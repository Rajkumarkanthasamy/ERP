﻿namespace Erp_Project_With_Buttons.Indent
{//this.dgBOMIndent.CellClick += dgBOMIndent_CellClick;
    partial class frmIndent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmIndent));
            this.pnitemlist = new System.Windows.Forms.Panel();
            this.chkItemDesc = new System.Windows.Forms.CheckBox();
            this.chkItemCode = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.chklbItemList = new System.Windows.Forms.CheckedListBox();
            this.txtItemDescription = new System.Windows.Forms.TextBox();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.lblReturnedby = new System.Windows.Forms.Label();
            this.dgIndentList = new System.Windows.Forms.DataGridView();
            this.ItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Units = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AvailableQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.testBatchCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.testAssignQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.testLocation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pickUpLocation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pickUpBatchCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgIndentListRough = new System.Windows.Forms.DataGridViewButtonColumn();
            this.pnIndent = new System.Windows.Forms.Panel();
            this.cmbProjectCode = new System.Windows.Forms.TextBox();
            this.chkApprove = new System.Windows.Forms.CheckBox();
            this.lblVersion = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblProjectStatus = new System.Windows.Forms.Label();
            this.cmbbomname = new System.Windows.Forms.ComboBox();
            this.lblprdname = new System.Windows.Forms.Label();
            this.lblProductName = new System.Windows.Forms.Label();
            this.lblcustomername = new System.Windows.Forms.Label();
            this.lblprojectbom = new System.Windows.Forms.Label();
            this.pndate = new System.Windows.Forms.Panel();
            this.lblindentby = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblindentdate = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dtpIndentDate = new System.Windows.Forms.DateTimePicker();
            this.lblprojname = new System.Windows.Forms.Label();
            this.cmbIndentNo = new System.Windows.Forms.ComboBox();
            this.lblcustomer = new System.Windows.Forms.Label();
            this.lblIndentNO = new System.Windows.Forms.Label();
            this.lblrowcount = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.lblRemarks = new System.Windows.Forms.Label();
            this.lblProjectCode = new System.Windows.Forms.Label();
            this.lblProjectName = new System.Windows.Forms.Label();
            this.btnviewpolist = new System.Windows.Forms.Button();
            this.btnApprove = new System.Windows.Forms.Button();
            this.btnSaveExcel = new System.Windows.Forms.Button();
            this.btnView = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClearAll = new System.Windows.Forms.Button();
            this.pickUpDone = new System.Windows.Forms.Button();
            this.dgBOMIndent = new System.Windows.Forms.DataGridView();
            this.BOMItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BOMItemDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BOMUnit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BOMAvailableQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BOMQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IssuedQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BOMIndentQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectBOMCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.batchCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.location = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AssignQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pickUpLocation1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pickUpBatchCode1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rough = new System.Windows.Forms.DataGridViewButtonColumn();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.ReviewTextBox = new Erp_Project_With_Buttons.SpellCheck();
            this.textBox1 = new System.Windows.Controls.TextBox();
            this.pnitemlist.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgIndentList)).BeginInit();
            this.pnIndent.SuspendLayout();
            this.pndate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgBOMIndent)).BeginInit();
            this.SuspendLayout();
            // 
            // pnitemlist
            // 
            this.pnitemlist.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnitemlist.Controls.Add(this.chkItemDesc);
            this.pnitemlist.Controls.Add(this.chkItemCode);
            this.pnitemlist.Controls.Add(this.label3);
            this.pnitemlist.Controls.Add(this.chklbItemList);
            this.pnitemlist.Controls.Add(this.txtItemDescription);
            this.pnitemlist.Enabled = false;
            this.pnitemlist.Location = new System.Drawing.Point(4, 5);
            this.pnitemlist.Name = "pnitemlist";
            this.pnitemlist.Size = new System.Drawing.Size(498, 251);
            this.pnitemlist.TabIndex = 15;
            // 
            // chkItemDesc
            // 
            this.chkItemDesc.AutoSize = true;
            this.chkItemDesc.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemDesc.ForeColor = System.Drawing.Color.Black;
            this.chkItemDesc.Location = new System.Drawing.Point(225, 2);
            this.chkItemDesc.Name = "chkItemDesc";
            this.chkItemDesc.Size = new System.Drawing.Size(140, 23);
            this.chkItemDesc.TabIndex = 209;
            this.chkItemDesc.Text = "Item Description";
            this.chkItemDesc.UseVisualStyleBackColor = true;
            this.chkItemDesc.CheckedChanged += new System.EventHandler(this.chkItemDesc_CheckedChanged);
            // 
            // chkItemCode
            // 
            this.chkItemCode.AutoSize = true;
            this.chkItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemCode.ForeColor = System.Drawing.Color.Black;
            this.chkItemCode.Location = new System.Drawing.Point(129, 2);
            this.chkItemCode.Name = "chkItemCode";
            this.chkItemCode.Size = new System.Drawing.Size(97, 23);
            this.chkItemCode.TabIndex = 208;
            this.chkItemCode.Text = "Item Code";
            this.chkItemCode.UseVisualStyleBackColor = true;
            this.chkItemCode.CheckedChanged += new System.EventHandler(this.chkItemCode_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(3, 2);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 19);
            this.label3.TabIndex = 124;
            this.label3.Text = "Search Item by";
            // 
            // chklbItemList
            // 
            this.chklbItemList.CheckOnClick = true;
            this.chklbItemList.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chklbItemList.FormattingEnabled = true;
            this.chklbItemList.HorizontalScrollbar = true;
            this.chklbItemList.Location = new System.Drawing.Point(3, 75);
            this.chklbItemList.Name = "chklbItemList";
            this.chklbItemList.Size = new System.Drawing.Size(731, 151);
            this.chklbItemList.TabIndex = 117;
            this.chklbItemList.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.chklbItemList_ItemCheck);
            // 
            // txtItemDescription
            // 
            this.txtItemDescription.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemDescription.Location = new System.Drawing.Point(7, 26);
            this.txtItemDescription.Multiline = true;
            this.txtItemDescription.Name = "txtItemDescription";
            this.txtItemDescription.Size = new System.Drawing.Size(483, 44);
            this.txtItemDescription.TabIndex = 121;
            this.txtItemDescription.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtItemDescription_KeyPress);
            this.txtItemDescription.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemDescription_KeyUp);
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.ForeColor = System.Drawing.Color.Black;
            this.lblWelcome.Location = new System.Drawing.Point(245, 563);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(98, 24);
            this.lblWelcome.TabIndex = 22;
            this.lblWelcome.Text = "Welcome :";
            // 
            // lblReturnedby
            // 
            this.lblReturnedby.AutoSize = true;
            this.lblReturnedby.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturnedby.ForeColor = System.Drawing.Color.Black;
            this.lblReturnedby.Location = new System.Drawing.Point(341, 563);
            this.lblReturnedby.Name = "lblReturnedby";
            this.lblReturnedby.Size = new System.Drawing.Size(0, 24);
            this.lblReturnedby.TabIndex = 21;
            // 
            // dgIndentList
            // 
            this.dgIndentList.AllowUserToAddRows = false;
            this.dgIndentList.AllowUserToDeleteRows = false;
            this.dgIndentList.AllowUserToResizeRows = false;
            this.dgIndentList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgIndentList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgIndentList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgIndentList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgIndentList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgIndentList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ItemCode,
            this.ItemDescription,
            this.Units,
            this.AvailableQty,
            this.Quantity,
            this.testBatchCode,
            this.testAssignQty,
            this.testLocation,
            this.pickUpLocation,
            this.pickUpBatchCode,
            this.dgIndentListRough});
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgIndentList.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgIndentList.EnableHeadersVisualStyles = false;
            this.dgIndentList.Location = new System.Drawing.Point(4, 262);
            this.dgIndentList.MultiSelect = false;
            this.dgIndentList.Name = "dgIndentList";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgIndentList.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgIndentList.RowHeadersVisible = false;
            this.dgIndentList.RowHeadersWidth = 62;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgIndentList.RowsDefaultCellStyle = dataGridViewCellStyle7;
            this.dgIndentList.Size = new System.Drawing.Size(1254, 292);
            this.dgIndentList.TabIndex = 122;
            this.dgIndentList.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgIndentList_CellBeginEdit);
            this.dgIndentList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgIndentList_CellClick);
            this.dgIndentList.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgIndentList_CellEndEdit);
            this.dgIndentList.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgIndentList_EditingControlShowing);
            this.dgIndentList.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgIndentList_KeyUp);
            // 
            // ItemCode
            // 
            this.ItemCode.DataPropertyName = "ItemCode";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ItemCode.DefaultCellStyle = dataGridViewCellStyle2;
            this.ItemCode.FillWeight = 32.55033F;
            this.ItemCode.HeaderText = "Item Code";
            this.ItemCode.MinimumWidth = 8;
            this.ItemCode.Name = "ItemCode";
            this.ItemCode.ReadOnly = true;
            this.ItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemCode.Width = 97;
            // 
            // ItemDescription
            // 
            this.ItemDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ItemDescription.DataPropertyName = "ItemDescription";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ItemDescription.DefaultCellStyle = dataGridViewCellStyle3;
            this.ItemDescription.HeaderText = "Item Desc";
            this.ItemDescription.MinimumWidth = 8;
            this.ItemDescription.Name = "ItemDescription";
            this.ItemDescription.ReadOnly = true;
            this.ItemDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemDescription.Width = 99;
            // 
            // Units
            // 
            this.Units.DataPropertyName = "Units";
            this.Units.FillWeight = 46.78395F;
            this.Units.HeaderText = "UOM";
            this.Units.MinimumWidth = 8;
            this.Units.Name = "Units";
            this.Units.ReadOnly = true;
            this.Units.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Units.Width = 58;
            // 
            // AvailableQty
            // 
            this.AvailableQty.DataPropertyName = "AvailableQty";
            this.AvailableQty.FillWeight = 155.6846F;
            this.AvailableQty.HeaderText = "Available Qty";
            this.AvailableQty.MinimumWidth = 8;
            this.AvailableQty.Name = "AvailableQty";
            this.AvailableQty.ReadOnly = true;
            this.AvailableQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.AvailableQty.Width = 123;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "ReqQty";
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Quantity.DefaultCellStyle = dataGridViewCellStyle4;
            this.Quantity.FillWeight = 164.9812F;
            this.Quantity.HeaderText = "Indent Qty";
            this.Quantity.MinimumWidth = 8;
            this.Quantity.Name = "Quantity";
            this.Quantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Quantity.Width = 101;
            // 
            // testBatchCode
            // 
            this.testBatchCode.DataPropertyName = "testBatchCode";
            this.testBatchCode.DefaultCellStyle = dataGridViewCellStyle2;
            this.testBatchCode.FillWeight = 32.55033F;
            this.testBatchCode.HeaderText = "Batch Code";
            this.testBatchCode.MinimumWidth = 8;
            this.testBatchCode.Name = "testBatchCode";
            this.testBatchCode.ReadOnly = true;
            this.testBatchCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.testBatchCode.Visible = false;
            this.testBatchCode.Width = 142;
            // 
            // testAssignQty
            // 
            this.testAssignQty.DataPropertyName = "testAssignQty";
            this.testAssignQty.DefaultCellStyle = dataGridViewCellStyle2;
            this.testAssignQty.FillWeight = 32.55033F;
            this.testAssignQty.HeaderText = "Assign Qty";
            this.testAssignQty.MinimumWidth = 8;
            this.testAssignQty.Name = "testAssignQty";
            this.testAssignQty.ReadOnly = true;
            this.testAssignQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.testAssignQty.Visible = false;
            this.testAssignQty.Width = 136;
            // 
            // testLocation
            // 
            this.testLocation.DataPropertyName = "testLocation";
            this.testLocation.DefaultCellStyle = dataGridViewCellStyle2;
            this.testLocation.FillWeight = 32.55033F;
            this.testLocation.HeaderText = "Location";
            this.testLocation.MinimumWidth = 8;
            this.testLocation.Name = "testLocation";
            this.testLocation.ReadOnly = true;
            this.testLocation.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.testLocation.Visible = false;
            this.testLocation.Width = 124;
            // 
            // pickUpLocation
            // 
            this.pickUpLocation.DataPropertyName = "pickUpLocation";
            this.pickUpLocation.HeaderText = "PickUp Location";
            this.pickUpLocation.MinimumWidth = 8;
            this.pickUpLocation.Name = "pickUpLocation";
            this.pickUpLocation.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.pickUpLocation.Visible = false;
            this.pickUpLocation.Width = 193;
            // 
            // pickUpBatchCode
            // 
            this.pickUpBatchCode.DataPropertyName = "pickUpBatchCode";
            this.pickUpBatchCode.HeaderText = "PickUp BatchCode";
            this.pickUpBatchCode.MinimumWidth = 8;
            this.pickUpBatchCode.Name = "pickUpBatchCode";
            this.pickUpBatchCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.pickUpBatchCode.Visible = false;
            this.pickUpBatchCode.Width = 217;
            // 
            // dgIndentListRough
            // 
            this.dgIndentListRough.DataPropertyName = "dgIndentListRough";
            this.dgIndentListRough.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.dgIndentListRough.HeaderText = "Scan";
            this.dgIndentListRough.MinimumWidth = 8;
            this.dgIndentListRough.Name = "dgIndentListRough";
            this.dgIndentListRough.Text = "Scan";
            this.dgIndentListRough.UseColumnTextForButtonValue = true;
            this.dgIndentListRough.Visible = false;
            this.dgIndentListRough.Width = 77;
            // 
            // pnIndent
            // 
            this.pnIndent.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnIndent.Controls.Add(this.cmbProjectCode);
            this.pnIndent.Controls.Add(this.chkApprove);
            this.pnIndent.Controls.Add(this.lblVersion);
            this.pnIndent.Controls.Add(this.label5);
            this.pnIndent.Controls.Add(this.label9);
            this.pnIndent.Controls.Add(this.lblProjectStatus);
            this.pnIndent.Controls.Add(this.cmbbomname);
            this.pnIndent.Controls.Add(this.lblprdname);
            this.pnIndent.Controls.Add(this.lblProductName);
            this.pnIndent.Controls.Add(this.lblcustomername);
            this.pnIndent.Controls.Add(this.lblprojectbom);
            this.pnIndent.Controls.Add(this.pndate);
            this.pnIndent.Controls.Add(this.dtpIndentDate);
            this.pnIndent.Controls.Add(this.lblprojname);
            this.pnIndent.Controls.Add(this.cmbIndentNo);
            this.pnIndent.Controls.Add(this.lblcustomer);
            this.pnIndent.Controls.Add(this.lblIndentNO);
            this.pnIndent.Controls.Add(this.lblrowcount);
            this.pnIndent.Controls.Add(this.label2);
            this.pnIndent.Controls.Add(this.txtRemarks);
            this.pnIndent.Controls.Add(this.lblRemarks);
            this.pnIndent.Controls.Add(this.lblProjectCode);
            this.pnIndent.Controls.Add(this.lblProjectName);
            this.pnIndent.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnIndent.Location = new System.Drawing.Point(505, 5);
            this.pnIndent.Name = "pnIndent";
            this.pnIndent.Size = new System.Drawing.Size(753, 251);
            this.pnIndent.TabIndex = 123;
            // 
            // cmbProjectCode
            // 
            this.cmbProjectCode.BackColor = System.Drawing.Color.LightGreen;
            this.cmbProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.cmbProjectCode.Location = new System.Drawing.Point(97, 8);
            this.cmbProjectCode.Name = "cmbProjectCode";
            this.cmbProjectCode.ReadOnly = true;
            this.cmbProjectCode.Size = new System.Drawing.Size(286, 26);
            this.cmbProjectCode.TabIndex = 210;
            this.toolTip1.SetToolTip(this.cmbProjectCode, "Double click to view project list");
            this.cmbProjectCode.TextChanged += new System.EventHandler(this.cmbProjectCode_TextChanged);
            this.cmbProjectCode.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.cmbProjectCode_MouseDoubleClick);
            // 
            // chkApprove
            // 
            this.chkApprove.AutoSize = true;
            this.chkApprove.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkApprove.ForeColor = System.Drawing.Color.ForestGreen;
            this.chkApprove.Location = new System.Drawing.Point(565, 202);
            this.chkApprove.Name = "chkApprove";
            this.chkApprove.Size = new System.Drawing.Size(167, 30);
            this.chkApprove.TabIndex = 209;
            this.chkApprove.Text = "Approve Indent";
            this.chkApprove.UseVisualStyleBackColor = true;
            this.chkApprove.CheckedChanged += new System.EventHandler(this.chkApprove_CheckedChanged);
            // 
            // lblVersion
            // 
            this.lblVersion.AutoSize = true;
            this.lblVersion.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVersion.ForeColor = System.Drawing.Color.Black;
            this.lblVersion.Location = new System.Drawing.Point(468, 93);
            this.lblVersion.MaximumSize = new System.Drawing.Size(300, 0);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(15, 18);
            this.lblVersion.TabIndex = 139;
            this.lblVersion.Text = "x";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(405, 93);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 18);
            this.label5.TabIndex = 138;
            this.label5.Text = "Version :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(419, 22);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(100, 18);
            this.label9.TabIndex = 137;
            this.label9.Text = "Project Status :";
            // 
            // lblProjectStatus
            // 
            this.lblProjectStatus.AutoSize = true;
            this.lblProjectStatus.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectStatus.ForeColor = System.Drawing.Color.Black;
            this.lblProjectStatus.Location = new System.Drawing.Point(521, 22);
            this.lblProjectStatus.Name = "lblProjectStatus";
            this.lblProjectStatus.Size = new System.Drawing.Size(34, 18);
            this.lblProjectStatus.TabIndex = 136;
            this.lblProjectStatus.Text = "WIP";
            // 
            // cmbbomname
            // 
            this.cmbbomname.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbbomname.DropDownHeight = 130;
            this.cmbbomname.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbbomname.DropDownWidth = 680;
            this.cmbbomname.Enabled = false;
            this.cmbbomname.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbbomname.FormattingEnabled = true;
            this.cmbbomname.IntegralHeight = false;
            this.cmbbomname.Location = new System.Drawing.Point(97, 75);
            this.cmbbomname.Name = "cmbbomname";
            this.cmbbomname.Size = new System.Drawing.Size(286, 23);
            this.cmbbomname.TabIndex = 75;
            this.cmbbomname.SelectedIndexChanged += new System.EventHandler(this.cmbbomname_SelectedIndexChanged);
            // 
            // lblprdname
            // 
            this.lblprdname.AutoSize = true;
            this.lblprdname.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprdname.ForeColor = System.Drawing.Color.Black;
            this.lblprdname.Location = new System.Drawing.Point(390, 70);
            this.lblprdname.Name = "lblprdname";
            this.lblprdname.Size = new System.Drawing.Size(103, 18);
            this.lblprdname.TabIndex = 4;
            this.lblprdname.Text = "Product Name :";
            // 
            // lblProductName
            // 
            this.lblProductName.AutoSize = true;
            this.lblProductName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductName.ForeColor = System.Drawing.Color.Black;
            this.lblProductName.Location = new System.Drawing.Point(493, 70);
            this.lblProductName.MaximumSize = new System.Drawing.Size(300, 0);
            this.lblProductName.Name = "lblProductName";
            this.lblProductName.Size = new System.Drawing.Size(15, 18);
            this.lblProductName.TabIndex = 134;
            this.lblProductName.Text = "x";
            // 
            // lblcustomername
            // 
            this.lblcustomername.AutoSize = true;
            this.lblcustomername.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcustomername.ForeColor = System.Drawing.Color.Black;
            this.lblcustomername.Location = new System.Drawing.Point(516, 2);
            this.lblcustomername.Name = "lblcustomername";
            this.lblcustomername.Size = new System.Drawing.Size(15, 18);
            this.lblcustomername.TabIndex = 134;
            this.lblcustomername.Text = "x";
            // 
            // lblprojectbom
            // 
            this.lblprojectbom.AutoSize = true;
            this.lblprojectbom.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.lblprojectbom.ForeColor = System.Drawing.Color.Black;
            this.lblprojectbom.Location = new System.Drawing.Point(1, 78);
            this.lblprojectbom.Name = "lblprojectbom";
            this.lblprojectbom.Size = new System.Drawing.Size(97, 18);
            this.lblprojectbom.TabIndex = 74;
            this.lblprojectbom.Text = "BOM Product :";
            // 
            // pndate
            // 
            this.pndate.Controls.Add(this.lblindentby);
            this.pndate.Controls.Add(this.label1);
            this.pndate.Controls.Add(this.lblindentdate);
            this.pndate.Controls.Add(this.label4);
            this.pndate.Location = new System.Drawing.Point(397, 151);
            this.pndate.Name = "pndate";
            this.pndate.Size = new System.Drawing.Size(292, 51);
            this.pndate.TabIndex = 135;
            this.pndate.Visible = false;
            // 
            // lblindentby
            // 
            this.lblindentby.AutoSize = true;
            this.lblindentby.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblindentby.ForeColor = System.Drawing.Color.Black;
            this.lblindentby.Location = new System.Drawing.Point(87, 7);
            this.lblindentby.Name = "lblindentby";
            this.lblindentby.Size = new System.Drawing.Size(15, 18);
            this.lblindentby.TabIndex = 69;
            this.lblindentby.Text = "x";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(15, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 18);
            this.label1.TabIndex = 4;
            this.label1.Text = "Indent By :";
            // 
            // lblindentdate
            // 
            this.lblindentdate.AutoSize = true;
            this.lblindentdate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblindentdate.ForeColor = System.Drawing.Color.Black;
            this.lblindentdate.Location = new System.Drawing.Point(87, 31);
            this.lblindentdate.Name = "lblindentdate";
            this.lblindentdate.Size = new System.Drawing.Size(15, 18);
            this.lblindentdate.TabIndex = 70;
            this.lblindentdate.Text = "x";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(3, 31);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 18);
            this.label4.TabIndex = 4;
            this.label4.Text = "Indent date :";
            // 
            // dtpIndentDate
            // 
            this.dtpIndentDate.Checked = false;
            this.dtpIndentDate.Enabled = false;
            this.dtpIndentDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpIndentDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpIndentDate.Location = new System.Drawing.Point(641, 87);
            this.dtpIndentDate.Name = "dtpIndentDate";
            this.dtpIndentDate.Size = new System.Drawing.Size(87, 26);
            this.dtpIndentDate.TabIndex = 1;
            // 
            // lblprojname
            // 
            this.lblprojname.AutoSize = true;
            this.lblprojname.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprojname.ForeColor = System.Drawing.Color.Black;
            this.lblprojname.Location = new System.Drawing.Point(94, 45);
            this.lblprojname.Name = "lblprojname";
            this.lblprojname.Size = new System.Drawing.Size(15, 18);
            this.lblprojname.TabIndex = 133;
            this.lblprojname.Text = "x";
            // 
            // cmbIndentNo
            // 
            this.cmbIndentNo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbIndentNo.DropDownHeight = 130;
            this.cmbIndentNo.DropDownWidth = 239;
            this.cmbIndentNo.Enabled = false;
            this.cmbIndentNo.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbIndentNo.FormattingEnabled = true;
            this.cmbIndentNo.IntegralHeight = false;
            this.cmbIndentNo.Items.AddRange(new object[] {
            "None"});
            this.cmbIndentNo.Location = new System.Drawing.Point(97, 111);
            this.cmbIndentNo.Name = "cmbIndentNo";
            this.cmbIndentNo.Size = new System.Drawing.Size(286, 26);
            this.cmbIndentNo.TabIndex = 62;
            this.cmbIndentNo.SelectedIndexChanged += new System.EventHandler(this.cmbIndentNo_SelectedIndexChanged);
            // 
            // lblcustomer
            // 
            this.lblcustomer.AutoSize = true;
            this.lblcustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcustomer.ForeColor = System.Drawing.Color.Black;
            this.lblcustomer.Location = new System.Drawing.Point(444, 2);
            this.lblcustomer.Name = "lblcustomer";
            this.lblcustomer.Size = new System.Drawing.Size(75, 18);
            this.lblcustomer.TabIndex = 72;
            this.lblcustomer.Text = "Customer :";
            // 
            // lblIndentNO
            // 
            this.lblIndentNO.AutoSize = true;
            this.lblIndentNO.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndentNO.ForeColor = System.Drawing.Color.Black;
            this.lblIndentNO.Location = new System.Drawing.Point(21, 114);
            this.lblIndentNO.Name = "lblIndentNO";
            this.lblIndentNO.Size = new System.Drawing.Size(77, 18);
            this.lblIndentNO.TabIndex = 61;
            this.lblIndentNO.Text = "Indent No :";
            // 
            // lblrowcount
            // 
            this.lblrowcount.AutoSize = true;
            this.lblrowcount.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrowcount.ForeColor = System.Drawing.Color.Red;
            this.lblrowcount.Location = new System.Drawing.Point(512, 209);
            this.lblrowcount.Name = "lblrowcount";
            this.lblrowcount.Size = new System.Drawing.Size(0, 18);
            this.lblrowcount.TabIndex = 67;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(394, 209);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 18);
            this.label2.TabIndex = 68;
            this.label2.Text = "Total no of Items :";
            // 
            // txtRemarks
            // 
            this.txtRemarks.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemarks.Location = new System.Drawing.Point(97, 149);
            this.txtRemarks.Multiline = true;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRemarks.Size = new System.Drawing.Size(286, 78);
            this.txtRemarks.TabIndex = 52;
            // 
            // lblRemarks
            // 
            this.lblRemarks.AutoSize = true;
            this.lblRemarks.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRemarks.ForeColor = System.Drawing.Color.Black;
            this.lblRemarks.Location = new System.Drawing.Point(30, 149);
            this.lblRemarks.Name = "lblRemarks";
            this.lblRemarks.Size = new System.Drawing.Size(68, 18);
            this.lblRemarks.TabIndex = 4;
            this.lblRemarks.Text = "Remarks :";
            // 
            // lblProjectCode
            // 
            this.lblProjectCode.AutoSize = true;
            this.lblProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectCode.ForeColor = System.Drawing.Color.Black;
            this.lblProjectCode.Location = new System.Drawing.Point(1, 11);
            this.lblProjectCode.Name = "lblProjectCode";
            this.lblProjectCode.Size = new System.Drawing.Size(94, 18);
            this.lblProjectCode.TabIndex = 59;
            this.lblProjectCode.Text = "Project Code :";
            // 
            // lblProjectName
            // 
            this.lblProjectName.AutoSize = true;
            this.lblProjectName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectName.ForeColor = System.Drawing.Color.Black;
            this.lblProjectName.Location = new System.Drawing.Point(-1, 45);
            this.lblProjectName.Name = "lblProjectName";
            this.lblProjectName.Size = new System.Drawing.Size(99, 18);
            this.lblProjectName.TabIndex = 1;
            this.lblProjectName.Text = "Project Name :";
            // 
            // btnviewpolist
            // 
            this.btnviewpolist.BackColor = System.Drawing.Color.Chocolate;
            this.btnviewpolist.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnviewpolist.Location = new System.Drawing.Point(4, 559);
            this.btnviewpolist.Name = "btnviewpolist";
            this.btnviewpolist.Size = new System.Drawing.Size(219, 32);
            this.btnviewpolist.TabIndex = 127;
            this.btnviewpolist.Text = "View Indent List";
            this.btnviewpolist.UseVisualStyleBackColor = false;
            this.btnviewpolist.Click += new System.EventHandler(this.btnviewpolist_Click);
            // 
            // btnApprove
            // 
            this.btnApprove.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnApprove.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnApprove.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnApprove.Location = new System.Drawing.Point(574, 564);
            this.btnApprove.Name = "btnApprove";
            this.btnApprove.Size = new System.Drawing.Size(88, 33);
            this.btnApprove.TabIndex = 15;
            this.btnApprove.Text = "Approve";
            this.btnApprove.UseVisualStyleBackColor = false;
            this.btnApprove.Click += new System.EventHandler(this.btnApprove_Click);
            // 
            // btnSaveExcel
            // 
            this.btnSaveExcel.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSaveExcel.Enabled = false;
            this.btnSaveExcel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSaveExcel.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveExcel.Location = new System.Drawing.Point(1027, 563);
            this.btnSaveExcel.Name = "btnSaveExcel";
            this.btnSaveExcel.Size = new System.Drawing.Size(88, 32);
            this.btnSaveExcel.TabIndex = 14;
            this.btnSaveExcel.Text = "Print";
            this.btnSaveExcel.UseVisualStyleBackColor = false;
            this.btnSaveExcel.Click += new System.EventHandler(this.btnSaveExcel_Click);
            // 
            // btnView
            // 
            this.btnView.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnView.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnView.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnView.Location = new System.Drawing.Point(910, 563);
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(88, 32);
            this.btnView.TabIndex = 11;
            this.btnView.Text = "View";
            this.btnView.UseVisualStyleBackColor = false;
            this.btnView.Click += new System.EventHandler(this.btnView_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(793, 563);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(88, 32);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClearAll
            // 
            this.btnClearAll.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnClearAll.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnClearAll.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearAll.Location = new System.Drawing.Point(1144, 563);
            this.btnClearAll.Name = "btnClearAll";
            this.btnClearAll.Size = new System.Drawing.Size(88, 32);
            this.btnClearAll.TabIndex = 7;
            this.btnClearAll.Text = "Clear All";
            this.btnClearAll.UseVisualStyleBackColor = false;
            this.btnClearAll.Click += new System.EventHandler(this.btnClearAll_Click);
            // 
            // pickUpDone
            // 
            this.pickUpDone.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.pickUpDone.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.pickUpDone.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pickUpDone.Location = new System.Drawing.Point(668, 564);
            this.pickUpDone.Name = "pickUpDone";
            this.pickUpDone.Size = new System.Drawing.Size(119, 32);
            this.pickUpDone.TabIndex = 136;
            this.pickUpDone.Text = "PickUp Done";
            this.pickUpDone.UseVisualStyleBackColor = false;
            this.pickUpDone.Visible = false;
            this.pickUpDone.Click += new System.EventHandler(this.btnPickUpDone);
            // 
            // dgBOMIndent
            // 
            this.dgBOMIndent.AllowUserToAddRows = false;
            this.dgBOMIndent.AllowUserToDeleteRows = false;
            this.dgBOMIndent.AllowUserToResizeRows = false;
            this.dgBOMIndent.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgBOMIndent.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgBOMIndent.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgBOMIndent.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dgBOMIndent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgBOMIndent.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.BOMItemCode,
            this.BOMItemDesc,
            this.BOMUnit,
            this.BOMAvailableQty,
            this.BOMQty,
            this.IssuedQty,
            this.BOMIndentQty,
            this.ProjectBOMCode,
            this.ProductNo,
            this.batchCode,
            this.location,
            this.AssignQty,
            this.pickUpLocation1,
            this.pickUpBatchCode1,
            this.rough});
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgBOMIndent.DefaultCellStyle = dataGridViewCellStyle12;
            this.dgBOMIndent.EnableHeadersVisualStyles = false;
            this.dgBOMIndent.Location = new System.Drawing.Point(4, 262);
            this.dgBOMIndent.MultiSelect = false;
            this.dgBOMIndent.Name = "dgBOMIndent";
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgBOMIndent.RowHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dgBOMIndent.RowHeadersVisible = false;
            this.dgBOMIndent.RowHeadersWidth = 62;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgBOMIndent.RowsDefaultCellStyle = dataGridViewCellStyle14;
            this.dgBOMIndent.Size = new System.Drawing.Size(1254, 292);
            this.dgBOMIndent.TabIndex = 135;
            this.dgBOMIndent.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgBOMIndent_CellBeginEdit);
            this.dgBOMIndent.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgBOMIndent_CellClick);
            this.dgBOMIndent.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgBOMIndent_CellContentClick);
            this.dgBOMIndent.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgBOMIndent_CellEndEdit);
            this.dgBOMIndent.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgBOMIndent_EditingControlShowing);
            this.dgBOMIndent.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgBOMIndent_KeyUp);
            // 
            // BOMItemCode
            // 
            this.BOMItemCode.DataPropertyName = "ItemName";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.BOMItemCode.DefaultCellStyle = dataGridViewCellStyle9;
            this.BOMItemCode.HeaderText = "Item Code";
            this.BOMItemCode.MinimumWidth = 8;
            this.BOMItemCode.Name = "BOMItemCode";
            this.BOMItemCode.ReadOnly = true;
            this.BOMItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.BOMItemCode.Width = 97;
            // 
            // BOMItemDesc
            // 
            this.BOMItemDesc.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.BOMItemDesc.DataPropertyName = "ItemDescription";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.BOMItemDesc.DefaultCellStyle = dataGridViewCellStyle10;
            this.BOMItemDesc.HeaderText = "Item Desc";
            this.BOMItemDesc.MinimumWidth = 8;
            this.BOMItemDesc.Name = "BOMItemDesc";
            this.BOMItemDesc.ReadOnly = true;
            this.BOMItemDesc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.BOMItemDesc.Width = 99;
            // 
            // BOMUnit
            // 
            this.BOMUnit.DataPropertyName = "Units";
            this.BOMUnit.HeaderText = "UOM";
            this.BOMUnit.MinimumWidth = 8;
            this.BOMUnit.Name = "BOMUnit";
            this.BOMUnit.ReadOnly = true;
            this.BOMUnit.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.BOMUnit.Width = 58;
            // 
            // BOMAvailableQty
            // 
            this.BOMAvailableQty.DataPropertyName = "AvailableQty";
            this.BOMAvailableQty.HeaderText = "Available Qty";
            this.BOMAvailableQty.MinimumWidth = 8;
            this.BOMAvailableQty.Name = "BOMAvailableQty";
            this.BOMAvailableQty.ReadOnly = true;
            this.BOMAvailableQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.BOMAvailableQty.Width = 123;
            // 
            // BOMQty
            // 
            this.BOMQty.DataPropertyName = "Quantity";
            this.BOMQty.HeaderText = "BOMQty";
            this.BOMQty.MinimumWidth = 8;
            this.BOMQty.Name = "BOMQty";
            this.BOMQty.ReadOnly = true;
            this.BOMQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.BOMQty.Width = 86;
            // 
            // IssuedQty
            // 
            this.IssuedQty.DataPropertyName = "IssuedQuantity";
            this.IssuedQty.HeaderText = "IssuedQty";
            this.IssuedQty.MinimumWidth = 8;
            this.IssuedQty.Name = "IssuedQty";
            this.IssuedQty.ReadOnly = true;
            this.IssuedQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IssuedQty.Width = 96;
            // 
            // BOMIndentQty
            // 
            this.BOMIndentQty.DataPropertyName = "IndentQty";
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.BOMIndentQty.DefaultCellStyle = dataGridViewCellStyle11;
            this.BOMIndentQty.HeaderText = "Indent Qty";
            this.BOMIndentQty.MinimumWidth = 8;
            this.BOMIndentQty.Name = "BOMIndentQty";
            this.BOMIndentQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.BOMIndentQty.Width = 101;
            // 
            // ProjectBOMCode
            // 
            this.ProjectBOMCode.DataPropertyName = "ProjectBOMCode";
            this.ProjectBOMCode.HeaderText = "ProjectBOMCode";
            this.ProjectBOMCode.MinimumWidth = 8;
            this.ProjectBOMCode.Name = "ProjectBOMCode";
            this.ProjectBOMCode.ReadOnly = true;
            this.ProjectBOMCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectBOMCode.Visible = false;
            this.ProjectBOMCode.Width = 229;
            // 
            // ProductNo
            // 
            this.ProductNo.DataPropertyName = "ProductNo";
            this.ProductNo.HeaderText = "ProductNo";
            this.ProductNo.MinimumWidth = 8;
            this.ProductNo.Name = "ProductNo";
            this.ProductNo.ReadOnly = true;
            this.ProductNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductNo.Visible = false;
            this.ProductNo.Width = 151;
            // 
            // batchCode
            // 
            this.batchCode.DataPropertyName = "batchCode";
            this.batchCode.DefaultCellStyle = dataGridViewCellStyle9;
            this.batchCode.HeaderText = "Batch Code";
            this.batchCode.MinimumWidth = 8;
            this.batchCode.Name = "batchCode";
            this.batchCode.ReadOnly = true;
            this.batchCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.batchCode.Visible = false;
            this.batchCode.Width = 142;
            // 
            // location
            // 
            this.location.DataPropertyName = "location";
            this.location.DefaultCellStyle = dataGridViewCellStyle9;
            this.location.HeaderText = "Location";
            this.location.MinimumWidth = 8;
            this.location.Name = "location";
            this.location.ReadOnly = true;
            this.location.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.location.Visible = false;
            this.location.Width = 124;
            // 
            // AssignQty
            // 
            this.AssignQty.DataPropertyName = "AssignQty";
            this.AssignQty.DefaultCellStyle = dataGridViewCellStyle9;
            this.AssignQty.HeaderText = "Assign Qty";
            this.AssignQty.MinimumWidth = 8;
            this.AssignQty.Name = "AssignQty";
            this.AssignQty.ReadOnly = true;
            this.AssignQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.AssignQty.Visible = false;
            this.AssignQty.Width = 136;
            // 
            // pickUpLocation1
            // 
            this.pickUpLocation1.DataPropertyName = "pickUpLocation1";
            this.pickUpLocation1.HeaderText = "pickUp Location";
            this.pickUpLocation1.MinimumWidth = 8;
            this.pickUpLocation1.Name = "pickUpLocation1";
            this.pickUpLocation1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.pickUpLocation1.Visible = false;
            this.pickUpLocation1.Width = 194;
            // 
            // pickUpBatchCode1
            // 
            this.pickUpBatchCode1.DataPropertyName = "pickUpBatchCode1";
            this.pickUpBatchCode1.HeaderText = "pickUp BatchCode";
            this.pickUpBatchCode1.MinimumWidth = 8;
            this.pickUpBatchCode1.Name = "pickUpBatchCode1";
            this.pickUpBatchCode1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.pickUpBatchCode1.Visible = false;
            this.pickUpBatchCode1.Width = 218;
            // 
            // rough
            // 
            this.rough.DataPropertyName = "rough";
            this.rough.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.rough.HeaderText = "Scan";
            this.rough.MinimumWidth = 8;
            this.rough.Name = "rough";
            this.rough.Text = "Scan";
            this.rough.UseColumnTextForButtonValue = true;
            this.rough.Visible = false;
            this.rough.Width = 77;
            // 
            // ReviewTextBox
            // 
            this.ReviewTextBox.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReviewTextBox.Location = new System.Drawing.Point(229, 89);
            this.ReviewTextBox.Multiline = true;
            this.ReviewTextBox.Name = "ReviewTextBox";
            this.ReviewTextBox.Size = new System.Drawing.Size(291, 69);
            this.ReviewTextBox.TabIndex = 211;
            this.ReviewTextBox.Child = this.textBox1;
            // 
            // frmIndent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1260, 618);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.lblReturnedby);
            this.Controls.Add(this.btnApprove);
            this.Controls.Add(this.dgBOMIndent);
            this.Controls.Add(this.btnSaveExcel);
            this.Controls.Add(this.btnviewpolist);
            this.Controls.Add(this.btnView);
            this.Controls.Add(this.pnIndent);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.dgIndentList);
            this.Controls.Add(this.btnClearAll);
            this.Controls.Add(this.pnitemlist);
            this.Controls.Add(this.pickUpDone);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmIndent";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Indent";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmIndent_FormClosing);
            this.Load += new System.EventHandler(this.frmIndent_Load);
            this.pnitemlist.ResumeLayout(false);
            this.pnitemlist.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgIndentList)).EndInit();
            this.pnIndent.ResumeLayout(false);
            this.pnIndent.PerformLayout();
            this.pndate.ResumeLayout(false);
            this.pndate.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgBOMIndent)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnitemlist;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckedListBox chklbItemList;
        private System.Windows.Forms.TextBox txtItemDescription;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Label lblReturnedby;
        private System.Windows.Forms.DataGridView dgIndentList;
        private System.Windows.Forms.Panel pnIndent;
        private System.Windows.Forms.Label lblcustomername;
        private System.Windows.Forms.Label lblprojname;
        private System.Windows.Forms.DateTimePicker dtpIndentDate;
        private System.Windows.Forms.Label lblindentdate;
        private System.Windows.Forms.ComboBox cmbIndentNo;
        private System.Windows.Forms.Label lblIndentNO;
        private System.Windows.Forms.Label lblcustomer;
        private System.Windows.Forms.Label lblrowcount;
        private System.Windows.Forms.Label lblProjectCode;
        private System.Windows.Forms.Label lblProjectName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblRemarks;
        private System.Windows.Forms.Label lblindentby;
        private System.Windows.Forms.Button btnviewpolist;
        private System.Windows.Forms.Button btnSaveExcel;
        private System.Windows.Forms.Button btnView;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClearAll;
        private System.Windows.Forms.Button pickUpDone;//PickUpDone
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pndate;
        private System.Windows.Forms.ComboBox cmbbomname;
        private System.Windows.Forms.Label lblprojectbom;
        private System.Windows.Forms.DataGridView dgBOMIndent;
        private System.Windows.Forms.Label lblprdname;
        private System.Windows.Forms.Label lblProductName;
        private System.Windows.Forms.Label lblProjectStatus;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckBox chkItemDesc;
        private System.Windows.Forms.CheckBox chkItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn testBatchCode;//testAssignQty
        private System.Windows.Forms.DataGridViewTextBoxColumn testAssignQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn testLocation;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn Units;
        private System.Windows.Forms.DataGridViewTextBoxColumn AvailableQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn pickUpLocation;
        private System.Windows.Forms.DataGridViewTextBoxColumn pickUpBatchCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn BOMItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn batchCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn AssignQty;//AssignQty
        private System.Windows.Forms.DataGridViewTextBoxColumn location;
        private System.Windows.Forms.DataGridViewTextBoxColumn BOMItemDesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn BOMUnit;
        private System.Windows.Forms.DataGridViewTextBoxColumn BOMAvailableQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn BOMQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssuedQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn BOMIndentQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn pickUpLocation1;
        private System.Windows.Forms.DataGridViewButtonColumn rough;
        private System.Windows.Forms.DataGridViewButtonColumn dgIndentListRough;//dgIndentListRough
        private System.Windows.Forms.DataGridViewTextBoxColumn pickUpBatchCode1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectBOMCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductNo;
        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnApprove;
        private System.Windows.Forms.CheckBox chkApprove;
        private System.Windows.Forms.TextBox cmbProjectCode;
        private System.Windows.Forms.ToolTip toolTip1;
        private SpellCheck ReviewTextBox;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Controls.TextBox textBox1;
    }
}