﻿#region NameSpace Declarations
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Diagnostics;
using System.Globalization;



using iTextSharp.text;
using iTextSharp.text.pdf;
using Font = System.Drawing.Font;
using System.ComponentModel;

#endregion


namespace Erp_Project_With_Buttons.Indent
{
    public partial class frmIndent : Form
    {
        #region Intialization of Local Datatables, Variables Daclaration
        DataAccessLayer DAL = new DataAccessLayer();
        Global GLobalClass = new Global();
        frmForm2 form = new frmForm2();
        Login.frmLoginForm login = new Login.frmLoginForm();
        DataTable dtItemList = new DataTable();
        //  DataTable dtTableFilter = new DataTable();
        DataView dvItemList = new DataView();
        DataTable dtProjectList = new DataTable();
        DataTable dtIndentNo = new DataTable();
        DataTable dtItemcode = new DataTable();
        DataTable dtItemAdd = new DataTable();
        DataTable dtBOMItemAdd = new DataTable();
        DataTable dtFinalSelectedItem = new DataTable();
        DataTable dtIndentList = new DataTable();
        DataTable dtIndentItems = new DataTable();
        DataTable dtProdcutName = new DataTable();
        DataTable dtBOMIndent = new DataTable();
        DataTable dtProjectBOMdetails = new DataTable();
        DataTable dtProjectBOM = new DataTable();
        DataTable dtprojectBOMItems = new DataTable();
        DataTable dtMachineBOMProduct = new DataTable();
        DataTable dtIssuedBOMItemQTY = new DataTable();




        public class BatchAllocation
        {
            public string BatchCode { get; set; }
            public string ItemLocation { get; set; }
            public double AllocatedQty { get; set; }
            public double RemainingQty { get; set; }
        }

        // Helper to parse BatchCode to DateTime
        



        public void ExportToPDFold(DataTable dtIndentItems, string filePath)
        {
            if (dtIndentItems == null || dtIndentItems.Rows.Count == 0)
                throw new Exception("No data to export.");

            // Create PDF document
            Document pdfDoc = new Document(PageSize.A4, 25, 25, 30, 30);
            PdfWriter.GetInstance(pdfDoc, new FileStream(filePath, FileMode.Create));
            pdfDoc.Open();

            // Add title
            Paragraph title = new Paragraph("Indent Items Report", FontFactory.GetFont("Arial", 16));
            title.Alignment = Element.ALIGN_CENTER;
            pdfDoc.Add(title);
            pdfDoc.Add(new Paragraph("\n")); // Add space

            // Create table with column count
            PdfPTable pdfTable = new PdfPTable(dtIndentItems.Columns.Count);
            pdfTable.WidthPercentage = 100;

            // Add headers
            foreach (DataColumn column in dtIndentItems.Columns)
            {
                PdfPCell cell = new PdfPCell(new Phrase(column.ColumnName, FontFactory.GetFont("Arial", 12)));
                cell.BackgroundColor = BaseColor.LIGHT_GRAY;
                cell.HorizontalAlignment = Element.ALIGN_CENTER;
                pdfTable.AddCell(cell);
            }

            // Add rows
            foreach (DataRow row in dtIndentItems.Rows)
            {
                foreach (var item in row.ItemArray)
                {
                    pdfTable.AddCell(new Phrase(item?.ToString() ?? "-", FontFactory.GetFont("Arial", 10)));
                }
            }

            // Add table to document
            pdfDoc.Add(pdfTable);
            pdfDoc.Close();
        }


        


public void ExportToPDFold2(DataTable dtIndentItems, string filePath, string receiverName = "", string createdDate = "", string createdByName = "")
    {
        if (dtIndentItems == null || dtIndentItems.Rows.Count == 0)
            throw new Exception("No data to export.");

        // Create PDF document
        var pdfDoc = new Document(PageSize.A4, 25, 25, 30, 30);
        var writer = PdfWriter.GetInstance(pdfDoc, new FileStream(filePath, FileMode.Create));
        pdfDoc.Open();

        // Fonts
        var titleFont = FontFactory.GetFont("Arial", 16);
        var headerFont = FontFactory.GetFont("Arial", 12);
        var cellFont = FontFactory.GetFont("Arial", 10);
        var labelFont = FontFactory.GetFont("Arial", 11);

        // Title
        var title = new Paragraph("Indent Items Report", titleFont) { Alignment = Element.ALIGN_CENTER };
        pdfDoc.Add(title);
        pdfDoc.Add(new Paragraph("\n"));

        // Table of data
        var pdfTable = new PdfPTable(dtIndentItems.Columns.Count) { WidthPercentage = 100 };

        // Headers
        foreach (DataColumn column in dtIndentItems.Columns)
        {
            var cell = new PdfPCell(new Phrase(column.ColumnName, headerFont))
            {
                BackgroundColor = BaseColor.LIGHT_GRAY,
                HorizontalAlignment = Element.ALIGN_CENTER
            };
            pdfTable.AddCell(cell);
        }

        // Rows
        foreach (DataRow row in dtIndentItems.Rows)
        {
            foreach (var item in row.ItemArray)
            {
                pdfTable.AddCell(new Phrase(item?.ToString() ?? "-", cellFont));
            }
        }

        pdfDoc.Add(pdfTable);

        // Spacer before signatures
        pdfDoc.Add(new Paragraph("\n\n"));

        // --- Signature Block (2 columns) ---
        var signatureTable = new PdfPTable(2);
        signatureTable.WidthPercentage = 100;
        signatureTable.SetWidths(new float[] { 1f, 1f }); // evenly spaced

        // Receiver block
        var receiverTitle = new PdfPCell(new Phrase("Created By", labelFont))
        {
            //Border = iTextSharp.text.Rectangle.NO_BORDER,
            PaddingBottom = 4f
        };
        signatureTable.AddCell(receiverTitle);

        // Created By block
        var createdByTitle = new PdfPCell(new Phrase("Receiver ", labelFont))
        {
            //Border = iTextSharp.text.Rectangle.NO_BORDER,
            PaddingBottom = 4f
        };
        signatureTable.AddCell(createdByTitle);

        // Signature lines (bottom border only)
        var receiverLine = new PdfPCell(new Phrase(receiverName ?? "", cellFont))
        {
            //Border = iTextSharp.text.Rectangle.BOTTOM_BORDER,
            PaddingTop = 12f,
            FixedHeight = 28f
        };
        signatureTable.AddCell(receiverLine);

        var createdByLine = new PdfPCell(new Phrase($"Name: {createdByName}" ?? "", cellFont))
        {
            //Border = iTextSharp.text.Rectangle.BOTTOM_BORDER,
            PaddingTop = 12f,
            FixedHeight = 28f
        };
        signatureTable.AddCell(createdByLine);

        // Optional: date rows under the signatures
        var receiverDate = new PdfPCell(new Phrase($"Date: {createdDate}", cellFont))
        {
           // Border = iTextSharp.text.Rectangle.NO_BORDER,
            PaddingTop = 8f
        };
        signatureTable.AddCell(receiverDate);

        var createdByDate = new PdfPCell(new Phrase("Date:", cellFont))
        {
            //Border = iTextSharp.text.Rectangle.BOTTOM_BORDER,
            PaddingTop = 8f
        };
            signatureTable.AddCell(createdByDate);

            var signatureTablePlace = new PdfPCell(new Phrase("Date:", cellFont))
            {
                //Border = iTextSharp.text.Rectangle.BOTTOM_BORDER,
                PaddingTop = 16f
            };
            signatureTable.AddCell(signatureTablePlace);

        pdfDoc.Add(signatureTable);

        pdfDoc.Close();
    }


        


        public void ExportToPDF_Old_(
            DataTable dtIndentItems,
            string filePath,
            string receiverName = "",
            string createdDate = "",
            string createdByName = "",
            string recievingDate="")
        {
            if (dtIndentItems == null || dtIndentItems.Rows.Count == 0)
                throw new Exception("No data to export.");

            var pdfDoc = new Document(PageSize.A4, 25, 25, 30, 30);
            var writer = PdfWriter.GetInstance(pdfDoc, new FileStream(filePath, FileMode.Create));
            pdfDoc.Open();

            // Fonts
            var titleFont = FontFactory.GetFont("Arial", 16, iTextSharp.text.Font.BOLD);
            var headerFont = FontFactory.GetFont("Arial", 12, iTextSharp.text.Font.BOLD);
            var cellFont = FontFactory.GetFont("Arial", 10, iTextSharp.text.Font.BOLD);

            // Title
            var title = new Paragraph("Indent Items Report", titleFont) { Alignment = Element.ALIGN_CENTER };
            pdfDoc.Add(title);
            pdfDoc.Add(new Paragraph("\n"));

            // Data table (your existing flow content)
            var pdfTable = new PdfPTable(dtIndentItems.Columns.Count) { WidthPercentage = 100 };

            foreach (DataColumn column in dtIndentItems.Columns)
            {
                var cell = new PdfPCell(new Phrase(column.ColumnName, headerFont))
                {
                    BackgroundColor = BaseColor.LIGHT_GRAY,
                    HorizontalAlignment = Element.ALIGN_CENTER
                };
                pdfTable.AddCell(cell);
            }

            foreach (DataRow row in dtIndentItems.Rows)
            {
                foreach (var item in row.ItemArray)
                {
                    pdfTable.AddCell(new Phrase(item?.ToString() ?? "-", cellFont));
                }
            }

            pdfDoc.Add(pdfTable);

            // -------- Bottom signature drawing (no table) --------
            // Direct content (absolute positioning)
            PdfContentByte cb = writer.DirectContent;

            // Page geometry
            float left = pdfDoc.LeftMargin;
            float right = pdfDoc.PageSize.Width - pdfDoc.RightMargin;
            float center = (left + right) / 2f;

            // Baseline Y position from the bottom margin
            // Adjust this value to move the block up/down.
            float baseY = pdfDoc.BottomMargin + 80f;

            // Signature line lengths
            float lineLen = (right - left) / 2f - 30f; // half page minus padding

            // Left block: Created By
            float createdLabelX = left;
            float createdLineStartX = left;
            float createdLineEndX = left + lineLen;

            // Right block: Receiver
            float receiverLabelX = center + 30f;
            float receiverLineStartX = receiverLabelX;
            float receiverLineEndX = receiverLabelX + lineLen;

            // Draw labels
            var bf = BaseFont.CreateFont(BaseFont.HELVETICA, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
            cb.BeginText();
            cb.SetFontAndSize(bf, 11);

            // Labels
            cb.ShowTextAligned(Element.ALIGN_LEFT, "Created By", createdLabelX, baseY + 28f, 0);
            cb.ShowTextAligned(Element.ALIGN_LEFT, "Receiver signature", receiverLabelX, baseY + 28f, 0);

            // Optional names above the lines
            cb.SetFontAndSize(bf, 10);
            if (!string.IsNullOrWhiteSpace(receiverName))
                cb.ShowTextAligned(Element.ALIGN_LEFT, $"Name: {receiverName}", createdLabelX+3, baseY + 14f, 0);
            if (!string.IsNullOrWhiteSpace(createdByName))
                cb.ShowTextAligned(Element.ALIGN_LEFT, $"Name: {createdByName}", receiverLabelX+3, baseY + 14f, 0);
            cb.ShowTextAligned(Element.ALIGN_LEFT, $"Name:", receiverLabelX+3, baseY + 14f, 0);
            cb.EndText();

            // Draw signature lines (bottom line only, visually)
            cb.SetLineWidth(0.8f);
            cb.MoveTo(createdLineStartX, baseY); cb.LineTo(createdLineEndX, baseY); cb.Stroke();
            cb.MoveTo(receiverLineStartX, baseY); cb.LineTo(receiverLineEndX, baseY); cb.Stroke();

            // Optional: date text under lines
            cb.BeginText();
            cb.SetFontAndSize(bf, 10);
            cb.ShowTextAligned(Element.ALIGN_LEFT, $"Date: {createdDate}", createdLabelX, baseY - 16f, 0);
            cb.ShowTextAligned(Element.ALIGN_LEFT, $"Date:{recievingDate}", receiverLabelX, baseY - 16f, 0);
            cb.EndText();

            

            // -----------------------------------------------------

            pdfDoc.Close();
        }


        public void ExportToPDF(

            DataTable dtIndentItems,
            string filePath,
            string receiverName = "",
            string createdDate = "",
            string createdByName = "",
            string recievingDate = "",
            // NEW: header arguments
            string indentNumber = "",
            string projectCode = "",
            string projectName = "",
            string remarks = "",
            string indentBy = "",
            string indentDate = ""
        )
        {
            if (dtIndentItems == null || dtIndentItems.Rows.Count == 0)
                throw new Exception("No data to export.");

            var pdfDoc = new Document(PageSize.A4, 25, 25, 30, 30);
            var writer = PdfWriter.GetInstance(pdfDoc, new FileStream(filePath, FileMode.Create));
            pdfDoc.Open();

            // Fonts
            var titleFont = FontFactory.GetFont("Arial", 16, iTextSharp.text.Font.BOLD);
            var headerFont = FontFactory.GetFont("Arial", 12, iTextSharp.text.Font.BOLD);
            var cellFont = FontFactory.GetFont("Arial", 10, iTextSharp.text.Font.NORMAL);
            var labelFont = FontFactory.GetFont("Arial", 11, iTextSharp.text.Font.BOLD);
            var valueFont = FontFactory.GetFont("Arial", 11, iTextSharp.text.Font.NORMAL);

            // ======= HEADER BLOCK (like your sample) =======

            // Header Title: "Indent"
            var indentTitle = new Paragraph("Indent", titleFont) { Alignment = Element.ALIGN_CENTER };
            pdfDoc.Add(indentTitle);
            pdfDoc.Add(new Paragraph("\n")); // small gap

            // Two-column table: label + value
            // Set column widths so label is narrower than value
            float[] headerWidths = new float[] { 25f, 75f };
            var headerTable = new PdfPTable(2)
            {
                WidthPercentage = 100f
            };
            headerTable.SetWidths(headerWidths);

            // Helper to add a row (label, value)
            PdfPCell MakeLabel(string text)
            {
                return new PdfPCell(new Phrase(text, labelFont))
                {
                    Border = iTextSharp.text.Rectangle.NO_BORDER,
                    PaddingTop = 4f,
                    PaddingBottom = 4f
                };
            }

            PdfPCell MakeValue(string text)
            {
                return new PdfPCell(new Phrase(text ?? string.Empty, valueFont))
                {
                    Border = iTextSharp.text.Rectangle.NO_BORDER,
                    PaddingTop = 4f,
                    PaddingBottom = 4f
                };
            }

            // Rows in the order shown in the sample image
            headerTable.AddCell(MakeLabel("Indent No:"));
            headerTable.AddCell(MakeValue(indentNumber));

            headerTable.AddCell(MakeLabel("Project Code:"));
            headerTable.AddCell(MakeValue(projectCode));

            headerTable.AddCell(MakeLabel("Project Name:"));
            headerTable.AddCell(MakeValue(projectName));

            headerTable.AddCell(MakeLabel("Remarks:"));
            headerTable.AddCell(MakeValue(remarks));

            // The last line in your sample is two labels on a single row:
            // "Indent By:" ... "Indent Date:"
            // We'll implement that with a 3-column table on one row for better alignment:
            var footerRowTable = new PdfPTable(new float[] { 12f, 38f, 50f }) { WidthPercentage = 100f };

            // "Indent By:" label
            footerRowTable.AddCell(new PdfPCell(new Phrase("Indent By:", labelFont))
            {
                Border = iTextSharp.text.Rectangle.NO_BORDER,
                PaddingTop = 4f,
                PaddingBottom = 4f
            });
            // "Indent By" value
            footerRowTable.AddCell(new PdfPCell(new Phrase(indentBy ?? string.Empty, valueFont))
            {
                Border = iTextSharp.text.Rectangle.NO_BORDER,
                PaddingTop = 4f,
                PaddingBottom = 4f
            });
            // "Indent Date:" value (label + value together for flexibility)
            footerRowTable.AddCell(new PdfPCell(new Phrase($"Indent Date: {indentDate}", valueFont))
            {
                Border = iTextSharp.text.Rectangle.NO_BORDER,
                PaddingTop = 4f,
                PaddingBottom = 4f
            });

            // Put this footerRowTable as a single cell spanning the header table width
            var footerRowCell = new PdfPCell(footerRowTable)
            {
                Border = iTextSharp.text.Rectangle.NO_BORDER,
                Padding = 0f
            };
            // Make it span both main columns by adding it as a single row across the table
            footerRowCell.Colspan = 2;
            headerTable.AddCell(footerRowCell);

            // Optional light bottom border under the whole header block to separate from data table
            // We can wrap headerTable into a single outer cell to draw a border.
            var headerWrapper = new PdfPTable(1) { WidthPercentage = 100f };
            var wrapperCell = new PdfPCell(headerTable)
            {
                Border = iTextSharp.text.Rectangle.BOTTOM_BORDER,
                BorderWidthBottom = 0.5f,
                PaddingBottom = 6f,
                PaddingLeft = 0f,
                PaddingRight = 0f,
                PaddingTop = 0f
            };
            headerWrapper.AddCell(wrapperCell);

            pdfDoc.Add(headerWrapper);
            pdfDoc.Add(new Paragraph("\n")); // space before main data table

            // ======= DATA TABLE (existing flow) =======
            var pdfTable = new PdfPTable(dtIndentItems.Columns.Count) { WidthPercentage = 100 };


            var bf1 = headerFont.BaseFont ?? BaseFont.CreateFont(BaseFont.HELVETICA, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
            float fontSize = headerFont.Size;

            // Measure header text in points, add padding

            float[] widths = dtIndentItems.Columns.Cast<DataColumn>()
                .Select(col => Math.Max(50f, bf1.GetWidthPoint(col.ColumnName, fontSize) + 24f)) // min width 50
                .ToArray();

            // Per-column absolute overrides (case-insensitive)
            var overrides = new Dictionary<string, float>(StringComparer.OrdinalIgnoreCase)
            {
                ["BOMQty"] = 40f,
                ["Qty"] = 40f,
                ["BatchCode"] = 50f
            };

            // Apply overrides
            for (int i = 0; i < dtIndentItems.Columns.Count; i++)
            {
                var name = dtIndentItems.Columns[i].ColumnName;
                if (overrides.TryGetValue(name, out float forcedWidth))
                {
                    widths[i] = forcedWidth;
                }
            }


            pdfTable.SetWidths(widths);


            foreach (DataColumn column in dtIndentItems.Columns)
            {
               // MessageBox.Show(column.ColumnName);
                var cell = new PdfPCell(new Phrase(column.ColumnName, headerFont))
                {
                    BackgroundColor = BaseColor.LIGHT_GRAY,
                    HorizontalAlignment = Element.ALIGN_CENTER,
                    PaddingTop = 4f,
                    PaddingBottom = 4f
                };
               
                pdfTable.AddCell(cell);
            }

            foreach (DataRow row in dtIndentItems.Rows)
            {
                foreach (var item in row.ItemArray)
                {
                    

                    if(item.ToString().Length > 40)
                    {

                        string result = item?.ToString()?.Length > 40
                                       ? item.ToString().Substring(0, 40)
                                       : item?.ToString();

                        var c = new PdfPCell(new Phrase(result ?? "-", cellFont))
                        {
                            PaddingTop = 2f,
                            PaddingBottom = 2f
                        };
                        pdfTable.AddCell(c);
                    }
                    else
                    {
                        var c = new PdfPCell(new Phrase(item?.ToString() ?? "-", cellFont))
                        {
                            PaddingTop = 2f,
                            PaddingBottom = 2f
                        };
                        pdfTable.AddCell(c);
                    }

                   
                }
            }

            pdfDoc.Add(pdfTable);

            // -------- Bottom signature drawing (no table) --------
            PdfContentByte cb = writer.DirectContent;

            // Page geometry
            float left = pdfDoc.LeftMargin;
            float right = pdfDoc.PageSize.Width - pdfDoc.RightMargin;
            float center = (left + right) / 2f;

            // Baseline Y position from the bottom margin
            float baseY = pdfDoc.BottomMargin + 80f;

            // Signature line lengths
            float lineLen = (right - left) / 2f - 30f; // half page minus padding

            // Left block: Created By
            float createdLabelX = left;
            float createdLineStartX = left;
            float createdLineEndX = left + lineLen;

            // Right block: Receiver
            float receiverLabelX = center + 30f;
            float receiverLineStartX = receiverLabelX;
            float receiverLineEndX = receiverLabelX + lineLen;

            // Draw labels
            var bf = BaseFont.CreateFont(BaseFont.HELVETICA, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
            cb.BeginText();
            cb.SetFontAndSize(bf, 11);

            // Labels
            cb.ShowTextAligned(Element.ALIGN_LEFT, "Created By", createdLabelX, baseY + 28f, 0);
            cb.ShowTextAligned(Element.ALIGN_LEFT, "Receiver Signature", receiverLabelX, baseY + 28f, 0);

            // Optional names above the lines (fixed: placed under the correct headings)
            cb.SetFontAndSize(bf, 10);
            if (!string.IsNullOrWhiteSpace(receiverName))
                cb.ShowTextAligned(Element.ALIGN_LEFT, $"Name: {receiverName}", createdLabelX + 3, baseY + 14f, 0);

            if (!string.IsNullOrWhiteSpace(createdByName))
                cb.ShowTextAligned(Element.ALIGN_LEFT, $"Name: {createdByName}", receiverLabelX + 3, baseY + 14f, 0);

            cb.EndText();

            // Draw signature lines (bottom line only)
            cb.SetLineWidth(0.8f);
            cb.MoveTo(createdLineStartX, baseY); cb.LineTo(createdLineEndX, baseY); cb.Stroke();
            cb.MoveTo(receiverLineStartX, baseY); cb.LineTo(receiverLineEndX, baseY); cb.Stroke();

            // Optional: date text under lines
            cb.BeginText();
            cb.SetFontAndSize(bf, 10);
            if (!string.IsNullOrWhiteSpace(createdDate))
                cb.ShowTextAligned(Element.ALIGN_LEFT, $"Date: {createdDate}", createdLabelX, baseY - 16f, 0);
            if (!string.IsNullOrWhiteSpace(recievingDate))
                cb.ShowTextAligned(Element.ALIGN_LEFT, $"Date: {recievingDate}", receiverLabelX, baseY - 16f, 0);
            cb.EndText();

            // -----------------------------------------------------

            pdfDoc.Close();
        }






            private string ConvertDateString(string input)
        {
           // MessageBox.Show(input, "Date");
            // Remove separators
            string clean = input.Replace("-", "").Replace(":", "").Replace(" ", "");
            // clean = "24112025192247"

            // Extract parts
            string day = clean.Substring(0, 2);
            string month = clean.Substring(2, 2);
            string year = clean.Substring(4, 4);
            string hour = clean.Substring(8, 2);
            string minute = clean.Substring(10, 2);

            // Combine
            return day + month + year + hour + minute;
        }


        private DateTime ParseBatchCode(string batchCode)
        {
           // MessageBox.Show(batchCode, "ParseBatchCode");
            // Example: "100920251235" => ddMMyyyyHHmm
            // MessageBox.Show(batchCode);
            //MessageBox.Show(ConvertDateString(batchCode));
            return DateTime.ParseExact(ConvertDateString(batchCode), "ddMMyyyyHHmm", CultureInfo.InvariantCulture);
        }

        public List<string> AllocateBatchesFIFO(string itemCode, double requestedQty)
        {
            var dt = DAL.getItemBatchLocation(itemCode).Tables[0];

            var rows = dt.AsEnumerable()
                .Where(r => Convert.ToDouble(r["RemainingQty"]) > 0)
                .OrderBy(r => ParseBatchCode(r["GINServerTime"].ToString()))
                .ThenBy(r => r["ID"].ToString())  // Use ThenBy for secondary sort
                .ToList();

            double qtyNeeded = requestedQty;

            // Use dictionary to aggregate by BatchCode
            Dictionary<string, double> batchAllocation = new Dictionary<string, double>();
            Dictionary<string, string> batchLocations = new Dictionary<string, string>();
            Dictionary<string, string> batchGINNumbers = new Dictionary<string, string>();

            foreach (var row in rows)
            {
                double batchQty = Convert.ToDouble(row["RemainingQty"].ToString());
                if (qtyNeeded <= 0) break;

                double allocate = Math.Min(batchQty, qtyNeeded);
                string batchCode = row["BatchCode"].ToString();

                // Aggregate quantities for duplicate batch codes
                if (batchAllocation.ContainsKey(batchCode))
                {
                    batchAllocation[batchCode] += allocate;
                    // Append location and GIN if different (optional - or keep first)
                    if (!batchLocations[batchCode].Contains(row["ItemLocation"].ToString()))
                        batchLocations[batchCode] += ";" + row["ItemLocation"].ToString();
                    if (!batchGINNumbers[batchCode].Contains(row["GINNumber"].ToString()))
                        batchGINNumbers[batchCode] += ";" + row["GINNumber"].ToString();
                }
                else
                {
                    batchAllocation[batchCode] = allocate;
                    batchLocations[batchCode] = row["ItemLocation"].ToString();
                    batchGINNumbers[batchCode] = row["GINNumber"].ToString();
                }

                double newRemainingQty = batchQty - allocate;
                int indentQtyValue = 0;
                int.TryParse(row["IndentQty"].ToString(), out indentQtyValue);
                double IndentQty = indentQtyValue + allocate;

                string input = row["GINServerTime"].ToString();
                DateTime dateFormat = DateTime.ParseExact(input, "dd-MM-yyyy HH:mm:ss", null);
                string DateFormatConverted = dateFormat.ToString("yyyy-MM-dd HH:mm:ss");

                DAL.fnUpdateInventoryLog("UPDATE", newRemainingQty, IndentQty, itemCode,
                    batchCode, row["ItemLocation"].ToString(), row["ProjectCode"].ToString(),
                    int.Parse(row["ID"].ToString()));

                qtyNeeded -= allocate;
            }

            if (batchAllocation.Count == 0)
                return new List<string> { "-", "-", "-", "-" };

            // Build return lists from aggregated data
            List<string> batchCodes = batchAllocation.Keys.ToList();
            List<string> locations = batchCodes.Select(b => batchLocations[b]).ToList();
            List<string> GINNumber = batchCodes.Select(b => batchGINNumbers[b]).ToList();
            List<string> AssignQty = batchCodes.Select(b => batchAllocation[b].ToString()).ToList();

            return new List<string>
    {
        string.Join(",", batchCodes),
        string.Join(",", locations),
        string.Join(",", GINNumber),
        string.Join(",", AssignQty),
    };
        }

        public List<string> AllocateBatchesFIFO_OLD(string itemCode, double requestedQty)
        {
            var dt = DAL.getItemBatchLocation(itemCode).Tables[0];
            // Filter out rows with RemainingQty <= 0, sort by BatchCode (oldest first)



            // MessageBox.Show()


            var rows = dt.AsEnumerable()
                .Where(r => Convert.ToDouble(r["RemainingQty"]) > 0)
                .OrderBy(r => ParseBatchCode(r["GINServerTime"].ToString())).OrderBy(r => r["ID"].ToString())
                .ToList();

            double qtyNeeded = requestedQty;
            List<string> batchCodes = new List<string>();
            List<string> locations = new List<string>();
            List<string> GINNumber = new List<string>();
            List<string> AssignQty = new List<string>();
           // MessageBox.Show(rows.Count.ToString(), "ROW count");

            foreach (var row in rows)
            {
                double batchQty = Convert.ToDouble(row["RemainingQty"].ToString()); ;
                if (qtyNeeded <= 0) break;

                double allocate = Math.Min(batchQty, qtyNeeded);


                batchCodes.Add(row["BatchCode"].ToString());
                locations.Add(row["ItemLocation"].ToString());
                GINNumber.Add(row["GINNumber"].ToString());
                AssignQty.Add(allocate.ToString());

                double newRemainingQty = batchQty - allocate;
                int indentQtyValue = 0;
                int.TryParse(row["IndentQty"].ToString(), out indentQtyValue);
                double IndentQty = indentQtyValue + allocate;
                //MessageBox.Show(newRemainingQty.ToString());


                string input = row["GINServerTime"].ToString();

                DateTime dateFormat = DateTime.ParseExact(input, "dd-MM-yyyy HH:mm:ss", null);

                string DateFormatConverted = dateFormat.ToString("yyyy-MM-dd HH:mm:ss");

                //MessageBox.Show(row["GINServerTime"].ToString());

                DAL.fnUpdateInventoryLog("UPDATE", newRemainingQty, IndentQty, itemCode, row["BatchCode"].ToString(), row["ItemLocation"].ToString(), row["ProjectCode"].ToString(), int.Parse(row["ID"].ToString()));//.Replace("%", "").Trim()


                qtyNeeded -= allocate;
            }

            if (batchCodes.Count == 0)
                return new List<string> { "-", "-", "-", "-" };

            // Join with commas
            return new List<string>
            {
                string.Join(",", batchCodes),
                string.Join(",", locations),
                string.Join(",", GINNumber),
                string.Join(",", AssignQty),
            };
        }




        string sIssuedQty;
        string sDot = ".";
        string[] sItemCode;

        bool bBOM;
        bool bDelete = false;
        bool bView = false;
        bool bChangeBOM = false;
        bool bQtyCheck = false;

        double oldvalue;
        public int Indentform = 0;
        private static string sProjectCode;
        public string fnProjectcode
        {
            get
            {
                return sProjectCode;
            }
            set
            {
                sProjectCode = value;
            }
        }


        public frmIndent()
        {
            InitializeComponent();
        }
        #endregion
        #region Indent Load
        private void frmIndent_Load(object sender, EventArgs e)
        {
            chkItemCode.Checked = true;
            bDelete = false;
            dtpIndentDate.Format = DateTimePickerFormat.Custom;
            dtpIndentDate.CustomFormat = "dd-MM-yyyy";

            lblReturnedby.Text = login.GetUserDetails[2];
            lblindentby.Text = login.GetUserDetails[2];
            dgIndentList.Columns[0].Width = 158;
            dgIndentList.Columns[1].Width = 600;
            dgBOMIndent.Columns[0].Width = 158;
            dgBOMIndent.Columns[1].Width = 600;
            lblprdname.Enabled = false;
            lblProductName.ResetText();
            btnSave.Text = "Save";

            dtItemList = DAL.fnItemList(null).Tables[0];
            dtProjectList = DAL.fnWIPProjectList(null).Tables[0];
            //if (dtProjectList.Rows.Count > 0)
            //{
            //    foreach (DataRow DR in dtProjectList.Rows)
            //    {
            //        if (!cmbProjectCode.Items.Contains(DR["ProjectCode"].ToString()))
            //            cmbProjectCode.Items.Add(DR["ProjectCode"].ToString());
            //    }
            //}

            if (login.GetUserDetails[23] == "Support")
            {
                chkApprove.Visible = true;
                btnApprove.Visible = true;
            }
            else
            {
                chkApprove.Visible = false;
                btnApprove.Visible = false;
            }
        }
        #endregion

        #region Rowfilter Funtion to select Item
        private void RowFilter()
        {
            chklbItemList.Items.Clear();
            if (Convert.ToBoolean(dtProjectBOMdetails.Rows[0]["BOMProject"].ToString()) == false)
            {
                foreach (DataRowView dv in dvItemList)
                {
                    chklbItemList.Items.Add(string.Concat(dv[17].ToString(), ") ", dv[0].ToString(), ", ", dv[1].ToString(), ", ", dv[12].ToString()));
                }
            }
            else
            {
                foreach (DataRowView dv in dvItemList)
                {
                    chklbItemList.Items.Add(string.Concat(dv[8].ToString(), ") ", dv[0].ToString(), ", ", dv[1].ToString(), ", ", dv[6].ToString()));
                }
            }

        }

        private void BOMRowFilter()
        {
            chklbItemList.Items.Clear();
            foreach (DataRow dr in dtMachineBOMProduct.Rows)
            {
                chklbItemList.Items.Add(string.Concat(dr["ID"].ToString(), ") ", dr["ItemCode"].ToString(), ", ", dr["ItemDescription"].ToString(), ", ", dr["AvailableQty"].ToString()));
            }
        }

        #endregion
        #region Item Search Funtion
        private void txtItemDescription_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
            {
                if (chkItemCode.Checked == true)
                {
                    if (Convert.ToBoolean(dtProjectBOMdetails.Rows[0]["BOMProject"].ToString()) == false)
                    {
                        dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);
                        RowFilter();
                    }
                    else
                    {
                        if (txtItemDescription.Text.Length > 5)
                        {
                            dvItemList = GLobalClass.RowFilter(dtMachineBOMProduct, 0, txtItemDescription.Text);
                            RowFilter();
                        }
                        else if (txtItemDescription.Text.Length <= 5)
                        {
                            BOMRowFilter();
                        }
                    }
                }
                else if (chkItemDesc.Checked == true)
                {
                    if (Convert.ToBoolean(dtProjectBOMdetails.Rows[0]["BOMProject"].ToString()) == false)
                    {
                        dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
                        RowFilter();
                    }
                    else
                    {
                        if (txtItemDescription.Text.Length > 3)
                        {
                            dvItemList = GLobalClass.RowFilter(dtMachineBOMProduct, 1, txtItemDescription.Text);
                            RowFilter();
                        }
                        else if (txtItemDescription.Text.Length <= 3)
                        {
                            BOMRowFilter();
                        }
                    }
                }
            }
            else
            {
                if (chkItemCode.Checked == true)
                {
                    if (Convert.ToBoolean(dtProjectBOMdetails.Rows[0]["BOMProject"].ToString()) == false)
                    {
                        dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);
                        RowFilter();
                    }
                    else
                    {
                        if (txtItemDescription.Text.Length > 5)
                        {
                            dvItemList = GLobalClass.RowFilter(dtMachineBOMProduct, 0, txtItemDescription.Text);
                            RowFilter();
                        }
                        else if (txtItemDescription.Text.Length <= 5)
                        {
                            BOMRowFilter();
                        }
                    }
                }
                else if (chkItemDesc.Checked == true)
                {
                    if (Convert.ToBoolean(dtProjectBOMdetails.Rows[0]["BOMProject"].ToString()) == false)
                    {
                        dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
                        RowFilter();
                    }
                    else
                    {
                        if (txtItemDescription.Text.Length > 3)
                        {
                            dvItemList = GLobalClass.RowFilter(dtMachineBOMProduct, 1, txtItemDescription.Text);
                            RowFilter();
                        }
                        else if (txtItemDescription.Text.Length <= 3)
                        {
                            BOMRowFilter();
                        }
                    }
                }
            }
        }

        private void txtItemDescription_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar == '%' || e.KeyChar == '['))
            {
                e.Handled = true;
            }
        }
        #endregion
        #region Item Select Function
        private void chklbItemList_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            string[] sitemtype;
            bool ctreate = true;
            var protype1 = "";
            if (Convert.ToBoolean(dtProjectBOMdetails.Rows[0]["BOMProject"].ToString()) == false)
            {
                int i = 0;
                try
                {
                    sItemCode = chklbItemList.SelectedItem.ToString().Trim().Split(')');
                    string sID = sItemCode[0];
                    string item = sItemCode[1];
                    sitemtype = sItemCode[1].ToString().Trim().Split('-');
                    string project = cmbProjectCode.Text;
                    string[] authorsList = project.Split('-');
                    var protype = authorsList[0];
                    if (protype == "CIP")
                    {
                        protype1 = authorsList[3];
                    }
                    string itemtyp = sitemtype[0];
                    if (itemtyp != "FA" && protype == "CIP" && protype1 == "CAP")
                    {
                        ctreate = false;
                    }
                    if (itemtyp == "FA" && (protype != "CIP" || protype1 != "CAP"))
                    {
                        ctreate = false;
                    }
                    //if (itemtyp == "CON" && protype != "EXP")
                    //{
                    //    ctreate = false;
                    //}
                    //if (itemtyp != "CON" && protype == "EXP")
                    //{
                    //    ctreate = false;
                    //}
                    if (ctreate == true)
                    {
                        dtItemcode = DAL.fnIndentItemList(sID).Tables[0];
                        if (dtItemcode.Rows.Count > 0)
                        {
                            if (!chklbItemList.CheckedItems.Contains(chklbItemList.SelectedItem))
                            {
                                foreach (DataGridViewRow DGVR in dgIndentList.Rows)
                                {
                                    if (DGVR.Cells["ItemCode"].Value.ToString().Equals(dtItemcode.Rows[0]["ItemCode"].ToString()))
                                    {
                                        i = 1;
                                        break;
                                    }

                                }
                                if (i != 1)
                                {
                                    if (dtItemAdd.Rows.Count == 0)
                                    {
                                        dtItemAdd = DAL.fnIndentItemList(null).Tables[0];
                                    }
                                    if (bDelete == false)
                                    {
                                        dtItemAdd.Rows.Add(dtItemcode.Rows[0]["ItemCode"].ToString(), dtItemcode.Rows[0]["ItemDescription"].ToString(),
                                                           dtItemcode.Rows[0]["Units"].ToString(), Convert.ToDouble(dtItemcode.Rows[0]["AvailableQty"].ToString()), dtItemcode.Rows[0]["ReqQty"].ToString());

                                        dgIndentList.AutoGenerateColumns = false;
                                        dgIndentList.DataSource = dtItemAdd;

                                    }
                                    else
                                    {
                                        dtIndentItems.Rows.Add("", dtItemcode.Rows[0]["ItemCode"].ToString(), dtItemcode.Rows[0]["ItemDescription"].ToString(),
                                                           dtItemcode.Rows[0]["Units"].ToString(), Convert.ToDouble(dtItemcode.Rows[0]["AvailableQty"].ToString()), "", "", "", "", "", dtItemcode.Rows[0]["ReqQty"].ToString());

                                        dgIndentList.AutoGenerateColumns = false;
                                        dgIndentList.DataSource = dtIndentItems;

                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Selected Item already present in the list", "Error", 0, MessageBoxIcon.Error);
                                    int k = chklbItemList.SelectedIndex;
                                    chklbItemList.SetItemCheckState(k, CheckState.Unchecked);
                                }

                                foreach (DataGridViewRow dgr in dgIndentList.Rows)
                                {
                                    if (Convert.ToDouble(dgr.Cells["AvailableQty"].Value) == Convert.ToDouble("0"))
                                    {
                                        dgr.DefaultCellStyle.BackColor = Color.Red;
                                    }
                                }
                            }
                            else
                            {
                                int rowIndex = -1;
                                bool bSelected;

                                foreach (DataGridViewRow row in dgIndentList.Rows)
                                {
                                    bSelected = (row.Cells["ItemCode"].Value.ToString().Equals(dtItemcode.Rows[0]["ItemCode"].ToString()));
                                    if (bSelected == true)
                                    {
                                        rowIndex = row.Index;
                                        dgIndentList.Rows.Remove(dgIndentList.Rows[rowIndex]);
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please Check selected Item Code Type\n 1)Item created under Fixed Asset(FA-) is only for CAP projects code. Not other projects can Indent.\n 2) Item created under Consumable(CON-) is only for EXP projects code.", "Error", 0, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("PurchaseOrder_chklbItemList_ItemCheck" + ex.Message);
                }
            }
            else
            {
                int i = 0;
                DataTable dtSelectedItem = new DataTable();

                try
                {
                    sItemCode = chklbItemList.SelectedItem.ToString().Trim().Split(')');
                    string sID = sItemCode[0];
                    string item = sItemCode[1];
                    sitemtype = sItemCode[1].ToString().Trim().Split('-');
                    string project = cmbProjectCode.Text;
                    string[] authorsList = project.Split('-');
                    var protype = authorsList[0];
                    //var protype1 = authorsList[3];
                    if (protype == "CIP")
                    {
                        protype1 = authorsList[3];
                    }
                    string itemtyp = sitemtype[0];
                    if (itemtyp != "FA" && protype == "CIP" && protype1 == "CAP")
                    {
                        ctreate = false;
                    }
                    if (itemtyp == "FA" && protype != "CIP" && protype1 != "CAP")
                    {
                        ctreate = false;
                    }
                    //if (itemtyp == "CON" && protype != "EXP")
                    //{
                    //    ctreate = false;
                    //}
                    //if (itemtyp != "CON" && protype == "EXP")
                    //{
                    //    ctreate = false;
                    //}
                    if (ctreate == true)
                    {
                        dtItemcode = DAL.fnIndentItemList(sID).Tables[0];
                        dtSelectedItem = DAL.fnGetIndentMachineBOM("null", dtprojectBOMItems.Rows[0]["ProductNo"].ToString(), cmbProjectCode.Text, dtItemcode.Rows[0]["ItemCode"].ToString()).Tables[0];
                        if (dtItemcode.Rows.Count > 0)
                        {
                            if (!chklbItemList.CheckedItems.Contains(chklbItemList.SelectedItem))
                            {
                                foreach (DataGridViewRow DGVR in dgBOMIndent.Rows)
                                {
                                    if (DGVR.Cells["BOMItemCode"].Value.Equals(dtItemcode.Rows[0]["ItemCode"].ToString()))
                                    {
                                        i = 1;
                                        break;
                                    }
                                }
                                if (i != 1)
                                {
                                    DataRow[] d;
                                    d = (dtMachineBOMProduct.Select("ID ='" + sID + "'"));

                                    DataRow dr = dtSelectedItem.NewRow();
                                    if (d.Length > 0)
                                    {
                                        for (int count = 0; count < d[0].ItemArray.Count(); count++)
                                        {
                                            dr[count] = d[0][count];
                                        }
                                        dtSelectedItem.Rows.Add(dr);
                                    }
                                    if (dtSelectedItem.Rows.Count > 0)
                                    {
                                        if (dgBOMIndent.Rows.Count == 0)
                                        {
                                            dtFinalSelectedItem = dtSelectedItem;
                                            dtFinalSelectedItem.Rows.Clear();

                                            if (d.Length > 0)
                                            {
                                                for (int count = 0; count < d[0].ItemArray.Count(); count++)
                                                {
                                                    dr[count] = d[0][count];
                                                }
                                                dtSelectedItem.Rows.Add(dr);
                                            }
                                        }
                                    }

                                    dtFinalSelectedItem.ImportRow(dtSelectedItem.Rows[0]);
                                    if (dgBOMIndent.Rows.Count == 0)
                                        dtFinalSelectedItem.Rows.RemoveAt(0);
                                    dgBOMIndent.AutoGenerateColumns = false;
                                    dgBOMIndent.DataSource = dtFinalSelectedItem;
                                    lblrowcount.Text = dgBOMIndent.Rows.Count.ToString();

                                    foreach (DataGridViewRow dgr in dgBOMIndent.Rows)
                                    {
                                        if (Convert.ToDouble(dgr.Cells["BOMAvailableQty"].Value) == Convert.ToDouble("0"))
                                        {
                                            dgr.DefaultCellStyle.BackColor = Color.Red;
                                        }
                                        if (Convert.ToDouble(dgr.Cells["BOMIndentQty"].Value) == Convert.ToDouble("0") && Convert.ToDouble(dgr.Cells["BOMAvailableQty"].Value) != Convert.ToDouble("0"))
                                        {
                                            dgr.DefaultCellStyle.BackColor = Color.Brown;
                                        }
                                    }
                                    cmbbomname.Enabled = false;
                                    btnSave.Enabled = true;
                                }
                                else
                                {
                                    MessageBox.Show("Selected Item already present in the list", "Error", 0, MessageBoxIcon.Error);
                                    int k = chklbItemList.SelectedIndex;
                                    chklbItemList.SetItemCheckState(k, CheckState.Unchecked);
                                }

                            }

                            else
                            {
                                int rowIndex = -1;
                                bool bSelected;

                                foreach (DataGridViewRow row in dgBOMIndent.Rows)
                                {
                                    bSelected = (row.Cells["BOMItemCode"].Value.ToString().Equals(dtItemcode.Rows[0]["ItemCode"].ToString()));
                                    if (bSelected == true)
                                    {
                                        rowIndex = row.Index;
                                        dgBOMIndent.Rows.Remove(dgBOMIndent.Rows[rowIndex]);
                                        if (dgBOMIndent.Rows.Count == 0)
                                        {
                                            cmbbomname.Enabled = true;
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please Check selected Item Code Type\n 1)Item created under Fixed Asset(FA-) is only for CAP projects code. Not other projects can Indent.\n 2) Item created under Consumable(CON-) is only for EXP projects code.", "Error", 0, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                { MessageBox.Show("PurchaseOrder_chklbItemList_ItemCheck" + ex.Message); }
            }
        }
        #endregion
        #region Exit Form Function
        private void btnExit_Click(object sender, EventArgs e)
        {
            frmForm2 frmForm2 = new frmForm2();
            this.Hide();
            frmForm2.Show();
        }
        #endregion
        #region Clear All Function
        private void btnClearAll_Click(object sender, EventArgs e)
        {
            if (dgIndentList.Rows.Count > 0 || chklbItemList.Items.Count > 0)
            {
                DialogResult dresult = MessageBox.Show("All selected items will be lost! do you want to continue anyway", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (dresult == DialogResult.Yes)
                {
                    this.Hide();
                    Indent.frmIndent Indent = new frmIndent();
                    Indent.Show();
                }
            }
        }
        #endregion
        #region Excel Save Function
        private void btnSaveExcel_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("Here the print function is called..!");
            int iRowIndex = 1;
            string ExcelFolderPath;
            string FileFullPath;
            EXCEL.Workbook NewWorkBook;
            EXCEL.Worksheet NewWorkSheet;
            EXCEL.Application ExcelApp;
            EXCEL.Range CELLS, cell1, cell2;
            object misValue;
            dtIndentItems = DAL.fnIndentExcel(cmbIndentNo.Text, null).Tables[0];//fnBOMIndent

            if (dtIndentItems.Rows.Count > 0)
            {
                ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\";
                FileFullPath = cmbIndentNo.Text + "--" + DateTime.Now.ToString("dd/MM/yyyy") + ".xls";
                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);
                ExcelApp = new EXCEL.Application();
                misValue = System.Reflection.Missing.Value;
                try
                {
                    if (ExcelApp == null)
                        MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                    NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                    NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                    if (NewWorkSheet == null)
                        MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                    else
                        NewWorkSheet.Name = "" + cmbIndentNo.Text + "";
                    // Select the Excel cells, in the range c1 to c7 in the worksheet for cell access check.
                    EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                    if (RANGE == null)
                        MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                    NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlWorkbookNormal, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                    CELLS = NewWorkSheet.Cells;

                    // dtIndentItems = DAL.fnIndentExcel(cmbIndentNo.Text, null).Tables[0];

                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);

                    NewWorkSheet.Cells[iRowIndex, 1] = "Indent";
                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "Indent No:";
                    NewWorkSheet.Cells[iRowIndex, 2] = cmbIndentNo.Text;
                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "Project Code:";
                    NewWorkSheet.Cells[iRowIndex, 2] = cmbProjectCode.Text;
                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "Project Name:";
                    NewWorkSheet.Cells[iRowIndex, 2] = lblprojname.Text;
                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "Remarks:";
                    NewWorkSheet.Cells[iRowIndex, 2] = ReviewTextBox.Text;
                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Indent By: " + lblindentby.Text;

                    NewWorkSheet.Cells[iRowIndex, 2] = "Indent Date: " + lblindentdate.Text;
                    iRowIndex++;

                    iRowIndex++;
                    ((Microsoft.Office.Interop.Excel.Range)NewWorkSheet.Rows[8, Type.Missing]).Font.Size = 14;
                    ((Microsoft.Office.Interop.Excel.Range)NewWorkSheet.Rows[8, Type.Missing]).Font.Bold = true;
                    iRowIndex++;


                    //MessageBox.Show(System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments).ToString());
                    //C:\Users\Kanthara095\Documents

                    if (!Directory.Exists(System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\" + "IndentReport")) { 
                        Directory.CreateDirectory(System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\" + "IndentReport");
                        MessageBox.Show("Creating New Folder...!");
                    }

                    ExportToPDF(dtIndentItems, System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments).ToString() +"\\IndentReport"+ "\\" + "IndentReport" + cmbIndentNo.Text + DateTime.Now.ToString("dd/MM/yyyy/HH/mm/ss") + ".pdf", lblindentby.Text, lblindentdate.Text, "", dtpIndentDate.Text, cmbIndentNo.Text, cmbProjectCode.Text, lblprojname.Text
                        ,ReviewTextBox.Text, lblindentby.Text, lblindentdate.Text
                        );


                    if (dtIndentItems.Rows.Count > 0)
                    {

                        if (dtIndentItems != null && dtIndentItems.Rows.Count > 0)
                        {
                            StringBuilder sb = new StringBuilder();
                            // Add column headers
                            foreach (DataColumn col in dtIndentItems.Columns)
                            {
                                sb.Append(col.ColumnName + "\t");
                            }
                            sb.AppendLine();
                            // Add row data
                            foreach (DataRow row in dtIndentItems.Rows)
                            {
                                foreach (var item in row.ItemArray)
                                {
                                    sb.Append(item?.ToString() + "\t");
                                }
                                sb.AppendLine();
                            }
                            // MessageBox.Show(sb.ToString(), "dtIndentItems Contents");
                        }
                        else
                        {
                            MessageBox.Show("dtIndentItems is empty.");
                        }


                        object[,] rawData = new object[dtIndentItems.Rows.Count + 1, dtIndentItems.Columns.Count];
                        for (int col = 0; col < dtIndentItems.Columns.Count; col++)
                        {
                            rawData[0, col] = dtIndentItems.Columns[col].ColumnName;
                        }
                        for (int row = 0; row < dtIndentItems.Rows.Count; row++)
                        {
                            for (int col = 0; col < dtIndentItems.Columns.Count; col++)
                            {
                                rawData[row + 1, col] = dtIndentItems.Rows[row].ItemArray[col];
                            }
                        }
                        string excelRange = string.Empty;
                        string finalColLetter = string.Empty;
                        string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        int colCharsetLen = colCharset.Length;

                        if (dtIndentItems.Columns.Count > colCharsetLen)
                        {
                            finalColLetter = colCharset.Substring(
                                (dtIndentItems.Columns.Count - 1) / colCharsetLen - 1, 1);
                        }

                        finalColLetter += colCharset.Substring(
                                (dtIndentItems.Columns.Count - 1) % colCharsetLen, 1);
                        excelRange = string.Format("A8:{0}{1}", finalColLetter, dtIndentItems.Rows.Count + iRowIndex - 1);


                        NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                    }
                    cell1 = NewWorkSheet.Cells[iRowIndex - 1, 1];
                    cell2 = NewWorkSheet.Cells[(iRowIndex + dtIndentItems.Rows.Count - 1), 4];
                    CELLS = (EXCEL.Range)NewWorkSheet.get_Range(cell1, cell2);
                    CELLS.Borders.Color = Color.Black;
                    CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);

                    NewWorkSheet.Range["A1:C1"].Cells.Font.Bold = true;
                    NewWorkSheet.Range["A1:C1"].Cells.Font.Size = 16;

                    NewWorkSheet.Range["A2:D6"].Cells.Font.Size = 12;
                    NewWorkSheet.Range["A2:D6"].Cells.Font.Bold = true;


                    cell1 = NewWorkSheet.Cells[1, 1];
                    cell2 = NewWorkSheet.Cells[1, 1];
                    CELLS = (EXCEL.Range)NewWorkSheet.get_Range(cell1, cell2);
                    CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                    CELLS.Font.Bold = true;

                    cell1 = NewWorkSheet.Cells[2, 1];
                    cell2 = NewWorkSheet.Cells[6, 1];
                    CELLS = (EXCEL.Range)NewWorkSheet.get_Range(cell1, cell2);
                    CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                    CELLS.Font.Bold = true;


                    NewWorkSheet.get_Range("A6:B999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    NewWorkSheet.get_Range("A6", "B999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;

                    Microsoft.Office.Interop.Excel.Range Range = NewWorkSheet.get_Range("C6", "E399");
                    Range.EntireColumn.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;

                    NewWorkSheet.Rows.AutoFit();

                    NewWorkSheet.Columns.AutoFit();
                    NewWorkSheet.Rows.RowHeight = "18";

                    NewWorkSheet.Columns[1].ColumnWidth = 20;
                    NewWorkSheet.Columns[1].WrapText = true;
                    NewWorkSheet.Columns[2].ColumnWidth = 50;
                    NewWorkSheet.Columns[2].WrapText = true;
                    NewWorkSheet.Columns[3].ColumnWidth = 11;
                    NewWorkSheet.Columns[3].WrapText = true;
                    NewWorkSheet.Columns[4].ColumnWidth = 8;
                    NewWorkSheet.Columns[4].WrapText = true;
                    //NewWorkSheet.Columns[5].ColumnWidth = 12;
                    //NewWorkSheet.Columns[5].WrapText = true;

                    NewWorkSheet.PageSetup.PrintArea = "A1:D" + dtIndentItems.Rows.Count + iRowIndex + 3 + "";
                    NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                    NewWorkSheet.PageSetup.PrintNotes = true;
                    NewWorkSheet.PageSetup.Zoom = 100;
                    NewWorkSheet.PageSetup.FitToPagesTall = 1;
                    NewWorkSheet.PageSetup.FitToPagesWide = 1;
                    NewWorkSheet.PageSetup.LeftMargin = 0;
                    NewWorkSheet.PageSetup.RightMargin = 0;
                    NewWorkSheet.PageSetup.TopMargin = 0.75;
                    NewWorkSheet.PageSetup.BottomMargin = 0.75;
                    NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                    NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                    string _stLOGO = ("C:\\Databasepath\\Bisslogo.jpg");
                    EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 3];

                    System.Drawing.Image oImage = System.Drawing.Image.FromFile(_stLOGO);
                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    NewWorkSheet.Paste(oRange, _stLOGO);

                    NewWorkBook.Save();
                    ExcelApp.Visible = true;
                    System.Threading.Thread.Sleep(1000);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                    {
                        GetProcess.Kill();
                    }
                }
            }
            else
                MessageBox.Show("No indent items to save", "Error", 0, MessageBoxIcon.Question);
        }
        #endregion
        #region Excel Merge Function
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlMedium, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

        }
        #endregion


        DataTable dtProjectType = new DataTable();
        DataTable dtProjectAllCost = new DataTable();
        double dProjectCost = 0;
        double dTotalIssuedAmount = 0;
        double dCurrentIssuedAmount = 0;
        double dIndentreturn = 0;
        double dJObreturn = 0;
        double dJObIssued = 0;
        double dTotalProjectSum = 0;
        bool bProjectCost = true;
        DataTable dtItemValue = new DataTable();
        public List<Tuple<string, int, string>> BatchAllocationSummary = new List<Tuple<string, int, string>>();
        private void fnProjectAmountCheck()
        {
            bProjectCost = true;
            dProjectCost = 0;
            dTotalIssuedAmount = 0;
            dCurrentIssuedAmount = 0;
            dIndentreturn = 0;
            dJObreturn = 0;
            dJObIssued = 0;
            dTotalProjectSum = 0;
            dtProjectType = DAL.fnProjectCostLimitCIP(0, cmbProjectCode.Text).Tables[0];
            if (dtProjectType.Rows.Count > 0)
            {
                if (dtProjectType.Rows[0]["ProjectType"].ToString() == "Fixed Asset (CIP)")
                {
                    dtProjectAllCost = DAL.fnProjectCostLimitCIP(2, cmbProjectCode.Text).Tables[0];

                    if (dtProjectAllCost.Rows.Count > 0)
                    {
                        dProjectCost = Convert.ToDouble(dtProjectAllCost.Rows[0]["TotalAmount"].ToString());
                        dTotalProjectSum = dtProjectAllCost.AsEnumerable().Sum(r => r.Field<double>("TotalAmount"));
                        dTotalProjectSum = dTotalProjectSum - dProjectCost;
                    }

                    dCurrentIssuedAmount = Convert.ToDouble(0);

                    if (dgBOMIndent.Rows.Count > 0)
                    {
                        foreach (DataGridViewRow drow in dgBOMIndent.Rows)
                        {
                            dtItemValue = DAL.fnAddItemList(drow.Cells["BOMItemCode"].Value.ToString()).Tables[0];

                            dCurrentIssuedAmount += Convert.ToDouble(drow.Cells["BOMIndentQty"].Value) * Convert.ToDouble(dtItemValue.Rows[0]["UnitCost"].ToString());
                        }
                    }
                    else if (dgIndentList.Rows.Count > 0)
                    {
                        foreach (DataGridViewRow drow in dgIndentList.Rows)
                        {
                            dtItemValue = DAL.fnAddItemList(drow.Cells["ItemCode"].Value.ToString()).Tables[0];

                            dCurrentIssuedAmount += Convert.ToDouble(drow.Cells["Quantity"].Value) * Convert.ToDouble(dtItemValue.Rows[0]["UnitCost"].ToString());
                        }
                    }


                    if (dtProjectType.Rows[0]["Type"].ToString() == "Inhouse")
                    {
                        dProjectCost = (dProjectCost / 1.3);
                        if ((dTotalProjectSum + dCurrentIssuedAmount) < dProjectCost)
                        {
                            bProjectCost = true;
                        }
                        else
                        {
                            bProjectCost = false;
                        }
                    }
                }
            }
        }

        public void SaveBatchQtyUpdateold(string itemCode, string batchCodesCsv, string locationsCsv, int reqQty)
        {
            // Split batch codes and locations
            //var batchCodes = batchCodesCsv.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            //var locations = locationsCsv.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

            // Sanity check
            //if (batchCodes.Length != reqQty || locations.Length != reqQty)
            //{
            //  MessageBox.Show("Batch code/location count does not match required quantity.");
            //return;
            //}

            // For each batch/location, decrement RemainingQty by 1
            //for (int i = 0; i < reqQty; i++)
            //{
            //  string batchCode = batchCodes[i].Trim();
            //string location = locations[i].Trim();

            // Get current RemainingQty for this batch
            //DataTable dt = DAL.getItemBatchLocation(itemCode).Tables[0];
            //var row = dt.AsEnumerable()
            //  .FirstOrDefault(r => r["BatchCode"].ToString() == batchCode && r["ItemLocation"].ToString() == location);

            //if (row != null)
            //{
            // double currentQty = Convert.ToDouble(row["RemainingQty"]);
            //double newQty = currentQty - 1; // Decrement by 1 for each allocation

            // Update RemainingQty in DB
            //using (var con = new SqlConnection(DataAccessLayer.cs))
            //{
            //  con.Open();
            //var cmd = new SqlCommand(
            //   "UPDATE ERPInventoryLog SET RemainingQty = @RemainingQty WHERE ItemCode = @ItemCode AND BatchCode = @BatchCode AND ItemLocation = @ItemLocation",
            //  con);
            //cmd.Parameters.AddWithValue("@RemainingQty", newQty);
            //cmd.Parameters.AddWithValue("@ItemCode", itemCode);
            //cmd.Parameters.AddWithValue("@BatchCode", batchCode);
            //cmd.Parameters.AddWithValue("@ItemLocation", location);
            //cmd.ExecuteNonQuery();

            foreach (var tuple in BatchAllocationSummary)
            {
                string batchCode = tuple.Item1;
                int pickedCount = tuple.Item2;
                string pickedItemCode = tuple.Item3;
                MessageBox.Show(batchCode + pickedItemCode + pickedCount.ToString());
                // Use batchCode and pickedCount as needed
                DataTable dt = DAL.getItemBatchLocation(pickedItemCode).Tables[0];
                string value = dt.Rows[0]["RemainingQty"].ToString();
                double finalQty = int.Parse(value) - pickedCount;
                // string response = DAL.fnUpdateInventoryLog("UPDATE", finalQty, batchCode, pickedItemCode);

                MessageBox.Show(finalQty.ToString());

            }

            // }
            //}
        }

        public void SaveBatchQtyUpdate(
       string itemCode,
       string batchCodesCsv,
       string locationsCsv,
       int reqQty,
       string ProjetCode)
        {

            var dt1 = DAL.getItemBatchLocation(itemCode).Tables[0];

            // Filter out rows with RemainingQty <= 0, sort by BatchCode (oldest first)
            var rows = dt1.AsEnumerable()
                .Where(r => Convert.ToDouble(r["RemainingQty"]) > 0)
                .OrderBy(r => ParseBatchCode(r["BatchCode"].ToString()))
                .ToList();

            double qtyNeeded = reqQty;
            List<string> batchCodes = new List<string>();
            List<string> locations = new List<string>();

            foreach (var row in rows)
            {
                double batchQty = Convert.ToDouble(row["RemainingQty"]);
                if (qtyNeeded <= 0) break;

                double allocate = Math.Min(batchQty, qtyNeeded);

                // Add this batch code and location ONCE per batch used
                // batchCodes.Add(row["BatchCode"].ToString());
                //locations.Add(row["ItemLocation"].ToString());

                // Track batch code and allocated count
                // string response = DAL.fnUpdateInventoryLog("UPDATE", allocate, itemCode, row["BatchCode"].ToString(), row["ItemLocation"].ToString());
                double newRemainingQty = batchQty - allocate;
                double IssuedQty = int.Parse(row["IssuedQty"].ToString()) + allocate;
                string IssuedProjectCodes = row["IssuedProjectCodes"].ToString() + "," + ProjetCode;
                string IndentBy = row["IndentBy"].ToString() + "," + lblindentby.Text;

                //DAL.fnUpdateInventoryLog("UPDATE", newRemainingQty, itemCode, row["BatchCode"].ToString(), row["ItemLocation"].ToString(), IssuedQty, IssuedProjectCodes, IndentBy);

                qtyNeeded -= allocate;
            }



            // Split batch codes and locations
            // var batchCodes = batchCodesCsv.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            //var locations = locationsCsv.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

            // Sanity check
            //if (batchCodes.Length != reqQty || locations.Length != reqQty)
            // {
            //   MessageBox.Show("Batch code/location count does not match required quantity.");
            // return;
            //}

            // For each batch/location, decrement RemainingQty by 1
            //for (int i = 0; i < batchCodesCsv.Length ; i++)
            //{
            //  string batchCode = batchCodes[i].Trim();
            // string location = locations[i].Trim();

            // Get current RemainingQty for this batch
            //DataTable dt = DAL.getItemBatchLocation(itemCode).Tables[0];
            //var row = dt.AsEnumerable()
            //  .FirstOrDefault(r => r["BatchCode"].ToString() == batchCode && r["ItemLocation"].ToString() == location);

            //if (row != null)
            //{
            //  double currentQty = Convert.ToDouble(row["RemainingQty"]);
            //double newQty = currentQty - 1; // Decrement by 1 for each allocation

            //string response = DAL.fnUpdateInventoryLog("UPDATE", newQty, itemCode, batchCode, location);
            //MessageBox.Show(response);
            //}
            // }
        }


        private void btnTestSave_Click(object sender, EventArgs e)
        {
            MessageBox.Show("upcoming datas are after clicked the update button!");

            if (dtIndentItems != null && dtIndentItems.Rows.Count > 0)
            {
                //SaveBatchQtyUpdate();
                foreach (DataRow row in dtIndentItems.Rows)
                {
                    string itemCode = row["ItemCode"].ToString();
                    string batchCodesCsv = row["testBatchcode"].ToString();   // e.g. "110920251040,110920251040"
                    string locationsCsv = row["testLocation"].ToString();      // e.g. "FR2-L1-B1,FR2-L1-B1"
                    int reqQty = 0;
                    int.TryParse(row["ReqQty"].ToString(), out reqQty);

                    // Call your save function for this row
                    if (batchCodesCsv != "-" && locationsCsv != "-")
                    {
                        //SaveBatchQtyUpdate(itemCode, batchCodesCsv, locationsCsv, reqQty, row["ProjectCode"].ToString());

                    }
                }
            }
            else
            {
                MessageBox.Show("dtIndentItems is empty.");
            }


            foreach (DataGridViewRow row in dgBOMIndent.Rows)
            {
                MessageBox.Show(row.Cells["pickUpBatchCode1"].Value.ToString());
            }


            if (dtIndentItems != null && dgBOMIndent.Rows.Count > 0)
            {
                StringBuilder sb = new StringBuilder();
                // Add column headers
                foreach (DataColumn col in dtIndentItems.Columns)
                {
                    sb.Append(col.ColumnName + "\t");
                }
                sb.AppendLine();
                // Add row data
                foreach (DataRow row in dtIndentItems.Rows)
                {
                    foreach (var item in row.ItemArray)
                    {
                        sb.Append(item?.ToString() + "\t");
                    }
                    sb.AppendLine();
                }
                MessageBox.Show(sb.ToString(), "dtIndentItems Contents");
            }
            else
            {
                MessageBox.Show("dtIndentItems is empty.");
            }

        }




        private void btnPickUpDone(object sender, EventArgs e)
        {
            pickUpDone.Enabled = false;
            string[] batchCheckArr;
            string[] locationCheckArr;
            string[] fixedBatchArr;
            string[] fixedLocationArr;

            string[] batchCheckArr_dgIndentList;
            string[] locationCheckArr_dgIndentList;
            string[] fixedBatchArr_dgIndentList;
            string[] fixedLocationArr_dgIndentList;

            if (Convert.ToBoolean(dtProjectBOMdetails.Rows[0]["BOMProject"].ToString()) == true)//BOM Project true || false
            {

                foreach (DataGridViewRow DGVR in dgBOMIndent.Rows)
                {
                    //Adding new code for the insert the indentlog with location.
                    try
                    {
                        string batchCodes = DGVR.Cells["pickUpBatchCode1"].Value?.ToString() ?? "";
                        string locations = DGVR.Cells["pickUpLocation1"].Value?.ToString() ?? "";
                        string fixedBatchCode = DGVR.Cells["BatchCode"].Value?.ToString() ?? "";
                        string fixedLocation = DGVR.Cells["Location"].Value?.ToString() ?? "";


                        batchCheckArr = batchCodes.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                                   .Select(s => s.Trim()).ToArray();
                        locationCheckArr = locations.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                                               .Select(s => s.Trim()).ToArray();
                        fixedBatchArr = fixedBatchCode.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                                 .Select(s => s.Trim()).ToArray();
                        fixedLocationArr = fixedLocation.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                                               .Select(s => s.Trim()).ToArray();


                        int index = 0;
                        string FIFOPicked = "true";
                        string remarks = "";
                        foreach (string batchCode in fixedBatchArr)
                        {

                            if (fixedBatchArr[index].ToUpper() != batchCheckArr[index].ToUpper())
                            {
                                FIFOPicked = "false";
                                remarks = remarks + $"| Batch code missmatch {fixedBatchArr[index]} ❌ {batchCheckArr[index]}  ";
                            }

                            if (locationCheckArr[index].ToUpper() != fixedLocationArr[index].ToUpper())
                            {
                                FIFOPicked = "false";
                                remarks = remarks + $"| Location  missmatch {fixedLocationArr[index]} ❌ {locationCheckArr[index]}  ";

                            }

                            index++;
                        }




                        //action,ItemCode, IndentNo, PickedBatchCode, PickedLocation, FIFOFollowed, IndentPickedBy, IssuedBy, CreateDate, Remarks
                        int fnUpdateERPInventoryFIFOlogs = DAL.fnUpdateERPInventoryFIFOLogs(Global.uUPDATE, DGVR.Cells["BOMItemCode"].Value.ToString(), cmbIndentNo.Text, DGVR.Cells["pickUpBatchCode1"].Value.ToString(), DGVR.Cells["pickUpLocation1"].Value.ToString(),
                            FIFOPicked, login.GetUserDetails[2].ToString().ToLower(), null, dtpIndentDate.Text, remarks
                            );
                        int fnUpdateERPInventoryIndentPickUpStatus = DAL.fnUpdateERPInventoryIndentPickUp(Global.uUPDATE, cmbIndentNo.Text, DGVR.Cells["BOMItemCode"].Value.ToString(), DGVR.Cells["pickUpBatchCode1"].Value.ToString(), DGVR.Cells["pickUpLocation1"].Value.ToString());

                        //code end..

                    }
                    catch (Exception ex)
                    {
                        //This Below line code for dev testing - RK
                        //MessageBox.Show("stage 1 code line problem!" + ex.Message);
                    }
                    
                }

                MessageBox.Show("Updated SuccessFully BOMIndent...!");
            }
            else
            {




                foreach (DataGridViewRow DGVR in dgIndentList.Rows)
                {
                    try
                    {
                        string batchCodes = DGVR.Cells["pickUpBatchCode"].Value?.ToString() ?? "";
                        string locations = DGVR.Cells["pickUpLocation"].Value?.ToString() ?? "";
                        string fixedBatchCode = DGVR.Cells["testBatchCode"].Value?.ToString() ?? "";
                        string fixedLocation = DGVR.Cells["testLocation"].Value?.ToString() ?? "";


                        batchCheckArr_dgIndentList = batchCodes.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                                   .Select(s => s.Trim()).ToArray();
                        locationCheckArr_dgIndentList = locations.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                                               .Select(s => s.Trim()).ToArray();
                        fixedBatchArr_dgIndentList = fixedBatchCode.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                                 .Select(s => s.Trim()).ToArray();
                        fixedLocationArr_dgIndentList = fixedLocation.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                                               .Select(s => s.Trim()).ToArray();


                        int index = 0;
                        string FIFOPicked = "true";
                        string remarks = "";
                        foreach (string batchCode in fixedBatchArr_dgIndentList)
                        {

                            if (fixedBatchArr_dgIndentList[index].ToUpper() != batchCheckArr_dgIndentList[index].ToUpper())
                            {
                                FIFOPicked = "false";
                                remarks = remarks + $"| Batch code missmatch {fixedBatchArr_dgIndentList[index]} ❌ {batchCheckArr_dgIndentList[index]}  ";
                            }

                            if (locationCheckArr_dgIndentList[index].ToUpper() != fixedLocationArr_dgIndentList[index].ToUpper())
                            {
                                FIFOPicked = "false";
                                remarks = remarks + $"| Location  missmatch {fixedLocationArr_dgIndentList[index]} ❌ {locationCheckArr_dgIndentList[index]}  ";

                            }

                            index++;
                        }

                        int fnUpdateERPInventoryFIFOlogs = DAL.fnUpdateERPInventoryFIFOLogs(Global.uUPDATE, DGVR.Cells["ItemCode"].Value.ToString(), cmbIndentNo.Text, DGVR.Cells["pickUpBatchCode"].Value.ToString(), DGVR.Cells["pickUpLocation"].Value.ToString(),
                                                 FIFOPicked, login.GetUserDetails[2].ToString().ToLower(), null, dtpIndentDate.Text, remarks
                                               );
                        int fnUpdateERPInventoryIndentPickUpStatus = DAL.fnUpdateERPInventoryIndentPickUp(Global.uUPDATE, cmbIndentNo.Text, DGVR.Cells["ItemCode"].Value.ToString(), DGVR.Cells["pickUpBatchCode"].Value.ToString(), DGVR.Cells["pickUpLocation"].Value.ToString());

                        //MessageBox.Show("Updated SuccessFully dgIndentList...!");
                    }
                    catch (Exception ex)
                    { 
                        //MessageBox.Show("stage 3 code line problem!" + ex.Message); 
                    }
                    
                }

                MessageBox.Show("Updated SuccessFully IndentList...!");
            }

        }

        #region Indent Save Function
        private void btnSave_Click(object sender, EventArgs e)
        {
            fnProjectAmountCheck();

            if (bProjectCost)
            {
                if (Convert.ToBoolean(dtProjectBOMdetails.Rows[0]["BOMProject"].ToString()) == true)//BOM Project true || false
                {
                    try
                    {
                        long iIndentNo = 0;
                        bQtyCheck = false;
                        if (dgBOMIndent.Rows.Count > 0 && !string.IsNullOrEmpty(cmbProjectCode.Text))
                        {
                            foreach (DataGridViewRow row in dgBOMIndent.Rows)
                            {
                                if (Convert.ToDouble(row.Cells["BOMAvailableQty"].Value) <= 0)
                                {
                                    bQtyCheck = true;
                                    MessageBox.Show("The selected item '" + row.Cells["BOMItemCode"].Value + "' available quantity is '0'", "Error", 0, MessageBoxIcon.Warning);
                                    break;
                                }
                                if (Convert.ToDouble(row.Cells["BOMIndentQty"].Value) <= 0)
                                {
                                    bQtyCheck = true;
                                    MessageBox.Show("The selected item '" + row.Cells["BOMItemCode"].Value + "' is already issued for the product", "Error", 0, MessageBoxIcon.Warning);
                                    break;
                                }
                                if (Convert.ToDouble(row.Cells["BOMIndentQty"].Value) > Convert.ToDouble(row.Cells["BOMAvailableQty"].Value))
                                {
                                    bQtyCheck = true;
                                    MessageBox.Show("The selected item '" + row.Cells["BOMItemCode"].Value + "' entered quantity '" + row.Cells["BOMIndentQty"].Value + "' is greater than the available quantity '" + row.Cells["BOMAvailableQty"].Value + "'", "Error", 0, MessageBoxIcon.Warning);
                                    break;
                                }


                            }
                            if (bQtyCheck == false)
                            {
                                if (bDelete == true)
                                {
                                    GLobalClass.iSuccess = DAL.fnAddIndent(Global.uDELETE, cmbIndentNo.Text, null, null, null, null, 0, 0, null, null, 0, lblProjectStatus.Text, false, null, null);
                                    iIndentNo = Convert.ToInt64(cmbIndentNo.Text.Remove(0, 2));
                                }
                                else if (bDelete == false)
                                {
                                    dtIndentNo = DAL.fnGetLastIndentNo().Tables[0];//get last indent no from Database
                                    if (dtIndentNo.Rows.Count > 0)
                                    {
                                        iIndentNo = Convert.ToInt64(dtIndentNo.Rows[0]["IndentNoList"].ToString()) + 1;    //seperate indent no from the indentno format
                                    }
                                }

                                string sProjectcode = cmbProjectCode.Text;

                                var result = sProjectcode.Substring(sProjectcode.Length - 1);
                                if (result.ToString() == "W")
                                {
                                    // bProject = true;

                                    foreach (DataGridViewRow DGVR in dgBOMIndent.Rows)
                                    {
                                        //Adding new code for the insert the indentlog with location.

                                        try
                                        {
                                            // var allocationselseif = AllocateBatchesFIFO(DGVR.Cells["BOMItemCode"].Value.ToString(), int.Parse(DGVR.Cells["BOMIndentQty"].Value.ToString()));

                                            int fnAddERPInventoryIndentStatus = DAL.fnAddERPInventoryIndent(Global.uINSERT, Convert.ToString(("IN" + iIndentNo)), DGVR.Cells["BOMItemCode"].Value.ToString(),
                                            cmbProjectCode.Text, lblReturnedby.Text, dtpIndentDate.Text, Convert.ToDouble(DGVR.Cells["BOMIndentQty"].Value.ToString()),
                                            Convert.ToDouble(DGVR.Cells["BOMIndentQty"].Value.ToString()), ReviewTextBox.Text, "Open", DGVR.Cells["ProjectBOMCode"].Value.ToString(),
                                            DGVR.Cells["ProductNo"].Value.ToString(), Convert.ToDouble(DGVR.Cells["BOMQty"].Value.ToString()), lblProjectStatus.Text, "false", null, null);
                                            // allocationselseif[2], allocationselseif[0], allocationselseif[1], allocationselseif[3]
                                            //MessageBox.Show(fnAddERPInventoryIndentStatus.ToString(), "successfully created work order 1");

                                            // int fnAddERPInventoryFIFOLogsStatus = DAL.fnAddERPInventoryFIFOLogs(Global.uINSERT, "NOBOMItemCode", Convert.ToString(("IN" + iIndentNo)),
                                            //DGVR.Cells["BOMIndentQty"].Value.ToString(),cmbProjectCode.Text, "remarks", allocationselseif[2], allocationselseif[0], allocationselseif[1], null, null, "pending", null, null, null, allocationselseif[3]
                                            // );

                                        }
                                        catch (Exception ex)
                                        { MessageBox.Show("stage 1 code line problem!" + ex.Message); }


                                        //code end..


                                        GLobalClass.iSuccess = DAL.fnAddBOMIndent(Global.uINSERT, Convert.ToString(("IN" + iIndentNo)), DGVR.Cells["BOMItemCode"].Value.ToString(),
                                            cmbProjectCode.Text, lblReturnedby.Text, dtpIndentDate.Text, Convert.ToDouble(DGVR.Cells["BOMIndentQty"].Value.ToString()),
                                            Convert.ToDouble(DGVR.Cells["BOMIndentQty"].Value.ToString()), ReviewTextBox.Text, "Open", iIndentNo, DGVR.Cells["ProjectBOMCode"].Value.ToString(),
                                            DGVR.Cells["ProductNo"].Value.ToString(), DGVR.Cells["BOMQty"].Value.ToString(), lblProjectStatus.Text, false, null, null);     //ProjectBOMCode ProductNo BOMQty Insert into indent table           
                                    }
                                }
                                else
                                {
                                    foreach (DataGridViewRow DGVR in dgBOMIndent.Rows)
                                    {


                                        try
                                        {
                                            //var allocationselseif = AllocateBatchesFIFO(DGVR.Cells["BOMItemCode"].Value.ToString(), int.Parse(DGVR.Cells["BOMIndentQty"].Value.ToString()));
                                            int fnAddERPInventoryIndentStatus = DAL.fnAddERPInventoryIndent(Global.uINSERT, Convert.ToString(("IN" + iIndentNo)), DGVR.Cells["BOMItemCode"].Value.ToString(),
                                            cmbProjectCode.Text, lblReturnedby.Text, dtpIndentDate.Text, Convert.ToDouble(DGVR.Cells["BOMIndentQty"].Value.ToString()),
                                            Convert.ToDouble(DGVR.Cells["BOMIndentQty"].Value.ToString()), ReviewTextBox.Text, "Open", DGVR.Cells["ProjectBOMCode"].Value.ToString(),
                                            DGVR.Cells["ProductNo"].Value.ToString(), Convert.ToDouble(DGVR.Cells["BOMQty"].Value.ToString()), lblProjectStatus.Text, "true", lblReturnedby.Text, dtpIndentDate.Text);
                                            //, allocationselseif[2], allocationselseif[0], allocationselseif[1], allocationselseif[3]
                                            //MessageBox.Show(fnAddERPInventoryIndentStatus.ToString(), "successfully created2");
                                            //int fnAddERPInventoryFIFOLogsStatus = DAL.fnAddERPInventoryFIFOLogs(Global.uINSERT, DGVR.Cells["BOMItemCode"].Value.ToString(), Convert.ToString(("IN" + iIndentNo)),
                                            // DGVR.Cells["BOMIndentQty"].Value.ToString(), cmbProjectCode.Text, "remarks", allocationselseif[2], allocationselseif[0], allocationselseif[1], null, null, "pending", null, null, null, allocationselseif[3]
                                            //);

                                        }
                                        catch (Exception ex)
                                        { MessageBox.Show("stage 2 code line problem!" + ex.Message); }

                                        GLobalClass.iSuccess = DAL.fnAddBOMIndent(Global.uINSERT, Convert.ToString(("IN" + iIndentNo)), DGVR.Cells["BOMItemCode"].Value.ToString(),
                                        cmbProjectCode.Text, lblReturnedby.Text, dtpIndentDate.Text, Convert.ToDouble(DGVR.Cells["BOMIndentQty"].Value.ToString()),
                                        Convert.ToDouble(DGVR.Cells["BOMIndentQty"].Value.ToString()), ReviewTextBox.Text, "Open", iIndentNo, DGVR.Cells["ProjectBOMCode"].Value.ToString(),
                                        DGVR.Cells["ProductNo"].Value.ToString(), DGVR.Cells["BOMQty"].Value.ToString(), lblProjectStatus.Text, true, lblReturnedby.Text, dtpIndentDate.Text);     //ProjectBOMCode ProductNo BOMQty Insert into indent table           
                                    }
                                }
                                if (GLobalClass.iSuccess > 0)
                                {
                                    GLobalClass.iSuccess = DAL.fnAddERPLog(0, ("IN" + iIndentNo), login.GetUserDetails[2], dtpIndentDate.Text, "Indent Created", "Indent");
                                    MessageBox.Show("Indent generated successfully with Indent no IN" + iIndentNo, "Success", 0, MessageBoxIcon.Information);
                                    cmbIndentNo.Text = "IN" + iIndentNo;
                                    btnSave.Enabled = false;
                                    btnSaveExcel.Enabled = true;
                                }
                                else
                                {
                                    MessageBox.Show("Error in Saving", "Error", 0, MessageBoxIcon.Error);
                                }
                            }
                        }
                        else
                        {
                            if (dgBOMIndent.Rows.Count == 0)
                            {
                                MessageBox.Show("No items to save", "Error", 0, MessageBoxIcon.Error);
                            }
                            else if (string.IsNullOrEmpty(cmbProjectCode.Text))
                            {
                                MessageBox.Show("Please select a project", "Error", 0, MessageBoxIcon.Error);
                            }
                        }
                    }
                    catch (Exception ex)
                    { MessageBox.Show("IndentForm_btnSave_Click   " + ex.Message); }
                }
                else
                {
                    try
                    {
                        long iIndentNo = 0;
                        bQtyCheck = false;
                        if (dgIndentList.Rows.Count > 0 && !string.IsNullOrEmpty(cmbProjectCode.Text))
                        {
                            foreach (DataGridViewRow row in dgIndentList.Rows)
                            {
                                if (Convert.ToDouble(row.Cells["AvailableQty"].Value) == 0)
                                {
                                    bQtyCheck = true;
                                    MessageBox.Show("The selected item '" + row.Cells["ItemCode"].Value + "' available quantity is '0'", "Error", 0, MessageBoxIcon.Warning);
                                    break;
                                }

                            }

                            if (bQtyCheck == false)
                            {
                                if (bDelete == true)
                                {
                                    GLobalClass.iSuccess = DAL.fnAddIndent(Global.uDELETE, cmbIndentNo.Text, null, null, null, null, 0, 0, null, null, 0, null, false, null, null);
                                    iIndentNo = Convert.ToInt64(cmbIndentNo.Text.Remove(0, 2));
                                }
                                else if (bDelete == false)
                                {
                                    dtIndentNo = DAL.fnGetLastIndentNo().Tables[0];//get last indent no from Database
                                    if (dtIndentNo.Rows.Count > 0)
                                    {
                                        iIndentNo = Convert.ToInt64(dtIndentNo.Rows[0]["IndentNoList"].ToString()) + 1;    //seperate indent no from the indentno format
                                    }
                                }

                                string sProjectcode = cmbProjectCode.Text;

                                var result = sProjectcode.Substring(sProjectcode.Length - 1);
                                if (result.ToString() == "W")
                                {

                                    foreach (DataGridViewRow DGVR in dgIndentList.Rows)
                                    {

                                        try
                                        {
                                            //  var allocationselseif = AllocateBatchesFIFO(DGVR.Cells["ItemCode"].Value.ToString(), int.Parse(DGVR.Cells["Quantity"].Value.ToString()));
                                            int fnAddERPInventoryIndentStatus = DAL.fnAddERPInventoryIndent(Global.uINSERT, Convert.ToString(("IN" + iIndentNo)), DGVR.Cells["ItemCode"].Value.ToString(),
                                            cmbProjectCode.Text, lblReturnedby.Text, dtpIndentDate.Text, Convert.ToDouble(DGVR.Cells["Quantity"].Value.ToString()),
                                            Convert.ToDouble(DGVR.Cells["Quantity"].Value.ToString()), ReviewTextBox.Text, "Open", "NONProjectBOMCode",
                                            "NONProductNo", 0, lblProjectStatus.Text, "false", null, null);
                                            // allocationselseif[2], allocationselseif[0], allocationselseif[1], allocationselseif[3]
                                            // MessageBox.Show(fnAddERPInventoryIndentStatus.ToString(), "successfully created4");

                                            //   int fnAddERPInventoryFIFOLogsStatus = DAL.fnAddERPInventoryFIFOLogs(Global.uINSERT, DGVR.Cells["ItemCode"].Value.ToString(), Convert.ToString(("IN" + iIndentNo)),
                                            //  DGVR.Cells["Quantity"].Value.ToString(), cmbProjectCode.Text, "remarks", allocationselseif[2], allocationselseif[0], allocationselseif[1], null, null, "pending", null, null, null, allocationselseif[3]
                                            //);
                                        }
                                        catch (Exception ex)
                                        { MessageBox.Show("stage 3 code line problem!" + ex.Message); }


                                        GLobalClass.iSuccess = DAL.fnAddIndent(Global.uINSERT, Convert.ToString(("IN" + iIndentNo)), DGVR.Cells["ItemCode"].Value.ToString(),
                                            cmbProjectCode.Text, lblindentby.Text, dtpIndentDate.Text, Convert.ToDouble(DGVR.Cells["Quantity"].Value.ToString()),
                                            Convert.ToDouble(DGVR.Cells["Quantity"].Value.ToString()), ReviewTextBox.Text, "Open", iIndentNo, lblProjectStatus.Text, false, null, null);     //Insert into indent table           
                                    }
                                }
                                else
                                {
                                    foreach (DataGridViewRow DGVR in dgIndentList.Rows)
                                    {
                                        try
                                        {

                                            // var allocationselseif = AllocateBatchesFIFO(DGVR.Cells["ItemCode"].Value.ToString(), int.Parse(DGVR.Cells["Quantity"].Value.ToString()));
                                            int fnAddERPInventoryIndentStatus = DAL.fnAddERPInventoryIndent(Global.uINSERT, Convert.ToString(("IN" + iIndentNo)), DGVR.Cells["ItemCode"].Value.ToString(),
                                            cmbProjectCode.Text, lblReturnedby.Text, dtpIndentDate.Text, Convert.ToDouble(DGVR.Cells["Quantity"].Value.ToString()),
                                            Convert.ToDouble(DGVR.Cells["Quantity"].Value.ToString()), ReviewTextBox.Text, "Open", "NONProjectBOMCode",
                                            "NONProductNo", 0, lblProjectStatus.Text, "true", lblReturnedby.Text, dtpIndentDate.Text);

                                            // allocationselseif[2], allocationselseif[0], allocationselseif[1], allocationselseif[3]
                                            // MessageBox.Show(fnAddERPInventoryIndentStatus.ToString(), "successfully created4");

                                            //   int fnAddERPInventoryFIFOLogsStatus = DAL.fnAddERPInventoryFIFOLogs(Global.uINSERT, DGVR.Cells["ItemCode"].Value.ToString(), Convert.ToString(("IN" + iIndentNo)),
                                            // DGVR.Cells["Quantity"].Value.ToString(), cmbProjectCode.Text, "remarks", allocationselseif[2], allocationselseif[0], allocationselseif[1], null, null, "pending", null, null, null, allocationselseif[3]
                                            //);
                                        }
                                        catch (Exception ex)
                                        { MessageBox.Show("stage 4 code line problem!" + ex.Message); }


                                        GLobalClass.iSuccess = DAL.fnAddIndent(Global.uINSERT, Convert.ToString(("IN" + iIndentNo)), DGVR.Cells["ItemCode"].Value.ToString(),
                                            cmbProjectCode.Text, lblindentby.Text, dtpIndentDate.Text, Convert.ToDouble(DGVR.Cells["Quantity"].Value.ToString()),
                                            Convert.ToDouble(DGVR.Cells["Quantity"].Value.ToString()), ReviewTextBox.Text, "Open", iIndentNo, lblProjectStatus.Text, true, lblReturnedby.Text, dtpIndentDate.Text);     //Insert into indent table           
                                    }
                                }
                                if (GLobalClass.iSuccess > 0 && bDelete == false)
                                {
                                    GLobalClass.iSuccess = DAL.fnAddERPLog(0, ("IN" + iIndentNo), login.GetUserDetails[2], dtpIndentDate.Text, "Indent Created", "Indent");
                                    MessageBox.Show("Indent generated successfully with Indent no IN" + iIndentNo, "Success", 0, MessageBoxIcon.Information);
                                    cmbIndentNo.Text = "IN" + iIndentNo;
                                    btnSave.Enabled = false;
                                    btnSaveExcel.Enabled = true;
                                    lblProjectStatus.ResetText();
                                }
                                else if (GLobalClass.iSuccess > 0 && bDelete == true)
                                {
                                    MessageBox.Show("Indent updated successfully with Indent no '" + cmbIndentNo.Text + "'", "Success", 0, MessageBoxIcon.Information);
                                    btnSave.Enabled = false;
                                    btnSaveExcel.Enabled = true;
                                    lblProjectStatus.ResetText();
                                }
                            }
                        }
                        else
                        {
                            if (dgIndentList.Rows.Count == 0)
                            {
                                MessageBox.Show("No items to save", "Error", 0, MessageBoxIcon.Error);
                            }
                            else if (string.IsNullOrEmpty(cmbProjectCode.Text))
                            {
                                MessageBox.Show("Please select a project", "Error", 0, MessageBoxIcon.Error);
                                cmbProjectCode.Focus();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("IndentForm_btnSave_Click   " + ex.Message);
                    }
                }
            }
            else
            {
                if (bProjectCost == false)
                {
                    MessageBox.Show("Issued items limit is more than capex amount.\nContact Accounts department for more details. \n \n Project Capex Amount : " + Math.Round(dProjectCost) + " \n Total Project Issued Amount : " + Math.Round(dTotalProjectSum) + " \n Current Project Indent Amount : " + Math.Round(dCurrentIssuedAmount) + "", "Error", 0, MessageBoxIcon.Error);
                }
            }
        }

        #endregion
        #region Indent View Function
        private void btnView_Click(object sender, EventArgs e)
        {
            bView = true;
            batchCode.Visible = true;
            location.Visible = true;
            testLocation.Visible = true;
            testBatchCode.Visible = true;
            pickUpLocation.Visible = true;
            pickUpLocation1.Visible = true;
            pickUpBatchCode.Visible = true;
            pickUpBatchCode1.Visible = true;
            BOMIndentQty.ReadOnly = true;
            Quantity.ReadOnly = true;
            rough.Visible = true;
            bDelete = true;
            bApprove = false;
            btnSave.Enabled = false;
            cmbIndentNo.Enabled = true;
            cmbIndentNo.Items.Clear();
            dtIndentList = DAL.fnIndentList(0).Tables[0];
            dgIndentList.DataSource = null;
            lblrowcount.ResetText();
            lblcustomername.ResetText();
            lblprojname.ResetText();
            ReviewTextBox.ResetText();
            cmbProjectCode.ResetText();
            cmbProjectCode.Enabled = false;
            lblprojectbom.Enabled = false;
            cmbbomname.Enabled = false;
            if (dtIndentList.Rows.Count > 0)
            {
                foreach (DataRow dr in dtIndentList.Rows)
                {
                    if (!cmbIndentNo.Items.Contains(dr["IndentNo"]))
                        cmbIndentNo.Items.Add(dr["IndentNo"]);
                }
            }

           // if(Convert.ToBoolean(login.GetUserDetails[16]) == true || login.GetUserDetails[2].ToString().ToLower() == "Siddhu")
           // {
             //   pickUpDone.Visible = true;
            //}

            
        }
        #endregion
        #region Indent Check Function





        private void ShowCustomPopup(bool bBOMLocal)
        {
            Form popup = new Form()
            {
                Width = 300,
                Height = 180,

                StartPosition = FormStartPosition.CenterParent
            };

            // Add a label at the top
            Label lblMessage = new Label()
            {
                Text = "Based on your choice, the system will assign location and batch code for the indent.",
                AutoSize = false,
                Width = 260,
                Height = 40,
                Left = 20,
                Top = 10
            };

            Button btnAssign = new Button() { Text = "Assign", Left = 30, Width = 100, Top = 70 };
            Button btnView = new Button() { Text = "View", Left = 150, Width = 100, Top = 70 };

            btnAssign.Click += (sender, e) =>
            {
                popup.Close();
                AssignPickDetails(bBOMLocal);
            };

            btnView.Click += (sender, e) =>
            {
                popup.Close();
                ViewDetails();
            };

            popup.Controls.Add(lblMessage);
            popup.Controls.Add(btnAssign);
            popup.Controls.Add(btnView);
            popup.ShowDialog();
        }

        private void AssignPickDetails(bool bBOMLocal)
        {

            //MessageBox.Show(bBOMLocal.ToString());

            if (dtIndentItems.Rows.Count > 0 && bBOM == false)
            {
                foreach (DataRow row in dtIndentItems.Rows)
                {
                    try
                    {
                        if (!dtIndentItems.Columns.Contains("testBatchCode"))
                            dtIndentItems.Columns.Add("testBatchCode", typeof(string));
                        if (!dtIndentItems.Columns.Contains("testLocation"))
                            dtIndentItems.Columns.Add("testLocation", typeof(string));
                        if (!dtIndentItems.Columns.Contains("pickUpLocation"))
                            dtIndentItems.Columns.Add("pickUpLocation", typeof(string));
                        if (!dtIndentItems.Columns.Contains("pickUpBatchCode"))
                            dtIndentItems.Columns.Add("pickUpBatchCode", typeof(string));
                        if (!dtIndentItems.Columns.Contains("testAssignQty"))
                            dtIndentItems.Columns.Add("testAssignQty", typeof(string));//AssignQty

                        DataTable itemLocationAndBatchCode = DAL.fnIndentAndItemToPickLocation(row["ItemCode"].ToString(), cmbIndentNo.Text).Tables[0];//string IndentNo, string ItemCode
                                                                                                                                                       //

                        //string.IsNullOrEmpty(itemLocationAndBatchCode.Rows[0]["Location"].ToString())) || (itemLocationAndBatchCode.Rows[0]["Location"].ToString() == "-"
                       
                        if ((string.IsNullOrEmpty(itemLocationAndBatchCode.Rows[0]["BatchCode"].ToString()) && string.IsNullOrEmpty(itemLocationAndBatchCode.Rows[0]["Location"].ToString())) || (itemLocationAndBatchCode.Rows[0]["Location"].ToString() == "-" && itemLocationAndBatchCode.Rows[0]["BatchCode"].ToString() =="-")  )
                        {
                            //MessageBox.Show("Tring to apply again");
                            // Handle empty or null case
                            var allocationselseif = AllocateBatchesFIFO(row["ItemCode"].ToString(), int.Parse(row["ReqQty"].ToString()));

                            row["testBatchCode"] = allocationselseif[0]; // itemLocationAndBatchCode.Rows[0]["BatchCode"].ToString();
                            row["testLocation"] = allocationselseif[1]; // itemLocationAndBatchCode.Rows[0]["Location"].ToString();
                            row["testAssignQty"] = allocationselseif[3]; //itemLocationAndBatchCode.Rows[0]["AssignQty"].ToString();
                            try
                            {
                                int fnUpdateERPInventoryIndentPickDetails = DAL.fnUpdateERPInventoryIndentPickDetails(Global.uUPDATE, allocationselseif[2], allocationselseif[0], Convert.ToDouble(row["ReqQty"].ToString()), allocationselseif[1], allocationselseif[3], cmbIndentNo.Text, row["ItemCode"].ToString());
                            }
                            catch (Exception Error)
                            {
                               // MessageBox.Show(Error.Message, "Indent Update New location and Batch code Error ");
                            }
                            try
                            {
                                int fnAddERPInventoryFIFOLogsStatus = DAL.fnAddERPInventoryFIFOLogs(Global.uINSERT, row["ItemCode"].ToString(), cmbIndentNo.Text,
                                           row["ReqQty"].ToString(), cmbProjectCode.Text, "remarks", allocationselseif[2], allocationselseif[0], allocationselseif[1], null, null, "pending", null, null, dtpIndentDate.Text, allocationselseif[3]
                                          );
                            }
                            catch (Exception Error)
                            {
                                //MessageBox.Show(Error.Message, "FIFO Creating Error ");
                            }
                        }
                        else
                        {
                            
                            // Normal case
                            row["testBatchCode"] = itemLocationAndBatchCode.Rows[0]["BatchCode"].ToString();
                            row["testLocation"] = itemLocationAndBatchCode.Rows[0]["Location"].ToString();
                            row["testAssignQty"] = itemLocationAndBatchCode.Rows[0]["AssignQty"].ToString();
                            row["pickUpLocation"] = itemLocationAndBatchCode.Rows[0]["PickedLocation"].ToString();
                            row["pickUpBatchCode"] = itemLocationAndBatchCode.Rows[0]["PickedBatchCode"].ToString();

                           

                            if (itemLocationAndBatchCode.Rows[0]["Location"].ToString() == "NOLocation")
                            {
                                try
                                {
                                    DataTable ItemTableData = DAL.getItemLocation(row["ItemCode"].ToString()).Tables[0];
                                    row["testLocation"] = ItemTableData.Rows[0]["Location"].ToString();
                                    int fnUpdateERPInventoryIndentPickLocationStatus = DAL.fnUpdateERPInventoryIndentPickLocation(Global.uUPDATE, ItemTableData.Rows[0]["Location"].ToString(), cmbIndentNo.Text, row["ItemCode"].ToString());
                                }
                                catch {
                                
                                }
                            }
                        }


                        // row["testBatchCode"] = itemLocationAndBatchCode.Rows[0]["BatchCode"].ToString();
                        // row["testLocation"] = itemLocationAndBatchCode.Rows[0]["Location"].ToString();
                        // row["pickUpLocation"] = itemLocationAndBatchCode.Rows[0]["PickedLocation"].ToString();
                        // row["pickUpBatchCode"] = itemLocationAndBatchCode.Rows[0]["PickedBatchCode"].ToString();
                        // row["testAssignQty"] = itemLocationAndBatchCode.Rows[0]["AssignQty"].ToString();

                        dgIndentListRough.Visible = true;
                        pickUpBatchCode.Visible = true;
                        pickUpBatchCode1.Visible = true;
                        pickUpLocation.Visible = true;
                        pickUpLocation1.Visible = true;
                        batchCode.Visible = true;
                        location.Visible = true;
                        testBatchCode.Visible = true;
                        testLocation.Visible = true;
                        rough.Visible = true;

                    }
                    catch (Exception error)
                    {
                       


                        rough.Visible = false;
                        dgIndentListRough.Visible = false;
                        pickUpBatchCode.Visible = false;
                        pickUpBatchCode1.Visible = false;
                        pickUpLocation.Visible = false;
                        pickUpLocation1.Visible = false;
                        //batchCode.Visible = false;
                        //location.Visible = false;
                        //testBatchCode.Visible = false;
                        //testLocation.Visible = false;
                    }

                }
            }
            else if (dtFinalSelectedItem.Rows.Count > 0 && bBOM == true)
            {

               // MessageBox.Show("Assign Pick Details function called.,", "BOM TRUE");
               // MessageBox.Show(dtBOMIndent.Rows.Count.ToString(), "Lenght");
                foreach (DataRow dr in dtBOMIndent.Rows)
                {
                    try
                    {
                      
                        if (!dtBOMIndent.Columns.Contains("batchCode"))
                            dtBOMIndent.Columns.Add("batchCode", typeof(string));
                        if (!dtBOMIndent.Columns.Contains("location"))
                            dtBOMIndent.Columns.Add("location", typeof(string));
                        if (!dtBOMIndent.Columns.Contains("pickUpLocation1"))
                            dtBOMIndent.Columns.Add("pickUpLocation1", typeof(string));
                        if (!dtBOMIndent.Columns.Contains("pickUpBatchCode1"))
                            dtBOMIndent.Columns.Add("pickUpBatchCode1", typeof(string));//pickUpBatchCode1
                        if (!dtBOMIndent.Columns.Contains("AssignQty"))
                            dtBOMIndent.Columns.Add("AssignQty", typeof(string));

                        DataTable itemLocationAndBatchCode = DAL.fnIndentAndItemToPickLocation(dr["ItemName"].ToString(), cmbIndentNo.Text).Tables[0];//string IndentNo, string ItemCode   

                       

                        if ((string.IsNullOrEmpty(itemLocationAndBatchCode.Rows[0]["BatchCode"].ToString()) && string.IsNullOrEmpty(itemLocationAndBatchCode.Rows[0]["Location"].ToString())) || (itemLocationAndBatchCode.Rows[0]["BatchCode"].ToString() == "-" && itemLocationAndBatchCode.Rows[0]["Location"].ToString() == "-"))
                        {
                            var allocationselseif = AllocateBatchesFIFO(dr["ItemName"].ToString(), int.Parse(dr["IndentQty"].ToString()));
                           // MessageBox.Show("BOM Block Tring to update");
                            // Handle empty or null case

                            dr["batchCode"] = allocationselseif[0]; // itemLocationAndBatchCode.Rows[0]["BatchCode"].ToString();
                            dr["location"] = allocationselseif[1]; // itemLocationAndBatchCode.Rows[0]["Location"].ToString();
                            dr["AssignQty"] = allocationselseif[3]; //itemLocationAndBatchCode.Rows[0]["AssignQty"].ToString();


                            try
                            {
                                int fnUpdateERPInventoryIndentPickDetails = DAL.fnUpdateERPInventoryIndentPickDetails(Global.uUPDATE, allocationselseif[2], allocationselseif[0], Convert.ToDouble(dr["IndentQty"].ToString()), allocationselseif[1], allocationselseif[3], cmbIndentNo.Text, dr["ItemName"].ToString());

                            }
                            catch (Exception Error)
                            {
                               // MessageBox.Show(Error.Message, "Indent Update New location and Batch code Error");
                            }

                            try
                            {

                                //  MessageBox.Show(allocationselseif[0], "batchCodes");
                                //  MessageBox.Show(allocationselseif[1],  "Location");
                                // MessageBox.Show(allocationselseif[2], "GIN Number");
                                // MessageBox.Show(allocationselseif[3], "Assign Qty");


                                int fnAddERPInventoryFIFOLogsStatus = DAL.fnAddERPInventoryFIFOLogs(Global.uINSERT, dr["ItemName"].ToString(), cmbIndentNo.Text,
                                            dr["IndentQty"].ToString(), cmbProjectCode.Text, "remarks", allocationselseif[2], allocationselseif[0], allocationselseif[1], null, null, "pending", null, null, dtpIndentDate.Text, allocationselseif[3]
                                          );

                            }
                            catch (Exception Error)
                            {
                               // MessageBox.Show(Error.Message, "FIFO Update New location and Batch code Error");
                            }


                        }
                        else
                        {
                            // Normal case
                            // MessageBox.Show("This Indent Already have Location and Item. Please Continue...");
                            dr["batchCode"] = itemLocationAndBatchCode.Rows[0]["BatchCode"].ToString();
                            dr["location"] = itemLocationAndBatchCode.Rows[0]["Location"].ToString();
                            dr["AssignQty"] = itemLocationAndBatchCode.Rows[0]["AssignQty"].ToString();
                            dr["pickUpLocation1"] = itemLocationAndBatchCode.Rows[0]["PickedLocation"].ToString();
                            dr["pickUpBatchCode1"] = itemLocationAndBatchCode.Rows[0]["PickedBatchCode"].ToString();

                            if (itemLocationAndBatchCode.Rows[0]["Location"].ToString() == "NOLocation")
                            {
                                try
                                {
                                    DataTable ItemTableData = DAL.getItemLocation(dr["ItemName"].ToString()).Tables[0];
                                    dr["location"] = ItemTableData.Rows[0]["Location"].ToString();
                                    int fnUpdateERPInventoryIndentPickLocationStatus = DAL.fnUpdateERPInventoryIndentPickLocation(Global.uUPDATE, ItemTableData.Rows[0]["Location"].ToString(), cmbIndentNo.Text, dr["ItemName"].ToString());
                                }
                                catch
                                {

                                }
                            }
                        }





                        rough.Visible = true;
                        pickUpBatchCode.Visible = true;
                        pickUpBatchCode1.Visible = true;
                        pickUpLocation.Visible = true;
                        pickUpLocation1.Visible = true;
                        batchCode.Visible = true;
                        location.Visible = true;
                        testBatchCode.Visible = true;
                        testLocation.Visible = true;
                    }
                    catch (Exception error)
                    {
                        // MessageBox.Show("Then Indent Number Not present in New Inverntory Indent Table...");
                        //MessageBox.Show(error.Message, "ERROR");
                        MessageBox.Show(error.ToString());
                        rough.Visible = false;
                        pickUpBatchCode.Visible = false;
                        pickUpBatchCode1.Visible = false;
                        pickUpLocation.Visible = false;
                        pickUpLocation1.Visible = false;
                        //batchCode.Visible = false;
                        //location.Visible = false;
                        //testBatchCode.Visible = false;
                        //testLocation.Visible = false;
                    }
                }

            }
        }

        private void ViewDetails()
        {
            // MessageBox.Show("View Details function called.");
        }



        //newlly added
        private void cmbIndentNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            //MessageBox.Show("IndentSelected:", cmbIndentNo.Text);

            rough.Visible = false;
            pickUpBatchCode.Visible = false;
            pickUpBatchCode1.Visible = false;
            pickUpLocation.Visible = false;
            pickUpLocation1.Visible = false;
            pickUpDone.Enabled = true;
            pickUpDone.Visible = true;
            bBOM = false;
            if (cmbIndentNo.Text != "None")
            {

                dtIndentItems = DAL.fnBOMIndent(cmbIndentNo.Text, null).Tables[0]; //get indent no's from indent database

                //MessageBox.Show(dtIndentItems.Rows[0]["BOMProject"].ToString(), "BOMProject");

                if (Convert.ToBoolean(dtIndentItems.Rows[0]["BOMProject"].ToString()) == true)
                {
                    bBOM = true;
                    dtBOMIndent = DAL.fnBOMIndentItems(cmbIndentNo.Text).Tables[0]; //get indent no's from indent database

                    dtFinalSelectedItem = DAL.fnBOMIndent(cmbIndentNo.Text, "BOM").Tables[0];

                    if (!string.IsNullOrEmpty(dtFinalSelectedItem.Rows[0]["ProjectBOMCode"].ToString()) && !string.IsNullOrEmpty(dtFinalSelectedItem.Rows[0]["ProductNo"].ToString()))
                    {
                        dtProdcutName = DAL.fnBOMIndentPoduct(dtFinalSelectedItem.Rows[0]["ProjectBOMCode"].ToString(), dtFinalSelectedItem.Rows[0]["ProductNo"].ToString()).Tables[0]; //get indent no's from indent database

                    }
                }
                else
                {
                    dtIndentItems = DAL.fnBOMIndent(cmbIndentNo.Text, null).Tables[0]; //get indent no's from indent database
                    bBOM = false;
                }

                // Add this code after you assign dtIndentItems


                //foreach (DataRow row in dtIndentItems.Rows)
                //{
                //  row["ItemCode"] = "NEWITEM" + dtIndentItems.Rows.IndexOf(row).ToString("D3"); // Example value
                // row["ProjectCode"] = "PROJ" + dtIndentItems.Rows.IndexOf(row).ToString("D3"); // Example value
                //}

                //fnIndentAndItemToPick

                // 2. Set values for each row

                //ShowCustomPopup(bBOM);
                AssignPickDetails(bBOM);




                if (dtIndentItems != null && dtIndentItems.Rows.Count > 0)
                {
                    StringBuilder sb = new StringBuilder();
                    // Add column headers
                    foreach (DataColumn col in dtIndentItems.Columns)
                    {
                        sb.Append(col.ColumnName + "\t");
                    }
                    sb.AppendLine();
                    // Add row data
                    foreach (DataRow row in dtIndentItems.Rows)
                    {
                        foreach (var item in row.ItemArray)
                        {
                            sb.Append(item?.ToString() + "\t");
                        }
                        sb.AppendLine();
                    }
                    // MessageBox.Show(sb.ToString(), "dtIndentItems Contents");
                }
                else
                {
                    MessageBox.Show("dtIndentItems is empty.");
                }






                if (dtIndentItems.Rows.Count > 0 && bBOM == false)
                {




                    if (dtIndentItems != null && dtIndentItems.Rows.Count > 0)
                    {
                        StringBuilder sb = new StringBuilder();
                        // Add column headers
                        foreach (DataColumn col in dtIndentItems.Columns)
                        {
                            sb.Append(col.ColumnName + "\t");
                        }
                        sb.AppendLine();
                        // Add row data
                        foreach (DataRow row in dtIndentItems.Rows)
                        {
                            foreach (var item in row.ItemArray)
                            {
                                sb.Append(item?.ToString() + "\t");
                            }
                            sb.AppendLine();
                        }
                        //MessageBox.Show(sb.ToString(), "dtIndentItems Contents");
                    }
                    else
                    {
                        MessageBox.Show("dtIndentItems is empty.");
                    }

                    btnSave.Enabled = false;
                    pnitemlist.Enabled = true;
                    pndate.Visible = true;
                    dgIndentList.ReadOnly = true;
                    pnitemlist.Enabled = false;
                    if (login.GetUserDetails[2].ToString().ToLower() == dtIndentItems.Rows[0]["IndentBy"].ToString().ToLower())
                    {
                        if (!bApprove)
                        {
                            //  btnSave.Enabled = true;
                            btnSave.Text = "Update";
                            pnitemlist.Enabled = true;
                            dgIndentList.ReadOnly = false;
                            btnApprove.Visible = false;
                        }
                        else if (bApprove)
                        {
                            btnApprove.Visible = true;
                        }
                    }
                    if (Convert.ToBoolean(login.GetUserDetails[16]) == true || login.GetUserDetails[2].ToString().ToLower() == "siddhu")
                    {
                        if (!bApprove)
                        {
                            // btnSave.Enabled = true;
                            btnSave.Text = "Update";
                            pnitemlist.Enabled = true;
                            dgIndentList.ReadOnly = false;
                            btnApprove.Visible = false;
                            
                        }
                        else if (bApprove)
                        {
                            btnApprove.Visible = true;
                        }
                    }
                    dgIndentList.Visible = true;
                    dgBOMIndent.Visible = false;
                    dgIndentList.AutoGenerateColumns = false;

                    cmbProjectCode.Text = dtIndentItems.Rows[0]["ProjectCode"].ToString();
                    lblprojname.Text = dtIndentItems.Rows[0]["ProjectDescription"].ToString();
                    lblcustomername.Text = dtIndentItems.Rows[0]["Customer"].ToString();
                    lblindentby.Visible = true;
                    lblprdname.Enabled = false;
                    lblProductName.Enabled = false;
                    lblProductName.ResetText();
                    lblReturnedby.Text = dtIndentItems.Rows[0]["IndentBy"].ToString();
                    lblindentby.Text = dtIndentItems.Rows[0]["IndentBy"].ToString();
                    lblindentdate.Text = dtIndentItems.Rows[0]["IndentDate"].ToString();
                    ReviewTextBox.Text = dtIndentItems.Rows[0]["Remarks"].ToString();
                    dgIndentList.DataSource = dtIndentItems;


                  



                    foreach (DataGridViewRow DGVR in dgIndentList.Rows)
                    {

                        DataTable eRPInventoryFIFOLogs = DAL.fnGetERPInventoryFIFOLogs(DGVR.Cells["ItemCode"].Value.ToString(), cmbIndentNo.Text).Tables[0];

                        if (eRPInventoryFIFOLogs.Rows.Count > 0)
                        {
                           // MessageBox.Show("entering...!");
                            foreach (DataRow FIFOrow in eRPInventoryFIFOLogs.Rows)
                            {
                                if (FIFOrow["FIFOFollowed"].ToString() == "true")
                                {
                                    DGVR.DefaultCellStyle.BackColor = System.Drawing.Color.LightGray;
                                    DGVR.ReadOnly = true;  // Makes the row non-editable
                                                           // DGVR.Cells[0].Style.ForeColor = System.Drawing.Color.Green;
                                    DGVR.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
                                    DGVR.DefaultCellStyle.BackColor = System.Drawing.Color.LightGreen;
                                }
                            }
                        }


                    }



                    //MessageBox.Show("if", bBOM.ToString());
                    lblrowcount.Text = dgIndentList.Rows.Count.ToString();
                    if (dtIndentItems.Rows.Count > 0)
                        btnSaveExcel.Enabled = true;
                    else
                        btnSaveExcel.Enabled = false;


                }

                else if (dtFinalSelectedItem.Rows.Count > 0 && bBOM == true)
                {
                    pnitemlist.Enabled = false;
                    btnSave.Enabled = false;
                    pndate.Visible = true;
                    dgIndentList.ReadOnly = true;
                    pnitemlist.Enabled = false;
                    if (login.GetUserDetails[2].ToString().ToLower() == dtFinalSelectedItem.Rows[0]["IndentBy"].ToString().ToLower())
                    {
                        if (!bApprove)
                        {
                            //  btnSave.Enabled = true;
                            btnSave.Text = "Update";
                            //  pnitemlist.Enabled = true;
                            dgIndentList.ReadOnly = false;
                            btnApprove.Visible = false;
                        }
                        else if (bApprove)
                        {
                            btnApprove.Visible = true;
                        }
                    }
                    if (Convert.ToBoolean(login.GetUserDetails[16]) == true || login.GetUserDetails[2].ToString().ToLower() == "siddhu")
                    {
                        if (!bApprove)
                        {
                            //  btnSave.Enabled = true;
                            btnSave.Text = "Update";
                            //   pnitemlist.Enabled = true;
                            dgIndentList.ReadOnly = false;
                            btnApprove.Visible = false;
                        }
                        else if (bApprove)
                        {
                            btnApprove.Visible = true;
                        }
                    }


                    foreach (DataRow dr in dtBOMIndent.Rows)
                    {


                        dtIssuedBOMItemQTY = DAL.fnIssuedBOMProductNumber(dtFinalSelectedItem.Rows[0]["ProjectBOMCode"].ToString(), dtFinalSelectedItem.Rows[0]["ProductNo"].ToString(), dr["ItemName"].ToString()).Tables[0];

                        if (dtIssuedBOMItemQTY.Rows.Count > 0)
                        {
                            sIssuedQty = dtIssuedBOMItemQTY.Rows[0]["IssuedQuantity"].ToString();
                        }
                        else
                        {
                            sIssuedQty = "0";
                        }
                        DataRow dr1 = dtBOMIndent.Rows[dtBOMIndent.Rows.IndexOf(dr)];

                        dr1["IssuedQuantity"] = sIssuedQty;

                        // var allocationselseif = AllocateBatchesFIFO(dr["ItemName"].ToString(), int.Parse(dr["IndentQty"].ToString()));
                        //this copy I made it for the testing 
                        // var allocationselseif = AllocateBatchesFIFO(dr["ItemName"].ToString(), 6);


                        //dr1["batchCode"] = allocationselseif[0];
                        //dr1["location"] = allocationselseif[1];
                        //MessageBox.Show($"BatchCode: {arr[0]}, Location: {arr[1]}");
                        //

                    }


                    dgIndentList.Visible = false;
                    dgBOMIndent.Visible = true;
                    dgBOMIndent.AutoGenerateColumns = false;

                    cmbProjectCode.Text = dtFinalSelectedItem.Rows[0]["ProjectCode"].ToString();
                    lblprojname.Text = dtFinalSelectedItem.Rows[0]["ProjectDescription"].ToString();
                    lblcustomername.Text = dtFinalSelectedItem.Rows[0]["Customer"].ToString();
                    lblindentby.Visible = true;
                    lblReturnedby.Text = dtFinalSelectedItem.Rows[0]["IndentBy"].ToString();
                    lblindentby.Text = dtFinalSelectedItem.Rows[0]["IndentBy"].ToString();
                    lblindentdate.Text = dtFinalSelectedItem.Rows[0]["IndentDate"].ToString();
                    ReviewTextBox.Text = dtFinalSelectedItem.Rows[0]["Remarks"].ToString();
                    if (dtProdcutName.Rows.Count > 0)
                    {
                        // pnitemlist.Enabled = false;
                        lblprdname.Enabled = true;
                        lblProductName.Enabled = true;
                        lblProductName.Text = dtProdcutName.Rows[0][0].ToString();
                    }
                    dgBOMIndent.DataSource = dtBOMIndent;



                    foreach (DataGridViewRow DGVR in dgBOMIndent.Rows)
                    {

                        DataTable eRPInventoryFIFOLogs = DAL.fnGetERPInventoryFIFOLogs(DGVR.Cells["BOMItemCode"].Value.ToString(), cmbIndentNo.Text).Tables[0];

                        if (eRPInventoryFIFOLogs.Rows.Count > 0)
                        {
                           // MessageBox.Show("entering...2");
                            foreach (DataRow FIFOrow in eRPInventoryFIFOLogs.Rows)
                            {
                                if (FIFOrow["FIFOFollowed"].ToString() == "true")
                                {
                                  //  MessageBox.Show("true");
                                    DGVR.DefaultCellStyle.BackColor = System.Drawing.Color.LightGray;
                                    DGVR.ReadOnly = true;  // Makes the row non-editable
                                    //DGVR.Cells[0].Style.ForeColor = System.Drawing.Color.Green;
                                    DGVR.DefaultCellStyle.BackColor = System.Drawing.Color.LightGreen;
                                    DGVR.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
                                    //DGVR.Cells["rough"].Style.BackColor = System.Drawing.Color.Green;
                                    //DGVR.Cells["rough"].Style.ForeColor = System.Drawing.Color.White;
                                    //DGVR.Visible = false;

                                }
                            }
                        }

                     
                    }


                    // Add this code after you assign dtIndentItems
                    if (dtBOMIndent != null && dtBOMIndent.Rows.Count > 0)
                    {
                        StringBuilder sb = new StringBuilder();
                        // Add column headers
                        foreach (DataColumn col in dtBOMIndent.Columns)
                        {
                            sb.Append(col.ColumnName + "\t");
                        }
                        sb.AppendLine();
                        // Add row data
                        foreach (DataRow row in dtBOMIndent.Rows)
                        {
                            foreach (var item in row.ItemArray)
                            {
                                sb.Append(item?.ToString() + "\t");
                            }
                            sb.AppendLine();
                        }
                        // MessageBox.Show(sb.ToString(), "dtBOMIndent");


                    }
                    else
                    {
                        MessageBox.Show("dtIndentItems is empty.");
                    }
                    //MessageBox.Show("else if", bBOM.ToString());
                    lblrowcount.Text = dgBOMIndent.Rows.Count.ToString();
                    if (dtFinalSelectedItem.Rows.Count > 0)
                        btnSaveExcel.Enabled = true;
                    else
                        btnSaveExcel.Enabled = false;
                }
                dtProjectBOMdetails = DAL.fnWIPProjectCode(cmbProjectCode.Text).Tables[0];
                btnClearAll.Enabled = true;
            }
        }

        #endregion


        #region View Indent List
        private void btnviewpolist_Click(object sender, EventArgs e)
        {
            this.Hide();
            pleasewaitform pleaseWait = new pleasewaitform();
            // Display form modelessly
            pleaseWait.Show();
            Application.DoEvents();
            IndentView indentview = new IndentView();
            indentview.Show();
            pleaseWait.Hide();
        }
        #endregion
        #region Indent Datagridview Quantity Validating Function
        private void dgIndentList_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgIndentList.CurrentCell.OwningColumn.Name == "Quantity")
            {
                oldvalue = Convert.ToDouble(dgIndentList.CurrentCell.Value);
            }
        }

        private void dgIndentList_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (!string.IsNullOrEmpty(dgIndentList.CurrentCell.Value.ToString()) && (dgIndentList.CurrentCell.Value.ToString() != sDot))// )// && // != null)
            {
                if (Convert.ToDouble(dgIndentList.CurrentCell.Value.ToString()) != 0)
                {
                    if (Convert.ToDouble(dgIndentList.CurrentCell.Value.ToString()) <= Convert.ToDouble(dgIndentList.CurrentRow.Cells["AvailableQty"].Value.ToString()))
                    {

                    }
                    else
                    {
                        MessageBox.Show("Entered value should be equal or lesser than available quantity", "Error", 0, MessageBoxIcon.Error);
                        dgIndentList.CurrentCell.Value = oldvalue;
                    }
                }
                else
                {
                    MessageBox.Show("Entered value should be greater than 0", "Error", 0, MessageBoxIcon.Error);
                    dgIndentList.CurrentCell.Value = oldvalue;
                }
            }
            else
            {
                MessageBox.Show("Enter a Valid Value", "Error", 0, MessageBoxIcon.Error);
                dgIndentList.CurrentCell.Value = oldvalue;
            }
        }

        private void Control_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }
            // only allow one decimal point
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                e.Handled = true;
            }
        }

        private void dgIndentList_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
            }
        }
        #endregion
        #region Indent Item Delete Function
        private void dgIndentList_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (dgIndentList.Rows.Count > 0)
                {
                    DataTable dtIssued = new DataTable();
                    dtIssued = DAL.fnIssuedDeleteIndent(cmbIndentNo.Text, dgIndentList.CurrentRow.Cells["ItemCode"].Value.ToString()).Tables[0];
                    if (dtIssued.Rows.Count == 0)
                    {

                        DialogResult DR = MessageBox.Show("Do you want to delete selected Item", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                        if (DR == DialogResult.Yes)
                        {
                            if (bDelete == true)
                            {
                                DAL.IndentDelete(cmbIndentNo.Text, dgIndentList.CurrentRow.Cells["ItemCode"].Value.ToString());
                            }
                            dgIndentList.Rows.RemoveAt(dgIndentList.Rows.IndexOf(dgIndentList.CurrentRow));
                        }
                    }
                    else
                    {
                        MessageBox.Show("Selected item already issued", "Error", 0, MessageBoxIcon.Error);
                    }
                }
            }
        }
        #endregion
        #region Form Closing Function
        private void frmIndent_FormClosing(object sender, FormClosingEventArgs e)
        {
            frmForm2 frmForm2 = new frmForm2();
            this.Hide();
            frmForm2.Show();
        }
        #endregion
        string[] sProductCode;
        #region BOM Select Function
        private void cmbbomname_SelectedIndexChanged(object sender, EventArgs e)
        {


            sProductCode = cmbbomname.Text.Split('`');

            dtprojectBOMItems = DAL.fnProjectBOMProdutnamenumber(sProductCode[0], cmbProjectCode.Text, sProductCode[1], sProductCode[2]).Tables[0];

            if (dtprojectBOMItems.Rows.Count > 0)
            {
                lblProductName.Text = dtprojectBOMItems.Rows[0]["ProductName"].ToString() + " - " + dtprojectBOMItems.Rows[0]["ProductType"].ToString();
                lblVersion.Text = dtprojectBOMItems.Rows[0]["Version"].ToString();

                dtMachineBOMProduct = DAL.fnGetIndentMachineBOM(dtprojectBOMItems.Rows[0]["ProjectBOMCode"].ToString(), dtprojectBOMItems.Rows[0]["ProductNo"].ToString(), cmbProjectCode.Text, null).Tables[0];

                if (dtMachineBOMProduct.Rows.Count > 0)
                {
                    chklbItemList.Items.Clear();
                    foreach (DataRow dr in dtMachineBOMProduct.Rows)
                    {
                        if (Convert.ToDouble(dr["IndentQty"].ToString()) > Convert.ToDouble(dr["AvailableQty"].ToString()))
                        {
                            dr["IndentQty"] = Convert.ToDouble(dr["AvailableQty"].ToString());
                        }
                    }
                }
                dgBOMIndent.ReadOnly = false;

                foreach (DataRow dr in dtMachineBOMProduct.Rows)
                {
                    chklbItemList.Items.Add(string.Concat(dr["ID"].ToString(), ") ", dr["ItemCode"].ToString(), ", ", dr["ItemDescription"].ToString(), ", ", dr["AvailableQty"].ToString()));

                }
                pnitemlist.Enabled = true;
            }
        }
        #endregion
        #region BOM Quantity Edit Functions
        private void dgBOMIndent_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            //MessageBox.Show("change!");
            if (dgBOMIndent.CurrentCell.OwningColumn.Name == "BOMIndentQty")
            {
                oldvalue = Convert.ToDouble(dgBOMIndent.CurrentCell.Value);
            }
        }

        private void dgBOMIndent_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            //MessageBox.Show("change1!");
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
            }
        }

        //this code for scan button
        private void dgBOMIndent_CellClick_rough(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dgBOMIndent.Columns["rough"].Index && e.RowIndex >= 0)
            {
                // Your logic here, e.g., show a label/input for this row
                MessageBox.Show("Button clicked for row " + e.RowIndex);
            }
        }
        // Example: Show dynamic labels and input fields on button click







        private int currentIndex_dgIndentList = 0;
        private string[] batchArr_dgIndentList;
        private string[] locationArr_dgIndentList;
        private int currentRowIndex_dgIndentList = -1;
        private string[] AssignQtyArr_dgIndentList;
        private string dgIndentListItemCode = "";

        #region Simplified QR Scanner - Multi-Batch with Auto-Advance

        // ============ CONFIGURATION ============
        // QR Format 1: "ItemCode+Batch" (e.g., "RES-001+BT20250313")
        // QR Format 2: "Location" only (e.g., "A1-B2" or "FR2-L1-B1")
        // Supports multiple batches/locations per item with quantities
        // Auto-advances to next row after completing current item

        // ============ UI CONTROLS ============
        private Panel scanPanel;
        private Label lblTitle;
        private Label lblProgress;
        private Label lblPickQty;
        private Label lblExpectedBatch;
        private Label lblExpectedLocation;
        private Label lblStatus;
        private TextBox txtScan;
        private Button btnSkipBatch;
        private Button btnSkipLocation;
        private Button btnManualEntry;
        private Button btnCancel;
        private Button btnStopAutoAdvance;  // NEW: Emergency stop button

        // ============ STATE ============
        private bool isBOMGrid;
        private int currentRowIndex;
        private string expectedItemCode;
        private string[] expectedBatches;
        private string[] expectedLocations;
        private string[] pickQuantities;
        private int currentBatchIndex;
        private bool waitingForLocation;
        private string currentScannedBatch;
        private List<string> collectedBatches;
        private List<string> collectedLocations;
        private List<string> collectedQuantities;
        private bool autoAdvanceEnabled = true;  // NEW: Can disable if needed

        // ============ ENTRY POINTS ============

        private void dgIndentList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || !(dgIndentList.Columns[e.ColumnIndex] is DataGridViewButtonColumn))
                return;
            StartScanning(dgIndentList, e.RowIndex, false);
        }

        private void dgBOMIndent_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || !(dgBOMIndent.Columns[e.ColumnIndex] is DataGridViewButtonColumn))
                return;
            StartScanning(dgBOMIndent, e.RowIndex, true);
        }

        // ============ MAIN SCANNING LOGIC ============

        private void StartScanning(DataGridView grid, int rowIndex, bool bomGrid)
        {
            isBOMGrid = bomGrid;
            currentRowIndex = rowIndex;
            currentBatchIndex = 0;
            waitingForLocation = false;
            currentScannedBatch = null;
            collectedBatches = new List<string>();
            collectedLocations = new List<string>();
            collectedQuantities = new List<string>();

            // Get data from grid
            DataGridViewRow row = grid.Rows[rowIndex];
            if (isBOMGrid)
            {
                expectedItemCode = row.Cells["BOMItemCode"].Value?.ToString() ?? "";
               // MessageBox.Show(expectedItemCode, "1");
                expectedBatches = ParseCsv(row.Cells["BatchCode"].Value?.ToString());

               // MessageBox.Show(
                //    $"Count: {expectedBatches.Length}\n\nValues:\n{string.Join("\n", expectedBatches)}",
                //    "expectedBatches",
                //    MessageBoxButtons.OK,
               //     MessageBoxIcon.Information
               // );

                expectedLocations = ParseCsv(row.Cells["Location"].Value?.ToString());
               // MessageBox.Show(
                //   $"Count: {expectedLocations.Length}\n\nValues:\n{string.Join("\n", expectedLocations)}",
                 //  "expectedLocations",
                 //  MessageBoxButtons.OK,
               //    MessageBoxIcon.Information
               //);
                pickQuantities = ParseCsv(row.Cells["AssignQty"].Value?.ToString());
            }
            else
            {
                expectedItemCode = row.Cells["ItemCode"].Value?.ToString() ?? "";
                expectedBatches = ParseCsv(row.Cells["testBatchCode"].Value?.ToString());
               // MessageBox.Show(
                //  $"Count: {expectedBatches.Length}\n\nValues:\n{string.Join("\n", expectedBatches)}",
               //   "expectedBatches2",
               //   MessageBoxButtons.OK,
               //   MessageBoxIcon.Information
             // );
                expectedLocations = ParseCsv(row.Cells["testLocation"].Value?.ToString());
                pickQuantities = ParseCsv(row.Cells["testAssignQty"].Value?.ToString());
            }

            // Validate counts match
            if (expectedBatches.Length != expectedLocations.Length || expectedBatches.Length != pickQuantities.Length)
            {
                MessageBox.Show($"Data mismatch!\nBatches: {expectedBatches.Length}\nLocations: {expectedLocations.Length}\nQuantities: {pickQuantities.Length}",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            ShowScanPanel();
        }

        private string[] ParseCsv(string csvValue)
        {
            if (string.IsNullOrWhiteSpace(csvValue) || csvValue == "-")
                return new string[0];

            return csvValue.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                           .Select(s => s.Trim())
                           .ToArray();
        }

        private void ShowScanPanel()
        {
            // Check completion and auto-advance
            if (currentBatchIndex >= expectedBatches.Length)
            {
                SaveCurrentRowAndAdvance();
                return;
            }

            // Clean up old
            if (scanPanel != null)
            {
                scanPanel.Dispose();
                scanPanel = null;
            }

            // Create panel
            scanPanel = new Panel
            {
                Name = "scanPanel",
                Size = new Size(520, 340),
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.White,
                Location = new Point((this.ClientSize.Width - 520) / 2, (this.ClientSize.Height - 340) / 2)
            };

            string currentBatch = expectedBatches[currentBatchIndex];
            string currentLocation = expectedLocations[currentBatchIndex];
            string currentQty = pickQuantities[currentBatchIndex];

            // Title with auto-advance indicator
            lblTitle = new Label
            {
                Text = waitingForLocation ? "📍 SCAN LOCATION QR" : "📦 SCAN ITEM + BATCH QR",
                Location = new Point(10, 10),
                Size = new Size(500, 30),
                Font = new Font("Arial", 14, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = waitingForLocation ? Color.DarkGreen : Color.DarkBlue
            };

            // Auto-advance status
            Label lblAutoAdvance = new Label
            {
                Text = autoAdvanceEnabled ? "⚡ AUTO-ADVANCE ON" : "⏹️ AUTO-ADVANCE OFF",
                Location = new Point(10, 42),
                Size = new Size(500, 20),
                Font = new Font("Arial", 9),
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = autoAdvanceEnabled ? Color.DarkGreen : Color.Gray
            };

            // Progress
            Label lblProgress = new Label
            {
                Text = $"Batch {currentBatchIndex + 1} of {expectedBatches.Length}",
                Location = new Point(10, 67),
                Size = new Size(500, 22),
                Font = new Font("Arial", 11, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.DarkSlateBlue
            };

            // Item info
            Label lblItemInfo = new Label
            {
                Text = $"Item: {expectedItemCode}",
                Location = new Point(10, 95),
                Size = new Size(500, 25),
                Font = new Font("Arial", 12, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleCenter
            };

            // Pick Qty - BIG AND RED
            lblPickQty = new Label
            {
                Text = $"🔴 PICK QTY: {currentQty}",
                Location = new Point(10, 125),
                Size = new Size(500, 40),
                Font = new Font("Arial", 18, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.Red,
                BackColor = Color.LightYellow,
                BorderStyle = BorderStyle.FixedSingle
            };

            // Expected values
            lblExpectedBatch = new Label
            {
                Text = waitingForLocation
                    ? $"✓ Batch: {currentScannedBatch}"
                    : $"Expected Batch: {currentBatch}",
                Location = new Point(10, 175),
                Size = new Size(500, 25),
                Font = new Font("Arial", 11),
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = waitingForLocation ? Color.Green : Color.Black
            };

            lblExpectedLocation = new Label
            {
                Text = waitingForLocation
                    ? $"Scan Location: {currentLocation}"
                    : $"Next: Location {currentLocation}",
                Location = new Point(10, 205),
                Size = new Size(500, 25),
                Font = new Font("Arial", 11),
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = waitingForLocation ? Color.DarkOrange : Color.Gray
            };

            // Status
            lblStatus = new Label
            {
                Text = "Ready to scan...",
                Location = new Point(10, 235),
                Size = new Size(500, 25),
                Font = new Font("Arial", 10),
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.Gray
            };

            // Scan input
            txtScan = new TextBox
            {
                Location = new Point(20, 265),
                Size = new Size(480, 35),
                Font = new Font("Arial", 16, FontStyle.Bold),
                TextAlign = HorizontalAlignment.Center,
                ShortcutsEnabled = false,
                CharacterCasing = CharacterCasing.Upper
            };
            txtScan.BackColor = Color.LightYellow;
            txtScan.KeyDown += TxtScan_KeyDown;

            // Buttons
            int btnY = 310;

            btnSkipBatch = new Button
            {
                Text = "Skip Batch",
                Location = new Point(10, btnY),
                Size = new Size(85, 28),
                Font = new Font("Arial", 9),
                Visible = !waitingForLocation
            };
            btnSkipBatch.Click += (s, e) => SkipCurrentBatch();

            btnSkipLocation = new Button
            {
                Text = "Skip Loc",
                Location = new Point(10, btnY),
                Size = new Size(75, 28),
                Font = new Font("Arial", 9),
                Visible = waitingForLocation
            };
            btnSkipLocation.Click += (s, e) => CompleteCurrentBatch(currentLocation);

            btnManualEntry = new Button
            {
                Text = "Manual",
                Location = new Point(105, btnY),
                Size = new Size(70, 28),
                Font = new Font("Arial", 9),
                Visible = false
            };
            btnManualEntry.Click += BtnManualEntry_Click;

            btnStopAutoAdvance = new Button
            {
                Text = autoAdvanceEnabled ? "Stop Auto" : "Start Auto",
                Location = new Point(185, btnY),
                Size = new Size(85, 28),
                Font = new Font("Arial", 9),
                BackColor = autoAdvanceEnabled ? Color.LightCoral : Color.LightGreen
            };
            btnStopAutoAdvance.Click += (s, e) =>
            {
                autoAdvanceEnabled = !autoAdvanceEnabled;
                ShowScanPanel(); // Refresh
            };

            btnCancel = new Button
            {
                Text = "Finish",
                Location = new Point(430, btnY),
                Size = new Size(70, 28),
                Font = new Font("Arial", 9),
                BackColor = Color.LightBlue
            };
            btnCancel.Click += (s, e) => CloseScanPanel();

            // Add controls
            scanPanel.Controls.Add(lblTitle);
            scanPanel.Controls.Add(lblAutoAdvance);
            scanPanel.Controls.Add(lblProgress);
            scanPanel.Controls.Add(lblItemInfo);
            scanPanel.Controls.Add(lblPickQty);
            scanPanel.Controls.Add(lblExpectedBatch);
            scanPanel.Controls.Add(lblExpectedLocation);
            scanPanel.Controls.Add(lblStatus);
            scanPanel.Controls.Add(txtScan);
            scanPanel.Controls.Add(btnSkipBatch);
            scanPanel.Controls.Add(btnSkipLocation);
            scanPanel.Controls.Add(btnManualEntry);
            scanPanel.Controls.Add(btnStopAutoAdvance);
            scanPanel.Controls.Add(btnCancel);

            this.Controls.Add(scanPanel);
            scanPanel.BringToFront();
            this.ActiveControl = txtScan;
            txtScan.Focus();
        }

        // ============ SCAN PROCESSING ============

        private void TxtScan_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Enter) return;

            string scan = txtScan.Text.Trim().ToUpper();
            txtScan.Clear();

            if (string.IsNullOrEmpty(scan))
            {
                ShowStatus("Empty scan", Color.LightCoral);
                return;
            }

            if (!waitingForLocation)
                ProcessItemBatchScan(scan);
            else
                ProcessLocationScan(scan);
        }

        private void ProcessItemBatchScan(string scan)
        {
            //MessageBox.Show(scan, "SCAN TEXT");
            string expectedBatch = expectedBatches[currentBatchIndex];

            var separators = new[] { '+', '|', '#', ' ', '-', ':' };
            var parts = scan.Split(separators, StringSplitOptions.RemoveEmptyEntries);

            //string scannedItem = parts.Length >= 2 ? string.Join("+", parts.Take(parts.Length - 1)) : expectedItemCode;
            //string scannedBatch = parts.Length >= 1 ? parts[parts.Length - 1] : scan;
            string scannedBatch = scan.Substring(scan.Length - 8);
            string scannedItem = scan.Substring(0, scan.Length - 8);


            string resultSubString = expectedBatch.Substring(expectedBatch.Length - 8); 

           // MessageBox.Show(resultSubString, "Scanned Batch!");
           // MessageBox.Show(scannedItem, "scanned item"+ expectedItemCode);
           // MessageBox.Show(scannedBatch, "scannedItem"+ expectedBatch);

            DateTime date = DateTime.ParseExact(resultSubString, "ddMMyyyy", null);

            if (date.Year < 2026)
            {
                // date is before 2026
               // MessageBox.Show("date is before 2026");

                currentScannedBatch = expectedBatch;
                waitingForLocation = true;
                ShowScanPanel();
                ShowStatus("✓ Batch OK! Scan location...", Color.LightGreen);
                System.Media.SystemSounds.Asterisk.Play();
                return;
            }

            // Validate Item

            //MessageBox.Show(expectedItemCode+expectedBatch, "SC"+scannedItem.ToLower()+scannedBatch);

            if (scannedItem.ToLower() != expectedItemCode.ToLower())
            {
                ShowStatus($"❌ WRONG ITEM! Expected: {expectedItemCode}", Color.LightCoral);
                System.Media.SystemSounds.Beep.Play();
                return;
            }
           
            // Validate Batch
            if (scannedBatch != expectedBatch)
            {
                int foundIndex = Array.IndexOf(expectedBatches, scannedBatch);
                if (foundIndex >= 0 && foundIndex != currentBatchIndex)
                {
                    // Wrong order - offer jump
                    var result = MessageBox.Show($"This is batch {foundIndex + 1}. Jump to it?",
                        "Wrong Order", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        currentBatchIndex = foundIndex;
                        currentScannedBatch = scannedBatch;
                        waitingForLocation = true;
                        ShowScanPanel();
                        return;
                    }
                    return;
                }

                ShowStatus($"❌ WRONG BATCH! Expected: {expectedBatch}", Color.LightCoral);
                System.Media.SystemSounds.Beep.Play();
                return;
            }

            // Success
            currentScannedBatch = scannedBatch;
            waitingForLocation = true;
            ShowScanPanel();
            ShowStatus("✓ Batch OK! Scan location...", Color.LightGreen);
            System.Media.SystemSounds.Asterisk.Play();
        }

        private void ProcessLocationScan(string scan)
        {
            string expectedLocation = expectedLocations[currentBatchIndex];
            string scannedLocation = scan.Replace("LOC:", "").Replace("BIN:", "").Trim().ToUpper();

            if (scannedLocation != expectedLocation)
            {
                // Check if valid alternative
                var validLocs = GetValidLocationsForBatch(expectedItemCode, currentScannedBatch);
                if (validLocs.Contains(scannedLocation))
                {
                    ShowStatus($"⚠️ Alt location accepted", Color.LightYellow);
                    CompleteCurrentBatch(scannedLocation);
                }
                else
                {
                    ShowStatus($"❌ WRONG LOCATION! Expected: {expectedLocation}", Color.LightCoral);
                    System.Media.SystemSounds.Beep.Play();
                }
            }
            else
            {
                ShowStatus("✓ Location OK!", Color.LightGreen);
                CompleteCurrentBatch(scannedLocation);
            }
        }

        // ============ BATCH & ROW COMPLETION ============

        private void CompleteCurrentBatch(string finalLocation)
        {
            collectedBatches.Add(currentScannedBatch);
            collectedLocations.Add(finalLocation);
            collectedQuantities.Add(pickQuantities[currentBatchIndex]);

            currentBatchIndex++;
            waitingForLocation = false;
            currentScannedBatch = null;

            // Auto-advance to next batch or next row
            ShowScanPanel();
        }

        private void SkipCurrentBatch()
        {
            collectedBatches.Add(expectedBatches[currentBatchIndex] + "[SKIPPED]");
            collectedLocations.Add(expectedLocations[currentBatchIndex] + "[SKIPPED]");
            collectedQuantities.Add(pickQuantities[currentBatchIndex]);

            currentBatchIndex++;
            waitingForLocation = false;
            currentScannedBatch = null;

            ShowScanPanel();
        }

        // NEW: Save current row and auto-advance to next
        private void SaveCurrentRowAndAdvance()
        {
            // Save to current row
            string batches = string.Join(",", collectedBatches);
            string locations = string.Join(",", collectedLocations);

            DataGridView grid = isBOMGrid ? dgBOMIndent : dgIndentList;
            string batchCol = isBOMGrid ? "pickUpBatchCode1" : "pickUpBatchCode";
            string locCol = isBOMGrid ? "pickUpLocation1" : "pickUpLocation";

            grid.Rows[currentRowIndex].Cells[batchCol].Value = batches;
            grid.Rows[currentRowIndex].Cells[locCol].Value = locations;

            // Color coding
            bool allSkipped = collectedBatches.All(b => b.Contains("[SKIPPED]"));
            bool anySkipped = collectedBatches.Any(b => b.Contains("[SKIPPED]"));

            if (allSkipped)
                grid.Rows[currentRowIndex].DefaultCellStyle.BackColor = Color.LightCoral;
            else if (anySkipped)
                grid.Rows[currentRowIndex].DefaultCellStyle.BackColor = Color.LightYellow;
            else
                grid.Rows[currentRowIndex].DefaultCellStyle.BackColor = Color.LightGreen;

            // Success sound
            System.Media.SystemSounds.Asterisk.Play();

            // Check for next row with pending batches
            if (!autoAdvanceEnabled)
            {
                MessageBox.Show($"Row complete!\n{collectedBatches.Count(b => !b.Contains("[SKIPPED]"))} picked, " +
                               $"{collectedBatches.Count(b => b.Contains("[SKIPPED]"))} skipped", "Done",
                               MessageBoxButtons.OK, MessageBoxIcon.Information);
                CloseScanPanel();
                return;
            }

            // Find next row with batches to scan
            int nextRow = FindNextRowWithBatches(grid, currentRowIndex + 1);

            if (nextRow >= 0)
            {
                // Auto-advance to next row
                currentRowIndex = nextRow;
                currentBatchIndex = 0;
                waitingForLocation = false;
                currentScannedBatch = null;
                collectedBatches.Clear();
                collectedLocations.Clear();
                collectedQuantities.Clear();

                // Get new row's data
                DataGridViewRow row = grid.Rows[nextRow];
                if (isBOMGrid)
                {
                    expectedItemCode = row.Cells["BOMItemCode"].Value?.ToString() ?? "";
                    expectedBatches = ParseCsv(row.Cells["BatchCode"].Value?.ToString());
                    expectedLocations = ParseCsv(row.Cells["Location"].Value?.ToString());
                    pickQuantities = ParseCsv(row.Cells["AssignQty"].Value?.ToString());
                }
                else
                {
                    expectedItemCode = row.Cells["ItemCode"].Value?.ToString() ?? "";
                    expectedBatches = ParseCsv(row.Cells["testBatchCode"].Value?.ToString());
                    expectedLocations = ParseCsv(row.Cells["testLocation"].Value?.ToString());
                    pickQuantities = ParseCsv(row.Cells["testAssignQty"].Value?.ToString());
                }

                // Brief pause so user sees the transition
                ShowTransitionMessage($"✓ Row saved! Moving to next: {expectedItemCode}");
            }
            else
            {
                // No more rows
                MessageBox.Show("🎉 All items completed!", "Done", MessageBoxButtons.OK, MessageBoxIcon.Information);
                CloseScanPanel();
            }
        }

        // Find next row that has batches to scan
        private int FindNextRowWithBatches(DataGridView grid, int startIndex)
        {
            for (int i = startIndex; i < grid.Rows.Count; i++)
            {
                string batchCol = isBOMGrid ? "BatchCode" : "testBatchCode";
                string pickCol = isBOMGrid ? "pickUpBatchCode1" : "pickUpBatchCode";

                string batches = grid.Rows[i].Cells[batchCol].Value?.ToString() ?? "";
                string picked = grid.Rows[i].Cells[pickCol].Value?.ToString() ?? "";

                // Has batches and not yet picked
                if (!string.IsNullOrWhiteSpace(batches) && batches != "-" &&
                    (string.IsNullOrWhiteSpace(picked) || picked == "-"))
                {
                    return i;
                }
            }
            return -1; // No more rows
        }

        // Show brief transition message before reloading panel
        // Show brief transition message before reloading panel
        private void ShowTransitionMessage(string message)
        {
            // Dispose old panel completely and create fresh one
            if (scanPanel != null)
            {
                scanPanel.Dispose();
                scanPanel = null;
            }

            // Create new simple panel for transition
            scanPanel = new Panel
            {
                Name = "scanPanel",
                Size = new Size(520, 340),
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.LightGreen,
                Location = new Point((this.ClientSize.Width - 520) / 2, (this.ClientSize.Height - 340) / 2)
            };

            var lbl = new Label
            {
                Text = message,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Arial", 14, FontStyle.Bold),
                ForeColor = Color.DarkGreen,
                BackColor = Color.LightGreen
            };

            scanPanel.Controls.Add(lbl);
            this.Controls.Add(scanPanel);
            scanPanel.BringToFront();

            // Pause then load next row
            var timer = new System.Windows.Forms.Timer { Interval = 800 };
            timer.Tick += (s, e) =>
            {
                timer.Stop();
                timer.Dispose();
                ShowScanPanel(); // Load next row
            };
            timer.Start();
        }

        // ============ FALLBACK HANDLERS ============

        private void BtnManualEntry_Click(object sender, EventArgs e)
        {
            if (currentBatchIndex >= expectedBatches.Length) return;

            string expectedBatch = expectedBatches[currentBatchIndex];
            string expectedLoc = expectedLocations[currentBatchIndex];
            string expectedQty = pickQuantities[currentBatchIndex];

            using (var form = new Form())
            {
                form.Text = waitingForLocation ? $"Enter Location (Qty: {expectedQty})" : $"Enter Item+Batch (Qty: {expectedQty})";
                form.Size = new Size(450, 250);
                form.StartPosition = FormStartPosition.CenterParent;
                form.FormBorderStyle = FormBorderStyle.FixedDialog;

                var lblQty = new Label
                {
                    Text = $"PICK QTY: {expectedQty}",
                    Location = new Point(20, 20),
                    Size = new Size(400, 30),
                    Font = new Font("Arial", 14, FontStyle.Bold),
                    ForeColor = Color.Red,
                    TextAlign = ContentAlignment.MiddleCenter
                };

                var lbl = new Label
                {
                    Text = waitingForLocation ? $"Location (expected: {expectedLoc}):" : $"ItemCode+Batch:",
                    Location = new Point(20, 60),
                    Size = new Size(400, 20)
                };

                var txt = new TextBox
                {
                    Location = new Point(20, 85),
                    Size = new Size(400, 25),
                    Text = waitingForLocation ? expectedLoc : $"{expectedItemCode}+{expectedBatch}",
                    CharacterCasing = CharacterCasing.Upper
                };

                var btnOK = new Button { Text = "OK", Location = new Point(260, 130), Size = new Size(75, 30), DialogResult = DialogResult.OK };
                var btnCancel = new Button { Text = "Cancel", Location = new Point(345, 130), Size = new Size(75, 30), DialogResult = DialogResult.Cancel };

                form.Controls.AddRange(new Control[] { lblQty, lbl, txt, btnOK, btnCancel });
                form.AcceptButton = btnOK;
                form.CancelButton = btnCancel;

                if (form.ShowDialog(this) == DialogResult.OK)
                {
                    string input = txt.Text.Trim().ToUpper();
                    if (waitingForLocation)
                        CompleteCurrentBatch(input);
                    else
                    {
                        var parts = input.Split(new[] { '+', '|', ' ', '-', ':' }, StringSplitOptions.RemoveEmptyEntries);
                        if (parts.Length >= 1)
                        {
                            currentScannedBatch = parts.Length >= 2 ? parts[parts.Length - 1] : parts[0];
                            waitingForLocation = true;
                            ShowScanPanel();
                        }
                    }
                }
            }
        }

        // ============ HELPERS ============

        private void ShowStatus(string message, Color backColor)
        {
            if (txtScan != null) txtScan.BackColor = backColor;
            if (lblStatus != null)
            {
                lblStatus.Text = message;
                lblStatus.ForeColor = backColor == Color.LightCoral ? Color.DarkRed :
                                    backColor == Color.LightGreen ? Color.DarkGreen : Color.DarkOrange;
            }
        }

        private void CloseScanPanel()
        {
            if (scanPanel != null)
            {
                scanPanel.Dispose();
                scanPanel = null;
            }
            (isBOMGrid ? dgBOMIndent : dgIndentList).Focus();
        }

        private List<string> GetValidLocationsForBatch(string itemCode, string batchCode)
        {
            try
            {
                var dt = DAL.getItemBatchLocation(itemCode).Tables[0];
                return dt.AsEnumerable()
                    .Where(r => r["BatchCode"].ToString().ToUpper() == batchCode.ToUpper())
                    .Select(r => r["ItemLocation"].ToString().ToUpper())
                    .Distinct()
                    .ToList();
            }
            catch
            {
                return new List<string>();
            }
        }

        #endregion

        #endregion

        // private void dgIndentList_CellClick
        private void dgIndentList_CellClick_old(object sender, DataGridViewCellEventArgs e)
        {
            //MessageBox.Show("First Block!");

            if (e.RowIndex >= 0 && dgIndentList.Columns[e.ColumnIndex] is DataGridViewButtonColumn)
            {
                currentRowIndex_dgIndentList = e.RowIndex;
                //testAssignQty testBatchCode testLocation

                string batchCodes = dgIndentList.Rows[e.RowIndex].Cells["testBatchCode"].Value?.ToString() ?? "";
                string locations = dgIndentList.Rows[e.RowIndex].Cells["testLocation"].Value?.ToString() ?? "";
                string AssignQty = dgIndentList.Rows[e.RowIndex].Cells["testAssignQty"].Value?.ToString() ?? "";
                dgIndentListItemCode = dgIndentList.Rows[e.RowIndex].Cells["ItemCode"].Value?.ToString() ?? "";//ItemCode



                batchArr_dgIndentList = batchCodes.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                                     .Select(s => s.Trim()).ToArray();
                locationArr_dgIndentList = locations.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                                       .Select(s => s.Trim()).ToArray();
                AssignQtyArr_dgIndentList = AssignQty.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                                       .Select(s => s.Trim()).ToArray();

               // MessageBox.Show(batchArr_dgIndentList[0], "Indent List");

                currentIndex_dgIndentList = 0;
                ShowValidationPanel_dgIndentList();
            }
        }

        private void ShowValidationPanel_dgIndentList()
        {
            // Remove old panel
            var oldPanel = this.Controls.OfType<Panel>().FirstOrDefault(p => p.Name == "dynamicPanel");
            if (oldPanel != null) this.Controls.Remove(oldPanel);

            if (currentIndex_dgIndentList < 0 || currentIndex_dgIndentList >= batchArr_dgIndentList.Length)
            {
                // ✅ Save once all indexes are done
                dgIndentList.Rows[currentRowIndex_dgIndentList].Cells["pickUpBatchCode"].Value = string.Join(",", batchArr_dgIndentList);
                dgIndentList.Rows[currentRowIndex_dgIndentList].Cells["pickUpLocation"].Value = string.Join(",", locationArr_dgIndentList);
                MessageBox.Show("✔ All values processed and saved!");
                return;
            }

            Panel dynamicPanel = new Panel
            {
                Name = "dynamicPanel",
                Size = new Size(540, 260),
                BorderStyle = BorderStyle.FixedSingle,
                Location = new Point((this.ClientSize.Width - 480) / 2,
                                     (this.ClientSize.Height - 230) / 2)
            };
            this.Controls.Add(dynamicPanel);
            dynamicPanel.BringToFront();


            Label lblAssignQty = new Label { Text = $"PICK QTY: {AssignQtyArr_dgIndentList[currentIndex_dgIndentList]}", Location = new Point(10, 20), Width = 180, Font = new System.Drawing.Font("Arial", 10, FontStyle.Bold), ForeColor = Color.Red };

            Label lblBatch = new Label { Text = $"Batch: {batchArr_dgIndentList[currentIndex_dgIndentList]}", Location = new Point(10, 50), Width = 180, Font = new System.Drawing.Font("Arial", 10, FontStyle.Bold) };
            Label lblLoc = new Label { Text = $"Location: {locationArr_dgIndentList[currentIndex_dgIndentList]}", Location = new Point(10, 90), Width = 180, Font = new System.Drawing.Font("Arial", 10, FontStyle.Bold) };

            //TextBox txtBatch = new TextBox { Name = "txtBatch", Location = new Point(200, 50), Width = 300, Font = new System.Drawing.Font("Arial", 10, FontStyle.Bold) };
            // TextBox txtLoc = new TextBox { Name = "txtLoc", Location = new Point(200, 90), Width = 300, Font = new System.Drawing.Font("Arial", 10, FontStyle.Bold) };

            // Real-time validation colors
            // txtBatch.TextChanged += (s, e) =>
            //{
            //     txtBatch.BackColor = txtBatch.Text.Trim() == dgIndentListItemCode+batchArr_dgIndentList[currentIndex_dgIndentList]
            //        ? Color.LightGreen
            //        : Color.LightCoral;
            //};

            //txtLoc.TextChanged += (s, e) =>
            //{
            //    txtLoc.BackColor = txtLoc.Text.Trim() == locationArr_dgIndentList[currentIndex_dgIndentList]
            //       ? Color.LightGreen
            //       : Color.LightCoral;
            //};


            TextBox txtBatch;
            TextBox txtLoc;


            string batchBuffer = "";
            string locBuffer = "";
            DateTime lastBatchKeyTime = DateTime.MinValue;
            DateTime lastLocKeyTime = DateTime.MinValue;

            const int MaxInterCharMs = 50; // threshold for fast input
            const int MinLengthToAccept = 5; // minimum barcode length


            txtBatch = new TextBox
            {
                Name = "txtBatch",
                Location = new Point(200, 50),
                Width = 300,
                Font = new Font("Arial", 10, FontStyle.Bold),
                ShortcutsEnabled = false // disable paste
            };

            txtLoc = new TextBox
            {
                Name = "txtLoc",
                Location = new Point(200, 90),
                Width = 300,
                Font = new Font("Arial", 10, FontStyle.Bold),
                ShortcutsEnabled = false
            };

            // Attach scanner-only handlers
            txtBatch.KeyPress += TxtBatch_KeyPress;
            txtLoc.KeyPress += TxtLoc_KeyPress;

            // Real-time validation colors
            // Real-time validation colors
             txtBatch.TextChanged += (s, e) =>
            {
                 txtBatch.BackColor = txtBatch.Text.Trim() == dgIndentListItemCode+batchArr_dgIndentList[currentIndex_dgIndentList]
                  ? Color.LightGreen
                   : Color.LightCoral;
            };

            txtLoc.TextChanged += (s, e) =>
            {
                txtLoc.BackColor = txtLoc.Text.Trim() == locationArr_dgIndentList[currentIndex_dgIndentList]
                   ? Color.LightGreen
                  : Color.LightCoral;
            };

            Controls.Add(txtBatch);
            Controls.Add(txtLoc);


            void TxtBatch_KeyPress(object sender, KeyPressEventArgs e)
            {
                HandleScannerInput(e, ref batchBuffer, ref lastBatchKeyTime, txtBatch);
            }

            void TxtLoc_KeyPress(object sender, KeyPressEventArgs e)
            {
                HandleScannerInput(e, ref locBuffer, ref lastLocKeyTime, txtLoc);
            }

            void HandleScannerInput(KeyPressEventArgs e, ref string buffer, ref DateTime lastKeyTime, TextBox targetTextBox)
            {
                var now = DateTime.UtcNow;

                if (e.KeyChar == (char)Keys.Enter)
                {
                    if (buffer.Length >= MinLengthToAccept)
                    {
                        targetTextBox.Text = buffer;
                    }
                    buffer = "";
                    e.Handled = true;
                    return;
                }

                if (!char.IsControl(e.KeyChar))
                {
                    if (lastKeyTime != DateTime.MinValue && (now - lastKeyTime).TotalMilliseconds > MaxInterCharMs)
                    {
                        // Too slow → likely manual typing
                        buffer = "";
                        e.Handled = true;
                        lastKeyTime = now;
                        return;
                    }

                    lastKeyTime = now;
                    buffer += e.KeyChar;
                    e.Handled = true; // prevent showing characters until Enter
                }
            }


            // Next (only if correct)
            Button btnNext = new Button { Text = "Next", Location = new Point(70, 160), Width = 90, Font = new System.Drawing.Font("Arial", 10, FontStyle.Bold), Height = 30, BackColor = Color.White, ForeColor = Color.Black };
            btnNext.Click += (s, e) =>
            {
                if (txtBatch.Text.Trim() == dgIndentListItemCode+batchArr_dgIndentList[currentIndex_dgIndentList] &&
                    txtLoc.Text.Trim() == locationArr_dgIndentList[currentIndex_dgIndentList])
                {

                    this.Controls.Remove(dynamicPanel);
                    currentIndex_dgIndentList++;
                    ShowValidationPanel_dgIndentList();
                }
                else
                {

                    MessageBox.Show("❌ Wrong entry. Please correct before moving.");
                }
            };

            // Back
            Button btnBack = new Button { Text = "Back", Location = new Point(170, 160), Width = 90, Font = new System.Drawing.Font("Arial", 10, FontStyle.Bold), Height = 30, BackColor = Color.White, ForeColor = Color.Black };
            btnBack.Click += (s, e) =>
            {
                if (currentIndex_dgIndentList > 0)
                {
                    this.Controls.Remove(dynamicPanel);
                    currentIndex_dgIndentList--;
                    ShowValidationPanel_dgIndentList();
                }
            };

            // Force Pick (overwrite even if wrong)
            Button btnForce = new Button { Text = "Force Pick", Location = new Point(270, 160), Width = 100, Font = new System.Drawing.Font("Arial", 10, FontStyle.Bold), Height = 30, BackColor = Color.White, ForeColor = Color.Black };
            btnForce.Click += (s, e) =>
            {

                if (txtBatch.Text.Trim() != "" && txtLoc.Text.Trim() != "")
                {
                    batchArr_dgIndentList[currentIndex_dgIndentList] = txtBatch.Text.Trim();
                    locationArr_dgIndentList[currentIndex_dgIndentList] = txtLoc.Text.Trim();

                    this.Controls.Remove(dynamicPanel);
                    currentIndex_dgIndentList++;
                    ShowValidationPanel_dgIndentList();
                }
                else
                {
                    MessageBox.Show("❌ No entry. Please fill the entry before moving.");
                }

            };

            // Close
            Button btnClose = new Button { Text = "Close", Location = new Point(380, 160), Width = 80, Font = new System.Drawing.Font("Arial", 10, FontStyle.Bold), Height = 30, BackColor = Color.White, ForeColor = Color.Black };
            btnClose.Click += (s, e) => { this.Controls.Remove(dynamicPanel); };

            dynamicPanel.Controls.Add(lblAssignQty);
            dynamicPanel.Controls.Add(lblBatch);
            dynamicPanel.Controls.Add(lblLoc);
            dynamicPanel.Controls.Add(txtBatch);
            dynamicPanel.Controls.Add(txtLoc);
            dynamicPanel.Controls.Add(btnNext);
            dynamicPanel.Controls.Add(btnBack);
            dynamicPanel.Controls.Add(btnForce);
            dynamicPanel.Controls.Add(btnClose);
        }


        private int currentIndex = 0;
        private string[] batchArr;
        private string[] locationArr;
       //rk 13-03-2026 private int currentRowIndex = -1;
        private string[] AssignQtyArr;
        private string dgBOMIndentItemCode = "";

        private void dgBOMIndent_CellClick_old(object sender, DataGridViewCellEventArgs e)
        {
            //MessageBox.Show("show message!");
            if (e.RowIndex >= 0 && dgBOMIndent.Columns[e.ColumnIndex] is DataGridViewButtonColumn)
            {
                currentRowIndex = e.RowIndex;
                dgBOMIndentItemCode = dgBOMIndent.Rows[e.RowIndex].Cells["BOMItemCode"].Value?.ToString() ?? "";
                string batchCodes = dgBOMIndent.Rows[e.RowIndex].Cells["BatchCode"].Value?.ToString() ?? "";
                string locations = dgBOMIndent.Rows[e.RowIndex].Cells["Location"].Value?.ToString() ?? "";
                string AssignQty = dgBOMIndent.Rows[e.RowIndex].Cells["AssignQty"].Value?.ToString() ?? "";



                batchArr = batchCodes.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                                     .Select(s => s.Trim()).ToArray();
                locationArr = locations.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                                       .Select(s => s.Trim()).ToArray();
                AssignQtyArr = AssignQty.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                                       .Select(s => s.Trim()).ToArray();
               // MessageBox.Show(AssignQty);
                //MessageBox.Show(AssignQtyArr[0].ToString());
                currentIndex = 0;
                ShowValidationPanel();
            }
        }

        private void ShowValidationPanel()
        {
            // Remove old panel
            var oldPanel = this.Controls.OfType<Panel>().FirstOrDefault(p => p.Name == "dynamicPanel");
            if (oldPanel != null) this.Controls.Remove(oldPanel);

            if (currentIndex < 0 || currentIndex >= batchArr.Length)
            {
                // ✅ Save once all indexes are done
                dgBOMIndent.Rows[currentRowIndex].Cells["pickUpBatchCode1"].Value = string.Join(",", batchArr);
                dgBOMIndent.Rows[currentRowIndex].Cells["pickUpLocation1"].Value = string.Join(",", locationArr);
                MessageBox.Show("✔ All values processed and saved!");
                return;
            }

            Panel dynamicPanel = new Panel
            {
                Name = "dynamicPanel",
                Size = new Size(540, 260),
                BorderStyle = BorderStyle.FixedSingle,
                Location = new Point((this.ClientSize.Width - 480) / 2,
                                     (this.ClientSize.Height - 230) / 2)
            };
            this.Controls.Add(dynamicPanel);
            dynamicPanel.BringToFront();

           // MessageBox.Show(AssignQtyArr[currentIndex].ToString());
            Label lblAssignQty = new Label { Text = $"PICK QTY: {AssignQtyArr[currentIndex]}", Location = new Point(10, 20), Width = 180, Font = new System.Drawing.Font("Arial", 10, FontStyle.Bold), ForeColor = Color.Red };

            Label lblBatch = new Label { Text = $"Batch: {batchArr[currentIndex]}", Location = new Point(10, 50), Width = 180, Font = new System.Drawing.Font("Arial", 10, FontStyle.Bold) };
            Label lblLoc = new Label { Text = $"Location: {locationArr[currentIndex]}", Location = new Point(10, 90), Width = 180, Font = new System.Drawing.Font("Arial", 10, FontStyle.Bold) };

            //TextBox txtBatch = new TextBox { Name = "txtBatch", Location = new Point(200, 50), Width = 300, Font = new System.Drawing.Font("Arial", 10, FontStyle.Bold) };
            //TextBox txtLoc = new TextBox { Name = "txtLoc", Location = new Point(200, 90), Width = 300, Font = new System.Drawing.Font("Arial", 10, FontStyle.Bold) };

            TextBox txtBatch;
            TextBox txtLoc;


            string batchBuffer = "";
            string locBuffer = "";
            DateTime lastBatchKeyTime = DateTime.MinValue;
            DateTime lastLocKeyTime = DateTime.MinValue;

            const int MaxInterCharMs = 50; // threshold for fast input
            const int MinLengthToAccept = 5; // minimum barcode length


            txtBatch = new TextBox
            {
                Name = "txtBatch",
                Location = new Point(200, 50),
                Width = 300,
                Font = new Font("Arial", 10, FontStyle.Bold),
                ShortcutsEnabled = false // disable paste
            };

            txtLoc = new TextBox
            {
                Name = "txtLoc",
                Location = new Point(200, 90),
                Width = 300,
                Font = new Font("Arial", 10, FontStyle.Bold),
                ShortcutsEnabled = false
            };

            // Attach scanner-only handlers
            txtBatch.KeyPress += TxtBatch_KeyPress;
            txtLoc.KeyPress += TxtLoc_KeyPress;

            // Real-time validation colors
            txtBatch.TextChanged += (s, e) =>
            {
                txtBatch.BackColor = txtBatch.Text.Trim() == dgBOMIndentItemCode + batchArr[currentIndex]
                    ? Color.LightGreen
                    : Color.LightCoral;
            };

            txtLoc.TextChanged += (s, e) =>
            {
                txtLoc.BackColor = txtLoc.Text.Trim() == locationArr[currentIndex]
                    ? Color.LightGreen
                    : Color.LightCoral;
            };

            Controls.Add(txtBatch);
            Controls.Add(txtLoc);


           void TxtBatch_KeyPress(object sender, KeyPressEventArgs e)
        {
            HandleScannerInput(e, ref batchBuffer, ref lastBatchKeyTime, txtBatch);
        }

         void TxtLoc_KeyPress(object sender, KeyPressEventArgs e)
        {
            HandleScannerInput(e, ref locBuffer, ref lastLocKeyTime, txtLoc);
        }

         void HandleScannerInput(KeyPressEventArgs e, ref string buffer, ref DateTime lastKeyTime, TextBox targetTextBox)
        {
            var now = DateTime.UtcNow;

            if (e.KeyChar == (char)Keys.Enter)
            {
                if (buffer.Length >= MinLengthToAccept)
                {
                    targetTextBox.Text = buffer;
                }
                buffer = "";
                e.Handled = true;
                return;
            }

            if (!char.IsControl(e.KeyChar))
            {
                if (lastKeyTime != DateTime.MinValue && (now - lastKeyTime).TotalMilliseconds > MaxInterCharMs)
                {
                    // Too slow → likely manual typing
                    buffer = "";
                    e.Handled = true;
                    lastKeyTime = now;
                    return;
                }

                lastKeyTime = now;
                buffer += e.KeyChar;
                e.Handled = true; // prevent showing characters until Enter
            }
        }

            // Real-time validation colors
            //txtBatch.TextChanged += (s, e) =>
           // {
               // MessageBox.Show(txtBatch.Text.Trim(), dgBOMIndentItemCode+batchArr[currentIndex]);

              //  txtBatch.BackColor = txtBatch.Text.Trim() == dgBOMIndentItemCode+batchArr[currentIndex]
                   // ? Color.LightGreen
                  //  : Color.LightCoral;
           /// };

           // txtLoc.TextChanged += (s, e) =>
           // {
           //     txtLoc.BackColor = txtLoc.Text.Trim() == locationArr[currentIndex]
           //         ? Color.LightGreen
            //        : Color.LightCoral;
            //};

            // Next (only if correct)
            Button btnNext = new Button { Text = "Next", Location = new Point(70, 160), Width = 90, Font = new System.Drawing.Font("Arial", 10, FontStyle.Bold), Height = 30, BackColor = Color.White, ForeColor = Color.Black };
            btnNext.Click += (s, e) =>
            {
                if (txtBatch.Text.Trim() == dgBOMIndentItemCode+batchArr[currentIndex] &&
                    txtLoc.Text.Trim() == locationArr[currentIndex])
                {
                    this.Controls.Remove(dynamicPanel);
                    currentIndex++;
                    ShowValidationPanel();
                }
                else
                {
                    MessageBox.Show("❌ Wrong entry. Please correct before moving.");
                }
            };

            // Back
            Button btnBack = new Button { Text = "Back", Location = new Point(170, 160), Width = 90, Font = new System.Drawing.Font("Arial", 10, FontStyle.Bold), Height = 30, BackColor = Color.White, ForeColor = Color.Black };
            btnBack.Click += (s, e) =>
            {
                if (currentIndex > 0)
                {
                    this.Controls.Remove(dynamicPanel);
                    currentIndex--;
                    ShowValidationPanel();
                }
            };

            // Force Pick (overwrite even if wrong)
            Button btnForce = new Button { Text = "Force Pick", Location = new Point(270, 160), Width = 100, Font = new System.Drawing.Font("Arial", 10, FontStyle.Bold), Height = 30, BackColor = Color.White, ForeColor = Color.Black };
            btnForce.Click += (s, e) =>
            {

                if (txtBatch.Text.Trim() != "" && txtLoc.Text.Trim() != "")
                {
                    batchArr[currentIndex] = txtBatch.Text.Trim();
                    locationArr[currentIndex] = txtLoc.Text.Trim();

                    this.Controls.Remove(dynamicPanel);
                    currentIndex++;
                    ShowValidationPanel();
                }
                else
                {
                    MessageBox.Show("❌ No entry. Please fill the entry before moving.");
                }

            };

            // Close
            Button btnClose = new Button { Text = "Close", Location = new Point(380, 160), Width = 80, Font = new System.Drawing.Font("Arial", 10, FontStyle.Bold), Height = 30, BackColor = Color.White, ForeColor = Color.Black };
            btnClose.Click += (s, e) => { this.Controls.Remove(dynamicPanel); };

            dynamicPanel.Controls.Add(lblAssignQty);
            dynamicPanel.Controls.Add(lblBatch);
            dynamicPanel.Controls.Add(lblLoc);
            dynamicPanel.Controls.Add(txtBatch);
            dynamicPanel.Controls.Add(txtLoc);
            dynamicPanel.Controls.Add(btnNext);
            dynamicPanel.Controls.Add(btnBack);
            dynamicPanel.Controls.Add(btnForce);
            dynamicPanel.Controls.Add(btnClose);
        }


        //this is the end

        private void dgBOMIndent_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            //MessageBox.Show("final changes!");

            if (dgBOMIndent.CurrentCell.OwningColumn.Name == "pickUpLocation1")
            {
                var editedValue = dgBOMIndent.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;
                MessageBox.Show("pickUpLocation1", editedValue.ToString());
            }

            if (dgBOMIndent.CurrentCell.OwningColumn.Name == "BOMIndentQty")
            {
                if (!string.IsNullOrEmpty(dgBOMIndent.CurrentCell.Value.ToString()) && (dgBOMIndent.CurrentCell.Value.ToString() != sDot))// != null)
                {
                    if (Convert.ToDouble(dgBOMIndent.CurrentCell.Value.ToString()) >= 0)
                    {
                        // dgIndentList.CurrentRow.Cells["Quantity"].Value = Convert.ToString(GlobalClass.fnDGVIsFloatingNumber(dgIndentList.CurrentRow.Cells["Quantity"].Value.ToString()));
                        if (Convert.ToDouble(dgBOMIndent.CurrentRow.Cells["BOMIndentQty"].Value) > (Convert.ToDouble(dgBOMIndent.CurrentRow.Cells["BOMQty"].Value) - Convert.ToDouble(dgBOMIndent.CurrentRow.Cells["IssuedQty"].Value)))
                        {
                            MessageBox.Show("Required Quantity is more than the (BOM Quantity - Issued Quantity) ", "Error", 0, MessageBoxIcon.Error);
                            dgBOMIndent.CurrentRow.Cells["BOMIndentQty"].Value = (Convert.ToDouble(dgBOMIndent.CurrentRow.Cells["BOMQty"].Value) - Convert.ToDouble(dgBOMIndent.CurrentRow.Cells["IssuedQty"].Value)).ToString();
                            if (Convert.ToDouble(dgBOMIndent.CurrentRow.Cells["BOMIndentQty"].Value) > Convert.ToDouble(dgBOMIndent.CurrentRow.Cells["BOMAvailableQty"].Value))
                            {
                                dgBOMIndent.CurrentRow.Cells["BOMIndentQty"].Value = (Convert.ToDouble(dgBOMIndent.CurrentRow.Cells["BOMAvailableQty"].Value));
                            }
                        }
                        else if (Convert.ToDouble(dgBOMIndent.CurrentRow.Cells["BOMIndentQty"].Value) > Convert.ToDouble(dgBOMIndent.CurrentRow.Cells["BOMAvailableQty"].Value))
                        {
                            MessageBox.Show("Required Quantity is more than the Available Quantity", "Error", 0, MessageBoxIcon.Error);
                            dgBOMIndent.CurrentRow.Cells["BOMIndentQty"].Value = (Convert.ToDouble(dgBOMIndent.CurrentRow.Cells["BOMAvailableQty"].Value));
                        }
                        else
                        {
                        }
                    }
                    else
                    {
                        MessageBox.Show("Required Quantity should be greater than 0", "Error", 0, MessageBoxIcon.Error);
                        dgBOMIndent.CurrentRow.Cells["BOMIndentQty"].Value = (Convert.ToDouble(dgBOMIndent.CurrentRow.Cells["BOMQty"].Value) - Convert.ToDouble(dgBOMIndent.CurrentRow.Cells["IssuedQty"].Value)).ToString();
                        if (Convert.ToDouble(dgBOMIndent.CurrentRow.Cells["BOMIndentQty"].Value) > Convert.ToDouble(dgBOMIndent.CurrentRow.Cells["BOMAvailableQty"].Value))
                        {
                            dgBOMIndent.CurrentRow.Cells["BOMIndentQty"].Value = (Convert.ToDouble(dgBOMIndent.CurrentRow.Cells["BOMAvailableQty"].Value));
                        }

                    }
                }

                else
                {
                    MessageBox.Show("Enter a Valid Value", "Error", 0, MessageBoxIcon.Error);
                    dgBOMIndent.CurrentCell.Value = oldvalue;
                }
            }
        }

        private void dgBOMIndent_KeyUp(object sender, KeyEventArgs e)
        {
            //MessageBox.Show("change2!");
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (bView == true)
                {
                    DataTable dtIssued = new DataTable();
                    dtIssued = DAL.fnIssuedDeleteIndent(cmbIndentNo.Text, dgBOMIndent.CurrentRow.Cells["BOMItemCode"].Value.ToString()).Tables[0];
                    if (dtIssued.Rows.Count == 0)
                    {
                        if (dgBOMIndent.Rows.Count > 0 && (Convert.ToBoolean(login.GetUserDetails[16]) == true) || login.GetUserDetails[2].ToString().ToLower() == dtIndentItems.Rows[0]["IndentBy"].ToString().ToLower()
                            || login.GetUserDetails[2].ToString().ToLower() == "Siddhu" || login.GetUserDetails[23] == "Support")
                        {
                            DialogResult DR = MessageBox.Show("Do you want to delete selected Item", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                            if (DR == DialogResult.Yes)
                            {
                                if (bDelete == true)
                                {
                                    DAL.IndentDelete(cmbIndentNo.Text, dgBOMIndent.CurrentRow.Cells["BOMItemCode"].Value.ToString());
                                }
                                dgBOMIndent.Rows.RemoveAt(dgBOMIndent.Rows.IndexOf(dgBOMIndent.CurrentRow));
                                if (dgBOMIndent.Rows.Count == 0)
                                {
                                    cmbbomname.Enabled = true;
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Selected item already issued", "Error", 0, MessageBoxIcon.Error);
                    }

                }
                else
                {
                    DialogResult DR = MessageBox.Show("Do you want to delete selected Item", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (DR == DialogResult.Yes)
                    {
                        dgBOMIndent.Rows.RemoveAt(dgBOMIndent.Rows.IndexOf(dgBOMIndent.CurrentRow));
                        if (dgBOMIndent.Rows.Count == 0)
                        {
                            cmbbomname.Enabled = true;
                        }
                    }
                }
            }
        }
        


        private void chkItemCode_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemCode.CheckState == CheckState.Checked)
            {
                chkItemDesc.Checked = false;
            }
        }

        private void chkItemDesc_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemDesc.CheckState == CheckState.Checked)
            {
                chkItemCode.Checked = false;
            }
        }
        bool bApprove = false;


        private void btnApprove_Click(object sender, EventArgs e)
        {
            if (cmbIndentNo.SelectedIndex >= 0)
            {
                GLobalClass.iSuccess = DAL.fnApproveIndent(1, cmbIndentNo.Text, true, lblReturnedby.Text, dtpIndentDate.Text);
                MessageBox.Show("Indent approved successfully", "Success", 0, MessageBoxIcon.Information);
                cmbIndentNo.Items.RemoveAt(cmbIndentNo.SelectedIndex);
                cmbIndentNo.Text = "";
            }
            else
            {
                MessageBox.Show("Select indent to approve", "Error", 0, MessageBoxIcon.Error);
            }

        }

        private void chkApprove_CheckedChanged(object sender, EventArgs e)
        {
            if (chkApprove.Checked)
            {
                bView = true;
                // bDelete = true;
                btnView.Enabled = false;
                bApprove = true;
                btnSave.Enabled = false;
                cmbIndentNo.Enabled = true;
                cmbIndentNo.Items.Clear();
                dtIndentList = DAL.fnIndentList(1).Tables[0];
                dgIndentList.DataSource = null;
                lblrowcount.ResetText();
                lblcustomername.ResetText();
                lblprojname.ResetText();
                ReviewTextBox.ResetText();
                cmbProjectCode.ResetText();
                cmbProjectCode.Enabled = false;
                lblprojectbom.Enabled = false;
                cmbbomname.Enabled = false;
                if (dtIndentList.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtIndentList.Rows)
                    {
                        if (!cmbIndentNo.Items.Contains(dr["IndentNo"]))
                            cmbIndentNo.Items.Add(dr["IndentNo"]);
                    }
                }
            }
        }

        private void cmbProjectCode_TextChanged(object sender, EventArgs e)
        {
            // MessageBox.Show("message fron new page!");
            BOMIndentQty.ReadOnly = false;
            Quantity.ReadOnly = false;
            if (bView == false)
            {
                dtProjectBOMdetails = DAL.fnWIPProjectCode(cmbProjectCode.Text).Tables[0];

                if (dtProjectBOMdetails.Rows.Count > 0)
                {
                    if (dgBOMIndent.Rows.Count > 0)
                    {
                        DialogResult DR = MessageBox.Show("If project changed all the selected items will be cleared. Do you want to proceed ?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (DR == DialogResult.Yes)
                        {
                            dgBOMIndent.DataSource = null;
                        }
                    }

                    lblprojname.Text = dtProjectBOMdetails.Rows[0]["ProjectDescription"].ToString();
                    lblcustomername.Text = dtProjectBOMdetails.Rows[0]["Customer"].ToString();
                    pnitemlist.Enabled = true;
                    lblProjectStatus.Text = dtProjectBOMdetails.Rows[0]["Status"].ToString();
                    if (Convert.ToBoolean(dtProjectBOMdetails.Rows[0]["BOMProject"].ToString()) == true)
                    {
                        dgBOMIndent.Visible = true;
                        dgIndentList.Visible = false;
                        dtProjectBOM = DAL.fnProjectBOMIndentList(cmbProjectCode.Text).Tables[0];
                        cmbbomname.Items.Clear();
                        cmbbomname.Enabled = true;
                        lblprojectbom.Enabled = true;
                        chklbItemList.Items.Clear();
                        pnitemlist.Enabled = false;
                        lblprdname.Enabled = true;
                        lblProductName.ResetText();
                        lblVersion.ResetText();
                        foreach (DataRow DR in dtProjectBOM.Rows)
                        {
                            cmbbomname.Items.Add(DR["ProductCode"].ToString() + "`" + DR["ProductType"].ToString() + "`" + DR["ProductName"].ToString());
                        }
                        if (cmbbomname.Items.Count > 0)
                        {
                            cmbbomname.Enabled = true;
                        }
                        else
                        {
                            cmbbomname.Enabled = false;
                        }
                        dgIndentList.DataSource = null;

                    }
                    else
                    {
                        lblprdname.Enabled = false;
                        lblProductName.ResetText();
                        dgBOMIndent.DataSource = null;
                        pnitemlist.Enabled = true;
                        chklbItemList.Items.Clear();
                        cmbbomname.Items.Clear();
                        cmbbomname.Enabled = false;
                        lblprojectbom.Enabled = false;
                        dgBOMIndent.Visible = false;
                        dgIndentList.Visible = true;
                    }
                }
            }
        }

        private void cmbProjectCode_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            Indentform = 1;
            frmProjectselect projectsearch = new frmProjectselect();
            projectsearch.fnIndentform = Indentform.ToString();
            projectsearch.ShowDialog();

            if (fnProjectcode != null)
            {
                cmbProjectCode.Text = sProjectCode;
            }
        }

        private void dgBOMIndent_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
