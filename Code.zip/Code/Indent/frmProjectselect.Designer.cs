﻿namespace Erp_Project_With_Buttons.Indent
{
    partial class frmProjectselect
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProjectselect));
            this.gbSearchOptions = new System.Windows.Forms.GroupBox();
            this.btnAllProjects = new System.Windows.Forms.Button();
            this.txtprojectname = new System.Windows.Forms.TextBox();
            this.lblProjectname = new System.Windows.Forms.Label();
            this.lblCustomer = new System.Windows.Forms.Label();
            this.dgProjectList = new System.Windows.Forms.DataGridView();
            this.ProjectCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Customer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TransferProject = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CreatedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DateCreated = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AccountsApprovedby = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AccountsApprovedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GMApproved = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GMApprovedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WarrantyStartDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WarrantyCloseDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbSearchOptions.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgProjectList)).BeginInit();
            this.SuspendLayout();
            // 
            // gbSearchOptions
            // 
            this.gbSearchOptions.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.gbSearchOptions.Controls.Add(this.btnAllProjects);
            this.gbSearchOptions.Controls.Add(this.txtprojectname);
            this.gbSearchOptions.Controls.Add(this.lblProjectname);
            this.gbSearchOptions.Controls.Add(this.lblCustomer);
            this.gbSearchOptions.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.gbSearchOptions.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbSearchOptions.Location = new System.Drawing.Point(4, 4);
            this.gbSearchOptions.Name = "gbSearchOptions";
            this.gbSearchOptions.Size = new System.Drawing.Size(1247, 93);
            this.gbSearchOptions.TabIndex = 8;
            this.gbSearchOptions.TabStop = false;
            // 
            // btnAllProjects
            // 
            this.btnAllProjects.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAllProjects.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAllProjects.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAllProjects.Location = new System.Drawing.Point(1078, 56);
            this.btnAllProjects.Name = "btnAllProjects";
            this.btnAllProjects.Size = new System.Drawing.Size(163, 32);
            this.btnAllProjects.TabIndex = 207;
            this.btnAllProjects.Text = "Load All Projects";
            this.btnAllProjects.UseVisualStyleBackColor = false;
            this.btnAllProjects.Click += new System.EventHandler(this.btnAllProjects_Click);
            // 
            // txtprojectname
            // 
            this.txtprojectname.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtprojectname.Location = new System.Drawing.Point(79, 12);
            this.txtprojectname.Multiline = true;
            this.txtprojectname.Name = "txtprojectname";
            this.txtprojectname.Size = new System.Drawing.Size(657, 48);
            this.txtprojectname.TabIndex = 1;
            this.txtprojectname.Enter += new System.EventHandler(this.txtprojectname_Enter);
            this.txtprojectname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtprojectname_KeyPress);
            this.txtprojectname.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtprojectname_KeyUp);
            // 
            // lblProjectname
            // 
            this.lblProjectname.AutoSize = true;
            this.lblProjectname.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectname.Location = new System.Drawing.Point(19, 27);
            this.lblProjectname.Name = "lblProjectname";
            this.lblProjectname.Size = new System.Drawing.Size(63, 19);
            this.lblProjectname.TabIndex = 9;
            this.lblProjectname.Text = "Search :";
            // 
            // lblCustomer
            // 
            this.lblCustomer.AutoSize = true;
            this.lblCustomer.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomer.Location = new System.Drawing.Point(93, 63);
            this.lblCustomer.Name = "lblCustomer";
            this.lblCustomer.Size = new System.Drawing.Size(427, 19);
            this.lblCustomer.TabIndex = 2;
            this.lblCustomer.Text = "Search result includes project code, project name, customer :";
            // 
            // dgProjectList
            // 
            this.dgProjectList.AllowUserToAddRows = false;
            this.dgProjectList.AllowUserToDeleteRows = false;
            this.dgProjectList.AllowUserToResizeRows = false;
            this.dgProjectList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgProjectList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgProjectList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgProjectList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgProjectList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgProjectList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProjectCode,
            this.ProjectDescription,
            this.Customer,
            this.Status,
            this.ProjectType,
            this.TransferProject,
            this.CreatedBy,
            this.DateCreated,
            this.AccountsApprovedby,
            this.AccountsApprovedDate,
            this.GMApproved,
            this.GMApprovedDate,
            this.WarrantyStartDate,
            this.WarrantyCloseDate});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgProjectList.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgProjectList.EnableHeadersVisualStyles = false;
            this.dgProjectList.Location = new System.Drawing.Point(4, 103);
            this.dgProjectList.MultiSelect = false;
            this.dgProjectList.Name = "dgProjectList";
            this.dgProjectList.ReadOnly = true;
            this.dgProjectList.RowHeadersVisible = false;
            this.dgProjectList.RowHeadersWidth = 51;
            this.dgProjectList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgProjectList.Size = new System.Drawing.Size(1259, 472);
            this.dgProjectList.TabIndex = 9;
            this.dgProjectList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgProjectList_CellContentClick);
            this.dgProjectList.DoubleClick += new System.EventHandler(this.dgProjectList_DoubleClick);
            // 
            // ProjectCode
            // 
            this.ProjectCode.DataPropertyName = "ProjectCode";
            this.ProjectCode.HeaderText = "Project Code";
            this.ProjectCode.MinimumWidth = 6;
            this.ProjectCode.Name = "ProjectCode";
            this.ProjectCode.ReadOnly = true;
            this.ProjectCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectCode.Width = 105;
            // 
            // ProjectDescription
            // 
            this.ProjectDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ProjectDescription.DataPropertyName = "ProjectDescription";
            this.ProjectDescription.HeaderText = "Name";
            this.ProjectDescription.MinimumWidth = 6;
            this.ProjectDescription.Name = "ProjectDescription";
            this.ProjectDescription.ReadOnly = true;
            this.ProjectDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectDescription.Width = 112;
            // 
            // Customer
            // 
            this.Customer.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Customer.DataPropertyName = "Customer";
            this.Customer.HeaderText = "Customer";
            this.Customer.MinimumWidth = 6;
            this.Customer.Name = "Customer";
            this.Customer.ReadOnly = true;
            this.Customer.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Customer.Width = 93;
            // 
            // Status
            // 
            this.Status.DataPropertyName = "Status";
            this.Status.HeaderText = "Status";
            this.Status.MinimumWidth = 6;
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            this.Status.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Status.Width = 66;
            // 
            // ProjectType
            // 
            this.ProjectType.DataPropertyName = "ProjectType";
            this.ProjectType.HeaderText = "ProjectType";
            this.ProjectType.MinimumWidth = 6;
            this.ProjectType.Name = "ProjectType";
            this.ProjectType.ReadOnly = true;
            this.ProjectType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectType.Width = 110;
            // 
            // TransferProject
            // 
            this.TransferProject.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.TransferProject.DataPropertyName = "TransferProject";
            this.TransferProject.HeaderText = "TransferProject";
            this.TransferProject.MinimumWidth = 6;
            this.TransferProject.Name = "TransferProject";
            this.TransferProject.ReadOnly = true;
            this.TransferProject.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.TransferProject.Width = 138;
            // 
            // CreatedBy
            // 
            this.CreatedBy.DataPropertyName = "CreatedBy";
            this.CreatedBy.HeaderText = "Created By";
            this.CreatedBy.MinimumWidth = 6;
            this.CreatedBy.Name = "CreatedBy";
            this.CreatedBy.ReadOnly = true;
            this.CreatedBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CreatedBy.Width = 93;
            // 
            // DateCreated
            // 
            this.DateCreated.DataPropertyName = "DateCreated";
            this.DateCreated.HeaderText = "Created Date";
            this.DateCreated.MinimumWidth = 6;
            this.DateCreated.Name = "DateCreated";
            this.DateCreated.ReadOnly = true;
            this.DateCreated.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DateCreated.Width = 109;
            // 
            // AccountsApprovedby
            // 
            this.AccountsApprovedby.DataPropertyName = "AccountsApprovedby";
            this.AccountsApprovedby.HeaderText = "Approved By";
            this.AccountsApprovedby.MinimumWidth = 6;
            this.AccountsApprovedby.Name = "AccountsApprovedby";
            this.AccountsApprovedby.ReadOnly = true;
            this.AccountsApprovedby.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.AccountsApprovedby.Width = 106;
            // 
            // AccountsApprovedDate
            // 
            this.AccountsApprovedDate.DataPropertyName = "AccountsApprovedDate";
            this.AccountsApprovedDate.HeaderText = "Approved Date";
            this.AccountsApprovedDate.MinimumWidth = 6;
            this.AccountsApprovedDate.Name = "AccountsApprovedDate";
            this.AccountsApprovedDate.ReadOnly = true;
            this.AccountsApprovedDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.AccountsApprovedDate.Width = 122;
            // 
            // GMApproved
            // 
            this.GMApproved.DataPropertyName = "GMApproved";
            this.GMApproved.HeaderText = "GM Approved";
            this.GMApproved.MinimumWidth = 6;
            this.GMApproved.Name = "GMApproved";
            this.GMApproved.ReadOnly = true;
            this.GMApproved.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.GMApproved.Width = 114;
            // 
            // GMApprovedDate
            // 
            this.GMApprovedDate.DataPropertyName = "GMApprovedDate";
            this.GMApprovedDate.HeaderText = "GM Approved Date";
            this.GMApprovedDate.MinimumWidth = 6;
            this.GMApprovedDate.Name = "GMApprovedDate";
            this.GMApprovedDate.ReadOnly = true;
            this.GMApprovedDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.GMApprovedDate.Width = 152;
            // 
            // WarrantyStartDate
            // 
            this.WarrantyStartDate.DataPropertyName = "WarrantyStartDate";
            this.WarrantyStartDate.HeaderText = "Warranty Start";
            this.WarrantyStartDate.MinimumWidth = 6;
            this.WarrantyStartDate.Name = "WarrantyStartDate";
            this.WarrantyStartDate.ReadOnly = true;
            this.WarrantyStartDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.WarrantyStartDate.Width = 120;
            // 
            // WarrantyCloseDate
            // 
            this.WarrantyCloseDate.DataPropertyName = "WarrantyCloseDate";
            this.WarrantyCloseDate.HeaderText = "Warranty Close";
            this.WarrantyCloseDate.MinimumWidth = 6;
            this.WarrantyCloseDate.Name = "WarrantyCloseDate";
            this.WarrantyCloseDate.ReadOnly = true;
            this.WarrantyCloseDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.WarrantyCloseDate.Width = 123;
            // 
            // frmProjectselect
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1267, 577);
            this.Controls.Add(this.dgProjectList);
            this.Controls.Add(this.gbSearchOptions);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmProjectselect";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Project Select";
            this.Load += new System.EventHandler(this.frmProjectselect_Load);
            this.gbSearchOptions.ResumeLayout(false);
            this.gbSearchOptions.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgProjectList)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbSearchOptions;
        private System.Windows.Forms.Label lblCustomer;
        private System.Windows.Forms.TextBox txtprojectname;
        private System.Windows.Forms.Label lblProjectname;
        private System.Windows.Forms.DataGridView dgProjectList;
        private System.Windows.Forms.Button btnAllProjects;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn Customer;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectType;
        private System.Windows.Forms.DataGridViewTextBoxColumn TransferProject;
        private System.Windows.Forms.DataGridViewTextBoxColumn CreatedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn DateCreated;
        private System.Windows.Forms.DataGridViewTextBoxColumn AccountsApprovedby;
        private System.Windows.Forms.DataGridViewTextBoxColumn AccountsApprovedDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn GMApproved;
        private System.Windows.Forms.DataGridViewTextBoxColumn GMApprovedDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn WarrantyStartDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn WarrantyCloseDate;
    }
}