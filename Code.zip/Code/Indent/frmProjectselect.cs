﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Indent
{
    public partial class frmProjectselect : Form
    {
        #region Intialization of Local Datatables, Variables Daclaration
        private const uint uPROJECT_PROJECTCODE_SEARCH = 0;
        private const uint uPROJECT_CUSTOMER_SEARCH = 1;
        private const uint uPROJECT_NAME_SEARCH = 2;
        Login.frmLoginForm login = new Login.frmLoginForm();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        DataTable dtProjectList = new DataTable();
        DataTable dtTableFilter = new DataTable();
        BindingSource bsProjectList = new BindingSource();
        DataView dvProjectList = new DataView();
        Purchase_Order.PurchaseOrder PurchaseOrder = new Purchase_Order.PurchaseOrder();
        JobWork.frmJObWork WorkOrder = new JobWork.frmJObWork();
        ProjectBOM.frmProjectBOM PBOM = new ProjectBOM.frmProjectBOM();
        ProjectBOM.LockBOM PBOMLOCK = new ProjectBOM.LockBOM();
        Project_Documents.frmProjectDocs ProjectDocs = new Project_Documents.frmProjectDocs();
        Design_BOM.frmDesignBOM DesignBOM = new Design_BOM.frmDesignBOM();
        Biss_NC.frmRaiseNC NC = new Biss_NC.frmRaiseNC();
        Biss_NC.Escalation escnc = new Biss_NC.Escalation();
        Item_Return_Adjust_Stock.frmTranferForm TransferForm = new Item_Return_Adjust_Stock.frmTranferForm();

        Project_Master.frmProjectStatusUpdate PSU = new Project_Master.frmProjectStatusUpdate();
        Project_Master.frmProjectInstall PSI = new Project_Master.frmProjectInstall();
        Project_Master.frmProjectShipmentStatusUpdate PSSU = new Project_Master.frmProjectShipmentStatusUpdate();

        Time_Sheet.frmMachineUtilization frmMachineUtilization = new Time_Sheet.frmMachineUtilization();
        Time_Sheet.frmValidationTimeSheet fTimeSheet = new Time_Sheet.frmValidationTimeSheet();

        Project_Master.frmProjectTransferRequest PTR = new Project_Master.frmProjectTransferRequest();

        Indent.frmIndent Indent = new frmIndent();
        KanBanProduct.frmKanbanIssue TransIssue = new KanBanProduct.frmKanbanIssue();
        KanBanProduct.frmElectronicsissue ElectronicIssue = new KanBanProduct.frmElectronicsissue();
        KanBanProduct.frmProjectBOM ElectronicsBOM = new KanBanProduct.frmProjectBOM();
        KanBanProduct.frmKanBanReports KBReports = new KanBanProduct.frmKanBanReports();
        Project_Master.frmProjectApprove ProjectApprove = new Project_Master.frmProjectApprove();

        Purchase_Order.frmPOTrackBOM POTrackBOM = new Purchase_Order.frmPOTrackBOM();
        Project_Master.Machine_Passport MachinePassport = new Project_Master.Machine_Passport();
        Project_Master.Project_Closer Project_Closer = new Project_Master.Project_Closer();

        private static string sIndentform;
        public string fnIndentform
        {
            get
            {
                return sIndentform;
            }
            set
            {
                sIndentform = value;
            }
        }

        private static string sTransIssue;
        public string fnTransIssue
        {
            get
            {
                return sTransIssue;
            }
            set
            {
                sTransIssue = value;
            }
        }

        private static string sElectronicIssue;
        public string fnElectronicIssue
        {
            get
            {
                return sElectronicIssue;
            }
            set
            {
                sElectronicIssue = value;
            }
        }

        private static string sElectronicIssueBOM;
        public string fnElectronicIssueBOM
        {
            get
            {
                return sElectronicIssueBOM;
            }
            set
            {
                sElectronicIssueBOM = value;
            }
        }

        private static string sElectronicReportIssue;
        public string fnElectronicReportIssue
        {
            get
            {
                return sElectronicReportIssue;
            }
            set
            {
                sElectronicReportIssue = value;
            }
        }

        private static string sProjectApprove;
        public string fnProjectApprove
        {
            get
            {
                return sProjectApprove;
            }
            set
            {
                sProjectApprove = value;
            }
        }

        private static string sPTR;
        public string fnPTRform
        {
            get
            {
                return sPTR;
            }
            set
            {
                sPTR = value;
            }
        }

        private static string sNC;
        public string fnNCform
        {
            get
            {
                return sNC;
            }
            set
            {
                sNC = value;
            }
        }
        private static string sEscNC;
        public string fnEscNC
        {
            get
            {
                return sEscNC;
            }
            set
            {
                sEscNC = value;
            }
        }


        private static string sPOform;
        public string fnPOform
        {
            get
            {
                return sPOform;
            }
            set
            {
                sPOform = value;
            }
        }

        private static string sTransferform;
        public string fnTransferform
        {
            get
            {
                return sTransferform;
            }
            set
            {
                sTransferform = value;
            }
        }

        private static string sWOform;
        public string fnWOform
        {
            get
            {
                return sWOform;
            }
            set
            {
                sWOform = value;
            }
        }

        private static string sProjectStatusform;
        public string fnProjectStatusform
        {
            get
            {
                return sProjectStatusform;
            }
            set
            {
                sProjectStatusform = value;
            }
        }

        private static string sProjectStatusInstallform;
        public string fnProjectStatusInstallform
        {
            get
            {
                return sProjectStatusInstallform;
            }
            set
            {
                sProjectStatusInstallform = value;
            }
        }


        private static string sProjectShipStatusInstallform;
        public string fnProjectShipStatusInstallform
        {
            get
            {
                return sProjectShipStatusInstallform;
            }
            set
            {
                sProjectShipStatusInstallform = value;
            }
        }


        private static string sValidationform;
        public string fnValidationform
        {
            get
            {
                return sValidationform;
            }
            set
            {
                sValidationform = value;
            }
        }

        private static string sMUform;
        public string fnMUform
        {
            get
            {
                return sMUform;
            }
            set
            {
                sMUform = value;
            }
        }

        private static string sProjectBOM;
        public string fnProjectBOM
        {
            get
            {
                return sProjectBOM;
            }
            set
            {
                sProjectBOM = value;
            }
        }

        private static string sProjectBOMLOCK;
        public string fnProjectBOMLOCK
        {
            get
            {
                return sProjectBOMLOCK;
            }
            set
            {
                sProjectBOMLOCK = value;
            }
        }

        private static string sViewProjectBOM;
        public string fnViewProjectBOM
        {
            get
            {
                return sViewProjectBOM;
            }
            set
            {
                sViewProjectBOM = value;
            }
        }

        private static string sProjectDoc;
        public string fnProjectDoc
        {
            get
            {
                return sProjectDoc;
            }
            set
            {
                sProjectDoc = value;
            }
        }

        private static string sDesignBOMProjectCode;

        public string fnDesignBOMProjectcode
        {
            get
            {
                return sDesignBOMProjectCode;
            }
            set
            {
                sDesignBOMProjectCode = value;
            }
        }

        //shreeshail
        private static string sMPProjectCode;
        public string fnProject_Master
        {
            get
            {
                return sMPProjectCode;
            }
            set
            {
                sMPProjectCode = value;
            }
        }

        //shreeshail
        private static string scloserProjectCode;
        public string fnProject_Master_coser
        {
            get
            {
                return scloserProjectCode;
            }
            set
            {
                scloserProjectCode = value;
            }
        }


        public frmProjectselect()
        {
            InitializeComponent();
        }
        #endregion
        #region Project Search Filter Function
        private void fnRowFilter(uint uSearchOption, string sRowFilter)
        {
            dvProjectList = new DataView(dtProjectList);
            switch (uSearchOption)
            {
                case uPROJECT_PROJECTCODE_SEARCH:
                    {
                        dvProjectList.RowFilter = "ProjectCode like '%" + sRowFilter + "%' or ProjectDescription like '%" + sRowFilter + "%' or Customer like '%" + sRowFilter + "%'";
                        dvProjectList.Sort = "ProjectCode desc";
                        dgProjectList.DataSource = dvProjectList.ToTable();
                        break;
                    }

                    //case uPROJECT_NAME_SEARCH:
                    //    {
                    //        dvProjectList.RowFilter = "ProjectDescription like '%" + sRowFilter + "%'";
                    //        dgProjectList.DataSource = dvProjectList.ToTable();
                    //        break;
                    //    }
                    //case uPROJECT_CUSTOMER_SEARCH:
                    //    {
                    //        dvProjectList.RowFilter = "Customer like '%" + sRowFilter + "%'";
                    //        dgProjectList.DataSource = dvProjectList.ToTable();
                    //        break;
                    //    }
            }
        }
        #endregion
        #region Project Filter Color
        private void Datagridviewcolor()
        {
            foreach (DataGridViewRow row in dgProjectList.Rows)
            {
                switch (row.Cells["Status"].Value.ToString())
                {
                    case "WIP":
                        row.DefaultCellStyle.BackColor = Color.PaleGreen;
                        break;
                    case "Installation completed":
                        row.DefaultCellStyle.BackColor = Color.LightBlue;
                        break;
                    case "Shipped":
                        row.DefaultCellStyle.BackColor = Color.Moccasin;
                        break;
                    case "Transferred":
                        row.DefaultCellStyle.BackColor = Color.Salmon;
                        break;
                    case "Expensed":
                        row.DefaultCellStyle.BackColor = Color.Wheat;
                        break;
                    case "FG":
                        row.DefaultCellStyle.BackColor = Color.Chocolate;
                        break;
                    case "Cancelled":
                        row.DefaultCellStyle.BackColor = Color.Red;
                        break;
                    case "Converted to FG":
                        row.DefaultCellStyle.BackColor = Color.SteelBlue;
                        break;
                    case "Capitalized FA":
                        row.DefaultCellStyle.BackColor = Color.Silver;
                        break;
                }
            }
        }
        #endregion
        #region Project Select Form Load
        private void frmProjectselect_Load(object sender, EventArgs e)
        {
            dtProjectList = DAL.fnViewProjectList(0, null).Tables[0];  //get all project from database
            bsProjectList.DataSource = dtProjectList;
            dgProjectList.AutoGenerateColumns = false;
            dgProjectList.DataSource = bsProjectList;
            Datagridviewcolor();
        }
        #endregion
        #region Project Search Filters


        private void txtprojectname_Enter(object sender, EventArgs e)
        {
            dgProjectList.DataSource = bsProjectList;
            Datagridviewcolor();
        }

        private void txtprojectname_KeyUp(object sender, KeyEventArgs e)
        {
            fnRowFilter(0, txtprojectname.Text);
            Datagridviewcolor();
        }
        #endregion
        #region Project Select & Send to Different Forms
        DataTable dtProjectDepartment = new DataTable();

        private void dgProjectList_DoubleClick(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(sIndentform))
            {
                sIndentform = "0";
            }
            if (string.IsNullOrEmpty(sPTR))
            {
                sPTR = "0";
            }
            if (string.IsNullOrEmpty(sPOform))
            {
                sPOform = "0";
            }
            if (string.IsNullOrEmpty(sWOform))
            {
                sWOform = "0";
            }
            if (string.IsNullOrEmpty(sProjectBOM))
            {
                sProjectBOM = "0";
            }
            if (string.IsNullOrEmpty(sProjectBOMLOCK))
            {
                sProjectBOMLOCK = "0";
            }
            if (string.IsNullOrEmpty(sProjectDoc))
            {
                sProjectDoc = "0";
            }
            if (string.IsNullOrEmpty(sTransferform))
            {
                sTransferform = "0";
            }

            if (string.IsNullOrEmpty(sDesignBOMProjectCode))
            {
                sDesignBOMProjectCode = "0";
            }
            if (string.IsNullOrEmpty(sNC))
            {
                sNC = "0";
            }
            if (string.IsNullOrEmpty(sEscNC))
            {
                sEscNC = "0";
            }
            if (string.IsNullOrEmpty(sProjectStatusform))
            {
                sProjectStatusform = "0";
            }
            if (string.IsNullOrEmpty(sProjectStatusInstallform))
            {
                sProjectStatusInstallform = "0";
            }
            if (string.IsNullOrEmpty(sValidationform))
            {
                sValidationform = "0";
            }
            if (string.IsNullOrEmpty(sMUform))
            {
                sMUform = "0";
            }
            if (string.IsNullOrEmpty(sTransIssue))
            {
                sTransIssue = "0";
            }
            if (string.IsNullOrEmpty(sElectronicIssue))
            {
                sElectronicIssue = "0";
            }
            if (string.IsNullOrEmpty(sElectronicReportIssue))
            {
                sElectronicReportIssue = "0";
            }
            if (string.IsNullOrEmpty(sProjectApprove))
            {
                sProjectApprove = "0";
            }
            if (string.IsNullOrEmpty(sViewProjectBOM))
            {
                sViewProjectBOM = "0";
            }
            if (string.IsNullOrEmpty(sElectronicIssueBOM))
            {
                sElectronicIssueBOM = "0";
            }
           
            if (string.IsNullOrEmpty(sMPProjectCode))
            {
                sMPProjectCode = "0";
            }
            if (string.IsNullOrEmpty(scloserProjectCode))
            {
                scloserProjectCode = "0";
            }
            //if (Convert.ToBoolean(login.GetUserDetails[24]) == false)
            {

                if (sIndentform.ToString() == "1" && dgProjectList.CurrentRow.Cells["Status"].Value.ToString() == "WIP" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Contract Testing Service (CTS)" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Product Service (PRS)")
                {
                    if (dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() == "Fixed Asset (CIP)")
                    {
                        dtProjectDepartment = DAL.fnDepartmentList(1, dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString(), login.GetUserDetails[23]).Tables[0];
                        if (dtProjectDepartment.Rows.Count > 0)
                        {
                            Indent.fnProjectcode = string.Empty;
                            Indent.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                            sIndentform = "0";
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("You do not have access to use this project, \nPlease contact accounts or corresponding department to give permission to use this project ", "Error", 0, MessageBoxIcon.Error);
                        }
                    }

                    
                    else
                    {
                        if (dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "PurchaseStock(PST)")
                        {
                            Indent.fnProjectcode = string.Empty;
                            Indent.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                            sIndentform = "0";
                            this.Close();
                        }
                    }
                }
                else if (sPOform.ToString() == "1" && dgProjectList.CurrentRow.Cells["Status"].Value.ToString() == "WIP" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Contract Testing Service (CTS)" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Product Service (PRS)")
                {
                    if (dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() == "Fixed Asset (CIP)")
                    {
                        dtProjectDepartment = DAL.fnDepartmentList(1, dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString(), login.GetUserDetails[23]).Tables[0];
                        if (dtProjectDepartment.Rows.Count > 0)
                        {
                            PurchaseOrder.fnProjectcode = string.Empty;
                            PurchaseOrder.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                            sPOform = "0";
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("You do not have access to use this project, \nPlease contact accounts or corresponding department to give permission to use this project ", "Error", 0, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        PurchaseOrder.fnProjectcode = string.Empty;
                        PurchaseOrder.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                        sPOform = "0";
                        this.Close();
                    }
                }
                else if (sWOform.ToString() == "1" && dgProjectList.CurrentRow.Cells["Status"].Value.ToString() == "WIP" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Contract Testing Service (CTS)" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Product Service (PRS)")
                {
                    if (dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() == "Fixed Asset (CIP)")
                    {
                        dtProjectDepartment = DAL.fnDepartmentList(1, dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString(), login.GetUserDetails[23]).Tables[0];
                        if (dtProjectDepartment.Rows.Count > 0)
                        {
                            WorkOrder.fnProjectcode = string.Empty;
                            WorkOrder.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                            sWOform = "0";
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("You do not have access to use this project, \nPlease contact accounts or corresponding department to give permission to use this project ", "Error", 0, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        WorkOrder.fnProjectcode = string.Empty;
                        WorkOrder.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                        sWOform = "0";
                        this.Close();
                    }
                }

                //shreeshail is add bellow code
                /*
                // Check if the indent form is in the '1' state and the project status is 'WIP'
                if (sIndentform.ToString() == "1" &&
                    dgProjectList.CurrentRow.Cells["Status"].Value.ToString() == "WIP" &&
                    dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Contract Testing Service (CTS)" &&
                    dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Product Service (PRS)" &&
                    dgProjectList.CurrentRow.Cells["Status"].Value.ToString() != "Capitalized FA")
                {
                    // Check if the project type is 'Fixed Asset (CIP)'
                    if (dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() == "Fixed Asset (CIP)")
                    {
                        // Retrieve the department list for the project
                        dtProjectDepartment = DAL.fnDepartmentList(
                            1,
                            dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString(),
                            login.GetUserDetails[23]
                        ).Tables[0];

                        // Check if there are any departments
                        if (dtProjectDepartment.Rows.Count > 0)
                        {
                            // User has access, so allow indent
                            Indent.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                            sIndentform = "0";
                            this.Close();
                        }
                        else
                        {
                            // User does not have access, show error message
                            MessageBox.Show(
                                "You do not have access to use this project, \nPlease contact accounts or corresponding department to give permission to use this project",
                                "Error",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error
                            );
                        }
                    }
                }
                else if (dgProjectList.CurrentRow.Cells["Status"].Value.ToString() == "Capitalized FA")
                {
                    // Allow indent for 'Capitalized FA' status
                    Indent.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                    sIndentform = "0";
                    this.Close();
                }
                */


                // Check if the indent form is in the '1' state and the project status is 'WIP'
                if (sIndentform.ToString() == "1" &&
                    dgProjectList.CurrentRow.Cells["Status"].Value.ToString() == "WIP" &&
                    dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Contract Testing Service (CTS)" &&
                    dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Product Service (PRS)" &&
                    dgProjectList.CurrentRow.Cells["Status"].Value.ToString() != "Capitalized FA")
                {
                    // Check if the project type is 'Fixed Asset (CIP)'
                    if (dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() == "Fixed Asset (CIP)")
                    {
                        // Retrieve the department list for the project
                        dtProjectDepartment = DAL.fnDepartmentList(
                            1,
                            dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString(),
                            login.GetUserDetails[23]
                        ).Tables[0];

                        // Check if there are any departments
                        if (dtProjectDepartment.Rows.Count > 0)
                        {
                            // User has access, so allow indent
                            Indent.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                            sIndentform = "0";
                            this.Close();
                        }
                        else
                        {
                            // User does not have access, show error message
                            MessageBox.Show(
                                "You do not have access to use this project, \nPlease contact accounts or corresponding department to give permission to use this project",
                                "Error",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error
                            );
                        }
                    }
                }
                else if (dgProjectList.CurrentRow.Cells["Status"].Value.ToString() == "Capitalized FA")
                {
                    // Allow indent for 'Capitalized FA' status
                    Indent.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                    sIndentform = "0";
                    this.Close();
                }

                // Add code to refresh or clear the project list if another project is selected
                

                //shreeshail is add above code
                else if (sViewProjectBOM.ToString() == "1" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Contract Testing Service (CTS)" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Product Service (PRS)")
                {
                    //POTrackBOM.fnViewBOMProjectcode = string.Empty;
                    POTrackBOM.fnViewBOMProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                    sViewProjectBOM = "0";
                    this.Close();
                }
                else if (sProjectBOM.ToString() == "1" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Contract Testing Service (CTS)" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Product Service (PRS)")
                {
                    PBOM.fnBOMProjectcode = string.Empty;
                    PBOM.fnBOMProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                    sProjectBOM = "0";
                    this.Close();
                }

                else if (sProjectBOMLOCK.ToString() == "1" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Contract Testing Service (CTS)" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Product Service (PRS)")
                {
                    PBOMLOCK.fnProjectcode = string.Empty;
                    PBOMLOCK.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                    sProjectBOMLOCK = "0";
                    this.Close();
                }




                else if (sTransferform.ToString() == "1" && dgProjectList.CurrentRow.Cells["Status"].Value.ToString() == "WIP" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Contract Testing Service (CTS)" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Product Service (PRS)")
                {
                    TransferForm.fnProjectcode = string.Empty;
                    TransferForm.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                    sTransferform = "0";
                    this.Close();
                }
                else if (sProjectDoc.ToString() == "1" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Contract Testing Service (CTS)" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Product Service (PRS)")
                {
                    ProjectDocs.fnProjectcode = string.Empty;
                    ProjectDocs.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                    sProjectDoc = "0";
                    this.Close();
                }
                else if (sDesignBOMProjectCode.ToString() == "1" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Contract Testing Service (CTS)" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Product Service (PRS)")
                {
                    DesignBOM.fnDesignBOMProjectcode = string.Empty;
                    DesignBOM.fnDesignBOMProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                    sDesignBOMProjectCode = "0";
                    this.Close();
                }
                else if (sNC.ToString() == "1" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Contract Testing Service (CTS)" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Product Service (PRS)")
                {
                    NC.fnProjectcode = string.Empty;
                    NC.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                    sNC = "0";
                    this.Close();
                }
                else if (sEscNC.ToString() == "1" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Contract Testing Service (CTS)" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Product Service (PRS)")
                {
                    escnc.fnProjectcode = string.Empty;
                    escnc.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                    sEscNC = "0";
                    this.Close();
                }
                else if (sProjectStatusform.ToString() == "1" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Contract Testing Service (CTS)" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Product Service (PRS)")
                {
                    PSU.fnProjectcode = string.Empty;
                    PSU.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                    sProjectStatusform = "0";
                    this.Close();
                }
                else if (sProjectStatusInstallform.ToString() == "1" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Contract Testing Service (CTS)" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Product Service (PRS)")
                {
                    PSI.fnProjectcode = string.Empty;
                    PSI.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                    sProjectStatusInstallform = "0";
                    this.Close();
                }

                else if (sMUform.ToString() == "1")
                {
                    frmMachineUtilization.fnProjectcode = string.Empty;
                    frmMachineUtilization.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                    sMUform = "0";
                    this.Close();
                }
                else if (sValidationform.ToString() == "1" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Contract Testing Service (CTS)" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Product Service (PRS)")
                {
                    fTimeSheet.fnProjectcode = string.Empty;
                    fTimeSheet.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                    sValidationform = "0";
                    this.Close();
                }
                else if (sPTR.ToString() == "1" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Contract Testing Service (CTS)" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Product Service (PRS)")
                {
                    PTR.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                    sPTR = "0";
                    this.Close();
                }
                else if (sTransIssue.ToString() == "1" && dgProjectList.CurrentRow.Cells["Status"].Value.ToString() == "WIP" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Contract Testing Service (CTS)" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Product Service (PRS)")
                {
                    TransIssue.fnProjectcode = string.Empty;
                    TransIssue.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                    sTransIssue = "0";
                    this.Close();
                }

                else if (sElectronicIssue.ToString() == "1" && dgProjectList.CurrentRow.Cells["Status"].Value.ToString() == "WIP" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Contract Testing Service (CTS)" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Product Service (PRS)")
                {
                    ElectronicIssue.fnProjectcode = string.Empty;
                    ElectronicIssue.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                    sElectronicIssue = "0";
                    this.Close();
                }

                else if (sElectronicIssueBOM.ToString() == "1")
                {
                    ElectronicsBOM.fnProjectcode = string.Empty;
                    ElectronicsBOM.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                    sElectronicIssueBOM = "0";
                    this.Close();
                }

                else if (sElectronicReportIssue.ToString() == "1" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Contract Testing Service (CTS)" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Product Service (PRS)")
                {
                    KBReports.fnProjectcode = string.Empty;
                    KBReports.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                    sElectronicReportIssue = "0";
                    this.Close();
                }

                else if (sProjectApprove.ToString() == "1" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Contract Testing Service (CTS)" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Product Service (PRS)")
                {
                    ProjectApprove.fnProjectcode = string.Empty;
                    ProjectApprove.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                    sProjectApprove = "0";
                    this.Close();
                }
                //shreeshail is added
                else if (sMPProjectCode.ToString() == "1" && dgProjectList.CurrentRow.Cells["Status"].Value.ToString() == "WIP" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Contract Testing Service (CTS)" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Product Service (PRS)")
                {
                    MachinePassport.fnProject_Master = string.Empty;
                    MachinePassport.fnProject_Master = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                    sMPProjectCode = "0";
                    this.Close();
                }
                //shreeshail is added
                else if (scloserProjectCode.ToString() == "1" && dgProjectList.CurrentRow.Cells["Status"].Value.ToString() == "WIP" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Contract Testing Service (CTS)" && dgProjectList.CurrentRow.Cells["ProjectType"].Value.ToString() != "Product Service (PRS)")
                {
                    Project_Closer.fnProject_Master_coser = string.Empty;
                    Project_Closer.fnProject_Master_coser = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                    scloserProjectCode = "0";
                    this.Close();
                }
                //else if ElectronicIssue (sProjectShipStatusInstallform.ToString() == "1")
                //{
                //    PSSU.fnProjectcode = string.Empty;
                //    PSSU.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
                //    sProjectShipStatusInstallform = "0";
                //    this.Close();
                //}
            }
            //else
            //{
            //    //if (sIndentform.ToString() == "1" )
            //    //{
            //    //    Indent.fnProjectcode = string.Empty;
            //    //    Indent.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
            //    //    sIndentform = "0";
            //    //    this.Close();
            //    //}
            //     if (sPOform.ToString() == "1" && dgProjectList.CurrentRow.Cells["Status"].Value.ToString() == "WIP")
            //    {
            //        PurchaseOrder.fnProjectcode = string.Empty;
            //        PurchaseOrder.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
            //        sPOform = "0";
            //        this.Close();
            //    }
            //    else if (sWOform.ToString() == "1" && dgProjectList.CurrentRow.Cells["Status"].Value.ToString() == "WIP" )
            //    {
            //        WorkOrder.fnProjectcode = string.Empty;
            //        WorkOrder.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
            //        sWOform = "0";
            //        this.Close();
            //    }
            //    if (sProjectBOM.ToString() == "1" )
            //    {
            //        PBOM.fnBOMProjectcode = string.Empty;
            //        PBOM.fnBOMProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
            //        sProjectBOM = "0";
            //        this.Close();
            //    }
            //    else if (sTransferform.ToString() == "1" && dgProjectList.CurrentRow.Cells["Status"].Value.ToString() == "WIP")
            //    {
            //        TransferForm.fnProjectcode = string.Empty;
            //        TransferForm.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
            //        sTransferform = "0";
            //        this.Close();
            //    }
            //    else if (sProjectDoc.ToString() == "1" )
            //    {
            //        ProjectDocs.fnProjectcode = string.Empty;
            //        ProjectDocs.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
            //        sProjectDoc = "0";
            //        this.Close();
            //    }
            //    else if (sDesignBOMProjectCode.ToString() == "1" )
            //    {
            //        DesignBOM.fnDesignBOMProjectcode = string.Empty;
            //        DesignBOM.fnDesignBOMProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
            //        sDesignBOMProjectCode = "0";
            //        this.Close();
            //    }
            //    else if (sNC.ToString() == "1")
            //    {
            //        NC.fnProjectcode = string.Empty;
            //        NC.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
            //        sNC = "0";
            //        this.Close();
            //    }

            //    else if (sProjectStatusform.ToString() == "1")
            //    {
            //        PSU.fnProjectcode = string.Empty;
            //        PSU.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
            //        sProjectStatusform = "0";
            //        this.Close();
            //    }
            //    else if (sProjectStatusInstallform.ToString() == "1")
            //    {
            //        PSI.fnProjectcode = string.Empty;
            //        PSI.fnProjectcode = dgProjectList.CurrentRow.Cells["ProjectCode"].Value.ToString();
            //        sProjectStatusInstallform = "0";
            //        this.Close();
            //    }
            //}
        }
        #endregion
        //shreeshail is add bellow code

        // This part will handle the case when the project status is 'Capitalized FA' and another project is selected
        private void RefreshOrClearProjectList()
        {
            if (dgProjectList.CurrentRow != null &&
                dgProjectList.CurrentRow.Cells["Status"].Value.ToString() == "Capitalized FA")
            {
                // Logic to refresh or clear the project list
                // For example:
                // dgProjectList.DataSource = null; // Clear the data source
                dgProjectList.Refresh(); // Refresh the display
                
            }
        }
        //shreeshail is add above code
        private void btnAllProjects_Click(object sender, EventArgs e)
        {
            if (btnAllProjects.Text == "Load All Projects")
            {
                dtProjectList = DAL.fnViewProjectList(1, null).Tables[0];
                btnAllProjects.Text = "Load WIP Projects";
            }
            else if (btnAllProjects.Text == "Load WIP Projects")
            {
                dtProjectList = DAL.fnViewProjectList(0, null).Tables[0];
                btnAllProjects.Text = "Load All Projects";
            }
            bsProjectList.DataSource = dtProjectList;
            dgProjectList.AutoGenerateColumns = false;
            dgProjectList.DataSource = bsProjectList;
            Datagridviewcolor();
        }

        private void txtprojectname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar == '%' || e.KeyChar == '['))
            {
                e.Handled = true;
            }
        }

        private void dgProjectList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
