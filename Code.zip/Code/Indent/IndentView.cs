﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Diagnostics;
namespace Erp_Project_With_Buttons.Indent
{
    public partial class IndentView : Form
    {
        #region Intialization of Local Datatables, Variables Daclaration
        DataTable dtIndentlist = new DataTable();
        DataAccessLayer DAL = new DataAccessLayer();
        DataView dvPOViewList = new DataView();
        BindingSource bsItemList = new BindingSource();
        DataTable dtIndentItems = new DataTable();
        DataTable dtProjectList = new DataTable();
        public IndentView()
        {
            InitializeComponent();
        }

        private void IndentView_Load(object sender, EventArgs e)
        {


        }
        #endregion
        #region Filter the Item list depends upon the user inpts

        private void fnRowFilter(uint uSearchOption, string sRowFilter)
        {
            DataView dvPOViewList = new DataView(dtIndentlist);
            switch (uSearchOption)
            {
                case Global.uITEM_CODE_SEARCH:
                    {
                        dvPOViewList.RowFilter = "ItemCode like '" + sRowFilter + "%'";
                        dgpolist.DataSource = dvPOViewList.ToTable();
                        break;
                    }
                case Global.uITEM_DESCRIPTION_SEARCH:
                    {
                        dvPOViewList.RowFilter = "ProjectCode like '" + sRowFilter + "%'";
                        dgpolist.DataSource = dvPOViewList.ToTable();
                        break;
                    }
                case Global.uITEM_TYPE_SEARCH:
                    {
                        dvPOViewList.RowFilter = "IndentNo like '" + sRowFilter + "%'";
                        dgpolist.DataSource = dvPOViewList.ToTable();
                        break;
                    }
                case Global.uITEM_STATUS_SEARCH:
                    {
                        dvPOViewList.RowFilter = "IndentBy like '" + sRowFilter + "%'";
                        dgpolist.DataSource = dvPOViewList.ToTable();
                        break;
                    }

            }
        }



        private void txtItemCode_Enter(object sender, EventArgs e)
        {
            txtItemCode.Text = string.Empty;
            dgpolist.DataSource = bsItemList;
        }

        private void txtProjectcode_Enter(object sender, EventArgs e)
        {
            txtProjectcode.Text = string.Empty;
            dgpolist.DataSource = bsItemList;
        }

        private void txtIndentNo_Enter(object sender, EventArgs e)
        {
            txtIndentNo.Text = string.Empty;
            dgpolist.DataSource = bsItemList;
        }

        private void txtIndentBy_Enter(object sender, EventArgs e)
        {
            txtIndentBy.Text = string.Empty;
            dgpolist.DataSource = bsItemList;
        }

        private void txtItemCode_KeyUp(object sender, KeyEventArgs e)
        {
            fnRowFilter(0, txtItemCode.Text);
        }

        private void txtProjectcode_KeyUp(object sender, KeyEventArgs e)
        {
            fnRowFilter(1, txtProjectcode.Text);
        }

        private void txtIndentNo_KeyUp(object sender, KeyEventArgs e)
        {
            fnRowFilter(2, txtIndentNo.Text);
        }

        private void txtIndentBy_KeyUp(object sender, KeyEventArgs e)
        {
            fnRowFilter(3, txtIndentBy.Text);
        }
        #endregion
        #region Please wait form
        private void IndentView_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            pleasewaitform pleaseWait = new pleasewaitform();
            // Display form modelessly
            pleaseWait.Show();
            //  ALlow main UI thread to properly display please wait form.
            Application.DoEvents();
            frmIndent indentform = new frmIndent();
            indentform.Show();
            pleaseWait.Hide();
        }
        #endregion

        #region Load recent Indent list
        private void btnrecentlist_Click(object sender, EventArgs e)
        {
            dtpFromDate.Format = DateTimePickerFormat.Custom;
            dtpFromDate.CustomFormat = "yyyy-MM-dd";
            dtpToDate.Format = DateTimePickerFormat.Custom;
            dtpToDate.CustomFormat = "yyyy-MM-dd";
            if (cbProjectSearch.CheckState == CheckState.Unchecked)
            {
                dtIndentlist = DAL.fnIndentViewList(dtpFromDate.Text, dtpToDate.Text, null).Tables[0];
            }
            else if (cbProjectSearch.CheckState == CheckState.Checked)
            {
                dtIndentlist = DAL.fnIndentViewList(dtpFromDate.Text, dtpToDate.Text, cmbProjectCode.Text).Tables[0];
            }
            dtpFromDate.Format = DateTimePickerFormat.Custom;
            dtpFromDate.CustomFormat = "dd-MM-yyyy";
            dtpToDate.Format = DateTimePickerFormat.Custom;
            dtpToDate.CustomFormat = "dd-MM-yyyy";

            bsItemList.DataSource = dtIndentlist;
            dgpolist.AutoGenerateColumns = false;
            dgpolist.DataSource = dtIndentlist;
        }
        #endregion
        #region Excel Indent List
        private void dgpolist_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgpolist.CurrentCell.OwningColumn.Name == "Print")
            {
                int iRowIndex = 1;
                string ExcelFolderPath;
                string FileFullPath;
                EXCEL.Workbook NewWorkBook;
                EXCEL.Worksheet NewWorkSheet;
                EXCEL.Application ExcelApp;
                EXCEL.Range CELLS, cell1, cell2;
                object misValue;
                dtIndentItems = DAL.fnIndentExcel(dgpolist.CurrentRow.Cells["IndentNo"].Value.ToString(), null).Tables[0];
                if (dtIndentItems.Rows.Count > 0)
                {
                    ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\";
                    FileFullPath = dgpolist.CurrentRow.Cells["IndentNo"].Value.ToString() + "--" + DateTime.Now.ToString("dd/MM/yyyy") + ".xls";
                    if (!Directory.Exists(ExcelFolderPath))
                        Directory.CreateDirectory(ExcelFolderPath);
                    ExcelApp = new EXCEL.Application();
                    misValue = System.Reflection.Missing.Value;
                    try
                    {
                        if (ExcelApp == null)
                            MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                        NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                        NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                        if (NewWorkSheet == null)
                            MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                        else
                            NewWorkSheet.Name = "" + dgpolist.CurrentRow.Cells["IndentNo"].Value.ToString() + "";
                        // Select the Excel cells, in the range c1 to c7 in the worksheet for cell access check.
                        EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                        if (RANGE == null)
                            MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                        NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlWorkbookNormal, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        CELLS = NewWorkSheet.Cells;

                        // dtIndentItems = DAL.fnIndentExcel(cmbIndentNo.Text, null).Tables[0];

                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);

                        NewWorkSheet.Cells[iRowIndex, 1] = "Indent";
                        iRowIndex++;
                        NewWorkSheet.Cells[iRowIndex, 1] = "Indent No:";
                        NewWorkSheet.Cells[iRowIndex, 2] = dgpolist.CurrentRow.Cells["IndentNo"].Value.ToString();
                        iRowIndex++;
                        NewWorkSheet.Cells[iRowIndex, 1] = "Project Code:";
                        NewWorkSheet.Cells[iRowIndex, 2] = dgpolist.CurrentRow.Cells["ProjectCode"].Value.ToString();
                        iRowIndex++;
                        NewWorkSheet.Cells[iRowIndex, 1] = "Project Name:";
                        NewWorkSheet.Cells[iRowIndex, 2] = dgpolist.CurrentRow.Cells["ProjectDescription"].Value.ToString();
                        iRowIndex++;
                        NewWorkSheet.Cells[iRowIndex, 1] = "Remarks:";
                        NewWorkSheet.Cells[iRowIndex, 2] = dgpolist.CurrentRow.Cells["Remarks"].Value.ToString();
                        iRowIndex++;

                        NewWorkSheet.Cells[iRowIndex, 1] = "Indent By: " + dgpolist.CurrentRow.Cells["IndentBy"].Value.ToString();

                        NewWorkSheet.Cells[iRowIndex, 2] = "Indent Date: " + dgpolist.CurrentRow.Cells["IndentDate"].Value.ToString();
                        iRowIndex++;

                        iRowIndex++;
                        ((Microsoft.Office.Interop.Excel.Range)NewWorkSheet.Rows[8, Type.Missing]).Font.Size = 14;
                        ((Microsoft.Office.Interop.Excel.Range)NewWorkSheet.Rows[8, Type.Missing]).Font.Bold = true;
                        iRowIndex++;



                        if (dtIndentItems.Rows.Count > 0)
                        {
                            object[,] rawData = new object[dtIndentItems.Rows.Count + 1, dtIndentItems.Columns.Count];
                            for (int col = 0; col < dtIndentItems.Columns.Count; col++)
                            {
                                rawData[0, col] = dtIndentItems.Columns[col].ColumnName;
                            }
                            for (int row = 0; row < dtIndentItems.Rows.Count; row++)
                            {
                                for (int col = 0; col < dtIndentItems.Columns.Count; col++)
                                {
                                    rawData[row + 1, col] = dtIndentItems.Rows[row].ItemArray[col];
                                }
                            }
                            string excelRange = string.Empty;
                            string finalColLetter = string.Empty;
                            string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                            int colCharsetLen = colCharset.Length;

                            if (dtIndentItems.Columns.Count > colCharsetLen)
                            {
                                finalColLetter = colCharset.Substring(
                                    (dtIndentItems.Columns.Count - 1) / colCharsetLen - 1, 1);
                            }

                            finalColLetter += colCharset.Substring(
                                    (dtIndentItems.Columns.Count - 1) % colCharsetLen, 1);
                            excelRange = string.Format("A8:{0}{1}", finalColLetter, dtIndentItems.Rows.Count + iRowIndex - 1);


                            NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        }
                        cell1 = NewWorkSheet.Cells[iRowIndex - 1, 1];
                        cell2 = NewWorkSheet.Cells[(iRowIndex + dtIndentItems.Rows.Count - 1), 4];
                        CELLS = (EXCEL.Range)NewWorkSheet.get_Range(cell1, cell2);
                        CELLS.Borders.Color = System.Drawing.Color.Black;
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);

                        NewWorkSheet.Range["A1:C1"].Cells.Font.Bold = true;
                        NewWorkSheet.Range["A1:C1"].Cells.Font.Size = 16;

                        NewWorkSheet.Range["A2:D6"].Cells.Font.Size = 12;
                        NewWorkSheet.Range["A2:D6"].Cells.Font.Bold = true;


                        cell1 = NewWorkSheet.Cells[1, 1];
                        cell2 = NewWorkSheet.Cells[1, 1];
                        CELLS = (EXCEL.Range)NewWorkSheet.get_Range(cell1, cell2);
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                        CELLS.Font.Bold = true;

                        cell1 = NewWorkSheet.Cells[2, 1];
                        cell2 = NewWorkSheet.Cells[6, 1];
                        CELLS = (EXCEL.Range)NewWorkSheet.get_Range(cell1, cell2);
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                        CELLS.Font.Bold = true;


                        NewWorkSheet.get_Range("A6:B999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        NewWorkSheet.get_Range("A6", "B999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;

                        Microsoft.Office.Interop.Excel.Range Range = NewWorkSheet.get_Range("C6", "E399");
                        Range.EntireColumn.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;

                        NewWorkSheet.Rows.AutoFit();

                        NewWorkSheet.Columns.AutoFit();
                        NewWorkSheet.Rows.RowHeight = "18";

                        NewWorkSheet.Columns[1].ColumnWidth = 20;
                        NewWorkSheet.Columns[1].WrapText = true;
                        NewWorkSheet.Columns[2].ColumnWidth = 50;
                        NewWorkSheet.Columns[2].WrapText = true;
                        NewWorkSheet.Columns[3].ColumnWidth = 11;
                        NewWorkSheet.Columns[3].WrapText = true;
                        NewWorkSheet.Columns[4].ColumnWidth = 8;
                        NewWorkSheet.Columns[4].WrapText = true;
                        //NewWorkSheet.Columns[5].ColumnWidth = 12;
                        //NewWorkSheet.Columns[5].WrapText = true;

                        NewWorkSheet.PageSetup.PrintArea = "A1:D" + dtIndentItems.Rows.Count + iRowIndex + 3 + "";
                        NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                        NewWorkSheet.PageSetup.PrintNotes = true;
                        NewWorkSheet.PageSetup.Zoom = 100;
                        NewWorkSheet.PageSetup.FitToPagesTall = 1;
                        NewWorkSheet.PageSetup.FitToPagesWide = 1;
                        NewWorkSheet.PageSetup.LeftMargin = 0;
                        NewWorkSheet.PageSetup.RightMargin = 0;
                        NewWorkSheet.PageSetup.TopMargin = 0.75;
                        NewWorkSheet.PageSetup.BottomMargin = 0.75;
                        NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                        NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                        string _stLOGO = ("C:\\Databasepath\\Bisslogo.jpg");
                        EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 3];

                        Image oImage = Image.FromFile(_stLOGO);
                        System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                        NewWorkSheet.Paste(oRange, _stLOGO);

                        NewWorkBook.Save();
                        ExcelApp.Visible = true;
                        System.Threading.Thread.Sleep(1000);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                        foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                        {
                            GetProcess.Kill();
                        }
                    }
                }
                else
                {
                    MessageBox.Show("No indent items to save", "Error", 0, MessageBoxIcon.Question);
                }
            }
        }
        #endregion
        #region Excel Merge Function
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlMedium, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

        }
        #endregion

        private void cbProjectSearch_CheckedChanged(object sender, EventArgs e)
        {
            if (cbProjectSearch.CheckState == CheckState.Checked)
            {
                lblProjectCode.Visible = true;
                cmbProjectCode.Visible = true;
                if (dtProjectList.Rows.Count == 0)
                {
                    dtProjectList = DAL.fnAllProjectList(null).Tables[0];
                    if (dtProjectList.Rows.Count > 0)
                    {
                        foreach (DataRow DR in dtProjectList.Rows)
                        {
                            if (!cmbProjectCode.Items.Contains(DR["ProjectCode"].ToString()))
                                cmbProjectCode.Items.Add(DR["ProjectCode"].ToString());
                        }
                    }
                }
            }
            else
            {
                lblProjectCode.Visible = false;
                cmbProjectCode.Visible = false;
            }
        }

        private void btnExcel_Click(object sender, EventArgs e)
        {
            int iRowIndex = 1;
            string ExcelFolderPath;
            string FileFullPath;
            EXCEL.Workbook NewWorkBook;
            EXCEL.Worksheet NewWorkSheet;
            EXCEL.Application ExcelApp;
            EXCEL.Range CELLS, cell1, cell2;
            object misValue;
            if (dtIndentlist.Rows.Count > 0)
            {
                ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\Indent List\\";
                FileFullPath = ExcelFolderPath + "Indent List" + "--" + DateTime.Now.ToString("dd/MM/yyyy hh/mm/ss") + ".xls";
                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);
                ExcelApp = new EXCEL.Application();
                misValue = System.Reflection.Missing.Value;
                try
                {
                    if (ExcelApp == null)
                        MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                    NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                    NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                    if (NewWorkSheet == null)
                        MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                    else
                        NewWorkSheet.Name = "Indent List";
                    // Select the Excel cells, in the range c1 to c7 in the worksheet for cell access check.
                    EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                    if (RANGE == null)
                        MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                    NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlWorkbookNormal, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                    CELLS = NewWorkSheet.Cells;

                    // dtIndentItems = DAL.fnIndentExcel(cmbIndentNo.Text, null).Tables[0];

                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);

                    NewWorkSheet.Cells[iRowIndex, 1] = "Indent List";
                    iRowIndex++;
                    iRowIndex++;
                    iRowIndex++;



                    if (dtIndentlist.Rows.Count > 0)
                    {
                        object[,] rawData = new object[dtIndentlist.Rows.Count + 1, dtIndentlist.Columns.Count];
                        for (int col = 0; col < dtIndentlist.Columns.Count; col++)
                        {
                            rawData[0, col] = dtIndentlist.Columns[col].ColumnName;
                        }
                        for (int row = 0; row < dtIndentlist.Rows.Count; row++)
                        {
                            for (int col = 0; col < dtIndentlist.Columns.Count; col++)
                            {
                                rawData[row + 1, col] = dtIndentlist.Rows[row].ItemArray[col];
                            }
                        }
                        string excelRange = string.Empty;
                        string finalColLetter = string.Empty;
                        string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        int colCharsetLen = colCharset.Length;

                        if (dtIndentlist.Columns.Count > colCharsetLen)
                        {
                            finalColLetter = colCharset.Substring(
                                (dtIndentlist.Columns.Count - 1) / colCharsetLen - 1, 1);
                        }

                        finalColLetter += colCharset.Substring((dtIndentlist.Columns.Count - 1) % colCharsetLen, 1);
                        excelRange = string.Format("A6:{0}{1}", finalColLetter, dtIndentlist.Rows.Count + 6);


                        NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                    }


                    NewWorkSheet.Range["A1:S6"].Cells.Font.Bold = true;
                    NewWorkSheet.Range["A1:S6"].Cells.Font.Size = 16;



                    //NewWorkSheet.get_Range("A6:B999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    // NewWorkSheet.get_Range("A6", "B999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;

                    //  Microsoft.Office.Interop.Excel.Range Range = NewWorkSheet.get_Range("C6", "E399");
                    //  Range.EntireColumn.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;

                    NewWorkSheet.Rows.AutoFit();

                    NewWorkSheet.Columns.AutoFit();
                    NewWorkSheet.Rows.RowHeight = "18";


                    NewWorkSheet.PageSetup.PrintArea = "A1:J" + dtIndentlist.Rows.Count + iRowIndex + 6 + "";
                    NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                    NewWorkSheet.PageSetup.PrintNotes = true;
                    NewWorkSheet.PageSetup.Zoom = 100;
                    NewWorkSheet.PageSetup.FitToPagesTall = 1;
                    NewWorkSheet.PageSetup.FitToPagesWide = 1;
                    NewWorkSheet.PageSetup.LeftMargin = 0;
                    NewWorkSheet.PageSetup.RightMargin = 0;
                    NewWorkSheet.PageSetup.TopMargin = 0.75;
                    NewWorkSheet.PageSetup.BottomMargin = 0.75;
                    NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                    NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                    string _stLOGO = ("C:\\Databasepath\\Bisslogo.jpg");
                    EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 7];

                    Image oImage = Image.FromFile(_stLOGO);
                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    NewWorkSheet.Paste(oRange, _stLOGO);

                    NewWorkBook.Save();
                    ExcelApp.Visible = true;
                    System.Threading.Thread.Sleep(1000);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                    {
                        GetProcess.Kill();
                    }
                }
            }
            else
                MessageBox.Show("No items to save", "Error", 0, MessageBoxIcon.Question);
        }

    }
}
