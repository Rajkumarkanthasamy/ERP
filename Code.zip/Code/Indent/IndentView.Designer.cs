﻿namespace Erp_Project_With_Buttons.Indent
{
    partial class IndentView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(IndentView));
            this.label1 = new System.Windows.Forms.Label();
            this.txtIndentNo = new System.Windows.Forms.TextBox();
            this.lblIteType = new System.Windows.Forms.Label();
            this.txtProjectcode = new System.Windows.Forms.TextBox();
            this.lblItemDescription = new System.Windows.Forms.Label();
            this.txtItemCode = new System.Windows.Forms.TextBox();
            this.lblItemCode = new System.Windows.Forms.Label();
            this.gbSearchOptions = new System.Windows.Forms.GroupBox();
            this.btnExcel = new System.Windows.Forms.Button();
            this.cbProjectSearch = new System.Windows.Forms.CheckBox();
            this.lblProjectCode = new System.Windows.Forms.Label();
            this.cmbProjectCode = new System.Windows.Forms.ComboBox();
            this.lblFromdate = new System.Windows.Forms.Label();
            this.lblToDate = new System.Windows.Forms.Label();
            this.dtpFromDate = new System.Windows.Forms.DateTimePicker();
            this.dtpToDate = new System.Windows.Forms.DateTimePicker();
            this.btnrecentlist = new System.Windows.Forms.Button();
            this.txtIndentBy = new System.Windows.Forms.TextBox();
            this.dgpolist = new System.Windows.Forms.DataGridView();
            this.Print = new System.Windows.Forms.DataGridViewButtonColumn();
            this.IndentNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IndentQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IndentRemainingQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IndentBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IndentDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Remarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbSearchOptions.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgpolist)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(363, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 23);
            this.label1.TabIndex = 5;
            this.label1.Text = "Indent By:";
            // 
            // txtIndentNo
            // 
            this.txtIndentNo.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIndentNo.Location = new System.Drawing.Point(100, 69);
            this.txtIndentNo.Name = "txtIndentNo";
            this.txtIndentNo.Size = new System.Drawing.Size(211, 26);
            this.txtIndentNo.TabIndex = 4;
            this.txtIndentNo.Enter += new System.EventHandler(this.txtIndentNo_Enter);
            this.txtIndentNo.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtIndentNo_KeyUp);
            // 
            // lblIteType
            // 
            this.lblIteType.AutoSize = true;
            this.lblIteType.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIteType.Location = new System.Drawing.Point(6, 72);
            this.lblIteType.Name = "lblIteType";
            this.lblIteType.Size = new System.Drawing.Size(94, 23);
            this.lblIteType.TabIndex = 1;
            this.lblIteType.Text = "Indent No:";
            // 
            // txtProjectcode
            // 
            this.txtProjectcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProjectcode.Location = new System.Drawing.Point(456, 28);
            this.txtProjectcode.Name = "txtProjectcode";
            this.txtProjectcode.Size = new System.Drawing.Size(324, 26);
            this.txtProjectcode.TabIndex = 3;
            this.txtProjectcode.Enter += new System.EventHandler(this.txtProjectcode_Enter);
            this.txtProjectcode.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtProjectcode_KeyUp);
            // 
            // lblItemDescription
            // 
            this.lblItemDescription.AutoSize = true;
            this.lblItemDescription.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemDescription.Location = new System.Drawing.Point(338, 29);
            this.lblItemDescription.Name = "lblItemDescription";
            this.lblItemDescription.Size = new System.Drawing.Size(116, 23);
            this.lblItemDescription.TabIndex = 2;
            this.lblItemDescription.Text = "Project Code:";
            // 
            // txtItemCode
            // 
            this.txtItemCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemCode.Location = new System.Drawing.Point(100, 30);
            this.txtItemCode.Name = "txtItemCode";
            this.txtItemCode.Size = new System.Drawing.Size(211, 26);
            this.txtItemCode.TabIndex = 1;
            this.txtItemCode.Enter += new System.EventHandler(this.txtItemCode_Enter);
            this.txtItemCode.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemCode_KeyUp);
            // 
            // lblItemCode
            // 
            this.lblItemCode.AutoSize = true;
            this.lblItemCode.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemCode.Location = new System.Drawing.Point(4, 30);
            this.lblItemCode.Name = "lblItemCode";
            this.lblItemCode.Size = new System.Drawing.Size(96, 23);
            this.lblItemCode.TabIndex = 0;
            this.lblItemCode.Text = "Item Code:";
            // 
            // gbSearchOptions
            // 
            this.gbSearchOptions.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.gbSearchOptions.Controls.Add(this.btnExcel);
            this.gbSearchOptions.Controls.Add(this.cbProjectSearch);
            this.gbSearchOptions.Controls.Add(this.lblProjectCode);
            this.gbSearchOptions.Controls.Add(this.cmbProjectCode);
            this.gbSearchOptions.Controls.Add(this.lblFromdate);
            this.gbSearchOptions.Controls.Add(this.lblToDate);
            this.gbSearchOptions.Controls.Add(this.dtpFromDate);
            this.gbSearchOptions.Controls.Add(this.dtpToDate);
            this.gbSearchOptions.Controls.Add(this.btnrecentlist);
            this.gbSearchOptions.Controls.Add(this.txtIndentBy);
            this.gbSearchOptions.Controls.Add(this.label1);
            this.gbSearchOptions.Controls.Add(this.txtIndentNo);
            this.gbSearchOptions.Controls.Add(this.lblIteType);
            this.gbSearchOptions.Controls.Add(this.txtProjectcode);
            this.gbSearchOptions.Controls.Add(this.lblItemDescription);
            this.gbSearchOptions.Controls.Add(this.txtItemCode);
            this.gbSearchOptions.Controls.Add(this.lblItemCode);
            this.gbSearchOptions.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.gbSearchOptions.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbSearchOptions.Location = new System.Drawing.Point(4, 4);
            this.gbSearchOptions.Name = "gbSearchOptions";
            this.gbSearchOptions.Size = new System.Drawing.Size(1295, 110);
            this.gbSearchOptions.TabIndex = 9;
            this.gbSearchOptions.TabStop = false;
            // 
            // btnExcel
            // 
            this.btnExcel.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcel.ForeColor = System.Drawing.Color.Indigo;
            this.btnExcel.Location = new System.Drawing.Point(1165, 70);
            this.btnExcel.Name = "btnExcel";
            this.btnExcel.Size = new System.Drawing.Size(123, 31);
            this.btnExcel.TabIndex = 168;
            this.btnExcel.Text = "Excel";
            this.btnExcel.UseVisualStyleBackColor = true;
            this.btnExcel.Click += new System.EventHandler(this.btnExcel_Click);
            // 
            // cbProjectSearch
            // 
            this.cbProjectSearch.AutoSize = true;
            this.cbProjectSearch.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbProjectSearch.ForeColor = System.Drawing.Color.Blue;
            this.cbProjectSearch.Location = new System.Drawing.Point(924, 50);
            this.cbProjectSearch.Name = "cbProjectSearch";
            this.cbProjectSearch.Size = new System.Drawing.Size(161, 23);
            this.cbProjectSearch.TabIndex = 167;
            this.cbProjectSearch.Text = "Search only Project";
            this.cbProjectSearch.UseVisualStyleBackColor = true;
            this.cbProjectSearch.CheckedChanged += new System.EventHandler(this.cbProjectSearch_CheckedChanged);
            // 
            // lblProjectCode
            // 
            this.lblProjectCode.AutoSize = true;
            this.lblProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectCode.ForeColor = System.Drawing.Color.Black;
            this.lblProjectCode.Location = new System.Drawing.Point(828, 78);
            this.lblProjectCode.Name = "lblProjectCode";
            this.lblProjectCode.Size = new System.Drawing.Size(94, 18);
            this.lblProjectCode.TabIndex = 61;
            this.lblProjectCode.Text = "Project Code :";
            this.lblProjectCode.Visible = false;
            // 
            // cmbProjectCode
            // 
            this.cmbProjectCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProjectCode.DropDownHeight = 130;
            this.cmbProjectCode.DropDownWidth = 239;
            this.cmbProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProjectCode.FormattingEnabled = true;
            this.cmbProjectCode.IntegralHeight = false;
            this.cmbProjectCode.Location = new System.Drawing.Point(924, 73);
            this.cmbProjectCode.Name = "cmbProjectCode";
            this.cmbProjectCode.Size = new System.Drawing.Size(229, 26);
            this.cmbProjectCode.TabIndex = 62;
            this.cmbProjectCode.Visible = false;
            // 
            // lblFromdate
            // 
            this.lblFromdate.AutoSize = true;
            this.lblFromdate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblFromdate.Location = new System.Drawing.Point(872, 19);
            this.lblFromdate.Name = "lblFromdate";
            this.lblFromdate.Size = new System.Drawing.Size(52, 19);
            this.lblFromdate.TabIndex = 22;
            this.lblFromdate.Text = "From :";
            // 
            // lblToDate
            // 
            this.lblToDate.AutoSize = true;
            this.lblToDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblToDate.Location = new System.Drawing.Point(1020, 18);
            this.lblToDate.Name = "lblToDate";
            this.lblToDate.Size = new System.Drawing.Size(33, 19);
            this.lblToDate.TabIndex = 23;
            this.lblToDate.Text = "To :";
            this.lblToDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dtpFromDate
            // 
            this.dtpFromDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.dtpFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFromDate.Location = new System.Drawing.Point(924, 17);
            this.dtpFromDate.Name = "dtpFromDate";
            this.dtpFromDate.Size = new System.Drawing.Size(94, 27);
            this.dtpFromDate.TabIndex = 24;
            // 
            // dtpToDate
            // 
            this.dtpToDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.dtpToDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpToDate.Location = new System.Drawing.Point(1059, 16);
            this.dtpToDate.Name = "dtpToDate";
            this.dtpToDate.Size = new System.Drawing.Size(94, 27);
            this.dtpToDate.TabIndex = 25;
            // 
            // btnrecentlist
            // 
            this.btnrecentlist.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrecentlist.ForeColor = System.Drawing.Color.Indigo;
            this.btnrecentlist.Location = new System.Drawing.Point(1165, 15);
            this.btnrecentlist.Name = "btnrecentlist";
            this.btnrecentlist.Size = new System.Drawing.Size(123, 31);
            this.btnrecentlist.TabIndex = 12;
            this.btnrecentlist.Text = "Load Indents";
            this.btnrecentlist.UseVisualStyleBackColor = true;
            this.btnrecentlist.Click += new System.EventHandler(this.btnrecentlist_Click);
            // 
            // txtIndentBy
            // 
            this.txtIndentBy.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIndentBy.Location = new System.Drawing.Point(456, 73);
            this.txtIndentBy.Name = "txtIndentBy";
            this.txtIndentBy.Size = new System.Drawing.Size(146, 26);
            this.txtIndentBy.TabIndex = 6;
            this.txtIndentBy.Enter += new System.EventHandler(this.txtIndentBy_Enter);
            this.txtIndentBy.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtIndentBy_KeyUp);
            // 
            // dgpolist
            // 
            this.dgpolist.AllowUserToAddRows = false;
            this.dgpolist.AllowUserToDeleteRows = false;
            this.dgpolist.AllowUserToResizeRows = false;
            this.dgpolist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgpolist.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgpolist.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgpolist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgpolist.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Print,
            this.IndentNo,
            this.ProjectCode,
            this.ProjectDescription,
            this.ItemCode,
            this.ItemDescription,
            this.IndentQty,
            this.IndentRemainingQty,
            this.IndentBy,
            this.IndentDate,
            this.Remarks});
            this.dgpolist.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgpolist.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgpolist.EnableHeadersVisualStyles = false;
            this.dgpolist.Location = new System.Drawing.Point(4, 120);
            this.dgpolist.MultiSelect = false;
            this.dgpolist.Name = "dgpolist";
            this.dgpolist.ReadOnly = true;
            this.dgpolist.RowHeadersVisible = false;
            this.dgpolist.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgpolist.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgpolist.Size = new System.Drawing.Size(1295, 558);
            this.dgpolist.TabIndex = 10;
            this.dgpolist.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgpolist_CellClick);
            // 
            // Print
            // 
            this.Print.HeaderText = "Print";
            this.Print.Name = "Print";
            this.Print.ReadOnly = true;
            this.Print.Width = 50;
            // 
            // IndentNo
            // 
            this.IndentNo.DataPropertyName = "IndentNo";
            this.IndentNo.HeaderText = "Indent No";
            this.IndentNo.Name = "IndentNo";
            this.IndentNo.ReadOnly = true;
            this.IndentNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IndentNo.Width = 87;
            // 
            // ProjectCode
            // 
            this.ProjectCode.DataPropertyName = "ProjectCode";
            this.ProjectCode.HeaderText = "Project Code";
            this.ProjectCode.Name = "ProjectCode";
            this.ProjectCode.ReadOnly = true;
            this.ProjectCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectCode.Width = 106;
            // 
            // ProjectDescription
            // 
            this.ProjectDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ProjectDescription.DataPropertyName = "ProjectDescription";
            this.ProjectDescription.HeaderText = "Project Name";
            this.ProjectDescription.Name = "ProjectDescription";
            this.ProjectDescription.ReadOnly = true;
            this.ProjectDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ItemCode
            // 
            this.ItemCode.DataPropertyName = "ItemCode";
            this.ItemCode.HeaderText = "Item Code";
            this.ItemCode.Name = "ItemCode";
            this.ItemCode.ReadOnly = true;
            this.ItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemCode.Width = 90;
            // 
            // ItemDescription
            // 
            this.ItemDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ItemDescription.DataPropertyName = "ItemDescription";
            this.ItemDescription.HeaderText = "Item Desc";
            this.ItemDescription.Name = "ItemDescription";
            this.ItemDescription.ReadOnly = true;
            this.ItemDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // IndentQty
            // 
            this.IndentQty.DataPropertyName = "IndentQty";
            this.IndentQty.HeaderText = "Indent Qty";
            this.IndentQty.Name = "IndentQty";
            this.IndentQty.ReadOnly = true;
            this.IndentQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IndentQty.Width = 93;
            // 
            // IndentRemainingQty
            // 
            this.IndentRemainingQty.DataPropertyName = "IndentRemainingQty";
            this.IndentRemainingQty.HeaderText = "Rem Qty";
            this.IndentRemainingQty.Name = "IndentRemainingQty";
            this.IndentRemainingQty.ReadOnly = true;
            this.IndentRemainingQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IndentRemainingQty.Width = 79;
            // 
            // IndentBy
            // 
            this.IndentBy.DataPropertyName = "IndentBy";
            this.IndentBy.HeaderText = "Indent By";
            this.IndentBy.Name = "IndentBy";
            this.IndentBy.ReadOnly = true;
            this.IndentBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IndentBy.Width = 85;
            // 
            // IndentDate
            // 
            this.IndentDate.DataPropertyName = "IndentDate";
            this.IndentDate.HeaderText = "Indent Date";
            this.IndentDate.Name = "IndentDate";
            this.IndentDate.ReadOnly = true;
            this.IndentDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IndentDate.Width = 101;
            // 
            // Remarks
            // 
            this.Remarks.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Remarks.DataPropertyName = "Remarks";
            this.Remarks.HeaderText = "Remarks";
            this.Remarks.Name = "Remarks";
            this.Remarks.ReadOnly = true;
            this.Remarks.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // IndentView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1304, 682);
            this.Controls.Add(this.gbSearchOptions);
            this.Controls.Add(this.dgpolist);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "IndentView";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Indent View";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.IndentView_FormClosing);
            this.Load += new System.EventHandler(this.IndentView_Load);
            this.gbSearchOptions.ResumeLayout(false);
            this.gbSearchOptions.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgpolist)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtIndentNo;
        private System.Windows.Forms.Label lblIteType;
        private System.Windows.Forms.TextBox txtProjectcode;
        private System.Windows.Forms.Label lblItemDescription;
        private System.Windows.Forms.TextBox txtItemCode;
        private System.Windows.Forms.Label lblItemCode;
        private System.Windows.Forms.GroupBox gbSearchOptions;
        private System.Windows.Forms.TextBox txtIndentBy;
        private System.Windows.Forms.DataGridView dgpolist;
        private System.Windows.Forms.Button btnrecentlist;
        private System.Windows.Forms.DataGridViewButtonColumn Print;
        private System.Windows.Forms.DataGridViewTextBoxColumn IndentNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn IndentQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn IndentRemainingQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn IndentBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn IndentDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Remarks;
        private System.Windows.Forms.Label lblFromdate;
        private System.Windows.Forms.Label lblToDate;
        private System.Windows.Forms.DateTimePicker dtpFromDate;
        private System.Windows.Forms.DateTimePicker dtpToDate;
        private System.Windows.Forms.Label lblProjectCode;
        private System.Windows.Forms.ComboBox cmbProjectCode;
        private System.Windows.Forms.CheckBox cbProjectSearch;
        private System.Windows.Forms.Button btnExcel;
    }
}