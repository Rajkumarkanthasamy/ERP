﻿namespace Erp_Project_With_Buttons.Login
{
    partial class frmChangePasswordForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmChangePasswordForm));
            this.lblUserName = new System.Windows.Forms.Label();
            this.txtNewPassword = new System.Windows.Forms.TextBox();
            this.lblNewPassword = new System.Windows.Forms.Label();
            this.gbControlButtons = new System.Windows.Forms.GroupBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnChange = new System.Windows.Forms.Button();
            this.btnClearAll = new System.Windows.Forms.Button();
            this.lblUserNameDisplay = new System.Windows.Forms.Label();
            this.txtConfirmPassword = new System.Windows.Forms.TextBox();
            this.lblConfirmPassword = new System.Windows.Forms.Label();
            this.txtOldPassword = new System.Windows.Forms.TextBox();
            this.lblOldPassword = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.llforgotpassword = new System.Windows.Forms.LinkLabel();
            this.llbViewPassord = new System.Windows.Forms.LinkLabel();
            this.llbViewOldPassword = new System.Windows.Forms.LinkLabel();
            this.gbControlButtons.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserName.ForeColor = System.Drawing.Color.Black;
            this.lblUserName.Location = new System.Drawing.Point(104, 22);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(87, 19);
            this.lblUserName.TabIndex = 71;
            this.lblUserName.Text = "User Name:";
            // 
            // txtNewPassword
            // 
            this.txtNewPassword.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNewPassword.Location = new System.Drawing.Point(197, 96);
            this.txtNewPassword.MaxLength = 12;
            this.txtNewPassword.Name = "txtNewPassword";
            this.txtNewPassword.Size = new System.Drawing.Size(246, 26);
            this.txtNewPassword.TabIndex = 2;
            this.toolTip1.SetToolTip(this.txtNewPassword, "Enter Your New PassWord Here");
            this.txtNewPassword.Enter += new System.EventHandler(this.txtNewPassword_Enter);
            // 
            // lblNewPassword
            // 
            this.lblNewPassword.AutoSize = true;
            this.lblNewPassword.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewPassword.ForeColor = System.Drawing.Color.Black;
            this.lblNewPassword.Location = new System.Drawing.Point(78, 98);
            this.lblNewPassword.Name = "lblNewPassword";
            this.lblNewPassword.Size = new System.Drawing.Size(113, 19);
            this.lblNewPassword.TabIndex = 69;
            this.lblNewPassword.Text = "New Password:";
            // 
            // gbControlButtons
            // 
            this.gbControlButtons.Controls.Add(this.btnExit);
            this.gbControlButtons.Controls.Add(this.btnChange);
            this.gbControlButtons.Controls.Add(this.btnClearAll);
            this.gbControlButtons.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.gbControlButtons.Location = new System.Drawing.Point(161, 164);
            this.gbControlButtons.Name = "gbControlButtons";
            this.gbControlButtons.Size = new System.Drawing.Size(455, 76);
            this.gbControlButtons.TabIndex = 68;
            this.gbControlButtons.TabStop = false;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(308, 19);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(91, 33);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "Exit";
            this.toolTip1.SetToolTip(this.btnExit, "Click Here to Exit this Tab");
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnChange
            // 
            this.btnChange.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnChange.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnChange.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChange.Location = new System.Drawing.Point(176, 19);
            this.btnChange.Name = "btnChange";
            this.btnChange.Size = new System.Drawing.Size(89, 33);
            this.btnChange.TabIndex = 4;
            this.btnChange.Text = "Change";
            this.toolTip1.SetToolTip(this.btnChange, "Click Here To Change Your Password");
            this.btnChange.UseVisualStyleBackColor = false;
            this.btnChange.Click += new System.EventHandler(this.btnChange_Click);
            // 
            // btnClearAll
            // 
            this.btnClearAll.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnClearAll.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnClearAll.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearAll.Location = new System.Drawing.Point(43, 19);
            this.btnClearAll.Name = "btnClearAll";
            this.btnClearAll.Size = new System.Drawing.Size(87, 33);
            this.btnClearAll.TabIndex = 6;
            this.btnClearAll.Text = "Clear All";
            this.toolTip1.SetToolTip(this.btnClearAll, "Click Here To Clear All The Fields");
            this.btnClearAll.UseVisualStyleBackColor = false;
            this.btnClearAll.Click += new System.EventHandler(this.btnClearAll_Click);
            // 
            // lblUserNameDisplay
            // 
            this.lblUserNameDisplay.AutoSize = true;
            this.lblUserNameDisplay.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserNameDisplay.ForeColor = System.Drawing.Color.Black;
            this.lblUserNameDisplay.Location = new System.Drawing.Point(195, 22);
            this.lblUserNameDisplay.Name = "lblUserNameDisplay";
            this.lblUserNameDisplay.Size = new System.Drawing.Size(0, 19);
            this.lblUserNameDisplay.TabIndex = 72;
            // 
            // txtConfirmPassword
            // 
            this.txtConfirmPassword.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConfirmPassword.Location = new System.Drawing.Point(197, 132);
            this.txtConfirmPassword.MaxLength = 12;
            this.txtConfirmPassword.Name = "txtConfirmPassword";
            this.txtConfirmPassword.Size = new System.Drawing.Size(246, 26);
            this.txtConfirmPassword.TabIndex = 3;
            this.toolTip1.SetToolTip(this.txtConfirmPassword, "Re Confirm Your New Password");
            this.txtConfirmPassword.MouseEnter += new System.EventHandler(this.txtConfirmPassword_MouseEnter);
            // 
            // lblConfirmPassword
            // 
            this.lblConfirmPassword.AutoSize = true;
            this.lblConfirmPassword.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConfirmPassword.ForeColor = System.Drawing.Color.Black;
            this.lblConfirmPassword.Location = new System.Drawing.Point(55, 134);
            this.lblConfirmPassword.Name = "lblConfirmPassword";
            this.lblConfirmPassword.Size = new System.Drawing.Size(136, 19);
            this.lblConfirmPassword.TabIndex = 73;
            this.lblConfirmPassword.Text = "Confirm Password:";
            // 
            // txtOldPassword
            // 
            this.txtOldPassword.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOldPassword.Location = new System.Drawing.Point(197, 57);
            this.txtOldPassword.MaxLength = 24;
            this.txtOldPassword.Name = "txtOldPassword";
            this.txtOldPassword.Size = new System.Drawing.Size(246, 26);
            this.txtOldPassword.TabIndex = 1;
            this.toolTip1.SetToolTip(this.txtOldPassword, "Enter Your Old PassWord Here");
            this.txtOldPassword.Enter += new System.EventHandler(this.txtOldPassword_Enter);
            // 
            // lblOldPassword
            // 
            this.lblOldPassword.AutoSize = true;
            this.lblOldPassword.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOldPassword.ForeColor = System.Drawing.Color.Black;
            this.lblOldPassword.Location = new System.Drawing.Point(113, 59);
            this.lblOldPassword.Name = "lblOldPassword";
            this.lblOldPassword.Size = new System.Drawing.Size(78, 19);
            this.lblOldPassword.TabIndex = 75;
            this.lblOldPassword.Text = "Password:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(55, 288);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 19);
            this.label1.TabIndex = 77;
            this.label1.Text = "Password Strength";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(83, 332);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(147, 19);
            this.label2.TabIndex = 78;
            this.label2.Text = "Password Length : 12";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(57, 372);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(699, 19);
            this.label3.TabIndex = 79;
            this.label3.Text = "Password Conditions : At least 1 leter in uppercase,1 leter in lower case, 1 numb" +
    "er and 1 special character";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(53, 440);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(175, 19);
            this.label4.TabIndex = 80;
            this.label4.Text = "Password Other Options";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(53, 476);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(249, 19);
            this.label5.TabIndex = 81;
            this.label5.Text = "Allow User to Change Password : Yes";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(116, 510);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(178, 19);
            this.label6.TabIndex = 82;
            this.label6.Text = "Password Expiry Days : 90";
            // 
            // llforgotpassword
            // 
            this.llforgotpassword.AutoSize = true;
            this.llforgotpassword.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llforgotpassword.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.llforgotpassword.LinkColor = System.Drawing.SystemColors.HotTrack;
            this.llforgotpassword.Location = new System.Drawing.Point(449, 102);
            this.llforgotpassword.Name = "llforgotpassword";
            this.llforgotpassword.Size = new System.Drawing.Size(102, 18);
            this.llforgotpassword.TabIndex = 83;
            this.llforgotpassword.TabStop = true;
            this.llforgotpassword.Text = "View Password";
            this.toolTip1.SetToolTip(this.llforgotpassword, "Click here to view password");
            this.llforgotpassword.MouseEnter += new System.EventHandler(this.llforgotpassword_MouseEnter);
            this.llforgotpassword.MouseLeave += new System.EventHandler(this.llforgotpassword_MouseLeave);
            // 
            // llbViewPassord
            // 
            this.llbViewPassord.AutoSize = true;
            this.llbViewPassord.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbViewPassord.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.llbViewPassord.LinkColor = System.Drawing.SystemColors.HotTrack;
            this.llbViewPassord.Location = new System.Drawing.Point(449, 140);
            this.llbViewPassord.Name = "llbViewPassord";
            this.llbViewPassord.Size = new System.Drawing.Size(102, 18);
            this.llbViewPassord.TabIndex = 84;
            this.llbViewPassord.TabStop = true;
            this.llbViewPassord.Text = "View Password";
            this.toolTip1.SetToolTip(this.llbViewPassord, "Click here to view password");
            this.llbViewPassord.MouseEnter += new System.EventHandler(this.llbViewPassord_MouseEnter);
            this.llbViewPassord.MouseLeave += new System.EventHandler(this.llbViewPassord_MouseLeave);
            // 
            // llbViewOldPassword
            // 
            this.llbViewOldPassword.AutoSize = true;
            this.llbViewOldPassword.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbViewOldPassword.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.llbViewOldPassword.LinkColor = System.Drawing.SystemColors.HotTrack;
            this.llbViewOldPassword.Location = new System.Drawing.Point(449, 65);
            this.llbViewOldPassword.Name = "llbViewOldPassword";
            this.llbViewOldPassword.Size = new System.Drawing.Size(102, 18);
            this.llbViewOldPassword.TabIndex = 85;
            this.llbViewOldPassword.TabStop = true;
            this.llbViewOldPassword.Text = "View Password";
            this.toolTip1.SetToolTip(this.llbViewOldPassword, "Click here to view password");
            this.llbViewOldPassword.MouseEnter += new System.EventHandler(this.llbViewOldPassword_MouseEnter);
            this.llbViewOldPassword.MouseLeave += new System.EventHandler(this.llbViewOldPassword_MouseLeave);
            // 
            // frmChangePasswordForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(803, 554);
            this.Controls.Add(this.llbViewOldPassword);
            this.Controls.Add(this.llbViewPassord);
            this.Controls.Add(this.llforgotpassword);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtOldPassword);
            this.Controls.Add(this.lblOldPassword);
            this.Controls.Add(this.txtConfirmPassword);
            this.Controls.Add(this.lblConfirmPassword);
            this.Controls.Add(this.lblUserNameDisplay);
            this.Controls.Add(this.lblUserName);
            this.Controls.Add(this.txtNewPassword);
            this.Controls.Add(this.lblNewPassword);
            this.Controls.Add(this.gbControlButtons);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmChangePasswordForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Change Password";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmChangePasswordForm_FormClosing);
            this.Load += new System.EventHandler(this.frmChangePasswordForm_Load);
            this.gbControlButtons.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.TextBox txtNewPassword;
        private System.Windows.Forms.Label lblNewPassword;
        private System.Windows.Forms.GroupBox gbControlButtons;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnChange;
        private System.Windows.Forms.Button btnClearAll;
        private System.Windows.Forms.Label lblUserNameDisplay;
        private System.Windows.Forms.TextBox txtConfirmPassword;
        private System.Windows.Forms.Label lblConfirmPassword;
        private System.Windows.Forms.TextBox txtOldPassword;
        private System.Windows.Forms.Label lblOldPassword;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.LinkLabel llforgotpassword;
        private System.Windows.Forms.LinkLabel llbViewPassord;
        private System.Windows.Forms.LinkLabel llbViewOldPassword;
    }
}