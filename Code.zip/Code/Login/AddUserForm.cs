﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Login
{
    public partial class frmAddUserForm : Form
    {
        #region Intialization of Local Datatables, Variables Daclaration
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        DataTable dtUserList = new DataTable();
        Login.frmLoginForm login = new Login.frmLoginForm();
        BindingSource bsUserList = new BindingSource();
        DataView dvUserList = new DataView();
        DataRow[] drrRes;

        private static string sLoginId;
        public string fnGetLoginId //Share loginId details Globally
        {
            get
            {
                return sLoginId;
            }
            set
            {
                sLoginId = value;
            }
        }

        public frmAddUserForm()
        {
            InitializeComponent();
        }
        #endregion
        #region Code to Load Add User Form 
        private void AddUserForm_Load(object sender, EventArgs e)
        {
            timer1.Interval = 1000;
            timer1.Enabled = true;
            lblReturnedby.Text = login.GetUserDetails[2];
            dgPanelList.Rows.Add("Project Master", 0); //Initialise dataGridView Rows
            dgPanelList.Rows.Add("Part Master", 0);
            dgPanelList.Rows.Add("Reciept", 0);
            dgPanelList.Rows.Add("Issue", 0);
            dgPanelList.Rows.Add("Additional Master", 0);
            dgPanelList.Rows.Add("Reports", 0);
            dgPanelList.Rows.Add("Indent", 0);
            dgPanelList.Rows.Add("Purchase Order", 0);
            dgPanelList.Rows.Add("Work Order", 0);
            dgPanelList.Rows.Add("Project BOM", 0);
            dgPanelList.Rows.Add("Product Master", 0);
            dgPanelList.Rows.Add("Customer Master", 0);
            dgPanelList.Rows.Add("Vendor Master", 0);
            dgPanelList.Rows.Add("Material Ledger", 0);

            dgPanelList.Rows.Add("BOMAuthorise", 0);
            dgPanelList.Rows.Add("Quotation", 0);
            dgPanelList.Rows.Add("Design", 0);
            dgPanelList.Rows.Add("ProductBOM", 0);
            dgPanelList.Rows.Add("PurchaseManager", 0);
            dgPanelList.Rows.Add("GeneralManager", 0);
            dgPanelList.Rows.Add("ProductionManager", 0);
            dgPanelList.Rows.Add("ManufacturingHead", 0);

            dgPanelList.Rows.Add("ProjectTransfer", 0);
            dgPanelList.Rows.Add("ProjectDocuments", 0);
            dgPanelList.Rows.Add("ProjectSSWarranty", 0);
            dgPanelList.Rows.Add("ProjectStatusUpdate", 0);
            dgPanelList.Rows.Add("ProjectIntallStatus", 0);
            dgPanelList.Rows.Add("ProjectTransferrequest", 0);
            dgPanelList.Rows.Add("SalesQuote", 0);
            dgPanelList.Rows.Add("SalesProduct", 0);
            dgPanelList.Rows.Add("CustomerVisit", 0);
            dgPanelList.Rows.Add("OpportunityDetails", 0);
            dgPanelList.Rows.Add("PegRate", 0);
            dgPanelList.Rows.Add("EnquiryRegister", 0);
            dgPanelList.Rows.Add("TestingLabQuote", 0);
            dgPanelList.Rows.Add("CreateProject", 0);
            dgPanelList.Rows.Add("ProjectDates", 0);
            dgPanelList.Rows.Add("Validation", 0);
            dgPanelList.Rows.Add("VTimeSheet", 0);
            dgPanelList.Rows.Add("POTrack", 0);
            dgPanelList.Rows.Add("KanBanMaster", 0);
            dgPanelList.Rows.Add("KanBanItems", 0);
            dgPanelList.Rows.Add("KanBanReports", 0);
            dgPanelList.Rows.Add("KanBanIssue", 0);
            dgPanelList.Rows.Add("SecurityCheck", 0);
            dgPanelList.Rows.Add("QualityManagement", 0);
            dgPanelList.Rows.Add("Copmalint", 0);
            dgPanelList.Rows.Add("KanBanElectronicsItems", 0);
            dgPanelList.Rows.Add("KanBanBOM", 0);
            dgPanelList.Rows.Add("KanBanElectronicsIssue", 0);
            dgPanelList.Rows.Add("KanBanElectronicsLedger", 0);
            dgPanelList.Rows.Add("QuoteViewItems", 0);
            dgPanelList.Rows.Add("KanBanElectronicsItemReturn", 0);
            dgPanelList.Rows.Add("KanBanElectronicsStockAdjust", 0);
            dgPanelList.Rows.Add("ProjectPermission", 0);
            dgPanelList.Rows.Add("KanBanItemReturn", 0);
            dgPanelList.Rows.Add("KanBanStockAdjust", 0);
            dgPanelList.Rows.Add("TimeSheet", 0);
            dgPanelList.Rows.Add("TimeSheetReports", 0);
            //dgPanelList.Rows.Add("MachinePassport", 0);



            txtPassword.PasswordChar = '*';
            cmbUserName.Visible = false;
            txtUserName.Visible = true;
            dtUserList.Clear();
            dtUserList = DAL.fnUserList(null).Tables[0];    //Get User details from database
            dgPanelList.AutoGenerateColumns = false;
            bsUserList.DataSource = dtUserList;
            foreach (DataRow DR in dtUserList.Rows)
            {
                if (!cmbUserName.Items.Contains(DR["UserName"].ToString())) //add items to combobox cmbUserName dynamically
                    cmbUserName.Items.Add(DR["UserName"].ToString());
                if (!cmbAthorisedPerson.Items.Contains(DR["UserName"].ToString()))  //add items to combobox cmbAthorisedPerson dynamically
                    cmbAthorisedPerson.Items.Add(DR["UserName"].ToString());
            }
            cmbAthorisedPerson.Text = Global.sCOMBOBOX_DEFAULT_TEXT;
            chkActive.Checked = true;
            dgPanelList.Columns[1].Width = 90;
            dgPanelList.Columns[1].Width = 120;
        }
        #endregion 
        #region Code to Clear Form 
        private void btnClearAll_Click(object sender, EventArgs e)
        {
            if (txtUserName.Text != string.Empty || txtPassword.Text != string.Empty || txtConfirmPassword.Text != string.Empty || cmbAthorisedPerson.Text != Global.sCOMBOBOX_DEFAULT_TEXT) //check All required field is filled or not
            {
                if (GlobalClass.fnClearallMessage() == DialogResult.Yes)    //calling clearall message function
                {
                    foreach (DataGridViewRow DGVR in dgPanelList.Rows)
                    {
                        DGVR.Cells["Allow"].Value = false;
                    }
                    btnSave.Text = Global.sBUTTON_SAVE_TEXT_ISSAVE;
                    txtPassword.PasswordChar = '*';
                    txtUserName.Enabled = true;
                    txtPassword.Enabled = true;
                    txtConfirmPassword.Enabled = true;
                    cmbAthorisedPerson.Text = Global.sCOMBOBOX_DEFAULT_TEXT;
                }
                else
                {
                    btnSave.Text = Global.sBUTTON_SAVE_TEXT_ISSAVE;
                    txtPassword.PasswordChar = '*';
                    txtUserName.Enabled = true;
                    txtPassword.Enabled = true;
                    txtConfirmPassword.Enabled = true;
                    cmbAthorisedPerson.Text = Global.sCOMBOBOX_DEFAULT_TEXT;
                }
            }
            else
                MessageBox.Show("No items to clear", "Information", 0, MessageBoxIcon.Information);
        }
        #endregion 
        #region Function to Exit Form 
        private void fnExitForm()
        {
            frmForm2 frmForm = new frmForm2();
            this.Hide();
            frmForm.Show();
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            fnExitForm();
        }
        private void AddUserForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnExitForm();
        }
        #endregion
        #region Code to Save User Details
        private void btnSave_Click(object sender, EventArgs e)
        {
            var vList = new List<bool>();
            if ((txtUserName.Text != string.Empty || cmbUserName.Text != Global.sCOMBOBOX_DEFAULT_TEXT) && cmbAthorisedPerson.Text != Global.sCOMBOBOX_DEFAULT_TEXT)
            {
                if (txtPassword.Text != string.Empty && txtConfirmPassword.Text != string.Empty && txtPassword.Text == txtConfirmPassword.Text)
                {
                    //var PASSENCRYPT= Encrypt(txtPassword.Text.Trim());
                    foreach (DataGridViewRow DGVR in dgPanelList.Rows)
                    {
                        vList.Add(Convert.ToBoolean(DGVR.Cells["Allow"].Value));
                    }
                    if (btnSave.Text == Global.sBUTTON_SAVE_TEXT_ISSAVE)
                    {
                        GlobalClass.iSuccess = DAL.fnAddUser(Global.uINSERT, null, txtUserName.Text, Cryptography.Encrypt(txtPassword.Text.ToString().Trim()), vList[0], vList[1], vList[2], vList[3], vList[4], vList[5], vList[6], vList[7], vList[8], vList[9],
                                                cmbAthorisedPerson.Text, chkActive.Checked, chkPOWOGenerate.Checked, vList[10], vList[11], vList[12], vList[13], vList[14]
                                                , vList[15], vList[16], vList[17], vList[18], vList[19], vList[20], vList[21], cmbDepartment.Text, txtEmailId.Text, txtERPVersion.Text,
                                                 vList[22], vList[23], vList[24], vList[25], vList[26], vList[27], vList[28], vList[29], vList[30], vList[31], vList[32], vList[33],
                                                 vList[34], vList[35], vList[36], vList[37], vList[38], vList[39], vList[40], vList[41], vList[42], vList[43], vList[44], vList[45],
                                                 vList[46], vList[47], vList[48], vList[49], vList[50], vList[51], vList[52], vList[53], vList[54], vList[55], vList[56], vList[57], vList[58]);
                        if (GlobalClass.iSuccess > 0)
                            MessageBox.Show("New User " + txtUserName.Text + " Added Successfully", "Success", 0, MessageBoxIcon.Information);
                        btnClearAll_Click(sender, e);
                    }
                    else
                    {
                        GlobalClass.iSuccess = DAL.fnAddUser(Global.uUPDATE, sLoginId, cmbUserName.Text, Cryptography.Encrypt(txtPassword.Text.ToString().Trim()), vList[0], vList[1], vList[2], vList[3], vList[4], vList[5], vList[6], vList[7], vList[8], vList[9],
                                                cmbAthorisedPerson.Text, chkActive.Checked, chkPOWOGenerate.Checked, vList[10], vList[11], vList[12], vList[13], vList[14]
                                                , vList[15], vList[16], vList[17], vList[18], vList[19], vList[20], vList[21], cmbDepartment.Text, txtEmailId.Text, txtERPVersion.Text,
                                                 vList[22], vList[23], vList[24], vList[25], vList[26], vList[27], vList[28], vList[29], vList[30], vList[31], vList[32], vList[33],
                                                 vList[34], vList[35], vList[36], vList[37], vList[38], vList[39], vList[40], vList[41], vList[42], vList[43], vList[44], vList[45],
                                                 vList[46], vList[47], vList[48], vList[49], vList[50], vList[51], vList[52], vList[53], vList[54], vList[55], vList[56], vList[57], vList[58]);
                        if (GlobalClass.iSuccess > 0)
                        {
                            MessageBox.Show(" User " + cmbUserName.Text + " details Updated Successfully", "Success", 0, MessageBoxIcon.Information);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Password fields are empty or Password not matched with Confirm password ", "ERP", 0, MessageBoxIcon.Exclamation);
                    txtUserName.Focus();
                }
            }
            else
            {
                MessageBox.Show("User name field is empty or Select Authorised Person ", "ERP", 0, MessageBoxIcon.Exclamation);
                txtUserName.Focus();
            }
        }
        #endregion 
        #region Code to Delete User Details
        private void btnDelete_Click(object sender, EventArgs e)
        {
            string sUserName = null;
            if (txtUserName.Visible == true)
                sUserName = txtUserName.Text.ToLower();
            if (cmbUserName.Visible == true)
                sUserName = cmbUserName.Text;
            if (sUserName != string.Empty && sUserName != Global.sCOMBOBOX_DEFAULT_TEXT)
            {
                if (sUserName != "Biss")
                {
                    DialogResult Result = MessageBox.Show("Do you want to permenently delete the User " + sUserName + " ", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
                    if (Result == DialogResult.Yes)
                    {
                        GlobalClass.iSuccess = DAL.fnAddUser(Global.uDELETE, sLoginId, null, null, false, false, false, false, false, false, false, false, false, false, null, false, false, false, false, false, false, false, false, false, false, false, false, false, false, null, null, null, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false);  //Calling add user function for deleting operation
                        if (GlobalClass.iSuccess > 0)
                        {
                            MessageBox.Show("User " + sUserName + " Deleted successfully", "Success", 0, MessageBoxIcon.Information);
                            btnClearAll_Click(sender, e);
                            cmbUserName.Items.Remove(sUserName);
                        }
                        else
                        {
                            MessageBox.Show("User " + sUserName + "was Not found", "Error", 0, MessageBoxIcon.Error);
                            btnSave.Text = Global.sBUTTON_SAVE_TEXT_ISSAVE;
                            txtUserName.Focus();
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Cannot perform Delete operation because User is DBAdmin", "BIM", 0, MessageBoxIcon.Stop);
                    cmbUserName.Focus();
                }
            }
            else
            {
                MessageBox.Show("User Name field is empty", "Error", 0, MessageBoxIcon.Error);
                txtUserName.Focus();
            }
        }
        #endregion
        #region Code to Search a User
        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtUserName.Text != string.Empty || txtPassword.Text != string.Empty || txtConfirmPassword.Text != string.Empty)
            {
                if (GlobalClass.fnClearallMessage() == DialogResult.Yes) //calling clearall message function
                {
                    cmbUserName.SelectedIndex = 0;
                    cmbUserName.Visible = true;
                    txtUserName.Visible = false;
                }
            }
            else
            {
                cmbUserName.SelectedIndex = 0;
                cmbUserName.Visible = true;
                txtUserName.Visible = false;
            }
        }
        #endregion 
        #region Code to Load Selected User Details
        private void cmbUserName_SelectedIndexChanged(object sender, EventArgs e)
        {
            int iIndex = 9;
            dtUserList = DAL.fnUserList(cmbUserName.Text).Tables[0];    //Get user details from data table
            dgPanelList.AutoGenerateColumns = false;
            bsUserList.DataSource = dtUserList;
            DataView view1 = new DataView(dtUserList);
            view1.Sort = "UserName desc";
            dtUserList = view1.ToTable();
            if (dtUserList.Rows.Count > 0)
            {
                foreach (DataRow DR in dtUserList.Rows)
                {
                    if (!cmbUserName.Items.Contains(DR["UserName"].ToString().ToLower())) //add items to combobox cmbUserName dynamically
                        cmbUserName.Items.Add(DR["UserName"].ToString().ToLower());
                    if (!cmbAthorisedPerson.Items.Contains(DR["UserName"].ToString())) //add items to combobox cmbAthorisedPerson dynamically
                        cmbAthorisedPerson.Items.Add(DR["UserName"].ToString());
                }
                if (cmbUserName.Text != Global.sCOMBOBOX_DEFAULT_TEXT)
                {
                    if (cmbUserName.Items.Contains(cmbUserName.Text) && cmbUserName.Text != string.Empty)
                    {
                        // int k = dtUserList.Columns.Count;
                        drrRes = dtUserList.Select("UserName= '" + cmbUserName.Text + "'");

                        if (drrRes[0]["LoginPassword"].ToString().Length > 12)
                        {
                            txtPassword.Text = Cryptography.Decrypt(drrRes[0]["LoginPassword"].ToString());
                            txtConfirmPassword.Text = Cryptography.Decrypt(drrRes[0]["LoginPassword"].ToString());
                        }
                        else
                        {
                            txtPassword.Text = (drrRes[0]["LoginPassword"].ToString());
                            txtConfirmPassword.Text = (drrRes[0]["LoginPassword"].ToString());
                        }
                        cmbAthorisedPerson.Text = drrRes[0]["AuthorisedPreson"].ToString();
                        txtEmailId.Text = drrRes[0]["emailid"].ToString();
                        cmbDepartment.Text = drrRes[0]["Department"].ToString();
                        chkActive.Checked = Convert.ToBoolean(drrRes[0]["Active"].ToString());
                        chkPOWOGenerate.Checked = Convert.ToBoolean(drrRes[0]["POWOGenerate"].ToString());
                        // dgPanelList.Rows[10].Cells["Allow"].Value = Convert.ToBoolean(drrRes[0]["ProductMaster"]);
                        //  dgPanelList.Rows[11].Cells["Allow"].Value = Convert.ToBoolean(drrRes[0]["CustomerMaster"]);
                        int k = dtUserList.Columns.Count;
                        sLoginId = drrRes[0]["LoginId"].ToString();
                        
                        foreach (DataGridViewRow DGVR in dgPanelList.Rows)
                        {
                            int jk = dgPanelList.Rows.Count;
                            //  if (iIndex < 69)// add rows only the accesable buttons 4 to 13 issue,indent etc
                            {
                                if (!string.IsNullOrEmpty(drrRes[0][iIndex].ToString()))
                                {
                                    DGVR.Cells["Allow"].Value = Convert.ToBoolean(drrRes[0][iIndex]);
                                }
                            }

                            //else
                            //{
                            //    break;
                            //}
                            iIndex++;
                        }
                        
                        /*
                        foreach (DataGridViewRow DGVR in dgPanelList.Rows)
                        {
                            int columnCount = dgPanelList.Columns.Count;
                            int drrResLength = drrRes[0].ItemArray.Length;

                            if (iIndex >= drrResLength || iIndex >= columnCount)
                            {
                                break;
                            }

                            if (!string.IsNullOrEmpty(drrRes[0].ItemArray[iIndex].ToString()))
                            {
                                DGVR.Cells["Allow"].Value = Convert.ToBoolean(drrRes[0].ItemArray[iIndex]);
                            }

                            iIndex++;
                        }
                        */
                        txtERPVersion.Text = login.GetUserDetails[36].ToString();
                    }
                    else
                    {
                        MessageBox.Show("UserName Not Found", "EBM", 0, MessageBoxIcon.Warning);
                        cmbUserName.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Please Select User Name", "Information", 0, MessageBoxIcon.Information);
                    cmbUserName.Focus();
                }
                txtPassword.Enabled = true;
                txtPassword.PasswordChar = '\0';
                txtConfirmPassword.Enabled = false;
                btnSave.Text = Global.sBUTTON_SAVE_TEXT_ISUPDATE;
            }
        }
        #endregion
        #region Code to GO Home Form 
        private void llHome_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            btnHome_Click(sender, e);
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            GlobalClass.sMessageResult = GlobalClass.fnMessageResult();
            if (GlobalClass.sMessageResult == Global.sCLOSE_MESSAGE_RESULT_YES)
            {
                this.Close();
            }
        }
        #endregion 
        #region Code to Quit Form 
        private void llIMExit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            GlobalClass.sMessageResult = GlobalClass.fnMessageResultquit();
            if (GlobalClass.sMessageResult == Global.sCLOSE_MESSAGE_RESULT_YES)
            {
                Application.ExitThread();
            }
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            GlobalClass.sMessageResult = GlobalClass.fnMessageResultquit();
            if (GlobalClass.sMessageResult == Global.sCLOSE_MESSAGE_RESULT_YES)
            {
                Application.ExitThread();
            }
        }
        #endregion
        #region Code to Go Other Forms
        private void treeView1_DoubleClick(object sender, EventArgs e)
        {
            //  GlobalClass.fnCloseMessage(treeView1, this);
        }
        #endregion
        #region Code to Display Time
        private void timer1_Tick(object sender, EventArgs e)
        {
            lbltime.Text = DateTime.Now.ToString("hh:mm:ss tt");
        }
        #endregion
        #region Code to Select the Authorised Person
        private void cmbAthorisedPerson_Leave(object sender, EventArgs e)
        {
            if (!cmbAthorisedPerson.Items.Contains(cmbAthorisedPerson.Text) || cmbAthorisedPerson.Text == string.Empty)
                cmbAthorisedPerson.Text = Global.sCOMBOBOX_DEFAULT_TEXT;
        }
        #endregion

        private void cmbAthorisedPerson_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pnMain_Paint(object sender, PaintEventArgs e)
        {

        }
        //public string Encrypt(string clearText)
        //{
        //    string EncryptionKey = "MAKV2SPBNI99212";
        //    byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
        //    using (Aes encryptor = Aes.Create())
        //    {
        //        Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
        //        encryptor.Key = pdb.GetBytes(32);
        //        encryptor.IV = pdb.GetBytes(16);
        //        using (MemoryStream ms = new MemoryStream())
        //        {
        //            using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
        //            {
        //                cs.Write(clearBytes, 0, clearBytes.Length);
        //                cs.Close();
        //            }
        //            clearText = Convert.ToBase64String(ms.ToArray());
        //        }
        //    }
        //    return clearText;
        //}
        //public string Decrypt(string cipherText)
        //{
        //    string EncryptionKey = "MAKV2SPBNI99212";
        //    byte[] cipherBytes = Convert.FromBase64String(cipherText);
        //    using (Aes encryptor = Aes.Create())
        //    {
        //        Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
        //        encryptor.Key = pdb.GetBytes(32);
        //        encryptor.IV = pdb.GetBytes(16);
        //        using (MemoryStream ms = new MemoryStream())
        //        {
        //            using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
        //            {
        //                cs.Write(cipherBytes, 0, cipherBytes.Length);
        //                cs.Close();
        //            }
        //            cipherText = Encoding.Unicode.GetString(ms.ToArray());
        //        }
        //    }
        //    return cipherText;
        //}
    }
}
