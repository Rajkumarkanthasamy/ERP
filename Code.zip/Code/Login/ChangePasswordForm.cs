﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Login
{
    public partial class frmChangePasswordForm : Form
    {
        #region Intialization of Local Datatables, Variables Daclaration
        Login.frmLoginForm frmLoginForm = new Login.frmLoginForm();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        public frmChangePasswordForm()
        {
            InitializeComponent();
        }
        #endregion
        #region Code to Clear Form 
        private void btnClearAll_Click(object sender, EventArgs e)
        {
            GlobalClass.fnClearAll(this);   //Calling clearall message
        }
        #endregion
        #region Code to Change the Password
        private void btnChange_Click(object sender, EventArgs e)
        {
            if (Cryptography.Encrypt(txtOldPassword.Text.ToString()) == frmLoginForm.sUserDetails[3])//comapre old passowrd with database
            {
                if (txtNewPassword.Text != string.Empty && txtConfirmPassword.Text != string.Empty)
                {
                    if (IsValidPassword(txtConfirmPassword.Text))
                    {
                        if (frmLoginForm.sUserDetails[3] == txtNewPassword.Text)
                        {
                            MessageBox.Show("New password should not same as old password", "Error", 0, MessageBoxIcon.Error);
                            txtNewPassword.Focus();
                        }
                        else
                        {
                            if (txtConfirmPassword.Text == txtNewPassword.Text)
                            {
                                //Login.frmAddUserForm formad = new frmAddUserForm();
                                //var passwordencrypt = formad.Encrypt(txtNewPassword.Text);
                                GlobalClass.iSuccess = DAL.fnChangePassword(Global.uUPDATE, frmLoginForm.sUserDetails[2], Cryptography.Encrypt(txtNewPassword.Text.ToString()));

                                if (GlobalClass.iSuccess > 0)
                                {
                                    MessageBox.Show("Password changed successfully", "Success", 0, MessageBoxIcon.Information);
                                    btnExit_Click(sender, e);
                                }
                            }
                            else
                            {
                                MessageBox.Show("New password not matched with confirm password", "Error", 0, MessageBoxIcon.Error);
                                txtNewPassword.Focus();
                            }
                        }                      
                    }
                    else
                    {
                        MessageBox.Show("Password length should be 12 characters and enter at least one leter in uppercase,lower case, one number & one special character", "Error", 0, MessageBoxIcon.Exclamation);
                        txtNewPassword.Focus();
                    }


                }
                else
                {
                    if (string.IsNullOrEmpty(txtNewPassword.Text))
                    {
                        MessageBox.Show("New password field is empty", "Error", 0, MessageBoxIcon.Exclamation);
                        txtNewPassword.Focus();
                    }
                    else if (string.IsNullOrEmpty(txtConfirmPassword.Text))
                    {
                        MessageBox.Show("Confirm password field is empty", "Error", 0, MessageBoxIcon.Exclamation);
                        txtConfirmPassword.Focus();
                    }
                }
            }
            else
            {
                MessageBox.Show("Wrong old password", "Error", 0, MessageBoxIcon.Exclamation);
                txtOldPassword.Focus();
            }
        }


        private bool IsValidPassword(string password)
        {
            return (password.Length == 12 && password.Any(char.IsUpper) ==true && password.Any(char.IsLower) 
                && (password.Any(char.IsSymbol) || password.Any(char.IsPunctuation)) && password.Any(char.IsNumber));
        }


        #endregion
        #region Code to Display User name
        private void frmChangePasswordForm_Load(object sender, EventArgs e)
        {
            lblUserNameDisplay.Text = frmLoginForm.sUserDetails[2]; //Display User Name
        }
        #endregion
        #region Code for Exit Form 
        private void frmChangePasswordForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            btnExit_Click(sender, e);
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
           // frmForm2 MainForm = new frmForm2();
            this.Hide();
            frmLoginForm.Show();
        }
        #endregion

        private void txtNewPassword_Enter(object sender, EventArgs e)
        {
            txtNewPassword.UseSystemPasswordChar = true;
        }

        private void llforgotpassword_MouseLeave(object sender, EventArgs e)
        {
            txtNewPassword.UseSystemPasswordChar = true;
        }

        private void llbViewPassord_MouseEnter(object sender, EventArgs e)
        {
            txtConfirmPassword.UseSystemPasswordChar = false;
        }

        private void llbViewPassord_MouseLeave(object sender, EventArgs e)
        {
            txtConfirmPassword.UseSystemPasswordChar = true;
        }

        private void llforgotpassword_MouseEnter(object sender, EventArgs e)
        {
            txtNewPassword.UseSystemPasswordChar = false;
        }

        private void txtConfirmPassword_MouseEnter(object sender, EventArgs e)
        {
            txtConfirmPassword.UseSystemPasswordChar = true;
        }

        private void llbViewOldPassword_MouseEnter(object sender, EventArgs e)
        {
            txtOldPassword.UseSystemPasswordChar = false;
        }

        private void llbViewOldPassword_MouseLeave(object sender, EventArgs e)
        {
            txtOldPassword.UseSystemPasswordChar = true;
        }

        private void txtOldPassword_Enter(object sender, EventArgs e)
        {
            txtOldPassword.UseSystemPasswordChar = true;
        }
    }
}
