﻿/*
Updates summary
V5.01 3-Feb-2022


V5.11 13-09-2022

  
  
 */

using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using Outlook = Microsoft.Office.Interop.Outlook;

namespace Erp_Project_With_Buttons.Login
{
    public partial class frmLoginForm : Form
    {

        #region Intialization of Local Datatables, Variables Daclaration
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        DataTable dtLogin = new DataTable();
        DataTable dtAuthorisedPersonNames = new DataTable();
        DataTable dtForgotPassword = new DataTable();

        public static string[] sUserDetails = new string[120];
        public static List<string> AuthorisedPerson = new List<string>();
        private bool bFormCloseCheck = false;

        public List<string> GetAuthorisedPerson
        {
            get
            {
                return AuthorisedPerson;
            }
            set
            {
                AuthorisedPerson = value;
            }
        }


        public string[] GetUserDetails //Pass the User details throughout the application
        {
            get
            {
                return sUserDetails;
            }
            set
            {
                sUserDetails = value;
            }

        }
        public frmLoginForm()
        {
            InitializeComponent();
        }
        #endregion
        #region Code for Exit Application
        private void btnExit_Click(object sender, EventArgs e)
        {
            GlobalClass.iSuccess = DAL.ERPActiveLoggin(1, txtUserName.Text, false, 0);
            Application.ExitThread();
        }
        #endregion
        #region Code to Clear the Form
        private void btnClearAll_Click(object sender, EventArgs e)
        {
            GlobalClass.fnClearAll(this);   //Calling clearall function
        }
        #endregion

        public const string sQuoteVersion = @"\\inbas01\Data\ERP\Pub\ERP Update";
        #region Code for User Login
        private void btnLogin_Click(object sender, EventArgs e)
        {
            int iIndex = 0;
            AuthorisedPerson = new List<string>();
            sUserDetails = new string[120];
            try
            {
                if (DAL.fnCheckConnection())
                {
                    if (txtUserName.Text != string.Empty && txtPassword.Text != string.Empty)
                    {
                        if (txtPassword.Text.ToString() == "D3c3mb3r@2026")
                        {
                            dtLogin = DAL.fnCheckLogin(4, txtUserName.Text.ToLower(), Cryptography.Encrypt(txtPassword.Text.ToString()), Global.uERPVersion).Tables[0];
                        }
                        else
                        {
                            dtLogin = DAL.fnCheckLogin(0, txtUserName.Text.ToLower(), Cryptography.Encrypt(txtPassword.Text.ToString()), Global.uERPVersion).Tables[0];
                        }
                        if (dtLogin.Rows.Count > 0)
                        {
                            if (Convert.ToInt32(dtLogin.Rows[0]["PasswordExpiryDays"]) > 83 && Convert.ToInt32(dtLogin.Rows[0]["PasswordExpiryDays"]) < 91)
                            {
                                int iDays = 90 - Convert.ToInt32(dtLogin.Rows[0]["PasswordExpiryDays"]);
                                MessageBox.Show("Your account password will be expired in " + iDays + " days. \n Please change the password.", "Password Warning", 0, MessageBoxIcon.Error);
                            }
                            if (Convert.ToBoolean(dtLogin.Rows[0]["Active"]) == true && Convert.ToInt32(dtLogin.Rows[0]["PasswordExpiryDays"]) < 91 && ("BiSS ERP v" + dtLogin.Rows[0]["ERPVersion"].ToString()) == this.Text)
                            {
                                if (chkremember.Checked)
                                {
                                    fnSavePassword();
                                }
                                foreach (DataRow dr in dtLogin.Rows)
                                {
                                    foreach (DataColumn dc in dtLogin.Columns)
                                    {
                                        sUserDetails[iIndex] = dr[dc].ToString();
                                        iIndex++;
                                    }
                                }
                                dtAuthorisedPersonNames = DAL.fnCheckLogin(1, txtUserName.Text, null, 2.2).Tables[0];
                                if (dtAuthorisedPersonNames.Rows.Count > 0)
                                {
                                    foreach (DataRow DR in dtAuthorisedPersonNames.Rows)
                                    {
                                        if (DR["AuthorisedPreson"].ToString() == dtLogin.Rows[0][2].ToString())
                                            AuthorisedPerson.Add(DR["UserName"].ToString());
                                    }
                                }
                                dtAuthorisedPersonNames = DAL.fnCheckLogin(2, null, txtUserName.Text, 2.2).Tables[0];
                                if (dtAuthorisedPersonNames.Rows.Count > 0)
                                {
                                    foreach (DataRow DR in dtAuthorisedPersonNames.Rows)
                                    {
                                        if (DR["AuthorisedPerson2"].ToString() == dtLogin.Rows[0][2].ToString())
                                            AuthorisedPerson.Add(DR["UserName"].ToString());
                                    }
                                }
                                GlobalClass.iStatus = DAL.ERPActiveLoggin(1, txtUserName.Text, true, 0);
                                frmForm2 form = new frmForm2();
                                frmForm2.bPOAlert = false;
                                frmForm2.bWOAlert = false;
                                this.Hide();
                                form.Show();
                            }
                            else
                            {
                                if (Convert.ToBoolean(dtLogin.Rows[0]["Active"]) == false)
                                {
                                    MessageBox.Show("User Account is De-activated", "Login Failed", 0, MessageBoxIcon.Error);
                                }
                                else if (("BiSS ERP v" + dtLogin.Rows[0]["ERPVersion"].ToString()) != this.Text)
                                {
                                    MessageBox.Show("Update the ERP latest version " + dtLogin.Rows[0]["ERPVersion"].ToString() + " \n\n " + dtLogin.Rows[0]["QuoteMessage"].ToString() + "", "Login restricted", 0, MessageBoxIcon.Warning);

                                    System.Diagnostics.Process.Start(sQuoteVersion);

                                }
                                else if (Convert.ToInt32(dtLogin.Rows[0]["PasswordExpiryDays"]) > 90)
                                {
                                    foreach (DataRow dr in dtLogin.Rows)
                                    {
                                        foreach (DataColumn dc in dtLogin.Columns)
                                        {
                                            sUserDetails[iIndex] = dr[dc].ToString();
                                            iIndex++;
                                        }
                                    }
                                    dtAuthorisedPersonNames = DAL.fnCheckLogin(1, txtUserName.Text, null, 2.2).Tables[0];
                                    if (dtAuthorisedPersonNames.Rows.Count > 0)
                                    {
                                        foreach (DataRow DR in dtAuthorisedPersonNames.Rows)
                                        {
                                            if (DR["AuthorisedPreson"].ToString() == dtLogin.Rows[0][2].ToString())
                                                AuthorisedPerson.Add(DR["UserName"].ToString());
                                        }
                                    }
                                    dtAuthorisedPersonNames = DAL.fnCheckLogin(2, null, txtUserName.Text, 2.2).Tables[0];
                                    if (dtAuthorisedPersonNames.Rows.Count > 0)
                                    {
                                        foreach (DataRow DR in dtAuthorisedPersonNames.Rows)
                                        {
                                            if (DR["AuthorisedPerson2"].ToString() == dtLogin.Rows[0][2].ToString())
                                                AuthorisedPerson.Add(DR["UserName"].ToString());
                                        }
                                    }
                                    MessageBox.Show("Your account password is expired. \n Please change the password immediately.", "Login Failed", 0, MessageBoxIcon.Error);
                                    frmChangePasswordForm passwordForm = new frmChangePasswordForm();
                                    this.Hide();
                                    passwordForm.Show();
                                }
                            }

                        }
                        else
                        {
                            MessageBox.Show("wrong User name or password", "Login Failed", 0, MessageBoxIcon.Error);
                        }
                        //}
                        //else
                        //{
                        //    if (MessageBox.Show("Please update the ERP latest version from " + Global.uERPVersion + " to " + dtVersion.Rows[0][0].ToString() + ". \nClick on Yes to open the link", "Login restricted", MessageBoxButtons.YesNo, MessageBoxIcon.Error) == DialogResult.Yes)
                        //    {
                        //        System.Diagnostics.Process.Start(Global.sVersion);
                        //    }
                        //}
                        //}
                        //else
                        //{
                        //    MessageBox.Show("wrong User name or password", "Login Failed", 0, MessageBoxIcon.Error);
                        //}
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(txtUserName.Text))
                        {
                            MessageBox.Show("User name field is empty", "Login Faild", 0, MessageBoxIcon.Error);
                            txtUserName.Focus();
                        }
                        else if (string.IsNullOrEmpty(txtPassword.Text))
                        {
                            MessageBox.Show("Password field is empty", "Login Faild", 0, MessageBoxIcon.Error);
                            txtPassword.Focus();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("LoginForm_btnLogin_Click   " + ex.Message);
            }
        }
        #endregion
        #region Code for Quit Application
        private void frmLoginForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (!bFormCloseCheck)
                {
                    if (GlobalClass.fnMessageResultquit() == Global.sCLOSE_MESSAGE_RESULT_YES)//calling Quit message
                    {
                        bFormCloseCheck = true;
                        GlobalClass.iSuccess = DAL.ERPActiveLoggin(1, txtUserName.Text, false, 0);
                        Application.ExitThread();
                    }
                    else
                        e.Cancel = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("LoginForm_frmLoginForm_FormClosing " + ex.Message);
            }
        }
        #endregion
        #region Code to Load User Name & Password If Saved
        private void frmLoginForm_Load(object sender, EventArgs e)
        {
            DAL.fnGetConnectionString();
            txtUserName.Text = Erp_Project_With_Buttons.Properties.Settings.Default.UserName;
            txtPassword.Text = Erp_Project_With_Buttons.Properties.Settings.Default.Password;
        }
        #endregion
        #region Code to Login
        private void txtUserName_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnLogin_Click(sender, e);
            }
        }

        private void txtPassword_KeyUp(object sender, KeyEventArgs e)
        {
            txtUserName_KeyUp(sender, e);
        }
        #endregion
        #region Code to Save UserName & Password
        private void fnSavePassword()
        {
            Erp_Project_With_Buttons.Properties.Settings.Default.UserName = txtUserName.Text;
            Erp_Project_With_Buttons.Properties.Settings.Default.Password = (txtPassword.Text);
            Erp_Project_With_Buttons.Properties.Settings.Default.Save();
        }
        #endregion

        bool bMail = false;
        #region Code to Send Email to User For Forgot Password
        private void btnEmailreq_Click(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(txtbissEmailid.Text))
            {
                dtForgotPassword = DAL.fnPaswordUsername(txtbissEmailid.Text).Tables[0];
                if (dtForgotPassword.Rows.Count > 0)
                {
                    try
                    {
                        Outlook.Application oApp = new Outlook.Application();
                        Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                        oMsg.DeleteAfterSubmit = true;
                        oMsg.Subject = "ERP Credentials";
                        oMsg.HTMLBody = " Dear " + dtForgotPassword.Rows[0]["UserName"].ToString() + ", <br /><br /> User Name : " + dtForgotPassword.Rows[0]["UserName"].ToString() + "  <br /> Password : " + Cryptography.Decrypt(dtForgotPassword.Rows[0]["LoginPassword"].ToString()) + " <br /> <br />Please do not share the credentials with anyone.<br /> <br /> <b>**** THIS IS AN AUTO GENARATED EMAIL. PLEASE DO NOT REPLY ****</b>";
                        // Add a recipient.
                        Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                        oRecips.Add(txtbissEmailid.Text);
                        oRecips.ResolveAll();
                        // Send.
                        oMsg.Send();
                        bMail = true;
                        // Clean up.
                        oRecips = null;
                        oMsg = null;
                        oApp = null;


                        MessageBox.Show("Mail sent to your e-mail id successfully!", "Success", 0, MessageBoxIcon.Information);

                        txtbissEmailid.Text = "";
                        lblemailid.Visible = false;
                        txtbissEmailid.Visible = false;
                        btnEmailreq.Visible = false;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
                else
                {
                    MessageBox.Show("Your e-mail Id not updated. Please contact the admin ", "Information", 0, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Enter a valid BiSS e-mail Id ", "Information", 0, MessageBoxIcon.Warning);
            }
        }
        #endregion
        #region Code to Forgot Password Enable
        private void llforgotpassword_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            lblemailid.Visible = true;
            txtbissEmailid.Visible = true;
            btnEmailreq.Visible = true;
        }
        #endregion
        //public string Encrypt(string clearText)
        //{
        //    string EncryptionKey = "MAKV2SPBNI99212";
        //    byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
        //    using (Aes encryptor = Aes.Create())
        //    {
        //        Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
        //        encryptor.Key = pdb.GetBytes(32);
        //        encryptor.IV = pdb.GetBytes(16);
        //        using (MemoryStream ms = new MemoryStream())
        //        {
        //            using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
        //            {
        //                cs.Write(clearBytes, 0, clearBytes.Length);
        //                cs.Close();
        //            }
        //            clearText = Convert.ToBase64String(ms.ToArray());
        //        }
        //    }
        //    return clearText;
        //}
        //public string Decrypt(string cipherText)
        //{
        //    string EncryptionKey = "MAKV2SPBNI99212";
        //    byte[] cipherBytes = Convert.FromBase64String(cipherText);
        //    using (Aes encryptor = Aes.Create())
        //    {
        //        Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
        //        encryptor.Key = pdb.GetBytes(32);
        //        encryptor.IV = pdb.GetBytes(16);
        //        using (MemoryStream ms = new MemoryStream())
        //        {
        //            using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
        //            {
        //                cs.Write(cipherBytes, 0, cipherBytes.Length);
        //                cs.Close();
        //            }
        //            cipherText = Encoding.Unicode.GetString(ms.ToArray());
        //        }
        //    }
        //    return cipherText;
        //}
    }
}
