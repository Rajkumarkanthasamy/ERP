﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.City_Master
{

    public partial class CityMaster : Form
    {
        
        public CityMaster()
        {
            InitializeComponent();
        }
        Global globalclass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        
        private void CityMaster_Load(object sender, EventArgs e)
        {
            DataTable dtstateList = DAL.getstate(0, null,null).Tables[0];                    
            List<KeyValuePair<int, string>> allitems = new List<KeyValuePair<int, string>>();
            KeyValuePair<int, string> first = new KeyValuePair<int, string>(0, "Please Select");
            allitems.Add(first);
            foreach (DataRow dr in dtstateList.Rows)
            {
                KeyValuePair<int, string> obj = new KeyValuePair<int, string>(Convert.ToInt32(dr["ID"]), dr["StateName"].ToString());
                allitems.Add(obj);
            }
            statecmb.DataSource = allitems;
            statecmb.DisplayMember = "Value";
            statecmb.ValueMember = "Key";

        }

        private void Savebtn_Click(object sender, EventArgs e)
        {
           
            string dropval = statecmb.SelectedValue.ToString();
            if(!string.IsNullOrEmpty(citytxt.Text))
            {
                globalclass.iSuccess = DAL.fninsertcity(1, citytxt.Text, dropval, login.GetUserDetails[2]);
                if(globalclass.iSuccess>0)
                {
                    MessageBox.Show("City Name Inserted Successfully");
                    citytxt.ResetText();
                    statecmb.SelectedValue=0;
                }
            }

        }

        private void fnClose()
        {
            frmForm2 frmForm2 = new frmForm2();
            this.Hide();
            frmForm2.Show();
        }

        private void CityMaster_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnClose();
        }

        private void Cancelbtn_Click(object sender, EventArgs e)
        {
            fnClose();
        }

        private void btnaddstate_Click(object sender, EventArgs e)
        {
           // string dropval = statecmb.SelectedValue.ToString();
            if (!string.IsNullOrEmpty(textboxcountry.Text) && !string.IsNullOrEmpty(textBoxstate.Text))
            {
                globalclass.iSuccess = DAL.fninsertcity(2, textBoxstate.Text, textboxcountry.Text,"");
                if (globalclass.iSuccess > 0)
                {
                    MessageBox.Show("State Name Inserted Successfully");
                    textboxcountry.ResetText();
                    textBoxstate.ResetText();
                    statepanel.Visible = false;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {            
            statepanel.Visible = true;
        }

        private void btnclostate_Click(object sender, EventArgs e)
        {
            textboxcountry.ResetText();
            textBoxstate.ResetText();
            statepanel.Visible = false;
        }
    }
}
