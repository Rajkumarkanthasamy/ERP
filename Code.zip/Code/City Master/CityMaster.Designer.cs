﻿
namespace Erp_Project_With_Buttons.City_Master
{
    partial class CityMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CityMaster));
            this.Savebtn = new System.Windows.Forms.Button();
            this.Cancelbtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.citytxt = new System.Windows.Forms.TextBox();
            this.statecmb = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.statepanel = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnclostate = new System.Windows.Forms.Button();
            this.btnaddstate = new System.Windows.Forms.Button();
            this.textBoxstate = new System.Windows.Forms.TextBox();
            this.textboxcountry = new System.Windows.Forms.TextBox();
            this.statepanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // Savebtn
            // 
            this.Savebtn.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Savebtn.Location = new System.Drawing.Point(179, 220);
            this.Savebtn.Name = "Savebtn";
            this.Savebtn.Size = new System.Drawing.Size(106, 43);
            this.Savebtn.TabIndex = 0;
            this.Savebtn.TabStop = false;
            this.Savebtn.Text = "Save";
            this.Savebtn.UseVisualStyleBackColor = true;
            this.Savebtn.Click += new System.EventHandler(this.Savebtn_Click);
            // 
            // Cancelbtn
            // 
            this.Cancelbtn.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cancelbtn.Location = new System.Drawing.Point(319, 220);
            this.Cancelbtn.Name = "Cancelbtn";
            this.Cancelbtn.Size = new System.Drawing.Size(127, 43);
            this.Cancelbtn.TabIndex = 1;
            this.Cancelbtn.Text = "Cancel";
            this.Cancelbtn.UseVisualStyleBackColor = true;
            this.Cancelbtn.Click += new System.EventHandler(this.Cancelbtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(67, 128);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 19);
            this.label1.TabIndex = 2;
            this.label1.Text = "State Name :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(75, 174);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 19);
            this.label2.TabIndex = 3;
            this.label2.Text = "City Name :";
            // 
            // citytxt
            // 
            this.citytxt.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.citytxt.Location = new System.Drawing.Point(179, 167);
            this.citytxt.Name = "citytxt";
            this.citytxt.Size = new System.Drawing.Size(269, 26);
            this.citytxt.TabIndex = 4;
            // 
            // statecmb
            // 
            this.statecmb.DropDownHeight = 100;
            this.statecmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.statecmb.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statecmb.FormattingEnabled = true;
            this.statecmb.IntegralHeight = false;
            this.statecmb.Location = new System.Drawing.Point(181, 120);
            this.statecmb.Name = "statecmb";
            this.statecmb.Size = new System.Drawing.Size(267, 27);
            this.statecmb.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LightGreen;
            this.button1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(181, 30);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(159, 33);
            this.button1.TabIndex = 8;
            this.button1.Text = "Add State/Country";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // statepanel
            // 
            this.statepanel.Controls.Add(this.label5);
            this.statepanel.Controls.Add(this.label4);
            this.statepanel.Controls.Add(this.btnclostate);
            this.statepanel.Controls.Add(this.btnaddstate);
            this.statepanel.Controls.Add(this.textBoxstate);
            this.statepanel.Controls.Add(this.textboxcountry);
            this.statepanel.Location = new System.Drawing.Point(71, 96);
            this.statepanel.Name = "statepanel";
            this.statepanel.Size = new System.Drawing.Size(431, 226);
            this.statepanel.TabIndex = 9;
            this.statepanel.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(60, 102);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 19);
            this.label5.TabIndex = 5;
            this.label5.Text = "State *:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(41, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 19);
            this.label4.TabIndex = 4;
            this.label4.Text = "Country *:";
            // 
            // btnclostate
            // 
            this.btnclostate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclostate.Location = new System.Drawing.Point(239, 154);
            this.btnclostate.Name = "btnclostate";
            this.btnclostate.Size = new System.Drawing.Size(93, 35);
            this.btnclostate.TabIndex = 3;
            this.btnclostate.Text = "Close";
            this.btnclostate.UseVisualStyleBackColor = true;
            this.btnclostate.Click += new System.EventHandler(this.btnclostate_Click);
            // 
            // btnaddstate
            // 
            this.btnaddstate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaddstate.Location = new System.Drawing.Point(127, 154);
            this.btnaddstate.Name = "btnaddstate";
            this.btnaddstate.Size = new System.Drawing.Size(90, 35);
            this.btnaddstate.TabIndex = 2;
            this.btnaddstate.Text = "Save";
            this.btnaddstate.UseVisualStyleBackColor = true;
            this.btnaddstate.Click += new System.EventHandler(this.btnaddstate_Click);
            // 
            // textBoxstate
            // 
            this.textBoxstate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxstate.Location = new System.Drawing.Point(127, 102);
            this.textBoxstate.Name = "textBoxstate";
            this.textBoxstate.Size = new System.Drawing.Size(205, 26);
            this.textBoxstate.TabIndex = 1;
            // 
            // textboxcountry
            // 
            this.textboxcountry.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textboxcountry.Location = new System.Drawing.Point(127, 50);
            this.textboxcountry.Name = "textboxcountry";
            this.textboxcountry.Size = new System.Drawing.Size(205, 26);
            this.textboxcountry.TabIndex = 0;
            // 
            // CityMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.statepanel);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.statecmb);
            this.Controls.Add(this.citytxt);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Cancelbtn);
            this.Controls.Add(this.Savebtn);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimizeBox = false;
            this.Name = "CityMaster";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CityMaster";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CityMaster_FormClosing);
            this.Load += new System.EventHandler(this.CityMaster_Load);
            this.statepanel.ResumeLayout(false);
            this.statepanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Savebtn;
        private System.Windows.Forms.Button Cancelbtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox citytxt;
        private System.Windows.Forms.ComboBox statecmb;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel statepanel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnclostate;
        private System.Windows.Forms.Button btnaddstate;
        private System.Windows.Forms.TextBox textBoxstate;
        private System.Windows.Forms.TextBox textboxcountry;
    }
}