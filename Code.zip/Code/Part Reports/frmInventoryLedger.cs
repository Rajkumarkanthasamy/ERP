﻿using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.IO;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.Diagnostics;

namespace Erp_Project_With_Buttons.Part_Reports
{
    public partial class frmInventoryLedger : Form
    {
        frmForm2 frm = new frmForm2();
        Login.frmLoginForm LoginForm = new Login.frmLoginForm();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        DataTable dtRepeatedItemList = new DataTable();
        DataTable dtMaterialLedger = new DataTable();
        DataTable dtTableFilter = new DataTable();
        DataView dvItemList = new DataView();
        DataTable dtItemList = new DataTable();

        public frmInventoryLedger()
        {
            InitializeComponent();
        }

        private void frmMaterialLedger_Load(object sender, EventArgs e)
        {
            chkItemCode.Checked = true;
            dtpfromdate.Format = DateTimePickerFormat.Custom;
            dtpfromdate.CustomFormat = "dd-MM-yyyy";
            dtpfromdate.Value = new DateTime(2025, 04, 01);
            dtptodate.Format = DateTimePickerFormat.Custom;
            dtptodate.CustomFormat = "dd-MM-yyyy";
            dtItemList = DAL.fnItemList(null).Tables[0];
            dtTableFilter = dtItemList;

            if (Convert.ToBoolean(LoginForm.GetUserDetails[16]) == true || Convert.ToBoolean(LoginForm.GetUserDetails[30]) == true || Convert.ToBoolean(LoginForm.GetUserDetails[29]) == true || Convert.ToBoolean(LoginForm.GetUserDetails[31]) == true || Convert.ToBoolean(LoginForm.GetUserDetails[32]) == true || LoginForm.GetUserDetails[2].ToLower() == "lizzy")    //  lblPrepareBy.Text.ToLower() == "hebbarrk")
            {
                dgvmaterialLedger.Columns[5].Visible = true;
                dgvmaterialLedger.Columns[6].Visible = true;
                lblrepeatCost.Visible = true;
                btnExportExcel.Visible = true;
            }
            else
            {
                dgvmaterialLedger.Columns[5].Visible = false;
                dgvmaterialLedger.Columns[6].Visible = false;
                lblrepeatCost.Visible = false;
                btnExportExcel.Visible = false;
            }
        }


        private void btnmaterialledger_Click(object sender, EventArgs e)
        {
            bAllLedger = false;
            dgvALLLedgerReport.Visible = false;
            dtpfromdate.Format = DateTimePickerFormat.Custom;
            dtpfromdate.CustomFormat = "yyyy-MM-dd";
            dtptodate.Format = DateTimePickerFormat.Custom;
            dtptodate.CustomFormat = "yyyy-MM-dd";

            var yesterday1 = dtpfromdate.Value.AddDays(-1);


            dtMaterialLedger = DAL.fnMaterialLedger(lblRepeatitemcode.Text, "2001-01-01", yesterday1.ToString("yyyy-MM-dd")).Tables[0];

            if (dtMaterialLedger.Rows.Count > 0)
            {
                DataView view = dtMaterialLedger.DefaultView;
                view.Sort = "date ASC";
                DataTable sortedDate = view.ToTable();
                dgvmaterialLedger.AutoGenerateColumns = false;
                dgvmaterialLedger.DataSource = sortedDate;

                RecievedQTY = 0;
                IssuedQTY = 0;
                ReturnQTY = 0;
                StockAdjusted = 0;
                foreach (DataRow dgvr in dtMaterialLedger.Rows)
                {
                    RecievedQTY += Convert.ToDouble(dgvr["RecievedQty"].ToString());
                    IssuedQTY += Convert.ToDouble(dgvr["IssuedQty"].ToString());
                    ReturnQTY += Convert.ToDouble(dgvr["ReturnQty"].ToString());
                    StockAdjusted += Convert.ToDouble(dgvr["StockAdjsued"].ToString());
                }

                //lblrecievqty.Text = RecievedQTY.ToString();
                //lblissuedqty.Text = IssuedQTY.ToString();
                //lblreturnqty.Text = ReturnQTY.ToString();
                //lblStockAdjusted.Text = StockAdjusted.ToString();
                //lblRecipt.Text = RecievedQTY.ToString();
                //lblIssue.Text = IssuedQTY.ToString();
                //lblItemReturn.Text = ReturnQTY.ToString();
                //lblStockAdjused.Text = StockAdjusted.ToString();
                lblOpeningBalance.Text = (Convert.ToDouble(lblOpeningBalance.Text) + RecievedQTY + ReturnQTY - IssuedQTY + StockAdjusted).ToString();

            }
            else
            {
                dtMaterialLedger = DAL.fnMaterialLedger(lblRepeatitemcode.Text, "2001-01-01", null).Tables[0];
                if (dtMaterialLedger.Rows.Count > 0)
                {
                    lblOpeningBalance.Text = dtMaterialLedger.Rows[0]["OpeningQuantity"].ToString();
                    RecievedQTY = 0;
                    IssuedQTY = 0;
                    ReturnQTY = 0;
                    StockAdjusted = 0;
                    lblClosingStock.Text = (Convert.ToDouble(lblOpeningBalance.Text) + RecievedQTY + ReturnQTY - IssuedQTY + StockAdjusted).ToString();
                }
            }

            dtMaterialLedger = DAL.fnMaterialLedger(lblRepeatitemcode.Text, dtpfromdate.Text, dtptodate.Text).Tables[0];

            if (dtMaterialLedger.Rows.Count > 0)
            {
                DataView view = dtMaterialLedger.DefaultView;
                view.Sort = "date ASC";
                DataTable sortedDate = view.ToTable();
                dgvmaterialLedger.AutoGenerateColumns = false;
                dgvmaterialLedger.DataSource = sortedDate;

                RecievedQTY = 0;
                IssuedQTY = 0;
                ReturnQTY = 0;
                StockAdjusted = 0;
                foreach (DataRow dgvr in dtMaterialLedger.Rows)
                {
                    RecievedQTY += Convert.ToDouble(dgvr["RecievedQty"].ToString());
                    IssuedQTY += Convert.ToDouble(dgvr["IssuedQty"].ToString());
                    ReturnQTY += Convert.ToDouble(dgvr["ReturnQty"].ToString());
                    StockAdjusted += Convert.ToDouble(dgvr["StockAdjsued"].ToString());
                }

                lblrecievqty.Text = RecievedQTY.ToString();
                lblissuedqty.Text = IssuedQTY.ToString();
                lblreturnqty.Text = ReturnQTY.ToString();
                lblStockAdjusted.Text = StockAdjusted.ToString();
                lblRecipt.Text = RecievedQTY.ToString();
                lblIssue.Text = IssuedQTY.ToString();
                lblItemReturn.Text = ReturnQTY.ToString();
                lblStockAdjused.Text = StockAdjusted.ToString();
                lblClosingStock.Text = (Convert.ToDouble(lblOpeningBalance.Text) + RecievedQTY + ReturnQTY - IssuedQTY + StockAdjusted).ToString();
            }
            else
            {
                //lblNoitems.Visible = true;
                //dgvmaterialLedger.DataSource = null;
                //lblrecievqty.Text = "0";
                //lblissuedqty.Text = "0";
                //lblreturnqty.Text = "0";
                //lblStockAdjusted.Text = "0";
                //lblStockAdjused.Text = "0";

                //lblRecipt.Text = "0";
                //lblIssue.Text = "0";
                //lblStockAdjused.Text = "0";
                //lblClosingStock.Text = "0";
            }

            dtpfromdate.Format = DateTimePickerFormat.Custom;
            dtpfromdate.CustomFormat = "dd-MM-yyyy";
            dtptodate.Format = DateTimePickerFormat.Custom;
            dtptodate.CustomFormat = "dd-MM-yyyy";
        }




        private void frmMaterialLedger_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            frm.Show();
        }


        #region Rowfilter Funtion to select Item
        private void RowFilter()
        {
            chklbItemList.Items.Clear();
            foreach (DataRowView dv in dvItemList)
            {
                chklbItemList.Items.Add(string.Concat(dv[17].ToString(), ") ", dv[0].ToString(), ", ", dv[1].ToString(), ", ", dv[12].ToString()));
            }
        }
        #endregion


        private void txtItemDescription_Enter(object sender, EventArgs e)
        {
        }

        private void txtItemDescription_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar == '%'))
            {
                e.Handled = true;
            }
        }
        private void txtItemDescription_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GlobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text.Trim());

                    RowFilter();

                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GlobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text.Trim());
                    RowFilter();
                }

            }
            else
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GlobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text.Trim());
                    RowFilter();
                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GlobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text.Trim());
                    RowFilter();
                }

            }
        }

        //#region Excel App Release Object Function
        //private void releaseObject(object obj)
        //{
        //    try
        //    {
        //        System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
        //        obj = null;
        //    }
        //    catch (Exception ex)
        //    {
        //        obj = null;
        //        MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
        //    }
        //    finally
        //    {
        //        GC.Collect();
        //    }
        //}
        //#endregion



        string[] sItemCode;
        DataTable dtItemcode = new DataTable();
        double RecievedQTY;
        double IssuedQTY;
        double ReturnQTY;
        double StockAdjusted;

        private void chklbItemList_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            try
            {
                bAllLedger = false;
                dgvALLLedgerReport.Visible = false;
                if (!chklbItemList.CheckedItems.Contains(chklbItemList.SelectedItem))
                {
                    sItemCode = chklbItemList.SelectedItem.ToString().Trim().Split(')');
                    string sID = sItemCode[0];
                    dtItemcode = DAL.fnStandardCostItemList(sID).Tables[0];
                    if (dtItemcode.Rows.Count > 0)
                    {
                        lblRepeatitemcode.Text = dtItemcode.Rows[0]["Itemcode"].ToString();
                        lblitemname.Text = dtItemcode.Rows[0]["ItemDescription"].ToString();
                        lblrepeatCost.Text = dtItemcode.Rows[0]["UnitCost"].ToString() + " Rs";
                        lblavailableqty.Text = dtItemcode.Rows[0]["AvailableQty"].ToString(); //+ " " + dtItemcode.Rows[0]["Units"].ToString()
                        lblOpeningBalance.Text = dtItemcode.Rows[0]["OpeningQuantity"].ToString();
                        itemLocation.Text = dtItemcode.Rows[0]["ItemLocation"].ToString();

                        // dtMaterialLedger = DAL.fnMaterialLedger(lblRepeatitemcode.Text, null, null).Tables[0];
                        Cursor.Current = Cursors.WaitCursor;
                        
                        dtMaterialLedger = DAL.fnInventoryLedgerItem(lblRepeatitemcode.Text, dtpfromdate.Text, dtptodate.Text).Tables[0];//fnInventoryLedgerItem
                        if (dtMaterialLedger.Rows.Count > 0)
                        {


                            lblNoitems.Visible = false;


                            DataView view = dtMaterialLedger.DefaultView;
                            view.Sort = "date ASC";
                            DataTable sortedDate = view.ToTable();


                           // var col = dgvmaterialLedger.Columns["Date1"];
                           // col.DataPropertyName = "Date";                    // already done
                          //  col.ValueType = typeof(DateTime);                 // <-- IMPORTANT
                          //  col.DefaultCellStyle.Format = "yyyy-MM-dd HH:mm:ss.fff";       // or "dd-MMM-yyyy"
                          //  col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;


                            dgvmaterialLedger.AutoGenerateColumns = false; 
                            dgvmaterialLedger.Columns["projectcode"].DataPropertyName = "Date";
                            dgvmaterialLedger.Columns["Recieved"].DataPropertyName = "RecievedQty";
                            dgvmaterialLedger.Columns["Issued"].DataPropertyName = "IssuedQty";
                            dgvmaterialLedger.Columns["Return"].DataPropertyName = "ReturnQty";
                            dgvmaterialLedger.Columns["StockAdjsued"].DataPropertyName = "StockAdjsued";
                            dgvmaterialLedger.Columns["unitcost"].DataPropertyName = "UnitCost";
                            dgvmaterialLedger.Columns["amount"].DataPropertyName = "Amount";
                            dgvmaterialLedger.Columns["ledgerClosingQty"].DataPropertyName = "Closing Qty";
                            dgvmaterialLedger.Columns["ledgerClosingValue"].DataPropertyName = "Closing Value";
                            dgvmaterialLedger.Columns["refnumber"].DataPropertyName = "RefNumber";
                            dgvmaterialLedger.Columns["User"].DataPropertyName = "User";
                            dgvmaterialLedger.Columns["ledgerBasePrice"].DataPropertyName = "BasePrice";
                            dgvmaterialLedger.Columns["ledgerCD"].DataPropertyName = "CD";
                            dgvmaterialLedger.Columns["ledgerFreight"].DataPropertyName = "Freight";
                            dgvmaterialLedger.Columns["ledgerPackingFrowarding"].DataPropertyName = "Packing Frowarding";
                            dgvmaterialLedger.Columns["ledgerTransactionLocation"].DataPropertyName = "Transaction Location";



                            // ---- Formats ----
                            // Dates (server date/time)
                           // dgvmaterialLedger.Columns["Date1"].DefaultCellStyle.Format = "yyyy-MM-dd HH:mm:ss.fff"; // or "dd-MMM-yyyy"

                            // Quantities as whole numbers (change to "N3" if you need 3 decimals)
                            dgvmaterialLedger.Columns["Recieved"].DefaultCellStyle.Format = "N0";
                            dgvmaterialLedger.Columns["Issued"].DefaultCellStyle.Format = "N0";
                            dgvmaterialLedger.Columns["Return"].DefaultCellStyle.Format = "N0";
                            dgvmaterialLedger.Columns["StockAdjsued"].DefaultCellStyle.Format = "N0";
                            dgvmaterialLedger.Columns["ledgerClosingQty"].DefaultCellStyle.Format = "N0";

                            // Costs/Amounts to 2 decimals
                            dgvmaterialLedger.Columns["unitcost"].DefaultCellStyle.Format = "N2";
                            dgvmaterialLedger.Columns["amount"].DefaultCellStyle.Format = "N2";
                            dgvmaterialLedger.Columns["ledgerClosingValue"].DefaultCellStyle.Format = "N2";
                            dgvmaterialLedger.Columns["ledgerBasePrice"].DefaultCellStyle.Format = "N2";
                            dgvmaterialLedger.Columns["ledgerCD"].DefaultCellStyle.Format = "N2";
                            dgvmaterialLedger.Columns["ledgerFreight"].DefaultCellStyle.Format = "N2";
                            dgvmaterialLedger.Columns["ledgerPackingFrowarding"].DefaultCellStyle.Format = "N2";

                            // Optional: show blanks for nulls (instead of 0)
                            dgvmaterialLedger.Columns["unitcost"].DefaultCellStyle.NullValue = "";
                            dgvmaterialLedger.Columns["ledgerBasePrice"].DefaultCellStyle.NullValue = "";
                            dgvmaterialLedger.Columns["ledgerCD"].DefaultCellStyle.NullValue = "";
                            dgvmaterialLedger.Columns["ledgerFreight"].DefaultCellStyle.NullValue = "";
                            dgvmaterialLedger.Columns["ledgerPackingFrowarding"].DefaultCellStyle.NullValue = "";



                            // Bind the data
                            dgvmaterialLedger.DataSource = dtMaterialLedger;
                            dgvmaterialLedger.DataSource = sortedDate;
                            Cursor.Current = Cursors.Default;

                            RecievedQTY = 0;
                            IssuedQTY = 0;
                            ReturnQTY = 0;
                            StockAdjusted = 0;
                            foreach (DataRow dgvr in dtMaterialLedger.Rows)
                            {
                                RecievedQTY += Convert.ToDouble(dgvr["RecievedQty"].ToString());
                                IssuedQTY += Convert.ToDouble(dgvr["IssuedQty"].ToString());
                                ReturnQTY += Convert.ToDouble(dgvr["ReturnQty"].ToString());
                                StockAdjusted += Convert.ToDouble(dgvr["StockAdjsued"].ToString());
                            }
                            lblrecievqty.Text = RecievedQTY.ToString();
                            lblissuedqty.Text = IssuedQTY.ToString();
                            lblreturnqty.Text = ReturnQTY.ToString();
                            lblStockAdjusted.Text = StockAdjusted.ToString();
                            lblRecipt.Text = RecievedQTY.ToString();
                            lblIssue.Text = IssuedQTY.ToString();
                            lblItemReturn.Text = ReturnQTY.ToString();
                            lblStockAdjused.Text = StockAdjusted.ToString();
                            lblClosingStock.Text = (Convert.ToDouble(lblOpeningBalance.Text) + RecievedQTY + ReturnQTY - IssuedQTY + StockAdjusted).ToString();

                        }
                        else
                        {
                            lblNoitems.Visible = true;
                            dgvmaterialLedger.DataSource = null;
                            lblrecievqty.Text = "0";
                            lblissuedqty.Text = "0";
                            lblreturnqty.Text = "0";
                            lblStockAdjusted.Text = "0";
                            lblStockAdjused.Text = "0";

                            lblRecipt.Text = "0";
                            lblIssue.Text = "0";
                            lblStockAdjused.Text = "0";
                            lblClosingStock.Text = "0";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("chklbItemList_ItemCheck" + ex.Message);
            }
        }

        private void dgvmaterialLedger_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            // If the column is the DATED column, check the
            // value.
            if (this.dgvmaterialLedger.Columns[e.ColumnIndex].Name == "Date1")
            {
                ShortFormDateFormat(e);
            }
        }

        private static void ShortFormDateFormat(DataGridViewCellFormattingEventArgs formatting)
        {
            if (formatting.Value != null)
            {
                try
                {
                    DateTime theDate = DateTime.Parse(formatting.Value.ToString());
                    String dateString = theDate.ToString("dd-MM-yy");
                    formatting.Value = dateString;
                    formatting.FormattingApplied = true;
                }
                catch (FormatException)
                {
                    // Set to false in case there are other handlers interested trying to
                    // format this DataGridViewCellFormattingEventArgs instance.
                    formatting.FormattingApplied = false;
                }
            }
        }

        private void dgvmaterialLedger_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {

        }
        //Inventory report -testing
        private void dtnExportToExcel(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            string path = Path.Combine(
                           Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                           $"Inventory_Ledger_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx"
                       );

            //CsvExporter.DataTableToXlsx(dtMaterialLedger, path);
            ExcelExport.DataTableToXlsx(
                dtMaterialLedger,
                path,
                "Sheet1",
                itemCode: lblRepeatitemcode.Text,
                description: lblitemname.Text
            );
            Cursor.Current = Cursors.Default;
            MessageBox.Show(path, "Excel Generate succssfully");
        }

        private void btnExportExcel_Click(object sender, EventArgs e)
        {
            string ExcelFolderPath;
            string FileFullPath;

            Microsoft.Office.Interop.Excel._Application ExcelApp = null;
            Microsoft.Office.Interop.Excel._Workbook NewWorkBook = null;
            Cursor.Current = Cursors.WaitCursor;
            EXCEL.Worksheet NewWorkSheet;
            bool IsFirsttime = true;

            if (dtMaterialLedger.Rows.Count > 0)
            {
                int j = 14;
                ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\Materail Ledger\\";
                FileFullPath = ExcelFolderPath + "Material Ledger " + dtpfromdate.Text + " To " + dtptodate.Text + " " + DateTime.Now.ToString("d/M/yyyy HH/mm/ss") + " ";
                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);

                ExcelApp = new Microsoft.Office.Interop.Excel.Application();
                NewWorkBook = ExcelApp.Workbooks.Add(Type.Missing);
                Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
                worksheet = NewWorkBook.Sheets["Sheet1"];
                worksheet = NewWorkBook.ActiveSheet;
                worksheet.Name = "Material Ledger";
                object misValue = System.Reflection.Missing.Value;
                worksheet.Cells[1, 1] = Global.sCompanyName; //i++;       

                worksheet.Cells[2, 1] = "Item Code :";// i++;
                worksheet.Cells[2, 2] = lblRepeatitemcode.Text;
                //  CellMerge("Merge", NewWorkBook.ActiveSheet, 2, 2, 1, 7);
                worksheet.Cells[3, 1] = "Item Desc : ";
                worksheet.Cells[3, 2] = lblitemname.Text;
                //CellMerge("Merge", NewWorkBook.ActiveSheet, 3, 3, 1, 7);
                worksheet.Cells[4, 1] = "Dated From : ";

                worksheet.Cells[4, 2] = "" + dtpfromdate.Text + "  To : " + dtptodate.Text + "";// i++; i++;
                //CellMerge("Merge", NewWorkBook.ActiveSheet, 3, 3, 1, 3);
                worksheet.Range["A1:C1"].Cells.Font.Size = 16;
                worksheet.Range["A2:C12"].Cells.Font.Size = 12;
                // worksheet.Range["A4:C4"].Cells.Font.Size = 12;
                worksheet.Range["A1:C1"].Cells.Font.Bold = true;
                // worksheet.Range["A2:A11"].Cells.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;

                //  worksheet.Range["B2:B11"].Cells.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignLeft;
                var yesterday1 = DateTime.Today;

                worksheet.Cells[5, 1] = "Available Qunatity as on " + yesterday1.ToString("dd-MM-yyyy") + " ";



                worksheet.Cells[7, 1] = "Opening Balance :";
                worksheet.Cells[8, 1] = "Reciepts : ";
                worksheet.Cells[9, 1] = "Item Return : ";
                worksheet.Cells[10, 1] = "Issue : ";
                worksheet.Cells[11, 1] = "Stock Adjusted : ";
                worksheet.Cells[12, 1] = "Closing Stock : ";


                //worksheet.Cells[5, 1] = "Available Qunatity as on " + yesterday1.ToString("yyyy-MM-dd") + ": " + lblavailableqty.Text + "";


                worksheet.Cells[5, 2] = lblavailableqty.Text;
                worksheet.Cells[7, 2] = lblOpeningBalance.Text;
                worksheet.Cells[8, 2] = lblRecipt.Text;
                worksheet.Cells[9, 2] = lblItemReturn.Text;
                worksheet.Cells[10, 2] = lblIssue.Text;
                worksheet.Cells[11, 2] = lblStockAdjusted.Text;
                worksheet.Cells[12, 2] = lblClosingStock.Text;

                CellMerge("AlignRight", NewWorkBook.ActiveSheet, 2, 12, 1, 1);
                CellMerge("AlignLeft", NewWorkBook.ActiveSheet, 2, 12, 2, 2);

                bool bFirsttime = true;


                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Bold = true;

                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Bold = true;
                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Color = Color.Blue;


                object[,] rawData = new object[dtMaterialLedger.Rows.Count + 1, dtMaterialLedger.Columns.Count];
                if (bFirsttime)
                {
                    for (int col = 0; col < dtMaterialLedger.Columns.Count; col++)
                    {
                        rawData[0, col] = dtMaterialLedger.Columns[col].ColumnName;
                    }
                    bFirsttime = false;
                }
                if (dtMaterialLedger.Rows.Count > 0)
                {
                    for (int row = 0; row < dtMaterialLedger.Rows.Count; row++)
                    {
                        for (int col = 0; col < dtMaterialLedger.Columns.Count; col++)
                        {
                            rawData[row + 1, col] = dtMaterialLedger.Rows[row].ItemArray[col];
                        }
                    }
                    string finalColLetter = string.Empty;
                    string excelRange = string.Empty;
                    if (IsFirsttime)
                    {
                        finalColLetter = string.Empty;
                        string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        int colCharsetLen = colCharset.Length;

                        if (dtMaterialLedger.Columns.Count > colCharsetLen)
                        {
                            finalColLetter = colCharset.Substring(
                                (dtMaterialLedger.Columns.Count - 1) / colCharsetLen - 1, 1);
                        }

                        finalColLetter += colCharset.Substring(
                                (dtMaterialLedger.Columns.Count - 1) % colCharsetLen, 1);
                        excelRange = string.Format("A14:{0}{1}", finalColLetter, (dtMaterialLedger.Rows.Count + 14));
                        IsFirsttime = false;
                    }
                    worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;

                }

                //worksheet.Range["A3:C5"].Cells.Font.Size = 14;
                //worksheet.Range["A3:C5"].Cells.Font.Bold = 14;
                CellMerge("Merge", NewWorkBook.ActiveSheet, 1, 1, 1, 3);
                if (!bAllLedger)
                {
                    worksheet.get_Range("C6", "C99999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    Microsoft.Office.Interop.Excel.Range Range = worksheet.get_Range("N6", "R99999");
                    Range.EntireColumn.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                    //worksheet.Rows.RowHeight = "18";
                    Microsoft.Office.Interop.Excel.Range rangea = worksheet.get_Range("K6", "K99999");
                    rangea.NumberFormat = "dd-MM-yyyy";

                    worksheet.Columns.AutoFit();
                    worksheet.Rows.AutoFit();

                    worksheet.Columns[1].ColumnWidth = 40;
                    // worksheet.Columns[1].ColumnWidth = 12;
                    // worksheet.Columns[1].WrapText = true;
                    worksheet.Columns[7].ColumnWidth = 30;
                    worksheet.Columns[7].WrapText = true;
                    worksheet.Columns[8].ColumnWidth = 50;
                    worksheet.Columns[8].WrapText = true;
                }
                else if (bAllLedger)
                {
                    worksheet.Columns.AutoFit();
                    worksheet.Rows.AutoFit();


                    worksheet.Columns[2].ColumnWidth = 40;
                    // worksheet.Columns[2].WrapText = true;
                    bAllLedger = false;
                    Microsoft.Office.Interop.Excel.Range rangea = worksheet.get_Range("J6", "J99999");
                    rangea.NumberFormat = "0.00";

                    worksheet.Cells[7, 11].Formula = "=SUM(C7,E7,-F7,-G7,H7,I7,J7)";
                    worksheet.Cells[7, 11].Calculate();

                    worksheet.Cells[7, 13].Formula = "=SUM(D7*L7)";
                    worksheet.Cells[7, 13].Calculate();
                }


                worksheet.Rows.RowHeight = "18";
                worksheet.PageSetup.PrintArea = "A1:Q" + (dtMaterialLedger.Rows.Count + 14) + "";
                worksheet.PageSetup.PrintTitleRows = "$1:$2";
                worksheet.PageSetup.PrintNotes = true;
                worksheet.PageSetup.Zoom = 75;
                worksheet.PageSetup.PrintGridlines = true;
                worksheet.PageSetup.LeftMargin = 0;
                worksheet.PageSetup.RightMargin = 0;
                worksheet.PageSetup.TopMargin = 0.75;
                worksheet.PageSetup.BottomMargin = 0.75;
                worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                NewWorkBook.SaveAs(FileFullPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                NewWorkBook.Save();
                NewWorkBook.Close(true, misValue, misValue);
                ExcelApp.Quit();
                releaseObject(worksheet);
                releaseObject(NewWorkBook);
                releaseObject(ExcelApp);

                if (Directory.Exists(ExcelFolderPath))
                {
                    Process.Start(ExcelFolderPath);
                }
                Cursor.Current = Cursors.Default;
            }
            else
            {
                MessageBox.Show("Select date range has no data to print.", "Error", 0, MessageBoxIcon.Error);
            }

        }

        #region CellMerge Funtion
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlMedium, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "GridLines":
                    {
                        CELLS.Borders.Color = System.Drawing.Color.Black;
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignCenter":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                        break;
                    }
                case "AlignRight":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                        break;
                    }
                case "AlignLeft":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignLeft;
                        break;
                    }
                case "Bold":
                    {
                        CELLS.Font.Bold = true;
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

        }
        #endregion

        #region Excel App Release Object Function
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
        #endregion

        private void chkItemCode_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemCode.CheckState == CheckState.Checked)
            {
                chkItemDesc.Checked = false;
            }
        }

        private void chkItemDesc_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemDesc.CheckState == CheckState.Checked)
            {
                chkItemCode.Checked = false;
            }
        }
        bool bAllLedger = false;
        private void btnAllledger_Click(object sender, EventArgs e)
        {
            bAllLedger = true;
            dtpfromdate.Format = DateTimePickerFormat.Custom;
            dtpfromdate.CustomFormat = "yyyy-MM-dd";
            dtptodate.Format = DateTimePickerFormat.Custom;
            dtptodate.CustomFormat = "yyyy-MM-dd";
            dgvALLLedgerReport.Visible = true;
            dtMaterialLedger = DAL.fnMaterialLedger(null, dtpfromdate.Text, dtptodate.Text).Tables[0];
            dtpfromdate.Format = DateTimePickerFormat.Custom;
            dtpfromdate.CustomFormat = "dd-MM-yyyy";
            dtptodate.Format = DateTimePickerFormat.Custom;
            dtptodate.CustomFormat = "dd-MM-yyyy";

            if (dtMaterialLedger.Rows.Count > 0)
            {
                fnTableMerge();
                dgvALLLedgerReport.DataSource = dtMaterialLedger;
            }
            dgvALLLedgerReport.Columns[1].Width = 40;
        }

        private void fnTableMerge()
        {
            DataTable dtMerge = new DataTable();

            dtMerge = dtMaterialLedger.Copy();



            DataTable dtRsult = dtMerge.Clone();
            var distinctRows = dtMerge.DefaultView.ToTable(true, "ItemCode").Rows.OfType<DataRow>().Select(k => k[0] + "").ToArray();
            foreach (string name in distinctRows)
            {
                var rows = dtMerge.Select("ItemCode = '" + name + "'");
                string sItemcode = "";
                string sItemdesc = "";
                double dOpenQuantity = 0;
                double dAvaQuantity = 0;
                double dRecQuantity = 0;
                double dIssuedQuantity = 0;
                double dJobIssuedQuantity = 0;
                double dIssuedItemReturnQuantity = 0;
                double dJObIssuedItemReturnQuantity = 0;
                double dStockAdjusted = 0;
                double dClsoingQuantity = 0;
                double UnitCost = 0;
                double Amount = 0;
                //  double dTotal = 0;
                //    double dGrandTotal = 0;

                if (name == "HYD-PFA-000002")
                {

                }

                foreach (DataRow row in rows)
                {
                    sItemcode = row["ItemCode"].ToString();
                    sItemdesc = row["ItemDescription"].ToString();
                    if (row["OpeningQuantity"] != DBNull.Value)
                        dOpenQuantity += Convert.ToDouble(row["OpeningQuantity"]);
                    if (row["AvailableQty"] != DBNull.Value)
                        dAvaQuantity += Convert.ToDouble(row["AvailableQty"]);
                    dRecQuantity += Convert.ToDouble(row["RecievedQty"]);
                    dIssuedQuantity += Convert.ToDouble(row["IssuedQty"]);
                    dJobIssuedQuantity += Convert.ToDouble(row["JobIssuedQty"]);
                    dIssuedItemReturnQuantity += Convert.ToDouble(row["IssueReturnQty"]);
                    dJObIssuedItemReturnQuantity += Convert.ToDouble(row["JobIssueReturnQty"]);
                    dStockAdjusted += Convert.ToDouble(row["StockAdjsued"]);
                    //  dStockAdjusted = Convert.ToDouble(row["Qty"]);
                    UnitCost = Convert.ToDouble(row["UnitCost"]);
                }
                //if (sItemcode == "ELE-P/N 3 842 992 457")
                //{
                //    int k = 99;
                //}
                // dClsoingQuantity = dOpenQuantity + dRecQuantity - dIssuedQuantity - dJobIssuedQuantity + dIssuedItemReturnQuantity + dJObIssuedItemReturnQuantity + dStockAdjusted;
                Amount = dClsoingQuantity * UnitCost;
                dtRsult.Rows.Add(sItemcode, sItemdesc, dOpenQuantity, dAvaQuantity, dRecQuantity, dIssuedQuantity, dJobIssuedQuantity, dIssuedItemReturnQuantity,
                    dJObIssuedItemReturnQuantity, dStockAdjusted, dClsoingQuantity, UnitCost, Amount);

                //lblClosingStock.Text = (Convert.ToDouble(lblOpeningBalance.Text) + RecievedQTY + ReturnQTY - IssuedQTY + StockAdjusted).ToString();

                //  value = "";
            }


            dtMaterialLedger = dtRsult.Copy();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm.Show();
        }

        private void lblItemcode_Click(object sender, EventArgs e)
        {

        }

        private void lblavailableqty_Click(object sender, EventArgs e)
        {

        }

        private void dgvmaterialLedger_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
