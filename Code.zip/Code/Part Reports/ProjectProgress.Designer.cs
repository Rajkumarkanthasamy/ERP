﻿
namespace Erp_Project_With_Buttons.Part_Reports
{
    partial class ProjectProgress
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProjectProgress));
            this.panel1 = new System.Windows.Forms.Panel();
            this.selectedProjectList = new System.Windows.Forms.Label();
            this.ProjectCodecomboBox = new System.Windows.Forms.ComboBox();
            this.Generatebtn = new System.Windows.Forms.Button();
            this.Clearbutton = new System.Windows.Forms.Button();
            this.selectedProjectListLable = new System.Windows.Forms.Label();
            this.Addtolist = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.selectedProjectList);
            this.panel1.Location = new System.Drawing.Point(12, 45);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1012, 100);
            this.panel1.TabIndex = 0;
            // 
            // selectedProjectList
            // 
            this.selectedProjectList.AllowDrop = true;
            this.selectedProjectList.AutoEllipsis = true;
            this.selectedProjectList.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectedProjectList.Location = new System.Drawing.Point(21, 13);
            this.selectedProjectList.Name = "selectedProjectList";
            this.selectedProjectList.Size = new System.Drawing.Size(971, 73);
            this.selectedProjectList.TabIndex = 0;
            this.selectedProjectList.Text = "-";
            // 
            // ProjectCodecomboBox
            // 
            this.ProjectCodecomboBox.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProjectCodecomboBox.FormattingEnabled = true;
            this.ProjectCodecomboBox.Location = new System.Drawing.Point(12, 172);
            this.ProjectCodecomboBox.Name = "ProjectCodecomboBox";
            this.ProjectCodecomboBox.Size = new System.Drawing.Size(320, 26);
            this.ProjectCodecomboBox.TabIndex = 1;
            // 
            // Generatebtn
            // 
            this.Generatebtn.BackColor = System.Drawing.Color.Green;
            this.Generatebtn.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Generatebtn.ForeColor = System.Drawing.Color.White;
            this.Generatebtn.Location = new System.Drawing.Point(572, 172);
            this.Generatebtn.Name = "Generatebtn";
            this.Generatebtn.Size = new System.Drawing.Size(111, 26);
            this.Generatebtn.TabIndex = 2;
            this.Generatebtn.Text = "Generate Report";
            this.Generatebtn.UseVisualStyleBackColor = false;
            this.Generatebtn.Click += new System.EventHandler(this.Generatebtn_Click);
            // 
            // Clearbutton
            // 
            this.Clearbutton.BackColor = System.Drawing.Color.Red;
            this.Clearbutton.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clearbutton.ForeColor = System.Drawing.Color.White;
            this.Clearbutton.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.Clearbutton.Location = new System.Drawing.Point(455, 172);
            this.Clearbutton.Name = "Clearbutton";
            this.Clearbutton.Size = new System.Drawing.Size(111, 26);
            this.Clearbutton.TabIndex = 3;
            this.Clearbutton.Text = "Clear List";
            this.Clearbutton.UseVisualStyleBackColor = false;
            this.Clearbutton.Click += new System.EventHandler(this.Clearbutton_Click);
            // 
            // selectedProjectListLable
            // 
            this.selectedProjectListLable.AutoSize = true;
            this.selectedProjectListLable.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectedProjectListLable.Location = new System.Drawing.Point(12, 24);
            this.selectedProjectListLable.Name = "selectedProjectListLable";
            this.selectedProjectListLable.Size = new System.Drawing.Size(140, 18);
            this.selectedProjectListLable.TabIndex = 4;
            this.selectedProjectListLable.Text = "Selected Project List :";
            // 
            // Addtolist
            // 
            this.Addtolist.BackColor = System.Drawing.Color.MediumAquamarine;
            this.Addtolist.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold);
            this.Addtolist.ForeColor = System.Drawing.Color.White;
            this.Addtolist.Location = new System.Drawing.Point(338, 172);
            this.Addtolist.Name = "Addtolist";
            this.Addtolist.Size = new System.Drawing.Size(111, 26);
            this.Addtolist.TabIndex = 5;
            this.Addtolist.Text = "Add into List";
            this.Addtolist.UseVisualStyleBackColor = false;
            this.Addtolist.Click += new System.EventHandler(this.Addtolist_Click);
            // 
            // ProjectProgress
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1036, 612);
            this.Controls.Add(this.Addtolist);
            this.Controls.Add(this.selectedProjectListLable);
            this.Controls.Add(this.Clearbutton);
            this.Controls.Add(this.Generatebtn);
            this.Controls.Add(this.ProjectCodecomboBox);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ProjectProgress";
            this.Text = "ProjectProgress";
            this.Load += new System.EventHandler(this.ProjectProgress_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox ProjectCodecomboBox;
        private System.Windows.Forms.Button Generatebtn;
        private System.Windows.Forms.Button Clearbutton;
        private System.Windows.Forms.Label selectedProjectList;
        private System.Windows.Forms.Label selectedProjectListLable;
        private System.Windows.Forms.Button Addtolist;
    }
}