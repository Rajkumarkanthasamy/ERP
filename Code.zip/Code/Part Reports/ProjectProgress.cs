﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.Diagnostics;

namespace Erp_Project_With_Buttons.Part_Reports
{
    public partial class ProjectProgress : Form
    {
        public ProjectProgress()
        {
            InitializeComponent();
        }

        DataTable DTProjectList = new DataTable();
        DataAccessLayer DAL = new DataAccessLayer();
        DataTable ProjectListProgress = new DataTable();

        private void ProjectProgress_Load(object sender, EventArgs e)
        {
            if (DTProjectList.Rows.Count == 0)
            {
                DTProjectList = DAL.fnProjectList(null).Tables[0];

                foreach (DataRow row in DTProjectList.Rows)
                {
                    if (!ProjectCodecomboBox.Items.Contains(row["ProjectCode"].ToString()))
                        ProjectCodecomboBox.Items.Add(row["ProjectCode"].ToString());
                }
            }



        }

        private void Addtolist_Click(object sender, EventArgs e)
        {
            //ProjectCodecomboBox
            if(selectedProjectList.Text == "-")
            {
                selectedProjectList.Text = $@"'{ProjectCodecomboBox.Text}'";
            }
            else
            {
                selectedProjectList.Text = $@"{selectedProjectList.Text},'{ProjectCodecomboBox.Text}'";
            }
        }

        private void Clearbutton_Click(object sender, EventArgs e)
        {
            selectedProjectList.Text = "-";
        }

        private void Generatebtn_Click(object sender, EventArgs e)
        {
            if (selectedProjectList.Text != "-")
            {
                Cursor.Current = Cursors.WaitCursor;
                ProjectListProgress = DAL.fnProjectListProgress(selectedProjectList.Text).Tables[0];

                if(ProjectListProgress.Rows.Count > 0)
                {
                   
                    string path = Path.Combine(
                                   Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                                   $"Project_Progress_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx"
                               );

                    //CsvExporter.DataTableToXlsx(dtMaterialLedger, path);
                    CsvExporter.DataTableToXlsx(
                        ProjectListProgress,
                        path,
                        "ProjectProgress"
                    );
                    //Cursor.Current = Cursors.Default;
                    AutoClosingMessageBox.Show("Excel generated successfully", "Success", 3000);
                   // MessageBox.Show(path, "Excel Generate succssfully");
                }
                 Cursor.Current = Cursors.Default;

            }
        }

        //fnProjectListProgress


    }
}
