﻿namespace Erp_Project_With_Buttons
{
    partial class frmReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }


        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmReports));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.InOutWardpanel = new System.Windows.Forms.Panel();
            this.comboBoxINOutWard = new System.Windows.Forms.ComboBox();
            this.stockBalancepanel = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.CategorycomboBox4 = new System.Windows.Forms.ComboBox();
            this.subStoreNamecomboBox2 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.storeNamecomboBox3 = new System.Windows.Forms.ComboBox();
            this.FilterTypecomboBox1 = new System.Windows.Forms.ComboBox();
            this.cmbReport = new System.Windows.Forms.ComboBox();
            this.pnGenaralPanel = new System.Windows.Forms.Panel();
            this.pnoneyear = new System.Windows.Forms.Panel();
            this.dtptwelve = new System.Windows.Forms.DateTimePicker();
            this.lblTwelveMonths = new System.Windows.Forms.Label();
            this.lblFromdate = new System.Windows.Forms.Label();
            this.lblToDate = new System.Windows.Forms.Label();
            this.dtpFromDate = new System.Windows.Forms.DateTimePicker();
            this.dptToDate = new System.Windows.Forms.DateTimePicker();
            this.btnexcelreport = new System.Windows.Forms.Button();
            this.lblTables = new System.Windows.Forms.Label();
            this.pnginprint = new System.Windows.Forms.Panel();
            this.comboBox1Level = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.LocationUpdatebutton = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.comboBox5Position = new System.Windows.Forms.ComboBox();
            this.comboBox4RackNumber = new System.Windows.Forms.ComboBox();
            this.comboBox3SubStoreLocation = new System.Windows.Forms.ComboBox();
            this.comboBox2StoreNameLocation = new System.Windows.Forms.ComboBox();
            this.comboBox1ItemCodeLocation = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label11Location = new System.Windows.Forms.Label();
            this.comboBox1Location = new System.Windows.Forms.ComboBox();
            this.PrintBatchCode = new System.Windows.Forms.Button();
            this.btnprintgin = new System.Windows.Forms.Button();
            this.dgvprintpreview = new System.Windows.Forms.DataGridView();
            this.ItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.POQTY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SupplyQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.location = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.printCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Printbtn = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtprintvendorname = new System.Windows.Forms.TextBox();
            this.cmbprintginnumber = new System.Windows.Forms.ComboBox();
            this.txtprintvendorcode = new System.Windows.Forms.TextBox();
            this.txtprintprojectname = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtprintprojectcode = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pnVendorPanel = new System.Windows.Forms.Panel();
            this.lblvendorname = new System.Windows.Forms.Label();
            this.cmbvendorlist = new System.Windows.Forms.ComboBox();
            this.pnProjectCodePanel = new System.Windows.Forms.Panel();
            this.cmbProjectCode = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtProjectCode = new System.Windows.Forms.TextBox();
            this.lblSelectedProjectCode = new System.Windows.Forms.Label();
            this.lblItemDiscription = new System.Windows.Forms.Label();
            this.ItemLabelPrintpanel = new System.Windows.Forms.Panel();
            this.textBox1LableCount = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.comboBox1LabelPrintItemCode = new System.Windows.Forms.ComboBox();
            this.checkBox2ItemCode = new System.Windows.Forms.CheckBox();
            this.comboBox2LabelPrintLocation = new System.Windows.Forms.ComboBox();
            this.checkBox1Location = new System.Windows.Forms.CheckBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.checkBoxPrintLocation = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.InOutWardpanel.SuspendLayout();
            this.stockBalancepanel.SuspendLayout();
            this.pnGenaralPanel.SuspendLayout();
            this.pnoneyear.SuspendLayout();
            this.pnginprint.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvprintpreview)).BeginInit();
            this.pnVendorPanel.SuspendLayout();
            this.pnProjectCodePanel.SuspendLayout();
            this.ItemLabelPrintpanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Add-icon.png");
            this.imageList1.Images.SetKeyName(1, "table-add-icon.png");
            this.imageList1.Images.SetKeyName(2, "order-history-icon.png");
            this.imageList1.Images.SetKeyName(3, "Package-Add-icon.png");
            this.imageList1.Images.SetKeyName(4, "Excel-icon.png");
            this.imageList1.Images.SetKeyName(5, "Actions-address-book-new-icon.png");
            this.imageList1.Images.SetKeyName(6, "invoice-icon.png");
            this.imageList1.Images.SetKeyName(7, "Apps-kspread-icon.png");
            this.imageList1.Images.SetKeyName(8, "Apps-klipper-icon.png");
            this.imageList1.Images.SetKeyName(9, "Upline-icon.png");
            this.imageList1.Images.SetKeyName(10, "reports-icon.png");
            this.imageList1.Images.SetKeyName(11, "Mimetypes-application-vnd-sun-xml-calc-template-icon.png");
            this.imageList1.Images.SetKeyName(12, "catalog-icon.png");
            this.imageList1.Images.SetKeyName(13, "Add-icon.png");
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.LightGray;
            this.groupBox1.Controls.Add(this.InOutWardpanel);
            this.groupBox1.Controls.Add(this.stockBalancepanel);
            this.groupBox1.Controls.Add(this.cmbReport);
            this.groupBox1.Controls.Add(this.pnGenaralPanel);
            this.groupBox1.Controls.Add(this.btnexcelreport);
            this.groupBox1.Controls.Add(this.lblTables);
            this.groupBox1.Controls.Add(this.pnginprint);
            this.groupBox1.Controls.Add(this.pnVendorPanel);
            this.groupBox1.Controls.Add(this.pnProjectCodePanel);
            this.groupBox1.Controls.Add(this.ItemLabelPrintpanel);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1303, 612);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // InOutWardpanel
            // 
            this.InOutWardpanel.Controls.Add(this.comboBoxINOutWard);
            this.InOutWardpanel.Location = new System.Drawing.Point(583, 35);
            this.InOutWardpanel.Name = "InOutWardpanel";
            this.InOutWardpanel.Size = new System.Drawing.Size(258, 120);
            this.InOutWardpanel.TabIndex = 245;
            this.InOutWardpanel.Visible = false;
            // 
            // comboBoxINOutWard
            // 
            this.comboBoxINOutWard.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.comboBoxINOutWard.FormattingEnabled = true;
            this.comboBoxINOutWard.Items.AddRange(new object[] {
            "All",
            "Inward",
            "Outward",
            "StockAdjust"});
            this.comboBoxINOutWard.Location = new System.Drawing.Point(3, 3);
            this.comboBoxINOutWard.Name = "comboBoxINOutWard";
            this.comboBoxINOutWard.Size = new System.Drawing.Size(212, 27);
            this.comboBoxINOutWard.SelectedIndex = 0;
            // 
            // stockBalancepanel
            // 
            this.stockBalancepanel.Controls.Add(this.button1);
            this.stockBalancepanel.Controls.Add(this.label9);
            this.stockBalancepanel.Controls.Add(this.CategorycomboBox4);
            this.stockBalancepanel.Controls.Add(this.subStoreNamecomboBox2);
            this.stockBalancepanel.Controls.Add(this.label2);
            this.stockBalancepanel.Controls.Add(this.label3);
            this.stockBalancepanel.Controls.Add(this.label4);
            this.stockBalancepanel.Controls.Add(this.storeNamecomboBox3);
            this.stockBalancepanel.Controls.Add(this.FilterTypecomboBox1);
            this.stockBalancepanel.Location = new System.Drawing.Point(40, 38);
            this.stockBalancepanel.Margin = new System.Windows.Forms.Padding(2);
            this.stockBalancepanel.Name = "stockBalancepanel";
            this.stockBalancepanel.Size = new System.Drawing.Size(538, 122);
            this.stockBalancepanel.TabIndex = 217;
            this.stockBalancepanel.Visible = false;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.button1.Location = new System.Drawing.Point(427, 90);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(108, 26);
            this.button1.TabIndex = 217;
            this.button1.Text = "Clear Filter";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            this.button1.MouseLeave += new System.EventHandler(this.buttton1_leaving);
            this.button1.MouseHover += new System.EventHandler(this.buttton1_hover);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold);
            this.label9.Location = new System.Drawing.Point(5, 6);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 22);
            this.label9.TabIndex = 215;
            this.label9.Text = "Category";
            this.label9.Visible = false;
            // 
            // CategorycomboBox4
            // 
            this.CategorycomboBox4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.CategorycomboBox4.FormattingEnabled = true;
            this.CategorycomboBox4.Items.AddRange(new object[] {
            "OTC – Accessories",
            "Mechanical",
            "Packing Materials",
            "OTC – Italy",
            "LFA – Machines",
            "FixedAsset",
            "TGT",
            "PTI- Plastic testing Machines",
            "Hydraulics",
            "KanBan",
            "LFA–Machines",
            "HFA- Machines",
            "Transducers",
            "Testlab",
            "Boughtout",
            "Maintenance",
            "Service(Non-Inventory)",
            "Broughtout",
            "Tools",
            "Consumable",
            "Chennai Stock",
            "Electronics",
            "Electricals",
            "Electronics RnD",
            "OTC – US",
            "Consumable- Non-Inventory",
            "Service Spares",
            "OTC – UK",
            ""});
            this.CategorycomboBox4.Location = new System.Drawing.Point(115, 2);
            this.CategorycomboBox4.Margin = new System.Windows.Forms.Padding(2);
            this.CategorycomboBox4.Name = "CategorycomboBox4";
            this.CategorycomboBox4.Size = new System.Drawing.Size(308, 27);
            this.CategorycomboBox4.TabIndex = 216;
            this.CategorycomboBox4.Visible = false;
            // 
            // subStoreNamecomboBox2
            // 
            this.subStoreNamecomboBox2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.subStoreNamecomboBox2.FormattingEnabled = true;
            this.subStoreNamecomboBox2.Items.AddRange(new object[] {
            "Ground Floor",
            "First Floor",
            "Old Stores",
            "Gripper Area",
            "Actuator Area",
            "Load Frame Area",
            "Manifold Area",
            ""});
            this.subStoreNamecomboBox2.Location = new System.Drawing.Point(115, 90);
            this.subStoreNamecomboBox2.Margin = new System.Windows.Forms.Padding(2);
            this.subStoreNamecomboBox2.Name = "subStoreNamecomboBox2";
            this.subStoreNamecomboBox2.Size = new System.Drawing.Size(308, 27);
            this.subStoreNamecomboBox2.TabIndex = 212;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(5, 34);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 22);
            this.label2.TabIndex = 210;
            this.label2.Text = "Filter Type";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(8, 86);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 22);
            this.label3.TabIndex = 211;
            this.label3.Text = "Sub Store";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(5, 62);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 22);
            this.label4.TabIndex = 214;
            this.label4.Text = "Store Name";
            // 
            // storeNamecomboBox3
            // 
            this.storeNamecomboBox3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.storeNamecomboBox3.FormattingEnabled = true;
            this.storeNamecomboBox3.Items.AddRange(new object[] {
            "Main Store",
            "De-Centralised",
            "KANBAN Shop FLOOR"});
            this.storeNamecomboBox3.Location = new System.Drawing.Point(115, 62);
            this.storeNamecomboBox3.Margin = new System.Windows.Forms.Padding(2);
            this.storeNamecomboBox3.Name = "storeNamecomboBox3";
            this.storeNamecomboBox3.Size = new System.Drawing.Size(308, 27);
            this.storeNamecomboBox3.TabIndex = 213;
            // 
            // FilterTypecomboBox1
            // 
            this.FilterTypecomboBox1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.FilterTypecomboBox1.FormattingEnabled = true;
            this.FilterTypecomboBox1.ItemHeight = 19;
            this.FilterTypecomboBox1.Items.AddRange(new object[] {
            "BatchWise",
            "Without BatchWise"});
            this.FilterTypecomboBox1.Location = new System.Drawing.Point(115, 31);
            this.FilterTypecomboBox1.Margin = new System.Windows.Forms.Padding(2);
            this.FilterTypecomboBox1.Name = "FilterTypecomboBox1";
            this.FilterTypecomboBox1.Size = new System.Drawing.Size(308, 27);
            this.FilterTypecomboBox1.TabIndex = 208;
            // 
            // cmbReport
            // 
            this.cmbReport.DropDownHeight = 130;
            this.cmbReport.DropDownWidth = 184;
            this.cmbReport.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbReport.FormattingEnabled = true;
            this.cmbReport.IntegralHeight = false;
            this.cmbReport.ItemHeight = 19;
            this.cmbReport.Location = new System.Drawing.Point(155, 8);
            this.cmbReport.Name = "cmbReport";
            this.cmbReport.Size = new System.Drawing.Size(308, 27);
            this.cmbReport.TabIndex = 32;
            this.cmbReport.SelectedIndexChanged += new System.EventHandler(this.cmbReport_SelectedIndexChanged);
            // 
            // pnGenaralPanel
            // 
            this.pnGenaralPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnGenaralPanel.Controls.Add(this.pnoneyear);
            this.pnGenaralPanel.Controls.Add(this.lblFromdate);
            this.pnGenaralPanel.Controls.Add(this.lblToDate);
            this.pnGenaralPanel.Controls.Add(this.dtpFromDate);
            this.pnGenaralPanel.Controls.Add(this.dptToDate);
            this.pnGenaralPanel.Location = new System.Drawing.Point(847, 35);
            this.pnGenaralPanel.Name = "pnGenaralPanel";
            this.pnGenaralPanel.Size = new System.Drawing.Size(244, 119);
            this.pnGenaralPanel.TabIndex = 29;
            this.pnGenaralPanel.Visible = false;
            // 
            // pnoneyear
            // 
            this.pnoneyear.Controls.Add(this.dtptwelve);
            this.pnoneyear.Controls.Add(this.lblTwelveMonths);
            this.pnoneyear.Location = new System.Drawing.Point(18, 72);
            this.pnoneyear.Name = "pnoneyear";
            this.pnoneyear.Size = new System.Drawing.Size(208, 39);
            this.pnoneyear.TabIndex = 241;
            // 
            // dtptwelve
            // 
            this.dtptwelve.Font = new System.Drawing.Font("Times New Roman", 11.25F);
            this.dtptwelve.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtptwelve.Location = new System.Drawing.Point(88, 6);
            this.dtptwelve.Name = "dtptwelve";
            this.dtptwelve.Size = new System.Drawing.Size(112, 25);
            this.dtptwelve.TabIndex = 22;
            // 
            // lblTwelveMonths
            // 
            this.lblTwelveMonths.AutoSize = true;
            this.lblTwelveMonths.Font = new System.Drawing.Font("Times New Roman", 11.25F);
            this.lblTwelveMonths.Location = new System.Drawing.Point(3, 8);
            this.lblTwelveMonths.Name = "lblTwelveMonths";
            this.lblTwelveMonths.Size = new System.Drawing.Size(79, 17);
            this.lblTwelveMonths.TabIndex = 25;
            this.lblTwelveMonths.Text = "1 Year Date";
            // 
            // lblFromdate
            // 
            this.lblFromdate.AutoSize = true;
            this.lblFromdate.Font = new System.Drawing.Font("Times New Roman", 11.25F);
            this.lblFromdate.Location = new System.Drawing.Point(31, 10);
            this.lblFromdate.Name = "lblFromdate";
            this.lblFromdate.Size = new System.Drawing.Size(72, 17);
            this.lblFromdate.TabIndex = 4;
            this.lblFromdate.Text = "From Date";
            // 
            // lblToDate
            // 
            this.lblToDate.Font = new System.Drawing.Font("Times New Roman", 11.25F);
            this.lblToDate.Location = new System.Drawing.Point(3, 42);
            this.lblToDate.Name = "lblToDate";
            this.lblToDate.Size = new System.Drawing.Size(100, 17);
            this.lblToDate.TabIndex = 6;
            this.lblToDate.Text = "           To Date";
            this.lblToDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // dtpFromDate
            // 
            this.dtpFromDate.Font = new System.Drawing.Font("Times New Roman", 11.25F);
            this.dtpFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFromDate.Location = new System.Drawing.Point(109, 4);
            this.dtpFromDate.Name = "dtpFromDate";
            this.dtpFromDate.Size = new System.Drawing.Size(109, 25);
            this.dtpFromDate.TabIndex = 9;
            this.dtpFromDate.ValueChanged += new System.EventHandler(this.dtpFromDate_ValueChanged);
            // 
            // dptToDate
            // 
            this.dptToDate.Font = new System.Drawing.Font("Times New Roman", 11.25F);
            this.dptToDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dptToDate.Location = new System.Drawing.Point(109, 41);
            this.dptToDate.Name = "dptToDate";
            this.dptToDate.Size = new System.Drawing.Size(109, 25);
            this.dptToDate.TabIndex = 10;
            // 
            // btnexcelreport
            // 
            this.btnexcelreport.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexcelreport.Location = new System.Drawing.Point(1103, 33);
            this.btnexcelreport.Name = "btnexcelreport";
            this.btnexcelreport.Size = new System.Drawing.Size(144, 40);
            this.btnexcelreport.TabIndex = 28;
            this.btnexcelreport.Text = "Generate Report";
            this.btnexcelreport.UseVisualStyleBackColor = true;
            this.btnexcelreport.Click += new System.EventHandler(this.btnexcelreport_Click);
            // 
            // lblTables
            // 
            this.lblTables.AutoSize = true;
            this.lblTables.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTables.Location = new System.Drawing.Point(45, 8);
            this.lblTables.Name = "lblTables";
            this.lblTables.Size = new System.Drawing.Size(112, 22);
            this.lblTables.TabIndex = 0;
            this.lblTables.Text = "Report Type";
            // 
            // pnginprint
            // 
            this.pnginprint.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnginprint.Controls.Add(this.comboBox1Level);
            this.pnginprint.Controls.Add(this.label17);
            this.pnginprint.Controls.Add(this.label16);
            this.pnginprint.Controls.Add(this.LocationUpdatebutton);
            this.pnginprint.Controls.Add(this.label15);
            this.pnginprint.Controls.Add(this.label14);
            this.pnginprint.Controls.Add(this.label13);
            this.pnginprint.Controls.Add(this.comboBox5Position);
            this.pnginprint.Controls.Add(this.comboBox4RackNumber);
            this.pnginprint.Controls.Add(this.comboBox3SubStoreLocation);
            this.pnginprint.Controls.Add(this.comboBox2StoreNameLocation);
            this.pnginprint.Controls.Add(this.comboBox1ItemCodeLocation);
            this.pnginprint.Controls.Add(this.label12);
            this.pnginprint.Controls.Add(this.label11);
            this.pnginprint.Controls.Add(this.label11Location);
            this.pnginprint.Controls.Add(this.comboBox1Location);
            this.pnginprint.Controls.Add(this.PrintBatchCode);
            this.pnginprint.Controls.Add(this.btnprintgin);
            this.pnginprint.Controls.Add(this.dgvprintpreview);
            this.pnginprint.Controls.Add(this.label10);
            this.pnginprint.Controls.Add(this.label8);
            this.pnginprint.Controls.Add(this.txtprintvendorname);
            this.pnginprint.Controls.Add(this.cmbprintginnumber);
            this.pnginprint.Controls.Add(this.txtprintvendorcode);
            this.pnginprint.Controls.Add(this.txtprintprojectname);
            this.pnginprint.Controls.Add(this.label7);
            this.pnginprint.Controls.Add(this.txtprintprojectcode);
            this.pnginprint.Controls.Add(this.label6);
            this.pnginprint.Controls.Add(this.label5);
            this.pnginprint.Location = new System.Drawing.Point(25, 165);
            this.pnginprint.Name = "pnginprint";
            this.pnginprint.Size = new System.Drawing.Size(1272, 442);
            this.pnginprint.TabIndex = 207;
            this.pnginprint.Visible = false;
            // 
            // comboBox1Level
            // 
            this.comboBox1Level.Font = new System.Drawing.Font("Calibri", 12F);
            this.comboBox1Level.FormattingEnabled = true;
            this.comboBox1Level.IntegralHeight = false;
            this.comboBox1Level.Items.AddRange(new object[] {
            "L1",
            "L2",
            "L3",
            "L4",
            "Bin"});
            this.comboBox1Level.Location = new System.Drawing.Point(1092, 260);
            this.comboBox1Level.Name = "comboBox1Level";
            this.comboBox1Level.Size = new System.Drawing.Size(153, 27);
            this.comboBox1Level.TabIndex = 257;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold);
            this.label17.Location = new System.Drawing.Point(990, 270);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(46, 17);
            this.label17.TabIndex = 256;
            this.label17.Text = "Level";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.Red;
            this.label16.Location = new System.Drawing.Point(987, 76);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(272, 13);
            this.label16.TabIndex = 255;
            this.label16.Text = "Update item location based on the selected GIN number";
            // 
            // LocationUpdatebutton
            // 
            this.LocationUpdatebutton.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold);
            this.LocationUpdatebutton.Location = new System.Drawing.Point(1092, 354);
            this.LocationUpdatebutton.Name = "LocationUpdatebutton";
            this.LocationUpdatebutton.Size = new System.Drawing.Size(151, 33);
            this.LocationUpdatebutton.TabIndex = 254;
            this.LocationUpdatebutton.Text = "Location Update";
            this.LocationUpdatebutton.UseVisualStyleBackColor = true;
            this.LocationUpdatebutton.Click += new System.EventHandler(this.LocationUpdatebutton_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold);
            this.label15.Location = new System.Drawing.Point(990, 306);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(61, 17);
            this.label15.TabIndex = 253;
            this.label15.Text = "Position";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold);
            this.label14.Location = new System.Drawing.Point(990, 227);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(99, 17);
            this.label14.TabIndex = 252;
            this.label14.Text = "Rack Number";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold);
            this.label13.Location = new System.Drawing.Point(987, 188);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(70, 17);
            this.label13.TabIndex = 251;
            this.label13.Text = "Sub store";
            // 
            // comboBox5Position
            // 
            this.comboBox5Position.Font = new System.Drawing.Font("Calibri", 12F);
            this.comboBox5Position.FormattingEnabled = true;
            this.comboBox5Position.IntegralHeight = false;
            this.comboBox5Position.Items.AddRange(new object[] {
            "P1",
            "P2"});
            this.comboBox5Position.Location = new System.Drawing.Point(1092, 302);
            this.comboBox5Position.Name = "comboBox5Position";
            this.comboBox5Position.Size = new System.Drawing.Size(151, 27);
            this.comboBox5Position.TabIndex = 250;
            // 
            // comboBox4RackNumber
            // 
            this.comboBox4RackNumber.Font = new System.Drawing.Font("Calibri", 12F);
            this.comboBox4RackNumber.FormattingEnabled = true;
            this.comboBox4RackNumber.IntegralHeight = false;
            this.comboBox4RackNumber.Items.AddRange(new object[] {
            "C1 Cupboard",
            "C2 Cupboard",
            "Cantilever",
            "Pallet",
            "CL1",
            "CL2",
            "CH",
            "R1",
            "R2",
            "R3",
            "R4",
            "R5",
            "R6",
            "R7",
            "R8",
            "R9",
            "R10",
            "R11",
            "R12",
            "R13",
            "R14"});
            this.comboBox4RackNumber.Location = new System.Drawing.Point(1092, 223);
            this.comboBox4RackNumber.Name = "comboBox4RackNumber";
            this.comboBox4RackNumber.Size = new System.Drawing.Size(153, 27);
            this.comboBox4RackNumber.TabIndex = 249;
            // 
            // comboBox3SubStoreLocation
            // 
            this.comboBox3SubStoreLocation.Font = new System.Drawing.Font("Calibri", 12F);
            this.comboBox3SubStoreLocation.FormattingEnabled = true;
            this.comboBox3SubStoreLocation.IntegralHeight = false;
            this.comboBox3SubStoreLocation.Items.AddRange(new object[] {
            "First Floor",
            "Ground Floor",
            "Old Store Area"});
            this.comboBox3SubStoreLocation.Location = new System.Drawing.Point(1092, 184);
            this.comboBox3SubStoreLocation.Name = "comboBox3SubStoreLocation";
            this.comboBox3SubStoreLocation.Size = new System.Drawing.Size(153, 27);
            this.comboBox3SubStoreLocation.TabIndex = 248;
            this.comboBox3SubStoreLocation.SelectedIndexChanged += new System.EventHandler(this.comboBox3SubStoreLocation_SelectedIndexChanged);
            // 
            // comboBox2StoreNameLocation
            // 
            this.comboBox2StoreNameLocation.Font = new System.Drawing.Font("Calibri", 12F);
            this.comboBox2StoreNameLocation.FormattingEnabled = true;
            this.comboBox2StoreNameLocation.IntegralHeight = false;
            this.comboBox2StoreNameLocation.Items.AddRange(new object[] {
            "Main Store",
            "De-Centralised",
            "Kanban Shop Floor"});
            this.comboBox2StoreNameLocation.Location = new System.Drawing.Point(1092, 141);
            this.comboBox2StoreNameLocation.Name = "comboBox2StoreNameLocation";
            this.comboBox2StoreNameLocation.Size = new System.Drawing.Size(153, 27);
            this.comboBox2StoreNameLocation.TabIndex = 247;
            this.comboBox2StoreNameLocation.SelectedIndexChanged += new System.EventHandler(this.comboBox2StoreNameLocation_SelectedIndexChanged);
            // 
            // comboBox1ItemCodeLocation
            // 
            this.comboBox1ItemCodeLocation.Font = new System.Drawing.Font("Calibri", 12F);
            this.comboBox1ItemCodeLocation.FormattingEnabled = true;
            this.comboBox1ItemCodeLocation.IntegralHeight = false;
            this.comboBox1ItemCodeLocation.Location = new System.Drawing.Point(1092, 104);
            this.comboBox1ItemCodeLocation.Name = "comboBox1ItemCodeLocation";
            this.comboBox1ItemCodeLocation.Size = new System.Drawing.Size(153, 27);
            this.comboBox1ItemCodeLocation.TabIndex = 246;
            this.comboBox1ItemCodeLocation.SelectedIndexChanged += new System.EventHandler(this.comboBox1ItemCodeLocation_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold);
            this.label12.Location = new System.Drawing.Point(987, 141);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(85, 17);
            this.label12.TabIndex = 245;
            this.label12.Text = "Store Name";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold);
            this.label11.Location = new System.Drawing.Point(987, 108);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(74, 17);
            this.label11.TabIndex = 244;
            this.label11.Text = "Item code";
            // 
            // label11Location
            // 
            this.label11Location.AutoSize = true;
            this.label11Location.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold);
            this.label11Location.Location = new System.Drawing.Point(817, 24);
            this.label11Location.Name = "label11Location";
            this.label11Location.Size = new System.Drawing.Size(70, 17);
            this.label11Location.TabIndex = 243;
            this.label11Location.Text = "Location:";
            // 
            // comboBox1Location
            // 
            this.comboBox1Location.Font = new System.Drawing.Font("Calibri", 12F);
            this.comboBox1Location.FormattingEnabled = true;
            this.comboBox1Location.IntegralHeight = false;
            this.comboBox1Location.ItemHeight = 19;
            this.comboBox1Location.Location = new System.Drawing.Point(931, 18);
            this.comboBox1Location.Name = "comboBox1Location";
            this.comboBox1Location.Size = new System.Drawing.Size(251, 27);
            this.comboBox1Location.TabIndex = 242;
            // 
            // PrintBatchCode
            // 
            this.PrintBatchCode.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.PrintBatchCode.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.PrintBatchCode.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PrintBatchCode.Location = new System.Drawing.Point(726, 392);
            this.PrintBatchCode.Name = "PrintBatchCode";
            this.PrintBatchCode.Size = new System.Drawing.Size(137, 33);
            this.PrintBatchCode.TabIndex = 241;
            this.PrintBatchCode.Text = "Print Batch Code";
            this.PrintBatchCode.UseVisualStyleBackColor = false;
            this.PrintBatchCode.Click += new System.EventHandler(this.GeneratePdfBatchCode);
            // 
            // btnprintgin
            // 
            this.btnprintgin.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnprintgin.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnprintgin.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnprintgin.Location = new System.Drawing.Point(869, 392);
            this.btnprintgin.Name = "btnprintgin";
            this.btnprintgin.Size = new System.Drawing.Size(103, 33);
            this.btnprintgin.TabIndex = 240;
            this.btnprintgin.Text = "Print GIN";
            this.btnprintgin.UseVisualStyleBackColor = false;
            this.btnprintgin.Click += new System.EventHandler(this.btnprintgin_Click);
            // 
            // dgvprintpreview
            // 
            this.dgvprintpreview.AllowUserToAddRows = false;
            this.dgvprintpreview.AllowUserToDeleteRows = false;
            this.dgvprintpreview.AllowUserToResizeRows = false;
            this.dgvprintpreview.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvprintpreview.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.Desktop;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvprintpreview.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvprintpreview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvprintpreview.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ItemCode,
            this.ItemDescription,
            this.POQTY,
            this.SupplyQty,
            this.UnitCost,
            this.Amount,
            this.location,
            this.printCount,
            this.Printbtn});
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvprintpreview.DefaultCellStyle = dataGridViewCellStyle7;
            this.dgvprintpreview.Location = new System.Drawing.Point(7, 108);
            this.dgvprintpreview.MultiSelect = false;
            this.dgvprintpreview.Name = "dgvprintpreview";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvprintpreview.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dgvprintpreview.RowHeadersVisible = false;
            this.dgvprintpreview.RowHeadersWidth = 62;
            this.dgvprintpreview.Size = new System.Drawing.Size(965, 279);
            this.dgvprintpreview.TabIndex = 238;
            // 
            // ItemCode
            // 
            this.ItemCode.DataPropertyName = "ItemCode";
            this.ItemCode.HeaderText = "ItemCode";
            this.ItemCode.MinimumWidth = 8;
            this.ItemCode.Name = "ItemCode";
            this.ItemCode.ReadOnly = true;
            this.ItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemCode.Width = 81;
            // 
            // ItemDescription
            // 
            this.ItemDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ItemDescription.DataPropertyName = "ItemDescription";
            this.ItemDescription.HeaderText = "ItemDescription";
            this.ItemDescription.MinimumWidth = 8;
            this.ItemDescription.Name = "ItemDescription";
            this.ItemDescription.ReadOnly = true;
            this.ItemDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // POQTY
            // 
            this.POQTY.DataPropertyName = "POQty";
            this.POQTY.HeaderText = "PO Qty";
            this.POQTY.MinimumWidth = 8;
            this.POQTY.Name = "POQTY";
            this.POQTY.ReadOnly = true;
            this.POQTY.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.POQTY.Width = 65;
            // 
            // SupplyQty
            // 
            this.SupplyQty.DataPropertyName = "SupplyQty";
            this.SupplyQty.HeaderText = "Supply Qty";
            this.SupplyQty.MinimumWidth = 8;
            this.SupplyQty.Name = "SupplyQty";
            this.SupplyQty.ReadOnly = true;
            this.SupplyQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SupplyQty.Width = 89;
            // 
            // UnitCost
            // 
            this.UnitCost.DataPropertyName = "Rate";
            this.UnitCost.HeaderText = "Rate";
            this.UnitCost.MinimumWidth = 8;
            this.UnitCost.Name = "UnitCost";
            this.UnitCost.ReadOnly = true;
            this.UnitCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitCost.Width = 48;
            // 
            // Amount
            // 
            this.Amount.DataPropertyName = "Amount";
            dataGridViewCellStyle6.Format = "N2";
            dataGridViewCellStyle6.NullValue = "0";
            this.Amount.DefaultCellStyle = dataGridViewCellStyle6;
            this.Amount.HeaderText = "Amount";
            this.Amount.MinimumWidth = 8;
            this.Amount.Name = "Amount";
            this.Amount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Amount.Width = 67;
            // 
            // location
            // 
            this.location.DataPropertyName = "location";
            this.location.HeaderText = "Location";
            this.location.MinimumWidth = 8;
            this.location.Name = "location";
            this.location.ReadOnly = true;
            this.location.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.location.Width = 73;
            // 
            // printCount
            // 
            this.printCount.DataPropertyName = "printCount";
            this.printCount.HeaderText = "Print Count";
            this.printCount.MinimumWidth = 8;
            this.printCount.Name = "printCount";
            this.printCount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.printCount.Width = 91;
            // 
            // Printbtn
            // 
            this.Printbtn.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Printbtn.HeaderText = "Print Lable";
            this.Printbtn.MinimumWidth = 8;
            this.Printbtn.Name = "Printbtn";
            this.Printbtn.Text = "Print";
            this.Printbtn.UseColumnTextForButtonValue = true;
            this.Printbtn.Visible = false;
            this.Printbtn.Width = 89;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(16, 14);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(98, 17);
            this.label10.TabIndex = 204;
            this.label10.Text = "GIN Number:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(15, 76);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(99, 17);
            this.label8.TabIndex = 196;
            this.label8.Text = "Vendor Code:";
            // 
            // txtprintvendorname
            // 
            this.txtprintvendorname.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtprintvendorname.Location = new System.Drawing.Point(123, 74);
            this.txtprintvendorname.Name = "txtprintvendorname";
            this.txtprintvendorname.ReadOnly = true;
            this.txtprintvendorname.Size = new System.Drawing.Size(255, 22);
            this.txtprintvendorname.TabIndex = 195;
            // 
            // cmbprintginnumber
            // 
            this.cmbprintginnumber.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbprintginnumber.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbprintginnumber.DropDownHeight = 130;
            this.cmbprintginnumber.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbprintginnumber.FormattingEnabled = true;
            this.cmbprintginnumber.IntegralHeight = false;
            this.cmbprintginnumber.ItemHeight = 15;
            this.cmbprintginnumber.Location = new System.Drawing.Point(123, 9);
            this.cmbprintginnumber.Name = "cmbprintginnumber";
            this.cmbprintginnumber.Size = new System.Drawing.Size(255, 23);
            this.cmbprintginnumber.TabIndex = 203;
            this.cmbprintginnumber.SelectedIndexChanged += new System.EventHandler(this.cmbprintginnumber_SelectedIndexChanged);
            // 
            // txtprintvendorcode
            // 
            this.txtprintvendorcode.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtprintvendorcode.Location = new System.Drawing.Point(508, 65);
            this.txtprintvendorcode.Multiline = true;
            this.txtprintvendorcode.Name = "txtprintvendorcode";
            this.txtprintvendorcode.ReadOnly = true;
            this.txtprintvendorcode.Size = new System.Drawing.Size(283, 37);
            this.txtprintvendorcode.TabIndex = 197;
            // 
            // txtprintprojectname
            // 
            this.txtprintprojectname.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtprintprojectname.Location = new System.Drawing.Point(508, 14);
            this.txtprintprojectname.Multiline = true;
            this.txtprintprojectname.Name = "txtprintprojectname";
            this.txtprintprojectname.ReadOnly = true;
            this.txtprintprojectname.Size = new System.Drawing.Size(283, 41);
            this.txtprintprojectname.TabIndex = 202;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(396, 77);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(102, 17);
            this.label7.TabIndex = 198;
            this.label7.Text = "Vendor Name:";
            // 
            // txtprintprojectcode
            // 
            this.txtprintprojectcode.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtprintprojectcode.Location = new System.Drawing.Point(123, 42);
            this.txtprintprojectcode.Name = "txtprintprojectcode";
            this.txtprintprojectcode.ReadOnly = true;
            this.txtprintprojectcode.Size = new System.Drawing.Size(255, 22);
            this.txtprintprojectcode.TabIndex = 201;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(399, 18);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 17);
            this.label6.TabIndex = 199;
            this.label6.Text = "Project Desc:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(15, 43);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 17);
            this.label5.TabIndex = 200;
            this.label5.Text = "Project Code:";
            // 
            // pnVendorPanel
            // 
            this.pnVendorPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnVendorPanel.Controls.Add(this.lblvendorname);
            this.pnVendorPanel.Controls.Add(this.cmbvendorlist);
            this.pnVendorPanel.Location = new System.Drawing.Point(40, 165);
            this.pnVendorPanel.Name = "pnVendorPanel";
            this.pnVendorPanel.Size = new System.Drawing.Size(520, 63);
            this.pnVendorPanel.TabIndex = 33;
            this.pnVendorPanel.Visible = false;
            // 
            // lblvendorname
            // 
            this.lblvendorname.AutoSize = true;
            this.lblvendorname.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblvendorname.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblvendorname.Location = new System.Drawing.Point(46, 14);
            this.lblvendorname.Name = "lblvendorname";
            this.lblvendorname.Size = new System.Drawing.Size(110, 19);
            this.lblvendorname.TabIndex = 244;
            this.lblvendorname.Text = "Vendor Name :";
            // 
            // cmbvendorlist
            // 
            this.cmbvendorlist.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbvendorlist.DropDownHeight = 130;
            this.cmbvendorlist.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbvendorlist.FormattingEnabled = true;
            this.cmbvendorlist.IntegralHeight = false;
            this.cmbvendorlist.ItemHeight = 15;
            this.cmbvendorlist.Location = new System.Drawing.Point(158, 12);
            this.cmbvendorlist.Name = "cmbvendorlist";
            this.cmbvendorlist.Size = new System.Drawing.Size(302, 23);
            this.cmbvendorlist.TabIndex = 243;
            // 
            // pnProjectCodePanel
            // 
            this.pnProjectCodePanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnProjectCodePanel.Controls.Add(this.cmbProjectCode);
            this.pnProjectCodePanel.Controls.Add(this.label1);
            this.pnProjectCodePanel.Controls.Add(this.txtProjectCode);
            this.pnProjectCodePanel.Controls.Add(this.lblSelectedProjectCode);
            this.pnProjectCodePanel.Controls.Add(this.lblItemDiscription);
            this.pnProjectCodePanel.Location = new System.Drawing.Point(38, 167);
            this.pnProjectCodePanel.Name = "pnProjectCodePanel";
            this.pnProjectCodePanel.Size = new System.Drawing.Size(743, 62);
            this.pnProjectCodePanel.TabIndex = 30;
            this.pnProjectCodePanel.Visible = false;
            // 
            // cmbProjectCode
            // 
            this.cmbProjectCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProjectCode.DropDownHeight = 160;
            this.cmbProjectCode.DropDownWidth = 121;
            this.cmbProjectCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProjectCode.FormattingEnabled = true;
            this.cmbProjectCode.IntegralHeight = false;
            this.cmbProjectCode.ItemHeight = 19;
            this.cmbProjectCode.Items.AddRange(new object[] {
            "None"});
            this.cmbProjectCode.Location = new System.Drawing.Point(106, 5);
            this.cmbProjectCode.Name = "cmbProjectCode";
            this.cmbProjectCode.Size = new System.Drawing.Size(272, 27);
            this.cmbProjectCode.Sorted = true;
            this.cmbProjectCode.TabIndex = 3;
            this.cmbProjectCode.SelectedIndexChanged += new System.EventHandler(this.cmbProjectCode_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(384, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 17);
            this.label1.TabIndex = 200;
            this.label1.Text = "Name :";
            // 
            // txtProjectCode
            // 
            this.txtProjectCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProjectCode.Location = new System.Drawing.Point(442, 3);
            this.txtProjectCode.Multiline = true;
            this.txtProjectCode.Name = "txtProjectCode";
            this.txtProjectCode.ReadOnly = true;
            this.txtProjectCode.Size = new System.Drawing.Size(294, 49);
            this.txtProjectCode.TabIndex = 27;
            // 
            // lblSelectedProjectCode
            // 
            this.lblSelectedProjectCode.AutoSize = true;
            this.lblSelectedProjectCode.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.lblSelectedProjectCode.Location = new System.Drawing.Point(3, 9);
            this.lblSelectedProjectCode.Name = "lblSelectedProjectCode";
            this.lblSelectedProjectCode.Size = new System.Drawing.Size(104, 19);
            this.lblSelectedProjectCode.TabIndex = 2;
            this.lblSelectedProjectCode.Text = "Project Code :";
            // 
            // lblItemDiscription
            // 
            this.lblItemDiscription.AutoSize = true;
            this.lblItemDiscription.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemDiscription.Location = new System.Drawing.Point(280, 14);
            this.lblItemDiscription.Name = "lblItemDiscription";
            this.lblItemDiscription.Size = new System.Drawing.Size(0, 17);
            this.lblItemDiscription.TabIndex = 15;
            // 
            // ItemLabelPrintpanel
            // 
            this.ItemLabelPrintpanel.BackColor = System.Drawing.Color.LightGray;
            this.ItemLabelPrintpanel.Controls.Add(this.checkBoxPrintLocation);
            this.ItemLabelPrintpanel.Controls.Add(this.textBox1LableCount);
            this.ItemLabelPrintpanel.Controls.Add(this.label18);
            this.ItemLabelPrintpanel.Controls.Add(this.comboBox1LabelPrintItemCode);
            this.ItemLabelPrintpanel.Controls.Add(this.checkBox2ItemCode);
            this.ItemLabelPrintpanel.Controls.Add(this.comboBox2LabelPrintLocation);
            this.ItemLabelPrintpanel.Controls.Add(this.checkBox1Location);
            this.ItemLabelPrintpanel.Location = new System.Drawing.Point(5, 159);
            this.ItemLabelPrintpanel.Margin = new System.Windows.Forms.Padding(2);
            this.ItemLabelPrintpanel.Name = "ItemLabelPrintpanel";
            this.ItemLabelPrintpanel.Size = new System.Drawing.Size(813, 448);
            this.ItemLabelPrintpanel.TabIndex = 244;
            this.ItemLabelPrintpanel.Visible = false;
            this.ItemLabelPrintpanel.Paint += new System.Windows.Forms.PaintEventHandler(this.ItemLabelPrintpanel_Paint);
            // 
            // textBox1LableCount
            // 
            this.textBox1LableCount.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold);
            this.textBox1LableCount.Location = new System.Drawing.Point(131, 75);
            this.textBox1LableCount.Name = "textBox1LableCount";
            this.textBox1LableCount.Size = new System.Drawing.Size(71, 29);
            this.textBox1LableCount.TabIndex = 7;
            this.textBox1LableCount.Visible = false;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold);
            this.label18.Location = new System.Drawing.Point(13, 79);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(111, 22);
            this.label18.TabIndex = 6;
            this.label18.Text = "Label Count";
            this.label18.Visible = false;
            // 
            // comboBox1LabelPrintItemCode
            // 
            this.comboBox1LabelPrintItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.comboBox1LabelPrintItemCode.FormattingEnabled = true;
            this.comboBox1LabelPrintItemCode.IntegralHeight = false;
            this.comboBox1LabelPrintItemCode.ItemHeight = 19;
            this.comboBox1LabelPrintItemCode.Location = new System.Drawing.Point(131, 27);
            this.comboBox1LabelPrintItemCode.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox1LabelPrintItemCode.Name = "comboBox1LabelPrintItemCode";
            this.comboBox1LabelPrintItemCode.Size = new System.Drawing.Size(173, 27);
            this.comboBox1LabelPrintItemCode.TabIndex = 2;
            this.comboBox1LabelPrintItemCode.SelectedIndexChanged += new System.EventHandler(this.comboBox1LabelPrintItemCode_SelectedIndexChanged);
            // 
            // checkBox2ItemCode
            // 
            this.checkBox2ItemCode.AutoSize = true;
            this.checkBox2ItemCode.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold);
            this.checkBox2ItemCode.Location = new System.Drawing.Point(17, 27);
            this.checkBox2ItemCode.Margin = new System.Windows.Forms.Padding(2);
            this.checkBox2ItemCode.Name = "checkBox2ItemCode";
            this.checkBox2ItemCode.Size = new System.Drawing.Size(114, 26);
            this.checkBox2ItemCode.TabIndex = 5;
            this.checkBox2ItemCode.Text = "Item Code";
            this.checkBox2ItemCode.UseVisualStyleBackColor = true;
            this.checkBox2ItemCode.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // comboBox2LabelPrintLocation
            // 
            this.comboBox2LabelPrintLocation.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.comboBox2LabelPrintLocation.FormattingEnabled = true;
            this.comboBox2LabelPrintLocation.IntegralHeight = false;
            this.comboBox2LabelPrintLocation.ItemHeight = 19;
            this.comboBox2LabelPrintLocation.Location = new System.Drawing.Point(429, 27);
            this.comboBox2LabelPrintLocation.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox2LabelPrintLocation.Name = "comboBox2LabelPrintLocation";
            this.comboBox2LabelPrintLocation.Size = new System.Drawing.Size(173, 27);
            this.comboBox2LabelPrintLocation.TabIndex = 3;
            this.comboBox2LabelPrintLocation.SelectedIndexChanged += new System.EventHandler(this.comboBox2LabelPrintLocation_SelectedIndexChanged);
            // 
            // checkBox1Location
            // 
            this.checkBox1Location.AutoSize = true;
            this.checkBox1Location.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold);
            this.checkBox1Location.Location = new System.Drawing.Point(333, 26);
            this.checkBox1Location.Margin = new System.Windows.Forms.Padding(2);
            this.checkBox1Location.Name = "checkBox1Location";
            this.checkBox1Location.Size = new System.Drawing.Size(101, 26);
            this.checkBox1Location.TabIndex = 4;
            this.checkBox1Location.Text = "Location";
            this.checkBox1Location.UseVisualStyleBackColor = true;
            this.checkBox1Location.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // checkBoxPrintLocation
            // 
            this.checkBoxPrintLocation.AutoSize = true;
            this.checkBoxPrintLocation.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold);
            this.checkBoxPrintLocation.Location = new System.Drawing.Point(333, 73);
            this.checkBoxPrintLocation.Name = "checkBoxPrintLocation";
            this.checkBoxPrintLocation.Size = new System.Drawing.Size(198, 26);
            this.checkBoxPrintLocation.TabIndex = 8;
            this.checkBoxPrintLocation.Text = "Print Location Lable";
            this.checkBoxPrintLocation.UseVisualStyleBackColor = true;
            // 
            // frmReports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1327, 642);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmReports";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reports";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmReports_FormClosing);
            this.Load += new System.EventHandler(this.frmReports_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.InOutWardpanel.ResumeLayout(false);
            this.stockBalancepanel.ResumeLayout(false);
            this.stockBalancepanel.PerformLayout();
            this.pnGenaralPanel.ResumeLayout(false);
            this.pnGenaralPanel.PerformLayout();
            this.pnoneyear.ResumeLayout(false);
            this.pnoneyear.PerformLayout();
            this.pnginprint.ResumeLayout(false);
            this.pnginprint.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvprintpreview)).EndInit();
            this.pnVendorPanel.ResumeLayout(false);
            this.pnVendorPanel.PerformLayout();
            this.pnProjectCodePanel.ResumeLayout(false);
            this.pnProjectCodePanel.PerformLayout();
            this.ItemLabelPrintpanel.ResumeLayout(false);
            this.ItemLabelPrintpanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblItemDiscription;
        private System.Windows.Forms.DateTimePicker dptToDate;
        private System.Windows.Forms.DateTimePicker dtpFromDate;
        private System.Windows.Forms.Label lblToDate;
        private System.Windows.Forms.Label lblFromdate;
        private System.Windows.Forms.ComboBox cmbProjectCode;
        private System.Windows.Forms.Label lblSelectedProjectCode;
        private System.Windows.Forms.Label lblTables;
        private System.Windows.Forms.DateTimePicker dtptwelve;
        private System.Windows.Forms.Label lblTwelveMonths;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.TextBox txtProjectCode;
        private System.Windows.Forms.Button btnexcelreport;
        private System.Windows.Forms.Panel pnGenaralPanel;
        private System.Windows.Forms.Panel pnProjectCodePanel;
        private System.Windows.Forms.ComboBox cmbReport;
        private System.Windows.Forms.Panel pnVendorPanel;
        private System.Windows.Forms.Label lblvendorname;
        private System.Windows.Forms.ComboBox cmbvendorlist;
        private System.Windows.Forms.Panel pnginprint;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtprintvendorname;
        private System.Windows.Forms.ComboBox cmbprintginnumber;
        private System.Windows.Forms.TextBox txtprintvendorcode;
        private System.Windows.Forms.TextBox txtprintprojectname;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtprintprojectcode;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dgvprintpreview;
        private System.Windows.Forms.Button btnprintgin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnoneyear;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn POQTY;
        private System.Windows.Forms.DataGridViewTextBoxColumn SupplyQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn printCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn location;//location
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
        private System.Windows.Forms.DataGridViewButtonColumn Printbtn;
        private System.Windows.Forms.Button PrintBatchCode;
        private System.Windows.Forms.ComboBox FilterTypecomboBox1;
        private System.Windows.Forms.ComboBox subStoreNamecomboBox2;
        private System.Windows.Forms.ComboBox storeNamecomboBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox CategorycomboBox4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel stockBalancepanel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label11Location;
        private System.Windows.Forms.ComboBox comboBox1Location;
        private System.Windows.Forms.Panel ItemLabelPrintpanel;
        private System.Windows.Forms.ComboBox comboBox2LabelPrintLocation;
        private System.Windows.Forms.ComboBox comboBox1LabelPrintItemCode;
        private System.Windows.Forms.CheckBox checkBox2ItemCode;
        private System.Windows.Forms.CheckBox checkBox1Location;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox comboBox5Position;
        private System.Windows.Forms.ComboBox comboBox4RackNumber;
        private System.Windows.Forms.ComboBox comboBox3SubStoreLocation;
        private System.Windows.Forms.ComboBox comboBox2StoreNameLocation;
        private System.Windows.Forms.ComboBox comboBox1ItemCodeLocation;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button LocationUpdatebutton;
        private System.Windows.Forms.ComboBox comboBox1Level;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox1LableCount;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel InOutWardpanel;
        private System.Windows.Forms.ComboBox comboBoxINOutWard;
        private System.Windows.Forms.CheckBox checkBoxPrintLocation;
    }
}
