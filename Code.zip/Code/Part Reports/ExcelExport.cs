﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Erp_Project_With_Buttons.Part_Reports
//{
  //  class ExcelExport
    //{
    //}
//}

using System;
using System.Data;
using System.IO;
using System.Xml;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;


namespace Erp_Project_With_Buttons.Part_Reports
{
    class ExcelExport
    {
        public static void DataTableToXlsx(DataTable table, string filePath, string sheetName = "Export", string itemCode = "", string description = "")
        {
            if (table == null) throw new ArgumentNullException(nameof(table));
            if (string.IsNullOrWhiteSpace(filePath)) throw new ArgumentNullException(nameof(filePath));

            using (var doc = SpreadsheetDocument.Create(filePath, SpreadsheetDocumentType.Workbook))
            {
                var wbPart = doc.AddWorkbookPart();
                wbPart.Workbook = new Workbook();

                // Add styles part for bold formatting
                var stylesPart = wbPart.AddNewPart<WorkbookStylesPart>();
                stylesPart.Stylesheet = CreateStylesheet();

                var wsPart = wbPart.AddNewPart<WorksheetPart>();
                wsPart.Worksheet = new Worksheet(new SheetData());

                var sheets = wbPart.Workbook.AppendChild(new Sheets());
                var sheet = new Sheet
                {
                    Id = wbPart.GetIdOfPart(wsPart),
                    SheetId = 1,
                    Name = string.IsNullOrWhiteSpace(sheetName) ? "Export" : sheetName
                };
                sheets.Append(sheet);

                var sheetData = wsPart.Worksheet.GetFirstChild<SheetData>();

                uint currentRow = 1;

                // Add Item Code row (Bold)
                if (!string.IsNullOrWhiteSpace(itemCode))
                {
                    var itemCodeRow = new Row { RowIndex = currentRow };
                    var itemCodeLabelCell = CreateStyledCell(1, currentRow, "Item Code:", 1); // Style 1 = Bold
                    var itemCodeValueCell = CreateStyledCell(2, currentRow, itemCode, 1);
                    itemCodeRow.Append(itemCodeLabelCell);
                    itemCodeRow.Append(itemCodeValueCell);
                    sheetData.Append(itemCodeRow);
                    currentRow++;
                }

                // Add Description row (Bold)
                if (!string.IsNullOrWhiteSpace(description))
                {
                    var descRow = new Row { RowIndex = currentRow };
                    var descLabelCell = CreateStyledCell(1, currentRow, "Description:", 1); // Style 1 = Bold
                    var descValueCell = CreateStyledCell(2, currentRow, description, 1);
                    descRow.Append(descLabelCell);
                    descRow.Append(descValueCell);
                    sheetData.Append(descRow);
                    currentRow++;
                }

                // Add empty row for spacing if header details were added
                if (!string.IsNullOrWhiteSpace(itemCode) || !string.IsNullOrWhiteSpace(description))
                {
                    currentRow++;
                }

                // Header row (Bold)
                var headerRow = new Row { RowIndex = currentRow };
                for (uint c = 0; c < table.Columns.Count; c++)
                    headerRow.Append(CreateStyledCell(c + 1, currentRow, table.Columns[(int)c].ColumnName, 1)); // Style 1 = Bold
                sheetData.Append(headerRow);
                currentRow++;

                // Data rows
                for (int r = 0; r < table.Rows.Count; r++)
                {
                    var row = new Row { RowIndex = currentRow };
                    for (uint c = 0; c < table.Columns.Count; c++)
                        row.Append(CreateCell(c + 1, currentRow, SanitizeForXml(table.Rows[r][(int)c].ToString())));
                    sheetData.Append(row);
                    currentRow++;
                }

                // Auto-size columns (optional but recommended)
                var columns = new Columns();
                for (uint c = 1; c <= table.Columns.Count; c++)
                {
                    columns.Append(new Column
                    {
                        Min = c,
                        Max = c,
                        Width = 20,
                        CustomWidth = true
                    });
                }
                wsPart.Worksheet.InsertAt(columns, 0);

                wbPart.Workbook.Save();
            }
        }

        public static string SanitizeForXml(string input)
        {
            if (string.IsNullOrEmpty(input)) return input;

            var sb = new System.Text.StringBuilder(input.Length);
            foreach (char c in input)
            {
                if (XmlConvert.IsXmlChar(c))
                    sb.Append(c);
                // else drop it
            }
            return sb.ToString();
        }

        private static Stylesheet CreateStylesheet()
        {
            var stylesheet = new Stylesheet();

            // Add fonts
            var fonts = new Fonts();
            fonts.Append(new Font()); // Default font (Index 0)
            fonts.Append(new Font(new Bold())); // Bold font (Index 1)
            stylesheet.Append(fonts);

            // Add fills
            var fills = new Fills();
            fills.Append(new Fill()); // Default fill (Index 0)
            stylesheet.Append(fills);

            // Add borders
            var borders = new Borders();
            borders.Append(new Borders()); // Default border (Index 0)
            stylesheet.Append(borders);

            // Add cell formats
            var cellFormats = new CellFormats();
            cellFormats.Append(new CellFormat()); // Default format (Index 0)
            cellFormats.Append(new CellFormat { FontId = 1 }); // Bold format (Index 1)
            stylesheet.Append(cellFormats);

            return stylesheet;
        }

        private static Cell CreateStyledCell(uint colIndex, uint rowIndex, string text, uint styleIndex)
        {
            string cellRef = $"{GetColumnName(colIndex)}{rowIndex}";
            return new Cell
            {
                CellReference = cellRef,
                DataType = CellValues.String,
                CellValue = new CellValue(text ?? string.Empty),
                StyleIndex = styleIndex
            };
        }

        private static Cell CreateCell(uint colIndex, uint rowIndex, object value)
        {
            string cellRef = $"{GetColumnName(colIndex)}{rowIndex}";
            if (value == null || value == DBNull.Value)
                return new Cell { CellReference = cellRef, DataType = CellValues.String, CellValue = new CellValue(string.Empty) };

            if (value is DateTime dt)
            {
                return new Cell
                {
                    CellReference = cellRef,
                    DataType = CellValues.Number,
                    CellValue = new CellValue(dt.ToOADate().ToString(System.Globalization.CultureInfo.InvariantCulture))
                };
            }

            double num;
            if (double.TryParse(Convert.ToString(value), out num))
                return new Cell
                {
                    CellReference = cellRef,
                    DataType = CellValues.Number,
                    CellValue = new CellValue(num.ToString(System.Globalization.CultureInfo.InvariantCulture))
                };

            return new Cell
            {
                CellReference = cellRef,
                DataType = CellValues.String,
                CellValue = new CellValue(Convert.ToString(value))
            };
        }

        private static string GetColumnName(uint index)
        {
            string name = string.Empty;
            while (index > 0)
            {
                uint mod = (index - 1) % 26;
                name = (char)('A' + mod) + name;
                index = (index - mod) / 26;
            }
            return name;
        }
    }
}