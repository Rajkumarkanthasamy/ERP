﻿
using System;
using System.Data;
using System.IO;
using System.Xml;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;

public static class CsvExporter
{
    public static void DataTableToXlsx(DataTable table, string filePath, string sheetName = "Export")
    {
        if (table == null) throw new ArgumentNullException(nameof(table));
        if (string.IsNullOrWhiteSpace(filePath)) throw new ArgumentNullException(nameof(filePath));

        using (var doc = SpreadsheetDocument.Create(filePath, SpreadsheetDocumentType.Workbook))
        {
            var wbPart = doc.AddWorkbookPart();
            wbPart.Workbook = new Workbook();

            var wsPart = wbPart.AddNewPart<WorksheetPart>();
            wsPart.Worksheet = new Worksheet(new SheetData());

            var sheets = wbPart.Workbook.AppendChild(new Sheets());
            var sheet = new Sheet
            {
                Id = wbPart.GetIdOfPart(wsPart),
                SheetId = 1,
                Name = string.IsNullOrWhiteSpace(sheetName) ? "Export" : sheetName
            };
            sheets.Append(sheet);

            var sheetData = wsPart.Worksheet.GetFirstChild<SheetData>();

            // Header row
            var headerRow = new Row { RowIndex = 1 };
            for (uint c = 0; c < table.Columns.Count; c++)
                headerRow.Append(CreateTextCell(c + 1, 1, table.Columns[(int)c].ColumnName));
            sheetData.Append(headerRow);

            // Data rows
            for (int r = 0; r < table.Rows.Count; r++)
            {
                var row = new Row { RowIndex = (uint)(r + 2) };
                for (uint c = 0; c < table.Columns.Count; c++)
                    // row.Append(CreateCell(c + 1, (uint)(r + 2), table.Rows[r][(int)c]));
                     row.Append(CreateCell(c + 1, (uint)(r + 2), SanitizeForXml(table.Rows[r][(int)c].ToString()) ) );
                    sheetData.Append(row);
            }

            wbPart.Workbook.Save();
        }
    }


    public static string SanitizeForXml(string input)
    {
        if (string.IsNullOrEmpty(input)) return input;

        var sb = new System.Text.StringBuilder(input.Length);
        foreach (char c in input)
        {
            if (XmlConvert.IsXmlChar(c))
                sb.Append(c);
            // else drop it
        }
        return sb.ToString();
    }


    private static Cell CreateCell(uint colIndex, uint rowIndex, object value)
    {
        string cellRef = $"{GetColumnName(colIndex)}{rowIndex}";
        if (value == null || value == DBNull.Value)
            return new Cell { CellReference = cellRef, DataType = CellValues.String, CellValue = new CellValue(string.Empty) };

        if (value is DateTime dt)
        {
            // Excel serial date number (styling for date display would be added via cell styles if needed)
            return new Cell { CellReference = cellRef, DataType = CellValues.Number, CellValue = new CellValue(dt.ToOADate().ToString(System.Globalization.CultureInfo.InvariantCulture)) };
        }

        // Try numeric
        double num;
        if (double.TryParse(Convert.ToString(value), out num))
            return new Cell { CellReference = cellRef, DataType = CellValues.Number, CellValue = new CellValue(num.ToString(System.Globalization.CultureInfo.InvariantCulture)) };

        // Fallback to plain string
        return new Cell { CellReference = cellRef, DataType = CellValues.String, CellValue = new CellValue(Convert.ToString(value)) };
    }

    private static Cell CreateTextCell(uint colIndex, uint rowIndex, string text)
    {
        string cellRef = $"{GetColumnName(colIndex)}{rowIndex}";
        return new Cell { CellReference = cellRef, DataType = CellValues.String, CellValue = new CellValue(text ?? string.Empty) };
    }

    private static string GetColumnName(uint index)
    {
        string name = string.Empty;
        while (index > 0)
        {
            uint mod = (index - 1) % 26;
            name = (char)('A' + mod) + name;
            index = (index - mod) / 26;
        }
        return name;
    }

}
