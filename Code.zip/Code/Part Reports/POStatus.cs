﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;
using System.IO;
using System.Diagnostics;
using System.Globalization;
using Outlook = Microsoft.Office.Interop.Outlook;


namespace Erp_Project_With_Buttons.Part_Reports
{
  //  public partial class POStatus : Form
    //{
      //  public POStatus()
      //  {
      //      InitializeComponent();
      //  }

  //  }

    public partial class POStatus : Form
    {
        public POStatus()
        {
            InitializeComponent();

            // Events
            tabControl1.SelectedIndexChanged += tabControl1_SelectedIndexChanged;
            this.Load += POStatus_Load;
        }

        private void POStatus_Load(object sender, EventArgs e)
        {
            // Set default tab
            tabControl1.SelectedIndex = 0;

            // Add a button to Tab 1
            Button btn = new Button();
            btn.Text = "Load Data";
            btn.Location = new Point(30, 30);
            btn.Click += Btn_Click;

            tabPage1.Controls.Add(btn);
        }

        private void Btn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Button inside Tab clicked!");
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Switched to: " + tabControl1.SelectedTab.Text);
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }

}



