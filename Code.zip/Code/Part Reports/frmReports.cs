﻿#region NameSpace Declaration
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.Globalization;
using System.Collections;

using iTextSharp.text;
using iTextSharp.text.pdf;
using QRCoder;
using Aspose.Cells;
using Rectangle = iTextSharp.text.Rectangle;




#endregion

namespace Erp_Project_With_Buttons
{
    public partial class frmReports : Form
    {
        #region DataTables
        Excel ex = new Excel();
        frmForm2 frm = new frmForm2();
        DataSet Exceldataset = new DataSet();
        Global GLobalClass = new Global();
        SqlCommand cmd = new SqlCommand();
        SqlDataAdapter sqldataadapter = new SqlDataAdapter();
        DataTable dtWIPTable = new DataTable();
        DataTable DTProjectList = new DataTable();
        DataTable dtReciept = new DataTable();
        DataTable DtProjectIssued = new DataTable();
        DataTable DtProjectName = new DataTable();
        DataTable dtProductionTable = new DataTable();
        DataTable dtProjectItemReturn = new DataTable();
        DataTable dtAllJobWork = new DataTable();
        DataTable dtJobIssuedList = new DataTable();
        DataTable dtJobIssue = new DataTable();
        DataAccessLayer DAL = new DataAccessLayer();
        DataTable dtGINNumber = new DataTable();
        DataTable dtLocations = new DataTable();
        DataTable dtItemCodeList = new DataTable();
        
        DataTable Dt12Month = new DataTable();
        DataTable dtvendorList = new DataTable();

        List<Dictionary<string, string>> BatchCodeDataList = new List<Dictionary<string, string>>
        {

        };


        #endregion
        #region VariableDeclare
        public object Total = 0.0;
        double TotalSum;
        object sumProjectIndentCost;
        object sumProjectItemReturnCost;
        object sumProjectJobCost;
        object sumProjectJobReturnCost;
        object sumProjectTimesheetManhours;
        object sumProjectMachineUtilizationhours;


        string sProjectCode;
        string sProjectDiscription;
        string sCustomername;
        double dBasicnPacking;
        double dDiscount;
        double dExcise;
        double dVat;
        double dCST;
        double dTotal;
        double dAfterdiscount;
        double dAfterExcise;
        double FinalSum;
        string finalColLetter = string.Empty;
        string excelRange = string.Empty;
        string TotalValues = string.Empty;
        double dGrandSum = 0.0;
        Microsoft.Office.Interop.Excel._Application app1 = null;
        Microsoft.Office.Interop.Excel._Workbook workbook1 = null;
        List<string> lJWNos = new List<string>();
        #endregion

        public frmReports()
        {
            InitializeComponent();
        }
        #region Home Button Click
        private void btnHome_Click(object sender, EventArgs e)
        {
            foreach (Process process in Process.GetProcessesByName("Excel"))
            {
                process.Kill();
            }
            DialogResult res = MessageBox.Show("Are you sure you want to Exit this window?", "Exit confirmation",
             MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (res == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void lklblHome_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            foreach (Process process in Process.GetProcessesByName("Excel"))
            {
                process.Kill();
            }
            DialogResult res = MessageBox.Show("Are you sure you want to Exit this window?", "Exit confirmation",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (res == DialogResult.Yes)
            {
                this.Close();
            }
        }
        #endregion


        #region Quit Application
        private void btnQuit_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }
        #endregion
        #region Go Back to Home Panel
        private void frmReports_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            frmForm2 frm = new frmForm2();
            frm.Show();
        }
        #endregion


        #region Report Form Load
        private void frmReports_Load(object sender, EventArgs e)
        {
            //{'Project Issue', }
            dtptwelve.Format = DateTimePickerFormat.Custom;
            dtptwelve.CustomFormat = "dd-MM-yyyy";
            dtpFromDate.Format = DateTimePickerFormat.Custom;
            dtpFromDate.CustomFormat = "dd-MM-yyyy";
            dptToDate.Format = DateTimePickerFormat.Custom;
            dptToDate.CustomFormat = "dd-MM-yyyy";
            timer1.Interval = 1000;
            timer1.Enabled = true;
            Login.frmLoginForm login = new Login.frmLoginForm();
            //lblReturnedby.Text = login.GetUserDetails[2];
            // LoadEnabledReports();
            // dtGINNumber = DAL.fnprintReceipt(null, null).Tables[0];
            //foreach (DataRow dr in dtGINNumber.Rows)
            //{
            //  if (!cmbprintginnumber.Items.Contains(dr["GINNumber"].ToString()))
            //    cmbprintginnumber.Items.Add(dr["GINNumber"].ToString());
            //}

            //Location drop down
            //dtLocations = DAL.fnPrintReceiptLocationList().Tables[0];
            //foreach (DataRow dr in dtLocations.Rows)
            //{
            //  if (!comboBox1Location.Items.Contains(dr["Location"].ToString()))
            //    comboBox1Location.Items.Add(dr["Location"].ToString());
            //}

            //foreach(DataRow location in dtLocations.Rows)
            //{
            //comboBox2LabelPrintLocation
            //  if (!comboBox2LabelPrintLocation.Items.Contains(location["Location"].ToString()))
            //    comboBox2LabelPrintLocation.Items.Add(location["Location"].ToString());
            //}

            // dtItemCodeList = DAL.fnPrintReceiptItemCodeList(null, null).Tables[0];

            //foreach(DataRow item in dtItemCodeList.Rows)
            //{
            //  if (!comboBox1LabelPrintItemCode.Items.Contains(item["ItemCode"].ToString()))
            //    comboBox1LabelPrintItemCode.Items.Add(item["ItemCode"].ToString());
            //}

           
            dtGINNumber = DAL.fnprintReceipt(null, null).Tables[0];
            foreach (DataRow dr in dtGINNumber.Rows)
            {
                if (!cmbprintginnumber.Items.Contains(dr["GINNumber"].ToString()))
                    cmbprintginnumber.Items.Add(dr["GINNumber"].ToString());
            }

            // || login.GetUserDetails[2].ToLower() == "muthuramalingam"
            if (login.GetUserDetails[23] == "Accounts" || login.GetUserDetails[2].ToLower() == "ravi" || login.GetUserDetails[2].ToLower() == "thilak kumar" || login.GetUserDetails[2].ToLower() == "hebbarrk" || login.GetUserDetails[2].ToLower() == "vivek g" || login.GetUserDetails[2].ToLower() == "vishal" || login.GetUserDetails[2].ToLower() == "biss" || login.GetUserDetails[2].ToLower() == "hemanth" || login.GetUserDetails[2].ToLower() == "hemanth reddy" || login.GetUserDetails[2].ToLower() == "vishal raina")
            {
                cmbReport.Items.Clear();
                cmbReport.Items.Add("Project Issue");
                cmbReport.Items.Add("Receipt");
                cmbReport.Items.Add("Stock Balance");
                cmbReport.Items.Add("Item Label Print");
                cmbReport.Items.Add("Filter Stock Balance");
                cmbReport.Items.Add("Project Cost");
                cmbReport.Items.Add("Inventory Grading Report");
                cmbReport.Items.Add("Job Issue");
                cmbReport.Items.Add("Stock Adjusted");
                cmbReport.Items.Add("Purchase Cost");
                cmbReport.Items.Add("ItemReturn Project Issued");
                cmbReport.Items.Add("ItemReturn Job Issued");
                cmbReport.Items.Add("Consolidated GIN Report PO");
                cmbReport.Items.Add("Consolidated GIN Report PO and WO");
                cmbReport.Items.Add("Consolidated GIN Report WO");
                cmbReport.Items.Add("Vendor GIN Report PO");
                cmbReport.Items.Add("Vendor GIN Report WO");
                cmbReport.Items.Add("Print GIN");
                cmbReport.Items.Add("Vendor List");
                cmbReport.Items.Add("Transactional Spend Data");
                cmbReport.Items.Add("AP Spend Data");
                cmbReport.Items.Add("Project List");
                cmbReport.Items.Add("Standard Cost PO");
                cmbReport.Items.Add("Standard Cost WO");
                cmbReport.Items.Add("Pending PO");
                cmbReport.Items.Add("DepartmentWise Issued");
                cmbReport.Items.Add("DepartmentWise PO/WO");
                // cmbReport.Items.Add("DepartmentWise WOr");
                cmbReport.Items.Add("No of PO's Placed");
                cmbReport.Items.Add("Consolidated GIN PO Standard Cost");
                cmbReport.Items.Add("Consolidated GIN WO Standard Cost");
                cmbReport.Items.Add("Purchase Register PO");
                cmbReport.Items.Add("Riverse GIN");
                cmbReport.Items.Add("Project PO Placed");
                cmbReport.Items.Add("Gin Job Work");
                cmbReport.Items.Add("Item Usage Work Order");
                cmbReport.Items.Add("GM Approve Pending PO");
                cmbReport.Items.Add("Purchase Register WO");
                cmbReport.Items.Add("Project Transform Details");
                cmbReport.Items.Add("Project Status Update Details");
                cmbReport.Items.Add("Project Installation Status Update Details");
                cmbReport.Items.Add("Consolidated Stock Report");
                cmbReport.Items.Add("Consolidated Projects Conusmption Report");
                cmbReport.Items.Add("Customer Projects Conusmption Report");
                cmbReport.Items.Add("Cust. Project Inventory Grading Report");
                cmbReport.Items.Add("User Access Report");
                cmbReport.Items.Add("Project Document Tracking");
                cmbReport.Items.Add("Standard Item Cost");
                cmbReport.Items.Add("Job Work");
                cmbReport.Items.Add("Service GIN");
                cmbReport.Items.Add("All Stock Latest Standard Cost Report");
                cmbReport.Items.Add("All Stock Standard Cost Analysis");
                cmbReport.Items.Add("Project Master");
                cmbReport.Items.Add("Fixed Asset Register");
                cmbReport.Items.Add("Project Cost, Machine & Man hours details");
                cmbReport.Items.Add("ERP Log Report");
                cmbReport.Items.Add("ERP WAR Log Report");
            }
            else if (login.GetUserDetails[2].ToLower() == "suresh kumar"  || login.GetUserDetails[2].ToLower() == "pavana" || login.GetUserDetails[2].ToLower() == "hemanth" || login.GetUserDetails[2].ToLower() == "hemanth Reddy" || login.GetUserDetails[2].ToLower() == "pavana_sm")
            {
                cmbReport.Items.Clear();
                cmbReport.Items.Add("Project Issue");
                cmbReport.Items.Add("Receipt");
                cmbReport.Items.Add("Stock Balance");
                cmbReport.Items.Add("Item Label Print");
                cmbReport.Items.Add("Filter Stock Balance");
                //cmbReport.Items.Add("Project Cost");
                cmbReport.Items.Add("Inventory Grading Report");
                cmbReport.Items.Add("Job Issue");
                cmbReport.Items.Add("Stock Adjusted");
                //cmbReport.Items.Add("Purchase Cost");
                cmbReport.Items.Add("ItemReturn Project Issued");
                cmbReport.Items.Add("ItemReturn Job Issued");
                cmbReport.Items.Add("Consolidated GIN Report PO");
                cmbReport.Items.Add("Consolidated GIN Report PO and WO");
                cmbReport.Items.Add("Consolidated GIN Report WO");
                cmbReport.Items.Add("Vendor GIN Report PO");
                cmbReport.Items.Add("Vendor GIN Report WO");
                cmbReport.Items.Add("Print GIN");
                // cmbReport.Items.Add("Vendor List");
                //  cmbReport.Items.Add("Transactional Spend Data");
                cmbReport.Items.Add("AP Spend Data");
                cmbReport.Items.Add("Project List");
                cmbReport.Items.Add("Standard Cost PO");
                cmbReport.Items.Add("Standard Cost WO");
                //  cmbReport.Items.Add("Pending PO");
                cmbReport.Items.Add("DepartmentWise Issued");
                //  cmbReport.Items.Add("DepartmentWise PO/WO");
                //cmbReport.Items.Add("DepartmentWise WOr");
                cmbReport.Items.Add("No of PO's Placed");
                cmbReport.Items.Add("Consolidated GIN PO Standard Cost");
                cmbReport.Items.Add("Consolidated GIN WO Standard Cost");
                cmbReport.Items.Add("Purchase Register PO");
                cmbReport.Items.Add("Riverse GIN");
                cmbReport.Items.Add("Project PO Placed");
                cmbReport.Items.Add("Gin Job Work");
                cmbReport.Items.Add("Item Usage Work Order");
                cmbReport.Items.Add("GM Approve Pending PO");
                cmbReport.Items.Add("Purchase Register WO");
                cmbReport.Items.Add("Project Transform Details");
                cmbReport.Items.Add("Project Status Update Details");
                cmbReport.Items.Add("Project Installation Status Update Details");
                //  cmbReport.Items.Add("Consolidated Stock Report");
                //cmbReport.Items.Add("Consolidated Projects Conusmption Report");
                //cmbReport.Items.Add("Customer Projects Conusmption Report");
                //   cmbReport.Items.Add("Cust. Project Inventory Grading Report");
                //cmbReport.Items.Add("User Access Report");
                // cmbReport.Items.Add("Project Document Tracking");
                //cmbReport.Items.Add("Standard Item Cost");
                cmbReport.Items.Add("Job Work");
            }
            else
            {
                cmbReport.Items.Clear();
                cmbReport.Items.Add("Project Issue");
                cmbReport.Items.Add("Receipt");
                cmbReport.Items.Add("Stock Balance");
                cmbReport.Items.Add("Item Label Print");
                cmbReport.Items.Add("Filter Stock Balance");
                //cmbReport.Items.Add("Project Cost");
                cmbReport.Items.Add("Inventory Grading Report");
                cmbReport.Items.Add("Job Issue");
                cmbReport.Items.Add("Stock Adjusted");
                //cmbReport.Items.Add("Purchase Cost");
                cmbReport.Items.Add("ItemReturn Project Issued");
                cmbReport.Items.Add("ItemReturn Job Issued");
                cmbReport.Items.Add("Consolidated GIN Report PO");
                cmbReport.Items.Add("Consolidated GIN Report PO and WO");
                cmbReport.Items.Add("Consolidated GIN Report WO");
                // cmbReport.Items.Add("Vendor GIN Report PO");
                // cmbReport.Items.Add("Vendor GIN Report WO");
                cmbReport.Items.Add("Print GIN");
                // cmbReport.Items.Add("Vendor List");
                //  cmbReport.Items.Add("Transactional Spend Data");
                cmbReport.Items.Add("AP Spend Data");
                cmbReport.Items.Add("Project List");
                //  cmbReport.Items.Add("Standard Cost PO");
                // cmbReport.Items.Add("Standard Cost WO");
                //  cmbReport.Items.Add("Pending PO");
                cmbReport.Items.Add("DepartmentWise Issued");
                //  cmbReport.Items.Add("DepartmentWise PO/WO");
                //cmbReport.Items.Add("DepartmentWise WOr");
                cmbReport.Items.Add("No of PO's Placed");
                // cmbReport.Items.Add("Consolidated GIN PO Standard Cost");
                // cmbReport.Items.Add("Consolidated GIN WO Standard Cost");
                cmbReport.Items.Add("Purchase Register PO");
                cmbReport.Items.Add("Riverse GIN");
                cmbReport.Items.Add("Project PO Placed");
                cmbReport.Items.Add("Gin Job Work");
                cmbReport.Items.Add("Item Usage Work Order");
                cmbReport.Items.Add("GM Approve Pending PO");
                cmbReport.Items.Add("Purchase Register WO");
                cmbReport.Items.Add("Project Transform Details");
                cmbReport.Items.Add("Project Status Update Details");
                cmbReport.Items.Add("Project Installation Status Update Details");
                //  cmbReport.Items.Add("Consolidated Stock Report");
                //cmbReport.Items.Add("Consolidated Projects Conusmption Report");
                //cmbReport.Items.Add("Customer Projects Conusmption Report");
                //   cmbReport.Items.Add("Cust. Project Inventory Grading Report");
                //cmbReport.Items.Add("User Access Report");
                // cmbReport.Items.Add("Project Document Tracking");
                //cmbReport.Items.Add("Standard Item Cost");
                cmbReport.Items.Add("Job Work");

                //  cmbReport.Items.Add("Project Cost, Machine & Man hours details");
                // cmbReport.Items.Add("ERP Log Report");
            }


        }




        private void LoadEnabledReports()
        {
            Login.frmLoginForm login = new Login.frmLoginForm();
            DataAccessLayer Dal = new DataAccessLayer();
            string loginId = login.GetUserDetails[1]; // Get LoginId as string
            DataTable dtReports = Dal.fnLoadEnabledReports(loginId); // or proper int value

            cmbReport.Items.Clear();
            foreach (DataRow row in dtReports.Rows)
            {
                cmbReport.Items.Add(Convert.ToString(row["ReportName"]));
            }

            if (cmbReport.Items.Count > 0)
                cmbReport.SelectedIndex = -1;
        }

        #endregion


        #region Create Exce lSheet
        string ExcelFolderPath;
        string FileFullPath;



        private void CreateExcelSheet()
        {
            // This returns something like C:\Users\Username:
            string userRoot = System.Environment.GetEnvironmentVariable("USERPROFILE");
            // Now let's get C:\Users\Username\Downloads:
            string downloadFolder = Path.Combine(userRoot, "Downloads");
            sqldataadapter = DAL.SQLDadpr;
            cmd = DAL.SQLCmd;

            Exceldataset = DAL.SQLDataset;
            try
            {
                switch (cmbReport.SelectedItem.ToString())
                {
                    case "Project Issue":
                        ExcelFolderPath = downloadFolder + @"\Issued\";
                        FileFullPath = ExcelFolderPath + "Issued (" + dtpFromDate.Text + " To " + dptToDate.Text + " )" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "Issued");
                        break;
                    case "Receipt":
                        ExcelFolderPath = downloadFolder + @"\Receipt\";
                        FileFullPath = ExcelFolderPath + "Receipt (" + dtpFromDate.Text + " To " + dptToDate.Text + " )" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "Receipt");
                        break;

                    case "Project Master":
                        ExcelFolderPath = downloadFolder + @"\Project Master\";
                        FileFullPath = ExcelFolderPath + "Project Master (" + dtpFromDate.Text + " To " + dptToDate.Text + " )" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "Project Master");
                        break;

                    case "DepartmentWise PO/WO":

                        ExcelFolderPath = downloadFolder + @"\DepartmentWise POWO\";
                        FileFullPath = ExcelFolderPath + "DepartmentWise POWO (" + dtpFromDate.Text + " To " + dptToDate.Text + " )" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "DepartmentWise POWO");
                        break;

                    case "Stock Balance":
                        ExcelFolderPath = downloadFolder + @"\Stock Balance\";
                        var yesterday = DateTime.Today;
                        FileFullPath = ExcelFolderPath + "Stock Balance on " + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + "";
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "Stock Balance");
                        break;

                    case "Inventory Grading Report":
                    case "Item Usage Work Order":
                        ExcelFolderPath = downloadFolder + @"\Inventory grading report\";
                        FileFullPath = ExcelFolderPath + "Inventory grading report From " + dtpFromDate.Text + " To " + dtptwelve.Text + "--" + DateTime.Now.ToString("hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "Inventory grading report");
                        break;
                    case "Job Issue":
                        ExcelFolderPath = downloadFolder + @"\Job Issued\";
                        FileFullPath = ExcelFolderPath + "Job Issued (" + dtpFromDate.Text + " To " + dptToDate.Text + ")" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "Job Issued");
                        break;
                    case "Stock Adjusted":
                        ExcelFolderPath = downloadFolder + @"\Stock Adjusted\";
                        FileFullPath = ExcelFolderPath + "Stock Adjusted (" + dtpFromDate.Text + " To " + dptToDate.Text + ")";
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "Stock Adjusted");
                        break;
                    case "Purchase Cost":
                        ExcelFolderPath = downloadFolder + @"\Purchase Cost\";
                        FileFullPath = ExcelFolderPath + "Purchase Cost (" + dtpFromDate.Text + " To " + dptToDate.Text + ")";
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "PurchaseCost");
                        break;
                    case "ItemReturn Project Issued":
                        ExcelFolderPath = downloadFolder + @"\Project Issued ItemReturn\";
                        FileFullPath = ExcelFolderPath + "Project Issued ItemReturn (" + dtpFromDate.Text + " To " + dptToDate.Text + ")" + DateTime.Now.ToString("hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "Project Issued ItemReturn");
                        break;
                    case "ItemReturn Job Issued":
                        ExcelFolderPath = downloadFolder + @"\Job Issued ItemReturn\";
                        FileFullPath = ExcelFolderPath + "Job Issued ItemReturn (" + dtpFromDate.Text + " To " + dptToDate.Text + ")" + DateTime.Now.ToString("hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "Job Issued ItemReturn");
                        break;
                    case "Vendor List":
                        ExcelFolderPath = downloadFolder + @"\Vendors\";
                        FileFullPath = ExcelFolderPath + "Vendors" + DateTime.Now.ToString("hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "Vendors");
                        break;

                    //

                    case "Fixed Asset Register":
                        ExcelFolderPath = downloadFolder + @"\Fixed Asset Register\";
                        FileFullPath = ExcelFolderPath + "Fixed Asset Register" + DateTime.Now.ToString("hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "Fixed Asset Register");
                        break;

                    case "ERP Log Report":
                        ExcelFolderPath = downloadFolder + @"\ERP Log Report\";
                        FileFullPath = ExcelFolderPath + "ERP Log Report  " + DateTime.Now.ToString("hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "ERP Log Report");
                        break;

                    case "ERP WAR Log Report":
                        ExcelFolderPath = downloadFolder + @"\ERP WAR Log Report\";
                        FileFullPath = ExcelFolderPath + "ERP WAR Log Report  " + DateTime.Now.ToString("hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "ERP WAR Log Report");
                        break;

                    case "Transactional Spend Data":
                        ExcelFolderPath = downloadFolder + @"\Transactional Spend Data\";
                        FileFullPath = ExcelFolderPath + "Transactional Spend Data (" + dtpFromDate.Text + " To " + dptToDate.Text + ")";
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "Transactionalspenddata");
                        break;
                    case "AP Spend Data":
                        ExcelFolderPath = downloadFolder + @"\AP Spend Data\";
                        FileFullPath = ExcelFolderPath + "AP Spend Data (" + dtpFromDate.Text + " To " + dptToDate.Text + ")";
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "ApSpenddata");
                        break;

                    case "Project List":
                        ExcelFolderPath = downloadFolder + @"\Project List\";
                        FileFullPath = ExcelFolderPath + "Project List";
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "ProjectList");
                        break;
                    case "Standard Cost PO":
                        ExcelFolderPath = downloadFolder + @"\Standard Cost PO\";
                        FileFullPath = ExcelFolderPath + "StandardCost PO (" + dtpFromDate.Text + " To " + dptToDate.Text + ")";
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "StandarCostPO");
                        break;
                    case "Standard Cost WO":
                        ExcelFolderPath = downloadFolder + @"\Standard Cost WO\";
                        FileFullPath = ExcelFolderPath + "StandardCost WO (" + dtpFromDate.Text + " To " + dptToDate.Text + ")";
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "StandarCostWO");
                        break;
                    case "Purchase Register PO":
                    case "Purchase Register WO":
                        ExcelFolderPath = downloadFolder + @"\Purchase Register\";
                        FileFullPath = ExcelFolderPath + cmbReport.Text + "(" + dtpFromDate.Text + " To " + dptToDate.Text + ")" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        DataSet ds = new DataSet();
                        ds.Tables.Add(dtCloned);
                        ExportToExcel(ds, FileFullPath, "Purchase Register");
                        break;
                    case "Riverse GIN":
                        ExcelFolderPath = downloadFolder + @"\Riverse GIN\";
                        FileFullPath = ExcelFolderPath + "Riverse GIN (" + dtpFromDate.Text + " To " + dptToDate.Text + ")" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "Riverse GIN");
                        break;
                    case "Project PO Placed":
                        ExcelFolderPath = downloadFolder + @"\Project PO Placed\";
                        FileFullPath = ExcelFolderPath + "Project PO Placed (" + dtpFromDate.Text + " To " + dptToDate.Text + ")" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "Project PO Placed");
                        break;
                    case "Gin Job Work":
                        ExcelFolderPath = downloadFolder + @"\GIN Job Work\";
                        FileFullPath = ExcelFolderPath + "GIN Job Work (" + dtpFromDate.Text + " To " + dptToDate.Text + ")" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "GIN Job Work");
                        break;
                    case "Project Transform Details"://Project Transfer Report
                        ExcelFolderPath = downloadFolder + @"\Project Transfer Report\";
                        FileFullPath = ExcelFolderPath + "Project Transfer Report (" + dtpFromDate.Text + " To " + dptToDate.Text + ")" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "Project Transfer Report");
                        break;
                    case "Project Status Update Details":
                        ExcelFolderPath = downloadFolder + @"\Project Status Update\";
                        FileFullPath = ExcelFolderPath + "Project Status Update (" + dtpFromDate.Text + " To " + dptToDate.Text + ")" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "Project Status Update");
                        break;

                    case "Project Installation Status Update Details":
                        ExcelFolderPath = downloadFolder + @"\Project Install Status\";
                        FileFullPath = ExcelFolderPath + "Project Install Status (" + dtpFromDate.Text + " To " + dptToDate.Text + ")" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "Project Install Status");
                        break;

                    case "Consolidated Stock Report":
                        ExcelFolderPath = downloadFolder + @"\Consolidated Stock Report\";
                        FileFullPath = ExcelFolderPath + "Consolidated Stock Report (" + dtpFromDate.Text + " To " + dptToDate.Text + ")" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "Consolidated Stock Report");
                        break;

                    case "All Stock Latest Standard Cost Report":
                        ExcelFolderPath = downloadFolder + @"\All Stock Latest Standard Cost Report\";
                        FileFullPath = ExcelFolderPath + "All Stock Latest Standard Cost Report" + DateTime.Now.ToString("hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        //  Exceldataset.Tables.Add(dtReciept);
                        ExportToExcel(Exceldataset, FileFullPath, "Latest Standard Cost Report");
                        break;

                    case "Consolidated Projects Conusmption Report":
                        ExcelFolderPath = downloadFolder + @"\Consolidated Project Conusmption Report\";
                        FileFullPath = ExcelFolderPath + "Consolidated Project Conusmption Report (" + dtpFromDate.Text + " To " + dptToDate.Text + ")" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "Conusmption Report");
                        break;

                    case "Customer Projects Conusmption Report":
                        ExcelFolderPath = downloadFolder + @"\Customer Conusmption Report\";
                        FileFullPath = ExcelFolderPath + "Customer Conusmption Report (" + dtpFromDate.Text + " To " + dptToDate.Text + ")" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "Customer Conusmption Report");
                        break;

                    case "Cust. Project Inventory Grading Report":
                        ExcelFolderPath = downloadFolder + @"\Customer Inventory Grading Report\";
                        FileFullPath = ExcelFolderPath + "Customer Inventory Grading Report (" + dtpFromDate.Text + " To " + dptToDate.Text + ")" + DateTime.Now.ToString("hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "CInventory Grading");
                        break;

                    case "User Access Report":
                        ExcelFolderPath = downloadFolder + @"\User Access Level Report\";
                        FileFullPath = ExcelFolderPath + "User Access Report" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "UserAccess");
                        break;

                    case "Project Document Tracking":
                        ExcelFolderPath = downloadFolder + @"\Project Doc Tracking Report\";
                        FileFullPath = ExcelFolderPath + "Project Document Tracking Report" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        DataSet disset = new DataSet();
                        disset.Merge(dtReciept);
                        ExportToExcel(disset, FileFullPath, "Project Doc Tracking Report");
                        break;

                    case "Standard Item Cost":
                        ExcelFolderPath = downloadFolder + @"\Std Item Cost Report\";
                        FileFullPath = ExcelFolderPath + "Std Item Cost Report" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "Standard Item Cost Report");
                        break;

                    case "Job Work":
                        ExcelFolderPath = downloadFolder + @"\Job Work\";
                        FileFullPath = ExcelFolderPath + "Job Work (" + dtpFromDate.Text + " To " + dptToDate.Text + ")" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "Job Work");
                        break;

                    case "Service GIN":
                        ExcelFolderPath = downloadFolder + @"\Service GIN\";
                        FileFullPath = ExcelFolderPath + "Service GIN (" + dtpFromDate.Text + " To " + dptToDate.Text + ")" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        ExportToExcel(Exceldataset, FileFullPath, "Service GIN");
                        break;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                foreach (Process process in Process.GetProcessesByName("Excel"))
                {
                    process.Kill();
                }
            }

        }

        #endregion
        #region Excel Sheet Quit Application Function
        private void ExcelKillProcess()
        {
            try
            {

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                foreach (Process process in Process.GetProcessesByName("Excel"))
                {
                    process.Kill();
                }
            }
        }
        #endregion

        #region Project Cost Report Generate Method
        DataTable dtJobIssued = new DataTable();
        DataTable dtJobIssuedItemReturn = new DataTable();
        DataTable dtGinJobCost = new DataTable();
        DataTable DtkanbanIssued = new DataTable();
        DataTable dtkanabanreturn = new DataTable();

        public void ProjectCodeReportlist()
        {
            double dSumGinCost = 0;
            dtpFromDate.Format = DateTimePickerFormat.Custom;
            dtpFromDate.CustomFormat = "yyyy-MM-dd";
            dptToDate.Format = DateTimePickerFormat.Custom;
            dptToDate.CustomFormat = "yyyy-MM-dd";

            sumProjectIndentCost = 0;
            sumProjectItemReturnCost = 0;
            sumProjectJobReturnCost = 0;
            sumProjectJobCost = 0;
            sumProjectMachineUtilizationhours = 0;
            sumProjectTimesheetManhours = 0;
            // case "Project Cost":

            switch (cmbReport.SelectedItem.ToString())
            {
                case "Project Cost":
                    DtProjectIssued = DAL.fnProjectIssued(0, cmbProjectCode.Text, dtpFromDate.Text, dptToDate.Text).Tables[0];
                    if (DtProjectIssued.Rows.Count > 0)
                    {
                        sumProjectIndentCost = DtProjectIssued.Compute("Sum(Amount)", "[IssueType]='Indent Issue' or [IssueType]='ElectronicsFG' or [IssueType]='ElectronicsItem' or [IssueType]='TransducerFG' or [IssueType]='TransducerItem'");
                        sumProjectJobCost = DtProjectIssued.Compute("Sum(Amount)", "[IssueType]='Job Issue'");
                        sumProjectItemReturnCost = DtProjectIssued.Compute("Sum(Amount)", "[IssueType]='Indent Return' or [IssueType]='ELC-ReturnFG' or [IssueType]='ELC-ReturnItem' or [IssueType]='TRS-ReturnFG' or [IssueType]='TRS-ReturnItem'");
                        sumProjectJobReturnCost = DtProjectIssued.Compute("Sum(Amount)", "[IssueType]='Job Return'");
                    }
                    break;
                case "Project Cost, Machine & Man hours details":
                    DtProjectIssued = DAL.fnProjectIssued(2, cmbProjectCode.Text, dtpFromDate.Text, dptToDate.Text).Tables[0];
                    if (DtProjectIssued.Rows.Count > 0)
                    {
                        sumProjectIndentCost = DtProjectIssued.Compute("Sum(Amount)", "[IssueType]='Indent Issue' or [IssueType]='ElectronicsFG' or [IssueType]='ElectronicsItem' or [IssueType]='TransducerFG' or [IssueType]='TransducerItem'");
                        sumProjectJobCost = DtProjectIssued.Compute("Sum(Amount)", "[IssueType]='Job Issue'");
                        sumProjectItemReturnCost = DtProjectIssued.Compute("Sum(Amount)", "[IssueType]='Indent Return' or [IssueType]='ELC-ReturnFG' or [IssueType]='ELC-ReturnItem' or [IssueType]='TRS-ReturnFG' or [IssueType]='TRS-ReturnItem'");
                        sumProjectJobReturnCost = DtProjectIssued.Compute("Sum(Amount)", "[IssueType]='Job Return'");
                        sumProjectTimesheetManhours = DtProjectIssued.Compute("Sum(IssuedQty)", "[IssueType]='Timesheet Man hours'");
                        sumProjectMachineUtilizationhours = DtProjectIssued.Compute("Sum(IssuedQty)", "[IssueType]='Machine Utilization hours'");
                    }
                    break;
            }

            sumProjectIndentCost = sumProjectIndentCost == DBNull.Value ? 0 : Convert.ToDouble(sumProjectIndentCost);
            sumProjectJobCost = sumProjectJobCost == DBNull.Value ? 0 : Convert.ToDouble(sumProjectJobCost);
            sumProjectItemReturnCost = sumProjectItemReturnCost == DBNull.Value ? 0 : Convert.ToDouble(sumProjectItemReturnCost);
            sumProjectJobReturnCost = sumProjectJobReturnCost == DBNull.Value ? 0 : Convert.ToDouble(sumProjectJobReturnCost);


            dtpFromDate.Format = DateTimePickerFormat.Custom;
            dtpFromDate.CustomFormat = "dd-MM-yyyy";
            dptToDate.Format = DateTimePickerFormat.Custom;
            dptToDate.CustomFormat = "dd-MM-yyyy";

            if (DtProjectIssued.Rows.Count > 0)
            {
                TotalSum = (Convert.ToDouble(sumProjectIndentCost) + Convert.ToDouble(sumProjectJobCost)) - (Convert.ToDouble(sumProjectItemReturnCost) + Convert.ToDouble(sumProjectJobReturnCost));

                EXCEL.Workbook workbook;
                EXCEL.Worksheet worksheet;
                EXCEL.Application app;

                app = new Microsoft.Office.Interop.Excel.Application();
                //NewWorkBook = excelApp.Workbooks.Add(Type.Missing);
                // worksheet = NewWorkBook.Sheets["Sheet1"];
                // worksheet = NewWorkBook.ActiveSheet;

                //  Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
                // Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
                //   Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
                workbook = app.Workbooks.Add(Type.Missing);
                worksheet = workbook.Sheets["Sheet1"];
                worksheet = workbook.ActiveSheet;
                worksheet.Name = "Project Cost Report";
                object misValue = System.Reflection.Missing.Value;

                // This returns something like C:\Users\Username:
                string userRoot = System.Environment.GetEnvironmentVariable("USERPROFILE");
                // Now let's get C:\Users\Username\Downloads:
                string downloadFolder = Path.Combine(userRoot, "Downloads");

                string ExcelFolderPath = downloadFolder + "\\Project Cost\\";
                string FileFullPath = ExcelFolderPath + "Project Cost of (" + cmbProjectCode.Text + ")" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);

                workbook.SaveAs(FileFullPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                worksheet.Cells[1, 1] = Global.sCompanyName;
                worksheet.Range["A1:A1"].Cells.Font.Size = 16;
                worksheet.Range["A1:A1"].Cells.Font.Bold = true;
                CellMerge("Merge", workbook.ActiveSheet, 1, 1, 1, 3);
                worksheet.Cells[2, 2] = "Dated From  : " + dtpFromDate.Text + "  To  : " + dptToDate.Text + "";
                worksheet.Range["A2:C2"].Cells.Font.Bold = 14;
                worksheet.Cells[4, 1] = "Project Code:";
                worksheet.Cells[4, 2] = cmbProjectCode.Text;
                worksheet.Cells[5, 1] = "Project Name:";
                worksheet.Cells[5, 2] = txtProjectCode.Text;
                worksheet.Cells[2, 4] = "Total Issued Cost";
                CellMerge("Merge", workbook.ActiveSheet, 2, 2, 4, 5);
                worksheet.Cells[3, 4] = "Total Job Issued Cost";
                CellMerge("Merge", workbook.ActiveSheet, 3, 3, 4, 5);
                //worksheet.Cells[4, 4] = "Total Job GIN Cost";
                //CellMerge("Merge", workbook.ActiveSheet, 3, 3, 4, 5);
                worksheet.Cells[4, 4] = "Total Issued Return Cost";
                CellMerge("Merge", workbook.ActiveSheet, 4, 4, 4, 5);
                worksheet.Cells[5, 4] = "Total Job Return Cost";
                CellMerge("Merge", workbook.ActiveSheet, 5, 5, 4, 5);
                worksheet.Cells[6, 4] = "Net Project Cost";
                CellMerge("Merge", workbook.ActiveSheet, 6, 6, 4, 5);

                switch (cmbReport.SelectedItem.ToString())
                {
                    case "Project Cost, Machine & Man hours details":
                        worksheet.Cells[2, 8] = "Timesheet Man hours";
                        CellMerge("Merge", workbook.ActiveSheet, 2, 2, 8, 9);
                        worksheet.Cells[2, 10] = sumProjectTimesheetManhours.ToString();
                        worksheet.Cells[3, 8] = "Machine Utilization hours";
                        CellMerge("Merge", workbook.ActiveSheet, 3, 3, 8, 9);
                        worksheet.Cells[3, 10] = sumProjectMachineUtilizationhours.ToString();
                        break;
                }

                worksheet.Cells[2, 6] = sumProjectIndentCost.ToString();
                worksheet.Cells[3, 6] = sumProjectJobCost.ToString();
                // worksheet.Cells[4, 6] = dSumGinCost.ToString();
                worksheet.Cells[4, 6] = "-" + sumProjectItemReturnCost.ToString();
                worksheet.Cells[5, 6] = "-" + sumProjectJobReturnCost.ToString();
                worksheet.Cells[6, 6] = TotalSum.ToString();
                worksheet.Range["A1:J8"].Cells.Font.Bold = true;
                worksheet.Range["A1:E6"].Cells.Font.Color = Color.Red;
                worksheet.Range["A8:J8"].Cells.Font.Color = Color.Blue;
                worksheet.Range["I1:I3"].Cells.Font.Color = Color.Red;
                if (DtProjectIssued.Rows.Count > 0)
                {
                    Cursor.Current = Cursors.WaitCursor;
                    object[,] rawData = new object[DtProjectIssued.Rows.Count + 1, DtProjectIssued.Columns.Count];


                    foreach (DataRow row in DtProjectIssued.Rows)
                    {
                        string type = row["IssueType"].ToString();
                        if (type.Contains("Return"))
                        {
                            row["Amount"] = -Math.Abs(Convert.ToDouble(row["Amount"]));
                        }
                    }


                    for (int col = 0; col < DtProjectIssued.Columns.Count; col++)
                    {
                        rawData[0, col] = DtProjectIssued.Columns[col].ColumnName;
                    }

                    // Copy the values to the object array
                    for (int col = 0; col < DtProjectIssued.Columns.Count; col++)
                    {
                        for (int row = 0; row < DtProjectIssued.Rows.Count; row++)
                        {
                            rawData[row + 1, col] = DtProjectIssued.Rows[row].ItemArray[col];
                        }
                    }
                    string finalColLetter = string.Empty;
                    string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                    int colCharsetLen = colCharset.Length;
                    if (DtProjectIssued.Columns.Count > colCharsetLen)
                    {
                        finalColLetter = colCharset.Substring(
                            (DtProjectIssued.Columns.Count - 1) / colCharsetLen - 1, 1);
                    }
                    finalColLetter += colCharset.Substring(
                            (DtProjectIssued.Columns.Count - 1) % colCharsetLen, 1);

                    excelRange = string.Format("A8:{0}{1}",
                    finalColLetter, DtProjectIssued.Rows.Count + 8);
                    worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                }

                worksheet.Columns.AutoFit();
                worksheet.Rows.AutoFit();
                worksheet.get_Range("C6", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                worksheet.Columns[2].ColumnWidth = 50;
                worksheet.Columns[2].WrapText = true;
                worksheet.Columns[5].ColumnWidth = 16;
                worksheet.Columns[9].ColumnWidth = 28;
                worksheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                worksheet.Rows.RowHeight = "18";

                worksheet.get_Range("D2", "D6").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignRight;
                // worksheet.get_Range("A1", "A1").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                //Microsoft.Office.Interop.Excel.Range range1 = worksheet.get_Range("H6", "J99999");
                //range1.NumberFormat = "dd/MM/yyyy";

                fnDateFormatstring(worksheet, "H6", "H99999");
                fnNumberFormatstring(worksheet, "D6", "F99999");
                worksheet.PageSetup.Zoom = false;
                worksheet.PageSetup.PrintArea = "A1:H" + (DtProjectIssued.Rows.Count + 11 + dtProjectItemReturn.Rows.Count) + "";
                worksheet.PageSetup.PrintTitleRows = "$1:$2";
                worksheet.PageSetup.PrintNotes = true;
                worksheet.PageSetup.Zoom = 100;
                worksheet.PageSetup.PrintGridlines = true;
                worksheet.PageSetup.LeftMargin = 0;
                worksheet.PageSetup.RightMargin = 0;
                worksheet.PageSetup.TopMargin = 0.75;
                worksheet.PageSetup.BottomMargin = 0.75;
                worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
                // fnDrawLogo(worksheet, 1, 9);
                workbook.Save();
                workbook.Close(true, misValue, misValue);
                app.Quit();
                releaseObject(worksheet);
                releaseObject(workbook);
                releaseObject(app);
                if (Directory.Exists(ExcelFolderPath))
                {
                    Process.Start(ExcelFolderPath);
                }
            }
            else
            {
                MessageBox.Show("Selected Project does not have any Items to Summarise Total Cost");
            }
        }
        #endregion


        public void testingBatchCode(object sender, EventArgs e)
        {

            foreach (DataGridViewRow row in dgvprintpreview.Rows)
            {


                MessageBox.Show(row.Cells["printCount"].Value?.ToString(), row.Cells["ItemCode"].Value?.ToString());

                DataTable ERPInventoryGINDeatils = DAL.getERPInventoryGINDeatils(row.Cells["ItemCode"].Value?.ToString(), cmbprintginnumber.Text, null).Tables[0];


                MessageBox.Show(ERPInventoryGINDeatils.Rows[0]["BatchCode"].ToString(), "Batch Code");
                MessageBox.Show(ERPInventoryGINDeatils.Rows[0]["ItemLocation"].ToString(), "Item Location");



                string printCountStr = row.Cells["printCount"].Value?.ToString();

                if (int.TryParse(printCountStr, out int printCount) && ERPInventoryGINDeatils != null)
                {
                    // Run loop based on printCount
                    for (int i = 0; i < printCount; i++)
                    {
                        // Create dictionary for this iteration
                        Dictionary<string, string> rowData = new Dictionary<string, string>
                        {
                            { "QrValue",  row.Cells["ItemCode"].Value?.ToString()+ERPInventoryGINDeatils.Rows[0]["BatchCode"].ToString() ?? "" },
                            { "ItemCode", row.Cells["ItemCode"].Value?.ToString() ?? "" },
                            { "VendorCode", "" },
                            { "BatchCode", ERPInventoryGINDeatils.Rows[0]["BatchCode"].ToString()?? "" },
                            { "Count", row.Cells["SupplyQty"].Value?.ToString() ?? "" }
                        };

                        // Add to list
                        BatchCodeDataList.Add(rowData);
                    }
                }
                else
                {
                    MessageBox.Show("GIN Log Not Available...!");
                }
                MessageBox.Show(BatchCodeDataList.Count.ToString());


                //  foreach (DataRow data in ERPInventoryGINDeatils.Rows)
                //{
                //  MessageBox.Show(data["BatchCode"].ToString(), "batch Code!");
                // MessageBox.Show(data["ItemLocation"].ToString(), "Location!");
                // }





            }
        }


        public void GenerateLocationPdfQRCode()
        {
            //MessageBox.Show("New code added...");

            BatchCodeDataList.Clear();
            DataTable ERPInventoryGINDeatils = null;

            if (comboBox1Location.Text != "")
            {
                //MessageBox.Show(comboBox1Location.Text);
               // ERPInventoryGINDeatils = DAL.getERPInventoryGINDeatils(null, null, comboBox1Location.Text).Tables[0];
            }
            // MessageBox.Show(ERPInventoryGINDeatils.Rows.Count.ToString(), "Row Count...");
            string printCountStr = "1";

         



            


                // MessageBox.Show(row.Cells["printCount"].Value?.ToString(), row.Cells["ItemCode"].Value?.ToString());

                // DataTable ERPInventoryGINDeatils = DAL.getERPInventoryGINDeatils(row.Cells["ItemCode"].Value?.ToString(), cmbprintginnumber.Text).Tables[0];
                ERPInventoryGINDeatils = null;

                // MessageBox.Show(comboBox1Location.Text, "Slected Location..");

                //if (comboBox1Location.Text != "")
                //{
                // MessageBox.Show(comboBox1Location.Text);
                // ERPInventoryGINDeatils = DAL.getERPInventoryGINDeatils(null, null, comboBox1Location.Text).Tables[0];
                //}
                //  else
                // {
                // MessageBox.Show(row.Cells["ItemCode"].Value?.ToString(), cmbprintginnumber.Text);
                // MessageBox.Show(DAL.getERPInventoryGINDeatilsPrintGIN(row.Cells["ItemCode"].Value?.ToString(), cmbprintginnumber.Text).Tables[0].Rows.Count.ToString());
               // ERPInventoryGINDeatils = DAL.getERPInventoryGINDeatilsPrintGIN(row.Cells["ItemCode"].Value?.ToString(), cmbprintginnumber.Text).Tables[0];
                //}
                //MessageBox.Show(ERPInventoryGINDeatils.Rows.Count.ToString(), "row count");

                //string fnUpdateInventoryLogQROrintedStatus = DAL.fnUpdateInventoryLogQROrinted("UPDATE", "Printed", row.Cells["ItemCode"].Value?.ToString(), cmbprintginnumber.Text);

                //MessageBox.Show(ERPInventoryGINDeatils.Rows[0]["BatchCode"].ToString(), "Batch Code");
                //MessageBox.Show(ERPInventoryGINDeatils.Rows[0]["ItemLocation"].ToString(), "Item Location");



                        printCountStr = "1";

                            // Create dictionary for this iteration
                            Dictionary<string, string> rowData = new Dictionary<string, string>
                            {
                            { "QrValue",  comboBox2LabelPrintLocation.Text },
                            { "ItemCode", comboBox2LabelPrintLocation.Text },
                            { "Location",  "" },
                            {
                                "VendorCode",
                                 ""
                                    
                            },

                            //{ "BatchCode", ERPInventoryGINDeatils.Rows[0]["BatchCode"].ToString()  ?? "" },
                            {
                                "BatchCode",
                                 ""
                            },
                            { "Count",  comboBox1Location.Text }
                        };

            // Add to list
                       //MessageBox.Show("One count added");
                       BatchCodeDataList.Add(rowData);
                        
                   
                // MessageBox.Show(BatchCodeDataList.Count.ToString());


                //  foreach (DataRow data in ERPInventoryGINDeatils.Rows)
                //{
                //  MessageBox.Show(data["BatchCode"].ToString(), "batch Code!");
                // MessageBox.Show(data["ItemLocation"].ToString(), "Location!");
                // }


            


            //new changes end

            if (BatchCodeDataList.Count > 0)
            {

                string userRoot = System.Environment.GetEnvironmentVariable("USERPROFILE");
                // Now let's get C:\Users\Username\Downloads:
                string downloadFolder = Path.Combine(userRoot, "Downloads\\");



                string outputPath = $"{downloadFolder}{"MS-F-R7-L4-P2"}_{DateTime.Now:ddMMyyyyHHmmss}.pdf";
                if (comboBox1Location.Text != "")
                {
                    outputPath = $"{downloadFolder}{"MS-F-R7-L4-P2"}_{DateTime.Now:ddMMyyyyHHmmss}.pdf";
                }

                // Custom page size: 10 cm x 2.5 cm
                iTextSharp.text.Rectangle customSize = new iTextSharp.text.Rectangle(
                Utilities.MillimetersToPoints(60), // width
                Utilities.MillimetersToPoints(30)   // height
                 );

                using (FileStream fs = new FileStream(outputPath, FileMode.Create, FileAccess.Write, FileShare.None))
                using (Document doc = new Document(customSize, 1, 0, 0, 0))
                using (PdfWriter writer = PdfWriter.GetInstance(doc, fs))
                {
                    doc.Open();

                    // Main table with 2 columns for two labels per page
                    PdfPTable mainTable = new PdfPTable(1);
                    PdfPTable outer = new PdfPTable(1);
                    mainTable.WidthPercentage = 100;
                    mainTable.SetWidths(new float[] { 1f });


                    int index = 1;
                    foreach (var data in BatchCodeDataList)
                    {

                        // MessageBox.Show(index.ToString());
                        // Generate QR Code
                        QRCodeGenerator qrGenerator = new QRCodeGenerator();
                        QRCodeData qrCodeData = qrGenerator.CreateQrCode(data["QrValue"], QRCodeGenerator.ECCLevel.Q);
                        QRCode qrCode = new QRCode(qrCodeData);
                        Bitmap qrCodeImage = qrCode.GetGraphic(2);

                        iTextSharp.text.Image qrImg;
                        using (MemoryStream ms = new MemoryStream())
                        {
                            qrCodeImage.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                            qrImg = iTextSharp.text.Image.GetInstance(ms.ToArray());
                            qrImg.ScaleAbsolute(60f, 60f);
                        }

                        // Inner table for label
                        PdfPTable labelTable = new PdfPTable(2);
                        labelTable.WidthPercentage = 100;
                        labelTable.SetWidths(new float[] { 0.6f, 2f });

                        PdfPCell qrCell = new PdfPCell(qrImg);
                        qrCell.Border = Rectangle.NO_BORDER;
                        qrCell.HorizontalAlignment = Element.ALIGN_BASELINE;//ALIGN_CENTER
                        qrCell.VerticalAlignment = Element.ALIGN_BASELINE;//ALIGN_MIDDLE
                        qrCell.PaddingTop = 4f;
                        qrCell.PaddingLeft = -3f;
                        labelTable.AddCell(qrCell);

                        PdfPCell textCell = new PdfPCell();
                        textCell.PaddingTop = 5f;
                        textCell.PaddingLeft = 17f;
                        textCell.Border = Rectangle.NO_BORDER;
                        textCell.HorizontalAlignment = Element.ALIGN_BASELINE;//ALIGN_CENTER
                        textCell.VerticalAlignment = Element.ALIGN_BASELINE;
                        // textCell.PaddingLeft = 3;
                        if (index % 2 == 0)
                        {
                            // textCell.PaddingLeft = 6f;
                        }
                        textCell.AddElement(new Paragraph(data["ItemCode"], FontFactory.GetFont("Arial", 13, iTextSharp.text.Font.BOLD)));
                        textCell.AddElement(new Paragraph(data["Location"], FontFactory.GetFont("Arial", 9, iTextSharp.text.Font.BOLD)));

                        textCell.AddElement(new Paragraph($"{data["Count"]}", FontFactory.GetFont("Arial", 9, iTextSharp.text.Font.BOLD)));
                        //textCell.AddElement(new Paragraph($"", FontFactory.GetFont("Arial", 7)));
                        // textCell.AddElement(new Paragraph(data["VendorCode"], FontFactory.GetFont("Arial", 7)));
                        labelTable.AddCell(textCell);

                        PdfPTable labelTable2 = new PdfPTable(1);
                        labelTable2.WidthPercentage = 100;
                        labelTable2.SetWidths(new float[] { 1f });

                        PdfPCell textCell2 = new PdfPCell();
                        //textCell.PaddingTop = 10f;
                        textCell2.Border = Rectangle.NO_BORDER;
                        // textCell2.PaddingLeft = 3;
                        textCell2.HorizontalAlignment = Element.ALIGN_BASELINE;//ALIGN_CENTER
                        textCell2.VerticalAlignment = Element.ALIGN_BASELINE;
                        textCell2.AddElement(new Paragraph(data["VendorCode"], FontFactory.GetFont("Arial", 9, iTextSharp.text.Font.BOLD)));
                        textCell2.PaddingLeft = -3f;
                        //textCell2.PaddingTop = -4f;
                        labelTable2.AddCell(textCell2);

                        PdfPCell mainCell = new PdfPCell();


                        mainCell.AddElement(labelTable);   // first inner table
                        mainCell.AddElement(labelTable2);



                        mainCell.PaddingTop = 8f;
                        mainCell.PaddingLeft = 5f;

                        if (index % 2 == 0)
                        {
                            //MessageBox.Show("value is zero:");
                            //mainCell.PaddingLeft = 13f;
                        }






                        mainCell.Border = Rectangle.NO_BORDER;
                        mainTable.AddCell(mainCell);
                        index++;
                        outer.WidthPercentage = 100;
                        outer.AddCell(mainCell);
                    }

                    // If odd number of labels, add empty cell
                    if (BatchCodeDataList.Count % 2 != 0)
                    {
                        PdfPCell emptyCell = new PdfPCell(new Phrase(""));
                        emptyCell.Border = Rectangle.NO_BORDER;
                        mainTable.AddCell(emptyCell);
                    }

                    doc.Add(outer);
                    doc.Close();

                }

                MessageBox.Show($"PDF generated successfully at: {outputPath}");
                if (Directory.Exists(outputPath))
                {
                    Process.Start(outputPath);
                }

                //Cursor.Current = Cursors.Default;

            }
            else
            {
                MessageBox.Show("Print List Zero...!");
            }
        }


        public void GeneratePdfBatchCode(object sender, EventArgs e)
        {
            //MessageBox.Show("New code added...");

            BatchCodeDataList.Clear();
            DataTable ERPInventoryGINDeatils = null;

            if (comboBox1Location.Text != "")
            {
                //MessageBox.Show(comboBox1Location.Text);
                ERPInventoryGINDeatils = DAL.getERPInventoryGINDeatils(null, null, comboBox1Location.Text).Tables[0];
            }
           // MessageBox.Show(ERPInventoryGINDeatils.Rows.Count.ToString(), "Row Count...");
            string printCountStr = "1";

            if (ERPInventoryGINDeatils != null)
            {
                foreach (DataRow row in ERPInventoryGINDeatils.Rows)
                {
                    if (int.TryParse(printCountStr, out int printCount))
                    {
                        // Run loop based on printCount
                        for (int i = 0; i < printCount; i++)
                        {
                            // Create dictionary for this iteration
                            Dictionary<string, string> rowData = new Dictionary<string, string>
                        {
                            { "QrValue",  row["ItemCode"]?.ToString()+row["BatchCode"].ToString() ?? "" },
                            { "ItemCode", row["ItemCode"]?.ToString() ?? "" },
                            //{ "VendorCode", row.Cells["ItemDescription"].Value?.ToString() ?? "" },
                            { "Location", row["ItemLocation"]?.ToString() ?? "" },
                            {
                                "VendorCode",
                                (row["ItemDescription"]?.ToString() ?? "")
                                    .Substring(0, Math.Min(40, (row["ItemDescription"]?.ToString() ?? "").Length))
                            },

                            //{ "BatchCode", ERPInventoryGINDeatils.Rows[0]["BatchCode"].ToString()  ?? "" },
                            {
                                "BatchCode",
                                (ERPInventoryGINDeatils.Rows[0]["BatchCode"].ToString() ?? "").Substring(0, Math.Min(50, (row["BatchCode"].ToString() ?? "").Length))
                            },
                            { "Count", row["ReceivedQtY"]?.ToString() ?? "" }
                        };

                            // Add to list
                            BatchCodeDataList.Add(rowData);
                        }
                    }
                }
            }
            else
            {
                //  MessageBox.Show(printCount.ToString(), "ERROR");
            }



                foreach (DataGridViewRow row in dgvprintpreview.Rows)
            {


                // MessageBox.Show(row.Cells["printCount"].Value?.ToString(), row.Cells["ItemCode"].Value?.ToString());

                // DataTable ERPInventoryGINDeatils = DAL.getERPInventoryGINDeatils(row.Cells["ItemCode"].Value?.ToString(), cmbprintginnumber.Text).Tables[0];
                ERPInventoryGINDeatils = null;

                // MessageBox.Show(comboBox1Location.Text, "Slected Location..");

                //if (comboBox1Location.Text != "")
                //{
                // MessageBox.Show(comboBox1Location.Text);
                // ERPInventoryGINDeatils = DAL.getERPInventoryGINDeatils(null, null, comboBox1Location.Text).Tables[0];
                //}
                //  else
                // {
               // MessageBox.Show(row.Cells["ItemCode"].Value?.ToString(), cmbprintginnumber.Text);
               // MessageBox.Show(DAL.getERPInventoryGINDeatilsPrintGIN(row.Cells["ItemCode"].Value?.ToString(), cmbprintginnumber.Text).Tables[0].Rows.Count.ToString());
                ERPInventoryGINDeatils = DAL.getERPInventoryGINDeatilsPrintGIN(row.Cells["ItemCode"].Value?.ToString(), cmbprintginnumber.Text).Tables[0];
                //}
                //MessageBox.Show(ERPInventoryGINDeatils.Rows.Count.ToString(), "row count");

                    string fnUpdateInventoryLogQROrintedStatus = DAL.fnUpdateInventoryLogQROrinted("UPDATE", "Printed", row.Cells["ItemCode"].Value?.ToString(), cmbprintginnumber.Text);
                
                //MessageBox.Show(ERPInventoryGINDeatils.Rows[0]["BatchCode"].ToString(), "Batch Code");
                //MessageBox.Show(ERPInventoryGINDeatils.Rows[0]["ItemLocation"].ToString(), "Item Location");



                 printCountStr = row.Cells["printCount"].Value?.ToString();

                if (ERPInventoryGINDeatils.Rows.Count > 0)
                {

                    if (int.TryParse(printCountStr, out int printCount))
                    {
                        // Run loop based on printCount
                        for (int i = 0; i < printCount; i++)
                        {
                            // Create dictionary for this iteration
                            Dictionary<string, string> rowData = new Dictionary<string, string>
                        {
                            { "QrValue",  row.Cells["ItemCode"].Value?.ToString()+ERPInventoryGINDeatils.Rows[0]["BatchCode"].ToString() ?? "" },
                            { "ItemCode", row.Cells["ItemCode"].Value?.ToString() ?? "" },
                            { "Location", ERPInventoryGINDeatils.Rows[0]["ItemLocation"]?.ToString() ?? "" },
                            {
                                "VendorCode",
                                (row.Cells["ItemDescription"].Value?.ToString() ?? "")
                                    .Substring(0, Math.Min(50, (row.Cells["ItemDescription"].Value?.ToString() ?? "").Length))
                            },

                            //{ "BatchCode", ERPInventoryGINDeatils.Rows[0]["BatchCode"].ToString()  ?? "" },
                            {
                                "BatchCode",
                                (ERPInventoryGINDeatils.Rows[0]["BatchCode"].ToString() ?? "").Substring(0, Math.Min(60, (ERPInventoryGINDeatils.Rows[0]["BatchCode"].ToString() ?? "").Length))
                            },
                            { "Count", row.Cells["SupplyQty"].Value?.ToString() ?? "" }
                        };

                            // Add to list
                            BatchCodeDataList.Add(rowData);
                        }
                    }
                    else
                    {
                        //  MessageBox.Show(printCount.ToString(), "ERROR");
                    }
                }
                else
                {
                   // MessageBox.Show("GIN Log Not Available...!");
                    //return;
                }
                // MessageBox.Show(BatchCodeDataList.Count.ToString());


                //  foreach (DataRow data in ERPInventoryGINDeatils.Rows)
                //{
                //  MessageBox.Show(data["BatchCode"].ToString(), "batch Code!");
                // MessageBox.Show(data["ItemLocation"].ToString(), "Location!");
                // }


            }


            //new changes end

            if (BatchCodeDataList.Count > 0)
            {

                string userRoot = System.Environment.GetEnvironmentVariable("USERPROFILE");
                // Now let's get C:\Users\Username\Downloads:
                string downloadFolder = Path.Combine(userRoot, "Downloads\\");



                string outputPath = $"{downloadFolder}{cmbprintginnumber.Text}_{DateTime.Now:ddMMyyyyHHmmss}.pdf";
                if (comboBox1Location.Text != "")
                {
                    outputPath = $"{downloadFolder}{comboBox1Location.Text}_{DateTime.Now:ddMMyyyyHHmmss}.pdf";
                }

                    // Custom page size: 10 cm x 2.5 cm
                    iTextSharp.text.Rectangle customSize = new iTextSharp.text.Rectangle(
                    Utilities.MillimetersToPoints(60), // width
                    Utilities.MillimetersToPoints(30)   // height
                );

                using (FileStream fs = new FileStream(outputPath, FileMode.Create, FileAccess.Write, FileShare.None))
                using (Document doc = new Document(customSize, 1, 0, 0, 0))
                using (PdfWriter writer = PdfWriter.GetInstance(doc, fs))
                {
                    doc.Open();

                    // Main table with 2 columns for two labels per page
                    PdfPTable mainTable = new PdfPTable(1);
                    PdfPTable outer = new PdfPTable(1);
                    mainTable.WidthPercentage = 100;
                    mainTable.SetWidths(new float[] { 1f });
                    

                    int index = 1;
                    foreach (var data in BatchCodeDataList)
                    {

                        // MessageBox.Show(index.ToString());
                        // Generate QR Code
                        QRCodeGenerator qrGenerator = new QRCodeGenerator();
                        QRCodeData qrCodeData = qrGenerator.CreateQrCode(data["QrValue"], QRCodeGenerator.ECCLevel.Q);
                        QRCode qrCode = new QRCode(qrCodeData);
                        Bitmap qrCodeImage = qrCode.GetGraphic(2);

                        iTextSharp.text.Image qrImg;
                        using (MemoryStream ms = new MemoryStream())
                        {
                            qrCodeImage.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                            qrImg = iTextSharp.text.Image.GetInstance(ms.ToArray());
                            qrImg.ScaleAbsolute(45f, 45f);
                        }

                        // Inner table for label
                        PdfPTable labelTable = new PdfPTable(2);
                        labelTable.WidthPercentage = 100;
                        labelTable.SetWidths(new float[] { 0.6f, 2f });

                        PdfPCell qrCell = new PdfPCell(qrImg);
                        qrCell.Border = Rectangle.NO_BORDER;
                        qrCell.HorizontalAlignment = Element.ALIGN_BASELINE;//ALIGN_CENTER
                        qrCell.VerticalAlignment = Element.ALIGN_BASELINE;//ALIGN_MIDDLE
                        qrCell.PaddingTop = -8f;
                        qrCell.PaddingLeft = -6f;
                        labelTable.AddCell(qrCell);

                        PdfPCell textCell = new PdfPCell();
                        textCell.PaddingTop = -12f;
                        textCell.PaddingLeft = -1f;
                        textCell.Border = Rectangle.NO_BORDER;
                        textCell.HorizontalAlignment = Element.ALIGN_BASELINE;//ALIGN_CENTER
                        textCell.VerticalAlignment = Element.ALIGN_BASELINE;
                        // textCell.PaddingLeft = 3;
                        if (index % 2 == 0)
                        {
                           // textCell.PaddingLeft = 6f;
                        }
                        textCell.AddElement(new Paragraph(data["ItemCode"], FontFactory.GetFont("Arial", 13, iTextSharp.text.Font.BOLD)));
                        textCell.AddElement(new Paragraph(data["Location"], FontFactory.GetFont("Arial", 9, iTextSharp.text.Font.BOLD)));
                       
                        textCell.AddElement(new Paragraph($"{data["BatchCode"]} | QTY:{data["Count"]}", FontFactory.GetFont("Arial", 9, iTextSharp.text.Font.BOLD)));
                        //textCell.AddElement(new Paragraph($"", FontFactory.GetFont("Arial", 7)));
                       // textCell.AddElement(new Paragraph(data["VendorCode"], FontFactory.GetFont("Arial", 7)));
                        labelTable.AddCell(textCell);

                        PdfPTable labelTable2 = new PdfPTable(1);
                        labelTable2.WidthPercentage = 100;
                        labelTable2.SetWidths(new float[] { 1f });
                        
                        PdfPCell textCell2 = new PdfPCell();
                        //textCell.PaddingTop = 10f;
                        textCell2.Border = Rectangle.NO_BORDER;
                       // textCell2.PaddingLeft = 3;
                        textCell2.HorizontalAlignment = Element.ALIGN_BASELINE;//ALIGN_CENTER
                        textCell2.VerticalAlignment = Element.ALIGN_BASELINE;
                        textCell2.AddElement(new Paragraph(data["VendorCode"], FontFactory.GetFont("Arial", 9, iTextSharp.text.Font.BOLD)));
                        textCell2.PaddingLeft = -3f;
                        //textCell2.PaddingTop = -4f;
                        labelTable2.AddCell(textCell2);

                        PdfPCell mainCell = new PdfPCell();


                        mainCell.AddElement(labelTable);   // first inner table
                        mainCell.AddElement(labelTable2);
                        


                        mainCell.PaddingTop = 8f;
                        mainCell.PaddingLeft = 5f;

                        if (index % 2 == 0)
                        {
                            //MessageBox.Show("value is zero:");
                            //mainCell.PaddingLeft = 13f;
                        }


                        
                       
                        

                        mainCell.Border = Rectangle.NO_BORDER;
                        mainTable.AddCell(mainCell);
                        index++;
                        outer.WidthPercentage = 100;
                        outer.AddCell(mainCell);
                    }

                    // If odd number of labels, add empty cell
                    if (BatchCodeDataList.Count % 2 != 0)
                    {
                        PdfPCell emptyCell = new PdfPCell(new Phrase(""));
                        emptyCell.Border = Rectangle.NO_BORDER;
                        mainTable.AddCell(emptyCell);
                    }

                    doc.Add(outer);
                    doc.Close();

                }

                MessageBox.Show($"PDF generated successfully at: {outputPath}");
                if (Directory.Exists(outputPath))
                {
                    Process.Start(outputPath);
                }

                //Cursor.Current = Cursors.Default;

            }
            else
            {
                MessageBox.Show("Print List Zero...!");
            }
        }

        #region Combobox Projectcode Changed
        private void cmbProjectCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbProjectCode.Text != "None")
            {
                DataTable dt = new DataTable();
                dt = DAL.fnProjectList(cmbProjectCode.Text).Tables[0];
                if (dt.Rows.Count > 0)
                {
                    txtProjectCode.Text = dt.Rows[0]["ProjectDescription"].ToString();
                }
            }
        }
        #endregion
        #region Exit Form
        private void btnExit_Click(object sender, EventArgs e)
        {

        }
        #endregion
        #region TImer
        private void timer1_Tick(object sender, EventArgs e)
        {
            //  lbltime.Text = DateTime.Now.ToString("hh:mm:ss tt");
        }
        #endregion

        #region Excel App Release Object Function
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
        #endregion

        public void fnDrawLogo(EXCEL.Worksheet worksheet, int column1, int column2)
        {
            if (File.Exists("C:\\Databasepath\\TQBiSSLogo.jpg"))
            {
                var oRange = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[column1, column2];
                var oImage = System.Drawing.Image.FromFile("C:\\Databasepath\\TQBiSSLogo.jpg");

                System.Windows.Forms.Clipboard.SetImage(oImage);
                System.Threading.Thread.Sleep(100); // Give clipboard time to copy

                worksheet.Paste(oRange);

            }
        }

        public void fnDateFormat(EXCEL.Worksheet worksheet, int column1, int column2)
        {
            Microsoft.Office.Interop.Excel.Range date = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[column1, column2];
            date.EntireColumn.NumberFormat = "DD/MM/YYYY";
        }
        public void fnDateFormatstring(EXCEL.Worksheet worksheet, string column1, string column2)
        {
            Microsoft.Office.Interop.Excel.Range date = worksheet.get_Range(column1, column2);
            date.EntireColumn.NumberFormat = "DD/MM/YYYY";
        }
        public void fnDateFormatstring1(EXCEL.Worksheet worksheet, string column1, string column2)
        {
            Microsoft.Office.Interop.Excel.Range date = worksheet.get_Range(column1, column2);
            date.EntireColumn.NumberFormat = "DD/MM/YYYY HH:MM:SS";
        }

        public void fnNumberFormat(EXCEL.Worksheet worksheet, int column1, int column2)
        {
            Microsoft.Office.Interop.Excel.Range r = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[column1, column2];
            r.EntireColumn.NumberFormat = "0.00";
        }

        public void fnNumberFormatstring(EXCEL.Worksheet worksheet, string column1, string column2)
        {
            Microsoft.Office.Interop.Excel.Range r = worksheet.get_Range(column1, column2);
            r.EntireColumn.NumberFormat = "0.00";
        }

        public void fnNumberFormatPercentage(EXCEL.Worksheet worksheet, string column1, string column2)
        {
            Microsoft.Office.Interop.Excel.Range r = worksheet.get_Range(column1, column2);
            r.EntireColumn.NumberFormat = "0.0%";
        }

        public void fnExcelPrint(EXCEL.Worksheet worksheet, string PrintArea)
        {
            worksheet.PageSetup.Zoom = false;
            worksheet.PageSetup.PrintArea = PrintArea;
            worksheet.PageSetup.PrintTitleRows = "$1:$2";
            worksheet.PageSetup.PrintNotes = true;
            worksheet.PageSetup.Zoom = 55;
            worksheet.PageSetup.PrintGridlines = true;
            worksheet.PageSetup.LeftMargin = 0;
            worksheet.PageSetup.RightMargin = 0;
            worksheet.PageSetup.TopMargin = 0.75;
            worksheet.PageSetup.BottomMargin = 0.75;
            worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
            worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
        }

        #region Excel at 1 Click Fucnction
        public void ExportToExcel(DataSet dataSet, string outputPath, string tablename)
        {
            //Microsoft.Office.Interop.Excel._Application excelApp = null;
            //Microsoft.Office.Interop.Excel._Workbook NewWorkBook = null;
            //Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
            EXCEL.Workbook NewWorkBook;
            EXCEL.Worksheet worksheet;
            EXCEL.Application excelApp;

            excelApp = new Microsoft.Office.Interop.Excel.Application();
            NewWorkBook = excelApp.Workbooks.Add(Type.Missing);
            worksheet = NewWorkBook.Sheets["Sheet1"];
            worksheet = NewWorkBook.ActiveSheet;
            worksheet.Name = tablename;
            int StockValue;

            foreach (System.Data.DataTable dt in dataSet.Tables)
            {
                Total = 0.0;
                if (tablename == "Stock Balance")
                {
                    Total = dt.Compute("Sum(StockValue)", "");
                    StockValue = dataSet.Tables[0].Columns.IndexOf("StockValue");
                }
                // Copy the DataTable to an object array
                object[,] rawData = new object[dt.Rows.Count + 1, dt.Columns.Count];

                // Copy the column names to the first row of the object array
                for (int col = 0; col < dt.Columns.Count; col++)
                {
                    rawData[0, col] = dt.Columns[col].ColumnName;
                }
                // Copy the values to the object array
                for (int col = 0; col < dt.Columns.Count; col++)
                {
                    for (int row = 0; row < dt.Rows.Count; row++)
                    {
                        rawData[row + 1, col] = dt.Rows[row].ItemArray[col];
                    }
                }

                string finalColLetter = string.Empty;
                string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                int colCharsetLen = colCharset.Length;

                if (dt.Columns.Count > colCharsetLen)
                {
                    finalColLetter = colCharset.Substring((dt.Columns.Count - 1) / colCharsetLen - 1, 1);
                }

                finalColLetter += colCharset.Substring((dt.Columns.Count - 1) % colCharsetLen, 1);

                worksheet.Columns.AutoFit();
                worksheet.Rows.AutoFit();
                //   worksheet.Name = dt.TableName;
                worksheet.Cells[1, 1] = Global.sCompanyName;
                worksheet.Range["A1:C1"].Cells.Font.Size = 14;
                worksheet.Range["A1:C1"].Cells.Font.Bold = 14;
                worksheet.get_Range("A1", "B1").Merge(true);
                // Fast data export to Excel
                string excelRange;//= string.Format("A5:{0}{1}", finalColLetter, dt.Rows.Count);
                worksheet.Rows.RowHeight = "18";
                switch (tablename)
                {
                    case "Stock Balance":
                        // worksheet.Name = "Stock Balance";
                        worksheet.get_Range("E1", "F1").Merge(true);
                        Microsoft.Office.Interop.Excel.Range r = worksheet.get_Range("E6", "E99999");
                        r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                        worksheet.Cells[2, 2] = "Stock Balance"; worksheet.Range["A2:C2"].Cells.Font.Size = 14;
                        worksheet.Cells[3, 1] = "Total Stock Balance"; worksheet.Range["A3:B3"].Cells.Font.Size = 12;
                        worksheet.Cells[3, 2] = Total.ToString(); worksheet.Range["A3:C4"].Cells.Font.Size = 12;
                        worksheet.Range["A1:C4"].Cells.Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[7, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[7, Type.Missing]).Font.Size = 12;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[7, Type.Missing]).Font.Color = Color.Blue;
                        excelRange = string.Format("A7:{0}{1}", finalColLetter, dt.Rows.Count + 7);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.get_Range("C6", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                        worksheet.Columns[2].ColumnWidth = 50;
                        worksheet.Columns[2].WrapText = true;
                        worksheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        Microsoft.Office.Interop.Excel.Range oRange = worksheet.get_Range("G6", "I99999");
                        oRange.EntireColumn.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignRight;
                        fnExcelPrint(worksheet, "A1:K" + (dt.Rows.Count + 7) + "");
                        fnDrawLogo(worksheet, 1, 7);
                        Process.Start(ExcelFolderPath);
                        break;
                    case "Inventory grading report":
                        worksheet.Cells[2, 1] = "Inventory grading report";
                        worksheet.Cells[3, 1] = "Dated : " + DateTime.Now.ToString();
                        worksheet.get_Range("A2", "B2").Merge(true);
                        worksheet.Range["A2:B4"].Cells.Font.Size = 14;
                        worksheet.Range["A2:B4"].Cells.Font.Bold = true;

                        worksheet.Range["C1:I5"].Cells.Font.Color = Color.Brown;
                        worksheet.Range["C1:I5"].Cells.Font.Size = 11;
                        worksheet.Range["C1:I5"].Cells.Font.Bold = true;

                        worksheet.Range["A7:M7"].Cells.Font.Color = Color.Blue;
                        worksheet.Range["A7:M7"].Cells.Font.Bold = true;
                        worksheet.Range["A7:M7"].Cells.Font.Size = 12;

                        excelRange = string.Format("A7:{0}{1}", finalColLetter, dt.Rows.Count + 7);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.Columns[2].ColumnWidth = 50;
                        worksheet.Columns[2].WrapText = true;
                        worksheet.Columns[6].ColumnWidth = 18;
                        worksheet.Columns[7].ColumnWidth = 14;

                        fnDateFormatstring(worksheet, "C7", "C59999");
                        fnNumberFormatPercentage(worksheet, "I2", "I7");
                        worksheet.Cells[1, 7] = "Value  With OH";
                        worksheet.Cells[1, 8] = "Reserve";
                        worksheet.Cells[1, 9] = "Percentage %";
                        worksheet.Cells[2, 5] = "Stock value with OH";
                        worksheet.Cells[3, 5] = "Active";
                        worksheet.Cells[4, 5] = "Slow";
                        worksheet.Cells[5, 5] = "Obsolute";

                        worksheet.Cells[2, 3] = "Stock value";

                        worksheet.Cells[2, 4] = Math.Round(dStockvalue);

                        worksheet.Cells[2, 6] = Math.Round(dStockvalue);

                        worksheet.Cells[2, 7] = Math.Round(dStockvaluewithOH);

                        worksheet.Cells[3, 6] = Math.Round(dDActive);

                        worksheet.Cells[4, 6] = Math.Round(dDSlow);

                        worksheet.Cells[5, 6] = Math.Round(dDObsolute);

                        worksheet.Cells[3, 7] = Math.Round(dActive);

                        worksheet.Cells[4, 7] = Math.Round(dSlow);

                        worksheet.Cells[5, 7] = Math.Round(dObsolute);


                        worksheet.Cells[2, 8] = Math.Round(dReserve);

                        worksheet.Cells[3, 8] = Math.Round(dRActive);

                        worksheet.Cells[4, 8] = Math.Round(dRSlow);

                        worksheet.Cells[5, 8] = Math.Round(dRObsolute);


                        worksheet.Cells[2, 9] = (dStockvaluewithOH / dStockvaluewithOH);

                        worksheet.Cells[3, 9] = dActiveP;

                        worksheet.Cells[4, 9] = dSlowP;

                        worksheet.Cells[5, 9].Formula = dObsoluteP;


                        worksheet.Cells[2, 11] = "Direct Labour Rate";
                        worksheet.Cells[3, 11] = "Period Cost Rate:";
                        worksheet.Cells[4, 11] = "Expensed items recapitalization rate";

                        worksheet.Cells[2, 12] = "";
                        worksheet.Cells[3, 12] = "";
                        worksheet.Cells[4, 12] = "";

                        fnExcelPrint(worksheet, "A1:S" + (dt.Rows.Count + 7) + "");
                        // fnDrawLogo(worksheet, 1, 10);
                        Process.Start(ExcelFolderPath);
                        break;

                    case "CInventory Grading":
                        worksheet.Cells[2, 1] = "Customer Project Grading Report";
                        worksheet.Cells[3, 1] = "Dated : " + DateTime.Now.ToString();
                        worksheet.get_Range("A2", "B2").Merge(true);
                        worksheet.Range["A2:B4"].Cells.Font.Size = 14;
                        worksheet.Range["A2:B4"].Cells.Font.Bold = true;

                        worksheet.Range["C1:I5"].Cells.Font.Color = Color.Brown;
                        worksheet.Range["C1:I5"].Cells.Font.Size = 11;
                        worksheet.Range["C1:I5"].Cells.Font.Bold = true;

                        worksheet.Range["A7:M7"].Cells.Font.Color = Color.Blue;
                        worksheet.Range["A7:M7"].Cells.Font.Bold = true;
                        worksheet.Range["A7:M7"].Cells.Font.Size = 12;

                        excelRange = string.Format("A7:{0}{1}", finalColLetter, dt.Rows.Count + 7);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.Columns[2].ColumnWidth = 50;
                        worksheet.Columns[2].WrapText = true;
                        worksheet.Columns[6].ColumnWidth = 18;
                        worksheet.Columns[7].ColumnWidth = 14;

                        fnDateFormatstring(worksheet, "C7", "C59999");
                        fnNumberFormatPercentage(worksheet, "I2", "I7");
                        worksheet.Cells[1, 7] = "Value  With OH";
                        worksheet.Cells[1, 8] = "Reserve";
                        worksheet.Cells[1, 9] = "Percentage %";
                        worksheet.Cells[2, 5] = "Stock value with OH";
                        worksheet.Cells[3, 5] = "Active";
                        worksheet.Cells[4, 5] = "Slow";
                        worksheet.Cells[5, 5] = "Obsolute";

                        worksheet.Cells[2, 3] = "Stock value";

                        worksheet.Cells[2, 4] = Math.Round(dStockvalue);

                        worksheet.Cells[2, 6] = Math.Round(dStockvalue);

                        worksheet.Cells[2, 7] = Math.Round(dStockvaluewithOH);

                        worksheet.Cells[3, 6] = Math.Round(dDActive);

                        worksheet.Cells[4, 6] = Math.Round(dDSlow);

                        worksheet.Cells[5, 6] = Math.Round(dDObsolute);

                        worksheet.Cells[3, 7] = Math.Round(dActive);

                        worksheet.Cells[4, 7] = Math.Round(dSlow);

                        worksheet.Cells[5, 7] = Math.Round(dObsolute);


                        worksheet.Cells[2, 8] = Math.Round(dReserve);

                        worksheet.Cells[3, 8] = Math.Round(dRActive);

                        worksheet.Cells[4, 8] = Math.Round(dRSlow);

                        worksheet.Cells[5, 8] = Math.Round(dRObsolute);


                        worksheet.Cells[2, 9] = (dStockvaluewithOH / dStockvaluewithOH);

                        worksheet.Cells[3, 9] = dActiveP;

                        worksheet.Cells[4, 9] = dSlowP;

                        worksheet.Cells[5, 9].Formula = dObsoluteP;


                        worksheet.Cells[2, 11] = "Direct Labour Rate";
                        worksheet.Cells[3, 11] = "Period Cost Rate:";
                        worksheet.Cells[4, 11] = "Expensed items recapitalization rate";

                        worksheet.Cells[2, 12] = "0.08729878";
                        worksheet.Cells[3, 12] = "0.14299940";
                        worksheet.Cells[4, 12] = "-0.00702831";

                        fnExcelPrint(worksheet, "A1:S" + (dt.Rows.Count + 7) + "");
                        // fnDrawLogo(worksheet, 1, 10);
                        Process.Start(ExcelFolderPath);
                        break;
                    case "GINPO":
                        //  worksheet.Name = "ItemUsage";
                        worksheet.Cells[2, 2] = "GIN Report";
                        worksheet.Range["A2:C2"].Cells.Font.Size = 14;
                        worksheet.Range["A2:C2"].Cells.Font.Bold = 14;

                        worksheet.Cells[3, 1] = "Total NetAmount:";
                        worksheet.Cells[3, 2] = dNetAmount.ToString();
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[3, Type.Missing]).Font.Color = Color.Red;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[3, Type.Missing]).Font.Bold = true;

                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[7, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[7, Type.Missing]).Font.Size = 12;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[7, Type.Missing]).Font.Color = Color.Blue;
                        excelRange = string.Format("A7:{0}{1}", finalColLetter, dt.Rows.Count + 7);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.get_Range("D6", "E9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;

                        worksheet.Columns[2].ColumnWidth = 50;
                        worksheet.Columns[2].WrapText = true;
                        worksheet.Columns[5].ColumnWidth = 50;
                        worksheet.Columns[5].WrapText = true;

                        worksheet.Columns[11].ColumnWidth = 50;
                        worksheet.Columns[11].WrapText = true;

                        //Microsoft.Office.Interop.Excel.Range range = worksheet.get_Range("D5", "E9999");
                        //range.NumberFormat = "0.00";
                        // worksheet.get_Range("C5", "D9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignRight;
                        fnExcelPrint(worksheet, "A1:BA" + (dt.Rows.Count + 7) + "");
                        fnDrawLogo(worksheet, 1, 10);
                        // This returns something like C:\Users\Username:
                        string userRoot = System.Environment.GetEnvironmentVariable("USERPROFILE");
                        // Now let's get C:\Users\Username\Downloads:

                        if (cmbReport.Text == "Consolidated GIN Report PO")
                        {
                            fnDateFormatstring(worksheet, "AW7", "AW99999");
                            string downloadFolder = Path.Combine(userRoot, "Downloads");
                            ExcelFolderPath = downloadFolder + "\\Consolidated GIN PO Report\\";
                            Process.Start(ExcelFolderPath);
                        }
                        else
                        {
                            worksheet.Columns[12].ColumnWidth = 50;
                            worksheet.Columns[12].WrapText = true;
                            fnDateFormatstring(worksheet, "AV7", "AY99999");
                            string downloadFolder = Path.Combine(userRoot, "Downloads");
                            ExcelFolderPath = downloadFolder + "\\Consolidated GIN PO and WO Report\\";
                            Process.Start(ExcelFolderPath);
                        }
                        break;

                    //

                    case "Project Master":
                        worksheet.Cells[2, 2] = "Project Master"; worksheet.Range["A2:C2"].Cells.Font.Size = 14;
                        worksheet.Range["A2:C2"].Cells.Font.Bold = 14;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Size = 12;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Color = Color.Blue;
                        excelRange = string.Format("A5:{0}{1}", finalColLetter, dt.Rows.Count + 5);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.get_Range("C6", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                        worksheet.Columns[3].ColumnWidth = 50;
                        worksheet.Columns[3].WrapText = true;
                        worksheet.Columns[4].ColumnWidth = 40;
                        worksheet.Columns[4].WrapText = true;
                        worksheet.Columns[16].ColumnWidth = 40;
                        worksheet.Columns[16].WrapText = true;
                        // worksheet.Columns[6].ColumnWidth = 40;
                        // worksheet.Columns[6].WrapText = true;
                        // worksheet.Columns[22].ColumnWidth = 40;
                        // worksheet.Columns[22].WrapText = true;
                        worksheet.Rows.RowHeight = "18";
                        fnDateFormatstring(worksheet, "H6", "H9999");
                        //  fnDateFormatstring(worksheet, "AD6", "AD9999");
                        // worksheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        fnExcelPrint(worksheet, "A1:S" + (dt.Rows.Count + 5) + "");
                        // fnDrawLogo(worksheet, 1, 14);
                        Process.Start(ExcelFolderPath);
                        break;



                    case "Vendors":
                        worksheet.Cells[2, 2] = "Vendor List"; worksheet.Range["A2:C2"].Cells.Font.Size = 14;
                        worksheet.Range["A2:C2"].Cells.Font.Bold = 14;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Size = 12;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Color = Color.Blue;
                        excelRange = string.Format("A5:{0}{1}", finalColLetter, dt.Rows.Count + 5);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.get_Range("C6", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                        worksheet.Columns[2].ColumnWidth = 50;
                        worksheet.Columns[2].WrapText = true;
                        worksheet.Columns[4].ColumnWidth = 40;
                        worksheet.Columns[4].WrapText = true;
                        worksheet.Columns[5].ColumnWidth = 40;
                        worksheet.Columns[5].WrapText = true;
                        worksheet.Columns[6].ColumnWidth = 40;
                        worksheet.Columns[6].WrapText = true;
                        worksheet.Columns[22].ColumnWidth = 40;
                        worksheet.Columns[22].WrapText = true;
                        worksheet.Rows.RowHeight = "18";
                        fnDateFormatstring(worksheet, "AB6", "AB9999");
                        fnDateFormatstring(worksheet, "AD6", "AD9999");
                        worksheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        fnExcelPrint(worksheet, "A1:S" + (dt.Rows.Count + 5) + "");
                        fnDrawLogo(worksheet, 1, 14);
                        Process.Start(ExcelFolderPath);
                        break;

                    //

                    case "Fixed Asset Register":
                        worksheet.Cells[2, 2] = "Fixed Asset Register"; worksheet.Range["A2:C2"].Cells.Font.Size = 14;
                        worksheet.Range["A2:C2"].Cells.Font.Bold = 14;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Size = 12;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Color = Color.Blue;
                        excelRange = string.Format("A5:{0}{1}", finalColLetter, dt.Rows.Count + 5);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        // worksheet.get_Range("C6", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                        worksheet.Columns[7].ColumnWidth = 50;
                        worksheet.Columns[7].WrapText = true;
                        worksheet.Columns[11].ColumnWidth = 40;
                        worksheet.Columns[11].WrapText = true;
                        worksheet.Columns[12].ColumnWidth = 40;
                        worksheet.Columns[12].WrapText = true;
                        worksheet.Columns[13].ColumnWidth = 40;
                        worksheet.Columns[13].WrapText = true;
                        worksheet.Columns[14].ColumnWidth = 40;
                        worksheet.Columns[14].WrapText = true;
                        worksheet.Columns[22].ColumnWidth = 40;
                        worksheet.Columns[22].WrapText = true;
                        worksheet.Columns[24].ColumnWidth = 40;
                        worksheet.Columns[24].WrapText = true;
                        worksheet.Rows.RowHeight = "18";
                        fnDateFormatstring(worksheet, "O6", "O9999");
                        fnDateFormatstring(worksheet, "W6", "W9999");
                        fnDateFormatstring(worksheet, "T6", "T9999");
                        // worksheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        fnExcelPrint(worksheet, "A1:Y" + (dt.Rows.Count + 5) + "");
                        //  fnDrawLogo(worksheet, 1, 14);
                        Process.Start(ExcelFolderPath);
                        break;

                    case "ERP Log Report":
                        worksheet.Cells[2, 2] = "ERP Log Report from " + dtpFromDate.Text + " To " + dptToDate.Text;

                        worksheet.Range["A2:C2"].Cells.Font.Size = 14;
                        worksheet.Range["A2:C2"].Cells.Font.Bold = 14;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Size = 12;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Color = Color.Blue;
                        excelRange = string.Format("A5:{0}{1}", finalColLetter, dt.Rows.Count + 5);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        // worksheet.get_Range("C6", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                        //worksheet.Columns[7].ColumnWidth = 50;
                        //worksheet.Columns[7].WrapText = true;
                        //worksheet.Columns[11].ColumnWidth = 40;
                        //worksheet.Columns[11].WrapText = true;
                        //worksheet.Columns[12].ColumnWidth = 40;
                        //worksheet.Columns[12].WrapText = true;
                        //worksheet.Columns[13].ColumnWidth = 40;
                        //worksheet.Columns[13].WrapText = true;
                        //worksheet.Columns[14].ColumnWidth = 40;
                        //worksheet.Columns[14].WrapText = true;
                        //worksheet.Columns[22].ColumnWidth = 40;
                        //worksheet.Columns[22].WrapText = true;
                        //worksheet.Columns[24].ColumnWidth = 40;
                        //worksheet.Columns[24].WrapText = true;
                        worksheet.Rows.RowHeight = "18";
                        fnDateFormatstring(worksheet, "C6", "C99999");
                        fnDateFormatstring1(worksheet, "E6", "C99999");
                        fnDateFormatstring(worksheet, "F6", "F99999");
                        // worksheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        fnExcelPrint(worksheet, "A1:F" + (dt.Rows.Count + 5) + "");
                        //  fnDrawLogo(worksheet, 1, 14);
                        Process.Start(ExcelFolderPath);
                        break;



                    case "ERP WAR Log Report":
                        worksheet.Cells[2, 2] = "ERP WAR Log Report from " + dtpFromDate.Text + " To " + dptToDate.Text;

                        worksheet.Range["A2:C2"].Cells.Font.Size = 14;
                        worksheet.Range["A2:C2"].Cells.Font.Bold = 14;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Size = 12;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Color = Color.Blue;
                        excelRange = string.Format("A5:{0}{1}", finalColLetter, dt.Rows.Count + 5);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        // worksheet.get_Range("C6", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                        //worksheet.Columns[7].ColumnWidth = 50;
                        //worksheet.Columns[7].WrapText = true;
                        //worksheet.Columns[11].ColumnWidth = 40;
                        //worksheet.Columns[11].WrapText = true;
                        //worksheet.Columns[12].ColumnWidth = 40;
                        //worksheet.Columns[12].WrapText = true;
                        //worksheet.Columns[13].ColumnWidth = 40;
                        //worksheet.Columns[13].WrapText = true;
                        //worksheet.Columns[14].ColumnWidth = 40;
                        //worksheet.Columns[14].WrapText = true;
                        //worksheet.Columns[22].ColumnWidth = 40;
                        //worksheet.Columns[22].WrapText = true;
                        //worksheet.Columns[24].ColumnWidth = 40;
                        //worksheet.Columns[24].WrapText = true;
                        worksheet.Rows.RowHeight = "18";
                        fnDateFormatstring(worksheet, "C6", "C99999");
                        fnDateFormatstring(worksheet, "E6", "C99999");
                        fnDateFormatstring(worksheet, "F6", "F99999");
                        // worksheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        fnExcelPrint(worksheet, "A1:F" + (dt.Rows.Count + 5) + "");
                        //  fnDrawLogo(worksheet, 1, 14);
                        Process.Start(ExcelFolderPath);
                        break;



                    case "DepartmentWise POWO":

                        worksheet.Cells[2, 2] = "DepartmentWise PO/WO";
                        worksheet.Range["A2:C2"].Cells.Font.Size = 14;
                        worksheet.Range["A2:C2"].Cells.Font.Bold = 14;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Size = 12;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Color = Color.Blue;
                        excelRange = string.Format("A5:{0}{1}", finalColLetter, dt.Rows.Count + 5);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.Columns[3].ColumnWidth = 35;
                        worksheet.Columns[3].WrapText = true;
                        worksheet.Columns[4].ColumnWidth = 35;
                        worksheet.Columns[4].WrapText = true;
                        worksheet.Columns[9].ColumnWidth = 40;
                        worksheet.Columns[9].WrapText = true;
                        worksheet.Rows.RowHeight = "18";
                        fnDateFormatstring(worksheet, "G6", "G9999");
                        fnExcelPrint(worksheet, "A1:Q" + (dt.Rows.Count + 5) + "");
                        Process.Start(ExcelFolderPath);

                        break;

                    case "Issued":
                        fnNumberFormat(worksheet, 14, 18);
                        fnDateFormat(worksheet, 11, 13);
                        worksheet.Cells[2, 2] = "Issued Report";
                        worksheet.Range["A2:B2"].Cells.Font.Size = 14;
                        worksheet.Range["A2:B2"].Cells.Font.Bold = 14;
                        worksheet.Cells[4, 2] = "Grand Total:";
                        worksheet.Cells[4, 3] = dataSet.Tables[0].Compute("Sum(Amount)", "").ToString();
                        excelRange = string.Format("A6:{0}{1}", finalColLetter, dt.Rows.Count + 6);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[6, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[6, Type.Missing]).Font.Color = Color.Blue;
                        worksheet.Range["A4:C5"].Cells.Font.Size = 14;
                        worksheet.Range["A4:C5"].Cells.Font.Bold = 14;
                        CellMerge("Merge", NewWorkBook.ActiveSheet, 1, 1, 1, 3);
                        worksheet.get_Range("C6", "C99999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        fnDateFormatstring(worksheet, "K6", "M99999");
                        fnNumberFormatstring(worksheet, "N6", "R99999");
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.Columns[1].ColumnWidth = 30;
                        worksheet.Columns[1].WrapText = true;
                        worksheet.Columns[2].ColumnWidth = 45;
                        worksheet.Columns[2].WrapText = true;
                        worksheet.Columns[3].ColumnWidth = 40;
                        worksheet.Columns[3].WrapText = true;
                        worksheet.Columns[7].ColumnWidth = 50;
                        worksheet.Columns[7].WrapText = true;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        fnDrawLogo(worksheet, 2, 5);
                        Process.Start(ExcelFolderPath);
                        break;

                    case "Project Issued ItemReturn":
                        worksheet.Cells[2, 1] = "Project Issued ItemReturn";
                        worksheet.Range["A2:B4"].Cells.Font.Size = 14;
                        worksheet.Range["A2:B4"].Cells.Font.Bold = 14;
                        worksheet.Cells[4, 1] = "Grand Total:";
                        worksheet.Cells[4, 2] = dataSet.Tables[0].Compute("Sum(Amount)", "").ToString();
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[6, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[6, Type.Missing]).Font.Color = Color.Blue;
                        excelRange = string.Format("A6:{0}{1}", finalColLetter, dt.Rows.Count + 6);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        fnDateFormatstring(worksheet, "J7", "J9999");
                        fnNumberFormatstring(worksheet, "G7", "I9999");
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        fnDrawLogo(worksheet, 1, 5);
                        Process.Start(ExcelFolderPath);
                        break;
                    case "Job Issued ItemReturn":
                        worksheet.Cells[2, 1] = "Job Issued ItemReturn";
                        worksheet.Range["A2:B4"].Cells.Font.Size = 14;
                        worksheet.Range["A2:B4"].Cells.Font.Bold = 14;
                        worksheet.Cells[4, 1] = "Grand Total:";
                        worksheet.Cells[4, 2] = dataSet.Tables[0].Compute("Sum(Amount)", "").ToString();
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[6, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[6, Type.Missing]).Font.Color = Color.Blue;
                        excelRange = string.Format("A6:{0}{1}", finalColLetter, dt.Rows.Count + 6);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        fnDateFormatstring(worksheet, "J7", "J9999");
                        fnNumberFormatstring(worksheet, "G7", "I9999");
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        fnDrawLogo(worksheet, 1, 5);
                        Process.Start(ExcelFolderPath);
                        break;
                    case "Purchase Register":
                        //Microsoft.Office.Interop.Excel.Range r = worksheet.get_Range("E5", "M99999");
                        //r.EntireColumn.NumberFormat = "0.00";
                        fnNumberFormatstring(worksheet, "F5", "N99999");
                        fnDateFormatstring(worksheet, "B5", "B99999");

                        worksheet.Cells[2, 2] = "Purchase Register";
                        worksheet.Range["A2:C2"].Cells.Font.Size = 14;
                        worksheet.Range["A2:C2"].Cells.Font.Bold = 14;
                        excelRange = string.Format("A4:{0}{1}", finalColLetter, dt.Rows.Count + 4);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[4, Type.Missing]).Font.Bold = true;
                        worksheet.Columns.AutoFit(); worksheet.Rows.AutoFit();
                        Process.Start(ExcelFolderPath);
                        break;
                    case "Riverse GIN":
                        //Microsoft.Office.Interop.Excel.Range r = worksheet.get_Range("D5", "G99999");
                        //r.EntireColumn.NumberFormat = "0.00";
                        fnNumberFormatstring(worksheet, "D5", "G99999");
                        fnNumberFormatstring(worksheet, "N5", "S99999");
                        fnDateFormatstring(worksheet, "K5", "M99999");
                        //Microsoft.Office.Interop.Excel.Range r2 = worksheet.get_Range("N5", "S99999");
                        //r2.EntireColumn.NumberFormat = "0.00";
                        //Microsoft.Office.Interop.Excel.Range date = worksheet.get_Range("K5", "M99999");
                        //date.EntireColumn.NumberFormat = "DD/MM/YYYY";
                        worksheet.Cells[2, 2] = "Riverse GIN";
                        // DataTable firstTable = dataSet.Tables;
                        worksheet.Cells[2, 3] = "Total";
                        worksheet.Cells[2, 4] = dataSet.Tables[0].Compute("Sum(Amount)", "").ToString();
                        worksheet.Range["A2:D2"].Cells.Font.Size = 14;
                        worksheet.Range["A2:D2"].Cells.Font.Bold = 14;
                        excelRange = string.Format("A4:{0}{1}", finalColLetter, dt.Rows.Count + 4);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[4, Type.Missing]).Font.Bold = true;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        Process.Start(ExcelFolderPath);
                        break;

                    case "GIN Job Work":
                        //Microsoft.Office.Interop.Excel.Range r2 = worksheet.get_Range("E5", "M99999");
                        //r2.EntireColumn.NumberFormat = "0.00";
                        //Microsoft.Office.Interop.Excel.Range date = worksheet.get_Range("B5", "B99999");
                        //date.EntireColumn.NumberFormat = "DD/MM/YYYY";
                        fnDateFormatstring(worksheet, "B5", "B99999");
                        fnNumberFormatstring(worksheet, "E5", "M99999");
                        worksheet.Cells[2, 2] = "GIN Job Work";
                        worksheet.Cells[3, 2] = "Total";
                        worksheet.Cells[3, 3] = dataSet.Tables[0].Compute("Sum(Amount)", "").ToString();
                        worksheet.Range["A2:D3"].Cells.Font.Size = 14;
                        worksheet.Range["A2:D3"].Cells.Font.Bold = 14;
                        excelRange = string.Format("A4:{0}{1}", finalColLetter, dt.Rows.Count + 4);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[4, Type.Missing]).Font.Size = 13;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[4, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[4, Type.Missing]).Font.Color = Color.Blue;
                        worksheet.Columns.AutoFit(); worksheet.Rows.AutoFit();
                        Process.Start(ExcelFolderPath);
                        break;
                    case "Project PO Placed":
                        //Microsoft.Office.Interop.Excel.Range r = worksheet.get_Range("G5", "J99999");
                        //r.EntireColumn.NumberFormat = "0.00";
                        //Microsoft.Office.Interop.Excel.Range r2 = worksheet.get_Range("S5", "AC99999");
                        //r2.EntireColumn.NumberFormat = "0.00";
                        //Microsoft.Office.Interop.Excel.Range date = worksheet.get_Range("L5", "Q99999");
                        //date.EntireColumn.NumberFormat = "DD/MM/YYYY";

                        fnNumberFormatstring(worksheet, "G5", "J99999");
                        fnNumberFormatstring(worksheet, "S5", "AC99999");
                        fnDateFormatstring(worksheet, "L5", "Q99999");
                        worksheet.Cells[3, 1] = "PO Placed for Porject : " + txtProjectCode.Text + "";
                        worksheet.Cells[4, 1] = "Porject code : " + cmbProjectCode.Text + "";
                        worksheet.Range["A3:C4"].Cells.Font.Size = 14;
                        worksheet.Range["A3:C4"].Cells.Font.Bold = 14;
                        worksheet.get_Range("A3", "C3").Merge(true);
                        worksheet.get_Range("A4", "C3").Merge(true);
                        excelRange = string.Format("A6:{0}{1}",
                        finalColLetter, dt.Rows.Count + 4);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[6, Type.Missing]).Font.Bold = true;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.Columns[5].ColumnWidth = 40;
                        worksheet.Columns[5].WrapText = true;
                        worksheet.Columns[2].WrapText = true;
                        Process.Start(ExcelFolderPath);
                        break;

                    case "Receipt":
                        //  worksheet.Name = "Receipt Report";
                        fnDateFormatstring(worksheet, "J6", "J99999");
                        //Microsoft.Office.Interop.Excel.Range r = worksheet.get_Range("J6", "J99999");
                        //r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                        worksheet.Cells[3, 1] = "Receipt Report"; worksheet.Range["A1:C3"].Cells.Font.Size = 14;
                        worksheet.Range["A1:C3"].Cells.Font.Bold = true;
                        worksheet.get_Range("A1", "C3").Merge(true);
                        excelRange = string.Format("A7:{0}{1}",
                       finalColLetter, dt.Rows.Count + 7);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[7, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[7, Type.Missing]).Font.Color = Color.Blue;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[7, Type.Missing]).Font.Size = 12;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.get_Range("C6", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                        worksheet.Columns[3].ColumnWidth = 50;
                        worksheet.Columns[3].WrapText = true;
                        worksheet.Columns[9].ColumnWidth = 45;
                        worksheet.Columns[9].WrapText = true;
                        worksheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        Microsoft.Office.Interop.Excel.Range oRangeee = worksheet.get_Range("F6", "H99999");
                        oRangeee.EntireColumn.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignRight;
                        worksheet.Rows.RowHeight = "18";
                        // int Print = dt.Rows.Count + 7;
                        worksheet.PageSetup.PrintArea = "A1:L" + (dt.Rows.Count + 7) + "";
                        worksheet.PageSetup.PrintTitleRows = "$1:$2";
                        worksheet.PageSetup.PrintNotes = true;
                        worksheet.PageSetup.Zoom = 65;
                        worksheet.PageSetup.PrintGridlines = true;
                        worksheet.PageSetup.LeftMargin = 0;
                        worksheet.PageSetup.RightMargin = 0;
                        worksheet.PageSetup.TopMargin = 0.75;
                        worksheet.PageSetup.BottomMargin = 0.75;
                        worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                        worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
                        fnDrawLogo(worksheet, 1, 8);
                        //Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[1, 8];
                        //System.Drawing.Image oImage = System.Drawing.Image.FromFile(Global.sLogo);
                        //System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                        //worksheet.Paste(oRange, Global.sLogo);
                        Process.Start(ExcelFolderPath);
                        break;
                    case "Job Issued":
                        fnNumberFormatstring(worksheet, "S5", "AC99999");
                        fnDateFormat(worksheet, 1, 1);
                        fnNumberFormat(worksheet, 9, 12);
                        fnNumberFormat(worksheet, 19, 21);
                        //Microsoft.Office.Interop.Excel.Range r = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[1, 1];
                        //r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                        //Microsoft.Office.Interop.Excel.Range r2 = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[9, 12];
                        //r2.EntireColumn.NumberFormat = "0.00";
                        //Microsoft.Office.Interop.Excel.Range r3 = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[19, 21];
                        //r3.EntireColumn.NumberFormat = "0.00";
                        worksheet.Cells[2, 2] = "Job Issued";
                        worksheet.Range["A2:C2"].Cells.Font.Size = 14;
                        worksheet.Range["A2:C2"].Cells.Font.Bold = 14;
                        excelRange = string.Format("A8:{0}{1}", finalColLetter, dt.Rows.Count + 8);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[8, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[8, Type.Missing]).Font.Color = Color.Blue;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.Columns[8].ColumnWidth = 50;
                        worksheet.Columns[8].WrapText = true;
                        worksheet.Columns[17].ColumnWidth = 50;
                        worksheet.Columns[17].WrapText = true;
                        worksheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        worksheet.Rows.RowHeight = "18";
                        //int print = dt.Rows.Count + 5;
                        worksheet.PageSetup.PrintArea = "A1:L" + (dt.Rows.Count + 5) + "";
                        worksheet.PageSetup.PrintTitleRows = "$1:$2";
                        worksheet.PageSetup.PrintNotes = true;
                        worksheet.PageSetup.Zoom = 65;
                        worksheet.PageSetup.PrintGridlines = true;
                        worksheet.PageSetup.LeftMargin = 0;
                        worksheet.PageSetup.RightMargin = 0;
                        worksheet.PageSetup.TopMargin = 0.75;
                        worksheet.PageSetup.BottomMargin = 0.75;
                        worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                        worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
                        //Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[1, 4];
                        //System.Drawing.Image oImage = System.Drawing.Image.FromFile(Global.sLogo);
                        //System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                        //worksheet.Paste(oRange, Global.sLogo);
                        fnDrawLogo(worksheet, 1, 4);
                        Process.Start(ExcelFolderPath);
                        break;
                    case "Job In Progress":
                        //Microsoft.Office.Interop.Excel.Range r = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[1, 10];
                        //r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                        fnDateFormat(worksheet, 1, 10);
                        worksheet.Cells[2, 2] = "Job In Progress"; worksheet.Range["A2:C2"].Cells.Font.Size = 14;
                        worksheet.Range["A2:C2"].Cells.Font.Bold = 14;
                        excelRange = string.Format("A8:{0}{1}", finalColLetter, dt.Rows.Count + 8);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[8, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[8, Type.Missing]).Font.Color = Color.Blue;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.Columns[4].ColumnWidth = 50;
                        worksheet.Columns[4].WrapText = true;
                        worksheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        worksheet.Rows.RowHeight = "18";
                        //  int print = dt.Rows.Count + 5;
                        worksheet.PageSetup.PrintArea = "A1:L" + (dt.Rows.Count + 5) + "";
                        worksheet.PageSetup.PrintTitleRows = "$1:$2";
                        worksheet.PageSetup.PrintNotes = true;
                        worksheet.PageSetup.Zoom = 65;
                        worksheet.PageSetup.PrintGridlines = true;
                        worksheet.PageSetup.LeftMargin = 0;
                        worksheet.PageSetup.RightMargin = 0;
                        worksheet.PageSetup.TopMargin = 0.75;
                        worksheet.PageSetup.BottomMargin = 0.75;
                        worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                        worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
                        //Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[1, 4];
                        //System.Drawing.Image oImage = System.Drawing.Image.FromFile(Global.sLogo);
                        //System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                        //worksheet.Paste(oRange, Global.sLogo);
                        fnDrawLogo(worksheet, 1, 4);
                        Process.Start(ExcelFolderPath);
                        break;
                    case "Stock Adjusted":
                        fnDateFormat(worksheet, 1, 10);
                        //Microsoft.Office.Interop.Excel.Range r = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[1, 10];
                        //r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                        worksheet.Cells[2, 2] = "Stock Adjusted"; worksheet.Range["A2:C2"].Cells.Font.Size = 14;
                        worksheet.Range["A2:C2"].Cells.Font.Bold = 14;
                        excelRange = string.Format("A5:{0}{1}",
                       finalColLetter, dt.Rows.Count + 5);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Color = Color.Blue;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.Columns[3].ColumnWidth = 50;
                        worksheet.Columns[3].WrapText = true;
                        worksheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        worksheet.Rows.RowHeight = "18";
                        // int print = dt.Rows.Count + 5;
                        worksheet.PageSetup.PrintArea = "A1:L" + (dt.Rows.Count + 5) + "";
                        worksheet.PageSetup.PrintTitleRows = "$1:$2";
                        worksheet.PageSetup.PrintNotes = true;
                        worksheet.PageSetup.Zoom = 65;
                        worksheet.PageSetup.PrintGridlines = true;
                        worksheet.PageSetup.LeftMargin = 0;
                        worksheet.PageSetup.RightMargin = 0;
                        worksheet.PageSetup.TopMargin = 0.75;
                        worksheet.PageSetup.BottomMargin = 0.75;
                        worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                        worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
                        fnDrawLogo(worksheet, 1, 4);
                        //Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[1, 4];
                        //System.Drawing.Image oImage = System.Drawing.Image.FromFile(Global.sLogo);
                        //System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                        //worksheet.Paste(oRange, Global.sLogo);
                        Process.Start(ExcelFolderPath);
                        break;
                    case "PurchaseCost":
                        //  worksheet.Name = "Purchase Cost";
                        //Microsoft.Office.Interop.Excel.Range r = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[1, 2];
                        //r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                        fnDateFormat(worksheet, 1, 2);
                        worksheet.Cells[2, 1] = "Purchase Cost Report From " + dtpFromDate.Text + " To " + dptToDate.Text + "";
                        //Purchase Cost (" + dtpFromDate.Text + " To " + dptToDate.Text + ")
                        worksheet.Range["A2:B3"].Cells.Font.Color = Color.Blue;
                        worksheet.Range["A2:B3"].Cells.Font.Bold = 14;
                        worksheet.get_Range("A2", "C2").Merge(true);
                        excelRange = string.Format("A5:{0}{1}",
                        finalColLetter, dt.Rows.Count + 5);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Color = Color.Blue;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Size = 12;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.get_Range("C6", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                        worksheet.Columns[2].ColumnWidth = 50;
                        worksheet.Columns[2].WrapText = true;
                        worksheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        worksheet.Rows.RowHeight = "18";
                        fnNumberFormatstring(worksheet, "E6", "I99999");
                        // fnDateFormat(worksheet, 3, 3);
                        //fnDateFormat(worksheet, 4, 11);
                        fnDateFormatstring(worksheet, "L6", "L99999");
                        fnDateFormatstring(worksheet, "C6", "C99999");
                        //Microsoft.Office.Interop.Excel.Range range = worksheet.get_Range("E6", "G9999");
                        //range.NumberFormat = "0.00";

                        //Microsoft.Office.Interop.Excel.Range r1 = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[3, 3];
                        //r1.EntireColumn.NumberFormat = "DD/MM/YYYY";

                        //Microsoft.Office.Interop.Excel.Range r4 = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[4, 11];
                        //r4.EntireColumn.NumberFormat = "DD/MM/YYYY";
                        //Microsoft.Office.Interop.Excel.Range range1 = worksheet.get_Range("C6", "C9999");
                        //range1.NumberFormat = "DD/MM/YYYY";
                        //Microsoft.Office.Interop.Excel.Range range2 = worksheet.get_Range("L6", "L9999");
                        //range2.NumberFormat = "DD/MM/YYYY";
                        //int Print = dt.Rows.Count + 8;
                        worksheet.PageSetup.PrintArea = "A1:G" + (dt.Rows.Count + 8) + "";
                        worksheet.PageSetup.PrintTitleRows = "$1:$2";
                        worksheet.PageSetup.PrintNotes = true;
                        worksheet.PageSetup.Zoom = 65;
                        worksheet.PageSetup.PrintGridlines = true;
                        worksheet.PageSetup.LeftMargin = 0;
                        worksheet.PageSetup.RightMargin = 0;
                        worksheet.PageSetup.TopMargin = 0.75;
                        worksheet.PageSetup.BottomMargin = 0.75;
                        worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                        worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
                        //Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[1, 5];
                        //System.Drawing.Image oImage = System.Drawing.Image.FromFile(Global.sLogo);
                        //System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                        //worksheet.Paste(oRange, Global.sLogo);
                        fnDrawLogo(worksheet, 1, 5);
                        Process.Start(ExcelFolderPath);
                        break;
                    case "Transactionalspenddata":

                        //  worksheet.Name = "Transactional Spend Data";
                        //Microsoft.Office.Interop.Excel.Range r = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[3, 3];
                        //r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                        fnDateFormat(worksheet, 3, 3);
                        worksheet.Cells[2, 1] = "Transactional spend data Report";
                        worksheet.Range["A2:B3"].Cells.Font.Color = Color.Blue;
                        worksheet.Range["A2:B3"].Cells.Font.Bold = 14;
                        worksheet.get_Range("A2", "C2").Merge(true);
                        worksheet.Cells[3, 1] = "Date : " + DateTime.Today.ToString("dd-MM-yyyy") + "";
                        worksheet.Range["A3:B3"].Cells.Font.Size = 12;
                        worksheet.Range["A3:B3"].Cells.Font.Bold = true;
                        worksheet.get_Range("A3", "C3").Merge(true);
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Color = Color.Blue;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Size = 12;
                        excelRange = string.Format("A5:{0}{1}", finalColLetter, dt.Rows.Count + 5);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.get_Range("C6", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                        worksheet.Columns[5].ColumnWidth = 32;
                        worksheet.Columns[5].WrapText = true;
                        worksheet.Columns[6].ColumnWidth = 46;
                        worksheet.Columns[6].WrapText = true;
                        worksheet.Columns[7].ColumnWidth = 50;
                        worksheet.Columns[7].WrapText = true;
                        worksheet.Columns[8].ColumnWidth = 34;
                        worksheet.Columns[8].WrapText = true;
                        worksheet.Columns[18].ColumnWidth = 50;
                        worksheet.Columns[18].WrapText = true;
                        worksheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        worksheet.Rows.RowHeight = "18";
                        //Microsoft.Office.Interop.Excel.Range range = worksheet.get_Range("L6", "O9999");
                        //range.NumberFormat = "0.00";
                        fnNumberFormatstring(worksheet, "L6", "O9999");
                        // int Print = dt.Rows.Count + 5;
                        worksheet.PageSetup.PrintArea = "A1:G" + (dt.Rows.Count + 5) + "";
                        worksheet.PageSetup.PrintTitleRows = "$1:$2";
                        worksheet.PageSetup.PrintNotes = true;
                        worksheet.PageSetup.Zoom = 65;
                        worksheet.PageSetup.PrintGridlines = true;
                        worksheet.PageSetup.LeftMargin = 0;
                        worksheet.PageSetup.RightMargin = 0;
                        worksheet.PageSetup.TopMargin = 0.75;
                        worksheet.PageSetup.BottomMargin = 0.75;
                        worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                        worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
                        //Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[1, 4];
                        //System.Drawing.Image oImage = System.Drawing.Image.FromFile(Global.sLogo);
                        //System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                        //worksheet.Paste(oRange, Global.sLogo);
                        fnDrawLogo(worksheet, 1, 4);
                        Process.Start(ExcelFolderPath);
                        break;
                    case "ApSpenddata":
                        //  worksheet.Name = "Ap Spend Data";
                        worksheet.Cells[2, 1] = "Ap spend data Report"; worksheet.Range["A2:B3"].Cells.Font.Color = Color.Blue;
                        worksheet.Range["A2:B3"].Cells.Font.Bold = 14;
                        worksheet.get_Range("A2", "C2").Merge(true);
                        worksheet.Cells[3, 1] = "Date : " + DateTime.Today.ToString("dd-MM-yyyy") + "";
                        worksheet.Range["A3:B3"].Cells.Font.Size = 12;
                        worksheet.Range["A3:B3"].Cells.Font.Bold = true;
                        worksheet.get_Range("A3", "C3").Merge(true);
                        excelRange = string.Format("A5:{0}{1}", finalColLetter, dt.Rows.Count + 5);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Color = Color.Blue;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Size = 12;
                        worksheet.get_Range("C6", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                        worksheet.Columns[3].ColumnWidth = 50;
                        worksheet.Columns[3].WrapText = true;
                        worksheet.Columns[4].ColumnWidth = 48;
                        worksheet.Columns[4].WrapText = true;
                        worksheet.Columns[5].ColumnWidth = 50;
                        worksheet.Columns[5].WrapText = true;
                        worksheet.Columns[6].ColumnWidth = 34;
                        worksheet.Columns[6].WrapText = true;
                        worksheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        worksheet.Rows.RowHeight = "18";
                        //Microsoft.Office.Interop.Excel.Range range = worksheet.get_Range("K6", "K9999");
                        //range.NumberFormat = "0.00";
                        fnNumberFormatstring(worksheet, "K6", "K9999");
                        // int Print = dt.Rows.Count + 5;
                        worksheet.PageSetup.PrintArea = "A1:G" + (dt.Rows.Count + 5) + "";
                        worksheet.PageSetup.PrintTitleRows = "$1:$2";
                        worksheet.PageSetup.PrintNotes = true;
                        worksheet.PageSetup.Zoom = 65;
                        worksheet.PageSetup.PrintGridlines = true;
                        worksheet.PageSetup.LeftMargin = 0;
                        worksheet.PageSetup.RightMargin = 0;
                        worksheet.PageSetup.TopMargin = 0.75;
                        worksheet.PageSetup.BottomMargin = 0.75;
                        worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                        worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
                        //Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[1, 4];
                        //System.Drawing.Image oImage = System.Drawing.Image.FromFile(Global.sLogo);
                        //System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                        //worksheet.Paste(oRange, Global.sLogo);
                        fnDrawLogo(worksheet, 1, 4);
                        Process.Start(ExcelFolderPath);
                        break;
                    case "ProjectList":
                        // worksheet.Name = "ProjectList";
                        worksheet.Cells[2, 1] = "ProjectList"; worksheet.Range["A2:B3"].Cells.Font.Color = Color.Blue;
                        worksheet.Range["A2:B3"].Cells.Font.Size = 14; worksheet.Range["A2:B3"].Cells.Font.Bold = 14;
                        worksheet.get_Range("A2", "C2").Merge(true);
                        worksheet.Cells[3, 1] = "Date : " + DateTime.Today.ToString("dd-MM-yyyy") + "";
                        worksheet.Range["A3:B3"].Cells.Font.Size = 12;
                        worksheet.Range["A3:B3"].Cells.Font.Bold = true;
                        worksheet.get_Range("A3", "C3").Merge(true);
                        excelRange = string.Format("A5:{0}{1}", finalColLetter, dt.Rows.Count + 5);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Color = Color.Blue;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Size = 12;
                        worksheet.get_Range("C6", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                        worksheet.Columns[2].ColumnWidth = 50;
                        worksheet.Columns[2].WrapText = true;
                        worksheet.Columns[4].ColumnWidth = 48;
                        worksheet.Columns[4].WrapText = true;
                        worksheet.Columns[9].ColumnWidth = 50;
                        worksheet.Columns[9].WrapText = true;
                        worksheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        worksheet.Rows.RowHeight = "18";

                        Microsoft.Office.Interop.Excel.Range range1 = worksheet.get_Range("A6", "A9999");
                        range1.NumberFormat = "0";
                        fnDateFormatstring(worksheet, "E6", "H9999");
                        //Microsoft.Office.Interop.Excel.Range range = worksheet.get_Range("E6", "H9999");
                        //range.NumberFormat = "DD/MM/YYYY";
                        //   int Print = dt.Rows.Count + 5;
                        worksheet.PageSetup.PrintArea = "A1:G" + (dt.Rows.Count + 5) + "";
                        worksheet.PageSetup.PrintTitleRows = "$1:$2";
                        worksheet.PageSetup.PrintNotes = true;
                        worksheet.PageSetup.Zoom = 65;
                        worksheet.PageSetup.PrintGridlines = true;
                        worksheet.PageSetup.LeftMargin = 0;
                        worksheet.PageSetup.RightMargin = 0;
                        worksheet.PageSetup.TopMargin = 0.75;
                        worksheet.PageSetup.BottomMargin = 0.75;
                        worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                        worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
                        //Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[1, 4];
                        //System.Drawing.Image oImage = System.Drawing.Image.FromFile(Global.sLogo);
                        //System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                        //worksheet.Paste(oRange, Global.sLogo);
                        fnDrawLogo(worksheet, 1, 4);
                        Process.Start(ExcelFolderPath);
                        break;
                    case "StandarCostPO":
                        // worksheet.Name = "Standar Cost PO";
                        //Microsoft.Office.Interop.Excel.Range r = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[1, 3];
                        //r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                        fnDateFormat(worksheet, 1, 2);
                        fnDateFormat(worksheet, 1, 4);
                        fnNumberFormatstring(worksheet, "H6", "J9999");
                        worksheet.Cells[2, 1] = "Standar Cost PO";
                        worksheet.Range["A2:B3"].Cells.Font.Color = Color.Blue;
                        worksheet.Range["A2:B3"].Cells.Font.Bold = 14;
                        worksheet.get_Range("A2", "C2").Merge(true);
                        excelRange = string.Format("A5:{0}{1}", finalColLetter, dt.Rows.Count + 5);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Color = Color.Blue;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Size = 12;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.get_Range("D6", "D9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                        worksheet.Columns[6].ColumnWidth = 50;
                        worksheet.Columns[6].WrapText = true;
                        worksheet.get_Range("D6", "D9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        worksheet.Rows.RowHeight = "18";
                        //Microsoft.Office.Interop.Excel.Range range = worksheet.get_Range("E6", "G9999");
                        //range.NumberFormat = "0.00";
                        //  int Print = dt.Rows.Count + 8;
                        worksheet.PageSetup.PrintArea = "A1:G" + (dt.Rows.Count + 8) + "";
                        worksheet.PageSetup.PrintTitleRows = "$1:$2";
                        worksheet.PageSetup.PrintNotes = true;
                        worksheet.PageSetup.Zoom = 65;
                        worksheet.PageSetup.PrintGridlines = true;
                        worksheet.PageSetup.LeftMargin = 0;
                        worksheet.PageSetup.RightMargin = 0;
                        worksheet.PageSetup.TopMargin = 0.75;
                        worksheet.PageSetup.BottomMargin = 0.75;
                        worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                        worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
                        //Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[1, 5];
                        //System.Drawing.Image oImage = System.Drawing.Image.FromFile(Global.sLogo);
                        //System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                        //worksheet.Paste(oRange, Global.sLogo);
                        fnDrawLogo(worksheet, 1, 5);
                        Process.Start(ExcelFolderPath);
                        break;
                    case "StandarCostWO":
                        //  worksheet.Name = "Standar Cost WO";
                        //Microsoft.Office.Interop.Excel.Range r = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[1, 3];
                        //r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                        fnDateFormat(worksheet, 1, 2);
                        fnDateFormat(worksheet, 1, 4);
                        fnNumberFormatstring(worksheet, "H6", "J9999");
                        worksheet.Cells[2, 1] = "Standar Cost WO";
                        worksheet.Range["A2:B3"].Cells.Font.Color = Color.Blue;
                        worksheet.Range["A2:B3"].Cells.Font.Bold = 14;
                        worksheet.get_Range("A2", "C2").Merge(true);
                        excelRange = string.Format("A5:{0}{1}", finalColLetter, dt.Rows.Count + 5);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Color = Color.Blue;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Size = 12;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.get_Range("D6", "D9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                        worksheet.Columns[6].ColumnWidth = 60;
                        worksheet.Columns[6].WrapText = true;
                        worksheet.get_Range("D6", "D9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        worksheet.Rows.RowHeight = "18";
                        //Microsoft.Office.Interop.Excel.Range range = worksheet.get_Range("E6", "G9999");
                        //range.NumberFormat = "0.00";
                        //int Print = dt.Rows.Count + 8;
                        worksheet.PageSetup.PrintArea = "A1:G" + (dt.Rows.Count + 8) + "";
                        worksheet.PageSetup.PrintTitleRows = "$1:$2";
                        worksheet.PageSetup.PrintNotes = true;
                        worksheet.PageSetup.Zoom = 65;
                        worksheet.PageSetup.PrintGridlines = true;
                        worksheet.PageSetup.LeftMargin = 0;
                        worksheet.PageSetup.RightMargin = 0;
                        worksheet.PageSetup.TopMargin = 0.75;
                        worksheet.PageSetup.BottomMargin = 0.75;
                        worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                        worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
                        //Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[1, 5];
                        //System.Drawing.Image oImage = System.Drawing.Image.FromFile(Global.sLogo);
                        //System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                        //worksheet.Paste(oRange, Global.sLogo);
                        fnDrawLogo(worksheet, 1, 5);
                        Process.Start(ExcelFolderPath);
                        break;

                    case "Project Status Update":
                        // worksheet.Name = "Project Status Update";
                        //Microsoft.Office.Interop.Excel.Range r = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[1, 3];
                        //r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                        // fnDateFormat(worksheet, 1, 2);
                        // fnDateFormat(worksheet, 1, 4);
                        //  fnNumberFormatstring(worksheet, "H6", "J9999");
                        worksheet.Cells[2, 1] = "Project Status Update";
                        worksheet.Range["A2:B3"].Cells.Font.Color = Color.Blue;
                        worksheet.Range["A2:B3"].Cells.Font.Bold = 14;
                        worksheet.get_Range("A2", "C2").Merge(true);
                        excelRange = string.Format("A5:{0}{1}", finalColLetter, dt.Rows.Count + 5);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Color = Color.Blue;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Size = 12;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.get_Range("D6", "D9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                        //  worksheet.Columns[6].ColumnWidth = 60;
                        //worksheet.Columns[6].WrapText = true;
                        worksheet.get_Range("D6", "D9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        worksheet.Rows.RowHeight = "18";

                        fnDateFormatstring(worksheet, "J6", "J9999");
                        //Microsoft.Office.Interop.Excel.Range range = worksheet.get_Range("E6", "G9999");
                        //range.NumberFormat = "0.00";
                        //int Print = dt.Rows.Count + 8;
                        worksheet.PageSetup.PrintArea = "A1:J" + (dt.Rows.Count + 8) + "";
                        worksheet.PageSetup.PrintTitleRows = "$1:$2";
                        worksheet.PageSetup.PrintNotes = true;
                        worksheet.PageSetup.Zoom = 65;
                        worksheet.PageSetup.PrintGridlines = true;
                        worksheet.PageSetup.LeftMargin = 0;
                        worksheet.PageSetup.RightMargin = 0;
                        worksheet.PageSetup.TopMargin = 0.75;
                        worksheet.PageSetup.BottomMargin = 0.75;
                        worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                        worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
                        //Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[1, 5];
                        //System.Drawing.Image oImage = System.Drawing.Image.FromFile(Global.sLogo);
                        //System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                        //worksheet.Paste(oRange, Global.sLogo);
                        fnDrawLogo(worksheet, 1, 5);
                        Process.Start(ExcelFolderPath);
                        break;

                    case "Project Transfer Report":

                        //  worksheet.Name = "Standar Cost WO";
                        //Microsoft.Office.Interop.Excel.Range r = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[1, 3];
                        //r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                        fnDateFormat(worksheet, 1, 2);
                        fnDateFormat(worksheet, 1, 4);
                        fnNumberFormatstring(worksheet, "H6", "J9999");
                        worksheet.Cells[2, 1] = "Project Transfer Report";
                        worksheet.Range["A2:B3"].Cells.Font.Color = Color.Blue;
                        worksheet.Range["A2:B3"].Cells.Font.Bold = 14;
                        worksheet.get_Range("A2", "C2").Merge(true);
                        excelRange = string.Format("A5:{0}{1}", finalColLetter, dt.Rows.Count + 5);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Color = Color.Blue;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Size = 12;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.get_Range("D6", "D9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                        worksheet.Columns[6].ColumnWidth = 60;
                        worksheet.Columns[6].WrapText = true;
                        worksheet.get_Range("D6", "D9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        worksheet.Rows.RowHeight = "18";
                        //Microsoft.Office.Interop.Excel.Range range = worksheet.get_Range("E6", "G9999");
                        //range.NumberFormat = "0.00";
                        //int Print = dt.Rows.Count + 8;
                        worksheet.PageSetup.PrintArea = "A1:G" + (dt.Rows.Count + 8) + "";
                        worksheet.PageSetup.PrintTitleRows = "$1:$2";
                        worksheet.PageSetup.PrintNotes = true;
                        worksheet.PageSetup.Zoom = 65;
                        worksheet.PageSetup.PrintGridlines = true;
                        worksheet.PageSetup.LeftMargin = 0;
                        worksheet.PageSetup.RightMargin = 0;
                        worksheet.PageSetup.TopMargin = 0.75;
                        worksheet.PageSetup.BottomMargin = 0.75;
                        worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                        worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
                        //Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[1, 5];
                        //System.Drawing.Image oImage = System.Drawing.Image.FromFile(Global.sLogo);
                        //System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                        //worksheet.Paste(oRange, Global.sLogo);
                        fnDrawLogo(worksheet, 1, 5);
                        Process.Start(ExcelFolderPath);
                        break;

                    case "Project Install Status":
                        // worksheet.Name = "Project Status Update";
                        //Microsoft.Office.Interop.Excel.Range r = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[1, 3];
                        //r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                        // fnDateFormat(worksheet, 1, 2);
                        // fnDateFormat(worksheet, 1, 4);
                        //  fnNumberFormatstring(worksheet, "H6", "J9999");
                        worksheet.Cells[2, 1] = "Project  Install Status";
                        worksheet.Range["A2:B3"].Cells.Font.Color = Color.Blue;
                        worksheet.Range["A2:B3"].Cells.Font.Bold = 14;
                        worksheet.get_Range("A2", "C2").Merge(true);
                        excelRange = string.Format("A5:{0}{1}", finalColLetter, dt.Rows.Count + 5);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Color = Color.Blue;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Size = 12;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.get_Range("D6", "D9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                        //  worksheet.Columns[6].ColumnWidth = 60;
                        //worksheet.Columns[6].WrapText = true;
                        worksheet.get_Range("D6", "D9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        worksheet.Rows.RowHeight = "18";

                        fnDateFormatstring(worksheet, "L6", "L9999");
                        //Microsoft.Office.Interop.Excel.Range range = worksheet.get_Range("E6", "G9999");
                        //range.NumberFormat = "0.00";
                        //int Print = dt.Rows.Count + 8;
                        worksheet.PageSetup.PrintArea = "A1:J" + (dt.Rows.Count + 8) + "";
                        worksheet.PageSetup.PrintTitleRows = "$1:$2";
                        worksheet.PageSetup.PrintNotes = true;
                        worksheet.PageSetup.Zoom = 65;
                        worksheet.PageSetup.PrintGridlines = true;
                        worksheet.PageSetup.LeftMargin = 0;
                        worksheet.PageSetup.RightMargin = 0;
                        worksheet.PageSetup.TopMargin = 0.75;
                        worksheet.PageSetup.BottomMargin = 0.75;
                        worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                        worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
                        //Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[1, 5];
                        //System.Drawing.Image oImage = System.Drawing.Image.FromFile(Global.sLogo);
                        //System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                        //worksheet.Paste(oRange, Global.sLogo);
                        fnDrawLogo(worksheet, 1, 5);
                        Process.Start(ExcelFolderPath);
                        break;

                    case "Consolidated Stock Report":
                        worksheet.Cells[2, 1] = "Consolidated Stock Report";
                        worksheet.Range["A3:C9"].Cells.Font.Color = Color.Brown;
                        worksheet.Range["A2:D9"].Cells.Font.Bold = 14;

                        worksheet.Cells[2, 3] = "Dated : " + DateTime.Now.ToString();

                        worksheet.Cells[3, 1] = "Main StoresRM";
                        worksheet.Cells[4, 1] = "Electronics StoresFG";
                        worksheet.Cells[5, 1] = "Electronics StoresRM";
                        worksheet.Cells[6, 1] = "Transducer StoresFG";
                        worksheet.Cells[7, 1] = "Transducer StoresRM";
                        worksheet.Cells[8, 1] = "Grand Total";

                        worksheet.Cells[3, 3] = Math.Round(dActive);
                        worksheet.Cells[3, 2] = Math.Round(dActive1);
                        worksheet.Cells[4, 3] = Math.Round(dSlow);
                        worksheet.Cells[4, 2] = Math.Round(dSlow1);
                        worksheet.Cells[5, 3] = Math.Round(dObsolute);
                        worksheet.Cells[5, 2] = Math.Round(dObsolute1);
                        worksheet.Cells[6, 3] = Math.Round(dRActive);
                        worksheet.Cells[6, 2] = Math.Round(dRActive1);
                        worksheet.Cells[7, 3] = Math.Round(dRSlow);
                        worksheet.Cells[7, 2] = Math.Round(dRSlow1);
                        worksheet.Cells[8, 3] = Math.Round(dStockvalue);
                        worksheet.Cells[8, 2] = Math.Round(dStockvalue1);

                        worksheet.Range["A10:J10"].Cells.Font.Color = Color.Blue;
                        worksheet.Range["A10:J10"].Cells.Font.Bold = 14;
                        excelRange = string.Format("A10:{0}{1}", finalColLetter, dt.Rows.Count + 10);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.Columns[3].ColumnWidth = 60;
                        worksheet.Columns[3].WrapText = true;
                        worksheet.Rows.RowHeight = "18";

                        fnDateFormatstring(worksheet, "D6", "D9999");
                        worksheet.PageSetup.PrintArea = "A1:J" + (dt.Rows.Count + 10) + "";
                        worksheet.PageSetup.PrintTitleRows = "$1:$2";
                        worksheet.PageSetup.PrintNotes = true;
                        worksheet.PageSetup.Zoom = 65;
                        worksheet.PageSetup.PrintGridlines = true;
                        worksheet.PageSetup.LeftMargin = 0;
                        worksheet.PageSetup.RightMargin = 0;
                        worksheet.PageSetup.TopMargin = 0.75;
                        worksheet.PageSetup.BottomMargin = 0.75;
                        worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                        worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
                        //Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[1, 5];
                        //System.Drawing.Image oImage = System.Drawing.Image.FromFile(Global.sLogo);
                        //System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                        //worksheet.Paste(oRange, Global.sLogo);
                        fnDrawLogo(worksheet, 1, 5);
                        Process.Start(ExcelFolderPath);
                        break;

                    case "All Stock Latest Standard Cost Report":
                        worksheet.Cells[2, 1] = "All Stock Latest Standard Cost";
                        worksheet.Range["A3:B9"].Cells.Font.Color = Color.Brown;
                        worksheet.Range["A2:D9"].Cells.Font.Bold = 14;

                        worksheet.Cells[2, 3] = "Dated : " + DateTime.Now.ToString();



                        worksheet.Range["A10:J10"].Cells.Font.Color = Color.Blue;
                        worksheet.Range["A10:J10"].Cells.Font.Bold = 14;
                        excelRange = string.Format("A10:{0}{1}", finalColLetter, dt.Rows.Count + 10);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.Columns[3].ColumnWidth = 60;
                        worksheet.Columns[3].WrapText = true;
                        worksheet.Rows.RowHeight = "18";

                        fnDateFormatstring(worksheet, "D6", "D9999");
                        worksheet.PageSetup.PrintArea = "A1:J" + (dt.Rows.Count + 10) + "";
                        worksheet.PageSetup.PrintTitleRows = "$1:$2";
                        worksheet.PageSetup.PrintNotes = true;
                        worksheet.PageSetup.Zoom = 65;
                        worksheet.PageSetup.PrintGridlines = true;
                        worksheet.PageSetup.LeftMargin = 0;
                        worksheet.PageSetup.RightMargin = 0;
                        worksheet.PageSetup.TopMargin = 0.75;
                        worksheet.PageSetup.BottomMargin = 0.75;
                        worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                        worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
                        //Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[1, 5];
                        //System.Drawing.Image oImage = System.Drawing.Image.FromFile(Global.sLogo);
                        //System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                        //worksheet.Paste(oRange, Global.sLogo);
                        fnDrawLogo(worksheet, 1, 5);
                        Process.Start(ExcelFolderPath);
                        break;
                    case "Conusmption Report":
                        worksheet.Cells[2, 1] = "Consolidated Projects Conusmption Report";
                        // worksheet.Range["A3:B9"].Cells.Font.Color = Color.Brown;
                        worksheet.Range["A2:D9"].Cells.Font.Bold = 14;
                        worksheet.Cells[2, 3] = "Dated : " + DateTime.Now.ToString();

                        //worksheet.Cells[4, 2] = "Report Date :";
                        worksheet.Cells[4, 2] = "From Date :";
                        worksheet.Cells[4, 3] = dtpFromDate.Text;
                        //worksheet.Cells[5, 2] = "6 Months Start Date :";
                        worksheet.Cells[5, 2] = "To Date :";
                        worksheet.Cells[5, 3] = dptToDate.Text;
                        //worksheet.Cells[6, 2] = "12 Months Start Date :";
                        //worksheet.Cells[6, 3] = dtptwelve.Text;
                        worksheet.Range["B4:C6"].Cells.Font.Color = Color.DarkRed;
                        worksheet.Range["B4:C6"].Cells.Font.Bold = 14;

                        worksheet.Range["A10:Q10"].Cells.Font.Color = Color.Blue;
                        worksheet.Range["A10:Q10"].Cells.Font.Bold = 14;
                        excelRange = string.Format("A10:{0}{1}", finalColLetter, dt.Rows.Count + 10);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.Columns[2].ColumnWidth = 40;
                        worksheet.Columns[2].WrapText = true;
                        worksheet.Rows.RowHeight = "18";

                        fnDateFormatstring(worksheet, "G6", "G99999");
                        worksheet.PageSetup.PrintArea = "A1:M" + (dt.Rows.Count + 10) + "";
                        worksheet.PageSetup.PrintTitleRows = "$1:$2";
                        worksheet.PageSetup.PrintNotes = true;
                        worksheet.PageSetup.Zoom = 65;
                        worksheet.PageSetup.PrintGridlines = true;
                        worksheet.PageSetup.LeftMargin = 0;
                        worksheet.PageSetup.RightMargin = 0;
                        worksheet.PageSetup.TopMargin = 0.75;
                        worksheet.PageSetup.BottomMargin = 0.75;
                        worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                        worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
                        fnDrawLogo(worksheet, 1, 5);
                        Process.Start(ExcelFolderPath);
                        break;

                    case "UserAccess":
                        fnNumberFormat(worksheet, 14, 18);
                        fnDateFormat(worksheet, 11, 13);
                        worksheet.Cells[2, 2] = "UserAccess Report";
                        worksheet.Range["A2:B2"].Cells.Font.Size = 14;
                        worksheet.Range["A2:B2"].Cells.Font.Bold = 14;
                        // worksheet.Cells[4, 2] = "Grand Total:";
                        //  worksheet.Cells[4, 3] = dataSet.Tables[0].Compute("Sum(Amount)", "").ToString();
                        excelRange = string.Format("A6:{0}{1}", finalColLetter, dt.Rows.Count + 6);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[6, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[6, Type.Missing]).Font.Color = Color.Blue;
                        worksheet.Range["A4:C5"].Cells.Font.Size = 14;
                        worksheet.Range["A4:C5"].Cells.Font.Bold = 14;
                        CellMerge("Merge", NewWorkBook.ActiveSheet, 1, 1, 1, 3);
                        worksheet.get_Range("C6", "C99999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        fnDateFormatstring(worksheet, "K6", "M99999");
                        fnNumberFormatstring(worksheet, "N6", "R99999");
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.Columns[1].ColumnWidth = 30;
                        worksheet.Columns[1].WrapText = true;
                        worksheet.Columns[2].ColumnWidth = 45;
                        worksheet.Columns[2].WrapText = true;
                        worksheet.Columns[3].ColumnWidth = 40;
                        worksheet.Columns[3].WrapText = true;
                        worksheet.Columns[7].ColumnWidth = 50;
                        worksheet.Columns[7].WrapText = true;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        fnDrawLogo(worksheet, 2, 5);
                        Process.Start(ExcelFolderPath);
                        break;

                    case "Project Doc Tracking Report":
                        fnNumberFormat(worksheet, 14, 18);
                        fnDateFormat(worksheet, 11, 13);
                        worksheet.Cells[2, 2] = "Project Doc Tracking Report";
                        worksheet.Range["A2:B2"].Cells.Font.Size = 14;
                        worksheet.Range["A2:B2"].Cells.Font.Bold = 14;
                        // worksheet.Cells[4, 2] = "Grand Total:";
                        //  worksheet.Cells[4, 3] = dataSet.Tables[0].Compute("Sum(Amount)", "").ToString();
                        excelRange = string.Format("A6:{0}{1}", finalColLetter, dt.Rows.Count + 6);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[6, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[6, Type.Missing]).Font.Color = Color.Blue;
                        worksheet.Range["A4:C5"].Cells.Font.Size = 14;
                        worksheet.Range["A4:C5"].Cells.Font.Bold = 14;
                        CellMerge("Merge", NewWorkBook.ActiveSheet, 1, 1, 1, 3);
                        worksheet.get_Range("C6", "C99999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        fnDateFormatstring(worksheet, "K6", "M99999");
                        //  fnNumberFormatstring(worksheet, "N6", "R99999");
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.Columns[1].ColumnWidth = 30;
                        worksheet.Columns[1].WrapText = true;
                        worksheet.Columns[2].ColumnWidth = 45;
                        worksheet.Columns[2].WrapText = true;
                        worksheet.Columns[3].ColumnWidth = 40;
                        worksheet.Columns[3].WrapText = true;
                        worksheet.Columns[7].ColumnWidth = 50;
                        worksheet.Columns[7].WrapText = true;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        fnDrawLogo(worksheet, 2, 5);
                        Process.Start(ExcelFolderPath);
                        break;

                    case "Standard Item Cost Report":
                        fnNumberFormat(worksheet, 1, 4);
                        fnDateFormat(worksheet, 1, 4);
                        worksheet.Cells[2, 2] = "Standard Item Cost Report";
                        worksheet.Range["A2:B2"].Cells.Font.Size = 14;
                        worksheet.Range["A2:B2"].Cells.Font.Bold = 14;
                        // worksheet.Cells[4, 2] = "Grand Total:";
                        //  worksheet.Cells[4, 3] = dataSet.Tables[0].Compute("Sum(Amount)", "").ToString();
                        excelRange = string.Format("A6:{0}{1}", finalColLetter, dt.Rows.Count + 6);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[6, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[6, Type.Missing]).Font.Color = Color.Blue;
                        worksheet.Range["A4:C5"].Cells.Font.Size = 14;
                        worksheet.Range["A4:C5"].Cells.Font.Bold = 14;
                        CellMerge("Merge", NewWorkBook.ActiveSheet, 1, 1, 1, 3);
                        worksheet.get_Range("C6", "C99999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        fnDateFormatstring(worksheet, "K6", "M99999");
                        //  fnNumberFormatstring(worksheet, "N6", "R99999");
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.Columns[1].ColumnWidth = 30;
                        worksheet.Columns[1].WrapText = true;
                        worksheet.Columns[2].ColumnWidth = 45;
                        worksheet.Columns[2].WrapText = true;
                        worksheet.Columns[3].ColumnWidth = 40;
                        worksheet.Columns[3].WrapText = true;
                        worksheet.Columns[7].ColumnWidth = 50;
                        worksheet.Columns[7].WrapText = true;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        fnDrawLogo(worksheet, 2, 5);
                        Process.Start(ExcelFolderPath);
                        break;

                    case "Job Work":
                        fnNumberFormatstring(worksheet, "S5", "AC99999");
                        fnDateFormat(worksheet, 3, 3);
                        fnDateFormat(worksheet, 20, 20);
                        //fnNumberFormat(worksheet, 9, 12);
                        //fnNumberFormat(worksheet, 19, 21);
                        worksheet.Cells[2, 2] = "Job Work";
                        worksheet.Range["A2:C2"].Cells.Font.Size = 14;
                        worksheet.Range["A2:C2"].Cells.Font.Bold = 14;
                        excelRange = string.Format("A8:{0}{1}", finalColLetter, dt.Rows.Count + 8);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[8, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[8, Type.Missing]).Font.Color = Color.Blue;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.Columns[9].ColumnWidth = 50;
                        //worksheet.Columns[5].WrapText = true;
                        worksheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        //worksheet.Rows.RowHeight = "18";
                        //int print = dt.Rows.Count + 5;
                        worksheet.PageSetup.PrintArea = "A1:L" + (dt.Rows.Count + 5) + "";
                        worksheet.PageSetup.PrintTitleRows = "$1:$2";
                        worksheet.PageSetup.PrintNotes = true;
                        worksheet.PageSetup.Zoom = 65;
                        worksheet.PageSetup.PrintGridlines = true;
                        worksheet.PageSetup.LeftMargin = 0;
                        worksheet.PageSetup.RightMargin = 0;
                        worksheet.PageSetup.TopMargin = 0.75;
                        worksheet.PageSetup.BottomMargin = 0.75;
                        worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                        worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
                        fnDrawLogo(worksheet, 1, 4);
                        Process.Start(ExcelFolderPath);
                        break;

                    case "Service GIN":
                        fnNumberFormatstring(worksheet, "S5", "AC99999");
                        fnDateFormat(worksheet, 21, 21);
                        fnDateFormat(worksheet, 20, 20);
                        //fnNumberFormat(worksheet, 9, 12);
                        //fnNumberFormat(worksheet, 19, 21);
                        worksheet.Cells[2, 2] = "Service GIN";
                        worksheet.Range["A2:C2"].Cells.Font.Size = 14;
                        worksheet.Range["A2:C2"].Cells.Font.Bold = 14;
                        excelRange = string.Format("A8:{0}{1}", finalColLetter, dt.Rows.Count + 8);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[8, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[8, Type.Missing]).Font.Color = Color.Blue;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.Columns[9].ColumnWidth = 50;
                        //worksheet.Columns[5].WrapText = true;
                        worksheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        //worksheet.Rows.RowHeight = "18";
                        //int print = dt.Rows.Count + 5;
                        worksheet.PageSetup.PrintArea = "A1:L" + (dt.Rows.Count + 5) + "";
                        worksheet.PageSetup.PrintTitleRows = "$1:$2";
                        worksheet.PageSetup.PrintNotes = true;
                        worksheet.PageSetup.Zoom = 65;
                        worksheet.PageSetup.PrintGridlines = true;
                        worksheet.PageSetup.LeftMargin = 0;
                        worksheet.PageSetup.RightMargin = 0;
                        worksheet.PageSetup.TopMargin = 0.75;
                        worksheet.PageSetup.BottomMargin = 0.75;
                        worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                        worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
                        fnDrawLogo(worksheet, 1, 4);
                        Process.Start(ExcelFolderPath);
                        break;

                    case "Customer Conusmption Report":
                        worksheet.Cells[2, 1] = "Customer Projects Conusmption Report";
                        //   worksheet.Range["A3:B9"].Cells.Font.Color = Color.Brown;
                        worksheet.Range["A2:D9"].Cells.Font.Bold = 14;
                        worksheet.Cells[2, 3] = "Dated : " + DateTime.Now.ToString();

                        worksheet.Cells[4, 2] = "Report Date :";
                        worksheet.Cells[4, 3] = dtpFromDate.Text;
                        worksheet.Cells[5, 2] = "6 Months Start Date :";
                        worksheet.Cells[5, 3] = dptToDate.Text;
                        worksheet.Cells[6, 2] = "12 Months Start Date :";
                        worksheet.Cells[6, 3] = dtptwelve.Text;
                        worksheet.Range["B4:C6"].Cells.Font.Color = Color.DarkRed;
                        worksheet.Range["B4:C6"].Cells.Font.Bold = 14;

                        worksheet.Range["A10:P10"].Cells.Font.Color = Color.Blue;
                        worksheet.Range["A10:P10"].Cells.Font.Bold = 14;
                        excelRange = string.Format("A10:{0}{1}", finalColLetter, dt.Rows.Count + 10);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        worksheet.Columns.AutoFit();
                        worksheet.Rows.AutoFit();
                        worksheet.Columns[2].ColumnWidth = 40;
                        worksheet.Columns[2].WrapText = true;
                        worksheet.Rows.RowHeight = "18";

                        fnDateFormatstring(worksheet, "G6", "G99999");
                        worksheet.PageSetup.PrintArea = "A1:M" + (dt.Rows.Count + 10) + "";
                        worksheet.PageSetup.PrintTitleRows = "$1:$2";
                        worksheet.PageSetup.PrintNotes = true;
                        worksheet.PageSetup.Zoom = 65;
                        worksheet.PageSetup.PrintGridlines = true;
                        worksheet.PageSetup.LeftMargin = 0;
                        worksheet.PageSetup.RightMargin = 0;
                        worksheet.PageSetup.TopMargin = 0.75;
                        worksheet.PageSetup.BottomMargin = 0.75;
                        worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                        worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
                        fnDrawLogo(worksheet, 1, 5);
                        Process.Start(ExcelFolderPath);
                        break;
                }
            }
            NewWorkBook.SaveAs(outputPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                               Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive,
                               Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

            NewWorkBook.Save();
            NewWorkBook.Close(true, Type.Missing, Type.Missing);
            excelApp.Quit();

            releaseObject(worksheet);
            releaseObject(NewWorkBook);
            releaseObject(excelApp);
        }
        #endregion

        private void fnCustomDate(int SwitchCustom)
        {
            switch (SwitchCustom)
            {
                case 0:
                    Cursor.Current = Cursors.WaitCursor;
                    dtpFromDate.Format = DateTimePickerFormat.Custom;
                    dtpFromDate.CustomFormat = "yyyy-MM-dd";
                    dptToDate.Format = DateTimePickerFormat.Custom;
                    dptToDate.CustomFormat = "yyyy-MM-dd";
                    dtptwelve.Format = DateTimePickerFormat.Custom;
                    dtptwelve.CustomFormat = "yyyy-MM-dd";
                    break;
                case 1:
                    dtpFromDate.Format = DateTimePickerFormat.Custom;
                    dtpFromDate.CustomFormat = "dd-MM-yyyy";
                    dptToDate.Format = DateTimePickerFormat.Custom;
                    dptToDate.CustomFormat = "dd-MM-yyyy";
                    dtptwelve.Format = DateTimePickerFormat.Custom;
                    dtptwelve.CustomFormat = "dd-MM-yyyy";
                    dtReciept.Rows.Clear();
                    break;
            }
        }

        public DataTable RemoveDuplicateRows(DataTable table, string DistinctColumn)
        {
            try
            {
                ArrayList UniqueRecords = new ArrayList();
                ArrayList DuplicateRecords = new ArrayList();


                foreach (DataRow dRow in table.Rows)
                {
                    if (UniqueRecords.Contains(dRow[DistinctColumn]))
                        DuplicateRecords.Add(dRow);
                    else
                        UniqueRecords.Add(dRow[DistinctColumn]);

                }
                // Remove dupliate rows from DataTable added to DuplicateRecords
                if (DuplicateRecords.Count > 0)
                {
                    foreach (DataRow dRow in DuplicateRecords)
                    {
                        table.Rows.Remove(dRow);
                    }
                }
                // Return the clean DataTable which contains unique records.
                return table;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;

            }
        }
        private double sQty;
        private void fnUsageCount()
        {
            object value;
            foreach (DataRow dr in dtReciept.Rows)
            {
                value = dr["6Months"];
                if (value == DBNull.Value)
                {
                    dr["6Months"] = 0;
                }
                value = dr["12Months"];
                if (value == DBNull.Value)
                {
                    dr["12Months"] = 0;
                }
            }

            if (dtReciept.Rows.Count > 0)
            {
                Dictionary<string, double> dicSum = new Dictionary<string, double>();
                Dictionary<string, double> dicSum1 = new Dictionary<string, double>();
                Dictionary<string, double> dicSum2 = new Dictionary<string, double>();
                foreach (DataRow row in dtReciept.Rows)
                {
                    string group = row["ItemCode"].ToString();
                    double rate = Convert.ToDouble(row["6Months"]);

                    string group1 = row["ItemCode"].ToString();
                    double rate1 = Convert.ToDouble(row["12Months"]);

                    string group2 = row["ItemCode"].ToString();
                    double rate2 = Convert.ToDouble(row["AvailableQty"]);


                    if (dicSum.ContainsKey(group))
                        dicSum[group] += rate;
                    else
                        dicSum.Add(group, rate);

                    if (dicSum1.ContainsKey(group1))
                        dicSum1[group1] += rate1;
                    else
                        dicSum1.Add(group1, rate1);

                    if (dicSum2.ContainsKey(group2))
                        dicSum2[group2] += rate2;
                    else
                        dicSum2.Add(group2, rate2);
                }

                DataTable UniqueRecords = RemoveDuplicateRows(dtReciept, "ItemCode");

                foreach (var group in dicSum)
                {
                    foreach (DataRow FinalItems in dtReciept.Rows)
                    {
                        if (FinalItems["ItemCode"].ToString() == group.Key.ToString())
                        {
                            sQty = group.Value;
                            FinalItems["6Months"] = sQty;
                            break;
                        }
                    }
                }
                sQty = 0;
                foreach (var group1 in dicSum1)
                {
                    foreach (DataRow FinalItems in dtReciept.Rows)
                    {
                        if (FinalItems["ItemCode"].ToString() == group1.Key.ToString())
                        {
                            sQty = group1.Value;
                            FinalItems["12Months"] = sQty;
                            break;
                        }
                    }
                }

                sQty = 0;
                foreach (var group2 in dicSum2)
                {
                    foreach (DataRow FinalItems in dtReciept.Rows)
                    {
                        if (FinalItems["ItemCode"].ToString() == group2.Key.ToString())
                        {
                            sQty = group2.Value;
                            FinalItems["AvailableQty"] = sQty;
                            break;
                        }
                    }
                }
            }
        }


        private void fnUsageCount1()
        {
            object value;


            if (dtReciept.Rows.Count > 0)
            {
                Dictionary<string, double> dicSum2 = new Dictionary<string, double>();
                foreach (DataRow row in dtReciept.Rows)
                {

                    string group2 = row["ItemCode"].ToString();
                    double rate2 = Convert.ToDouble(row["AvailableQty"]);


                    if (dicSum2.ContainsKey(group2))
                        dicSum2[group2] += rate2;
                    else
                        dicSum2.Add(group2, rate2);
                }

                DataTable UniqueRecords = RemoveDuplicateRows(dtReciept, "ItemCode");

                sQty = 0;
                foreach (var group2 in dicSum2)
                {
                    foreach (DataRow FinalItems in dtReciept.Rows)
                    {
                        if (FinalItems["ItemCode"].ToString() == group2.Key.ToString())
                        {
                            sQty = group2.Value;
                            FinalItems["AvailableQty"] = sQty;
                            break;
                        }
                    }
                }
            }
        }


        DataTable dtPurchaseCost = new DataTable();
        // string ExcelFolderPath;
        // string FileFullPath;
        EXCEL.Application excelapp;
        EXCEL.Workbook workbook;
        EXCEL.Worksheet worksheet;

        double dStockvalue = 0;
        double dActive1 = 0;
        double dStockvaluewithOH = 0;
        double dActive = 0;
        double dSlow = 0;
        double dObsolute = 0;
        double dReserve = 0;
        double dRActive = 0;
        double dRSlow = 0;
        double dRObsolute = 0;
        double dActiveP = 0;
        double dSlowP = 0;
        double dObsoluteP = 0;

        double dSlow1 = 0;
        double dObsolute1 = 0;
        double dRActive1 = 0;
        double dRSlow1 = 0;
        double dStockvalue1 = 0;

        double dDActive = 0;
        double dDSlow = 0;
        double dDObsolute = 0;
        DataTable dtLatestPurchaseCost = new DataTable();
        double dNetAmount = 0.0;
        #region Excel Report Genarate
        private void btnexcelreport_Click(object sender, EventArgs e)
        {
            fnCustomDate(0);
            switch (cmbReport.SelectedItem.ToString())
            {
                #region Issued Report
                case "Project Issue":
                    dtReciept = DAL.fnIssuedListConsalidated(dtpFromDate.Text, dptToDate.Text).Tables[0];

                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;
                #endregion
                #region Reciept Report
                case "Receipt":
                    dtReciept = DAL.fnstockGINReport(dtpFromDate.Text, dptToDate.Text, 1).Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;
                #endregion
                #region Item Master Report
                case "Stock Balance":
                    dtReciept.Rows.Clear();
                   // MessageBox.Show("Stock Balance");
                    dtReciept = DAL.fnItemList2(null).Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;
                case "Item Label Print":

                    if (checkBoxPrintLocation.Checked == true && checkBox1Location.Checked == true)
                    {
                        GenerateLocationPdfQRCode();
                        return;
                    }

                    BatchCodeDataList.Clear();
                    DataTable ItemdeatilsLogs = null;
                    string printCountStr = "1";
                    //DAL.fnPrintReceiptItemCodeList
                    //MessageBox.Show(comboBox1LabelPrintItemCode.Text.ToString(), comboBox2LabelPrintLocation.Text.ToString());
                    if (checkBox1Location.Checked == true)
                    {
                        //MessageBox.Show(comboBox1Location.Text);
                        ItemdeatilsLogs = DAL.fnPrintReceiptItemCodeList(null, comboBox2LabelPrintLocation.Text).Tables[0];
                        printCountStr = "1";
                        //MessageBox.Show("Location", comboBox2LabelPrintLocation.Text);
                    }

                    if (checkBox2ItemCode.Checked == true)
                    {
                        //MessageBox.Show("Item Code", comboBox1LabelPrintItemCode.Text);
                        ItemdeatilsLogs = DAL.fnPrintReceiptItemCodeList(comboBox1LabelPrintItemCode.Text, null).Tables[0];
                        printCountStr = "1";//textBox1LableCount.Text;
                    }

                    //MessageBox.Show(ItemdeatilsLogs.Rows.Count.ToString(), "Row Count...");
                   

                    if (ItemdeatilsLogs != null)
                    {
                        foreach (DataRow row in ItemdeatilsLogs.Rows)
                        {
                            if (int.TryParse(printCountStr, out int printCount))
                            {
                                // Run loop based on printCount
                                for (int i = 0; i < printCount; i++)
                                {
                                    // Create dictionary for this iteration
                                    Dictionary<string, string> rowData = new Dictionary<string, string>
                        {
                            { "ItemCode",  row["ItemCode"]?.ToString()??"" },
                            { "ItemDescription", row["ItemDescription"]?.ToString() ?? "" },
                            { "ItemDes", (row["ItemDescription"]?.ToString() ?? "").Substring(0, Math.Min(55, (row["ItemDescription"]?.ToString() ?? "").Length))}
                           
                        };

                                    // Add to list
                                    BatchCodeDataList.Add(rowData);
                                }
                            }
                        }
                    }
                    else
                    {
                        //  MessageBox.Show(printCount.ToString(), "ERROR");
                    }

                    if (BatchCodeDataList.Count > 0)
                    {

                        string userRoot = System.Environment.GetEnvironmentVariable("USERPROFILE");
                        // Now let's get C:\Users\Username\Downloads:
                        string downloadFolder = Path.Combine(userRoot, "Downloads\\");



                        string outputPath = $"{downloadFolder}ItemLabel_{DateTime.Now:ddMMyyyyHHmmss}.pdf";
                       

                        // Custom page size: 10 cm x 2.5 cm
                        iTextSharp.text.Rectangle customSize = new iTextSharp.text.Rectangle(
                        Utilities.MillimetersToPoints(60), // width
                        Utilities.MillimetersToPoints(30)   // height
                    );

                        using (FileStream fs = new FileStream(outputPath, FileMode.Create, FileAccess.Write, FileShare.None))
                        using (Document doc = new Document(customSize, 2, 0, 0, 2))
                        using (PdfWriter writer = PdfWriter.GetInstance(doc, fs))
                        {
                            doc.Open();

                            // Main table with 2 columns for two labels per page
                            PdfPTable mainTable = new PdfPTable(1); 
                            mainTable.WidthPercentage = 100;
                            mainTable.SetWidths(new float[] { 1f });

                            int index = 1;
                            foreach (var data in BatchCodeDataList)
                            {

                                // MessageBox.Show(index.ToString());
                                // Generate QR Code
                                QRCodeGenerator qrGenerator = new QRCodeGenerator();
                                QRCodeData qrCodeData = qrGenerator.CreateQrCode(data["ItemCode"], QRCodeGenerator.ECCLevel.Q);
                                QRCode qrCode = new QRCode(qrCodeData);
                                Bitmap qrCodeImage = qrCode.GetGraphic(2);

                                iTextSharp.text.Image qrImg;
                                using (MemoryStream ms = new MemoryStream())
                                {
                                    qrCodeImage.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                                    qrImg = iTextSharp.text.Image.GetInstance(ms.ToArray());
                                    qrImg.ScaleAbsolute(45f, 45f);
                                }

                                // Inner table for label
                                PdfPTable labelTable = new PdfPTable(1);

                                labelTable.WidthPercentage = 100;
                                labelTable.SetWidths(new float[] { 2f });

                                PdfPCell qrCell = new PdfPCell(qrImg);
                                qrCell.Border = Rectangle.NO_BORDER;
                                qrCell.HorizontalAlignment = Element.ALIGN_CENTER;
                                qrCell.VerticalAlignment = Element.ALIGN_MIDDLE;

                                //labelTable.AddCell(qrCell);

                                PdfPCell textCell = new PdfPCell();
                                //textCell.PaddingTop = 10f;
                                textCell.Border = Rectangle.NO_BORDER;
                                textCell.PaddingLeft = -2;
                                textCell.PaddingTop = -10;
                                if (index % 2 == 0)
                                {
                                   // textCell.PaddingLeft = 6f;
                                }
                                //textCell.AddElement(new Paragraph(data["Location"], FontFactory.GetFont("Arial", 6)));
                                textCell.AddElement(new Paragraph(data["ItemCode"], FontFactory.GetFont("Arial", data["ItemDes"].Length < 14 ? 18 : 14, iTextSharp.text.Font.BOLD)));
                                textCell.AddElement(new Paragraph(data["ItemDes"], FontFactory.GetFont("Arial", 12, iTextSharp.text.Font.BOLD)));
                               
                                labelTable.AddCell(textCell);

                                PdfPCell mainCell = new PdfPCell(labelTable);
                                mainCell.PaddingTop = 8f;
                                mainCell.PaddingLeft = 8f;
                                if (index % 2 == 0)
                                {
                                    //MessageBox.Show("value is zero:");
                                   // mainCell.PaddingLeft = 13f;
                                }
                                mainCell.Border = Rectangle.NO_BORDER;
                                mainTable.AddCell(mainCell);
                                index++;
                            }

                            // If odd number of labels, add empty cell
                            if (BatchCodeDataList.Count % 2 != 0)
                            {
                                PdfPCell emptyCell = new PdfPCell(new Phrase(""));
                                emptyCell.Border = Rectangle.NO_BORDER;
                                mainTable.AddCell(emptyCell);
                            }

                            doc.Add(mainTable);
                            doc.Close();

                        }

                        MessageBox.Show($"PDF generated successfully at: {outputPath}");
                        if (Directory.Exists(outputPath))
                        {
                            Process.Start(outputPath);
                        }

                        //Cursor.Current = Cursors.Default;

                    }
                    else
                    {
                        MessageBox.Show("Print List Zero...!");
                    }


                    break;
                case "Filter Stock Balance":
                    dtReciept.Rows.Clear();
                   // MessageBox.Show("Stock Balance");
                   if(FilterTypecomboBox1.Text == "")
                    {
                        MessageBox.Show("Please Select The Filter Type...!");
                        break;
                    }

                   


                    string subStore = string.IsNullOrWhiteSpace(subStoreNamecomboBox2.Text) ? null : subStoreNamecomboBox2.Text;
                    string StoreName = string.IsNullOrWhiteSpace(storeNamecomboBox3.Text) ? null : storeNamecomboBox3.Text;
                    string Category = string.IsNullOrWhiteSpace(CategorycomboBox4.Text) ? null : CategorycomboBox4.Text;

                    string categorytxt = "";

                    if(false)
                    {
                        switch (Category)
                        {
                            case "OTC – Accessories":
                                categorytxt = "-B-%";
                                break;
                            case "Mechanical":
                                categorytxt = "";
                                break;
                            case "Packing Materials":
                                categorytxt = "";
                                break;
                            case "OTC – Italy":
                                categorytxt = "";
                                break;
                            case "LFA – Machines":
                                categorytxt = "";
                                break;
                            case "FixedAsset":
                                categorytxt = "";
                                break;
                            case "TGT":
                                categorytxt = "";
                                break;
                            case "PTI- Plastic testing Machines":
                                categorytxt = "";
                                break;
                            case "Hydraulics":
                                categorytxt = "";
                                break;
                            case "KanBan":
                                categorytxt = "";
                                break;
                            case "LFA–Machines":
                                categorytxt = "";
                                break;
                            case "HFA- Machines":
                                categorytxt = "";
                                break;
                            case "Transducers":
                                categorytxt = "";
                                break;
                            case "Testlab":
                                categorytxt = "";
                                break;
                            case "Boughtout":
                                categorytxt = "";
                                break;
                            case "Maintenance":
                                categorytxt = "";
                                break;
                            case "Service(Non-Inventory)":
                                categorytxt = "";
                                break;
                            case "Broughtout":
                                categorytxt = "";
                                break;
                            case "Tools":
                                categorytxt = "";
                                break;
                            case "Consumable":
                                categorytxt = "";
                                break;
                            case "Chennai Stock":
                                categorytxt = "";
                                break;
                            case "Electronics":
                                categorytxt = "";
                                break;
                            case "Electricals":
                                categorytxt = "";
                                break;
                            case "Electronics RnD":
                                categorytxt = "";
                                break;
                            case "OTC – US":
                                categorytxt = "";
                                break;
                            case "Consumable- Non-Inventory":
                                categorytxt = "";
                                break;
                            case "Service Spares":
                                categorytxt = "";
                                break;
                            case "OTC – UK":
                                categorytxt = "";
                                break;
                        }
                    }


                   

                    dtReciept = DAL.filterStockBalance(FilterTypecomboBox1.Text, StoreName, subStore, Category).Tables[0];

                    // Assume dtReciept is your DataTable
                    if (dtReciept != null && dtReciept.Rows.Count > 0)
                    {
                        string path = Path.Combine(
                            Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                            $"Inventory_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx"
                        );

                        CsvExporter.DataTableToXlsx(dtReciept, path);
                        MessageBox.Show("Exported to xlsx successfully.", "Export",
                                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("No data to export.", "Export",
                                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }

                    break;
                #endregion]
                #region Project Cost Report
                case "Project Cost":
                case "Project Cost, Machine & Man hours details":
                    ProjectCodeReportlist();
                    break;
                #endregion


                #region Inventory Grading eport
                case "Inventory Grading Report":
                case "Item Usage Work Order":
                    dtReciept = DAL.fnItemUsageofAllStores(0, dtpFromDate.Text, dptToDate.Text, dtptwelve.Text, null).Tables[0];
                    fnUsageCount();

                    foreach (DataRow dr in dtReciept.Rows)
                    {
                        if (Convert.ToDateTime(dr["CreatedDate"].ToString()) > Convert.ToDateTime(dtptwelve.Text) || Convert.ToDouble(dr["AvailableQty"].ToString()) == 0)
                        {
                            dr["Grading"] = "Active";
                        }
                        else if ((Convert.ToDouble(dr["12Months"].ToString()) == 0 && Convert.ToDouble(dr["AvailableQty"].ToString()) > 0) && Convert.ToDateTime(dr["CreatedDate"].ToString()) < Convert.ToDateTime(dtptwelve.Text))
                        {
                            dr["Grading"] = "Obsolute";
                        }
                        else if ((Convert.ToDouble(dr["AvailableQty"].ToString()) > Convert.ToDouble(dr["6Months"].ToString())))
                        {
                            dr["Grading"] = "Slow";
                        }
                        else
                        {
                            dr["Grading"] = "Active";
                        }
                    }

                    foreach (DataRow dr in dtReciept.Rows)
                    {
                        dr["StockValue"] = (Convert.ToDouble(dr["AvailableQty"].ToString()) * Convert.ToDouble(dr["UnitCost"].ToString()));
                    }

                    foreach (DataRow dr in dtReciept.Rows)
                    {
                        dr["Inventory Value with OH"] = (Convert.ToDouble(dr["StockValue"].ToString()) + (Convert.ToDouble(dr["StockValue"].ToString()) * 0.223269876));
                    }
                    foreach (DataRow dr in dtReciept.Rows)
                    {
                        if (dr["Grading"].ToString() == "Slow")
                        {
                            dr["Reserve Amount"] = (Convert.ToDouble(dr["Inventory Value with OH"].ToString()) * 0.5);
                        }
                        else if (dr["Grading"].ToString() == "Obsolute")
                        {
                            dr["Reserve Amount"] = (Convert.ToDouble(dr["Inventory Value with OH"].ToString()) * 0.9);
                        }
                        else if (dr["Grading"].ToString() == "Active")
                        {
                            dr["Reserve Amount"] = ((Convert.ToDouble(dr["Inventory Value with OH"].ToString())) * 0);
                        }
                    }
                    dStockvalue = 0;
                    dStockvaluewithOH = 0;
                    dActive = 0;
                    dSlow = 0;
                    dObsolute = 0;
                    dReserve = 0;
                    dRActive = 0;
                    dRSlow = 0;
                    dRObsolute = 0;
                    dActiveP = 0;
                    dSlowP = 0;
                    dObsoluteP = 0;

                    dDActive = 0;
                    dDSlow = 0;
                    dDObsolute = 0;
                    foreach (DataRow dr in dtReciept.Rows)
                    {
                        dStockvalue += Convert.ToDouble(dr["StockValue"].ToString());
                        dStockvaluewithOH += Convert.ToDouble(dr["Inventory Value with OH"].ToString());
                        dReserve += Convert.ToDouble(dr["Reserve Amount"].ToString());

                        if (dr["Grading"].ToString() == "Active")
                        {
                            dDActive += Convert.ToDouble(dr["StockValue"].ToString());
                            dActive += Convert.ToDouble(dr["Inventory Value with OH"].ToString());
                            dRActive += Convert.ToDouble(dr["Reserve Amount"].ToString());
                        }
                        else if (dr["Grading"].ToString() == "Slow")
                        {
                            dDSlow += Convert.ToDouble(dr["StockValue"].ToString());
                            dSlow += Convert.ToDouble(dr["Inventory Value with OH"].ToString());
                            dRSlow += Convert.ToDouble(dr["Reserve Amount"].ToString());
                        }
                        else if (dr["Grading"].ToString() == "Obsolute")
                        {
                            dDObsolute += Convert.ToDouble(dr["StockValue"].ToString());
                            dObsolute += Convert.ToDouble(dr["Inventory Value with OH"].ToString());
                            dRObsolute += Convert.ToDouble(dr["Reserve Amount"].ToString());
                        }
                    }

                    dActiveP = (dActive / dStockvaluewithOH);
                    dSlowP = (dSlow / dStockvaluewithOH);
                    dObsoluteP = (dObsolute / dStockvaluewithOH);


                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;
                #endregion
                #region Job Issue Report
                case "Job Issue":
                    dtReciept = DAL.fnJobIssuedData(dtpFromDate.Text, dptToDate.Text, 7).Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;
                #endregion
                #region Stock Adjusted Report
                case "Stock Adjusted":
                    dtReciept = DAL.fnstockGINReport(dtpFromDate.Text, dptToDate.Text, 0).Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;
                #endregion
                #region Purchase Cost Report
                case "Purchase Cost":
                    dtPurchaseCost = DAL.fnStockValue(dtpFromDate.Text, dptToDate.Text).Tables[0];
                    dtReciept = DAL.fnPurchaseItemList(null).Tables[0];
                    dtReciept.Rows.OfType<DataRow>().ToList().ForEach(r =>
                    {
                        r[11] = DBNull.Value;
                    });

                    for (int j = 0; j < dtPurchaseCost.Rows.Count; j++)
                    {
                        for (int p = 0; p < dtReciept.Rows.Count; p++)
                        {
                            if (dtPurchaseCost.Rows[j]["ItemCode"].ToString() == dtReciept.Rows[p]["ItemCode"].ToString())
                            {
                                {
                                    int nIndex = dtReciept.Rows.IndexOf(dtReciept.Rows[p]);
                                    DataRow dr1 = dtReciept.Rows[nIndex];
                                    dr1["RefNumber"] = dtPurchaseCost.Rows[j]["RefNumber"].ToString();
                                    dr1["Ginnumber"] = dtPurchaseCost.Rows[j]["Ginnumber"].ToString();
                                    dr1["GINDate"] = dtPurchaseCost.Rows[j]["GINDate"].ToString();
                                    dr1["PurchaseCost"] = dtPurchaseCost.Rows[j]["PurchaseCost"].ToString();
                                    break;
                                }
                            }
                        }
                    }

                    if (dtPurchaseCost.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;
                #endregion
                #region Project Issued ItemReturn Report
                case "ItemReturn Project Issued":
                    dtReciept = DAL.fnReturnStockValue(dtpFromDate.Text, dptToDate.Text).Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;
                #endregion
                #region Job Issued ItemReturn Report
                case "ItemReturn Job Issued":
                    dtReciept = DAL.fnJobReturnStockValue(null, dtpFromDate.Text, dptToDate.Text).Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;
                #endregion
                #region Consolidated GIN PO Report
                case "Consolidated GIN Report PO and WO":
                    {
                        DataTable ConsolidatedGINPOReport = new DataTable();
                        List<string> listSupplierName = new List<string>();
                        ConsolidatedGINPOReport = DAL.GINReportTables(null, null, dtpFromDate.Text, dptToDate.Text, 10).Tables[0];

                        if (ConsolidatedGINPOReport.Rows.Count > 0)
                        {
                            string userRoot = System.Environment.GetEnvironmentVariable("USERPROFILE");
                            string downloadFolder = Path.Combine(userRoot, "Downloads");

                            string ExcelFolderPath = downloadFolder + "\\Consolidated GIN PO and WO Report\\";
                            string FileFullPath = ExcelFolderPath + "Consolidated GIN PO and WO Report " + dtpFromDate.Text + " to " + dptToDate.Text + "" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                            if (!Directory.Exists(ExcelFolderPath))
                                Directory.CreateDirectory(ExcelFolderPath);
                            DataTable dtSelectedGIN = new DataTable();
                            DataTable dtGINPODetails = new DataTable();
                            string finalColLetter = string.Empty;
                            dNetAmount = 0.0;

                            DataTable dtGINReport = new DataTable();
                            dtGINReport = DAL.GINReportTables(null, null, dtpFromDate.Text, dptToDate.Text, 11).Tables[0];
                            if (dtGINReport.Rows.Count > 0)
                            {
                                List<string> listPO = new List<string>();
                                foreach (DataRow dr1 in dtGINReport.Rows)
                                {
                                    if (!listPO.Contains(dr1["GINNumber"].ToString()))
                                    {
                                        listPO.Add(dr1["GINNumber"].ToString());
                                    }

                                }
                                if (listPO.Count > 0)
                                {
                                    foreach (string dr2 in listPO)
                                    {
                                        //string res = dr2.Substring(0, 1);
                                        //   if (dr2.ToString() == "ITWGIN2022001113")
                                        {
                                            dtGINPODetails = DAL.GINReportTables(null, dr2.ToString(), dtpFromDate.Text, dptToDate.Text, 10).Tables[0];
                                        }
                                        //if (dtGINPODetails.Rows.Count == 0)
                                        //{
                                        //    dtGINPODetails = DAL.GINReportTables(null, dr2.ToString(), dtpFromDate.Text, dptToDate.Text, 12).Tables[0];
                                        //}
                                        //if (dr2.ToString() == "ITWGIN2020003983")
                                        //{
                                        //    string sk = "PO";
                                        //}
                                        if (dtGINPODetails.Rows.Count > 0)
                                        {
                                            DataRow dr1 = dtGINPODetails.Rows[0];

                                            dr1["GrandTotal"] = 0;

                                            //if (dr2.ToString() == "ITWGIN2020003983")
                                            //{
                                            //    string sk = "PO";
                                            //}
                                            // DataTable dtPOQty = new DataTable();
                                            DataTable dtPack = new DataTable();


                                            dtPack = DAL.fnPackingForwarding(dr2.ToString(), "Packing & Forwarding").Tables[0];
                                            if (dtPack.Rows.Count > 0)
                                            {
                                                //if (Convert.ToDouble(dtPack.Rows[0]["Packing/Forwarding"].ToString()) > 0)
                                                //{
                                                dr1["PackingForwarding"] = Convert.ToDouble(dtPack.Rows[0]["Packing/Forwarding"].ToString());
                                                //}
                                                //else
                                                //{
                                                //    dr1["PackingForwarding"] = 0.0;
                                                //}

                                                //if (Convert.ToDouble(dtPack.Rows[0]["PFIGSTRate"].ToString()) > 0)
                                                //{
                                                dr1["PFIGSTRate"] = Convert.ToDouble(dtPack.Rows[0]["PFIGSTRate"].ToString());
                                                dr1["PFIGSTAmount"] = Convert.ToDouble(dtPack.Rows[0]["PFIGSTAmount"].ToString());
                                                //}
                                                //else
                                                //{
                                                //    dr1["PFIGSTRate"] = 0.0;
                                                //    dr1["PFIGSTAmount"] = 0.0;
                                                //}

                                                //if (Convert.ToDouble(dtPack.Rows[0]["PFSGSTRate"].ToString()) > 0)
                                                //{
                                                dr1["PFSGSTRate"] = Convert.ToDouble(dtPack.Rows[0]["PFSGSTRate"].ToString());
                                                dr1["PFSGSTAmount"] = Convert.ToDouble(dtPack.Rows[0]["PFSGSTAmount"].ToString());
                                                //}
                                                //else
                                                //{
                                                //    dr1["PFSGSTRate"] = 0.0;
                                                //    dr1["PFSGSTAmount"] = 0.0;
                                                //}

                                                //if (Convert.ToDouble(dtPack.Rows[0]["PFCGSTRate"].ToString()) > 0)
                                                //{
                                                dr1["PFCGSTRate"] = Convert.ToDouble(dtPack.Rows[0]["PFCGSTRate"].ToString());
                                                dr1["PFCGSTAmount"] = Convert.ToDouble(dtPack.Rows[0]["PFCGSTAmount"].ToString());
                                                //}
                                                //else
                                                //{
                                                //    dr1["PFCGSTRate"] = 0.0;
                                                //    dr1["PFCGSTAmount"] = 0.0;
                                                //}


                                                //if (Convert.ToDouble(dtPack.Rows[0]["Transportation/Freight"].ToString()) > 0)
                                                //{
                                                dr1["TransportationFreight"] = Convert.ToDouble(dtPack.Rows[0]["Transportation/Freight"].ToString());
                                                //}
                                                //else
                                                //{
                                                //    dr1["TransportationFreight"] = 0.0;
                                                //}

                                                //if (Convert.ToDouble(dtPack.Rows[0]["TFIGSTRate"].ToString()) > 0)
                                                //{
                                                dr1["TFIGSTRate"] = Convert.ToDouble(dtPack.Rows[0]["TFIGSTRate"].ToString());
                                                dr1["TFIGSTAmount"] = Convert.ToDouble(dtPack.Rows[0]["TFIGSTAmount"].ToString());
                                                //}
                                                //else
                                                //{
                                                //    dr1["TFIGSTRate"] = 0.0;
                                                //    dr1["TFIGSTAmount"] = 0.0;
                                                //}

                                                //if (Convert.ToDouble(dtPack.Rows[0]["TFSGSTRate"].ToString()) > 0)
                                                //{
                                                dr1["TFSGSTRate"] = Convert.ToDouble(dtPack.Rows[0]["TFSGSTRate"].ToString());
                                                dr1["TFSGSTAmount"] = Convert.ToDouble(dtPack.Rows[0]["TFSGSTAmount"].ToString());
                                                //}
                                                //else
                                                //{
                                                //    dr1["TFSGSTRate"] = 0.0;
                                                //    dr1["TFSGSTAmount"] = 0.0;
                                                //}

                                                //if (Convert.ToDouble(dtPack.Rows[0]["TFCGSTRate"].ToString()) > 0)
                                                //{
                                                dr1["TFCGSTRate"] = Convert.ToDouble(dtPack.Rows[0]["TFCGSTRate"].ToString());
                                                dr1["TFCGSTAmount"] = Convert.ToDouble(dtPack.Rows[0]["TFCGSTAmount"].ToString());
                                                //}
                                                //else
                                                //{
                                                //    dr1["TFCGSTRate"] = 0.0;
                                                //    dr1["TFCGSTAmount"] = 0.0;
                                                //}


                                                //if (Convert.ToDouble(dtPack.Rows[0]["CDPercent"].ToString()) > 0)
                                                //{
                                                dr1["CDPercent"] = Convert.ToDouble(dtPack.Rows[0]["CDPercent"].ToString());
                                                dr1["CDValue"] = Convert.ToDouble(dtPack.Compute("Sum(CDValue)", "").ToString());
                                                //}
                                                //else
                                                //{
                                                //    dr1["CDPercent"] = 0.0;
                                                //    dr1["CDValue"] = 0.0;
                                                //}

                                                //if (Convert.ToDouble(dtPack.Rows[0]["CDIGSTRate"].ToString()) > 0)
                                                //{
                                                dr1["CDIGSTRate"] = Convert.ToDouble(dtPack.Rows[0]["CDIGSTRate"].ToString());
                                                dr1["CDIGSTAmount"] = Convert.ToDouble(dtPack.Compute("Sum(CDIGSTAmount)", "").ToString());
                                                //}
                                                //else
                                                //{
                                                //    dr1["CDIGSTRate"] = 0.0;
                                                //    dr1["CDIGSTAmount"] = 0.0;
                                                //}

                                                //if (Convert.ToDouble(dtPack.Rows[0]["CDCessRate"].ToString()) > 0)
                                                //{
                                                dr1["CDCessRate"] = Convert.ToDouble(dtPack.Rows[0]["CDCessRate"].ToString());
                                                dr1["CDCessAmount"] = Convert.ToDouble(dtPack.Compute("Sum(CDCessAmount)", "").ToString());
                                                //}
                                                //else
                                                //{
                                                //    dr1["CDCessRate"] = 0.0;
                                                //    dr1["CDCessAmount"] = 0.0;
                                                //}

                                                //if (Convert.ToDouble(dtPack.Rows[0]["TCSAmount"].ToString()) > 0)
                                                //{
                                                dr1["TCSAmount"] = Convert.ToDouble(dtPack.Rows[0]["TCSAmount"].ToString());
                                                //}
                                                //else
                                                //{
                                                //    dr1["TCSAmount"] = 0.0;
                                                //}
                                            }


                                            dr1["GrandTotal"] = (Convert.ToDouble(dtGINPODetails.Compute("Sum(TaxableAmount)", "").ToString())
                                                + Convert.ToDouble(dtGINPODetails.Compute("Sum(SGSTAmount)", "").ToString())
                                                 + Convert.ToDouble(dtGINPODetails.Compute("Sum(CGSTAmount)", "").ToString())
                                                 + Convert.ToDouble(dtGINPODetails.Compute("Sum(IGSTAmount)", "").ToString())
                                                 + Convert.ToDouble(dtGINPODetails.Compute("Sum(PackingForwarding)", "").ToString())
                                                 + Convert.ToDouble(dtGINPODetails.Compute("Sum(TransportationFreight)", "").ToString())
                                                  + Convert.ToDouble(dtGINPODetails.Compute("Sum(PFIGSTAmount)", "").ToString())
                                                   + Convert.ToDouble(dtGINPODetails.Compute("Sum(PFCGSTAmount)", "").ToString())
                                                    + Convert.ToDouble(dtGINPODetails.Compute("Sum(PFSGSTAmount)", "").ToString())
                                                     + Convert.ToDouble(dtGINPODetails.Compute("Sum(TFIGSTAmount)", "").ToString())
                                                      + Convert.ToDouble(dtGINPODetails.Compute("Sum(TFCGSTAmount)", "").ToString())
                                                       + Convert.ToDouble(dtGINPODetails.Compute("Sum(TFSGSTAmount)", "").ToString())
                                                        + Convert.ToDouble(dtGINPODetails.Compute("Sum(CDValue)", "").ToString())
                                                         + Convert.ToDouble(dtGINPODetails.Compute("Sum(CDIGSTAmount)", "").ToString())
                                                          + Convert.ToDouble(dtGINPODetails.Compute("Sum(CDCessAmount)", "").ToString())
                                                           + Convert.ToDouble(dtGINPODetails.Compute("Sum(TCSAmount)", "").ToString()));

                                            dNetAmount += Convert.ToDouble(dtGINPODetails.Compute("Sum(Amount)", "").ToString());


                                            dtSelectedGIN.Merge(dtGINPODetails);

                                        }
                                    }
                                }
                            }
                            // dtGINPODetails.Rows.Clear();
                            // }

                            DataSet ds = new DataSet("GIN");
                            ds.Tables.Add(dtSelectedGIN);

                            ExportToExcel(ds, FileFullPath, "GINPO");
                        }
                        else
                        {
                            MessageBox.Show("Selected date has no records to genarate report!");
                        }
                    }
                    break;
                #endregion

                #region Consolidated GIN PO Report
                case "Consolidated GIN Report PO":
                    {
                        DataTable ConsolidatedGINPOReport = new DataTable();
                        List<string> listSupplierName = new List<string>();
                        ConsolidatedGINPOReport = DAL.GINReportTables(null, null, dtpFromDate.Text, dptToDate.Text, 2).Tables[0];

                        if (ConsolidatedGINPOReport.Rows.Count > 0)
                        {
                            string userRoot = System.Environment.GetEnvironmentVariable("USERPROFILE");
                            string downloadFolder = Path.Combine(userRoot, "Downloads");

                            string ExcelFolderPath = downloadFolder + "\\Consolidated GIN PO Report\\";
                            string FileFullPath = ExcelFolderPath + "Consolidated GIN PO Report " + dtpFromDate.Text + " to " + dptToDate.Text + "" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                            if (!Directory.Exists(ExcelFolderPath))
                                Directory.CreateDirectory(ExcelFolderPath);
                            DataTable dtSelectedGIN = new DataTable();
                            DataTable dtGINPODetails = new DataTable();
                            string finalColLetter = string.Empty;
                            dNetAmount = 0.0;

                            DataTable dtGINReport = new DataTable();
                            dtGINReport = DAL.GINReportTables(null, null, dtpFromDate.Text, dptToDate.Text, 4).Tables[0];
                            //if (dtGINReport.Rows.Count > 0)
                            //{
                            //    List<string> listPO = new List<string>();
                            //    foreach (DataRow dr1 in dtGINReport.Rows)
                            //    {
                            //        if (!listPO.Contains(dr1["GINNumber"].ToString()))
                            //        {
                            //            listPO.Add(dr1["GINNumber"].ToString());
                            //        }
                            //    }
                            //    if (listPO.Count > 0)
                            //    {
                            //        foreach (string dr2 in listPO)
                            //        {

                            //            dtGINPODetails = DAL.GINReportTables(null, dr2.ToString(), dtpFromDate.Text, dptToDate.Text, 10).Tables[0];
                            //            //bhavya
                            //            if (dtGINPODetails.Rows.Count > 0)
                            //            {
                            //                // Setup a cumulative summary for charges/taxes
                            //                double packingForwarding = 0;
                            //                double pfigstRate = 0, pfigstAmount = 0;
                            //                double pfsgstRate = 0, pfsgstAmount = 0;
                            //                double pfcgstRate = 0, pfcgstAmount = 0;
                            //                double transportationFreight = 0;
                            //                double tfigstRate = 0, tfigstAmount = 0;
                            //                double tfsgstRate = 0, tfsgstAmount = 0;
                            //                double tfcgstRate = 0, tfcgstAmount = 0;
                            //                double cdPercent = 0, cdValue = 0;
                            //                double cdigstRate = 0, cdigstAmount = 0;
                            //                double cdCessRate = 0, cdCessAmount = 0;
                            //                double tcsAmount = 0;

                            //                // Load packing/forwarding data
                            //                DataTable dtPack = DAL.fnPackingForwarding(dr2.ToString(), "Packing & Forwarding").Tables[0];

                            //                if (dtPack.Rows.Count > 0)
                            //                {
                            //                    foreach (DataRow row in dtPack.Rows)
                            //                    {
                            //                        packingForwarding += Convert.ToDouble(row["Packing/Forwarding"]);
                            //                        pfigstRate += Convert.ToDouble(row["PFIGSTRate"]);
                            //                        pfigstAmount += Convert.ToDouble(row["PFIGSTAmount"]);
                            //                        pfsgstRate += Convert.ToDouble(row["PFSGSTRate"]);
                            //                        pfsgstAmount += Convert.ToDouble(row["PFSGSTAmount"]);
                            //                        pfcgstRate += Convert.ToDouble(row["PFCGSTRate"]);
                            //                        pfcgstAmount += Convert.ToDouble(row["PFCGSTAmount"]);
                            //                        transportationFreight += Convert.ToDouble(row["Transportation/Freight"]);
                            //                        tfigstRate += Convert.ToDouble(row["TFIGSTRate"]);
                            //                        tfigstAmount += Convert.ToDouble(row["TFIGSTAmount"]);
                            //                        tfsgstRate += Convert.ToDouble(row["TFSGSTRate"]);
                            //                        tfsgstAmount += Convert.ToDouble(row["TFSGSTAmount"]);
                            //                        tfcgstRate += Convert.ToDouble(row["TFCGSTRate"]);
                            //                        tfcgstAmount += Convert.ToDouble(row["TFCGSTAmount"]);
                            //                        cdPercent += Convert.ToDouble(row["CDPercent"]);
                            //                        cdValue += Convert.ToDouble(row["CDValue"]);
                            //                        cdigstRate += Convert.ToDouble(row["CDIGSTRate"]);
                            //                        cdigstAmount += Convert.ToDouble(row["CDIGSTAmount"]);
                            //                        cdCessRate += Convert.ToDouble(row["CDCessRate"]);
                            //                        cdCessAmount += Convert.ToDouble(row["CDCessAmount"]);
                            //                        tcsAmount += Convert.ToDouble(row["TCSAmount"]);
                            //                    }
                            //                }

                            //                // Assign values and calculate per-row GrandTotal
                            //                foreach (DataRow dr in dtGINPODetails.Rows)
                            //                {
                            //                    dr["PackingForwarding"] = packingForwarding;
                            //                    dr["PFIGSTRate"] = pfigstRate;
                            //                    dr["PFIGSTAmount"] = pfigstAmount;
                            //                    dr["PFSGSTRate"] = pfsgstRate;
                            //                    dr["PFSGSTAmount"] = pfsgstAmount;
                            //                    dr["PFCGSTRate"] = pfcgstRate;
                            //                    dr["PFCGSTAmount"] = pfcgstAmount;
                            //                    dr["TransportationFreight"] = transportationFreight;
                            //                    dr["TFIGSTRate"] = tfigstRate;
                            //                    dr["TFIGSTAmount"] = tfigstAmount;
                            //                    dr["TFSGSTRate"] = tfsgstRate;
                            //                    dr["TFSGSTAmount"] = tfsgstAmount;
                            //                    dr["TFCGSTRate"] = tfcgstRate;
                            //                    dr["TFCGSTAmount"] = tfcgstAmount;
                            //                    dr["CDPercent"] = cdPercent;
                            //                    dr["CDValue"] = cdValue;
                            //                    dr["CDIGSTRate"] = cdigstRate;
                            //                    dr["CDIGSTAmount"] = cdigstAmount;
                            //                    dr["CDCessRate"] = cdCessRate;
                            //                    dr["CDCessAmount"] = cdCessAmount;
                            //                    dr["TCSAmount"] = tcsAmount;

                            //                    // Now calculate and assign the per-row GrandTotal
                            //                    double grandTotal = 0;

                            //                    grandTotal += Convert.ToDouble(dr["TaxableAmount"]);
                            //                    grandTotal += Convert.ToDouble(dr["SGSTAmount"]);
                            //                    grandTotal += Convert.ToDouble(dr["CGSTAmount"]);
                            //                    grandTotal += Convert.ToDouble(dr["IGSTAmount"]);
                            //                    grandTotal += Convert.ToDouble(dr["PackingForwarding"]);
                            //                    grandTotal += Convert.ToDouble(dr["TransportationFreight"]);
                            //                    grandTotal += Convert.ToDouble(dr["PFIGSTAmount"]);
                            //                    grandTotal += Convert.ToDouble(dr["PFCGSTAmount"]);
                            //                    grandTotal += Convert.ToDouble(dr["PFSGSTAmount"]);
                            //                    grandTotal += Convert.ToDouble(dr["TFIGSTAmount"]);
                            //                    grandTotal += Convert.ToDouble(dr["TFCGSTAmount"]);
                            //                    grandTotal += Convert.ToDouble(dr["TFSGSTAmount"]);
                            //                    grandTotal += Convert.ToDouble(dr["CDValue"]);
                            //                    grandTotal += Convert.ToDouble(dr["CDIGSTAmount"]);
                            //                    grandTotal += Convert.ToDouble(dr["CDCessAmount"]);
                            //                    grandTotal += Convert.ToDouble(dr["TCSAmount"]);

                            //                    dr["GrandTotal"] = grandTotal;
                            //                }

                            //                // Update overall net amount (sum of "Amount" across all rows)
                            //                dNetAmount += Convert.ToDouble(dtGINPODetails.Compute("Sum(Amount)", ""));

                            //                // Merge into selected data table
                            //                dtSelectedGIN.Merge(dtGINPODetails);
                            //            }



                            //        }
                            //    }
                            //}


                            if (dtGINReport.Rows.Count > 0)
                            {
                                List<string> listPO = new List<string>();
                                foreach (DataRow dr1 in dtGINReport.Rows)
                                {
                                    if (!listPO.Contains(dr1["GINNumber"].ToString()))
                                    {
                                        listPO.Add(dr1["GINNumber"].ToString());
                                    }
                                }
                                if (listPO.Count > 0)
                                {
                                    foreach (string dr2 in listPO)
                                    {
                                        //string res = dr2.Substring(0, 1);
                                        //   if (dr2.ToString() == "ITWGIN2022001113")
                                        {
                                            dtGINPODetails = DAL.GINReportTables(null, dr2.ToString(), dtpFromDate.Text, dptToDate.Text, 10).Tables[0];
                                        }
                                        //if (dtGINPODetails.Rows.Count == 0)
                                        //{
                                        //    dtGINPODetails = DAL.GINReportTables(null, dr2.ToString(), dtpFromDate.Text, dptToDate.Text, 12).Tables[0];
                                        //}
                                        //if (dr2.ToString() == "ITWGIN2020003983")
                                        //{
                                        //    string sk = "PO";
                                        //}
                                        if (dtGINPODetails.Rows.Count > 0)
                                        {
                                            DataRow dr1 = dtGINPODetails.Rows[0];

                                            dr1["GrandTotal"] = 0;

                                            //if (dr2.ToString() == "ITWGIN2020003983")
                                            //{
                                            //    string sk = "PO";
                                            //}
                                            // DataTable dtPOQty = new DataTable();
                                            DataTable dtPack = new DataTable();


                                            dtPack = DAL.fnPackingForwarding(dr2.ToString(), "Packing & Forwarding").Tables[0];
                                            if (dtPack.Rows.Count > 0)
                                            {
                                                //if (Convert.ToDouble(dtPack.Rows[0]["Packing/Forwarding"].ToString()) > 0)
                                                //{
                                                dr1["PackingForwarding"] = Convert.ToDouble(dtPack.Rows[0]["Packing/Forwarding"].ToString());
                                                //}
                                                //else
                                                //{
                                                //    dr1["PackingForwarding"] = 0.0;
                                                //}

                                                //if (Convert.ToDouble(dtPack.Rows[0]["PFIGSTRate"].ToString()) > 0)
                                                //{
                                                dr1["PFIGSTRate"] = Convert.ToDouble(dtPack.Rows[0]["PFIGSTRate"].ToString());
                                                dr1["PFIGSTAmount"] = Convert.ToDouble(dtPack.Rows[0]["PFIGSTAmount"].ToString());
                                                //}
                                                //else
                                                //{
                                                //    dr1["PFIGSTRate"] = 0.0;
                                                //    dr1["PFIGSTAmount"] = 0.0;
                                                //}

                                                //if (Convert.ToDouble(dtPack.Rows[0]["PFSGSTRate"].ToString()) > 0)
                                                //{
                                                dr1["PFSGSTRate"] = Convert.ToDouble(dtPack.Rows[0]["PFSGSTRate"].ToString());
                                                dr1["PFSGSTAmount"] = Convert.ToDouble(dtPack.Rows[0]["PFSGSTAmount"].ToString());
                                                //}
                                                //else
                                                //{
                                                //    dr1["PFSGSTRate"] = 0.0;
                                                //    dr1["PFSGSTAmount"] = 0.0;
                                                //}

                                                //if (Convert.ToDouble(dtPack.Rows[0]["PFCGSTRate"].ToString()) > 0)
                                                //{
                                                dr1["PFCGSTRate"] = Convert.ToDouble(dtPack.Rows[0]["PFCGSTRate"].ToString());
                                                dr1["PFCGSTAmount"] = Convert.ToDouble(dtPack.Rows[0]["PFCGSTAmount"].ToString());
                                                //}
                                                //else
                                                //{
                                                //    dr1["PFCGSTRate"] = 0.0;
                                                //    dr1["PFCGSTAmount"] = 0.0;
                                                //}


                                                //if (Convert.ToDouble(dtPack.Rows[0]["Transportation/Freight"].ToString()) > 0)
                                                //{
                                                dr1["TransportationFreight"] = Convert.ToDouble(dtPack.Rows[0]["Transportation/Freight"].ToString());
                                                //}
                                                //else
                                                //{
                                                //    dr1["TransportationFreight"] = 0.0;
                                                //}

                                                //if (Convert.ToDouble(dtPack.Rows[0]["TFIGSTRate"].ToString()) > 0)
                                                //{
                                                dr1["TFIGSTRate"] = Convert.ToDouble(dtPack.Rows[0]["TFIGSTRate"].ToString());
                                                dr1["TFIGSTAmount"] = Convert.ToDouble(dtPack.Rows[0]["TFIGSTAmount"].ToString());
                                                //}
                                                //else
                                                //{
                                                //    dr1["TFIGSTRate"] = 0.0;
                                                //    dr1["TFIGSTAmount"] = 0.0;
                                                //}

                                                //if (Convert.ToDouble(dtPack.Rows[0]["TFSGSTRate"].ToString()) > 0)
                                                //{
                                                dr1["TFSGSTRate"] = Convert.ToDouble(dtPack.Rows[0]["TFSGSTRate"].ToString());
                                                dr1["TFSGSTAmount"] = Convert.ToDouble(dtPack.Rows[0]["TFSGSTAmount"].ToString());
                                                //}
                                                //else
                                                //{
                                                //    dr1["TFSGSTRate"] = 0.0;
                                                //    dr1["TFSGSTAmount"] = 0.0;
                                                //}

                                                //if (Convert.ToDouble(dtPack.Rows[0]["TFCGSTRate"].ToString()) > 0)
                                                //{
                                                dr1["TFCGSTRate"] = Convert.ToDouble(dtPack.Rows[0]["TFCGSTRate"].ToString());
                                                dr1["TFCGSTAmount"] = Convert.ToDouble(dtPack.Rows[0]["TFCGSTAmount"].ToString());
                                                //}
                                                //else
                                                //{
                                                //    dr1["TFCGSTRate"] = 0.0;
                                                //    dr1["TFCGSTAmount"] = 0.0;
                                                //}


                                                //if (Convert.ToDouble(dtPack.Rows[0]["CDPercent"].ToString()) > 0)
                                                //{
                                                dr1["CDPercent"] = Convert.ToDouble(dtPack.Rows[0]["CDPercent"].ToString());
                                                dr1["CDValue"] = Convert.ToDouble(dtPack.Compute("Sum(CDValue)", "").ToString());
                                                //}
                                                //else
                                                //{
                                                //    dr1["CDPercent"] = 0.0;
                                                //    dr1["CDValue"] = 0.0;
                                                //}

                                                //if (Convert.ToDouble(dtPack.Rows[0]["CDIGSTRate"].ToString()) > 0)
                                                //{
                                                dr1["CDIGSTRate"] = Convert.ToDouble(dtPack.Rows[0]["CDIGSTRate"].ToString());
                                                dr1["CDIGSTAmount"] = Convert.ToDouble(dtPack.Compute("Sum(CDIGSTAmount)", "").ToString());
                                                //}
                                                //else
                                                //{
                                                //    dr1["CDIGSTRate"] = 0.0;
                                                //    dr1["CDIGSTAmount"] = 0.0;
                                                //}

                                                //if (Convert.ToDouble(dtPack.Rows[0]["CDCessRate"].ToString()) > 0)
                                                //{
                                                dr1["CDCessRate"] = Convert.ToDouble(dtPack.Rows[0]["CDCessRate"].ToString());
                                                dr1["CDCessAmount"] = Convert.ToDouble(dtPack.Compute("Sum(CDCessAmount)", "").ToString());
                                                //}
                                                //else
                                                //{
                                                //    dr1["CDCessRate"] = 0.0;
                                                //    dr1["CDCessAmount"] = 0.0;
                                                //}

                                                //if (Convert.ToDouble(dtPack.Rows[0]["TCSAmount"].ToString()) > 0)
                                                //{
                                                dr1["TCSAmount"] = Convert.ToDouble(dtPack.Rows[0]["TCSAmount"].ToString());
                                                //}
                                                //else
                                                //{
                                                //    dr1["TCSAmount"] = 0.0;
                                                //}
                                            }


                                            dr1["GrandTotal"] = (Convert.ToDouble(dtGINPODetails.Compute("Sum(TaxableAmount)", "").ToString())
                                                + Convert.ToDouble(dtGINPODetails.Compute("Sum(SGSTAmount)", "").ToString())
                                                 + Convert.ToDouble(dtGINPODetails.Compute("Sum(CGSTAmount)", "").ToString())
                                                 + Convert.ToDouble(dtGINPODetails.Compute("Sum(IGSTAmount)", "").ToString())
                                                 + Convert.ToDouble(dtGINPODetails.Compute("Sum(PackingForwarding)", "").ToString())
                                                 + Convert.ToDouble(dtGINPODetails.Compute("Sum(TransportationFreight)", "").ToString())
                                                  + Convert.ToDouble(dtGINPODetails.Compute("Sum(PFIGSTAmount)", "").ToString())
                                                   + Convert.ToDouble(dtGINPODetails.Compute("Sum(PFCGSTAmount)", "").ToString())
                                                    + Convert.ToDouble(dtGINPODetails.Compute("Sum(PFSGSTAmount)", "").ToString())
                                                     + Convert.ToDouble(dtGINPODetails.Compute("Sum(TFIGSTAmount)", "").ToString())
                                                      + Convert.ToDouble(dtGINPODetails.Compute("Sum(TFCGSTAmount)", "").ToString())
                                                       + Convert.ToDouble(dtGINPODetails.Compute("Sum(TFSGSTAmount)", "").ToString())
                                                        + Convert.ToDouble(dtGINPODetails.Compute("Sum(CDValue)", "").ToString())
                                                         + Convert.ToDouble(dtGINPODetails.Compute("Sum(CDIGSTAmount)", "").ToString())
                                                          + Convert.ToDouble(dtGINPODetails.Compute("Sum(CDCessAmount)", "").ToString())
                                                           + Convert.ToDouble(dtGINPODetails.Compute("Sum(TCSAmount)", "").ToString()));

                                            dNetAmount += Convert.ToDouble(dtGINPODetails.Compute("Sum(Amount)", "").ToString());


                                            dtSelectedGIN.Merge(dtGINPODetails);

                                        }
                                    }
                                }
                            }


                            DataSet ds = new DataSet("GIN");
                            ds.Tables.Add(dtSelectedGIN);

                            ExportToExcel(ds, FileFullPath, "GINPO");
                        }
                        else
                        {
                            MessageBox.Show("Selected date has no records to genarate report!");
                        }
                    }
                    break;
                #endregion
                #region Consolidated GIN WO Report
                case "Consolidated GIN Report WO":
                    {
                        FinalSum = 0.0;
                        DataTable dtissued = new DataTable();
                        List<string> listSupplierName = new List<string>();
                        dtissued = DAL.GINWOReportTables(null, null, dtpFromDate.Text, dptToDate.Text, 11).Tables[0];
                        if (dtissued.Rows.Count > 0)
                        {
                            foreach (DataRow dr in dtissued.Rows)
                            {
                                if (!listSupplierName.Contains(dr["SupplierName"].ToString()))
                                {
                                    listSupplierName.Add(dr["SupplierName"].ToString());
                                }
                            }
                            excelapp = new Microsoft.Office.Interop.Excel.Application();
                            workbook = excelapp.Workbooks.Add(Type.Missing);
                            // This returns something like C:\Users\Username:
                            string userRoot = System.Environment.GetEnvironmentVariable("USERPROFILE");
                            // Now let's get C:\Users\Username\Downloads:
                            string downloadFolder = Path.Combine(userRoot, "Downloads");

                            string ExcelFolderPath = downloadFolder + "\\Consolidated GIN WO Report\\";
                            string FileFullPath = ExcelFolderPath + "Consolidated GIN WO Report (" + dtpFromDate.Text + "to " + dptToDate.Text + ")" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                            if (!Directory.Exists(ExcelFolderPath))
                                Directory.CreateDirectory(ExcelFolderPath);

                            workbook.SaveAs(FileFullPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                            Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                            worksheet = workbook.Sheets["Sheet1"];
                            worksheet = workbook.ActiveSheet;
                            worksheet.Name = "Consolidated GIN Report";
                            object misValue = System.Reflection.Missing.Value;
                            worksheet.Cells[1, 1] = Global.sCompanyName;
                            CellMerge("Merge", workbook.ActiveSheet, 1, 1, 1, 3);
                            worksheet.Cells[2, 1] = "Consolidated GIN WO Report";
                            CellMerge("Merge", workbook.ActiveSheet, 2, 2, 1, 3);
                            worksheet.Range["A1:C1"].Cells.Font.Size = 16;
                            worksheet.Range["A1:C1"].Cells.Font.Bold = 16;
                            worksheet.Range["A2:C2"].Cells.Font.Size = 14;
                            worksheet.Range["A2:C2"].Cells.Font.Bold = 14;
                            worksheet.Range["A3:C3"].Cells.Font.Size = 12;
                            worksheet.Range["A3:C3"].Cells.Font.Bold = 12;
                            worksheet.Range["A3:C4"].Cells.Font.Size = 12;
                            worksheet.Range["A3:C4"].Cells.Font.Bold = 12;
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[6, Type.Missing]).Font.Color = Color.Blue;
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[6, Type.Missing]).Font.Bold = true;
                            int i = 0;
                            int j = 7;
                            bool bvendorname = true;
                            foreach (string dr in listSupplierName)
                            {

                                DataTable dtWOGINIndiviual = new DataTable();
                                dtWOGINIndiviual = DAL.GINWOReportTables(dr.ToString(), null, dtpFromDate.Text, dptToDate.Text, 11).Tables[0];
                                if (dtWOGINIndiviual.Rows.Count > 0)
                                {

                                    if (dtWOGINIndiviual.Rows.Count > 0)
                                    {
                                        if (bvendorname)
                                        {
                                            bvendorname = false;
                                            string[] sColumnNames = new string[] { "WONo","Vendor Name" ,"Vendor GST Number","Item Code", "Item Description","HSN / SAC", "GINNumber", "Supplier Invoice Number", "GIN Date", "Invoice Date", "Quantity", "UnitCost", "Amount",
                                                                                            "SGSTRate","SGSTAmount","CGSTRate","CGSTAmount","IGSTRate","IGSTAmount","DC Number"};
                                            int icolumn = 1;
                                            for (int p = 0; p < sColumnNames.Length; p++)
                                            {
                                                worksheet.Cells[(j - 1), icolumn] = sColumnNames[p];
                                                icolumn++;
                                            }
                                        }

                                        if (dtWOGINIndiviual.Rows.Count > 0)
                                        {
                                            // i++;
                                            object[,] rawData = new object[dtWOGINIndiviual.Rows.Count, dtWOGINIndiviual.Columns.Count];//one line project code next line column header

                                            for (int row = 0; row < dtWOGINIndiviual.Rows.Count; row++)
                                            {
                                                for (int col = 0; col < dtWOGINIndiviual.Columns.Count; col++)
                                                {
                                                    rawData[row, col] = dtWOGINIndiviual.Rows[row].ItemArray[col];
                                                }
                                            }


                                            finalColLetter = string.Empty;
                                            string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                                            int colCharsetLen = colCharset.Length;

                                            if (dtWOGINIndiviual.Columns.Count > colCharsetLen)
                                            {
                                                finalColLetter = colCharset.Substring((dtWOGINIndiviual.Columns.Count - 1) / colCharsetLen - 1, 1);
                                            }

                                            finalColLetter += colCharset.Substring((dtWOGINIndiviual.Columns.Count - 1) % colCharsetLen, 1);
                                            excelRange = string.Format("A" + j + ":{0}{1}", finalColLetter, (dtWOGINIndiviual.Rows.Count + j - 1));

                                            worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;

                                            j = j + (dtWOGINIndiviual.Rows.Count);

                                            // j = j + 3;
                                        }
                                        //   i++;
                                        FinalSum = FinalSum + Convert.ToDouble(dtWOGINIndiviual.Compute("Sum(Amount)", "").ToString());
                                        //  i += 2;
                                        //  bvendorname = true;
                                    }
                                }
                            }
                            worksheet.Cells[3, 1] = "Total NetAmount:";
                            worksheet.Cells[3, 2] = FinalSum.ToString();
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[3, Type.Missing]).Font.Color = Color.Red;
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[3, Type.Missing]).Font.Bold = true;

                            worksheet.Columns.AutoFit();
                            worksheet.Rows.AutoFit();
                            worksheet.get_Range("D6", "D9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                            worksheet.Columns[4].ColumnWidth = 50;
                            worksheet.Columns[4].WrapText = true;
                            worksheet.Rows.RowHeight = "18";
                            worksheet.get_Range("D6", "D9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;

                            fnDateFormatstring(worksheet, "I7", "J9999");
                            fnNumberFormatstring(worksheet, "K6", "S9999");

                            fnExcelPrint(worksheet, "A1:S" + (j + 6) + "");
                            fnDrawLogo(worksheet, 1, 6);


                            Microsoft.Office.Interop.Excel.Range Range = worksheet.get_Range("I6", "K99999");
                            Range.EntireColumn.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                            workbook.Save();
                            workbook.Close(true, misValue, misValue);
                            excelapp.Quit();
                            releaseObject(worksheet);
                            releaseObject(workbook);
                            releaseObject(excelapp);

                            if (Directory.Exists(ExcelFolderPath))
                            {
                                Process.Start(ExcelFolderPath);
                            }
                            Cursor.Current = Cursors.Default;
                        }
                        else
                        {
                            MessageBox.Show("Selected date has no records to genarate report!");
                        }
                    }
                    break;
                #endregion
                #region Consolidated Vendor PO Report
                case "Vendor GIN Report PO":
                    {
                        if (!string.IsNullOrEmpty(cmbvendorlist.Text))
                        {
                            int j = 6;
                            excelapp = new Microsoft.Office.Interop.Excel.Application();
                            workbook = excelapp.Workbooks.Add(Type.Missing);
                            // This returns something like C:\Users\Username:
                            string userRoot = System.Environment.GetEnvironmentVariable("USERPROFILE");
                            // Now let's get C:\Users\Username\Downloads:
                            string downloadFolder = Path.Combine(userRoot, "Downloads");

                            string ExcelFolderPath = downloadFolder + "\\Consolidated Vendor GIN PO Report\\";
                            string FileFullPath = ExcelFolderPath + "Consolidated Vendor GIN PO Report (" + dtpFromDate.Text + "to " + dptToDate.Text + ")" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                            if (!Directory.Exists(ExcelFolderPath))
                                Directory.CreateDirectory(ExcelFolderPath);

                            workbook.SaveAs(FileFullPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                            Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                            DataTable dtSupllierTable = new DataTable();
                            dtSupllierTable = DAL.GINReportTablesVendorwise(cmbvendorlist.Text, null, dtpFromDate.Text, dptToDate.Text).Tables[0];

                            if (dtSupllierTable.Rows.Count > 0)
                            {
                                worksheet = workbook.Sheets["Sheet1"];
                                worksheet = workbook.ActiveSheet;
                                worksheet.Name = "Consolidated Vendor GIN Report";
                                object misValue = System.Reflection.Missing.Value;
                                worksheet.Cells[1, 1] = Global.sCompanyName;
                                CellMerge("Merge", workbook.ActiveSheet, 1, 1, 1, 3);
                                worksheet.Cells[2, 1] = "Consolidated Vendor GIN PO Report";
                                CellMerge("Merge", workbook.ActiveSheet, 2, 2, 1, 3);
                                worksheet.Cells[3, 1] = "Dated From : " + dtpFromDate.Text + " To : " + dptToDate.Text + "";
                                CellMerge("Merge", workbook.ActiveSheet, 3, 3, 1, 3);
                                worksheet.Range["A1:C1"].Cells.Font.Size = 16;
                                worksheet.Range["A1:C4"].Cells.Font.Bold = true;
                                worksheet.Range["A2:C2"].Cells.Font.Size = 14;
                                worksheet.Range["A3:C3"].Cells.Font.Size = 12;
                                worksheet.Range["A3:C4"].Cells.Font.Size = 12;

                                worksheet.Cells[j, 1] = cmbvendorlist.Text;
                                CellMerge("Merge", workbook.ActiveSheet, j, j, 1, 5);
                                worksheet.Range["A6:C5"].Cells.Font.Size = 16;
                                worksheet.Range["A6:C5"].Cells.Font.Bold = true;
                                worksheet.Range["A6:C5"].Cells.Font.Color = Color.Red;

                                DataTable dtPOVendorList = new DataTable();
                                bool IsFirsttime = true;
                                string finalColLetter = string.Empty;
                                double dNetAmount = 0.0;

                                List<string> listPO = new List<string>();
                                foreach (DataRow dr1 in dtSupllierTable.Rows)
                                {
                                    if (!listPO.Contains(dr1["GINNumber"].ToString()))
                                    {
                                        listPO.Add(dr1["GINNumber"].ToString());
                                    }
                                }

                                if (listPO.Count > 0)
                                {
                                    foreach (string dr2 in listPO)
                                    {
                                        dtPOVendorList = DAL.GINReportTablesVendorwise(null, dr2.ToString(), dtpFromDate.Text, dptToDate.Text).Tables[0];
                                        if (dtPOVendorList.Rows.Count > 0)
                                        {
                                            DataRow dr1 = dtPOVendorList.Rows[0];

                                            dr1["GrandTotal"] = 0;
                                            DataTable dtPOQty = new DataTable();
                                            DataTable dtPack = new DataTable();
                                            double sTotalQTY = 0;
                                            //  dtPOQty = DAL.fnPOQty(dtPOVendorList.Rows[0]["RefNumber"].ToString()).Tables[0];
                                            // sTotalQTY = Convert.ToDouble(dtPOQty.Compute("Sum(TotalQty)", "").ToString());

                                            //  double sGINQTY = 0;
                                            // sGINQTY = Convert.ToDouble(dtPOVendorList.Compute("Sum(Quantity)", "").ToString());

                                            dtPack = DAL.fnPackingForwarding(dtPOVendorList.Rows[0]["GINNumber"].ToString(), "Packing & Forwarding").Tables[0];
                                            double pack = 0;
                                            if (dtPack.Rows.Count > 0)
                                            {
                                                pack = (Convert.ToDouble(dtPack.Rows[0]["Amount"].ToString()));// / sTotalQTY) * sGINQTY;
                                                dr1["Packing/Forwarding"] = pack;
                                            }
                                            else
                                            {
                                                dr1["Packing/Forwarding"] = 0.0;
                                                pack = 0;
                                            }
                                            dtPack = DAL.fnPackingForwarding(dtPOVendorList.Rows[0]["GINNumber"].ToString(), "Transportation / Freight").Tables[0];
                                            double freight = 0;
                                            if (dtPack.Rows.Count > 0)
                                            {
                                                freight = (Convert.ToDouble(dtPack.Rows[0]["Amount"].ToString()));
                                                dr1["Transportation/Freight"] = freight;
                                            }
                                            else
                                            {
                                                dr1["Transportation/Freight"] = 0.0;
                                                freight = 0;
                                            }

                                            dr1["GrandTotal"] = (Convert.ToDouble(dtPOVendorList.Compute("Sum(TaxableAmount)", "").ToString()) + Convert.ToDouble(dtPOVendorList.Compute("Sum(SGSTAmount)", "").ToString())
                                                 + Convert.ToDouble(dtPOVendorList.Compute("Sum(CGSTAmount)", "").ToString()) + Convert.ToDouble(dtPOVendorList.Compute("Sum(IGSTAmount)", "").ToString()) + pack + freight).ToString();

                                            dNetAmount += Convert.ToDouble(dtPOVendorList.Compute("Sum(Amount)", "").ToString());
                                            j++;

                                            dtPOVendorList.Columns.Remove("ProjectCode");
                                            dtPOVendorList.Columns.Remove("ProjectDescription");
                                            dtPOVendorList.Columns.Remove("Customer");

                                            object[,] rawData = new object[dtPOVendorList.Rows.Count + 1, dtPOVendorList.Columns.Count];//one line project code next line column header
                                            for (int col = 0; col < dtPOVendorList.Columns.Count; col++)
                                            {
                                                rawData[0, col] = dtPOVendorList.Columns[col].ColumnName;

                                            }
                                            for (int row = 0; row < dtPOVendorList.Rows.Count; row++)
                                            {
                                                for (int col = 0; col < dtPOVendorList.Columns.Count; col++)
                                                {
                                                    rawData[row + 1, col] = dtPOVendorList.Rows[row].ItemArray[col];
                                                }
                                            }
                                            string excelRange = string.Empty;
                                            if (IsFirsttime)
                                            {
                                                finalColLetter = string.Empty;
                                                string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                                                int colCharsetLen = colCharset.Length;

                                                if (dtPOVendorList.Columns.Count > colCharsetLen)
                                                {
                                                    finalColLetter = colCharset.Substring(
                                                        (dtPOVendorList.Columns.Count - 1) / colCharsetLen - 1, 1);
                                                }

                                                finalColLetter += colCharset.Substring(
                                                        (dtPOVendorList.Columns.Count - 1) % colCharsetLen, 1);
                                                excelRange = string.Format("A9:{0}{1}", finalColLetter, dtPOVendorList.Rows.Count + j + 2);
                                                IsFirsttime = false;
                                                j += 2;
                                            }
                                            else
                                            {
                                                j += 2;
                                                excelRange = string.Format("A" + j + ":{0}{1}", finalColLetter, dtPOVendorList.Rows.Count + j);
                                            }

                                            worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;

                                            j = j + (dtPOVendorList.Rows.Count);
                                        }
                                    }
                                }

                                j++;
                                dtPOVendorList.Rows.Clear();

                                worksheet.Cells[4, 1] = "Net Amount:";
                                worksheet.Cells[4, 2] = dNetAmount.ToString();
                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[4, Type.Missing]).Font.Color = Color.Blue;
                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[4, Type.Missing]).Font.Bold = true;

                                worksheet.get_Range("C6", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;

                                worksheet.Columns.AutoFit();
                                worksheet.Rows.AutoFit();
                                worksheet.Columns[3].ColumnWidth = 50;
                                worksheet.Columns[3].WrapText = true;

                                worksheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                                worksheet.Rows.RowHeight = "18";

                                fnDateFormatstring(worksheet, "F1", "G9999");
                                fnNumberFormatstring(worksheet, "H1", "V9999");
                                fnExcelPrint(worksheet, "A1:O" + j + "");
                                fnDrawLogo(worksheet, 1, 9);
                                workbook.Save();
                                workbook.Close(true, misValue, misValue);
                                excelapp.Quit();
                                releaseObject(worksheet);
                                releaseObject(workbook);
                                releaseObject(excelapp);

                                if (Directory.Exists(ExcelFolderPath))
                                {
                                    Process.Start(ExcelFolderPath);
                                }
                                Cursor.Current = Cursors.Default;
                            }
                            else
                            {
                                MessageBox.Show("No transactions found to genarate consolidated PO Excel Report");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please select a Vendor to genarate consolidated PO Excel Report");
                        }
                    }
                    break;
                #endregion
                #region Consolidated Vendor WO Report
                case "Vendor GIN Report WO":
                    {
                        if (!string.IsNullOrEmpty(cmbvendorlist.Text))
                        {
                            DataTable dtVendorGIN = new DataTable();
                            dtVendorGIN = DAL.GINWOReportTablesVendorwise2(cmbvendorlist.Text, null, dtpFromDate.Text, dptToDate.Text).Tables[0];

                            if (dtVendorGIN.Rows.Count > 0)
                            {
                                FinalSum = 0.0;
                                excelapp = new Microsoft.Office.Interop.Excel.Application();
                                workbook = excelapp.Workbooks.Add(Type.Missing);
                                // This returns something like C:\Users\Username:
                                string userRoot = System.Environment.GetEnvironmentVariable("USERPROFILE");
                                // Now let's get C:\Users\Username\Downloads:
                                string downloadFolder = Path.Combine(userRoot, "Downloads");
                                string ExcelFolderPath = downloadFolder + "\\Consolidated Vendor GIN WO Report\\";
                                string FileFullPath = ExcelFolderPath + "Consolidated Vendor GIN Wo Report (" + dtpFromDate.Text + "to " + dptToDate.Text + ")" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                                if (!Directory.Exists(ExcelFolderPath))
                                    Directory.CreateDirectory(ExcelFolderPath);

                                workbook.SaveAs(FileFullPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                                Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                                worksheet = workbook.Sheets["Sheet1"];
                                worksheet = workbook.ActiveSheet;
                                worksheet.Name = "Consolidated Vendor GIN Report";
                                object misValue = System.Reflection.Missing.Value;
                                worksheet.Cells[1, 1] = Global.sCompanyName;
                                CellMerge("Merge", workbook.ActiveSheet, 1, 1, 1, 3);
                                worksheet.Cells[2, 1] = "Consolidated Vendor GIN WO Report";
                                CellMerge("Merge", workbook.ActiveSheet, 2, 2, 1, 3);
                                worksheet.Cells[3, 1] = "Dated From : " + dtpFromDate.Text + " To : " + dptToDate.Text + "";
                                CellMerge("Merge", workbook.ActiveSheet, 3, 3, 1, 3);
                                worksheet.Cells[5, 1] = cmbvendorlist.Text;
                                CellMerge("Merge", workbook.ActiveSheet, 5, 5, 1, 3);

                                worksheet.Range["A1:C1"].Cells.Font.Bold = true;
                                worksheet.Range["A1:C1"].Cells.Font.Size = 16;
                                worksheet.Range["A2:C2"].Cells.Font.Bold = true;
                                worksheet.Range["A2:C2"].Cells.Font.Size = 14;
                                worksheet.Range["A3:C3"].Cells.Font.Size = 12;
                                worksheet.Range["A3:C3"].Cells.Font.Bold = true;
                                worksheet.Range["A5:C5"].Cells.Font.Bold = true;
                                worksheet.Range["A5:C5"].Cells.Font.Size = 16;// 16;
                                worksheet.Range["A5:C5"].Cells.Font.Color = Color.Red;

                                int i = 0;

                                List<string> listPO = new List<string>();
                                foreach (DataRow dr1 in dtVendorGIN.Rows)
                                {
                                    if (!listPO.Contains(dr1["GINNumber"].ToString()))
                                    {
                                        listPO.Add(dr1["GINNumber"].ToString());
                                    }
                                }
                                if (listPO.Count > 0)
                                {
                                    foreach (string dr2 in listPO)
                                    {
                                        DataTable dtWOGIN = new DataTable();
                                        dtWOGIN = DAL.GINWOReportTablesVendorwise(null, dr2.ToString(), dtpFromDate.Text, dptToDate.Text).Tables[0];
                                        if (dtWOGIN.Rows.Count > 0)
                                        {
                                            DataTable dtTax = new DataTable();
                                            string name = "WOReport";
                                            dtTax = DAL.GINTax(dr2.ToString(), name).Tables[0];

                                            string sCustomer = string.Empty;
                                            string slistSupplierName = string.Empty;
                                            DataTable dtProjectdiscription = new DataTable();

                                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 6, Type.Missing]).Font.Bold = true;
                                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 6, Type.Missing]).Font.Color = Color.Blue;

                                            string[] sColumnNames = new string[] { "WONo", "Item Code", "Item Discription", "GINNumber", "GIN Date", "SupplierInvoiceNumber", "Invoice Date", "Quantity", "UnitCost", "Amount" };
                                            int icolumn = 1;
                                            for (int p = 0; p < sColumnNames.Length; p++)
                                            {
                                                worksheet.Cells[i + 6, icolumn] = sColumnNames[p];
                                                icolumn++;
                                            }

                                            if (dtWOGIN.Rows.Count > 0)
                                            {
                                                for (int iCountRow = 0; iCountRow < (dtWOGIN.Rows.Count); iCountRow++)
                                                {
                                                    i++;
                                                    worksheet.Rows.AutoFit();
                                                    for (int j = 0; j < dtWOGIN.Columns.Count; j++)
                                                    {
                                                        worksheet.Columns.AutoFit();
                                                        worksheet.Cells[i + 6, j + 1] = dtWOGIN.Rows[iCountRow][j].ToString();
                                                    }
                                                }

                                            }
                                            i++;
                                            worksheet.Cells[i + 6, 8] = "Grand Total:";
                                            worksheet.Cells[i + 6, 9] = dtWOGIN.Compute("Sum(Amount)", "").ToString();
                                            if (dtTax.Rows.Count > 0)
                                            {
                                                double sTotalQTY = 0;
                                                DataTable dtWOQTY = new DataTable();
                                                dtWOQTY = DAL.fnWOQty(dtWOGIN.Rows[0]["RefNumber"].ToString()).Tables[0];
                                                sTotalQTY = Convert.ToDouble(dtWOQTY.Compute("Sum(TotalQty)", "").ToString());

                                                double sGINQTY = 0;
                                                sGINQTY = Convert.ToDouble(dtWOGIN.Compute("Sum(Quantity)", "").ToString());

                                                dBasicnPacking = (((Convert.ToDouble(dtTax.Rows[0]["PackingForwording"].ToString())) / sTotalQTY) * sGINQTY);

                                                dBasicnPacking = ((dBasicnPacking) + Convert.ToDouble(dtWOGIN.Compute("Sum(Amount)", "").ToString()));

                                                dDiscount = (((Convert.ToDouble(dtTax.Rows[0]["Discount_per"].ToString().Trim('%'))) / 100) * dBasicnPacking);

                                                dAfterdiscount = dBasicnPacking - dDiscount;

                                                dExcise = (((Convert.ToDouble(dtTax.Rows[0]["ExciseDuty_per"].ToString().Trim('%'))) / 100) * dAfterdiscount);

                                                dAfterExcise = dExcise + dAfterdiscount;

                                                dVat = (((Convert.ToDouble(dtTax.Rows[0]["VATServiceTax_per"].ToString().Trim('%'))) / 100) * dAfterExcise);

                                                dCST = (((Convert.ToDouble(dtTax.Rows[0]["CST_per"].ToString().Trim('%'))) / 100) * dAfterExcise);

                                                dTotal = dAfterExcise + dVat + dCST + (((Convert.ToDouble(dtTax.Rows[0]["Others"].ToString())) / sTotalQTY) * sGINQTY);


                                                worksheet.Cells[i + 7, 8] = "Tax Amount:";
                                                worksheet.Cells[i + 7, 9] = (((Convert.ToDouble(dtTax.Rows[0]["PackingForwording"].ToString())) / sTotalQTY) * sGINQTY) + dExcise + dVat + dCST + (((Convert.ToDouble(dtTax.Rows[0]["Others"].ToString())) / sTotalQTY) * sGINQTY);
                                                worksheet.Cells[i + 8, 8] = "Final Amount:";
                                                worksheet.Cells[i + 8, 9] = dTotal;
                                                FinalSum = FinalSum + dTotal;
                                            }
                                            else
                                            {
                                                worksheet.Cells[i + 7, 8] = "Tax Amount:";
                                                worksheet.Cells[i + 7, 9] = "0";
                                                worksheet.Cells[i + 8, 8] = "Final Amount:";
                                                worksheet.Cells[i + 8, 9] = Convert.ToDouble(dtWOGIN.Compute("Sum(Amount)", "").ToString());
                                                FinalSum = FinalSum + Convert.ToDouble(dtWOGIN.Compute("Sum(Amount)", "").ToString());
                                            }
                                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 6, Type.Missing]).Font.Bold = true;
                                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 6, Type.Missing]).Font.Color = Color.Blue;
                                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 7, Type.Missing]).Font.Bold = true;
                                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 7, Type.Missing]).Font.Color = Color.Blue;
                                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 8, Type.Missing]).Font.Bold = true;
                                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 8, Type.Missing]).Font.Color = Color.Blue;
                                            i += 4;
                                        }
                                    }
                                }
                                worksheet.Cells[3, 4] = "Total NetAmount:";
                                CellMerge("Merge", workbook.ActiveSheet, 3, 3, 4, 5);
                                worksheet.Cells[3, 6] = FinalSum.ToString();
                                worksheet.Range["D3:F3"].Cells.Font.Bold = true;
                                worksheet.Range["D3:F3"].Cells.Font.Size = 16;
                                worksheet.Range["D3:F3"].Cells.Font.Color = Color.Red;
                                worksheet.get_Range("C6", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                                worksheet.Columns.AutoFit();
                                worksheet.Rows.AutoFit();
                                worksheet.Columns[3].ColumnWidth = 50;
                                worksheet.Columns[3].WrapText = true;
                                worksheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                                worksheet.Rows.RowHeight = "18";
                                fnDateFormatstring(worksheet, "E7", "E9999");
                                fnNumberFormatstring(worksheet, "H6", "I9999");
                                fnExcelPrint(worksheet, "A1:I" + (i + 4) + "");
                                fnDrawLogo(worksheet, 1, 7);
                                workbook.Save();
                                workbook.Close(true, misValue, misValue);
                                excelapp.Quit();
                                releaseObject(worksheet);
                                releaseObject(workbook);
                                releaseObject(excelapp);

                                if (Directory.Exists(ExcelFolderPath))
                                {
                                    Process.Start(ExcelFolderPath);
                                }
                            }
                            else
                            {
                                MessageBox.Show("No transactions found to genarate consolidated WO Excel Report");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Please select a Vendor to genarate consolidated WO Excel Report");
                        }
                    }
                    break;
                #endregion
                #region VendorMaster Report
                case "Vendor List":
                    dtReciept = DAL.fnVedorList(null).Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {
                        // dtReciept.Columns.Remove("id");
                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;
                #endregion
                #region Transactional Spent Report
                case "Transactional Spend Data":
                    dtReciept = DAL.fnTransactionalspenddata(dtpFromDate.Text, dptToDate.Text).Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;
                #endregion
                #region Ap Spendt Data
                case "AP Spend Data":
                    dtReciept = DAL.fnApSpenddata(dtpFromDate.Text, dptToDate.Text).Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;
                #endregion
                #region ProjectMaster Report
                case "Project List":
                    dtReciept = DAL.fnReportProjectList().Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;
                #endregion
                #region Standard Cost PO Report
                case "Standard Cost PO":
                    dtReciept = DAL.fnStandardCostPOWO("PO", null, dtpFromDate.Text, dptToDate.Text).Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;
                #endregion
                #region Standard Cost WO Report
                case "Standard Cost WO":
                    dtReciept = DAL.fnStandardCostPOWO(null, "WO", dtpFromDate.Text, dptToDate.Text).Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;
                #endregion
                #region Pending PO Report
                case "Pending PO":
                case "GM Approve Pending PO":
                    {
                        DataTable ConsolidatedPendingPOReport = new DataTable();
                        List<string> listSupplierName = new List<string>();
                        if (cmbReport.SelectedItem.ToString() == "Pending PO")
                        {
                            ConsolidatedPendingPOReport = DAL.GINPendingPOReport(1, dtpFromDate.Text, dptToDate.Text).Tables[0];
                        }
                        else if (cmbReport.SelectedItem.ToString() == "GM Approve Pending PO")
                        {
                            ConsolidatedPendingPOReport = DAL.GINPendingPOReport(2, dtpFromDate.Text, dptToDate.Text).Tables[0];
                        }
                        int j = 7;
                        if (ConsolidatedPendingPOReport.Rows.Count > 0)
                        {
                            excelapp = new Microsoft.Office.Interop.Excel.Application();
                            workbook = excelapp.Workbooks.Add(Type.Missing);
                            // This returns something like C:\Users\Username:
                            string userRoot = System.Environment.GetEnvironmentVariable("USERPROFILE");
                            // Now let's get C:\Users\Username\Downloads:
                            string downloadFolder = Path.Combine(userRoot, "Downloads");
                            string ExcelFolderPath = downloadFolder + "\\Pending PO\\";
                            string FileFullPath = ExcelFolderPath + cmbReport.Text + dtpFromDate.Text + " to " + dptToDate.Text + "" + DateTime.Now.ToString(" hh/mm/ss");
                            if (!Directory.Exists(ExcelFolderPath))
                                Directory.CreateDirectory(ExcelFolderPath);

                            workbook.SaveAs(FileFullPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                            Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                            worksheet = workbook.Sheets["Sheet1"];
                            worksheet = workbook.ActiveSheet;
                            worksheet.Name = "Pending PO Report";
                            object misValue = System.Reflection.Missing.Value;

                            worksheet.Cells[1, 1] = Global.sCompanyName;
                            worksheet.Cells[2, 1] = "Pending PO Report";
                            worksheet.Cells[3, 1] = "Date";
                            worksheet.Cells[3, 2] = DateTime.Today.ToString("dd-MM-yyyy");
                            worksheet.Range["A1:C1"].Cells.Font.Size = 16;
                            worksheet.Range["A1:C1"].Cells.Font.Bold = 16;
                            worksheet.Range["A2:C2"].Cells.Font.Size = 14;
                            worksheet.Range["A2:C2"].Cells.Font.Bold = 14;
                            worksheet.Range["A3:C3"].Cells.Font.Size = 12;
                            worksheet.Range["A3:C3"].Cells.Font.Bold = 12;
                            worksheet.Range["A3:C4"].Cells.Font.Size = 12;
                            worksheet.Range["A3:C4"].Cells.Font.Bold = 12;

                            bool IsFirsttime = true;
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Bold = true;
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Color = Color.Blue;
                            object[,] rawData = new object[ConsolidatedPendingPOReport.Rows.Count + 1, ConsolidatedPendingPOReport.Columns.Count];
                            for (int col = 0; col < ConsolidatedPendingPOReport.Columns.Count; col++)
                            {
                                rawData[0, col] = ConsolidatedPendingPOReport.Columns[col].ColumnName;
                            }
                            if (ConsolidatedPendingPOReport.Rows.Count > 0)
                            {
                                for (int row = 0; row < ConsolidatedPendingPOReport.Rows.Count; row++)
                                {
                                    for (int col = 0; col < ConsolidatedPendingPOReport.Columns.Count; col++)
                                    {
                                        rawData[row + 1, col] = ConsolidatedPendingPOReport.Rows[row].ItemArray[col];
                                    }
                                }
                                string finalColLetter = string.Empty;
                                string excelRange = string.Empty;
                                if (IsFirsttime)
                                {
                                    finalColLetter = string.Empty;
                                    string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                                    int colCharsetLen = colCharset.Length;

                                    if (ConsolidatedPendingPOReport.Columns.Count > colCharsetLen)
                                    {
                                        finalColLetter = colCharset.Substring(
                                            (ConsolidatedPendingPOReport.Columns.Count - 1) / colCharsetLen - 1, 1);
                                    }

                                    finalColLetter += colCharset.Substring(
                                            (ConsolidatedPendingPOReport.Columns.Count - 1) % colCharsetLen, 1);
                                    excelRange = string.Format("A7:{0}{1}", finalColLetter, ConsolidatedPendingPOReport.Rows.Count + j);
                                    IsFirsttime = false;
                                }
                                worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                            }
                            worksheet.Columns.AutoFit();
                            worksheet.Rows.AutoFit();
                            worksheet.Columns[3].ColumnWidth = 30;
                            worksheet.Columns[3].WrapText = true;
                            worksheet.Columns[6].ColumnWidth = 50;
                            worksheet.Columns[6].WrapText = true;
                            worksheet.Columns[17].ColumnWidth = 30;
                            worksheet.Columns[17].WrapText = true;
                            worksheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                            worksheet.Rows.RowHeight = "18";

                            fnDateFormat(worksheet, 1, 5);
                            fnNumberFormatstring(worksheet, "H1", "M9999");
                            fnDateFormatstring(worksheet, "O1", "P9999");
                            //fnNumberFormatstring(worksheet, "P1", "T9999");
                            fnExcelPrint(worksheet, "A1:O" + j + "");
                            fnDrawLogo(worksheet, 1, 6);
                            workbook.Save();
                            workbook.Close(true, misValue, misValue);
                            excelapp.Quit();
                            releaseObject(worksheet);
                            releaseObject(workbook);
                            releaseObject(excelapp);

                            if (Directory.Exists(ExcelFolderPath))
                            {
                                Process.Start(ExcelFolderPath);
                            }
                            Cursor.Current = Cursors.Default;
                        }
                        else
                        {
                            MessageBox.Show("Selected date has no records to genarate report!");
                        }
                    }
                    break;
                #endregion
                #region DepartmentWise Issued
                case "DepartmentWise Issued":
                    {
                        double dGrandSum = 0.0;
                        DataTable dtissued = new DataTable();
                        List<string> listprojects = new List<string>();
                        dtissued = DAL.fnIssuedListDepartmentwise(null, dtpFromDate.Text, dptToDate.Text).Tables[0];
                        bool IsFirsttime = true;
                        if (dtissued.Rows.Count > 0)
                        {
                            int j = 7;
                            excelapp = new Microsoft.Office.Interop.Excel.Application();
                            workbook = excelapp.Workbooks.Add(Type.Missing);
                            // This returns something like C:\Users\Username:
                            string userRoot = System.Environment.GetEnvironmentVariable("USERPROFILE");
                            // Now let's get C:\Users\Username\Downloads:
                            string downloadFolder = Path.Combine(userRoot, "Downloads");
                            string ExcelFolderPath = downloadFolder + "\\Department wise Issued Report\\";
                            string FileFullPath = ExcelFolderPath + "Department wise Issued " + dtpFromDate.Text + " to " + dptToDate.Text + "" + DateTime.Now.ToString(" hh/mm/ss");
                            if (!Directory.Exists(ExcelFolderPath))
                                Directory.CreateDirectory(ExcelFolderPath);

                            workbook.SaveAs(FileFullPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                            Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                            worksheet = workbook.Sheets["Sheet1"];
                            worksheet = workbook.ActiveSheet;
                            worksheet.Name = "Issued Report";
                            object misValue = System.Reflection.Missing.Value;
                            worksheet.Cells[1, 1] = Global.sCompanyName; //i++;       
                            CellMerge("Merge", workbook.ActiveSheet, 1, 1, 1, 3);
                            worksheet.Cells[2, 1] = "Department wise Issued Report";// i++;
                            CellMerge("Merge", workbook.ActiveSheet, 2, 2, 1, 3);
                            worksheet.Cells[3, 1] = "Dated From : " + dtpFromDate.Text + "  To : " + dptToDate.Text + "";// i++; i++;
                            CellMerge("Merge", workbook.ActiveSheet, 3, 3, 1, 3);
                            worksheet.Range["A1:C1"].Cells.Font.Size = 16;
                            worksheet.Range["A1:C1"].Cells.Font.Bold = 16;
                            worksheet.Range["A2:C2"].Cells.Font.Size = 14;
                            worksheet.Range["A2:C2"].Cells.Font.Bold = 14;
                            worksheet.Range["A3:C3"].Cells.Font.Size = 12;
                            worksheet.Range["A3:C3"].Cells.Font.Bold = 12;

                            int im2 = 0;
                            foreach (DataRow dr in dtissued.Rows)
                            {
                                im2++;
                                DataTable dtIssuedConsolidated = new DataTable();
                                dtIssuedConsolidated = DAL.fnIssuedListDepartmentwise(dr[0].ToString(), dtpFromDate.Text, dptToDate.Text).Tables[0];
                                if (dtIssuedConsolidated.Rows.Count > 0)
                                {
                                    CellMerge("Merge", workbook.ActiveSheet, j, j, 1, 2);
                                    CellMerge("Merge", workbook.ActiveSheet, j, j, 3, 7);
                                    CellMerge("Merge", workbook.ActiveSheet, j, j, 9, 12);
                                    if (!string.IsNullOrEmpty(dr[0].ToString()))
                                    {
                                        worksheet.Cells[j, 1] = dr[0].ToString();

                                    }
                                    else
                                    {
                                        string sDept = "Non Department Issued";
                                        worksheet.Cells[j, 1] = sDept;
                                    }

                                    ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Bold = true;
                                    ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Size = 14;
                                    ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Color = Color.Red;
                                    ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j + 1, Type.Missing]).Font.Bold = true;
                                    ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j + 1, Type.Missing]).Font.Color = Color.Blue;
                                    object[,] rawData = new object[dtIssuedConsolidated.Rows.Count + 1, dtIssuedConsolidated.Columns.Count];
                                    for (int col = 0; col < dtIssuedConsolidated.Columns.Count; col++)
                                    {
                                        rawData[0, col] = dtIssuedConsolidated.Columns[col].ColumnName;
                                    }
                                    if (dtIssuedConsolidated.Rows.Count > 0)
                                    {
                                        for (int row = 0; row < dtIssuedConsolidated.Rows.Count; row++)
                                        {
                                            for (int col = 0; col < dtIssuedConsolidated.Columns.Count; col++)
                                            {
                                                rawData[row + 1, col] = dtIssuedConsolidated.Rows[row].ItemArray[col];
                                            }
                                        }
                                        string excelRange = string.Empty;
                                        if (IsFirsttime)
                                        {
                                            finalColLetter = string.Empty;
                                            string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                                            int colCharsetLen = colCharset.Length;

                                            if (dtIssuedConsolidated.Columns.Count > colCharsetLen)
                                            {
                                                finalColLetter = colCharset.Substring(
                                                    (dtIssuedConsolidated.Columns.Count - 1) / colCharsetLen - 1, 1);
                                            }

                                            finalColLetter += colCharset.Substring(
                                                    (dtIssuedConsolidated.Columns.Count - 1) % colCharsetLen, 1);
                                            excelRange = string.Format("A8:{0}{1}", finalColLetter, dtIssuedConsolidated.Rows.Count + j + 1);
                                            IsFirsttime = false;
                                            j++;
                                        }
                                        else
                                        {
                                            j += 1;
                                            excelRange = string.Format("A" + j + ":{0}{1}", finalColLetter, dtIssuedConsolidated.Rows.Count + j);
                                        }

                                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                                    }
                                    j = j + (dtIssuedConsolidated.Rows.Count + 1);

                                    worksheet.Cells[j, 12] = "Sub Total:";
                                    if (dtIssuedConsolidated.Rows.Count > 0)
                                    {
                                        worksheet.Cells[j, 13] = dtIssuedConsolidated.Compute("Sum(Amount)", "").ToString();
                                        dGrandSum = dGrandSum + Convert.ToDouble(dtIssuedConsolidated.Compute("Sum(Amount)", "").ToString());
                                    }
                                    ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Color = Color.Blue;
                                    ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Bold = true;
                                }
                                j++;
                                dtIssuedConsolidated.Rows.Clear();
                            }
                            j++;
                            worksheet.Cells[5, 1] = "Grand Total:";
                            worksheet.Cells[5, 2] = dGrandSum.ToString();
                            worksheet.Range["A5:B6"].Cells.Font.Size = 14;
                            worksheet.Range["A5:B6"].Cells.Font.Bold = 14;
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Color = Color.Red;
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Bold = true;
                            CellMerge("Merge", workbook.ActiveSheet, 1, 1, 1, 3);
                            worksheet.get_Range("C6", "C99999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                            worksheet.Rows.RowHeight = "18";
                            worksheet.Columns[1].ColumnWidth = 18;
                            worksheet.Columns[6].ColumnWidth = 12;
                            worksheet.Columns[1].WrapText = true;
                            worksheet.Columns[6].WrapText = true;
                            worksheet.Columns[2].ColumnWidth = 18;
                            worksheet.Columns[7].ColumnWidth = 12;
                            worksheet.Columns[2].WrapText = true;
                            worksheet.Columns[7].WrapText = true;
                            worksheet.Columns[3].ColumnWidth = 50;
                            worksheet.Columns[3].WrapText = true;
                            worksheet.Columns[4].ColumnWidth = 14;
                            worksheet.Columns[5].ColumnWidth = 10;
                            worksheet.Columns[6].ColumnWidth = 11;
                            worksheet.Columns[7].ColumnWidth = 12;
                            worksheet.Columns[8].ColumnWidth = 11;
                            worksheet.Columns[8].WrapText = true;
                            worksheet.Columns[9].ColumnWidth = 8;
                            worksheet.Columns[10].ColumnWidth = 10;
                            worksheet.Columns[11].ColumnWidth = 10;
                            worksheet.Columns[12].ColumnWidth = 13;
                            worksheet.Columns[12].WrapText = true;
                            worksheet.Columns[13].ColumnWidth = 13;
                            worksheet.Columns[13].WrapText = true;

                            fnDateFormatstring(worksheet, "F9", "F99999");
                            fnDateFormatstring(worksheet, "H9", "H99999");
                            fnNumberFormatstring(worksheet, "A5", "A99999");
                            fnNumberFormatstring(worksheet, "I6", "M99999");
                            fnNumberFormatstring(worksheet, "P1", "T9999");
                            fnExcelPrint(worksheet, "A1:O" + (j + 5) + "");
                            fnDrawLogo(worksheet, 1, 6);

                            workbook.Save();
                            workbook.Close(true, misValue, misValue);
                            excelapp.Quit();
                            releaseObject(worksheet);
                            releaseObject(workbook);
                            releaseObject(excelapp);

                            if (Directory.Exists(ExcelFolderPath))
                            {
                                Process.Start(ExcelFolderPath);
                            }
                        }
                        else
                        { MessageBox.Show("Selected date has no records to genarate report!"); }
                    }
                    break;
                #endregion
                #region Departmentwise PO Report
                case "DepartmentWise PO/WO":
                    {

                        dtReciept = DAL.GINDepartmentWiseReport(0, dtpFromDate.Text, dptToDate.Text).Tables[0];

                        if (dtReciept.Rows.Count > 0)
                        {
                            CreateExcelSheet();
                        }
                        else
                        {
                            MessageBox.Show("Selected date has no records to genarate report!");
                        }

                        // DataTable ConsolidatedGINPOReport = new DataTable();
                        // List<string> listSupplierName = new List<string>();
                        //ConsolidatedGINPOReport = 
                        // int j = 6;
                        // bool bFirsttime = true;
                        // //if (ConsolidatedGINPOReport.Rows.Count > 0)
                        // //{
                        //     //foreach (DataRow dr in ConsolidatedGINPOReport.Rows)
                        //     //{
                        //     //    if (!listSupplierName.Contains(dr["Department"].ToString()))
                        //     //    {
                        //     //        listSupplierName.Add(dr["Department"].ToString());
                        //     //    }
                        //     //}
                        //     excelapp = new Microsoft.Office.Interop.Excel.Application();
                        //     workbook = excelapp.Workbooks.Add(Type.Missing);
                        //     // This returns something like C:\Users\Username:
                        //     string userRoot = System.Environment.GetEnvironmentVariable("USERPROFILE");
                        //     // Now let's get C:\Users\Username\Downloads:
                        //     string downloadFolder = Path.Combine(userRoot, "Downloads");
                        //     string ExcelFolderPath = downloadFolder + "\\Department wise GIN PO Report\\";
                        //     string FileFullPath = ExcelFolderPath + "Department wise GIN PO Report " + dtpFromDate.Text + " to " + dptToDate.Text + "";
                        //     if (!Directory.Exists(ExcelFolderPath))
                        //         Directory.CreateDirectory(ExcelFolderPath);

                        //     workbook.SaveAs(FileFullPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                        //     Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        //     worksheet = workbook.Sheets["Sheet1"];
                        //     worksheet = workbook.ActiveSheet;
                        //     worksheet.Name = "Department GIN PO Report";
                        //     object misValue = System.Reflection.Missing.Value;

                        //     worksheet.Cells[1, 1] = Global.sCompanyName;
                        //     worksheet.Cells[2, 1] = "Department GIN PO Report";
                        //     worksheet.Cells[3, 1] = "Date";
                        //     worksheet.Cells[3, 2] = DateTime.Today.ToString("dd-MM-yyyy");
                        //     worksheet.Range["A1:C1"].Cells.Font.Size = 16;
                        //     worksheet.Range["A1:C1"].Cells.Font.Bold = 16;
                        //     worksheet.Range["A2:C2"].Cells.Font.Size = 14;
                        //     worksheet.Range["A2:C2"].Cells.Font.Bold = 14;
                        //     worksheet.Range["A3:C3"].Cells.Font.Size = 12;
                        //     worksheet.Range["A3:C3"].Cells.Font.Bold = 12;
                        //     worksheet.Range["A3:C4"].Cells.Font.Size = 12;
                        //     worksheet.Range["A3:C4"].Cells.Font.Bold = 12;
                        //     DataTable dtGINPODetails = new DataTable();
                        //     bool IsFirsttime = true;
                        //     string finalColLetter = string.Empty;
                        //     bool bvendorname = true;
                        //     double dNetAmount = 0.0;

                        //     //foreach (string dr in listSupplierName)
                        //     //{
                        //         //bvendorname = false;
                        //         //DataTable dtGINReport = new DataTable();
                        //         //dtGINReport = DAL.GINDepartmentWiseReport(dr.ToString(), null, dtpFromDate.Text, dptToDate.Text).Tables[0];
                        //         //if (dtGINReport.Rows.Count > 0)
                        //         //{
                        //             //List<string> listPO = new List<string>();
                        //             //foreach (DataRow dr1 in dtGINReport.Rows)
                        //             //{
                        //             //    if (!listPO.Contains(dr1["GINNumber"].ToString()))
                        //             //    {
                        //             //        listPO.Add(dr1["GINNumber"].ToString());
                        //             //    }
                        //             //}
                        //           //  if (listPO.Count > 0)
                        //           //  {
                        //                 //foreach (string dr2 in listPO)
                        //                // {
                        //                     dtGINPODetails = DAL.GINDepartmentWiseReport(null, dr2.ToString(), dtpFromDate.Text, dptToDate.Text).Tables[0];

                        //                     DataRow dr1 = dtGINPODetails.Rows[0];
                        //                     DataTable dtTax = new DataTable();
                        //                     dtTax = DAL.fnGINTaxDetailsReport(dtGINPODetails.Rows[0]["PO Number"].ToString(), null).Tables[0];
                        //                     DataTable dtPOQty = new DataTable();
                        //                     double sTotalQTY = 0;
                        //                     dtPOQty = DAL.fnPOQty(dtGINPODetails.Rows[0]["PO Number"].ToString()).Tables[0];
                        //                     sTotalQTY = Convert.ToDouble(dtPOQty.Compute("Sum(TotalQty)", "").ToString());

                        //                     dr1["Total Amount:"] = dtGINPODetails.Compute("Sum(Amount)", "").ToString();

                        //                     double sGINQTY = 0;
                        //                     sGINQTY = Convert.ToDouble(dtGINPODetails.Compute("Sum(Quantity)", "").ToString());
                        //                     if (dtTax.Rows.Count > 0)
                        //                     {
                        //                         dBasicnPacking = (((Convert.ToDouble(dtTax.Rows[0]["PackingForwording"].ToString())) / sTotalQTY) * sGINQTY);

                        //                         dBasicnPacking = ((dBasicnPacking) + Convert.ToDouble(dtGINPODetails.Compute("Sum(Amount)", "").ToString()));

                        //                         if (!string.IsNullOrEmpty(dtTax.Rows[0]["Discount_per"].ToString()))// != null)
                        //                         {
                        //                             dDiscount = (((Convert.ToDouble(dtTax.Rows[0]["Discount_per"].ToString().Trim('%'))) / 100) * dBasicnPacking);
                        //                         }
                        //                         else
                        //                         {
                        //                             dDiscount = 0;
                        //                         }
                        //                         dAfterdiscount = dBasicnPacking - dDiscount;

                        //                         if (!string.IsNullOrEmpty(dtTax.Rows[0]["ExciseDuty_per"].ToString()))// != null)
                        //                         {
                        //                             dExcise = (((Convert.ToDouble(dtTax.Rows[0]["ExciseDuty_per"].ToString().Trim('%'))) / 100) * dAfterdiscount);
                        //                         }
                        //                         else
                        //                         {
                        //                             dExcise = 0;
                        //                         }
                        //                         dAfterExcise = dExcise + dAfterdiscount;
                        //                         if (!string.IsNullOrEmpty(dtTax.Rows[0]["VATServiceTax_per"].ToString()))// != null)
                        //                         {
                        //                             dVat = (((Convert.ToDouble(dtTax.Rows[0]["VATServiceTax_per"].ToString().Trim('%'))) / 100) * dAfterExcise);
                        //                         }
                        //                         else
                        //                         {
                        //                             dVat = 0;
                        //                         }
                        //                         if (!string.IsNullOrEmpty(dtTax.Rows[0]["CST_per"].ToString()))// != null)
                        //                         {
                        //                             dCST = (((Convert.ToDouble(dtTax.Rows[0]["CST_per"].ToString().Trim('%'))) / 100) * dAfterExcise);
                        //                         }
                        //                         else
                        //                         {
                        //                             dCST = 0;
                        //                         }

                        //                         dTotal = dAfterExcise + dVat + dCST + (((Convert.ToDouble(dtTax.Rows[0]["Others"].ToString())) / sTotalQTY) * sGINQTY);

                        //                         dr1["Tax Amount:"] = (((Convert.ToDouble(dtTax.Rows[0]["PackingForwording"].ToString())) / sTotalQTY) * sGINQTY) + dExcise + dVat + dCST + (((Convert.ToDouble(dtTax.Rows[0]["Others"].ToString())) / sTotalQTY) * sGINQTY);
                        //                         dr1["Grand Total:"] = dTotal;
                        //                         dNetAmount = dNetAmount + dTotal;
                        //                         dr1["Excise Amount:"] = dExcise;
                        //                         dr1["Vat Amount:"] = dVat;
                        //                     }
                        //                     else
                        //                     {
                        //                         dr1["Grand Total:"] = Convert.ToDouble(dtGINPODetails.Compute("Sum(Amount)", "").ToString());
                        //                         dNetAmount = dNetAmount + Convert.ToDouble(dtGINPODetails.Compute("Sum(Amount)", "").ToString());
                        //                     }
                        //                     if (bvendorname == false)
                        //                     {
                        //                         if (!string.IsNullOrEmpty(dr.ToString()))
                        //                         {
                        //                             worksheet.Cells[j, 1] = dr.ToString();
                        //                         }
                        //                         else
                        //                         {
                        //                             string sDept = "Non Department PO";
                        //                             worksheet.Cells[j, 1] = sDept;
                        //                         }
                        //                         CellMerge("Merge", workbook.ActiveSheet, j, j, 1, 5);

                        //                         bFirsttime = true;
                        //                         worksheet.Cells[j + 1, 1] = "PO Number";
                        //                         worksheet.Cells[j + 1, 2] = "Project Code";
                        //                         worksheet.Cells[j + 1, 3] = "Project Name";
                        //                         worksheet.Cells[j + 1, 4] = "Customer";
                        //                         worksheet.Cells[j + 1, 5] = "GINNumber";
                        //                         worksheet.Cells[j + 1, 6] = "Invoice Number";
                        //                         worksheet.Cells[j + 1, 7] = "GIN Date";
                        //                         worksheet.Cells[j + 1, 8] = "Item Code";
                        //                         worksheet.Cells[j + 1, 9] = "Item Description";
                        //                         worksheet.Cells[j + 1, 10] = "Quantity";
                        //                         worksheet.Cells[j + 1, 11] = "Unit Cost";
                        //                         worksheet.Cells[j + 1, 12] = "Amount";
                        //                         worksheet.Cells[j + 1, 13] = "Total Amount:";
                        //                         worksheet.Cells[j + 1, 14] = "Tax Amount:";
                        //                         worksheet.Cells[j + 1, 15] = "Excise Amount:";
                        //                         worksheet.Cells[j + 1, 16] = "Vat Amount:";
                        //                         worksheet.Cells[j + 1, 17] = "Grand Total:";
                        //                         worksheet.Cells[j + 1, 18] = "DeliveryMonitor";
                        //                         ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Color = Color.Red;
                        //                         ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Bold = true;
                        //                         ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Size = 14;
                        //                         ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j + 1, Type.Missing]).Font.Bold = true;
                        //                         ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j + 1, Type.Missing]).Font.Color = Color.Blue;
                        //                         ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j + 1, Type.Missing]).Font.Bold = true;
                        //                     }
                        //                     else
                        //                     {
                        //                         bFirsttime = false;
                        //                     }

                        //                     object[,] rawData = new object[dtGINPODetails.Rows.Count, dtGINPODetails.Columns.Count];//one line project code next line column header


                        //                     for (int row = 0; row < dtGINPODetails.Rows.Count; row++)
                        //                     {
                        //                         for (int col = 0; col < dtGINPODetails.Columns.Count; col++)
                        //                         {
                        //                             rawData[row, col] = dtGINPODetails.Rows[row].ItemArray[col];
                        //                         }
                        //                     }
                        //                     string excelRange = string.Empty;
                        //                     if (IsFirsttime)
                        //                     {

                        //                         finalColLetter = string.Empty;
                        //                         string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        //                         int colCharsetLen = colCharset.Length;

                        //                         if (dtGINPODetails.Columns.Count > colCharsetLen)
                        //                         {
                        //                             finalColLetter = colCharset.Substring(
                        //                                 (dtGINPODetails.Columns.Count - 1) / colCharsetLen - 1, 1);
                        //                         }
                        //                         j = 8;
                        //                         finalColLetter += colCharset.Substring(
                        //                                 (dtGINPODetails.Columns.Count - 1) % colCharsetLen, 1);
                        //                         excelRange = string.Format("A8:{0}{1}", finalColLetter, dtGINPODetails.Rows.Count + (j - 1));
                        //                         IsFirsttime = false;
                        //                     }
                        //                     else
                        //                     {
                        //                         if (bFirsttime)
                        //                         {
                        //                             j = j + 2;
                        //                             bFirsttime = false;
                        //                         }
                        //                         excelRange = string.Format("A" + j + ":{0}{1}", finalColLetter, dtGINPODetails.Rows.Count + (j - 1));
                        //                     }

                        //                     worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;

                        //                     j = j + (dtGINPODetails.Rows.Count);
                        //                     bvendorname = true;
                        //                // }
                        //             //}
                        //        // }

                        //         j++;
                        //         dtGINPODetails.Rows.Clear();
                        //    // }
                        //     worksheet.Cells[4, 1] = "Net Amount:";
                        //     worksheet.Cells[4, 2] = dNetAmount.ToString();
                        //     ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[4, Type.Missing]).Font.Color = Color.Blue;
                        //     ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[4, Type.Missing]).Font.Bold = true;

                        //     worksheet.Columns.AutoFit();
                        //     worksheet.Rows.AutoFit();
                        //     worksheet.Columns[9].ColumnWidth = 50;
                        //     worksheet.Columns[3].WrapText = true;
                        //     worksheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        //     Microsoft.Office.Interop.Excel.Range Range = worksheet.get_Range("J6", "Q99999");
                        //     Range.EntireColumn.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;

                        //     worksheet.Rows.RowHeight = "18";

                        //     fnDateFormat(worksheet, 1, 5);
                        //     fnDateFormatstring(worksheet, "G1", "G99999");
                        //     fnNumberFormatstring(worksheet, "J6", "Q99999");
                        //     fnExcelPrint(worksheet, "A1:O" + j + "");
                        //     fnDrawLogo(worksheet, 1, 6);

                        //     workbook.Save();
                        //     workbook.Close(true, misValue, misValue);
                        //     excelapp.Quit();
                        //     releaseObject(worksheet);
                        //     releaseObject(workbook);
                        //     releaseObject(excelapp);

                        //     if (Directory.Exists(ExcelFolderPath))
                        //     {
                        //         Process.Start(ExcelFolderPath);
                        //     }
                        //     Cursor.Current = Cursors.Default;

                        // //}
                        // //else
                        // //{

                        // //}

                    }
                    break;
                #endregion
                #region Departmentwise WO Report
                //case "DepartmentWise WO":
                //    {
                //        FinalSum = 0.0;
                //        DataTable dtissued = new DataTable();
                //        List<string> listSupplierName = new List<string>();
                //        dtissued = DAL.DepartmentwiseGINWOReport(null, null, dtpFromDate.Text, dptToDate.Text).Tables[0];
                //        if (dtissued.Rows.Count > 0)
                //        {
                //            foreach (DataRow dr in dtissued.Rows)
                //            {
                //                if (!listSupplierName.Contains(dr["Department"].ToString()))
                //                {
                //                    listSupplierName.Add(dr["Department"].ToString());
                //                }
                //            }

                //            excelapp = new Microsoft.Office.Interop.Excel.Application();
                //            workbook = excelapp.Workbooks.Add(Type.Missing);
                //            // This returns something like C:\Users\Username:
                //            string userRoot = System.Environment.GetEnvironmentVariable("USERPROFILE");
                //            // Now let's get C:\Users\Username\Downloads:
                //            string downloadFolder = Path.Combine(userRoot, "Downloads");

                //            string ExcelFolderPath = downloadFolder + "\\Department wise GIN WO Report\\";
                //            string FileFullPath = ExcelFolderPath + "Department wise GIN WO Report " + dtpFromDate.Text + " to " + dptToDate.Text + "" + DateTime.Now.ToString(" hh/mm/ss");
                //            if (!Directory.Exists(ExcelFolderPath))
                //                Directory.CreateDirectory(ExcelFolderPath);

                //            workbook.SaveAs(FileFullPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                //            Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                //            worksheet = workbook.Sheets["Sheet1"];
                //            worksheet = workbook.ActiveSheet;
                //            worksheet.Name = "DepartmentWise GIN WO Report";
                //            object misValue = System.Reflection.Missing.Value;
                //            worksheet.Cells[1, 1] = Global.sCompanyName;
                //            CellMerge("Merge", workbook.ActiveSheet, 1, 1, 1, 3);
                //            worksheet.Cells[2, 1] = "DepartmentWise GIN WO Report";
                //            CellMerge("Merge", workbook.ActiveSheet, 2, 2, 1, 3);
                //            worksheet.Range["A1:C1"].Cells.Font.Size = 16;
                //            worksheet.Range["A1:C1"].Cells.Font.Bold = 16;
                //            worksheet.Range["A2:C2"].Cells.Font.Size = 14;
                //            worksheet.Range["A2:C2"].Cells.Font.Bold = 14;
                //            worksheet.Range["A3:C3"].Cells.Font.Size = 12;
                //            worksheet.Range["A3:C3"].Cells.Font.Bold = 12;
                //            worksheet.Range["A3:C4"].Cells.Font.Size = 12;
                //            worksheet.Range["A3:C4"].Cells.Font.Bold = 12;
                //            int i = 0;
                //            foreach (string dr in listSupplierName)
                //            {
                //                DataTable dtWOGIN = new DataTable();
                //                dtWOGIN = DAL.DepartmentwiseGINWOReport(dr.ToString(), null, dtpFromDate.Text, dptToDate.Text).Tables[0];
                //                if (dtWOGIN.Rows.Count > 0)
                //                {
                //                    if (!string.IsNullOrEmpty(dr.ToString()))
                //                    {
                //                        worksheet.Cells[i + 5, 1] = dr.ToString();
                //                    }
                //                    else
                //                    {
                //                        string sDept = "Non Department WO";
                //                        worksheet.Cells[i + 5, 1] = sDept;
                //                    }
                //                    worksheet.Cells[i + 5, 1].Font.Size = 16;
                //                    CellMerge("Merge", workbook.ActiveSheet, i + 5, i + 5, 1, 3);
                //                    worksheet.Cells[3, 1] = "Date";

                //                    List<string> listPO = new List<string>();
                //                    foreach (DataRow dr1 in dtWOGIN.Rows)
                //                    {
                //                        if (!listPO.Contains(dr1["GINNumber"].ToString()))
                //                        {
                //                            listPO.Add(dr1["GINNumber"].ToString());
                //                        }
                //                    }
                //                    if (listPO.Count > 0)
                //                    {
                //                        foreach (string dr2 in listPO)
                //                        {
                //                            DataTable dtWOGINIndiviual = new DataTable();
                //                            dtWOGINIndiviual = DAL.DepartmentwiseGINWOReport(null, dr2.ToString(), dtpFromDate.Text, dptToDate.Text).Tables[0];
                //                            if (dtWOGINIndiviual.Rows.Count > 0)
                //                            {
                //                                DataTable dtTax = new DataTable();
                //                                string name = "DepartmentWise GIN WO Report";
                //                                dtTax = DAL.GINTax(dr2.ToString(), name).Tables[0];

                //                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 5, Type.Missing]).Font.Color = Color.Red;
                //                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 5, Type.Missing]).Font.Bold = true;
                //                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 6, Type.Missing]).Font.Color = Color.Blue;
                //                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 6, Type.Missing]).Font.Bold = true;

                //                                // ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 6, Type.Missing]).Font.Color = Color.Blue;

                //                                string[] sColumnNames = new string[] { "WONo", "Item Code", "Item Discription", "GINNumber", "Date", "SupplierInvoiceNumber", "Quantity", "UnitCost", "Amount" };
                //                                int icolumn = 1;
                //                                for (int p = 0; p < sColumnNames.Length; p++)
                //                                {
                //                                    worksheet.Cells[i + 6, icolumn] = sColumnNames[p];
                //                                    icolumn++;
                //                                }

                //                                if (dtWOGINIndiviual.Rows.Count > 0)
                //                                {

                //                                    for (int iCountRow = 0; iCountRow < (dtWOGINIndiviual.Rows.Count); iCountRow++)
                //                                    {
                //                                        i++;
                //                                        worksheet.Rows.AutoFit();
                //                                        for (int j = 0; j < dtWOGINIndiviual.Columns.Count; j++)
                //                                        {
                //                                            worksheet.Columns.AutoFit();
                //                                            worksheet.Cells[i + 6, j + 1] = dtWOGINIndiviual.Rows[iCountRow][j].ToString();
                //                                        }
                //                                    }

                //                                }
                //                                i++;
                //                                worksheet.Cells[i + 6, 8] = "Grand Total:";
                //                                worksheet.Cells[i + 6, 9] = dtWOGINIndiviual.Compute("Sum(Amount)", "").ToString();

                //                                if (dtTax.Rows.Count > 0)
                //                                {
                //                                    double sTotalQTY = 0;
                //                                    DataTable dtWOQTY = new DataTable();
                //                                    dtWOQTY = DAL.fnWOQty(dtWOGINIndiviual.Rows[0]["RefNumber"].ToString()).Tables[0];
                //                                    sTotalQTY = Convert.ToDouble(dtWOQTY.Compute("Sum(TotalQty)", "").ToString());

                //                                    double sGINQTY = 0;
                //                                    sGINQTY = Convert.ToDouble(dtWOGINIndiviual.Compute("Sum(Quantity)", "").ToString());

                //                                    dBasicnPacking = (((Convert.ToDouble(dtTax.Rows[0]["PackingForwording"].ToString())) / sTotalQTY) * sGINQTY);

                //                                    dBasicnPacking = ((dBasicnPacking) + Convert.ToDouble(dtWOGINIndiviual.Compute("Sum(Amount)", "").ToString()));

                //                                    dDiscount = (((Convert.ToDouble(dtTax.Rows[0]["Discount_per"].ToString().Trim('%'))) / 100) * dBasicnPacking);

                //                                    dAfterdiscount = dBasicnPacking - dDiscount;

                //                                    dExcise = (((Convert.ToDouble(dtTax.Rows[0]["ExciseDuty_per"].ToString().Trim('%'))) / 100) * dAfterdiscount);

                //                                    dAfterExcise = dExcise + dAfterdiscount;

                //                                    dVat = (((Convert.ToDouble(dtTax.Rows[0]["VATServiceTax_per"].ToString().Trim('%'))) / 100) * dAfterExcise);

                //                                    dCST = (((Convert.ToDouble(dtTax.Rows[0]["CST_per"].ToString().Trim('%'))) / 100) * dAfterExcise);

                //                                    dTotal = dAfterExcise + dVat + dCST + (((Convert.ToDouble(dtTax.Rows[0]["Others"].ToString())) / sTotalQTY) * sGINQTY);


                //                                    worksheet.Cells[i + 7, 8] = "Tax Amount:";
                //                                    worksheet.Cells[i + 7, 9] = (((Convert.ToDouble(dtTax.Rows[0]["PackingForwording"].ToString())) / sTotalQTY) * sGINQTY) + dExcise + dVat + dCST + (((Convert.ToDouble(dtTax.Rows[0]["Others"].ToString())) / sTotalQTY) * sGINQTY);
                //                                    worksheet.Cells[i + 8, 8] = "Final Amount:";
                //                                    worksheet.Cells[i + 8, 9] = dTotal;
                //                                    FinalSum = FinalSum + dTotal;
                //                                }
                //                                else
                //                                {
                //                                    worksheet.Cells[i + 7, 8] = "Tax Amount:";
                //                                    worksheet.Cells[i + 7, 9] = "0";
                //                                    worksheet.Cells[i + 8, 8] = "Final Amount:";
                //                                    worksheet.Cells[i + 8, 9] = Convert.ToDouble(dtWOGINIndiviual.Compute("Sum(Amount)", "").ToString());
                //                                    FinalSum = FinalSum + Convert.ToDouble(dtWOGINIndiviual.Compute("Sum(Amount)", "").ToString());
                //                                }
                //                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 6, Type.Missing]).Font.Bold = true;
                //                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 6, Type.Missing]).Font.Color = Color.Blue;
                //                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 7, Type.Missing]).Font.Bold = true;
                //                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 7, Type.Missing]).Font.Color = Color.Blue;
                //                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 8, Type.Missing]).Font.Bold = true;
                //                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 8, Type.Missing]).Font.Color = Color.Red;
                //                                i += 4;
                //                            }
                //                        }
                //                    }
                //                }
                //            }

                //            worksheet.Cells[i + 6, 8] = "Total NetAmount:";
                //            worksheet.Cells[i + 6, 9] = FinalSum.ToString();
                //            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 6, Type.Missing]).Font.Color = Color.Red;
                //            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 6, Type.Missing]).Font.Bold = true;

                //            worksheet.Cells[3, 1] = "Total NetAmount:";
                //            worksheet.Cells[3, 2] = FinalSum.ToString();
                //            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[3, Type.Missing]).Font.Color = Color.Red;
                //            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[3, Type.Missing]).Font.Bold = true;

                //            worksheet.Columns.AutoFit();
                //            worksheet.Rows.AutoFit();
                //            worksheet.get_Range("C6", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                //            worksheet.Columns[3].ColumnWidth = 50;
                //            worksheet.Columns[3].WrapText = true;
                //            worksheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                //            worksheet.Rows.RowHeight = "18";
                //            Microsoft.Office.Interop.Excel.Range Range = worksheet.get_Range("G6", "I99999");
                //            Range.EntireColumn.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                //            fnDateFormatstring(worksheet, "E7", "E9999");
                //            fnNumberFormatstring(worksheet, "G6", "I9999");
                //            fnExcelPrint(worksheet, "A1:O" + (i + 6) + "");
                //            fnDrawLogo(worksheet, 1, 6);

                //            workbook.Save();
                //            workbook.Close(true, misValue, misValue);
                //            excelapp.Quit();
                //            releaseObject(worksheet);
                //            releaseObject(workbook);
                //            releaseObject(excelapp);

                //            if (Directory.Exists(ExcelFolderPath))
                //            {
                //                Process.Start(ExcelFolderPath);
                //            }
                //            Cursor.Current = Cursors.Default;
                //        }
                //        else
                //        {
                //            MessageBox.Show("Selected date has no records to genarate report!");
                //        }
                //    }
                //    break;
                #endregion
                #region No of POs Placed
                case "No of PO's Placed":
                    {
                        DataTable ConsolidatedGINPOReport = new DataTable();
                        List<string> listSupplierName = new List<string>();
                        ConsolidatedGINPOReport = DAL.GINCompletedPO(null, null, dtpFromDate.Text, dptToDate.Text).Tables[0];
                        int j = 6;
                        bool bFirsttime = true;
                        if (ConsolidatedGINPOReport.Rows.Count > 0)
                        {
                            foreach (DataRow dr in ConsolidatedGINPOReport.Rows)
                            {
                                if (!listSupplierName.Contains(dr["VendorName"].ToString()))
                                {
                                    listSupplierName.Add(dr["VendorName"].ToString());
                                }
                            }
                            excelapp = new Microsoft.Office.Interop.Excel.Application();
                            workbook = excelapp.Workbooks.Add(Type.Missing);
                            // This returns something like C:\Users\Username:
                            string userRoot = System.Environment.GetEnvironmentVariable("USERPROFILE");
                            // Now let's get C:\Users\Username\Downloads:
                            string downloadFolder = Path.Combine(userRoot, "Downloads");
                            string ExcelFolderPath = downloadFolder + "\\No of POs placed\\";
                            string FileFullPath = ExcelFolderPath + "No of POs " + dtpFromDate.Text + " to " + dptToDate.Text + "" + DateTime.Now.ToString(" hh/mm/ss");
                            if (!Directory.Exists(ExcelFolderPath))
                                Directory.CreateDirectory(ExcelFolderPath);

                            workbook.SaveAs(FileFullPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                            Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                            worksheet = workbook.Sheets["Sheet1"];
                            worksheet = workbook.ActiveSheet;
                            worksheet.Name = "No of POs placed";
                            object misValue = System.Reflection.Missing.Value;

                            worksheet.Cells[1, 1] = Global.sCompanyName;
                            worksheet.Cells[2, 1] = "GIN Report";
                            worksheet.Cells[3, 1] = "Date";
                            worksheet.Cells[3, 2] = DateTime.Today.ToString("dd-MM-yyyy");
                            worksheet.Range["A1:C1"].Cells.Font.Size = 16;
                            worksheet.Range["A1:C1"].Cells.Font.Bold = 16;
                            worksheet.Range["A2:C2"].Cells.Font.Size = 14;
                            worksheet.Range["A2:C2"].Cells.Font.Bold = 14;
                            worksheet.Range["A3:C3"].Cells.Font.Size = 12;
                            worksheet.Range["A3:C3"].Cells.Font.Bold = 12;
                            worksheet.Range["A3:C4"].Cells.Font.Size = 12;
                            worksheet.Range["A3:C4"].Cells.Font.Bold = 12;
                            // EXCEL.Worksheet NewWorkSheet;
                            DataTable dtGINPODetails = new DataTable();
                            bool IsFirsttime = true;
                            string finalColLetter = string.Empty;
                            bool bvendorname = true;

                            foreach (string dr in listSupplierName)
                            {
                                bvendorname = false;
                                DataTable dtGINReport = new DataTable();
                                dtGINReport = DAL.GINCompletedPO(dr.ToString(), null, dtpFromDate.Text, dptToDate.Text).Tables[0];
                                if (dtGINReport.Rows.Count > 0)
                                {
                                    List<string> listPO = new List<string>();
                                    foreach (DataRow dr1 in dtGINReport.Rows)
                                    {
                                        if (!listPO.Contains(dr1["DBOMNo"].ToString()))
                                        {
                                            listPO.Add(dr1["DBOMNo"].ToString());
                                        }
                                    }
                                    if (listPO.Count > 0)
                                    {
                                        foreach (string dr2 in listPO)
                                        {
                                            dtGINPODetails = DAL.GINCompletedPO(null, dr2.ToString(), dtpFromDate.Text, dptToDate.Text).Tables[0];

                                            if (bvendorname == false)
                                            {
                                                worksheet.Cells[j, 1] = dr.ToString();
                                                CellMerge("Merge", workbook.ActiveSheet, j, j, 1, 5);
                                                bFirsttime = true;
                                                worksheet.Cells[j + 1, 1] = "PO Number";
                                                worksheet.Cells[j + 1, 2] = "Project Code";
                                                worksheet.Cells[j + 1, 3] = "Project Name";
                                                worksheet.Cells[j + 1, 4] = "Customer";
                                                worksheet.Cells[j + 1, 5] = "PO By";
                                                worksheet.Cells[j + 1, 6] = "PO Authorised By";
                                                worksheet.Cells[j + 1, 7] = "PO Genarated Date";
                                                worksheet.Cells[j + 1, 8] = "Item Code";
                                                worksheet.Cells[j + 1, 9] = "Item Description";
                                                worksheet.Cells[j + 1, 10] = "UOM";
                                                worksheet.Cells[j + 1, 11] = "Quantity";
                                                worksheet.Cells[j + 1, 12] = "Unit Price"; worksheet.Cells[j + 1, 13] = "Amount"; //[POGeneratedBy],P.[Remarks]
                                                worksheet.Cells[j + 1, 14] = "POGeneratedBy"; worksheet.Cells[j + 1, 15] = "Remarks"; //[],P.[]
                                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Color = Color.Red;
                                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Bold = true;
                                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Size = 14;
                                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j + 1, Type.Missing]).Font.Bold = true;
                                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j + 1, Type.Missing]).Font.Color = Color.Blue;
                                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j + 1, Type.Missing]).Font.Bold = true;
                                            }
                                            else
                                            {
                                                bFirsttime = false;
                                            }
                                            object[,] rawData = new object[dtGINPODetails.Rows.Count, dtGINPODetails.Columns.Count];//one line project code next line column header

                                            for (int row = 0; row < dtGINPODetails.Rows.Count; row++)
                                            {
                                                for (int col = 0; col < dtGINPODetails.Columns.Count; col++)
                                                {
                                                    rawData[row, col] = dtGINPODetails.Rows[row].ItemArray[col];
                                                }
                                            }
                                            string excelRange = string.Empty;
                                            if (IsFirsttime)
                                            {
                                                finalColLetter = string.Empty;
                                                string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                                                int colCharsetLen = colCharset.Length;

                                                if (dtGINPODetails.Columns.Count > colCharsetLen)
                                                {
                                                    finalColLetter = colCharset.Substring(
                                                        (dtGINPODetails.Columns.Count - 1) / colCharsetLen - 1, 1);
                                                }
                                                j = 8;
                                                finalColLetter += colCharset.Substring(
                                                        (dtGINPODetails.Columns.Count - 1) % colCharsetLen, 1);
                                                excelRange = string.Format("A8:{0}{1}", finalColLetter, dtGINPODetails.Rows.Count + (j - 1));
                                                IsFirsttime = false;
                                            }
                                            else
                                            {
                                                if (bFirsttime)
                                                {
                                                    j = j + 2;
                                                    bFirsttime = false;
                                                }
                                                excelRange = string.Format("A" + j + ":{0}{1}", finalColLetter, dtGINPODetails.Rows.Count + (j - 1));
                                            }
                                            worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;

                                            j = j + (dtGINPODetails.Rows.Count);
                                            bvendorname = true;
                                        }
                                    }
                                }

                                j++;
                                dtGINPODetails.Rows.Clear();
                            }

                            worksheet.Columns.AutoFit();
                            worksheet.Rows.AutoFit();
                            worksheet.Columns[9].ColumnWidth = 50;
                            worksheet.Columns[3].WrapText = true;

                            worksheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                            Microsoft.Office.Interop.Excel.Range Range = worksheet.get_Range("j6", "Q99999");
                            Range.EntireColumn.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                            worksheet.Rows.RowHeight = "18";

                            fnDateFormat(worksheet, 1, 5);
                            fnDateFormatstring(worksheet, "G1", "G99999");
                            fnNumberFormatstring(worksheet, "j6", "Q99999");
                            fnExcelPrint(worksheet, "A1:O" + j + "");
                            fnDrawLogo(worksheet, 1, 6);
                            workbook.Save();
                            workbook.Close(true, misValue, misValue);
                            excelapp.Quit();
                            releaseObject(worksheet);
                            releaseObject(workbook);
                            releaseObject(excelapp);

                            if (Directory.Exists(ExcelFolderPath))
                            {
                                Process.Start(ExcelFolderPath);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Selected date has no records to genarate report!");
                        }
                    }
                    break;
                #endregion
                #region Consolidated GIN PO Report
                case "Consolidated GIN PO Standard Cost":
                    {
                        DataTable ConsolidatedGINPOReport = new DataTable();
                        List<string> listSupplierName = new List<string>();
                        ConsolidatedGINPOReport = DAL.GINReportTables(null, null, dtpFromDate.Text, dptToDate.Text, 26).Tables[0];
                        int j = 6;
                        bool bFirsttime = true;
                        if (ConsolidatedGINPOReport.Rows.Count > 0)
                        {
                            foreach (DataRow dr in ConsolidatedGINPOReport.Rows)
                            {
                                if (!listSupplierName.Contains(dr["SupplierName"].ToString()))
                                {
                                    listSupplierName.Add(dr["SupplierName"].ToString());
                                }
                            }
                            excelapp = new Microsoft.Office.Interop.Excel.Application();
                            workbook = excelapp.Workbooks.Add(Type.Missing);
                            // This returns something like C:\Users\Username:
                            string userRoot = System.Environment.GetEnvironmentVariable("USERPROFILE");
                            // Now let's get C:\Users\Username\Downloads:
                            string downloadFolder = Path.Combine(userRoot, "Downloads");
                            string ExcelFolderPath = downloadFolder + "\\Standard Cost GIN PO Report\\";
                            //string FileFullPath = ExcelFolderPath + "Standard Cost GIN PO Report " +  dtpFromDate.Text + " to " + dptToDate.Text + "" + DateTime.Now.ToString(" hh / mm / ss");
                            string FileFullPath = ExcelFolderPath + "Standard Cost GIN PO Report (" + dtpFromDate.Text + "to " + dptToDate.Text + ")" + DateTime.Now.ToString(" hh/mm/ss");

                            if (!Directory.Exists(ExcelFolderPath))
                                Directory.CreateDirectory(ExcelFolderPath);

                            workbook.SaveAs(FileFullPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                            Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                            worksheet = workbook.Sheets["Sheet1"];
                            worksheet = workbook.ActiveSheet;
                            worksheet.Name = "Consolidated GIN Report";
                            object misValue = System.Reflection.Missing.Value;

                            worksheet.Cells[1, 1] = Global.sCompanyName;
                            worksheet.Cells[2, 1] = "GIN Report";
                            worksheet.Cells[3, 1] = "Date";
                            worksheet.Cells[3, 2] = DateTime.Today.ToString("dd-MM-yyyy");
                            worksheet.Range["A1:C1"].Cells.Font.Size = 16;
                            worksheet.Range["A1:C1"].Cells.Font.Bold = 16;
                            worksheet.Range["A2:C2"].Cells.Font.Size = 14;
                            worksheet.Range["A2:C2"].Cells.Font.Bold = 14;
                            worksheet.Range["A3:C3"].Cells.Font.Size = 12;
                            worksheet.Range["A3:C3"].Cells.Font.Bold = 12;
                            worksheet.Range["A3:C4"].Cells.Font.Size = 12;
                            worksheet.Range["A3:C4"].Cells.Font.Bold = 12;
                            DataTable dtGINPODetails = new DataTable();
                            bool IsFirsttime = true;
                            string finalColLetter = string.Empty;
                            bool bvendorname = true;
                            double dNetAmount = 0.0;

                            foreach (string dr in listSupplierName)
                            {
                                bvendorname = false;
                                DataTable dtGINReport = new DataTable();
                                dtGINReport = DAL.GINReportTables(dr.ToString(), null, dtpFromDate.Text, dptToDate.Text, 26).Tables[0];
                                if (dtGINReport.Rows.Count > 0)
                                {
                                    List<string> listPO = new List<string>();
                                    foreach (DataRow dr1 in dtGINReport.Rows)
                                    {
                                        if (!listPO.Contains(dr1["GINNumber"].ToString()))
                                        {
                                            listPO.Add(dr1["GINNumber"].ToString());
                                        }
                                    }
                                    if (listPO.Count > 0)
                                    {
                                        foreach (string dr2 in listPO)
                                        {
                                            dtGINPODetails = DAL.GINReportTables(null, dr2.ToString(), dtpFromDate.Text, dptToDate.Text, 26).Tables[0];
                                            DataRow dr1 = dtGINPODetails.Rows[0];
                                            dr1["GrandTotal"] = 0;
                                            DataTable dtPOQty = new DataTable();
                                            DataTable dtPack = new DataTable();
                                            double sTotalQTY = 0;
                                            dtPOQty = DAL.fnPOQty(dtGINPODetails.Rows[0]["PO Number"].ToString()).Tables[0];
                                            sTotalQTY = Convert.ToDouble(dtPOQty.Compute("Sum(TotalQty)", "").ToString());
                                            double sGINQTY = 0;
                                            sGINQTY = Convert.ToDouble(dtGINPODetails.Compute("Sum(Quantity)", "").ToString());
                                            dtPack = DAL.fnPackingForwarding(dtGINPODetails.Rows[0]["PO Number"].ToString(), "Packing & Forwarding").Tables[0];
                                            double pack = 0;
                                            if (dtPack.Rows.Count > 0)
                                            {
                                                pack = (Convert.ToDouble(dtPack.Compute("Sum(Amount)", "").ToString()) / sTotalQTY) * sGINQTY;
                                                dr1["Packing/Forwarding"] = pack;
                                            }
                                            else
                                            {
                                                dr1["Packing/Forwarding"] = 0.0;
                                                pack = 0;
                                            }
                                            dtPack = DAL.fnPackingForwarding(dtGINPODetails.Rows[0]["PO Number"].ToString(), "Transportation / Freight").Tables[0];
                                            double freight = 0;
                                            if (dtPack.Rows.Count > 0)
                                            {
                                                freight = (Convert.ToDouble(dtPack.Compute("Sum(Amount)", "").ToString()) / sTotalQTY) * sGINQTY;
                                                dr1["Transportation/Freight"] = freight;
                                            }
                                            else
                                            {
                                                dr1["Transportation/Freight"] = 0.0;
                                                freight = 0;
                                            }
                                            dr1["GrandTotal"] = (Convert.ToDouble(dtGINPODetails.Compute("Sum(TaxableAmount)", "").ToString()) + Convert.ToDouble(dtGINPODetails.Compute("Sum(SGSTAmount)", "").ToString())
                                                 + Convert.ToDouble(dtGINPODetails.Compute("Sum(CGSTAmount)", "").ToString()) + Convert.ToDouble(dtGINPODetails.Compute("Sum(IGSTAmount)", "").ToString()) + pack + freight).ToString();
                                            dNetAmount += Convert.ToDouble(dtGINPODetails.Compute("Sum(Amount)", "").ToString());

                                            if (bvendorname == false)
                                            {
                                                worksheet.Cells[j, 1] = dr.ToString();
                                                CellMerge("Merge", workbook.ActiveSheet, j, j, 1, 5);
                                                bFirsttime = true;
                                                string[] sColumnNames = new string[] { "PO Number", "Project Code", "Project Name", "Customer", "Project Status",
                                                                                        "GINNumber", "Invoice Number", "Item Code", "Item Description","HSN / SAC", "Quantity","Unit Cost","Amount","DiscRate","DiscAmount","TaxableAmount","SGSTRate","SGSTAmount","CGSTRate","CGSTAmount","IGSTRate"
                                                                                        ,"IGSTAmount","Packing/Forwarding","Transportation/Freight","GrandTotal","PO Generated Date","GIN Date","Invoice Date","PO Delivery Date","DeliveryMonitor"};
                                                int icolumn = 1;
                                                for (int p = 0; p < sColumnNames.Length; p++)
                                                {
                                                    worksheet.Cells[j + 1, icolumn] = sColumnNames[p];
                                                    icolumn++;
                                                }
                                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Color = Color.Red;
                                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Bold = true;
                                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Size = 14;
                                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j + 1, Type.Missing]).Font.Bold = true;
                                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j + 1, Type.Missing]).Font.Color = Color.Blue;
                                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j + 1, Type.Missing]).Font.Bold = true;
                                            }
                                            else
                                            {
                                                bFirsttime = false;
                                            }
                                            object[,] rawData = new object[dtGINPODetails.Rows.Count, dtGINPODetails.Columns.Count];//one line project code next line column header
                                            for (int row = 0; row < dtGINPODetails.Rows.Count; row++)
                                            {
                                                for (int col = 0; col < dtGINPODetails.Columns.Count; col++)
                                                {
                                                    rawData[row, col] = dtGINPODetails.Rows[row].ItemArray[col];
                                                }
                                            }
                                            string excelRange = string.Empty;
                                            if (IsFirsttime)
                                            {
                                                finalColLetter = string.Empty;
                                                string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                                                int colCharsetLen = colCharset.Length;

                                                if (dtGINPODetails.Columns.Count > colCharsetLen)
                                                {
                                                    finalColLetter = colCharset.Substring((dtGINPODetails.Columns.Count - 1) / colCharsetLen - 1, 1);
                                                }
                                                j = 8;
                                                finalColLetter += colCharset.Substring((dtGINPODetails.Columns.Count - 1) % colCharsetLen, 1);
                                                excelRange = string.Format("A8:{0}{1}", finalColLetter, dtGINPODetails.Rows.Count + (j - 1));
                                                IsFirsttime = false;
                                            }
                                            else
                                            {
                                                if (bFirsttime)
                                                {
                                                    j = j + 2;
                                                    bFirsttime = false;
                                                }
                                                excelRange = string.Format("A" + j + ":{0}{1}", finalColLetter, dtGINPODetails.Rows.Count + (j - 1));
                                            }

                                            worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;

                                            j = j + (dtGINPODetails.Rows.Count);
                                            bvendorname = true;
                                        }
                                    }
                                }
                                j++;
                                dtGINPODetails.Rows.Clear();
                            }
                            worksheet.Cells[4, 1] = "Net Amount:";
                            worksheet.Cells[4, 2] = dNetAmount.ToString();
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[4, Type.Missing]).Font.Color = Color.Blue;
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[4, Type.Missing]).Font.Bold = true;
                            worksheet.Columns.AutoFit();
                            worksheet.Rows.AutoFit();
                            worksheet.Columns[9].ColumnWidth = 50;
                            worksheet.Columns[3].WrapText = true;

                            worksheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                            worksheet.Rows.RowHeight = "18";
                            fnDateFormatstring(worksheet, "Z1", "AC99999");
                            fnNumberFormatstring(worksheet, "K6", "Y99999");
                            fnExcelPrint(worksheet, "A1:O" + j + "");
                            fnDrawLogo(worksheet, 1, 6);

                            workbook.Save();
                            workbook.Close(true, misValue, misValue);
                            excelapp.Quit();
                            releaseObject(worksheet);
                            releaseObject(workbook);
                            releaseObject(excelapp);

                            if (Directory.Exists(ExcelFolderPath))
                            {
                                Process.Start(ExcelFolderPath);
                            }
                        }
                        else
                        {

                        }
                    }
                    break;
                #endregion
                #region Consolidated GIN WO Report
                case "Consolidated GIN WO Standard Cost":
                    {
                        FinalSum = 0.0;
                        DataTable dtissued = new DataTable();
                        List<string> listSupplierName = new List<string>();
                        dtissued = DAL.GINWOReportTables(null, null, dtpFromDate.Text, dptToDate.Text, 27).Tables[0];
                        if (dtissued.Rows.Count > 0)
                        {
                            foreach (DataRow dr in dtissued.Rows)
                            {
                                if (!listSupplierName.Contains(dr["SupplierName"].ToString()))
                                {
                                    listSupplierName.Add(dr["SupplierName"].ToString());
                                }
                            }

                            excelapp = new Microsoft.Office.Interop.Excel.Application();
                            workbook = excelapp.Workbooks.Add(Type.Missing);
                            // This returns something like C:\Users\Username:
                            string userRoot = System.Environment.GetEnvironmentVariable("USERPROFILE");
                            // Now let's get C:\Users\Username\Downloads:
                            string downloadFolder = Path.Combine(userRoot, "Downloads");
                            string ExcelFolderPath = downloadFolder + "\\Standard Cost GIN WO Report\\";
                            string FileFullPath = ExcelFolderPath + "Standard Cost GIN WO Report (" + dtpFromDate.Text + "to " + dptToDate.Text + ")" + DateTime.Now.ToString(" hh/mm/ss");
                            if (!Directory.Exists(ExcelFolderPath))
                                Directory.CreateDirectory(ExcelFolderPath);

                            workbook.SaveAs(FileFullPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                            Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                            worksheet = workbook.Sheets["Sheet1"];
                            worksheet = workbook.ActiveSheet;
                            worksheet.Name = "Consolidated GIN Report";
                            object misValue = System.Reflection.Missing.Value;
                            worksheet.Cells[1, 1] = Global.sCompanyName;
                            CellMerge("Merge", workbook.ActiveSheet, 1, 1, 1, 3);
                            worksheet.Cells[2, 1] = "Consolidated GIN WO Report";
                            CellMerge("Merge", workbook.ActiveSheet, 2, 2, 1, 3);
                            worksheet.Range["A1:C1"].Cells.Font.Size = 16;
                            worksheet.Range["A1:C1"].Cells.Font.Bold = 16;
                            worksheet.Range["A2:C2"].Cells.Font.Size = 14;
                            worksheet.Range["A2:C2"].Cells.Font.Bold = 14;
                            worksheet.Range["A3:C3"].Cells.Font.Size = 12;
                            worksheet.Range["A3:C3"].Cells.Font.Bold = 12;
                            worksheet.Range["A3:C4"].Cells.Font.Size = 12;
                            worksheet.Range["A3:C4"].Cells.Font.Bold = 12;
                            int i = 0;
                            foreach (string dr in listSupplierName)
                            {
                                DataTable dtWOGIN = new DataTable();
                                dtWOGIN = DAL.GINWOReportTables(dr.ToString(), null, dtpFromDate.Text, dptToDate.Text, 27).Tables[0];
                                if (dtWOGIN.Rows.Count > 0)
                                {
                                    worksheet.Cells[i + 5, 1] = dr.ToString();
                                    worksheet.Cells[i + 5, 1].Font.Size = 16;
                                    CellMerge("Merge", workbook.ActiveSheet, i + 5, i + 5, 1, 3);
                                    worksheet.Cells[3, 1] = "Date";

                                    List<string> listPO = new List<string>();
                                    foreach (DataRow dr1 in dtWOGIN.Rows)
                                    {
                                        if (!listPO.Contains(dr1["GINNumber"].ToString()))
                                        {
                                            listPO.Add(dr1["GINNumber"].ToString());
                                        }
                                    }
                                    if (listPO.Count > 0)
                                    {
                                        foreach (string dr2 in listPO)
                                        {
                                            DataTable dtWOGINIndiviual = new DataTable();
                                            dtWOGINIndiviual = DAL.GINWOReportTables(null, dr2.ToString(), dtpFromDate.Text, dptToDate.Text, 27).Tables[0];
                                            if (dtWOGINIndiviual.Rows.Count > 0)
                                            {
                                                DataTable dtTax = new DataTable();
                                                string name = "Consolidated GIN Report WOReport";
                                                dtTax = DAL.GINTax(dr2.ToString(), name).Tables[0];

                                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 5, Type.Missing]).Font.Color = Color.Red;
                                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 5, Type.Missing]).Font.Bold = true;
                                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 6, Type.Missing]).Font.Color = Color.Blue;
                                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 6, Type.Missing]).Font.Bold = true;

                                                string[] sColumnNames = new string[] { "WONo", "Item Code", "Item Description","HSN / SAC", "GINNumber", "Supplier Invoice Number", "GIN Date", "Invoice Date", "Quantity", "UnitCost", "Amount",
                                                  "SGSTRate","SGSTAmount","CGSTRate","CGSTAmount","IGSTRate","IGSTAmount"};
                                                int icolumn = 1;
                                                for (int p = 0; p < sColumnNames.Length; p++)
                                                {
                                                    worksheet.Cells[i + 6, icolumn] = sColumnNames[p];
                                                    icolumn++;
                                                }
                                                if (dtWOGINIndiviual.Rows.Count > 0)
                                                {
                                                    for (int iCountRow = 0; iCountRow < (dtWOGINIndiviual.Rows.Count); iCountRow++)
                                                    {
                                                        i++;
                                                        worksheet.Rows.AutoFit();
                                                        for (int j = 0; j < dtWOGINIndiviual.Columns.Count; j++)
                                                        {
                                                            worksheet.Columns.AutoFit();
                                                            worksheet.Cells[i + 6, j + 1] = dtWOGINIndiviual.Rows[iCountRow][j].ToString();
                                                        }
                                                    }
                                                }
                                                i++;
                                                double sTaxAmount = Convert.ToDouble(dtWOGINIndiviual.Compute("Sum(IGSTAmount)", "").ToString()) + Convert.ToDouble(dtWOGINIndiviual.Compute("Sum(SGSTAmount)", "").ToString())
                                                     + Convert.ToDouble(dtWOGINIndiviual.Compute("Sum(CGSTAmount)", "").ToString());
                                                worksheet.Cells[i + 6, 10] = "Total Amount:";
                                                worksheet.Cells[i + 6, 11] = dtWOGINIndiviual.Compute("Sum(Amount)", "").ToString();
                                                worksheet.Cells[i + 7, 10] = "Tax Amount:";
                                                worksheet.Cells[i + 7, 11] = sTaxAmount;
                                                worksheet.Cells[i + 8, 10] = "Final Amount:";
                                                FinalSum = FinalSum + Convert.ToDouble(dtWOGINIndiviual.Compute("Sum(Amount)", "").ToString());
                                                worksheet.Cells[i + 8, 11] = (FinalSum + sTaxAmount);
                                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 6, Type.Missing]).Font.Bold = true;
                                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 6, Type.Missing]).Font.Color = Color.Blue;
                                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 7, Type.Missing]).Font.Bold = true;
                                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 7, Type.Missing]).Font.Color = Color.Blue;
                                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 8, Type.Missing]).Font.Bold = true;
                                                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 8, Type.Missing]).Font.Color = Color.Red;
                                                i += 4;
                                            }
                                        }
                                    }
                                }
                            }
                            worksheet.Cells[3, 1] = "Total NetAmount:";
                            worksheet.Cells[3, 2] = FinalSum.ToString();
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[3, Type.Missing]).Font.Color = Color.Red;
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[3, Type.Missing]).Font.Bold = true;

                            worksheet.Columns.AutoFit();
                            worksheet.Rows.AutoFit();
                            worksheet.get_Range("C6", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                            worksheet.Columns[3].ColumnWidth = 50;
                            worksheet.Columns[3].WrapText = true;
                            worksheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                            worksheet.Rows.RowHeight = "18";
                            fnDateFormatstring(worksheet, "G7", "H9999");
                            fnNumberFormatstring(worksheet, "I6", "Q9999");
                            fnExcelPrint(worksheet, "A1:O" + (i + 6) + "");
                            fnDrawLogo(worksheet, 1, 6);
                            workbook.Save();
                            workbook.Close(true, misValue, misValue);
                            excelapp.Quit();
                            releaseObject(worksheet);
                            releaseObject(workbook);
                            releaseObject(excelapp);

                            if (Directory.Exists(ExcelFolderPath))
                            {
                                Process.Start(ExcelFolderPath);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Selected date has no records to genarate report!");
                        }
                    }
                    break;
                #endregion
                #region Purchase Register
                case "Purchase Register PO":
                case "Purchase Register WO":
                    if (cmbReport.SelectedItem.ToString() == "Purchase Register PO")
                    {
                        dtReciept = DAL.fnPurchaseRegister(dtpFromDate.Text, dptToDate.Text, 0).Tables[0];
                    }
                    else if (cmbReport.SelectedItem.ToString() == "Purchase Register WO")
                    {
                        dtReciept = DAL.fnPurchaseRegister(dtpFromDate.Text, dptToDate.Text, 1).Tables[0];
                    }

                    //dtReciept.Columns.RemoveAt(1);
                    //dtReciept.Columns.RemoveAt(0);
                    dtReciept.Columns.Add("IGSTAmount");
                    dtReciept.Columns.Add("SGSTAmount");
                    dtReciept.Columns.Add("CGSTAmount");

                    foreach (DataRow row in dtReciept.Rows)
                    {
                        row["IGSTAmount"] = (((Convert.ToDouble(row["Basic Value"]) + Convert.ToDouble(row["Packing&Forwarding,Transportation"])) * Convert.ToDouble(row["IGSTRate"])) / 100);
                        row["SGSTAmount"] = (((Convert.ToDouble(row["Basic Value"]) + Convert.ToDouble(row["Packing&Forwarding,Transportation"])) * Convert.ToDouble(row["SGSTRate"])) / 100);
                        row["CGSTAmount"] = (((Convert.ToDouble(row["Basic Value"]) + Convert.ToDouble(row["Packing&Forwarding,Transportation"])) * Convert.ToDouble(row["CGSTRate"])) / 100);
                        row["Gross Value"] = (Convert.ToDouble(row["Basic Value"]) + Convert.ToDouble(row["TCSAmount"]) + Convert.ToDouble(row["Packing&Forwarding,Transportation"]) +
                                                     Convert.ToDouble(row["IGSTAmount"]) + Convert.ToDouble(row["SGSTAmount"]) + Convert.ToDouble(row["CGSTAmount"])
                                                     + Convert.ToDouble(row["CDValue"]) + Convert.ToDouble(row["CDCessAmount"]) + Convert.ToDouble(row["CDIGSTAmount"]));
                    }

                    dtCloned = dtReciept.Clone();

                    for (int i = 8; i < 12; i++)
                    {
                        dtCloned.Columns[i].DataType = typeof(string);
                    }

                    foreach (DataRow row in dtReciept.Rows)
                    {
                        dtCloned.ImportRow(row);
                    }

                    //foreach (DataRow row in dtReciept.Rows)
                    //{
                    //    // if (dtGINPODetails.Rows.Count > 0)
                    //    // {
                    //    DataRow dr1 = row;

                    //    //dr1["GrandTotal"] = 0;


                    //    // DataTable dtPOQty = new DataTable();
                    //    DataTable dtPack = new DataTable();


                    //    dtPack = DAL.fnPackingForwarding(row["GINNumber"].ToString(), "Packing & Forwarding").Tables[0];
                    //    if (dtPack.Rows.Count > 0)
                    //    {
                    //        if (Convert.ToDouble(dtPack.Rows[0]["Packing/Forwarding"].ToString()) > 0)
                    //        {
                    //            dr1["Packing/Forwarding"] = Convert.ToDouble(dtPack.Rows[0]["Packing/Forwarding"].ToString());
                    //        }
                    //        else
                    //        {
                    //            dr1["Packing/Forwarding"] = 0.0;
                    //        }

                    //        if (Convert.ToDouble(dtPack.Rows[0]["PFIGSTRate"].ToString()) > 0)
                    //        {
                    //            dr1["PFIGSTRate"] = Convert.ToDouble(dtPack.Rows[0]["PFIGSTRate"].ToString());
                    //            dr1["PFIGSTAmount"] = Convert.ToDouble(dtPack.Rows[0]["PFIGSTAmount"].ToString());
                    //        }
                    //        else
                    //        {
                    //            dr1["PFIGSTRate"] = 0.0;
                    //            dr1["PFIGSTAmount"] = 0.0;
                    //        }

                    //        if (Convert.ToDouble(dtPack.Rows[0]["PFSGSTRate"].ToString()) > 0)
                    //        {
                    //            dr1["PFSGSTRate"] = Convert.ToDouble(dtPack.Rows[0]["PFSGSTRate"].ToString());
                    //            dr1["PFSGSTAmount"] = Convert.ToDouble(dtPack.Rows[0]["PFSGSTAmount"].ToString());
                    //        }
                    //        else
                    //        {
                    //            dr1["PFSGSTRate"] = 0.0;
                    //            dr1["PFSGSTAmount"] = 0.0;
                    //        }

                    //        if (Convert.ToDouble(dtPack.Rows[0]["PFCGSTRate"].ToString()) > 0)
                    //        {
                    //            dr1["PFCGSTRate"] = Convert.ToDouble(dtPack.Rows[0]["PFCGSTRate"].ToString());
                    //            dr1["PFCGSTAmount"] = Convert.ToDouble(dtPack.Rows[0]["PFCGSTAmount"].ToString());
                    //        }
                    //        else
                    //        {
                    //            dr1["PFCGSTRate"] = 0.0;
                    //            dr1["PFCGSTAmount"] = 0.0;
                    //        }


                    //        if (Convert.ToDouble(dtPack.Rows[0]["Transportation/Freight"].ToString()) > 0)
                    //        {
                    //            dr1["TransportationFreight"] = Convert.ToDouble(dtPack.Rows[0]["Transportation/Freight"].ToString());
                    //        }
                    //        else
                    //        {
                    //            dr1["TransportationFreight"] = 0.0;
                    //        }

                    //        if (Convert.ToDouble(dtPack.Rows[0]["TFIGSTRate"].ToString()) > 0)
                    //        {
                    //            dr1["TFIGSTRate"] = Convert.ToDouble(dtPack.Rows[0]["TFIGSTRate"].ToString());
                    //            dr1["TFIGSTAmount"] = Convert.ToDouble(dtPack.Rows[0]["TFIGSTAmount"].ToString());
                    //        }
                    //        else
                    //        {
                    //            dr1["TFIGSTRate"] = 0.0;
                    //            dr1["TFIGSTAmount"] = 0.0;
                    //        }

                    //        if (Convert.ToDouble(dtPack.Rows[0]["TFSGSTRate"].ToString()) > 0)
                    //        {
                    //            dr1["TFSGSTRate"] = Convert.ToDouble(dtPack.Rows[0]["TFSGSTRate"].ToString());
                    //            dr1["TFSGSTAmount"] = Convert.ToDouble(dtPack.Rows[0]["TFSGSTAmount"].ToString());
                    //        }
                    //        else
                    //        {
                    //            dr1["TFSGSTRate"] = 0.0;
                    //            dr1["TFSGSTAmount"] = 0.0;
                    //        }

                    //        if (Convert.ToDouble(dtPack.Rows[0]["TFCGSTRate"].ToString()) > 0)
                    //        {
                    //            dr1["TFCGSTRate"] = Convert.ToDouble(dtPack.Rows[0]["TFCGSTRate"].ToString());
                    //            dr1["TFCGSTAmount"] = Convert.ToDouble(dtPack.Rows[0]["TFCGSTAmount"].ToString());
                    //        }
                    //        else
                    //        {
                    //            dr1["TFCGSTRate"] = 0.0;
                    //            dr1["TFCGSTAmount"] = 0.0;
                    //        }


                    //        if (Convert.ToDouble(dtPack.Rows[0]["CDPercent"].ToString()) > 0)
                    //        {
                    //            dr1["CDPercent"] = Convert.ToDouble(dtPack.Rows[0]["CDPercent"].ToString());
                    //            dr1["CDValue"] = Convert.ToDouble(dtPack.Compute("Sum(CDValue)", "").ToString());
                    //        }
                    //        else
                    //        {
                    //            dr1["CDPercent"] = 0.0;
                    //            dr1["CDValue"] = 0.0;
                    //        }

                    //        if (Convert.ToDouble(dtPack.Rows[0]["CDIGSTRate"].ToString()) > 0)
                    //        {
                    //            dr1["CDIGSTRate"] = Convert.ToDouble(dtPack.Rows[0]["CDIGSTRate"].ToString());
                    //            dr1["CDIGSTAmount"] = Convert.ToDouble(dtPack.Compute("Sum(CDIGSTAmount)", "").ToString());
                    //        }
                    //        else
                    //        {
                    //            dr1["CDIGSTRate"] = 0.0;
                    //            dr1["CDIGSTAmount"] = 0.0;
                    //        }

                    //        if (Convert.ToDouble(dtPack.Rows[0]["CDCessRate"].ToString()) > 0)
                    //        {
                    //            dr1["CDCessRate"] = Convert.ToDouble(dtPack.Rows[0]["CDCessRate"].ToString());
                    //            dr1["CDCessAmount"] = Convert.ToDouble(dtPack.Compute("Sum(CDCessAmount)", "").ToString());
                    //        }
                    //        else
                    //        {
                    //            dr1["CDCessRate"] = 0.0;
                    //            dr1["CDCessAmount"] = 0.0;
                    //        }

                    //        if (Convert.ToDouble(dtPack.Rows[0]["TCSAmount"].ToString()) > 0)
                    //        {
                    //            dr1["TCSAmount"] = Convert.ToDouble(dtPack.Rows[0]["TCSAmount"].ToString());
                    //        }
                    //        else
                    //        {
                    //            dr1["TCSAmount"] = 0.0;
                    //        }
                    //    }


                    //    //dr1["GrandTotal"] = (Convert.ToDouble(dtGINPODetails.Compute("Sum(TaxableAmount)", "").ToString())
                    //    //    + Convert.ToDouble(dtGINPODetails.Compute("Sum(SGSTAmount)", "").ToString())
                    //    //     + Convert.ToDouble(dtGINPODetails.Compute("Sum(CGSTAmount)", "").ToString())
                    //    //     + Convert.ToDouble(dtGINPODetails.Compute("Sum(IGSTAmount)", "").ToString())
                    //    //     + Convert.ToDouble(dtGINPODetails.Compute("Sum(PackingForwarding)", "").ToString())
                    //    //     + Convert.ToDouble(dtGINPODetails.Compute("Sum(TransportationFreight)", "").ToString())
                    //    //      + Convert.ToDouble(dtGINPODetails.Compute("Sum(PFIGSTAmount)", "").ToString())
                    //    //       + Convert.ToDouble(dtGINPODetails.Compute("Sum(PFCGSTAmount)", "").ToString())
                    //    //        + Convert.ToDouble(dtGINPODetails.Compute("Sum(PFSGSTAmount)", "").ToString())
                    //    //         + Convert.ToDouble(dtGINPODetails.Compute("Sum(TFIGSTAmount)", "").ToString())
                    //    //          + Convert.ToDouble(dtGINPODetails.Compute("Sum(TFCGSTAmount)", "").ToString())
                    //    //           + Convert.ToDouble(dtGINPODetails.Compute("Sum(TFSGSTAmount)", "").ToString())
                    //    //            + Convert.ToDouble(dtGINPODetails.Compute("Sum(CDValue)", "").ToString())
                    //    //             + Convert.ToDouble(dtGINPODetails.Compute("Sum(CDIGSTAmount)", "").ToString())
                    //    //              + Convert.ToDouble(dtGINPODetails.Compute("Sum(CDCessAmount)", "").ToString())
                    //    //               + Convert.ToDouble(dtGINPODetails.Compute("Sum(TCSAmount)", "").ToString()));

                    //    //  dNetAmount += Convert.ToDouble(dtGINPODetails.Compute("Sum(Amount)", "").ToString());


                    //    //   dtSelectedGIN.Merge(dtGINPODetails);

                    //    // }
                    //}                  
                    dtCloned.Columns[18].SetOrdinal(9);
                    dtCloned.Columns[19].SetOrdinal(11);
                    dtCloned.Columns[20].SetOrdinal(13);
                    for (int i = 0; i < dtCloned.Rows.Count; i++)
                    {
                        if (Convert.ToDouble(dtCloned.Rows[i]["IGSTRate"].ToString()) > 0)
                        {
                            dtCloned.Rows[i]["IGSTRate"] = "21040 IGST In @ " + dtCloned.Rows[i]["IGSTRate"] + " %";
                        }
                        if (Convert.ToDouble(dtCloned.Rows[i]["SGSTRate"].ToString()) > 0)
                        {
                            dtCloned.Rows[i]["SGSTRate"] = "21040 SGST In @ " + dtCloned.Rows[i]["SGSTRate"] + " %";
                        }
                        if (Convert.ToDouble(dtCloned.Rows[i]["CGSTRate"].ToString()) > 0)
                        {
                            dtCloned.Rows[i]["CGSTRate"] = "21040 CGST In @ " + dtCloned.Rows[i]["CGSTRate"] + " %";
                        }
                    }
                    if (dtCloned.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;
                #endregion
                #region Riverse GIN
                case "Riverse GIN":
                    dtReciept = DAL.fnGINRiverseReport(dtpFromDate.Text, dptToDate.Text, 0).Tables[0];

                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;

                #endregion
                #region Project PO
                case "Project PO Placed":
                    dtReciept = DAL.GINProjectPOReport(cmbProjectCode.Text, dtpFromDate.Text, dptToDate.Text).Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;

                #endregion
                #region GIN Job Work
                case "Gin Job Work":
                    dtReciept = DAL.GINJobReciept(null, dtpFromDate.Text, dptToDate.Text).Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;

                #endregion
                //#region Item Usage Work Order Report
                //case 32:
                //    dtReciept = DAL.fnWOItemUsage(dtpFromDate.Text, dptToDate.Text, dtptwelve.Text, null).Tables[0];
                //    if (dtReciept.Rows.Count > 0)
                //    {
                //        CreateExcelSheet();
                //    }
                //    else
                //    {
                //        MessageBox.Show("Selected date has no records to genarate report!");
                //    }
                //    break;
                //#endregion


                #region Project Transfer Report
                case "Project Transform Details":
                    dtReciept = DAL.fnProjectStatusTransferDeatils(0, dtpFromDate.Text, dptToDate.Text).Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;
                #endregion

                #region Project Status update
                case "Project Status Update Details":
                    dtReciept = DAL.fnProjectStatusTransferDeatils(1, dtpFromDate.Text, dptToDate.Text).Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;
                #endregion

                #region Project Install Status
                case "Project Installation Status Update Details":
                    dtReciept = DAL.fnProjectStatusTransferDeatils(2, dtpFromDate.Text, dptToDate.Text).Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;
                #endregion

                #region Consolidated Stock report
                case "Consolidated Stock Report":
                    dtReciept = DAL.fnProjectStatusTransferDeatils(3, dtpFromDate.Text, dptToDate.Text).Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {

                        dStockvalue = 0;
                        dActive = 0;
                        dSlow = 0;
                        dObsolute = 0;
                        dRActive = 0;
                        dRSlow = 0;
                        dActive1 = 0;
                        dSlow1 = 0;
                        dObsolute1 = 0;
                        dRActive1 = 0;
                        dRSlow1 = 0;
                        dStockvalue1 = 0;
                        foreach (DataRow dr in dtReciept.Rows)
                        {
                            dStockvalue += Convert.ToDouble(dr["StockValue"].ToString());
                            dStockvalue1 += Convert.ToDouble(dr["AvailableQty"].ToString());

                            if (dr["Source"].ToString() == "Main StoresRM")
                            {
                                dActive += Convert.ToDouble(dr["StockValue"].ToString());

                                dActive1 += Convert.ToDouble(dr["AvailableQty"].ToString());
                            }
                            else if (dr["Source"].ToString() == "Electronics StoresFG")
                            {
                                dSlow += (Convert.ToDouble(dr["AvailableQty"].ToString()) * Convert.ToDouble(dr["UnitCost"].ToString()));

                                dSlow1 += Convert.ToDouble(dr["AvailableQty"].ToString());
                            }
                            else if (dr["Source"].ToString() == "Electronics StoresRM")
                            {
                                dObsolute += Convert.ToDouble(dr["StockValue"].ToString());
                                dObsolute1 += Convert.ToDouble(dr["AvailableQty"].ToString());
                            }
                            else if (dr["Source"].ToString() == "Transducer StoresFG")
                            {
                                dRActive += Convert.ToDouble(dr["StockValue"].ToString());
                                dRActive1 += Convert.ToDouble(dr["AvailableQty"].ToString());
                            }
                            else if (dr["Source"].ToString() == "Transducer StoresRM")
                            {
                                dRSlow += Convert.ToDouble(dr["StockValue"].ToString());
                                dRSlow1 += Convert.ToDouble(dr["AvailableQty"].ToString());
                            }
                        }

                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;
                #endregion

                #region All Stock Latest Standard Cost Report
                case "All Stock Latest Standard Cost Report":
                case "All Stock Standard Cost Analysis":
                    dtReciept.Clear();

                    if (cmbReport.Text == "All Stock Latest Standard Cost Report")
                    {
                        dtReciept = DAL.fnProjectStatusTransferDeatils(4, dtpFromDate.Text, dptToDate.Text).Tables[0];

                        dtReciept.Columns.Remove("Top 1 Purchase");
                    }

                    else if (cmbReport.Text == "All Stock Standard Cost Analysis")
                    {
                        dtReciept = DAL.fnProjectStatusTransferDeatils(8, dtpFromDate.Text, dptToDate.Text).Tables[0];
                    }

                    if (dtReciept.Rows.Count > 0)
                    {
                        int iRowIndex = 1;
                        string ExcelFolderPath;
                        string FileFullPath;
                        EXCEL.Workbook NewWorkBook;
                        EXCEL.Worksheet NewWorkSheet;
                        EXCEL.Application ExcelApp;
                        EXCEL.Range CELLS, cell1, cell2;
                        object misValue;
                        if (dtReciept.Rows.Count > 0)
                        {
                            string userRoot = System.Environment.GetEnvironmentVariable("USERPROFILE");
                            // Now let's get C:\Users\Username\Downloads:
                            string downloadFolder = Path.Combine(userRoot, "Downloads");
                            ExcelFolderPath = downloadFolder + @"\All Stock Latest Standard Cost Report\";
                            if (cmbReport.Text == "All Stock Standard Cost Analysis")
                            {
                                FileFullPath = ExcelFolderPath + "All Stock Standard Cost Analysis" + DateTime.Now.ToString("hh/mm/ss");
                            }
                            else
                            {
                                FileFullPath = ExcelFolderPath + "All Stock Latest Standard Cost Report" + DateTime.Now.ToString("hh/mm/ss");
                            }
                            //  ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\Order Entry\\";
                            //FileFullPath = ExcelFolderPath + txtPMProjectCode.Text + " -Scope of Supply" + "-" + DateTime.Now.ToString("dd/MM/yyyy hh/mm/ss") + ".xls";
                            if (!Directory.Exists(ExcelFolderPath))
                                Directory.CreateDirectory(ExcelFolderPath);
                            ExcelApp = new EXCEL.Application();
                            misValue = System.Reflection.Missing.Value;
                            try
                            {
                                if (ExcelApp == null)
                                    MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                                NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                                NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                                if (NewWorkSheet == null)
                                    MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                                else
                                    NewWorkSheet.Name = "Scope of Supply";
                                // Select the Excel cells, in the range c1 to c7 in the worksheet for cell access check.
                                EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                                if (RANGE == null)
                                    MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                                NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlWorkbookNormal, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                                CELLS = NewWorkSheet.Cells;



                                if (dtReciept.Rows.Count > 0)
                                {
                                    object[,] rawData = new object[dtReciept.Rows.Count + 1, dtReciept.Columns.Count];
                                    for (int col = 0; col < dtReciept.Columns.Count; col++)
                                    {
                                        rawData[0, col] = dtReciept.Columns[col].ColumnName;
                                    }
                                    for (int row = 0; row < dtReciept.Rows.Count; row++)
                                    {
                                        for (int col = 0; col < dtReciept.Columns.Count; col++)
                                        {
                                            rawData[row + 1, col] = dtReciept.Rows[row].ItemArray[col];
                                        }
                                    }
                                    string excelRange = string.Empty;
                                    string finalColLetter = string.Empty;
                                    string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                                    int colCharsetLen = colCharset.Length;

                                    if (dtReciept.Columns.Count > colCharsetLen)
                                    {
                                        finalColLetter = colCharset.Substring((dtReciept.Columns.Count - 1) / colCharsetLen - 1, 1);
                                    }

                                    finalColLetter += colCharset.Substring((dtReciept.Columns.Count - 1) % colCharsetLen, 1);
                                    excelRange = string.Format("A1:{0}{1}", finalColLetter, dtReciept.Rows.Count);


                                    NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                                }


                                NewWorkSheet.Range["A1:P1"].Cells.Font.Bold = true;
                                NewWorkSheet.Range["A1:P1"].Cells.Font.Size = 12;




                                NewWorkSheet.Rows.AutoFit();

                                NewWorkSheet.Columns.AutoFit();
                                // NewWorkSheet.Columns[1].ColumnWidth = 20;
                                NewWorkSheet.Columns[3].ColumnWidth = 50;
                                // NewWorkSheet.Columns[5].ColumnWidth = 50;
                                //CellMerge("AlignTop", NewWorkSheet, 1, (dtReciept.Rows.Count + 1), 1, 7);
                                NewWorkSheet.Rows.RowHeight = "18";

                                Microsoft.Office.Interop.Excel.Range range1 = NewWorkSheet.get_Range("D2", "D" + (dtReciept.Rows.Count + 1));
                                range1.NumberFormat = "dd-MM-yyyy";

                                Microsoft.Office.Interop.Excel.Range range2 = NewWorkSheet.get_Range("L2", "L" + (dtReciept.Rows.Count + 1));
                                range2.NumberFormat = "dd-MM-yyyy";


                                NewWorkSheet.PageSetup.PrintArea = "A1:P" + (dtReciept.Rows.Count + 1) + "";
                                NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                                NewWorkSheet.PageSetup.PrintNotes = true;
                                NewWorkSheet.PageSetup.Zoom = 100;
                                NewWorkSheet.PageSetup.FitToPagesTall = 1;
                                NewWorkSheet.PageSetup.FitToPagesWide = 1;
                                NewWorkSheet.PageSetup.LeftMargin = 0;
                                NewWorkSheet.PageSetup.RightMargin = 0;
                                NewWorkSheet.PageSetup.TopMargin = 0.75;
                                NewWorkSheet.PageSetup.BottomMargin = 0.75;
                                NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                                NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                                //string _stLOGO = ("C:\\Databasepath\\Bisslogo.jpg");
                                //EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 7];

                                //Image oImage = Image.FromFile(_stLOGO);
                                //System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                                //NewWorkSheet.Paste(oRange, _stLOGO);

                                NewWorkBook.Save();
                                ExcelApp.Visible = true;
                                System.Threading.Thread.Sleep(1000);
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message);
                            }
                        }
                    }

                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;
                #endregion

                #region Conusmption Report

                case "Consolidated Projects Conusmption Report":

                    //dtReciept = DAL.fnItemUsageofAllStores(6, dtpFromDate.Text, dptToDate.Text, dtptwelve.Text, null).Tables[0];
                    
                    dtReciept = DAL.fnItemUsageofFilterReport(comboBoxINOutWard.Text, dtpFromDate.Text, dptToDate.Text, dtptwelve.Text, null).Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    break;
                #endregion

                #region Conusmption Report

                case "Customer Projects Conusmption Report":

                    dtReciept = DAL.fnItemUsageofAllStores(2, dtpFromDate.Text, dptToDate.Text, dtptwelve.Text, null).Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    break;
                #endregion


                #region All stock Conusmption Report

                case "Cust. Project Inventory Grading Report":

                    dtReciept = DAL.fnItemUsageofAllStores(3, dtpFromDate.Text, dptToDate.Text, dtptwelve.Text, null).Tables[0];

                    fnUsageCount();

                    foreach (DataRow dr in dtReciept.Rows)
                    {
                        if (Convert.ToDateTime(dr["CreatedDate"].ToString()) > Convert.ToDateTime(dtptwelve.Text) || Convert.ToDouble(dr["AvailableQty"].ToString()) == 0)
                        {
                            dr["Grading"] = "Active";
                        }
                        else if ((Convert.ToDouble(dr["12Months"].ToString()) == 0 && Convert.ToDouble(dr["AvailableQty"].ToString()) > 0) && Convert.ToDateTime(dr["CreatedDate"].ToString()) < Convert.ToDateTime(dtptwelve.Text))
                        {
                            dr["Grading"] = "Obsolute";
                        }
                        else if ((Convert.ToDouble(dr["AvailableQty"].ToString()) > Convert.ToDouble(dr["6Months"].ToString())))
                        {
                            dr["Grading"] = "Slow";
                        }
                        else
                        {
                            dr["Grading"] = "Active";
                        }
                    }

                    foreach (DataRow dr in dtReciept.Rows)
                    {
                        dr["StockValue"] = (Convert.ToDouble(dr["AvailableQty"].ToString()) * Convert.ToDouble(dr["UnitCost"].ToString()));
                    }

                    foreach (DataRow dr in dtReciept.Rows)
                    {
                        dr["Inventory Value with OH"] = (Convert.ToDouble(dr["StockValue"].ToString()) + (Convert.ToDouble(dr["StockValue"].ToString()) * 0.223269876));
                    }
                    foreach (DataRow dr in dtReciept.Rows)
                    {
                        if (dr["Grading"].ToString() == "Slow")
                        {
                            dr["Reserve Amount"] = (Convert.ToDouble(dr["Inventory Value with OH"].ToString()) * 0.5);
                        }
                        else if (dr["Grading"].ToString() == "Obsolute")
                        {
                            dr["Reserve Amount"] = (Convert.ToDouble(dr["Inventory Value with OH"].ToString()) * 0.9);
                        }
                        else if (dr["Grading"].ToString() == "Active")
                        {
                            dr["Reserve Amount"] = ((Convert.ToDouble(dr["Inventory Value with OH"].ToString())) * 0);
                        }
                    }
                    dStockvalue = 0;
                    dStockvaluewithOH = 0;
                    dActive = 0;
                    dSlow = 0;
                    dObsolute = 0;
                    dReserve = 0;
                    dRActive = 0;
                    dRSlow = 0;
                    dRObsolute = 0;
                    dActiveP = 0;
                    dSlowP = 0;
                    dObsoluteP = 0;
                    dActive1 = 0;

                    dDActive = 0;
                    dDSlow = 0;
                    dDObsolute = 0;
                    foreach (DataRow dr in dtReciept.Rows)
                    {
                        dStockvalue += Convert.ToDouble(dr["StockValue"].ToString());
                        dStockvaluewithOH += Convert.ToDouble(dr["Inventory Value with OH"].ToString());
                        dReserve += Convert.ToDouble(dr["Reserve Amount"].ToString());

                        if (dr["Grading"].ToString() == "Active")
                        {
                            dDActive += Convert.ToDouble(dr["StockValue"].ToString());
                            dActive += Convert.ToDouble(dr["Inventory Value with OH"].ToString());
                            dRActive += Convert.ToDouble(dr["Reserve Amount"].ToString());
                        }
                        else if (dr["Grading"].ToString() == "Slow")
                        {
                            dDSlow += Convert.ToDouble(dr["StockValue"].ToString());
                            dSlow += Convert.ToDouble(dr["Inventory Value with OH"].ToString());
                            dRSlow += Convert.ToDouble(dr["Reserve Amount"].ToString());
                        }
                        else if (dr["Grading"].ToString() == "Obsolute")
                        {
                            dDObsolute += Convert.ToDouble(dr["StockValue"].ToString());
                            dObsolute += Convert.ToDouble(dr["Inventory Value with OH"].ToString());
                            dRObsolute += Convert.ToDouble(dr["Reserve Amount"].ToString());
                        }
                    }

                    dActiveP = (dActive / dStockvaluewithOH);
                    dSlowP = (dSlow / dStockvaluewithOH);
                    dObsoluteP = (dObsolute / dStockvaluewithOH);


                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    break;
                #endregion
                #region User Access level report
                case "User Access Report":
                    dtReciept = DAL.fnUseraccesslist(1).Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    break;
                #endregion

                #region project document tracking report

                case "Project Document Tracking":

                    string[] DocumentList = { "Customer Order", "Bank Guarantee", "Performance Bank Guarantee", "Security Deposit", "LC", "Design approval by customer", "PDI acceptance certificate/communication", "PI for Advance", "Invoice & Packing list", "Dispatch Proof (Bill of lading/transportation copy etc)", "Installation certificate", "Guarantee certificate", "Warranty certificate" };
                    dtReciept = DAL.fnProjectdoctrackList(1).Tables[0];
                    DataTable DT = new DataTable();
                    DT = DAL.fnProjectdoctrackList(2).Tables[0];
                    string[] arrray = DT.Rows.OfType<DataRow>().Select(k => k[0].ToString()).ToArray();
                    bool bDocExist = false;
                    if (dtReciept.Rows.Count > 0)
                    {
                        for (int i = 0; i < arrray.Length; i++)
                        {
                            foreach (string sDocumnet in DocumentList)
                            {
                                bDocExist = false;
                                foreach (DataRow dr in dtReciept.Rows)
                                {
                                    if (arrray[i] == dr["ProjectCode"].ToString())
                                    {
                                        if (dr["DocumentType"].ToString() == sDocumnet)
                                        {
                                            bDocExist = true;
                                            break;
                                        }
                                    }
                                }
                                if (!bDocExist)
                                {
                                    // dtReciept.Rows.Add(0, arrray[i], "", "", "", "", "False", "False", "", "", "", sDocumnet);
                                    dtReciept.Rows.Add(arrray[i], sDocumnet, "", "", "False", "", "");
                                }
                            }
                        }
                    }

                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    break;
                #endregion

                #region std item cost report
                case "Standard Item Cost":
                    dtReciept = DAL.fnItemGinDetail(3, "").Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    break;
                #endregion
                #region Job Work Report
                case "Job Work":
                    dtReciept = DAL.fnJobWorkData(dtpFromDate.Text, dptToDate.Text, 45).Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;
                #endregion
                #region Service GIN Report
                case "Service GIN":

                    dtReciept = DAL.GINReportTables(null, null, dtpFromDate.Text, dptToDate.Text, 15).Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;
                #endregion

                #region All Projects Master

                case "Project Master":

                    dtReciept = DAL.AllProjectMaster(0, dtpFromDate.Text, dptToDate.Text).Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }

                    break;
                #endregion

                #region Fixed Asset Register
                case "Fixed Asset Register":

                    dtReciept = DAL.AllProjectMaster(1, dtpFromDate.Text, dptToDate.Text).Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }

                    break;
                #endregion


                #region ERP  WAR Log Report

                case "ERP WAR Log Report":
                    dtReciept = DAL.ERPWARLogReport(0, dtpFromDate.Text, dptToDate.Text).Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;

                #endregion

                #region ERP Log Report

                case "ERP Log Report":
                    dtReciept = DAL.ERPLogReport(0, dtpFromDate.Text, dptToDate.Text).Tables[0];
                    if (dtReciept.Rows.Count > 0)
                    {
                        CreateExcelSheet();
                    }
                    else
                    {
                        MessageBox.Show("Selected date has no records to genarate report!");
                    }
                    break;

                    #endregion
            }
            fnCustomDate(1);
        }
        #endregion
        DataTable dtCloned = new DataTable();
        #region CellMerge Funtion
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlMedium, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "GridLines":
                    {
                        CELLS.Borders.Color = System.Drawing.Color.Black;
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignCenter":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                        break;
                    }
                case "Bold":
                    {
                        CELLS.Font.Bold = true;
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

        }
        #endregion

        #region ComboBox Selection Change
        private void cmbReport_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbReport.SelectedItem.ToString() == "Consolidated Projects Conusmption Report")
            {
                InOutWardpanel.Visible = true;
            }
            else
            {
                InOutWardpanel.Visible = false;
            }
            pnoneyear.Visible = false;
            pnGenaralPanel.Enabled = true;
            lblToDate.Text = "To Date";
            switch (cmbReport.SelectedItem.ToString())
            {
                case "Stock Balance":
                    
                case "GM Approve Pending PO":
                    //pnGenaralPanel.Visible = true;
                    pnGenaralPanel.Visible = false;
                    pnProjectCodePanel.Visible = false;
                    pnVendorPanel.Visible = false;
                    pnginprint.Visible = false;
                    btnexcelreport.Visible = true;
                    stockBalancepanel.Visible = false;
                    ItemLabelPrintpanel.Visible = false;
                    break;
                case "Item Label Print":
                    ItemLabelPrintpanel.Visible = true;
                    btnexcelreport.Visible = true;
                    pnginprint.Visible = false;

                    dtLocations = DAL.fnPrintReceiptLocationList().Tables[0];
                   

                    foreach (DataRow location in dtLocations.Rows)
                    {
                        //comboBox2LabelPrintLocation
                        if (!comboBox2LabelPrintLocation.Items.Contains(location["Location"].ToString()))
                            comboBox2LabelPrintLocation.Items.Add(location["Location"].ToString());
                    }

                    dtItemCodeList = DAL.fnPrintReceiptItemCodeList(null, null).Tables[0];

                    foreach (DataRow item in dtItemCodeList.Rows)
                    {
                        if (!comboBox1LabelPrintItemCode.Items.Contains(item["ItemCode"].ToString()))
                            comboBox1LabelPrintItemCode.Items.Add(item["ItemCode"].ToString());
                    }

                    break;
                case "Filter Stock Balance":
                    pnGenaralPanel.Visible = false;
                    ItemLabelPrintpanel.Visible = false;
                    pnProjectCodePanel.Visible = false;
                    pnVendorPanel.Visible = false;
                    pnginprint.Visible = false;
                    btnexcelreport.Visible = true;
                    stockBalancepanel.Visible = true;
                    break;
                case "Project Cost":
                case "Project Cost, Machine & Man hours details":
                case "Project PO Placed":
                    pnGenaralPanel.Visible = true;
                    ItemLabelPrintpanel.Visible = false;
                    pnProjectCodePanel.Visible = true;
                    pnVendorPanel.Visible = false;
                    pnginprint.Visible = false;
                    btnexcelreport.Visible = true;
                    stockBalancepanel.Visible = false;
                    if (DTProjectList.Rows.Count == 0)
                    {
                        DTProjectList = DAL.fnProjectList(null).Tables[0];

                        foreach (DataRow row in DTProjectList.Rows)
                        {
                            if (!cmbProjectCode.Items.Contains(row["ProjectCode"].ToString()))
                                cmbProjectCode.Items.Add(row["ProjectCode"].ToString());
                        }
                    }
                    break;

                case "Consolidated Projects Conusmption Report":
                case "Customer Projects Conusmption Report":

                    pnGenaralPanel.Visible = true;
                    pnGenaralPanel.Enabled = true;
                    pnProjectCodePanel.Visible = false;
                    pnVendorPanel.Visible = false;
                    pnginprint.Visible = false;
                    btnexcelreport.Visible = true;
                    //pnoneyear.Visible = true;
                    stockBalancepanel.Visible = false;
                    ItemLabelPrintpanel.Visible = false;
                    //lblToDate.Text = "6 Months Date";
                    var sTodatydate1 = DateTime.Today;
                    dtpFromDate.Value = sTodatydate1;
                    dptToDate.Value = sTodatydate1;



                    break;
                case "Inventory Grading Report":
                case "Item Usage Work Order":
                case "Cust. Project Inventory Grading Report":
                    pnGenaralPanel.Visible = true;
                    pnGenaralPanel.Enabled = true;
                    pnProjectCodePanel.Visible = false;
                    pnVendorPanel.Visible = false;
                    pnginprint.Visible = false;
                    btnexcelreport.Visible = true;
                    pnoneyear.Visible = true;
                    stockBalancepanel.Visible = false;
                    ItemLabelPrintpanel.Visible = false;
                    lblToDate.Text = "6 Months Date";
                    var sTodatydate = DateTime.Today;
                    dtpFromDate.Value = sTodatydate;
                    break;


                case "Vendor GIN Report PO":
                case "Vendor GIN Report WO":
                    pnGenaralPanel.Visible = true;
                    pnProjectCodePanel.Visible = false;
                    pnVendorPanel.Visible = true;
                    pnginprint.Visible = false;
                    btnexcelreport.Visible = true;
                    ItemLabelPrintpanel.Visible = false;
                    stockBalancepanel.Visible = false;
                    dtvendorList = DAL.fnVedorList(null).Tables[0];
                    foreach (DataRow dr in dtvendorList.Rows)
                    {
                        if (!cmbvendorlist.Items.Contains(dr["VendorName"].ToString()))
                        {
                            cmbvendorlist.Items.Add(dr["VendorName"].ToString());
                        }
                    }
                    break;
                case "Print GIN":
                    pnGenaralPanel.Visible = false;
                    pnProjectCodePanel.Visible = false;
                    pnVendorPanel.Visible = false;
                    pnginprint.Visible = true;
                    btnexcelreport.Visible = false;
                    stockBalancepanel.Visible = false;
                    ItemLabelPrintpanel.Visible = false;
                    dtLocations = DAL.fnPrintReceiptLocationList().Tables[0];
                    foreach (DataRow dr in dtLocations.Rows)
                    {
                        if (!comboBox1Location.Items.Contains(dr["Location"].ToString()))
                            comboBox1Location.Items.Add(dr["Location"].ToString());
                    }
                    break;
                case "Vendor List":
                case "Project List":
                case "Fixed Asset Register":
                    pnGenaralPanel.Visible = false;
                    pnProjectCodePanel.Visible = false;
                    pnVendorPanel.Visible = false;
                    pnginprint.Visible = false;
                    btnexcelreport.Visible = true;
                    stockBalancepanel.Visible = false;
                    ItemLabelPrintpanel.Visible = false;
                    break;

                case "User Access Report":
                    pnGenaralPanel.Visible = false;
                    pnProjectCodePanel.Visible = false;
                    pnVendorPanel.Visible = false;
                    pnginprint.Visible = false;
                    btnexcelreport.Visible = true;
                    stockBalancepanel.Visible = false;
                    ItemLabelPrintpanel.Visible = false;
                    break;
                case "Project Document Tracking":
                    pnGenaralPanel.Visible = false;
                    ItemLabelPrintpanel.Visible = false;
                    pnProjectCodePanel.Visible = false;
                    pnVendorPanel.Visible = false;
                    pnginprint.Visible = false;
                    btnexcelreport.Visible = true;
                    stockBalancepanel.Visible = false;
                    break;

                case "Standard Item Cost":
                case "All Stock Latest Standard Cost Report":
                case "All Stock Standard Cost Analysis":
                    pnGenaralPanel.Visible = false;
                    pnProjectCodePanel.Visible = false;
                    pnVendorPanel.Visible = false;
                    pnginprint.Visible = false;
                    btnexcelreport.Visible = true;
                    ItemLabelPrintpanel.Visible = false;
                    stockBalancepanel.Visible = false;
                    break;

                default:
                    pnGenaralPanel.Visible = true;
                    pnProjectCodePanel.Visible = false;
                    pnVendorPanel.Visible = false;
                    pnginprint.Visible = false;
                    ItemLabelPrintpanel.Visible = false;
                    btnexcelreport.Visible = true;
                    stockBalancepanel.Visible = false;
                    break;
            }
        }
        #endregion
        string sWOPO;
        #region GIN Number Selection Change
        private void cmbprintginnumber_SelectedIndexChanged(object sender, EventArgs e)
        {

            sWOPO = "";
            dtGINNumber = new DataTable();
            dtGINNumber.Rows.Clear();

            dtGINNumber = DAL.fnprintReceipt(cmbprintginnumber.Text, "PO").Tables[0];

            if (!dtGINNumber.Columns.Contains("location"))
            {
                dtGINNumber.Columns.Add("location", typeof(string));
            }

            foreach (DataRow rowData in dtGINNumber.Rows)
            {
                // MessageBox.Show("location added for this row");
                DataTable ERPInventoryGINDeatils = DAL.getERPInventoryGINDeatils(rowData["ItemCode"]?.ToString(), cmbprintginnumber.Text, null).Tables[0];

                if (ERPInventoryGINDeatils.Rows.Count > 0)
                {
                    //  MessageBox.Show(ERPInventoryGINDeatils.Rows.Count.ToString(), "Data count");
                    rowData["location"] = ERPInventoryGINDeatils.Rows[0]["ItemLocation"]?.ToString();
                }
                else
                {
                    rowData["location"] = "-";
                }

            }



            if (dtGINNumber.Rows.Count > 0)
            {
                sWOPO = "PO";
                dgvprintpreview.AutoGenerateColumns = false;
                dgvprintpreview.DataSource = dtGINNumber;

                string tempItemcode = "";
                double tempSupplyQty = 0;
                double temTotalAmount = 0;

                comboBox1ItemCodeLocation.Items.Clear();
                foreach (DataGridViewRow row in dgvprintpreview.Rows)
                {
                    tempSupplyQty = 0;
                    temTotalAmount = 0;
                    //MessageBox.Show(row.Cells["ItemCode"].Value?.ToString());
                    if (tempItemcode != row.Cells["ItemCode"].Value?.ToString())
                    {
                        tempItemcode = row.Cells["ItemCode"].Value?.ToString();
                       
                            if (!comboBox1ItemCodeLocation.Items.Contains(row.Cells["ItemCode"].Value?.ToString()))
                                comboBox1ItemCodeLocation.Items.Add(row.Cells["ItemCode"].Value?.ToString());
                        
                        foreach (DataGridViewRow subRow in dgvprintpreview.Rows)
                        {
                            if (row.Cells["ItemCode"].Value?.ToString() == subRow.Cells["ItemCode"].Value?.ToString())
                            {
                                tempSupplyQty += Convert.ToDouble(subRow.Cells["SupplyQty"].Value?.ToString());
                                temTotalAmount += Convert.ToDouble(subRow.Cells["Amount"].Value?.ToString());//Amount 




                                row.Cells["SupplyQty"].Value = tempSupplyQty;
                                row.Cells["Amount"].Value = temTotalAmount;

                            }
                        }
                    }
                    else
                    {
                        //row.DefaultCellStyle.BackColor = Color.LightGreen;
                        //row.Cells["RecieveQuantity"].ReadOnly = true;
                        //row.Cells["RecieveQuantity"].Style.BackColor = Color.LightGray;
                        //row.Cells["totalRemainingQty"].Value = Convert.ToDouble(row.Cells["RemainingQty"].Value?.ToString());
                        row.Visible = false;
                        row.DefaultCellStyle.BackColor = Color.LightBlue;
                        //tempRemQty += Convert.ToDouble(row.Cells["RemainingQty"].Value?.ToString());

                    }

                }



                txtprintvendorcode.Text = dtGINNumber.Rows[0]["SupplierName"].ToString();
                txtprintprojectcode.Text = dtGINNumber.Rows[0]["ProjectCode"].ToString();
                txtprintvendorname.Text = dtGINNumber.Rows[0]["VendorCode"].ToString();
                txtprintprojectname.Text = dtGINNumber.Rows[0]["ProjectDescription"].ToString();
            }

            else
            {
                dtGINNumber.Rows.Clear();
                dtGINNumber = DAL.fnprintReceipt(cmbprintginnumber.Text, "WO").Tables[0];
                // MessageBox.Show("Else");


                if (dtGINNumber.Rows.Count > 0)
                {
                    sWOPO = "WO";
                    dgvprintpreview.AutoGenerateColumns = false;
                    if (!dtGINNumber.Columns.Contains("location"))
                    {
                        dtGINNumber.Columns.Add("location", typeof(string));
                    }

                    foreach (DataRow rowData in dtGINNumber.Rows)
                    {
                        //  MessageBox.Show("location added for this row");
                        rowData["location"] = "-";
                    }

                    dgvprintpreview.DataSource = dtGINNumber;

                    string tempItemcode = "";
                    double tempSupplyQty = 0;
                    double temTotalAmount = 0;

                    comboBox1ItemCodeLocation.Items.Clear();
                    foreach (DataGridViewRow row in dgvprintpreview.Rows)
                    {
                        tempSupplyQty = 0;
                        temTotalAmount = 0;
                        //MessageBox.Show(row.Cells["ItemCode"].Value?.ToString());
                        if (tempItemcode != row.Cells["ItemCode"].Value?.ToString())
                        {
                            tempItemcode = row.Cells["ItemCode"].Value?.ToString();

                            if (!comboBox1ItemCodeLocation.Items.Contains(row.Cells["ItemCode"].Value?.ToString()))
                                comboBox1ItemCodeLocation.Items.Add(row.Cells["ItemCode"].Value?.ToString());

                            foreach (DataGridViewRow subRow in dgvprintpreview.Rows)
                            {
                                if (row.Cells["ItemCode"].Value?.ToString() == subRow.Cells["ItemCode"].Value?.ToString())
                                {
                                    tempSupplyQty += Convert.ToDouble(subRow.Cells["SupplyQty"].Value?.ToString());
                                    temTotalAmount += Convert.ToDouble(subRow.Cells["Amount"].Value?.ToString());//Amount 




                                    row.Cells["SupplyQty"].Value = tempSupplyQty;
                                    row.Cells["Amount"].Value = temTotalAmount;

                                }
                            }
                        }
                        else
                        {
                            //row.DefaultCellStyle.BackColor = Color.LightGreen;
                            //row.Cells["RecieveQuantity"].ReadOnly = true;
                            //row.Cells["RecieveQuantity"].Style.BackColor = Color.LightGray;
                            //row.Cells["totalRemainingQty"].Value = Convert.ToDouble(row.Cells["RemainingQty"].Value?.ToString());
                            row.Visible = false;
                            row.DefaultCellStyle.BackColor = Color.LightBlue;
                            //tempRemQty += Convert.ToDouble(row.Cells["RemainingQty"].Value?.ToString());

                        }

                    }

                    txtprintvendorcode.Text = dtGINNumber.Rows[0]["SupplierName"].ToString();
                    txtprintprojectcode.Text = dtGINNumber.Rows[0]["ProjectCode"].ToString();
                    txtprintvendorname.Text = dtGINNumber.Rows[0]["VendorCode"].ToString();
                    txtprintprojectname.Text = dtGINNumber.Rows[0]["ProjectDescription"].ToString();
                }
            }



            //DataTable dtginTax = new DataTable();
            //dtginTax = DAL.fnGINTaxDetails(cmbprintginnumber.Text, null).Tables[0];

            //if (dtginTax.Rows.Count > 0)
            //{
            //    txtnet.Text = dtginTax.Rows[0]["NetAmount"].ToString();
            //    txtpaking.Text = dtginTax.Rows[0]["PackingForwording"].ToString();
            //    txtdis.Text = dtginTax.Rows[0]["Discount"].ToString();
            //    txtdis_per.Text = dtginTax.Rows[0]["Discount_per"].ToString();
            //    txtdis_per.Text = Math.Round(Convert.ToDouble(txtdis_per.Text), 2).ToString();
            //    txtafterdis.Text = dtginTax.Rows[0]["afterdicountamount"].ToString();
            //    txtexise.Text = dtginTax.Rows[0]["ExciseDuty"].ToString();
            //    txtexise_per1.Text = dtginTax.Rows[0]["ExciseDuty_per"].ToString();
            //    txtexise_per1.Text = Math.Round(Convert.ToDouble(txtexise_per1.Text), 2).ToString();
            //    txtcst.Text = dtginTax.Rows[0]["CST"].ToString();
            //    txtcst_per.Text = dtginTax.Rows[0]["CST_per"].ToString();
            //    txtcst_per.Text = Math.Round(Convert.ToDouble(txtcst_per.Text), 2).ToString();
            //    txtvat.Text = dtginTax.Rows[0]["VATServiceTax"].ToString();
            //    txtvat_per.Text = dtginTax.Rows[0]["VATServiceTax_per"].ToString();
            //    txtvat_per.Text = Math.Round(Convert.ToDouble(txtvat_per.Text), 2).ToString();
            //    txtother.Text = dtginTax.Rows[0]["Others"].ToString();
            //    txtfinalnet.Text = dtginTax.Rows[0]["FinalNetAmount"].ToString();
            //}
        }


        int currentRowIndex;

        private void dgvprintpreview_CellClick_old(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0 && dgvprintpreview.Columns[e.ColumnIndex] is DataGridViewButtonColumn)
            {
                currentRowIndex = e.RowIndex;
                MessageBox.Show(currentRowIndex.ToString());
                string printCount = dgvprintpreview.Rows[e.RowIndex].Cells["printCount"].Value?.ToString() ?? "";
                MessageBox.Show($"Index : {currentRowIndex} & print Count :{printCount}", "Print count");


                //  if (dgBOMIndent.CurrentCell.OwningColumn.Name == "pickUpLocation1")
                //{
                //  var editedValue = dgBOMIndent.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;
                //  MessageBox.Show("pickUpLocation1", editedValue.ToString());
                //}
            }
        }




        private void dgvprintpreview_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //MessageBox.Show("message!");
            if (e.RowIndex >= 0 && dgvprintpreview.Columns[e.ColumnIndex] is DataGridViewButtonColumn)
            {
                dgvprintpreview.EndEdit();

                currentRowIndex = e.RowIndex;
                string printCount = dgvprintpreview.Rows[e.RowIndex].Cells["printCount"].Value?.ToString() ?? "";

                MessageBox.Show($"Index : {currentRowIndex} & print Count : {printCount}", "Print count");


                // MessageBox.Show(dgvprintpreview.Rows[e.RowIndex].Cells["ItemCode"].Value?.ToString(),
                //dgvprintpreview.Rows[e.RowIndex].Cells["SupplyQty"].Value?.ToString());
                //MessageBox.Show(dgvprintpreview.Rows[e.RowIndex].Cells["printCount"].Value?.ToString(),
                //  cmbprintginnumber.Text);

                DataTable ERPInventoryGINDeatils = DAL.getERPInventoryGINDeatils(dgvprintpreview.Rows[e.RowIndex].Cells["ItemCode"].Value?.ToString(), cmbprintginnumber.Text, null).Tables[0];


                foreach (DataRow data in ERPInventoryGINDeatils.Rows)
                {
                    MessageBox.Show(data["BatchCode"].ToString(), "batch Code!");
                    MessageBox.Show(data["ItemLocation"].ToString(), "Location!");
                }


            }
        }



        //BatchCodeDataList.Add(new Dictionary<string, string>
        // {
        //{ "QrValue", "HYD-BOS-000006110920251653" },
        //{ "ItemCode", "HYD-BOS-000006" },
        //{ "VendorCode", "TSC TTP-345" },
        //{ "BatchCode", "110920251653" },
        //{ "Count", "400" }
        //});








        public void GeneratePdfFromListlast(object sender, DataGridViewCellEventArgs e)
        {
            var dataList = new List<Dictionary<string, string>>
    {
        new Dictionary<string, string>
        {
            { "QrValue", "HYD-BOS-000002110920251649" },
            { "ItemCode", "HYD-BOS-000002" },
            { "VendorCode", "TSC TTP-345" },
            { "BatchCode", "110920251649" },
            { "Count", "100" }
        },
        new Dictionary<string, string>
        {
            { "QrValue", "HYD-BOS-000003110920251650" },
            { "ItemCode", "HYD-BOS-000003" },
            { "VendorCode", "TSC TTP-345" },
            { "BatchCode", "110920251650" },
            { "Count", "200" }
        },
        new Dictionary<string, string>
        {
            { "QrValue", "HYD-BOS-000004110920251651" },
            { "ItemCode", "HYD-BOS-000004" },
            { "VendorCode", "TSC TTP-345" },
            { "BatchCode", "110920251651" },
            { "Count", "300" }
        }
    };

            string outputPath = $"Labels_{DateTime.Now:ddMMyyyyHHmm}.pdf";

            // Custom page size: 10 cm x 2.5 cm
            iTextSharp.text.Rectangle customSize = new iTextSharp.text.Rectangle(
                Utilities.MillimetersToPoints(100), // width
                Utilities.MillimetersToPoints(25)   // height
            );

            using (FileStream fs = new FileStream(outputPath, FileMode.Create, FileAccess.Write, FileShare.None))
            using (Document doc = new Document(customSize, 20, 2, 2, 2))
            using (PdfWriter writer = PdfWriter.GetInstance(doc, fs))
            {
                doc.Open();

                // Main table with 2 columns for two labels per page
                PdfPTable mainTable = new PdfPTable(2);
                mainTable.WidthPercentage = 100;
                mainTable.SetWidths(new float[] { 1f, 1f });


                foreach (var data in dataList)
                {
                    // Generate QR Code
                    QRCodeGenerator qrGenerator = new QRCodeGenerator();
                    QRCodeData qrCodeData = qrGenerator.CreateQrCode(data["QrValue"], QRCodeGenerator.ECCLevel.Q);
                    QRCode qrCode = new QRCode(qrCodeData);
                    Bitmap qrCodeImage = qrCode.GetGraphic(2);

                    iTextSharp.text.Image qrImg;
                    using (MemoryStream ms = new MemoryStream())
                    {
                        qrCodeImage.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                        qrImg = iTextSharp.text.Image.GetInstance(ms.ToArray());
                        qrImg.ScaleAbsolute(45f, 45f);
                    }

                    // Inner table for label
                    PdfPTable labelTable = new PdfPTable(2);
                    labelTable.WidthPercentage = 100;
                    labelTable.SetWidths(new float[] { 1f, 2f });

                    PdfPCell qrCell = new PdfPCell(qrImg);
                    qrCell.Border = Rectangle.NO_BORDER;
                    qrCell.HorizontalAlignment = Element.ALIGN_CENTER;
                    qrCell.VerticalAlignment = Element.ALIGN_MIDDLE;
                    labelTable.AddCell(qrCell);

                    PdfPCell textCell = new PdfPCell();
                    //textCell.PaddingTop = 10f;
                    textCell.Border = Rectangle.NO_BORDER;
                    textCell.PaddingLeft = 3;
                    textCell.AddElement(new Paragraph(data["ItemCode"], FontFactory.GetFont("Arial", 8, iTextSharp.text.Font.BOLD)));
                    textCell.AddElement(new Paragraph($"BNO: {data["BatchCode"]}", FontFactory.GetFont("Arial", 7)));
                    textCell.AddElement(new Paragraph($"Qty: {data["Count"]}", FontFactory.GetFont("Arial", 7)));
                    textCell.AddElement(new Paragraph(data["VendorCode"], FontFactory.GetFont("Arial", 7)));
                    labelTable.AddCell(textCell);

                    PdfPCell mainCell = new PdfPCell(labelTable);
                    mainCell.PaddingTop = 10f;
                    mainCell.PaddingLeft = 5f;
                    mainCell.Border = Rectangle.NO_BORDER;
                    mainTable.AddCell(mainCell);

                }

                // If odd number of labels, add empty cell
                if (dataList.Count % 2 != 0)
                {
                    PdfPCell emptyCell = new PdfPCell(new Phrase(""));
                    emptyCell.Border = Rectangle.NO_BORDER;
                    mainTable.AddCell(emptyCell);
                }

                doc.Add(mainTable);
                doc.Close();
            }

            MessageBox.Show($"PDF generated successfully at: {outputPath}");
        }





        public void GeneratePdfFromListworkingcodewithonepage(object sender, DataGridViewCellEventArgs e)
        {
            var dataList = new List<Dictionary<string, string>>
    {
        new Dictionary<string, string>
        {
            { "QrValue", "HYD-BOS-000002110920251649" },
            { "ItemCode", "HYD-BOS-000002" },
            { "VendorCode", "TSC TTP-345" },
            { "BatchCode", "110920251649" },
            { "Count", "100" }
        },
        new Dictionary<string, string>
        {
            { "QrValue", "HYD-BOS-000003110920251650" },
            { "ItemCode", "HYD-BOS-000003" },
            { "VendorCode", "TSC TTP-345" },
            { "BatchCode", "110920251650" },
            { "Count", "200" }
        },
        new Dictionary<string, string>
        {
            { "QrValue", "HYD-BOS-000004110920251651" },
            { "ItemCode", "HYD-BOS-000004" },
            { "VendorCode", "TSC TTP-345" },
            { "BatchCode", "110920251651" },
            { "Count", "300" }
        }
    };

            string outputPath = $"Labels_{DateTime.Now:ddMMyyyyHHmm}.pdf";

            // Custom page size: 10 cm x 2.5 cm
            iTextSharp.text.Rectangle customSize = new iTextSharp.text.Rectangle(
            Utilities.MillimetersToPoints(50), // width
            Utilities.MillimetersToPoints(25)   // height
        );

            using (FileStream fs = new FileStream(outputPath, FileMode.Create, FileAccess.Write, FileShare.None))
            using (Document doc = new Document(customSize, 2, 2, 2, 2)) // small margins
            using (PdfWriter writer = PdfWriter.GetInstance(doc, fs))
            {
                doc.Open();

                foreach (var data in dataList)
                {
                    // Generate QR Code
                    QRCodeGenerator qrGenerator = new QRCodeGenerator();
                    QRCodeData qrCodeData = qrGenerator.CreateQrCode(data["QrValue"], QRCodeGenerator.ECCLevel.Q);
                    QRCode qrCode = new QRCode(qrCodeData);
                    Bitmap qrCodeImage = qrCode.GetGraphic(2);

                    iTextSharp.text.Image qrImg;
                    using (MemoryStream ms = new MemoryStream())
                    {
                        qrCodeImage.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                        qrImg = iTextSharp.text.Image.GetInstance(ms.ToArray());
                        qrImg.ScaleAbsolute(20f, 20f); // smaller QR
                    }

                    // Table for label
                    PdfPTable labelTable = new PdfPTable(2);
                    labelTable.WidthPercentage = 100;
                    labelTable.SetWidths(new float[] { 1f, 2f });

                    PdfPCell qrCell = new PdfPCell(qrImg);
                    qrCell.Border = iTextSharp.text.Rectangle.NO_BORDER;
                    qrCell.HorizontalAlignment = Element.ALIGN_CENTER;
                    qrCell.VerticalAlignment = Element.ALIGN_MIDDLE;
                    labelTable.AddCell(qrCell);

                    PdfPCell textCell = new PdfPCell();
                    textCell.Border = iTextSharp.text.Rectangle.NO_BORDER;
                    textCell.PaddingLeft = 2;
                    textCell.AddElement(new Paragraph(data["ItemCode"], FontFactory.GetFont("Arial", 6)));
                    textCell.AddElement(new Paragraph($"BNO: {data["BatchCode"]}", FontFactory.GetFont("Arial", 6)));
                    textCell.AddElement(new Paragraph($"Qty: {data["Count"]}", FontFactory.GetFont("Arial", 6)));
                    textCell.AddElement(new Paragraph(data["VendorCode"], FontFactory.GetFont("Arial", 6)));
                    labelTable.AddCell(textCell);

                    doc.Add(labelTable);
                    doc.NewPage(); // Each label on a new page
                }

                doc.Close();
            }

            MessageBox.Show($"PDF generated successfully at: {outputPath}");
        }

        public void GeneratePdfFromListnew(object sender, DataGridViewCellEventArgs e)
        {
            var dataList = new List<Dictionary<string, string>>
    {
        new Dictionary<string, string>
        {
            { "QrValue", "HYD-BOS-000002110920251649" },
            { "ItemCode", "HYD-BOS-000002" },
            { "VendorCode", "TSC TTP-345" },
            { "BatchCode", "110920251649" },
            { "Count", "100" }
        },
        new Dictionary<string, string>
        {
            { "QrValue", "HYD-BOS-000003110920251650" },
            { "ItemCode", "HYD-BOS-000003" },
            { "VendorCode", "TSC TTP-345" },
            { "BatchCode", "110920251650" },
            { "Count", "200" }
        },
        new Dictionary<string, string>
        {
            { "QrValue", "HYD-BOS-000004110920251651" },
            { "ItemCode", "HYD-BOS-000004" },
            { "VendorCode", "TSC TTP-345" },
            { "BatchCode", "110920251651" },
            { "Count", "300" }
        }
    };

            string outputPath = $"Labels_{DateTime.Now:ddMMyyyyHHmm}.pdf";

            // Custom page size: 10 cm x 2.5 cm
            iTextSharp.text.Rectangle customSize = new iTextSharp.text.Rectangle(
            Utilities.MillimetersToPoints(100), // 10 cm = 100 mm
            Utilities.MillimetersToPoints(25)   // 2.5 cm = 25 mm
        );

            using (FileStream fs = new FileStream(outputPath, FileMode.Create, FileAccess.Write, FileShare.None))
            using (Document doc = new Document(customSize))
            using (PdfWriter writer = PdfWriter.GetInstance(doc, fs))
            {
                doc.Open();

                foreach (var data in dataList)
                {
                    // Generate QR Code
                    QRCodeGenerator qrGenerator = new QRCodeGenerator();
                    QRCodeData qrCodeData = qrGenerator.CreateQrCode(data["QrValue"], QRCodeGenerator.ECCLevel.Q);
                    QRCode qrCode = new QRCode(qrCodeData);
                    Bitmap qrCodeImage = qrCode.GetGraphic(2);

                    iTextSharp.text.Image qrImg;
                    using (MemoryStream ms = new MemoryStream())
                    {
                        qrCodeImage.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                        qrImg = iTextSharp.text.Image.GetInstance(ms.ToArray());
                        qrImg.ScaleAbsolute(40f, 40f); // Adjust QR size for small page
                    }

                    // Create a table for label layout
                    PdfPTable labelTable = new PdfPTable(2);
                    labelTable.WidthPercentage = 100;
                    labelTable.SetWidths(new float[] { 1f, 2f });

                    PdfPCell qrCell = new PdfPCell(qrImg);
                    qrCell.Border = iTextSharp.text.Rectangle.NO_BORDER;
                    qrCell.HorizontalAlignment = Element.ALIGN_CENTER;
                    qrCell.VerticalAlignment = Element.ALIGN_MIDDLE;
                    labelTable.AddCell(qrCell);

                    PdfPCell textCell = new PdfPCell();
                    textCell.Border = iTextSharp.text.Rectangle.NO_BORDER;
                    textCell.PaddingLeft = 5;
                    textCell.AddElement(new Paragraph(data["ItemCode"], FontFactory.GetFont("Arial", 8)));
                    textCell.AddElement(new Paragraph($"BNO: {data["BatchCode"]}", FontFactory.GetFont("Arial", 7)));
                    textCell.AddElement(new Paragraph($"Qty: {data["Count"]}", FontFactory.GetFont("Arial", 7)));
                    textCell.AddElement(new Paragraph(data["VendorCode"], FontFactory.GetFont("Arial", 7)));
                    labelTable.AddCell(textCell);

                    doc.Add(labelTable);
                    doc.NewPage(); // Each label on a new page
                }

                doc.Close();
            }

            MessageBox.Show($"PDF generated successfully at: {outputPath}");
        }




        public void GeneratePdfFromListCrt(object sender, DataGridViewCellEventArgs e)
        {
            var dataList = new List<Dictionary<string, string>>
    {
        new Dictionary<string, string>
        {
            { "QrValue", "HYD-BOS-000002110920251649" },
            { "ItemCode", "HYD-BOS-000002" },
            { "VendorCode", "TSC TTP-345" },
            { "BatchCode", "110920251649" },
            { "Count", "100" }
        },
        new Dictionary<string, string>
        {
            { "QrValue", "HYD-BOS-000003110920251650" },
            { "ItemCode", "HYD-BOS-000003" },
            { "VendorCode", "TSC TTP-345" },
            { "BatchCode", "110920251650" },
            { "Count", "200" }
        },
        new Dictionary<string, string>
        {
            { "QrValue", "HYD-BOS-000004110920251651" },
            { "ItemCode", "HYD-BOS-000004" },
            { "VendorCode", "TSC TTP-345" },
            { "BatchCode", "110920251651" },
            { "Count", "300" }
        }
    };

            // string outputPath = "TwoColumnLabels.pdf";
            string outputPath = $"TwoColumnLabels{DateTime.Now.ToString("ddMMyyyyhhmm")}.pdf";


            using (FileStream fs = new FileStream(outputPath, FileMode.Create, FileAccess.Write, FileShare.None))
            using (Document doc = new Document(PageSize.A4)) // A4 for multiple labels
            using (PdfWriter writer = PdfWriter.GetInstance(doc, fs))
            {
                doc.Open();

                PdfPTable mainTable = new PdfPTable(2); // Two columns
                mainTable.WidthPercentage = 100;
                mainTable.SetWidths(new float[] { 1f, 1f });

                //Font fontBold = FontFactory.GetFont("Arial", 12, Font.BOLD);
                //Font fontNormal = FontFactory.GetFont("Arial", 11, Font.NORMAL);

                foreach (var data in dataList)
                {
                    // Generate QR Code
                    QRCodeGenerator qrGenerator = new QRCodeGenerator();
                    QRCodeData qrCodeData = qrGenerator.CreateQrCode(data["QrValue"], QRCodeGenerator.ECCLevel.Q);
                    QRCode qrCode = new QRCode(qrCodeData);
                    Bitmap qrCodeImage = qrCode.GetGraphic(2);

                    iTextSharp.text.Image qrImg;
                    using (MemoryStream ms = new MemoryStream())
                    {
                        qrCodeImage.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                        qrImg = iTextSharp.text.Image.GetInstance(ms.ToArray());
                        qrImg.ScaleAbsolute(60f, 60f);
                    }

                    // Inner table for label layout
                    PdfPTable labelTable = new PdfPTable(2);
                    labelTable.WidthPercentage = 100;
                    labelTable.SetWidths(new float[] { 1f, 2f });

                    PdfPCell qrCell = new PdfPCell(qrImg);
                    //qrCell.Border = Rectangle.NO_BORDER;
                    qrCell.HorizontalAlignment = Element.ALIGN_CENTER;
                    qrCell.VerticalAlignment = Element.ALIGN_MIDDLE;
                    labelTable.AddCell(qrCell);

                    PdfPCell textCell = new PdfPCell();
                    // textCell.Border = Rectangle.NO_BORDER;
                    textCell.PaddingLeft = 10;
                    textCell.AddElement(new Paragraph(data["ItemCode"]));
                    textCell.AddElement(new Paragraph($"BNO: {data["BatchCode"]}"));
                    textCell.AddElement(new Paragraph($"Qty: {data["Count"]}"));
                    textCell.AddElement(new Paragraph(data["VendorCode"]));
                    labelTable.AddCell(textCell);

                    PdfPCell mainCell = new PdfPCell(labelTable);
                    // mainCell.Border = Rectangle.NO_BORDER;
                    mainTable.AddCell(mainCell);
                }

                // Fill last cell if odd number of labels
                if (dataList.Count % 2 != 0)
                {
                    PdfPCell emptyCell = new PdfPCell(new Phrase(""));
                    //emptyCell.Border = Rectangle.NO_BORDER;
                    mainTable.AddCell(emptyCell);
                }

                doc.Add(mainTable);
                doc.Close();
            }
        }

        public void old1GeneratePdfFromList(object sender, DataGridViewCellEventArgs e)
        {
            var dataList = new List<Dictionary<string, string>>
    {
        new Dictionary<string, string>
        {
            { "QrValue", "HYD-BOS-000002110920251649" },
            { "ItemCode", "HYD-BOS-000002" },
            { "VendorCode", "TSC TTP-345" },
            { "BatchCode", "110920251649" },
            { "Count", "100" }
        },
        new Dictionary<string, string>
        {
            { "QrValue", "HYD-BOS-000003110920251650" },
            { "ItemCode", "HYD-BOS-000003" },
            { "VendorCode", "TSC TTP-345" },
            { "BatchCode", "110920251650" },
            { "Count", "200" }
        }
    };

            string outputPath = "WordStyleLabels.pdf";

            // Custom label size similar to Word layout
            using (FileStream fs = new FileStream(outputPath, FileMode.Create, FileAccess.Write, FileShare.None))
            using (Document doc = new Document(new iTextSharp.text.Rectangle(394, 197))) // Matches approx Word label size
            using (PdfWriter writer = PdfWriter.GetInstance(doc, fs))
            {
                doc.Open();

                foreach (var data in dataList)
                {
                    // Generate QR Code
                    QRCodeGenerator qrGenerator = new QRCodeGenerator();
                    QRCodeData qrCodeData = qrGenerator.CreateQrCode(data["QrValue"], QRCodeGenerator.ECCLevel.Q);
                    QRCode qrCode = new QRCode(qrCodeData);
                    Bitmap qrCodeImage = qrCode.GetGraphic(2);

                    // Convert Bitmap to iTextSharp Image
                    iTextSharp.text.Image qrImg;
                    using (MemoryStream ms = new MemoryStream())
                    {
                        qrCodeImage.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                        qrImg = iTextSharp.text.Image.GetInstance(ms.ToArray());
                        qrImg.ScaleAbsolute(80f, 80f); // Adjust size
                    }

                    // Create table for layout
                    PdfPTable table = new PdfPTable(2);
                    table.WidthPercentage = 100;
                    table.SetWidths(new float[] { 1f, 2f });

                    PdfPCell qrCell = new PdfPCell(qrImg);
                    //qrCell.Border = Rectangle.NO_BORDER;
                    qrCell.HorizontalAlignment = Element.ALIGN_CENTER;
                    qrCell.VerticalAlignment = Element.ALIGN_MIDDLE;
                    table.AddCell(qrCell);

                    PdfPCell textCell = new PdfPCell();
                    //textCell.Border = Rectangle.NO_BORDER;
                    textCell.PaddingLeft = 10;

                    //Font fontBold = FontFactory.GetFont("Arial", 12, Font.BOLD);
                    //Font fontNormal = FontFactory.GetFont("Arial", 11, Font.NORMAL);

                    textCell.AddElement(new Paragraph(data["ItemCode"]));
                    textCell.AddElement(new Paragraph($"BNO: {data["BatchCode"]}"));
                    textCell.AddElement(new Paragraph($"Qty: {data["Count"]}"));

                    table.AddCell(textCell);

                    doc.Add(table);
                    doc.NewPage();
                }

                doc.Close();
            }
        }
        public void oldGeneratePdfFromList(object sender, DataGridViewCellEventArgs e)
        {
            // Prepare your dynamic data list
            var dataList = new List<Dictionary<string, string>>
        {
        new Dictionary<string, string>
        {
            { "QrValue", "HYD-BOS-000002110920251649" },
            { "ItemCode", "HYD-BOS-000002" },
            { "VendorCode", "TSC TTP-345" },
            { "BatchCode", "110920251649" },
            { "Count", "100" }
        },
        new Dictionary<string, string>
        {
            { "QrValue", "HYD-BOS-000003110920251650" },
            { "ItemCode", "HYD-BOS-000003" },
            { "VendorCode", "TSC TTP-345" },
            { "BatchCode", "110920251650" },
            { "Count", "200" }
        }
    };

            string outputPath = "Labels.pdf";

            using (FileStream fs = new FileStream(outputPath, FileMode.Create, FileAccess.Write, FileShare.None))
            using (Document doc = new Document(PageSize.A6)) // Adjust size as needed
            using (PdfWriter writer = PdfWriter.GetInstance(doc, fs))
            {
                doc.Open();

                foreach (var data in dataList)
                {
                    // Generate QR Code
                    QRCodeGenerator qrGenerator = new QRCodeGenerator();
                    QRCodeData qrCodeData = qrGenerator.CreateQrCode(data["QrValue"], QRCodeGenerator.ECCLevel.Q);
                    QRCode qrCode = new QRCode(qrCodeData);
                    Bitmap qrCodeImage = qrCode.GetGraphic(2);

                    // Convert Bitmap to iTextSharp Image
                    using (MemoryStream ms = new MemoryStream())
                    {
                        qrCodeImage.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                        iTextSharp.text.Image qrImg = iTextSharp.text.Image.GetInstance(ms.ToArray());
                        qrImg.ScaleAbsolute(80f, 80f); // Adjust size
                        doc.Add(qrImg);
                    }

                    // Add Text
                    doc.Add(new Paragraph(data["ItemCode"]));
                    doc.Add(new Paragraph($"{data["BatchCode"]}  {data["Count"]}"));
                    doc.Add(new Paragraph(data["VendorCode"]));

                    doc.NewPage(); // For next label
                }

                doc.Close();
            }
        }








        #endregion
        #region GIN Number Report
        private void btnprintgin_Click(object sender, EventArgs e)
        {
            DataTable dtAdvancedReciept = new DataTable();
            DataTable dtPODetails = new DataTable();
            DataTable dtVendoAddress = new DataTable();
            dtAdvancedReciept = DAL.fnAdvancedReceipt(cmbprintginnumber.Text, null, sWOPO).Tables[0];
            dtPODetails = DAL.fnAdvancedReceipt(null, dtGINNumber.Rows[0]["RefNumber"].ToString(), sWOPO).Tables[0];
            dtVendoAddress = DAL.fnVedorList(dtGINNumber.Rows[0]["VendorCode"].ToString()).Tables[0];
            int iRowIndex = 1;
            int k = 1;
            string ExcelFolderPath;
            string FileFullPath;
            EXCEL.Workbook NewWorkBook;
            EXCEL.Worksheet NewWorkSheet;
            EXCEL.Application ExcelApp;
            EXCEL.Range CELLS, cell1, cell2;
            object misValue;
            Cursor.Current = Cursors.WaitCursor;
            if (dtGINNumber.Rows.Count > 0)
            {
                // This returns something like C:\Users\Username:
                string userRoot = System.Environment.GetEnvironmentVariable("USERPROFILE");
                // Now let's get C:\Users\Username\Downloads:
                string downloadFolder = Path.Combine(userRoot, "Downloads");
                ExcelFolderPath = downloadFolder + @"\Print GIN\";
                FileFullPath = ExcelFolderPath + cmbprintginnumber.Text + "-" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + "";
                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);


                ExcelApp = new EXCEL.Application();
                misValue = System.Reflection.Missing.Value;
                try
                {
                    if (ExcelApp == null)
                        MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                    NewWorkBook = ExcelApp.Workbooks.Add(misValue);

                    NewWorkBook.SaveAs(FileFullPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                    Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                    NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                    if (NewWorkSheet == null)
                        MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                    else
                        NewWorkSheet.Name = "Project GIN";
                    // Select the Excel cells, in the range c1 to c7 in the worksheet for cell access check.
                    EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                    if (RANGE == null)
                        MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                    // NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    //ExcelApp.Visible = true;
                    CELLS = NewWorkSheet.Cells;

                    string[] Text ={"",
                                Global.sCompanyName,
                                "NO.497E, 14th Cross, 4th Phase, Peenya Industrial Area,",
                                "Bangalore-560 058, Karnataka,  India. ",
                                "Phone:91(080) 28360184. FAX: (080) 28360047."};

                    foreach (string str in Text)
                    {
                        NewWorkSheet.Cells[iRowIndex, 1] = str;
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);
                        iRowIndex++;
                    }

                    NewWorkSheet.Cells[iRowIndex, 1] = "GOODS INWARD NOTE REPORT";
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 15);
                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Document Number :";
                    NewWorkSheet.Cells[iRowIndex, 2] = cmbprintginnumber.Text;
                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Document Date :";
                    NewWorkSheet.Cells[iRowIndex, 2] = dtGINNumber.Rows[0]["GINDate"].ToString();
                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "PO Number :";
                    NewWorkSheet.Cells[iRowIndex, 2] = dtGINNumber.Rows[0]["RefNumber"].ToString();
                    NewWorkSheet.Cells[iRowIndex, 3] = "Invoice No:";
                    NewWorkSheet.Cells[iRowIndex, 4] = dtGINNumber.Rows[0]["Invoice No"].ToString();
                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "PO Date :";
                    NewWorkSheet.Cells[iRowIndex, 2] = dtGINNumber.Rows[0]["PODate"].ToString();
                    NewWorkSheet.Cells[iRowIndex, 3] = "Invoice Date :";
                    NewWorkSheet.Cells[iRowIndex, 4] = dtGINNumber.Rows[0]["InvoiceDate"].ToString();
                    iRowIndex++;
                    iRowIndex++;
                    if (dtPODetails.Rows.Count > 0)
                    {
                        iRowIndex--;
                        NewWorkSheet.Cells[iRowIndex, 1] = "Nature of Transaction :";
                        NewWorkSheet.Cells[iRowIndex, 2] = dtPODetails.Rows[0]["NatureofTransaction"].ToString();
                        iRowIndex++;
                    }
                    NewWorkSheet.Cells[iRowIndex, 1] = "Customer Type :";
                    NewWorkSheet.Cells[iRowIndex, 2] = "Registered";
                    iRowIndex++;
                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Received from";
                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Name :";
                    NewWorkSheet.Cells[iRowIndex, 2] = dtGINNumber.Rows[0]["SupplierName"].ToString();
                    iRowIndex++;


                    NewWorkSheet.Cells[iRowIndex, 1] = "Address :";
                    NewWorkSheet.Cells[iRowIndex, 2] = dtVendoAddress.Rows[0]["Address1"].ToString();
                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 2] = dtVendoAddress.Rows[0]["Address2"].ToString();
                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 2] = dtVendoAddress.Rows[0]["Address3"].ToString();
                    iRowIndex++;
                    if (dtPODetails.Rows.Count > 0)
                    {

                        NewWorkSheet.Cells[iRowIndex, 1] = "State Code :";
                        NewWorkSheet.Cells[iRowIndex, 2] = dtPODetails.Rows[0]["ShippedStateCode"].ToString();

                        iRowIndex++;
                        NewWorkSheet.Cells[iRowIndex, 1] = "GSTIN:";
                        NewWorkSheet.Cells[iRowIndex, 2] = dtPODetails.Rows[0]["ShippedGSTIN"].ToString();
                    }
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 4, 6);
                    iRowIndex++;

                    NewWorkSheet.Range["A1:B1"].Cells.Font.Size = 16;
                    NewWorkSheet.Range["A1:B1"].Cells.Font.Bold = 16;

                    NewWorkSheet.Range["A6:B6"].Cells.Font.Size = 16;
                    NewWorkSheet.Range["A6:B6"].Cells.Font.Bold = true;
                    NewWorkSheet.Range["A6:B6"].Cells.Font.Color = Color.Red;
                    //Insert Text to the worksheet
                    //      iRowIndex++;

                    iRowIndex++;


                    string finalColLetter = string.Empty;
                    int j = 23;
                    if (dtAdvancedReciept.Rows.Count > 0)
                    {
                        object[,] rawData = new object[dtAdvancedReciept.Rows.Count + 1, dtAdvancedReciept.Columns.Count];
                        for (int col = 0; col < dtAdvancedReciept.Columns.Count; col++)
                        {
                            rawData[0, col] = dtAdvancedReciept.Columns[col].ColumnName;
                        }
                        for (int row = 0; row < dtAdvancedReciept.Rows.Count; row++)
                        {
                            for (int col = 0; col < dtAdvancedReciept.Columns.Count; col++)
                            {
                                rawData[row + 1, col] = dtAdvancedReciept.Rows[row].ItemArray[col];
                            }
                        }

                        string excelRange = string.Empty;
                        finalColLetter = string.Empty;
                        string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        int colCharsetLen = colCharset.Length;

                        if (dtAdvancedReciept.Columns.Count > colCharsetLen)
                        {
                            finalColLetter = colCharset.Substring(
                                (dtAdvancedReciept.Columns.Count - 1) / colCharsetLen - 1, 1);
                        }
                        //  j = j + 2;
                        finalColLetter += colCharset.Substring(
                                (dtAdvancedReciept.Columns.Count - 1) % colCharsetLen, 1);
                        excelRange = string.Format("A23:{0}{1}", finalColLetter, dtAdvancedReciept.Rows.Count + j);


                        NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                    }


                    if (sWOPO == "PO")
                    {
                        CellMerge("BorderAround", NewWorkSheet, 22, 22, 1, 16);
                        NewWorkSheet.Cells[22, 8] = "Discount";
                        CellMerge("Merge", NewWorkSheet, 22, 22, 8, 9);
                        CellMerge("BorderAround", NewWorkSheet, 22, 22, 8, 9);
                        NewWorkSheet.Cells[23, 8] = "%";
                        NewWorkSheet.Cells[23, 9] = "Amt";
                        NewWorkSheet.Cells[22, 11] = "CGST";
                        CellMerge("Merge", NewWorkSheet, 22, 22, 11, 12);
                        CellMerge("BorderAround", NewWorkSheet, 22, 22, 11, 12);
                        NewWorkSheet.Cells[23, 11] = "%";
                        NewWorkSheet.Cells[23, 12] = "Amt";
                        NewWorkSheet.Cells[22, 13] = "SGST";
                        CellMerge("Merge", NewWorkSheet, 22, 22, 13, 14);
                        CellMerge("BorderAround", NewWorkSheet, 22, 22, 13, 14);
                        NewWorkSheet.Cells[23, 13] = "%";
                        NewWorkSheet.Cells[23, 14] = "Amt";
                        NewWorkSheet.Cells[22, 15] = "IGST";
                        CellMerge("Merge", NewWorkSheet, 22, 22, 15, 16);
                        CellMerge("BorderAround", NewWorkSheet, 22, 22, 15, 16);
                        NewWorkSheet.Cells[23, 15] = "%";
                        NewWorkSheet.Cells[23, 16] = "Amt";
                    }

                    else
                    {

                        NewWorkSheet.Cells[22, 8] = "SGST";
                        CellMerge("Merge", NewWorkSheet, 22, 22, 8, 9);
                        CellMerge("BorderAround", NewWorkSheet, 22, 22, 8, 9);
                        NewWorkSheet.Cells[23, 8] = "%";
                        NewWorkSheet.Cells[23, 9] = "Amt";

                        NewWorkSheet.Cells[22, 10] = "CGST";
                        CellMerge("Merge", NewWorkSheet, 22, 22, 10, 11);
                        CellMerge("BorderAround", NewWorkSheet, 22, 22, 10, 11);
                        NewWorkSheet.Cells[23, 10] = "%";
                        NewWorkSheet.Cells[23, 11] = "Amt";

                        NewWorkSheet.Cells[22, 12] = "IGST";
                        CellMerge("Merge", NewWorkSheet, 22, 22, 12, 13);
                        CellMerge("BorderAround", NewWorkSheet, 22, 22, 12, 13);
                        NewWorkSheet.Cells[23, 12] = "%";
                        NewWorkSheet.Cells[23, 13] = "Amt";
                    }
                    CellMerge("GridLines", NewWorkSheet, 23, (25 + dtAdvancedReciept.Rows.Count), 1, 16);
                    CellMerge("BorderAround", NewWorkSheet, 1, 6, 1, 16);
                    CellMerge("BorderAround", NewWorkSheet, 7, 12, 1, 16);
                    CellMerge("BorderAround", NewWorkSheet, 14, 20, 1, 16);
                    CellMerge("BorderAround", NewWorkSheet, 23, 23, 1, 16);
                    NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 2] = "Packing & Forwarding";
                    DataTable dtPackingForwarding = DAL.fnPOPackingGST(cmbprintginnumber.Text, "Packing & Forwarding").Tables[0];
                    double Packing = 0;
                    double PIGST = 0;
                    double PSGST = 0;
                    double PCGST = 0;
                    if (dtPackingForwarding.Rows.Count > 0)
                    {
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 7] = dtPackingForwarding.Rows[0]["Amount"].ToString();
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 8] = 0;
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 9] = 0;
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 10] = dtPackingForwarding.Rows[0]["Amount"].ToString();
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 11] = dtPackingForwarding.Rows[0]["SGSTRate"].ToString();
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 12] = dtPackingForwarding.Rows[0]["SGSTAmount"].ToString();
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 13] = dtPackingForwarding.Rows[0]["CGSTRate"].ToString();
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 14] = dtPackingForwarding.Rows[0]["CGSTAmount"].ToString();
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 15] = dtPackingForwarding.Rows[0]["IGSTRate"].ToString();
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 16] = dtPackingForwarding.Rows[0]["IGSTAmount"].ToString();
                        Packing = Convert.ToDouble(dtPackingForwarding.Rows[0]["Amount"].ToString());
                        PIGST = Convert.ToDouble(dtPackingForwarding.Rows[0]["IGSTAmount"].ToString());
                        PSGST = Convert.ToDouble(dtPackingForwarding.Rows[0]["SGSTAmount"].ToString());
                        PCGST = Convert.ToDouble(dtPackingForwarding.Rows[0]["CGSTAmount"].ToString());
                    }
                    else
                    {
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 6] = 0;
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 7] = 0;
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 8] = 0;
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 9] = 0;
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 10] = 0;
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 11] = 0;
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 12] = 0;
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 13] = 0;
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 14] = 0;
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 15] = 0;
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 16] = 0;
                    }
                    NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 2] = "Transportation / Freight";

                    dtPackingForwarding = DAL.fnPOPackingGST(cmbprintginnumber.Text, "Transportation / Freight").Tables[0];
                    double freight = 0;
                    double TIGST = 0;
                    double TSGST = 0;
                    double TCGST = 0;
                    if (dtPackingForwarding.Rows.Count > 0)
                    {
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 7] = dtPackingForwarding.Rows[0]["Amount"].ToString();
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 8] = 0;
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 9] = 0;
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 10] = dtPackingForwarding.Rows[0]["Amount"].ToString();
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 11] = dtPackingForwarding.Rows[0]["SGSTRate"].ToString();
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 12] = dtPackingForwarding.Rows[0]["SGSTAmount"].ToString();
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 13] = dtPackingForwarding.Rows[0]["CGSTRate"].ToString();
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 14] = dtPackingForwarding.Rows[0]["CGSTAmount"].ToString();
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 15] = dtPackingForwarding.Rows[0]["IGSTRate"].ToString();
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 16] = dtPackingForwarding.Rows[0]["IGSTAmount"].ToString();
                        freight = Convert.ToDouble(dtPackingForwarding.Rows[0]["Amount"].ToString());
                        TIGST = Convert.ToDouble(dtPackingForwarding.Rows[0]["IGSTAmount"].ToString());
                        TSGST = Convert.ToDouble(dtPackingForwarding.Rows[0]["SGSTAmount"].ToString());
                        TCGST = Convert.ToDouble(dtPackingForwarding.Rows[0]["CGSTAmount"].ToString());
                    }
                    else
                    {
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 7] = 0;
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 8] = 0;
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 9] = 0;
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 10] = 0;
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 11] = 0;
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 12] = 0;
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 13] = 0;
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 14] = 0;
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 15] = 0;
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 16] = 0;
                    }
                    string Text42;
                    if (sWOPO == "PO")
                    {
                        Text42 = "" + string.Format(india, "{0:c}", (Convert.ToDouble(dtAdvancedReciept.Compute("Sum(Amount)", "").ToString()) - Convert.ToDouble(dtAdvancedReciept.Compute("Sum(DiscAmount)", "").ToString()) + Convert.ToDouble(dtAdvancedReciept.Compute("Sum(IGSTAmount)", "").ToString()) + Convert.ToDouble(dtAdvancedReciept.Compute("Sum(SGSTAmount)", "").ToString()) + Convert.ToDouble(dtAdvancedReciept.Compute("Sum(CGSTAmount)", "").ToString()) + freight + Packing + PIGST + PSGST + PCGST + TIGST + TSGST + TCGST)) + "";
                    }
                    else
                    {
                        Text42 = "" + string.Format(india, "{0:c}", (Convert.ToDouble(dtAdvancedReciept.Compute("Sum(Amount)", "").ToString()) + Convert.ToDouble(dtAdvancedReciept.Compute("Sum(IGSTAmount)", "").ToString()) + Convert.ToDouble(dtAdvancedReciept.Compute("Sum(SGSTAmount)", "").ToString()) + Convert.ToDouble(dtAdvancedReciept.Compute("Sum(CGSTAmount)", "").ToString()) + freight + Packing + PIGST + PSGST + PCGST + TIGST + TSGST + TCGST)) + "";
                    }

                    NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count + 1, 6] = "Sub Total";
                    NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count + 1, 7] = "" + (Convert.ToDouble(dtAdvancedReciept.Compute("Sum(Amount)", "").ToString()) + Packing + freight) + "";
                    if (sWOPO == "PO")
                    {
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count + 1, 9] = "" + (Convert.ToDouble(dtAdvancedReciept.Compute("Sum(DiscAmount)", "").ToString())) + "";
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count + 1, 10] = "" + (Convert.ToDouble(dtAdvancedReciept.Compute("Sum(Amount)", "").ToString()) + Packing + freight - (Convert.ToDouble(dtAdvancedReciept.Compute("Sum(DiscAmount)", "").ToString()))) + "";
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count + 1, 12] = "" + (Convert.ToDouble(dtAdvancedReciept.Compute("Sum(SGSTAmount)", "").ToString()) + PSGST + TSGST) + "";
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count + 1, 14] = "" + (Convert.ToDouble(dtAdvancedReciept.Compute("Sum(CGSTAmount)", "").ToString()) + PCGST + TCGST) + "";
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count + 1, 16] = "" + (Convert.ToDouble(dtAdvancedReciept.Compute("Sum(IGSTAmount)", "").ToString()) + PIGST + TIGST) + "";
                    }

                    else
                    {
                        //  NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count + 1, 8] = "" + string.Format(india, "{0:c}", (Convert.ToDouble(0))) + "";
                        //  NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count + 1, 9] = "" + string.Format(india, "{0:c}", (Convert.ToDouble(dtAdvancedReciept.Compute("Sum(Amount)", "").ToString()) + Packing + freight)) + "";
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count + 1, 10] = "" + (Convert.ToDouble(dtAdvancedReciept.Compute("Sum(SGSTAmount)", "").ToString()) + PSGST + TSGST) + "";
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count + 1, 12] = "" + (Convert.ToDouble(dtAdvancedReciept.Compute("Sum(CGSTAmount)", "").ToString()) + PCGST + TCGST) + "";
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count + 1, 14] = "" + (Convert.ToDouble(dtAdvancedReciept.Compute("Sum(IGSTAmount)", "").ToString()) + PIGST + TIGST) + "";
                    }
                    if (sWOPO == "PO")
                    {
                        DataTable dtCDValue = new DataTable();
                        dtCDValue = DAL.fnAdvancedCDReceipt(0, cmbprintginnumber.Text).Tables[0];
                        if (!string.IsNullOrEmpty(dtCDValue.Rows[0]["CDPercent"].ToString()))
                        {
                            NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 1, 4] = "CDPercent";
                            NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 1, 5] = dtCDValue.Rows[0]["CDPercent"].ToString();
                            NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 1, 6] = (Convert.ToDouble(dtCDValue.Compute("Sum(CDValue)", "").ToString()));
                            NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 2, 4] = "CDCessRate";
                            NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 2, 5] = dtCDValue.Rows[0]["CDCessRate"].ToString();
                            NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 2, 6] = (Convert.ToDouble(dtCDValue.Compute("Sum(CDCessAmount)", "").ToString()));
                            NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 3, 4] = "CDIGSTRate";
                            NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 3, 5] = dtCDValue.Rows[0]["CDIGSTRate"].ToString();
                            NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 3, 6] = (Convert.ToDouble(dtCDValue.Compute("Sum(CDIGSTAmount)", "").ToString()));

                            NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 4, 5] = "Grand Total";
                            NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 4, 6] = (Convert.ToDouble((Convert.ToDouble(dtAdvancedReciept.Compute("Sum(Amount)", "").ToString()) - Convert.ToDouble(dtAdvancedReciept.Compute("Sum(DiscAmount)", "").ToString()) + Convert.ToDouble(dtAdvancedReciept.Compute("Sum(IGSTAmount)", "").ToString()) + Convert.ToDouble(dtAdvancedReciept.Compute("Sum(SGSTAmount)", "").ToString()) + Convert.ToDouble(dtAdvancedReciept.Compute("Sum(CGSTAmount)", "").ToString()) + freight + Packing + PIGST + PSGST + PCGST + TIGST + TSGST + TCGST)) + Convert.ToDouble(dtCDValue.Compute("Sum(CDValue)", "").ToString()) + Convert.ToDouble(dtCDValue.Compute("Sum(CDCessAmount)", "").ToString()) + Convert.ToDouble(dtCDValue.Compute("Sum(CDIGSTAmount)", "").ToString()));
                        }

                        else
                        {
                            NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 4, 5] = "Grand Total";
                            NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 4, 6] = Text42;
                        }
                    }
                    else
                    {
                        NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 4, 5] = "Grand Total";
                        NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 4, 6] = Text42;
                    }

                    CellMerge("BorderAround", NewWorkSheet, 1, 27 + dtAdvancedReciept.Rows.Count + 4, 1, 16);


                    Microsoft.Office.Interop.Excel.Range range = NewWorkSheet.get_Range("D14", "G9999");
                    range.NumberFormat = "0.00";
                    Microsoft.Office.Interop.Excel.Range range1 = NewWorkSheet.get_Range("D10", "D10");
                    range1.NumberFormat = "dd-MM-yyyy";

                    Microsoft.Office.Interop.Excel.Range range2 = NewWorkSheet.get_Range("B10", "B10");
                    range2.NumberFormat = "dd-MM-yyyy";

                    Microsoft.Office.Interop.Excel.Range range3 = NewWorkSheet.get_Range("B8", "B8");
                    range3.NumberFormat = "dd-MM-yyyy";

                    //  Microsoft.Office.Interop.Excel.Range range11 = NewWorkSheet.get_Range("D10", "D11");
                    //range11.NumberFormat = "000";
                    NewWorkSheet.Range["A2:A2"].Cells.Font.Size = 16;
                    NewWorkSheet.Range["A2:A2"].Cells.Font.Bold = true;
                    NewWorkSheet.Range["A1:A1"].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    NewWorkSheet.Range["A2:A2"].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    NewWorkSheet.Range["A3:A3"].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    NewWorkSheet.Range["A4:A4"].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    NewWorkSheet.Range["A5:A5"].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    NewWorkSheet.Range["A14:A14"].Cells.Font.Bold = true;
                    NewWorkSheet.Range["A7:A20"].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignRight;

                    NewWorkSheet.Range["B7:B20"].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;

                    ((Microsoft.Office.Interop.Excel.Range)NewWorkSheet.Rows[22, Type.Missing]).Font.Bold = true;
                    ((Microsoft.Office.Interop.Excel.Range)NewWorkSheet.Rows[22, Type.Missing]).Font.Color = Color.Blue;
                    ((Microsoft.Office.Interop.Excel.Range)NewWorkSheet.Rows[23, Type.Missing]).Font.Bold = true;
                    ((Microsoft.Office.Interop.Excel.Range)NewWorkSheet.Rows[23, Type.Missing]).Font.Color = Color.Blue;

                    NewWorkSheet.get_Range("C1", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
                    NewWorkSheet.get_Range("C1", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                    NewWorkSheet.Columns.AutoFit(); //NewWorkSheet.Rows.AutoFit();
                    NewWorkSheet.Columns[1].ColumnWidth = 16;
                    NewWorkSheet.Columns[1].WrapText = true;
                    NewWorkSheet.Columns[3].ColumnWidth = 18;
                    NewWorkSheet.Columns[3].WrapText = true;
                    NewWorkSheet.Columns[2].ColumnWidth = 30;
                    NewWorkSheet.Columns[2].WrapText = true;
                    NewWorkSheet.Columns[4].ColumnWidth = 14;
                    NewWorkSheet.Columns[4].WrapText = true;
                    NewWorkSheet.Columns[5].ColumnWidth = 12;
                    NewWorkSheet.Columns[5].WrapText = true;
                    NewWorkSheet.PageSetup.Zoom = false;
                    iRowIndex = (27 + dtAdvancedReciept.Rows.Count + 4);
                    NewWorkSheet.PageSetup.PrintArea = "A1 : O" + iRowIndex + "";
                    NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                    //NewWorkSheet.Rows.RowHeight = "18";
                    NewWorkSheet.PageSetup.PrintNotes = true;
                    NewWorkSheet.PageSetup.Zoom = 60;
                    NewWorkSheet.PageSetup.FitToPagesTall = 1;
                    NewWorkSheet.PageSetup.FitToPagesWide = 1;
                    NewWorkSheet.PageSetup.LeftMargin = 0;
                    NewWorkSheet.PageSetup.RightMargin = 0;
                    NewWorkSheet.PageSetup.TopMargin = 0.75;
                    NewWorkSheet.PageSetup.BottomMargin = 0.75;
                    NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                    NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                    EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[1, 9];
                    System.Drawing.Image oImage = System.Drawing.Image.FromFile(Global.sLogo);
                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    // NewWorkSheet.Paste(oRange, Global.sLogo);
                    System.Threading.Thread.Sleep(100);
                    NewWorkSheet.Paste(oRange);
                    NewWorkBook.Save();
                    NewWorkBook.Close(true, misValue, misValue);
                    ExcelApp.Quit();
                    releaseObject(NewWorkSheet);
                    releaseObject(NewWorkBook);
                    releaseObject(ExcelApp);

                    if (Directory.Exists(ExcelFolderPath))
                    {
                        Process.Start(ExcelFolderPath);
                    }
                    Cursor.Current = Cursors.Default;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                    {
                        GetProcess.Kill();
                    }
                }
            }
            else
                MessageBox.Show("No indent items to save", "Error", 0, MessageBoxIcon.Question);
        }

        #endregion
        CultureInfo india = new CultureInfo("hi-IN");

        private void dtpFromDate_ValueChanged(object sender, EventArgs e)
        {
            if (cmbReport.Text == "Consolidated Projects Conusmption Report" || cmbReport.Text == "Customer Projects Conusmption Report" ||
               cmbReport.Text == "Inventory Grading Report" || cmbReport.Text == "Item Usage Work Order"
               || cmbReport.Text == "Cust. Project Inventory Grading Report")
            {
                var sTodatydate = DateTime.Today;
                dptToDate.Value = sTodatydate;
                var s6MonthsDate1 = dtpFromDate.Value.AddDays(-182);
                var s12MotnhsDate1 = dtpFromDate.Value.AddDays(-365);

               // dptToDate.Value = s6MonthsDate1;
                dtptwelve.Value = s12MotnhsDate1;
            }
        }

        private void avaQtycheckBox_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            FilterTypecomboBox1.Text = "";
            subStoreNamecomboBox2.Text = "";
            storeNamecomboBox3.Text = "";
            CategorycomboBox4.Text = "";
        }

        private void buttton1_hover(object sender, EventArgs e)
        {
            button1.BackColor = Color.Gray;
            button1.ForeColor = Color.White;
            // Set the cursor to a wait cursor
            Cursor.Current = Cursors.Hand;
        }

        private void buttton1_leaving(object sender, EventArgs e)
        {
            button1.BackColor = Color.White;
            button1.ForeColor = Color.Black;
            Cursor.Current = Cursors.Default;

        }

        private void comboBox1LabelPrintItemCode_SelectedIndexChanged(object sender, EventArgs e)
        {
           // comboBox2LabelPrintLocation.Text = null;
            //comboBox1LabelPrintItemCode.Text = comboBox1LabelPrintItemCode.Text;
        }

        private void comboBox2LabelPrintLocation_SelectedIndexChanged(object sender, EventArgs e)
        {
            //comboBox1LabelPrintItemCode.Text = null;
            //comboBox2LabelPrintLocation.Text = comboBox2LabelPrintLocation.Text;
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2ItemCode.Checked) { 
            checkBox1Location.Checked = false;
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1Location.Checked) { 
            checkBox2ItemCode.Checked = false;
            }
        }

        private void ItemLabelPrintpanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void LocationUpdatebutton_Click(object sender, EventArgs e)
        {
            
            //update the Item Master Locations
            //update Every ERPInventoryLogs locations
            //Create the Location row in ERPItemLocation

            //DAL.fnERPItemLocation()  //check itemlocation is PresentationTraceLevel or not
            //DAL.fnUpdateInventoryLogItemLocation("UPDATE", $"{temStoreName}-{temSubStoreName}-{comboBox4RackNumber.Text}-{comboBox5Position.Text}", comboBox1ItemCodeLocation.Text);
            //DAL.fnCreateERPItemLocation  create new ERPItemLocatuin
            // fnUpateItemLocationItemMaster update ItemMaster


            string temStoreName = "";
            string temSubStoreName = "";

            if (!string.IsNullOrWhiteSpace(comboBox3SubStoreLocation.Text))
            {
                switch (comboBox3SubStoreLocation.Text)
                {
                    case "First Floor":
                        temSubStoreName = "F";
                        break;
                    case "Ground Floor":
                        temSubStoreName = "G";
                        break;
                    case "Old Store Area":
                        temSubStoreName = "OS";
                        break;
                    case "Actuator Area":
                        temSubStoreName = "AA";
                        break;
                    case "Control Panel Area":
                        temSubStoreName = "Control Panel Area";
                        break;
                    case "Grip Area":
                        temSubStoreName = "GA";
                        break;
                    case "Load Frame Area":
                        temSubStoreName = "LA";
                        break;
                    case "Manifold Area":
                        temSubStoreName = "MF";
                        break;
                    case "Power Pack Area":
                        temSubStoreName = "Power Pack Area";
                        break;
                }
            }

            if (!string.IsNullOrWhiteSpace(comboBox2StoreNameLocation.Text))
            {
                switch (comboBox2StoreNameLocation.Text)
                {
                    case "Main Store":
                        temStoreName = "MS";
                        break;
                    case "De-Centralised":
                        temStoreName = "DC";
                        break;
                    case "Kanban Shop Floor":
                        temStoreName = "KSF";
                        break;

                }
            }


            DataTable ERPItemLocationTable = DAL.fnERPItemLocation(comboBox1ItemCodeLocation.Text).Tables[0];

            if(ERPItemLocationTable.Rows.Count == 0)
            {

                if (!string.IsNullOrWhiteSpace(comboBox5Position.Text))
                {
                    string fnUpdateInventoryLogItemLocationStatus = DAL.fnUpdateInventoryLogItemLocation("UPDATE", $"{temStoreName}-{temSubStoreName}-{comboBox4RackNumber.Text}-{comboBox1Level.Text}-{comboBox5Position.Text}", comboBox1ItemCodeLocation.Text);
                    string fnUpateItemLocationItemMasterStatus = DAL.fnUpateItemLocationItemMaster($"{temStoreName}-{temSubStoreName}-{comboBox4RackNumber.Text}-{comboBox1Level.Text}-{comboBox5Position.Text}", comboBox1ItemCodeLocation.Text);
                    string fnCreateERPItemLocationstatus = DAL.fnCreateERPItemLocation("NEW", comboBox1ItemCodeLocation.Text, comboBox2StoreNameLocation.Text, comboBox3SubStoreLocation.Text, $"{temStoreName}-{temSubStoreName}-{comboBox4RackNumber.Text}-{comboBox1Level.Text}-{comboBox5Position.Text}");

                }
                else if (comboBox3SubStoreLocation.Text == "Control Panel Area" || comboBox3SubStoreLocation.Text == "Power Pack Area")
                {
                    string fnUpdateInventoryLogItemLocationStatus = DAL.fnUpdateInventoryLogItemLocation("UPDATE", $"{temStoreName}-{temSubStoreName}", comboBox1ItemCodeLocation.Text);
                    string fnUpateItemLocationItemMasterStatus = DAL.fnUpateItemLocationItemMaster($"{temStoreName}-{temSubStoreName}", comboBox1ItemCodeLocation.Text);
                    string fnCreateERPItemLocationstatus = DAL.fnCreateERPItemLocation("NEW", comboBox1ItemCodeLocation.Text, comboBox2StoreNameLocation.Text, comboBox3SubStoreLocation.Text, $"{temStoreName}-{temSubStoreName}");

                }
                else if (!string.IsNullOrWhiteSpace(comboBox1Level.Text))
                {
                    string fnUpdateInventoryLogItemLocationStatus = DAL.fnUpdateInventoryLogItemLocation("UPDATE", $"{temStoreName}-{temSubStoreName}-{comboBox4RackNumber.Text}-{comboBox1Level.Text}", comboBox1ItemCodeLocation.Text);
                    string fnUpateItemLocationItemMasterStatus = DAL.fnUpateItemLocationItemMaster($"{temStoreName}-{temSubStoreName}-{comboBox4RackNumber.Text}-{comboBox1Level.Text}", comboBox1ItemCodeLocation.Text);
                    string fnCreateERPItemLocationstatus = DAL.fnCreateERPItemLocation("NEW", comboBox1ItemCodeLocation.Text, comboBox2StoreNameLocation.Text, comboBox3SubStoreLocation.Text, $"{temStoreName}-{temSubStoreName}-{comboBox4RackNumber.Text}-{comboBox1Level.Text}");
                }
                else if (!string.IsNullOrWhiteSpace(comboBox4RackNumber.Text))
                {
                    string fnUpdateInventoryLogItemLocationStatus = DAL.fnUpdateInventoryLogItemLocation("UPDATE", $"{temStoreName}-{temSubStoreName}-{comboBox4RackNumber.Text}", comboBox1ItemCodeLocation.Text);
                    string fnUpateItemLocationItemMasterStatus = DAL.fnUpateItemLocationItemMaster($"{temStoreName}-{temSubStoreName}-{comboBox4RackNumber.Text}", comboBox1ItemCodeLocation.Text);
                    string fnCreateERPItemLocationstatus = DAL.fnCreateERPItemLocation("NEW", comboBox1ItemCodeLocation.Text, comboBox2StoreNameLocation.Text, comboBox3SubStoreLocation.Text, $"{temStoreName}-{temSubStoreName}-{comboBox4RackNumber.Text}");
                }
                else if (!string.IsNullOrWhiteSpace(temSubStoreName))
                {
                    string fnUpdateInventoryLogItemLocationStatus = DAL.fnUpdateInventoryLogItemLocation("UPDATE", $"{temStoreName}-{temSubStoreName}", comboBox1ItemCodeLocation.Text);
                    string fnUpateItemLocationItemMasterStatus = DAL.fnUpateItemLocationItemMaster($"{temStoreName}-{temSubStoreName}", comboBox1ItemCodeLocation.Text);
                    string fnCreateERPItemLocationstatus = DAL.fnCreateERPItemLocation("NEW", comboBox1ItemCodeLocation.Text, comboBox2StoreNameLocation.Text, comboBox3SubStoreLocation.Text, $"{temStoreName}-{temSubStoreName}");
                }
                else if (!string.IsNullOrWhiteSpace(temStoreName))
                {
                    string fnUpdateInventoryLogItemLocationStatus = DAL.fnUpdateInventoryLogItemLocation("UPDATE", $"{temStoreName}", comboBox1ItemCodeLocation.Text);
                    string fnUpateItemLocationItemMasterStatus = DAL.fnUpateItemLocationItemMaster($"{temStoreName}", comboBox1ItemCodeLocation.Text);
                    string fnCreateERPItemLocationstatus = DAL.fnCreateERPItemLocation("NEW", comboBox1ItemCodeLocation.Text, comboBox2StoreNameLocation.Text, comboBox3SubStoreLocation.Text, $"{temStoreName}");

                }

                MessageBox.Show("Location Create Successfully...", "Successfully");
                comboBox3SubStoreLocation.Text = "";
                comboBox2StoreNameLocation.Text = "";
                comboBox4RackNumber.Text = "";
                comboBox1Level.Text = "";
                comboBox5Position.Text = "";
            }
            else
            {
                MessageBox.Show("Location already presented please check with adimn...", "Location E");
            }





            //comboBox3SubStoreLocation
            //comboBox2StoreNameLocation
            //comboBox4RackNumber
            //comboBox5Position
            //MessageBox.Show($"{temStoreName}-{temSubStoreName}-{comboBox4RackNumber.Text}-{comboBox5Position.Text}", comboBox1ItemCodeLocation.Text);
        }

        private void comboBox2StoreNameLocation_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2StoreNameLocation.Text == "De-Centralised")
            {
                comboBox3SubStoreLocation.Items.Clear();
                this.comboBox3SubStoreLocation.Items.AddRange(new object[] {
            "Actuator Area",
            "Control Panel Area",
            "Grip Area",
            "Load Frame Area",
            "Manifold Area",
            "Power Pack Area"});
            }
            else
            {
                comboBox3SubStoreLocation.Items.Clear();
                this.comboBox3SubStoreLocation.Items.AddRange(new object[] {
            "First Floor",
            "Ground Floor",
            "Old Store Area"});
            }
        }

        private void comboBox3SubStoreLocation_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox3SubStoreLocation.Text == "Control Panel Area" || comboBox3SubStoreLocation.Text == "Power Pack Area")
            {
                comboBox4RackNumber.Enabled = false;
                comboBox1Level.Enabled = false;
                comboBox5Position.Enabled = false;
            }
            else
            {
                comboBox4RackNumber.Enabled = true;
                comboBox1Level.Enabled = true;
                comboBox5Position.Enabled = true;
            }
        }

        private void comboBox1ItemCodeLocation_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
