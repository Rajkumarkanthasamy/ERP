﻿namespace Erp_Project_With_Buttons.Additional_Masters
{
    partial class frmAdditoinalMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Issue", 7, 7);
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Indent", 11, 11);
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Part Master", 1, 1);
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Reciept", 9, 9);
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("Product Master ", 10, 10);
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Project Master", 5, 5);
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("Work Order", 2, 2);
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("Project BOM", 13, 13);
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("Customer Master", 12, 12);
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("Purchase Order", 8, 8);
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("Reports", 4, 4);
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("Applications", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3,
            treeNode4,
            treeNode5,
            treeNode6,
            treeNode7,
            treeNode8,
            treeNode9,
            treeNode10,
            treeNode11});
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAdditoinalMaster));
            this.pnWorkOrder = new System.Windows.Forms.Panel();
            this.lblAdditionalMaster = new System.Windows.Forms.Label();
            this.tcWorkOrder = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dtpCreatedDate = new System.Windows.Forms.DateTimePicker();
            this.txtCode = new System.Windows.Forms.TextBox();
            this.lblCode = new System.Windows.Forms.Label();
            this.cmbStatus = new System.Windows.Forms.ComboBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.cmbSelectMaster = new System.Windows.Forms.ComboBox();
            this.txtPercentage = new System.Windows.Forms.TextBox();
            this.lblPercentage = new System.Windows.Forms.Label();
            this.dgMasterDetails = new System.Windows.Forms.DataGridView();
            this.Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Percentage = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CreatedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CreatedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtCreatedBy = new System.Windows.Forms.TextBox();
            this.lblCreatedBy = new System.Windows.Forms.Label();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.lblDescription = new System.Windows.Forms.Label();
            this.lblSelectMaster = new System.Windows.Forms.Label();
            this.gbControlButtons = new System.Windows.Forms.GroupBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClearAll = new System.Windows.Forms.Button();
            this.pnHomeExit = new System.Windows.Forms.Panel();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.llQuit = new System.Windows.Forms.LinkLabel();
            this.btnQuit = new System.Windows.Forms.Button();
            this.llHome = new System.Windows.Forms.LinkLabel();
            this.btnHome = new System.Windows.Forms.Button();
            this.pnBIM = new System.Windows.Forms.Panel();
            this.lbltime = new System.Windows.Forms.Label();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.lblReturnedby = new System.Windows.Forms.Label();
            this.lblIBM = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pnWorkOrder.SuspendLayout();
            this.tcWorkOrder.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgMasterDetails)).BeginInit();
            this.gbControlButtons.SuspendLayout();
            this.pnHomeExit.SuspendLayout();
            this.pnBIM.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnWorkOrder
            // 
            this.pnWorkOrder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.pnWorkOrder.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnWorkOrder.Controls.Add(this.lblAdditionalMaster);
            this.pnWorkOrder.Controls.Add(this.tcWorkOrder);
            this.pnWorkOrder.Location = new System.Drawing.Point(228, 148);
            this.pnWorkOrder.Name = "pnWorkOrder";
            this.pnWorkOrder.Size = new System.Drawing.Size(1073, 529);
            this.pnWorkOrder.TabIndex = 18;
            // 
            // lblAdditionalMaster
            // 
            this.lblAdditionalMaster.AutoSize = true;
            this.lblAdditionalMaster.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdditionalMaster.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.lblAdditionalMaster.Location = new System.Drawing.Point(445, -1);
            this.lblAdditionalMaster.Name = "lblAdditionalMaster";
            this.lblAdditionalMaster.Size = new System.Drawing.Size(175, 26);
            this.lblAdditionalMaster.TabIndex = 11;
            this.lblAdditionalMaster.Text = "Additional Masters";
            // 
            // tcWorkOrder
            // 
            this.tcWorkOrder.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.tcWorkOrder.Controls.Add(this.tabPage1);
            this.tcWorkOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tcWorkOrder.ItemSize = new System.Drawing.Size(0, 1);
            this.tcWorkOrder.Location = new System.Drawing.Point(17, 25);
            this.tcWorkOrder.Margin = new System.Windows.Forms.Padding(2);
            this.tcWorkOrder.Name = "tcWorkOrder";
            this.tcWorkOrder.SelectedIndex = 0;
            this.tcWorkOrder.Size = new System.Drawing.Size(1036, 496);
            this.tcWorkOrder.TabIndex = 10;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.tabPage1.Controls.Add(this.dtpCreatedDate);
            this.tabPage1.Controls.Add(this.txtCode);
            this.tabPage1.Controls.Add(this.lblCode);
            this.tabPage1.Controls.Add(this.cmbStatus);
            this.tabPage1.Controls.Add(this.lblStatus);
            this.tabPage1.Controls.Add(this.cmbSelectMaster);
            this.tabPage1.Controls.Add(this.txtPercentage);
            this.tabPage1.Controls.Add(this.lblPercentage);
            this.tabPage1.Controls.Add(this.dgMasterDetails);
            this.tabPage1.Controls.Add(this.txtCreatedBy);
            this.tabPage1.Controls.Add(this.lblCreatedBy);
            this.tabPage1.Controls.Add(this.txtDescription);
            this.tabPage1.Controls.Add(this.lblDescription);
            this.tabPage1.Controls.Add(this.lblSelectMaster);
            this.tabPage1.Controls.Add(this.gbControlButtons);
            this.tabPage1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 5);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1028, 487);
            this.tabPage1.TabIndex = 0;
            // 
            // dtpCreatedDate
            // 
            this.dtpCreatedDate.Location = new System.Drawing.Point(924, 14);
            this.dtpCreatedDate.Name = "dtpCreatedDate";
            this.dtpCreatedDate.Size = new System.Drawing.Size(1, 26);
            this.dtpCreatedDate.TabIndex = 93;
            // 
            // txtCode
            // 
            this.txtCode.Enabled = false;
            this.txtCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCode.Location = new System.Drawing.Point(568, 15);
            this.txtCode.Multiline = true;
            this.txtCode.Name = "txtCode";
            this.txtCode.Size = new System.Drawing.Size(127, 22);
            this.txtCode.TabIndex = 92;
            // 
            // lblCode
            // 
            this.lblCode.AutoSize = true;
            this.lblCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCode.ForeColor = System.Drawing.Color.White;
            this.lblCode.Location = new System.Drawing.Point(431, 16);
            this.lblCode.Name = "lblCode";
            this.lblCode.Size = new System.Drawing.Size(47, 19);
            this.lblCode.TabIndex = 91;
            this.lblCode.Text = "Code:";
            // 
            // cmbStatus
            // 
            this.cmbStatus.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.Items.AddRange(new object[] {
            "Active",
            "InActive"});
            this.cmbStatus.Location = new System.Drawing.Point(774, 16);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(151, 27);
            this.cmbStatus.Sorted = true;
            this.cmbStatus.TabIndex = 90;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.ForeColor = System.Drawing.Color.White;
            this.lblStatus.Location = new System.Drawing.Point(704, 16);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(64, 19);
            this.lblStatus.TabIndex = 89;
            this.lblStatus.Text = "Status*:";
            // 
            // cmbSelectMaster
            // 
            this.cmbSelectMaster.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectMaster.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSelectMaster.FormattingEnabled = true;
            this.cmbSelectMaster.Items.AddRange(new object[] {
            "CST",
            "DeliveryTerm",
            "Discount",
            "ExciseDuty",
            "Others",
            "PaymentTerm",
            "Tax"});
            this.cmbSelectMaster.Location = new System.Drawing.Point(240, 16);
            this.cmbSelectMaster.Name = "cmbSelectMaster";
            this.cmbSelectMaster.Size = new System.Drawing.Size(168, 27);
            this.cmbSelectMaster.Sorted = true;
            this.cmbSelectMaster.TabIndex = 88;
            this.cmbSelectMaster.SelectedIndexChanged += new System.EventHandler(this.cmbSelectMaster_SelectedIndexChanged);
            // 
            // txtPercentage
            // 
            this.txtPercentage.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPercentage.Location = new System.Drawing.Point(240, 99);
            this.txtPercentage.Multiline = true;
            this.txtPercentage.Name = "txtPercentage";
            this.txtPercentage.Size = new System.Drawing.Size(168, 22);
            this.txtPercentage.TabIndex = 86;
            this.txtPercentage.Text = "0.0";
            this.txtPercentage.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtPercentage_KeyUp);
            // 
            // lblPercentage
            // 
            this.lblPercentage.AutoSize = true;
            this.lblPercentage.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPercentage.ForeColor = System.Drawing.Color.White;
            this.lblPercentage.Location = new System.Drawing.Point(137, 102);
            this.lblPercentage.Name = "lblPercentage";
            this.lblPercentage.Size = new System.Drawing.Size(98, 19);
            this.lblPercentage.TabIndex = 85;
            this.lblPercentage.Text = "Percentage*:";
            // 
            // dgMasterDetails
            // 
            this.dgMasterDetails.AllowUserToAddRows = false;
            this.dgMasterDetails.AllowUserToDeleteRows = false;
            this.dgMasterDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgMasterDetails.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgMasterDetails.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgMasterDetails.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgMasterDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgMasterDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Code,
            this.Name,
            this.Percentage,
            this.CreatedDate,
            this.CreatedBy,
            this.Status});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgMasterDetails.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgMasterDetails.Location = new System.Drawing.Point(20, 133);
            this.dgMasterDetails.MultiSelect = false;
            this.dgMasterDetails.Name = "dgMasterDetails";
            this.dgMasterDetails.ReadOnly = true;
            this.dgMasterDetails.RowHeadersVisible = false;
            this.dgMasterDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgMasterDetails.Size = new System.Drawing.Size(984, 276);
            this.dgMasterDetails.TabIndex = 80;
            this.dgMasterDetails.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgMasterDetails_CellMouseDoubleClick);
            this.dgMasterDetails.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgMasterDetails_KeyUp);
            // 
            // Code
            // 
            this.Code.HeaderText = "Code";
            this.Code.Name = "Code";
            this.Code.ReadOnly = true;
            this.Code.Width = 69;
            // 
            // Name
            // 
            this.Name.HeaderText = "Name";
            this.Name.Name = "Name";
            this.Name.ReadOnly = true;
            this.Name.Width = 74;
            // 
            // Percentage
            // 
            this.Percentage.HeaderText = "Percentage";
            this.Percentage.Name = "Percentage";
            this.Percentage.ReadOnly = true;
            this.Percentage.Width = 109;
            // 
            // CreatedDate
            // 
            this.CreatedDate.DataPropertyName = "CreatedDate";
            this.CreatedDate.HeaderText = "Created Date";
            this.CreatedDate.Name = "CreatedDate";
            this.CreatedDate.ReadOnly = true;
            this.CreatedDate.Width = 125;
            // 
            // CreatedBy
            // 
            this.CreatedBy.DataPropertyName = "CreatedBy";
            this.CreatedBy.HeaderText = "Created By";
            this.CreatedBy.Name = "CreatedBy";
            this.CreatedBy.ReadOnly = true;
            this.CreatedBy.Width = 111;
            // 
            // Status
            // 
            this.Status.DataPropertyName = "Status";
            this.Status.HeaderText = "Status";
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            this.Status.Width = 76;
            // 
            // txtCreatedBy
            // 
            this.txtCreatedBy.Enabled = false;
            this.txtCreatedBy.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCreatedBy.Location = new System.Drawing.Point(708, 99);
            this.txtCreatedBy.Multiline = true;
            this.txtCreatedBy.Name = "txtCreatedBy";
            this.txtCreatedBy.Size = new System.Drawing.Size(217, 22);
            this.txtCreatedBy.TabIndex = 73;
            // 
            // lblCreatedBy
            // 
            this.lblCreatedBy.AutoSize = true;
            this.lblCreatedBy.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCreatedBy.ForeColor = System.Drawing.Color.White;
            this.lblCreatedBy.Location = new System.Drawing.Point(604, 102);
            this.lblCreatedBy.Name = "lblCreatedBy";
            this.lblCreatedBy.Size = new System.Drawing.Size(87, 19);
            this.lblCreatedBy.TabIndex = 72;
            this.lblCreatedBy.Text = "Created By:";
            // 
            // txtDescription
            // 
            this.txtDescription.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescription.Location = new System.Drawing.Point(240, 58);
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(685, 27);
            this.txtDescription.TabIndex = 71;
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescription.ForeColor = System.Drawing.Color.White;
            this.lblDescription.Location = new System.Drawing.Point(56, 59);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(98, 19);
            this.lblDescription.TabIndex = 70;
            this.lblDescription.Text = "Description*:";
            this.lblDescription.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblSelectMaster
            // 
            this.lblSelectMaster.AutoSize = true;
            this.lblSelectMaster.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectMaster.ForeColor = System.Drawing.Color.White;
            this.lblSelectMaster.Location = new System.Drawing.Point(125, 16);
            this.lblSelectMaster.Name = "lblSelectMaster";
            this.lblSelectMaster.Size = new System.Drawing.Size(106, 19);
            this.lblSelectMaster.TabIndex = 59;
            this.lblSelectMaster.Text = "Select Master:";
            // 
            // gbControlButtons
            // 
            this.gbControlButtons.Controls.Add(this.btnExit);
            this.gbControlButtons.Controls.Add(this.btnSave);
            this.gbControlButtons.Controls.Add(this.btnClearAll);
            this.gbControlButtons.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.gbControlButtons.Location = new System.Drawing.Point(20, 413);
            this.gbControlButtons.Name = "gbControlButtons";
            this.gbControlButtons.Size = new System.Drawing.Size(984, 65);
            this.gbControlButtons.TabIndex = 58;
            this.gbControlButtons.TabStop = false;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(766, 16);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(104, 43);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(486, 16);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(104, 43);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClearAll
            // 
            this.btnClearAll.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnClearAll.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnClearAll.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearAll.Location = new System.Drawing.Point(206, 16);
            this.btnClearAll.Name = "btnClearAll";
            this.btnClearAll.Size = new System.Drawing.Size(104, 43);
            this.btnClearAll.TabIndex = 7;
            this.btnClearAll.Text = "Clear All";
            this.btnClearAll.UseVisualStyleBackColor = false;
            this.btnClearAll.Click += new System.EventHandler(this.btnClearAll_Click);
            // 
            // pnHomeExit
            // 
            this.pnHomeExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.pnHomeExit.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnHomeExit.Controls.Add(this.treeView1);
            this.pnHomeExit.Controls.Add(this.llQuit);
            this.pnHomeExit.Controls.Add(this.btnQuit);
            this.pnHomeExit.Controls.Add(this.llHome);
            this.pnHomeExit.Controls.Add(this.btnHome);
            this.pnHomeExit.Location = new System.Drawing.Point(6, 148);
            this.pnHomeExit.Name = "pnHomeExit";
            this.pnHomeExit.Size = new System.Drawing.Size(216, 529);
            this.pnHomeExit.TabIndex = 17;
            // 
            // treeView1
            // 
            this.treeView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.treeView1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.treeView1.ImageIndex = 0;
            this.treeView1.ImageList = this.imageList1;
            this.treeView1.Location = new System.Drawing.Point(3, 87);
            this.treeView1.Name = "treeView1";
            treeNode1.ImageIndex = 7;
            treeNode1.Name = "Node3";
            treeNode1.SelectedImageIndex = 7;
            treeNode1.Text = "Issue";
            treeNode2.ImageIndex = 11;
            treeNode2.Name = "Node7";
            treeNode2.SelectedImageIndex = 11;
            treeNode2.Text = "Indent";
            treeNode3.ImageIndex = 1;
            treeNode3.Name = "Node5";
            treeNode3.SelectedImageIndex = 1;
            treeNode3.Text = "Part Master";
            treeNode4.ImageIndex = 9;
            treeNode4.Name = "Node6";
            treeNode4.SelectedImageIndex = 9;
            treeNode4.Text = "Reciept";
            treeNode5.ImageIndex = 10;
            treeNode5.Name = "Node0";
            treeNode5.SelectedImageIndex = 10;
            treeNode5.Text = "Product Master ";
            treeNode6.ImageIndex = 5;
            treeNode6.Name = "Node0";
            treeNode6.SelectedImageIndex = 5;
            treeNode6.Text = "Project Master";
            treeNode7.ImageIndex = 2;
            treeNode7.Name = "Node8";
            treeNode7.SelectedImageIndex = 2;
            treeNode7.Text = "Work Order";
            treeNode8.ImageIndex = 13;
            treeNode8.Name = "Node1";
            treeNode8.SelectedImageIndex = 13;
            treeNode8.Text = "Project BOM";
            treeNode9.ImageIndex = 12;
            treeNode9.Name = "Node2";
            treeNode9.SelectedImageIndex = 12;
            treeNode9.Text = "Customer Master";
            treeNode10.ImageIndex = 8;
            treeNode10.Name = "Node5";
            treeNode10.SelectedImageIndex = 8;
            treeNode10.Text = "Purchase Order";
            treeNode11.ImageIndex = 4;
            treeNode11.Name = "Node6";
            treeNode11.SelectedImageIndex = 4;
            treeNode11.Text = "Reports";
            treeNode12.Name = "Node0";
            treeNode12.Text = "Applications";
            this.treeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode12});
            this.treeView1.SelectedImageIndex = 0;
            this.treeView1.ShowLines = false;
            this.treeView1.Size = new System.Drawing.Size(207, 297);
            this.treeView1.TabIndex = 78;
            this.treeView1.DoubleClick += new System.EventHandler(this.treeView1_DoubleClick_1);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Add-icon.png");
            this.imageList1.Images.SetKeyName(1, "table-add-icon.png");
            this.imageList1.Images.SetKeyName(2, "order-history-icon.png");
            this.imageList1.Images.SetKeyName(3, "Package-Add-icon.png");
            this.imageList1.Images.SetKeyName(4, "Excel-icon.png");
            this.imageList1.Images.SetKeyName(5, "Actions-address-book-new-icon.png");
            this.imageList1.Images.SetKeyName(6, "invoice-icon.png");
            this.imageList1.Images.SetKeyName(7, "Apps-kspread-icon.png");
            this.imageList1.Images.SetKeyName(8, "Apps-klipper-icon.png");
            this.imageList1.Images.SetKeyName(9, "Upline-icon.png");
            this.imageList1.Images.SetKeyName(10, "reports-icon.png");
            this.imageList1.Images.SetKeyName(11, "Mimetypes-application-vnd-sun-xml-calc-template-icon.png");
            this.imageList1.Images.SetKeyName(12, "catalog-icon.png");
            this.imageList1.Images.SetKeyName(13, "Add-icon.png");
            // 
            // llQuit
            // 
            this.llQuit.AutoSize = true;
            this.llQuit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llQuit.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.llQuit.LinkColor = System.Drawing.Color.Red;
            this.llQuit.Location = new System.Drawing.Point(73, 465);
            this.llQuit.Name = "llQuit";
            this.llQuit.Size = new System.Drawing.Size(45, 23);
            this.llQuit.TabIndex = 76;
            this.llQuit.TabStop = true;
            this.llQuit.Text = "Quit";
            this.llQuit.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llQuit_LinkClicked);
            // 
            // btnQuit
            // 
            this.btnQuit.FlatAppearance.BorderSize = 0;
            this.btnQuit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQuit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuit.Image = global::Erp_Project_With_Buttons.Properties.Resources.glossy_3d_blue_delete_icon__1_;
            this.btnQuit.Location = new System.Drawing.Point(12, 445);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(55, 57);
            this.btnQuit.TabIndex = 75;
            this.btnQuit.UseVisualStyleBackColor = true;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // llHome
            // 
            this.llHome.AutoSize = true;
            this.llHome.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llHome.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.llHome.LinkColor = System.Drawing.SystemColors.HotTrack;
            this.llHome.Location = new System.Drawing.Point(64, 26);
            this.llHome.Name = "llHome";
            this.llHome.Size = new System.Drawing.Size(57, 23);
            this.llHome.TabIndex = 9;
            this.llHome.TabStop = true;
            this.llHome.Text = "Home";
            this.llHome.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llHome_LinkClicked);
            // 
            // btnHome
            // 
            this.btnHome.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnHome.FlatAppearance.BorderSize = 0;
            this.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnHome.Image = global::Erp_Project_With_Buttons.Properties.Resources.Dryicons_Aesthetica_2_Home;
            this.btnHome.Location = new System.Drawing.Point(12, 17);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(46, 36);
            this.btnHome.TabIndex = 1;
            this.btnHome.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnHome.UseVisualStyleBackColor = true;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // pnBIM
            // 
            this.pnBIM.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.pnBIM.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnBIM.Controls.Add(this.lbltime);
            this.pnBIM.Controls.Add(this.lblWelcome);
            this.pnBIM.Controls.Add(this.lblReturnedby);
            this.pnBIM.Controls.Add(this.lblIBM);
            this.pnBIM.Location = new System.Drawing.Point(6, 4);
            this.pnBIM.Name = "pnBIM";
            this.pnBIM.Size = new System.Drawing.Size(1295, 138);
            this.pnBIM.TabIndex = 16;
            // 
            // lbltime
            // 
            this.lbltime.AutoSize = true;
            this.lbltime.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltime.ForeColor = System.Drawing.Color.Khaki;
            this.lbltime.Location = new System.Drawing.Point(1167, 100);
            this.lbltime.Name = "lbltime";
            this.lbltime.Size = new System.Drawing.Size(0, 23);
            this.lbltime.TabIndex = 24;
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lblWelcome.ForeColor = System.Drawing.Color.Yellow;
            this.lblWelcome.Location = new System.Drawing.Point(3, 100);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(98, 24);
            this.lblWelcome.TabIndex = 22;
            this.lblWelcome.Text = "Welcome :";
            // 
            // lblReturnedby
            // 
            this.lblReturnedby.AutoSize = true;
            this.lblReturnedby.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.lblReturnedby.ForeColor = System.Drawing.Color.Yellow;
            this.lblReturnedby.Location = new System.Drawing.Point(101, 100);
            this.lblReturnedby.Name = "lblReturnedby";
            this.lblReturnedby.Size = new System.Drawing.Size(0, 24);
            this.lblReturnedby.TabIndex = 21;
            // 
            // lblIBM
            // 
            this.lblIBM.AutoSize = true;
            this.lblIBM.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIBM.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblIBM.Location = new System.Drawing.Point(492, 54);
            this.lblIBM.Name = "lblIBM";
            this.lblIBM.Size = new System.Drawing.Size(294, 29);
            this.lblIBM.TabIndex = 0;
            this.lblIBM.Text = "BiSS Inventory Management";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick_1);
            // 
            // frmAdditoinalMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.ClientSize = new System.Drawing.Size(1304, 682);
            this.Controls.Add(this.pnWorkOrder);
            this.Controls.Add(this.pnHomeExit);
            this.Controls.Add(this.pnBIM);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            //this.Name = "frmAdditoinalMaster";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Additoinal Master";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AdditoinalMasterForm_FormClosing);
            this.Load += new System.EventHandler(this.frmAdditoinalMaster_Load);
            this.pnWorkOrder.ResumeLayout(false);
            this.pnWorkOrder.PerformLayout();
            this.tcWorkOrder.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgMasterDetails)).EndInit();
            this.gbControlButtons.ResumeLayout(false);
            this.pnHomeExit.ResumeLayout(false);
            this.pnHomeExit.PerformLayout();
            this.pnBIM.ResumeLayout(false);
            this.pnBIM.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnWorkOrder;
        private System.Windows.Forms.Label lblAdditionalMaster;
        private System.Windows.Forms.TabControl tcWorkOrder;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.ComboBox cmbSelectMaster;
        private System.Windows.Forms.TextBox txtPercentage;
        private System.Windows.Forms.Label lblPercentage;
        private System.Windows.Forms.DataGridView dgMasterDetails;
        private System.Windows.Forms.TextBox txtCreatedBy;
        private System.Windows.Forms.Label lblCreatedBy;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.Label lblSelectMaster;
        private System.Windows.Forms.GroupBox gbControlButtons;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClearAll;
        private System.Windows.Forms.Panel pnHomeExit;
        private System.Windows.Forms.LinkLabel llQuit;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.LinkLabel llHome;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Panel pnBIM;
        private System.Windows.Forms.Label lblIBM;
        private System.Windows.Forms.ComboBox cmbStatus;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.TextBox txtCode;
        private System.Windows.Forms.Label lblCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn Code;
        private System.Windows.Forms.DataGridViewTextBoxColumn Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Percentage;
        private System.Windows.Forms.DataGridViewTextBoxColumn CreatedDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn CreatedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.DateTimePicker dtpCreatedDate;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Label lblReturnedby;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lbltime;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.ImageList imageList1;
    }
}