﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Additional_Masters
{
    public partial class frmAdditoinalMaster : Form
    {  
        #region Intialization of Local Datatables, Variables Daclaration
        public const string sDELIVERYTERM="DeliveryTerm";
        public const string sDISCOUNT = "Discount";
        public const string sEXCISEDUTY = "ExciseDuty";
        public const string sPAYMENTTERM = "PaymentTerm";
        public const string sTAX = "Tax";
        public const string sCST = "CST";
        public const string sOTHERS = "Others";

        Global GLobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        frmForm2 frm = new frmForm2();
        DataTable dtMasterList = new DataTable();
        public static bool  bPercentageCheck=false;
     
        public frmAdditoinalMaster()
        {
            InitializeComponent();
        }
        #endregion
        #region Function to Check Percentage
        public void fnPercentageCheck()
        {
            if (cmbSelectMaster.Text != sDELIVERYTERM && cmbSelectMaster.Text != sPAYMENTTERM)
            {
                if (txtPercentage.Text == "0.0" || txtPercentage.Text == string.Empty)
                {
                    MessageBox.Show(lblPercentage.Text + " field is empty", "Error");
                    bPercentageCheck = false;
                }
                else
                    bPercentageCheck = true;
            }
            else
                bPercentageCheck = true;
        }
        #endregion
        #region Home Page Function
        private void btnHome_Click(object sender, EventArgs e)
        {           
                this.Close();
                frm.Show();
        }

        private void llHome_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            btnHome_Click(sender, e);
        }
        #endregion
        #region Quit Applcation Function
        private void btnQuit_Click(object sender, EventArgs e)
        {
            if (GLobalClass.fnMessageResultquit() == Global.sCLOSE_MESSAGE_RESULT_YES)
            {
                Application.ExitThread();
            }
        }

        private void llQuit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            btnQuit_Click(sender, e);
        }
        #endregion
        #region Clear All Function
        private void btnClearAll_Click(object sender, EventArgs e)
        {
            if (GLobalClass.fnClearallMessage() == DialogResult.Yes)    //calling clearall message function
            {
                GLobalClass.fnClearAll(tabPage1);   //calling clearall function
                btnSave.Text = Global.sBUTTON_SAVE_TEXT_ISSAVE;
                txtCreatedBy.Text = Login.frmLoginForm.sUserDetails[2].ToLower();
                cmbStatus.SelectedIndex = 0;
                dgMasterDetails.DataSource = null;
                dgMasterDetails.Rows.Clear();
            }
        }
        #endregion
        #region Exit Form Function
        private void btnExit_Click(object sender, EventArgs e)
        {
            if (GLobalClass.fnMessageResult() == Global.sCLOSE_MESSAGE_RESULT_YES)  //calling closing message function
            {
                this.Hide();
                frm.Show();
            }
        }

        private void AdditoinalMasterForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            btnExit_Click(sender, e);
        }
        #endregion
        #region Form Load 
        private void frmAdditoinalMaster_Load(object sender, EventArgs e)
        {
            //Text = Global.sVersion;
            timer1.Interval = 1000;
            timer1.Enabled = true;
            Login.frmLoginForm login = new Login.frmLoginForm();
            lblReturnedby.Text = login.GetUserDetails[2];
            txtCreatedBy.Text = Login.frmLoginForm.sUserDetails[2].ToLower();
            cmbSelectMaster.Text = Global.sCOMBOBOX_DEFAULT_TEXT;
            cmbStatus.SelectedIndex = 0;
            btnSave.Text = Global.sBUTTON_SAVE_TEXT_ISSAVE;
        }
        #endregion
        #region Save Tax Function
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmbSelectMaster.Text != string.Empty && cmbSelectMaster.Text != Global.sCOMBOBOX_DEFAULT_TEXT && cmbSelectMaster.Items.Contains(cmbSelectMaster.Text) && cmbStatus.Text != string.Empty && cmbStatus.Text != Global.sCOMBOBOX_DEFAULT_TEXT && cmbStatus.Items.Contains(cmbStatus.Text))
                {
                    if (btnSave.Text == Global.sBUTTON_SAVE_TEXT_ISSAVE)
                        cmbStatus.SelectedIndex = 0;
                    if (txtDescription.Text != string.Empty)
                    {
                        fnPercentageCheck();
                        if (bPercentageCheck)
                        {
                            switch (cmbSelectMaster.Text)
                            {
                                case sDELIVERYTERM:
                                    {
                                        if (btnSave.Text == Global.sBUTTON_SAVE_TEXT_ISSAVE)
                                        {
                                            GLobalClass.iSuccess = DAL.fnAddDeliveryTermMaster(Global.uINSERT, null, txtDescription.Text, txtCreatedBy.Text, dtpCreatedDate.Text, cmbStatus.Text);
                                            if (GLobalClass.iSuccess > 0)
                                            {
                                                txtCode.Text = DAL.fnGetLastDeliveryCode();
                                                MessageBox.Show("New Delivery term added successfully Delivery code is: " + txtCode.Text, "Success");
                                            }
                                        }
                                        else
                                        {
                                            GLobalClass.iSuccess = DAL.fnAddDeliveryTermMaster(Global.uUPDATE, txtCode.Text, txtDescription.Text, txtCreatedBy.Text, dtpCreatedDate.Text, cmbStatus.Text);
                                            if (GLobalClass.iSuccess > 0)
                                            {
                                                MessageBox.Show("Delivery term " + txtCode.Text + " updated Successfully", "Success");
                                            }
                                        }
                                        break;
                                    }
                                case sDISCOUNT:
                                    {
                                        if (btnSave.Text == Global.sBUTTON_SAVE_TEXT_ISSAVE)
                                        {
                                            GLobalClass.iSuccess = DAL.fnAddDiscountMaster(Global.uINSERT, null, txtDescription.Text, txtCreatedBy.Text, dtpCreatedDate.Text, cmbStatus.Text, Convert.ToDouble(txtPercentage.Text));
                                            if (GLobalClass.iSuccess > 0)
                                            {
                                                txtCode.Text = DAL.fnGetLastDiscountCode();
                                                MessageBox.Show("New Discount added successfully Discount code is: " + txtCode.Text, "Success");
                                            }
                                        }
                                        else
                                        {
                                            GLobalClass.iSuccess = DAL.fnAddDiscountMaster(Global.uUPDATE, txtCode.Text, txtDescription.Text, txtCreatedBy.Text, dtpCreatedDate.Text, cmbStatus.Text, Convert.ToDouble(txtPercentage.Text));
                                            if (GLobalClass.iSuccess > 0)
                                            {
                                                MessageBox.Show("Discount" + txtCode.Text + " updated successfully", "Success");
                                            }
                                        }
                                        break;
                                    }
                                case sEXCISEDUTY:
                                    {
                                        if (btnSave.Text == Global.sBUTTON_SAVE_TEXT_ISSAVE)
                                        {
                                            GLobalClass.iSuccess = DAL.fnAddExciseDutyMaster(Global.uINSERT, null, txtDescription.Text, txtCreatedBy.Text, dtpCreatedDate.Text, cmbStatus.Text, Convert.ToDouble(txtPercentage.Text));
                                            if (GLobalClass.iSuccess > 0)
                                            {
                                                txtCode.Text = DAL.fnGetLastExciseDutyCode();
                                                MessageBox.Show("New Excise Duty added successfully Excise duty code is: " + txtCode.Text, "Success");
                                            }
                                        }
                                        else
                                        {
                                            GLobalClass.iSuccess = DAL.fnAddExciseDutyMaster(Global.uUPDATE, txtCode.Text, txtDescription.Text, txtCreatedBy.Text, dtpCreatedDate.Text, cmbStatus.Text, Convert.ToDouble(txtPercentage.Text));
                                            if (GLobalClass.iSuccess > 0)
                                            {
                                                MessageBox.Show("Excise Duty " + txtCode.Text + " updated successfully", "Success");
                                            }
                                        }
                                        break;
                                    }
                                case sPAYMENTTERM:
                                    {
                                        if (btnSave.Text == Global.sBUTTON_SAVE_TEXT_ISSAVE)
                                        {
                                            GLobalClass.iSuccess = DAL.fnAddPaymentTermMaster(Global.uINSERT, null, txtDescription.Text, txtCreatedBy.Text, dtpCreatedDate.Text, cmbStatus.Text);
                                            if (GLobalClass.iSuccess > 0)
                                            {
                                                txtCode.Text = DAL.fnGetLastPaymentCode();
                                                MessageBox.Show("New Payment term added Successfully Payment term Code is: " + txtCode.Text, "Success...");
                                            }
                                        }
                                        else
                                        {
                                            GLobalClass.iSuccess = DAL.fnAddPaymentTermMaster(Global.uUPDATE, txtCode.Text, txtDescription.Text, txtCreatedBy.Text, dtpCreatedDate.Text, cmbStatus.Text);
                                            if (GLobalClass.iSuccess > 0)
                                            {
                                                MessageBox.Show("Payment term " + txtCode.Text + "updatedsSuccessfully", "Success");
                                            }
                                        }
                                        break;
                                    }
                                case sTAX:
                                    {
                                        if (btnSave.Text == Global.sBUTTON_SAVE_TEXT_ISSAVE)
                                        {
                                            GLobalClass.iSuccess = DAL.fnAddTaxMaster(Global.uINSERT, null, txtDescription.Text, txtCreatedBy.Text, dtpCreatedDate.Text, cmbStatus.Text, Convert.ToDouble(txtPercentage.Text));
                                            if (GLobalClass.iSuccess > 0)
                                            {
                                                txtCode.Text = DAL.fnGetLastTaxCode();
                                                MessageBox.Show("New Tax added successfully Tax code: " + txtCode.Text, "Success");
                                            }
                                        }
                                        else
                                        {
                                            GLobalClass.iSuccess = DAL.fnAddTaxMaster(Global.uUPDATE, txtCode.Text, txtDescription.Text, txtCreatedBy.Text, dtpCreatedDate.Text, cmbStatus.Text, Convert.ToDouble(txtPercentage.Text));
                                            if (GLobalClass.iSuccess > 0)
                                            {
                                                MessageBox.Show("Tax " + txtCode.Text + " Updated successfully", "Success");
                                            }
                                        }
                                        break;
                                    }
                                case sCST:
                                    {
                                        if (btnSave.Text == Global.sBUTTON_SAVE_TEXT_ISSAVE)
                                        {
                                            GLobalClass.iSuccess = DAL.fnAddCSTMaster(Global.uINSERT, null, txtDescription.Text, txtCreatedBy.Text, dtpCreatedDate.Text, cmbStatus.Text, Convert.ToDouble(txtPercentage.Text));
                                            if (GLobalClass.iSuccess > 0)
                                            {
                                                txtCode.Text = DAL.fnGetLastCSTCode();
                                                MessageBox.Show("New CST added successfully CST code: " + txtCode.Text, "Success");
                                            }
                                        }
                                        else
                                        {
                                            GLobalClass.iSuccess = DAL.fnAddCSTMaster(Global.uUPDATE, txtCode.Text, txtDescription.Text, txtCreatedBy.Text, dtpCreatedDate.Text, cmbStatus.Text, Convert.ToDouble(txtPercentage.Text));
                                            if (GLobalClass.iSuccess > 0)
                                            {
                                                MessageBox.Show("CST " + txtCode.Text + " updated successfully", "Success");
                                            }
                                        }
                                        break;
                                    }
                                case sOTHERS:
                                    {
                                        if (btnSave.Text == Global.sBUTTON_SAVE_TEXT_ISSAVE)
                                        {
                                            GLobalClass.iSuccess = DAL.fnAddOthersTaxMaster(Global.uINSERT, null, txtDescription.Text, txtCreatedBy.Text, dtpCreatedDate.Text, cmbStatus.Text, Convert.ToDouble(txtPercentage.Text));
                                            if (GLobalClass.iSuccess > 0)
                                            {
                                                txtCode.Text = DAL.fnGetLastOTCode();
                                                MessageBox.Show("New OtherTax added successfully OtherTax code: " + txtCode.Text, "Success");
                                            }
                                        }
                                        else
                                        {
                                            GLobalClass.iSuccess = DAL.fnAddOthersTaxMaster(Global.uUPDATE, txtCode.Text, txtDescription.Text, txtCreatedBy.Text, dtpCreatedDate.Text, cmbStatus.Text, Convert.ToDouble(txtPercentage.Text));
                                            if (GLobalClass.iSuccess > 0)
                                            {
                                                MessageBox.Show("OtherTax " + txtCode.Text + " updated successfully", "Success");
                                            }
                                        }
                                        break;
                                    }

                                default:
                                    {
                                        break;
                                    }
                            }
                            GLobalClass.fnClearAll(tabPage1);   //calling clearall function
                            btnSave.Text = Global.sBUTTON_SAVE_TEXT_ISSAVE;
                            txtCreatedBy.Text = Login.frmLoginForm.sUserDetails[2].ToLower();
                            cmbStatus.SelectedIndex = 0;
                            dgMasterDetails.DataSource = null;
                            dgMasterDetails.Rows.Clear();
                        }
                    }
                    else
                        MessageBox.Show(lblDescription.Text + "Field is empty", "Error");
                }
                else
                    MessageBox.Show("Please select the required master or the status should be active for new Terms", "Error");
            }
            catch (Exception ex)
            { MessageBox.Show("AdditoinalMasterForm_btnSave_Click   " + ex.Message); }
          
        }
        #endregion
        #region Tax Selection Changed Function
        private void cmbSelectMaster_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                switch (cmbSelectMaster.Text)
                {
                    case sDELIVERYTERM:
                        {
                            txtPercentage.Visible = false;
                            lblPercentage.Visible = false;
                            lblDescription.Text = "Delivery Term Discription*:";
                            lblCode.Text = "Delivery Code:";
                            dtMasterList = DAL.fnDeliveryTermMasterList(null).Tables["DeliveryTermMasterList"];
                            if (dtMasterList.Rows.Count > 0)
                            {
                                dgMasterDetails.Columns["Code"].DataPropertyName = dtMasterList.Columns["DeliveryCode"].ColumnName;
                                dgMasterDetails.Columns["Name"].DataPropertyName = dtMasterList.Columns["DeliveryTerms"].ColumnName;
                                dgMasterDetails.Columns["Percentage"].Visible = false;
                                dgMasterDetails.AutoGenerateColumns = false;
                                dgMasterDetails.DataSource = dtMasterList;
                            }
                            break;
                        }
                    case sDISCOUNT:
                        {
                            txtPercentage.Visible = true;
                            lblPercentage.Visible = true;
                            lblDescription.Text = "Discount Description*:";
                            lblCode.Text = "Discount Code:";
                            dtMasterList = DAL.fnDiscountMasterList(null).Tables["DiscountMasterList"];
                            if (dtMasterList.Rows.Count > 0)
                            {
                                dgMasterDetails.Columns["Code"].DataPropertyName = dtMasterList.Columns["DiscountCode"].ColumnName;
                                dgMasterDetails.Columns["Name"].DataPropertyName = dtMasterList.Columns["DiscountName"].ColumnName;
                                dgMasterDetails.Columns["Percentage"].DataPropertyName = dtMasterList.Columns["DiscountPercentage"].ColumnName;
                                dgMasterDetails.Columns["Percentage"].Visible = true;
                                dgMasterDetails.AutoGenerateColumns = false;
                                dgMasterDetails.DataSource = dtMasterList;
                            }
                            break;
                        }
                    case sEXCISEDUTY:
                        {
                            txtPercentage.Visible = true;
                            lblPercentage.Visible = true;
                            lblDescription.Text = "Excise Duty Description*:";
                            lblCode.Text = "ExciseDuty Code:";
                            dtMasterList = DAL.fnExciseDutyMasterList(null).Tables["ExciseDutyMasterList"];
                            if (dtMasterList.Rows.Count > 0)
                            {
                                dgMasterDetails.Columns["Code"].DataPropertyName = dtMasterList.Columns["ExciseDutyCode"].ColumnName;
                                dgMasterDetails.Columns["Name"].DataPropertyName = dtMasterList.Columns["ExciseDutyName"].ColumnName;
                                dgMasterDetails.Columns["Percentage"].DataPropertyName = dtMasterList.Columns["ExciseDutyPercentage"].ColumnName;
                                dgMasterDetails.Columns["Percentage"].Visible = true;
                                dgMasterDetails.AutoGenerateColumns = false;
                                dgMasterDetails.DataSource = dtMasterList;
                            }
                            break;
                        }
                    case sPAYMENTTERM:
                        {
                            txtPercentage.Visible = false;
                            lblPercentage.Visible = false;
                            lblDescription.Text = "Payment Term Description*:";
                            lblCode.Text = "Payment Code:";
                            dtMasterList = DAL.fnPaymentTermMasterList(null).Tables["PaymentTermMasterList"];
                            if (dtMasterList.Rows.Count > 0)
                            {
                                dgMasterDetails.Columns["Code"].DataPropertyName = dtMasterList.Columns["PaymentCode"].ColumnName;
                                dgMasterDetails.Columns["Name"].DataPropertyName = dtMasterList.Columns["PaymentTerms"].ColumnName;
                                dgMasterDetails.Columns["Percentage"].Visible = false;
                                dgMasterDetails.AutoGenerateColumns = false;
                                dgMasterDetails.DataSource = dtMasterList;
                            }
                            break;
                        }
                    case sTAX:
                        {
                            txtPercentage.Visible = true;
                            lblPercentage.Visible = true;
                            lblDescription.Text = "Tax Description*:";
                            lblCode.Text = "Tax Code:";
                            dtMasterList = DAL.fnTaxMasterList(null).Tables["TaxMasterList"];
                            if (dtMasterList.Rows.Count > 0)
                            {
                                dgMasterDetails.Columns["Code"].DataPropertyName = dtMasterList.Columns["TaxCode"].ColumnName;
                                dgMasterDetails.Columns["Name"].DataPropertyName = dtMasterList.Columns["TaxName"].ColumnName;
                                dgMasterDetails.Columns["Percentage"].DataPropertyName = dtMasterList.Columns["TaxPercentage"].ColumnName;
                                dgMasterDetails.Columns["Percentage"].Visible = true;
                                dgMasterDetails.AutoGenerateColumns = false;
                                dgMasterDetails.DataSource = dtMasterList;
                            }
                            break;
                        }
                    case sCST:
                        {
                            txtPercentage.Visible = true;
                            lblPercentage.Visible = true;
                            lblDescription.Text = "CST Description*:";
                            lblCode.Text = "CST Code:";
                            dtMasterList = DAL.fnCSTMasterList(null).Tables["CSTMasterList"];
                            if (dtMasterList.Rows.Count > 0)
                            {
                                dgMasterDetails.Columns["Code"].DataPropertyName = dtMasterList.Columns["CSTCode"].ColumnName;
                                dgMasterDetails.Columns["Name"].DataPropertyName = dtMasterList.Columns["CSTName"].ColumnName;
                                dgMasterDetails.Columns["Percentage"].DataPropertyName = dtMasterList.Columns["CSTPercentage"].ColumnName;
                                dgMasterDetails.Columns["Percentage"].Visible = true;
                                dgMasterDetails.AutoGenerateColumns = false;
                                dgMasterDetails.DataSource = dtMasterList;
                            }
                            break;
                        }
                    case sOTHERS:
                        {
                            txtPercentage.Visible = true;
                            lblPercentage.Visible = true;
                            lblDescription.Text = "OtherTax Description*:";
                            lblCode.Text = "OT Code:";
                            dtMasterList = DAL.fnOthersTaxMasterList(null).Tables["OthersTaxMasterList"];
                            if (dtMasterList.Rows.Count > 0)
                            {
                                dgMasterDetails.Columns["Code"].DataPropertyName = dtMasterList.Columns["OTCode"].ColumnName;
                                dgMasterDetails.Columns["Name"].DataPropertyName = dtMasterList.Columns["OTName"].ColumnName;
                                dgMasterDetails.Columns["Percentage"].DataPropertyName = dtMasterList.Columns["OTPercentage"].ColumnName;
                                dgMasterDetails.Columns["Percentage"].Visible = true;
                                dgMasterDetails.AutoGenerateColumns = false;
                                dgMasterDetails.DataSource = dtMasterList;
                            }
                            break;
                        }

                    default:
                        {
                            break;
                        }
                }
            }
            catch (Exception ex)
            { MessageBox.Show("AdditoinalMasterForm_cmbSelectMaster_SelectedIndexChanged  " + ex.Message); }
        }
        #endregion
        #region Function to Check Float Number
        private void txtPercentage_KeyUp(object sender, KeyEventArgs e)
        {
           GLobalClass.fnIsFloatingNumber(txtPercentage);
        }
        #endregion
        #region Function to Load Tax Details
        private void dgMasterDetails_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            txtCode.Text = dgMasterDetails.CurrentRow.Cells["Code"].Value.ToString();
            txtDescription.Text = dgMasterDetails.CurrentRow.Cells["Name"].Value.ToString();
            txtCreatedBy.Text = dgMasterDetails.CurrentRow.Cells["CreatedBy"].Value.ToString();
            cmbStatus.Text = dgMasterDetails.CurrentRow.Cells["Status"].Value.ToString();
            if (cmbSelectMaster.Text != sDELIVERYTERM && cmbSelectMaster.Text != sPAYMENTTERM)
                txtPercentage.Text = dgMasterDetails.CurrentRow.Cells["Percentage"].Value.ToString();

            btnSave.Text = Global.sBUTTON_SAVE_TEXT_ISUPDATE;
        }
        #endregion     
        #region Delete Tax Function
        private void dgMasterDetails_KeyUp(object sender, KeyEventArgs e)
        {            
            if (e.KeyCode == Keys.Delete)
            {
                DialogResult DR = MessageBox.Show("Do you want to permanently delete the Item " + dgMasterDetails.CurrentRow.Cells["Name"].Value.ToString(), "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if(DR==DialogResult.Yes)
                {
                    string sCode=dgMasterDetails.CurrentRow.Cells["Code"].Value.ToString();
                    switch (cmbSelectMaster.Text)
                    {
                        case sDELIVERYTERM:
                            {
                                GLobalClass.iSuccess = DAL.fnAddDeliveryTermMaster(Global.uDELETE,sCode, null, null, null, null);
                                if (GLobalClass.iSuccess > 0)
                                {
                                    MessageBox.Show("Selected item " + sCode + " Removed from the Database","Success...");
                                    dgMasterDetails.Rows.Remove(dgMasterDetails.CurrentRow);
                                }                                
                                    break;
                            }
                        case sDISCOUNT:
                            {
                                GLobalClass.iSuccess = DAL.fnAddDiscountMaster(Global.uDELETE, sCode, null, null, null, null,0.0);
                                if (GLobalClass.iSuccess > 0)
                                {
                                    MessageBox.Show("Selected item " + sCode + " Removed from the Database", "Success...");
                                    dgMasterDetails.Rows.Remove(dgMasterDetails.CurrentRow);
                                }
                                
                                break;
                            }
                        case sEXCISEDUTY:
                            {
                                GLobalClass.iSuccess = DAL.fnAddExciseDutyMaster(Global.uDELETE, sCode, null, null, null, null,0.0);
                                if (GLobalClass.iSuccess > 0)
                                {
                                    MessageBox.Show("Selected item " + sCode + " Removed from the Database", "Success...");
                                    dgMasterDetails.Rows.Remove(dgMasterDetails.CurrentRow);
                                }
                                
                                break;
                            }
                        case sPAYMENTTERM:
                            {
                                GLobalClass.iSuccess = DAL.fnAddPaymentTermMaster(Global.uDELETE, sCode, null, null, null, null);
                                if (GLobalClass.iSuccess > 0)
                                {
                                    MessageBox.Show("Selected item " + sCode + " Removed from the Database", "Success...");
                                    dgMasterDetails.Rows.Remove(dgMasterDetails.CurrentRow);
                                }
                                break;
                            }
                        case sTAX:
                            {
                                GLobalClass.iSuccess = DAL.fnAddTaxMaster(Global.uDELETE, sCode, null, null, null, null,0.0);
                                if (GLobalClass.iSuccess > 0)
                                {
                                    MessageBox.Show("Selected item " + sCode + " Removed from the Database", "Success...");
                                    dgMasterDetails.Rows.Remove(dgMasterDetails.CurrentRow);
                                }

                                break;
                            }
                        case sCST:
                            {
                                GLobalClass.iSuccess = DAL.fnAddCSTMaster(Global.uDELETE, sCode, null, null, null, null, 0.0);
                                if (GLobalClass.iSuccess > 0)
                                {
                                    MessageBox.Show("Selected item " + sCode + " Removed from the Database", "Success...");
                                    dgMasterDetails.Rows.Remove(dgMasterDetails.CurrentRow);
                                }
                                break;
                            }
                        case sOTHERS:
                            {
                                GLobalClass.iSuccess = DAL.fnAddOthersTaxMaster(Global.uDELETE, sCode, null, null, null, null, 0.0);
                                if (GLobalClass.iSuccess > 0)
                                {
                                    MessageBox.Show("Selected item " + sCode + " Removed from the Database", "Success...");
                                    dgMasterDetails.Rows.Remove(dgMasterDetails.CurrentRow);
                                }
                                break;
                            }

                        default:
                            {
                                break;
                            }
                    }
                }
            }
        }
        #endregion
        #region To DisplayTime
        private void timer1_Tick_1(object sender, EventArgs e)
        {
            lbltime.Text = DateTime.Now.ToString("hh:mm:ss tt");
        }
        #endregion
        #region Fucntion to go Different Forms
        private void treeView1_DoubleClick_1(object sender, EventArgs e)
        {
          //  GLobalClass.fnCloseMessage(treeView1, this);
        }
        #endregion
    }
}
