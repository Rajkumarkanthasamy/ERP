﻿using System;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.ValidationDocuments
{
    public partial class frmValidationHome : Form
    {
        public frmValidationHome()
        {
            InitializeComponent();
        }
        frmForm2 frm = new frmForm2();
        Global GLobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        private void btnTimeSheet_Click(object sender, EventArgs e)
        {
            Time_Sheet.frmValidationTimeSheet TimeSheet = new Time_Sheet.frmValidationTimeSheet();
            fnFormShow(TimeSheet);
        }

        private void frmValidationHome_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            frm.Show();
        }

        #region Function to Show Please wait form & Switch to Selected From
        private void fnFormShow(Form Frm)
        {
            this.Hide();
            pleasewaitform pleaseWait = new pleasewaitform();
            pleaseWait.Show();
            Application.DoEvents();
            Frm.Show();
            pleaseWait.Hide();
        }
        #endregion


        private void frmValidationHome_Load(object sender, EventArgs e)
        {
            if (Login.frmLoginForm.sUserDetails[72] != "True")
            {
                btnTimeSheet.Enabled = false;
            }
            else
            {
                btnTimeSheet.Enabled = true;
            }

            if (Login.frmLoginForm.sUserDetails[73] != "True")
            {
                btnReport.Enabled = false;
            }
            else
            {
                btnReport.Enabled = true;
            }

            if (Login.frmLoginForm.sUserDetails[75] != "True")
            {
                btnMachineUtilization.Enabled = false;
            }
            else
            {
                btnMachineUtilization.Enabled = true;
            }
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            Time_Sheet.frmTimesheetView VTS = new Time_Sheet.frmTimesheetView();
            fnFormShow(VTS);
        }

        private void btnMachineUtilization_Click(object sender, EventArgs e)
        {
            Time_Sheet.frmMachineUtilization MU = new Time_Sheet.frmMachineUtilization();
            fnFormShow(MU);
        }
    }
}
