﻿namespace Erp_Project_With_Buttons.ValidationDocuments
{
    partial class frmValidationHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmValidationHome));
            this.lblName = new System.Windows.Forms.Label();
            this.btnMachineUtilization = new System.Windows.Forms.Button();
            this.btnReport = new System.Windows.Forms.Button();
            this.btnTimeSheet = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.Indigo;
            this.lblName.Location = new System.Drawing.Point(320, 22);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(294, 29);
            this.lblName.TabIndex = 42;
            this.lblName.Text = "BiSS Inventory Management";
            // 
            // btnMachineUtilization
            // 
            this.btnMachineUtilization.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnMachineUtilization.Enabled = false;
            this.btnMachineUtilization.FlatAppearance.BorderSize = 0;
            this.btnMachineUtilization.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMachineUtilization.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnMachineUtilization.ForeColor = System.Drawing.Color.MediumBlue;
            this.btnMachineUtilization.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_task_planning_48;
            this.btnMachineUtilization.Location = new System.Drawing.Point(334, 121);
            this.btnMachineUtilization.Name = "btnMachineUtilization";
            this.btnMachineUtilization.Size = new System.Drawing.Size(124, 119);
            this.btnMachineUtilization.TabIndex = 43;
            this.btnMachineUtilization.Text = "Machine Utilization";
            this.btnMachineUtilization.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnMachineUtilization.UseVisualStyleBackColor = true;
            this.btnMachineUtilization.Click += new System.EventHandler(this.btnMachineUtilization_Click);
            // 
            // btnReport
            // 
            this.btnReport.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnReport.Enabled = false;
            this.btnReport.FlatAppearance.BorderSize = 0;
            this.btnReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReport.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnReport.ForeColor = System.Drawing.Color.MediumBlue;
            this.btnReport.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_microsoft_excel_481;
            this.btnReport.Location = new System.Drawing.Point(641, 144);
            this.btnReport.Name = "btnReport";
            this.btnReport.Size = new System.Drawing.Size(118, 96);
            this.btnReport.TabIndex = 34;
            this.btnReport.Text = "Report";
            this.btnReport.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnReport.UseVisualStyleBackColor = true;
            this.btnReport.Click += new System.EventHandler(this.btnReport_Click);
            // 
            // btnTimeSheet
            // 
            this.btnTimeSheet.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnTimeSheet.Enabled = false;
            this.btnTimeSheet.FlatAppearance.BorderSize = 0;
            this.btnTimeSheet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTimeSheet.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnTimeSheet.ForeColor = System.Drawing.Color.MediumBlue;
            this.btnTimeSheet.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_timetable_481;
            this.btnTimeSheet.Location = new System.Drawing.Point(59, 121);
            this.btnTimeSheet.Name = "btnTimeSheet";
            this.btnTimeSheet.Size = new System.Drawing.Size(124, 119);
            this.btnTimeSheet.TabIndex = 32;
            this.btnTimeSheet.Text = "Add Time Sheet";
            this.btnTimeSheet.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnTimeSheet.UseVisualStyleBackColor = true;
            this.btnTimeSheet.Click += new System.EventHandler(this.btnTimeSheet_Click);
            // 
            // frmValidationHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(877, 468);
            this.Controls.Add(this.btnMachineUtilization);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.btnReport);
            this.Controls.Add(this.btnTimeSheet);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmValidationHome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Time Sheet";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmValidationHome_FormClosing);
            this.Load += new System.EventHandler(this.frmValidationHome_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnTimeSheet;
        private System.Windows.Forms.Button btnReport;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Button btnMachineUtilization;
    }
}