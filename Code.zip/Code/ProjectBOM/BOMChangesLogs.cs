﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.ProjectBOM
{
    public partial class BOMChangesLogs : Form
    {

        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        ToolTip tt = new ToolTip();
        DataTable ProjectDetails = new DataTable();
        DataTable ERPProjectBOMLockLogsList = new DataTable();
        public BOMChangesLogs()
        {
            InitializeComponent();
        }

        private void LockBOM_Load(object sender, EventArgs e)
        {
           // DataTable ProjectList = DAL.fnAllProjectList_(null).Tables[0];
            //MessageBox.Show(ProjectList.Rows.Count.ToString());
            //foreach (DataRow dr in ProjectList.Rows)
           // {
            //    if (!comboBox1ProjectCode.Items.Contains(dr["ProjectCode"].ToString()))
                   // comboBox1ProjectCode.Items.Add(dr["ProjectCode"].ToString());

           // }
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "dd-MM-yyyy";

            LOGSButton.BackColor = Color.LightSteelBlue;
            LOGSButton.ForeColor = Color.Black;

            DataTable ProjectList = DAL.fnAllProjectList_(null).Tables[0];
            //MessageBox.Show(ProjectList.Rows.Count.ToString());
            foreach (DataRow dr in ProjectList.Rows)
            {
                if (!comboBoxLogProjectCode.Items.Contains(dr["ProjectCode"].ToString()))
                    comboBoxLogProjectCode.Items.Add(dr["ProjectCode"].ToString());


            }

            // fnAllUserName_
            DataTable UserList = DAL.fnAllUserName_(null).Tables[0];

            //comboBoxLogUser
            foreach (DataRow dr in UserList.Rows)
            {
                if (!comboBoxLogUser.Items.Contains(dr["UserName"].ToString()))
                    comboBoxLogUser.Items.Add(dr["UserName"].ToString());
            }

            dateTimePickerLogFrom.Format = DateTimePickerFormat.Custom;
            dateTimePickerLogFrom.CustomFormat = "dd-MM-yyyy";
            //dateTimePickerLogFrom.Value = DateTime.Today;

            dateTimePickerLogTo.Format = DateTimePickerFormat.Custom;
            dateTimePickerLogTo.CustomFormat = "dd-MM-yyyy";


            string LogProjectCode = string.IsNullOrWhiteSpace(comboBoxLogProjectCode.Text) ? null : comboBoxLogProjectCode.Text;
            string LogUser = string.IsNullOrWhiteSpace(comboBoxLogUser.Text) ? null : comboBoxLogUser.Text;
           // string LogRemarks = string.IsNullOrWhiteSpace(comboBox1Remarks.Text) ? null : comboBox1Remarks.Text;

            // MessageBox.Show(dateTimePickerLogFrom.Text, dateTimePickerLogTo.Text);

            string fromDate = dateTimePickerLogFrom.Checked ? dateTimePickerLogFrom.Text : null;
            string toDate = dateTimePickerLogTo.Checked ? dateTimePickerLogTo.Text : null;

             ERPProjectBOMLockLogsList = DAL.fnGetERPProjectBOMChangesLogs(fromDate, toDate, LogProjectCode, LogUser).Tables[0];

            dataGridViewBOMLockLogs.AutoGenerateColumns = false;


            // Map DataTable columns to your DataGridView columns
            dataGridViewBOMLockLogs.Columns["ProjectCode"].DataPropertyName = "ProjectCode";
            dataGridViewBOMLockLogs.Columns["ProductNumber"].DataPropertyName = "ProductNumber";
            dataGridViewBOMLockLogs.Columns["ProductName"].DataPropertyName = "ProductName";
            dataGridViewBOMLockLogs.Columns["Qty"].DataPropertyName = "Qty";
            //dataGridViewGIN.Columns["BOMProjectCodeGIN"].DataPropertyName = "BOMProjectCode";
            dataGridViewBOMLockLogs.Columns["Cost"].DataPropertyName = "Cost";
            dataGridViewBOMLockLogs.Columns["ActionMadeBy"].DataPropertyName = "ActionMadeBy";
            dataGridViewBOMLockLogs.Columns["Version"].DataPropertyName = "Version";
            dataGridViewBOMLockLogs.Columns["ProductCode"].DataPropertyName = "ProductCode";
            dataGridViewBOMLockLogs.Columns["ProductCategory"].DataPropertyName = "ProductCategory";
            dataGridViewBOMLockLogs.Columns["ProjectBOMNumber"].DataPropertyName = "ProjectBOMNumber";
            dataGridViewBOMLockLogs.Columns["ProjectStatus"].DataPropertyName = "ProjectStatus";
            dataGridViewBOMLockLogs.Columns["ItemCode"].DataPropertyName = "ItemCode";
            dataGridViewBOMLockLogs.Columns["ActionType"].DataPropertyName = "ActionType";
            dataGridViewBOMLockLogs.Columns["CreatedDate"].DataPropertyName = "CreatedDate";
            //ProjectCost,
            //this.ProjectIssuedCost}
            dataGridViewBOMLockLogs.Columns["ProjectCost"].DataPropertyName = "ProjectBOMCost";
            dataGridViewBOMLockLogs.Columns["ProjectIssuedCost"].DataPropertyName = "ProjectIssuedCost";
            // Bind the data
            dataGridViewBOMLockLogs.DataSource = ERPProjectBOMLockLogsList;

        }

        private void frmIndent_FormClosing(object sender, FormClosingEventArgs e)
        {
            frmForm2 frmForm2 = new frmForm2();
            this.Hide();
            frmForm2.Show();
        }

        private void comboBox1ProjectCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            ProjectDetails = DAL.fnAllProjectList_(comboBox1ProjectCode.Text).Tables[0];
            if (ProjectDetails.Rows.Count > 0)
            {
                labelProjectDec.Text = ProjectDetails.Rows[0]["ProjectDescription"].ToString();
                labelCustomerName.Text = ProjectDetails.Rows[0]["Customer"].ToString();
            }
            DataTable GetERPProjectBOMLockDetails = DAL.fnGetERPProjectBOMLock(comboBox1ProjectCode.Text).Tables[0];

            // btnVibrate_Click();



            if (GetERPProjectBOMLockDetails.Rows.Count > 0)
            {
                if (GetERPProjectBOMLockDetails.Rows[0]["LockNow"].ToString().ToLower() == "true")
                {
                    //MessageBox.Show($"The selected project currently LOCK...!");
                    pictureBox1.Visible = true;
                    pictureBox2.Visible = false;
                    pictureBox3.Visible = false;
                }
                else
                {
                    openingDate.Visible = false;
                    pictureBox1.Visible = false;
                    pictureBox2.Visible = true;
                    pictureBox3.Visible = false;
                }
                try
                {
                    var s = GetERPProjectBOMLockDetails.Rows[0]["BOMClosingDate"]?.ToString();
                    var bomClosingDate = DateTime.ParseExact(s, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                    int cmp = DateTime.Compare(bomClosingDate.Date, DateTime.Today);
                    // MessageBox.Show(cmp.ToString());
                    if (cmp == 1)
                    {
                        MessageBox.Show($"The selected project currently Open till{s}..!");
                        openingDate.Text = $"Open Till {s}";
                        openingDate.Visible = true;
                        pictureBox1.Visible = false;
                        pictureBox2.Visible = true;
                        pictureBox3.Visible = false;
                    }
                    else
                    {
                        openingDate.Visible = false;
                        pictureBox1.Visible = true;
                        pictureBox2.Visible = false;
                        pictureBox3.Visible = false;
                        // MessageBox.Show($"The selected project currently LOCK {s}..!");
                    }
                }
                catch
                {
                }


                checkBox1.Enabled = true;
            }
            else
            {
                openingDate.Visible = false;
                checkBox1.Enabled = false;
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = true;
            }
            //activeTheLockButton();
        }




        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            // MessageBox.Show(dateTimePicker1.Text);

            //remove check for Lock Now

            if (dateTimePicker1.Value.Date < DateTime.Today && checkBox1BlockNow.Checked != true)
            {
                MessageBox.Show("Selected date is less than the current date..!");
                dateTimePicker1.Focus();
            }
            else
            {
                checkBox1BlockNow.Checked = false;
                checkBox1.Checked = false;
            }
            // activeTheLockButton();
        }

        private void checkBox1BlockNow_CheckedChanged(object sender, EventArgs e)
        {
            //reset the Date lock
            //dateTimePicker1.ResetText();
            //activeTheLockButton();
            checkBox1.Checked = false;
        }

        private void activeTheLockButton()
        {
            if (comboBox1ProjectCode.Text != null && comboBoxLockRemarks.Text != "" && (dateTimePicker1.Value.Date > DateTime.Today || checkBox1BlockNow.Checked) && comboBoxLockRemarks.Text != null)
            {
                button2Lock.Enabled = true;
            }
            else
            {
                button2Lock.Enabled = false;
            }
        }

        private void button2Lock_Click(object sender, EventArgs e)
        {
            if (comboBox1ProjectCode.Text != null && comboBoxLockRemarks.Text != "" && (dateTimePicker1.Value.Date > DateTime.Today || checkBox1BlockNow.Checked || checkBox1.Checked))
            {
                // button2Lock.Enabled = true;
                // MessageBox.Show(" Completed The Form..!", "Waring Message!");
            }
            else
            {
                MessageBox.Show("Not Yet Completed The Form..!", "Waring Message!");
                return;
                //button2Lock.Enabled = false;
            }

            DataTable GetERPProjectBOMLockDetails = DAL.fnGetERPProjectBOMLock(comboBox1ProjectCode.Text).Tables[0];

            if (GetERPProjectBOMLockDetails.Rows.Count == 0)
            {
                int ERPProjectBOMLockStatus = DAL.fnERPProjectBOMLock("NEW", comboBox1ProjectCode.Text, ProjectDetails.Rows[0]["ProjectDescription"].ToString(), ProjectDetails.Rows[0]["Customer"].ToString(), checkBox1BlockNow.Checked ? true : false,
                    checkBox1BlockNow.Checked ? null : dateTimePicker1.Text, login.GetUserDetails[2].ToString(), DateTime.Now.ToString(), comboBoxLockRemarks.Text);
                int fnCreateERPProjectBOMLockLogsStatus = DAL.fnCreateERPProjectBOMLockLogs(comboBox1ProjectCode.Text, ProjectDetails.Rows[0]["ProjectDescription"].ToString(), "UNLOCK", "LOCK", login.GetUserDetails[2].ToString(), comboBoxLockRemarks.Text, "LOCK BOM");

                if (checkBox1BlockNow.Checked)
                {
                    // MessageBox.Show("You have seleted the Lock Now Option..!", $"Dear {login.GetUserDetails[2].ToString().ToUpper()} Based on Selected BOM will get Lock.");
                    pictureBox1.Visible = true;
                    pictureBox2.Visible = false;
                    pictureBox3.Visible = false;
                }
                else
                {
                    pictureBox1.Visible = false;
                    pictureBox2.Visible = true;
                    pictureBox3.Visible = false;
                    // MessageBox.Show($"You Have Seleted The Date({dateTimePicker1.Value}) Lock Option..!", $"Dear {login.GetUserDetails[2].ToString().ToUpper()} Based on Date BOM will get Lock.");
                }
            }
            else
            {

                int ERPProjectBOMLockStatus = DAL.fnERPProjectBOMLock("UPDATE", comboBox1ProjectCode.Text, null, null, checkBox1BlockNow.Checked ? true : false, checkBox1BlockNow.Checked ? null : checkBox1.Checked ? null : dateTimePicker1.Text, login.GetUserDetails[2].ToString(), DateTime.Now.ToString(), comboBoxLockRemarks.Text);
                string currentStatus = "";


                try
                {
                    var s = GetERPProjectBOMLockDetails.Rows[0]["BOMClosingDate"]?.ToString();
                    var bomClosingDate = DateTime.ParseExact(s, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                    int cmp = DateTime.Compare(bomClosingDate.Date, DateTime.Today);
                    currentStatus = cmp != 1 ? "LOCK" : "UNLOCK";
                }
                catch
                {

                }

                currentStatus = (GetERPProjectBOMLockDetails.Rows[0]["LockNow"].ToString().ToString().ToLower() == "true") || (currentStatus == "LOCK") ? "LOCK" : "UNLOCK";

                int fnCreateERPProjectBOMLockLogsStatus = DAL.fnCreateERPProjectBOMLockLogs(comboBox1ProjectCode.Text, ProjectDetails.Rows[0]["ProjectDescription"].ToString(), currentStatus, currentStatus == "LOCK" ? "UNLOCK" : "LOCK", login.GetUserDetails[2].ToString(), comboBoxLockRemarks.Text, currentStatus == "LOCK" ? "UNLOCK BOM" : "LOCK BOM");

                if (checkBox1BlockNow.Checked)
                {
                    MessageBox.Show("You have seleted the Lock Now Option..!", $"Dear {login.GetUserDetails[2].ToString().ToUpper()} Based on Selected BOM will get Lock.");
                    pictureBox1.Visible = true;
                    pictureBox2.Visible = false;
                    pictureBox3.Visible = false;
                }
                else if (checkBox1.Checked)
                {
                    MessageBox.Show("You have seleted the UNLock Option..!", $"Dear {login.GetUserDetails[2].ToString().ToUpper()} Based on Selected BOM will get UNLock.");
                    pictureBox1.Visible = false;
                    pictureBox2.Visible = true;
                    pictureBox3.Visible = false;
                }
                else
                {
                    MessageBox.Show($"You Have Seleted The Date({dateTimePicker1.Value}) Lock Option..!", $"Dear {login.GetUserDetails[2].ToString().ToUpper()} Based on Date BOM will get Lock.");
                    pictureBox1.Visible = false;
                    pictureBox2.Visible = true;
                    pictureBox3.Visible = false;
                }

                comboBoxLockRemarks.Text = "";
                checkBox1BlockNow.Checked = false;
                checkBox1.Checked = false;

            }

        }

        private void button2Lock_MouseEnter(object sender, EventArgs e)
        {
            if (comboBox1ProjectCode.Text != null && comboBoxLockRemarks.Text != null && (dateTimePicker1.Value.Date > DateTime.Today || checkBox1BlockNow.Checked) && comboBoxLockRemarks.Text != null)
            {
                tt.SetToolTip(button2Lock, "Click here to Lock BOM..!");
            }
            else
            {
                tt.SetToolTip(button2Lock, "Not Yet Completed The Form..!");
            }
        }





        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            checkBox1BlockNow.Checked = false;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void LOGSButton_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
            panel1.Visible = false;
           // LOCKTabbutton.Font = new Font(LOCKTabbutton.Font.FontFamily, 9.25f);
            //LOGSButton.Font = new Font(LOCKTabbutton.Font.FontFamily, 11.25f);
            LOGSButton.BackColor = Color.DodgerBlue;
            LOGSButton.ForeColor = Color.White;
            //LOCKTabbutton.BackColor = Color.White;
           // LOCKTabbutton.ForeColor = Color.Black;


            //comboBoxLogProjectCode

           // DataTable ProjectList = DAL.fnAllProjectList_(null).Tables[0];
            //MessageBox.Show(ProjectList.Rows.Count.ToString());
           // foreach (DataRow dr in ProjectList.Rows)
           // {
              //  if (!comboBoxLogProjectCode.Items.Contains(dr["ProjectCode"].ToString()))
              //      comboBoxLogProjectCode.Items.Add(dr["ProjectCode"].ToString());


           // }

             DataTable ProjectList = DAL.fnAllProjectList_(null).Tables[0];
            //MessageBox.Show(ProjectList.Rows.Count.ToString());
            foreach (DataRow dr in ProjectList.Rows)
            {
                if (!comboBoxLogProjectCode.Items.Contains(dr["ProjectCode"].ToString()))
                    comboBoxLogProjectCode.Items.Add(dr["ProjectCode"].ToString());


            }

            // fnAllUserName_
            DataTable UserList = DAL.fnAllUserName_(null).Tables[0];

            //comboBoxLogUser
            foreach (DataRow dr in UserList.Rows)
            {
                if (!comboBoxLogUser.Items.Contains(dr["UserName"].ToString()))
                    comboBoxLogUser.Items.Add(dr["UserName"].ToString());
            }

            dateTimePickerLogFrom.Format = DateTimePickerFormat.Custom;
            dateTimePickerLogFrom.CustomFormat = "dd-MM-yyyy";
            //dateTimePickerLogFrom.Value = DateTime.Today;

            dateTimePickerLogTo.Format = DateTimePickerFormat.Custom;
            dateTimePickerLogTo.CustomFormat = "dd-MM-yyyy";


            string LogProjectCode = string.IsNullOrWhiteSpace(comboBoxLogProjectCode.Text) ? null : comboBoxLogProjectCode.Text;
            string LogUser = string.IsNullOrWhiteSpace(comboBoxLogUser.Text) ? null : comboBoxLogUser.Text;
          //  string LogRemarks = string.IsNullOrWhiteSpace(comboBox1Remarks.Text) ? null : comboBox1Remarks.Text;

            // MessageBox.Show(dateTimePickerLogFrom.Text, dateTimePickerLogTo.Text);

            string fromDate = dateTimePickerLogFrom.Checked ? dateTimePickerLogFrom.Text : null;
            string toDate = dateTimePickerLogTo.Checked ? dateTimePickerLogTo.Text : null;

            ERPProjectBOMLockLogsList = DAL.fnGetERPProjectBOMChangesLogs(fromDate, toDate, LogProjectCode, LogUser).Tables[0];

            dataGridViewBOMLockLogs.AutoGenerateColumns = false;


            // Map DataTable columns to your DataGridView columns
            dataGridViewBOMLockLogs.Columns["ProjectCode"].DataPropertyName = "ProjectCode";
            dataGridViewBOMLockLogs.Columns["ProductNumber"].DataPropertyName = "ProductNumber";
            dataGridViewBOMLockLogs.Columns["ProductName"].DataPropertyName = "ProductName";
            dataGridViewBOMLockLogs.Columns["Qty"].DataPropertyName = "Qty";
            //dataGridViewGIN.Columns["BOMProjectCodeGIN"].DataPropertyName = "BOMProjectCode";
            dataGridViewBOMLockLogs.Columns["Cost"].DataPropertyName = "Cost";
            dataGridViewBOMLockLogs.Columns["ActionMadeBy"].DataPropertyName = "ActionMadeBy";
            dataGridViewBOMLockLogs.Columns["Version"].DataPropertyName = "Version";
            dataGridViewBOMLockLogs.Columns["ProductCode"].DataPropertyName = "ProductCode";
            dataGridViewBOMLockLogs.Columns["ProductCategory"].DataPropertyName = "ProductCategory";
            dataGridViewBOMLockLogs.Columns["ProjectBOMNumber"].DataPropertyName = "ProjectBOMNumber";
            dataGridViewBOMLockLogs.Columns["ProjectStatus"].DataPropertyName = "ProjectStatus";
            dataGridViewBOMLockLogs.Columns["ItemCode"].DataPropertyName = "ItemCode";
            dataGridViewBOMLockLogs.Columns["ActionType"].DataPropertyName = "ActionType";
            dataGridViewBOMLockLogs.Columns["CreatedDate"].DataPropertyName = "CreatedDate";

            // Bind the data
            dataGridViewBOMLockLogs.DataSource = ERPProjectBOMLockLogsList;
        }

        private void LOCKTabbutton_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;
            panel1.Visible = true;
           // LOGSButton.Font = new Font(LOCKTabbutton.Font.FontFamily, 9.25f);
            //LOCKTabbutton.Font = new Font(LOCKTabbutton.Font.FontFamily, 11.25f);
           // LOCKTabbutton.BackColor = Color.DodgerBlue;
           // LOCKTabbutton.ForeColor = Color.White;
            LOGSButton.BackColor = Color.White;
            LOGSButton.ForeColor = Color.Black;


        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void FilterApplybutton_Click(object sender, EventArgs e)
        {
            string LogProjectCode = string.IsNullOrWhiteSpace(comboBoxLogProjectCode.Text) ? null : comboBoxLogProjectCode.Text;
            string LogUser = string.IsNullOrWhiteSpace(comboBoxLogUser.Text) ? null : comboBoxLogUser.Text;
           // string LogRemarks = string.IsNullOrWhiteSpace(comboBox1Remarks.Text) ? null : comboBox1Remarks.Text;

            // MessageBox.Show(dateTimePickerLogFrom.Text, dateTimePickerLogTo.Text);

            string fromDate = dateTimePickerLogFrom.Checked ? dateTimePickerLogFrom.Text : null;
            string toDate = dateTimePickerLogTo.Checked ? dateTimePickerLogTo.Text : null;

           

            if (dateTimePickerLogFrom.Value.Date == DateTime.Today && dateTimePickerLogTo.Value.Date == DateTime.Today)
            {
                ERPProjectBOMLockLogsList = DAL.fnGetERPProjectBOMChangesLogs(null, null, LogProjectCode, LogUser).Tables[0];
            }
            else
            {
                ERPProjectBOMLockLogsList = DAL.fnGetERPProjectBOMChangesLogs(fromDate, toDate, LogProjectCode, LogUser).Tables[0];
            }


             //DAL.fnGetERPProjectBOMChangesLogs(fromDate, toDate, LogProjectCode, LogUser).Tables[0];

            dataGridViewBOMLockLogs.AutoGenerateColumns = false;


            // Map DataTable columns to your DataGridView columns
            dataGridViewBOMLockLogs.Columns["ProjectCode"].DataPropertyName = "ProjectCode";
            dataGridViewBOMLockLogs.Columns["ProductNumber"].DataPropertyName = "ProductNumber";
            dataGridViewBOMLockLogs.Columns["ProductName"].DataPropertyName = "ProductName";
            dataGridViewBOMLockLogs.Columns["Qty"].DataPropertyName = "Qty";
            //dataGridViewGIN.Columns["BOMProjectCodeGIN"].DataPropertyName = "BOMProjectCode";
            dataGridViewBOMLockLogs.Columns["Cost"].DataPropertyName = "Cost";
            dataGridViewBOMLockLogs.Columns["ActionMadeBy"].DataPropertyName = "ActionMadeBy";
            dataGridViewBOMLockLogs.Columns["Version"].DataPropertyName = "Version";
            dataGridViewBOMLockLogs.Columns["ProductCode"].DataPropertyName = "ProductCode";
            dataGridViewBOMLockLogs.Columns["ProductCategory"].DataPropertyName = "ProductCategory";
            dataGridViewBOMLockLogs.Columns["ProjectBOMNumber"].DataPropertyName = "ProjectBOMNumber";
            dataGridViewBOMLockLogs.Columns["ProjectStatus"].DataPropertyName = "ProjectStatus";
            dataGridViewBOMLockLogs.Columns["ItemCode"].DataPropertyName = "ItemCode";
            dataGridViewBOMLockLogs.Columns["ActionType"].DataPropertyName = "ActionType";
            dataGridViewBOMLockLogs.Columns["CreatedDate"].DataPropertyName = "CreatedDate";

            // Bind the data
            dataGridViewBOMLockLogs.DataSource = ERPProjectBOMLockLogsList;
        }

        private void ClearFilter_Click(object sender, EventArgs e)
        {
            comboBoxLogProjectCode.Text = "";
            comboBoxLogUser.Text = "";
            comboBox1Remarks.Text = "";
        }

        private void Exportbutton_Click(object sender, EventArgs e)
        {
            try
            {
                string path = Path.Combine(
                              Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                              $"BOM Changes Logs_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx"
                          );
                //MessageBox.Show( ERPProjectBOMLockLogsList.Rows.Count.ToString(),"Count");
                CsvExporter.DataTableToXlsx(ERPProjectBOMLockLogsList, path);

                MessageBox.Show(path,"Successfully Exported");
            }
            catch
            {
                MessageBox.Show("Export Failed Please check with Admin");
            }
        }
    }
}
