﻿namespace Erp_Project_With_Buttons.ProjectBOM
{
    partial class frmProjectBOM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProjectBOM));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            this.gbControlButtons = new System.Windows.Forms.GroupBox();
            this.btnSaveExcel = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnJobItemsView = new System.Windows.Forms.Button();
            this.btnPrintprojectbom = new System.Windows.Forms.Button();
            this.btnPrintBOM = new System.Windows.Forms.Button();
            this.dtpCreatedDate = new System.Windows.Forms.DateTimePicker();
            this.tvProduct = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.dgItemOrProductList = new System.Windows.Forms.DataGridView();
            this.SLNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PProductCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Version = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IssuedAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Progress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectBOM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DesignBOM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StartDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FinishDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbSearchOptions = new System.Windows.Forms.GroupBox();
            this.chkItemDesc = new System.Windows.Forms.CheckBox();
            this.chkItemCode = new System.Windows.Forms.CheckBox();
            this.txtItemCode = new System.Windows.Forms.TextBox();
            this.lblItemCode = new System.Windows.Forms.Label();
            this.chkSelectItem = new System.Windows.Forms.CheckBox();
            this.gbProjectDetails = new System.Windows.Forms.GroupBox();
            this.btnGMApprove = new System.Windows.Forms.Button();
            this.labelLockStatus = new System.Windows.Forms.Label();
            this.txtprojecttarget = new System.Windows.Forms.Label();
            this.labelprojecttarget = new System.Windows.Forms.Label();
            this.oDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.lblJobissuedCost = new System.Windows.Forms.Label();
            this.pnAddProduct = new System.Windows.Forms.Panel();
            this.btnAddCategoryProduct = new System.Windows.Forms.Button();
            this.txtProductCategory = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.chkAddProduct = new System.Windows.Forms.CheckBox();
            this.label66 = new System.Windows.Forms.Label();
            this.lblIssuedCost = new System.Windows.Forms.Label();
            this.cmbProductCategory = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lblperc = new System.Windows.Forms.Label();
            this.lblProjectStaus = new System.Windows.Forms.Label();
            this.txtTotalCost = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblTotalCost = new System.Windows.Forms.Label();
            this.btnProjectView = new System.Windows.Forms.Button();
            this.lblprojectbomlist = new System.Windows.Forms.Label();
            this.txtcustomer = new System.Windows.Forms.Label();
            this.lblcustomer = new System.Windows.Forms.Label();
            this.txtProjectName = new System.Windows.Forms.Label();
            this.lblProjectName = new System.Windows.Forms.Label();
            this.cmbProjectCode = new System.Windows.Forms.ComboBox();
            this.lblProjectCode = new System.Windows.Forms.Label();
            this.pbProjectProgress = new System.Windows.Forms.ProgressBar();
            this.dgBOMList = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IProductType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IssuedQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uBOMQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FixedCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IssueCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BOMAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LatestCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DrawingNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Addedby = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PODate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RevisionNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chklbItemList = new System.Windows.Forms.CheckedListBox();
            this.gbtreesearch = new System.Windows.Forms.GroupBox();
            this.chkProductCode = new System.Windows.Forms.CheckBox();
            this.cmbVersion = new System.Windows.Forms.ComboBox();
            this.lblVersion = new System.Windows.Forms.Label();
            this.cleartreeview = new System.Windows.Forms.Button();
            this.txtsearchtree = new System.Windows.Forms.TextBox();
            this.btnsearchtree = new System.Windows.Forms.Button();
            this.txtItemSearch = new System.Windows.Forms.TextBox();
            this.lblItemcodeorName = new System.Windows.Forms.Label();
            this.lblProductCost = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dgvJobIssuedList = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IssueDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WONumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.cmbWorkDescription = new System.Windows.Forms.ComboBox();
            this.gbControlButtons.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgItemOrProductList)).BeginInit();
            this.gbSearchOptions.SuspendLayout();
            this.gbProjectDetails.SuspendLayout();
            this.pnAddProduct.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgBOMList)).BeginInit();
            this.gbtreesearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvJobIssuedList)).BeginInit();
            this.SuspendLayout();
            // 
            // gbControlButtons
            // 
            this.gbControlButtons.Controls.Add(this.btnSaveExcel);
            this.gbControlButtons.Controls.Add(this.btnExit);
            this.gbControlButtons.Controls.Add(this.btnJobItemsView);
            this.gbControlButtons.Controls.Add(this.btnPrintprojectbom);
            this.gbControlButtons.Controls.Add(this.btnPrintBOM);
            this.gbControlButtons.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.gbControlButtons.Location = new System.Drawing.Point(381, 628);
            this.gbControlButtons.Name = "gbControlButtons";
            this.gbControlButtons.Size = new System.Drawing.Size(931, 53);
            this.gbControlButtons.TabIndex = 63;
            this.gbControlButtons.TabStop = false;
            // 
            // btnSaveExcel
            // 
            this.btnSaveExcel.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSaveExcel.Enabled = false;
            this.btnSaveExcel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSaveExcel.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveExcel.Location = new System.Drawing.Point(626, 13);
            this.btnSaveExcel.Name = "btnSaveExcel";
            this.btnSaveExcel.Size = new System.Drawing.Size(155, 35);
            this.btnSaveExcel.TabIndex = 13;
            this.btnSaveExcel.Text = "Export Full Project";
            this.btnSaveExcel.UseVisualStyleBackColor = false;
            this.btnSaveExcel.Click += new System.EventHandler(this.btnSaveExcel_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnExit.Location = new System.Drawing.Point(823, 12);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(96, 35);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnJobItemsView
            // 
            this.btnJobItemsView.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnJobItemsView.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnJobItemsView.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJobItemsView.Location = new System.Drawing.Point(10, 12);
            this.btnJobItemsView.Name = "btnJobItemsView";
            this.btnJobItemsView.Size = new System.Drawing.Size(184, 35);
            this.btnJobItemsView.TabIndex = 116;
            this.btnJobItemsView.Text = "View Job Issued Items";
            this.btnJobItemsView.UseVisualStyleBackColor = false;
            this.btnJobItemsView.Click += new System.EventHandler(this.btnJobItemsView_Click);
            // 
            // btnPrintprojectbom
            // 
            this.btnPrintprojectbom.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnPrintprojectbom.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnPrintprojectbom.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrintprojectbom.Location = new System.Drawing.Point(444, 13);
            this.btnPrintprojectbom.Name = "btnPrintprojectbom";
            this.btnPrintprojectbom.Size = new System.Drawing.Size(155, 35);
            this.btnPrintprojectbom.TabIndex = 12;
            this.btnPrintprojectbom.Text = "Export Product BOM";
            this.btnPrintprojectbom.UseVisualStyleBackColor = false;
            this.btnPrintprojectbom.Click += new System.EventHandler(this.btnPrintprojectbom_Click);
            // 
            // btnPrintBOM
            // 
            this.btnPrintBOM.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnPrintBOM.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnPrintBOM.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Bold);
            this.btnPrintBOM.Location = new System.Drawing.Point(228, 12);
            this.btnPrintBOM.Name = "btnPrintBOM";
            this.btnPrintBOM.Size = new System.Drawing.Size(177, 35);
            this.btnPrintBOM.TabIndex = 117;
            this.btnPrintBOM.Text = "Export Selected Product";
            this.btnPrintBOM.UseVisualStyleBackColor = false;
            this.btnPrintBOM.Click += new System.EventHandler(this.btnPrintBOM_Click);
            // 
            // dtpCreatedDate
            // 
            this.dtpCreatedDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpCreatedDate.Location = new System.Drawing.Point(1175, 96);
            this.dtpCreatedDate.Name = "dtpCreatedDate";
            this.dtpCreatedDate.Size = new System.Drawing.Size(91, 22);
            this.dtpCreatedDate.TabIndex = 12;
            // 
            // tvProduct
            // 
            this.tvProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tvProduct.Location = new System.Drawing.Point(3, 237);
            this.tvProduct.Name = "tvProduct";
            this.tvProduct.Size = new System.Drawing.Size(373, 445);
            this.tvProduct.StateImageList = this.imageList1;
            this.tvProduct.TabIndex = 62;
            this.tvProduct.AfterLabelEdit += new System.Windows.Forms.NodeLabelEditEventHandler(this.tvProduct_AfterLabelEdit);
            this.tvProduct.NodeMouseDoubleClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.tvProduct_NodeMouseDoubleClick);
            this.tvProduct.KeyUp += new System.Windows.Forms.KeyEventHandler(this.tvProduct_KeyUp);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "folderopened_yellow.ico");
            this.imageList1.Images.SetKeyName(1, "diagram_v2_17.ico");
            this.imageList1.Images.SetKeyName(2, "Dryicons-Aesthetica-2-Process-accept.ico");
            this.imageList1.Images.SetKeyName(3, "Dryicons-Aesthetica-2-Process-remove.ico");
            this.imageList1.Images.SetKeyName(4, "Rafiqul-Hassan-Blogger-Settings.ico");
            // 
            // dgItemOrProductList
            // 
            this.dgItemOrProductList.AllowUserToAddRows = false;
            this.dgItemOrProductList.AllowUserToDeleteRows = false;
            this.dgItemOrProductList.AllowUserToResizeRows = false;
            this.dgItemOrProductList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgItemOrProductList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgItemOrProductList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgItemOrProductList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgItemOrProductList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgItemOrProductList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SLNO,
            this.PProductCode,
            this.ProductName,
            this.Version,
            this.ProductType,
            this.Quantity,
            this.UnitCost,
            this.IssuedAmount,
            this.Progress,
            this.ProjectBOM,
            this.DesignBOM,
            this.StartDate,
            this.FinishDate});
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgItemOrProductList.DefaultCellStyle = dataGridViewCellStyle9;
            this.dgItemOrProductList.EnableHeadersVisualStyles = false;
            this.dgItemOrProductList.Location = new System.Drawing.Point(381, 133);
            this.dgItemOrProductList.MultiSelect = false;
            this.dgItemOrProductList.Name = "dgItemOrProductList";
            this.dgItemOrProductList.RowHeadersVisible = false;
            this.dgItemOrProductList.RowHeadersWidth = 62;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgItemOrProductList.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.dgItemOrProductList.Size = new System.Drawing.Size(938, 256);
            this.dgItemOrProductList.TabIndex = 61;
            this.dgItemOrProductList.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgItemOrProductList_CellBeginEdit);
            this.dgItemOrProductList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgItemOrProductList_CellClick);
            this.dgItemOrProductList.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgItemOrProductList_CellEndEdit);
            this.dgItemOrProductList.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgItemOrProductList_CellEnter);
            this.dgItemOrProductList.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgItemOrProductList_EditingControlShowing);
            this.dgItemOrProductList.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgItemOrProductList_KeyUp);
            // 
            // SLNO
            // 
            this.SLNO.DataPropertyName = "SlNo";
            this.SLNO.HeaderText = "SlNo";
            this.SLNO.MinimumWidth = 8;
            this.SLNO.Name = "SLNO";
            this.SLNO.ReadOnly = true;
            this.SLNO.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SLNO.Width = 47;
            // 
            // PProductCode
            // 
            this.PProductCode.DataPropertyName = "ProductCode";
            this.PProductCode.HeaderText = "ProductCode";
            this.PProductCode.MinimumWidth = 8;
            this.PProductCode.Name = "PProductCode";
            this.PProductCode.ReadOnly = true;
            this.PProductCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PProductCode.Width = 104;
            // 
            // ProductName
            // 
            this.ProductName.DataPropertyName = "ProductName";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ProductName.DefaultCellStyle = dataGridViewCellStyle2;
            this.ProductName.HeaderText = "Product Name";
            this.ProductName.MinimumWidth = 8;
            this.ProductName.Name = "ProductName";
            this.ProductName.ReadOnly = true;
            this.ProductName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductName.Width = 114;
            // 
            // Version
            // 
            this.Version.DataPropertyName = "Version";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Version.DefaultCellStyle = dataGridViewCellStyle3;
            this.Version.HeaderText = "Version";
            this.Version.MinimumWidth = 8;
            this.Version.Name = "Version";
            this.Version.ReadOnly = true;
            this.Version.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Version.Width = 65;
            // 
            // ProductType
            // 
            this.ProductType.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ProductType.DataPropertyName = "ProductType";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ProductType.DefaultCellStyle = dataGridViewCellStyle4;
            this.ProductType.HeaderText = "Product Type";
            this.ProductType.MinimumWidth = 8;
            this.ProductType.Name = "ProductType";
            this.ProductType.ReadOnly = true;
            this.ProductType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductType.Visible = false;
            this.ProductType.Width = 107;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "Quantity";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Quantity.DefaultCellStyle = dataGridViewCellStyle5;
            this.Quantity.HeaderText = "Qty";
            this.Quantity.MinimumWidth = 8;
            this.Quantity.Name = "Quantity";
            this.Quantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Quantity.Width = 40;
            // 
            // UnitCost
            // 
            this.UnitCost.DataPropertyName = "UnitCost";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.Format = "N0";
            dataGridViewCellStyle6.NullValue = null;
            this.UnitCost.DefaultCellStyle = dataGridViewCellStyle6;
            this.UnitCost.HeaderText = "Project Cost";
            this.UnitCost.MinimumWidth = 8;
            this.UnitCost.Name = "UnitCost";
            this.UnitCost.ReadOnly = true;
            this.UnitCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitCost.Width = 97;
            // 
            // IssuedAmount
            // 
            this.IssuedAmount.DataPropertyName = "IssuedAmount";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.Format = "N0";
            dataGridViewCellStyle7.NullValue = null;
            this.IssuedAmount.DefaultCellStyle = dataGridViewCellStyle7;
            this.IssuedAmount.HeaderText = "Issued Amount";
            this.IssuedAmount.MinimumWidth = 8;
            this.IssuedAmount.Name = "IssuedAmount";
            this.IssuedAmount.ReadOnly = true;
            this.IssuedAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IssuedAmount.Width = 117;
            // 
            // Progress
            // 
            this.Progress.DataPropertyName = "Progress";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Progress.DefaultCellStyle = dataGridViewCellStyle8;
            this.Progress.HeaderText = "Progress(%)";
            this.Progress.MinimumWidth = 8;
            this.Progress.Name = "Progress";
            this.Progress.ReadOnly = true;
            this.Progress.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Progress.Width = 95;
            // 
            // ProjectBOM
            // 
            this.ProjectBOM.DataPropertyName = "ProjectBOM";
            this.ProjectBOM.HeaderText = "ProjectBOM";
            this.ProjectBOM.MinimumWidth = 8;
            this.ProjectBOM.Name = "ProjectBOM";
            this.ProjectBOM.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectBOM.Visible = false;
            this.ProjectBOM.Width = 98;
            // 
            // DesignBOM
            // 
            this.DesignBOM.DataPropertyName = "DesignBOM";
            this.DesignBOM.HeaderText = "DesignBOM";
            this.DesignBOM.MinimumWidth = 8;
            this.DesignBOM.Name = "DesignBOM";
            this.DesignBOM.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DesignBOM.Visible = false;
            this.DesignBOM.Width = 94;
            // 
            // StartDate
            // 
            this.StartDate.DataPropertyName = "StartDate";
            this.StartDate.HeaderText = "Start Date";
            this.StartDate.MinimumWidth = 8;
            this.StartDate.Name = "StartDate";
            this.StartDate.ReadOnly = true;
            this.StartDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.StartDate.Width = 85;
            // 
            // FinishDate
            // 
            this.FinishDate.DataPropertyName = "FinishDate";
            this.FinishDate.HeaderText = "Finish Date";
            this.FinishDate.MinimumWidth = 8;
            this.FinishDate.Name = "FinishDate";
            this.FinishDate.ReadOnly = true;
            this.FinishDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.FinishDate.Width = 90;
            // 
            // gbSearchOptions
            // 
            this.gbSearchOptions.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.gbSearchOptions.Controls.Add(this.chkItemDesc);
            this.gbSearchOptions.Controls.Add(this.chkItemCode);
            this.gbSearchOptions.Controls.Add(this.txtItemCode);
            this.gbSearchOptions.Controls.Add(this.lblItemCode);
            this.gbSearchOptions.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.gbSearchOptions.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbSearchOptions.Location = new System.Drawing.Point(5, 130);
            this.gbSearchOptions.Name = "gbSearchOptions";
            this.gbSearchOptions.Size = new System.Drawing.Size(373, 95);
            this.gbSearchOptions.TabIndex = 60;
            this.gbSearchOptions.TabStop = false;
            this.gbSearchOptions.Visible = false;
            // 
            // chkItemDesc
            // 
            this.chkItemDesc.AutoSize = true;
            this.chkItemDesc.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemDesc.ForeColor = System.Drawing.Color.Black;
            this.chkItemDesc.Location = new System.Drawing.Point(226, 16);
            this.chkItemDesc.Name = "chkItemDesc";
            this.chkItemDesc.Size = new System.Drawing.Size(140, 23);
            this.chkItemDesc.TabIndex = 213;
            this.chkItemDesc.Text = "Item Description";
            this.chkItemDesc.UseVisualStyleBackColor = true;
            this.chkItemDesc.CheckedChanged += new System.EventHandler(this.chkItemDesc_CheckedChanged);
            // 
            // chkItemCode
            // 
            this.chkItemCode.AutoSize = true;
            this.chkItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemCode.ForeColor = System.Drawing.Color.Black;
            this.chkItemCode.Location = new System.Drawing.Point(124, 16);
            this.chkItemCode.Name = "chkItemCode";
            this.chkItemCode.Size = new System.Drawing.Size(97, 23);
            this.chkItemCode.TabIndex = 212;
            this.chkItemCode.Text = "Item Code";
            this.chkItemCode.UseVisualStyleBackColor = true;
            this.chkItemCode.CheckedChanged += new System.EventHandler(this.chkItemCode_CheckedChanged);
            // 
            // txtItemCode
            // 
            this.txtItemCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemCode.Location = new System.Drawing.Point(6, 38);
            this.txtItemCode.Multiline = true;
            this.txtItemCode.Name = "txtItemCode";
            this.txtItemCode.Size = new System.Drawing.Size(360, 49);
            this.txtItemCode.TabIndex = 1;
            this.txtItemCode.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtItemCode_MouseClick);
            this.txtItemCode.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemCode_KeyUp);
            // 
            // lblItemCode
            // 
            this.lblItemCode.AutoSize = true;
            this.lblItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemCode.Location = new System.Drawing.Point(6, 15);
            this.lblItemCode.Name = "lblItemCode";
            this.lblItemCode.Size = new System.Drawing.Size(115, 19);
            this.lblItemCode.TabIndex = 0;
            this.lblItemCode.Text = "Search Item by:";
            // 
            // chkSelectItem
            // 
            this.chkSelectItem.AutoSize = true;
            this.chkSelectItem.Enabled = false;
            this.chkSelectItem.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkSelectItem.ForeColor = System.Drawing.Color.Green;
            this.chkSelectItem.Location = new System.Drawing.Point(7, 107);
            this.chkSelectItem.Name = "chkSelectItem";
            this.chkSelectItem.Size = new System.Drawing.Size(103, 23);
            this.chkSelectItem.TabIndex = 0;
            this.chkSelectItem.Text = "Add Item(s)";
            this.chkSelectItem.UseVisualStyleBackColor = true;
            this.chkSelectItem.CheckedChanged += new System.EventHandler(this.chkSelectItem_CheckedChanged);
            // 
            // gbProjectDetails
            // 
            this.gbProjectDetails.Controls.Add(this.btnGMApprove);
            this.gbProjectDetails.Controls.Add(this.labelLockStatus);
            this.gbProjectDetails.Controls.Add(this.txtprojecttarget);
            this.gbProjectDetails.Controls.Add(this.labelprojecttarget);
            this.gbProjectDetails.Controls.Add(this.oDateTimePicker);
            this.gbProjectDetails.Controls.Add(this.chkSelectItem);
            this.gbProjectDetails.Controls.Add(this.lblJobissuedCost);
            this.gbProjectDetails.Controls.Add(this.pnAddProduct);
            this.gbProjectDetails.Controls.Add(this.label8);
            this.gbProjectDetails.Controls.Add(this.chkAddProduct);
            this.gbProjectDetails.Controls.Add(this.label66);
            this.gbProjectDetails.Controls.Add(this.lblIssuedCost);
            this.gbProjectDetails.Controls.Add(this.cmbProductCategory);
            this.gbProjectDetails.Controls.Add(this.label4);
            this.gbProjectDetails.Controls.Add(this.lblperc);
            this.gbProjectDetails.Controls.Add(this.lblProjectStaus);
            this.gbProjectDetails.Controls.Add(this.txtTotalCost);
            this.gbProjectDetails.Controls.Add(this.label5);
            this.gbProjectDetails.Controls.Add(this.lblTotalCost);
            this.gbProjectDetails.Controls.Add(this.btnProjectView);
            this.gbProjectDetails.Controls.Add(this.lblprojectbomlist);
            this.gbProjectDetails.Controls.Add(this.txtcustomer);
            this.gbProjectDetails.Controls.Add(this.lblcustomer);
            this.gbProjectDetails.Controls.Add(this.txtProjectName);
            this.gbProjectDetails.Controls.Add(this.lblProjectName);
            this.gbProjectDetails.Controls.Add(this.cmbProjectCode);
            this.gbProjectDetails.Controls.Add(this.lblProjectCode);
            this.gbProjectDetails.Controls.Add(this.pbProjectProgress);
            this.gbProjectDetails.Controls.Add(this.dtpCreatedDate);
            this.gbProjectDetails.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbProjectDetails.ForeColor = System.Drawing.Color.Black;
            this.gbProjectDetails.Location = new System.Drawing.Point(4, -5);
            this.gbProjectDetails.Name = "gbProjectDetails";
            this.gbProjectDetails.Size = new System.Drawing.Size(1315, 132);
            this.gbProjectDetails.TabIndex = 64;
            this.gbProjectDetails.TabStop = false;
            // 
            // btnGMApprove
            // 
            this.btnGMApprove.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGMApprove.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnGMApprove.Location = new System.Drawing.Point(750, 8);
            this.btnGMApprove.Name = "btnGMApprove";
            this.btnGMApprove.Size = new System.Drawing.Size(136, 34);
            this.btnGMApprove.TabIndex = 226;
            this.btnGMApprove.Text = "Request Approve";
            this.btnGMApprove.UseVisualStyleBackColor = true;
            this.btnGMApprove.Visible = false;
            this.btnGMApprove.Click += new System.EventHandler(this.btnGMApprove_Click);
            // 
            // labelLockStatus
            // 
            this.labelLockStatus.AutoSize = true;
            this.labelLockStatus.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLockStatus.ForeColor = System.Drawing.Color.Red;
            this.labelLockStatus.Location = new System.Drawing.Point(626, 16);
            this.labelLockStatus.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelLockStatus.Name = "labelLockStatus";
            this.labelLockStatus.Size = new System.Drawing.Size(82, 19);
            this.labelLockStatus.TabIndex = 230;
            this.labelLockStatus.Text = "BOM LOCK";
            this.labelLockStatus.Visible = false;
            // 
            // txtprojecttarget
            // 
            this.txtprojecttarget.AutoSize = true;
            this.txtprojecttarget.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtprojecttarget.Location = new System.Drawing.Point(1144, 10);
            this.txtprojecttarget.Name = "txtprojecttarget";
            this.txtprojecttarget.Size = new System.Drawing.Size(15, 18);
            this.txtprojecttarget.TabIndex = 229;
            this.txtprojecttarget.Text = "0";
            // 
            // labelprojecttarget
            // 
            this.labelprojecttarget.AutoSize = true;
            this.labelprojecttarget.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelprojecttarget.Location = new System.Drawing.Point(1040, 10);
            this.labelprojecttarget.Name = "labelprojecttarget";
            this.labelprojecttarget.Size = new System.Drawing.Size(100, 18);
            this.labelprojecttarget.TabIndex = 228;
            this.labelprojecttarget.Text = "Project Target :";
            // 
            // oDateTimePicker
            // 
            this.oDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.oDateTimePicker.Location = new System.Drawing.Point(902, 87);
            this.oDateTimePicker.Name = "oDateTimePicker";
            this.oDateTimePicker.Size = new System.Drawing.Size(94, 22);
            this.oDateTimePicker.TabIndex = 227;
            this.oDateTimePicker.Visible = false;
            this.oDateTimePicker.CloseUp += new System.EventHandler(this.oDateTimePicker_CloseUp);
            this.oDateTimePicker.TabIndexChanged += new System.EventHandler(this.oDateTimePicker_TabIndexChanged);
            // 
            // lblJobissuedCost
            // 
            this.lblJobissuedCost.AutoSize = true;
            this.lblJobissuedCost.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJobissuedCost.ForeColor = System.Drawing.Color.Black;
            this.lblJobissuedCost.Location = new System.Drawing.Point(1144, 70);
            this.lblJobissuedCost.Name = "lblJobissuedCost";
            this.lblJobissuedCost.Size = new System.Drawing.Size(15, 18);
            this.lblJobissuedCost.TabIndex = 118;
            this.lblJobissuedCost.Text = "0";
            this.lblJobissuedCost.Visible = false;
            // 
            // pnAddProduct
            // 
            this.pnAddProduct.Controls.Add(this.btnAddCategoryProduct);
            this.pnAddProduct.Controls.Add(this.txtProductCategory);
            this.pnAddProduct.Location = new System.Drawing.Point(484, 81);
            this.pnAddProduct.Name = "pnAddProduct";
            this.pnAddProduct.Size = new System.Drawing.Size(362, 39);
            this.pnAddProduct.TabIndex = 225;
            this.pnAddProduct.Visible = false;
            // 
            // btnAddCategoryProduct
            // 
            this.btnAddCategoryProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddCategoryProduct.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnAddCategoryProduct.Location = new System.Drawing.Point(310, 6);
            this.btnAddCategoryProduct.Name = "btnAddCategoryProduct";
            this.btnAddCategoryProduct.Size = new System.Drawing.Size(46, 26);
            this.btnAddCategoryProduct.TabIndex = 135;
            this.btnAddCategoryProduct.Text = "Add";
            this.btnAddCategoryProduct.UseVisualStyleBackColor = true;
            this.btnAddCategoryProduct.Click += new System.EventHandler(this.btnAddCategoryProduct_Click);
            // 
            // txtProductCategory
            // 
            this.txtProductCategory.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProductCategory.Location = new System.Drawing.Point(5, 6);
            this.txtProductCategory.Name = "txtProductCategory";
            this.txtProductCategory.Size = new System.Drawing.Size(302, 26);
            this.txtProductCategory.TabIndex = 134;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(1031, 70);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(109, 18);
            this.label8.TabIndex = 117;
            this.label8.Text = "Job Issued Cost :";
            this.label8.Visible = false;
            // 
            // chkAddProduct
            // 
            this.chkAddProduct.AutoSize = true;
            this.chkAddProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkAddProduct.ForeColor = System.Drawing.Color.Black;
            this.chkAddProduct.Location = new System.Drawing.Point(133, 107);
            this.chkAddProduct.Name = "chkAddProduct";
            this.chkAddProduct.Size = new System.Drawing.Size(168, 23);
            this.chkAddProduct.TabIndex = 224;
            this.chkAddProduct.Text = "Add Product Category";
            this.chkAddProduct.UseVisualStyleBackColor = true;
            this.chkAddProduct.CheckedChanged += new System.EventHandler(this.chkAddProduct_CheckedChanged);
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.ForeColor = System.Drawing.Color.Black;
            this.label66.Location = new System.Drawing.Point(10, 84);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(121, 18);
            this.label66.TabIndex = 222;
            this.label66.Text = "Product Category :";
            // 
            // lblIssuedCost
            // 
            this.lblIssuedCost.AutoSize = true;
            this.lblIssuedCost.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIssuedCost.ForeColor = System.Drawing.Color.Black;
            this.lblIssuedCost.Location = new System.Drawing.Point(1144, 48);
            this.lblIssuedCost.Name = "lblIssuedCost";
            this.lblIssuedCost.Size = new System.Drawing.Size(15, 18);
            this.lblIssuedCost.TabIndex = 116;
            this.lblIssuedCost.Text = "0";
            // 
            // cmbProductCategory
            // 
            this.cmbProductCategory.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbProductCategory.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProductCategory.DropDownHeight = 180;
            this.cmbProductCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProductCategory.DropDownWidth = 150;
            this.cmbProductCategory.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProductCategory.FormattingEnabled = true;
            this.cmbProductCategory.IntegralHeight = false;
            this.cmbProductCategory.Location = new System.Drawing.Point(133, 81);
            this.cmbProductCategory.Name = "cmbProductCategory";
            this.cmbProductCategory.Size = new System.Drawing.Size(329, 26);
            this.cmbProductCategory.TabIndex = 223;
            this.cmbProductCategory.SelectedIndexChanged += new System.EventHandler(this.cmbProductCategory_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(1055, 48);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 18);
            this.label4.TabIndex = 115;
            this.label4.Text = "Issued Cost :";
            // 
            // lblperc
            // 
            this.lblperc.AutoSize = true;
            this.lblperc.BackColor = System.Drawing.Color.Transparent;
            this.lblperc.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblperc.ForeColor = System.Drawing.Color.Transparent;
            this.lblperc.Location = new System.Drawing.Point(1159, 96);
            this.lblperc.Name = "lblperc";
            this.lblperc.Size = new System.Drawing.Size(21, 19);
            this.lblperc.TabIndex = 115;
            this.lblperc.Text = "%";
            // 
            // lblProjectStaus
            // 
            this.lblProjectStaus.AutoSize = true;
            this.lblProjectStaus.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectStaus.ForeColor = System.Drawing.Color.Black;
            this.lblProjectStaus.Location = new System.Drawing.Point(532, 14);
            this.lblProjectStaus.Name = "lblProjectStaus";
            this.lblProjectStaus.Size = new System.Drawing.Size(12, 18);
            this.lblProjectStaus.TabIndex = 73;
            this.lblProjectStaus.Text = ".";
            // 
            // txtTotalCost
            // 
            this.txtTotalCost.AutoSize = true;
            this.txtTotalCost.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalCost.ForeColor = System.Drawing.Color.Black;
            this.txtTotalCost.Location = new System.Drawing.Point(1144, 30);
            this.txtTotalCost.Name = "txtTotalCost";
            this.txtTotalCost.Size = new System.Drawing.Size(15, 18);
            this.txtTotalCost.TabIndex = 65;
            this.txtTotalCost.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(481, 14);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 18);
            this.label5.TabIndex = 74;
            this.label5.Text = "Status :";
            // 
            // lblTotalCost
            // 
            this.lblTotalCost.AutoSize = true;
            this.lblTotalCost.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalCost.ForeColor = System.Drawing.Color.Black;
            this.lblTotalCost.Location = new System.Drawing.Point(1051, 30);
            this.lblTotalCost.Name = "lblTotalCost";
            this.lblTotalCost.Size = new System.Drawing.Size(89, 18);
            this.lblTotalCost.TabIndex = 65;
            this.lblTotalCost.Text = "Project Cost :";
            // 
            // btnProjectView
            // 
            this.btnProjectView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnProjectView.Location = new System.Drawing.Point(451, 8);
            this.btnProjectView.Name = "btnProjectView";
            this.btnProjectView.Size = new System.Drawing.Size(24, 29);
            this.btnProjectView.TabIndex = 72;
            this.btnProjectView.Text = "....";
            this.btnProjectView.UseVisualStyleBackColor = false;
            this.btnProjectView.Click += new System.EventHandler(this.btnProjectView_Click);
            // 
            // lblprojectbomlist
            // 
            this.lblprojectbomlist.AutoSize = true;
            this.lblprojectbomlist.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprojectbomlist.ForeColor = System.Drawing.Color.Black;
            this.lblprojectbomlist.Location = new System.Drawing.Point(1012, 95);
            this.lblprojectbomlist.Name = "lblprojectbomlist";
            this.lblprojectbomlist.Size = new System.Drawing.Size(128, 19);
            this.lblprojectbomlist.TabIndex = 75;
            this.lblprojectbomlist.Text = "Project Progress :";
            // 
            // txtcustomer
            // 
            this.txtcustomer.AutoSize = true;
            this.txtcustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcustomer.ForeColor = System.Drawing.Color.Black;
            this.txtcustomer.Location = new System.Drawing.Point(100, 61);
            this.txtcustomer.Name = "txtcustomer";
            this.txtcustomer.Size = new System.Drawing.Size(12, 18);
            this.txtcustomer.TabIndex = 5;
            this.txtcustomer.Text = ".";
            // 
            // lblcustomer
            // 
            this.lblcustomer.AutoSize = true;
            this.lblcustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcustomer.ForeColor = System.Drawing.Color.Black;
            this.lblcustomer.Location = new System.Drawing.Point(28, 61);
            this.lblcustomer.Name = "lblcustomer";
            this.lblcustomer.Size = new System.Drawing.Size(75, 18);
            this.lblcustomer.TabIndex = 5;
            this.lblcustomer.Text = "Customer :";
            // 
            // txtProjectName
            // 
            this.txtProjectName.AutoSize = true;
            this.txtProjectName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProjectName.ForeColor = System.Drawing.Color.Black;
            this.txtProjectName.Location = new System.Drawing.Point(100, 41);
            this.txtProjectName.Name = "txtProjectName";
            this.txtProjectName.Size = new System.Drawing.Size(12, 18);
            this.txtProjectName.TabIndex = 3;
            this.txtProjectName.Text = ".";
            // 
            // lblProjectName
            // 
            this.lblProjectName.AutoSize = true;
            this.lblProjectName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectName.ForeColor = System.Drawing.Color.Black;
            this.lblProjectName.Location = new System.Drawing.Point(6, 41);
            this.lblProjectName.Name = "lblProjectName";
            this.lblProjectName.Size = new System.Drawing.Size(96, 18);
            this.lblProjectName.TabIndex = 3;
            this.lblProjectName.Text = "Project Name:";
            // 
            // cmbProjectCode
            // 
            this.cmbProjectCode.DropDownHeight = 130;
            this.cmbProjectCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProjectCode.FormattingEnabled = true;
            this.cmbProjectCode.IntegralHeight = false;
            this.cmbProjectCode.Location = new System.Drawing.Point(115, 10);
            this.cmbProjectCode.Name = "cmbProjectCode";
            this.cmbProjectCode.Size = new System.Drawing.Size(330, 26);
            this.cmbProjectCode.TabIndex = 2;
            this.cmbProjectCode.SelectedIndexChanged += new System.EventHandler(this.cmbProjectCode_SelectedIndexChanged);
            // 
            // lblProjectCode
            // 
            this.lblProjectCode.AutoSize = true;
            this.lblProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectCode.ForeColor = System.Drawing.Color.Black;
            this.lblProjectCode.Location = new System.Drawing.Point(6, 13);
            this.lblProjectCode.Name = "lblProjectCode";
            this.lblProjectCode.Size = new System.Drawing.Size(98, 18);
            this.lblProjectCode.TabIndex = 1;
            this.lblProjectCode.Text = "Project Code*:";
            // 
            // pbProjectProgress
            // 
            this.pbProjectProgress.Location = new System.Drawing.Point(1147, 91);
            this.pbProjectProgress.Name = "pbProjectProgress";
            this.pbProjectProgress.Size = new System.Drawing.Size(120, 29);
            this.pbProjectProgress.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.pbProjectProgress.TabIndex = 77;
            // 
            // dgBOMList
            // 
            this.dgBOMList.AllowUserToAddRows = false;
            this.dgBOMList.AllowUserToDeleteRows = false;
            this.dgBOMList.AllowUserToResizeRows = false;
            this.dgBOMList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgBOMList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgBOMList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgBOMList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.dgBOMList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgBOMList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.IProductType,
            this.uItemCode,
            this.uItemDescription,
            this.IssuedQuantity,
            this.uBOMQty,
            this.FixedCost,
            this.IssueCost,
            this.BOMAmount,
            this.UnitPrice,
            this.LatestCost,
            this.Date,
            this.DrawingNo,
            this.Addedby,
            this.PODate,
            this.RevisionNo,
            this.Status});
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgBOMList.DefaultCellStyle = dataGridViewCellStyle20;
            this.dgBOMList.EnableHeadersVisualStyles = false;
            this.dgBOMList.Location = new System.Drawing.Point(381, 419);
            this.dgBOMList.MultiSelect = false;
            this.dgBOMList.Name = "dgBOMList";
            this.dgBOMList.RowHeadersVisible = false;
            this.dgBOMList.RowHeadersWidth = 62;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgBOMList.RowsDefaultCellStyle = dataGridViewCellStyle21;
            this.dgBOMList.Size = new System.Drawing.Size(931, 209);
            this.dgBOMList.TabIndex = 73;
            this.dgBOMList.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgBOMList_CellBeginEdit);
            this.dgBOMList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgBOMList_CellClick);
            this.dgBOMList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgBOMList_CellContentClick);
            this.dgBOMList.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgBOMList_CellEndEdit);
            this.dgBOMList.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgBOMList_EditingControlShowing);
            this.dgBOMList.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgBOMList_KeyUp);
            // 
            // ID
            // 
            this.ID.DataPropertyName = "ID";
            this.ID.HeaderText = "ID";
            this.ID.MinimumWidth = 8;
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ID.Visible = false;
            this.ID.Width = 29;
            // 
            // IProductType
            // 
            this.IProductType.DataPropertyName = "ProductType";
            this.IProductType.HeaderText = "ProductType";
            this.IProductType.MinimumWidth = 8;
            this.IProductType.Name = "IProductType";
            this.IProductType.ReadOnly = true;
            this.IProductType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IProductType.Width = 103;
            // 
            // uItemCode
            // 
            this.uItemCode.DataPropertyName = "ItemName";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.uItemCode.DefaultCellStyle = dataGridViewCellStyle12;
            this.uItemCode.HeaderText = "Item Code";
            this.uItemCode.MinimumWidth = 8;
            this.uItemCode.Name = "uItemCode";
            this.uItemCode.ReadOnly = true;
            this.uItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.uItemCode.Width = 76;
            // 
            // uItemDescription
            // 
            this.uItemDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.uItemDescription.DataPropertyName = "ItemDescription";
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.uItemDescription.DefaultCellStyle = dataGridViewCellStyle13;
            this.uItemDescription.HeaderText = "Item Description";
            this.uItemDescription.MinimumWidth = 8;
            this.uItemDescription.Name = "uItemDescription";
            this.uItemDescription.ReadOnly = true;
            this.uItemDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.uItemDescription.Width = 125;
            // 
            // IssuedQuantity
            // 
            this.IssuedQuantity.DataPropertyName = "IssuedQuantity";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.IssuedQuantity.DefaultCellStyle = dataGridViewCellStyle14;
            this.IssuedQuantity.HeaderText = "Issued Qty";
            this.IssuedQuantity.MinimumWidth = 8;
            this.IssuedQuantity.Name = "IssuedQuantity";
            this.IssuedQuantity.ReadOnly = true;
            this.IssuedQuantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IssuedQuantity.Width = 77;
            // 
            // uBOMQty
            // 
            this.uBOMQty.DataPropertyName = "Quantity";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.uBOMQty.DefaultCellStyle = dataGridViewCellStyle15;
            this.uBOMQty.HeaderText = "BOM Qty";
            this.uBOMQty.MinimumWidth = 8;
            this.uBOMQty.Name = "uBOMQty";
            this.uBOMQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.uBOMQty.Width = 70;
            // 
            // FixedCost
            // 
            this.FixedCost.DataPropertyName = "FixedCost";
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.FixedCost.DefaultCellStyle = dataGridViewCellStyle16;
            this.FixedCost.HeaderText = "FixedCost";
            this.FixedCost.MinimumWidth = 8;
            this.FixedCost.Name = "FixedCost";
            this.FixedCost.ReadOnly = true;
            this.FixedCost.Width = 98;
            // 
            // IssueCost
            // 
            this.IssueCost.DataPropertyName = "IssueCost";
            this.IssueCost.HeaderText = "IssuedCost";
            this.IssueCost.MinimumWidth = 8;
            this.IssueCost.Name = "IssueCost";
            this.IssueCost.Width = 105;
            // 
            // BOMAmount
            // 
            this.BOMAmount.DataPropertyName = "BOMAmount";
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle17.Format = "N2";
            dataGridViewCellStyle17.NullValue = null;
            this.BOMAmount.DefaultCellStyle = dataGridViewCellStyle17;
            this.BOMAmount.HeaderText = "Amount";
            this.BOMAmount.MinimumWidth = 8;
            this.BOMAmount.Name = "BOMAmount";
            this.BOMAmount.ReadOnly = true;
            this.BOMAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.BOMAmount.Visible = false;
            this.BOMAmount.Width = 71;
            // 
            // UnitPrice
            // 
            this.UnitPrice.DataPropertyName = "UnitCost";
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle18.Format = "N2";
            dataGridViewCellStyle18.NullValue = null;
            this.UnitPrice.DefaultCellStyle = dataGridViewCellStyle18;
            this.UnitPrice.HeaderText = "Unit Cost";
            this.UnitPrice.MinimumWidth = 8;
            this.UnitPrice.Name = "UnitPrice";
            this.UnitPrice.ReadOnly = true;
            this.UnitPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitPrice.Visible = false;
            this.UnitPrice.Width = 69;
            // 
            // LatestCost
            // 
            this.LatestCost.DataPropertyName = "LatestCost";
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle19.Format = "N2";
            dataGridViewCellStyle19.NullValue = null;
            this.LatestCost.DefaultCellStyle = dataGridViewCellStyle19;
            this.LatestCost.HeaderText = "Latest Cost";
            this.LatestCost.MinimumWidth = 8;
            this.LatestCost.Name = "LatestCost";
            this.LatestCost.ReadOnly = true;
            this.LatestCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.LatestCost.Visible = false;
            this.LatestCost.Width = 80;
            // 
            // Date
            // 
            this.Date.DataPropertyName = "AddedDate";
            this.Date.HeaderText = "Date";
            this.Date.MinimumWidth = 8;
            this.Date.Name = "Date";
            this.Date.ReadOnly = true;
            this.Date.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Date.Visible = false;
            this.Date.Width = 47;
            // 
            // DrawingNo
            // 
            this.DrawingNo.DataPropertyName = "DrawingNo";
            this.DrawingNo.HeaderText = "DrawingNo";
            this.DrawingNo.MinimumWidth = 8;
            this.DrawingNo.Name = "DrawingNo";
            this.DrawingNo.ReadOnly = true;
            this.DrawingNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DrawingNo.Visible = false;
            this.DrawingNo.Width = 92;
            // 
            // Addedby
            // 
            this.Addedby.DataPropertyName = "AddedBy";
            this.Addedby.HeaderText = "Added By";
            this.Addedby.MinimumWidth = 8;
            this.Addedby.Name = "Addedby";
            this.Addedby.ReadOnly = true;
            this.Addedby.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Addedby.Width = 73;
            // 
            // PODate
            // 
            this.PODate.DataPropertyName = "PODate";
            this.PODate.HeaderText = "PO Date";
            this.PODate.MinimumWidth = 8;
            this.PODate.Name = "PODate";
            this.PODate.ReadOnly = true;
            this.PODate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PODate.Visible = true;
            this.PODate.Width = 64;
            // 
            // RevisionNo
            // 
            this.RevisionNo.DataPropertyName = "RevisionNo";
            this.RevisionNo.HeaderText = "RevisionNo";
            this.RevisionNo.MinimumWidth = 8;
            this.RevisionNo.Name = "RevisionNo";
            this.RevisionNo.ReadOnly = true;
            this.RevisionNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RevisionNo.Visible = false;
            this.RevisionNo.Width = 92;
            // 
            // Status
            // 
            this.Status.DataPropertyName = "Status";
            this.Status.HeaderText = "Status";
            this.Status.MinimumWidth = 8;
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            this.Status.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Status.Visible = false;
            this.Status.Width = 58;
            // 
            // chklbItemList
            // 
            this.chklbItemList.CheckOnClick = true;
            this.chklbItemList.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chklbItemList.FormattingEnabled = true;
            this.chklbItemList.HorizontalScrollbar = true;
            this.chklbItemList.Location = new System.Drawing.Point(3, 236);
            this.chklbItemList.Name = "chklbItemList";
            this.chklbItemList.Size = new System.Drawing.Size(372, 403);
            this.chklbItemList.TabIndex = 110;
            this.chklbItemList.Visible = false;
            this.chklbItemList.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.chklbItemList_ItemCheck);
            // 
            // gbtreesearch
            // 
            this.gbtreesearch.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.gbtreesearch.Controls.Add(this.chkProductCode);
            this.gbtreesearch.Controls.Add(this.cmbVersion);
            this.gbtreesearch.Controls.Add(this.lblVersion);
            this.gbtreesearch.Controls.Add(this.cleartreeview);
            this.gbtreesearch.Controls.Add(this.txtsearchtree);
            this.gbtreesearch.Controls.Add(this.btnsearchtree);
            this.gbtreesearch.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
            this.gbtreesearch.Location = new System.Drawing.Point(4, 130);
            this.gbtreesearch.Name = "gbtreesearch";
            this.gbtreesearch.Size = new System.Drawing.Size(373, 104);
            this.gbtreesearch.TabIndex = 5;
            this.gbtreesearch.TabStop = false;
            // 
            // chkProductCode
            // 
            this.chkProductCode.AutoSize = true;
            this.chkProductCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.chkProductCode.Location = new System.Drawing.Point(11, 43);
            this.chkProductCode.Name = "chkProductCode";
            this.chkProductCode.Size = new System.Drawing.Size(171, 23);
            this.chkProductCode.TabIndex = 137;
            this.chkProductCode.Text = "Search Product Code";
            this.chkProductCode.UseVisualStyleBackColor = true;
            // 
            // cmbVersion
            // 
            this.cmbVersion.DropDownHeight = 60;
            this.cmbVersion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbVersion.DropDownWidth = 150;
            this.cmbVersion.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbVersion.FormattingEnabled = true;
            this.cmbVersion.IntegralHeight = false;
            this.cmbVersion.ItemHeight = 18;
            this.cmbVersion.Location = new System.Drawing.Point(119, 75);
            this.cmbVersion.Name = "cmbVersion";
            this.cmbVersion.Size = new System.Drawing.Size(80, 26);
            this.cmbVersion.Sorted = true;
            this.cmbVersion.TabIndex = 136;
            this.cmbVersion.SelectedIndexChanged += new System.EventHandler(this.cmbVersion_SelectedIndexChanged);
            // 
            // lblVersion
            // 
            this.lblVersion.AutoSize = true;
            this.lblVersion.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVersion.ForeColor = System.Drawing.Color.Black;
            this.lblVersion.Location = new System.Drawing.Point(9, 76);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(108, 19);
            this.lblVersion.TabIndex = 135;
            this.lblVersion.Text = "Select Version:";
            // 
            // cleartreeview
            // 
            this.cleartreeview.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.cleartreeview.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.cleartreeview.Location = new System.Drawing.Point(308, 40);
            this.cleartreeview.Name = "cleartreeview";
            this.cleartreeview.Size = new System.Drawing.Size(56, 29);
            this.cleartreeview.TabIndex = 134;
            this.cleartreeview.Text = "Clear";
            this.cleartreeview.UseVisualStyleBackColor = true;
            this.cleartreeview.Click += new System.EventHandler(this.cleartreeview_Click);
            // 
            // txtsearchtree
            // 
            this.txtsearchtree.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsearchtree.Location = new System.Drawing.Point(10, 11);
            this.txtsearchtree.Name = "txtsearchtree";
            this.txtsearchtree.Size = new System.Drawing.Size(357, 26);
            this.txtsearchtree.TabIndex = 133;
            this.txtsearchtree.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtsearchtree_KeyUp);
            // 
            // btnsearchtree
            // 
            this.btnsearchtree.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.btnsearchtree.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnsearchtree.Location = new System.Drawing.Point(239, 40);
            this.btnsearchtree.Name = "btnsearchtree";
            this.btnsearchtree.Size = new System.Drawing.Size(63, 29);
            this.btnsearchtree.TabIndex = 132;
            this.btnsearchtree.Text = "Search";
            this.btnsearchtree.UseVisualStyleBackColor = true;
            this.btnsearchtree.Click += new System.EventHandler(this.btnsearchtree_Click);
            // 
            // txtItemSearch
            // 
            this.txtItemSearch.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtItemSearch.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemSearch.Location = new System.Drawing.Point(488, 396);
            this.txtItemSearch.Name = "txtItemSearch";
            this.txtItemSearch.Size = new System.Drawing.Size(340, 22);
            this.txtItemSearch.TabIndex = 111;
            this.txtItemSearch.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemSearch_KeyUp);
            // 
            // lblItemcodeorName
            // 
            this.lblItemcodeorName.AutoSize = true;
            this.lblItemcodeorName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemcodeorName.ForeColor = System.Drawing.Color.Black;
            this.lblItemcodeorName.Location = new System.Drawing.Point(387, 396);
            this.lblItemcodeorName.Name = "lblItemcodeorName";
            this.lblItemcodeorName.Size = new System.Drawing.Size(98, 19);
            this.lblItemcodeorName.TabIndex = 112;
            this.lblItemcodeorName.Text = "Search Item :";
            // 
            // lblProductCost
            // 
            this.lblProductCost.AutoSize = true;
            this.lblProductCost.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblProductCost.ForeColor = System.Drawing.Color.Black;
            this.lblProductCost.Location = new System.Drawing.Point(1093, 392);
            this.lblProductCost.Name = "lblProductCost";
            this.lblProductCost.Size = new System.Drawing.Size(17, 19);
            this.lblProductCost.TabIndex = 113;
            this.lblProductCost.Text = "0";
            this.lblProductCost.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(945, 392);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(146, 19);
            this.label7.TabIndex = 114;
            this.label7.Text = "Product Latest Cost:";
            this.label7.Visible = false;
            // 
            // dgvJobIssuedList
            // 
            this.dgvJobIssuedList.AllowUserToAddRows = false;
            this.dgvJobIssuedList.AllowUserToDeleteRows = false;
            this.dgvJobIssuedList.AllowUserToResizeRows = false;
            this.dgvJobIssuedList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvJobIssuedList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvJobIssuedList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvJobIssuedList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle22;
            this.dgvJobIssuedList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvJobIssuedList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn7,
            this.IssueDate,
            this.WONumber});
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle28.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle28.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvJobIssuedList.DefaultCellStyle = dataGridViewCellStyle28;
            this.dgvJobIssuedList.EnableHeadersVisualStyles = false;
            this.dgvJobIssuedList.Location = new System.Drawing.Point(382, 418);
            this.dgvJobIssuedList.MultiSelect = false;
            this.dgvJobIssuedList.Name = "dgvJobIssuedList";
            this.dgvJobIssuedList.RowHeadersVisible = false;
            this.dgvJobIssuedList.RowHeadersWidth = 62;
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle29.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvJobIssuedList.RowsDefaultCellStyle = dataGridViewCellStyle29;
            this.dgvJobIssuedList.Size = new System.Drawing.Size(937, 210);
            this.dgvJobIssuedList.TabIndex = 119;
            this.dgvJobIssuedList.Visible = false;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ItemCode";
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle23;
            this.dataGridViewTextBoxColumn1.HeaderText = "Item Code";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Width = 76;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn2.DataPropertyName = "ItemDescription";
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle24;
            this.dataGridViewTextBoxColumn2.HeaderText = "Item Description";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn2.Width = 125;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "UnitCost";
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle25;
            this.dataGridViewTextBoxColumn3.HeaderText = "UnitCost";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn3.Width = 73;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "issuedQuantity";
            this.dataGridViewTextBoxColumn4.HeaderText = "Job Issued Qty";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn4.Width = 102;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Amount";
            dataGridViewCellStyle26.Format = "N2";
            dataGridViewCellStyle26.NullValue = null;
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle26;
            this.dataGridViewTextBoxColumn5.HeaderText = "Amount";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn5.Width = 71;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "WorkOrderBy";
            dataGridViewCellStyle27.Format = "N2";
            dataGridViewCellStyle27.NullValue = null;
            this.dataGridViewTextBoxColumn7.DefaultCellStyle = dataGridViewCellStyle27;
            this.dataGridViewTextBoxColumn7.HeaderText = "WorkOrderBy";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn7.Width = 109;
            // 
            // IssueDate
            // 
            this.IssueDate.DataPropertyName = "IssueDate";
            this.IssueDate.HeaderText = "IssueDate";
            this.IssueDate.MinimumWidth = 8;
            this.IssueDate.Name = "IssueDate";
            this.IssueDate.ReadOnly = true;
            this.IssueDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IssueDate.Width = 80;
            // 
            // WONumber
            // 
            this.WONumber.DataPropertyName = "WONumber";
            this.WONumber.HeaderText = "WO Number";
            this.WONumber.MinimumWidth = 8;
            this.WONumber.Name = "WONumber";
            this.WONumber.ReadOnly = true;
            this.WONumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.WONumber.Width = 91;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // cmbWorkDescription
            // 
            this.cmbWorkDescription.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbWorkDescription.DropDownHeight = 130;
            this.cmbWorkDescription.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbWorkDescription.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbWorkDescription.FormattingEnabled = true;
            this.cmbWorkDescription.IntegralHeight = false;
            this.cmbWorkDescription.Items.AddRange(new object[] {
            "Boughtout",
            "Machining",
            "BoughtoutMachining"});
            this.cmbWorkDescription.Location = new System.Drawing.Point(383, 480);
            this.cmbWorkDescription.Name = "cmbWorkDescription";
            this.cmbWorkDescription.Size = new System.Drawing.Size(105, 26);
            this.cmbWorkDescription.TabIndex = 173;
            this.cmbWorkDescription.Visible = false;
            this.cmbWorkDescription.SelectedIndexChanged += new System.EventHandler(this.cmbWorkDescription_SelectedIndexChanged);
            // 
            // frmProjectBOM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1360, 707);
            this.Controls.Add(this.cmbWorkDescription);
            this.Controls.Add(this.lblProductCost);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lblItemcodeorName);
            this.Controls.Add(this.txtItemSearch);
            this.Controls.Add(this.gbProjectDetails);
            this.Controls.Add(this.dgItemOrProductList);
            this.Controls.Add(this.gbControlButtons);
            this.Controls.Add(this.tvProduct);
            this.Controls.Add(this.dgBOMList);
            this.Controls.Add(this.dgvJobIssuedList);
            this.Controls.Add(this.chklbItemList);
            this.Controls.Add(this.gbtreesearch);
            this.Controls.Add(this.gbSearchOptions);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmProjectBOM";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Project BOM";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmProjectBOM_FormClosing);
            this.Load += new System.EventHandler(this.frmProjectBOM_Load);
            this.gbControlButtons.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgItemOrProductList)).EndInit();
            this.gbSearchOptions.ResumeLayout(false);
            this.gbSearchOptions.PerformLayout();
            this.gbProjectDetails.ResumeLayout(false);
            this.gbProjectDetails.PerformLayout();
            this.pnAddProduct.ResumeLayout(false);
            this.pnAddProduct.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgBOMList)).EndInit();
            this.gbtreesearch.ResumeLayout(false);
            this.gbtreesearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvJobIssuedList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbControlButtons;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TreeView tvProduct;
        private System.Windows.Forms.DataGridView dgItemOrProductList;
        private System.Windows.Forms.GroupBox gbSearchOptions;
        private System.Windows.Forms.TextBox txtItemCode;
        private System.Windows.Forms.Label lblItemCode;
        private System.Windows.Forms.GroupBox gbProjectDetails;
        private System.Windows.Forms.CheckBox chkSelectItem;
        private System.Windows.Forms.Label lblProjectCode;
        private System.Windows.Forms.ComboBox cmbProjectCode;
        private System.Windows.Forms.Label lblProjectName;
        private System.Windows.Forms.Label lblTotalCost;
        private System.Windows.Forms.DateTimePicker dtpCreatedDate;
        private System.Windows.Forms.Button btnSaveExcel;
        private System.Windows.Forms.DataGridView dgBOMList;
        private System.Windows.Forms.Label lblprojectbomlist;
        private System.Windows.Forms.Label lblcustomer;
        private System.Windows.Forms.CheckedListBox chklbItemList;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.GroupBox gbtreesearch;
        private System.Windows.Forms.Button cleartreeview;
        private System.Windows.Forms.TextBox txtsearchtree;
        private System.Windows.Forms.Button btnsearchtree;
        private System.Windows.Forms.Label txtcustomer;
        private System.Windows.Forms.Label txtProjectName;
        private System.Windows.Forms.Label txtTotalCost;
        private System.Windows.Forms.Button btnProjectView;
        private System.Windows.Forms.TextBox txtItemSearch;
        private System.Windows.Forms.Label lblItemcodeorName;
        private System.Windows.Forms.Label lblProjectStaus;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblProductCost;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblperc;
        private System.Windows.Forms.Button btnPrintprojectbom;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblIssuedCost;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblJobissuedCost;
        private System.Windows.Forms.Button btnJobItemsView;
        private System.Windows.Forms.DataGridView dgvJobIssuedList;
        private System.Windows.Forms.CheckBox chkItemDesc;
        private System.Windows.Forms.CheckBox chkItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssueDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn WONumber;
        private System.Windows.Forms.ComboBox cmbVersion;
        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btnPrintBOM;
        private System.Windows.Forms.CheckBox chkProductCode;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.ComboBox cmbProductCategory;
        private System.Windows.Forms.Panel pnAddProduct;
        private System.Windows.Forms.Button btnAddCategoryProduct;
        private System.Windows.Forms.TextBox txtProductCategory;
        private System.Windows.Forms.CheckBox chkAddProduct;
        private System.Windows.Forms.Button btnGMApprove;
        private System.Windows.Forms.ComboBox cmbWorkDescription;
        private System.Windows.Forms.DateTimePicker oDateTimePicker;
        private System.Windows.Forms.Label txtprojecttarget;
        private System.Windows.Forms.Label labelprojecttarget;
        private System.Windows.Forms.DataGridViewTextBoxColumn SLNO;
        private System.Windows.Forms.DataGridViewTextBoxColumn PProductCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Version;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductType;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssuedAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn Progress;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectBOM;
        private System.Windows.Forms.DataGridViewTextBoxColumn DesignBOM;
        private System.Windows.Forms.DataGridViewTextBoxColumn StartDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn FinishDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn IProductType;
        private System.Windows.Forms.DataGridViewTextBoxColumn uItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn uItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssuedQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn uBOMQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn FixedCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssueCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn BOMAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn LatestCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date;
        private System.Windows.Forms.DataGridViewTextBoxColumn DrawingNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Addedby;
        private System.Windows.Forms.DataGridViewTextBoxColumn PODate;
        private System.Windows.Forms.DataGridViewTextBoxColumn RevisionNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.Label labelLockStatus;
        private System.Windows.Forms.ProgressBar pbProjectProgress;
    }
}
