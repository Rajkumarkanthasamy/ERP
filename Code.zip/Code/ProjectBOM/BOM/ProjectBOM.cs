﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows.Forms;
using EXCEL = Microsoft.Office.Interop.Excel;
using Outlook = Microsoft.Office.Interop.Outlook;

namespace Erp_Project_With_Buttons.ProjectBOM
{
    public partial class frmProjectBOM : Form
    {
        #region DataTable Declaration
        DataAccessLayer DAL = new DataAccessLayer();
        Global GLobalClass = new Global();
        frmForm2 form = new frmForm2();
        Login.frmLoginForm login = new Login.frmLoginForm();
        // Login.frmLoginForm LoginForm = new Login.frmLoginForm();
        DataTable dtItemList = new DataTable();
        DataTable dtProjectList = new DataTable();
        DataTable dtTableFilter = new DataTable();
        DataTable dtTreeFromTable = new DataTable();
        DataTable dtDGDatatable = new DataTable();
        DataTable dtProjectBOMList = new DataTable();
        DataTable dtSelectedProjectBOMList = new DataTable();
        BindingSource bsItemList = new BindingSource();
        DataView dvItemList = new DataView();
        DataView dvProjectName = new DataView();
        DataView dvProjectBOMList = new DataView();
        DataTable dtProjectCheck = new DataTable();
        DataTable dtWIPProjectlist = new DataTable();
        DataTable dtParentid = new DataTable();
        DataTable dtCompleteBOM = new DataTable();
        DataTable dtProjectBOMDeleteDetail = new DataTable();
        DataTable dtProjectBOMDelete = new DataTable();
        DataTable dtMachineBOMDelete = new DataTable();
        DataTable dtIssuedBOMdelete = new DataTable();
        DataTable dtNewGridviewItems = new DataTable();
        DataTable dtIssuedBOMItemQTY = new DataTable();
        DataTable dtItemsofMachineBOM = new DataTable();
        DataTable dtUpdateMachineBOM = new DataTable();
        DataTable dtDeleteMachineBOMQty = new DataTable();
        DataTable dtParentName = new DataTable();
        DataTable dtProductCode = new DataTable();
        DataTable dtIssuedCost = new DataTable();
        DataTable dtJobIssued = new DataTable();
        DataTable dtProjectOrdertarget = new DataTable();
        DataRow DR;
        CultureInfo india = new CultureInfo("hi-IN");
        string sPBOMNo = string.Empty;
        private string sAutherisedPerson = string.Empty;
        //   private string[] sTableColumns = { "ProductCode", "ProductName", "ProductType", "UOM", "UnitCost", "Quantity", "NodeID" };
        private double fCost = 0.0;
        string sNName = string.Empty;
        string sProductName = string.Empty;
        private static string sBOMProjectCode;
        double dNewTotalAmount;
        bool bIssuedItem = true;
        private double sTotalAmount;
        string sDot = ".";
        List<DataGridViewRow> lcheckedRow = new List<DataGridViewRow>();
        TreeNode tnCurrentParentNode = new TreeNode();
        DataTable dtProductCategory = new DataTable();
        public string fnBOMProjectcode
        {
            get
            {
                return sBOMProjectCode;
            }
            set
            {
                sBOMProjectCode = value;
            }
        }

        #endregion

        public frmProjectBOM()
        {
            InitializeComponent();
        }

        #region ProjectBOM Load
        private void frmProjectBOM_Load(object sender, EventArgs e)
        {
            try
            {


                chkItemCode.Checked = true;
                dgItemOrProductList.Columns[0].Width = 150;
                dgItemOrProductList.Columns[1].Width = 410;
                dgItemOrProductList.Columns[5].Width = 120;
                dgBOMList.Columns[1].Width = 440;
                dtpCreatedDate.Format = DateTimePickerFormat.Custom;
                dtpCreatedDate.CustomFormat = "dd-MM-yyyy";
                gbSearchOptions.Enabled = false;
                cmbProjectCode.Text = Global.sCOMBOBOX_DEFAULT_TEXT;
                dtProjectList = DAL.fnProjectList(null).Tables[0];
                dtProductCategory = DAL.fnProdcuctCategoryList(null).Tables[0];


                //foreach (string str in sTableColumns)
                //{
                //    dtDGDatatable.Columns.Add(str);
                //}

                dtDGDatatable = DAL.fnDirectProjectBOMList(cmbProjectCode.Text).Tables[0];

                if (Convert.ToBoolean(login.GetUserDetails[24]) == false)
                {
                    dtWIPProjectlist = DAL.fnWIPProjectList(null).Tables[0];
                }
                else
                {
                    dtWIPProjectlist = DAL.fnAllProjectList(null).Tables[0];
                }
                if (dtWIPProjectlist.Rows.Count > 0)
                {
                    foreach (DataRow DR in dtWIPProjectlist.Rows)
                    {
                        if (!cmbProjectCode.Items.Contains(DR["ProjectCode"].ToString()))
                            cmbProjectCode.Items.Add(DR["ProjectCode"].ToString());
                    }
                    dtTreeFromTable = DAL.fnGetSalesMasterProductTreeView(1).Tables[0]; //get the tree folders and sub-folders from database
                    if (dtTreeFromTable.Rows.Count > 0)
                    {
                        tvProduct.Nodes.AddRange(GLobalClass.fnTreeFromTable(dtTreeFromTable, "ParentID", "NodeID", "ProductName", "ImageIndex")); // display the folders in the treeview
                        tnCurrentParentNode = null;
                        tvProduct.CollapseAll();
                        tvProduct.Sort();
                        tvProduct.Enabled = false;
                    }
                }
                // dtProjectBOMList = DAL.fnProjectBOMList(null).Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show("ProductMasterForm_frmProductMasterForm_Load " + ex.Message);
            }
        }

        #endregion




        #region Row Filter Function
        private void RowFilter()
        {
            chklbItemList.Items.Clear();
            foreach (DataRowView dv in dvItemList)
            {
                chklbItemList.Items.Add(string.Concat(dv[17].ToString(), ") ", dv[0].ToString(), ", ", dv[1].ToString(), ", ", dv[12].ToString()));
            }
        }
        #endregion

        #region Item Search Functions
        private void txtItemCode_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemCode.Text);
                    RowFilter();
                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtItemCode.Text);
                    RowFilter();
                }
            }
            else
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemCode.Text);
                    RowFilter();
                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtItemCode.Text);
                    RowFilter();
                }
            }
        }

        #endregion
        private void btnExit_Click(object sender, EventArgs e)
        {
            //  if (GLobalClass.fnMessageResult() == Global.sCLOSE_MESSAGE_RESULT_YES)
            {
                this.Hide();
                form.Show();
            }
        }

        private void frmProjectBOM_FormClosing(object sender, FormClosingEventArgs e)
        {
            //if (GLobalClass.fnMessageResult() == Global.sCLOSE_MESSAGE_RESULT_YES)
            //{
            this.Hide();
            form.Show();
            //}
            //else
            //    e.Cancel = true;
        }

        DataTable dtGMApprovePending = new DataTable();
        #region Project code changed

        private void cmbProjectCode_SelectedIndexChanged_new_but_have_bug(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            string projectCode = cmbProjectCode.Text;

            try
            {
                // ========== SINGLE DATABASE CALL FOR ENTIRE PROJECT ==========
                // This replaces: fnMachineBOMProdutViewItems + fnUpdateMachineBOMFixedCost + UpdateMachineBOMFixedCost
                // From 1000+ calls down to 1 call!

                int fixedCostUpdates = DAL.FastUpdateMachineBOMFixedCosts(projectCode); // New method

                // Rest of your code remains same...
                DataTable KanbanDetails = DAL.getKanbanDetails(projectCode)?.Tables[0];
                DataTable GetERPProjectBOMLockDetails = DAL.fnGetERPProjectBOMLock(projectCode)?.Tables[0];
                DataTable dtDGDatatable = DAL.fnDirectProjectBOMList(projectCode)?.Tables[0];
                // ... etc

                // NO MORE LOOPING FOR COST UPDATES - ALREADY DONE IN SQL!

                // Just load the now-updated data for display
                foreach (DataRow dr in dtDGDatatable.Rows)
                {
                    if (string.IsNullOrEmpty(dr["ProductCode"]?.ToString())) continue;

                    string productNo = dr[3]?.ToString();

                    // These now read pre-calculated values (fast!)
                    dr[14] = DAL.fnMachineBOMProdutcost("", projectCode, productNo);
                    dr[6] = DAL.fnMachineBOMProdutcost("FixedCost", projectCode, productNo);

                    double issuedAmt = Convert.ToDouble(dr[14] ?? 0);
                    double unitCost = Convert.ToDouble(dr[6] ?? 0);
                    dr[15] = unitCost > 0 ? Math.Round((issuedAmt / unitCost * 100), 0) : 0;
                }

                // ... rest of UI code

                double projecttargetamount = 0;
                double IssuedAmount = 0;
                double JobIssuedAmount = 0;

                if (KanbanDetails.Rows.Count > 0 && false)
                {
                    //  MessageBox.Show(KanbanDetails.Rows[0]["IssuedAmount"].ToString());
                    DataRow row = dtDGDatatable.NewRow();

                    row["SlNo"] = dtDGDatatable.Rows.Count + 1;   // Or MAX(SlNo)+1 if you prefer
                    row["ProjectBOMCode"] = DBNull.Value;
                    row["ProjectCode"] = projectCode;
                    row["ProductNo"] = DBNull.Value;
                    row["ProductName"] = "Kanban Products";
                    row["Quantity"] = 1;
                    //row["UnitCost"] = KanbanDetails.Rows[0]["ProjectCost"].ToString();

                    var rawUnitCost = KanbanDetails.Rows[0]["ProjectCost"];
                    var tmpUnitCost = Convert.ToDecimal(rawUnitCost, CultureInfo.InvariantCulture);
                    row["UnitCost"] = Convert.ToInt32(Math.Round(tmpUnitCost));

                    row["CreatedDate"] = DateTime.Now;
                    row["CreatedBy"] = Environment.UserName; // Or your own value
                    row["AutherisedBy"] = DBNull.Value;
                    row["ProductType"] = "Kanban Items";
                    row["Remarks"] = DBNull.Value;
                    row["Version"] = 1;
                    row["ProductCode"] = DBNull.Value;
                    //row["IssuedAmount"] = KanbanDetails.Rows[0]["IssuedAmount"].ToString();     // From query = Decimal


                    var rawIssued = KanbanDetails.Rows[0]["IssuedAmount"];
                    var tmpIssued = Convert.ToDecimal(rawIssued, CultureInfo.InvariantCulture);
                    row["IssuedAmount"] = Convert.ToInt32(Math.Round(tmpIssued));

                    row["Progress"] = "";            // VARCHAR
                    row["ProjectBOM"] = false;         // BIT
                    row["DesignBOM"] = false;         // BIT
                                                      //row["StartDate"] ="";
                                                      //row["FinishDate"] = "";

                    dtDGDatatable.Rows.Add(row);

                    dgItemOrProductList.AutoGenerateColumns = false;
                    dgItemOrProductList.DataSource = dtDGDatatable;

                }




                // Datagridviewcolor();
                btnSaveExcel.Enabled = true;
                dgBOMList.DataSource = null;
                double totalamount = 0.0;
                /* rk
                foreach (DataGridViewRow dgvr in dgItemOrProductList.Rows)
                {
                    if (!string.IsNullOrEmpty(dgvr.Cells["PProductCode"].Value.ToString()))
                    {
                        totalamount += Convert.ToDouble(dgvr.Cells["UnitCost"].Value);
                        IssuedAmount += Convert.ToDouble(dgvr.Cells["IssuedAmount"].Value);
                       
                    }

                }
                */
                CultureInfo india = new CultureInfo("hi-IN");
                IssuedAmount = DAL.fnMachineBOMProdutcost("projectIsseCost", cmbProjectCode.Text, "");
                if (KanbanDetails.Rows.Count > 0)
                {

                    var rawUnitCost = KanbanDetails.Rows[0]["IssuedAmount"];
                    var tmpUnitCost = Convert.ToDouble(rawUnitCost, CultureInfo.InvariantCulture);
                    IssuedAmount = IssuedAmount + tmpUnitCost;
                }
                //string text = string.Format(india, "{0:c}", IssuedAmount); // ₹ 3,20,000  DAL.fnMachineBOMProdutcost
                string text = string.Format(india, "{0:c}", IssuedAmount); // ₹ 3,20,000  DAL.fnMachineBOMProdutcost
                lblIssuedCost.Text = text;

                //dtJobIssued = DAL.fnProjectIssued(cmbProjectCode.Text, "2015/01/01", DateTime.Now.ToString("yyyy-MM-dd"), "Job").Tables[0];
                //if (dtJobIssued.Rows.Count > 0)
                //{
                //    dgvJobIssuedList.AutoGenerateColumns = false;
                //    dgvJobIssuedList.DataSource = dtJobIssued;

                //    foreach (DataRow dr in dtJobIssued.Rows)
                //    {
                //        JobIssuedAmount += Convert.ToDouble(dr[5].ToString());
                //    }
                //    fnTotalAmount(JobIssuedAmount);
                //    text = string.Format(india, "{0:c}", dNewTotalAmount);
                //    lblJobissuedCost.Text = text;
                //}
                //else
                //{
                //    fnTotalAmount(0.00);
                //    text = string.Format(india, "{0:c}", dNewTotalAmount);
                //    lblJobissuedCost.Text = text;
                //}

                // rk  fnTotalAmount(totalamount + JobIssuedAmount);

                totalamount = DAL.fnMachineBOMProdutcost("projectCost", cmbProjectCode.Text, "");

                if (KanbanDetails.Rows.Count > 0 && false)
                {

                    var rawUnitCost = KanbanDetails.Rows[0]["ProjectCost"];
                    var tmpUnitCost = Convert.ToDouble(rawUnitCost, CultureInfo.InvariantCulture);
                    totalamount = totalamount + tmpUnitCost;
                }

                fnTotalAmount(totalamount + JobIssuedAmount);
                text = string.Format(india, "{0:c}", dNewTotalAmount); // ₹ 3,20,000 
                txtTotalCost.Text = text;

                //-------------------------------------------------------------------------------------------
                dtProjectOrdertarget = DAL.fnProjectOrderEntry(cmbProjectCode.Text, 1).Tables[0];
                if (dtProjectOrdertarget.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtProjectOrdertarget.Rows[0]["TargetMargin"].ToString()))
                    {
                        projecttargetamount = double.Parse(Math.Round((1 - (Convert.ToDouble(dtProjectOrdertarget.Rows[0]["TargetMargin"].ToString()) / 100)) * Convert.ToDouble(dtProjectOrdertarget.Rows[0]["OrderValueinINR"].ToString())).ToString());
                        text = string.Format(india, "{0:c}", projecttargetamount); // ₹ 3,20,000
                        txtprojecttarget.Text = text;
                    }
                    if (Convert.ToInt32(dNewTotalAmount) > Convert.ToInt32(projecttargetamount))
                    {
                        //MessageBox.Show("bom cost is more than project cost", "warning", 0, MessageBoxIcon.Warning);
                        txtTotalCost.ForeColor = System.Drawing.Color.Red;
                    }
                    else
                    {
                        txtTotalCost.ForeColor = System.Drawing.Color.Black;
                    }
                }
                //-----------------------------------------------------------------------
                double dPercentage = ((IssuedAmount + JobIssuedAmount) / (totalamount + JobIssuedAmount)) * 100;
                if (dPercentage > 100)
                {
                    dPercentage = 100;
                }
                else if (dPercentage <= 100 && dPercentage >= 0)
                {
                    pbProjectProgress.Value = Convert.ToInt32(dPercentage);
                    lblperc.Text = Math.Round(dPercentage, 0) + " %";
                }
                fnTotalCalucalation();


                cmbProductCategory.Items.Clear();


                foreach (DataRow DR in dtProductCategory.Rows)
                {
                    if (!cmbProductCategory.Items.Contains(DR[1].ToString()))
                        cmbProductCategory.Items.Add(DR[1].ToString());
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }
        }

        private void cmbProjectCode_SelectedIndexChanged(object sender, EventArgs e)
        {


            Cursor.Current = Cursors.WaitCursor;

            int UpdateMachineBOMFixedCostStuts = DAL.UpdateMachineBOMFixedCost(cmbProjectCode.Text);
            // MessageBox.Show(UpdateMachineBOMFixedCostStuts.ToString());
            int fixedCostUpdates = DAL.FastUpdateMachineBOMFixedCosts(cmbProjectCode.Text);

            DataTable KanbanDetails = DAL.getKanbanDetails(cmbProjectCode.Text).Tables[0];


            DataTable GetERPProjectBOMLockDetails = DAL.fnGetERPProjectBOMLock(cmbProjectCode.Text).Tables[0];
            bool AllowBOM = true;
            if (GetERPProjectBOMLockDetails.Rows.Count > 0)
            {
                if (GetERPProjectBOMLockDetails.Rows[0]["LockNow"].ToString().ToLower() == "true")
                {
                    // MessageBox.Show($"The selected project currently LOCK...!");
                    AllowBOM = false;
                }
                else
                {
                    AllowBOM = true;
                }
                if (GetERPProjectBOMLockDetails.Rows[0]["LockNow"].ToString().ToLower() == "false")
                {
                    try
                    {
                        var s = GetERPProjectBOMLockDetails.Rows[0]["BOMClosingDate"]?.ToString();
                        var bomClosingDate = DateTime.ParseExact(s, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                        int cmp = DateTime.Compare(bomClosingDate.Date, DateTime.Today);
                        // MessageBox.Show(cmp.ToString());
                        if (cmp == 1)
                        {
                            // MessageBox.Show($"The selected project currently Open till{s}..!");
                            AllowBOM = true;
                        }
                        else
                        {
                            AllowBOM = false;
                            // MessageBox.Show($"The selected project currently LOCK {s}..!");
                        }
                    }
                    catch
                    {
                    }
                }

            }

            if (AllowBOM)
            {
                labelLockStatus.Visible = false;
            }
            else
            {
                MessageBox.Show("BOM is LOCKED You Can Only View. If You Want Edit Please Check With Managers", "BOM Status");
                labelLockStatus.Visible = true;

            }

            if (bJobView)
            {
                btnJobItemsView_Click(sender, e);
            }
            timer1.Stop();
            cmbVersion.Items.Clear();
            lProducts.Clear();
            fCost = 0.0;
            lblperc.Text = "0 %";
            pbProjectProgress.Value = 0;
            dvProjectName = new DataView(dtProjectList);


            dvProjectName.RowFilter = "ProjectCode='" + cmbProjectCode.Text + "'";
            if (dvProjectName.ToTable().Rows.Count > 0)
            {
                txtProjectName.Text = dvProjectName.ToTable().Rows[0]["ProjectDescription"].ToString();
                txtcustomer.Text = dvProjectName.ToTable().Rows[0]["Customer"].ToString();
                lblProjectStaus.Text = dvProjectName.ToTable().Rows[0]["Status"].ToString();
                chkSelectItem.Enabled = true;
                chkSelectItem.Checked = false;
            }
            tvProduct.Enabled = true;
            tvProduct.CollapseAll();

            dtDGDatatable.Rows.Clear();
            dtDGDatatable = DAL.fnDirectProjectBOMList(cmbProjectCode.Text).Tables[0];
            //dtDGDatatable = DAL.fnQuotationNumberLoadData(2, "BISQ20210218", "0").Tables[0];
            dtGMApprovePending = DAL.fnGMProjectList(cmbProjectCode.Text).Tables[0];
            if (dtGMApprovePending.Rows.Count > 0)
            {
                btnGMApprove.Visible = true;
            }
            else
            {
                btnGMApprove.Visible = false;
            }





            if (dtDGDatatable.Rows.Count > 0)
            {
                var set = new HashSet<string>();

                foreach (DataRow dr in dtDGDatatable.Rows)
                {
                    if (set.Add(dr["ProductType"].ToString()))   // Add() returns false if duplicate
                    {
                        cmbProductCategory.Items.Add(dr["ProductType"].ToString());
                    }
                }
                foreach (DataRow dr in dtDGDatatable.Rows)
                {
                    // if (!cmbProductCategory.Items.Contains(dr["ProductType"].ToString())) { 
                    //   cmbProductCategory.Items.Add(dr["ProductType"].ToString());
                    //}
                    double amount = 0.0;
                    double unitcst = 0.0;
                    if (!string.IsNullOrEmpty(dr["ProductCode"].ToString()))
                    {
                        //----------------------------------- this also used for updating  start
                        //dtItemsofMachineBOM = DAL.fnMachineBOMProdutViewItems(3, dr[3].ToString(), cmbProjectCode.Text).Tables[0];
                        //end

                        //rk
                        //  dtLatestCost = DAL.fnLatestCost().Tables[0];

                        // foreach (DataRow rowSampleOne in dtLatestCost.Rows)
                        //  {
                        //  foreach (DataRow rowSampleTwo in dtItemsofMachineBOM.Rows)
                        //  {
                        //    if (rowSampleTwo["ItemName"].ToString().Equals(rowSampleOne["ItemCode"].ToString()))
                        //    {
                        //rowSampleTwo["LatestCost"] = (!string.IsNullOrEmpty(rowSampleOne["PurchaseCost"].ToString())) ? Convert.ToDouble(rowSampleOne["PurchaseCost"].ToString()) : Convert.ToDouble(rowSampleTwo["UnitCost"].ToString());
                        //   }


                        // }
                        // }

                        // start - this code updating the Machine BOM

                        //foreach (DataRow rowSampleTwo in dtItemsofMachineBOM.Rows)
                        //{
                        //DataTable correctFixedCost = DAL.fnUpdateMachineBOMFixedCost(rowSampleTwo["ItemName"].ToString(), rowSampleTwo["AddedDate"].ToString()).Tables[0];

                        //ItemName, AddedDate

                        //if (correctFixedCost != null && correctFixedCost.Rows[0]["CorrectFixedCost"] != null && correctFixedCost.Rows[0]["CostSource"].ToString() != "NOT_FOUND")
                        //{
                        // MessageBox.Show(correctFixedCost.Rows[0]["CorrectFixedCost"].ToString(), "ERROR!");
                        // MessageBox.Show(rowSampleTwo["AddedDate"].ToString() + "-" + correctFixedCost.Rows[0]["CorrectFixedCost"], rowSampleTwo["ItemName"].ToString() + correctFixedCost.Rows[0]["Receipt_Date"]);
                        //     int fnUpdateMachineBOMFixedCostStatus = DAL.UpdateMachineBOMFixedCost(1, Convert.ToDouble(correctFixedCost.Rows[0]["CorrectFixedCost"].ToString()), rowSampleTwo["ProjectBOMCode"].ToString(), rowSampleTwo["ProductNo"].ToString(),
                        //       cmbProjectCode.Text, rowSampleTwo["ItemName"].ToString());
                        // MessageBox.Show(fnUpdateMachineBOMFixedCostStatus.ToString(), "fnUpdateMachineBOMFixedCostStatus");
                        //   }

                        // }
                        //end
                        //if (rowSampleTwo["LatestCost"].ToString().Equals("0"))
                        //{
                        //    rowSampleTwo["LatestCost"] = Convert.ToDouble(rowSampleTwo["UnitCost"].ToString());
                        //}
                        //unitcst += Convert.ToDouble(rowSampleTwo["LatestCost"].ToString()) * Convert.ToDouble(rowSampleTwo["Quantity"].ToString());
                        //amount += Convert.ToDouble(rowSampleTwo["LatestCost"].ToString()) * Convert.ToDouble(rowSampleTwo["IssuedQuantity"].ToString());

                        //if (double.TryParse(rowSampleTwo["FixedCost"].ToString(), out double fixedCost) &&  double.TryParse(rowSampleTwo["Quantity"].ToString(), out double quantity))
                        //{
                        //    unitcst += fixedCost * quantity;
                        //}

                        //if (double.TryParse(rowSampleTwo["IssueCost"].ToString(), out fixedCost) &&
                        //    double.TryParse(rowSampleTwo["IssuedQuantity"].ToString(), out double issuedQty))
                        //{
                        //    amount += fixedCost * issuedQty;
                        //}
                        //   unitcst   += Convert.ToDouble(rowSampleTwo["FixedCost"].ToString()) * Convert.ToDouble(rowSampleTwo["Quantity"].ToString());
                        //   amount  += Convert.ToDouble(rowSampleTwo["IssueCost"].ToString()) * Convert.ToDouble(rowSampleTwo["IssuedQuantity"].ToString());
                        // }

                        // rk dr[6] = unitcst;
                        // rk dr[14] = amount;

                        dr[14] = DAL.fnMachineBOMProdutcost("", cmbProjectCode.Text, dr[3].ToString());
                        dr[6] = DAL.fnMachineBOMProdutcost("FixedCost", cmbProjectCode.Text, dr[3].ToString());


                        //MessageBox.Show(dr[6].ToString());

                        //-----------------------------------
                        //dtIssuedCost = DAL.fnProjectBOMIssuedCost(cmbProjectCode.Text, dr[3].ToString()).Tables[0];
                        //if(dtIssuedCost.Rows.Count>0)
                        //{
                        //    foreach(DataRow ROW1 in dtIssuedCost.Rows)
                        //    {
                        //        amount += Convert.ToDouble(ROW1[0].ToString());
                        //    }
                        //}
                        //if (amount!=0)
                        //{
                        //    dr[14] = amount;
                        //}
                        //else
                        //{
                        //    dr[14] = Convert.ToDouble("0.00");
                        //}

                        dr[15] = Math.Round((Convert.ToDouble(dr[14]) / Convert.ToDouble(dr[6]) * 100), 0);
                    }
                }
                double projecttargetamount = 0;
                double IssuedAmount = 0;
                double JobIssuedAmount = 0;

                if (KanbanDetails.Rows.Count > 0 && false)
                {
                    //  MessageBox.Show(KanbanDetails.Rows[0]["IssuedAmount"].ToString());
                    DataRow row = dtDGDatatable.NewRow();

                    row["SlNo"] = dtDGDatatable.Rows.Count + 1;   // Or MAX(SlNo)+1 if you prefer
                    row["ProjectBOMCode"] = DBNull.Value;
                    row["ProjectCode"] = cmbProjectCode.Text;
                    row["ProductNo"] = DBNull.Value;
                    row["ProductName"] = "Kanban Products";
                    row["Quantity"] = 1;
                    //row["UnitCost"] = KanbanDetails.Rows[0]["ProjectCost"].ToString();

                    var rawUnitCost = KanbanDetails.Rows[0]["ProjectCost"];
                    var tmpUnitCost = Convert.ToDecimal(rawUnitCost, CultureInfo.InvariantCulture);
                    row["UnitCost"] = Convert.ToInt32(Math.Round(tmpUnitCost));

                    row["CreatedDate"] = DateTime.Now;
                    row["CreatedBy"] = Environment.UserName; // Or your own value
                    row["AutherisedBy"] = DBNull.Value;
                    row["ProductType"] = "Kanban Items";
                    row["Remarks"] = DBNull.Value;
                    row["Version"] = 1;
                    row["ProductCode"] = DBNull.Value;
                    //row["IssuedAmount"] = KanbanDetails.Rows[0]["IssuedAmount"].ToString();     // From query = Decimal


                    var rawIssued = KanbanDetails.Rows[0]["IssuedAmount"];
                    var tmpIssued = Convert.ToDecimal(rawIssued, CultureInfo.InvariantCulture);
                    row["IssuedAmount"] = Convert.ToInt32(Math.Round(tmpIssued));

                    row["Progress"] = "";            // VARCHAR
                    row["ProjectBOM"] = false;         // BIT
                    row["DesignBOM"] = false;         // BIT
                                                      //row["StartDate"] ="";
                                                      //row["FinishDate"] = "";

                    dtDGDatatable.Rows.Add(row);

                    dgItemOrProductList.AutoGenerateColumns = false;
                    dgItemOrProductList.DataSource = dtDGDatatable;

                }




                // Datagridviewcolor();
                btnSaveExcel.Enabled = true;
                dgBOMList.DataSource = null;
                double totalamount = 0.0;
                /* rk
                foreach (DataGridViewRow dgvr in dgItemOrProductList.Rows)
                {
                    if (!string.IsNullOrEmpty(dgvr.Cells["PProductCode"].Value.ToString()))
                    {
                        totalamount += Convert.ToDouble(dgvr.Cells["UnitCost"].Value);
                        IssuedAmount += Convert.ToDouble(dgvr.Cells["IssuedAmount"].Value);
                       
                    }

                }
                */
                CultureInfo india = new CultureInfo("hi-IN");
                IssuedAmount = DAL.fnMachineBOMProdutcost("projectIsseCost", cmbProjectCode.Text, "");
                if (KanbanDetails.Rows.Count > 0 && false)
                {

                    var rawUnitCost = KanbanDetails.Rows[0]["IssuedAmount"];
                    var tmpUnitCost = Convert.ToDouble(rawUnitCost, CultureInfo.InvariantCulture);
                    IssuedAmount = IssuedAmount + tmpUnitCost;
                }
                //string text = string.Format(india, "{0:c}", IssuedAmount); // ₹ 3,20,000  DAL.fnMachineBOMProdutcost
                string text = string.Format(india, "{0:c}", IssuedAmount); // ₹ 3,20,000  DAL.fnMachineBOMProdutcost
                lblIssuedCost.Text = text;

                //dtJobIssued = DAL.fnProjectIssued(cmbProjectCode.Text, "2015/01/01", DateTime.Now.ToString("yyyy-MM-dd"), "Job").Tables[0];
                //if (dtJobIssued.Rows.Count > 0)
                //{
                //    dgvJobIssuedList.AutoGenerateColumns = false;
                //    dgvJobIssuedList.DataSource = dtJobIssued;

                //    foreach (DataRow dr in dtJobIssued.Rows)
                //    {
                //        JobIssuedAmount += Convert.ToDouble(dr[5].ToString());
                //    }
                //    fnTotalAmount(JobIssuedAmount);
                //    text = string.Format(india, "{0:c}", dNewTotalAmount);
                //    lblJobissuedCost.Text = text;
                //}
                //else
                //{
                //    fnTotalAmount(0.00);
                //    text = string.Format(india, "{0:c}", dNewTotalAmount);
                //    lblJobissuedCost.Text = text;
                //}

                // rk  fnTotalAmount(totalamount + JobIssuedAmount);

                totalamount = DAL.fnMachineBOMProdutcost("projectCost", cmbProjectCode.Text, "");

                if (KanbanDetails.Rows.Count > 0 && false)
                {

                    var rawUnitCost = KanbanDetails.Rows[0]["ProjectCost"];
                    var tmpUnitCost = Convert.ToDouble(rawUnitCost, CultureInfo.InvariantCulture);
                    totalamount = totalamount + tmpUnitCost;
                }

                fnTotalAmount(totalamount + JobIssuedAmount);
                text = string.Format(india, "{0:c}", dNewTotalAmount); // ₹ 3,20,000 
                txtTotalCost.Text = text;

                //-------------------------------------------------------------------------------------------
                dtProjectOrdertarget = DAL.fnProjectOrderEntry(cmbProjectCode.Text, 1).Tables[0];

                if (dtProjectOrdertarget.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtProjectOrdertarget.Rows[0]["TargetMargin"].ToString()))
                    {
                        projecttargetamount = double.Parse(Math.Round((1 - (Convert.ToDouble(dtProjectOrdertarget.Rows[0]["TargetMargin"].ToString()) / 100)) * Convert.ToDouble(dtProjectOrdertarget.Rows[0]["OrderValueinINR"].ToString())).ToString());
                        text = string.Format(india, "{0:c}", projecttargetamount); // ₹ 3,20,000
                        txtprojecttarget.Text = text;
                    }
                    if (Convert.ToInt32(dNewTotalAmount) > Convert.ToInt32(projecttargetamount))
                    {
                        //MessageBox.Show("bom cost is more than project cost", "warning", 0, MessageBoxIcon.Warning);
                        txtTotalCost.ForeColor = System.Drawing.Color.Red;
                    }
                    else
                    {
                        txtTotalCost.ForeColor = System.Drawing.Color.Black;
                    }
                }
                //-----------------------------------------------------------------------
                double dPercentage = ((IssuedAmount + JobIssuedAmount) / (totalamount + JobIssuedAmount)) * 100;
                if (dPercentage > 100)
                {
                    dPercentage = 100;
                }
                else if (dPercentage <= 100 && dPercentage >= 0)
                {
                    pbProjectProgress.Value = Convert.ToInt32(dPercentage);
                    lblperc.Text = Math.Round(dPercentage, 0) + " %";
                }
                fnTotalCalucalation();


                cmbProductCategory.Items.Clear();


                foreach (DataRow DR in dtProductCategory.Rows)
                {
                    if (!cmbProductCategory.Items.Contains(DR[1].ToString()))
                        cmbProductCategory.Items.Add(DR[1].ToString());
                }

                //foreach (DataRow DR in dtDGDatatable.Rows)
                // {
                //    if (!cmbProductCategory.Items.Contains(DR["ProductType"].ToString()))
                //        cmbProductCategory.Items.Add(DR["ProductType"].ToString());
                // }
            }
            //  }
            else
            {
                cmbProductCategory.Items.Clear();
                //dtProductCategory = DAL.fnProdcuctCategoryList(null).Tables[0];

                foreach (DataRow DR in dtProductCategory.Rows)
                {
                    if (!cmbProductCategory.Items.Contains(DR[1].ToString()))
                        cmbProductCategory.Items.Add(DR[1].ToString());
                }
                dtDGDatatable.Rows.Clear();
                dtDGDatatable = DAL.fnDirectProjectBOMList(cmbProjectCode.Text).Tables[0];
                dgvJobIssuedList.DataSource = null;
                dgItemOrProductList.DataSource = null;
                dgBOMList.DataSource = null;
                gbSearchOptions.Enabled = false;
                gbtreesearch.Visible = true;
                cmbProjectCode.Enabled = true;
                txtTotalCost.ResetText();
                lblIssuedCost.ResetText();
                lblProductCost.ResetText();
                lblJobissuedCost.ResetText();
                txtprojecttarget.ResetText();
            }
            Cursor.Current = Cursors.Default;
        }

        private void cmbProjectCode_SelectedIndexChanged_new(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            this.SuspendLayout();
            dgItemOrProductList.SuspendLayout();
            cmbProductCategory.BeginUpdate();
            tvProduct.BeginUpdate();

            try
            {
                string projectCode = cmbProjectCode.Text;

                // 1) Read lock status (no change in feature, but safer parsing)
                DataTable dtLock = DAL.fnGetERPProjectBOMLock(projectCode).Tables[0];
                bool allowBOM = true;

                if (dtLock.Rows.Count > 0)
                {
                    var r0 = dtLock.Rows[0];
                    bool lockNow = false;
                    // Accept "true"/"false" strings in any case
                    bool.TryParse(Convert.ToString(r0["LockNow"]), out lockNow);

                    if (lockNow)
                    {
                        allowBOM = false;
                    }
                    else
                    {
                        // Only if unlocked, check closing date
                        var sDate = Convert.ToString(r0["BOMClosingDate"]);
                        if (!string.IsNullOrWhiteSpace(sDate) &&
                            DateTime.TryParseExact(sDate, "dd-MM-yyyy", CultureInfo.InvariantCulture,
                                                   DateTimeStyles.None, out DateTime bomClosingDate))
                        {
                            allowBOM = bomClosingDate.Date.CompareTo(DateTime.Today) > 0;
                        }
                    }
                }

                labelLockStatus.Visible = !allowBOM;
                if (!allowBOM)
                {
                    MessageBox.Show("BOM is LOCKED. You can only view. If you want to edit, please check with Managers.", "BOM Status");
                }

                // 2) Fast reset of progress/UI state (no feature change)
                if (bJobView)
                {
                    // If this is heavy, consider deferring until after data is loaded.
                    btnJobItemsView_Click(sender, e);
                }
                timer1.Stop();

                cmbVersion.Items.Clear();
                lProducts.Clear();
                fCost = 0.0;
                lblperc.Text = "0 %";
                pbProjectProgress.Value = 0;

                // 3) Project name/customer/status lookup without ToTable() twice
                var projRows = dtProjectList.Select($"ProjectCode = '{projectCode.Replace("'", "''")}'");
                if (projRows.Length > 0)
                {
                    var pr = projRows[0];
                    txtProjectName.Text = Convert.ToString(pr["ProjectDescription"]);
                    txtcustomer.Text = Convert.ToString(pr["Customer"]);
                    lblProjectStaus.Text = Convert.ToString(pr["Status"]);
                    chkSelectItem.Enabled = true;
                    chkSelectItem.Checked = false;
                }

                tvProduct.Enabled = true;
                tvProduct.CollapseAll();

                // 4) Load main grids/tables once
                dtDGDatatable = DAL.fnDirectProjectBOMList(projectCode).Tables[0]; // product-level rows
                dtGMApprovePending = DAL.fnGMProjectList(projectCode).Tables[0];
                btnGMApprove.Visible = dtGMApprovePending.Rows.Count > 0;

                // LOAD LATEST COST ONCE (was per product)
                DataTable dtLatestCost = DAL.fnLatestCost().Tables[0];
                // Build lookup: ItemCode -> PurchaseCost (double?)
                var latestCost = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
                foreach (DataRow lc in dtLatestCost.Rows)
                {
                    string itemCode = Convert.ToString(lc["ItemCode"]);
                    if (string.IsNullOrEmpty(itemCode)) continue;

                    double purchaseCost = 0.0;
                    double.TryParse(Convert.ToString(lc["PurchaseCost"]),
                                    NumberStyles.Any, CultureInfo.InvariantCulture, out purchaseCost);

                    // Keep last or prefer non-zero; adjust rule if needed
                    if (!latestCost.ContainsKey(itemCode) || purchaseCost != 0)
                        latestCost[itemCode] = purchaseCost;
                }

                // 5) Populate product category (use HashSet to avoid O(n^2))
                var catSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

                if (dtDGDatatable.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtDGDatatable.Rows)
                    {
                        // Categories
                        var productType = Convert.ToString(dr["ProductType"]);
                        if (!string.IsNullOrEmpty(productType))
                            catSet.Add(productType);

                        if (!string.IsNullOrEmpty(Convert.ToString(dr["ProductCode"])))
                        {
                            // Fetch BOM items for this product
                            // (If possible: replace with a batched DAL call to get ALL products' BOM items once.)
                            DataTable dtItemsofMachineBOM =
                                DAL.fnMachineBOMProdutViewItems(3, Convert.ToString(dr[3]), projectCode).Tables[0];

                            // Apply latest cost via dictionary (O(n))
                            foreach (DataRow itm in dtItemsofMachineBOM.Rows)
                            {
                                string itemName = Convert.ToString(itm["ItemName"]); // seems to be ItemCode
                                double unitCost = ToDouble(itm["UnitCost"]);
                                if (latestCost.TryGetValue(itemName, out double lc))
                                {
                                    itm["LatestCost"] = (lc != 0) ? lc : unitCost;
                                }
                                else
                                {
                                    itm["LatestCost"] = unitCost;
                                }
                            }

                            // Use existing DAL that computes costs per product, but avoid duplicate calls.
                            // You call it twice with different mode strings; keep as-is but cached per product if repetition exists.
                            double issued = ToDouble(DAL.fnMachineBOMProdutcost("", projectCode, Convert.ToString(dr[3])));
                            double fixedCost = ToDouble(DAL.fnMachineBOMProdutcost("FixedCost", projectCode, Convert.ToString(dr[3])));

                            dr[14] = issued;      // IssuedAmount?
                            dr[6] = fixedCost;   // FixedCost?

                            // Guard divide-by-zero
                            double pct = 0.0;
                            if (fixedCost > 0)
                            {
                                pct = Math.Round((issued / fixedCost) * 100.0, 0);
                                if (pct > 100.0) pct = 100.0;
                                if (pct < 0.0) pct = 0.0;
                            }
                            dr[15] = pct;
                        }
                    }

                    // Bind once
                    dgItemOrProductList.AutoGenerateColumns = false;
                    dgItemOrProductList.DataSource = dtDGDatatable;

                    // Currency formatting with hi-IN
                    CultureInfo india = new CultureInfo("hi-IN");

                    // Project-level amounts via DAL (keep behavior)
                    double issuedAmountProject = ToDouble(DAL.fnMachineBOMProdutcost("projectCost", projectCode, ""));
                    lblIssuedCost.Text = string.Format(india, "{0:c}", issuedAmountProject);

                    // totalamount + jobissued → using "projectIsseCost" (existing)
                    double totalamount = ToDouble(DAL.fnMachineBOMProdutcost("projectIsseCost", projectCode, ""));
                    double jobIssuedAmount = 0.0; // your previous job-issued block is commented; keeping behavior

                    fnTotalAmount(totalamount + jobIssuedAmount);
                    txtTotalCost.Text = string.Format(india, "{0:c}", dNewTotalAmount);

                    // Target margin/cost
                    dtProjectOrdertarget = DAL.fnProjectOrderEntry(projectCode, 1).Tables[0];
                    if (dtProjectOrdertarget.Rows.Count > 0 &&
                        !string.IsNullOrWhiteSpace(Convert.ToString(dtProjectOrdertarget.Rows[0]["TargetMargin"])) &&
                        !string.IsNullOrWhiteSpace(Convert.ToString(dtProjectOrdertarget.Rows[0]["OrderValueinINR"])))
                    {
                        double targetMargin = ToDouble(dtProjectOrdertarget.Rows[0]["TargetMargin"]);
                        double orderValue = ToDouble(dtProjectOrdertarget.Rows[0]["OrderValueinINR"]);
                        double projectTargetAmount = Math.Round((1 - (targetMargin / 100.0)) * orderValue);

                        txtprojecttarget.Text = string.Format(india, "{0:c}", projectTargetAmount);

                        // Warn color if over budget
                        txtTotalCost.ForeColor =
                            (dNewTotalAmount > projectTargetAmount) ? System.Drawing.Color.Red : System.Drawing.Color.Black;
                    }

                    // Progress bar calculation
                    double denom = totalamount + jobIssuedAmount;
                    double numer = issuedAmountProject + jobIssuedAmount;
                    double dPercentage = (denom > 0) ? (numer / denom) * 100.0 : 0.0;
                    if (dPercentage > 100) dPercentage = 100;
                    if (dPercentage < 0) dPercentage = 0;

                    pbProjectProgress.Value = Convert.ToInt32(dPercentage);
                    lblperc.Text = Math.Round(dPercentage, 0) + " %";

                    // Your own totals
                    fnTotalCalucalation();
                }

                // Rebuild product category dropdown once
                cmbProductCategory.Items.Clear();
                foreach (DataRow DR in dtProductCategory.Rows) // keep existing behavior of including master list
                {
                    string cat = Convert.ToString(DR[1]);
                    if (!string.IsNullOrEmpty(cat))
                        catSet.Add(cat);
                }
                // Now add all unique values at once
                foreach (var c in catSet)
                    cmbProductCategory.Items.Add(c);

                // In the 'else' branch in your original code, you clear a lot of UI if dtDGDatatable is empty.
                // We keep that behavior if needed:
                if (dtDGDatatable.Rows.Count == 0)
                {
                    dgvJobIssuedList.DataSource = null;
                    dgItemOrProductList.DataSource = null;
                    dgBOMList.DataSource = null;
                    gbSearchOptions.Enabled = false;
                    gbtreesearch.Visible = true;
                    cmbProjectCode.Enabled = true;
                    txtTotalCost.ResetText();
                    lblIssuedCost.ResetText();
                    lblProductCost.ResetText();
                    lblJobissuedCost.ResetText();
                    txtprojecttarget.ResetText();
                }
            }
            finally
            {
                tvProduct.EndUpdate();
                cmbProductCategory.EndUpdate();
                dgItemOrProductList.ResumeLayout();
                this.ResumeLayout();
                Cursor.Current = Cursors.Default;
            }
        }

        // ---- helpers ----
        private static double ToDouble(object value)
        {
            if (value == null) return 0.0;
            if (value is double d) return d;
            double.TryParse(Convert.ToString(value), NumberStyles.Any, CultureInfo.InvariantCulture, out var x);
            return x;
        }
        #endregion

        #region PO Item Color
        private void Datagridviewcolor()
        {
            //int count = 0;
            //foreach (DataGridViewRow dgr in dgItemOrProductList.Rows)
            //{
            //    if (Convert.ToBoolean(dgr.Cells["ProjectBOM"].Value) && !Convert.ToBoolean(dgr.Cells["DesignBOM"].Value))
            //    {
            //        //    dgr.DefaultCellStyle.BackColor = Color.SteelBlue;
            //    }
            //    else
            //    {
            //        dgr.DefaultCellStyle.BackColor = Color.BurlyWood;
            //    }
            //    count++;
            //}
        }
        #endregion

        #region Item Select
        private void chkSelectItem_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSelectItem.Checked)
            {
                gbSearchOptions.Visible = true;
                gbtreesearch.Visible = false;
                tvProduct.Visible = false;
                chklbItemList.Visible = true;
            }
            else
            {
                tvProduct.Visible = true;
                chklbItemList.Visible = false;
                gbtreesearch.Visible = true;
                gbSearchOptions.Visible = false;
            }
        }
        # endregion

        #region Save Function for BOM
        private void fnSaveProjectBOM(string sProjectCode, bool bMainItem)
        {
            DataTable dtResultProductTreeView = new DataTable();
            DataTable dtFinalResult = new DataTable();
            DataTable dtProjectBOMProdcuNumber = new DataTable();
            int iProjectBOMNumber = 0;
            int sLastProductNo = 0;
            string sLastProjectBOMCode = string.Empty;
            string sNewProjectBOMCode = string.Empty;

            // if (dgItemOrProductList.Rows.Count > 0)
            // {
            dtProjectBOMList = DAL.fnProjectBOMList(sProjectCode).Tables[0];
            dtProjectBOMProdcuNumber = DAL.fnProjectBOMProdcuNumber(sProjectCode).Tables[0];

            if (dtProjectBOMList.Rows.Count > 0)
            {
                sNewProjectBOMCode = dtProjectBOMList.Rows[0]["ProjectBOMCode"].ToString();
            }

            if (string.IsNullOrEmpty(sNewProjectBOMCode))
            {
                sLastProjectBOMCode = DAL.fnGetLastProjectBOMCode();
                if (sLastProjectBOMCode != string.Empty)
                {
                    iProjectBOMNumber = Convert.ToInt32(sLastProjectBOMCode.Substring(5)) + 1;
                    sNewProjectBOMCode = string.Concat("PBOM00" + Convert.ToString(iProjectBOMNumber));
                }
            }

            dtProjectBOMProdcuNumber = DAL.fnProjectBOMProdcuNumber(sProjectCode).Tables[0];
            if (dtProjectBOMProdcuNumber.Rows.Count > 0)
            {
                sLastProductNo = Convert.ToInt32(dtProjectBOMProdcuNumber.Rows[0]["ProductNo"].ToString());
                iProjectBOMNumber = Convert.ToInt32(dtProjectBOMProdcuNumber.Rows[0]["ProjectBOMNumber"].ToString());
            }

            sLastProductNo++;



            if (!bMainItem)
            {
                GLobalClass.iSuccess = DAL.fnAddProjectBOM(Global.uINSERT, sNewProjectBOMCode, sProjectCode, sLastProductNo.ToString(), DR["ProductName"].ToString(), iQty,
                                        fCost, Login.frmLoginForm.sUserDetails[2], dtpCreatedDate.Text, Login.frmLoginForm.sUserDetails[2], "", cmbVersion.Text, DR["ProductCode"].ToString(),
                                        cmbProductCategory.Text, iProjectBOMNumber, lblProjectStaus.Text, "1", "0", "1", Convert.ToDouble(DR["SLNO"]), false);
                //[ProjectCode],[ProductNumber],[ProductName],[Qty],[Cost],[ActionMadeBy],[Version],[ProductCode],[ProductCategory],[ProjectBOMNumber],[ProjectStatus],[ProjectBOM],[ActionType]

                try
                {
                    double projectCost = DAL.fnGetProjectCost("PROJECT", sProjectCode);
                    double projectIssuedCost = DAL.fnGetProjectCost("ISSUE", sProjectCode);

                    int fnCreateERPProjectBOMChangesLogsStatus = DAL.fnCreateERPProjectBOMChangesLogs(sProjectCode, sLastProductNo.ToString(), DR["ProductName"].ToString(), iQty.ToString(), fCost.ToString(), Login.frmLoginForm.sUserDetails[2],
                       cmbVersion.Text, DR["ProductCode"].ToString(), cmbProductCategory.Text, dtProjectBOMProdcuNumber.Rows[0]["ProjectBOMNumber"].ToString(), lblProjectStaus.Text, null, "Adding ProjectBOM", projectCost, projectIssuedCost);
                }
                catch
                {
                }

                dtFinalResult = DAL.fnVersionProductBOMList(sName[0], cmbVersion.Text).Tables[0];
                dtProjectBOMProdcuNumber = DAL.fnProjectBOMProdcuNumber(sProjectCode).Tables[0];

                if (dtFinalResult.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtFinalResult.Rows)
                    {
                        if (lblProjectStaus.Text == "WIP")
                        {
                            GLobalClass.iSuccess = DAL.fnAddMachineBOM(Global.uINSERT, dtProjectBOMProdcuNumber.Rows[0]["ProjectBOMCode"].ToString(), sLastProductNo.ToString(),
                              dr["ItemCode"].ToString(), dtProjectBOMProdcuNumber.Rows[0]["ProjectCode"].ToString(), dr["MfgPartNo"].ToString(), dr["Make"].ToString(), dr["Specification"].ToString(),
                              dr["Location"].ToString(), dr["Vendor"].ToString(), dr["DrawingNo"].ToString(), Convert.ToDouble(dr["Quantity"].ToString()), 1, 0, lblProjectStaus.Text,
                              login.GetUserDetails[2], dtpCreatedDate.Text, dr["ProductType"].ToString(), Convert.ToDecimal(dr["FixedCost"].ToString()));

                            try
                            {
                                double projectCost = DAL.fnGetProjectCost("PROJECT", dtProjectBOMProdcuNumber.Rows[0]["ProjectCode"].ToString());
                                double projectIssuedCost = DAL.fnGetProjectCost("ISSUE", dtProjectBOMProdcuNumber.Rows[0]["ProjectCode"].ToString());

                                int fnCreateERPProjectBOMChangesLogsStatus = DAL.fnCreateERPProjectBOMChangesLogs(dtProjectBOMProdcuNumber.Rows[0]["ProjectCode"].ToString(), sLastProductNo.ToString(), DR["ProductName"].ToString(), dr["Quantity"].ToString(), dr["FixedCost"].ToString(), Login.frmLoginForm.sUserDetails[2],
                                   cmbVersion.Text, DR["ProductCode"].ToString(), cmbProductCategory.Text, dtProjectBOMProdcuNumber.Rows[0]["ProjectBOMCode"].ToString(), lblProjectStaus.Text, dr["ItemCode"].ToString(), "Adding MachineBOM", projectCost, projectIssuedCost);
                            }
                            catch
                            {
                            }
                        }
                        else
                        {
                            GLobalClass.iSuccess = DAL.fnAddMachineBOM(Global.uINSERT, dtProjectBOMProdcuNumber.Rows[0]["ProjectBOMCode"].ToString(), sLastProductNo.ToString(),
                                dr["ItemCode"].ToString(), dtProjectBOMProdcuNumber.Rows[0]["ProjectCode"].ToString(), dr["MfgPartNo"].ToString(), dr["Make"].ToString(), dr["Specification"].ToString(),
                                dr["Location"].ToString(), dr["Vendor"].ToString(), dr["DrawingNo"].ToString(), Convert.ToDouble(dr["Quantity"].ToString()), 0, 0, lblProjectStaus.Text,
                                login.GetUserDetails[2], dtpCreatedDate.Text, dr["ProductType"].ToString(), Convert.ToDecimal(dr["FixedCost"].ToString()));

                            try
                            {
                                double projectCost = DAL.fnGetProjectCost("PROJECT", dtProjectBOMProdcuNumber.Rows[0]["ProjectCode"].ToString());
                                double projectIssuedCost = DAL.fnGetProjectCost("ISSUE", dtProjectBOMProdcuNumber.Rows[0]["ProjectCode"].ToString());

                                int fnCreateERPProjectBOMChangesLogsStatus = DAL.fnCreateERPProjectBOMChangesLogs(dtProjectBOMProdcuNumber.Rows[0]["ProjectCode"].ToString(), sLastProductNo.ToString(), DR["ProductName"].ToString(), dr["Quantity"].ToString(), dr["FixedCost"].ToString(), Login.frmLoginForm.sUserDetails[2],
                                   cmbVersion.Text, DR["ProductCode"].ToString(), cmbProductCategory.Text, dtProjectBOMProdcuNumber.Rows[0]["ProjectBOMCode"].ToString(), lblProjectStaus.Text, dr["ItemCode"].ToString(), "Adding MachineBOM", projectCost, projectIssuedCost);
                            }
                            catch
                            {
                            }
                        }
                    }
                    MessageBox.Show("Product added.", "Success", 0, MessageBoxIcon.Information);
                }
            }
            else
            {
                GLobalClass.iSuccess = DAL.fnAddProjectBOM(Global.uINSERT, sNewProjectBOMCode, sProjectCode, sLastProductNo.ToString(), DR["ProductName"].ToString(), iQty,
                                        fCost, Login.frmLoginForm.sUserDetails[2], dtpCreatedDate.Text, Login.frmLoginForm.sUserDetails[2], "", "", DR["ProductCode"].ToString(),
                                        cmbProductCategory.Text, iProjectBOMNumber, lblProjectStaus.Text, "1", "0", "1", Convert.ToDouble(DR["SLNO"]), false);

                try
                {

                    double projectCost = DAL.fnGetProjectCost("PROJECT", sProjectCode);
                    double projectIssuedCost = DAL.fnGetProjectCost("ISSUE", sProjectCode);
                    int fnCreateERPProjectBOMChangesLogsStatus = DAL.fnCreateERPProjectBOMChangesLogs(sProjectCode, sLastProductNo.ToString(), DR["ProductName"].ToString(), iQty.ToString(), fCost.ToString(), Login.frmLoginForm.sUserDetails[2],
                       cmbVersion.Text, DR["ProductCode"].ToString(), cmbProductCategory.Text, iProjectBOMNumber.ToString(), lblProjectStaus.Text, null, "Adding ProjectBOM", projectCost, projectIssuedCost);
                }
                catch
                {
                }

                MessageBox.Show("Product type added.", "Success", 0, MessageBoxIcon.Information);
            }
        }
        #endregion

        #region Delete Item Function
        private void dgItemOrProductList_KeyUp(object sender, KeyEventArgs e)
        {
            DataTable GetERPProjectBOMLockDetails = DAL.fnGetERPProjectBOMLock(cmbProjectCode.Text).Tables[0];
            bool AllowBOM = true;
            if (GetERPProjectBOMLockDetails.Rows.Count > 0)
            {
                if (GetERPProjectBOMLockDetails.Rows[0]["LockNow"].ToString().ToLower() == "true")
                {
                    // MessageBox.Show($"The selected project currently LOCK...!");
                    AllowBOM = false;
                }
                else
                {
                    AllowBOM = true;
                }
                if (GetERPProjectBOMLockDetails.Rows[0]["LockNow"].ToString().ToLower() == "false")
                {
                    try
                    {
                        var s = GetERPProjectBOMLockDetails.Rows[0]["BOMClosingDate"]?.ToString();
                        var bomClosingDate = DateTime.ParseExact(s, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                        int cmp = DateTime.Compare(bomClosingDate.Date, DateTime.Today);
                        // MessageBox.Show(cmp.ToString());
                        if (cmp == 1)
                        {
                            // MessageBox.Show($"The selected project currently Open till{s}..!");
                            AllowBOM = true;
                        }
                        else
                        {
                            AllowBOM = false;
                            // MessageBox.Show($"The selected project currently LOCK {s}..!");
                        }
                    }
                    catch
                    {
                    }
                }

            }

            if (AllowBOM)
            {


                if (e.KeyCode == Keys.Delete)
                {
                    if (!string.IsNullOrEmpty(dgItemOrProductList.CurrentRow.Cells["PProductCode"].Value.ToString()))
                    {
                        if (dgBOMList.Rows.Count > 0)
                        {
                            if (dgItemOrProductList.Rows.Count > 0)
                            {

                                DialogResult DR = MessageBox.Show("Do you want to delete selected BOM  '" + dgItemOrProductList.CurrentRow.Cells["ProductName"].Value.ToString() + "'", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                                if (DR == DialogResult.Yes)
                                {
                                    if (dgBOMList.Rows.Count > 0)
                                    {
                                        bIssuedItem = true;
                                        foreach (DataGridViewRow dgbom in dgBOMList.Rows)
                                        {
                                            if (Convert.ToDouble(dgBOMList.CurrentRow.Cells["IssuedQuantity"].Value) > 0)
                                            {
                                                bIssuedItem = false;
                                                break;
                                            }
                                        }
                                    }
                                    if (bIssuedItem)
                                    {
                                        dtProjectBOMDeleteDetail = DAL.fnProjectBOMProdutnamenumber(dgItemOrProductList.CurrentRow.Cells["PProductCode"].Value.ToString(), cmbProjectCode.Text, dgItemOrProductList.CurrentRow.Cells["ProductType"].Value.ToString(), dgItemOrProductList.CurrentRow.Cells["ProductName"].Value.ToString()).Tables[0];

                                        if (dtProjectBOMDeleteDetail.Rows.Count > 0)
                                        {
                                            GLobalClass.iSuccess = DAL.fnAddProjectBOM(Global.uDELETE, dtProjectBOMDeleteDetail.Rows[0]["ProjectBOMCode"].ToString(), cmbProjectCode.Text,
                                                dtProjectBOMDeleteDetail.Rows[0]["ProductNo"].ToString(), "", Convert.ToDouble(null), Convert.ToDouble(null), null, null, null, null, null, dtProjectBOMDeleteDetail.Rows[0]["ProductCode"].ToString(), null, 0, null, "1", "1", "", 0, true);

                                            try
                                            {

                                                double projectCost = DAL.fnGetProjectCost("PROJECT", cmbProjectCode.Text);
                                                double projectIssuedCost = DAL.fnGetProjectCost("ISSUE", cmbProjectCode.Text);
                                                int fnCreateERPProjectBOMChangesLogsStatus = DAL.fnCreateERPProjectBOMChangesLogs(cmbProjectCode.Text, dtProjectBOMDeleteDetail.Rows[0]["ProductNo"].ToString(), dgItemOrProductList.CurrentRow.Cells["ProductName"].Value.ToString(), null, null, Login.frmLoginForm.sUserDetails[2],
                                                  null, dtProjectBOMDeleteDetail.Rows[0]["ProductCode"].ToString(), dgItemOrProductList.CurrentRow.Cells["ProductType"].Value.ToString(), dtProjectBOMDeleteDetail.Rows[0]["ProjectBOMCode"].ToString(), lblProjectStaus.Text, null, "Delete ProjectBOM", projectCost, projectIssuedCost);
                                            }
                                            catch
                                            {
                                            }

                                            GLobalClass.iSuccess = DAL.fnAddMachineBOM(Global.uDELETE, dtProjectBOMDeleteDetail.Rows[0]["ProjectBOMCode"].ToString(), dtProjectBOMDeleteDetail.Rows[0]["ProductNo"].ToString(),
                                            null, dtProjectBOMDeleteDetail.Rows[0]["ProjectCode"].ToString(), null, null, null, null, null, null, 0, 0, 0, null, null, null, null, 0);

                                            try
                                            {
                                                double projectCost = DAL.fnGetProjectCost("PROJECT", cmbProjectCode.Text);
                                                double projectIssuedCost = DAL.fnGetProjectCost("ISSUE", cmbProjectCode.Text);
                                                int fnCreateERPProjectBOMChangesLogsStatus = DAL.fnCreateERPProjectBOMChangesLogs(cmbProjectCode.Text, dtProjectBOMDeleteDetail.Rows[0]["ProductNo"].ToString(), dgItemOrProductList.CurrentRow.Cells["ProductName"].Value.ToString(), null, null, Login.frmLoginForm.sUserDetails[2],
                                                   null, dtProjectBOMDeleteDetail.Rows[0]["ProductCode"].ToString(), dgItemOrProductList.CurrentRow.Cells["ProductType"].Value.ToString(), dtProjectBOMDeleteDetail.Rows[0]["ProjectBOMCode"].ToString(), lblProjectStaus.Text, null, "Delete MachineBOM", projectCost, projectIssuedCost);
                                            }
                                            catch
                                            {
                                            }


                                            dgItemOrProductList.Rows.RemoveAt(dgItemOrProductList.Rows.IndexOf(dgItemOrProductList.CurrentRow));

                                            sTotalAmount = Convert.ToDouble("0.0");
                                            foreach (DataGridViewRow dgvr in dgItemOrProductList.Rows)
                                            {
                                                //avinash------------------------------------
                                                if (!string.IsNullOrEmpty(dgvr.Cells["PProductCode"].Value.ToString()))
                                                {
                                                    sTotalAmount += Convert.ToDouble(dgvr.Cells["UnitCost"].Value);
                                                }
                                                //---------------------------------------------
                                                //sTotalAmount += Convert.ToDouble(dgvr.Cells["UnitCost"].Value); Shiva code
                                            }

                                            fnTotalAmount(sTotalAmount);
                                            CultureInfo india = new CultureInfo("hi-IN");
                                            string text = string.Format(india, "{0:c}", dNewTotalAmount); // ₹ 3,20,000 
                                            txtTotalCost.Text = text;
                                            lblProductCost.ResetText();
                                            dgBOMList.DataSource = null;
                                            MessageBox.Show("BOM '" + sProductName + "' deleted successfully.", "Information", 0, MessageBoxIcon.Information);
                                        }
                                        else
                                        {
                                            dgItemOrProductList.Rows.RemoveAt(dgItemOrProductList.Rows.IndexOf(dgItemOrProductList.CurrentRow));

                                            sTotalAmount = Convert.ToDouble("0.0");
                                            foreach (DataGridViewRow dgvr in dgItemOrProductList.Rows)
                                            {
                                                sTotalAmount += Convert.ToDouble(dgvr.Cells["UnitCost"].Value);
                                            }

                                            fnTotalAmount(sTotalAmount);
                                            CultureInfo india = new CultureInfo("hi-IN");
                                            string text = string.Format(india, "{0:c}", dNewTotalAmount); // ₹ 3,20,000 
                                            txtTotalCost.Text = text;
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("BOM cannot be deleted.Some Items are already Issued for the selected BOM", "Error", 0, MessageBoxIcon.Error);
                                    }

                                    if (dgItemOrProductList.Rows.Count == 0)
                                    {
                                        dgBOMList.DataSource = null;
                                    }
                                }

                            }
                            else
                            {
                                MessageBox.Show("BOM cannot be deleted. Select the project code delete a product.", "Error", 0, MessageBoxIcon.Error);
                            }
                        }
                        else
                        {
                            MessageBox.Show("BOM cannot be deleted. Click on the BOM Product to delete.", "Error", 0, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        DialogResult DR = MessageBox.Show("Do you want to delete selected BOM  '" + dgItemOrProductList.CurrentRow.Cells["ProductName"].Value.ToString() + "'", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (DR == DialogResult.Yes)
                        {
                            dtProjectBOMDeleteDetail = DAL.fnProjectBOMProdutnamenumber(dgItemOrProductList.CurrentRow.Cells["PProductCode"].Value.ToString(), cmbProjectCode.Text, dgItemOrProductList.CurrentRow.Cells["ProductType"].Value.ToString(), dgItemOrProductList.CurrentRow.Cells["ProductName"].Value.ToString()).Tables[0];

                            if (dtProjectBOMDeleteDetail.Rows.Count > 0)
                            {
                                GLobalClass.iSuccess = DAL.fnAddProjectBOM(Global.uDELETE, dtProjectBOMDeleteDetail.Rows[0]["ProjectBOMCode"].ToString(), cmbProjectCode.Text,
                                    dtProjectBOMDeleteDetail.Rows[0]["ProductNo"].ToString(), "", Convert.ToDouble(null), Convert.ToDouble(null), null, null, null, null, null, dtProjectBOMDeleteDetail.Rows[0]["ProductCode"].ToString(), null, 0, null, "1", "1", "", 0, true);


                                dgItemOrProductList.Rows.RemoveAt(dgItemOrProductList.Rows.IndexOf(dgItemOrProductList.CurrentRow));
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("The BOM in Lock Please Check With Manager", "BOM IN LOCK");
            }

        }
        #endregion

        #region Quantity Update Function
        private void dgItemOrProductList_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            DataTable GetERPProjectBOMLockDetails = DAL.fnGetERPProjectBOMLock(cmbProjectCode.Text).Tables[0];
            bool AllowBOM = true;
            if (GetERPProjectBOMLockDetails.Rows.Count > 0)
            {
                if (GetERPProjectBOMLockDetails.Rows[0]["LockNow"].ToString().ToLower() == "true")
                {
                    // MessageBox.Show($"The selected project currently LOCK...!");
                    AllowBOM = false;
                }
                else
                {
                    AllowBOM = true;
                }
                if (GetERPProjectBOMLockDetails.Rows[0]["LockNow"].ToString().ToLower() == "false")
                {
                    try
                    {
                        var s = GetERPProjectBOMLockDetails.Rows[0]["BOMClosingDate"]?.ToString();
                        var bomClosingDate = DateTime.ParseExact(s, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                        int cmp = DateTime.Compare(bomClosingDate.Date, DateTime.Today);
                        // MessageBox.Show(cmp.ToString());
                        if (cmp == 1)
                        {
                            // MessageBox.Show($"The selected project currently Open till{s}..!");
                            AllowBOM = true;
                        }
                        else
                        {
                            AllowBOM = false;
                            // MessageBox.Show($"The selected project currently LOCK {s}..!");
                        }
                    }
                    catch
                    {
                    }
                }

            }

            if (AllowBOM)
            {
                bool bQTYUpdate = true;

                if (dgItemOrProductList.CurrentCell.OwningColumn.Name == "Quantity")
                {
                    if (!string.IsNullOrEmpty(dgItemOrProductList.CurrentCell.Value.ToString()))// != null)
                    {
                        if (Convert.ToDouble(dgItemOrProductList.CurrentCell.Value.ToString()) != 0)
                        {
                            if (Convert.ToDouble(dgItemOrProductList.CurrentCell.Value.ToString()) != oldvalue)
                            {
                                dtProjectCheck = DAL.fnProjectBOMProdutnamenumber(dgItemOrProductList.CurrentRow.Cells["PProductCode"].Value.ToString(), cmbProjectCode.Text,
                                    dgItemOrProductList.CurrentRow.Cells["ProductType"].Value.ToString(), dgItemOrProductList.CurrentRow.Cells["ProductName"].Value.ToString()).Tables[0];
                                if (dtProjectCheck.Rows.Count > 0)
                                {
                                    double iqtyvalue = Convert.ToDouble(dtProjectCheck.Rows[0]["Quantity"].ToString());

                                    foreach (DataGridViewRow dr in dgBOMList.Rows)
                                    {
                                        double iQTY3 = (Convert.ToDouble(dr.Cells["uBOMQty"].Value.ToString()) / iqtyvalue) * Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["Quantity"].Value.ToString());

                                        if (Convert.ToDouble(dr.Cells["IssuedQuantity"].Value.ToString()) > iQTY3)
                                        {
                                            bQTYUpdate = false;
                                            MessageBox.Show("Quantity not updated. Because some items already issued for the product", "Error", 0, MessageBoxIcon.Error);
                                            break;
                                        }
                                    }

                                    if (bQTYUpdate == true)
                                    {
                                        DialogResult DR = MessageBox.Show("Product '" + sProductName + "' quantity will be updated. Are you sure you want to change the quantity", "Update confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                                        if (DR == DialogResult.Yes)
                                        {
                                            foreach (DataGridViewRow dr in dgBOMList.Rows)
                                            {
                                                double iQTY4 = (Convert.ToDouble(dr.Cells["uBOMQty"].Value.ToString()) / iqtyvalue) * Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["Quantity"].Value.ToString());

                                                fnTotalAmount(iQTY4);
                                                dr.Cells["uBOMQty"].Value = dNewTotalAmount.ToString();
                                            }
                                            dtUpdateMachineBOM = DAL.fnProjectBOMProdutnamenumber(dgItemOrProductList.CurrentRow.Cells["PProductCode"].Value.ToString(), cmbProjectCode.Text,
                                                dgItemOrProductList.CurrentRow.Cells["ProductType"].Value.ToString(), dgItemOrProductList.CurrentRow.Cells["ProductName"].Value.ToString()).Tables[0];
                                            if (dtUpdateMachineBOM.Rows.Count > 0)
                                            {
                                                foreach (DataGridViewRow dgvr in dgBOMList.Rows)
                                                {
                                                    GLobalClass.iSuccess = DAL.fnAddMachineBOM(Global.uUPDATE, dtUpdateMachineBOM.Rows[0]["ProjectBOMCode"].ToString(), dtUpdateMachineBOM.Rows[0]["ProductNo"].ToString(), dgvr.Cells["uItemCode"].Value.ToString(),
                                                        dtUpdateMachineBOM.Rows[0]["ProjectCode"].ToString(), null, null, null, null, null, null, Convert.ToDouble(dgvr.Cells["uBOMQty"].Value), 0, 0, null, login.GetUserDetails[2], dtpCreatedDate.Text, dgvr.Cells["ID"].Value.ToString(), Convert.ToDecimal(dgvr.Cells["FixedCost"].Value));
                                                    double dc;
                                                    //added by bhavya replaced latest cost with fixedcost
                                                    dc = Convert.ToDouble(dgvr.Cells["uBOMQty"].Value.ToString()) * Convert.ToDouble(dgvr.Cells["FixedCost"].Value.ToString());
                                                    dc = Math.Round((Double)dc, 2);
                                                    dgvr.Cells["BOMAmount"].Value = dc;
                                                }
                                                sTotalAmount = 0;
                                                foreach (DataGridViewRow dr in dgBOMList.Rows)
                                                {
                                                    sTotalAmount += Convert.ToDouble(dr.Cells["BOMAmount"].Value.ToString()); ;
                                                }
                                                fnTotalAmount(sTotalAmount);
                                                dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value = dNewTotalAmount.ToString();
                                                string text2 = string.Format(india, "{0:c}", dNewTotalAmount); // ₹ 3,20,000 
                                                lblProductCost.Text = text2;

                                                GLobalClass.iSuccess = DAL.fnAddProjectBOM(Global.uUPDATE, null, cmbProjectCode.Text, dtProjectCheck.Rows[0]["ProductNo"].ToString(), dgItemOrProductList.CurrentRow.Cells["PProductCode"].Value.ToString(),
                                                    Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["Quantity"].Value), Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value), null, null, null, null, null, null, null, 0, null, "1", "1", "", 0, false);

                                                sTotalAmount = 0;
                                                foreach (DataGridViewRow dgvr in dgItemOrProductList.Rows)
                                                {
                                                    //AVINASH---------------------------------
                                                    if (!string.IsNullOrEmpty(dgvr.Cells["PProductCode"].Value.ToString()))
                                                    {
                                                        sTotalAmount += Convert.ToDouble(dgvr.Cells["UnitCost"].Value);
                                                    }
                                                    //------------------------------------------
                                                }
                                                fnTotalAmount(sTotalAmount);
                                                string text = string.Format(india, "{0:c}", dNewTotalAmount); // ₹ 3,20,000 
                                                txtTotalCost.Text = text;
                                            }
                                        }
                                        else
                                        {
                                            dgItemOrProductList.CurrentRow.Cells["Quantity"].Value = iqtyvalue.ToString();
                                        }
                                    }
                                }
                                else
                                {
                                    double ssTotalAmount = Convert.ToDouble("0.0");
                                    foreach (DataGridViewRow dgvr in dgBOMList.Rows)
                                    {
                                        ssTotalAmount += Convert.ToDouble(dgvr.Cells["BOMAmount"].Value);
                                    }
                                    fnTotalAmount(ssTotalAmount);

                                    double dc1;
                                    dc1 = Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["Quantity"].Value) * dNewTotalAmount;
                                    dc1 = Math.Round((Double)dc1, 2);
                                    dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value = dc1;
                                    sTotalAmount = Convert.ToDouble("0.0");
                                    foreach (DataGridViewRow dgvr in dgItemOrProductList.Rows)
                                    {
                                        if (!string.IsNullOrEmpty(dgvr.Cells["PProductCode"].Value.ToString()))
                                        {
                                            sTotalAmount += Convert.ToDouble(dgvr.Cells["UnitCost"].Value);
                                        }
                                        // sTotalAmount += Convert.ToDouble(dgvr.Cells["UnitCost"].Value);
                                    }
                                    fnTotalAmount(sTotalAmount);
                                    CultureInfo india = new CultureInfo("hi-IN");
                                    string text = string.Format(india, "{0:c}", dNewTotalAmount); // ₹ 3,20,000 
                                    txtTotalCost.Text = text;
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("Entered value should be greater than 0", "Error", 0, MessageBoxIcon.Error);
                            dgItemOrProductList.CurrentCell.Value = oldvalue;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Enter a Valid Value", "Error", 0, MessageBoxIcon.Error);
                        dgItemOrProductList.CurrentCell.Value = oldvalue;
                    }
                }
            }
        }
        #endregion


        #region Excel File Creation
        string ExcelFolderPath;
        string FileFullPath;
        private void btnSaveExcel_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Excel._Application app1 = null;
            Microsoft.Office.Interop.Excel._Workbook workbook1 = null;
            Cursor.Current = Cursors.WaitCursor;
            DataTable dtExcleProjectBOM = new DataTable();
            List<string> listProductORItemName = new List<string>();
            dtExcleProjectBOM = DAL.fnProjectBOMList(cmbProjectCode.Text).Tables[0];

            DataTable KanbanDetails = DAL.getKanbanDetails(cmbProjectCode.Text).Tables[0];

            if (KanbanDetails.Rows.Count > 0 && false)
            {
                //  MessageBox.Show(KanbanDetails.Rows[0]["IssuedAmount"].ToString());
                DataRow row = dtExcleProjectBOM.NewRow();

                row["id"] = dtExcleProjectBOM.Rows.Count + 1;   // Or MAX(SlNo)+1 if you prefer
                row["ProjectBOMCode"] = DBNull.Value;
                row["ProjectCode"] = cmbProjectCode.Text;
                row["ProductNo"] = "1111111111";
                row["ProductName"] = "Kanban Products";
                row["Quantity"] = 1;
                //row["UnitCost"] = KanbanDetails.Rows[0]["ProjectCost"].ToString();

                var rawUnitCost = KanbanDetails.Rows[0]["ProjectCost"];
                var tmpUnitCost = Convert.ToDecimal(rawUnitCost, CultureInfo.InvariantCulture);
                row["UnitCost"] = Convert.ToInt32(Math.Round(tmpUnitCost));

                row["CreatedDate"] = DateTime.Now;
                row["CreatedBy"] = Environment.UserName; // Or your own value
                row["AutherisedBy"] = DBNull.Value;
                row["ProductType"] = "Kanban Items";
                row["Remarks"] = DBNull.Value;
                row["Version"] = 1;
                row["ProductCode"] = 1111111;
                //row["IssuedAmount"] = KanbanDetails.Rows[0]["IssuedAmount"].ToString();     // From query = Decimal


                var rawIssued = KanbanDetails.Rows[0]["IssuedAmount"];
                var tmpIssued = Convert.ToDecimal(rawIssued, CultureInfo.InvariantCulture);
                // row["IssuedAmount"] = Convert.ToInt32(Math.Round(tmpIssued));

                // row["Progress"] = "";            // VARCHAR
                //row["ProjectBOM"] = false;         // BIT
                row["DesignBOM"] = false;         // BIT
                                                  //row["StartDate"] ="";
                                                  //row["FinishDate"] = "";

                dtExcleProjectBOM.Rows.Add(row);

                //dgItemOrProductList.AutoGenerateColumns = false;
                //dgItemOrProductList.DataSource = dtDGDatatable;
                //MessageBox.Show("added");
            }

            if (dtExcleProjectBOM.Rows.Count > 0)
            {
                app1 = new Microsoft.Office.Interop.Excel.Application();
                workbook1 = app1.Workbooks.Add(Type.Missing);
                Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
                worksheet = workbook1.Sheets["Sheet1"];
                worksheet = workbook1.ActiveSheet;
                worksheet.Name = "Project BOM";
                object misValue = System.Reflection.Missing.Value;

                ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\Project BOM\";
                FileFullPath = ExcelFolderPath + cmbProjectCode.Text + "-" + DateTime.Now.ToString("d/M/yyyy/hh/mm/ss") + "";
                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);

                workbook1.SaveAs(FileFullPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                 Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                worksheet.Cells[1, 2] = "BiSS-ITW PVT LTD";
                worksheet.Cells[2, 1] = "Project Code";
                worksheet.Cells[2, 2] = "" + cmbProjectCode.Text + "";
                worksheet.Cells[3, 1] = "Project Name";
                worksheet.Cells[3, 2] = "" + txtProjectName.Text + "";
                worksheet.Cells[4, 1] = "Total Issued Amount:";
                worksheet.Cells[4, 2] = lblIssuedCost.Text;
                worksheet.Cells[5, 1] = "Total project Cost:";
                worksheet.Cells[5, 2] = txtTotalCost.Text;
                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[4, Type.Missing]).Font.Color = Color.Green;
                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[5, Type.Missing]).Font.Color = Color.Green;

                worksheet.Range["A1:C1"].Cells.Font.Size = 16;
                worksheet.Range["A1:C1"].Cells.Font.Bold = 16;
                worksheet.Range["A2:C2"].Cells.Font.Size = 14;
                worksheet.Range["A2:C2"].Cells.Font.Bold = 14;
                worksheet.Range["A3:C3"].Cells.Font.Size = 12;
                worksheet.Range["A3:C3"].Cells.Font.Bold = 12;
                worksheet.Range["A3:C4"].Cells.Font.Size = 12;
                worksheet.Range["A3:C4"].Cells.Font.Bold = 12;
                worksheet.Range["A4:C4"].Cells.Font.Bold = true;
                worksheet.Range["A4:C4"].Cells.Font.Size = 16;
                int i = 0;
                foreach (DataRow dr in dtExcleProjectBOM.Rows)
                {
                    DataTable dtMachineBOM = new DataTable();
                    if (dr["ProductNo"].ToString() == "1111111111" )
                    {

                       // dtMachineBOM = DAL.fnKanbanProdutItemsList(cmbProjectCode.Text).Tables[0];
                        dtMachineBOM = DAL.getKanbanItenList(cmbProjectCode.Text).Tables[0];//getKanbanItenList
                        if (dtMachineBOM.Rows.Count > 0)
                        {
                            if (dtMachineBOM.Rows.Count > 0)
                            {
                                CellMerge("Merge", workbook1.ActiveSheet, (i + 7), (i + 7), 1, 8);
                                worksheet.Cells[i + 7, 1] = dr["ProductName"].ToString() + "  -   " + dr["ProductType"].ToString();

                                dtMachineBOM.Columns.Remove("id");
                                dtMachineBOM.Columns.Remove("Unitprice");
                                dtMachineBOM.Columns.Remove("ProjectBOMCode");
                                dtMachineBOM.Columns.Remove("ProductNo");
                                dtMachineBOM.Columns.Remove("PODATE");
                                dtMachineBOM.Columns.Remove("LatestCost");
                                dtMachineBOM.Columns.Remove("Status");
                                dtMachineBOM.Columns.Remove("BOMAmount");
                                dtMachineBOM.Columns.Remove("DrawingNo");
                                dtMachineBOM.Columns.Remove("RevisionNo");
                                dtMachineBOM.Columns.Remove("AvailableQty");
                                //dtMachineBOM.Columns.Remove("ProductNo");
                            }
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 7, Type.Missing]).Font.Color = Color.Red;
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 7, Type.Missing]).Font.Bold = true;
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 8, Type.Missing]).Font.Bold = true;
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 8, Type.Missing]).Font.Color = Color.Blue;

                            string[] sColumnNames = new string[]
                                {
                                    //"ID",
                                   // "ProjectBOMCode",
                                    //"ProductNo",
                                    "ItemName",
                                    "ItemDescription",
                                    "Quantity",
                                    "IssuedQuantity",
                                    //"AvailableQty",
                                    "UnitCost",
                                    "FixedCost",
                                    //"Unitprice",
                                    "IssueCost",
                                    //"BOMAmount",
                                    //"LatestCost",
                                    //"RevisionNo",
                                    //"DrawingNo",
                                    //"Status",
                                    "AddedBy",
                                    "AddedDate",
                                    "ProductType",
                                    //"PODATE"
                                };
                                // { "ItemCode", "ItemDescription", "ItemType", "BOMQuantity", "Unitprice", "AddedBy", "AddedDate", "Unit" };
                            int icolumn = 1;
                            for (int p = 0; p < sColumnNames.Length; p++)
                            {
                                worksheet.Cells[i + 8, icolumn] = sColumnNames[p];
                                icolumn++;
                            }

                            for (int iCountRow = 0; iCountRow < (dtMachineBOM.Rows.Count); iCountRow++)
                            {
                                i++;
                                worksheet.Rows.AutoFit();
                                for (int j = 0; j < dtMachineBOM.Columns.Count; j++)
                                {
                                    worksheet.Columns.AutoFit();
                                    worksheet.Cells[i + 8, j + 1] = dtMachineBOM.Rows[iCountRow][j].ToString();
                                }
                            }
                            i++;
                            worksheet.Cells[i + 9, 5] = "Total Cost:";

                            double TotalMachineBOM = 0.0;
                            foreach (DataRow dtme in dtMachineBOM.Rows)
                            {
                                TotalMachineBOM += Convert.ToDouble(Convert.ToDouble(dtme["FixedCost"].ToString()) * Convert.ToDouble(dtme["Quantity"].ToString()));
                            }

                            worksheet.Cells[i + 9, 6] = TotalMachineBOM.ToString();

                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 8, Type.Missing]).Font.Bold = true;
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 8, Type.Missing]).Font.Color = Color.Blue;
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 9, Type.Missing]).Font.Bold = true;
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 9, Type.Missing]).Font.Color = Color.Blue;
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 10, Type.Missing]).Font.Bold = true;
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 10, Type.Missing]).Font.Color = Color.Blue;
                            i += 4;
                        }
                    }
                    else
                    {


                        dtMachineBOM = DAL.fnMachineBOMProdutItems(dr["ProductNo"].ToString(), cmbProjectCode.Text).Tables[0];

                        //MessageBox.Show(dr["ProductNo"].ToString()+cmbProjectCode.Text, dtMachineBOM.Rows.Count.ToString());
                        if (dtMachineBOM.Rows.Count > 0)
                        {
                            if (dtMachineBOM.Rows.Count > 0)
                            {
                                CellMerge("Merge", workbook1.ActiveSheet, (i + 7), (i + 7), 1, 8);
                                worksheet.Cells[i + 7, 1] = dr["ProductCode"].ToString() + "    -   " + dr["ProductName"].ToString() + "  -   " + dr["ProductType"].ToString();

                                dtMachineBOM.Columns.Remove("ProjectBOMCode");
                                dtMachineBOM.Columns.Remove("ProductNo");
                            }
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 7, Type.Missing]).Font.Color = Color.Red;
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 7, Type.Missing]).Font.Bold = true;
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 8, Type.Missing]).Font.Bold = true;
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 8, Type.Missing]).Font.Color = Color.Blue;

                            string[] sColumnNames = new string[] { "ItemName", "ItemDescription", "BOM Qty", "Issued Qty", "UnitCost", "FixedCost", "IssueCost", "Amount", "ExtraItem", "DrawingNo", "MfgPartNo", "Make", "Specification", "Location", "Vendor" };
                            int icolumn = 1;
                            for (int p = 0; p < sColumnNames.Length; p++)
                            {
                                worksheet.Cells[i + 8, icolumn] = sColumnNames[p];
                                icolumn++;
                            }

                            for (int iCountRow = 0; iCountRow < (dtMachineBOM.Rows.Count); iCountRow++)
                            {
                                i++;
                                worksheet.Rows.AutoFit();
                                for (int j = 0; j < dtMachineBOM.Columns.Count; j++)
                                {
                                    worksheet.Columns.AutoFit();
                                    worksheet.Cells[i + 8, j + 1] = dtMachineBOM.Rows[iCountRow][j].ToString();
                                }
                            }
                            i++;
                            worksheet.Cells[i + 9, 5] = "Total Cost:";

                            double TotalMachineBOM = 0.0;
                            foreach (DataRow dtme in dtMachineBOM.Rows)
                            {
                                TotalMachineBOM += Convert.ToDouble(dtme["BOMAmount"].ToString());
                            }

                            worksheet.Cells[i + 9, 6] = TotalMachineBOM.ToString();

                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 8, Type.Missing]).Font.Bold = true;
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 8, Type.Missing]).Font.Color = Color.Blue;
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 9, Type.Missing]).Font.Bold = true;
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 9, Type.Missing]).Font.Color = Color.Blue;
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 10, Type.Missing]).Font.Bold = true;
                            ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[i + 10, Type.Missing]).Font.Color = Color.Blue;
                            i += 4;
                        }
                    }
                }

                Microsoft.Office.Interop.Excel.Range r = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[1, 1];
                r.EntireColumn.NumberFormat = "@";
                Microsoft.Office.Interop.Excel.Range range = worksheet.get_Range("C6", "F9999");
                range.NumberFormat = "0.00";
                worksheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
                worksheet.Columns[1].ColumnWidth = 20;
                worksheet.Columns[1].WrapText = true;
                worksheet.Columns[2].ColumnWidth = 48;
                worksheet.Columns[2].WrapText = true;
                worksheet.Columns[3].ColumnWidth = 10;
                worksheet.Columns[4].ColumnWidth = 10;
                worksheet.Columns[5].ColumnWidth = 10;
                worksheet.Columns[6].ColumnWidth = 10;
                worksheet.Columns[7].ColumnWidth = 11;
                worksheet.Columns[8].ColumnWidth = 20;
                worksheet.Columns[8].WrapText = true;
                worksheet.Columns[9].ColumnWidth = 15;
                worksheet.Columns[9].WrapText = true;
                worksheet.Columns[10].ColumnWidth = 18;
                worksheet.Columns[10].WrapText = true;
                worksheet.Columns[11].ColumnWidth = 15;
                worksheet.Columns[11].WrapText = true;
                worksheet.Columns[12].ColumnWidth = 50;
                worksheet.Columns[12].WrapText = true;
                worksheet.Rows.RowHeight = "18";
                worksheet.PageSetup.Zoom = false;
                worksheet.PageSetup.Zoom = 86;
                worksheet.PageSetup.FitToPagesTall = 1;
                worksheet.PageSetup.FitToPagesWide = 1;
                worksheet.PageSetup.LeftMargin = 0;
                worksheet.PageSetup.RightMargin = 0;
                worksheet.PageSetup.TopMargin = 0.75;
                worksheet.PageSetup.BottomMargin = 0.75;
                worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                EXCEL.Range oRange = (EXCEL.Range)worksheet.Cells[1, 8];
                Image oImage = Image.FromFile(Global.sLogo);
                System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                // worksheet.Paste(oRange, Global.sLogo);
                System.Threading.Thread.Sleep(500);
                worksheet.Paste(oRange);

                workbook1.Save();
                workbook1.Close(true, misValue, misValue);
                app1.Quit();
                releaseObject(worksheet);
                releaseObject(workbook1);
                releaseObject(app1);
                if (Directory.Exists(ExcelFolderPath))
                {
                    Process.Start(ExcelFolderPath);
                }
                Cursor.Current = Cursors.Default;

                // app1.Visible = true;
            }
            else
            {
                MessageBox.Show("Please slect a BOM project to Create Excel Report", "Error", 0, MessageBoxIcon.Warning);
            }
        }
        #endregion

        #region Excel App Release Object Function
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
        #endregion

        #region Excel cell merge
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlMedium, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

        }
        #endregion
        #region Update BOM Quantity
        private void dgBOMList_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            DataTable GetERPProjectBOMLockDetails = DAL.fnGetERPProjectBOMLock(cmbProjectCode.Text).Tables[0];
            bool AllowBOM = true;
            if (GetERPProjectBOMLockDetails.Rows.Count > 0)
            {
                if (GetERPProjectBOMLockDetails.Rows[0]["LockNow"].ToString().ToLower() == "true")
                {
                    // MessageBox.Show($"The selected project currently LOCK...!");
                    AllowBOM = false;
                }
                else
                {
                    AllowBOM = true;
                }
                if (GetERPProjectBOMLockDetails.Rows[0]["LockNow"].ToString().ToLower() == "false")
                {
                    try
                    {
                        var s = GetERPProjectBOMLockDetails.Rows[0]["BOMClosingDate"]?.ToString();
                        var bomClosingDate = DateTime.ParseExact(s, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                        int cmp = DateTime.Compare(bomClosingDate.Date, DateTime.Today);
                        // MessageBox.Show(cmp.ToString());
                        if (cmp == 1)
                        {
                            // MessageBox.Show($"The selected project currently Open till{s}..!");
                            AllowBOM = true;
                        }
                        else
                        {
                            AllowBOM = false;
                            // MessageBox.Show($"The selected project currently LOCK {s}..!");
                        }
                    }
                    catch
                    {
                    }
                }

            }

            if (AllowBOM)
            {
                if (dgBOMList.CurrentCell.OwningColumn.Name == "uBOMQty")
                {
                    if (!string.IsNullOrEmpty(dgBOMList.CurrentCell.Value.ToString()) && (dgBOMList.CurrentCell.Value.ToString() != sDot))// != null)
                    {
                        if (Convert.ToDouble(dgBOMList.CurrentCell.Value.ToString()) != 0)
                        {
                            if (Convert.ToDouble(dgBOMList.CurrentCell.Value.ToString()) != oldvalue) //oldvalue
                            {
                                if (Convert.ToDouble(dgBOMList.CurrentRow.Cells["uBOMQty"].Value) >= Convert.ToDouble(dgBOMList.CurrentRow.Cells["IssuedQuantity"].Value))// && (Convert.ToDouble(dgBOMList.CurrentCell.Value.ToString()) != oldvalue))
                                {
                                    dtUpdateMachineBOM = DAL.fnProjectBOMProdutnamenumber(dgItemOrProductList.CurrentRow.Cells["PProductCode"].Value.ToString(), cmbProjectCode.Text,
                                        dgItemOrProductList.CurrentRow.Cells["ProductType"].Value.ToString(), dgItemOrProductList.CurrentRow.Cells["ProductName"].Value.ToString()).Tables[0];
                                    if (dtUpdateMachineBOM.Rows.Count > 0)
                                    {
                                        GLobalClass.iSuccess = DAL.fnAddMachineBOM(Global.uUPDATE, dtUpdateMachineBOM.Rows[0]["ProjectBOMCode"].ToString(), dtUpdateMachineBOM.Rows[0]["ProductNo"].ToString(),
                                            dgBOMList.CurrentRow.Cells["uItemCode"].Value.ToString(), dtUpdateMachineBOM.Rows[0]["ProjectCode"].ToString(), null, null, null, null, null, null, Convert.ToDouble(dgBOMList.CurrentRow.Cells["uBOMQty"].Value, null),
                                            0, 0, null, login.GetUserDetails[2], dtpCreatedDate.Text, dgBOMList.CurrentRow.Cells["ID"].Value.ToString(), Convert.ToDecimal(dgBOMList.CurrentRow.Cells["FixedCost"].Value));



                                        try
                                        {
                                            double projectCost = DAL.fnGetProjectCost("PROJECT", dtUpdateMachineBOM.Rows[0]["ProjectCode"].ToString());
                                            double projectIssuedCost = DAL.fnGetProjectCost("ISSUE", dtUpdateMachineBOM.Rows[0]["ProjectCode"].ToString());

                                            int fnCreateERPProjectBOMChangesLogsStatus = DAL.fnCreateERPProjectBOMChangesLogs(dtUpdateMachineBOM.Rows[0]["ProjectCode"].ToString(), dtUpdateMachineBOM.Rows[0]["ProductNo"].ToString(), dtUpdateMachineBOM.Rows[0]["ProductName"].ToString(), dgBOMList.CurrentRow.Cells["uBOMQty"].Value.ToString(), fCost.ToString(), Login.frmLoginForm.sUserDetails[2],
                                               cmbVersion.Text, dgItemOrProductList.CurrentRow.Cells["PProductCode"].Value.ToString(), cmbProductCategory.Text, dtUpdateMachineBOM.Rows[0]["ProjectBOMCode"].ToString(), lblProjectStaus.Text, dgBOMList.CurrentRow.Cells["uItemCode"].Value.ToString(), "Updated ProjectBOM", projectCost, projectIssuedCost);
                                        }
                                        catch
                                        {
                                        }

                                        dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value = Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value) - Convert.ToDouble(dgBOMList.CurrentRow.Cells["BOMAmount"].Value);

                                        double dc;

                                        //dc = Convert.ToDouble(dgBOMList.CurrentRow.Cells["uBOMQty"].Value.ToString()) * Convert.ToDouble(dgBOMList.CurrentRow.Cells["LatestCost"].Value.ToString());
                                        dc = Convert.ToDouble(dgBOMList.CurrentRow.Cells["uBOMQty"].Value.ToString()) * Convert.ToDouble(dgBOMList.CurrentRow.Cells["FixedCost"].Value.ToString());
                                        dc = Math.Round((Double)dc, 2);
                                        fnTotalAmount(dc);
                                        //dgBOMList.CurrentRow.Cells["BOMAmount"].Value = dNewTotalAmount.ToString();

                                        fnTotalAmount(Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value));
                                        dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value = dNewTotalAmount.ToString();

                                        dtProjectCheck = DAL.fnProjectBOMProdutnamenumber(dgItemOrProductList.CurrentRow.Cells["PProductCode"].Value.ToString(), cmbProjectCode.Text,
                                            dgItemOrProductList.CurrentRow.Cells["ProductType"].Value.ToString(), dgItemOrProductList.CurrentRow.Cells["ProductName"].Value.ToString()).Tables[0];
                                        if (dtProjectCheck.Rows.Count > 0)
                                        {

                                            sTotalAmount = 0;
                                            foreach (DataGridViewRow dgvr in dgBOMList.Rows)
                                            {
                                                sTotalAmount += Convert.ToDouble(dgvr.Cells["FixedCost"].Value) * Convert.ToDouble(dgvr.Cells["uBOMQty"].Value);
                                            }
                                            fnTotalAmount(sTotalAmount);
                                            dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value = Math.Round(sTotalAmount);


                                            GLobalClass.iSuccess = DAL.fnAddProjectBOM(Global.uUPDATE, null, cmbProjectCode.Text, dtProjectCheck.Rows[0]["ProductNo"].ToString(), dgItemOrProductList.CurrentRow.Cells["PProductCode"].Value.ToString(),
                                                Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["Quantity"].Value), Convert.ToDouble(dNewTotalAmount), null, null, null, null, null, null, null, 0, null, "", "", "", 0, false);

                                            sTotalAmount = 0;

                                            foreach (DataGridViewRow dgvr in dgItemOrProductList.Rows)
                                            {
                                                if (!string.IsNullOrEmpty(dgvr.Cells["PProductCode"].Value.ToString()))
                                                {
                                                    sTotalAmount += Convert.ToDouble(dgvr.Cells["UnitCost"].Value);
                                                }
                                                // sTotalAmount += Convert.ToDouble(dgvr.Cells["UnitCost"].Value) * Convert.ToDouble(dgvr.Cells["Quantity"].Value);
                                            }
                                            //    txtTotalCost.Text = sTotalAmount.ToString();
                                            fnTotalAmount(sTotalAmount);
                                            string text = string.Format(india, "{0:c}", dNewTotalAmount); // ₹ 3,20,000 
                                            txtTotalCost.Text = text;


                                            sTotalAmount = 0;
                                            foreach (DataGridViewRow dgvr in dgBOMList.Rows)
                                            {
                                                sTotalAmount += Convert.ToDouble(dgvr.Cells["FixedCost"].Value) * Convert.ToDouble(dgvr.Cells["uBOMQty"].Value);
                                            }
                                            fnTotalAmount(sTotalAmount);
                                            text = string.Format(india, "{0:c}", dNewTotalAmount); // ₹ 3,20,000 
                                            lblProductCost.Text = text;
                                        }

                                        MessageBox.Show("'" + dgBOMList.CurrentRow.Cells["uItemCode"].Value.ToString() + "'  BOM Quantity Updated.", "Success", 0, MessageBoxIcon.Information);
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Items already issued for the product. Entered value should be greater than issued quanity ", "Error", 0, MessageBoxIcon.Error);
                                    dgBOMList.CurrentCell.Value = oldvalue;
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("Entered value should be greater than 0", "Error", 0, MessageBoxIcon.Error);
                            dgBOMList.CurrentCell.Value = oldvalue;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Enter a Valid Value", "Error", 0, MessageBoxIcon.Error);
                        dgBOMList.CurrentCell.Value = oldvalue;
                    }
                }
                else if (dgBOMList.CurrentCell.OwningColumn.Name == "IProductType")
                {
                    if (!string.IsNullOrEmpty(dgBOMList.CurrentRow.Cells["IProductType"].Value.ToString()))
                    {
                        dtUpdateMachineBOM = DAL.fnProjectBOMProdutnamenumber(dgItemOrProductList.CurrentRow.Cells["PProductCode"].Value.ToString(), cmbProjectCode.Text,
                                          dgItemOrProductList.CurrentRow.Cells["ProductType"].Value.ToString(), dgItemOrProductList.CurrentRow.Cells["ProductName"].Value.ToString()).Tables[0];
                        if (dtUpdateMachineBOM.Rows.Count > 0)
                        {
                            GLobalClass.iSuccess = DAL.fnAddMachineBOM(7, dgBOMList.CurrentRow.Cells["IProductType"].Value.ToString(), dgBOMList.CurrentRow.Cells["ID"].Value.ToString(),
                                                                dgBOMList.CurrentRow.Cells["uItemCode"].Value.ToString(), dtUpdateMachineBOM.Rows[0]["ProjectCode"].ToString(), null, null, null, null, null, null, Convert.ToDouble(dgBOMList.CurrentRow.Cells["uBOMQty"].Value, null),
                                                                0, 0, null, login.GetUserDetails[2], dtpCreatedDate.Text, dgBOMList.CurrentRow.Cells["ID"].Value.ToString(), 0);
                        }
                    }
                }
                else if (login.GetUserDetails[2].ToLower() == "vivek g" || login.GetUserDetails[2].ToLower() == "ravi" || login.GetUserDetails[2].ToLower() == "thilak kumar" || login.GetUserDetails[2].ToLower() == "kumar ravi" || login.GetUserDetails[2].ToLower() == "santhoshdj" || login.GetUserDetails[2].ToLower() == "veena" || login.GetUserDetails[2].ToLower() == "pavana" || login.GetUserDetails[2].ToLower() == "hemanth reddy" || login.GetUserDetails[2].ToLower() == "vishal raina")
                {
                    if (dgBOMList.CurrentCell.OwningColumn.Name == "FixedCost")
                    {
                        if (!string.IsNullOrEmpty(dgBOMList.CurrentRow.Cells["FixedCost"].Value.ToString()))
                        {
                            //  GLobalClass.iSuccess = DAL.fnAddMachineBOM(8, dgBOMList.CurrentRow.Cells["IProductType"].Value.ToString(), dgBOMList.CurrentRow.Cells["ID"].Value.ToString(),
                            //     dgBOMList.CurrentRow.Cells["uItemCode"].Value.ToString(), dtUpdateMachineBOM.Rows[0]["ProjectCode"].ToString(), null, null, null, null, null, null, Convert.ToDouble(dgBOMList.CurrentRow.Cells["uBOMQty"].Value, null),
                            //   0, 0, null, login.GetUserDetails[2], dtpCreatedDate.Text, dgBOMList.CurrentRow.Cells["ID"].Value.ToString(), 0);

                            dtUpdateMachineBOM = DAL.fnProjectBOMProdutnamenumber(dgItemOrProductList.CurrentRow.Cells["PProductCode"].Value.ToString(), cmbProjectCode.Text,
                                       dgItemOrProductList.CurrentRow.Cells["ProductType"].Value.ToString(), dgItemOrProductList.CurrentRow.Cells["ProductName"].Value.ToString()).Tables[0];
                            if (dtUpdateMachineBOM.Rows.Count > 0)
                            {
                                GLobalClass.iSuccess = DAL.fnAddMachineBOM(8, dtUpdateMachineBOM.Rows[0]["ProjectBOMCode"].ToString(), dtUpdateMachineBOM.Rows[0]["ProductNo"].ToString(),
                                           dgBOMList.CurrentRow.Cells["uItemCode"].Value.ToString(), dtUpdateMachineBOM.Rows[0]["ProjectCode"].ToString(), null, null, null, null, null, null, Convert.ToDouble(dgBOMList.CurrentRow.Cells["uBOMQty"].Value, null),
                                           0, 0, null, login.GetUserDetails[2], dtpCreatedDate.Text, dgBOMList.CurrentRow.Cells["ID"].Value.ToString(), Convert.ToDecimal(dgBOMList.CurrentRow.Cells["FixedCost"].Value));
                            }

                        }

                    }
                }
            }
        }
        #endregion
        #region Total Amount Function
        private void fnTotalAmount(double sAmount)
        {
            dNewTotalAmount = 0.0;
            double number = sAmount;

            int intPortion = (int)number;

            decimal fraction = (decimal)(number - intPortion) * 100;

            int decPortion = (int)Math.Round(fraction);
            if (decPortion < 50)
            {
                double number1 = (double)Math.Round(number);
                dNewTotalAmount = number1;
            }
            else
            {
                double number1 = (double)Math.Ceiling(number);
                dNewTotalAmount = number1;
            }
        }
        #endregion
        #region BOM Item Delete
        private void dgBOMList_KeyUp(object sender, KeyEventArgs e)
        {
            DataTable GetERPProjectBOMLockDetails = DAL.fnGetERPProjectBOMLock(cmbProjectCode.Text).Tables[0];
            bool AllowBOM = true;
            if (GetERPProjectBOMLockDetails.Rows.Count > 0)
            {
                if (GetERPProjectBOMLockDetails.Rows[0]["LockNow"].ToString().ToLower() == "true")
                {
                    // MessageBox.Show($"The selected project currently LOCK...!");
                    AllowBOM = false;
                }
                else
                {
                    AllowBOM = true;
                }
                if (GetERPProjectBOMLockDetails.Rows[0]["LockNow"].ToString().ToLower() == "false")
                {
                    try
                    {
                        var s = GetERPProjectBOMLockDetails.Rows[0]["BOMClosingDate"]?.ToString();
                        var bomClosingDate = DateTime.ParseExact(s, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                        int cmp = DateTime.Compare(bomClosingDate.Date, DateTime.Today);
                        // MessageBox.Show(cmp.ToString());
                        if (cmp == 1)
                        {
                            // MessageBox.Show($"The selected project currently Open till{s}..!");
                            AllowBOM = true;
                        }
                        else
                        {
                            AllowBOM = false;
                            // MessageBox.Show($"The selected project currently LOCK {s}..!");
                        }
                    }
                    catch
                    {
                    }
                }

            }

            if (AllowBOM)
            {
                if (e.KeyCode == Keys.Delete)
                {
                    if (dgBOMList.Rows.Count > 0)
                    {
                        if (Convert.ToDouble(dgBOMList.CurrentRow.Cells["IssuedQuantity"].Value) == Convert.ToDouble("0"))
                        {
                            DialogResult DR = MessageBox.Show("Do you want to delete selected Item?  " + dgBOMList.CurrentRow.Cells["uItemDescription"].Value.ToString() + "", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                            if (DR == DialogResult.Yes)
                            {
                                dtDeleteMachineBOMQty = DAL.fnProjectBOMProdutnamenumber(dgItemOrProductList.CurrentRow.Cells["PProductCode"].Value.ToString(), cmbProjectCode.Text,
                                    dgItemOrProductList.CurrentRow.Cells["ProductType"].Value.ToString(), dgItemOrProductList.CurrentRow.Cells["ProductName"].Value.ToString()).Tables[0];
                                if (dtDeleteMachineBOMQty.Rows.Count > 0)
                                {
                                    GLobalClass.iSuccess = DAL.fnDeleteMachineBOMItem(Global.uDELETE, cmbProjectCode.Text, dtDeleteMachineBOMQty.Rows[0]["ProductNo"].ToString(), dgBOMList.CurrentRow.Cells["uItemCode"].Value.ToString(), dgBOMList.CurrentRow.Cells["ID"].Value.ToString());


                                    string descript = dgBOMList.CurrentRow.Cells["uItemDescription"].Value.ToString();
                                    dgBOMList.Rows.RemoveAt(dgBOMList.Rows.IndexOf(dgBOMList.CurrentRow));
                                    sTotalAmount = 0;
                                    foreach (DataGridViewRow dgvr in dgBOMList.Rows)
                                    {
                                        //sTotalAmount += Convert.ToDouble(dgvr.Cells["LatestCost"].Value) * Convert.ToDouble(dgvr.Cells["uBOMQty"].Value);
                                        sTotalAmount += Convert.ToDouble(dgvr.Cells["FixedCost"].Value) * Convert.ToDouble(dgvr.Cells["uBOMQty"].Value);
                                    }
                                    fnTotalAmount(sTotalAmount);
                                    dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value = dNewTotalAmount.ToString();

                                    dtProjectCheck = DAL.fnProjectBOMProdutnamenumber(dgItemOrProductList.CurrentRow.Cells["PProductCode"].Value.ToString(), cmbProjectCode.Text,
                                        dgItemOrProductList.CurrentRow.Cells["ProductType"].Value.ToString(), dgItemOrProductList.CurrentRow.Cells["ProductName"].Value.ToString()).Tables[0];

                                    if (dtProjectCheck.Rows.Count > 0)
                                    {
                                        GLobalClass.iSuccess = DAL.fnAddProjectBOM(Global.uUPDATE, null, cmbProjectCode.Text, dtProjectCheck.Rows[0]["ProductNo"].ToString(), dgItemOrProductList.CurrentRow.Cells["PProductCode"].Value.ToString(),
                                               Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["Quantity"].Value), Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value), null, null, null, null, null, null, null, 0, null, "", "", "", 0, false);
                                    }
                                    MessageBox.Show("'" + descript + "'  Machine BOM Item Deleted.", "Information", 0, MessageBoxIcon.Information);
                                    sTotalAmount = 0;
                                    foreach (DataGridViewRow dgvr in dgItemOrProductList.Rows)
                                    {
                                        if (!string.IsNullOrEmpty(dgvr.Cells["PProductCode"].Value.ToString()))
                                        {
                                            sTotalAmount += Convert.ToDouble(dgvr.Cells["UnitCost"].Value);
                                        }
                                    }
                                    fnTotalAmount(sTotalAmount);
                                    string text = string.Format(india, "{0:c}", dNewTotalAmount); // ₹ 3,20,000 
                                    txtTotalCost.Text = text;

                                    sTotalAmount = 0;
                                    foreach (DataGridViewRow dgvr in dgBOMList.Rows)
                                    {
                                        //sTotalAmount += Convert.ToDouble(dgvr.Cells["LatestCost"].Value) * Convert.ToDouble(dgvr.Cells["uBOMQty"].Value);
                                        sTotalAmount += Convert.ToDouble(dgvr.Cells["FixedCost"].Value) * Convert.ToDouble(dgvr.Cells["uBOMQty"].Value);
                                    }
                                    fnTotalAmount(sTotalAmount);
                                    text = string.Format(india, "{0:c}", dNewTotalAmount); // ₹ 3,20,000 
                                    lblProductCost.Text = text;
                                }
                            }
                        }
                        else
                        {
                            MessageBox.Show("'" + dgBOMList.CurrentRow.Cells["uItemDescription"].Value.ToString() + "'  Machine BOM Item Already Isuued. Cannot be deleted!!", "Warning", 0, MessageBoxIcon.Warning);
                        }
                    }
                }
            }
        }
        #endregion

        DataTable dtSelectItemList = new DataTable();
        string[] sItemCode;

        //  adding item code to the table

        private void chklbItemList_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            bool bItemCheck = false;
            sItemCode = chklbItemList.SelectedItem.ToString().Trim().Split(')');
            string sID = sItemCode[0];
            dtSelectItemList = DAL.fnPartmasterItemList(sID).Tables[0];
            if (dtSelectItemList.Rows.Count > 0)
            {
                foreach (DataGridViewRow dr in dgBOMList.Rows)
                {
                    if (dr.Cells["uItemCode"].Value.ToString().Trim().ToLower() == dtSelectItemList.Rows[0]["ItemCode"].ToString().Trim().ToLower())
                    {
                        MessageBox.Show("Selected Itemcode already present in the BOM item list", "Warning", 0, MessageBoxIcon.Warning);
                        bItemCheck = true;
                        break;
                    }
                }

                if (!bItemCheck)
                {

                    fCost = 0.0;
                    // Get FixedCost value
                    string fixedCostStr = dtSelectItemList.Rows[0]["FixedCost"].ToString();


                    // Validate FixedCost
                    if (string.IsNullOrWhiteSpace(fixedCostStr) || !decimal.TryParse(fixedCostStr, out decimal validatedFixedCost) || validatedFixedCost <= 0.01m)
                    {
                        MessageBox.Show("Fixed cost is not updated. Please get it done by the project managers.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return; // Prevent further execution
                    }
                    dtItemsofMachineBOM.Rows.Add(null, null, null, dtSelectItemList.Rows[0]["ItemCode"].ToString(), dtSelectItemList.Rows[0]["ItemDescription"].ToString(), "1", "0", dtSelectItemList.Rows[0]["UnitCost"].ToString(), dtSelectItemList.Rows[0]["UnitCost"].ToString(), dtSelectItemList.Rows[0]["UnitCost"].ToString(), dtSelectItemList.Rows[0]["UnitCost"].ToString());
                    dgBOMList.DataSource = dtItemsofMachineBOM;
                    sTotalAmount = 0.0;
                    //foreach (DataGridViewRow dgvr in dgBOMList.Rows)
                    //{
                    //    sTotalAmount += Convert.ToDouble(dgvr.Cells["UnitPrice"].Value) * Convert.ToDouble(dgvr.Cells["uBOMQty"].Value);
                    //}
                    //// dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value = Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value) + (Convert.ToDouble(dtSelectItemList.Rows[0]["UnitCost"].ToString()));
                    //// fnTotalAmount(Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value));
                    //fnTotalAmount(sTotalAmount);
                    //dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value = dNewTotalAmount.ToString();

                    dtProjectCheck = DAL.fnProjectBOMProdutnamenumber(dgItemOrProductList.CurrentRow.Cells["PProductCode"].Value.ToString(), cmbProjectCode.Text,
                        dgItemOrProductList.CurrentRow.Cells["ProductType"].Value.ToString(), dgItemOrProductList.CurrentRow.Cells["ProductName"].Value.ToString()).Tables[0];
                    if (dtProjectCheck.Rows.Count > 0)
                    {

                        // Get FixedCost value
                        //string fixedCostStr = dtSelectItemList.Rows[0]["FixedCost"].ToString();


                        //// Validate FixedCost
                        //if (string.IsNullOrWhiteSpace(fixedCostStr) || !decimal.TryParse(fixedCostStr, out decimal validatedFixedCost) || validatedFixedCost <= 0)
                        //{
                        //    MessageBox.Show("Fixed cost is not updated. Please get it done by the project managers.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        //    return; // Prevent further execution
                        //}

                        //MessageBox.Show("Adding Inprogress");
                        GLobalClass.iSuccess = DAL.fnAddMachineBOM(Global.uINSERT, dtProjectCheck.Rows[0]["ProjectBOMCode"].ToString(), dtProjectCheck.Rows[0]["ProductNo"].ToString(),
                            dtSelectItemList.Rows[0]["ItemCode"].ToString(), dtProjectCheck.Rows[0]["ProjectCode"].ToString(), null, null, null, null, null, null,
                            1, 1, 0, lblProjectStaus.Text, login.GetUserDetails[2], dtpCreatedDate.Text, "", Convert.ToDecimal(dtSelectItemList.Rows[0]["FixedCost"].ToString()));

                        //GLobalClass.iSuccess = DAL.fnAddProjectBOM(6, null, cmbProjectCode.Text, dtProjectCheck.Rows[0]["ProductNo"].ToString(),
                        //    dgItemOrProductList.CurrentRow.Cells["PProductCode"].Value.ToString(), Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["Quantity"].Value),
                        //    Convert.ToDouble(dtSelectItemList.Rows[0]["UnitCost"].ToString()), null, null, null, null, null, null, null, 0, null, "", "", "", 0, false);

                        dtNewGridviewItems = DAL.fnProjectBOMProdutnamenumber(dgItemOrProductList.CurrentRow.Cells["PProductCode"].Value.ToString(), cmbProjectCode.Text,
                                        dgItemOrProductList.CurrentRow.Cells["ProductType"].Value.ToString(), dgItemOrProductList.CurrentRow.Cells["ProductName"].Value.ToString()).Tables[0];
                        if (dtNewGridviewItems.Rows.Count > 0)
                        {
                            dtItemsofMachineBOM = DAL.fnMachineBOMProdutViewItems(3, dtNewGridviewItems.Rows[0]["ProductNo"].ToString(), cmbProjectCode.Text).Tables[0];

                            dtLatestCost = DAL.fnLatestCost().Tables[0];
                            foreach (DataRow rowSampleOne in dtLatestCost.Rows)
                            {
                                foreach (DataRow rowSampleTwo in dtItemsofMachineBOM.Rows)
                                {
                                    if (rowSampleTwo["ItemName"].ToString().Equals(rowSampleOne["ItemCode"].ToString()))
                                    {
                                        rowSampleTwo["LatestCost"] = Convert.ToDouble(rowSampleOne["PurchaseCost"].ToString());
                                    }
                                }
                            }
                            foreach (DataRow rowSampleTwo in dtItemsofMachineBOM.Rows)
                            {
                                if (rowSampleTwo["LatestCost"].ToString().Equals("0"))
                                {
                                    rowSampleTwo["LatestCost"] = Convert.ToDouble(rowSampleTwo["UnitCost"].ToString());
                                }
                            }
                            dtPODate = DAL.fnMachineBOMProdutViewItems(4, "", cmbProjectCode.Text).Tables[0];
                            if (dtPODate.Rows.Count > 0)
                            {
                                foreach (DataRow rowSampleOne in dtPODate.Rows)
                                {
                                    foreach (DataRow rowSampleTwo in dtItemsofMachineBOM.Rows)
                                    {
                                        if (rowSampleTwo["ItemName"].ToString().Equals(rowSampleOne["ItemCode"].ToString()))
                                        {
                                            rowSampleTwo["PODate"] = rowSampleOne["POGeneratedDate"].ToString();
                                        }
                                    }
                                }
                            }
                            sTotalAmount = 0;
                            foreach (DataRow rowSampleTwo in dtItemsofMachineBOM.Rows)
                            {
                                //rowSampleTwo["BOMAmount"] = Convert.ToDouble(rowSampleTwo["LatestCost"]) * Convert.ToDouble(rowSampleTwo["Quantity"]);
                                //sTotalAmount += Convert.ToDouble(rowSampleTwo["LatestCost"]) * Convert.ToDouble(rowSampleTwo["Quantity"]);


                                //bhavya replaced  latestcost with fixedcost
                                double fixedCost = rowSampleTwo["FixedCost"] != DBNull.Value ? Convert.ToDouble(rowSampleTwo["FixedCost"]) : 0.0;
                                double quantity = rowSampleTwo["Quantity"] != DBNull.Value ? Convert.ToDouble(rowSampleTwo["Quantity"]) : 0.0;

                                double bomAmount = fixedCost * quantity;

                                rowSampleTwo["BOMAmount"] = bomAmount;
                                sTotalAmount += bomAmount;
                            }
                            fnTotalAmount(sTotalAmount);
                            dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value = dNewTotalAmount.ToString();

                            GLobalClass.iSuccess = DAL.fnAddProjectBOM(6, null, cmbProjectCode.Text, dtProjectCheck.Rows[0]["ProductNo"].ToString(),
                            dgItemOrProductList.CurrentRow.Cells["PProductCode"].Value.ToString(), Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["Quantity"].Value),
                            Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value), null, null, null, null, null, null, null, 0, null, "", "", "", 0, false);
                            sTotalAmount = 0;
                            foreach (DataGridViewRow dgvr in dgItemOrProductList.Rows)
                            {
                                if (!string.IsNullOrEmpty(dgvr.Cells["PProductCode"].Value.ToString()))
                                {
                                    sTotalAmount += Convert.ToDouble(dgvr.Cells["UnitCost"].Value);
                                }
                            }
                            fnTotalAmount(sTotalAmount);
                            string text = string.Format(india, "{0:c}", dNewTotalAmount); // ₹ 3,20,000 
                            txtTotalCost.Text = text;
                            if (dtItemsofMachineBOM.Rows.Count > 0)
                            {
                                dgBOMList.AutoGenerateColumns = false;

                                dgBOMList.DataSource = dtItemsofMachineBOM;

                                int nRowIndex = dgBOMList.Rows.Count;
                                if (nRowIndex > 0)
                                    dgBOMList.CurrentCell = dgBOMList.Rows[nRowIndex - 1].Cells[1];

                                gbSearchOptions.Enabled = true;
                                ItemDatagridviewcolor();
                                fnProdctCosttotal();
                                chkSelectItem.Enabled = true;
                            }
                        }
                    }
                }
            }
        }
        string[] sNamee;
        string sParentName;
        private const int _blinkFrequency = 250;
        private const int _maxNumberOfBlinks = 1000;
        private int _blinkCount = 0;
        string[] sName;
        DataTable dtVersion = new DataTable();
        private void tvProduct_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            sName = e.Node.Name.Split(')');
            tvProduct.SelectedNode = e.Node;
            tvProduct.LabelEdit = false;
            if (e.Node.Parent != null && e.Node != null && e.Node.Name != "All Product" && e.Node.StateImageIndex == 1)
            {
                dtProductCode = DAL.fnGetSalesProductTreeDetails(sName[0]).Tables[0];
                if (dtProductCode.Rows.Count > 0)
                {
                    dtVersion = DAL.fnFullVersionList(sName[0]).Tables[0];
                    cmbVersion.Items.Clear();
                    foreach (DataRow DR in dtVersion.Rows)
                    {
                        if (!cmbVersion.Items.Contains(DR["Version"].ToString()))
                            cmbVersion.Items.Add(DR["Version"].ToString());
                    }
                    if (cmbVersion.Items.Count == 1)
                    {
                        timer1.Interval = _blinkFrequency;
                        lblVersion.Visible = true;
                        cmbVersion.Visible = true;
                        timer1.Start();
                        cmbVersion.SelectedIndex = 0;
                    }
                    else
                    {
                        timer1.Interval = _blinkFrequency;
                        lblVersion.Visible = true;
                        cmbVersion.Visible = true;
                        timer1.Start();
                        cmbVersion.DroppedDown = true;
                    }
                    dtProductCode.Clear();
                }
            }
            else
            {
                lblVersion.Visible = false;
                cmbVersion.Visible = false;
                timer1.Stop();
            }
        }
        private List<TreeNode> CurrentNodeMatches = new List<TreeNode>();

        private int LastNodeIndex = 0;

        private string LastSearchText;

        private void SearchNodes(string SearchText, TreeNode StartNode)
        {
            while (StartNode != null)
            {
                if (StartNode.Text.ToLower().Contains(SearchText.ToLower()))
                {
                    CurrentNodeMatches.Add(StartNode);
                };
                if (StartNode.Nodes.Count != 0)
                {
                    SearchNodes(SearchText, StartNode.Nodes[0]);//Recursive Search 
                };
                StartNode = StartNode.NextNode;
            };
        }
        DataTable dtProductCodeSearch = new DataTable();
        private void btnsearchtree_Click(object sender, EventArgs e)
        {
            string searchText = txtsearchtree.Text;
            if (String.IsNullOrEmpty(searchText))
            {
                return;
            };
            if (LastSearchText != searchText)
            {
                CurrentNodeMatches.Clear();

                if (chkProductCode.CheckState == CheckState.Checked)
                {
                    dtProductCodeSearch = DAL.fnSalesProductCodeName(searchText).Tables[0];
                    LastSearchText = searchText;
                    if (dtProductCodeSearch.Rows.Count > 0)
                    {
                        searchText = dtProductCodeSearch.Rows[0]["Name"].ToString().Trim();
                        LastNodeIndex = 0;
                        SearchNodes(searchText, tvProduct.Nodes[0]);
                    }
                }
                else
                {
                    LastSearchText = searchText;
                    LastNodeIndex = 0;
                    SearchNodes(searchText, tvProduct.Nodes[0]);
                }
            }

            if (LastNodeIndex >= 0 && CurrentNodeMatches.Count > 0 && LastNodeIndex < CurrentNodeMatches.Count)
            {
                TreeNode selectedNode = CurrentNodeMatches[LastNodeIndex];
                LastNodeIndex++;
                this.tvProduct.SelectedNode = selectedNode;
                this.tvProduct.SelectedNode.Expand();
                this.tvProduct.Select();
            }
        }

        private void cleartreeview_Click(object sender, EventArgs e)
        {
            txtsearchtree.ResetText();
            LastSearchText = "";
            tvProduct.CollapseAll();
        }

        private void txtsearchtree_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnsearchtree_Click(sender, e);
            }
        }

        private void tvProduct_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnsearchtree_Click(sender, e);
            }
        }
        double oldvalue;
        private void dgItemOrProductList_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {

        }

        private void dgItemOrProductList_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            DataTable GetERPProjectBOMLockDetails = DAL.fnGetERPProjectBOMLock(cmbProjectCode.Text).Tables[0];
            bool AllowBOM = true;
            if (GetERPProjectBOMLockDetails.Rows.Count > 0)
            {
                if (GetERPProjectBOMLockDetails.Rows[0]["LockNow"].ToString().ToLower() == "true")
                {
                    // MessageBox.Show($"The selected project currently LOCK...!");
                    AllowBOM = false;
                }
                else
                {
                    AllowBOM = true;
                }
                if (GetERPProjectBOMLockDetails.Rows[0]["LockNow"].ToString().ToLower() == "false")
                {
                    try
                    {
                        var s = GetERPProjectBOMLockDetails.Rows[0]["BOMClosingDate"]?.ToString();
                        var bomClosingDate = DateTime.ParseExact(s, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                        int cmp = DateTime.Compare(bomClosingDate.Date, DateTime.Today);
                        // MessageBox.Show(cmp.ToString());
                        if (cmp == 1)
                        {
                            // MessageBox.Show($"The selected project currently Open till{s}..!");
                            AllowBOM = true;
                        }
                        else
                        {
                            AllowBOM = false;
                            // MessageBox.Show($"The selected project currently LOCK {s}..!");
                        }
                    }
                    catch
                    {
                    }
                }

            }

            if (AllowBOM)
            {
                try
                {
                    e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress1);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
                }
            }
        }
        private void Control_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (dgBOMList.CurrentCell.OwningColumn.Name == "uBOMQty")
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
                {
                    e.Handled = true;
                }
                if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
                {
                    e.Handled = true;
                }
            }
        }
        private void Control_KeyPress1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) //&& e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }
        //shreeshail is added belove code
        private void dgBOMList_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                // Assuming "BOMQuantity" and "AvailableQty" are the names of the columns in your DataGridView
                DataGridViewRow row = dgBOMList.Rows[e.RowIndex];
                DataGridViewColumn column = dgBOMList.Columns[e.ColumnIndex];

                if (column.Name == "uBOMQty" || column.Name == "AvailableQty")
                {
                    int bomQuantity = Convert.ToInt32(row.Cells["uBOMQty"].Value);
                    int availableQty = Convert.ToInt32(row.Cells["AvailableQty"].Value);

                    // Compare BOM quantity and available quantity
                    if (bomQuantity < availableQty)
                    {
                        // Less than BOM quantity, compare to available - Set color
                        row.Cells[e.ColumnIndex].Style.BackColor = Color.Yellow;
                    }
                    else if (bomQuantity == availableQty)
                    {
                        // Equal to BOM quantity, compare to available - Set color
                        row.Cells[e.ColumnIndex].Style.BackColor = Color.Green;
                    }
                    else
                    {
                        // More than BOM quantity, compare to available - Set color
                        row.Cells[e.ColumnIndex].Style.BackColor = Color.Red;
                    }
                }
            }
        }

        //shreeshail is added above code

        //private void dgBOMList_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        //{
        //    if (dgBOMList.CurrentCell.OwningColumn.Name == "uBOMQty") //|| dgbomlist.CurrentCell.OwningColumn.Name == "Amount" || dgbomlist.CurrentCell.OwningColumn.Name == "ReqQty")
        //    {
        //        oldvalue = Convert.ToDouble(dgBOMList.CurrentCell.Value);
        //    }

        //}


        private void dgBOMList_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            DataTable GetERPProjectBOMLockDetails = DAL.fnGetERPProjectBOMLock(cmbProjectCode.Text).Tables[0];
            bool AllowBOM = true;
            if (GetERPProjectBOMLockDetails.Rows.Count > 0)
            {
                if (GetERPProjectBOMLockDetails.Rows[0]["LockNow"].ToString().ToLower() == "true")
                {
                    // MessageBox.Show($"The selected project currently LOCK...!");
                    AllowBOM = false;
                }
                else
                {
                    AllowBOM = true;
                }
                if (GetERPProjectBOMLockDetails.Rows[0]["LockNow"].ToString().ToLower() == "false")
                {
                    try
                    {
                        var s = GetERPProjectBOMLockDetails.Rows[0]["BOMClosingDate"]?.ToString();
                        var bomClosingDate = DateTime.ParseExact(s, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                        int cmp = DateTime.Compare(bomClosingDate.Date, DateTime.Today);
                        // MessageBox.Show(cmp.ToString());
                        if (cmp == 1)
                        {
                            // MessageBox.Show($"The selected project currently Open till{s}..!");
                            AllowBOM = true;
                        }
                        else
                        {
                            AllowBOM = false;
                            // MessageBox.Show($"The selected project currently LOCK {s}..!");
                        }
                    }
                    catch
                    {
                    }
                }

            }

            if (AllowBOM)
            {
                // Get the column name being edited
                string columnName = dgBOMList.Columns[e.ColumnIndex].Name;

                // Allow everyone to edit "uBOMQty" and store its old value
                if (columnName == "uBOMQty")
                {
                    oldvalue = Convert.ToDouble(dgBOMList.CurrentCell.Value);
                }

                // If column is "FixedCost"
                if (columnName == "FixedCost")
                {
                    // Check if user is "vivek g"
                    if (login.GetUserDetails[2].ToLower() == "vivek g" || login.GetUserDetails[2].ToLower() == "ravi" || login.GetUserDetails[2].ToLower() == "thilak kumar" || login.GetUserDetails[2].ToLower() == "kumar ravi" || login.GetUserDetails[2].ToLower() == "santhoshdj" || login.GetUserDetails[2].ToLower() == "veena" || login.GetUserDetails[2].ToLower() == "pavana" || login.GetUserDetails[2].ToLower() == "hemanth reddy" || login.GetUserDetails[2].ToLower() == "vishal raina")
                    {
                        // Store old value
                        oldvalue = Convert.ToDouble(dgBOMList.CurrentCell.Value);
                    }
                    else
                    {
                        // Block editing for other users
                        e.Cancel = true;

                        // Optional: Inform the user
                        MessageBox.Show("Only authorized persons are allowed to edit the 'FixedCost'",
                                        "Access Denied",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Warning);
                    }
                }
            }
        }


        private void dgBOMList_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            DataTable GetERPProjectBOMLockDetails = DAL.fnGetERPProjectBOMLock(cmbProjectCode.Text).Tables[0];
            bool AllowBOM = true;
            if (GetERPProjectBOMLockDetails.Rows.Count > 0)
            {
                if (GetERPProjectBOMLockDetails.Rows[0]["LockNow"].ToString().ToLower() == "true")
                {
                    // MessageBox.Show($"The selected project currently LOCK...!");
                    AllowBOM = false;
                }
                else
                {
                    AllowBOM = true;
                }
                if (GetERPProjectBOMLockDetails.Rows[0]["LockNow"].ToString().ToLower() == "false")
                {
                    try
                    {
                        var s = GetERPProjectBOMLockDetails.Rows[0]["BOMClosingDate"]?.ToString();
                        var bomClosingDate = DateTime.ParseExact(s, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                        int cmp = DateTime.Compare(bomClosingDate.Date, DateTime.Today);
                        // MessageBox.Show(cmp.ToString());
                        if (cmp == 1)
                        {
                            // MessageBox.Show($"The selected project currently Open till{s}..!");
                            AllowBOM = true;
                        }
                        else
                        {
                            AllowBOM = false;
                            // MessageBox.Show($"The selected project currently LOCK {s}..!");
                        }
                    }
                    catch
                    {
                    }
                }

            }

            if (AllowBOM)
            {
                try
                {
                    e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
                }
            }
        }

        #region PO Item Color
        private void ItemDatagridviewcolor()
        {
            foreach (DataGridViewRow dgr in dgBOMList.Rows)
            {
                if ((dgr.Cells[9].Value.ToString()) == "Deactive")
                {
                    dgr.DefaultCellStyle.BackColor = Color.Red;
                }
            }
        }
        #endregion

        DataTable dtLatestCost = new DataTable();
        DataTable dtPODate = new DataTable();
        private void dgItemOrProductList_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            if (dgItemOrProductList.CurrentRow.Cells["ProductType"].Value.ToString() == "Kanban Items")
            {
                // MessageBox.Show(dgItemOrProductList.CurrentRow.Cells["ProductType"].Value.ToString());
                dgBOMList.DataSource = null;
                btnPrintBOM.Enabled = true;
                DataTable kanbanItemList = DAL.getKanbanItenList(cmbProjectCode.Text).Tables[0];
                // MessageBox.Show(kanbanItemList.Rows.Count.ToString());
                dgBOMList.AutoGenerateColumns = false;
                dgBOMList.DataSource = kanbanItemList;
                return;
            }


            if (bJobView)
            {
                btnJobItemsView_Click(sender, e);
            }

            dgBOMList.DataSource = null;
            btnPrintBOM.Enabled = true;
            txtItemSearch.ResetText();
            if (!string.IsNullOrEmpty(dgItemOrProductList.CurrentRow.Cells["ProductType"].Value.ToString()))
            {
                cmbProductCategory.SelectedItem = dgItemOrProductList.CurrentRow.Cells["ProductType"].Value.ToString();
            }
            if (!string.IsNullOrEmpty(dgItemOrProductList.CurrentRow.Cells["PProductCode"].Value.ToString()))
            {
                if (e.ColumnIndex == 11 || e.ColumnIndex == 12)
                {
                    oDateTimePicker.Visible = false;
                    oDateTimePicker = new DateTimePicker();
                    dgItemOrProductList.Controls.Add(oDateTimePicker);
                    oDateTimePicker.Format = DateTimePickerFormat.Custom;
                    oDateTimePicker.CustomFormat = "dd-MM-yyyy";
                    Rectangle oRectangle = dgItemOrProductList.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, true);
                    oDateTimePicker.Size = new Size(oRectangle.Width, oRectangle.Height);
                    oDateTimePicker.Location = new Point(oRectangle.X, oRectangle.Y);
                    oDateTimePicker.CloseUp += new EventHandler(oDateTimePicker_CloseUp);
                    oDateTimePicker.TextChanged += new EventHandler(oDateTimePicker_TabIndexChanged);
                    oDateTimePicker.Visible = true;
                }
                else
                {
                    oDateTimePicker.Visible = false;
                }

                dtNewGridviewItems = DAL.fnProjectBOMProdutnamenumber(dgItemOrProductList.CurrentRow.Cells["PProductCode"].Value.ToString(), cmbProjectCode.Text,
                                        dgItemOrProductList.CurrentRow.Cells["ProductType"].Value.ToString(), dgItemOrProductList.CurrentRow.Cells["ProductName"].Value.ToString()).Tables[0];

                if (dtNewGridviewItems.Rows.Count > 0)
                {
                    sProductName = dtNewGridviewItems.Rows[0]["ProductName"].ToString();
                    dtItemsofMachineBOM = DAL.fnMachineBOMProdutViewItems(2, dtNewGridviewItems.Rows[0]["ProductNo"].ToString(), cmbProjectCode.Text).Tables[0];


                    //testing code







                    dtLatestCost = DAL.fnLatestCost().Tables[0];


                    foreach (DataRow rowSampleOne in dtLatestCost.Rows)
                    {
                        foreach (DataRow rowSampleTwo in dtItemsofMachineBOM.Rows)
                        {
                            if (rowSampleTwo["ItemName"].ToString().Equals(rowSampleOne["ItemCode"].ToString()))
                            {
                                rowSampleTwo["LatestCost"] = Convert.ToDouble(rowSampleOne["PurchaseCost"].ToString());
                            }
                        }
                    }
                    foreach (DataRow rowSampleTwo in dtItemsofMachineBOM.Rows)
                    {
                        if (rowSampleTwo["LatestCost"].ToString().Equals("0"))
                        {
                            rowSampleTwo["LatestCost"] = Convert.ToDouble(rowSampleTwo["UnitCost"].ToString());
                        }

                    }
                    dtPODate = DAL.fnMachineBOMProdutViewItems(4, "", cmbProjectCode.Text).Tables[0];
                    if (dtPODate.Rows.Count > 0)
                    {
                        foreach (DataRow rowSampleOne in dtPODate.Rows)
                        {
                            foreach (DataRow rowSampleTwo in dtItemsofMachineBOM.Rows)
                            {
                                if (rowSampleTwo["ItemName"].ToString().Equals(rowSampleOne["ItemCode"].ToString()))
                                {
                                    rowSampleTwo["PODate"] = rowSampleOne["POGeneratedDate"].ToString();
                                }
                            }
                        }
                    }
                    foreach (DataRow rowSampleTwo in dtItemsofMachineBOM.Rows)
                    {

                        //  rowSampleTwo["BOMAmount"] = Convert.ToDouble(rowSampleTwo["LatestCost"]) * Convert.ToDouble(rowSampleTwo["Quantity"]);
                        //bhavya replaced the latest cost with fixedcost
                        double fixedCost = rowSampleTwo["FixedCost"] != DBNull.Value ? Convert.ToDouble(rowSampleTwo["FixedCost"]) : 0.0;
                        double quantity = rowSampleTwo["Quantity"] != DBNull.Value ? Convert.ToDouble(rowSampleTwo["Quantity"]) : 0.0;

                        rowSampleTwo["BOMAmount"] = fixedCost * quantity;

                    }

                    //shreeshail is added code Available Quantity column

                    //-----------------------------------------shreeshail is added code below------------------------------
                    if (dtItemsofMachineBOM.Rows.Count > 0)
                    {
                        // Assuming dtItemsofMachineBOM is already populated with data
                        dgBOMList.AutoGenerateColumns = false;
                        dgBOMList.DataSource = dtItemsofMachineBOM;

                        // Add AvailableQty column if not already present
                        if (!dgBOMList.Columns.Contains("AvailableQty"))
                        {
                            dgBOMList.Columns.Add("AvailableQty", "AvailableQty");// sirst one table column name,second one is field name

                        }

                        // Bind AvailableQty data from DataTable to DataGridView column
                        for (int i = 0; i < dtItemsofMachineBOM.Rows.Count; i++)
                        {
                            dgBOMList.Rows[i].Cells["AvailableQty"].Value = dtItemsofMachineBOM.Rows[i]["AvailableQty"];

                            // Add color coding based on conditions
                            int availableQty = Convert.ToInt32(dtItemsofMachineBOM.Rows[i]["AvailableQty"]);
                            int bomQty = Convert.ToInt32(dtItemsofMachineBOM.Rows[i]["Quantity"]);

                            if (availableQty < bomQty)
                            {
                                dgBOMList.Rows[i].Cells["AvailableQty"].Style.BackColor = Color.Red; // Less than BOM quantity
                            }
                            else if (availableQty == bomQty)
                            {
                                dgBOMList.Rows[i].Cells["AvailableQty"].Style.BackColor = Color.Yellow; // Equal to BOM quantity
                            }
                            else
                            {
                                dgBOMList.Rows[i].Cells["AvailableQty"].Style.BackColor = Color.LightGreen; // More than BOM quantity
                            }
                        }
                        // Decrease cell size
                        dgBOMList.Columns["AvailableQty"].Width = 10; // Adjust the width as per your requirement

                        // Decrease font size within the cells
                        dgBOMList.Columns["AvailableQty"].DefaultCellStyle.Font = new Font("Arial", 8); // Adjust the font size as per your requirement
                        dgBOMList.Columns["AvailableQty"].ReadOnly = true;
                    }

                    //shreeshail is added above code
                    //-------------------------------------shreeshail is addedd------------------------------------------

                    if (dtItemsofMachineBOM.Rows.Count > 0)
                    {
                        dgBOMList.AutoGenerateColumns = false;
                        // rk command 
                        dgBOMList.DataSource = dtItemsofMachineBOM;

                        int nRowIndex = dgBOMList.Rows.Count;
                        if (nRowIndex > 0)
                            dgBOMList.CurrentCell = dgBOMList.Rows[nRowIndex - 1].Cells[1];

                        gbSearchOptions.Enabled = true;
                        ItemDatagridviewcolor();
                        fnProdctCosttotal();
                        chkSelectItem.Enabled = true;
                    }
                }
                else
                {
                    dtNewGridviewItems = DAL.fnProductBOMViewList(dgItemOrProductList.CurrentRow.Cells["NodeId"].Value.ToString(), dgItemOrProductList.CurrentRow.Cells["Version"].Value.ToString()).Tables[0];
                    dgBOMList.AutoGenerateColumns = false;
                    dgBOMList.ReadOnly = true;
                    dgBOMList.Columns[3].ReadOnly = true;
                    dgBOMList.DataSource = dtNewGridviewItems;
                    int nRowIndex = dgBOMList.Rows.Count;
                    if (nRowIndex > 0)
                        dgBOMList.CurrentCell = dgBOMList.Rows[nRowIndex - 1].Cells[1];
                }
            }
            else
            {
                oDateTimePicker.Visible = false;
                int iRow = 0;
                int i = Convert.ToInt32(dgItemOrProductList.CurrentRow.Cells["SLNO"].Value);
                foreach (DataGridViewRow dgr in dgItemOrProductList.Rows)
                {
                    if (dgr.Cells["PProductCode"].Value.ToString() == "" || (Convert.ToDouble(dgr.Cells["SLNO"].Value.ToString()) > i && Convert.ToDouble(dgr.Cells["SLNO"].Value.ToString()) < (i + 1)))
                    {
                        dgItemOrProductList.Rows[iRow].Visible = true;
                    }
                    else
                    {
                        dgItemOrProductList.Rows[iRow].Visible = false;
                    }

                    iRow++;
                }

                chkSelectItem.Checked = false;
                chkSelectItem.Enabled = false;
                lblProductCost.Text = "0";
                dgBOMList.DataSource = null;
            }

        }
        private double GetDoubleFromCell(object value)
        {
            if (value == DBNull.Value || value == null)
                return 0;
            return Convert.ToDouble(value);
        }
        BindingSource bs = new BindingSource();

        private void fnProdctCosttotal()
        {
            sTotalAmount = 0;
            foreach (DataGridViewRow dgvr in dgBOMList.Rows)
            {
                // sTotalAmount += Convert.ToDouble(dgvr.Cells["LatestCost"].Value) * Convert.ToDouble(dgvr.Cells["uBOMQty"].Value);
                sTotalAmount += GetDoubleFromCell(dgvr.Cells["FixedCost"].Value) * GetDoubleFromCell(dgvr.Cells["uBOMQty"].Value);

            }
            fnTotalAmount(sTotalAmount);
            string text = string.Format(india, "{0:c}", dNewTotalAmount); // ₹ 3,20,000 
            lblProductCost.Text = text;
        }

        private void btnProjectView_Click(object sender, EventArgs e)
        {
            Indent.frmProjectselect projectsearch = new Indent.frmProjectselect();
            projectsearch.fnProjectBOM = "1";
            projectsearch.ShowDialog();
            if (fnBOMProjectcode != null)
            {
                cmbProjectCode.Text = sBOMProjectCode;
            }
        }
        BindingSource bsIteSearch = new BindingSource();
        DataTable dtClone = new DataTable();
        private void txtItemSearch_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtItemSearch.TextLength > 2)
            {
                if (dtItemsofMachineBOM.Rows.Count > 0)
                {
                    dtClone = dtItemsofMachineBOM.Copy();
                    bsIteSearch.DataSource = dtClone;

                    bsIteSearch.Filter = string.Format("ItemName LIKE '%{0}%' OR ItemDescription LIKE '%{0}%' or ProductType LIKE '%{0}%'", txtItemSearch.Text);
                    dgBOMList.DataSource = bsIteSearch;
                    fnProdctCosttotal();
                }
            }
            else
            {
                bsIteSearch.RemoveFilter();
                fnProdctCosttotal();
            }
        }

        private void tvProduct_AfterLabelEdit(object sender, NodeLabelEditEventArgs e)
        {
            tvProduct.LabelEdit = false;
        }
        #region Project BOM Report
        private void btnPrintprojectbom_Click(object sender, EventArgs e)
        {
            int iRowIndex = 1;
            int k = 1;
            string ExcelFolderPath;
            string FileFullPath;
            EXCEL.Workbook NewWorkBook;
            EXCEL.Worksheet NewWorkSheet;
            EXCEL.Application ExcelApp;
            EXCEL.Range CELLS, cell1, cell2;
            object misValue;
            Cursor.Current = Cursors.WaitCursor;
            if (dgItemOrProductList.Rows.Count > 0)
            {
                ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\Project BOM Cost\";
                FileFullPath = ExcelFolderPath + cmbProjectCode.Text;
                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);

                ExcelApp = new EXCEL.Application();
                misValue = System.Reflection.Missing.Value;
                try
                {
                    if (ExcelApp == null)
                        MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                    NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                    NewWorkBook.SaveAs(FileFullPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                    Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                    if (NewWorkSheet == null)
                        MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                    else
                        NewWorkSheet.Name = "Project GIN";
                    // Select the Excel cells, in the range c1 to c7 in the worksheet for cell access check.
                    EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                    if (RANGE == null)
                        MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");

                    CELLS = NewWorkSheet.Cells;
                    NewWorkSheet.Cells[iRowIndex, 1] = "Project BOM REPORT";
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 13);
                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "Project Code:";
                    NewWorkSheet.Cells[iRowIndex, 2] = cmbProjectCode.Text;
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 2, 3);
                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "Project Name:";
                    NewWorkSheet.Cells[iRowIndex, 2] = txtProjectName.Text;
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 2, 3);
                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "Project Cost:";
                    NewWorkSheet.Cells[iRowIndex, 2] = txtTotalCost.Text;
                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "Issued Cost:";
                    NewWorkSheet.Cells[iRowIndex, 2] = lblIssuedCost.Text;
                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "Job Issued Cost:";
                    NewWorkSheet.Cells[iRowIndex, 2] = lblJobissuedCost.Text;
                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "Progress:";
                    NewWorkSheet.Cells[iRowIndex, 2] = lblperc.Text;
                    iRowIndex++;
                    NewWorkSheet.Range["A1:B1"].Cells.Font.Size = 16;
                    NewWorkSheet.Range["A1:B1"].Cells.Font.Bold = true;
                    NewWorkSheet.Range["A2:B7"].Cells.Font.Size = 11;
                    NewWorkSheet.Range["A2:B7"].Cells.Font.Bold = true;
                    NewWorkSheet.Range["A9:M9"].Cells.Font.Size = 11;
                    NewWorkSheet.Range["A9:M9"].Cells.Font.Bold = true;
                    NewWorkSheet.Range["A9:M9"].Cells.Font.Color = Color.Blue;
                    iRowIndex++;

                    foreach (DataGridViewRow DR in dgItemOrProductList.Rows)
                    {
                        NewWorkSheet.Rows.AutoFit();
                        k = 1;
                        for (int j = 0; j < dgItemOrProductList.Columns.Count; j++) // shreeshail dgItemOrProductList.Columns.Count-1 remove -1
                        {
                            NewWorkSheet.Columns.AutoFit();

                            if (dgItemOrProductList.Rows.IndexOf(DR) == 0)
                            {
                                cell1 = NewWorkSheet.Cells[iRowIndex, 1];
                                cell2 = NewWorkSheet.Cells[(iRowIndex + dgItemOrProductList.Rows.Count), (k)];

                                CELLS = (EXCEL.Range)NewWorkSheet.get_Range(cell1, cell2);
                                if (j == 0)
                                {
                                    NewWorkSheet.Cells[iRowIndex, k] = (dgItemOrProductList.Columns[j].Name.ToString());
                                    NewWorkSheet.Range["A" + iRowIndex + ":A" + k + ""].Cells[iRowIndex, k].HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                                    ((Microsoft.Office.Interop.Excel.Range)NewWorkSheet.Rows[iRowIndex, Type.Missing]).Font.Bold = true;
                                    NewWorkSheet.Cells[iRowIndex + 1, k] = DR.Cells[j].Value.ToString();
                                    NewWorkSheet.Range["A" + iRowIndex + 1 + ":A" + k + ""].Cells[iRowIndex + 1, k].HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                                }
                                else
                                {
                                    NewWorkSheet.Cells[iRowIndex, k] = (dgItemOrProductList.Columns[j].Name.ToString());
                                    NewWorkSheet.Cells[iRowIndex + 1, k] = DR.Cells[j].Value.ToString();
                                }
                            }
                            else
                                if (j == 0)
                            {
                                NewWorkSheet.Range["A" + iRowIndex + 1 + ":A" + k + ""].Cells[iRowIndex + 1, k].HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                                NewWorkSheet.Cells[iRowIndex + 1, k] = DR.Cells[j].Value.ToString();
                            }
                            else
                            {
                                NewWorkSheet.Cells[iRowIndex + 1, k] = DR.Cells[j].Value.ToString();
                            }
                            k++;

                            cell1 = NewWorkSheet.Cells[iRowIndex, 1];
                            cell2 = NewWorkSheet.Cells[(iRowIndex), 13];
                            CELLS = (EXCEL.Range)NewWorkSheet.get_Range(cell1, cell2);
                            CELLS.Borders.Color = System.Drawing.Color.Black;
                            CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);

                        }
                        iRowIndex++;
                    }
                    cell1 = NewWorkSheet.Cells[iRowIndex, 1];
                    cell2 = NewWorkSheet.Cells[(iRowIndex), 12];
                    CELLS = (EXCEL.Range)NewWorkSheet.get_Range(cell1, cell2);
                    CELLS.Borders.Color = System.Drawing.Color.Black;
                    CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);

                    NewWorkSheet.Cells[2, 1].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignRight;
                    NewWorkSheet.Cells[3, 1].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignRight;
                    NewWorkSheet.Cells[4, 1].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignRight;
                    NewWorkSheet.Cells[5, 1].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignRight;
                    NewWorkSheet.Cells[6, 1].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignRight;
                    NewWorkSheet.Cells[7, 1].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignRight;
                    NewWorkSheet.Cells[2, 2].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    NewWorkSheet.Cells[3, 2].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    NewWorkSheet.Cells[4, 2].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    NewWorkSheet.Cells[5, 2].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    NewWorkSheet.Cells[6, 2].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    NewWorkSheet.Cells[7, 2].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    Microsoft.Office.Interop.Excel.Range range = NewWorkSheet.get_Range("D6", "D999");
                    range.NumberFormat = "0";
                    Microsoft.Office.Interop.Excel.Range range1 = NewWorkSheet.get_Range("F6", "G999");
                    range1.NumberFormat = "0.00";
                    NewWorkSheet.get_Range("C1", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
                    NewWorkSheet.get_Range("C1", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                    NewWorkSheet.Columns.AutoFit(); NewWorkSheet.Rows.AutoFit();
                    NewWorkSheet.Columns[3].ColumnWidth = 45;
                    NewWorkSheet.Columns[3].WrapText = true;
                    NewWorkSheet.Columns[2].ColumnWidth = 45;
                    NewWorkSheet.Columns[2].WrapText = true;
                    NewWorkSheet.PageSetup.Zoom = false;
                    NewWorkSheet.PageSetup.PrintArea = "A1 : H" + iRowIndex + "";
                    NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                    NewWorkSheet.Rows.RowHeight = "18";
                    NewWorkSheet.PageSetup.PrintNotes = true;
                    NewWorkSheet.PageSetup.Zoom = 60;
                    NewWorkSheet.PageSetup.FitToPagesTall = 1;
                    NewWorkSheet.PageSetup.FitToPagesWide = 1;
                    NewWorkSheet.PageSetup.LeftMargin = 0;
                    NewWorkSheet.PageSetup.RightMargin = 0;
                    NewWorkSheet.PageSetup.TopMargin = 0.75;
                    NewWorkSheet.PageSetup.BottomMargin = 0.75;
                    NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                    NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                    //EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[1, 4];
                    //System.Drawing.Image oImage = System.Drawing.Image.FromFile(_stLOGO);
                    //System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    //NewWorkSheet.Paste(oRange, _stLOGO);
                    NewWorkBook.Save();
                    NewWorkBook.Close(true, misValue, misValue);
                    ExcelApp.Quit();
                    releaseObject(NewWorkSheet);
                    releaseObject(NewWorkBook);
                    releaseObject(ExcelApp);

                    if (Directory.Exists(ExcelFolderPath))
                    {
                        Process.Start(ExcelFolderPath);
                    }
                    Cursor.Current = Cursors.Default;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                    {
                        GetProcess.Kill();
                    }
                }
            }
            else
                MessageBox.Show("No Project BOM Items to Print", "Error", 0, MessageBoxIcon.Question);

        }
        #endregion
        bool bJobView = false;
        private void btnJobItemsView_Click(object sender, EventArgs e)
        {
            if (!bJobView)
            {
                dgvJobIssuedList.Visible = true;
                bJobView = true;
                btnJobItemsView.Text = "Hide Job Issued Items";
            }
            else
            {
                dgvJobIssuedList.Visible = false;
                bJobView = false;
                btnJobItemsView.Text = "View Job Issued Items";
            }
        }

        private void chkItemCode_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemCode.CheckState == CheckState.Checked)
            {
                chkItemDesc.Checked = false;
            }
        }

        private void chkItemDesc_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemDesc.CheckState == CheckState.Checked)
            {
                chkItemCode.Checked = false;
            }
        }
        List<string> lProducts = new List<string>();
        private void cmbVersion_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (dgItemOrProductList.Rows.Count > 0 && cmbProductCategory.SelectedIndex >= 0)
            {
                fnAddProducttoDataGridview(false, true);
            }
            else
            {
                MessageBox.Show("Please select the product category", "Information", 0, MessageBoxIcon.Warning);
                cmbProductCategory.DroppedDown = true;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblVersion.ForeColor = Color.Red;
            lblVersion.Visible = !lblVersion.Visible;
            _blinkCount++;
            if (_blinkCount == _maxNumberOfBlinks * 2)
            {
                timer1.Stop();
                lblVersion.Visible = true;
            }
        }

        private void txtItemCode_MouseClick(object sender, MouseEventArgs e)
        {
            if (dtItemList.Rows.Count == 0)
            {
                dtItemList = DAL.fnItemList(null).Tables[0];
            }
        }

        DataTable dtPrintBOM = new DataTable();
        private void btnPrintBOM_Click(object sender, EventArgs e)
        {

            int iRowIndex = 1;
            int k = 1;
            string ExcelFolderPath;
            string FileFullPath;
            EXCEL.Workbook NewWorkBook;
            EXCEL.Worksheet NewWorkSheet;
            EXCEL.Application ExcelApp;
            EXCEL.Range CELLS, cell1, cell2;
            object misValue;
            Cursor.Current = Cursors.WaitCursor;
            if (dgBOMList.Rows.Count > 0)
            {
                btnPrintBOM.Enabled = false;


                bs.DataSource = dgBOMList.DataSource;
                dtPrintBOM = (DataTable)(bs.DataSource);
                dtPrintBOM.Columns.RemoveAt(0);
                dtPrintBOM.Columns.RemoveAt(0);
                dtPrintBOM.Columns.RemoveAt(0);
                DialogResult DR = MessageBox.Show("Do you want to include price for selected BOM  '" + dgItemOrProductList.CurrentRow.Cells["ProductName"].Value.ToString() + "'", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DR == DialogResult.Yes)
                {
                    //if (chkIncludePrice.CheckState == CheckState.Unchecked)
                    // {
                    dtPrintBOM.Columns.RemoveAt(8);
                    dtPrintBOM.Columns.RemoveAt(8);
                    dtPrintBOM.Columns.RemoveAt(8);
                    dtPrintBOM.Columns.RemoveAt(8);

                    dtPrintBOM.Columns.RemoveAt(8);

                    //dtPrintBOM.Columns.RemoveAt(9);
                    //dtPrintBOM.Columns.RemoveAt(9);
                    //dtPrintBOM.Columns.RemoveAt(9);
                    //dtPrintBOM.Columns.RemoveAt(9);

                    //dtPrintBOM.Columns.RemoveAt(9);
                }
                else
                {
                    dtPrintBOM.Columns.RemoveAt(5);
                    dtPrintBOM.Columns.RemoveAt(5);
                    dtPrintBOM.Columns.RemoveAt(5);
                    dtPrintBOM.Columns.RemoveAt(5);

                    dtPrintBOM.Columns.RemoveAt(6);
                    dtPrintBOM.Columns.RemoveAt(6);

                }
                //ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\Product BOM\";
                string userRoot = System.Environment.GetEnvironmentVariable("USERPROFILE");
                // Now let's get C:\Users\Username\Downloads:
                string downloadFolder = Path.Combine(userRoot, "Downloads");
                ExcelFolderPath = downloadFolder + @"\Product BOM\";
                FileFullPath = ExcelFolderPath + "" + " For " + cmbProjectCode.Text + DateTime.Now.ToString(" hh-mm-ss");// lblbomitemlist.Text
                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);

                ExcelApp = new EXCEL.Application();
                misValue = System.Reflection.Missing.Value;
                try
                {
                    if (ExcelApp == null)
                        MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                    NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                    NewWorkBook.SaveAs(FileFullPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                    Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                    if (NewWorkSheet == null)
                        MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                    else
                        NewWorkSheet.Name = "Project GIN";
                    // Select the Excel cells, in the range c1 to c7 in the worksheet for cell access check.
                    EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                    if (RANGE == null)
                        MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");

                    CELLS = NewWorkSheet.Cells;
                    NewWorkSheet.Cells[iRowIndex, 1] = "Product BOM ";
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "Project Code:";
                    NewWorkSheet.Cells[iRowIndex, 2] = cmbProjectCode.Text;
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 2, 3);
                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "Project Name:";
                    NewWorkSheet.Cells[iRowIndex, 2] = txtProjectName.Text;
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 2, 3);
                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "Product Code:";
                    NewWorkSheet.Cells[iRowIndex, 2] = dgItemOrProductList.CurrentRow.Cells["PProductCode"].Value.ToString();
                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "Product Name:";
                    NewWorkSheet.Cells[iRowIndex, 2] = dgItemOrProductList.CurrentRow.Cells["ProductName"].Value.ToString();
                    iRowIndex++;
                    iRowIndex++;
                    iRowIndex++;
                    NewWorkSheet.Range["A1:B1"].Cells.Font.Size = 16;
                    NewWorkSheet.Range["A1:B1"].Cells.Font.Bold = true;
                    NewWorkSheet.Range["A2:B7"].Cells.Font.Size = 11;
                    NewWorkSheet.Range["A2:B7"].Cells.Font.Bold = true;
                    NewWorkSheet.Range["A8:H8"].Cells.Font.Size = 11;
                    NewWorkSheet.Range["A8:H8"].Cells.Font.Bold = true;
                    NewWorkSheet.Range["A8:H8"].Cells.Font.Color = Color.Blue;


                    if (dtPrintBOM.Rows.Count > 0)
                    {
                        object[,] rawData = new object[dtPrintBOM.Rows.Count + 1, dtPrintBOM.Columns.Count];
                        for (int col = 0; col < dtPrintBOM.Columns.Count; col++)
                        {
                            rawData[0, col] = dtPrintBOM.Columns[col].ColumnName;
                        }
                        for (int row = 0; row < dtPrintBOM.Rows.Count; row++)
                        {
                            for (int col = 0; col < dtPrintBOM.Columns.Count; col++)
                            {
                                rawData[row + 1, col] = dtPrintBOM.Rows[row].ItemArray[col];
                            }
                        }
                        string excelRange = string.Empty;
                        string finalColLetter = string.Empty;
                        string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        int colCharsetLen = colCharset.Length;

                        if (dtPrintBOM.Columns.Count > colCharsetLen)
                        {
                            finalColLetter = colCharset.Substring(
                                (dtPrintBOM.Columns.Count - 1) / colCharsetLen - 1, 1);
                        }
                        finalColLetter += colCharset.Substring((dtPrintBOM.Columns.Count - 1) % colCharsetLen, 1);
                        excelRange = string.Format("A8:{0}{1}", finalColLetter, (dtPrintBOM.Rows.Count + iRowIndex));
                        NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                    }
                    iRowIndex = (iRowIndex + 1 + dtPrintBOM.Columns.Count);
                    //cell1 = NewWorkSheet.Cells[iRowIndex, 1];
                    //cell2 = NewWorkSheet.Cells[(iRowIndex), 8];
                    //CELLS = (EXCEL.Range)NewWorkSheet.get_Range(cell1, cell2);
                    //CELLS.Borders.Color = System.Drawing.Color.Black;
                    //CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);

                    NewWorkSheet.Cells[2, 1].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignRight;
                    NewWorkSheet.Cells[3, 1].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignRight;
                    NewWorkSheet.Cells[4, 1].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignRight;
                    NewWorkSheet.Cells[5, 1].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignRight;
                    NewWorkSheet.Cells[6, 1].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignRight;
                    NewWorkSheet.Cells[7, 1].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignRight;
                    NewWorkSheet.Cells[2, 2].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    NewWorkSheet.Cells[3, 2].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    NewWorkSheet.Cells[4, 2].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    NewWorkSheet.Cells[5, 2].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    NewWorkSheet.Cells[6, 2].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    NewWorkSheet.Cells[7, 2].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;

                    if (DR == DialogResult.Yes)
                    {
                        //if (chkIncludePrice.CheckState == CheckState.Unchecked)
                        //{

                        Microsoft.Office.Interop.Excel.Range range = NewWorkSheet.get_Range("C6", "F9999");
                        range.NumberFormat = "0.00";
                        Microsoft.Office.Interop.Excel.Range range1 = NewWorkSheet.get_Range("I6", "I9999");
                        range1.NumberFormat = "DD/MM/YYYY";
                    }
                    else
                    {

                        Microsoft.Office.Interop.Excel.Range range = NewWorkSheet.get_Range("C6", "D9999");
                        range.NumberFormat = "0.00";
                        Microsoft.Office.Interop.Excel.Range range1 = NewWorkSheet.get_Range("G6", "G9999");
                        range1.NumberFormat = "DD/MM/YYYY";
                    }
                    NewWorkSheet.get_Range("C1", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
                    NewWorkSheet.get_Range("C1", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                    NewWorkSheet.Columns.AutoFit(); NewWorkSheet.Rows.AutoFit();
                    // NewWorkSheet.Columns[3].ColumnWidth = 45;
                    // NewWorkSheet.Columns[3].WrapText = true;
                    NewWorkSheet.Columns[2].ColumnWidth = 45;
                    NewWorkSheet.Columns[2].WrapText = true;
                    NewWorkSheet.PageSetup.Zoom = false;
                    NewWorkSheet.PageSetup.PrintArea = "A1 : H" + iRowIndex + "";
                    NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                    NewWorkSheet.Rows.RowHeight = "18";
                    NewWorkSheet.PageSetup.PrintNotes = true;
                    NewWorkSheet.PageSetup.Zoom = 60;
                    NewWorkSheet.PageSetup.FitToPagesTall = 1;
                    NewWorkSheet.PageSetup.FitToPagesWide = 1;
                    NewWorkSheet.PageSetup.LeftMargin = 0;
                    NewWorkSheet.PageSetup.RightMargin = 0;
                    NewWorkSheet.PageSetup.TopMargin = 0.75;
                    NewWorkSheet.PageSetup.BottomMargin = 0.75;
                    NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                    NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                    //EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[1, 4];
                    //System.Drawing.Image oImage = System.Drawing.Image.FromFile(_stLOGO);
                    //System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    //NewWorkSheet.Paste(oRange, _stLOGO);
                    NewWorkBook.Save();
                    NewWorkBook.Close(true, misValue, misValue);
                    ExcelApp.Quit();
                    releaseObject(NewWorkSheet);
                    releaseObject(NewWorkBook);
                    releaseObject(ExcelApp);

                    if (Directory.Exists(ExcelFolderPath))
                    {
                        Process.Start(ExcelFolderPath);
                    }
                    Cursor.Current = Cursors.Default;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                    {
                        GetProcess.Kill();
                    }
                }
            }
            else
                MessageBox.Show("No Project BOM Items to Print", "Error", 0, MessageBoxIcon.Question);
        }

        private void btnCopyProject_Click(object sender, EventArgs e)
        {
        }

        private void chkAddProduct_CheckedChanged(object sender, EventArgs e)
        {
            if (chkAddProduct.CheckState == CheckState.Checked)
            {
                pnAddProduct.Visible = true;
            }
            else
            {
                pnAddProduct.Visible = false;
            }

        }

        private void btnAddCategoryProduct_Click(object sender, EventArgs e)
        {
            if (!cmbProductCategory.Items.Contains(txtProductCategory.Text))
            {
                cmbProductCategory.Items.Add(txtProductCategory.Text);
                chkAddProduct.Checked = false;
                //  pnAddProduct.Visible = false;
                MessageBox.Show("Entered product group added", "Success", 0, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Entered product group exist, Enter a uniqe name", "Error", 0, MessageBoxIcon.Error);
            }
        }

        bool bMainCategory = false;
        bool bItemCheck = false;
        bool bCategory = false;
        private void cmbProductCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            //MessageBox.Show("Function called...");
            if (cmbProjectCode.SelectedIndex >= 0)
            {
                bMainCategory = true;

                foreach (DataGridViewRow DGVR in dgItemOrProductList.Rows)
                {
                    if (DGVR.Cells["ProductType"].Value.ToString().Equals(cmbProductCategory.Text))
                    {
                        bMainCategory = false;
                        break;
                    }
                    else
                    {
                        bMainCategory = true;
                    }
                }
                if (bMainCategory)
                {
                    fnAddProducttoDataGridview(true, false);
                }
            }
            else
            {
                MessageBox.Show("Please select a project code to add the products", "Error", 0, MessageBoxIcon.Error);
            }
        }

        private void Datagridviewcolor(string ColumnName, DataGridView dgDataGridView)
        {
            int k = dgItemOrProductList.Rows.Count;
            int iRow = 0;

            //for (int r = 0; r <= dgDataGridView.Rows.Count; r++)
            //{
            //}
            foreach (DataGridViewRow dgr in dgDataGridView.Rows)
            {

                if ((dgr.Cells[ColumnName].Value.ToString()) == "")
                {
                    dgr.DefaultCellStyle.BackColor = Color.BurlyWood;
                }
                else
                {
                    if (iRow > 0)
                    {
                        dgItemOrProductList.Rows[iRow].Visible = false;
                    }
                }
                iRow++;
            }
        }
        double dRowNumber = 0;
        string Productcode;
        int iQty;
        private void fnAddProducttoDataGridview(bool bMainItem, bool bAddFromProductCheck)
        {
            bItemCheck = false;
            bCategory = false;
            if (!bMainItem)
            {
                dtProductCode = DAL.fnGetSalesProductTreeDetails(sName[0]).Tables[0];
                if (dtProductCode.Rows.Count > 0)
                {
                    foreach (DataGridViewRow dr in dgItemOrProductList.Rows)
                    {
                        Productcode = dtProductCode.Rows[0]["ProductCode"].ToString();
                        if (dr.Cells["PProductCode"].Value.ToString() == Productcode && dr.Cells["ProductType"].Value.ToString() == (cmbProductCategory.Text))
                        {
                            if (bAddFromProductCheck)
                            {
                                MessageBox.Show("Selected product already added in the quote item list", "Warning", 0, MessageBoxIcon.Warning);
                            }
                            bItemCheck = true;
                            break;
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please recheck product saved correctly Product Master", "Error", 0, MessageBoxIcon.Error);
                    bItemCheck = true;
                }
            }
            dRowNumber = 0;
            if (!bItemCheck && cmbProductCategory.SelectedIndex >= 0)
            {
                DR = dtDGDatatable.NewRow();

                if (dgItemOrProductList.Rows.Count == 0)
                {
                    dRowNumber++;
                }
                foreach (DataGridViewRow DGVR in dgItemOrProductList.Rows)
                {
                    if (DGVR.Cells["ProductType"].Value.ToString().Equals(cmbProductCategory.Text))
                    {
                        bCategory = true;
                        dRowNumber = Convert.ToDouble(DGVR.Cells["SLNO"].Value.ToString());
                    }
                    else
                    {
                        bCategory = false;
                    }
                }

                if (!bCategory && dRowNumber == 0)
                {
                    DataTable dtCloned = dtDGDatatable.Clone();
                    dtCloned.Columns[0].DataType = typeof(double);
                    foreach (DataRow row in dtDGDatatable.Rows)
                    {
                        dtCloned.ImportRow(row);
                    }

                    double maxAccountLevel = double.MinValue;
                    foreach (DataRow dr in dtCloned.Rows)
                    {
                        double accountLevel = dr.Field<double>(0);
                        maxAccountLevel = Math.Max(maxAccountLevel, accountLevel);
                    }

                    if (maxAccountLevel == Math.Floor(maxAccountLevel))
                    {
                        DR["SLNO"] = Math.Ceiling(maxAccountLevel + 1);
                    }
                    else
                    {
                        DR["SLNO"] = Math.Ceiling(maxAccountLevel);
                    }
                }
                else
                {
                    if (dgItemOrProductList.Rows.Count > 0)
                    {
                        double d = Math.Truncate(dRowNumber);
                        double x = dRowNumber - d;
                        x = Math.Round(x, 2, MidpointRounding.AwayFromZero);
                        dRowNumber += 0.01;
                        dRowNumber = Math.Round(dRowNumber, 2, MidpointRounding.AwayFromZero);
                        DR["SLNO"] = dRowNumber;
                    }
                    else
                    {
                        DR["SLNO"] = dRowNumber;
                    }
                }
                if (bMainItem)
                {
                    iQty = 0;
                    fCost = 0.0;
                    DR["ProductCode"] = "";
                    DR["ProductName"] = cmbProductCategory.Text;
                    DR["ProductType"] = cmbProductCategory.Text;
                    DR["Version"] = 0;
                    DR["UnitCost"] = fCost;
                    DR["Quantity"] = iQty;
                    DR["IssuedAmount"] = 0;
                    DR["Progress"] = 0;
                    DR["ProjectBOM"] = "True";
                    DR["DesignBOM"] = "False";

                    DataTable GetERPProjectBOMLockDetails = DAL.fnGetERPProjectBOMLock(cmbProjectCode.Text).Tables[0];
                    bool AllowBOM = true;
                    if (GetERPProjectBOMLockDetails.Rows.Count > 0)
                    {
                        if (GetERPProjectBOMLockDetails.Rows[0]["LockNow"].ToString().ToLower() == "true")
                        {
                            // MessageBox.Show($"The selected project currently LOCK...!");
                            AllowBOM = false;
                        }
                        else
                        {
                            AllowBOM = true;
                        }
                        if (GetERPProjectBOMLockDetails.Rows[0]["LockNow"].ToString().ToLower() == "false")
                        {
                            try
                            {
                                var s = GetERPProjectBOMLockDetails.Rows[0]["BOMClosingDate"]?.ToString();
                                var bomClosingDate = DateTime.ParseExact(s, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                                int cmp = DateTime.Compare(bomClosingDate.Date, DateTime.Today);
                                // MessageBox.Show(cmp.ToString());
                                if (cmp == 1)
                                {
                                    // MessageBox.Show($"The selected project currently Open till{s}..!");
                                    AllowBOM = true;
                                }
                                else
                                {
                                    AllowBOM = false;
                                    // MessageBox.Show($"The selected project currently LOCK {s}..!");
                                }
                            }
                            catch
                            {
                            }
                        }

                    }

                    if (AllowBOM)
                    {
                        fnSaveProjectBOM(cmbProjectCode.Text, true);//1

                    }
                    else
                    {
                        MessageBox.Show("The BOM in Lock Please Check With Manager", "BOM IN LOCK");
                    }



                    dtDGDatatable.Rows.Add(DR);
                    dgItemOrProductList.AutoGenerateColumns = false;
                    dgItemOrProductList.DataSource = dtDGDatatable;

                    //avinash--------------------------------------------'
                    sTotalAmount = 0;
                    foreach (DataGridViewRow dgvr in dgItemOrProductList.Rows)
                    {
                        if (!string.IsNullOrEmpty(dgvr.Cells["PProductCode"].Value.ToString()))
                        {
                            sTotalAmount += Convert.ToDouble(dgvr.Cells["UnitCost"].Value);
                        }
                    }
                    fnTotalAmount(sTotalAmount);
                    string text1 = string.Format(india, "{0:c}", dNewTotalAmount); // ₹ 3,20,000 
                    txtTotalCost.Text = text1;
                    //---------------------------------------------
                }
                else
                {
                    fCost = 0.0;
                    iQty = 1;
                    //if (dtProductCode.Rows.Count > 0)
                    // {
                    dtCompleteBOM = DAL.fnVersionProductBOMList(sName[0], cmbVersion.Text).Tables[0];
                    dtLatestCost = DAL.fnLatestCost().Tables[0];
                    if (dtCompleteBOM.Rows.Count > 0)
                    {
                        foreach (DataRow rowSampleOne in dtLatestCost.Rows)
                        {
                            foreach (DataRow rowSampleTwo in dtCompleteBOM.Rows)
                            {
                                if (rowSampleTwo["ItemCode"].ToString().Equals(rowSampleOne["ItemCode"].ToString()))
                                {
                                    rowSampleTwo["LatestCost"] = Convert.ToDouble(rowSampleOne["PurchaseCost"].ToString());
                                }
                            }
                        }
                        foreach (DataRow rowSampleTwo in dtCompleteBOM.Rows)
                        {
                            if (rowSampleTwo["LatestCost"].ToString().Equals("0"))
                            {
                                rowSampleTwo["LatestCost"] = Convert.ToDouble(rowSampleTwo["UnitCost"].ToString());
                            }
                        }
                        foreach (DataRow dr in dtCompleteBOM.Rows)
                        {
                            fCost += Convert.ToDouble(dr["FixedCost"]) * Convert.ToDouble(dr["Quantity"]);
                        }
                    }

                    fnTotalAmount(fCost);
                    fCost = dNewTotalAmount;
                    // }

                    DR["ProductCode"] = dtProductCode.Rows[0]["ProductCode"].ToString();
                    DR["ProductName"] = dtProductCode.Rows[0]["Name"].ToString();
                    DR["ProductType"] = cmbProductCategory.Text;
                    DR["Version"] = cmbVersion.Text;
                    DR["UnitCost"] = fCost;
                    DR["Quantity"] = iQty;
                    DR["IssuedAmount"] = 0;
                    DR["Progress"] = 0;
                    DR["ProjectBOM"] = "True";
                    DR["DesignBOM"] = "False";


                    DataTable GetERPProjectBOMLockDetails = DAL.fnGetERPProjectBOMLock(cmbProjectCode.Text).Tables[0];
                    bool AllowBOM = true;
                    if (GetERPProjectBOMLockDetails.Rows.Count > 0)
                    {
                        if (GetERPProjectBOMLockDetails.Rows[0]["LockNow"].ToString().ToLower() == "true")
                        {
                            // MessageBox.Show($"The selected project currently LOCK...!");
                            AllowBOM = false;
                        }
                        else
                        {
                            AllowBOM = true;
                        }
                        if (GetERPProjectBOMLockDetails.Rows[0]["LockNow"].ToString().ToLower() == "false")
                        {
                            try
                            {
                                var s = GetERPProjectBOMLockDetails.Rows[0]["BOMClosingDate"]?.ToString();
                                var bomClosingDate = DateTime.ParseExact(s, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                                int cmp = DateTime.Compare(bomClosingDate.Date, DateTime.Today);
                                // MessageBox.Show(cmp.ToString());
                                if (cmp == 1)
                                {
                                    // MessageBox.Show($"The selected project currently Open till{s}..!");
                                    AllowBOM = true;
                                }
                                else
                                {
                                    AllowBOM = false;
                                    // MessageBox.Show($"The selected project currently LOCK {s}..!");
                                }
                            }
                            catch
                            {
                            }
                        }

                    }

                    if (AllowBOM)
                    {
                        fnSaveProjectBOM(cmbProjectCode.Text, false);//2

                    }
                    else
                    {
                        MessageBox.Show("The BOM in Lock Please Check With Manager", "BOM IN LOCK");
                    }


                    dtDGDatatable.Rows.Add(DR);

                    timer1.Stop();
                    lblVersion.Visible = true;

                    //avinash--------------------------------------------
                    sTotalAmount = 0;
                    foreach (DataGridViewRow dgvr in dgItemOrProductList.Rows)
                    {
                        if (!string.IsNullOrEmpty(dgvr.Cells["PProductCode"].Value.ToString()))
                        {
                            sTotalAmount += Convert.ToDouble(dgvr.Cells["UnitCost"].Value);
                        }
                    }
                    fnTotalAmount(sTotalAmount);
                    string text1 = string.Format(india, "{0:c}", dNewTotalAmount); // ₹ 3,20,000 
                    txtTotalCost.Text = text1;
                    //---------------------------------------------


                    //if (dgItemOrProductList.Rows.Count > 0)
                    //{
                    //    txtPreparedBy.Text = Login.frmLoginForm.sUserDetails[2];
                    //    // txtAutherisedBy.Text = Login.frmLoginForm.sUserDetails[2];
                    //    if (!btnSave.Enabled)
                    //        btnSave.Enabled = true;
                    //}
                    //sTotalAmount = 0;
                    //foreach (DataGridViewRow dgvr in dgItemOrProductList.Rows)
                    //{
                    //    sTotalAmount += Convert.ToDouble(dgvr.Cells["UnitCost"].Value);
                    //}
                    //fnTotalAmount(sTotalAmount);
                    //CultureInfo india = new CultureInfo("hi-IN");
                    //string text = string.Format(india, "{0:c}", dNewTotalAmount);
                    //txtTotalCost.Text = text;
                }
                fnTotalCalucalation();
                //---------------------------------------------------------------------------------------------------------------
                double totalamount = 0.0;
                double JobIssuedAmount = 0;
                dtDGDatatable = DAL.fnDirectProjectBOMList(cmbProjectCode.Text).Tables[0];
                foreach (DataRow dr in dtDGDatatable.Rows)
                {
                    if (!string.IsNullOrEmpty(dr["ProductCode"].ToString()))
                    {
                        totalamount += Convert.ToDouble(dr["UnitCost"].ToString());
                    }
                }
                dtJobIssued = DAL.fnProjectIssued(1, cmbProjectCode.Text, "2015/01/01", DateTime.Now.ToString("yyyy-MM-dd")).Tables[0];
                if (dtJobIssued.Rows.Count > 0)
                {
                    dgvJobIssuedList.AutoGenerateColumns = false;
                    dgvJobIssuedList.DataSource = dtJobIssued;

                    //foreach (DataRow dr in dtJobIssued.Rows)
                    //{
                    //    JobIssuedAmount += Convert.ToDouble(dr[5].ToString());
                    //}
                    //fnTotalAmount(JobIssuedAmount);
                    //string text1 = string.Format(india, "{0:c}", dNewTotalAmount);
                    //lblJobissuedCost.Text = text1;
                }
                else
                {
                    fnTotalAmount(0.00);
                    string text2 = string.Format(india, "{0:c}", dNewTotalAmount);
                    lblJobissuedCost.Text = text2;
                }
                fnTotalAmount(totalamount + JobIssuedAmount);
                string text = string.Format(india, "{0:c}", dNewTotalAmount); // ₹ 3,20,000 
                txtTotalCost.Text = text;
                dtProjectOrdertarget = DAL.fnProjectOrderEntry(cmbProjectCode.Text, 1).Tables[0];
                if (dtProjectOrdertarget.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtProjectOrdertarget.Rows[0]["TargetMargin"].ToString()))
                    {
                        txtprojecttarget.Text = Math.Round((1 - (Convert.ToDouble(dtProjectOrdertarget.Rows[0]["TargetMargin"].ToString()) / 100)) * Convert.ToDouble(dtProjectOrdertarget.Rows[0]["OrderValueinINR"].ToString())).ToString();
                    }
                    if (Convert.ToInt32(dNewTotalAmount) > Convert.ToInt32(txtprojecttarget.Text))
                    {
                        MessageBox.Show("BOM Cost Is More Than Project Cost", "Warning", 0, MessageBoxIcon.Warning);
                        txtTotalCost.ForeColor = System.Drawing.Color.Red;
                    }
                }

                //-----------------------------------------------------------------------------------------------------------------------
            }
            else
            {
                if (cmbProductCategory.SelectedIndex < 0)
                {
                    MessageBox.Show("Please select the product category", "Information", 0, MessageBoxIcon.Warning);
                    cmbProductCategory.DroppedDown = true;
                }
            }
        }

        private void fnTotalCalucalation()
        {
            DataView view = dtDGDatatable.DefaultView;
            view.Sort = "SLNO ASC";
            dtDGDatatable = view.ToTable();
            DataTable dtExcelImport = new DataTable();
            dtExcelImport = dtDGDatatable.Copy();
            /*  double sQty;
              if (dtExcelImport.Rows.Count > 0)
              {
                  Dictionary<string, double> dicSum = new Dictionary<string, double>();
                  foreach (DataRow row in dtExcelImport.Rows)
                  {
                      // if (!string.IsNullOrEmpty(row[3].ToString()))
                      {
                          string group = row["ProductType"].ToString();
                          //avinash---------------------------------------------------
                          // double rate = Convert.ToDouble(row["Quantity"]) * Convert.ToDouble(row["UnitCost"]);//shivacode
                          double rate = (!string.IsNullOrEmpty(row["ProductCode"].ToString())) ? Convert.ToDouble(row["UnitCost"]) : 0.0;
                          //------------------------------------------------
                          if (dicSum.ContainsKey(group))
                              dicSum[group] += rate;
                          else
                              dicSum.Add(group, rate);
                      }
                  }
                  DataTable UniqueRecords = RemoveDuplicateRows(dtExcelImport, "ProductType");

                  foreach (var group in dicSum)
                  {
                      foreach (DataRow FinalItems in dtExcelImport.Rows)
                      {
                          if (FinalItems["ProductType"].ToString() == group.Key.ToString())
                          {
                              sQty = group.Value;
                              FinalItems["UnitCost"] = sQty;

                              break;
                          }
                      }
                  }
              }

              foreach (DataRow row in dtDGDatatable.Rows)
              {
                  if (string.IsNullOrEmpty(row["ProductCode"].ToString()))
                  {
                      foreach (DataRow FinalItems in dtExcelImport.Rows)
                      {
                          if (row["ProductType"].ToString() == FinalItems["ProductType"].ToString())
                          {
                              row["UnitCost"] = FinalItems["UnitCost"].ToString();

                              //row["BreakupTotal"] = FinalItems["BreakupTotal"].ToString();
                              break;
                          }
                      }
                  }
              }*/

            double sQty;

            // Guard clauses
            if (dtExcelImport == null || dtExcelImport.Rows.Count == 0)
                return;

            // 1) Build per-ProductType sums for UnitCost and IssuedAmount (consider ProductCode filter)
            var sumUnitCostByType = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
            var sumIssuedAmountByType = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);

            foreach (DataRow row in dtExcelImport.Rows)
            {
                string group = row["ProductType"]?.ToString() ?? string.Empty;
                string productCode = row["ProductCode"]?.ToString() ?? string.Empty;

                // Only include rows with ProductCode (your original behavior)
                if (!string.IsNullOrEmpty(productCode))
                {
                    // UnitCost
                    if (double.TryParse(row["UnitCost"]?.ToString(), out double unitCost))
                    {
                        if (sumUnitCostByType.ContainsKey(group))
                            sumUnitCostByType[group] += unitCost;
                        else
                            sumUnitCostByType[group] = unitCost;
                    }

                    // IssuedAmount
                    if (double.TryParse(row["IssuedAmount"]?.ToString(), out double issuedAmount))
                    {
                        if (sumIssuedAmountByType.ContainsKey(group))
                            sumIssuedAmountByType[group] += issuedAmount;
                        else
                            sumIssuedAmountByType[group] = issuedAmount;
                    }
                }
            }

            // 2) Optional: remove duplicates if you need it for other logic
            //    (Your original code had this call but didn't use its result)
            DataTable uniqueRecords = RemoveDuplicateRows(dtExcelImport, "ProductType");

            // 3) Write the group sums back into dtExcelImport (first row per ProductType)
            foreach (var group in sumUnitCostByType)
            {
                foreach (DataRow final in dtExcelImport.Rows)
                {
                    if (string.Equals(final["ProductType"]?.ToString(), group.Key, StringComparison.OrdinalIgnoreCase))
                    {
                        final["UnitCost"] = group.Value;  // set group total
                        break;
                    }
                }
            }

            foreach (var group in sumIssuedAmountByType)
            {
                foreach (DataRow final in dtExcelImport.Rows)
                {
                    if (string.Equals(final["ProductType"]?.ToString(), group.Key, StringComparison.OrdinalIgnoreCase))
                    {
                        final["IssuedAmount"] = group.Value;  // set group total
                        break;
                    }
                }
            }

            // 4) Push values from dtExcelImport into dtDGDatatable where ProductCode is empty
            if (dtDGDatatable != null && dtDGDatatable.Rows.Count > 0)
            {
                foreach (DataRow row in dtDGDatatable.Rows)
                {
                    if (string.IsNullOrEmpty(row["ProductCode"]?.ToString()))
                    {
                        string type = row["ProductType"]?.ToString();
                        if (string.IsNullOrEmpty(type)) continue;

                        foreach (DataRow src in dtExcelImport.Rows)
                        {
                            if (string.Equals(src["ProductType"]?.ToString(), type, StringComparison.OrdinalIgnoreCase))
                            {
                                // Copy UnitCost
                                row["UnitCost"] = src["UnitCost"];

                                // Copy IssuedAmount (NEW)
                                row["IssuedAmount"] = src["IssuedAmount"];

                                // If you also need BreakupTotal or others, copy here similarly.
                                break;
                            }
                        }
                    }
                }
            }

            if (dtDGDatatable != null && dtDGDatatable.Rows.Count > 0)
            {
                StringBuilder sb = new StringBuilder();

                sb.AppendLine("IssuedAmount");

                foreach (DataRow row in dtDGDatatable.Rows)
                {
                    sb.AppendLine(row["IssuedAmount"].ToString());
                }

                // MessageBox.Show(sb.ToString(), "IssuedAmount Values");
            }
            else
            {
                MessageBox.Show("dtDGDatatable is empty.");
            }




            dgItemOrProductList.AutoGenerateColumns = false;
            dgItemOrProductList.DataSource = dtDGDatatable;
            Datagridviewcolor("PProductCode", dgItemOrProductList);


            //double sTotalAmount = 0;

            //Datagridviewcolor("ProductCod", dgQuoteBOM);
            //foreach (DataGridViewRow dgvr in dgQuoteBOM.Rows)
            //{
            //    if (Convert.ToDouble(dgvr.Cells["UnitPrice"].Value) == 0)
            //    {
            //        sTotalAmount += (Convert.ToDouble(dgvr.Cells["Quantity"].Value) * Convert.ToDouble(dgvr.Cells["BreakupTotal"].Value));
            //    }
            //    else
            //    {
            //        sTotalAmount += (Convert.ToDouble(dgvr.Cells["Quantity"].Value) * Convert.ToDouble(dgvr.Cells["UnitPrice"].Value));
            //    }
            //}

            //int nRowIndex = dgQuoteBOM.Rows.Count;
            //if (nRowIndex > 0)
            //    dgQuoteBOM.CurrentCell = dgQuoteBOM.Rows[nRowIndex - 1].Cells[0];

            //txtTotalPrice.Text = Math.Round(sTotalAmount).ToString();
        }

        public DataTable RemoveDuplicateRows(DataTable table, string DistinctColumn)
        {
            try
            {
                ArrayList UniqueRecords = new ArrayList();
                ArrayList DuplicateRecords = new ArrayList();

                foreach (DataRow dRow in table.Rows)
                {
                    if (UniqueRecords.Contains(dRow[DistinctColumn]))
                        DuplicateRecords.Add(dRow);
                    else
                        UniqueRecords.Add(dRow[DistinctColumn]);

                }
                if (DuplicateRecords.Count > 0)
                {
                    foreach (DataRow dRow in DuplicateRecords)
                    {
                        table.Rows.Remove(dRow);
                    }
                }
                return table;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;

            }
        }

        private void dgItemOrProductList_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            DataTable GetERPProjectBOMLockDetails = DAL.fnGetERPProjectBOMLock(cmbProjectCode.Text).Tables[0];
            bool AllowBOM = true;
            if (GetERPProjectBOMLockDetails.Rows.Count > 0)
            {
                if (GetERPProjectBOMLockDetails.Rows[0]["LockNow"].ToString().ToLower() == "true")
                {
                    // MessageBox.Show($"The selected project currently LOCK...!");
                    AllowBOM = false;
                }
                else
                {
                    AllowBOM = true;
                }
                if (GetERPProjectBOMLockDetails.Rows[0]["LockNow"].ToString().ToLower() == "false")
                {
                    try
                    {
                        var s = GetERPProjectBOMLockDetails.Rows[0]["BOMClosingDate"]?.ToString();
                        var bomClosingDate = DateTime.ParseExact(s, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                        int cmp = DateTime.Compare(bomClosingDate.Date, DateTime.Today);
                        // MessageBox.Show(cmp.ToString());
                        if (cmp == 1)
                        {
                            // MessageBox.Show($"The selected project currently Open till{s}..!");
                            AllowBOM = true;
                        }
                        else
                        {
                            AllowBOM = false;
                            // MessageBox.Show($"The selected project currently LOCK {s}..!");
                        }
                    }
                    catch
                    {
                    }
                }

            }

            if (AllowBOM)
            {
                if (e.ColumnIndex == 5 && string.IsNullOrEmpty(dgItemOrProductList.CurrentRow.Cells[1].Value.ToString()))
                {
                    dgItemOrProductList.Columns[e.ColumnIndex].ReadOnly = true;
                }
                else if (e.ColumnIndex == 5 && !string.IsNullOrEmpty(dgItemOrProductList.CurrentRow.Cells[1].Value.ToString()))
                {
                    dgItemOrProductList.Columns[e.ColumnIndex].ReadOnly = false;
                }
            }
        }

        private void btnGMApprove_Click(object sender, EventArgs e)
        {
            GLobalClass.iStatus = DAL.fnAddProjectUpdate(8, cmbProjectCode.Text, "", "", "");
            fnAlertMail("Vivek G");
            btnGMApprove.Enabled = false;
            MessageBox.Show("Project BOM approve request sent", "Information", 0, MessageBoxIcon.Information);
        }

        public void fnAlertMail(string sUser)
        {
            try
            {
                DataTable dtlogindetails = DAL.fnloginemail(sUser).Tables[0]; ;
                if (dtlogindetails.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
                    {
                        Outlook.Application oApp = new Outlook.Application();
                        Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);


                        oMsg.Subject = "Project " + txtProjectName.Text + " sent for approval";
                        oMsg.HTMLBody = "Dear " + sUser + ", <br /><br /> Project BOM added and  <font color='blue'>" + cmbProjectCode.Text + " - " + txtProjectName.Text + " </font> sent for  approval. <br /> <br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";

                        Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                        oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                        oRecips.ResolveAll();


                        oMsg.Send();
                        oRecips = null;


                        oMsg = null;
                        oApp = null;
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void dgBOMList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataTable GetERPProjectBOMLockDetails = DAL.fnGetERPProjectBOMLock(cmbProjectCode.Text).Tables[0];
            bool AllowBOM = true;
            if (GetERPProjectBOMLockDetails.Rows.Count > 0)
            {
                if (GetERPProjectBOMLockDetails.Rows[0]["LockNow"].ToString().ToLower() == "true")
                {
                    // MessageBox.Show($"The selected project currently LOCK...!");
                    AllowBOM = false;
                }
                else
                {
                    AllowBOM = true;
                }
                if (GetERPProjectBOMLockDetails.Rows[0]["LockNow"].ToString().ToLower() == "false")
                {
                    try
                    {
                        var s = GetERPProjectBOMLockDetails.Rows[0]["BOMClosingDate"]?.ToString();
                        var bomClosingDate = DateTime.ParseExact(s, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                        int cmp = DateTime.Compare(bomClosingDate.Date, DateTime.Today);
                        // MessageBox.Show(cmp.ToString());
                        if (cmp == 1)
                        {
                            // MessageBox.Show($"The selected project currently Open till{s}..!");
                            AllowBOM = true;
                        }
                        else
                        {
                            AllowBOM = false;
                            // MessageBox.Show($"The selected project currently LOCK {s}..!");
                        }
                    }
                    catch
                    {
                    }
                }

            }

            if (AllowBOM)
            {
                cmbWorkDescription.Visible = false;
                if (dgBOMList.CurrentCell.ColumnIndex == 1)
                {
                    Show_Combobox(dgBOMList.CurrentCell.RowIndex, 1);
                }
            }
        }

        private void Show_Combobox(int iRowIndex, int iColumnIndex)
        {
            // DESCRIPTION: SHOW THE COMBO BOX IN THE SELECTED CELL OF THE GRID.
            // PARAMETERS: iRowIndex - THE ROW ID OF THE GRID.
            //             iColumnIndex - THE COLUMN ID OF THE GRID.

            int x = 0;
            int y = 0;
            int Width = 0;
            int height = 0;

            // GET THE ACTIVE CELL'S DIMENTIONS TO BIND THE COMBOBOX WITH IT.
            Rectangle rect = default(Rectangle);
            rect = dgBOMList.GetCellDisplayRectangle(iColumnIndex, iRowIndex, false);
            x = rect.X + dgBOMList.Left;
            y = rect.Y + dgBOMList.Top;

            Width = rect.Width;
            height = rect.Height;

            cmbWorkDescription.SetBounds(x, y, Width, height);
            cmbWorkDescription.Visible = true;
            cmbWorkDescription.DroppedDown = true;
        }

        private void cmbWorkDescription_SelectedIndexChanged(object sender, EventArgs e)
        {

            // if (!string.IsNullOrEmpty(dgBOMList.CurrentRow.Cells["IProductType"].Value.ToString()))
            {
                dgBOMList.CurrentCell.Value = cmbWorkDescription.Text.ToString();
                cmbWorkDescription.Visible = false;

                dtUpdateMachineBOM = DAL.fnProjectBOMProdutnamenumber(dgItemOrProductList.CurrentRow.Cells["PProductCode"].Value.ToString(), cmbProjectCode.Text,
                                  dgItemOrProductList.CurrentRow.Cells["ProductType"].Value.ToString(), dgItemOrProductList.CurrentRow.Cells["ProductName"].Value.ToString()).Tables[0];
                if (dtUpdateMachineBOM.Rows.Count > 0)
                {
                    GLobalClass.iSuccess = DAL.fnAddMachineBOM(7, dgBOMList.CurrentRow.Cells["IProductType"].Value.ToString(), dgBOMList.CurrentRow.Cells["ID"].Value.ToString(),
                                                        dgBOMList.CurrentRow.Cells["uItemCode"].Value.ToString(), dtUpdateMachineBOM.Rows[0]["ProjectCode"].ToString(), null, null, null, null, null, null, Convert.ToDouble(dgBOMList.CurrentRow.Cells["uBOMQty"].Value, null),
                                                        0, 0, null, login.GetUserDetails[2], dtpCreatedDate.Text, dgBOMList.CurrentRow.Cells["ID"].Value.ToString(), 0);
                }
            }
        }

        private void oDateTimePicker_CloseUp(object sender, EventArgs e)
        {
            oDateTimePicker.Visible = false;
        }

        private void oDateTimePicker_TabIndexChanged(object sender, EventArgs e)
        {
            if (dgItemOrProductList.CurrentCell.OwningColumn.Name == "StartDate")
            {
                dgItemOrProductList.CurrentCell.Value = oDateTimePicker.Text.ToString();

                GLobalClass.iSuccess = DAL.fnAddProjectBOM(7, null, cmbProjectCode.Text, dgItemOrProductList.CurrentRow.Cells["SLNO"].Value.ToString(), dgItemOrProductList.CurrentRow.Cells["PProductCode"].Value.ToString(),
                                               Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["Quantity"].Value), Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value),
                                               dgItemOrProductList.CurrentRow.Cells["StartDate"].Value.ToString(), null, null, null, null, null, null, 0, null, "1", "1", "", 0, false);


            }
            else if (dgItemOrProductList.CurrentCell.OwningColumn.Name == "FinishDate")
            {
                dgItemOrProductList.CurrentCell.Value = oDateTimePicker.Text.ToString();

                GLobalClass.iSuccess = DAL.fnAddProjectBOM(8, null, cmbProjectCode.Text, dgItemOrProductList.CurrentRow.Cells["SLNO"].Value.ToString(), dgItemOrProductList.CurrentRow.Cells["PProductCode"].Value.ToString(),
                                               Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["Quantity"].Value), Convert.ToDouble(dgItemOrProductList.CurrentRow.Cells["UnitCost"].Value),
                                               dgItemOrProductList.CurrentRow.Cells["FinishDate"].Value.ToString(), null, null, null, null, null, null, 0, null, "1", "1", "", 0, false);


            }
        }

        private void dgBOMList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
