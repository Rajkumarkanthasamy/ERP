﻿namespace Erp_Project_With_Buttons.ProjectBOM
{
    partial class BOMChangesLogs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BOMChangesLogs));
            this.panel1 = new System.Windows.Forms.Panel();
            this.openingDate = new System.Windows.Forms.Label();
            this.button2Lock = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button1Exit = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.checkBox1BlockNow = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.labelProjectDec = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labelCustomerName = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox1ProjectCode = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxLockRemarks = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dataGridViewBOMLockLogs = new System.Windows.Forms.DataGridView();
            this.ProjectCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Qty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ActionMadeBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Version = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductCategory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectBOMNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ActionType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CreatedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectIssuedCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Exportbutton = new System.Windows.Forms.Button();
            this.FilterApplybutton = new System.Windows.Forms.Button();
            this.comboBox1Remarks = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.ClearFilter = new System.Windows.Forms.Button();
            this.dateTimePickerLogTo = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerLogFrom = new System.Windows.Forms.DateTimePicker();
            this.comboBoxLogUser = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.comboBoxLogProjectCode = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.LOGSButton = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBOMLockLogs)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.panel1.Controls.Add(this.openingDate);
            this.panel1.Controls.Add(this.button2Lock);
            this.panel1.Controls.Add(this.checkBox1);
            this.panel1.Controls.Add(this.button1Exit);
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.checkBox1BlockNow);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.labelProjectDec);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.labelCustomerName);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.comboBox1ProjectCode);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.comboBoxLockRemarks);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Location = new System.Drawing.Point(12, 66);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1791, 965);
            this.panel1.TabIndex = 0;
            this.panel1.Visible = false;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // openingDate
            // 
            this.openingDate.AutoSize = true;
            this.openingDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.openingDate.ForeColor = System.Drawing.Color.Red;
            this.openingDate.Location = new System.Drawing.Point(781, 116);
            this.openingDate.Name = "openingDate";
            this.openingDate.Size = new System.Drawing.Size(23, 28);
            this.openingDate.TabIndex = 21;
            this.openingDate.Text = "#";
            this.openingDate.Visible = false;
            // 
            // button2Lock
            // 
            this.button2Lock.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.button2Lock.Location = new System.Drawing.Point(236, 618);
            this.button2Lock.Name = "button2Lock";
            this.button2Lock.Size = new System.Drawing.Size(152, 48);
            this.button2Lock.TabIndex = 13;
            this.button2Lock.Text = "Save";
            this.button2Lock.UseVisualStyleBackColor = true;
            this.button2Lock.Click += new System.EventHandler(this.button2Lock_Click);
            this.button2Lock.MouseEnter += new System.EventHandler(this.button2Lock_MouseEnter);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.checkBox1.Location = new System.Drawing.Point(180, 443);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(153, 32);
            this.checkBox1.TabIndex = 11;
            this.checkBox1.Text = "Unlock Now";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // button1Exit
            // 
            this.button1Exit.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.button1Exit.Location = new System.Drawing.Point(46, 618);
            this.button1Exit.Name = "button1Exit";
            this.button1Exit.Size = new System.Drawing.Size(156, 48);
            this.button1Exit.TabIndex = 12;
            this.button1Exit.Text = "Exit";
            this.button1Exit.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.dateTimePicker1.Location = new System.Drawing.Point(381, 435);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(247, 35);
            this.dateTimePicker1.TabIndex = 11;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // label6
            // 
            this.label6.ForeColor = System.Drawing.Color.Blue;
            this.label6.Location = new System.Drawing.Point(376, 383);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(506, 40);
            this.label6.TabIndex = 10;
            this.label6.Text = "**Date Based -This option allows you to set a specific date (or date range) for w" +
    "hen the block should be applied**";
            // 
            // checkBox1BlockNow
            // 
            this.checkBox1BlockNow.AutoSize = true;
            this.checkBox1BlockNow.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.checkBox1BlockNow.Location = new System.Drawing.Point(45, 443);
            this.checkBox1BlockNow.Name = "checkBox1BlockNow";
            this.checkBox1BlockNow.Size = new System.Drawing.Size(130, 32);
            this.checkBox1BlockNow.TabIndex = 9;
            this.checkBox1BlockNow.Text = "Lock Now";
            this.checkBox1BlockNow.UseVisualStyleBackColor = true;
            this.checkBox1BlockNow.CheckedChanged += new System.EventHandler(this.checkBox1BlockNow_CheckedChanged);
            // 
            // label5
            // 
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(44, 383);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(308, 45);
            this.label5.TabIndex = 8;
            this.label5.Text = "**Block now - immediately applies a lock**";
            // 
            // labelProjectDec
            // 
            this.labelProjectDec.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.labelProjectDec.Location = new System.Drawing.Point(240, 188);
            this.labelProjectDec.Name = "labelProjectDec";
            this.labelProjectDec.Size = new System.Drawing.Size(642, 89);
            this.labelProjectDec.TabIndex = 7;
            this.labelProjectDec.Text = "#";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(40, 188);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(200, 28);
            this.label4.TabIndex = 6;
            this.label4.Text = "Project Description:";
            // 
            // labelCustomerName
            // 
            this.labelCustomerName.AutoSize = true;
            this.labelCustomerName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.labelCustomerName.Location = new System.Drawing.Point(240, 298);
            this.labelCustomerName.Name = "labelCustomerName";
            this.labelCustomerName.Size = new System.Drawing.Size(23, 28);
            this.labelCustomerName.TabIndex = 5;
            this.labelCustomerName.Text = "#";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(44, 298);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(172, 28);
            this.label3.TabIndex = 3;
            this.label3.Text = "Customer Name:";
            // 
            // comboBox1ProjectCode
            // 
            this.comboBox1ProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.comboBox1ProjectCode.FormattingEnabled = true;
            this.comboBox1ProjectCode.IntegralHeight = false;
            this.comboBox1ProjectCode.Location = new System.Drawing.Point(244, 108);
            this.comboBox1ProjectCode.Name = "comboBox1ProjectCode";
            this.comboBox1ProjectCode.Size = new System.Drawing.Size(452, 36);
            this.comboBox1ProjectCode.TabIndex = 1;
            this.comboBox1ProjectCode.SelectedIndexChanged += new System.EventHandler(this.comboBox1ProjectCode_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(42, 111);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(139, 28);
            this.label1.TabIndex = 0;
            this.label1.Text = "Project Code:";
            // 
            // comboBoxLockRemarks
            // 
            this.comboBoxLockRemarks.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.comboBoxLockRemarks.FormattingEnabled = true;
            this.comboBoxLockRemarks.Items.AddRange(new object[] {
            "some remarks"});
            this.comboBoxLockRemarks.Location = new System.Drawing.Point(244, 518);
            this.comboBoxLockRemarks.Name = "comboBoxLockRemarks";
            this.comboBoxLockRemarks.Size = new System.Drawing.Size(452, 36);
            this.comboBoxLockRemarks.TabIndex = 17;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(42, 518);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 28);
            this.label2.TabIndex = 16;
            this.label2.Text = "Remarks";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_new_50;
            this.pictureBox3.Location = new System.Drawing.Point(706, 100);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(52, 51);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 20;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Visible = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_unlock_50;
            this.pictureBox2.Location = new System.Drawing.Point(706, 100);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(40, 48);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 19;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Visible = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_lock_50;
            this.pictureBox1.Location = new System.Drawing.Point(706, 100);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(40, 48);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 18;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(375, 8);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(168, 45);
            this.label8.TabIndex = 15;
            this.label8.Text = "LOCK / UNLOCK BOM";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.AutoSize = true;
            this.panel2.BackColor = System.Drawing.Color.Silver;
            this.panel2.Controls.Add(this.dataGridViewBOMLockLogs);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(12, 66);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1791, 997);
            this.panel2.TabIndex = 14;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // dataGridViewBOMLockLogs
            // 
            this.dataGridViewBOMLockLogs.BackgroundColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewBOMLockLogs.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewBOMLockLogs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewBOMLockLogs.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProjectCode,
            this.ProductNumber,
            this.ProductName,
            this.Qty,
            this.Cost,
            this.ActionMadeBy,
            this.Version,
            this.ProductCode,
            this.ProductCategory,
            this.ProjectBOMNumber,
            this.ProjectStatus,
            this.ItemCode,
            this.ActionType,
            this.CreatedDate,
            this.ProjectCost,
            this.ProjectIssuedCost});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewBOMLockLogs.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewBOMLockLogs.Location = new System.Drawing.Point(18, 169);
            this.dataGridViewBOMLockLogs.Name = "dataGridViewBOMLockLogs";
            this.dataGridViewBOMLockLogs.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewBOMLockLogs.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewBOMLockLogs.RowHeadersWidth = 82;
            this.dataGridViewBOMLockLogs.RowTemplate.Height = 28;
            this.dataGridViewBOMLockLogs.Size = new System.Drawing.Size(1755, 796);
            this.dataGridViewBOMLockLogs.TabIndex = 4;
            // 
            // ProjectCode
            // 
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProjectCode.DefaultCellStyle = dataGridViewCellStyle2;
            this.ProjectCode.HeaderText = "Project Code";
            this.ProjectCode.MinimumWidth = 8;
            this.ProjectCode.Name = "ProjectCode";
            this.ProjectCode.ReadOnly = true;
            this.ProjectCode.Width = 150;
            // 
            // ProductNumber
            // 
            this.ProductNumber.DefaultCellStyle = dataGridViewCellStyle2;
            this.ProductNumber.HeaderText = "Product Number";
            this.ProductNumber.MinimumWidth = 8;
            this.ProductNumber.Name = "ProductNumber";
            this.ProductNumber.ReadOnly = true;
            this.ProductNumber.Width = 150;
            // 
            // ProductName
            // 
            this.ProductName.DefaultCellStyle = dataGridViewCellStyle2;
            this.ProductName.HeaderText = "Product Name";
            this.ProductName.MinimumWidth = 8;
            this.ProductName.Name = "ProductName";
            this.ProductName.ReadOnly = true;
            this.ProductName.Width = 150;
            // 
            // Qty
            // 
            this.Qty.DefaultCellStyle = dataGridViewCellStyle2;
            this.Qty.HeaderText = "Qty";
            this.Qty.MinimumWidth = 8;
            this.Qty.Name = "Qty";
            this.Qty.ReadOnly = true;
            this.Qty.Width = 150;
            // 
            // Cost
            // 
            this.Cost.DefaultCellStyle = dataGridViewCellStyle2;
            this.Cost.HeaderText = "Cost";
            this.Cost.MinimumWidth = 8;
            this.Cost.Name = "Cost";
            this.Cost.ReadOnly = true;
            this.Cost.Width = 150;
            // 
            // ActionMadeBy
            // 
            this.ActionMadeBy.DefaultCellStyle = dataGridViewCellStyle2;
            this.ActionMadeBy.HeaderText = "Action MadeBy";
            this.ActionMadeBy.MinimumWidth = 8;
            this.ActionMadeBy.Name = "ActionMadeBy";
            this.ActionMadeBy.ReadOnly = true;
            this.ActionMadeBy.Width = 150;
            // 
            // Version
            // 
            this.Version.DefaultCellStyle = dataGridViewCellStyle2;
            this.Version.HeaderText = "Version";
            this.Version.MinimumWidth = 8;
            this.Version.Name = "Version";
            this.Version.ReadOnly = true;
            this.Version.Width = 150;
            // 
            // ProductCode
            // 
            this.ProductCode.DefaultCellStyle = dataGridViewCellStyle2;
            this.ProductCode.HeaderText = "Product Code";
            this.ProductCode.MinimumWidth = 8;
            this.ProductCode.Name = "ProductCode";
            this.ProductCode.ReadOnly = true;
            this.ProductCode.Width = 150;
            // 
            // ProductCategory
            // 
            this.ProductCategory.DefaultCellStyle = dataGridViewCellStyle2;
            this.ProductCategory.HeaderText = "Product Category";
            this.ProductCategory.MinimumWidth = 8;
            this.ProductCategory.Name = "ProductCategory";
            this.ProductCategory.ReadOnly = true;
            this.ProductCategory.Width = 150;
            // 
            // ProjectBOMNumber
            // 
            this.ProjectBOMNumber.DefaultCellStyle = dataGridViewCellStyle2;
            this.ProjectBOMNumber.HeaderText = "Project BOM Number";
            this.ProjectBOMNumber.MinimumWidth = 8;
            this.ProjectBOMNumber.Name = "ProjectBOMNumber";
            this.ProjectBOMNumber.ReadOnly = true;
            this.ProjectBOMNumber.Width = 150;
            // 
            // ProjectStatus
            // 
            this.ProjectStatus.DefaultCellStyle = dataGridViewCellStyle2;
            this.ProjectStatus.HeaderText = "Project Status";
            this.ProjectStatus.MinimumWidth = 8;
            this.ProjectStatus.Name = "ProjectStatus";
            this.ProjectStatus.ReadOnly = true;
            this.ProjectStatus.Width = 150;
            // 
            // ItemCode
            // 
            this.ItemCode.DefaultCellStyle = dataGridViewCellStyle2;
            this.ItemCode.HeaderText = "Item Code";
            this.ItemCode.MinimumWidth = 8;
            this.ItemCode.Name = "ItemCode";
            this.ItemCode.ReadOnly = true;
            this.ItemCode.Width = 150;
            // 
            // ActionType
            // 
            this.ActionType.DefaultCellStyle = dataGridViewCellStyle2;
            this.ActionType.HeaderText = "Action Type";
            this.ActionType.MinimumWidth = 8;
            this.ActionType.Name = "ActionType";
            this.ActionType.ReadOnly = true;
            this.ActionType.Width = 150;
            // 
            // CreatedDate
            // 
            this.CreatedDate.DefaultCellStyle = dataGridViewCellStyle2;
            this.CreatedDate.HeaderText = "Created Date";
            this.CreatedDate.MinimumWidth = 8;
            this.CreatedDate.Name = "CreatedDate";
            this.CreatedDate.ReadOnly = true;
            this.CreatedDate.Width = 150;
            // 
            // ProjectCost
            // 
            this.ProjectCost.DefaultCellStyle = dataGridViewCellStyle2;
            this.ProjectCost.HeaderText = "Project Cost";
            this.ProjectCost.MinimumWidth = 8;
            this.ProjectCost.Name = "ProjectCost";
            this.ProjectCost.ReadOnly = true;
            this.ProjectCost.Width = 150;
            // 
            // ProjectIssuedCost
            // 
            this.ProjectIssuedCost.DefaultCellStyle = dataGridViewCellStyle2;
            this.ProjectIssuedCost.HeaderText = "Issued Cost";
            this.ProjectIssuedCost.MinimumWidth = 8;
            this.ProjectIssuedCost.Name = "ProjectIssuedCost";
            this.ProjectIssuedCost.ReadOnly = true;
            this.ProjectIssuedCost.Width = 150;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.LightGray;
            this.panel3.Controls.Add(this.Exportbutton);
            this.panel3.Controls.Add(this.FilterApplybutton);
            this.panel3.Controls.Add(this.comboBox1Remarks);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.ClearFilter);
            this.panel3.Controls.Add(this.dateTimePickerLogTo);
            this.panel3.Controls.Add(this.dateTimePickerLogFrom);
            this.panel3.Controls.Add(this.comboBoxLogUser);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.comboBoxLogProjectCode);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Location = new System.Drawing.Point(17, 28);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1756, 120);
            this.panel3.TabIndex = 3;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // Exportbutton
            // 
            this.Exportbutton.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.Exportbutton.Location = new System.Drawing.Point(1568, 40);
            this.Exportbutton.Name = "Exportbutton";
            this.Exportbutton.Size = new System.Drawing.Size(160, 47);
            this.Exportbutton.TabIndex = 13;
            this.Exportbutton.Text = "Export";
            this.Exportbutton.UseVisualStyleBackColor = true;
            this.Exportbutton.Click += new System.EventHandler(this.Exportbutton_Click);
            // 
            // FilterApplybutton
            // 
            this.FilterApplybutton.BackColor = System.Drawing.Color.White;
            this.FilterApplybutton.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.FilterApplybutton.Location = new System.Drawing.Point(1249, 68);
            this.FilterApplybutton.Name = "FilterApplybutton";
            this.FilterApplybutton.Size = new System.Drawing.Size(160, 43);
            this.FilterApplybutton.TabIndex = 12;
            this.FilterApplybutton.Text = "Apply Filter";
            this.FilterApplybutton.UseVisualStyleBackColor = false;
            this.FilterApplybutton.Click += new System.EventHandler(this.FilterApplybutton_Click);
            // 
            // comboBox1Remarks
            // 
            this.comboBox1Remarks.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.comboBox1Remarks.FormattingEnabled = true;
            this.comboBox1Remarks.Items.AddRange(new object[] {
            "Log Remarks"});
            this.comboBox1Remarks.Location = new System.Drawing.Point(771, 72);
            this.comboBox1Remarks.Name = "comboBox1Remarks";
            this.comboBox1Remarks.Size = new System.Drawing.Size(436, 36);
            this.comboBox1Remarks.TabIndex = 11;
            this.comboBox1Remarks.Visible = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label12.Location = new System.Drawing.Point(637, 75);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(101, 28);
            this.label12.TabIndex = 10;
            this.label12.Text = "Remarks:";
            this.label12.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(637, 14);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(128, 28);
            this.label7.TabIndex = 9;
            this.label7.Text = "Date Range:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label11.Location = new System.Drawing.Point(989, 15);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(18, 28);
            this.label11.TabIndex = 8;
            this.label11.Text = ":";
            // 
            // ClearFilter
            // 
            this.ClearFilter.BackColor = System.Drawing.Color.White;
            this.ClearFilter.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.ClearFilter.Location = new System.Drawing.Point(1249, 11);
            this.ClearFilter.Name = "ClearFilter";
            this.ClearFilter.Size = new System.Drawing.Size(160, 47);
            this.ClearFilter.TabIndex = 7;
            this.ClearFilter.Text = "Clear Filter";
            this.ClearFilter.UseVisualStyleBackColor = false;
            this.ClearFilter.Click += new System.EventHandler(this.ClearFilter_Click);
            // 
            // dateTimePickerLogTo
            // 
            this.dateTimePickerLogTo.Location = new System.Drawing.Point(1013, 17);
            this.dateTimePickerLogTo.Name = "dateTimePickerLogTo";
            this.dateTimePickerLogTo.Size = new System.Drawing.Size(194, 26);
            this.dateTimePickerLogTo.TabIndex = 6;
            // 
            // dateTimePickerLogFrom
            // 
            this.dateTimePickerLogFrom.Location = new System.Drawing.Point(771, 16);
            this.dateTimePickerLogFrom.Name = "dateTimePickerLogFrom";
            this.dateTimePickerLogFrom.Size = new System.Drawing.Size(212, 26);
            this.dateTimePickerLogFrom.TabIndex = 5;
            // 
            // comboBoxLogUser
            // 
            this.comboBoxLogUser.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.comboBoxLogUser.FormattingEnabled = true;
            this.comboBoxLogUser.IntegralHeight = false;
            this.comboBoxLogUser.Location = new System.Drawing.Point(148, 72);
            this.comboBoxLogUser.Name = "comboBoxLogUser";
            this.comboBoxLogUser.Size = new System.Drawing.Size(463, 36);
            this.comboBoxLogUser.TabIndex = 4;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label10.Location = new System.Drawing.Point(3, 75);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(62, 28);
            this.label10.TabIndex = 3;
            this.label10.Text = "User:";
            // 
            // comboBoxLogProjectCode
            // 
            this.comboBoxLogProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.comboBoxLogProjectCode.FormattingEnabled = true;
            this.comboBoxLogProjectCode.IntegralHeight = false;
            this.comboBoxLogProjectCode.Location = new System.Drawing.Point(148, 11);
            this.comboBoxLogProjectCode.Name = "comboBoxLogProjectCode";
            this.comboBoxLogProjectCode.Size = new System.Drawing.Size(463, 36);
            this.comboBoxLogProjectCode.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label9.Location = new System.Drawing.Point(3, 14);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(139, 28);
            this.label9.TabIndex = 2;
            this.label9.Text = "Project Code:";
            // 
            // LOGSButton
            // 
            this.LOGSButton.BackColor = System.Drawing.Color.White;
            this.LOGSButton.Font = new System.Drawing.Font("Calibri", 9.25F, System.Drawing.FontStyle.Bold);
            this.LOGSButton.Location = new System.Drawing.Point(15, 14);
            this.LOGSButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.LOGSButton.Name = "LOGSButton";
            this.LOGSButton.Size = new System.Drawing.Size(178, 44);
            this.LOGSButton.TabIndex = 2;
            this.LOGSButton.Text = "LOGS";
            this.LOGSButton.UseVisualStyleBackColor = false;
            this.LOGSButton.Click += new System.EventHandler(this.LOGSButton_Click);
            // 
            // BOMChangesLogs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1958, 1097);
            this.Controls.Add(this.LOGSButton);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "BOMChangesLogs";
            this.Text = "Project BOM Changes Logs";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmIndent_FormClosing);
            this.Load += new System.EventHandler(this.LockBOM_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBOMLockLogs)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1ProjectCode;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelCustomerName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelProjectDec;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox checkBox1BlockNow;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button button2Lock;
        private System.Windows.Forms.Button button1Exit;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.ComboBox comboBoxLockRemarks;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button LOGSButton;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comboBoxLogProjectCode;
        private System.Windows.Forms.DataGridView dataGridViewBOMLockLogs;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button ClearFilter;
        private System.Windows.Forms.DateTimePicker dateTimePickerLogTo;
        private System.Windows.Forms.DateTimePicker dateTimePickerLogFrom;
        private System.Windows.Forms.ComboBox comboBoxLogUser;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboBox1Remarks;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button FilterApplybutton;
        private System.Windows.Forms.Label openingDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Qty;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cost;
        private System.Windows.Forms.DataGridViewTextBoxColumn ActionMadeBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn Version;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductCategory;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectBOMNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ActionType;
        private System.Windows.Forms.DataGridViewTextBoxColumn CreatedDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectIssuedCost;
        private System.Windows.Forms.Button Exportbutton;
    }
}