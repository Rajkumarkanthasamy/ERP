﻿
namespace Erp_Project_With_Buttons.AssetMaster
{
    partial class frmAssetmaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAssetmaster));
            this.cmbAssetsgroup = new System.Windows.Forms.ComboBox();
            this.label55 = new System.Windows.Forms.Label();
            this.cmbAssetNature = new System.Windows.Forms.ComboBox();
            this.cmbVendor = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtCapexNo = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.lblProjecttype = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbLedgerinTally = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dtpVoucherdate = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbCostCenter4 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtVoucherNo = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtPlanNo = new System.Windows.Forms.TextBox();
            this.txtAssetDesc = new System.Windows.Forms.TextBox();
            this.txtQuantity = new System.Windows.Forms.TextBox();
            this.txtUOM = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txtPersonUser = new System.Windows.Forms.TextBox();
            this.txtInvoicenodate = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtLifeofasset = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.dtpDateofCapitalizaton = new System.Windows.Forms.DateTimePicker();
            this.label16 = new System.Windows.Forms.Label();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.cmbAssetSLNO = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.chkloadOldAsset = new System.Windows.Forms.CheckBox();
            this.dtpDateofDeletion = new System.Windows.Forms.DateTimePicker();
            this.label21 = new System.Windows.Forms.Label();
            this.txtProjectcode = new System.Windows.Forms.ComboBox();
            this.chkdeletedate = new System.Windows.Forms.CheckBox();
            this.cmbDepLedgerinTally = new System.Windows.Forms.TextBox();
            this.txtLocation = new System.Windows.Forms.ComboBox();
            this.btnDocUpload = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.txtDeletionRemarks = new System.Windows.Forms.TextBox();
            this.pnDelete = new System.Windows.Forms.Panel();
            this.cmbAssetBarcode = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.btnPrint = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnDownloadQRCode = new System.Windows.Forms.Button();
            this.txtvrfRemarks = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.dtpDateofVerification = new System.Windows.Forms.DateTimePicker();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.cmbCostCenter1 = new System.Windows.Forms.ComboBox();
            this.cmbCostCenter2 = new System.Windows.Forms.ComboBox();
            this.cmbCostCenter3 = new System.Windows.Forms.ComboBox();
            this.txtPct1 = new System.Windows.Forms.TextBox();
            this.txtPct2 = new System.Windows.Forms.TextBox();
            this.txtPct3 = new System.Windows.Forms.TextBox();
            this.txtPct4 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.pnDelete.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbAssetsgroup
            // 
            this.cmbAssetsgroup.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbAssetsgroup.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbAssetsgroup.DropDownHeight = 130;
            this.cmbAssetsgroup.DropDownWidth = 279;
            this.cmbAssetsgroup.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbAssetsgroup.FormattingEnabled = true;
            this.cmbAssetsgroup.IntegralHeight = false;
            this.cmbAssetsgroup.Location = new System.Drawing.Point(148, 226);
            this.cmbAssetsgroup.Name = "cmbAssetsgroup";
            this.cmbAssetsgroup.Size = new System.Drawing.Size(294, 26);
            this.cmbAssetsgroup.TabIndex = 121;
            this.cmbAssetsgroup.SelectedValueChanged += new System.EventHandler(this.cmbAssetsgroup_SelectedValueChanged);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.ForeColor = System.Drawing.Color.Black;
            this.label55.Location = new System.Drawing.Point(35, 228);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(106, 19);
            this.label55.TabIndex = 139;
            this.label55.Text = "Assets Group :";
            // 
            // cmbAssetNature
            // 
            this.cmbAssetNature.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbAssetNature.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbAssetNature.DropDownHeight = 130;
            this.cmbAssetNature.DropDownWidth = 279;
            this.cmbAssetNature.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbAssetNature.FormattingEnabled = true;
            this.cmbAssetNature.IntegralHeight = false;
            this.cmbAssetNature.Location = new System.Drawing.Point(149, 262);
            this.cmbAssetNature.Name = "cmbAssetNature";
            this.cmbAssetNature.Size = new System.Drawing.Size(295, 26);
            this.cmbAssetNature.TabIndex = 120;
            // 
            // cmbVendor
            // 
            this.cmbVendor.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbVendor.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbVendor.DropDownHeight = 130;
            this.cmbVendor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbVendor.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.cmbVendor.FormattingEnabled = true;
            this.cmbVendor.IntegralHeight = false;
            this.cmbVendor.Location = new System.Drawing.Point(616, 15);
            this.cmbVendor.Name = "cmbVendor";
            this.cmbVendor.Size = new System.Drawing.Size(294, 26);
            this.cmbVendor.TabIndex = 123;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(476, 22);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(110, 19);
            this.label12.TabIndex = 135;
            this.label12.Text = "Vendor Name :\t";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(30, 267);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(111, 19);
            this.label11.TabIndex = 134;
            this.label11.Text = "Assets Nature :";
            // 
            // txtCapexNo
            // 
            this.txtCapexNo.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtCapexNo.Location = new System.Drawing.Point(148, 188);
            this.txtCapexNo.Name = "txtCapexNo";
            this.txtCapexNo.Size = new System.Drawing.Size(295, 26);
            this.txtCapexNo.TabIndex = 117;
            this.txtCapexNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCapexNo_KeyPress);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(59, 188);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(81, 19);
            this.label10.TabIndex = 133;
            this.label10.Text = "Capex No :";
            // 
            // lblProjecttype
            // 
            this.lblProjecttype.AutoSize = true;
            this.lblProjecttype.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjecttype.ForeColor = System.Drawing.Color.Black;
            this.lblProjecttype.Location = new System.Drawing.Point(71, 112);
            this.lblProjecttype.Name = "lblProjecttype";
            this.lblProjecttype.Size = new System.Drawing.Size(71, 19);
            this.lblProjecttype.TabIndex = 130;
            this.lblProjecttype.Text = "Plan No :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(7, 307);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(134, 19);
            this.label4.TabIndex = 128;
            this.label4.Text = "Asset Description :";
            // 
            // cmbLedgerinTally
            // 
            this.cmbLedgerinTally.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbLedgerinTally.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbLedgerinTally.DropDownHeight = 130;
            this.cmbLedgerinTally.DropDownWidth = 279;
            this.cmbLedgerinTally.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbLedgerinTally.FormattingEnabled = true;
            this.cmbLedgerinTally.IntegralHeight = false;
            this.cmbLedgerinTally.Location = new System.Drawing.Point(611, 165);
            this.cmbLedgerinTally.Name = "cmbLedgerinTally";
            this.cmbLedgerinTally.Size = new System.Drawing.Size(299, 26);
            this.cmbLedgerinTally.TabIndex = 144;
            this.cmbLedgerinTally.SelectedIndexChanged += new System.EventHandler(this.cmbLedgerinTally_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(470, 167);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 19);
            this.label1.TabIndex = 162;
            this.label1.Text = "Ledger in Tally :";
            // 
            // dtpVoucherdate
            // 
            this.dtpVoucherdate.CustomFormat = "";
            this.dtpVoucherdate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpVoucherdate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpVoucherdate.Location = new System.Drawing.Point(611, 119);
            this.dtpVoucherdate.Name = "dtpVoucherdate";
            this.dtpVoucherdate.Size = new System.Drawing.Size(88, 26);
            this.dtpVoucherdate.TabIndex = 141;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(476, 124);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 19);
            this.label3.TabIndex = 160;
            this.label3.Text = "Voucher Date :";
            // 
            // cmbCostCenter4
            // 
            this.cmbCostCenter4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbCostCenter4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCostCenter4.DropDownHeight = 130;
            this.cmbCostCenter4.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.cmbCostCenter4.FormattingEnabled = true;
            this.cmbCostCenter4.IntegralHeight = false;
            this.cmbCostCenter4.Location = new System.Drawing.Point(629, 243);
            this.cmbCostCenter4.Name = "cmbCostCenter4";
            this.cmbCostCenter4.Size = new System.Drawing.Size(155, 26);
            this.cmbCostCenter4.TabIndex = 146;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(484, 248);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(111, 36);
            this.label7.TabIndex = 158;
            this.label7.Text = "Cost Centre1* :\r\n(% of Allocation)\t";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(59, 360);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 19);
            this.label8.TabIndex = 157;
            this.label8.Text = "Quantity :";
            // 
            // txtVoucherNo
            // 
            this.txtVoucherNo.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtVoucherNo.Location = new System.Drawing.Point(616, 82);
            this.txtVoucherNo.Name = "txtVoucherNo";
            this.txtVoucherNo.Size = new System.Drawing.Size(295, 26);
            this.txtVoucherNo.TabIndex = 140;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(476, 84);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(97, 19);
            this.label9.TabIndex = 156;
            this.label9.Text = "Voucher No :";
            // 
            // txtPlanNo
            // 
            this.txtPlanNo.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtPlanNo.Location = new System.Drawing.Point(148, 110);
            this.txtPlanNo.Name = "txtPlanNo";
            this.txtPlanNo.Size = new System.Drawing.Size(295, 26);
            this.txtPlanNo.TabIndex = 163;
            // 
            // txtAssetDesc
            // 
            this.txtAssetDesc.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtAssetDesc.Location = new System.Drawing.Point(149, 300);
            this.txtAssetDesc.Multiline = true;
            this.txtAssetDesc.Name = "txtAssetDesc";
            this.txtAssetDesc.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtAssetDesc.Size = new System.Drawing.Size(295, 45);
            this.txtAssetDesc.TabIndex = 164;
            // 
            // txtQuantity
            // 
            this.txtQuantity.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtQuantity.Location = new System.Drawing.Point(149, 353);
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Size = new System.Drawing.Size(100, 26);
            this.txtQuantity.TabIndex = 165;
            this.txtQuantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQuantity_KeyPress);
            // 
            // txtUOM
            // 
            this.txtUOM.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtUOM.Location = new System.Drawing.Point(354, 358);
            this.txtUOM.Name = "txtUOM";
            this.txtUOM.Size = new System.Drawing.Size(73, 26);
            this.txtUOM.TabIndex = 167;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(282, 360);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(52, 19);
            this.label18.TabIndex = 166;
            this.label18.Text = "UOM :";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(61, 397);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(75, 19);
            this.label19.TabIndex = 168;
            this.label19.Text = "Location :";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(38, 429);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(98, 19);
            this.label20.TabIndex = 170;
            this.label20.Text = "Person User :";
            // 
            // txtPersonUser
            // 
            this.txtPersonUser.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtPersonUser.Location = new System.Drawing.Point(148, 422);
            this.txtPersonUser.Name = "txtPersonUser";
            this.txtPersonUser.Size = new System.Drawing.Size(268, 26);
            this.txtPersonUser.TabIndex = 171;
            // 
            // txtInvoicenodate
            // 
            this.txtInvoicenodate.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtInvoicenodate.Location = new System.Drawing.Point(616, 50);
            this.txtInvoicenodate.Name = "txtInvoicenodate";
            this.txtInvoicenodate.Size = new System.Drawing.Size(268, 26);
            this.txtInvoicenodate.TabIndex = 173;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(476, 52);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(139, 19);
            this.label5.TabIndex = 172;
            this.label5.Text = "Invoice No n Date :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(461, 201);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 38);
            this.label2.TabIndex = 175;
            this.label2.Text = "Department Ledger\r\n in Tally :";
            // 
            // txtLifeofasset
            // 
            this.txtLifeofasset.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtLifeofasset.Location = new System.Drawing.Point(870, 119);
            this.txtLifeofasset.Name = "txtLifeofasset";
            this.txtLifeofasset.Size = new System.Drawing.Size(100, 26);
            this.txtLifeofasset.TabIndex = 177;
            this.txtLifeofasset.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLifeofasset_KeyPress);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(748, 116);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(99, 38);
            this.label15.TabIndex = 176;
            this.label15.Text = "Life of Asset :\r\n(In Months)";
            // 
            // dtpDateofCapitalizaton
            // 
            this.dtpDateofCapitalizaton.CustomFormat = "";
            this.dtpDateofCapitalizaton.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDateofCapitalizaton.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDateofCapitalizaton.Location = new System.Drawing.Point(629, 414);
            this.dtpDateofCapitalizaton.Name = "dtpDateofCapitalizaton";
            this.dtpDateofCapitalizaton.Size = new System.Drawing.Size(88, 26);
            this.dtpDateofCapitalizaton.TabIndex = 178;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(461, 416);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(160, 19);
            this.label16.TabIndex = 179;
            this.label16.Text = "Date of Capitalizaton :";
            // 
            // txtAmount
            // 
            this.txtAmount.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtAmount.Location = new System.Drawing.Point(838, 419);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(100, 26);
            this.txtAmount.TabIndex = 181;
            this.txtAmount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAmount_KeyPress);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(759, 419);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(73, 19);
            this.label17.TabIndex = 180;
            this.label17.Text = "Amount :";
            // 
            // txtRemarks
            // 
            this.txtRemarks.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtRemarks.Location = new System.Drawing.Point(591, 463);
            this.txtRemarks.Multiline = true;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRemarks.Size = new System.Drawing.Size(245, 45);
            this.txtRemarks.TabIndex = 183;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(498, 475);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 19);
            this.label6.TabIndex = 182;
            this.label6.Text = "Remarks :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(38, 151);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(104, 19);
            this.label13.TabIndex = 184;
            this.label13.Text = "Project Code :";
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(1149, 516);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(114, 38);
            this.btnExit.TabIndex = 187;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(898, 516);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(114, 38);
            this.btnSave.TabIndex = 186;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // cmbAssetSLNO
            // 
            this.cmbAssetSLNO.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbAssetSLNO.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbAssetSLNO.DropDownHeight = 130;
            this.cmbAssetSLNO.Enabled = false;
            this.cmbAssetSLNO.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.cmbAssetSLNO.FormattingEnabled = true;
            this.cmbAssetSLNO.IntegralHeight = false;
            this.cmbAssetSLNO.Location = new System.Drawing.Point(147, 36);
            this.cmbAssetSLNO.Name = "cmbAssetSLNO";
            this.cmbAssetSLNO.Size = new System.Drawing.Size(294, 26);
            this.cmbAssetSLNO.TabIndex = 188;
            this.cmbAssetSLNO.SelectedIndexChanged += new System.EventHandler(this.cmbAssetSLNO_SelectedIndexChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(43, 41);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(93, 19);
            this.label14.TabIndex = 189;
            this.label14.Text = "Asset Sl No :\t";
            // 
            // chkloadOldAsset
            // 
            this.chkloadOldAsset.AutoSize = true;
            this.chkloadOldAsset.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkloadOldAsset.ForeColor = System.Drawing.Color.Black;
            this.chkloadOldAsset.Location = new System.Drawing.Point(193, -2);
            this.chkloadOldAsset.Name = "chkloadOldAsset";
            this.chkloadOldAsset.Size = new System.Drawing.Size(129, 23);
            this.chkloadOldAsset.TabIndex = 215;
            this.chkloadOldAsset.Text = "Load Old Asset";
            this.chkloadOldAsset.UseVisualStyleBackColor = true;
            this.chkloadOldAsset.CheckedChanged += new System.EventHandler(this.chkloadOldAsset_CheckedChanged);
            // 
            // dtpDateofDeletion
            // 
            this.dtpDateofDeletion.CustomFormat = "";
            this.dtpDateofDeletion.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDateofDeletion.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDateofDeletion.Location = new System.Drawing.Point(157, 39);
            this.dtpDateofDeletion.Name = "dtpDateofDeletion";
            this.dtpDateofDeletion.Size = new System.Drawing.Size(88, 26);
            this.dtpDateofDeletion.TabIndex = 216;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(29, 39);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(128, 19);
            this.label21.TabIndex = 217;
            this.label21.Text = "Date of Deletion :";
            // 
            // txtProjectcode
            // 
            this.txtProjectcode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtProjectcode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txtProjectcode.DropDownHeight = 130;
            this.txtProjectcode.DropDownWidth = 279;
            this.txtProjectcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProjectcode.FormattingEnabled = true;
            this.txtProjectcode.IntegralHeight = false;
            this.txtProjectcode.Location = new System.Drawing.Point(147, 149);
            this.txtProjectcode.Name = "txtProjectcode";
            this.txtProjectcode.Size = new System.Drawing.Size(295, 26);
            this.txtProjectcode.TabIndex = 218;
            this.txtProjectcode.SelectedIndexChanged += new System.EventHandler(this.txtProjectcode_SelectedIndexChanged);
            // 
            // chkdeletedate
            // 
            this.chkdeletedate.AutoSize = true;
            this.chkdeletedate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkdeletedate.ForeColor = System.Drawing.Color.Black;
            this.chkdeletedate.Location = new System.Drawing.Point(156, 10);
            this.chkdeletedate.Name = "chkdeletedate";
            this.chkdeletedate.Size = new System.Drawing.Size(162, 23);
            this.chkdeletedate.TabIndex = 219;
            this.chkdeletedate.Text = "Update Delete Date";
            this.chkdeletedate.UseVisualStyleBackColor = true;
            // 
            // cmbDepLedgerinTally
            // 
            this.cmbDepLedgerinTally.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDepLedgerinTally.Location = new System.Drawing.Point(611, 206);
            this.cmbDepLedgerinTally.Name = "cmbDepLedgerinTally";
            this.cmbDepLedgerinTally.ReadOnly = true;
            this.cmbDepLedgerinTally.Size = new System.Drawing.Size(247, 26);
            this.cmbDepLedgerinTally.TabIndex = 220;
            // 
            // txtLocation
            // 
            this.txtLocation.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtLocation.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txtLocation.DropDownHeight = 130;
            this.txtLocation.DropDownWidth = 279;
            this.txtLocation.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLocation.FormattingEnabled = true;
            this.txtLocation.IntegralHeight = false;
            this.txtLocation.Items.AddRange(new object[] {
            "Admin Area",
            "Product Service Dept",
            "Test Lap",
            "Common Area",
            "Shop floor",
            "Sales Department",
            "R&D Lab",
            "Stores",
            "Chennai Office"});
            this.txtLocation.Location = new System.Drawing.Point(148, 390);
            this.txtLocation.Name = "txtLocation";
            this.txtLocation.Size = new System.Drawing.Size(293, 26);
            this.txtLocation.TabIndex = 221;
            // 
            // btnDocUpload
            // 
            this.btnDocUpload.BackColor = System.Drawing.Color.PaleGreen;
            this.btnDocUpload.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDocUpload.Location = new System.Drawing.Point(662, 516);
            this.btnDocUpload.Name = "btnDocUpload";
            this.btnDocUpload.Size = new System.Drawing.Size(170, 32);
            this.btnDocUpload.TabIndex = 224;
            this.btnDocUpload.TabStop = false;
            this.btnDocUpload.Text = "Document Upload\r\n";
            this.btnDocUpload.UseVisualStyleBackColor = false;
            this.btnDocUpload.Visible = false;
            this.btnDocUpload.Click += new System.EventHandler(this.btnDocUpload_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Black;
            this.label22.Location = new System.Drawing.Point(2, 73);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(154, 19);
            this.label22.TabIndex = 225;
            this.label22.Text = "Remarks of Deletion :";
            // 
            // txtDeletionRemarks
            // 
            this.txtDeletionRemarks.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtDeletionRemarks.Location = new System.Drawing.Point(156, 71);
            this.txtDeletionRemarks.MaxLength = 255;
            this.txtDeletionRemarks.Multiline = true;
            this.txtDeletionRemarks.Name = "txtDeletionRemarks";
            this.txtDeletionRemarks.Size = new System.Drawing.Size(236, 58);
            this.txtDeletionRemarks.TabIndex = 226;
            // 
            // pnDelete
            // 
            this.pnDelete.Controls.Add(this.chkdeletedate);
            this.pnDelete.Controls.Add(this.txtDeletionRemarks);
            this.pnDelete.Controls.Add(this.label21);
            this.pnDelete.Controls.Add(this.label22);
            this.pnDelete.Controls.Add(this.dtpDateofDeletion);
            this.pnDelete.Location = new System.Drawing.Point(870, 257);
            this.pnDelete.Name = "pnDelete";
            this.pnDelete.Size = new System.Drawing.Size(404, 139);
            this.pnDelete.TabIndex = 227;
            // 
            // cmbAssetBarcode
            // 
            this.cmbAssetBarcode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbAssetBarcode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbAssetBarcode.DropDownHeight = 130;
            this.cmbAssetBarcode.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.cmbAssetBarcode.FormattingEnabled = true;
            this.cmbAssetBarcode.IntegralHeight = false;
            this.cmbAssetBarcode.Location = new System.Drawing.Point(147, 74);
            this.cmbAssetBarcode.Name = "cmbAssetBarcode";
            this.cmbAssetBarcode.Size = new System.Drawing.Size(294, 26);
            this.cmbAssetBarcode.TabIndex = 228;
            this.cmbAssetBarcode.SelectedIndexChanged += new System.EventHandler(this.cmbAssetBarcode_SelectedIndexChanged);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Black;
            this.label23.Location = new System.Drawing.Point(27, 76);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(113, 19);
            this.label23.TabIndex = 229;
            this.label23.Text = "Asset Barcode :\t";
            // 
            // btnPrint
            // 
            this.btnPrint.Enabled = false;
            this.btnPrint.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrint.Location = new System.Drawing.Point(1020, 516);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(114, 38);
            this.btnPrint.TabIndex = 230;
            this.btnPrint.Text = "Print";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(1045, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(200, 201);
            this.pictureBox1.TabIndex = 231;
            this.pictureBox1.TabStop = false;
            // 
            // btnDownloadQRCode
            // 
            this.btnDownloadQRCode.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDownloadQRCode.Location = new System.Drawing.Point(1094, 209);
            this.btnDownloadQRCode.Name = "btnDownloadQRCode";
            this.btnDownloadQRCode.Size = new System.Drawing.Size(151, 38);
            this.btnDownloadQRCode.TabIndex = 233;
            this.btnDownloadQRCode.Text = "Save QR Code";
            this.btnDownloadQRCode.UseVisualStyleBackColor = true;
            this.btnDownloadQRCode.Visible = false;
            this.btnDownloadQRCode.Click += new System.EventHandler(this.btnDownloadQRCode_Click);
            // 
            // txtvrfRemarks
            // 
            this.txtvrfRemarks.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtvrfRemarks.Location = new System.Drawing.Point(149, 454);
            this.txtvrfRemarks.Multiline = true;
            this.txtvrfRemarks.Name = "txtvrfRemarks";
            this.txtvrfRemarks.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtvrfRemarks.Size = new System.Drawing.Size(224, 49);
            this.txtvrfRemarks.TabIndex = 234;
            this.txtvrfRemarks.Visible = false;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Black;
            this.label24.Location = new System.Drawing.Point(42, 465);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(98, 38);
            this.label24.TabIndex = 235;
            this.label24.Text = "Verification  :\r\nRemarks";
            this.label24.Visible = false;
            // 
            // dtpDateofVerification
            // 
            this.dtpDateofVerification.CustomFormat = "";
            this.dtpDateofVerification.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDateofVerification.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDateofVerification.Location = new System.Drawing.Point(532, 516);
            this.dtpDateofVerification.Name = "dtpDateofVerification";
            this.dtpDateofVerification.Size = new System.Drawing.Size(98, 26);
            this.dtpDateofVerification.TabIndex = 236;
            this.dtpDateofVerification.Visible = false;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(396, 516);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(130, 19);
            this.label25.TabIndex = 237;
            this.label25.Text = "Verification Date :";
            this.label25.Visible = false;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Calibri", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.Black;
            this.label26.Location = new System.Drawing.Point(482, 286);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(111, 36);
            this.label26.TabIndex = 238;
            this.label26.Text = "Cost Centre2* :\r\n(% of Allocation)\t";
            // 
            // cmbCostCenter1
            // 
            this.cmbCostCenter1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbCostCenter1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCostCenter1.DropDownHeight = 130;
            this.cmbCostCenter1.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.cmbCostCenter1.FormattingEnabled = true;
            this.cmbCostCenter1.IntegralHeight = false;
            this.cmbCostCenter1.Location = new System.Drawing.Point(629, 284);
            this.cmbCostCenter1.Name = "cmbCostCenter1";
            this.cmbCostCenter1.Size = new System.Drawing.Size(155, 26);
            this.cmbCostCenter1.TabIndex = 241;
            // 
            // cmbCostCenter2
            // 
            this.cmbCostCenter2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbCostCenter2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCostCenter2.DropDownHeight = 130;
            this.cmbCostCenter2.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.cmbCostCenter2.FormattingEnabled = true;
            this.cmbCostCenter2.IntegralHeight = false;
            this.cmbCostCenter2.Location = new System.Drawing.Point(629, 325);
            this.cmbCostCenter2.Name = "cmbCostCenter2";
            this.cmbCostCenter2.Size = new System.Drawing.Size(155, 26);
            this.cmbCostCenter2.TabIndex = 242;
            // 
            // cmbCostCenter3
            // 
            this.cmbCostCenter3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbCostCenter3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCostCenter3.DropDownHeight = 130;
            this.cmbCostCenter3.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.cmbCostCenter3.FormattingEnabled = true;
            this.cmbCostCenter3.IntegralHeight = false;
            this.cmbCostCenter3.Location = new System.Drawing.Point(629, 365);
            this.cmbCostCenter3.Name = "cmbCostCenter3";
            this.cmbCostCenter3.Size = new System.Drawing.Size(155, 26);
            this.cmbCostCenter3.TabIndex = 243;
            // 
            // txtPct1
            // 
            this.txtPct1.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtPct1.Location = new System.Drawing.Point(790, 243);
            this.txtPct1.Name = "txtPct1";
            this.txtPct1.Size = new System.Drawing.Size(57, 26);
            this.txtPct1.TabIndex = 244;
            // 
            // txtPct2
            // 
            this.txtPct2.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtPct2.Location = new System.Drawing.Point(790, 284);
            this.txtPct2.Name = "txtPct2";
            this.txtPct2.Size = new System.Drawing.Size(57, 26);
            this.txtPct2.TabIndex = 245;
            // 
            // txtPct3
            // 
            this.txtPct3.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtPct3.Location = new System.Drawing.Point(790, 325);
            this.txtPct3.Name = "txtPct3";
            this.txtPct3.Size = new System.Drawing.Size(57, 26);
            this.txtPct3.TabIndex = 246;
            // 
            // txtPct4
            // 
            this.txtPct4.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtPct4.Location = new System.Drawing.Point(790, 365);
            this.txtPct4.Name = "txtPct4";
            this.txtPct4.Size = new System.Drawing.Size(57, 26);
            this.txtPct4.TabIndex = 247;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Calibri", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.Black;
            this.label29.Location = new System.Drawing.Point(477, 328);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(111, 36);
            this.label29.TabIndex = 248;
            this.label29.Text = "Cost Centre3* :\r\n(% of Allocation)\t";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Calibri", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.Black;
            this.label30.Location = new System.Drawing.Point(482, 368);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(111, 36);
            this.label30.TabIndex = 249;
            this.label30.Text = "Cost Centre4* :\r\n(% of Allocation)\t";
            // 
            // frmAssetmaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1275, 560);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.txtPct4);
            this.Controls.Add(this.txtPct3);
            this.Controls.Add(this.txtPct2);
            this.Controls.Add(this.txtPct1);
            this.Controls.Add(this.cmbCostCenter3);
            this.Controls.Add(this.cmbCostCenter2);
            this.Controls.Add(this.cmbCostCenter1);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.dtpDateofVerification);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.txtvrfRemarks);
            this.Controls.Add(this.btnDownloadQRCode);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.cmbAssetBarcode);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.pnDelete);
            this.Controls.Add(this.btnDocUpload);
            this.Controls.Add(this.txtLocation);
            this.Controls.Add(this.cmbDepLedgerinTally);
            this.Controls.Add(this.txtProjectcode);
            this.Controls.Add(this.chkloadOldAsset);
            this.Controls.Add(this.cmbAssetSLNO);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtRemarks);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtAmount);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.dtpDateofCapitalizaton);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.txtLifeofasset);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtInvoicenodate);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtPersonUser);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.txtUOM);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.txtQuantity);
            this.Controls.Add(this.txtAssetDesc);
            this.Controls.Add(this.txtPlanNo);
            this.Controls.Add(this.cmbLedgerinTally);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtpVoucherdate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmbCostCenter4);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtVoucherNo);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.cmbAssetsgroup);
            this.Controls.Add(this.label55);
            this.Controls.Add(this.cmbAssetNature);
            this.Controls.Add(this.cmbVendor);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtCapexNo);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.lblProjecttype);
            this.Controls.Add(this.label4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmAssetmaster";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Asset Master";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmAssetmaster_FormClosing);
            this.Load += new System.EventHandler(this.frmAssetmaster_Load);
            this.pnDelete.ResumeLayout(false);
            this.pnDelete.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbAssetsgroup;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.ComboBox cmbAssetNature;
        private System.Windows.Forms.ComboBox cmbVendor;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtCapexNo;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblProjecttype;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbLedgerinTally;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtpVoucherdate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbCostCenter4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtVoucherNo;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtPlanNo;
        private System.Windows.Forms.TextBox txtAssetDesc;
        private System.Windows.Forms.TextBox txtQuantity;
        private System.Windows.Forms.TextBox txtUOM;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtPersonUser;
        private System.Windows.Forms.TextBox txtInvoicenodate;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtLifeofasset;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DateTimePicker dtpDateofCapitalizaton;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.ComboBox cmbAssetSLNO;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.CheckBox chkloadOldAsset;
        private System.Windows.Forms.DateTimePicker dtpDateofDeletion;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox txtProjectcode;
        private System.Windows.Forms.CheckBox chkdeletedate;
        private System.Windows.Forms.TextBox cmbDepLedgerinTally;
        private System.Windows.Forms.ComboBox txtLocation;
        private System.Windows.Forms.Button btnDocUpload;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtDeletionRemarks;
        private System.Windows.Forms.Panel pnDelete;
        private System.Windows.Forms.ComboBox cmbAssetBarcode;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnDownloadQRCode;
        private System.Windows.Forms.TextBox txtvrfRemarks;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.DateTimePicker dtpDateofVerification;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ComboBox cmbCostCenter1;
        private System.Windows.Forms.ComboBox cmbCostCenter2;
        private System.Windows.Forms.ComboBox cmbCostCenter3;
        private System.Windows.Forms.TextBox txtPct1;
        private System.Windows.Forms.TextBox txtPct2;
        private System.Windows.Forms.TextBox txtPct3;
        private System.Windows.Forms.TextBox txtPct4;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
    }
}
