﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using EXCEL = Microsoft.Office.Interop.Excel;
namespace Erp_Project_With_Buttons.AssetMaster
{
    public partial class frmAssetmaster : Form
    {
        public frmAssetmaster()
        {
            InitializeComponent();
        }
        frmForm2 frm = new frmForm2();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        DataTable dtAssetSlNo = new DataTable();
        Login.frmLoginForm LoginForm = new Login.frmLoginForm();
        AssetMaster.AssetDocument asetdoc = new AssetMaster.AssetDocument();

        private void fnOnlynumber(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        DataTable dtLoadMasters = new DataTable();
        private void frmAssetmaster_Load(object sender, EventArgs e)
        {
            pnDelete.Visible = false;
            DataTable dtvendorList = DAL.fnVedorNameList(0, null).Tables[0];
            foreach (DataRow dr in dtvendorList.Rows)
            {
                if (!cmbVendor.Items.Contains(dr["VendorName"].ToString()))
                {
                    cmbVendor.Items.Add(dr["VendorName"].ToString());
                }
            }

            dtLoadAssetNoList = DAL.fnAssetmasterList(2, null).Tables[0];

            foreach (DataRow DR in dtLoadAssetNoList.Rows)
            {
                if (!cmbAssetBarcode.Items.Contains(DR["Asset Sl No"].ToString()))
                    cmbAssetBarcode.Items.Add(DR["Asset Sl No"].ToString());
            }


            dtLoadMasters = DAL.fnAssetmasterList(3, null).Tables[0];

            foreach (DataRow dr in dtLoadMasters.Rows)
            {
                if (!cmbAssetsgroup.Items.Contains(dr[0].ToString()))
                {
                    cmbAssetsgroup.Items.Add(dr[0].ToString());
                }
            }

            dtLoadMasters = DAL.fnAssetmasterList(4, null).Tables[0];

            foreach (DataRow dr in dtLoadMasters.Rows)
            {
                if (!cmbAssetNature.Items.Contains(dr[0].ToString()))
                {
                    cmbAssetNature.Items.Add(dr[0].ToString());
                }
            }

            dtLoadMasters = DAL.fnAssetmasterList(5, null).Tables[0];

            foreach (DataRow dr in dtLoadMasters.Rows)
            {
                if (!cmbLedgerinTally.Items.Contains(dr[0].ToString()))
                {
                    cmbLedgerinTally.Items.Add(dr[0].ToString());
                }
            }

            //dtLoadMasters = DAL.fnAssetmasterList(6, null).Tables[0];

            //foreach (DataRow dr in dtLoadMasters.Rows)
            //{
            //    if (!cmbDepLedgerinTally.Items.Contains(dr[0].ToString()))
            //    {
            //        cmbDepLedgerinTally.Items.Add(dr[0].ToString());
            //    }fnIAssetCostCentre
            //}

            //dtLoadMasters = DAL.fnAssetmasterList(7, null).Tables[0];
            dtLoadMasters = DAL.fnIAssetCostCentre(0, null).Tables[0];


            //cost centre1
            foreach (DataRow dr in dtLoadMasters.Rows)
            {
                if (!cmbCostCenter4.Items.Contains(dr[0].ToString()))
                {
                    cmbCostCenter4.Items.Add(dr[0].ToString());
                }
            }

            //cost centre2
            foreach (DataRow dr in dtLoadMasters.Rows)
            {
                if (!cmbCostCenter1.Items.Contains(dr[0].ToString()))
                {
                    cmbCostCenter1.Items.Add(dr[0].ToString());
                }
            }
            //cost centre3
            foreach (DataRow dr in dtLoadMasters.Rows)
            {
                if (!cmbCostCenter2.Items.Contains(dr[0].ToString()))
                {
                    cmbCostCenter2.Items.Add(dr[0].ToString());
                }
            }
            //cost centre4
            foreach (DataRow dr in dtLoadMasters.Rows)
            {
                if (!cmbCostCenter3.Items.Contains(dr[0].ToString()))
                {
                    cmbCostCenter3.Items.Add(dr[0].ToString());
                }
            }

            dtLoadMasters = DAL.fnAssetmasterList(8, null).Tables[0];

            foreach (DataRow dr in dtLoadMasters.Rows)
            {
                if (!txtProjectcode.Items.Contains(dr[0].ToString()))
                {
                    txtProjectcode.Items.Add(dr[0].ToString());
                }
            }
        }

        private void txtCapexNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber(sender, e);
        }

        private void txtQuantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber(sender, e);
        }

        private void txtAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber(sender, e);
        }

        private void txtLifeofasset_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber(sender, e);
        }
        private void fnClose()
        {
            this.Hide();
            frm.Show();
        }


        private void btnSave_Click(object sender, EventArgs e)
        {
            string sAssetbarcode = cmbAssetBarcode.Text;


            if (btnSave.Text == "Save")
            {
                dtAssetSlNo = DAL.fnAssetmasterList(0, null).Tables[0];

                if (dtAssetSlNo.Rows.Count > 0)
                {
                    string sAssetSlno = dtAssetSlNo.Rows[0][0].ToString();
                    sAssetSlno = sAssetSlno.Substring(02, 09);
                    //sDBOMNo = sDBOMID.Substring(03, 08);
                    int Slno = Convert.ToInt32(sAssetSlno);
                    Slno++;

                    if (cmbAssetBarcode.SelectedIndex < 0)
                    {
                        sAssetbarcode = "FA" + Slno;
                    }
                    else
                    {
                        sAssetbarcode = cmbAssetBarcode.Text;
                    }


                  
                    string costCenterData = "";

                    if (!string.IsNullOrWhiteSpace(cmbCostCenter4.Text) && !string.IsNullOrWhiteSpace(txtPct1.Text))
                        costCenterData += $"{cmbCostCenter4.Text}-{txtPct1.Text},";

                    if (!string.IsNullOrWhiteSpace(cmbCostCenter1.Text) && !string.IsNullOrWhiteSpace(txtPct2.Text))
                        costCenterData += $"{cmbCostCenter1.Text}-{txtPct2.Text},";

                    if (!string.IsNullOrWhiteSpace(cmbCostCenter2.Text) && !string.IsNullOrWhiteSpace(txtPct3.Text))
                        costCenterData += $"{cmbCostCenter2.Text}-{txtPct3.Text},";

                    if (!string.IsNullOrWhiteSpace(cmbCostCenter3.Text) && !string.IsNullOrWhiteSpace(txtPct4.Text))
                        costCenterData += $"{cmbCostCenter3.Text}-{txtPct4.Text},";

                    // Remove trailing comma
                    if (costCenterData.EndsWith(","))
                        costCenterData = costCenterData.TrimEnd(',');

                    GlobalClass.iSuccess = DAL.fnAddAssetmaster(1, "FA" + Slno, txtPlanNo.Text, txtProjectcode.Text, txtCapexNo.Text, cmbAssetsgroup.Text, cmbAssetNature.Text,
                        txtAssetDesc.Text, txtQuantity.Text, txtUOM.Text, txtLocation.Text, txtPersonUser.Text, cmbVendor.Text, txtInvoicenodate.Text,
                        txtVoucherNo.Text, dtpVoucherdate.Text, cmbLedgerinTally.Text, cmbDepLedgerinTally.Text, costCenterData,
                        txtLifeofasset.Text, dtpDateofCapitalizaton.Text, txtAmount.Text, txtRemarks.Text, "", "","","", sAssetbarcode);
                    if (GlobalClass.iSuccess > 0)
                    {
                        GlobalClass.iStatus = DAL.fnAddProjectStatusUpdate(1, txtProjectcode.Text, "Capitalized FA", txtVoucherNo.Text.Trim(), txtAmount.Text.Trim(),
                                              txtCapexNo.Text.Trim(), "FA" + Slno, txtRemarks.Text.Trim(), login.GetUserDetails[2]);

                        GlobalClass.iStatus = DAL.fnAddProjectUpdate(5, txtProjectcode.Text, "", "Capitalized FA", "");
                    }

                    GlobalClass.iSuccess = DAL.fnAddERPLog(0, ("FA" + Slno), login.GetUserDetails[2], dtpVoucherdate.Text, "Asset Added", "AssetMaster");
                    MessageBox.Show("Asset added successfully.", "Success", 0, MessageBoxIcon.Information);
                    frmAssetmaster assetmaster = new frmAssetmaster();
                    this.Hide();
                    assetmaster.Show();
                }
            }
            else if (btnSave.Text == "Update")
            {
                if (string.IsNullOrEmpty(txtvrfRemarks.Text))
                {
                    
                    MessageBox.Show("Enter verification  remarks", "Error", 0, MessageBoxIcon.Error);
                    txtvrfRemarks.Focus();
                    return;
                }
                if (string.IsNullOrEmpty(dtpDateofVerification.Text))
                {
                    
                    MessageBox.Show("Enter verification  date", "Error", 0, MessageBoxIcon.Error);
                    dtpDateofVerification.Focus();
                    return;
                }

                if (chkdeletedate.Checked)
                {
                    if (!string.IsNullOrEmpty(txtDeletionRemarks.Text))
                    {
                        if (cmbAssetBarcode.SelectedIndex < 0)
                        {
                            sAssetbarcode = cmbAssetSLNO.Text;
                        }
                        else
                        {
                            sAssetbarcode = cmbAssetBarcode.Text;
                        }
                        string updatedCostCenterData = "";

                        if (!string.IsNullOrWhiteSpace(cmbCostCenter4.Text) && !string.IsNullOrWhiteSpace(txtPct1.Text))
                            updatedCostCenterData += $"{cmbCostCenter4.Text}-{txtPct1.Text},";

                        if (!string.IsNullOrWhiteSpace(cmbCostCenter1.Text) && !string.IsNullOrWhiteSpace(txtPct2.Text))
                            updatedCostCenterData += $"{cmbCostCenter1.Text}-{txtPct2.Text},";

                        if (!string.IsNullOrWhiteSpace(cmbCostCenter2.Text) && !string.IsNullOrWhiteSpace(txtPct3.Text))
                            updatedCostCenterData += $"{cmbCostCenter2.Text}-{txtPct3.Text},";

                        if (!string.IsNullOrWhiteSpace(cmbCostCenter3.Text) && !string.IsNullOrWhiteSpace(txtPct4.Text))
                            updatedCostCenterData += $"{cmbCostCenter3.Text}-{txtPct4.Text},";

                        // Remove trailing comma
                        if (updatedCostCenterData.EndsWith(","))
                            updatedCostCenterData = updatedCostCenterData.TrimEnd(',');

                        GlobalClass.iSuccess = DAL.fnAddAssetmaster(2, cmbAssetSLNO.Text, txtPlanNo.Text, txtProjectcode.Text, txtCapexNo.Text, cmbAssetsgroup.Text, cmbAssetNature.Text,
                            txtAssetDesc.Text, txtQuantity.Text, txtUOM.Text, txtLocation.Text, txtPersonUser.Text, cmbVendor.Text, txtInvoicenodate.Text,
                            txtVoucherNo.Text, dtpVoucherdate.Text, cmbLedgerinTally.Text, cmbDepLedgerinTally.Text, updatedCostCenterData,
                            txtLifeofasset.Text, dtpDateofCapitalizaton.Text, txtAmount.Text, txtRemarks.Text, dtpDateofDeletion.Text, txtDeletionRemarks.Text,txtvrfRemarks.Text,dtpDateofVerification.Text, sAssetbarcode);

                        MessageBox.Show("Asset updated successfully.", "Success", 0, MessageBoxIcon.Information);
                        frmAssetmaster assetmaster = new frmAssetmaster();
                        this.Hide();
                        assetmaster.Show();
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(txtDeletionRemarks.Text))
                        {
                            txtDeletionRemarks.Focus();
                            MessageBox.Show("Enter deletion remarks", "Error", 0, MessageBoxIcon.Error);
                        }
                    }

                }
                else
                {
                    if (cmbAssetBarcode.SelectedIndex < 0)
                    {
                        sAssetbarcode = cmbAssetSLNO.Text;
                    }
                    else
                    {
                        sAssetbarcode = cmbAssetBarcode.Text;
                    }

                 

                    string updatedCostCenterData = "";

                    if (!string.IsNullOrWhiteSpace(cmbCostCenter4.Text) && !string.IsNullOrWhiteSpace(txtPct1.Text))
                        updatedCostCenterData += $"{cmbCostCenter4.Text}-{txtPct1.Text},";

                    if (!string.IsNullOrWhiteSpace(cmbCostCenter1.Text) && !string.IsNullOrWhiteSpace(txtPct2.Text))
                        updatedCostCenterData += $"{cmbCostCenter1.Text}-{txtPct2.Text},";

                    if (!string.IsNullOrWhiteSpace(cmbCostCenter2.Text) && !string.IsNullOrWhiteSpace(txtPct3.Text))
                        updatedCostCenterData += $"{cmbCostCenter2.Text}-{txtPct3.Text},";

                    if (!string.IsNullOrWhiteSpace(cmbCostCenter3.Text) && !string.IsNullOrWhiteSpace(txtPct4.Text))
                        updatedCostCenterData += $"{cmbCostCenter3.Text}-{txtPct4.Text},";

                    // Remove trailing comma
                    if (updatedCostCenterData.EndsWith(","))
                        updatedCostCenterData = updatedCostCenterData.TrimEnd(',');

                    GlobalClass.iSuccess = DAL.fnAddAssetmaster(2, cmbAssetSLNO.Text, txtPlanNo.Text, txtProjectcode.Text, txtCapexNo.Text, cmbAssetsgroup.Text, cmbAssetNature.Text,
                          txtAssetDesc.Text, txtQuantity.Text, txtUOM.Text, txtLocation.Text, txtPersonUser.Text, cmbVendor.Text, txtInvoicenodate.Text,
                          txtVoucherNo.Text, dtpVoucherdate.Text, cmbLedgerinTally.Text, cmbDepLedgerinTally.Text, updatedCostCenterData,
                          txtLifeofasset.Text, dtpDateofCapitalizaton.Text, txtAmount.Text, txtRemarks.Text, "", "",txtvrfRemarks.Text,dtpDateofVerification.Text, sAssetbarcode);

                    MessageBox.Show("Asset updated successfully.", "Success", 0, MessageBoxIcon.Information);
                    frmAssetmaster assetmaster = new frmAssetmaster();
                    this.Hide();
                    assetmaster.Show();
                }

            }
        }

        private void frmAssetmaster_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnClose();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            fnClose();
        }
        DataTable dtLoadAssetNoList = new DataTable();
        DataTable dtLoadAssetList = new DataTable();

        private void chkloadOldAsset_CheckedChanged(object sender, EventArgs e)
        {
            if (chkloadOldAsset.Checked)
            {
                if (LoginForm.GetUserDetails[2] == "theertha rao"|| LoginForm.GetUserDetails[2] == "BiSS" || LoginForm.GetUserDetails[2] == "Puneeth Hegde")//Puneeth Hegde
                {
                    cmbAssetSLNO.Enabled = true;
                    dtLoadAssetNoList = DAL.fnAssetmasterList(2, null).Tables[0];

                    foreach (DataRow DR in dtLoadAssetNoList.Rows)
                    {
                        if (!cmbAssetSLNO.Items.Contains(DR["Asset Sl No"].ToString()))
                            cmbAssetSLNO.Items.Add(DR["Asset Sl No"].ToString());
                    }
                    btnSave.Text = "Update";
                    btnSave.Enabled = true;
                    pnDelete.Visible = true;
                    btnPrint.Enabled = true;
                    //pictureBox1.Visible = true;
                    btnDownloadQRCode.Visible = true;
                }
                else{
                    cmbAssetSLNO.Enabled = true;
                    dtLoadAssetNoList = DAL.fnAssetmasterList(2, null).Tables[0];

                    foreach (DataRow DR in dtLoadAssetNoList.Rows)
                    {
                        if (!cmbAssetSLNO.Items.Contains(DR["Asset Sl No"].ToString()))
                            cmbAssetSLNO.Items.Add(DR["Asset Sl No"].ToString());
                    }
                    btnSave.Text = "Update";
                    btnSave.Enabled = false;
                    pnDelete.Visible = false;
                    btnPrint.Enabled = true;
                    //pictureBox1.Visible = true;
                    btnDownloadQRCode.Visible = true;
                }
            }
            else
            {
                cmbAssetSLNO.SelectedIndex = -1;
                cmbAssetSLNO.Enabled = false;
                pnDelete.Visible = false;
                btnPrint.Enabled = false;
               // pictureBox1.Visible = false;
                btnDownloadQRCode.Visible = false;
            }
        }
        DataTable dtcapexlist = new DataTable();
        private void txtProjectcode_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtcapexlist = DAL.fnAssetmasterList(9, txtProjectcode.Text).Tables[0];
            if (dtcapexlist.Rows.Count > 0)
            {
                txtCapexNo.Text = dtcapexlist.Rows[0][0].ToString();
                txtAssetDesc.Text = dtcapexlist.Rows[0][1].ToString();
                txtPersonUser.Text = dtcapexlist.Rows[0][2].ToString();


            }
        }
        private void cmbAssetSLNO_SelectedIndexChanged(object sender, EventArgs e)
        {

            cmbCostCenter1.Text = "";
            txtPct1.Text = "";
            cmbCostCenter2.Text = "";
            txtPct2.Text = "";
            cmbCostCenter3.Text = "";
            txtPct3.Text = "";
            cmbCostCenter4.Text = "";
            txtPct4.Text = "";

            dtLoadAssetList = DAL.fnAssetmasterList(1, cmbAssetSLNO.Text).Tables[0];
            if (LoginForm.GetUserDetails[2] == "Sandeep S")
            {
                btnSave.Enabled = false;
            }
            if (dtLoadAssetList.Rows.Count > 0)
            {
                DataRow row = dtLoadAssetList.Rows[0];

                btnDocUpload.Visible = true;
                dtpDateofVerification.Visible = true;
                label24.Visible = true;
                txtvrfRemarks.Visible = true;
                label25.Visible=true;


                txtPlanNo.Text = dtLoadAssetList.Rows[0][0].ToString();
                txtProjectcode.Text = dtLoadAssetList.Rows[0][1].ToString();
                txtCapexNo.Text = dtLoadAssetList.Rows[0][2].ToString();

                cmbAssetsgroup.Text = dtLoadAssetList.Rows[0][3].ToString();
                cmbAssetNature.Text = dtLoadAssetList.Rows[0][4].ToString();

                txtAssetDesc.Text = dtLoadAssetList.Rows[0][5].ToString();
                txtQuantity.Text = dtLoadAssetList.Rows[0][6].ToString();
                txtUOM.Text = dtLoadAssetList.Rows[0][7].ToString();
                txtLocation.Text = dtLoadAssetList.Rows[0][8].ToString();
                txtPersonUser.Text = dtLoadAssetList.Rows[0][9].ToString();
                cmbVendor.Text = dtLoadAssetList.Rows[0][10].ToString();
                txtInvoicenodate.Text = dtLoadAssetList.Rows[0][11].ToString();
                txtVoucherNo.Text = dtLoadAssetList.Rows[0][12].ToString();
                dtpVoucherdate.Text = dtLoadAssetList.Rows[0][13].ToString();
                cmbLedgerinTally.Text = dtLoadAssetList.Rows[0][14].ToString();
                cmbDepLedgerinTally.Text = dtLoadAssetList.Rows[0][15].ToString();
                //cmbCostCenter4.Text = dtLoadAssetList.Rows[0][16].ToString();

                //ADDEDBY BHAVYA


                string costCenterData = dtLoadAssetList.Rows[0][16].ToString(); // e.g., "PO-25,ADMIN-30,R7D-45,TEL-10"

                if (!string.IsNullOrWhiteSpace(costCenterData))
                {
                    string[] pairs = costCenterData.Split(',');

                    if (pairs.Length > 0 && pairs[0].Contains("-"))
                    {
                        string[] parts = pairs[0].Split('-');
                        cmbCostCenter4.Text = parts[0];
                        txtPct1.Text = parts[1];
                    }

                    if (pairs.Length > 1 && pairs[1].Contains("-"))
                    {
                        string[] parts = pairs[1].Split('-');
                        cmbCostCenter1.Text = parts[0];
                        txtPct2.Text = parts[1];
                    }

                    if (pairs.Length > 2 && pairs[2].Contains("-"))
                    {
                        string[] parts = pairs[2].Split('-');
                        cmbCostCenter2.Text = parts[0];
                        txtPct3.Text = parts[1];
                    }

                    if (pairs.Length > 3 && pairs[3].Contains("-"))
                    {
                        string[] parts = pairs[3].Split('-');
                        cmbCostCenter3.Text = parts[0];
                        txtPct4.Text = parts[1];
                       
                    }
                }

                //



                txtLifeofasset.Text = dtLoadAssetList.Rows[0][17].ToString();
                dtpDateofCapitalizaton.Text = dtLoadAssetList.Rows[0][18].ToString();
                txtAmount.Text = dtLoadAssetList.Rows[0][19].ToString();
                txtRemarks.Text = dtLoadAssetList.Rows[0][20].ToString();
                dtpDateofDeletion.Text = dtLoadAssetList.Rows[0][21].ToString();
                txtDeletionRemarks.Text = dtLoadAssetList.Rows[0][22].ToString();

                cmbAssetBarcode.Text = dtLoadAssetList.Rows[0][23].ToString();
                txtvrfRemarks.Text = dtLoadAssetList.Rows[0][24].ToString();
               // txtvrfRemarks.Text = row["VerificationRemarks"].ToString();
                dtpDateofVerification.Text = dtLoadAssetList.Rows[0][25].ToString();

                

                Zen.Barcode.CodeQrBarcodeDraw qrcode = Zen.Barcode.BarcodeDrawFactory.CodeQr;
                pictureBox1.Image = qrcode.Draw(cmbAssetBarcode.Text, 70);
            }
        }

        private void cmbLedgerinTally_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbLedgerinTally.Text)
            {
                case "12000 Assets Land":
                    cmbDepLedgerinTally.Text = "-";
                    break;
                case "12001 Assets Building":
                    cmbDepLedgerinTally.Text = "12201 Accumulated Dep. Building";
                    break;
                case "12002 Assets - Electrical Installation":
                    cmbDepLedgerinTally.Text = "12202 Accumulated Dep. Electrical Installation";
                    break;
                case "12003 Assets Computers":
                    cmbDepLedgerinTally.Text = "12203 Accumulated Dep. Computer";
                    break;
                case "12004 Assets Furniture & Fixture":
                    cmbDepLedgerinTally.Text = "12204 Accumulated Dep. Furniture & Fixture";
                    break;
                case "12005 Assets Motor Car":
                    cmbDepLedgerinTally.Text = "12205 Accumulated Dep. Motor Car";
                    break;
                case "12006 Assets Motor Vehicle":
                    cmbDepLedgerinTally.Text = "12205 Accumulated Dep. Motor Vehical";
                    break;
                case "12007 Assets Office Equipments":
                    cmbDepLedgerinTally.Text = "12207 Accumulated Dep. Office Equipments";
                    break;
                case "12007 Assets Office Equipments-Intangibles":
                    cmbDepLedgerinTally.Text = "12203 Accumulated Dep. Intangibles";
                    break;
                case "12008 Assets Plant and Machinery":
                    cmbDepLedgerinTally.Text = "12208 Accumulated Dep. Plant and Machinery";
                    break;
                case "12009 Assets Tools":
                    cmbDepLedgerinTally.Text = "12209 Accumulated Dep. Tools";
                    break;
                case "12010 Assets Equipment Leased":
                    cmbDepLedgerinTally.Text = "12210 Accumulated Dep. Equipment Leased";
                    break;
            }
        }



        private void cmbAssetsgroup_SelectedValueChanged(object sender, EventArgs e)
        {
            var assetgroup = cmbAssetsgroup.SelectedItem;
            switch (assetgroup)
            {
                case "BUILDINGS":
                    txtLifeofasset.Text = "30";
                    break;
                case "Electrical Installation":
                    txtLifeofasset.Text = "10";
                    break;
                case "FURNITURE & FIXTURES":
                    txtLifeofasset.Text = "5";
                    break;
                case "Land":
                    txtLifeofasset.Text = "0";
                    break;
                case "MOTOR VEHICLES - CO OWNED":
                    txtLifeofasset.Text = "4";
                    break;
                case "OFFICE EQUIPMENT - IT OTHER THAN LAPTOPS":
                    txtLifeofasset.Text = "3";
                    break;
                case "OFFICE EQUIPMENT - LAPTOPS":
                    txtLifeofasset.Text = "3";
                    break;
                case "OFFICE EQUIPMENT-NON-IT ITEMS":
                    txtLifeofasset.Text = "5";
                    break;
                case "Plant and Machinery":
                    txtLifeofasset.Text = "10";
                    break;
                case "Software":
                    txtLifeofasset.Text = "3";
                    break;
                case "Tools":
                    txtLifeofasset.Text = "3";
                    break;
                case "Computers-Pre-Used":
                    txtLifeofasset.Text = "1";
                    break;
                default:
                    txtLifeofasset.Text = "0";
                    break;
            }
        }

        private void btnDocUpload_Click(object sender, EventArgs e)
        {
            asetdoc.fnGetassetnumber = cmbAssetSLNO.Text;
            this.Hide();
            pleasewaitform pleaseWait = new pleasewaitform();
            pleaseWait.Show();
            Application.DoEvents();
            AssetMaster.AssetDocument ginpo = new AssetMaster.AssetDocument();
            ginpo.Show();
            pleaseWait.Hide();
        }

        private void cmbAssetBarcode_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtLoadAssetList = DAL.fnAssetmasterList(1, cmbAssetBarcode.Text).Tables[0];

            if (dtLoadAssetList.Rows.Count > 0)
            {
                txtvrfRemarks.Text = dtLoadAssetList.Rows[0][24].ToString();
                dtpDateofVerification.Text = dtLoadAssetList.Rows[0][25].ToString();
                btnDocUpload.Visible = true;
                dtpDateofVerification.Visible = true;
                label24.Visible = true;
                txtvrfRemarks.Visible = true;
                label25.Visible = true;

                cmbAssetsgroup.Text = dtLoadAssetList.Rows[0][3].ToString();
                cmbAssetNature.Text = dtLoadAssetList.Rows[0][4].ToString();
                txtAssetDesc.Text = dtLoadAssetList.Rows[0][5].ToString();
                txtLocation.Text = dtLoadAssetList.Rows[0][8].ToString();
                cmbLedgerinTally.Text = dtLoadAssetList.Rows[0][14].ToString();
                cmbDepLedgerinTally.Text = dtLoadAssetList.Rows[0][15].ToString();
                // cmbCostCenter4.Text = dtLoadAssetList.Rows[0][16].ToString();
                string costCenterData = dtLoadAssetList.Rows[0][16].ToString(); // e.g., "PO-25,ADMIN-30,R7D-45,TEL-10"

                if (!string.IsNullOrWhiteSpace(costCenterData))
                {
                    string[] pairs = costCenterData.Split(',');

                    if (pairs.Length > 0 && pairs[0].Contains("-"))
                    {
                        string[] parts = pairs[0].Split('-');
                        cmbCostCenter4.Text = parts[0];
                        txtPct1.Text = parts[1];
                    }

                    if (pairs.Length > 1 && pairs[1].Contains("-"))
                    {
                        string[] parts = pairs[1].Split('-');
                        cmbCostCenter1.Text = parts[0];
                        txtPct2.Text = parts[1];
                    }

                    if (pairs.Length > 2 && pairs[2].Contains("-"))
                    {
                        string[] parts = pairs[2].Split('-');
                        cmbCostCenter2.Text = parts[0];
                        txtPct3.Text = parts[1];
                    }

                    if (pairs.Length > 3 && pairs[3].Contains("-"))
                    {
                        string[] parts = pairs[3].Split('-');
                        cmbCostCenter3.Text = parts[0];
                        txtPct4.Text = parts[1];
                    }
                }

            }
        }
        string FileFul;
        private void btnPrint_Click(object sender, EventArgs e)
        {
            if (cmbAssetSLNO.SelectedIndex >= 0)
            {

                int iRowIndex = 1;
                string ExcelFolderName;
                string ExcelFolderPath;
                string FileFullPath;

                EXCEL.Workbook NewWorkBook;
                EXCEL.Worksheet NewWorkSheet;
                EXCEL.Application ExcelApp;
                EXCEL.Range CELLS, cell1, cell2;
                {
                    object misValue;
                    ExcelFolderName = "\\Fixed Asset Register";
                    ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + ExcelFolderName + "\\";
                    FileFullPath = ExcelFolderPath + cmbAssetSLNO.Text + "_" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + ".xls";
                    FileFul = ExcelFolderPath + cmbAssetSLNO.Text + "_" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + ".pdf";
                    string[] Text ={ Global.sCompanyName,
                                "NO.497E, 14th Cross, 4th Phase, Peenya Industrial Area,",
                                "Bangalore-560 058, Karnataka,  India. ",
                                "Phone:91(080) 28360184. FAX: (080) 28360047.",""};




                    if (!Directory.Exists(ExcelFolderPath))
                        Directory.CreateDirectory(ExcelFolderPath);

                    ExcelApp = new EXCEL.Application();
                    misValue = System.Reflection.Missing.Value;
                    try
                    {
                        if (ExcelApp == null)
                            MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                        NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                        NewWorkSheet = NewWorkBook.Sheets.Add(misValue, misValue, 1, misValue);

                        if (NewWorkSheet == null)
                            MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                        else
                        {
                            NewWorkSheet.Name = "Fixed Asset Register";
                        }
                        EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                        if (RANGE == null)
                            MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                        NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        CELLS = NewWorkSheet.Cells;
                        NewWorkSheet.PageSetup.PrintGridlines = false;

                        //  NewWorkSheet.Cells[iRowIndex, 1] = "Fixed Asset Register";


                        foreach (string str in Text)
                        {
                            NewWorkSheet.Cells[iRowIndex, 1] = str;
                            //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);
                            iRowIndex++;
                        }

                        NewWorkSheet.Cells[iRowIndex, 1] = "Fixed Asset Register";
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 11);
                        CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                        iRowIndex++;

                        NewWorkSheet.Range["A1:B1"].Cells.Font.Size = 16;
                        NewWorkSheet.Range["A1:B1"].Cells.Font.Bold = 16;

                        NewWorkSheet.Range["A6:B7"].Cells.Font.Size = 16;
                        NewWorkSheet.Range["A6:B7"].Cells.Font.Bold = true;
                        NewWorkSheet.Range["A6:B6"].Cells.Font.Color = Color.Red;
                        NewWorkSheet.Range["A7:B7"].Cells.Font.Color = Color.Blue;

                        NewWorkSheet.Cells[iRowIndex, 1] = "Asset Sl No :";
                        NewWorkSheet.Cells[iRowIndex, 2] = cmbAssetSLNO.Text;
                        iRowIndex++;

                        NewWorkSheet.Cells[iRowIndex, 1] = "Asset Barcode :";
                        NewWorkSheet.Cells[iRowIndex, 2] = cmbAssetBarcode.Text;
                        iRowIndex++;

                        NewWorkSheet.Cells[iRowIndex, 1] = "Plan No :";
                        NewWorkSheet.Cells[iRowIndex, 2] = txtPlanNo.Text;
                        iRowIndex++;

                        NewWorkSheet.Cells[iRowIndex, 1] = "Project Code :";
                        NewWorkSheet.Cells[iRowIndex, 2] = txtProjectcode.Text;
                        iRowIndex++;

                        NewWorkSheet.Cells[iRowIndex, 1] = "Capex No :";
                        NewWorkSheet.Cells[iRowIndex, 2] = txtCapexNo.Text;
                        iRowIndex++;

                        NewWorkSheet.Cells[iRowIndex, 1] = "Assets Group :";
                        NewWorkSheet.Cells[iRowIndex, 2] = cmbAssetsgroup.Text;
                        iRowIndex++;

                        NewWorkSheet.Cells[iRowIndex, 1] = "Assets Nature :";
                        NewWorkSheet.Cells[iRowIndex, 2] = cmbAssetNature.Text;
                        iRowIndex++;

                        NewWorkSheet.Cells[iRowIndex, 1] = "Quantity :";
                        NewWorkSheet.Cells[iRowIndex, 2] = txtQuantity.Text + " " + txtUOM.Text;
                        iRowIndex++;

                        NewWorkSheet.Cells[iRowIndex, 1] = "Location :";
                        NewWorkSheet.Cells[iRowIndex, 2] = txtLocation.Text;
                        iRowIndex++;

                        NewWorkSheet.Cells[iRowIndex, 1] = "Person User :";
                        NewWorkSheet.Cells[iRowIndex, 2] = txtPersonUser.Text;
                        iRowIndex++;

                        NewWorkSheet.Cells[iRowIndex, 1] = "Vendor Name :";
                        NewWorkSheet.Cells[iRowIndex, 2] = cmbVendor.Text;
                        iRowIndex++;

                        NewWorkSheet.Cells[iRowIndex, 1] = "Invoice No & Date :";
                        NewWorkSheet.Cells[iRowIndex, 2] = txtInvoicenodate.Text;
                        iRowIndex++;

                        NewWorkSheet.Cells[iRowIndex, 1] = "Voucher No :";
                        NewWorkSheet.Cells[iRowIndex, 2] = txtVoucherNo.Text;
                        iRowIndex++;

                        NewWorkSheet.Cells[iRowIndex, 1] = "Voucher Date :";
                        NewWorkSheet.Cells[iRowIndex, 2] = dtpVoucherdate.Text;
                        iRowIndex++;

                        NewWorkSheet.Cells[iRowIndex, 1] = "Ledger in Tally :";
                        NewWorkSheet.Cells[iRowIndex, 2] = cmbLedgerinTally.Text;
                        iRowIndex++;

                        NewWorkSheet.Cells[iRowIndex, 1] = "Department Ledger in Tally :";
                        NewWorkSheet.Cells[iRowIndex, 2] = cmbDepLedgerinTally.Text;
                        iRowIndex++;

                        NewWorkSheet.Cells[iRowIndex, 1] = "Cost Centre :";
                        NewWorkSheet.Cells[iRowIndex, 2] = cmbCostCenter4.Text;
                        iRowIndex++;

                        NewWorkSheet.Cells[iRowIndex, 1] = "Life of Asset :";
                        NewWorkSheet.Cells[iRowIndex, 2] = txtLifeofasset.Text;
                        iRowIndex++;

                        NewWorkSheet.Cells[iRowIndex, 1] = "Date of Capitalizaton :";
                        NewWorkSheet.Cells[iRowIndex, 2] = dtpDateofCapitalizaton.Text;
                        iRowIndex++;

                        NewWorkSheet.Cells[iRowIndex, 1] = "Amount :";
                        NewWorkSheet.Cells[iRowIndex, 2] = txtAmount.Text;
                        iRowIndex++;

                        NewWorkSheet.Cells[iRowIndex, 1] = "Asset Description :";
                        NewWorkSheet.Cells[iRowIndex, 2] = txtAssetDesc.Text;

                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 2, 11);
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 2, 2);
                        EXCEL.Range cell = NewWorkSheet.Range["B" + iRowIndex + ""];
                        cell.WrapText = true;
                        iRowIndex++;
                        iRowIndex++;
                        iRowIndex++;

                        NewWorkSheet.Cells[iRowIndex, 1] = "Remarks :";
                        NewWorkSheet.Cells[iRowIndex, 2] = txtRemarks.Text;
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 2, 11);
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 2, 2);
                        cell = NewWorkSheet.Range["B" + iRowIndex + ""];
                        cell.WrapText = true;
                        iRowIndex++;
                        iRowIndex++;
                        iRowIndex++;




                        CellMerge("AlignRight", NewWorkSheet, 7, iRowIndex, 1, 1);
                        CellMerge("AlignLeft", NewWorkSheet, 7, iRowIndex, 2, 2);
                        CellMerge("BorderAround", NewWorkSheet, 1, 6, 1, 11);
                        CellMerge("BorderAround", NewWorkSheet, 7, iRowIndex, 1, 11);
                        NewWorkSheet.Columns[1].ColumnWidth = 26;
                        //  NewWorkSheet.Columns[2].WrapText = true;

                        NewWorkSheet.get_Range("A7", "K9999").Cells.Font.Size = 12;
                        NewWorkSheet.get_Range("A1", "K9999").Cells.Font.Name = "Calibri";
                        NewWorkSheet.get_Range("A1", "K1").Cells.Font.Size = 18;

                        NewWorkSheet.PageSetup.PrintArea = "A1:K" + (iRowIndex) + "";

                        // NewWorkSheet.PageSetup.CenterHeaderPicture.Filename = "C:\\Databasepath\\POHeader.jpg";
                        // NewWorkSheet.PageSetup.CenterHeader = "&G";

                        //NewWorkSheet.PageSetup.LeftHeader = "&\"Arial\"&10 .. " + cmbVendorName.Text.Trim() + "";
                        //NewWorkSheet.PageSetup.RightHeader = "&\"Arial\"&10 " + cmbPONO.Text + "";
                        NewWorkSheet.PageSetup.RightFooter = "Page &P of &N";
                        NewWorkSheet.PageSetup.PrintNotes = true;
                        NewWorkSheet.PageSetup.Zoom = 65;

                        NewWorkSheet.PageSetup.AlignMarginsHeaderFooter = true;
                        //NewWorkSheet.PageSetup.LeftMargin = 0.3;
                        // NewWorkSheet.PageSetup.RightMargin = 0.3;

                        NewWorkSheet.PageSetup.TopMargin = 0.2;
                        //NewWorkSheet.PageSetup.BottomMargin = 1;
                        // NewWorkSheet.PageSetup.LeftMargin = 1;
                        // NewWorkSheet.PageSetup.RightMargin = 1;
                        NewWorkSheet.PageSetup.CenterHorizontally = true;

                        // create the header range
                        //  Range headerRange = worksheet.Range["A1:J10"];

                        // set the header to repeat on each page
                        NewWorkSheet.PageSetup.PrintTitleRows = "A1:K7";


                        NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                        NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                        EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 9];
                        Image oImage = Image.FromFile("C:\\Databasepath\\TQBiSSLogo.jpg");//
                        System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                        NewWorkSheet.Paste(oRange, "C:\\Databasepath\\TQBiSSLogo.jpg");

                        //EXCEL.Range oRange88 = (EXCEL.Range)NewWorkSheet.Cells[ilogoindex, 9];
                        //Image oImage4 = Image.FromFile(Global.sLogo);
                        //System.Windows.Forms.Clipboard.SetDataObject(oImage4, true);
                        //NewWorkSheet.Paste(oRange88, Global.sLogo);


                        //EXCEL.Range oRange1 = (EXCEL.Range)NewWorkSheet.Cells[3, 2];
                        //Image oImage1 = Image.FromFile(Global.sITWLogo);
                        //System.Windows.Forms.Clipboard.SetDataObject(oImage1, true);
                        //NewWorkSheet.Paste(oRange1, Global.sITWLogo);


                        NewWorkBook.Save();
                        ExcelApp.Visible = false;

                        NewWorkBook.ExportAsFixedFormat(EXCEL.XlFixedFormatType.xlTypePDF, FileFul);
                        //if (btnprintpo.Text == "Draft PO")
                        {
                            System.Diagnostics.Process.Start(FileFul);
                        }
                        NewWorkBook.Close(true, misValue, misValue);
                        ExcelApp.Quit();
                        releaseObject(NewWorkSheet);
                        releaseObject(NewWorkBook);
                        releaseObject(ExcelApp);

                        if (File.Exists(FileFullPath))
                        {
                            File.Delete(FileFullPath);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }

        #region CellMerge Funtion
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlMedium, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "GridLines":
                    {
                        CELLS.Borders.Color = System.Drawing.Color.Black;
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignCenter":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                        break;
                    }
                case "AlignTop":
                    {
                        CELLS.VerticalAlignment = EXCEL.XlVAlign.xlVAlignTop;
                        break;
                    }

                case "AlignRight":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                        break;
                    }
                case "AlignLeft":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignLeft;
                        break;
                    }
                case "Bold":
                    {
                        CELLS.Font.Bold = true;
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

        }
        #endregion

        #region Excel App Release Object Function
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
        #endregion


        private void btnDownloadQRCode_Click(object sender, EventArgs e)
        {
           
            SaveImageCapture(pictureBox1.Image, cmbAssetBarcode.Text);
        }

        public static void SaveImageCapture(System.Drawing.Image image, string sFilename)
        {
            SaveFileDialog s = new SaveFileDialog();
            s.FileName = sFilename;// Default file name
            s.DefaultExt = ".Jpg";// Default file extension
            s.Filter = "Image (.jpg)|*.jpg"; // Filter files by extension

            // Show save file dialog box
            // Process save file dialog box results
            if (s.ShowDialog() == DialogResult.OK)
            {
                // Save Image
                string filename = s.FileName;
                FileStream fstream = new FileStream(filename, FileMode.Create);
                image.Save(fstream, System.Drawing.Imaging.ImageFormat.Jpeg);
                fstream.Close();

            }
        }
    }
}
