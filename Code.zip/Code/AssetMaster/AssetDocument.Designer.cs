﻿
namespace Erp_Project_With_Buttons.AssetMaster
{
    partial class AssetDocument
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AssetDocument));
            this.cmbAssetDocument = new System.Windows.Forms.ComboBox();
            this.label60 = new System.Windows.Forms.Label();
            this.txtprojectcode = new System.Windows.Forms.Label();
            this.txtprojname = new System.Windows.Forms.Label();
            this.lblProjectCode = new System.Windows.Forms.Label();
            this.lblAsset = new System.Windows.Forms.Label();
            this.lblProjectName = new System.Windows.Forms.Label();
            this.dgUploadList = new System.Windows.Forms.DataGridView();
            this.DocumentType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UploadedFile2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UploadStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UploadederName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UploadDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.View = new System.Windows.Forms.DataGridViewButtonColumn();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.dtpUploaddate = new System.Windows.Forms.DateTimePicker();
            this.cmbAssetSLNO = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgUploadList)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbAssetDocument
            // 
            this.cmbAssetDocument.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbAssetDocument.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbAssetDocument.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbAssetDocument.FormattingEnabled = true;
            this.cmbAssetDocument.Items.AddRange(new object[] {
            "Approved Capex",
            "Asset Photograph",
            "Consumption & OH Working",
            "Installation/Capitalization Certificate",
            "Other Document"});
            this.cmbAssetDocument.Location = new System.Drawing.Point(187, 115);
            this.cmbAssetDocument.Name = "cmbAssetDocument";
            this.cmbAssetDocument.Size = new System.Drawing.Size(376, 26);
            this.cmbAssetDocument.TabIndex = 180;
            this.cmbAssetDocument.SelectedIndexChanged += new System.EventHandler(this.cmbAssetDocument_SelectedIndexChanged);
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.ForeColor = System.Drawing.Color.Black;
            this.label60.Location = new System.Drawing.Point(56, 115);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(120, 18);
            this.label60.TabIndex = 181;
            this.label60.Text = "Asset Document*:";
            // 
            // txtprojectcode
            // 
            this.txtprojectcode.AutoSize = true;
            this.txtprojectcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtprojectcode.ForeColor = System.Drawing.Color.Black;
            this.txtprojectcode.Location = new System.Drawing.Point(184, 55);
            this.txtprojectcode.Name = "txtprojectcode";
            this.txtprojectcode.Size = new System.Drawing.Size(12, 18);
            this.txtprojectcode.TabIndex = 179;
            this.txtprojectcode.Text = ".";
            // 
            // txtprojname
            // 
            this.txtprojname.AutoSize = true;
            this.txtprojname.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtprojname.ForeColor = System.Drawing.Color.Black;
            this.txtprojname.Location = new System.Drawing.Point(184, 86);
            this.txtprojname.Name = "txtprojname";
            this.txtprojname.Size = new System.Drawing.Size(12, 18);
            this.txtprojname.TabIndex = 178;
            this.txtprojname.Text = ".";
            // 
            // lblProjectCode
            // 
            this.lblProjectCode.AutoSize = true;
            this.lblProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectCode.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblProjectCode.Location = new System.Drawing.Point(82, 55);
            this.lblProjectCode.Name = "lblProjectCode";
            this.lblProjectCode.Size = new System.Drawing.Size(94, 18);
            this.lblProjectCode.TabIndex = 177;
            this.lblProjectCode.Text = "Project Code :";
            // 
            // lblAsset
            // 
            this.lblAsset.AutoSize = true;
            this.lblAsset.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAsset.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblAsset.Location = new System.Drawing.Point(82, 20);
            this.lblAsset.Name = "lblAsset";
            this.lblAsset.Size = new System.Drawing.Size(96, 18);
            this.lblAsset.TabIndex = 174;
            this.lblAsset.Text = "Asset SI NO * :";
            // 
            // lblProjectName
            // 
            this.lblProjectName.AutoSize = true;
            this.lblProjectName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectName.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblProjectName.Location = new System.Drawing.Point(77, 86);
            this.lblProjectName.Name = "lblProjectName";
            this.lblProjectName.Size = new System.Drawing.Size(99, 18);
            this.lblProjectName.TabIndex = 173;
            this.lblProjectName.Text = "Project Name :";
            // 
            // dgUploadList
            // 
            this.dgUploadList.AllowUserToAddRows = false;
            this.dgUploadList.AllowUserToDeleteRows = false;
            this.dgUploadList.AllowUserToResizeRows = false;
            this.dgUploadList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgUploadList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgUploadList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgUploadList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgUploadList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgUploadList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DocumentType,
            this.UploadedFile2,
            this.UploadStatus,
            this.UploadederName,
            this.UploadDate,
            this.View});
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgUploadList.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgUploadList.EnableHeadersVisualStyles = false;
            this.dgUploadList.Location = new System.Drawing.Point(12, 168);
            this.dgUploadList.MultiSelect = false;
            this.dgUploadList.Name = "dgUploadList";
            this.dgUploadList.RowHeadersVisible = false;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgUploadList.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dgUploadList.Size = new System.Drawing.Size(1080, 288);
            this.dgUploadList.TabIndex = 182;
            this.dgUploadList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgUploadList_CellClick);
            this.dgUploadList.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgUploadList_KeyUp);
            // 
            // DocumentType
            // 
            this.DocumentType.DataPropertyName = "DocumentType";
            this.DocumentType.HeaderText = "DocumentType";
            this.DocumentType.Name = "DocumentType";
            this.DocumentType.ReadOnly = true;
            this.DocumentType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DocumentType.Width = 119;
            // 
            // UploadedFile2
            // 
            this.UploadedFile2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.UploadedFile2.DataPropertyName = "Filename";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.UploadedFile2.DefaultCellStyle = dataGridViewCellStyle2;
            this.UploadedFile2.HeaderText = "File Name";
            this.UploadedFile2.Name = "UploadedFile2";
            this.UploadedFile2.ReadOnly = true;
            this.UploadedFile2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UploadedFile2.Width = 319;
            // 
            // UploadStatus
            // 
            this.UploadStatus.DataPropertyName = "UploadStatus";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.UploadStatus.DefaultCellStyle = dataGridViewCellStyle3;
            this.UploadStatus.HeaderText = "Uploaded Status";
            this.UploadStatus.Name = "UploadStatus";
            this.UploadStatus.ReadOnly = true;
            this.UploadStatus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UploadStatus.Width = 115;
            // 
            // UploadederName
            // 
            this.UploadederName.DataPropertyName = "UploaderName";
            this.UploadederName.HeaderText = "Uploaded By";
            this.UploadederName.Name = "UploadederName";
            this.UploadederName.ReadOnly = true;
            this.UploadederName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UploadederName.Width = 92;
            // 
            // UploadDate
            // 
            this.UploadDate.DataPropertyName = "UploadDate";
            this.UploadDate.HeaderText = "Upload Date";
            this.UploadDate.Name = "UploadDate";
            this.UploadDate.ReadOnly = true;
            this.UploadDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UploadDate.Width = 90;
            // 
            // View
            // 
            this.View.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.View.DefaultCellStyle = dataGridViewCellStyle4;
            this.View.HeaderText = "View";
            this.View.Name = "View";
            this.View.ReadOnly = true;
            this.View.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.View.Width = 114;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // dtpUploaddate
            // 
            this.dtpUploaddate.CustomFormat = "";
            this.dtpUploaddate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpUploaddate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpUploaddate.Location = new System.Drawing.Point(968, 12);
            this.dtpUploaddate.MaxDate = new System.DateTime(2028, 12, 31, 0, 0, 0, 0);
            this.dtpUploaddate.MinDate = new System.DateTime(2017, 1, 1, 0, 0, 0, 0);
            this.dtpUploaddate.Name = "dtpUploaddate";
            this.dtpUploaddate.Size = new System.Drawing.Size(124, 26);
            this.dtpUploaddate.TabIndex = 183;
            // 
            // cmbAssetSLNO
            // 
            this.cmbAssetSLNO.Enabled = false;
            this.cmbAssetSLNO.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbAssetSLNO.Location = new System.Drawing.Point(187, 16);
            this.cmbAssetSLNO.Name = "cmbAssetSLNO";
            this.cmbAssetSLNO.Size = new System.Drawing.Size(361, 27);
            this.cmbAssetSLNO.TabIndex = 184;
            // 
            // AssetDocument
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1193, 488);
            this.Controls.Add(this.cmbAssetSLNO);
            this.Controls.Add(this.dtpUploaddate);
            this.Controls.Add(this.dgUploadList);
            this.Controls.Add(this.cmbAssetDocument);
            this.Controls.Add(this.label60);
            this.Controls.Add(this.txtprojectcode);
            this.Controls.Add(this.txtprojname);
            this.Controls.Add(this.lblProjectCode);
            this.Controls.Add(this.lblAsset);
            this.Controls.Add(this.lblProjectName);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AssetDocument";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Asset Documents";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AssetDocument_FormClosing);
            this.Load += new System.EventHandler(this.AssetDocument_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgUploadList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox cmbAssetDocument;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label txtprojectcode;
        private System.Windows.Forms.Label txtprojname;
        private System.Windows.Forms.Label lblProjectCode;
        private System.Windows.Forms.Label lblAsset;
        private System.Windows.Forms.Label lblProjectName;
        private System.Windows.Forms.DataGridView dgUploadList;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.DateTimePicker dtpUploaddate;
        private System.Windows.Forms.DataGridViewTextBoxColumn DocumentType;
        private System.Windows.Forms.DataGridViewTextBoxColumn UploadedFile2;
        private System.Windows.Forms.DataGridViewTextBoxColumn UploadStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn UploadederName;
        private System.Windows.Forms.DataGridViewTextBoxColumn UploadDate;
        private System.Windows.Forms.DataGridViewButtonColumn View;
        private System.Windows.Forms.TextBox cmbAssetSLNO;
    }
}