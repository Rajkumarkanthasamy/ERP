﻿using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;

namespace Erp_Project_With_Buttons.AssetMaster
{
    public partial class AssetDocument : Form
    {
        public AssetDocument()
        {
            InitializeComponent();
        }
        Login.frmLoginForm login = new Login.frmLoginForm();
        DataAccessLayer DAL = new DataAccessLayer();
        DataTable dtLoadAssetNoList = new DataTable();
        DataTable dtLoadAssetList = new DataTable();
        Global GlobalClass = new Global();
        private static string sassetnumber;
        public string fnGetassetnumber //get GIN from the receipt form
        {
            get
            {
                return sassetnumber;
            }
            set
            {
                sassetnumber = value;
            }
        }
        private void AssetDocument_Load(object sender, EventArgs e)
        {
            cmbAssetSLNO.Text = sassetnumber;
            //dtLoadAssetNoList = DAL.fnAssetmasterList(2, null).Tables[0];

            //foreach (DataRow DR in dtLoadAssetNoList.Rows)
            //{
            //    if (!cmbAssetSLNO.Items.Contains(DR["Asset Sl No"].ToString()))
            //        cmbAssetSLNO.Items.Add(DR["Asset Sl No"].ToString());
            //}
            dtLoadAssetList = DAL.fnAssetmasterList(1, sassetnumber).Tables[0];
            if (dtLoadAssetList.Rows.Count > 0)
            {
                txtprojectcode.Text = dtLoadAssetList.Rows[0][1].ToString();
                txtprojname.Text = dtLoadAssetList.Rows[0][5].ToString();
                fnAddProjectInfo();
            }
            else
            {
                txtprojectcode.ResetText();
                txtprojname.ResetText();
            }

        }
             

        DataTable dtProjectInfolist = new DataTable();
        string [] doctype;
        private void fnAddProjectInfo()
        {          
                dtProjectInfolist = DAL.fnProjectInfoList(3, cmbAssetSLNO.Text, "").Tables[0];
                doctype = new string[] { "Approved Capex", "Asset Photograph", "Consumption & OH Working", "Installation/Capitalization Certificate","Other Document" };
          
                     
            bool bDocExist = false;
            if (dtProjectInfolist.Rows.Count > 0)
            {
                for (int i = dtProjectInfolist.Rows.Count - 1; i >= 0; i--)
                {
                    if (!doctype.Contains(dtProjectInfolist.Rows[i]["DocumentType"].ToString()))
                    {
                        dtProjectInfolist.Rows.RemoveAt(i);
                    }
                }
                foreach (string sDocumnet in doctype)
                {
                    bDocExist = false;
                    foreach (DataRow dr in dtProjectInfolist.Rows)
                    {
                        if (dr["DocumentType"].ToString() == sDocumnet)
                        {
                            bDocExist = true;
                            break;
                        }
                    }
                    if (!bDocExist)
                    {
                        dtProjectInfolist.Rows.Add(0, "", "", "", "", "False", "", sDocumnet);
                    }
                }
                dgUploadList.AutoGenerateColumns = false;
                dgUploadList.DataSource = dtProjectInfolist;
                Datagridviewcolor();
            }
            else
            {
                foreach (string sDocumnet in doctype)
                {
                    foreach (DataRow dr in dtProjectInfolist.Rows)
                    {
                        if (dr["DocumentType"].ToString() == sDocumnet)
                        {
                            bDocExist = true;
                            break;
                        }
                    }
                    if (!bDocExist)
                    {
                        dtProjectInfolist.Rows.Add(0, "", "", "", "", "False", "", sDocumnet);
                    }
                }
                dgUploadList.AutoGenerateColumns = false;
                dgUploadList.DataSource = dtProjectInfolist;
                Datagridviewcolor();
            }
        }
        private void Datagridviewcolor()
        {
            int count = 0;
            foreach (DataGridViewRow dgr in dgUploadList.Rows)
            {
                if (Convert.ToBoolean(dgr.Cells["UploadStatus"].Value))
                {
                    dgr.DefaultCellStyle.BackColor = Color.LightGreen;
                }
                else
                {
                    dgr.DefaultCellStyle.BackColor = Color.Red;
                }
                count++;
            }
        }
        private void fnExit()
        {
            this.Hide();          
            pleasewaitform pleaseWait = new pleasewaitform();         
            pleaseWait.Show();           
            Application.DoEvents();
            frmAssetmaster asset = new frmAssetmaster();
            asset.Show();
            pleaseWait.Hide();
        }

        private void AssetDocument_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnExit();
        }
        Regex illegalInFileName = new Regex(@"[\\/:*?""<>|]");
        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            string sMonth = DateTime.Now.ToString("MM-yyyy");
            Regex illegalInFileName = new Regex(@"[\\/:*?""<>|]");
            bool bFileCheck = false;
            foreach (DataGridViewRow dr in dgUploadList.Rows)
            {
                if (dr.Cells["UploadedFile2"].Value.ToString() == openFileDialog1.SafeFileName)
                {
                    bFileCheck = true;
                    break;
                }
            }
            if (!bFileCheck)
            {
                string sProjName = cmbAssetSLNO.Text;
               sProjName = illegalInFileName.Replace(sProjName, " ");
                sProjName = sProjName + "\\";
                string sourcePath = openFileDialog1.FileName;
                string ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                if (!Directory.Exists(ExcelFolderPath))
                {
                    Directory.CreateDirectory(ExcelFolderPath);
                }
              //  string targetPath = @"\\192.168.1.81\ERP_Project_Document\AssetMaster\" + sMonth + "\\" + sProjName;
                string targetPath = @"\\inbas01\Data\ERP\Pub\ERP_Project_Document\AssetMaster\" + "\\" + sProjName;


                if (!Directory.Exists(targetPath))
                {
                    Directory.CreateDirectory(targetPath);
                }

                File.Copy(sourcePath, targetPath + Path.GetFileName(sourcePath), true);

                if (Directory.Exists(targetPath))
                {
                    GlobalClass.iSuccess = DAL.fnAddProjectDocuments(5, cmbAssetSLNO.Text, txtprojectcode.Text,
                                              login.GetUserDetails[2], dtpUploaddate.Text, "1","","",openFileDialog1.SafeFileName, cmbAssetDocument.Text);

                    MessageBox.Show("Selected file saved to the server succeessfully", "Success", 0, MessageBoxIcon.Information);
                    fnAddProjectInfo();
                }
            }
            else
            {
                MessageBox.Show("Selected file already saved in the server", "Error", 0, MessageBoxIcon.Error);
            }
        }

        private void cmbAssetDocument_SelectedIndexChanged(object sender, EventArgs e)
        {
            openFileDialog1.InitialDirectory = @"c:\";
            openFileDialog1.Title = "Select File";
            openFileDialog1.ShowDialog();
        }

        private void dgUploadList_CellClick(object sender, DataGridViewCellEventArgs e)
        {            
            
            if (dgUploadList.Rows.Count > 0)
            {
                if (dgUploadList.CurrentCell.OwningColumn.Name == "View")
                {              
                  
                    if (dgUploadList.CurrentRow.Cells["UploadStatus"].Value.ToString() == "True")
                    {
                        string UploadDate = dgUploadList.CurrentRow.Cells["UploadDate"].Value.ToString();
                        DateTime loadedDate = DateTime.Parse(UploadDate);
                        string sMonth = loadedDate.ToString("MM-yyyy");
                        string sProjName = cmbAssetSLNO.Text;
                        sProjName = illegalInFileName.Replace(sProjName, " ");
                        string FileOpen = @"\\inbas01\Data\ERP\Pub\ERP_Project_Document\AssetMaster\" + "\\" + sProjName+ "\\" + dgUploadList.CurrentRow.Cells["UploadedFile2"].Value.ToString();
                        System.Diagnostics.Process.Start(FileOpen);
                    }
                    else
                    {
                        if (dgUploadList.CurrentRow.Cells["UploadStatus"].Value.ToString() == "False")
                        {
                            MessageBox.Show("No document uploaded to view", "Information", 0, MessageBoxIcon.Warning);
                        }
                    }
                }
            }
        }
       
        private void dgUploadList_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                if (dgUploadList.Rows.Count > 0)
                {
                    if (dgUploadList.CurrentRow.Cells["UploadederName"].Value.ToString().ToLower() == login.GetUserDetails[2].ToLower())
                    {
                        DialogResult DR = MessageBox.Show("Do you want to delete selected file  '" + dgUploadList.CurrentRow.Cells["UploadedFile2"].Value.ToString() + "'", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (DR == DialogResult.Yes)
                        {
                            string UploadDate = dgUploadList.CurrentRow.Cells["UploadDate"].Value.ToString();
                            DateTime loadedDate = DateTime.Parse(UploadDate);
                            string sMonth = loadedDate.ToString("MM-yyyy");
                            string sProjName = cmbAssetSLNO.Text;
                            sProjName = illegalInFileName.Replace(sProjName, " ");
                            string FileOpen = @"\\inbas01\Data\ERP\Pub\ERP_Project_Document\AssetMaster\" +  "\\" + sProjName + "\\" + dgUploadList.CurrentRow.Cells["UploadedFile2"].Value.ToString();
                            GlobalClass.iSuccess = DAL.fnAddProjectDocuments(6, cmbAssetSLNO.Text, txtprojectcode.Text,
                                             login.GetUserDetails[2], dtpUploaddate.Text, "1", "", "", dgUploadList.CurrentRow.Cells["UploadedFile2"].Value.ToString(), cmbAssetDocument.Text);

                            File.Delete(FileOpen);
                            MessageBox.Show("Selected file deleted from the server", "Information", 0, MessageBoxIcon.Information);
                            fnAddProjectInfo();
                        }
                    }
                    else
                    {
                        MessageBox.Show("You cannot delete this document, ask " + dgUploadList.CurrentRow.Cells["UploadederName"].Value.ToString() + " to delete", "Information", 0, MessageBoxIcon.Warning);
                    }
                }
            }
        }
    }
}
