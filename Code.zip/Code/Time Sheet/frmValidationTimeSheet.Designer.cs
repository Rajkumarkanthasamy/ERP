﻿namespace Erp_Project_With_Buttons.Time_Sheet
{
    partial class frmValidationTimeSheet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmValidationTimeSheet));
            this.label8 = new System.Windows.Forms.Label();
            this.cmbProjectcode = new System.Windows.Forms.ComboBox();
            this.btnProjectSearch = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbSubTask = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblprojname = new System.Windows.Forms.Label();
            this.lbleighty = new System.Windows.Forms.Label();
            this.lblCustomizationLevel = new System.Windows.Forms.Label();
            this.dgvTimeSheet = new System.Windows.Forms.DataGridView();
            this.ID1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Username = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UserDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Week = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectET = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Customization = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ActivityTask = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SubTask = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TotalHours = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Remarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RangeCapacity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductSerialNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtWeek = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblUsername = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbMainActivity = new System.Windows.Forms.ComboBox();
            this.txtHours = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.lblHistoryHours = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lblDepartment = new System.Windows.Forms.Label();
            this.pnHydraulics = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.cmbCapacity = new System.Windows.Forms.ComboBox();
            this.cmbBOMProduct = new System.Windows.Forms.ComboBox();
            this.lblprdname = new System.Windows.Forms.Label();
            this.lblprojectbom = new System.Windows.Forms.Label();
            this.pnProduct = new System.Windows.Forms.Panel();
            this.txtProductName = new System.Windows.Forms.TextBox();
            this.txtSlNo = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.pnSubModule = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.cmbBackuprun = new System.Windows.Forms.ComboBox();
            this.txtVersion = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtSubModule = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.btnView = new System.Windows.Forms.Button();
            this.dtpTimeSheetDate = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTimeSheet)).BeginInit();
            this.pnHydraulics.SuspendLayout();
            this.pnProduct.SuspendLayout();
            this.pnSubModule.SuspendLayout();
            this.SuspendLayout();
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(61, 50);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(104, 19);
            this.label8.TabIndex = 126;
            this.label8.Text = "Project Code :";
            // 
            // cmbProjectcode
            // 
            this.cmbProjectcode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProjectcode.DropDownHeight = 130;
            this.cmbProjectcode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProjectcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProjectcode.FormattingEnabled = true;
            this.cmbProjectcode.IntegralHeight = false;
            this.cmbProjectcode.Location = new System.Drawing.Point(173, 48);
            this.cmbProjectcode.Name = "cmbProjectcode";
            this.cmbProjectcode.Size = new System.Drawing.Size(344, 26);
            this.cmbProjectcode.TabIndex = 127;
            this.cmbProjectcode.SelectedIndexChanged += new System.EventHandler(this.cmbProjectcode_SelectedIndexChanged);
            // 
            // btnProjectSearch
            // 
            this.btnProjectSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnProjectSearch.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProjectSearch.Location = new System.Drawing.Point(523, 50);
            this.btnProjectSearch.Name = "btnProjectSearch";
            this.btnProjectSearch.Size = new System.Drawing.Size(24, 24);
            this.btnProjectSearch.TabIndex = 128;
            this.btnProjectSearch.Text = "....";
            this.btnProjectSearch.UseVisualStyleBackColor = false;
            this.btnProjectSearch.Click += new System.EventHandler(this.btnProjectSearch_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(605, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 19);
            this.label1.TabIndex = 170;
            this.label1.Text = "Activity/Task* :";
            // 
            // cmbSubTask
            // 
            this.cmbSubTask.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSubTask.DropDownHeight = 130;
            this.cmbSubTask.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSubTask.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSubTask.FormattingEnabled = true;
            this.cmbSubTask.IntegralHeight = false;
            this.cmbSubTask.Location = new System.Drawing.Point(721, 90);
            this.cmbSubTask.Name = "cmbSubTask";
            this.cmbSubTask.Size = new System.Drawing.Size(344, 26);
            this.cmbSubTask.TabIndex = 171;
            this.cmbSubTask.SelectedIndexChanged += new System.EventHandler(this.cmbActivityTask_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(55, 92);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 19);
            this.label6.TabIndex = 172;
            this.label6.Text = "Project Name :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(255, 140);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(149, 19);
            this.label13.TabIndex = 174;
            this.label13.Text = "Customization level :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(53, 140);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(109, 19);
            this.label9.TabIndex = 173;
            this.label9.Text = "Project 80/20 :";
            // 
            // lblprojname
            // 
            this.lblprojname.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprojname.ForeColor = System.Drawing.Color.Black;
            this.lblprojname.Location = new System.Drawing.Point(169, 90);
            this.lblprojname.Name = "lblprojname";
            this.lblprojname.Size = new System.Drawing.Size(407, 41);
            this.lblprojname.TabIndex = 175;
            // 
            // lbleighty
            // 
            this.lbleighty.AutoSize = true;
            this.lbleighty.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbleighty.ForeColor = System.Drawing.Color.Black;
            this.lbleighty.Location = new System.Drawing.Point(165, 140);
            this.lbleighty.Name = "lbleighty";
            this.lbleighty.Size = new System.Drawing.Size(0, 19);
            this.lbleighty.TabIndex = 176;
            // 
            // lblCustomizationLevel
            // 
            this.lblCustomizationLevel.AutoSize = true;
            this.lblCustomizationLevel.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomizationLevel.ForeColor = System.Drawing.Color.Black;
            this.lblCustomizationLevel.Location = new System.Drawing.Point(406, 140);
            this.lblCustomizationLevel.Name = "lblCustomizationLevel";
            this.lblCustomizationLevel.Size = new System.Drawing.Size(0, 19);
            this.lblCustomizationLevel.TabIndex = 177;
            // 
            // dgvTimeSheet
            // 
            this.dgvTimeSheet.AllowUserToAddRows = false;
            this.dgvTimeSheet.AllowUserToDeleteRows = false;
            this.dgvTimeSheet.AllowUserToOrderColumns = true;
            this.dgvTimeSheet.AllowUserToResizeRows = false;
            this.dgvTimeSheet.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvTimeSheet.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvTimeSheet.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTimeSheet.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvTimeSheet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTimeSheet.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID1,
            this.Username,
            this.UserDate,
            this.Week,
            this.ProjectCode,
            this.ProjectET,
            this.Customization,
            this.ActivityTask,
            this.SubTask,
            this.TotalHours,
            this.Remarks,
            this.RangeCapacity,
            this.ProductCode,
            this.ProductName,
            this.ProductSerialNumber});
            this.dgvTimeSheet.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvTimeSheet.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvTimeSheet.EnableHeadersVisualStyles = false;
            this.dgvTimeSheet.Location = new System.Drawing.Point(10, 360);
            this.dgvTimeSheet.MultiSelect = false;
            this.dgvTimeSheet.Name = "dgvTimeSheet";
            this.dgvTimeSheet.RowHeadersVisible = false;
            this.dgvTimeSheet.Size = new System.Drawing.Size(1293, 252);
            this.dgvTimeSheet.TabIndex = 180;
            this.dgvTimeSheet.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTimeSheet_CellDoubleClick);
            this.dgvTimeSheet.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvTimeSheet_KeyUp);
            // 
            // ID1
            // 
            this.ID1.DataPropertyName = "ID";
            this.ID1.Frozen = true;
            this.ID1.HeaderText = "ID";
            this.ID1.Name = "ID1";
            this.ID1.ReadOnly = true;
            this.ID1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ID1.Width = 27;
            // 
            // Username
            // 
            this.Username.DataPropertyName = "Username";
            this.Username.Frozen = true;
            this.Username.HeaderText = "User";
            this.Username.Name = "Username";
            this.Username.ReadOnly = true;
            this.Username.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Username.Width = 43;
            // 
            // UserDate
            // 
            this.UserDate.DataPropertyName = "UserDate";
            this.UserDate.Frozen = true;
            this.UserDate.HeaderText = "Date";
            this.UserDate.Name = "UserDate";
            this.UserDate.ReadOnly = true;
            this.UserDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UserDate.Width = 43;
            // 
            // Week
            // 
            this.Week.DataPropertyName = "Week";
            this.Week.Frozen = true;
            this.Week.HeaderText = "Week";
            this.Week.Name = "Week";
            this.Week.ReadOnly = true;
            this.Week.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Week.Width = 50;
            // 
            // ProjectCode
            // 
            this.ProjectCode.DataPropertyName = "ProjectCode";
            this.ProjectCode.Frozen = true;
            this.ProjectCode.HeaderText = "ProjectCode";
            this.ProjectCode.Name = "ProjectCode";
            this.ProjectCode.ReadOnly = true;
            this.ProjectCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectCode.Width = 90;
            // 
            // ProjectET
            // 
            this.ProjectET.DataPropertyName = "ProjectET";
            this.ProjectET.Frozen = true;
            this.ProjectET.HeaderText = "80/20";
            this.ProjectET.Name = "ProjectET";
            this.ProjectET.ReadOnly = true;
            this.ProjectET.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectET.Width = 48;
            // 
            // Customization
            // 
            this.Customization.DataPropertyName = "Customization";
            this.Customization.Frozen = true;
            this.Customization.HeaderText = "Cust*";
            this.Customization.Name = "Customization";
            this.Customization.ReadOnly = true;
            this.Customization.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Customization.Width = 48;
            // 
            // ActivityTask
            // 
            this.ActivityTask.DataPropertyName = "ActivityTask";
            this.ActivityTask.Frozen = true;
            this.ActivityTask.HeaderText = "Activity Task";
            this.ActivityTask.Name = "ActivityTask";
            this.ActivityTask.ReadOnly = true;
            this.ActivityTask.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ActivityTask.Width = 90;
            // 
            // SubTask
            // 
            this.SubTask.DataPropertyName = "SubTask";
            this.SubTask.Frozen = true;
            this.SubTask.HeaderText = "Sub Task";
            this.SubTask.Name = "SubTask";
            this.SubTask.ReadOnly = true;
            this.SubTask.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SubTask.Width = 66;
            // 
            // TotalHours
            // 
            this.TotalHours.DataPropertyName = "TotalHours";
            this.TotalHours.Frozen = true;
            this.TotalHours.HeaderText = "TotalHours";
            this.TotalHours.Name = "TotalHours";
            this.TotalHours.ReadOnly = true;
            this.TotalHours.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.TotalHours.Width = 80;
            // 
            // Remarks
            // 
            this.Remarks.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Remarks.DataPropertyName = "Remarks";
            this.Remarks.Frozen = true;
            this.Remarks.HeaderText = "Remarks";
            this.Remarks.Name = "Remarks";
            this.Remarks.ReadOnly = true;
            this.Remarks.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Remarks.Width = 67;
            // 
            // RangeCapacity
            // 
            this.RangeCapacity.DataPropertyName = "RangeCapacity";
            this.RangeCapacity.Frozen = true;
            this.RangeCapacity.HeaderText = "Range/Capacity";
            this.RangeCapacity.Name = "RangeCapacity";
            this.RangeCapacity.ReadOnly = true;
            this.RangeCapacity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RangeCapacity.Width = 110;
            // 
            // ProductCode
            // 
            this.ProductCode.DataPropertyName = "ProductCode";
            this.ProductCode.HeaderText = "ProductCode";
            this.ProductCode.Name = "ProductCode";
            this.ProductCode.ReadOnly = true;
            this.ProductCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductCode.Width = 94;
            // 
            // ProductName
            // 
            this.ProductName.DataPropertyName = "ProductName";
            this.ProductName.HeaderText = "ProductName";
            this.ProductName.Name = "ProductName";
            this.ProductName.ReadOnly = true;
            this.ProductName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductName.Width = 99;
            // 
            // ProductSerialNumber
            // 
            this.ProductSerialNumber.DataPropertyName = "ProductSerialNumber";
            this.ProductSerialNumber.HeaderText = "ProductSerialNumber";
            this.ProductSerialNumber.Name = "ProductSerialNumber";
            this.ProductSerialNumber.ReadOnly = true;
            this.ProductSerialNumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductSerialNumber.Width = 148;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(116, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 19);
            this.label2.TabIndex = 181;
            this.label2.Text = "Date :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(338, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 19);
            this.label3.TabIndex = 182;
            this.label3.Text = "Week :";
            // 
            // txtWeek
            // 
            this.txtWeek.Enabled = false;
            this.txtWeek.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWeek.Location = new System.Drawing.Point(399, 15);
            this.txtWeek.Name = "txtWeek";
            this.txtWeek.Size = new System.Drawing.Size(118, 23);
            this.txtWeek.TabIndex = 183;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(1108, 194);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(90, 39);
            this.btnSave.TabIndex = 184;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsername.ForeColor = System.Drawing.Color.Blue;
            this.lblUsername.Location = new System.Drawing.Point(719, 9);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(13, 19);
            this.lblUsername.TabIndex = 187;
            this.lblUsername.Text = ":\t";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(643, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 19);
            this.label5.TabIndex = 186;
            this.label5.Text = "Welcome :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(6, 334);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(133, 23);
            this.label4.TabIndex = 188;
            this.label4.Text = "Activity History";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(638, 92);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(80, 19);
            this.label7.TabIndex = 189;
            this.label7.Text = "SubTask* :";
            // 
            // cmbMainActivity
            // 
            this.cmbMainActivity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbMainActivity.DropDownHeight = 130;
            this.cmbMainActivity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMainActivity.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbMainActivity.FormattingEnabled = true;
            this.cmbMainActivity.IntegralHeight = false;
            this.cmbMainActivity.Location = new System.Drawing.Point(721, 48);
            this.cmbMainActivity.Name = "cmbMainActivity";
            this.cmbMainActivity.Size = new System.Drawing.Size(344, 26);
            this.cmbMainActivity.TabIndex = 190;
            this.cmbMainActivity.SelectedIndexChanged += new System.EventHandler(this.cmbSubTask_SelectedIndexChanged);
            // 
            // txtHours
            // 
            this.txtHours.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHours.Location = new System.Drawing.Point(721, 129);
            this.txtHours.Name = "txtHours";
            this.txtHours.Size = new System.Drawing.Size(118, 23);
            this.txtHours.TabIndex = 192;
            this.txtHours.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtHours_KeyPress);
            this.txtHours.Leave += new System.EventHandler(this.txtHours_Leave);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(649, 129);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(69, 19);
            this.label10.TabIndex = 191;
            this.label10.Text = "Hours * :";
            // 
            // lblHistoryHours
            // 
            this.lblHistoryHours.AutoSize = true;
            this.lblHistoryHours.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHistoryHours.ForeColor = System.Drawing.Color.Blue;
            this.lblHistoryHours.Location = new System.Drawing.Point(1261, 334);
            this.lblHistoryHours.Name = "lblHistoryHours";
            this.lblHistoryHours.Size = new System.Drawing.Size(20, 23);
            this.lblHistoryHours.TabIndex = 193;
            this.lblHistoryHours.Text = "0";
            this.lblHistoryHours.Click += new System.EventHandler(this.lblHistoryHours_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Blue;
            this.label11.Location = new System.Drawing.Point(1090, 334);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(175, 23);
            this.label11.TabIndex = 194;
            this.label11.Text = "Total Entered Hours :";
            // 
            // txtRemarks
            // 
            this.txtRemarks.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemarks.Location = new System.Drawing.Point(721, 163);
            this.txtRemarks.Multiline = true;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRemarks.Size = new System.Drawing.Size(344, 70);
            this.txtRemarks.TabIndex = 196;
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(582, 163);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(136, 19);
            this.label12.TabIndex = 195;
            this.label12.Text = "Remarks :";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(936, 9);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(100, 19);
            this.label14.TabIndex = 197;
            this.label14.Text = "Department :";
            // 
            // lblDepartment
            // 
            this.lblDepartment.AutoSize = true;
            this.lblDepartment.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDepartment.ForeColor = System.Drawing.Color.Blue;
            this.lblDepartment.Location = new System.Drawing.Point(1033, 9);
            this.lblDepartment.Name = "lblDepartment";
            this.lblDepartment.Size = new System.Drawing.Size(13, 19);
            this.lblDepartment.TabIndex = 198;
            this.lblDepartment.Text = ":\t";
            // 
            // pnHydraulics
            // 
            this.pnHydraulics.Controls.Add(this.label15);
            this.pnHydraulics.Controls.Add(this.cmbCapacity);
            this.pnHydraulics.Location = new System.Drawing.Point(842, 122);
            this.pnHydraulics.Name = "pnHydraulics";
            this.pnHydraulics.Size = new System.Drawing.Size(237, 39);
            this.pnHydraulics.TabIndex = 199;
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(19, 9);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(75, 19);
            this.label15.TabIndex = 191;
            this.label15.Text = "Capacity :";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cmbCapacity
            // 
            this.cmbCapacity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCapacity.DropDownHeight = 130;
            this.cmbCapacity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCapacity.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCapacity.FormattingEnabled = true;
            this.cmbCapacity.IntegralHeight = false;
            this.cmbCapacity.Items.AddRange(new object[] {
            "4 LPM",
            "11 LPM",
            "21 LPM",
            "40 LPM",
            "65 LPM",
            "90 LPM",
            "130 LPM",
            "260 LPM",
            "500 LPM"});
            this.cmbCapacity.Location = new System.Drawing.Point(97, 7);
            this.cmbCapacity.Name = "cmbCapacity";
            this.cmbCapacity.Size = new System.Drawing.Size(123, 26);
            this.cmbCapacity.TabIndex = 190;
            // 
            // cmbBOMProduct
            // 
            this.cmbBOMProduct.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbBOMProduct.DropDownHeight = 130;
            this.cmbBOMProduct.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBOMProduct.DropDownWidth = 239;
            this.cmbBOMProduct.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.cmbBOMProduct.FormattingEnabled = true;
            this.cmbBOMProduct.IntegralHeight = false;
            this.cmbBOMProduct.Location = new System.Drawing.Point(147, 9);
            this.cmbBOMProduct.Name = "cmbBOMProduct";
            this.cmbBOMProduct.Size = new System.Drawing.Size(382, 26);
            this.cmbBOMProduct.TabIndex = 202;
            this.cmbBOMProduct.SelectedIndexChanged += new System.EventHandler(this.cmbbomname_SelectedIndexChanged);
            // 
            // lblprdname
            // 
            this.lblprdname.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblprdname.ForeColor = System.Drawing.Color.Black;
            this.lblprdname.Location = new System.Drawing.Point(25, 68);
            this.lblprdname.Name = "lblprdname";
            this.lblprdname.Size = new System.Drawing.Size(119, 18);
            this.lblprdname.TabIndex = 200;
            this.lblprdname.Text = "Product Name :";
            this.lblprdname.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblprojectbom
            // 
            this.lblprojectbom.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblprojectbom.ForeColor = System.Drawing.Color.Black;
            this.lblprojectbom.Location = new System.Drawing.Point(15, 1);
            this.lblprojectbom.Name = "lblprojectbom";
            this.lblprojectbom.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblprojectbom.Size = new System.Drawing.Size(128, 43);
            this.lblprojectbom.TabIndex = 201;
            this.lblprojectbom.Text = "BOM Product :";
            this.lblprojectbom.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pnProduct
            // 
            this.pnProduct.Controls.Add(this.txtProductName);
            this.pnProduct.Controls.Add(this.txtSlNo);
            this.pnProduct.Controls.Add(this.label16);
            this.pnProduct.Controls.Add(this.lblprojectbom);
            this.pnProduct.Controls.Add(this.cmbBOMProduct);
            this.pnProduct.Controls.Add(this.lblprdname);
            this.pnProduct.Location = new System.Drawing.Point(15, 184);
            this.pnProduct.Name = "pnProduct";
            this.pnProduct.Size = new System.Drawing.Size(545, 147);
            this.pnProduct.TabIndex = 204;
            // 
            // txtProductName
            // 
            this.txtProductName.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProductName.Location = new System.Drawing.Point(147, 68);
            this.txtProductName.Name = "txtProductName";
            this.txtProductName.Size = new System.Drawing.Size(382, 23);
            this.txtProductName.TabIndex = 206;
            this.txtProductName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtProductName_KeyPress);
            // 
            // txtSlNo
            // 
            this.txtSlNo.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSlNo.Location = new System.Drawing.Point(147, 102);
            this.txtSlNo.Name = "txtSlNo";
            this.txtSlNo.Size = new System.Drawing.Size(382, 23);
            this.txtSlNo.TabIndex = 205;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(49, 102);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(95, 19);
            this.label16.TabIndex = 204;
            this.label16.Text = "Seraial No* :";
            // 
            // pnSubModule
            // 
            this.pnSubModule.Controls.Add(this.label19);
            this.pnSubModule.Controls.Add(this.cmbBackuprun);
            this.pnSubModule.Controls.Add(this.txtVersion);
            this.pnSubModule.Controls.Add(this.label18);
            this.pnSubModule.Controls.Add(this.txtSubModule);
            this.pnSubModule.Controls.Add(this.label17);
            this.pnSubModule.Location = new System.Drawing.Point(620, 239);
            this.pnSubModule.Name = "pnSubModule";
            this.pnSubModule.Size = new System.Drawing.Size(459, 119);
            this.pnSubModule.TabIndex = 205;
            this.pnSubModule.Visible = false;
            // 
            // label19
            // 
            this.label19.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(207, 3);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(109, 19);
            this.label19.TabIndex = 201;
            this.label19.Text = "Backup Run :";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cmbBackuprun
            // 
            this.cmbBackuprun.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbBackuprun.DropDownHeight = 130;
            this.cmbBackuprun.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBackuprun.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbBackuprun.FormattingEnabled = true;
            this.cmbBackuprun.IntegralHeight = false;
            this.cmbBackuprun.Items.AddRange(new object[] {
            "Yes",
            "No",
            "  "});
            this.cmbBackuprun.Location = new System.Drawing.Point(322, 1);
            this.cmbBackuprun.Name = "cmbBackuprun";
            this.cmbBackuprun.Size = new System.Drawing.Size(123, 26);
            this.cmbBackuprun.TabIndex = 200;
            // 
            // txtVersion
            // 
            this.txtVersion.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVersion.Location = new System.Drawing.Point(101, 1);
            this.txtVersion.Name = "txtVersion";
            this.txtVersion.Size = new System.Drawing.Size(100, 23);
            this.txtVersion.TabIndex = 199;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(28, 2);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(67, 19);
            this.label18.TabIndex = 198;
            this.label18.Text = "Version :";
            // 
            // txtSubModule
            // 
            this.txtSubModule.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSubModule.Location = new System.Drawing.Point(101, 28);
            this.txtSubModule.Multiline = true;
            this.txtSubModule.Name = "txtSubModule";
            this.txtSubModule.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtSubModule.Size = new System.Drawing.Size(344, 87);
            this.txtSubModule.TabIndex = 197;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(9, 29);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(87, 19);
            this.label17.TabIndex = 191;
            this.label17.Text = "Remarks * :";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnView
            // 
            this.btnView.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnView.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnView.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnView.Location = new System.Drawing.Point(1178, 4);
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(125, 32);
            this.btnView.TabIndex = 206;
            this.btnView.Text = "View Time Sheet";
            this.btnView.UseVisualStyleBackColor = false;
            this.btnView.Click += new System.EventHandler(this.btnView_Click);
            // 
            // dtpTimeSheetDate
            // 
            this.dtpTimeSheetDate.CustomFormat = "";
            this.dtpTimeSheetDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpTimeSheetDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpTimeSheetDate.Location = new System.Drawing.Point(173, 17);
            this.dtpTimeSheetDate.Name = "dtpTimeSheetDate";
            this.dtpTimeSheetDate.Size = new System.Drawing.Size(111, 26);
            this.dtpTimeSheetDate.TabIndex = 207;
            this.dtpTimeSheetDate.ValueChanged += new System.EventHandler(this.dtpTimeSheetDate_ValueChanged);
            // 
            // frmValidationTimeSheet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1306, 620);
            this.Controls.Add(this.dtpTimeSheetDate);
            this.Controls.Add(this.btnView);
            this.Controls.Add(this.pnSubModule);
            this.Controls.Add(this.pnProduct);
            this.Controls.Add(this.pnHydraulics);
            this.Controls.Add(this.lblDepartment);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtRemarks);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.lblHistoryHours);
            this.Controls.Add(this.txtHours);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cmbMainActivity);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblUsername);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtWeek);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dgvTimeSheet);
            this.Controls.Add(this.lblCustomizationLevel);
            this.Controls.Add(this.lbleighty);
            this.Controls.Add(this.lblprojname);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbSubTask);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.cmbProjectcode);
            this.Controls.Add(this.btnProjectSearch);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmValidationTimeSheet";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Validation Time Sheet";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmValidationTimeSheet_FormClosing);
            this.Load += new System.EventHandler(this.frmValidationTimeSheet_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTimeSheet)).EndInit();
            this.pnHydraulics.ResumeLayout(false);
            this.pnProduct.ResumeLayout(false);
            this.pnProduct.PerformLayout();
            this.pnSubModule.ResumeLayout(false);
            this.pnSubModule.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbProjectcode;
        private System.Windows.Forms.Button btnProjectSearch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbSubTask;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblprojname;
        private System.Windows.Forms.Label lbleighty;
        private System.Windows.Forms.Label lblCustomizationLevel;
        private System.Windows.Forms.DataGridView dgvTimeSheet;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtWeek;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbMainActivity;
        private System.Windows.Forms.TextBox txtHours;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblHistoryHours;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblDepartment;
        private System.Windows.Forms.Panel pnHydraulics;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox cmbCapacity;
        private System.Windows.Forms.ComboBox cmbBOMProduct;
        private System.Windows.Forms.Label lblprdname;
        private System.Windows.Forms.Label lblprojectbom;
        private System.Windows.Forms.Panel pnProduct;
        private System.Windows.Forms.TextBox txtSlNo;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Username;
        private System.Windows.Forms.DataGridViewTextBoxColumn UserDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Week;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectET;
        private System.Windows.Forms.DataGridViewTextBoxColumn Customization;
        private System.Windows.Forms.DataGridViewTextBoxColumn ActivityTask;
        private System.Windows.Forms.DataGridViewTextBoxColumn SubTask;
        private System.Windows.Forms.DataGridViewTextBoxColumn TotalHours;
        private System.Windows.Forms.DataGridViewTextBoxColumn Remarks;
        private System.Windows.Forms.DataGridViewTextBoxColumn RangeCapacity;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductSerialNumber;
        private System.Windows.Forms.TextBox txtProductName;
        private System.Windows.Forms.Panel pnSubModule;
        private System.Windows.Forms.TextBox txtSubModule;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtVersion;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button btnView;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox cmbBackuprun;
        private System.Windows.Forms.DateTimePicker dtpTimeSheetDate;
    }
}