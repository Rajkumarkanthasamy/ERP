﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Time_Sheet
{
    public partial class frmViewTimesheetforuser : Form
    {
        public frmViewTimesheetforuser()
        {
            InitializeComponent();
        }

        Login.frmLoginForm Loginfrm = new Login.frmLoginForm();
        DataAccessLayer DAL = new DataAccessLayer();
        Global GlobalClass = new Global();

        private void frmViewTimesheetforuser_Load(object sender, EventArgs e)
        {

        }

        DataTable dtResults = new DataTable();
        DataTable dtDates = new DataTable();
        private void btnSearch_Click(object sender, EventArgs e)
        {

            dtpfromdate.Format = DateTimePickerFormat.Custom;
            dtpfromdate.CustomFormat = "yyyy-MM-dd";
            dtptodate.Format = DateTimePickerFormat.Custom;
            dtptodate.CustomFormat = "yyyy-MM-dd";
            dgvReportView.DataSource = null;

            switch (Loginfrm.GetUserDetails[23])
            {
                case "Validation":
                case "Sales":
                case "Design":
                case "Integration":
                case "Testlab":
                case "Production":
                case "Projects":
                case "Electronics R&D":
                case "Quality"://Quality
                    dtResults = DAL.fnTimesheetSummary(61, dtpfromdate.Text, dtptodate.Text, Loginfrm.GetUserDetails[2]).Tables[0];
                    break;
                case "Hydraulics":
                case "Electricals":
                    dtResults = DAL.fnTimesheetSummary(71, dtpfromdate.Text, dtptodate.Text, Loginfrm.GetUserDetails[2]).Tables[0];
                    break;
                case "Electronics":
                    dtResults = DAL.fnTimesheetSummary(81, dtpfromdate.Text, dtptodate.Text, Loginfrm.GetUserDetails[2]).Tables[0];
                    break;
                case "Transducer":
                    dtResults = DAL.fnTimesheetSummary(812, dtpfromdate.Text, dtptodate.Text, Loginfrm.GetUserDetails[2]).Tables[0];
                    break;
                case "RnD":
                    dtResults = DAL.fnTimesheetSummary(95, dtpfromdate.Text, dtptodate.Text, Loginfrm.GetUserDetails[2]).Tables[0];
                    dtDates = DAL.fnTimesheetSummary(951, dtpfromdate.Text, dtptodate.Text, Loginfrm.GetUserDetails[2]).Tables[0];

                    foreach (DataRow dr in dtResults.Rows)
                    {
                        foreach (DataRow dr1 in dtDates.Rows)
                        {
                            if (dr1["Date"].ToString() == dr["Date"].ToString())
                            {
                                dr1.Delete();

                            }
                        }
                        dtDates.AcceptChanges();
                    }

                    dtResults.Merge(dtDates, true, MissingSchemaAction.Ignore);
           
            if (dtResults.Rows.Count > 0)
            {
                DataView view = dtResults.DefaultView;
                view.Sort = "Date ASC";
                dtResults = view.ToTable();
            }
            break;
            }
            if (dtResults.Rows.Count > 0)
            {
                dgvReportView.AutoGenerateColumns = true;
                dgvReportView.DataSource = dtResults;
                foreach (DataGridViewColumn column in dgvReportView.Columns)
                {
                    column.SortMode = DataGridViewColumnSortMode.NotSortable;
                }
                Datagridviewcolor();
            }

            dtpfromdate.Format = DateTimePickerFormat.Custom;
            dtpfromdate.CustomFormat = "dd-MM-yyyy";
            dtptodate.Format = DateTimePickerFormat.Custom;
            dtptodate.CustomFormat = "dd-MM-yyyy";
        }

        private void Datagridviewcolor()
        {
            if (Loginfrm.GetUserDetails[23] == "RnD")
            {
                foreach (DataGridViewRow row in dgvReportView.Rows)
                {
                    switch (row.Cells[5].Value.ToString())
                    {
                        case "Leave":
                            row.DefaultCellStyle.BackColor = Color.Yellow;
                            break;
                        case "Holiday":
                            row.DefaultCellStyle.BackColor = Color.LightBlue;
                            break;
                        case "Weekly Off":
                            row.DefaultCellStyle.BackColor = Color.LawnGreen;
                            break;
                        case "":
                            row.DefaultCellStyle.BackColor = Color.BurlyWood;
                            break;
                    }
                }
            }
            else
            {

            }

            foreach (DataGridViewRow row in dgvReportView.Rows)
            {
                switch (row.Cells[7].Value.ToString())
                {
                    case "Leave":
                        row.DefaultCellStyle.BackColor = Color.Yellow;
                        break;
                    case "Holiday":
                        row.DefaultCellStyle.BackColor = Color.LightBlue;
                        break;
                    case "Weekly Off":
                        row.DefaultCellStyle.BackColor = Color.LawnGreen;
                        break;
                }
            }
        }
    }
}
