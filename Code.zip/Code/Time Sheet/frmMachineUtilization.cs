﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Time_Sheet
{
    public partial class frmMachineUtilization : Form
    {
        public frmMachineUtilization()
        {
            InitializeComponent();
        }

        Login.frmLoginForm Loginfrm = new Login.frmLoginForm();
        DataAccessLayer DAL = new DataAccessLayer();
        Global GlobalClass = new Global();
        ValidationDocuments.frmValidationHome VHome = new ValidationDocuments.frmValidationHome();
        frmForm2 form = new frmForm2();
        private static string sProjectCode;
        public string fnProjectcode
        {
            get
            {
                return sProjectCode;
            }
            set
            {
                sProjectCode = value;
            }
        }

        public int sMachineUtilizationform = 0;

        private void btnProjectSearch_Click(object sender, EventArgs e)
        {
            sMachineUtilizationform = 1;
            Indent.frmProjectselect projectsearch = new Indent.frmProjectselect();
            projectsearch.fnMUform = sMachineUtilizationform.ToString();
            projectsearch.ShowDialog();
            if (fnProjectcode != null)
            {
                cmbProjectcode.Text = sProjectCode;
            }
        }

        DataTable dtLabDetails = new DataTable();
        DataTable dtMachineName = new DataTable();
        DataTable dtProjectList = new DataTable();
        private void frmMachineUtilization_Load(object sender, EventArgs e)
        {
            lblUsername.Text = Loginfrm.GetUserDetails[2];
            fnLoadData();
            cmbProjectcode.Items.Add("BiSS_001");
            cmbProjectcode.Items.Add("CAL_001");
            cmbProjectcode.Items.Add("LM_001");
            cmbProjectcode.Items.Add("RnD_001");
            cmbProjectcode.Items.Add("S&SP_001");
            cmbProjectcode.Items.Add("SP_001");
            dtProjectList = DAL.fnAllProjectList(null).Tables[0];
            foreach (DataRow DR in dtProjectList.Rows)
            {
                if (!cmbProjectcode.Items.Contains(DR["ProjectCode"].ToString()))
                    cmbProjectcode.Items.Add(DR["ProjectCode"].ToString());
            }

            dtLabDetails = DAL.fnDepartmentMachines(0, "").Tables[0];
            if (dtLabDetails.Rows.Count > 0)
            {
                foreach (DataRow dr in dtLabDetails.Rows)
                {
                    if (!cmbMainActivity.Items.Contains(dr["LabName"].ToString()))
                    {
                        cmbMainActivity.Items.Add(dr["LabName"].ToString());
                    }
                }
            }
            btnSave.Text = "Save";
        }

        private void cmbMainActivity_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbSubTask.Items.Clear();
            cmbSubTask.SelectedIndex = -1;
            dtMachineName = DAL.fnDepartmentMachines(1, cmbMainActivity.Text).Tables[0];
            if (dtMachineName.Rows.Count > 0)
            {
                foreach (DataRow dr in dtMachineName.Rows)
                {
                    if (!cmbSubTask.Items.Contains(dr["MachineName"].ToString()))
                    {
                        cmbSubTask.Items.Add(dr["MachineName"].ToString());
                    }
                }
            }
        }

        private void cmbProjectcode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbProjectcode.Text == "BiSS_001" || cmbProjectcode.Text == "RnD_001" || cmbProjectcode.Text == "S&SP_001" || cmbProjectcode.Text == "SP_001" || cmbProjectcode.Text == "CAL_001" || cmbProjectcode.Text == "LM_001")
            {
                if (cmbProjectcode.Text == "BiSS_001")
                {
                    lblprojname.Text = "BiSS Inhouse";
                }
                else if (cmbProjectcode.Text == "RnD_001")
                {
                    lblprojname.Text = "RnD";
                }
                else if (cmbProjectcode.Text == "S&SP_001")
                {
                    lblprojname.Text = "Sales & Service Product";
                }
                else if (cmbProjectcode.Text == "SP_001")
                {
                    lblprojname.Text = "Support Product";
                }
                else if (cmbProjectcode.Text == "CAL_001")
                {
                    lblprojname.Text = "Calibration";
                }
                else if (cmbProjectcode.Text == "LM_001")
                {
                    lblprojname.Text = "LM";
                }
            }
            else
            {
                DataView dvProject = new DataView(dtProjectList);
                dvProject.RowFilter = "ProjectCode Like'" + cmbProjectcode.Text + "'";
                DataTable dtrow = dvProject.ToTable();
                if (dtrow.Rows.Count > 0)
                {
                    lblprojname.Text = dtrow.Rows[0]["ProjectDescription"].ToString();
                    lblCutomer.Text= dtrow.Rows[0]["Customer"].ToString();
                }
            }
        }

        private void fnReload()
        {
            this.Hide();
            frmMachineUtilization Vtime = new frmMachineUtilization();
            Vtime.Show();
        }
        DataTable dtLoadData = new DataTable();
        private void fnLoadData()
        {
            var date = DateTime.Parse(dtpTimeSheetDate.Text);
            dtLoadData = DAL.fnMachineActivity(0, date.ToString("yyyy-MM-dd"), Loginfrm.GetUserDetails[2],"").Tables[0];
            dgvTimeSheet.AutoGenerateColumns = false;
            dgvTimeSheet.DataSource = dtLoadData;
            btnSave.Text = "Save";

            double sTotalHours = 0;
            if (dgvTimeSheet.Rows.Count > 0)
            {
                foreach (DataGridViewRow dgvr in dgvTimeSheet.Rows)
                {
                   sTotalHours += (Convert.ToDouble(dgvr.Cells["Hours"].Value));
                }
                lblHistoryHours.Text = sTotalHours.ToString();
            }
            else
            {
                lblHistoryHours.Text = "0";
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (cmbProjectcode.SelectedIndex >= 0 && cmbMainActivity.SelectedIndex >= 0 && cmbSubTask.SelectedIndex >= 0 && !string.IsNullOrEmpty(txtHours.Text))
            {
                if (btnSave.Text == "Save")
                {
                    GlobalClass.iSuccess = DAL.fnAddMachineUtilization(1, Loginfrm.GetUserDetails[2], dtpTimeSheetDate.Text, cmbProjectcode.Text, lblprojname.Text,
                        cmbMainActivity.Text, cmbSubTask.Text, cmbCapacity.Text, Convert.ToDouble(txtHours.Text), txtRemarks.Text,txtSrfnumber.Text,txtNoofSpecimen.Text);

                }
                else if (btnSave.Text == "Update")
                {
                    GlobalClass.iSuccess = DAL.fnAddMachineUtilization(2, ID.ToString(), dtpTimeSheetDate.Text, cmbProjectcode.Text, lblprojname.Text,
                        cmbMainActivity.Text, cmbSubTask.Text, cmbCapacity.Text, Convert.ToDouble(txtHours.Text), txtRemarks.Text, txtSrfnumber.Text, txtNoofSpecimen.Text);

                }
                fnReload();
            }
            else
            {
                if (cmbProjectcode.SelectedIndex < 0)
                {
                    MessageBox.Show("Select the Project code", "Error", 0, MessageBoxIcon.Error);
                    cmbProjectcode.DroppedDown = true;
                }

                else if (cmbMainActivity.SelectedIndex < 0)
                {
                    MessageBox.Show("Select the Lab", "Error", 0, MessageBoxIcon.Error);
                    cmbMainActivity.DroppedDown = true;
                }
                else if (cmbSubTask.SelectedIndex < 0)
                {
                    MessageBox.Show("Select the Machine", "Error", 0, MessageBoxIcon.Error);
                    cmbSubTask.DroppedDown = true;
                }
                else if (string.IsNullOrEmpty(txtHours.Text))
                {
                    MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                    txtHours.Focus();
                }
                else if (Convert.ToDouble(txtHours.Text) == 0)
                {
                    MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                    txtHours.Focus();
                }

            }
        }

        private void frmMachineUtilization_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            form.Show();
        }

        private void dtpTimeSheetDate_ValueChanged(object sender, EventArgs e)
        {
            fnLoadData();
        }
        int ID = 0;
        private void dgvTimeSheet_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvTimeSheet.Rows.Count > 0)
            {
                cmbMainActivity.SelectedItem = dgvTimeSheet.CurrentRow.Cells["LabName"].Value.ToString();
                cmbSubTask.SelectedItem = dgvTimeSheet.CurrentRow.Cells["MachineName"].Value.ToString();
                cmbCapacity.SelectedItem = dgvTimeSheet.CurrentRow.Cells["Capacity"].Value.ToString();
                cmbProjectcode.SelectedItem = dgvTimeSheet.CurrentRow.Cells["ProjectCode"].Value.ToString();
                ID = Convert.ToInt32(dgvTimeSheet.CurrentRow.Cells["ID1"].Value);
                txtRemarks.Text = dgvTimeSheet.CurrentRow.Cells["Remarks"].Value.ToString();

                txtHours.Text = dgvTimeSheet.CurrentRow.Cells["Hours"].Value.ToString();

                txtSrfnumber.Text = dgvTimeSheet.CurrentRow.Cells["SRFNumber"].Value.ToString();
                txtNoofSpecimen.Text = dgvTimeSheet.CurrentRow.Cells["NoofSpecimen"].Value.ToString();
                btnSave.Text = "Update";
            }
        }

        private void dgvTimeSheet_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (dgvTimeSheet.Rows.Count > 0)
                {
                    DialogResult DR = MessageBox.Show("Do you want to delete selected?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (DR == DialogResult.Yes)
                    {
                        GlobalClass.iSuccess = DAL.fnAddMachineUtilization(3, dgvTimeSheet.CurrentRow.Cells["ID1"].Value.ToString(), dtpTimeSheetDate.Text, cmbProjectcode.Text, lblprojname.Text,
                        cmbMainActivity.Text, cmbSubTask.Text, cmbCapacity.Text, 0, txtRemarks.Text,"","");
                        dgvTimeSheet.Rows.RemoveAt(dgvTimeSheet.Rows.IndexOf(dgvTimeSheet.CurrentRow));
                        fnLoadData();
                    }
                }
            }
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmMachineUtilizationView view = new frmMachineUtilizationView();
            view.Show();
        }
    }
}
