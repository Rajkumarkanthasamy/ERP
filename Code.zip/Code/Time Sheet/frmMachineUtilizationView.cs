﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Time_Sheet
{
    public partial class frmMachineUtilizationView : Form
    {
        public frmMachineUtilizationView()
        {
            InitializeComponent();
        }

        Login.frmLoginForm Loginfrm = new Login.frmLoginForm();
        DataAccessLayer DAL = new DataAccessLayer();
        Global GlobalClass = new Global();
        ValidationDocuments.frmValidationHome VHome = new ValidationDocuments.frmValidationHome();

        DataTable dtLoadData = new DataTable();
        private void frmMachineUtilizationView_Load(object sender, EventArgs e)
        {
            fnLoadData();
        }

        private void fnLoadData()
        {
            dtpfromdate.Format = DateTimePickerFormat.Custom;
            dtpfromdate.CustomFormat = "yyyy-MM-dd";
            dtptodate.Format = DateTimePickerFormat.Custom;
            dtptodate.CustomFormat = "yyyy-MM-dd";
            dgvReportView.DataSource = null;
            dtLoadData = DAL.fnMachineActivity(1, dtpfromdate.Text, Loginfrm.GetUserDetails[2], dtptodate.Text).Tables[0];
            dgvReportView.AutoGenerateColumns = true;
            dgvReportView.DataSource = dtLoadData;
            dtpfromdate.Format = DateTimePickerFormat.Custom;
            dtpfromdate.CustomFormat = "dd-MM-yyyy";
            dtptodate.Format = DateTimePickerFormat.Custom;
            dtptodate.CustomFormat = "dd-MM-yyyy";
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            fnLoadData();
        }

        private void frmMachineUtilizationView_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            frmMachineUtilization frmMachineUtilization = new frmMachineUtilization();
            frmMachineUtilization.Show();
        }

        DataTable dtClone = new DataTable();
        BindingSource bsIteSearch = new BindingSource();
        private void txtItemSearch_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtItemSearch.TextLength > 2)
            {
                dtClone = dtLoadData.Copy();
                bsIteSearch.DataSource = dtClone;

                bsIteSearch.Filter = string.Format("Username LIKE '%{0}%' OR LabName LIKE '%{0}%'  or MachineName LIKE '%{0}%'  or ProjectCode LIKE '%{0}%'  or ProjectName LIKE '%{0}%'", txtItemSearch.Text);
                dgvReportView.DataSource = bsIteSearch;

            }
            else
            {
                bsIteSearch.RemoveFilter();
            }
        }
    }
}
