﻿
namespace Erp_Project_With_Buttons.Time_Sheet
{
    partial class frmMachineUtilization
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMachineUtilization));
            this.label7 = new System.Windows.Forms.Label();
            this.cmbMainActivity = new System.Windows.Forms.ComboBox();
            this.lblUsername = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblprojname = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbSubTask = new System.Windows.Forms.ComboBox();
            this.dtpTimeSheetDate = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbProjectcode = new System.Windows.Forms.ComboBox();
            this.btnProjectSearch = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.cmbCapacity = new System.Windows.Forms.ComboBox();
            this.txtHours = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dgvTimeSheet = new System.Windows.Forms.DataGridView();
            this.ID1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Username = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UserDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Week = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LabName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MachineName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Capacity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Hours = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Remarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SRFNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NoofSpecimen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label11 = new System.Windows.Forms.Label();
            this.lblHistoryHours = new System.Windows.Forms.Label();
            this.btnView = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lblCutomer = new System.Windows.Forms.Label();
            this.txtSrfnumber = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtNoofSpecimen = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTimeSheet)).BeginInit();
            this.SuspendLayout();
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(594, 103);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 19);
            this.label7.TabIndex = 212;
            this.label7.Text = "Machine* :";
            // 
            // cmbMainActivity
            // 
            this.cmbMainActivity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbMainActivity.DropDownHeight = 130;
            this.cmbMainActivity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMainActivity.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbMainActivity.FormattingEnabled = true;
            this.cmbMainActivity.IntegralHeight = false;
            this.cmbMainActivity.Location = new System.Drawing.Point(686, 59);
            this.cmbMainActivity.Name = "cmbMainActivity";
            this.cmbMainActivity.Size = new System.Drawing.Size(344, 26);
            this.cmbMainActivity.TabIndex = 213;
            this.cmbMainActivity.SelectedIndexChanged += new System.EventHandler(this.cmbMainActivity_SelectedIndexChanged);
            // 
            // lblUsername
            // 
            this.lblUsername.AutoSize = true;
            this.lblUsername.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsername.ForeColor = System.Drawing.Color.Blue;
            this.lblUsername.Location = new System.Drawing.Point(674, 9);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(13, 19);
            this.lblUsername.TabIndex = 211;
            this.lblUsername.Text = ":\t";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(598, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 19);
            this.label5.TabIndex = 210;
            this.label5.Text = "Welcome :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(84, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 19);
            this.label2.TabIndex = 207;
            this.label2.Text = "Date* :";
            // 
            // lblprojname
            // 
            this.lblprojname.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprojname.ForeColor = System.Drawing.Color.Black;
            this.lblprojname.Location = new System.Drawing.Point(141, 101);
            this.lblprojname.Name = "lblprojname";
            this.lblprojname.Size = new System.Drawing.Size(344, 46);
            this.lblprojname.TabIndex = 206;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(31, 101);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 19);
            this.label6.TabIndex = 205;
            this.label6.Text = "Project Name :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(629, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 19);
            this.label1.TabIndex = 203;
            this.label1.Text = "Lab* :";
            // 
            // cmbSubTask
            // 
            this.cmbSubTask.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSubTask.DropDownHeight = 130;
            this.cmbSubTask.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSubTask.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSubTask.FormattingEnabled = true;
            this.cmbSubTask.IntegralHeight = false;
            this.cmbSubTask.Location = new System.Drawing.Point(686, 100);
            this.cmbSubTask.Name = "cmbSubTask";
            this.cmbSubTask.Size = new System.Drawing.Size(344, 26);
            this.cmbSubTask.TabIndex = 204;
            // 
            // dtpTimeSheetDate
            // 
            this.dtpTimeSheetDate.CustomFormat = "";
            this.dtpTimeSheetDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpTimeSheetDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpTimeSheetDate.Location = new System.Drawing.Point(143, 17);
            this.dtpTimeSheetDate.Name = "dtpTimeSheetDate";
            this.dtpTimeSheetDate.Size = new System.Drawing.Size(125, 26);
            this.dtpTimeSheetDate.TabIndex = 202;
            this.dtpTimeSheetDate.ValueChanged += new System.EventHandler(this.dtpTimeSheetDate_ValueChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(29, 59);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(112, 19);
            this.label8.TabIndex = 199;
            this.label8.Text = "Project Code* :";
            // 
            // cmbProjectcode
            // 
            this.cmbProjectcode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProjectcode.DropDownHeight = 130;
            this.cmbProjectcode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProjectcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProjectcode.FormattingEnabled = true;
            this.cmbProjectcode.IntegralHeight = false;
            this.cmbProjectcode.Location = new System.Drawing.Point(141, 57);
            this.cmbProjectcode.Name = "cmbProjectcode";
            this.cmbProjectcode.Size = new System.Drawing.Size(344, 26);
            this.cmbProjectcode.TabIndex = 200;
            this.cmbProjectcode.SelectedIndexChanged += new System.EventHandler(this.cmbProjectcode_SelectedIndexChanged);
            // 
            // btnProjectSearch
            // 
            this.btnProjectSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnProjectSearch.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProjectSearch.Location = new System.Drawing.Point(491, 59);
            this.btnProjectSearch.Name = "btnProjectSearch";
            this.btnProjectSearch.Size = new System.Drawing.Size(24, 24);
            this.btnProjectSearch.TabIndex = 201;
            this.btnProjectSearch.Text = "....";
            this.btnProjectSearch.UseVisualStyleBackColor = false;
            this.btnProjectSearch.Click += new System.EventHandler(this.btnProjectSearch_Click);
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(602, 143);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(78, 19);
            this.label15.TabIndex = 191;
            this.label15.Text = "Capacity :";
            // 
            // cmbCapacity
            // 
            this.cmbCapacity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCapacity.DropDownHeight = 130;
            this.cmbCapacity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCapacity.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCapacity.FormattingEnabled = true;
            this.cmbCapacity.IntegralHeight = false;
            this.cmbCapacity.Items.AddRange(new object[] {
            "1 kN",
            "2 kN",
            "5 kN",
            "10 kN",
            "15 kN",
            "25 kN",
            "50 kN",
            "100 kN",
            "150 kN",
            "200 kN",
            "300 kN",
            "500 kN",
            "1000 kN",
            "2000 kN",
            "100 N",
            "200 N ",
            "500 N",
            "2000 Nm"});
            this.cmbCapacity.Location = new System.Drawing.Point(686, 141);
            this.cmbCapacity.Name = "cmbCapacity";
            this.cmbCapacity.Size = new System.Drawing.Size(118, 26);
            this.cmbCapacity.TabIndex = 190;
            // 
            // txtHours
            // 
            this.txtHours.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHours.Location = new System.Drawing.Point(912, 144);
            this.txtHours.Name = "txtHours";
            this.txtHours.Size = new System.Drawing.Size(118, 23);
            this.txtHours.TabIndex = 215;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(844, 146);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 19);
            this.label10.TabIndex = 214;
            this.label10.Text = "Hours* :";
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(1059, 280);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(82, 39);
            this.btnSave.TabIndex = 217;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtRemarks
            // 
            this.txtRemarks.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemarks.Location = new System.Drawing.Point(686, 256);
            this.txtRemarks.Multiline = true;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRemarks.Size = new System.Drawing.Size(347, 63);
            this.txtRemarks.TabIndex = 219;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(605, 256);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(75, 19);
            this.label17.TabIndex = 218;
            this.label17.Text = "Remarks :";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(11, 305);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(141, 23);
            this.label4.TabIndex = 221;
            this.label4.Text = "Machine History";
            // 
            // dgvTimeSheet
            // 
            this.dgvTimeSheet.AllowUserToAddRows = false;
            this.dgvTimeSheet.AllowUserToDeleteRows = false;
            this.dgvTimeSheet.AllowUserToOrderColumns = true;
            this.dgvTimeSheet.AllowUserToResizeRows = false;
            this.dgvTimeSheet.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvTimeSheet.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvTimeSheet.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTimeSheet.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvTimeSheet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTimeSheet.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID1,
            this.Username,
            this.UserDate,
            this.Week,
            this.ProjectCode,
            this.ProjectName,
            this.LabName,
            this.MachineName,
            this.Capacity,
            this.Hours,
            this.Remarks,
            this.SRFNumber,
            this.NoofSpecimen});
            this.dgvTimeSheet.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvTimeSheet.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvTimeSheet.EnableHeadersVisualStyles = false;
            this.dgvTimeSheet.Location = new System.Drawing.Point(12, 331);
            this.dgvTimeSheet.MultiSelect = false;
            this.dgvTimeSheet.Name = "dgvTimeSheet";
            this.dgvTimeSheet.RowHeadersVisible = false;
            this.dgvTimeSheet.Size = new System.Drawing.Size(1147, 210);
            this.dgvTimeSheet.TabIndex = 220;
            this.dgvTimeSheet.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTimeSheet_CellDoubleClick);
            this.dgvTimeSheet.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvTimeSheet_KeyUp);
            // 
            // ID1
            // 
            this.ID1.DataPropertyName = "ID";
            this.ID1.Frozen = true;
            this.ID1.HeaderText = "ID";
            this.ID1.Name = "ID1";
            this.ID1.ReadOnly = true;
            this.ID1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ID1.Width = 27;
            // 
            // Username
            // 
            this.Username.DataPropertyName = "Username";
            this.Username.Frozen = true;
            this.Username.HeaderText = "User";
            this.Username.Name = "Username";
            this.Username.ReadOnly = true;
            this.Username.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Username.Width = 43;
            // 
            // UserDate
            // 
            this.UserDate.DataPropertyName = "UserDate";
            this.UserDate.Frozen = true;
            this.UserDate.HeaderText = "Date";
            this.UserDate.Name = "UserDate";
            this.UserDate.ReadOnly = true;
            this.UserDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UserDate.Width = 43;
            // 
            // Week
            // 
            this.Week.DataPropertyName = "Week";
            this.Week.Frozen = true;
            this.Week.HeaderText = "Week";
            this.Week.Name = "Week";
            this.Week.ReadOnly = true;
            this.Week.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Week.Width = 50;
            // 
            // ProjectCode
            // 
            this.ProjectCode.DataPropertyName = "ProjectCode";
            this.ProjectCode.Frozen = true;
            this.ProjectCode.HeaderText = "ProjectCode";
            this.ProjectCode.Name = "ProjectCode";
            this.ProjectCode.ReadOnly = true;
            this.ProjectCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectCode.Width = 90;
            // 
            // ProjectName
            // 
            this.ProjectName.DataPropertyName = "ProjectName";
            this.ProjectName.Frozen = true;
            this.ProjectName.HeaderText = "ProjectName";
            this.ProjectName.Name = "ProjectName";
            this.ProjectName.ReadOnly = true;
            this.ProjectName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectName.Width = 95;
            // 
            // LabName
            // 
            this.LabName.DataPropertyName = "LabName";
            this.LabName.Frozen = true;
            this.LabName.HeaderText = "Lab";
            this.LabName.Name = "LabName";
            this.LabName.ReadOnly = true;
            this.LabName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.LabName.Width = 35;
            // 
            // MachineName
            // 
            this.MachineName.DataPropertyName = "MachineName";
            this.MachineName.Frozen = true;
            this.MachineName.HeaderText = "Machine";
            this.MachineName.Name = "MachineName";
            this.MachineName.ReadOnly = true;
            this.MachineName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.MachineName.Width = 68;
            // 
            // Capacity
            // 
            this.Capacity.DataPropertyName = "Capacity";
            this.Capacity.Frozen = true;
            this.Capacity.HeaderText = "Capacity";
            this.Capacity.Name = "Capacity";
            this.Capacity.ReadOnly = true;
            this.Capacity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Capacity.Width = 66;
            // 
            // Hours
            // 
            this.Hours.DataPropertyName = "Hours";
            this.Hours.Frozen = true;
            this.Hours.HeaderText = "Hours";
            this.Hours.Name = "Hours";
            this.Hours.ReadOnly = true;
            this.Hours.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Hours.Width = 50;
            // 
            // Remarks
            // 
            this.Remarks.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Remarks.DataPropertyName = "Remarks";
            this.Remarks.Frozen = true;
            this.Remarks.HeaderText = "Remarks";
            this.Remarks.Name = "Remarks";
            this.Remarks.ReadOnly = true;
            this.Remarks.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Remarks.Width = 67;
            // 
            // SRFNumber
            // 
            this.SRFNumber.DataPropertyName = "SRFNumber";
            this.SRFNumber.HeaderText = "SRFNumber";
            this.SRFNumber.Name = "SRFNumber";
            this.SRFNumber.ReadOnly = true;
            this.SRFNumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SRFNumber.Width = 87;
            // 
            // NoofSpecimen
            // 
            this.NoofSpecimen.DataPropertyName = "NoofSpecimen";
            this.NoofSpecimen.HeaderText = "NoofSpecimen";
            this.NoofSpecimen.Name = "NoofSpecimen";
            this.NoofSpecimen.ReadOnly = true;
            this.NoofSpecimen.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.NoofSpecimen.Width = 106;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Blue;
            this.label11.Location = new System.Drawing.Point(283, 305);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(175, 23);
            this.label11.TabIndex = 223;
            this.label11.Text = "Total Entered Hours :";
            // 
            // lblHistoryHours
            // 
            this.lblHistoryHours.AutoSize = true;
            this.lblHistoryHours.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHistoryHours.ForeColor = System.Drawing.Color.Blue;
            this.lblHistoryHours.Location = new System.Drawing.Point(454, 305);
            this.lblHistoryHours.Name = "lblHistoryHours";
            this.lblHistoryHours.Size = new System.Drawing.Size(20, 23);
            this.lblHistoryHours.TabIndex = 222;
            this.lblHistoryHours.Text = "0";
            // 
            // btnView
            // 
            this.btnView.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnView.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnView.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnView.Location = new System.Drawing.Point(999, 4);
            this.btnView.Name = "btnView";
            this.btnView.Size = new System.Drawing.Size(160, 32);
            this.btnView.TabIndex = 224;
            this.btnView.Text = "View Machine History";
            this.btnView.UseVisualStyleBackColor = false;
            this.btnView.Click += new System.EventHandler(this.btnView_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(59, 161);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 19);
            this.label3.TabIndex = 225;
            this.label3.Text = "Customer :";
            // 
            // lblCutomer
            // 
            this.lblCutomer.AutoSize = true;
            this.lblCutomer.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCutomer.ForeColor = System.Drawing.Color.Black;
            this.lblCutomer.Location = new System.Drawing.Point(141, 161);
            this.lblCutomer.Name = "lblCutomer";
            this.lblCutomer.Size = new System.Drawing.Size(0, 19);
            this.lblCutomer.TabIndex = 226;
            // 
            // txtSrfnumber
            // 
            this.txtSrfnumber.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSrfnumber.Location = new System.Drawing.Point(686, 182);
            this.txtSrfnumber.Name = "txtSrfnumber";
            this.txtSrfnumber.Size = new System.Drawing.Size(344, 23);
            this.txtSrfnumber.TabIndex = 228;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(579, 186);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(101, 19);
            this.label9.TabIndex = 227;
            this.label9.Text = "SRF Number :";
            // 
            // txtNoofSpecimen
            // 
            this.txtNoofSpecimen.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNoofSpecimen.Location = new System.Drawing.Point(686, 220);
            this.txtNoofSpecimen.Name = "txtNoofSpecimen";
            this.txtNoofSpecimen.Size = new System.Drawing.Size(344, 23);
            this.txtNoofSpecimen.TabIndex = 230;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(555, 224);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(125, 19);
            this.label12.TabIndex = 229;
            this.label12.Text = "No of Specimen :";
            // 
            // frmMachineUtilization
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1171, 553);
            this.Controls.Add(this.txtNoofSpecimen);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtSrfnumber);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lblCutomer);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnView);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.lblHistoryHours);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dgvTimeSheet);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.cmbCapacity);
            this.Controls.Add(this.txtRemarks);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.txtHours);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cmbMainActivity);
            this.Controls.Add(this.lblUsername);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblprojname);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbSubTask);
            this.Controls.Add(this.dtpTimeSheetDate);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.cmbProjectcode);
            this.Controls.Add(this.btnProjectSearch);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmMachineUtilization";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Machine Utilization";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMachineUtilization_FormClosing);
            this.Load += new System.EventHandler(this.frmMachineUtilization_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTimeSheet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbMainActivity;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblprojname;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbSubTask;
        private System.Windows.Forms.DateTimePicker dtpTimeSheetDate;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbProjectcode;
        private System.Windows.Forms.Button btnProjectSearch;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox cmbCapacity;
        private System.Windows.Forms.TextBox txtHours;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dgvTimeSheet;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblHistoryHours;
        private System.Windows.Forms.Button btnView;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblCutomer;
        private System.Windows.Forms.TextBox txtSrfnumber;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtNoofSpecimen;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Username;
        private System.Windows.Forms.DataGridViewTextBoxColumn UserDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Week;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectName;
        private System.Windows.Forms.DataGridViewTextBoxColumn LabName;
        private System.Windows.Forms.DataGridViewTextBoxColumn MachineName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Capacity;
        private System.Windows.Forms.DataGridViewTextBoxColumn Hours;
        private System.Windows.Forms.DataGridViewTextBoxColumn Remarks;
        private System.Windows.Forms.DataGridViewTextBoxColumn SRFNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn NoofSpecimen;
    }
}