﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.Diagnostics;
using System.IO;

namespace Erp_Project_With_Buttons.Time_Sheet
{
    public partial class frmTimesheetView : Form
    {
        public frmTimesheetView()
        {
            InitializeComponent();
        }

        private void Datagridviewcolor()
        {
            if (cmbDepartment.Text == "RnD")
            {
                foreach (DataGridViewRow row in dgvSummaryReport.Rows)
                {
                    switch (row.Cells[5].Value.ToString())
                    {
                        case "Leave":
                            row.DefaultCellStyle.BackColor = Color.Yellow;
                            break;
                        case "Holiday":
                            row.DefaultCellStyle.BackColor = Color.LightBlue;
                            break;
                        case "Weekly Off":
                            row.DefaultCellStyle.BackColor = Color.Green;
                            break;
                        case "":
                            if (cmbreporttype.Text == "Individual User Time Sheet")
                            {
                                row.DefaultCellStyle.BackColor = Color.BurlyWood;
                            }
                            break;
                    }
                }
            }

            else if (cmbDepartment.Text == "Validation" || cmbDepartment.Text == "Design" || cmbDepartment.Text == "Sales")
            {
                foreach (DataGridViewRow row in dgvSummaryReport.Rows)
                {
                    switch (row.Cells[9].Value.ToString())
                    {
                        case "Leave":
                            row.DefaultCellStyle.BackColor = Color.Yellow;
                            break;
                        case "Holiday":
                            row.DefaultCellStyle.BackColor = Color.LightBlue;
                            break;
                        case "Weekly Off":
                            row.DefaultCellStyle.BackColor = Color.Green;
                            break;
                        case "":
                            row.DefaultCellStyle.BackColor = Color.BurlyWood;
                            break;
                    }
                }
            }

            else
            {
                foreach (DataGridViewRow row in dgvSummaryReport.Rows)
                {
                    switch (row.Cells[7].Value.ToString())
                    {
                        case "Leave":
                            row.DefaultCellStyle.BackColor = Color.Yellow;
                            break;
                        case "Holiday":
                            row.DefaultCellStyle.BackColor = Color.LightBlue;
                            break;
                        case "Weekly Off":
                            row.DefaultCellStyle.BackColor = Color.Green;
                            break;
                        case "":
                            row.DefaultCellStyle.BackColor = Color.BurlyWood;
                            break;
                    }
                }
            }
        }

        Login.frmLoginForm Loginfrm = new Login.frmLoginForm();
        DataAccessLayer DAL = new DataAccessLayer();
        Global GlobalClass = new Global();
        ValidationDocuments.frmValidationHome VHome = new ValidationDocuments.frmValidationHome();
        DataTable dtResults = new DataTable();
        frmForm2 form = new frmForm2();
        DataTable dtDates = new DataTable();

        private void btnSearch_Click(object sender, EventArgs e)
        {
            dtpfromdate.Format = DateTimePickerFormat.Custom;
            dtpfromdate.CustomFormat = "yyyy-MM-dd";
            dtptodate.Format = DateTimePickerFormat.Custom;
            dtptodate.CustomFormat = "yyyy-MM-dd";
            dgvSummaryReport.DataSource = null;
            switch (cmbreporttype.Text)
            {
                case "Projectwise Summary":
                    dtResults = DAL.fnTimesheetSummary(0, dtpfromdate.Text, dtptodate.Text, cmbDepartment.Text).Tables[0];
                    if (dtResults.Rows.Count > 0)
                    {
                        dtResults.Rows.Add("", "", null);
                        dtResults.Rows.Add("Grand Total", "", Convert.ToDouble(dtResults.Compute("Sum([TotalHours])", "")));

                        dgvSummaryReport.AutoGenerateColumns = true;
                        dgvSummaryReport.DataSource = dtResults;

                        fnPlotGraph("ProjectCode", "ProjectCode");
                    }
                    break;
                case "Individual User Time Sheet":
                    if (cmbDepartment.Text == "Validation" || cmbDepartment.Text == "Design" || cmbDepartment.Text == "Sales" || cmbDepartment.Text == "Testlab" || cmbDepartment.Text == "Production" || cmbDepartment.Text == "Projects" || cmbDepartment.Text== "Electronics R&D")
                    {
                        dtResults = DAL.fnTimesheetSummary(65, dtpfromdate.Text, dtptodate.Text, cmbUser.Text).Tables[0];
                    }
                    else if (cmbDepartment.Text == "Hydraulics" || cmbDepartment.Text == "Electricals")
                    {
                        dtResults = DAL.fnTimesheetSummary(75, dtpfromdate.Text, dtptodate.Text, cmbUser.Text).Tables[0];
                    }
                    else if (cmbDepartment.Text == "Electronics")
                    {
                        dtResults = DAL.fnTimesheetSummary(85, dtpfromdate.Text, dtptodate.Text, cmbUser.Text).Tables[0];
                    }
                    else if (cmbDepartment.Text == "Transducer")
                    {
                        dtResults = DAL.fnTimesheetSummary(825, dtpfromdate.Text, dtptodate.Text, cmbUser.Text).Tables[0];
                    }
                    else if (cmbDepartment.Text == "RnD")
                    {
                        dtResults = DAL.fnTimesheetSummary(95, dtpfromdate.Text, dtptodate.Text, cmbUser.Text).Tables[0];
                        dtDates = DAL.fnTimesheetSummary(951, dtpfromdate.Text, dtptodate.Text, cmbUser.Text).Tables[0];

                        foreach (DataRow dr in dtResults.Rows)
                        {
                            foreach (DataRow dr1 in dtDates.Rows)
                            {
                                if (dr1["Date"].ToString() == dr["Date"].ToString())
                                {
                                    dr1.Delete();

                                }
                            }
                            dtDates.AcceptChanges();
                        }

                        dtResults.Merge(dtDates, true, MissingSchemaAction.Ignore);
                    }
                    if (dtResults.Rows.Count > 0)
                    {

                        DataView view = dtResults.DefaultView;
                        view.Sort = "Date ASC";
                        dtResults = view.ToTable();
                        DataTable dtExcelImport = new DataTable();

                        dgvSummaryReport.AutoGenerateColumns = true;
                        dgvSummaryReport.DataSource = dtResults;
                        Datagridviewcolor();
                    }
                    break;
                case "Activitywise Summary":
                    dtResults = DAL.fnTimesheetSummary(1, dtpfromdate.Text, dtptodate.Text, cmbDepartment.Text).Tables[0];
                    if (dtResults.Rows.Count > 0)
                    {
                        dtResults.Rows.Add("", null);
                        dtResults.Rows.Add("Grand Total", Convert.ToDouble(dtResults.Compute("Sum([TotalHours])", "")));
                        dgvSummaryReport.AutoGenerateColumns = true;
                        dgvSummaryReport.DataSource = dtResults;
                        fnPlotGraph("ActivityTask", "SubTask");
                    }
                    break;

                case "User Activitywise Summary":
                    dtResults = DAL.fnTimesheetSummary(5, dtpfromdate.Text, dtptodate.Text, cmbUser.Text).Tables[0];
                    if (dtResults.Rows.Count > 0)
                    {
                        dtResults.Rows.Add("", null);
                        dtResults.Rows.Add("Grand Total", Convert.ToDouble(dtResults.Compute("Sum([TotalHours])", "")));
                        dgvSummaryReport.AutoGenerateColumns = true;
                        dgvSummaryReport.DataSource = dtResults;
                        fnPlotGraph("ActivityTask", "SubTask");
                    }
                    break;
                case "Weekly Summary":
                    dtResults = DAL.fnTimesheetSummary(2, dtpfromdate.Text, dtptodate.Text, cmbDepartment.Text).Tables[0];
                    if (dtResults.Rows.Count > 0)
                    {
                        dtResults.Rows.Add("", null);
                        dtResults.Rows.Add("Grand Total", Convert.ToDouble(dtResults.Compute("Sum([TotalHours])", "")));

                        dgvSummaryReport.AutoGenerateColumns = true;
                        dgvSummaryReport.DataSource = dtResults;
                        fnPlotGraph("Week", "Week");
                    }
                    break;

                case "User Summary":
                    dtResults = DAL.fnTimesheetSummary(4, dtpfromdate.Text, dtptodate.Text, cmbDepartment.Text).Tables[0];
                    if (dtResults.Rows.Count > 0)
                    {
                        dtResults.Rows.Add("", null);
                        dtResults.Rows.Add("Grand Total", Convert.ToDouble(dtResults.Compute("Sum([TotalHours])", "")));

                        dgvSummaryReport.AutoGenerateColumns = true;
                        dgvSummaryReport.DataSource = dtResults;
                        fnPlotGraph("Username", "Username");
                    }
                    break;

                case "All Department Time Sheet":
                    dtResults = DAL.fnTimesheetSummary(651, dtpfromdate.Text, dtptodate.Text, cmbDepartment.Text).Tables[0];
                    if (dtResults.Rows.Count > 0)
                    {
                        dgvSummaryReport.AutoGenerateColumns = true;
                        dgvSummaryReport.DataSource = dtResults;
                    }

                    break;

                case "All Department Project Time Sheet":
                    dtResults = DAL.fnTimesheetSummary(652, dtpfromdate.Text, dtptodate.Text, cmbDepartment.Text).Tables[0];
                    if (dtResults.Rows.Count > 0)
                    {
                        dgvSummaryReport.AutoGenerateColumns = true;
                        dgvSummaryReport.DataSource = dtResults;
                    }
                    break;
                case "Department Time Sheet":
                    if (cmbDepartment.Text == "Validation" || cmbDepartment.Text == "Testlab" || cmbDepartment.Text == "Design" || cmbDepartment.Text == "Sales" || cmbDepartment.Text == "Production" || cmbDepartment.Text == "Projects" || cmbDepartment.Text == "Electronics R&D")
                    {
                        dtResults = DAL.fnTimesheetSummary(6, dtpfromdate.Text, dtptodate.Text, cmbDepartment.Text).Tables[0];
                    }
                    else if (cmbDepartment.Text == "Hydraulics" || cmbDepartment.Text == "Electricals")
                    {
                        dtResults = DAL.fnTimesheetSummary(7, dtpfromdate.Text, dtptodate.Text, cmbDepartment.Text).Tables[0];
                    }
                    else if (cmbDepartment.Text == "Electronics")
                    {
                        dtResults = DAL.fnTimesheetSummary(8, dtpfromdate.Text, dtptodate.Text, cmbDepartment.Text).Tables[0];
                    }
                    else if (cmbDepartment.Text == "Transducer")
                    {
                        dtResults = DAL.fnTimesheetSummary(82, dtpfromdate.Text, dtptodate.Text, cmbDepartment.Text).Tables[0];
                    }
                    else if (cmbDepartment.Text == "RnD")
                    {
                        dtResults = DAL.fnTimesheetSummary(9, dtpfromdate.Text, dtptodate.Text, cmbDepartment.Text).Tables[0];
                    }
                    if (dtResults.Rows.Count > 0)
                    {
                        dgvSummaryReport.AutoGenerateColumns = true;
                        dgvSummaryReport.DataSource = dtResults;
                        Datagridviewcolor();
                    }
                    break;
            }

            foreach (DataGridViewColumn column in dgvSummaryReport.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
            }

            dtpfromdate.Format = DateTimePickerFormat.Custom;
            dtpfromdate.CustomFormat = "dd-MM-yyyy";
            dtptodate.Format = DateTimePickerFormat.Custom;
            dtptodate.CustomFormat = "dd-MM-yyyy";
        }

        DataTable dtUserDetails = new DataTable();
        private void frmTimesheetView_Load(object sender, EventArgs e)
        {
            cmbDepartment.Items.Add(Loginfrm.GetUserDetails[23]);
            cmbDepartment.SelectedIndex = 0;
            dtUserDetails = DAL.fnActiveUserList(3, Loginfrm.GetUserDetails[23]).Tables[0];
            foreach (DataRow DR in dtUserDetails.Rows)
            {
                cmbUser.Items.Add(DR[0].ToString());
            }
        }

        DataTable dtGraph = new DataTable();
        private void fnPlotGraph(string sXValueMember, string sSeriesName)
        {
            dtGraph = dtResults.Copy();
            int k = dtGraph.Rows.Count;
            dtGraph.Rows.RemoveAt(k - 1);
            dtGraph.Rows.RemoveAt(k - 2);
            chart.Series.Clear();
            chart.Titles.Clear();
            if (cmbreporttype.Text == "User Activitywise Summary")
            {
                chart.Titles.Add(cmbUser.Text + " Activitywise Summary");
            }
            else
            {
                chart.Titles.Add(cmbreporttype.Text);
            }
            chart.DataSource = dtGraph;
            chart.Series.Add(sSeriesName);
            //chart.Series.Add("ActivityTask");
            chart.Series[sSeriesName].XValueMember = sXValueMember;
            chart.Series[sSeriesName].YValueMembers = "TotalHours";

            chart.Series[sSeriesName].ChartType = SeriesChartType.Pie;

            //  chart.Series[sSeriesName].ChartType = SeriesChartType.Column;
            // chart.Series[sSeriesName]["PieLabelStyle"] = "OutSide";
            chart.Series[sSeriesName].IsValueShownAsLabel = true;

            //List sUsername= new List
            //foreach (DataRow r in dtGraph.Rows)
            //{

            //}

            //foreach (DataRow r in dtGraph.Rows)
            //{
            //    Series s = new Series(string.Format("{0} {1}", ((double)r["TotalHours"]).ToString(), ((double)r["TotalHours"])));
            //    s.ChartType = SeriesChartType.Column;
            //    s.Points.AddXY("Username", new object[] { r["Username"] });
            //    s.Points.AddXY("ActivityTask", new object[] { r["ActivityTask"] });
            //    if (!chart.Series.Contains(s))
            //    {
            //        chart.Series.Add(s);
            //    }
            //}


            ////Get the DISTINCT Countries.
            //List<string> countries = (from p in dtGraph.AsEnumerable()
            //                          select p.Field<string>(sXValueMember)).Distinct().ToList();
            //chart.Series.Clear();
            //if (chart.Series.Count() == 1)
            //{
            //    chart.Series.Remove(chart.Series[0]);
            //}

            ////Loop through the Countries.
            //foreach (string country in countries)
            //{

            //    //Get the Year for each Country.
            //    double[] x = (from p in dtGraph.AsEnumerable()
            //                  where p.Field<string>(sXValueMember) == country
            //               orderby p.Field<double>("TotalHours") ascending
            //               select p.Field<double>("TotalHours")).ToArray();

            //    //Get the Total of Orders for each Country.
            //    double[] y = (from p in dtGraph.AsEnumerable()
            //                  where p.Field<string>(sXValueMember) == country
            //               orderby p.Field<double>("TotalHours") ascending
            //               select p.Field<double>("TotalHours")).ToArray();

            //    //Add Series to the Chart.
            //    chart.Series.Add(new Series(country));
            //    chart.Series[country].IsValueShownAsLabel = true;
            //    chart.Series[country].ChartType = SeriesChartType.StackedBar;
            //    chart.Series[country].Points.DataBindXY(x, y);
            //}

            //chart.Legends[0].Enabled = true;

        }

        private void fnChartPlot(int j, DataTable dtSpec, string sSeriesName)
        {
            dtSpec = dtResults.Copy();
            int k = dtSpec.Rows.Count;
            dtSpec.Rows.RemoveAt(k - 1);
            dtSpec.Rows.RemoveAt(k - 2);

            double xvals;
            double yvals;
            chart.Series.Clear();
            chart.Series.Add(sSeriesName);
            for (int y = 0; y < dtSpec.Rows.Count; y++)
            {
                // string seriesName = dtSpec.Rows[0][sSeriesName].ToString();
                // if (chart.Series.Contains(sSeriesName))




                chart.Series[0].BorderWidth = 4;
                chart.Series[0].ChartType = SeriesChartType.Pie;
                int i = 0;
                chart.Series[0].IsValueShownAsLabel = true;

                foreach (DataRow dr in dtSpec.Rows)
                {
                    if (dr["TotalHours"] != DBNull.Value)
                    {
                        if (Convert.ToDouble(dr["TotalHours"].ToString()) >= 0)
                        {

                            xvals = (Convert.ToDouble(y));
                            //  chart.Series[y].Label = xvals.ToString();
                            yvals = (Convert.ToDouble(dr["TotalHours"].ToString()));
                            chart.Series[y].Points.AddXY(xvals, yvals);

                            chart.Series[y].Points[i].MarkerStyle = MarkerStyle.Circle;
                            chart.Series[y].Points[i].MarkerSize = 16;
                            i++;

                        }
                    }
                }

                chart.Series[sSeriesName].XValueType = ChartValueType.Auto;
                chart.Series["TotalHours"].YValueType = ChartValueType.Auto;
            }
        }

        private void frmTimesheetView_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            form.Show();
        }

        Point? prevPosition = null;
        ToolTip tooltip = new ToolTip();
        string selectedSeries = "";
        private void chart_MouseMove(object sender, MouseEventArgs e)
        {
            var pos = e.Location;
            if (prevPosition.HasValue && pos == prevPosition.Value)
                return;
            tooltip.RemoveAll();
            prevPosition = pos;
            var results = chart.HitTest(pos.X, pos.Y, false,
                                            ChartElementType.DataPoint);
            foreach (var result in results)
            {
                // if (result.ChartElementType == ChartElementType.DataPoint)
                {
                    var prop = result.Object as DataPoint;
                    if (prop != null)
                    {
                        var pointXPixel = result.ChartArea.AxisX.ValueToPixelPosition(prop.XValue);
                        var pointYPixel = result.ChartArea.AxisY.ValueToPixelPosition(prop.YValues[0]);

                        //  if (Math.Abs(pos.X - pointXPixel) < 1 && Math.Abs(pos.Y - pointYPixel) < 1)
                        {

                            //string Xval = dgvViewResult.Rows[Convert.ToInt32(prop.XValue)].Cells["SpecimenID"].Value.ToString();
                            tooltip.Show("X=" + prop.XValue + ", Y=" + prop.YValues[0], this.chart,
                                            pos.X, pos.Y - 15);
                        }
                    }
                }
            }


        }

        private void btnGraph_Click(object sender, EventArgs e)
        {
            if (chart.Visible)
            {
                chart.Visible = false;
            }
            else
            {
                chart.Visible = true;
            }
        }

        private void btnExcel_Click(object sender, EventArgs e)
        {
            if (dgvSummaryReport.Rows.Count > 0)
            {
                string ExcelFolderPath;
                string FileFullPath;

                Microsoft.Office.Interop.Excel._Application ExcelApp = null;
                Microsoft.Office.Interop.Excel._Workbook NewWorkBook = null;
                //Cursor.Current = Cursors.WaitCursor;

                int j = 6;
                ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\TIME Sheet Reports\\";
                FileFullPath = ExcelFolderPath + "Time Sheet " + cmbreporttype.Text + "-" + dtpfromdate.Text + " To " + dtptodate.Text + " " + DateTime.Now.ToString("d/M/yyyy HH/mm/ss") + " ";
                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);

                ExcelApp = new Microsoft.Office.Interop.Excel.Application();
                NewWorkBook = ExcelApp.Workbooks.Add(Type.Missing);
                Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
                worksheet = NewWorkBook.Sheets["Sheet1"];
                worksheet = NewWorkBook.ActiveSheet;
                worksheet.Name = "Time Sheet Report";
                object misValue = System.Reflection.Missing.Value;
                worksheet.Cells[1, 1] = "BiSS-ITW PVT LTD"; //i++;       
                CellMerge("Merge", NewWorkBook.ActiveSheet, 1, 1, 1, 3);
                worksheet.Range["A1:C1"].Cells.Font.Size = 16;
                worksheet.Range["A2:C3"].Cells.Font.Size = 14;
                worksheet.Range["A4:C4"].Cells.Font.Size = 12;
                worksheet.Range["A1:C3"].Cells.Font.Bold = true;
                bool bFirsttime = true;

                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Bold = true;
                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Color = Color.Blue;


                object[,] rawData = new object[dtResults.Rows.Count + 1, dtResults.Columns.Count];
                if (bFirsttime)
                {
                    for (int col = 0; col < dtResults.Columns.Count; col++)
                    {
                        rawData[0, col] = dtResults.Columns[col].ColumnName;
                    }
                    bFirsttime = false;
                }
                if (dtResults.Rows.Count > 0)
                {
                    for (int row = 0; row < dtResults.Rows.Count; row++)
                    {
                        for (int col = 0; col < dtResults.Columns.Count; col++)
                        {
                            rawData[row + 1, col] = dtResults.Rows[row].ItemArray[col];
                        }
                    }
                    string finalColLetter = string.Empty;
                    string excelRange = string.Empty;
                    // if (IsFirsttime)
                    {
                        finalColLetter = string.Empty;
                        string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        int colCharsetLen = colCharset.Length;

                        if (dtResults.Columns.Count > colCharsetLen)
                        {
                            finalColLetter = colCharset.Substring(
                                (dtResults.Columns.Count - 1) / colCharsetLen - 1, 1);
                        }

                        finalColLetter += colCharset.Substring(
                                (dtResults.Columns.Count - 1) % colCharsetLen, 1);
                        excelRange = string.Format("A6:{0}{1}", finalColLetter, dtResults.Rows.Count + j);
                        // IsFirsttime = false;
                    }
                    worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;

                }

                worksheet.Range["A3:C5"].Cells.Font.Size = 14;
                worksheet.Range["A3:C5"].Cells.Font.Bold = 14;
                CellMerge("Merge", NewWorkBook.ActiveSheet, 1, 1, 1, 3);
                worksheet.get_Range("C6", "C99999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                //Microsoft.Office.Interop.Excel.Range Range = worksheet.get_Range("N6", "R99999");
                //Range.EntireColumn.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                worksheet.Rows.RowHeight = "18";
                worksheet.Columns.AutoFit();
                if (cmbreporttype.Text == "Individual User Time Sheet" && cmbDepartment.Text == "RnD")
                {
                    Microsoft.Office.Interop.Excel.Range rangea = worksheet.get_Range("E7", "E99999");
                    rangea.NumberFormat = "dd-MM-yyyy";

                    worksheet.Columns[9].ColumnWidth = 40;
                    worksheet.Columns[10].ColumnWidth = 40;
                }
                else if (cmbreporttype.SelectedIndex == 3)
                {
                    Microsoft.Office.Interop.Excel.Range rangea = worksheet.get_Range("E6", "E99999");
                    rangea.NumberFormat = "dd-MM-yyyy";
                }
                else if (cmbreporttype.SelectedIndex > 6)
                {
                    Microsoft.Office.Interop.Excel.Range rangea = worksheet.get_Range("B6", "B999999");
                    rangea.NumberFormat = "dd-MM-yyyy";
                    worksheet.Columns[7].ColumnWidth = 50;
                    worksheet.Columns[7].WrapText = true;
                    worksheet.Columns[8].ColumnWidth = 50;
                    worksheet.Columns[8].WrapText = true;
                    worksheet.Columns[14].ColumnWidth = 50;
                    worksheet.Columns[14].WrapText = true;
                }
                //Microsoft.Office.Interop.Excel.Range range = worksheet.get_Range("N6", "R99999");
                //range.NumberFormat = "0.00";


                worksheet.Rows.AutoFit();
                //worksheet.Columns[1].ColumnWidth = 12;
                //worksheet.Columns[1].WrapText = true;
           
                worksheet.Rows.RowHeight = "18";
                worksheet.PageSetup.PrintArea = "A1:Q" + (dtResults.Rows.Count + 6) + "";
                worksheet.PageSetup.PrintTitleRows = "$1:$2";
                worksheet.PageSetup.PrintNotes = true;
                worksheet.PageSetup.Zoom = 75;
                worksheet.PageSetup.PrintGridlines = true;
                worksheet.PageSetup.LeftMargin = 0;
                worksheet.PageSetup.RightMargin = 0;
                worksheet.PageSetup.TopMargin = 0.75;
                worksheet.PageSetup.BottomMargin = 0.75;
                worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                NewWorkBook.SaveAs(FileFullPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                NewWorkBook.Save();
                NewWorkBook.Close(true, misValue, misValue);
                ExcelApp.Quit();
                releaseObject(worksheet);
                releaseObject(NewWorkBook);
                releaseObject(ExcelApp);

                if (Directory.Exists(ExcelFolderPath))
                {
                    Process.Start(ExcelFolderPath);
                }
                //Cursor.Current = Cursors.Default;

            }
            else
            {
                MessageBox.Show("No data to generate excel file.", "Error", 0, MessageBoxIcon.Error);
            }
        }

        #region Excel App Release Object Function
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
        #endregion

        #region CellMerge Funtion
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlMedium, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "GridLines":
                    {
                        CELLS.Borders.Color = System.Drawing.Color.Black;
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignCenter":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                        break;
                    }
                case "Bold":
                    {
                        CELLS.Font.Bold = true;
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

        }
        #endregion

        private void cmbreporttype_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbUser.Visible = false;
            cmbDepartment.Enabled = false;
            cmbDepartment.Items.Clear();
            cmbDepartment.Text = "";
            if (!cmbDepartment.Items.Contains(Loginfrm.GetUserDetails[23]))
            {
                cmbDepartment.Items.Add(Loginfrm.GetUserDetails[23]);
            }
            cmbDepartment.SelectedIndex = 0;

            switch (cmbreporttype.Text)
            {
                case "User Activitywise Summary":
                case "Individual User Time Sheet":
                    cmbUser.Visible = true;
                    break;

                case "All Department Project Time Sheet":
                    cmbDepartment.Enabled = true;

                    // cmbDepartment.Items.Add(Loginfrm.GetUserDetails[23]);
                    //cmbDepartment.SelectedIndex = 0;
                    cmbDepartment.Items.Clear();
                    cmbDepartment.Text = "";
                    dtUserDetails = DAL.fnActiveUserList(4, Loginfrm.GetUserDetails[23]).Tables[0];
                    foreach (DataRow DR in dtUserDetails.Rows)
                    {
                        cmbDepartment.Items.Add(DR[0].ToString());
                    }

                    break;

                default:
                    cmbUser.Visible = false;
                    break;


            }
        }

        private void cmbUser_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
