﻿using System;
using System.Data;
using System.Globalization;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Time_Sheet
{
    public partial class frmValidationTimeSheet : Form
    {
        public frmValidationTimeSheet()
        {
            InitializeComponent();
        }

        Login.frmLoginForm Loginfrm = new Login.frmLoginForm();
        DataAccessLayer DAL = new DataAccessLayer();
        Global GlobalClass = new Global();
        ValidationDocuments.frmValidationHome VHome = new ValidationDocuments.frmValidationHome();
        frmForm2 form = new frmForm2();
        private static string sProjectCode;
        public string fnProjectcode
        {
            get
            {
                return sProjectCode;
            }
            set
            {
                sProjectCode = value;
            }
        }

        public int sValidationform = 0;

        public int GetIso8601WeekOfYear(DateTime time)
        {
            DayOfWeek day = CultureInfo.InvariantCulture.Calendar.GetDayOfWeek(time);
            if (day >= DayOfWeek.Monday && day <= DayOfWeek.Wednesday)
            {
                time = time.AddDays(3);
            }
            return CultureInfo.InvariantCulture.Calendar.GetWeekOfYear(time, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);
        }

        DataTable dtProjectList = new DataTable();
        DataTable dtMainActivity = new DataTable();
        int iWeek = 0;
        private void frmValidationTimeSheet_Load(object sender, EventArgs e)
        {

            iWeek = GetIso8601WeekOfYear(Convert.ToDateTime(dtpTimeSheetDate.Text));
            txtWeek.Text = "Week" + iWeek;
            lblUsername.Text = Loginfrm.GetUserDetails[2];
            lblDepartment.Text = Loginfrm.GetUserDetails[23];

            if (lblDepartment.Text == "Validation" || lblDepartment.Text == "Quality")
            {
                cmbProjectcode.Items.Add("BiSS_001");
                cmbProjectcode.Items.Add("RnD_001");

                pnHydraulics.Visible = false;
                for (int i = 11; i < 15; i++)
                {
                    dgvTimeSheet.Columns[i].Visible = false;
                }
                pnProduct.Visible = false;
            }

           else if (lblDepartment.Text == "Electronics R&D")
            {
                cmbProjectcode.Items.Add("BiSS_001");
                cmbProjectcode.Items.Add("RnD_001");

                pnHydraulics.Visible = false;
                for (int i = 11; i < 15; i++)
                {
                    dgvTimeSheet.Columns[i].Visible = false;
                }
                pnProduct.Visible = false;
            }

            else if (lblDepartment.Text == "Testlab")
            {
                cmbProjectcode.Items.Add("BiSS_001");
                cmbProjectcode.Items.Add("CAL_001");
                cmbProjectcode.Items.Add("LM_001");
                cmbProjectcode.Items.Add("RnD_001");
                cmbProjectcode.Items.Add("S&SP_001");
                cmbProjectcode.Items.Add("SP_001");
              

                pnHydraulics.Visible = false;
                for (int i = 11; i < 15; i++)
                {
                    dgvTimeSheet.Columns[i].Visible = false;
                }
                pnProduct.Visible = false;
            }
            else if (lblDepartment.Text == "Sales")
            {
                cmbProjectcode.Items.Add("BiSS_001");
                cmbProjectcode.Items.Add("RnD_001");

                pnHydraulics.Visible = false;
                for (int i = 11; i < 15; i++)
                {
                    dgvTimeSheet.Columns[i].Visible = false;
                }
                pnProduct.Visible = false;
            }
            else if (lblDepartment.Text == "Integration" || lblDepartment.Text == "Production" || lblDepartment.Text == "Projects")
            {
                cmbProjectcode.Items.Add("BiSS_001");
                cmbProjectcode.Items.Add("RnD_001");

                pnHydraulics.Visible = false;
                for (int i = 11; i < 15; i++)
                {
                    dgvTimeSheet.Columns[i].Visible = false;
                }
                pnProduct.Visible = false;
            }
            else if (lblDepartment.Text == "Design")
            {
                cmbProjectcode.Items.Add("BiSS_001");
                cmbProjectcode.Items.Add("ME_001");
                cmbProjectcode.Items.Add("TR_001");
                cmbProjectcode.Items.Add("DM_001");
                cmbProjectcode.Items.Add("SA_001");
                cmbProjectcode.Items.Add("R&D-02");
                cmbProjectcode.Items.Add("R&D-03");
                cmbProjectcode.Items.Add("R&D-04");
                cmbProjectcode.Items.Add("R&D-05");
                cmbProjectcode.Items.Add("ESG_001");
                cmbProjectcode.Items.Add("TL-001");


                pnHydraulics.Visible = false;
                for (int i = 11; i < 15; i++)
                {
                    dgvTimeSheet.Columns[i].Visible = false;
                }
                pnProduct.Visible = false;
            }
            else if (lblDepartment.Text == "Hydraulics")
            {
                cmbProjectcode.Items.Add("BiSS_001");
                cmbProjectcode.Items.Add("RnD_001");
                txtProductName.ReadOnly = true;
                lblprojectbom.Text = "BOM Product :";
                lblprdname.Text = "Product Name :";

                dgvTimeSheet.Columns[12].HeaderText = "Product Code";
                dgvTimeSheet.Columns[13].HeaderText = "Product Name";

                pnHydraulics.Visible = true;
                pnProduct.Visible = true;
                for (int i = 11; i < 15; i++)
                {
                    dgvTimeSheet.Columns[i].Visible = true;
                }
            }

            else if (lblDepartment.Text == "Electronics")
            {
                cmbProjectcode.Items.Add("BiSS_001");
                cmbProjectcode.Items.Add("ELC-001");
                cmbProjectcode.Items.Add("ELC-002");
                cmbProjectcode.Items.Add("ELC-003");
                pnHydraulics.Visible = false;
                txtProductName.ReadOnly = false;
                lblprojectbom.Text = "Card/Controller/\nTransducers :";
                lblprdname.Text = "Quantity :";
                pnProduct.Visible = true;

                dgvTimeSheet.Columns[11].Visible = false;

                dgvTimeSheet.Columns[12].HeaderText = "Card/Controller";
                dgvTimeSheet.Columns[13].HeaderText = "Quantity";
                for (int i = 12; i < 15; i++)
                {
                    dgvTimeSheet.Columns[i].Visible = true;
                }
            }

            else if (lblDepartment.Text == "Transducer")
            {
                cmbProjectcode.Items.Add("BiSS_001");
                pnHydraulics.Visible = false;
                txtProductName.ReadOnly = false;
                lblprojectbom.Text = "Transducers :";
                lblprdname.Text = "Quantity :";
                pnProduct.Visible = true;

                dgvTimeSheet.Columns[11].Visible = false;

                dgvTimeSheet.Columns[12].HeaderText = "LoadCell";
                dgvTimeSheet.Columns[13].HeaderText = "Quantity";
                for (int i = 12; i < 15; i++)
                {
                    dgvTimeSheet.Columns[i].Visible = true;
                }
            }
            else if (lblDepartment.Text == "Electricals")
            {
                cmbProjectcode.Items.Add("BiSS_001");
                cmbProjectcode.Items.Add("RnD_001");
                txtProductName.ReadOnly = true;
                lblprojectbom.Text = "BOM Product :";
                lblprdname.Text = "Product Name :";

                dgvTimeSheet.Columns[12].HeaderText = "Product Code";
                dgvTimeSheet.Columns[13].HeaderText = "Product Name";

                pnHydraulics.Visible = true;
                pnProduct.Visible = true;
                for (int i = 11; i < 15; i++)
                {
                    dgvTimeSheet.Columns[i].Visible = true;
                }
            }

            else if (lblDepartment.Text == "RnD")
            {
                cmbProjectcode.Items.Add("BiSS_001");
                // cmbProjectcode.Items.Add("RnD_001");
                pnSubModule.Visible = true;
                pnHydraulics.Visible = true;
                label15.Visible = false;
                label12.Text = "Sub Module:";
                cmbCapacity.Items.Clear();
                txtRemarks.MaxLength = 254;
                cmbCapacity.Items.Add("Mfg");
                cmbCapacity.Items.Add("Others");
                cmbCapacity.Items.Add("RnD");
                cmbCapacity.Items.Add("Support");

                //dgvTimeSheet.Columns[10].HeaderText = "";
                dgvTimeSheet.Columns[11].HeaderText = "Type";
                dgvTimeSheet.Columns[12].HeaderText = "Version";
                dgvTimeSheet.Columns[13].HeaderText = "Sub Module";
                dgvTimeSheet.Columns[14].HeaderText = "Backup Run";
                //dgvTimeSheet.Columns[13].DisplayIndex = 10;

                for (int i = 15; i < 15; i++)
                {
                    dgvTimeSheet.Columns[i].Visible = false;
                }
                pnProduct.Visible = false;
            }

            dtProjectList = DAL.fnAllProjectList(null).Tables[0];
            foreach (DataRow DR in dtProjectList.Rows)
            {
                if (!cmbProjectcode.Items.Contains(DR["ProjectCode"].ToString()))
                    cmbProjectcode.Items.Add(DR["ProjectCode"].ToString());
            }

            dtMainActivity = DAL.fnDepartmentTimeSheetActivity(0, Loginfrm.GetUserDetails[23], "", "", "").Tables[0];

            if (dtMainActivity.Rows.Count > 0)
            {
                foreach (DataRow dr in dtMainActivity.Rows)
                {
                    if (!cmbMainActivity.Items.Contains(dr["MainActivity"].ToString()))
                    {
                        cmbMainActivity.Items.Add(dr["MainActivity"].ToString());
                    }
                }
            }
            fnLoadData();
        }

        DataTable dtTimeSheet = new DataTable();
        private void fnLoadData()
        {
            var date = DateTime.Parse(dtpTimeSheetDate.Text);
            dtTimeSheet = DAL.fnDepartmentTimeSheetActivity(2, "", "", date.ToString("yyyy-MM-dd"), Loginfrm.GetUserDetails[2]).Tables[0];
            dgvTimeSheet.AutoGenerateColumns = false;
            dgvTimeSheet.DataSource = dtTimeSheet;

            double sTotalHours = 0;
            if (dgvTimeSheet.Rows.Count > 0)
            {
                foreach (DataGridViewRow dgvr in dgvTimeSheet.Rows)
                {
                    if (dgvr.Cells["ActivityTask"].Value.ToString() != "Holiday" && dgvr.Cells["ActivityTask"].Value.ToString() != "Leave" && dgvr.Cells["ActivityTask"].Value.ToString() != "Weekly Off")
                    {
                        sTotalHours += (Convert.ToDouble(dgvr.Cells["TotalHours"].Value));
                    }
                }
                lblHistoryHours.Text = sTotalHours.ToString();
            }
            else
            {
                lblHistoryHours.Text = "0";
            }
        }

        private void btnProjectSearch_Click(object sender, EventArgs e)
        {
            sValidationform = 1;
            Indent.frmProjectselect projectsearch = new Indent.frmProjectselect();
            projectsearch.fnValidationform = sValidationform.ToString();
            projectsearch.ShowDialog();
            if (fnProjectcode != null)
            {
                cmbProjectcode.Text = sProjectCode;
            }
        }
        DataTable dtProjectBOM = new DataTable();
        DataTable dtEnquiryDetails = new DataTable();
        private void cmbProjectcode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbProjectcode.SelectedIndex == -1)
            {
                lblprojname.ResetText();
                lbleighty.ResetText();
                lblCustomizationLevel.ResetText();
            }
            else
            {
                if (lblDepartment.Text == "Sales")
                {
                    if (cmbMainActivity.Text == "Enquiry Handling" || cmbMainActivity.Text == "Sales")
                    {
                        dtEnquiryDetails = DAL.fnQuotationNumberLoadData(19, cmbProjectcode.Text, "").Tables[0];
                        if (dtEnquiryDetails.Rows.Count > 0)
                        {
                            lblprojname.Text = dtEnquiryDetails.Rows[0]["CustomerName"].ToString();
                            lbleighty.Text = dtEnquiryDetails.Rows[0]["Project8020"].ToString();
                            lblCustomizationLevel.Text = dtEnquiryDetails.Rows[0]["LevelofCustomization"].ToString();
                        }
                        else if (dtEnquiryDetails.Rows.Count == 0)
                        {
                            dtEnquiryDetails = DAL.fnQuotationNumberLoadData(20, cmbProjectcode.Text, "").Tables[0];
                            if (dtEnquiryDetails.Rows.Count > 0)
                            {
                                lblprojname.Text = dtEnquiryDetails.Rows[0]["CustomerName"].ToString();
                                lbleighty.Text = "0";
                                lblCustomizationLevel.Text = "0";
                            }
                        }
                    }
                    else if (cmbMainActivity.Text == "Order Execution")
                    {
                        if (cmbProjectcode.Text != "  ")
                        {
                            DataView dvProject = new DataView(dtProjectList);
                            dvProject.RowFilter = "ProjectCode Like'" + cmbProjectcode.Text + "'";
                            DataTable dtrow = dvProject.ToTable();
                            if (dtrow.Rows.Count > 0)
                            {
                                lblprojname.Text = dtrow.Rows[0]["ProjectDescription"].ToString();
                                lbleighty.Text = dtrow.Rows[0]["project8020"].ToString();
                                lblCustomizationLevel.Text = dtrow.Rows[0]["customizationlevel"].ToString();
                            }
                        }
                    }
                }
                //btnSave.Enabled = true;
                //cmbSubTask.Enabled = true;
                //cmbCapacity.Enabled = true;
                //cmbMainActivity.Enabled = true;
                if (cmbProjectcode.Text == "BiSS_001" || cmbProjectcode.Text == "RnD_001")
                {
                    if (cmbProjectcode.Text == "BiSS_001")
                    {
                        lblprojname.Text = "BiSS Inhouse";
                    }
                    else if (cmbProjectcode.Text == "RnD_001")
                    {
                        lblprojname.Text = "RnD";
                    }
                    lbleighty.Text = "0";
                    lblCustomizationLevel.Text = "0";
                }

         

                else if (cmbProjectcode.Text == "S&SP_001" || cmbProjectcode.Text == "SP_001" || cmbProjectcode.Text == "CAL_001" || cmbProjectcode.Text == "LM_001")
                {
                    if (cmbProjectcode.Text == "S&SP_001")
                    {
                        lblprojname.Text = "Sales & Service Product";
                    }
                    else if (cmbProjectcode.Text == "SP_001")
                    {
                        lblprojname.Text = "Support Product";
                    }
                    else if (cmbProjectcode.Text == "CAL_001")
                    {
                        lblprojname.Text = "Calibration";
                    }
                    else if (cmbProjectcode.Text == "LM_001")
                    {
                        lblprojname.Text = "LM";
                    }
                    lbleighty.Text = "0";
                    lblCustomizationLevel.Text = "0";
                }

                else if (cmbProjectcode.Text == "ELC-001" || cmbProjectcode.Text == "ELC-002" || cmbProjectcode.Text == "ELC-003")
                {
                    if (cmbProjectcode.Text == "ELC-001")
                    {
                        lblprojname.Text = "Electronics Kanban";
                    }
                    else if (cmbProjectcode.Text == "ELC-002")
                    {
                        lblprojname.Text = "ELC RnD";
                    }
                    else if (cmbProjectcode.Text == "ELC-003")
                    {
                        lblprojname.Text = "Servicing";
                    }
                    lbleighty.Text = "0";
                    lblCustomizationLevel.Text = "0";
                }
                else if (cmbProjectcode.Text == "ME_001" || cmbProjectcode.Text == "TR_001" || cmbProjectcode.Text == "DM_001" ||
                    cmbProjectcode.Text == "SA_001" || cmbProjectcode.Text == "R&D-02" || cmbProjectcode.Text == "R&D-04" ||
                    cmbProjectcode.Text == "R&D-05" || cmbProjectcode.Text == "ESG_001" || cmbProjectcode.Text == "R&D-03" || cmbProjectcode.Text == "TL-001")
                {
                    if (cmbProjectcode.Text == "ME_001")
                    {
                        lblprojname.Text = "Meeting";
                    }
                    else if (cmbProjectcode.Text == "TR_001")
                    {
                        lblprojname.Text = "Training";
                    }
                    else if (cmbProjectcode.Text == "DM_001")
                    {
                        lblprojname.Text = "Design Activity Maintenance";
                    }
                    else if (cmbProjectcode.Text == "SA_001")
                    {
                        lblprojname.Text = "Sales Co-Ordination";
                    }
                    else if (cmbProjectcode.Text == "R&D-02")
                    {
                        lblprojname.Text = "LCF Development";
                    }
                    else if (cmbProjectcode.Text == "R&D-04")
                    {
                        lblprojname.Text = "Low force actuator development ";
                    }
                    else if (cmbProjectcode.Text == "R&D-05")
                    {
                        lblprojname.Text = "Extnesometer Calibrator ";
                    }
                    else if (cmbProjectcode.Text == "ESG_001")
                    {
                        lblprojname.Text = "ESG";
                    }
                    else if (cmbProjectcode.Text == "R&D-03")
                    {
                        lblprojname.Text = "Transducer Upgradation";
                    }
                    else if (cmbProjectcode.Text == "TL-001")
                    {
                        lblprojname.Text = "Testing Lab activity";
                    }
                }
                else
                {
                    if (lblDepartment.Text != "Sales")
                    {
                        if (cmbProjectcode.Text != "  ")
                        {
                            DataView dvProject = new DataView(dtProjectList);
                            dvProject.RowFilter = "ProjectCode Like'" + cmbProjectcode.Text + "'";
                            DataTable dtrow = dvProject.ToTable();
                            lblprojname.Text = dtrow.Rows[0]["ProjectDescription"].ToString();
                            lbleighty.Text = dtrow.Rows[0]["project8020"].ToString();
                            lblCustomizationLevel.Text = dtrow.Rows[0]["customizationlevel"].ToString();
                            cmbBOMProduct.Items.Clear();
                            cmbBOMProduct.SelectedIndex = -1;
                            if (lblDepartment.Text == "Hydraulics" || lblDepartment.Text == "Electricals")
                            {
                                dtProjectBOM = DAL.fnProjectBOMIndentList(cmbProjectcode.Text).Tables[0];
                                foreach (DataRow DR in dtProjectBOM.Rows)
                                {
                                    cmbBOMProduct.Items.Add(DR["ProductCode"].ToString());
                                }
                            }
                        }
                    }
                }

                if (lblDepartment.Text == "Electronics")
                {
                    cmbBOMProduct.Items.Clear();
                    cmbBOMProduct.SelectedIndex = -1;
                    cmbBOMProduct.Items.Add("SS LITE MB");
                    cmbBOMProduct.Items.Add("2020 SS MB");
                    cmbBOMProduct.Items.Add("OCTA MB");
                    cmbBOMProduct.Items.Add("2020 MS MB");
                    cmbBOMProduct.Items.Add("2020 MS DB");
                    cmbBOMProduct.Items.Add("Load SC");
                    cmbBOMProduct.Items.Add("LVDT SC");
                    cmbBOMProduct.Items.Add("SBC SC");
                    cmbBOMProduct.Items.Add("HL SC");
                    cmbBOMProduct.Items.Add("DI");
                    cmbBOMProduct.Items.Add("DO");
                    cmbBOMProduct.Items.Add("PLI");
                    cmbBOMProduct.Items.Add("PLB");
                    cmbBOMProduct.Items.Add("Encoder");
                    cmbBOMProduct.Items.Add("Servo");
                    cmbBOMProduct.Items.Add("2 CH DRV");
                    cmbBOMProduct.Items.Add("4 CH DRV");
                    cmbBOMProduct.Items.Add("Shunt board");
                    cmbBOMProduct.Items.Add("Thump encoder");
                    cmbBOMProduct.Items.Add("SSI");
                    cmbBOMProduct.Items.Add("2360 Controller");
                    cmbBOMProduct.Items.Add("Accelerometer ");
                    cmbBOMProduct.Items.Add("DSP");
                    cmbBOMProduct.Items.Add("LITE Controller");
                    cmbBOMProduct.Items.Add("SS Controller");
                    cmbBOMProduct.Items.Add("OCTA Controller");
                    cmbBOMProduct.Items.Add("MS Controller");
                    cmbBOMProduct.Items.Add("DCPD Unit");
                    cmbBOMProduct.Items.Add("Design and RnD");
                    cmbBOMProduct.Items.Add("Project  Documentation");
                    cmbBOMProduct.Items.Add("Production Documentation");
                    cmbBOMProduct.Items.Add("Support");
                    cmbBOMProduct.Items.Add("ISO Documentation");
                    cmbBOMProduct.Items.Add("Tool box");
                    cmbBOMProduct.Items.Add("NC, RCA and CA");
                    cmbBOMProduct.Items.Add("Misc");
                    cmbBOMProduct.Items.Add("Components procurement");
                    cmbBOMProduct.Items.Add("Others");
                    cmbBOMProduct.Items.Add("Transducer");
                    cmbBOMProduct.Items.Add("SMPS");

                }
                else if (lblDepartment.Text == "Transducer")
                {
                    cmbBOMProduct.Items.Clear();
                    cmbBOMProduct.SelectedIndex = -1;
                    cmbBOMProduct.Items.Add("200N LC");
                    cmbBOMProduct.Items.Add("500N LC");
                    cmbBOMProduct.Items.Add("1kN LC");
                    cmbBOMProduct.Items.Add("5kN LC");
                    cmbBOMProduct.Items.Add("10kN LC");
                    cmbBOMProduct.Items.Add("15kN LC");
                    cmbBOMProduct.Items.Add("25kN LC");
                    cmbBOMProduct.Items.Add("50kN LC");
                    cmbBOMProduct.Items.Add("100kN LC");
                    cmbBOMProduct.Items.Add("200kN LC");
                    cmbBOMProduct.Items.Add("300kN LC");
                    cmbBOMProduct.Items.Add("500kN LC");
                    cmbBOMProduct.Items.Add("600kN LC");
                    cmbBOMProduct.Items.Add("1000kN LC");
                    cmbBOMProduct.Items.Add("2000kN LC");
                    cmbBOMProduct.Items.Add("200N 2N-m ATLC");
                    cmbBOMProduct.Items.Add("100kN 2kN-m ATLC");
                    cmbBOMProduct.Items.Add("500N-m ATLC");
                    cmbBOMProduct.Items.Add("10kN-m ATLC");
                    cmbBOMProduct.Items.Add("20kN-m ATLC");
                    cmbBOMProduct.Items.Add("RT COD GL:5mm, TL:+3mm,-1mm");
                    cmbBOMProduct.Items.Add("RT COD GL:5mm, TL:+2mm,-1mm");
                    cmbBOMProduct.Items.Add("RT COD GL:10mm, TL:+4mm,-1mm");
                    cmbBOMProduct.Items.Add("RT COD GL:10mm, TL:+7mm,-1mm");
                    cmbBOMProduct.Items.Add("RT COD GL:12mm, TL:+12mm,-2mm");
                    cmbBOMProduct.Items.Add("HT COD GL:5mm, TL:+3mm,-0.5mm");
                    cmbBOMProduct.Items.Add("HT COD GL:10mm, TL:+4mm,-1mm");
                    cmbBOMProduct.Items.Add("RTE LCF GL:12.5mm, TL:+/-1mm");
                    cmbBOMProduct.Items.Add("RTE LCF GL:12.5mm, TL: +/- 2.5mm");
                    cmbBOMProduct.Items.Add("RTE LCF GL:12.5mm, TL: +/- 5mm");
                    cmbBOMProduct.Items.Add("RTE TEN GL:12.5mm, TL:(+6.25mm),(- 3.1mm)");
                    cmbBOMProduct.Items.Add("RTE TEN GL:12.5mm, TL:(+12.5mm),(-3.1mm)");
                    cmbBOMProduct.Items.Add("RTE TEN GL:25mm, TL:(+6mm)  ,( -3mm)");
                    cmbBOMProduct.Items.Add("RTE TEN GL:25mm, TL:(+12.5mm) ,  (-6.35mm)");
                    cmbBOMProduct.Items.Add("RTE TEN GL:25mm, TL:(+25mm)        (-12.5mm)");
                    cmbBOMProduct.Items.Add("RTE TEN GL:50mm, TL:(+12.5mm),(-6.35mm)");
                    cmbBOMProduct.Items.Add("HTE LCF GL:12.5mm, TL:+/-1.25mm");
                    cmbBOMProduct.Items.Add("HTE LCF GL:12.5mm, TL:+/-2.5mm");
                    cmbBOMProduct.Items.Add("HTE LCF GL:25mm, TL:+/-2.5mm");
                    cmbBOMProduct.Items.Add("HTE TEN GL:25mm, TL:+8mm, -2mm");
                    cmbBOMProduct.Items.Add("12gauged Flat ALS");
                    cmbBOMProduct.Items.Add("12gauged Round ALS");
                    cmbBOMProduct.Items.Add("12gauged square ALS");
                    cmbBOMProduct.Items.Add("Testing Specimen");
                    cmbBOMProduct.Items.Add("Custom Transducers");
                    cmbBOMProduct.Items.Add("Others");

                }
            }
        }

        private void frmValidationTimeSheet_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            form.Show();
        }

        private void dtpInstallationDate_ValueChanged(object sender, EventArgs e)
        {
            iWeek = GetIso8601WeekOfYear(Convert.ToDateTime(dtpTimeSheetDate.Text));
            txtWeek.Text = "Week" + iWeek;
            label4.Text = "Activity History of " + dtpTimeSheetDate.Text;
            btnSave.Text = "Save";
            fnLoadData();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            VHome.Show();
        }

        private void fnOnlynumber(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void txtHours_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber(sender, e);
        }
        private void fnEmptyTextBox(object sender, EventArgs e)
        {
            if (((TextBox)sender).Text == "")
            {
                ((TextBox)sender).Text = "0";
            }
            if (((TextBox)sender).Text == ".")
            {
                ((TextBox)sender).Text = "0";
            }
        }

        private void txtHours_Leave(object sender, EventArgs e)
        {
            fnEmptyTextBox(sender, e);
        }

        private void fnReload()
        {
            this.Hide();
            frmValidationTimeSheet Vtime = new frmValidationTimeSheet();
            Vtime.Show();
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (dtpTimeSheetDate.Value.Date <= DateTime.Today)
            {
                if (lblDepartment.Text == "Validation" || lblDepartment.Text == "Testlab" || lblDepartment.Text == "Electronics R&D" || lblDepartment.Text ==  "Quality")
                {
                    if (cmbProjectcode.SelectedIndex >= 0 && cmbSubTask.SelectedIndex >= 0 && cmbMainActivity.SelectedIndex >= 0 && !string.IsNullOrEmpty(txtHours.Text))
                    {
                        if (Convert.ToDouble(txtHours.Text) > 0)
                        {

                            if (btnSave.Text == "Save")
                            {
                                GlobalClass.iSuccess = DAL.fnAddValidationTimeSheet(1, Loginfrm.GetUserDetails[2], Loginfrm.GetUserDetails[23], dtpTimeSheetDate.Text, txtWeek.Text, cmbProjectcode.Text, lblprojname.Text,
                                    lbleighty.Text, lblCustomizationLevel.Text, cmbMainActivity.Text, cmbSubTask.Text, Convert.ToDouble(txtHours.Text), txtRemarks.Text, "", 0, "", "", "");

                                fnLoadData();
                                btnSave.Enabled = false;
                                // MessageBox.Show("Activity added to the time sheet", "Success", 0, MessageBoxIcon.Information);
                            }
                            else if (btnSave.Text == "Update")
                            {
                                GlobalClass.iSuccess = DAL.fnAddValidationTimeSheet(2, Loginfrm.GetUserDetails[2], Loginfrm.GetUserDetails[23], dtpTimeSheetDate.Text, txtWeek.Text, cmbProjectcode.Text, lblprojname.Text,
                                    lbleighty.Text, lblCustomizationLevel.Text, cmbMainActivity.Text, cmbSubTask.Text, Convert.ToDouble(txtHours.Text), txtRemarks.Text, "", ID, "", "", "");

                                fnLoadData();
                                btnSave.Enabled = false;
                                // MessageBox.Show("Activity added to the time sheet", "Success", 0, MessageBoxIcon.Information);
                                // btnSave.Text = "Save";
                            }
                            fnReload();

                        }
                        else
                        {
                            if (Convert.ToDouble(txtHours.Text) == 0)
                            {
                                MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                                txtHours.Focus();
                            }
                        }
                    }
                    else
                    {
                        if (cmbProjectcode.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the Project code", "Error", 0, MessageBoxIcon.Error);
                            cmbProjectcode.DroppedDown = true;
                        }
                        else if (cmbSubTask.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the Activity/Task", "Error", 0, MessageBoxIcon.Error);
                            cmbSubTask.DroppedDown = true;
                        }
                        else if (cmbMainActivity.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the SubTask", "Error", 0, MessageBoxIcon.Error);
                            cmbMainActivity.DroppedDown = true;
                        }
                        else if (string.IsNullOrEmpty(txtHours.Text))
                        {
                            MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                            txtHours.Focus();
                        }
                        else if (Convert.ToDouble(txtHours.Text) == 0)
                        {
                            MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                            txtHours.Focus();
                        }
                    }
                }
                else if (lblDepartment.Text == "Sales")
                {
                    if (cmbProjectcode.SelectedIndex >= 0 && cmbSubTask.SelectedIndex >= 0 && cmbMainActivity.SelectedIndex >= 0 && !string.IsNullOrEmpty(txtHours.Text))
                    {
                        if (Convert.ToDouble(txtHours.Text) > 0)
                        {

                            if (btnSave.Text == "Save")
                            {
                                GlobalClass.iSuccess = DAL.fnAddValidationTimeSheet(1, Loginfrm.GetUserDetails[2], Loginfrm.GetUserDetails[23], dtpTimeSheetDate.Text, txtWeek.Text, cmbProjectcode.Text, lblprojname.Text,
                                    lbleighty.Text, lblCustomizationLevel.Text, cmbMainActivity.Text, cmbSubTask.Text, Convert.ToDouble(txtHours.Text), txtRemarks.Text, "", 0, "", "", "");

                                fnLoadData();
                                btnSave.Enabled = false;
                                // MessageBox.Show("Activity added to the time sheet", "Success", 0, MessageBoxIcon.Information);
                            }
                            else if (btnSave.Text == "Update")
                            {
                                GlobalClass.iSuccess = DAL.fnAddValidationTimeSheet(2, Loginfrm.GetUserDetails[2], Loginfrm.GetUserDetails[23], dtpTimeSheetDate.Text, txtWeek.Text, cmbProjectcode.Text, lblprojname.Text,
                                    lbleighty.Text, lblCustomizationLevel.Text, cmbMainActivity.Text, cmbSubTask.Text, Convert.ToDouble(txtHours.Text), txtRemarks.Text, "", ID, "", "", "");

                                fnLoadData();
                                btnSave.Enabled = false;
                                // MessageBox.Show("Activity added to the time sheet", "Success", 0, MessageBoxIcon.Information);
                                // btnSave.Text = "Save";
                            }
                            fnReload();

                        }
                        else
                        {
                            if (Convert.ToDouble(txtHours.Text) == 0)
                            {
                                MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                                txtHours.Focus();
                            }
                        }
                    }
                    else
                    {
                        if (cmbProjectcode.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the Project code", "Error", 0, MessageBoxIcon.Error);
                            cmbProjectcode.DroppedDown = true;
                        }
                        else if (cmbSubTask.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the Activity/Task", "Error", 0, MessageBoxIcon.Error);
                            cmbSubTask.DroppedDown = true;
                        }
                        else if (cmbMainActivity.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the SubTask", "Error", 0, MessageBoxIcon.Error);
                            cmbMainActivity.DroppedDown = true;
                        }
                        else if (string.IsNullOrEmpty(txtHours.Text))
                        {
                            MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                            txtHours.Focus();
                        }
                        else if (Convert.ToDouble(txtHours.Text) == 0)
                        {
                            MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                            txtHours.Focus();
                        }
                    }
                }

                else if (lblDepartment.Text == "Integration" || lblDepartment.Text == "Production" || lblDepartment.Text == "Projects")
                {
                    if (cmbProjectcode.SelectedIndex >= 0 && cmbSubTask.SelectedIndex >= 0 && cmbMainActivity.SelectedIndex >= 0 && !string.IsNullOrEmpty(txtHours.Text))
                    {
                        if (Convert.ToDouble(txtHours.Text) > 0)
                        {

                            if (btnSave.Text == "Save")
                            {
                                GlobalClass.iSuccess = DAL.fnAddValidationTimeSheet(1, Loginfrm.GetUserDetails[2], Loginfrm.GetUserDetails[23], dtpTimeSheetDate.Text, txtWeek.Text, cmbProjectcode.Text, lblprojname.Text,
                                    lbleighty.Text, lblCustomizationLevel.Text, cmbMainActivity.Text, cmbSubTask.Text, Convert.ToDouble(txtHours.Text), txtRemarks.Text, "", 0, "", "", "");

                                fnLoadData();
                                btnSave.Enabled = false;
                                // MessageBox.Show("Activity added to the time sheet", "Success", 0, MessageBoxIcon.Information);
                            }
                            else if (btnSave.Text == "Update")
                            {
                                GlobalClass.iSuccess = DAL.fnAddValidationTimeSheet(2, Loginfrm.GetUserDetails[2], Loginfrm.GetUserDetails[23], dtpTimeSheetDate.Text, txtWeek.Text, cmbProjectcode.Text, lblprojname.Text,
                                    lbleighty.Text, lblCustomizationLevel.Text, cmbMainActivity.Text, cmbSubTask.Text, Convert.ToDouble(txtHours.Text), txtRemarks.Text, "", ID, "", "", "");

                                fnLoadData();
                                btnSave.Enabled = false;
                                // MessageBox.Show("Activity added to the time sheet", "Success", 0, MessageBoxIcon.Information);
                                // btnSave.Text = "Save";
                            }
                            fnReload();

                        }
                        else
                        {
                            if (Convert.ToDouble(txtHours.Text) == 0)
                            {
                                MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                                txtHours.Focus();
                            }
                        }
                    }
                    else
                    {
                        if (cmbProjectcode.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the Project code", "Error", 0, MessageBoxIcon.Error);
                            cmbProjectcode.DroppedDown = true;
                        }
                        else if (cmbSubTask.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the Activity/Task", "Error", 0, MessageBoxIcon.Error);
                            cmbSubTask.DroppedDown = true;
                        }
                        else if (cmbMainActivity.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the SubTask", "Error", 0, MessageBoxIcon.Error);
                            cmbMainActivity.DroppedDown = true;
                        }
                        else if (string.IsNullOrEmpty(txtHours.Text))
                        {
                            MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                            txtHours.Focus();
                        }
                        else if (Convert.ToDouble(txtHours.Text) == 0)
                        {
                            MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                            txtHours.Focus();
                        }
                    }
                }

                else if (lblDepartment.Text == "Design")
                {
                    if (cmbProjectcode.SelectedIndex >= 0 && cmbSubTask.SelectedIndex >= 0 && cmbMainActivity.SelectedIndex >= 0 && !string.IsNullOrEmpty(txtHours.Text))
                    {
                        if (Convert.ToDouble(txtHours.Text) > 0)
                        {
                            if (btnSave.Text == "Save")
                            {
                                GlobalClass.iSuccess = DAL.fnAddValidationTimeSheet(1, Loginfrm.GetUserDetails[2], Loginfrm.GetUserDetails[23], dtpTimeSheetDate.Text, txtWeek.Text, cmbProjectcode.Text, lblprojname.Text,
                                    lbleighty.Text, lblCustomizationLevel.Text, cmbMainActivity.Text, cmbSubTask.Text, Convert.ToDouble(txtHours.Text), txtRemarks.Text, "", 0, "", "", "");

                                fnLoadData();
                                // btnSave.Enabled = false;
                                // MessageBox.Show("Activity added to the time sheet", "Success", 0, MessageBoxIcon.Information);
                            }
                            else if (btnSave.Text == "Update")
                            {
                                GlobalClass.iSuccess = DAL.fnAddValidationTimeSheet(2, Loginfrm.GetUserDetails[2], Loginfrm.GetUserDetails[23], dtpTimeSheetDate.Text, txtWeek.Text, cmbProjectcode.Text, lblprojname.Text,
                                    lbleighty.Text, lblCustomizationLevel.Text, cmbMainActivity.Text, cmbSubTask.Text, Convert.ToDouble(txtHours.Text), txtRemarks.Text, "", ID, "", "", "");

                                fnLoadData();
                                // btnSave.Enabled = false;
                                //  MessageBox.Show("Activity added to the time sheet", "Success", 0, MessageBoxIcon.Information);
                                // btnSave.Text = "Save";
                            }
                            fnReload();
                        }
                        else
                        {
                            if (Convert.ToDouble(txtHours.Text) == 0)
                            {
                                MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                                txtHours.Focus();
                            }
                        }
                    }
                    else
                    {
                        if (cmbProjectcode.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the Project code", "Error", 0, MessageBoxIcon.Error);
                            cmbProjectcode.DroppedDown = true;
                        }
                        else if (cmbSubTask.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the Activity/Task", "Error", 0, MessageBoxIcon.Error);
                            cmbSubTask.DroppedDown = true;
                        }
                        else if (cmbMainActivity.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the SubTask", "Error", 0, MessageBoxIcon.Error);
                            cmbMainActivity.DroppedDown = true;
                        }
                        else if (string.IsNullOrEmpty(txtHours.Text))
                        {
                            MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                            txtHours.Focus();
                        }
                        else if (Convert.ToDouble(txtHours.Text) == 0)
                        {
                            MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                            txtHours.Focus();
                        }
                    }
                }
                else if (lblDepartment.Text == "Electricals")
                {
                    if (cmbProjectcode.SelectedIndex >= 0 && cmbSubTask.SelectedIndex >= 0 && cmbMainActivity.SelectedIndex >= 0 && !string.IsNullOrEmpty(txtHours.Text))
                    {
                        if (Convert.ToDouble(txtHours.Text) > 0)
                        {
                            if (btnSave.Text == "Save")
                            {
                                GlobalClass.iSuccess = DAL.fnAddValidationTimeSheet(1, Loginfrm.GetUserDetails[2], Loginfrm.GetUserDetails[23], dtpTimeSheetDate.Text, txtWeek.Text, cmbProjectcode.Text, lblprojname.Text,
                                    lbleighty.Text, lblCustomizationLevel.Text, cmbMainActivity.Text, cmbSubTask.Text, Convert.ToDouble(txtHours.Text), txtRemarks.Text, cmbCapacity.Text, 0, cmbBOMProduct.Text, txtProductName.Text, txtSlNo.Text);

                                fnLoadData();
                                //  btnSave.Enabled = false;
                                // MessageBox.Show("Activity added to the time sheet", "Success", 0, MessageBoxIcon.Information);
                            }
                            else if (btnSave.Text == "Update")
                            {
                                GlobalClass.iSuccess = DAL.fnAddValidationTimeSheet(2, Loginfrm.GetUserDetails[2], Loginfrm.GetUserDetails[23], dtpTimeSheetDate.Text, txtWeek.Text, cmbProjectcode.Text, lblprojname.Text,
                                    lbleighty.Text, lblCustomizationLevel.Text, cmbMainActivity.Text, cmbSubTask.Text, Convert.ToDouble(txtHours.Text), txtRemarks.Text, cmbCapacity.Text, ID, cmbBOMProduct.Text, txtProductName.Text, txtSlNo.Text);

                                fnLoadData();
                                //btnSave.Enabled = false;
                                //MessageBox.Show("Activity added to the time sheet", "Success", 0, MessageBoxIcon.Information);
                                //btnSave.Text = "Save";
                            }
                            fnReload();
                        }
                        else
                        {
                            if (Convert.ToDouble(txtHours.Text) == 0)
                            {
                                MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                                txtHours.Focus();
                            }
                        }
                    }
                    else
                    {
                        if (cmbProjectcode.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the Project code", "Error", 0, MessageBoxIcon.Error);
                            cmbProjectcode.DroppedDown = true;
                        }
                        else if (cmbSubTask.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the Activity/Task", "Error", 0, MessageBoxIcon.Error);
                            cmbSubTask.DroppedDown = true;
                        }
                        else if (cmbMainActivity.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the SubTask", "Error", 0, MessageBoxIcon.Error);
                            cmbMainActivity.DroppedDown = true;
                        }
                        else if (string.IsNullOrEmpty(txtHours.Text))
                        {
                            MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                            txtHours.Focus();
                        }
                        else if (Convert.ToDouble(txtHours.Text) == 0)
                        {
                            MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                            txtHours.Focus();
                        }
                    }
                }
                else if (lblDepartment.Text == "Hydraulics")
                {
                    if (cmbProjectcode.SelectedIndex >= 0 && cmbSubTask.SelectedIndex >= 0 && cmbMainActivity.SelectedIndex >= 0 && !string.IsNullOrEmpty(txtHours.Text))
                    {
                        if (Convert.ToDouble(txtHours.Text) > 0)
                        {
                            if (btnSave.Text == "Save")
                            {
                                GlobalClass.iSuccess = DAL.fnAddValidationTimeSheet(1, Loginfrm.GetUserDetails[2], Loginfrm.GetUserDetails[23], dtpTimeSheetDate.Text, txtWeek.Text, cmbProjectcode.Text, lblprojname.Text,
                                    lbleighty.Text, lblCustomizationLevel.Text, cmbMainActivity.Text, cmbSubTask.Text, Convert.ToDouble(txtHours.Text), txtRemarks.Text, cmbCapacity.Text, 0, cmbBOMProduct.Text, txtProductName.Text, txtSlNo.Text);

                                fnLoadData();
                                //btnSave.Enabled = false;
                                //MessageBox.Show("Activity added to the time sheet", "Success", 0, MessageBoxIcon.Information);
                            }
                            else if (btnSave.Text == "Update")
                            {
                                GlobalClass.iSuccess = DAL.fnAddValidationTimeSheet(2, Loginfrm.GetUserDetails[2], Loginfrm.GetUserDetails[23], dtpTimeSheetDate.Text, txtWeek.Text, cmbProjectcode.Text, lblprojname.Text,
                                    lbleighty.Text, lblCustomizationLevel.Text, cmbMainActivity.Text, cmbSubTask.Text, Convert.ToDouble(txtHours.Text), txtRemarks.Text, cmbCapacity.Text, ID, cmbBOMProduct.Text, txtProductName.Text, txtSlNo.Text);

                                fnLoadData();
                                //btnSave.Enabled = false;
                                //MessageBox.Show("Activity added to the time sheet", "Success", 0, MessageBoxIcon.Information);
                                //btnSave.Text = "Save";
                            }
                            fnReload();
                        }
                        else
                        {
                            if (Convert.ToDouble(txtHours.Text) == 0)
                            {
                                MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                                txtHours.Focus();
                            }
                        }
                    }
                    else
                    {
                        if (cmbProjectcode.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the Project code", "Error", 0, MessageBoxIcon.Error);
                            cmbProjectcode.DroppedDown = true;
                        }
                        else if (cmbSubTask.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the Activity/Task", "Error", 0, MessageBoxIcon.Error);
                            cmbSubTask.DroppedDown = true;
                        }
                        else if (cmbMainActivity.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the SubTask", "Error", 0, MessageBoxIcon.Error);
                            cmbMainActivity.DroppedDown = true;
                        }
                        else if (string.IsNullOrEmpty(txtHours.Text))
                        {
                            MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                            txtHours.Focus();
                        }
                        else if (Convert.ToDouble(txtHours.Text) == 0)
                        {
                            MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                            txtHours.Focus();
                        }
                    }
                }
                else if (lblDepartment.Text == "RnD")
                {
                    if (cmbProjectcode.SelectedIndex >= 0 && cmbSubTask.SelectedIndex >= 0 && cmbMainActivity.SelectedIndex >= 0 && !string.IsNullOrEmpty(txtHours.Text) && cmbCapacity.SelectedIndex >= 0 && !string.IsNullOrEmpty(txtSubModule.Text))
                    {
                        if (Convert.ToDouble(txtHours.Text) > 0)
                        {
                            if (btnSave.Text == "Save")
                            {
                                GlobalClass.iSuccess = DAL.fnAddValidationTimeSheet(1, Loginfrm.GetUserDetails[2], Loginfrm.GetUserDetails[23], dtpTimeSheetDate.Text, txtWeek.Text, cmbProjectcode.Text, lblprojname.Text,
                                    lbleighty.Text, lblCustomizationLevel.Text, cmbMainActivity.Text, cmbSubTask.Text, Convert.ToDouble(txtHours.Text), txtSubModule.Text, cmbCapacity.Text, 0, txtVersion.Text, txtRemarks.Text, cmbBackuprun.Text);

                                fnLoadData();
                                //btnSave.Enabled = false;
                                //MessageBox.Show("Activity added to the time sheet", "Success", 0, MessageBoxIcon.Information);
                            }
                            else if (btnSave.Text == "Update")
                            {
                                GlobalClass.iSuccess = DAL.fnAddValidationTimeSheet(2, Loginfrm.GetUserDetails[2], Loginfrm.GetUserDetails[23], dtpTimeSheetDate.Text, txtWeek.Text, cmbProjectcode.Text, lblprojname.Text,
                                    lbleighty.Text, lblCustomizationLevel.Text, cmbMainActivity.Text, cmbSubTask.Text, Convert.ToDouble(txtHours.Text), txtSubModule.Text, cmbCapacity.Text, ID, txtVersion.Text, txtRemarks.Text, cmbBackuprun.Text);

                                fnLoadData();
                                //btnSave.Enabled = false;
                                //MessageBox.Show("Activity added to the time sheet", "Success", 0, MessageBoxIcon.Information);
                                //btnSave.Text = "Save";
                            }
                            fnReload();
                        }
                        else
                        {
                            if (Convert.ToDouble(txtHours.Text) == 0)
                            {
                                MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                                txtHours.Focus();
                            }
                        }
                    }
                    else
                    {
                        if (cmbProjectcode.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the Project code", "Error", 0, MessageBoxIcon.Error);
                            cmbProjectcode.DroppedDown = true;
                        }
                        else if (cmbSubTask.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the Activity/Task", "Error", 0, MessageBoxIcon.Error);
                            cmbSubTask.DroppedDown = true;
                        }
                        else if (cmbMainActivity.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the SubTask", "Error", 0, MessageBoxIcon.Error);
                            cmbMainActivity.DroppedDown = true;
                        }

                        else if (string.IsNullOrEmpty(txtHours.Text))
                        {
                            MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                            txtHours.Focus();
                        }
                        else if (Convert.ToDouble(txtHours.Text) == 0)
                        {
                            MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                            txtHours.Focus();
                        }
                        else if (cmbCapacity.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the hour type ", "Error", 0, MessageBoxIcon.Error);
                            cmbCapacity.DroppedDown = true;
                        }
                        else if (string.IsNullOrEmpty(txtSubModule.Text))
                        {
                            MessageBox.Show("Write the remarks", "Error", 0, MessageBoxIcon.Error);
                            txtSubModule.Focus();
                        }
                    }
                }
                else if (lblDepartment.Text == "Electronics")
                {
                    if (cmbProjectcode.SelectedIndex >= 0 && cmbSubTask.SelectedIndex >= 0 && cmbMainActivity.SelectedIndex >= 0 && !string.IsNullOrEmpty(txtHours.Text)
                        && cmbBOMProduct.SelectedIndex >= 0 && !string.IsNullOrEmpty(txtProductName.Text) && !string.IsNullOrEmpty(txtSlNo.Text))
                    {
                        //if ((cmbMainActivity.Text == "Holiday" || cmbMainActivity.Text == "Leave"))
                        //{

                        //    if (btnSave.Text == "Save")
                        //    {
                        //        GlobalClass.iSuccess = DAL.fnAddValidationTimeSheet(1, Loginfrm.GetUserDetails[2], Loginfrm.GetUserDetails[23], dtpTimeSheetDate.Text, txtWeek.Text, cmbProjectcode.Text, lblprojname.Text,
                        //            lbleighty.Text, lblCustomizationLevel.Text, cmbMainActivity.Text, cmbSubTask.Text, Convert.ToDouble(txtHours.Text), txtRemarks.Text, cmbCapacity.Text, 0, cmbBOMProduct.Text, txtProductName.Text, txtSlNo.Text);

                        //        fnLoadData();
                        //        btnSave.Enabled = false;
                        //        MessageBox.Show("Activity added to the time sheet", "Success", 0, MessageBoxIcon.Information);
                        //    }
                        //    else if (btnSave.Text == "Update")
                        //    {
                        //        GlobalClass.iSuccess = DAL.fnAddValidationTimeSheet(2, Loginfrm.GetUserDetails[2], Loginfrm.GetUserDetails[23], dtpTimeSheetDate.Text, txtWeek.Text, cmbProjectcode.Text, lblprojname.Text,
                        //            lbleighty.Text, lblCustomizationLevel.Text, cmbMainActivity.Text, cmbSubTask.Text, Convert.ToDouble(txtHours.Text), txtRemarks.Text, cmbCapacity.Text, ID, cmbBOMProduct.Text, txtProductName.Text, txtSlNo.Text);

                        //        fnLoadData();
                        //        btnSave.Enabled = false;
                        //        MessageBox.Show("Activity added to the time sheet", "Success", 0, MessageBoxIcon.Information);
                        //        btnSave.Text = "Save";
                        //    }

                        //}
                        //else
                        //{
                        //if (cmbBOMProduct.SelectedIndex >= 0 && !string.IsNullOrEmpty(txtProductName.Text) && !string.IsNullOrEmpty(txtSlNo.Text))
                        //{
                        if (Convert.ToDouble(txtHours.Text) > 0)
                        {
                            if (btnSave.Text == "Save")
                            {
                                GlobalClass.iSuccess = DAL.fnAddValidationTimeSheet(1, Loginfrm.GetUserDetails[2], Loginfrm.GetUserDetails[23], dtpTimeSheetDate.Text, txtWeek.Text, cmbProjectcode.Text, lblprojname.Text,
                                    lbleighty.Text, lblCustomizationLevel.Text, cmbMainActivity.Text, cmbSubTask.Text, Convert.ToDouble(txtHours.Text), txtRemarks.Text, cmbCapacity.Text, 0, cmbBOMProduct.Text, txtProductName.Text, txtSlNo.Text);

                                fnLoadData();
                                //btnSave.Enabled = false;
                                //MessageBox.Show("Activity added to the time sheet", "Success", 0, MessageBoxIcon.Information);
                            }
                            else if (btnSave.Text == "Update")
                            {
                                GlobalClass.iSuccess = DAL.fnAddValidationTimeSheet(2, Loginfrm.GetUserDetails[2], Loginfrm.GetUserDetails[23], dtpTimeSheetDate.Text, txtWeek.Text, cmbProjectcode.Text, lblprojname.Text,
                                    lbleighty.Text, lblCustomizationLevel.Text, cmbMainActivity.Text, cmbSubTask.Text, Convert.ToDouble(txtHours.Text), txtRemarks.Text, cmbCapacity.Text, ID, cmbBOMProduct.Text, txtProductName.Text, txtSlNo.Text);

                                fnLoadData();
                                //btnSave.Enabled = false;
                                //MessageBox.Show("Activity added to the time sheet", "Success", 0, MessageBoxIcon.Information);
                                //btnSave.Text = "Save";
                            }
                            fnReload();
                        }
                        else
                        {
                            if (Convert.ToDouble(txtHours.Text) == 0)
                            {
                                MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                                txtHours.Focus();
                            }
                        }
                        //   }
                    }
                    else
                    {
                        if (cmbProjectcode.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the Project code", "Error", 0, MessageBoxIcon.Error);
                            cmbProjectcode.DroppedDown = true;
                        }
                        else if (cmbSubTask.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the Activity/Task", "Error", 0, MessageBoxIcon.Error);
                            cmbSubTask.DroppedDown = true;
                        }
                        else if (cmbMainActivity.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the SubTask", "Error", 0, MessageBoxIcon.Error);
                            cmbMainActivity.DroppedDown = true;
                        }
                        else if (string.IsNullOrEmpty(txtHours.Text))
                        {
                            MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                            txtHours.Focus();
                        }
                        else if (Convert.ToDouble(txtHours.Text) == 0)
                        {
                            MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                            txtHours.Focus();
                        }
                        else if (cmbBOMProduct.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the Card/Controller", "Error", 0, MessageBoxIcon.Error);
                            cmbBOMProduct.DroppedDown = true;
                        }
                        else if (string.IsNullOrEmpty(txtProductName.Text))
                        {
                            MessageBox.Show("Enter Quantity", "Error", 0, MessageBoxIcon.Error);
                            txtProductName.Focus();
                        }
                        else if (string.IsNullOrEmpty(txtSlNo.Text))
                        {
                            MessageBox.Show("Enter the serial number", "Error", 0, MessageBoxIcon.Error);
                            txtSlNo.Focus();
                        }

                    }
                }

                else if (lblDepartment.Text == "Transducer")
                {
                    if (cmbProjectcode.SelectedIndex >= 0 && cmbSubTask.SelectedIndex >= 0 && cmbMainActivity.SelectedIndex >= 0 && !string.IsNullOrEmpty(txtHours.Text)
                        && cmbBOMProduct.SelectedIndex >= 0 && !string.IsNullOrEmpty(txtProductName.Text) && !string.IsNullOrEmpty(txtSlNo.Text))
                    {
                        if (Convert.ToDouble(txtHours.Text) > 0)
                        {
                            if (btnSave.Text == "Save")
                            {
                                GlobalClass.iSuccess = DAL.fnAddValidationTimeSheet(1, Loginfrm.GetUserDetails[2], Loginfrm.GetUserDetails[23], dtpTimeSheetDate.Text, txtWeek.Text, cmbProjectcode.Text, lblprojname.Text,
                                    lbleighty.Text, lblCustomizationLevel.Text, cmbMainActivity.Text, cmbSubTask.Text, Convert.ToDouble(txtHours.Text), txtRemarks.Text, cmbCapacity.Text, 0, cmbBOMProduct.Text, txtProductName.Text, txtSlNo.Text);

                                fnLoadData();
                            }
                            else if (btnSave.Text == "Update")
                            {
                                GlobalClass.iSuccess = DAL.fnAddValidationTimeSheet(2, Loginfrm.GetUserDetails[2], Loginfrm.GetUserDetails[23], dtpTimeSheetDate.Text, txtWeek.Text, cmbProjectcode.Text, lblprojname.Text,
                                    lbleighty.Text, lblCustomizationLevel.Text, cmbMainActivity.Text, cmbSubTask.Text, Convert.ToDouble(txtHours.Text), txtRemarks.Text, cmbCapacity.Text, ID, cmbBOMProduct.Text, txtProductName.Text, txtSlNo.Text);

                                fnLoadData();
                            }
                            fnReload();
                        }
                        else
                        {
                            if (Convert.ToDouble(txtHours.Text) == 0)
                            {
                                MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                                txtHours.Focus();
                            }
                        }
                    }
                    else
                    {
                        if (cmbProjectcode.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the Project code", "Error", 0, MessageBoxIcon.Error);
                            cmbProjectcode.DroppedDown = true;
                        }
                        else if (cmbSubTask.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the Activity/Task", "Error", 0, MessageBoxIcon.Error);
                            cmbSubTask.DroppedDown = true;
                        }
                        else if (cmbMainActivity.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the SubTask", "Error", 0, MessageBoxIcon.Error);
                            cmbMainActivity.DroppedDown = true;
                        }
                        else if (string.IsNullOrEmpty(txtHours.Text))
                        {
                            MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                            txtHours.Focus();
                        }
                        else if (Convert.ToDouble(txtHours.Text) == 0)
                        {
                            MessageBox.Show("Enter the Hours", "Error", 0, MessageBoxIcon.Error);
                            txtHours.Focus();
                        }
                        else if (cmbBOMProduct.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the Card/Controller", "Error", 0, MessageBoxIcon.Error);
                            cmbBOMProduct.DroppedDown = true;
                        }
                        else if (string.IsNullOrEmpty(txtProductName.Text))
                        {
                            MessageBox.Show("Enter Quantity", "Error", 0, MessageBoxIcon.Error);
                            txtProductName.Focus();
                        }
                        else if (string.IsNullOrEmpty(txtSlNo.Text))
                        {
                            MessageBox.Show("Enter the serial number", "Error", 0, MessageBoxIcon.Error);
                            txtSlNo.Focus();
                        }

                    }
                }
            }
            else
            {
                MessageBox.Show("Date should be less than or equal to today date only.", "Error", 0, MessageBoxIcon.Error);
            }
        }

        private void cmbActivityTask_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (btnSave.Enabled == false)
            {
                btnSave.Enabled = true;
            }
            //   if (btnSave.Text == "Save")
            //{
            //   fnSubTaskTotal();
            //}
        }
        int ID = 0;
        DataTable dtTimeSheetActivities = new DataTable();
        DataTable dtEnquiryNum = new DataTable();
        private void cmbSubTask_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbSubTask.Items.Clear();
            cmbSubTask.SelectedIndex = -1;
            // txtHours.Text="0";
            if (lblDepartment.Text != "RnD")
            {
                dtTimeSheetActivities = DAL.fnDepartmentTimeSheetActivity(1, Loginfrm.GetUserDetails[23], cmbMainActivity.Text, "", "").Tables[0];

                if (dtTimeSheetActivities.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtTimeSheetActivities.Rows)
                    {
                        if (!cmbSubTask.Items.Contains(dr["SubActivity"].ToString()))
                        {
                            cmbSubTask.Items.Add(dr["SubActivity"].ToString());
                        }
                    }

                    if (lblDepartment.Text == "Sales")
                    {
                        if (cmbMainActivity.Text == "Enquiry Handling" || cmbMainActivity.Text == "Sales")
                        {
                            cmbProjectcode.SelectedIndex = -1;
                            cmbProjectcode.Items.Clear();
                            dtpTimeSheetDate.Format = DateTimePickerFormat.Custom;
                            dtpTimeSheetDate.CustomFormat = "yyyy-MM-dd";
                            dtEnquiryNum = DAL.fnEnquiryCheck(2, "2020-01-01", dtpTimeSheetDate.Text, "").Tables[0];
                            dtpTimeSheetDate.Format = DateTimePickerFormat.Custom;
                            dtpTimeSheetDate.CustomFormat = "dd-MM-yyyy";
                            cmbProjectcode.Items.Add("NA");
                            foreach (DataRow DR in dtEnquiryNum.Rows)
                            {
                                if (!cmbProjectcode.Items.Contains(DR["EnquiryNumber"].ToString()))
                                    cmbProjectcode.Items.Add(DR["EnquiryNumber"].ToString());
                            }
                        }
                        else if (cmbMainActivity.Text == "Order Execution")
                        {
                            cmbProjectcode.SelectedIndex = -1;
                            cmbProjectcode.Items.Clear();
                            cmbProjectcode.Items.Add("BiSS_001");
                            cmbProjectcode.Items.Add("RnD_001");
                            cmbProjectcode.Items.Add("NA");
                            foreach (DataRow DR in dtProjectList.Rows)
                            {
                                if (!cmbProjectcode.Items.Contains(DR["ProjectCode"].ToString()))
                                    cmbProjectcode.Items.Add(DR["ProjectCode"].ToString());
                            }

                        }
                        else if (cmbMainActivity.Text == "MARCOM" || cmbMainActivity.Text == "BT" || cmbMainActivity.Text == "Training" || cmbMainActivity.Text == "Tool Box" || cmbMainActivity.Text == "General")
                        {
                            cmbProjectcode.SelectedIndex = -1;
                            cmbProjectcode.Items.Clear();
                            cmbProjectcode.Items.Add("UTM");
                            cmbProjectcode.Items.Add("STS");
                            cmbProjectcode.Items.Add("DTS");
                            cmbProjectcode.Items.Add("LFS");
                            cmbProjectcode.Items.Add("TGT");
                            cmbProjectcode.Items.Add("FSW");
                            cmbProjectcode.Items.Add("ShakeTable");
                            cmbProjectcode.Items.Add("CustomRigs");
                            cmbProjectcode.Items.Add("Others");
                            cmbProjectcode.Items.Add("NA");


                        }

                    }


                    if (cmbMainActivity.Text == "Holiday" || cmbMainActivity.Text == "Leave" || cmbMainActivity.Text == "Weekly Off")
                    {
                        cmbSubTask.SelectedIndex = 0;
                        txtHours.Text = "0.00001";
                        cmbSubTask.Enabled = false;
                        txtHours.Enabled = false;
                        cmbProjectcode.Items.Add("  ");
                        cmbProjectcode.SelectedItem = "  ";
                        lblprojname.Text = "";
                        lbleighty.Text = "";
                        lblCustomizationLevel.Text = "";
                        if (lblDepartment.Text == "Electronics" || lblDepartment.Text == "Transducer")
                        {
                            cmbBOMProduct.Items.Add(" ");
                            cmbBOMProduct.SelectedItem = " ";
                            txtProductName.Text = "--";
                            txtSlNo.Text = "--";
                        }
                    }
                    else
                    {
                        cmbSubTask.Enabled = true;
                        txtHours.Enabled = true;
                    }
                }
                else
                {
                    cmbSubTask.Items.Add("");
                }
            }
            else if (lblDepartment.Text == "RnD")
            {
                dtTimeSheetActivities = DAL.fnDepartmentTimeSheetActivity(3, Loginfrm.GetUserDetails[23], cmbMainActivity.Text, "", "").Tables[0];

                if (dtTimeSheetActivities.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtTimeSheetActivities.Rows)
                    {
                        if (!cmbSubTask.Items.Contains(dr["SubActivity"].ToString()))
                        {
                            cmbSubTask.Items.Add(dr["SubActivity"].ToString());
                        }
                    }

                    if (cmbMainActivity.Text == "Holiday" || cmbMainActivity.Text == "Leave" || cmbMainActivity.Text == "Weekly Off")
                    {
                        cmbSubTask.Items.Add("--");
                        cmbSubTask.SelectedItem = "--";

                        cmbProjectcode.Items.Add("  ");
                        cmbProjectcode.SelectedItem = "  ";
                        lblprojname.Text = "";
                        lbleighty.Text = "";
                        lblCustomizationLevel.Text = "";
                        txtHours.Text = "0.00001";
                        cmbSubTask.Enabled = false;
                        txtHours.Enabled = false;

                        cmbCapacity.Items.Add("");
                        cmbCapacity.SelectedItem = "";
                        txtSubModule.Text = "--";
                    }
                    else
                    {
                        cmbSubTask.Enabled = true;
                        txtHours.Enabled = true;
                    }
                }
                else
                {
                    cmbSubTask.Items.Add("");
                }
            }

            //  fnSubTaskTotal();
        }

        private void fnSubTaskTotal()
        {
            //if (btnSave.Enabled == false)
            //{
            //    btnSave.Enabled = true;
            //}
            //btnSave.Text = "Save";
            if (dgvTimeSheet.Rows.Count > 0 && cmbMainActivity.SelectedIndex >= 0)
            {
                ID = 0;
                // btnSave.Text = "Update";
                ID = Convert.ToInt32(dgvTimeSheet.CurrentRow.Cells["ID1"].Value);
                txtHours.Text = dgvTimeSheet.CurrentRow.Cells["TotalHours"].Value.ToString();
                //  txtRemarks.Text = dgvTimeSheet.CurrentRow.Cells["Remarks"].Value.ToString();

            }
        }

        private void dgvTimeSheet_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvTimeSheet.Rows.Count > 0)
            {
                cmbMainActivity.SelectedItem = dgvTimeSheet.CurrentRow.Cells["ActivityTask"].Value.ToString();
                cmbSubTask.SelectedItem = dgvTimeSheet.CurrentRow.Cells["SubTask"].Value.ToString();
                cmbProjectcode.SelectedItem = dgvTimeSheet.CurrentRow.Cells["ProjectCode"].Value.ToString();
                ID = Convert.ToInt32(dgvTimeSheet.CurrentRow.Cells["ID1"].Value);
                txtRemarks.Text = dgvTimeSheet.CurrentRow.Cells["Remarks"].Value.ToString();
              
                txtHours.Text = dgvTimeSheet.CurrentRow.Cells["TotalHours"].Value.ToString();
                btnSave.Text = "Update";
                if (btnSave.Enabled == false)
                {
                    btnSave.Enabled = true;
                }
                if (lblDepartment.Text == "Hydraulics" || lblDepartment.Text == "Electricals")
                {
                    cmbCapacity.SelectedItem = dgvTimeSheet.CurrentRow.Cells["RangeCapacity"].Value.ToString();
                    cmbBOMProduct.SelectedItem = dgvTimeSheet.CurrentRow.Cells["ProductCode"].Value.ToString();
                    txtSlNo.Text = dgvTimeSheet.CurrentRow.Cells["ProductSerialNumber"].Value.ToString();
                }
                else if (lblDepartment.Text == "Electronics" || lblDepartment.Text == "Transducer")
                {
                    txtProductName.Text = dgvTimeSheet.CurrentRow.Cells["ProductName"].Value.ToString();
                    cmbBOMProduct.SelectedItem = dgvTimeSheet.CurrentRow.Cells["ProductCode"].Value.ToString();
                    txtSlNo.Text = dgvTimeSheet.CurrentRow.Cells["ProductSerialNumber"].Value.ToString();
                }

                else if (lblDepartment.Text == "RnD")
                {
                    txtSubModule.Text = dgvTimeSheet.CurrentRow.Cells["Remarks"].Value.ToString();
                    txtRemarks.Text = dgvTimeSheet.CurrentRow.Cells["ProductName"].Value.ToString();
                    cmbCapacity.SelectedItem = dgvTimeSheet.CurrentRow.Cells["RangeCapacity"].Value.ToString();
                    txtVersion.Text = dgvTimeSheet.CurrentRow.Cells["ProductCode"].Value.ToString();
                    if (!string.IsNullOrEmpty(dgvTimeSheet.CurrentRow.Cells["ProductSerialNumber"].Value.ToString()))
                    {
                        cmbBackuprun.SelectedItem = dgvTimeSheet.CurrentRow.Cells["ProductSerialNumber"].Value.ToString();
                    }
                    else
                    {
                        cmbBackuprun.SelectedIndex = -1;
                    }
                }
            }
        }

        private void dgvTimeSheet_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (dgvTimeSheet.Rows.Count > 0)
                {
                    DialogResult DR = MessageBox.Show("Do you want to delete selected?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (DR == DialogResult.Yes)
                    {
                        GlobalClass.iSuccess = DAL.fnAddValidationTimeSheet(3, Loginfrm.GetUserDetails[2], Loginfrm.GetUserDetails[23], dtpTimeSheetDate.Text, txtWeek.Text, cmbProjectcode.Text, lblprojname.Text,
                            lbleighty.Text, lblCustomizationLevel.Text, cmbMainActivity.Text, cmbSubTask.Text, 0.0, txtRemarks.Text, "", Convert.ToInt32(dgvTimeSheet.CurrentRow.Cells["ID1"].Value), "", "", "");
                        dgvTimeSheet.Rows.RemoveAt(dgvTimeSheet.Rows.IndexOf(dgvTimeSheet.CurrentRow));
                        fnLoadData();
                    }
                }
            }
        }

        DataTable dtprojectBOMItems = new DataTable();
        private void cmbbomname_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtprojectBOMItems = DAL.fnProjectBOMProdutDetails(cmbBOMProduct.Text, cmbProjectcode.Text).Tables[0];
            if (dtprojectBOMItems.Rows.Count > 0)
            {
                txtProductName.Text = dtprojectBOMItems.Rows[0]["ProductName"].ToString();
            }
        }

        private void txtProductName_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber(sender, e);
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            Time_Sheet.frmViewTimesheetforuser View = new frmViewTimesheetforuser();
            View.ShowDialog();
        }

        private void dtpTimeSheetDate_ValueChanged(object sender, EventArgs e)
        {
            iWeek = GetIso8601WeekOfYear(Convert.ToDateTime(dtpTimeSheetDate.Text));
            txtWeek.Text = "Week" + iWeek;
            label4.Text = "Activity History of " + dtpTimeSheetDate.Text;
            btnSave.Text = "Save";
            fnLoadData();
        }

        private void lblHistoryHours_Click(object sender, EventArgs e)
        {

        }
    }
}
