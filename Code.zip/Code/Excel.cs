﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Diagnostics;

namespace Erp_Project_With_Buttons
{
    class Excel
    {
        public object Total = 0.0; string excelRange = string.Empty;

        public static object XlLineStyle { get; internal set; }

        public void ExportToExcel(DataSet dataSet, string outputPath, string tablename)
        {

            // Create the Excel Application object
            Microsoft.Office.Interop.Excel.Application excelApp = new Microsoft.Office.Interop.Excel.Application();

            // Create a new Excel Workbook
            Workbook excelWorkbook = excelApp.Workbooks.Add(Type.Missing);
            Worksheet excelSheet = (Worksheet)excelWorkbook.Sheets.Add(excelWorkbook.Sheets.get_Item(1), Type.Missing, 1, XlSheetType.xlWorksheet);
            int StockValue;
            // Copy each DataTable
            foreach (System.Data.DataTable dt in dataSet.Tables)
            {
                Total = 0.0;
                if (tablename == "ItemMaster")
                {
                    Total = dt.Compute("Sum(StockValue)", "");
                    StockValue = dataSet.Tables[0].Columns.IndexOf("StockValue");
                }
                // Copy the DataTable to an object array
                object[,] rawData = new object[dt.Rows.Count + 1, dt.Columns.Count];

                // Copy the column names to the first row of the object array
                for (int col = 0; col < dt.Columns.Count; col++)
                {
                    rawData[0, col] = dt.Columns[col].ColumnName;
                }
                // Copy the values to the object array
                for (int col = 0; col < dt.Columns.Count; col++)
                {
                    for (int row = 0; row < dt.Rows.Count; row++)
                    {
                        rawData[row + 1, col] = dt.Rows[row].ItemArray[col];
                    }
                }

                // Calculate the final column letter
                string finalColLetter = string.Empty;
                string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                int colCharsetLen = colCharset.Length;

                if (dt.Columns.Count > colCharsetLen)
                {
                    finalColLetter = colCharset.Substring(
                        (dt.Columns.Count - 1) / colCharsetLen - 1, 1);
                }

                finalColLetter += colCharset.Substring(
                        (dt.Columns.Count - 1) % colCharsetLen, 1);

                // Create a new Sheet

                excelSheet.Columns.AutoFit(); excelSheet.Rows.AutoFit();
                excelSheet.Name = dt.TableName;
                excelSheet.Cells[1, 1] = Global.sCompanyName; excelSheet.Range["A1:C1"].Cells.Font.Size = 16; excelSheet.Range["A1:C1"].Cells.Font.Bold = 16;
                excelSheet.get_Range("A1", "C1").Merge(true);
                // Fast data export to Excel
                string excelRange = string.Format("A5:{0}{1}",
                    finalColLetter, dt.Rows.Count);

                if (tablename == "ItemMaster")
                {
                    excelSheet.Name = "Item Master";
                    excelSheet.get_Range("E1", "F3").Merge(true);
                    Range r = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[1, 3];
                    r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                    excelSheet.Cells[2, 2] = "Item Master"; excelSheet.Range["A2:C2"].Cells.Font.Size = 14; excelSheet.Range["A2:C2"].Cells.Font.Bold = 14;
                    excelSheet.Cells[3, 1] = "Total Stock Balance"; excelSheet.Range["A3:B3"].Cells.Font.Size = 12; excelSheet.Range["A3:B3"].Cells.Font.Bold = 12;
                    excelSheet.Cells[3, 2] = Total.ToString(); excelSheet.Range["A3:C4"].Cells.Font.Size = 12; excelSheet.Range["A3:C4"].Cells.Font.Bold = 12;
                    // Mark the first row as BOLD
                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Bold = true;
                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Size = 12;
                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Color = Color.Blue;
                    excelRange = string.Format("A5:{0}{1}",
                    finalColLetter, dt.Rows.Count + 5);
                    excelSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                    excelSheet.Columns.AutoFit();
                    excelSheet.Rows.AutoFit();
                    excelSheet.get_Range("C6", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                    excelSheet.Columns[2].ColumnWidth = 50;
                    excelSheet.Columns[2].WrapText = true;
                    excelSheet.Columns[6].ColumnWidth = 30;
                    excelSheet.Columns[6].WrapText = true;

                    Microsoft.Office.Interop.Excel.Range range = excelSheet.get_Range("H5", "M9999");
                    range.NumberFormat = "0.00";
                    Microsoft.Office.Interop.Excel.Range range1 = excelSheet.get_Range("O5", "P9999");
                    range1.NumberFormat = "0.00";
                    excelSheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;

                    Microsoft.Office.Interop.Excel.Range Range = excelSheet.get_Range("H6", "P99999");
                    Range.EntireColumn.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignRight;

                    excelSheet.Rows.RowHeight = "18";
                    int Print = dt.Rows.Count + 5;
                    excelSheet.PageSetup.PrintArea = "A1:R" + Print + "";
                    excelSheet.PageSetup.PrintTitleRows = "$1:$2";
                    excelSheet.PageSetup.PrintNotes = true;
                    excelSheet.PageSetup.Zoom = 55;
                    excelSheet.PageSetup.PrintGridlines = true;

                    excelSheet.PageSetup.LeftMargin = 0;
                    excelSheet.PageSetup.RightMargin = 0;
                    excelSheet.PageSetup.TopMargin = 0.75;
                    excelSheet.PageSetup.BottomMargin = 0.75;
                    excelSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                    excelSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
                    string _stLOGO = "C:\\Databasepath\\New_Biss_Logo.jpg";
                    Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[1, 5];
                    System.Drawing.Image oImage = System.Drawing.Image.FromFile(_stLOGO);
                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    excelSheet.Paste(oRange, _stLOGO);
                    Process.Start("C:\\Users\\Shivanand\\Documents\\Item Master");

                }
                else if (tablename == "ItemUsage")
                {
                    excelSheet.Name = "ItemUsage";
                    excelSheet.Cells[2, 2] = "ItemUsage Report"; excelSheet.Range["A2:C2"].Cells.Font.Size = 14; excelSheet.Range["A2:C2"].Cells.Font.Bold = 14;
                    Range r = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[1, 3];
                    r.EntireColumn.NumberFormat = "DD/MM/YYYY";

                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Bold = true;
                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Size = 12;
                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Color = Color.Blue;
                    excelRange = string.Format("A5:{0}{1}",
                    finalColLetter, dt.Rows.Count + 5);
                    excelSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                    excelSheet.Columns.AutoFit();
                    excelSheet.Rows.AutoFit();

                    excelSheet.get_Range("C6", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;

                    excelSheet.Columns[2].ColumnWidth = 50;
                    excelSheet.Columns[2].WrapText = true;
                    excelSheet.Columns[6].ColumnWidth = 12;
                    excelSheet.Columns[6].WrapText = true;

                    Microsoft.Office.Interop.Excel.Range range = excelSheet.get_Range("H5", "M9999");
                    range.NumberFormat = "0.00";

                    Microsoft.Office.Interop.Excel.Range range1 = excelSheet.get_Range("O5", "P9999");
                    range1.NumberFormat = "0.00";
                    Microsoft.Office.Interop.Excel.Range range15 = excelSheet.get_Range("S5", "T9999");
                    range15.NumberFormat = "0.00";
                    excelSheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;

                    Microsoft.Office.Interop.Excel.Range Range = excelSheet.get_Range("H6", "T99999");
                    Range.EntireColumn.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignRight;

                    excelSheet.Rows.RowHeight = "18";
                    int print = dt.Rows.Count + 5;
                    excelSheet.PageSetup.PrintArea = "A1:S" + print + "";
                    excelSheet.PageSetup.PrintTitleRows = "$1:$2";
                    excelSheet.PageSetup.PrintNotes = true;
                    excelSheet.PageSetup.Zoom = 55;
                    excelSheet.PageSetup.PrintGridlines = true;
                    //  ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[8, Type.Missing]).Font.Bold = true;
                    excelSheet.PageSetup.LeftMargin = 0;
                    excelSheet.PageSetup.RightMargin = 0;
                    excelSheet.PageSetup.TopMargin = 0.75;
                    excelSheet.PageSetup.BottomMargin = 0.75;
                    excelSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                    excelSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                    string _stLOGO = "C:\\Databasepath\\New_Biss_Logo.jpg";
                    Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[1, 6];
                    System.Drawing.Image oImage = System.Drawing.Image.FromFile(_stLOGO);
                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    excelSheet.Paste(oRange, _stLOGO);
                    Process.Start("C:\\Users\\Shivanand\\Documents\\Item Usage");
                }


                else if (tablename == "Vendors")
                {
                    excelSheet.Cells[2, 2] = "Vendor List"; excelSheet.Range["A2:C2"].Cells.Font.Size = 14; excelSheet.Range["A2:C2"].Cells.Font.Bold = 14;
                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Bold = true;
                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Size = 12;
                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Color = Color.Blue;
                    string rangeex = string.Format("A1:{0}{1}",
                    finalColLetter, dt.Rows.Count + 1);
                    excelRange = string.Format("A5:{0}{1}",
                    finalColLetter, dt.Rows.Count + 8);
                    excelSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                    excelSheet.Columns.AutoFit();
                    excelSheet.Rows.AutoFit();

                    excelSheet.get_Range("C6", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;

                    excelSheet.Columns[2].ColumnWidth = 50;
                    excelSheet.Columns[2].WrapText = true;
                    excelSheet.Columns[4].ColumnWidth = 40;
                    excelSheet.Columns[4].WrapText = true;
                    excelSheet.Columns[5].ColumnWidth = 40;
                    excelSheet.Columns[5].WrapText = true;
                    excelSheet.Columns[6].ColumnWidth = 40;
                    excelSheet.Columns[6].WrapText = true;
                    excelSheet.Rows.RowHeight = "18";
                    excelSheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                    int print = dt.Rows.Count + 5;
                    excelSheet.PageSetup.PrintArea = "A1:S" + print + "";
                    excelSheet.PageSetup.PrintTitleRows = "$1:$2";
                    excelSheet.PageSetup.PrintNotes = true;
                    excelSheet.PageSetup.Zoom = 55;
                    excelSheet.PageSetup.PrintGridlines = true;

                    excelSheet.PageSetup.LeftMargin = 0;
                    excelSheet.PageSetup.RightMargin = 0;
                    excelSheet.PageSetup.TopMargin = 0.75;
                    excelSheet.PageSetup.BottomMargin = 0.75;
                    excelSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                    excelSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
                    string _stLOGO = "C:\\Databasepath\\New_Biss_Logo.jpg";
                    Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[1, 14];
                    System.Drawing.Image oImage = System.Drawing.Image.FromFile(_stLOGO);
                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    excelSheet.Paste(oRange, _stLOGO);
                    Process.Start("C:\\Users\\Shivanand\\Documents\\Vendors");
                }
                else if (tablename == "Issued")
                {
                    Range r = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[1, 5];
                    r.EntireColumn.NumberFormat = "000";
                    Range date = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[1, 7];
                    date.EntireColumn.NumberFormat = "DD/MM/YYYY";
                    excelSheet.Cells[2, 3] = "Issued Report"; excelSheet.Range["A2:C2"].Cells.Font.Size = 14; excelSheet.Range["A2:C2"].Cells.Font.Bold = 14;
                    excelRange = string.Format("A4:{0}{1}",
                   finalColLetter, dt.Rows.Count + 4);
                    excelSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                    ((Range)excelSheet.Rows[4, Type.Missing]).Font.Bold = true;
                    excelSheet.Columns.AutoFit(); excelSheet.Rows.AutoFit();
                    Process.Start("C:\\Users\\Shivanand\\Documents\\Issued");
                }
             
                else if (tablename == "Receipt")
                {
                    excelSheet.Name = "Receipt Report";
                    Range r = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[1, 9];
                    r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                    excelSheet.Cells[3, 1] = "Receipt Report"; excelSheet.Range["A1:C3"].Cells.Font.Size = 14; excelSheet.Range["A1:C3"].Cells.Font.Bold = true;
                    excelSheet.get_Range("A1", "C3").Merge(true);
                    excelRange = string.Format("A5:{0}{1}",
                   finalColLetter, dt.Rows.Count + 5);
                    excelSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Bold = true;
                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Color = Color.Blue;
                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Size = 12;

                    excelSheet.Columns.AutoFit();
                    excelSheet.Rows.AutoFit();
                    excelSheet.get_Range("C6", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                    excelSheet.Columns[3].ColumnWidth = 50;
                    excelSheet.Columns[3].WrapText = true;
                    excelSheet.Columns[8].ColumnWidth = 45;
                    excelSheet.Columns[8].WrapText = true;

                    excelSheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    Microsoft.Office.Interop.Excel.Range Range = excelSheet.get_Range("E6", "G99999");
                    Range.EntireColumn.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignRight;

                    excelSheet.Rows.RowHeight = "18";
                    int Print = dt.Rows.Count + 5;
                    excelSheet.PageSetup.PrintArea = "A1:L" + Print + "";
                    excelSheet.PageSetup.PrintTitleRows = "$1:$2";
                    excelSheet.PageSetup.PrintNotes = true;
                    excelSheet.PageSetup.Zoom = 65;
                    excelSheet.PageSetup.PrintGridlines = true;

                    excelSheet.PageSetup.LeftMargin = 0;
                    excelSheet.PageSetup.RightMargin = 0;
                    excelSheet.PageSetup.TopMargin = 0.75;
                    excelSheet.PageSetup.BottomMargin = 0.75;
                    excelSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                    excelSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;


                    string _stLOGO = "C:\\Databasepath\\New_Biss_Logo.jpg";
                    Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[1, 4];
                    System.Drawing.Image oImage = System.Drawing.Image.FromFile(_stLOGO);
                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    excelSheet.Paste(oRange, _stLOGO);
                    Process.Start("C:\\Users\\Shivanand\\Documents\\Receipt");
                }

                else if (tablename == "Job Issued")
                {
                    Range r = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[1, 1];
                    r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                    Range r2 = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[8, 11];
                    r2.EntireColumn.NumberFormat = "0.00";
                    Range r3 = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[16, 18];
                    r3.EntireColumn.NumberFormat = "0.00";
                    excelSheet.Cells[2, 2] = "Job Issued"; excelSheet.Range["A2:C2"].Cells.Font.Size = 14; excelSheet.Range["A2:C2"].Cells.Font.Bold = 14;
                    excelRange = string.Format("A8:{0}{1}",
                   finalColLetter, dt.Rows.Count + 8);
                    excelSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                    ((Range)excelSheet.Rows[8, Type.Missing]).Font.Bold = true;
                    ((Range)excelSheet.Rows[8, Type.Missing]).Font.Color = Color.Blue;
                    excelSheet.Columns.AutoFit();
                    excelSheet.Rows.AutoFit();

                    excelSheet.Columns[7].ColumnWidth = 50;
                    excelSheet.Columns[7].WrapText = true;

                    excelSheet.Columns[15].ColumnWidth = 50;
                    excelSheet.Columns[15].WrapText = true;

                    excelSheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                    excelSheet.Rows.RowHeight = "18";

                    int print = dt.Rows.Count + 5;
                    excelSheet.PageSetup.PrintArea = "A1:L" + print + "";
                    excelSheet.PageSetup.PrintTitleRows = "$1:$2";
                    excelSheet.PageSetup.PrintNotes = true;
                    excelSheet.PageSetup.Zoom = 65;
                    excelSheet.PageSetup.PrintGridlines = true;

                    excelSheet.PageSetup.LeftMargin = 0;
                    excelSheet.PageSetup.RightMargin = 0;
                    excelSheet.PageSetup.TopMargin = 0.75;
                    excelSheet.PageSetup.BottomMargin = 0.75;
                    excelSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                    excelSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;


                    string _stLOGO = "C:\\Databasepath\\New_Biss_Logo.jpg";
                    Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[1, 4];
                    System.Drawing.Image oImage = System.Drawing.Image.FromFile(_stLOGO);
                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    excelSheet.Paste(oRange, _stLOGO);
                    Process.Start("C:\\Users\\Shivanand\\Documents\\Job Issued");
                }
                else if (tablename == "Job In Progress")
                {
                    Range r = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[1, 10];
                    r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                    //Range r2 = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[8, 11];
                    //r2.EntireColumn.NumberFormat = "0.00";
                    //Range r3 = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[16, 18];
                    //r3.EntireColumn.NumberFormat = "0.00";
                    excelSheet.Cells[2, 2] = "Job In Progress"; excelSheet.Range["A2:C2"].Cells.Font.Size = 14; excelSheet.Range["A2:C2"].Cells.Font.Bold = 14;
                    excelRange = string.Format("A8:{0}{1}",
                   finalColLetter, dt.Rows.Count + 8);
                    excelSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                    ((Range)excelSheet.Rows[8, Type.Missing]).Font.Bold = true;
                    ((Range)excelSheet.Rows[8, Type.Missing]).Font.Color = Color.Blue;
                    excelSheet.Columns.AutoFit();
                    excelSheet.Rows.AutoFit();

                    excelSheet.Columns[4].ColumnWidth = 50;
                    excelSheet.Columns[4].WrapText = true;


                    excelSheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                    excelSheet.Rows.RowHeight = "18";

                    int print = dt.Rows.Count + 5;
                    excelSheet.PageSetup.PrintArea = "A1:L" + print + "";
                    excelSheet.PageSetup.PrintTitleRows = "$1:$2";
                    excelSheet.PageSetup.PrintNotes = true;
                    excelSheet.PageSetup.Zoom = 65;
                    excelSheet.PageSetup.PrintGridlines = true;

                    excelSheet.PageSetup.LeftMargin = 0;
                    excelSheet.PageSetup.RightMargin = 0;
                    excelSheet.PageSetup.TopMargin = 0.75;
                    excelSheet.PageSetup.BottomMargin = 0.75;
                    excelSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                    excelSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;


                    string _stLOGO = "C:\\Databasepath\\New_Biss_Logo.jpg";
                    Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[1, 4];
                    System.Drawing.Image oImage = System.Drawing.Image.FromFile(_stLOGO);
                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    excelSheet.Paste(oRange, _stLOGO);
                    Process.Start("C:\\Users\\Shivanand\\Documents\\Job In Progress");
                }
                //

                else if (tablename == "Stock Adjusted")
                {
                    Range r = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[1, 9];
                    r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                    excelSheet.Cells[2, 2] = "Stock Adjusted"; excelSheet.Range["A2:C2"].Cells.Font.Size = 14; excelSheet.Range["A2:C2"].Cells.Font.Bold = 14;
                    excelRange = string.Format("A5:{0}{1}",
                   finalColLetter, dt.Rows.Count + 5);
                    excelSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Bold = true;
                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Color = Color.Blue;
                    excelSheet.Columns.AutoFit();
                    excelSheet.Rows.AutoFit();

                    excelSheet.Columns[3].ColumnWidth = 50;
                    excelSheet.Columns[3].WrapText = true;
                    excelSheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                    excelSheet.Rows.RowHeight = "18";

                    int print = dt.Rows.Count + 5;
                    excelSheet.PageSetup.PrintArea = "A1:L" + print + "";
                    excelSheet.PageSetup.PrintTitleRows = "$1:$2";
                    excelSheet.PageSetup.PrintNotes = true;
                    excelSheet.PageSetup.Zoom = 65;
                    excelSheet.PageSetup.PrintGridlines = true;

                    excelSheet.PageSetup.LeftMargin = 0;
                    excelSheet.PageSetup.RightMargin = 0;
                    excelSheet.PageSetup.TopMargin = 0.75;
                    excelSheet.PageSetup.BottomMargin = 0.75;
                    excelSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                    excelSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;


                    string _stLOGO = "C:\\Databasepath\\New_Biss_Logo.jpg";
                    Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[1, 4];
                    System.Drawing.Image oImage = System.Drawing.Image.FromFile(_stLOGO);
                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    excelSheet.Paste(oRange, _stLOGO);
                    Process.Start("C:\\Users\\Shivanand\\Documents\\Stock Adjusted");
                }

                else if (tablename == "PurchaseCost")
                {
                    excelSheet.Name = "Purchase Cost";
                    Range r = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[1, 2];
                    r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                    excelSheet.Cells[2, 1] = "Purchase Cost Report"; excelSheet.Range["A2:B3"].Cells.Font.Color = Color.Blue; excelSheet.Range["A2:B3"].Cells.Font.Bold = 14;
                    excelSheet.get_Range("A2", "C2").Merge(true);
                    excelRange = string.Format("A5:{0}{1}",
                    finalColLetter, dt.Rows.Count + 5);
                    excelSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;

                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Bold = true;
                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Color = Color.Blue;
                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Size = 12;

                    excelSheet.Columns.AutoFit();
                    excelSheet.Rows.AutoFit();
                    excelSheet.get_Range("C6", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                    excelSheet.Columns[4].ColumnWidth = 50;
                    excelSheet.Columns[4].WrapText = true;

                    excelSheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                    excelSheet.Rows.RowHeight = "18";
                    Microsoft.Office.Interop.Excel.Range range = excelSheet.get_Range("E6", "G9999");
                    range.NumberFormat = "0.00";
                    int Print = dt.Rows.Count + 8;
                    excelSheet.PageSetup.PrintArea = "A1:G" + Print + "";
                    excelSheet.PageSetup.PrintTitleRows = "$1:$2";
                    excelSheet.PageSetup.PrintNotes = true;
                    excelSheet.PageSetup.Zoom = 65;
                    excelSheet.PageSetup.PrintGridlines = true;

                    excelSheet.PageSetup.LeftMargin = 0;
                    excelSheet.PageSetup.RightMargin = 0;
                    excelSheet.PageSetup.TopMargin = 0.75;
                    excelSheet.PageSetup.BottomMargin = 0.75;
                    excelSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                    excelSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;


                    string _stLOGO = "C:\\Databasepath\\New_Biss_Logo.jpg";
                    Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[1, 5];
                    System.Drawing.Image oImage = System.Drawing.Image.FromFile(_stLOGO);
                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    excelSheet.Paste(oRange, _stLOGO);
                    Process.Start("C:\\Users\\Shivanand\\Documents\\Purchase Cost");
                }
                else if (tablename == "Transactionalspenddata")
                {
                    excelSheet.Name = "Transactional Spend Data";
                    Range r = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[3, 3];
                    r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                    excelSheet.Cells[2, 1] = "Transactional spend data Report"; excelSheet.Range["A2:B3"].Cells.Font.Color = Color.Blue; excelSheet.Range["A2:B3"].Cells.Font.Bold = 14;
                    excelSheet.get_Range("A2", "C2").Merge(true);
                    excelSheet.Cells[3, 1] = "Date : " + DateTime.Today.ToString("dd-MM-yyyy") + ""; excelSheet.Range["A3:B3"].Cells.Font.Size = 12; excelSheet.Range["A3:B3"].Cells.Font.Bold = true;
                    excelSheet.get_Range("A3", "C3").Merge(true);

                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Bold = true;
                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Color = Color.Blue;
                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Size = 12;

                    excelRange = string.Format("A5:{0}{1}",
                    finalColLetter, dt.Rows.Count + 5);
                    excelSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;

                    excelSheet.Columns.AutoFit();
                    excelSheet.Rows.AutoFit();

                    excelSheet.get_Range("C6", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;

                    excelSheet.Columns[5].ColumnWidth = 32;
                    excelSheet.Columns[5].WrapText = true;
                    excelSheet.Columns[6].ColumnWidth = 46;
                    excelSheet.Columns[6].WrapText = true;
                    excelSheet.Columns[7].ColumnWidth = 50;
                    excelSheet.Columns[7].WrapText = true;
                    excelSheet.Columns[8].ColumnWidth = 34;
                    excelSheet.Columns[8].WrapText = true;
                    excelSheet.Columns[18].ColumnWidth = 50;
                    excelSheet.Columns[18].WrapText = true;

                    excelSheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                    excelSheet.Rows.RowHeight = "18";
                    Microsoft.Office.Interop.Excel.Range range = excelSheet.get_Range("L6", "O9999");
                    range.NumberFormat = "0.00";
                    int Print = dt.Rows.Count + 5;
                    excelSheet.PageSetup.PrintArea = "A1:G" + Print + "";
                    excelSheet.PageSetup.PrintTitleRows = "$1:$2";
                    excelSheet.PageSetup.PrintNotes = true;
                    excelSheet.PageSetup.Zoom = 65;
                    excelSheet.PageSetup.PrintGridlines = true;

                    excelSheet.PageSetup.LeftMargin = 0;
                    excelSheet.PageSetup.RightMargin = 0;
                    excelSheet.PageSetup.TopMargin = 0.75;
                    excelSheet.PageSetup.BottomMargin = 0.75;
                    excelSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                    excelSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;


                    string _stLOGO = "C:\\Databasepath\\New_Biss_Logo.jpg";
                    Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[1, 4];
                    System.Drawing.Image oImage = System.Drawing.Image.FromFile(_stLOGO);
                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    excelSheet.Paste(oRange, _stLOGO);
                    Process.Start("C:\\Users\\Shivanand\\Documents\\Transactional Spend Data");
                }
                else if (tablename == "ApSpenddata")
                {
                    excelSheet.Name = "Ap Spend Data";
                    //Range r = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[3, 3];
                    //r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                    excelSheet.Cells[2, 1] = "Ap spend data Report"; excelSheet.Range["A2:B3"].Cells.Font.Color = Color.Blue; excelSheet.Range["A2:B3"].Cells.Font.Bold = 14;
                    excelSheet.get_Range("A2", "C2").Merge(true);
                    excelSheet.Cells[3, 1] = "Date : " + DateTime.Today.ToString("dd-MM-yyyy") + ""; excelSheet.Range["A3:B3"].Cells.Font.Size = 12; excelSheet.Range["A3:B3"].Cells.Font.Bold = true;
                    excelSheet.get_Range("A3", "C3").Merge(true);
                    //string rangeex = string.Format("A1:{0}{1}",
                    // finalColLetter, dt.Rows.Count + 1);
                    excelRange = string.Format("A5:{0}{1}",
                   finalColLetter, dt.Rows.Count + 5);
                    excelSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;

                    excelSheet.Columns.AutoFit();
                    excelSheet.Rows.AutoFit();
                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Bold = true;
                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Color = Color.Blue;
                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Size = 12;


                    excelSheet.get_Range("C6", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;

                    excelSheet.Columns[3].ColumnWidth = 50;
                    excelSheet.Columns[3].WrapText = true;
                    excelSheet.Columns[4].ColumnWidth = 48;
                    excelSheet.Columns[4].WrapText = true;
                    excelSheet.Columns[5].ColumnWidth = 50;
                    excelSheet.Columns[5].WrapText = true;
                    excelSheet.Columns[6].ColumnWidth = 34;
                    excelSheet.Columns[6].WrapText = true;

                    excelSheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                    excelSheet.Rows.RowHeight = "18";
                    Microsoft.Office.Interop.Excel.Range range = excelSheet.get_Range("K6", "K9999");
                    range.NumberFormat = "0.00";
                    int Print = dt.Rows.Count + 5;
                    excelSheet.PageSetup.PrintArea = "A1:G" + Print + "";
                    excelSheet.PageSetup.PrintTitleRows = "$1:$2";
                    excelSheet.PageSetup.PrintNotes = true;
                    excelSheet.PageSetup.Zoom = 65;
                    excelSheet.PageSetup.PrintGridlines = true;

                    excelSheet.PageSetup.LeftMargin = 0;
                    excelSheet.PageSetup.RightMargin = 0;
                    excelSheet.PageSetup.TopMargin = 0.75;
                    excelSheet.PageSetup.BottomMargin = 0.75;
                    excelSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                    excelSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;


                    string _stLOGO = "C:\\Databasepath\\New_Biss_Logo.jpg";
                    Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[1, 4];
                    System.Drawing.Image oImage = System.Drawing.Image.FromFile(_stLOGO);
                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    excelSheet.Paste(oRange, _stLOGO);
                    Process.Start("C:\\Users\\Shivanand\\Documents\\AP Spend Data");
                }
                else if (tablename == "ProjectList")
                {
                    excelSheet.Name = "ProjectList";

                    excelSheet.Cells[2, 1] = "ProjectList"; excelSheet.Range["A2:B3"].Cells.Font.Color = Color.Blue; excelSheet.Range["A2:B3"].Cells.Font.Size = 14; excelSheet.Range["A2:B3"].Cells.Font.Bold = 14;
                    excelSheet.get_Range("A2", "C2").Merge(true);
                    excelSheet.Cells[3, 1] = "Date : " + DateTime.Today.ToString("dd-MM-yyyy") + ""; excelSheet.Range["A3:B3"].Cells.Font.Size = 12; excelSheet.Range["A3:B3"].Cells.Font.Bold = true;
                    excelSheet.get_Range("A3", "C3").Merge(true);
                    excelRange = string.Format("A5:{0}{1}",
                    finalColLetter, dt.Rows.Count + 5);
                    excelSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;

                    excelSheet.Columns.AutoFit();
                    excelSheet.Rows.AutoFit();
                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Bold = true;
                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Color = Color.Blue;
                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Size = 12;


                    excelSheet.get_Range("C6", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;

                    excelSheet.Columns[2].ColumnWidth = 50;
                    excelSheet.Columns[2].WrapText = true;
                    excelSheet.Columns[4].ColumnWidth = 48;
                    excelSheet.Columns[4].WrapText = true;
                    excelSheet.Columns[9].ColumnWidth = 50;
                    excelSheet.Columns[9].WrapText = true;

                    excelSheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                    excelSheet.Rows.RowHeight = "18";
                    Microsoft.Office.Interop.Excel.Range range1 = excelSheet.get_Range("A6", "A9999");
                    range1.NumberFormat = "0";
                    Microsoft.Office.Interop.Excel.Range range = excelSheet.get_Range("E6", "H9999");
                    range.NumberFormat = "DD/MM/YYYY";
                    int Print = dt.Rows.Count + 5;
                    excelSheet.PageSetup.PrintArea = "A1:G" + Print + "";
                    excelSheet.PageSetup.PrintTitleRows = "$1:$2";
                    excelSheet.PageSetup.PrintNotes = true;
                    excelSheet.PageSetup.Zoom = 65;
                    excelSheet.PageSetup.PrintGridlines = true;

                    excelSheet.PageSetup.LeftMargin = 0;
                    excelSheet.PageSetup.RightMargin = 0;
                    excelSheet.PageSetup.TopMargin = 0.75;
                    excelSheet.PageSetup.BottomMargin = 0.75;
                    excelSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                    excelSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                    string _stLOGO = "C:\\Databasepath\\New_Biss_Logo.jpg";
                    Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[1, 4];
                    System.Drawing.Image oImage = System.Drawing.Image.FromFile(_stLOGO);
                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    excelSheet.Paste(oRange, _stLOGO);
                    Process.Start("C:\\Users\\Shivanand\\Documents\\Project List");
                }
                else if (tablename == "StandarCostPO")
                {
                    excelSheet.Name = "Standar Cost PO";
                    Range r = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[1, 3];
                    r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                    excelSheet.Cells[2, 1] = "Standar Cost PO"; excelSheet.Range["A2:B3"].Cells.Font.Color = Color.Blue; excelSheet.Range["A2:B3"].Cells.Font.Bold = 14;
                    excelSheet.get_Range("A2", "C2").Merge(true);
                    excelRange = string.Format("A5:{0}{1}",
                    finalColLetter, dt.Rows.Count + 5);
                    excelSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;

                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Bold = true;
                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Color = Color.Blue;
                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Size = 12;

                    excelSheet.Columns.AutoFit();
                    excelSheet.Rows.AutoFit();
                    excelSheet.get_Range("C6", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                    excelSheet.Columns[5].ColumnWidth = 50;
                    excelSheet.Columns[5].WrapText = true;

                    excelSheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                    excelSheet.Rows.RowHeight = "18";
                    Microsoft.Office.Interop.Excel.Range range = excelSheet.get_Range("E6", "G9999");
                    range.NumberFormat = "0.00";
                    int Print = dt.Rows.Count + 8;
                    excelSheet.PageSetup.PrintArea = "A1:G" + Print + "";
                    excelSheet.PageSetup.PrintTitleRows = "$1:$2";
                    excelSheet.PageSetup.PrintNotes = true;
                    excelSheet.PageSetup.Zoom = 65;
                    excelSheet.PageSetup.PrintGridlines = true;

                    excelSheet.PageSetup.LeftMargin = 0;
                    excelSheet.PageSetup.RightMargin = 0;
                    excelSheet.PageSetup.TopMargin = 0.75;
                    excelSheet.PageSetup.BottomMargin = 0.75;
                    excelSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                    excelSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;


                    string _stLOGO = "C:\\Databasepath\\New_Biss_Logo.jpg";
                    Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[1, 5];
                    System.Drawing.Image oImage = System.Drawing.Image.FromFile(_stLOGO);
                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    excelSheet.Paste(oRange, _stLOGO);
                    Process.Start("C:\\Users\\Shivanand\\Documents\\Standard Cost PO");
                }
                else if (tablename == "StandarCostWO")
                {
                    excelSheet.Name = "Standar Cost WO";
                    Range r = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[1, 3];
                    r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                    excelSheet.Cells[2, 1] = "Standar Cost WO"; excelSheet.Range["A2:B3"].Cells.Font.Color = Color.Blue; excelSheet.Range["A2:B3"].Cells.Font.Bold = 14;
                    excelSheet.get_Range("A2", "C2").Merge(true);
                    excelRange = string.Format("A5:{0}{1}",
                    finalColLetter, dt.Rows.Count + 5);
                    excelSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;

                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Bold = true;
                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Color = Color.Blue;
                    ((Range)excelSheet.Rows[5, Type.Missing]).Font.Size = 12;

                    excelSheet.Columns.AutoFit();
                    excelSheet.Rows.AutoFit();
                    excelSheet.get_Range("C6", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                    excelSheet.Columns[5].ColumnWidth = 60;
                    excelSheet.Columns[5].WrapText = true;

                    excelSheet.get_Range("C6", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                    excelSheet.Rows.RowHeight = "18";
                    Microsoft.Office.Interop.Excel.Range range = excelSheet.get_Range("E6", "G9999");
                    range.NumberFormat = "0.00";
                    int Print = dt.Rows.Count + 8;
                    excelSheet.PageSetup.PrintArea = "A1:G" + Print + "";
                    excelSheet.PageSetup.PrintTitleRows = "$1:$2";
                    excelSheet.PageSetup.PrintNotes = true;
                    excelSheet.PageSetup.Zoom = 65;
                    excelSheet.PageSetup.PrintGridlines = true;

                    excelSheet.PageSetup.LeftMargin = 0;
                    excelSheet.PageSetup.RightMargin = 0;
                    excelSheet.PageSetup.TopMargin = 0.75;
                    excelSheet.PageSetup.BottomMargin = 0.75;
                    excelSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                    excelSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;


                    string _stLOGO = "C:\\Databasepath\\New_Biss_Logo.jpg";
                    Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)excelSheet.Cells[1, 5];
                    System.Drawing.Image oImage = System.Drawing.Image.FromFile(_stLOGO);
                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    excelSheet.Paste(oRange, _stLOGO);
                    Process.Start("C:\\Users\\Shivanand\\Documents\\Standard Cost WO");
                }
            }

            //  Save and Close the Workbook
            excelWorkbook.SaveAs(string.Concat(outputPath), XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                Type.Missing, Type.Missing, Type.Missing, XlSaveAsAccessMode.xlExclusive,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

            excelWorkbook.Save();
            excelWorkbook.Close(true, Type.Missing, Type.Missing);
            excelApp.Quit();

            releaseObject(excelSheet);
            releaseObject(excelWorkbook);
            releaseObject(excelApp);
        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
    }
}
