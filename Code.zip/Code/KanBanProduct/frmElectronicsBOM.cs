﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Diagnostics;

namespace Erp_Project_With_Buttons.KanBanProduct
{
    public partial class frmElectronicsBOM : Form
    {
        public frmElectronicsBOM()
        {
            InitializeComponent();
        }
        frmForm2 Home = new frmForm2();
        DataAccessLayer DAL = new DataAccessLayer();
        Global GLobalClass = new Global();
        Login.frmLoginForm LoginForm = new Login.frmLoginForm();
        TreeNode tnCurrentParentNode = new TreeNode();
        DataTable dtTreeFromTable = new DataTable();

        private void frmElectronicsBOM_Load(object sender, EventArgs e)
        {
            dtTreeFromTable = DAL.fnGetKBELProductTreeView().Tables[0]; //get the tree folders and sub-folders from database 
            tvProduct.Nodes.AddRange(GLobalClass.fnTreeFromTable(dtTreeFromTable, "ParentID", "NodeID", "ProductName", "ImageIndex")); // display the folders in the treeview
            tnCurrentParentNode = null;
            tvProduct.Sort();
            chkItemCode.Checked = true;
            chkProductIssue.Checked = true;
        }

        private void frmElectronicsBOM_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnExit();
        }

        private void fnExit()
        {
            this.Hide();
            Home.Show();
        }

        private void txtName_Leave(object sender, EventArgs e)
        {
            if (txtName.Text.Length == 0)
            {
                txtName.Text = "Enter Name";
                txtName.ForeColor = SystemColors.GrayText;
            }
        }

        private void txtName_Enter(object sender, EventArgs e)
        {
            if (txtName.Text == "Enter Name")
            {
                txtName.Text = "";
                txtName.ForeColor = SystemColors.WindowText;
            }
        }

        private void btnAddFolder_Click(object sender, EventArgs e)
        {
            txtName.Visible = true;
            btnQuoteTreeSave.Visible = true;
            btnQuoteTreeSave.Enabled = true;
            txtName.ForeColor = SystemColors.GrayText;
            // txtName.Text = "Enter Name";
            txtName.Leave += new System.EventHandler(txtName_Leave);
            txtName.Enter += new System.EventHandler(txtName_Enter);
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            txtName.Visible = false;
            btnQuoteTreeSave.Visible = false;
            txtProductName.ResetText();
            txtProductCode.ResetText();
            txtProductName.ResetText();
            txtProductCost.ResetText();
            btnUpdateProduct.Text = "Save";
            pnProductcode.Enabled = true;
        }
        DataTable SalesProductMaster = new DataTable();
        string sNName;
        DataTable dtNodeID = new DataTable();
        int iLastNodeID;
        string[] sName;
        string[] sParentName;

        private void btnQuoteTreeSave_Click(object sender, EventArgs e)
        {
            if (btnQuoteTreeSave.Text == "Save")
            {
                if (txtName.Text != "Enter Name")
                {
                    dtNodeID = DAL.fnGetElectronicsProductLastNodeId(null).Tables[0];
                    if (dtNodeID.Rows.Count > 0)
                    {
                        iLastNodeID = Convert.ToInt32(dtNodeID.Rows[0]["NodeID"].ToString());
                        iLastNodeID++;
                    }
                    sName = tvProduct.SelectedNode.Name.Split(')');
                    GLobalClass.iSuccess = DAL.fnAddElectronicsProductName(Global.uINSERT, Convert.ToInt32(sName[0]), iLastNodeID, txtName.Text, "0", LoginForm.GetUserDetails[2], LoginForm.GetUserDetails[2], "", "", "", "");

                    MessageBox.Show("Folder '" + txtName.Text + "'  Created Successfully.", "Success", 0, MessageBoxIcon.Information);

                    TreeNode TN = new TreeNode();
                    tvProduct.BeginUpdate();
                    TN.Name = iLastNodeID + ") " + txtName.Text;
                    TN.Text = iLastNodeID + ") " + txtName.Text;
                    TN.ForeColor = Color.Black;
                    TN.StateImageIndex = 0;
                    tvProduct.SelectedNode.Nodes.Add(TN);
                    tvProduct.EndUpdate();
                    btnQuoteTreeSave.Enabled = false;
                    txtName.Visible = false;
                }
                else
                {
                    MessageBox.Show("Enter a folder name to save.", "Error", 0, MessageBoxIcon.Error);
                    txtName.Focus();
                }
            }
            else if (btnQuoteTreeSave.Text == "Rename")
            {
                if (txtName.Text != "Enter Name")
                {
                    GLobalClass.iSuccess = DAL.fnAddElectronicsProductName(7, Convert.ToInt32(sName[0]), iLastNodeID, txtName.Text, "0", LoginForm.GetUserDetails[2], LoginForm.GetUserDetails[2], "", "", "", "");

                    MessageBox.Show("Folder renamed to '" + txtName.Text + "' successfully.", "Success", 0, MessageBoxIcon.Information);

                    tvProduct.BeginUpdate();
                    tvProduct.SelectedNode.Name = sName[0] + ")" + txtName.Text;
                    tvProduct.SelectedNode.Text = sName[0] + ")" + txtName.Text;
                    tvProduct.SelectedNode.StateImageIndex = 0;
                    tvProduct.EndUpdate();

                    btnQuoteTreeSave.Text = "Save";
                    btnQuoteTreeSave.Enabled = false;
                    txtName.Visible = false;
                }
                else
                {
                    MessageBox.Show("Enter a folder name to save.", "Error", 0, MessageBoxIcon.Error);
                    txtName.Focus();
                }
            }
        }
        DataTable dtProductCodeCheck = new DataTable();
        DataTable dtNewProductCodeCheck = new DataTable();
        private void btnUpdateProduct_Click(object sender, EventArgs e)
        {
            if (btnUpdateProduct.Text == "Save")
            {
                dtNewProductCodeCheck = DAL.fnElectronicsProductCodeCheck(txtProductCode.Text).Tables[0];
                if (dtNewProductCodeCheck.Rows.Count == 0)
                {
                    fnUpadateTreeDetails(Global.uINSERT);
                }
                else
                {
                    MessageBox.Show("Entered new product code alreday used for product '" + dtNewProductCodeCheck.Rows[0]["Name"].ToString() + "'. Please enter a unique product code.", "Information", 0, MessageBoxIcon.Warning);
                }
            }

            else if (btnUpdateProduct.Text == "Update")
            {
                dtProductCodeCheck = DAL.fnGetPasteElectronicsProductTreeNode(0, sName[0].ToString()).Tables[0];
                dtNewProductCodeCheck = DAL.fnElectronicsProductCodeCheck(dtProductCodeCheck.Rows[0]["ProductCode"].ToString().Trim()).Tables[0];
                if (dtProductCodeCheck.Rows.Count < 2)
                {
                    if (dtProductCodeCheck.Rows[0]["ProductCode"].ToString().Trim() != txtProductCode.Text.Trim())
                    {
                        dtNewProductCodeCheck = DAL.fnElectronicsProductCodeCheck(txtProductCode.Text).Tables[0];
                        if (dtNewProductCodeCheck.Rows.Count == 0)
                        {
                            fnUpadateTreeDetails(Global.uUPDATE);
                        }
                        else
                        {
                            MessageBox.Show("Entered new product code alreday used for product '" + dtNewProductCodeCheck.Rows[0]["Name"].ToString() + "'. Please enter a unique product code.", "Information", 0, MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        fnUpadateTreeDetails(Global.uUPDATE);
                    }
                }
                else
                {
                    MessageBox.Show("Selected Product has duplicate product code. Please contact the admin.", "Information", 0, MessageBoxIcon.Warning);
                }
            }
        }

        int NodeID;
        int PasteParentID;
        int PasteImageIndex;
        DataTable dtParentAndNodeID = new DataTable();
        int iCurrentParentID;
        DataTable dtChildProdcut = new DataTable();
        string sTreeParentName = string.Empty;
        string sTreeChildName = string.Empty;
        string sPasteTreeParentName = string.Empty;
        string sPasteTreeChildName = string.Empty;

        private void fnUpadateTreeDetails(uint SaveorUpdate)
        {
            if (SaveorUpdate == Global.uINSERT)
            {
                dtParentAndNodeID = DAL.fnGetCopyElectronicsFolderNodeId(null).Tables[0];
                if (dtParentAndNodeID.Rows.Count > 0)
                {
                    iLastNodeID = Convert.ToInt32(dtParentAndNodeID.Rows[0]["NodeID"].ToString());
                    iLastNodeID++;
                }
                if (iLastNodeID != 0)
                {
                    GLobalClass.iSuccess = DAL.fnAddElectronicsProductName(SaveorUpdate, Convert.ToInt32(sName[0]), iLastNodeID, txtProductName.Text,
                        "2", LoginForm.GetUserDetails[2], LoginForm.GetUserDetails[2], txtProductCode.Text, "", txtProductCost.Text, "");
                }

                MessageBox.Show("Product successfully saved.", "Information", 0, MessageBoxIcon.Information);
                TreeNode TN = new TreeNode();
                tvProduct.BeginUpdate();
                TN.Name = iLastNodeID + ")" + txtProductName.Text.Trim(); ;
                TN.Text = iLastNodeID + ")" + txtProductName.Text.Trim(); ;
                TN.ForeColor = Color.Black;
                TN.StateImageIndex = 2;
                tvProduct.SelectedNode.Nodes.Add(TN);
                tvProduct.EndUpdate();
            }

            else if (SaveorUpdate == Global.uUPDATE)
            {
                GLobalClass.iSuccess = DAL.fnAddElectronicsProductName(SaveorUpdate, 0, Convert.ToInt32(sName[0]), txtProductName.Text, "1", "", "", txtProductCode.Text,
                    "", txtProductCost.Text, "");
                tvProduct.BeginUpdate();
                tvProduct.SelectedNode.Name = sName[0] + ")" + txtProductName.Text.Trim();
                tvProduct.SelectedNode.Text = sName[0] + ")" + txtProductName.Text.Trim();
                if (tvProduct.SelectedNode.StateImageIndex == 2)
                {
                    tvProduct.SelectedNode.StateImageIndex = 2;
                }
                else
                {
                    tvProduct.SelectedNode.StateImageIndex = 3;
                }
                tvProduct.EndUpdate();
                MessageBox.Show("Product successfully updated.", "Information", 0, MessageBoxIcon.Information);
            }
        }

        private List<TreeNode> CurrentNodeMatches = new List<TreeNode>();
        private int LastNodeIndex = 0;
        private string LastSearchText;
        DataTable dtProductCodeSearch = new DataTable();

        private void SearchNodes(string SearchText, TreeNode StartNode)
        {
            while (StartNode != null)
            {
                if (StartNode.Text.ToLower().Contains(SearchText.ToLower()))
                {
                    CurrentNodeMatches.Add(StartNode);
                };
                if (StartNode.Nodes.Count != 0)
                {
                    SearchNodes(SearchText, StartNode.Nodes[0]);//Recursive Search 
                };
                StartNode = StartNode.NextNode;
            };
        }

        private void btnsearchtree_Click(object sender, EventArgs e)
        {
            string searchText = this.txtsearchtree.Text;
            if (String.IsNullOrEmpty(searchText))
            {
                return;
            };

            if (LastSearchText != searchText)
            {
                //It's a new Search
                CurrentNodeMatches.Clear();
                if (chkProductCode.CheckState == CheckState.Checked)
                {
                    dtProductCodeSearch = DAL.fnElectronicsProductCodeName(searchText).Tables[0];
                    LastSearchText = searchText;
                    if (dtProductCodeSearch.Rows.Count > 0)
                    {
                        searchText = dtProductCodeSearch.Rows[0]["NodeID"].ToString() + ")" + dtProductCodeSearch.Rows[0]["Name"].ToString().Trim();
                        LastNodeIndex = 0;
                        SearchNodes(searchText, tvProduct.Nodes[0]);
                    }
                }
                else
                {
                    LastSearchText = searchText;
                    LastNodeIndex = 0;
                    SearchNodes(searchText, tvProduct.Nodes[0]);
                }

            }

            if (LastNodeIndex >= 0 && CurrentNodeMatches.Count > 0 && LastNodeIndex < CurrentNodeMatches.Count)
            {
                TreeNode selectedNode = CurrentNodeMatches[LastNodeIndex];
                LastNodeIndex++;
                tvProduct.SelectedNode = selectedNode;
                tvProduct.SelectedNode.Expand();
                tvProduct.Select();
                TreeNode tn = this.tvProduct.SelectedNode;
                int x = tn.Bounds.X;
                int y = tn.Bounds.Y;
                TreeNodeMouseClickEventArgs treeNodeMouseClickEventArgs = new TreeNodeMouseClickEventArgs(tn, MouseButtons.Left, 1, x, y);
                tvProduct_NodeMouseClick(tn, treeNodeMouseClickEventArgs);

            }
        }

        bool bchecked = false;
        DataTable dtProductorFolderCheck = new DataTable();
        DataTable dtProductItems = new DataTable();
        private void tvProduct_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Node.StateImageIndex == 0)
            {
                dgBOMList.DataSource = null;
                pnProductcode.Enabled = false;
                txtProductName.ResetText();
                txtProductCode.ResetText();
                txtProductName.ResetText();
                txtProductCost.ResetText();
                txtName.Visible = false;
                btnQuoteTreeSave.Visible = false;
                bchecked = false;
                sName = e.Node.Name.Split(')');

                dtProductorFolderCheck = DAL.fnElectronicsProductorFolder(sName[0], "CV").Tables[0];
                if (dtProductorFolderCheck.Rows.Count == 0)
                {
                    btnAddFolder.Enabled = true;
                    btnAddProduct.Enabled = true;
                    bchecked = true;
                }
                else if (dtProductorFolderCheck.Rows.Count > 0)
                {
                    btnAddFolder.Enabled = true;
                    btnAddProduct.Enabled = true;
                    bchecked = true;
                }
                if (!bchecked)
                {
                    dtProductorFolderCheck = DAL.fnElectronicsProductorFolder(sName[0], null).Tables[0];
                    if (dtProductorFolderCheck.Rows.Count > 0)
                    {
                        btnAddFolder.Enabled = true;
                        btnAddProduct.Enabled = false;
                    }
                }
            }
            else
            {

                pnProductcode.Enabled = true;
                btnAddFolder.Enabled = false;
                btnAddProduct.Enabled = false;
                tvProduct.SelectedNode = e.Node;
                tvProduct.LabelEdit = false;
                sNName = e.Node.Name;
                if (e.Node.Parent != null && e.Node != null && (e.Node.StateImageIndex == 2 || e.Node.StateImageIndex == 3 || e.Node.StateImageIndex == 4))
                {
                    dgBOMList.DataSource = null;
                    btnAddFolder.Enabled = false;
                    btnAddProduct.Enabled = false;

                    sName = tvProduct.SelectedNode.Name.Split(')');
                    if (!string.IsNullOrEmpty(sName[0]))
                    {
                        SalesProductMaster = DAL.fnElectronicsProductMaster(0, sName[0]).Tables[0];
                        if (chkProductIssue.Checked)
                        {
                            dtProductItems = DAL.fnElectronicsProductMaster(1, sName[0]).Tables[0];
                        }
                        else if (chkEleFM.Checked)
                        {
                            dtProductItems = DAL.fnElectronicsProductMaster(11, sName[0]).Tables[0];
                        }
                        else if (chkTrIssue.Checked)
                        {
                            dtProductItems = DAL.fnElectronicsProductMaster(12, sName[0]).Tables[0];
                        }

                        if (SalesProductMaster.Rows.Count > 0)
                        {
                            if (!string.IsNullOrEmpty(SalesProductMaster.Rows[0]["ProductCode"].ToString()))
                            {
                                txtProductName.Text = SalesProductMaster.Rows[0]["Name"].ToString();
                                txtProductCode.Text = SalesProductMaster.Rows[0]["ProductCode"].ToString();
                                txtProductCost.Text = SalesProductMaster.Rows[0]["ProductCost"].ToString();
                                btnUpdateProduct.Text = "Update";
                            }
                            else
                            {
                                txtProductName.ResetText();
                                txtProductCode.ResetText();
                                txtProductName.ResetText();
                                txtProductCost.ResetText();
                            }
                        }
                        if (dtProductItems.Rows.Count > 0)
                        {
                            dgBOMList.AutoGenerateColumns = false;
                            dgBOMList.DataSource = dtProductItems;
                            fnIPTotal();
                        }
                    }
                }
                else
                {
                    txtProductName.ResetText();
                    txtProductCode.ResetText();
                    txtProductName.ResetText();
                    txtProductCost.ResetText();
                    btnUpdateProduct.Text = "Save";
                }
            }
        }
        DataTable dtItemList = new DataTable();
        private void txtItemDescription_MouseClick(object sender, MouseEventArgs e)
        {

        }
        DataView dvItemList = new DataView();
        private void RowFilter() //filter the item list by user selected options
        {
            if (dvItemList.Count > 0)
            {
                dgItemList.AutoGenerateColumns = false;
                dgItemList.DataSource = dvItemList.ToTable();
            }
        }

        private void txtItemDescription_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);

                    RowFilter();

                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
                    RowFilter();
                }

            }
            else
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);
                    RowFilter();
                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
                    RowFilter();
                }
            }
        }
        double oldvalue;
        private void dgItemList_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if ((dgItemList.CurrentCell.OwningColumn.Name == "Quantity"))
            {
                oldvalue = Convert.ToDouble(dgItemList.CurrentCell.Value);
            }
        }

        private void dgItemList_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (dgItemList.CurrentCell.OwningColumn.Name == "Quantity")
            {
                if (!string.IsNullOrEmpty(dgItemList.CurrentCell.Value.ToString()) && (dgItemList.CurrentCell.Value.ToString() != "."))// != null)
                {
                    if (Convert.ToDouble(dgItemList.CurrentCell.Value.ToString()) <= 0)
                    {
                        dgItemList.CurrentCell.Value = oldvalue;
                    }
                }
                else
                {
                    MessageBox.Show("Enter a Valid Value", "Error", 0, MessageBoxIcon.Error);
                    dgItemList.CurrentCell.Value = oldvalue;
                }
            }
        }
        //#region Code to Validate Numbers in DataGrid View entered
        private void Control_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }
            // only allow one decimal point
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                e.Handled = true;
            }
        }

        private void dgItemList_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
            }
        }

        bool bItemExist = false;
        //Check Here the adding of Items
        private void dgItemList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgItemList.CurrentCell.OwningColumn.Name == "add")
            {
                bItemExist = false;
                foreach (DataGridViewRow DGVR in dgBOMList.Rows)
                {
                    if (DGVR.Cells["uItemCode"].Value.ToString().Trim().Equals(dgItemList.CurrentRow.Cells["ItemCode"].Value.ToString().Trim()))
                    {
                        bItemExist = true;
                        break;
                    }
                }
                if (!bItemExist)
                {
                    dtParentAndNodeID = DAL.fnGetElectronicsProductLastNodeId(sName[0]).Tables[0];
                    // if (dtParentAndNodeID.Rows.Count > 0)
                    iCurrentParentID = Convert.ToInt32(sName[0]);
                    if (iCurrentParentID != 0)
                    {
                        if (dtParentAndNodeID.Rows[0]["ImageIndex"].ToString() == "3")
                        {
                            GLobalClass.iSuccess = DAL.fnAddElectronicsProductName(8, 0, iCurrentParentID, tvProduct.SelectedNode.Name, "2", "", "", "", "", "", "");
                            tvProduct.SelectedNode.StateImageIndex = 2;
                        }

                        if (Convert.ToString(dgItemList.CurrentRow.Cells["Quantity"].Value) == string.Empty && Convert.ToString(dgItemList.CurrentRow.Cells["Quantity"].Value) != "0")
                        {
                            dgItemList.CurrentRow.Cells["Quantity"].Value = 1;
                        }

                        GLobalClass.iSuccess = DAL.fnAddElectronicsProductTreeItem(Global.uINSERT, iCurrentParentID, dgItemList.CurrentRow.Cells["ItemCode"].Value.ToString(), Convert.ToDouble(dgItemList.CurrentRow.Cells["Quantity"].Value.ToString()));

                        if (GLobalClass.iSuccess == 1)
                        {
                            if (chkProductIssue.Checked)
                            {
                                dtProductItems = DAL.fnElectronicsProductMaster(1, sName[0]).Tables[0];
                            }
                            else if (chkEleFM.Checked)
                            {
                                dtProductItems = DAL.fnElectronicsProductMaster(11, sName[0]).Tables[0];
                            }
                            else if (chkTrIssue.Checked)
                            {
                                dtProductItems = DAL.fnElectronicsProductMaster(12, sName[0]).Tables[0];
                            }
                            dgBOMList.AutoGenerateColumns = false;
                            dgBOMList.DataSource = dtProductItems;
                            fnIPTotal();
                            MessageBox.Show("Slected Item added to the '" + tvProduct.SelectedNode.Name + "' BOM successfully", "Success", 0, MessageBoxIcon.Information);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Selected item already added in BOM", "Information", 0, MessageBoxIcon.Error);
                }
            }
        }

        double dTotalIPAmount = 0;
        private void fnIPTotal()
        {
            dTotalIPAmount = 0;
            foreach (DataGridViewRow dgvr in dgBOMList.Rows)
            {
                dTotalIPAmount += (Convert.ToDouble(dgvr.Cells[4].Value));
            }
            lblIPTotalAmount.Text = Math.Round(dTotalIPAmount).ToString();
        }

        private void dgBOMList_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if ((dgBOMList.CurrentCell.OwningColumn.Name == "BOMQuantity")) //dgbomlist.CurrentCell.OwningColumn.Name == "Amount" || dgbomlist.CurrentCell.OwningColumn.Name == "ReqQty")
            {
                oldvalue = Convert.ToDouble(dgBOMList.CurrentCell.Value);
            }
        }

        private void dgBOMList_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (!string.IsNullOrEmpty(dgBOMList.CurrentCell.Value.ToString()) && (dgBOMList.CurrentCell.Value.ToString() != "."))
            {
                if (Convert.ToDouble(dgBOMList.CurrentCell.Value.ToString()) != 0)
                {
                    DialogResult DR = MessageBox.Show("Do you want to update of the quantity selected Item", "Information", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                    if (DR == DialogResult.Yes)
                    {
                        dgBOMList.CurrentRow.Cells["Amount"].Value = Convert.ToDouble(dgBOMList.CurrentRow.Cells["BOMQuantity"].Value) * Convert.ToDouble(dgBOMList.CurrentRow.Cells["UnitCost"].Value);

                        if (!string.IsNullOrEmpty(txtProductCode.Text))
                        {
                            //  dtUpdateParentID = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Parent.Name).Tables["LastNodeId"];
                            //   dtUpdateParentID = DAL.fnGetTreeNode(tvProduct.SelectedNode.Name, dtUpdateParentID.Rows[0]["NodeID"].ToString()).Tables[0];
                            // dtUpdateParentID = DAL.fnGetTreeProductCode(txtProductCode.Text).Tables[0];


                            GLobalClass.iSuccess = DAL.fnAddElectronicsProductTreeItem(Global.uUPDATE, Convert.ToInt32(sName[0]), dgBOMList.CurrentRow.Cells["uItemCode"].Value.ToString(), Convert.ToDouble(dgBOMList.CurrentRow.Cells["BOMQuantity"].Value));
                        }
                    }
                    else
                    {
                        dgBOMList.CurrentCell.Value = oldvalue;
                    }
                }
                else
                {
                    MessageBox.Show("Quantity should be greater than 0", "Error", 0, MessageBoxIcon.Error);
                    dgBOMList.CurrentCell.Value = oldvalue;
                }
            }
            else
            {
                MessageBox.Show("Quantity should be greater than 0", "Error", 0, MessageBoxIcon.Error);
                dgBOMList.CurrentCell.Value = oldvalue;
            }
        }

        private void dgBOMList_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
            }
        }

        private void dgBOMList_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                DialogResult DR = MessageBox.Show("Do you want to delete selected Item?  " + dgBOMList.CurrentRow.Cells["uItemDescription"].Value.ToString() + "", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DR == DialogResult.Yes)
                {
                    GLobalClass.iSuccess = DAL.fnAddElectronicsProductTreeItem(Global.uDELETE, Convert.ToInt32(sName[0]), dgBOMList.CurrentRow.Cells["uItemCode"].Value.ToString(), 0);

                    MessageBox.Show("Slected Item '" + dgBOMList.CurrentRow.Cells["uItemDescription"].Value.ToString() + "' Deleted successfully", "Success", 0, MessageBoxIcon.Information);
                    dgBOMList.Rows.RemoveAt(dgBOMList.Rows.IndexOf(dgBOMList.CurrentRow));
                }
            }
        }

        private void chkItemCode_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemCode.CheckState == CheckState.Checked)
            {
                chkItemDesc.Checked = false;
            }
        }

        private void chkItemDesc_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemDesc.CheckState == CheckState.Checked)
            {
                chkItemCode.Checked = false;
            }
        }

        private void txtItemDescription_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar == '%' || e.KeyChar == '['))
            {
                e.Handled = true;
            }
        }

        private void chkProductIssue_CheckedChanged(object sender, EventArgs e)
        {
            if (chkProductIssue.CheckState == CheckState.Checked)
            {
                dtItemList = DAL.fnElectronicsBOMItemList(0, null).Tables[0];
                chkEleFM.Checked = false;
                chkTrIssue.Checked = false;
                dgItemList.DataSource = null;
            }
        }

        private void chkEleFM_CheckedChanged(object sender, EventArgs e)
        {
            if (chkEleFM.CheckState == CheckState.Checked)
            {
                dtItemList = DAL.fnElectronicsBOMItemList(2, null).Tables[0];
                chkProductIssue.Checked = false;
                chkTrIssue.Checked = false;
                dgItemList.DataSource = null;
            }
        }

        private void chkTrIssue_CheckedChanged(object sender, EventArgs e)
        {
            if (chkTrIssue.CheckState == CheckState.Checked)
            {
                dtItemList = DAL.fnElectronicsBOMItemList(3, null).Tables[0];
                chkProductIssue.Checked = false;
                chkEleFM.Checked = false;
                dgItemList.DataSource = null;
            }
        }
        BindingSource bsIteSearch = new BindingSource();
        DataTable dtClone = new DataTable();
        private void txtItemSearch_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtItemSearch.TextLength > 2)
            {
                if (dtProductItems.Rows.Count > 0)
                {
                    dtClone = dtProductItems.Copy();
                    bsIteSearch.DataSource = dtClone;
                    bsIteSearch.Filter = string.Format("ItemCode LIKE '%{0}%' OR ItemDescription LIKE '%{0}%'", txtItemSearch.Text);
                    dgBOMList.DataSource = bsIteSearch;
                    fnColour();
                }
            }
            else
            {
                bsIteSearch.RemoveFilter();
                fnColour();
            }
        }


        private void fnColour()
        {
            dgBOMList.Sort(dgBOMList.Columns["Diffrence"], ListSortDirection.Ascending);
            fnQuantitycheck();
        }

        private void tvProduct_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete selected row from the list
            {
                if (tvProduct.SelectedNode.Name != "BiSS KANBAN Products" && tvProduct.SelectedNode.Name != "Electronics" && tvProduct.SelectedNode.Name != "Transducers" && (tvProduct.SelectedNode.StateImageIndex == 2 || tvProduct.SelectedNode.StateImageIndex == 3))
                {
                    DialogResult DR = MessageBox.Show("Do you want to delete the selected Product ' " + tvProduct.SelectedNode.Name + " ' from ERP", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (DR == DialogResult.Yes)
                    {
                        GLobalClass.iSuccess = DAL.fnAddElectronicsProductName(Global.uDELETE, 0, Convert.ToInt32(sName[0]), tvProduct.SelectedNode.Name, "2", "", "", sName[0], "", "", "");
                    }
                    if (GLobalClass.iSuccess > 0)
                        tvProduct.SelectedNode.Remove();
                }
                else
                {
                    MessageBox.Show("You can't delete this folder ", "Warning", 0, MessageBoxIcon.Warning);
                }
            }
            else if (e.KeyCode == Keys.Enter)
            {
                btnsearchtree_Click(sender, e);
            }
            else if (e.Control && e.KeyCode == Keys.R)
            {
                if (tvProduct.SelectedNode.Name != "BiSS KANBAN Products" && tvProduct.SelectedNode.Name != "Electronics" && tvProduct.SelectedNode.Name != "Transducers" && tvProduct.SelectedNode.StateImageIndex == 0)
                {
                    sName = tvProduct.SelectedNode.Name.Split(')');
                    btnQuoteTreeSave.Text = "Rename";
                    txtName.Text = sName[1];
                    btnAddFolder_Click(sender, e);
                }
            }

            else if (e.Control && e.KeyCode == Keys.X)
            {
                if (tvProduct.SelectedNode.Name != "BiSS KANBAN Products" && tvProduct.SelectedNode.Name != "Electronics" && tvProduct.SelectedNode.Name != "Transducers")
                {
                    sName = tvProduct.SelectedNode.Name.Split(')');
                    sParentName = tvProduct.SelectedNode.Parent.Name.Split(')');

                    if (tvProduct.SelectedNode.StateImageIndex != 0)
                    {
                        sTreeChildName = tvProduct.SelectedNode.Name;
                        PasteImageIndex = tvProduct.SelectedNode.StateImageIndex;
                        NodeID = Convert.ToInt32(sName[0]);
                        tvProduct.SelectedNode.Remove();
                    }
                    else
                    {
                        sTreeChildName = tvProduct.SelectedNode.Name;
                        PasteImageIndex = tvProduct.SelectedNode.StateImageIndex;
                        NodeID = Convert.ToInt32(sName[0]);
                        tvProduct.SelectedNode.Remove();
                    }
                }
            }
            else if (e.Control && e.KeyCode == Keys.V)
            {
                sName = tvProduct.SelectedNode.Name.Split(')');
                //sParentName = tvProduct.SelectedNode.Parent.Name.Split(')');
                if (!string.IsNullOrEmpty(sTreeChildName))
                {
                    PasteParentID = Convert.ToInt32(sName[0]);
                    GLobalClass.iSuccess = DAL.fnPasteProduct(5, PasteParentID, NodeID);
                    TreeNode TN = new TreeNode();
                    tvProduct.BeginUpdate();
                    TN.Name = sTreeChildName;
                    TN.Text = sTreeChildName;
                    TN.ForeColor = Color.Black;
                    TN.StateImageIndex = PasteImageIndex;
                    tvProduct.SelectedNode.Nodes.Add(TN);
                    tvProduct.EndUpdate();
                    sTreeChildName = "";
                }
                else
                {
                    MessageBox.Show("Selected a Product to be copied", "Error", 0, MessageBoxIcon.Error);
                }
            }
        }

        private void btnExporttoExcel_Click(object sender, EventArgs e)
        {
            if (dtProductItems.Rows.Count > 0)
            {
                int iRowIndex = 1;
                string ExcelFolderPath;
                string FileFullPath;
                EXCEL.Workbook NewWorkBook;
                EXCEL.Worksheet NewWorkSheet;
                EXCEL.Application ExcelApp;
                EXCEL.Range CELLS, cell1, cell2;
                object misValue;

                ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\KANBAN BOM\\";
                FileFullPath = ExcelFolderPath + txtProductCode.Text + "--" + DateTime.Now.ToString("dd/MM/yyyy hh/mm/ss") + ".xls";
                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);
                ExcelApp = new EXCEL.Application();
                misValue = System.Reflection.Missing.Value;
                try
                {
                    if (ExcelApp == null)
                        MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                    NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                    NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                    if (NewWorkSheet == null)
                        MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                    else
                        NewWorkSheet.Name = txtProductCode.Text;
                    // Select the Excel cells, in the range c1 to c7 in the worksheet for cell access check.
                    EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                    if (RANGE == null)
                        MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                    NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlWorkbookNormal, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                    CELLS = NewWorkSheet.Cells;
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);

                    NewWorkSheet.Cells[iRowIndex, 1] = txtProductCode.Text + " " + txtProductName.Text;

                    iRowIndex++;
                    iRowIndex++;
                    iRowIndex++;

                    if (dtProductItems.Rows.Count > 0)
                    {
                        object[,] rawData = new object[dtProductItems.Rows.Count + 1, dtProductItems.Columns.Count];
                        for (int col = 0; col < dtProductItems.Columns.Count; col++)
                        {
                            rawData[0, col] = dtProductItems.Columns[col].ColumnName;
                        }
                        for (int row = 0; row < dtProductItems.Rows.Count; row++)
                        {
                            for (int col = 0; col < dtProductItems.Columns.Count; col++)
                            {
                                rawData[row + 1, col] = dtProductItems.Rows[row].ItemArray[col];
                            }
                        }
                        string excelRange = string.Empty;
                        string finalColLetter = string.Empty;
                        string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        int colCharsetLen = colCharset.Length;

                        if (dtProductItems.Columns.Count > colCharsetLen)
                        {
                            finalColLetter = colCharset.Substring((dtProductItems.Columns.Count - 1) / colCharsetLen - 1, 1);
                        }

                        finalColLetter += colCharset.Substring((dtProductItems.Columns.Count - 1) % colCharsetLen, 1);
                        excelRange = string.Format("A6:{0}{1}", finalColLetter, dtProductItems.Rows.Count + 6);
                        NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                    }
                    NewWorkSheet.Range["A1:S6"].Cells.Font.Bold = true;
                    NewWorkSheet.Range["A1:S6"].Cells.Font.Size = 16;

                    //if ((cmbReport.SelectedIndex > 0 && cmbReport.SelectedIndex < 3) || (cmbReport.SelectedIndex > 6 && cmbReport.SelectedIndex < 9))
                    //{
                    //    Microsoft.Office.Interop.Excel.Range r = NewWorkSheet.get_Range("F6", "F99999");
                    //    r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                    //}
                    //if (cmbReport.SelectedIndex == 4 || cmbReport.SelectedIndex == 10)
                    //{
                    //    Microsoft.Office.Interop.Excel.Range r = NewWorkSheet.get_Range("G6", "G99999");
                    //    r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                    //}

                    NewWorkSheet.Rows.AutoFit();

                    NewWorkSheet.Columns.AutoFit();

                    //if (cmbReport.SelectedIndex == 0 || cmbReport.SelectedIndex == 6)
                    //{
                    //    NewWorkSheet.Columns[2].ColumnWidth = 50;
                    //    NewWorkSheet.Columns[2].WrapText = true;
                    //}
                    //else
                    //{
                    //    NewWorkSheet.Columns[3].ColumnWidth = 50;
                    //    NewWorkSheet.Columns[3].WrapText = true;
                    //}


                    NewWorkSheet.Rows.RowHeight = "18";
                    NewWorkSheet.PageSetup.PrintArea = "A1:N" + dtProductItems.Rows.Count + iRowIndex + 6 + "";
                    NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                    NewWorkSheet.PageSetup.PrintNotes = true;
                    NewWorkSheet.PageSetup.Zoom = 100;
                    NewWorkSheet.PageSetup.FitToPagesTall = 1;
                    NewWorkSheet.PageSetup.FitToPagesWide = 1;
                    NewWorkSheet.PageSetup.LeftMargin = 0;
                    NewWorkSheet.PageSetup.RightMargin = 0;
                    NewWorkSheet.PageSetup.TopMargin = 0.75;
                    NewWorkSheet.PageSetup.BottomMargin = 0.75;
                    NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                    NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                    string _stLOGO = ("C:\\Databasepath\\Bisslogo.jpg");
                    EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 7];

                    Image oImage = Image.FromFile(_stLOGO);
                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    NewWorkSheet.Paste(oRange, _stLOGO);

                    NewWorkBook.Save();
                    ExcelApp.Visible = true;
                    System.Threading.Thread.Sleep(1000);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                    {
                        GetProcess.Kill();
                    }
                }
            }
            else
            {
                MessageBox.Show("Select an item to export to excel", "Information", 0, MessageBoxIcon.Warning);
            }
        }

        #region Excel Merge Function
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlMedium, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

        }
        #endregion

        private void btnAddExtra_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtInsatallationCommision.Text))
            {
                foreach (DataGridViewRow dgvr in dgBOMList.Rows)
                {
                    dgvr.Cells[6].Value = (Convert.ToDouble(dgvr.Cells[2].Value) * Convert.ToDouble(txtInsatallationCommision.Text)).ToString("0.##");
                    dgvr.Cells[7].Value = (Convert.ToDouble(dgvr.Cells[5].Value) - Convert.ToDouble(dgvr.Cells[6].Value)).ToString("0.##");
                }
                fnColour();
            }
        }

        private void fnQuantitycheck()
        {
            foreach (DataGridViewRow row in dgBOMList.Rows)
            {
                if (Convert.ToDouble(row.Cells[5].Value.ToString()) <= 0)
                {
                    row.DefaultCellStyle.BackColor = Color.Salmon;
                }
                else if (Convert.ToDouble(row.Cells[7].Value.ToString()) <= 0)
                {                    
                        row.DefaultCellStyle.BackColor = Color.Khaki;
                }
                //else if (Convert.ToDouble(row.Cells[7].Value.ToString()) <= 0)
                //{
                //    row.DefaultCellStyle.BackColor = Color.Khaki;

                //}
            }
        }
    }
}
