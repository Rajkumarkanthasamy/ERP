﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.IO;

namespace Erp_Project_With_Buttons.KanBanProduct
{
    public partial class frmProjectBOM : Form
    {
        public frmProjectBOM()
        {
            InitializeComponent();
        }
        frmForm2 Home = new frmForm2();
        DataAccessLayer DAL = new DataAccessLayer();
        Global GLobalClass = new Global();
        Login.frmLoginForm LoginForm = new Login.frmLoginForm();
        TreeNode tnCurrentParentNode = new TreeNode();
        DataTable dtTreeFromTable = new DataTable();
        DataTable dtProductItems = new DataTable();
        string[] sName;
        DataTable dtProjectList = new DataTable();

        // public int ElectronicsIssue = 0;
        private static string sProjectCode;
        public string fnProjectcode
        {
            get
            {
                return sProjectCode;
            }
            set
            {
                sProjectCode = value;
            }
        }

        private void frmProjectBOM_Load(object sender, EventArgs e)
        {
            dtTreeFromTable = DAL.fnGetKBELProductTreeView().Tables[0];
            tvProduct.Nodes.AddRange(GLobalClass.fnTreeFromTable(dtTreeFromTable, "ParentID", "NodeID", "ProductName", "ImageIndex"));
            tnCurrentParentNode = null;
            tvProduct.Sort();
            chkRawMaterailIssue.Checked = true;
            dtProjectList = DAL.fnAllProjectList(null).Tables[0];

            if (dtProjectList.Rows.Count > 0)
            {
                foreach (DataRow DR in dtProjectList.Rows)
                {
                    if (!cmbProjectCode.Items.Contains(DR["ProjectCode"].ToString()))
                        cmbProjectCode.Items.Add(DR["ProjectCode"].ToString());
                }
            }
            chkItemCode.Checked = true;
        }

        string[] sItemCode;
        DataTable dtItemcode = new DataTable();
        DataTable dtItemAdd = new DataTable();

        private void chklbItemList_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            try
            {
                if (cmbProjectCode.SelectedIndex >= 0)
                {
                    int i = 0;
                    if (chkProductIssue.Checked)
                    {
                        sItemCode = chklbItemList.SelectedItem.ToString().Trim().Split(')');
                        string sID = sItemCode[0];
                        dtItemcode = DAL.fnKanBanElectronicsFGItemList(1, sID).Tables[0];
                        if (dtItemcode.Rows.Count > 0)
                        {
                            if (!chklbItemList.CheckedItems.Contains(chklbItemList.SelectedItem))
                            {
                                foreach (DataGridViewRow DGVR in dgIndentList.Rows)
                                {
                                    if (DGVR.Cells["ItemCode"].Value.ToString().Equals(dtItemcode.Rows[0]["ItemCode"].ToString()))
                                    {
                                        i = 1;
                                        break;
                                    }
                                }
                                if (i != 1)
                                {
                                    if (dtItemAdd.Rows.Count == 0)
                                    {
                                        dtItemAdd = DAL.fnKanBanElectronicsFGItemList(1, sID).Tables[0];
                                    }


                                    GLobalClass.iSuccess = DAL.fnAddKanBanElectronicsBOM(0, dtItemcode.Rows[0]["ItemCode"].ToString(), dtItemcode.Rows[0]["ItemDescription"].ToString(), sItemType,
                                                                                            1, Convert.ToDouble(dtItemcode.Rows[0]["UnitCost"].ToString()), LoginForm.GetUserDetails[2].ToString(), cmbProjectCode.Text, dtItemcode.Rows[0]["Units"].ToString());

                                    fnLoadData();
                                }
                                else
                                {
                                    MessageBox.Show("Selected Item already added", "Error", 0, MessageBoxIcon.Error);
                                    int k = chklbItemList.SelectedIndex;
                                    chklbItemList.SetItemCheckState(k, CheckState.Unchecked);
                                }

                            }
                            //else
                            //{
                            //    int rowIndex = -1;
                            //    bool bSelected;

                            //    foreach (DataGridViewRow row in dgIndentList.Rows)
                            //    {
                            //        bSelected = (row.Cells["ItemCode"].Value.ToString().Equals(dtItemcode.Rows[0]["ItemCode"].ToString()));
                            //        if (bSelected == true)
                            //        {
                            //            rowIndex = row.Index;
                            //            dgIndentList.Rows.Remove(dgIndentList.Rows[rowIndex]);
                            //            break;
                            //        }
                            //    }
                            //}
                        }
                    }
                    else if (chkRawMaterailIssue.Checked)
                    {
                        sItemCode = chklbItemList.SelectedItem.ToString().Trim().Split(')');
                        string sID = sItemCode[0];
                        dtItemcode = DAL.fnKanBanElectronicsFGItemList(2, sID).Tables[0];
                        if (dtItemcode.Rows.Count > 0)
                        {
                            if (!chklbItemList.CheckedItems.Contains(chklbItemList.SelectedItem))
                            {
                                foreach (DataGridViewRow DGVR in dgIndentList.Rows)
                                {
                                    if (DGVR.Cells["ItemCode"].Value.ToString().Equals(dtItemcode.Rows[0]["ItemCode"].ToString()))
                                    {
                                        i = 1;
                                        break;
                                    }
                                }
                                if (i != 1)
                                {
                                    if (dtItemAdd.Rows.Count == 0)
                                    {
                                        dtItemAdd = DAL.fnKanBanElectronicsFGItemList(2, sID).Tables[0];
                                    }

                                    //dtItemAdd.Rows.Add(dtItemcode.Rows[0]["ItemCode"].ToString(), dtItemcode.Rows[0]["ItemDescription"].ToString(),
                                    //                   dtItemcode.Rows[0]["Units"].ToString(), Convert.ToDouble(dtItemcode.Rows[0]["AvailableQty"].ToString()), dtItemcode.Rows[0]["UnitCost"].ToString(), dtItemcode.Rows[0]["ReqQty"].ToString());

                                    GLobalClass.iSuccess = DAL.fnAddKanBanElectronicsBOM(0, dtItemcode.Rows[0]["ItemCode"].ToString(), dtItemcode.Rows[0]["ItemDescription"].ToString(), sItemType,
                                                                                           1, Convert.ToDouble(dtItemcode.Rows[0]["UnitCost"].ToString()), LoginForm.GetUserDetails[2].ToString(), cmbProjectCode.Text, dtItemcode.Rows[0]["Units"].ToString());
                                    fnLoadData();

                                }
                                else
                                {
                                    MessageBox.Show("Selected Item already present in the list", "Error", 0, MessageBoxIcon.Error);
                                    int k = chklbItemList.SelectedIndex;
                                    chklbItemList.SetItemCheckState(k, CheckState.Unchecked);
                                }
                            }
                            //else
                            //{
                            //    int rowIndex = -1;
                            //    bool bSelected;

                            //    foreach (DataGridViewRow row in dgIndentList.Rows)
                            //    {
                            //        bSelected = (row.Cells["ItemCode"].Value.ToString().Equals(dtItemcode.Rows[0]["ItemCode"].ToString()));
                            //        if (bSelected == true)
                            //        {
                            //            rowIndex = row.Index;
                            //            dgIndentList.Rows.Remove(dgIndentList.Rows[rowIndex]);
                            //            break;
                            //        }
                            //    }
                            //}
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Select a project to add items", "Error", 0, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("PurchaseOrder_chklbItemList_ItemCheck" + ex.Message);
            }
        }
        DataView dvItemList = new DataView();
        DataTable dtItemList = new DataTable();

        private void RowFilter()
        {
            chklbItemList.Items.Clear();
            foreach (DataRowView dv in dvItemList)
            {
                chklbItemList.Items.Add(string.Concat(dv["ID"].ToString(), ") ", dv["ItemCode"].ToString(), ", ", dv["ItemDescription"].ToString(), ", ", dv["AvailableQty"].ToString()));
            }
        }
        string sItemType = "";
        private void chkProductIssue_CheckedChanged(object sender, EventArgs e)
        {
            if (chkProductIssue.Checked)
            {
                sItemType = "ElectronicsFG";
                chkRawMaterailIssue.Checked = false;
                dtItemList.Rows.Clear();
                dtItemList = DAL.fnKanBanElectronicsFGItemList(0, null).Tables[0];
                RowFilter();
            }
        }

        private void chkRawMaterailIssue_CheckedChanged(object sender, EventArgs e)
        {
            if (chkRawMaterailIssue.Checked)
            {
                sItemType = "ElectronicsItem";
                chkProductIssue.Checked = false;
                dtItemList.Rows.Clear();
                dtItemList = DAL.fnKanBanElectronicsRawItemList(null).Tables[0];
                RowFilter();
            }
        }

        private void txtItemDescription_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);
                    RowFilter();

                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
                    RowFilter();
                }
            }
            else
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);
                    RowFilter();
                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
                    RowFilter();
                }
            }
        }

        DataTable dtProjectBOMdetails = new DataTable();

        private void cmbProjectCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtProjectBOMdetails = DAL.fnWIPProjectCode(cmbProjectCode.Text).Tables[0];
            if (dtProjectBOMdetails.Rows.Count > 0)
            {
                lblprojname.Text = dtProjectBOMdetails.Rows[0]["ProjectDescription"].ToString();
                lblcustomername.Text = dtProjectBOMdetails.Rows[0]["Customer"].ToString();
                lblProjectStatus.Text = dtProjectBOMdetails.Rows[0]["Status"].ToString();

                fnLoadData();
            }
            else
            {
                lblprojname.ResetText();
                lblcustomername.ResetText();
                lblProjectStatus.ResetText();
            }
        }

        private void fnLoadData()
        {
            dtProjectBOM = DAL.fnElectronicsProductMaster(5, cmbProjectCode.Text).Tables[0];
            dgIndentList.AutoGenerateColumns = false;
            dgIndentList.DataSource = dtProjectBOM;

            foreach (DataGridViewRow dgr in dgIndentList.Rows)
            {
                if (Convert.ToDouble(dgr.Cells["AvailableQty"].Value) == Convert.ToDouble("0"))
                {
                    dgr.DefaultCellStyle.BackColor = Color.Red;
                }

                DataTable dtLatestPurchase = DAL.fnLatestPurchaseList(dgr.Cells["ItemCode"].ToString()).Tables[0];
                if (dtLatestPurchase.Rows.Count > 0)
                {
                    dgr.Cells["LatestCost"].Value = dtLatestPurchase.Rows[0][1].ToString();
                }
                else
                {
                    dgr.Cells["LatestCost"].Value = dgr.Cells["UnitCost"].Value;
                }
            }

            fnIPTotal();
        }

        double dTotalAmount = 0;
        double dLatestAmount = 0;
        private void fnIPTotal()
        {
            dTotalAmount = 0;
            dLatestAmount = 0;
            foreach (DataGridViewRow dgvr in dgIndentList.Rows)
            {
                dTotalAmount += Convert.ToDouble(dgvr.Cells["UnitCost"].Value) * Convert.ToDouble(dgvr.Cells["BOMQuantity"].Value);
                dLatestAmount += Convert.ToDouble(dgvr.Cells["LatestCost"].Value) * Convert.ToDouble(dgvr.Cells["BOMQuantity"].Value);
            }
            lblIPTotalAmount.Text = Math.Round(dTotalAmount).ToString();
            lblLatestCost.Text = Math.Round(dLatestAmount).ToString();
        }

        public int ElectronicsBOMIssue = 0;


        private void btnProjectView_Click(object sender, EventArgs e)
        {
            ElectronicsBOMIssue = 1;
            Indent.frmProjectselect projectsearch = new Indent.frmProjectselect();
            projectsearch.fnElectronicIssueBOM = ElectronicsBOMIssue.ToString();
            projectsearch.ShowDialog();
            if (fnProjectcode != null)
            {
                cmbProjectCode.Text = sProjectCode;
            }
        }

        private void fnExit()
        {
            this.Hide();
            Home.Show();
        }

        private void frmProjectBOM_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnExit();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            fnExit();
        }
        DataTable dtProjectBOM = new DataTable();

        private void tvProduct_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Node.Parent != null && e.Node != null && (e.Node.StateImageIndex == 2 || e.Node.StateImageIndex == 3 || e.Node.StateImageIndex == 4))
            {
                if (cmbProjectCode.SelectedIndex >= 0)
                {
                    sName = tvProduct.SelectedNode.Name.Split(')');
                    if (chkProductIssue.Checked)
                    {
                        dtProductItems = DAL.fnElectronicsProductMaster(3, sName[0]).Tables[0];
                    }
                    else if (chkRawMaterailIssue.Checked)
                    {
                        dtProductItems = DAL.fnElectronicsProductMaster(31, sName[0]).Tables[0];
                    }


                    if (dtProductItems.Rows.Count > 0)
                    {
                        int i = 0;
                        foreach (DataRow dr in dtProductItems.Rows)
                        {
                            i = 0;
                            foreach (DataGridViewRow DGVR in dgIndentList.Rows)
                            {
                                if (DGVR.Cells["ItemCode"].Value.ToString().Equals(dr["ItemCode"].ToString()))
                                {
                                    i = 1;
                                    break;
                                }
                            }

                            if (i != 1)
                            {
                                GLobalClass.iSuccess = DAL.fnAddKanBanElectronicsBOM(0, dr["ItemCode"].ToString(), dr["ItemDescription"].ToString(), sItemType,
                                                        Convert.ToDouble(dr["Quantity"].ToString()), Convert.ToDouble(dr["UnitCost"].ToString()),
                                                        LoginForm.GetUserDetails[2].ToString(), cmbProjectCode.Text, dr["Units"].ToString());
                            }
                        }
                        fnLoadData();
                    }

                }
                else
                {
                    MessageBox.Show("Select the project code to add the BOM", "Error", 0, MessageBoxIcon.Error);
                }
            }
        }
        BindingSource bsIteSearch = new BindingSource();
        DataTable dtClone = new DataTable();
        private void txtItemSearch_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtItemSearch.TextLength > 2)
            {
                if (dtProjectBOM.Rows.Count > 0)
                {
                    dtClone = dtProjectBOM.Copy();
                    bsIteSearch.DataSource = dtClone;
                    bsIteSearch.Filter = string.Format("ItemCode LIKE '%{0}%' OR ItemDescription LIKE '%{0}%'", txtItemSearch.Text);
                    dgIndentList.DataSource = bsIteSearch;
                }
            }
            else
            {
                bsIteSearch.RemoveFilter();
            }
        }
        double oldvalue;

        private void dgIndentList_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if ((dgIndentList.CurrentCell.OwningColumn.Name == "BOMQuantity")) //dgbomlist.CurrentCell.OwningColumn.Name == "Amount" || dgbomlist.CurrentCell.OwningColumn.Name == "ReqQty")
            {
                oldvalue = Convert.ToDouble(dgIndentList.CurrentCell.Value);
            }
        }

        private void dgIndentList_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (!string.IsNullOrEmpty(dgIndentList.CurrentCell.Value.ToString()) && (dgIndentList.CurrentCell.Value.ToString() != "."))
            {
                if (Convert.ToDouble(dgIndentList.CurrentCell.Value.ToString()) != 0)
                {
                    DialogResult DR = MessageBox.Show("Do you want to update of the quantity selected Item", "Information", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                    if (DR == DialogResult.Yes)
                    {
                        GLobalClass.iSuccess = DAL.fnAddKanBanElectronicsBOM(1, dgIndentList.CurrentRow.Cells["ItemCode"].Value.ToString(), "", sItemType,
                                                       Convert.ToDouble(dgIndentList.CurrentRow.Cells["BOMQuantity"].Value), 0,
                                                       LoginForm.GetUserDetails[2].ToString(), cmbProjectCode.Text, "");
                        fnLoadData();
                    }
                    else
                    {
                        dgIndentList.CurrentCell.Value = oldvalue;
                    }
                }
                else
                {
                    MessageBox.Show("Quantity should be greater than 0", "Error", 0, MessageBoxIcon.Error);
                    dgIndentList.CurrentCell.Value = oldvalue;
                }
            }
            else
            {
                MessageBox.Show("Quantity should be greater than 0", "Error", 0, MessageBoxIcon.Error);
                dgIndentList.CurrentCell.Value = oldvalue;
            }
        }

        //#region Code to Validate Numbers in DataGrid View entered
        private void Control_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }
            // only allow one decimal point
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                e.Handled = true;
            }
        }

        private void dgIndentList_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
            }
        }

        private void dgIndentList_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                DialogResult DR = MessageBox.Show("Do you want to delete selected Item?  " + dgIndentList.CurrentRow.Cells["ItemDesc"].Value.ToString() + "", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DR == DialogResult.Yes)
                {
                    GLobalClass.iSuccess = DAL.fnAddKanBanElectronicsBOM(2, dgIndentList.CurrentRow.Cells["ItemCode"].Value.ToString(), "", sItemType,
                                                      Convert.ToDouble(dgIndentList.CurrentRow.Cells["BOMQuantity"].Value), 0,
                                                      LoginForm.GetUserDetails[2].ToString(), cmbProjectCode.Text, "");

                    MessageBox.Show("Slected Item '" + dgIndentList.CurrentRow.Cells["ItemDesc"].Value.ToString() + "' Deleted successfully", "Success", 0, MessageBoxIcon.Information);
                  
                    dgIndentList.Rows.RemoveAt(dgIndentList.Rows.IndexOf(dgIndentList.CurrentRow));
                    fnLoadData();
                }
            }
        }

        #region Excel Merge Function
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlMedium, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

        }
        #endregion

        private void btnExporttoExcel_Click(object sender, EventArgs e)
        {
            if (dgIndentList.Rows.Count > 0)
            {
                dtProductItems = ((DataTable)dgIndentList.DataSource);
               // dtProductItems = dtProjectBOM.Copy();
                int iRowIndex = 1;
                string ExcelFolderPath;
                string FileFullPath;
                EXCEL.Workbook NewWorkBook;
                EXCEL.Worksheet NewWorkSheet;
                EXCEL.Application ExcelApp;
                EXCEL.Range CELLS, cell1, cell2;
                object misValue;

                ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\KANBAN BOM\\";
                FileFullPath = ExcelFolderPath + cmbProjectCode.Text + "--" + DateTime.Now.ToString("dd/MM/yyyy hh/mm/ss") + ".xls";
                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);
                ExcelApp = new EXCEL.Application();
                misValue = System.Reflection.Missing.Value;
                try
                {
                    if (ExcelApp == null)
                        MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                    NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                    NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                    if (NewWorkSheet == null)
                        MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                    else
                        NewWorkSheet.Name = cmbProjectCode.Text;
                    // Select the Excel cells, in the range c1 to c7 in the worksheet for cell access check.
                    EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                    if (RANGE == null)
                        MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                    NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlWorkbookNormal, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                    CELLS = NewWorkSheet.Cells;
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);

                    NewWorkSheet.Cells[iRowIndex, 1] = cmbProjectCode.Text;
                    NewWorkSheet.Cells[3, 1] = "Total Cost";
                    NewWorkSheet.Cells[3, 2] = lblIPTotalAmount.Text;
                    NewWorkSheet.Cells[4, 1] = "Latest Total Cost";
                    NewWorkSheet.Cells[4, 2] = lblLatestCost.Text;
                    iRowIndex++;
                    iRowIndex++;
                    iRowIndex++;

                    if (dtProductItems.Rows.Count > 0)
                    {
                        object[,] rawData = new object[dtProductItems.Rows.Count + 1, dtProductItems.Columns.Count];
                        for (int col = 0; col < dtProductItems.Columns.Count; col++)
                        {
                            rawData[0, col] = dtProductItems.Columns[col].ColumnName;
                        }
                        for (int row = 0; row < dtProductItems.Rows.Count; row++)
                        {
                            for (int col = 0; col < dtProductItems.Columns.Count; col++)
                            {
                                rawData[row + 1, col] = dtProductItems.Rows[row].ItemArray[col];
                            }
                        }
                        string excelRange = string.Empty;
                        string finalColLetter = string.Empty;
                        string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        int colCharsetLen = colCharset.Length;

                        if (dtProductItems.Columns.Count > colCharsetLen)
                        {
                            finalColLetter = colCharset.Substring((dtProductItems.Columns.Count - 1) / colCharsetLen - 1, 1);
                        }

                        finalColLetter += colCharset.Substring((dtProductItems.Columns.Count - 1) % colCharsetLen, 1);
                        excelRange = string.Format("A6:{0}{1}", finalColLetter, dtProductItems.Rows.Count + 6);
                        NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                    }
                    NewWorkSheet.Range["A1:S6"].Cells.Font.Bold = true;
                    NewWorkSheet.Range["A1:S6"].Cells.Font.Size = 12;

                    //if ((cmbReport.SelectedIndex > 0 && cmbReport.SelectedIndex < 3) || (cmbReport.SelectedIndex > 6 && cmbReport.SelectedIndex < 9))
                    //{
                    Microsoft.Office.Interop.Excel.Range r = NewWorkSheet.get_Range("J6", "J99999");
                    r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                    //}
                    //if (cmbReport.SelectedIndex == 4 || cmbReport.SelectedIndex == 10)
                    //{
                    //    Microsoft.Office.Interop.Excel.Range r = NewWorkSheet.get_Range("G6", "G99999");
                    //    r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                    //}

                    NewWorkSheet.Rows.AutoFit();

                    NewWorkSheet.Columns.AutoFit();

                    //if (cmbReport.SelectedIndex == 0 || cmbReport.SelectedIndex == 6)
                    //{
                    //    NewWorkSheet.Columns[2].ColumnWidth = 50;
                    //    NewWorkSheet.Columns[2].WrapText = true;
                    //}
                    //else
                    //{
                    //    NewWorkSheet.Columns[3].ColumnWidth = 50;
                    //    NewWorkSheet.Columns[3].WrapText = true;
                    //}


                    NewWorkSheet.Rows.RowHeight = "18";
                    NewWorkSheet.PageSetup.PrintArea = "A1:J" + dtProductItems.Rows.Count + iRowIndex + 6 + "";
                    NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                    NewWorkSheet.PageSetup.PrintNotes = true;
                    NewWorkSheet.PageSetup.Zoom = 100;
                    NewWorkSheet.PageSetup.FitToPagesTall = 1;
                    NewWorkSheet.PageSetup.FitToPagesWide = 1;
                    NewWorkSheet.PageSetup.LeftMargin = 0;
                    NewWorkSheet.PageSetup.RightMargin = 0;
                    NewWorkSheet.PageSetup.TopMargin = 0.75;
                    NewWorkSheet.PageSetup.BottomMargin = 0.75;
                    NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                    NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                    //string _stLOGO = ("C:\\Databasepath\\Bisslogo.jpg");
                    //EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 7];

                    //Image oImage = Image.FromFile(_stLOGO);
                    //System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    //NewWorkSheet.Paste(oRange, _stLOGO);

                    NewWorkBook.Save();
                    ExcelApp.Visible = true;
                    System.Threading.Thread.Sleep(1000);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    //foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                    //{
                    //    GetProcess.Kill();
                    //}
                }
            }
            else
            {
                MessageBox.Show("Select a project to export to excel", "Information", 0, MessageBoxIcon.Warning);
            }
        }

        private void chklbItemList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
