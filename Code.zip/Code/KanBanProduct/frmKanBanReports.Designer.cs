﻿namespace Erp_Project_With_Buttons.KanBanProduct
{
    partial class frmKanBanReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmKanBanReports));
            this.cmbReport = new System.Windows.Forms.ComboBox();
            this.lblFromdate = new System.Windows.Forms.Label();
            this.dtpFromDate = new System.Windows.Forms.DateTimePicker();
            this.dptToDate = new System.Windows.Forms.DateTimePicker();
            this.lblTables = new System.Windows.Forms.Label();
            this.btnexcelreport = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pnGenaralPanel = new System.Windows.Forms.Panel();
            this.dgvReportView = new System.Windows.Forms.DataGridView();
            this.btnSearch = new System.Windows.Forms.Button();
            this.lblItemcodeorName = new System.Windows.Forms.Label();
            this.txtItemSearch = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pnProjectCodePanel = new System.Windows.Forms.Panel();
            this.btnProjectView = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtProjectCode = new System.Windows.Forms.TextBox();
            this.lblSelectedProjectCode = new System.Windows.Forms.Label();
            this.cmbProjectCode = new System.Windows.Forms.ComboBox();
            this.lblItemDiscription = new System.Windows.Forms.Label();
            this.lblTotalAmount = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.pntotalamount = new System.Windows.Forms.Panel();
            this.pnAllyears = new System.Windows.Forms.Panel();
            this.pnoneyear = new System.Windows.Forms.Panel();
            this.dtptwelve = new System.Windows.Forms.DateTimePicker();
            this.lblTwelveMonths = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblToDate = new System.Windows.Forms.Label();
            this.dtpItemUsage = new System.Windows.Forms.DateTimePicker();
            this.dtp6months = new System.Windows.Forms.DateTimePicker();
            this.pnGenaralPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReportView)).BeginInit();
            this.pnProjectCodePanel.SuspendLayout();
            this.pntotalamount.SuspendLayout();
            this.pnAllyears.SuspendLayout();
            this.pnoneyear.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmbReport
            // 
            this.cmbReport.DropDownHeight = 130;
            this.cmbReport.DropDownWidth = 184;
            this.cmbReport.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbReport.FormattingEnabled = true;
            this.cmbReport.IntegralHeight = false;
            this.cmbReport.ItemHeight = 19;
            this.cmbReport.Items.AddRange(new object[] {
            "Transducer Current Stock",
            "Transducer Stock Recieved",
            "Transducer Items Issued",
            "Transducer Production",
            "Transducer Prodcuts Issued",
            "Transducer Prodcuts Stock",
            "Electronics Current Stock",
            "Electronics Stock Recieved",
            "Electronics Items Issued",
            "Electronics Production",
            "Electronics Prodcuts Issued",
            "Electronics Prodcuts Stock",
            "Electronics Project Issued",
            "Electronics Item Return",
            "Electronics Stock Adjusted",
            "Transducer Project Issued",
            "Transducer Item Return",
            "Transducer Stock Adjusted",
            "Electronics Item Usage",
            "Transducer Item Usage",
            "Electronics Inventory Grading",
            "Transducer Inventory Grading"});
            this.cmbReport.Location = new System.Drawing.Point(134, 12);
            this.cmbReport.Name = "cmbReport";
            this.cmbReport.Size = new System.Drawing.Size(343, 27);
            this.cmbReport.TabIndex = 35;
            this.cmbReport.SelectedIndexChanged += new System.EventHandler(this.cmbReport_SelectedIndexChanged);
            // 
            // lblFromdate
            // 
            this.lblFromdate.AutoSize = true;
            this.lblFromdate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFromdate.Location = new System.Drawing.Point(13, 12);
            this.lblFromdate.Name = "lblFromdate";
            this.lblFromdate.Size = new System.Drawing.Size(52, 19);
            this.lblFromdate.TabIndex = 4;
            this.lblFromdate.Text = "From :";
            // 
            // dtpFromDate
            // 
            this.dtpFromDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFromDate.Location = new System.Drawing.Point(65, 6);
            this.dtpFromDate.Name = "dtpFromDate";
            this.dtpFromDate.Size = new System.Drawing.Size(94, 27);
            this.dtpFromDate.TabIndex = 9;
            // 
            // dptToDate
            // 
            this.dptToDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dptToDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dptToDate.Location = new System.Drawing.Point(200, 6);
            this.dptToDate.Name = "dptToDate";
            this.dptToDate.Size = new System.Drawing.Size(95, 27);
            this.dptToDate.TabIndex = 10;
            // 
            // lblTables
            // 
            this.lblTables.AutoSize = true;
            this.lblTables.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTables.Location = new System.Drawing.Point(6, 13);
            this.lblTables.Name = "lblTables";
            this.lblTables.Size = new System.Drawing.Size(122, 22);
            this.lblTables.TabIndex = 33;
            this.lblTables.Text = "Report Type :";
            // 
            // btnexcelreport
            // 
            this.btnexcelreport.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexcelreport.Location = new System.Drawing.Point(570, 52);
            this.btnexcelreport.Name = "btnexcelreport";
            this.btnexcelreport.Size = new System.Drawing.Size(111, 33);
            this.btnexcelreport.TabIndex = 36;
            this.btnexcelreport.Text = "Excel Report";
            this.btnexcelreport.UseVisualStyleBackColor = true;
            this.btnexcelreport.Click += new System.EventHandler(this.btnexcelreport_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(164, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 19);
            this.label1.TabIndex = 11;
            this.label1.Text = "To :";
            // 
            // pnGenaralPanel
            // 
            this.pnGenaralPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnGenaralPanel.Controls.Add(this.label1);
            this.pnGenaralPanel.Controls.Add(this.lblFromdate);
            this.pnGenaralPanel.Controls.Add(this.dtpFromDate);
            this.pnGenaralPanel.Controls.Add(this.dptToDate);
            this.pnGenaralPanel.Location = new System.Drawing.Point(149, 44);
            this.pnGenaralPanel.Name = "pnGenaralPanel";
            this.pnGenaralPanel.Size = new System.Drawing.Size(306, 44);
            this.pnGenaralPanel.TabIndex = 34;
            this.pnGenaralPanel.Visible = false;
            // 
            // dgvReportView
            // 
            this.dgvReportView.AllowUserToAddRows = false;
            this.dgvReportView.AllowUserToDeleteRows = false;
            this.dgvReportView.AllowUserToOrderColumns = true;
            this.dgvReportView.AllowUserToResizeRows = false;
            this.dgvReportView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvReportView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvReportView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReportView.Location = new System.Drawing.Point(12, 126);
            this.dgvReportView.Name = "dgvReportView";
            this.dgvReportView.ReadOnly = true;
            this.dgvReportView.RowHeadersVisible = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvReportView.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvReportView.Size = new System.Drawing.Size(1258, 538);
            this.dgvReportView.TabIndex = 126;
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(461, 52);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(86, 32);
            this.btnSearch.TabIndex = 127;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // lblItemcodeorName
            // 
            this.lblItemcodeorName.AutoSize = true;
            this.lblItemcodeorName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemcodeorName.ForeColor = System.Drawing.Color.Black;
            this.lblItemcodeorName.Location = new System.Drawing.Point(20, 98);
            this.lblItemcodeorName.Name = "lblItemcodeorName";
            this.lblItemcodeorName.Size = new System.Drawing.Size(63, 19);
            this.lblItemcodeorName.TabIndex = 129;
            this.lblItemcodeorName.Text = "Search :";
            // 
            // txtItemSearch
            // 
            this.txtItemSearch.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtItemSearch.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemSearch.Location = new System.Drawing.Point(89, 95);
            this.txtItemSearch.Name = "txtItemSearch";
            this.txtItemSearch.Size = new System.Drawing.Size(340, 27);
            this.txtItemSearch.TabIndex = 128;
            this.txtItemSearch.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemSearch_KeyUp);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(435, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(608, 19);
            this.label2.TabIndex = 130;
            this.label2.Text = "Search results include only item code, item  description, project code and projec" +
    "t Name";
            // 
            // pnProjectCodePanel
            // 
            this.pnProjectCodePanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnProjectCodePanel.Controls.Add(this.btnProjectView);
            this.pnProjectCodePanel.Controls.Add(this.label5);
            this.pnProjectCodePanel.Controls.Add(this.label4);
            this.pnProjectCodePanel.Controls.Add(this.label3);
            this.pnProjectCodePanel.Controls.Add(this.txtProjectCode);
            this.pnProjectCodePanel.Controls.Add(this.lblSelectedProjectCode);
            this.pnProjectCodePanel.Controls.Add(this.cmbProjectCode);
            this.pnProjectCodePanel.Controls.Add(this.lblItemDiscription);
            this.pnProjectCodePanel.Location = new System.Drawing.Point(841, -1);
            this.pnProjectCodePanel.Name = "pnProjectCodePanel";
            this.pnProjectCodePanel.Size = new System.Drawing.Size(432, 121);
            this.pnProjectCodePanel.TabIndex = 131;
            this.pnProjectCodePanel.Visible = false;
            // 
            // btnProjectView
            // 
            this.btnProjectView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnProjectView.Location = new System.Drawing.Point(406, 5);
            this.btnProjectView.Name = "btnProjectView";
            this.btnProjectView.Size = new System.Drawing.Size(24, 26);
            this.btnProjectView.TabIndex = 217;
            this.btnProjectView.Text = "....";
            this.btnProjectView.UseVisualStyleBackColor = false;
            this.btnProjectView.Click += new System.EventHandler(this.btnProjectView_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(104, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(17, 19);
            this.label5.TabIndex = 202;
            this.label5.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(10, 90);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 19);
            this.label4.TabIndex = 201;
            this.label4.Text = "Issued Cost :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(52, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 17);
            this.label3.TabIndex = 200;
            this.label3.Text = "Name :";
            // 
            // txtProjectCode
            // 
            this.txtProjectCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProjectCode.Location = new System.Drawing.Point(108, 38);
            this.txtProjectCode.Multiline = true;
            this.txtProjectCode.Name = "txtProjectCode";
            this.txtProjectCode.ReadOnly = true;
            this.txtProjectCode.Size = new System.Drawing.Size(294, 49);
            this.txtProjectCode.TabIndex = 27;
            // 
            // lblSelectedProjectCode
            // 
            this.lblSelectedProjectCode.AutoSize = true;
            this.lblSelectedProjectCode.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.lblSelectedProjectCode.Location = new System.Drawing.Point(3, 9);
            this.lblSelectedProjectCode.Name = "lblSelectedProjectCode";
            this.lblSelectedProjectCode.Size = new System.Drawing.Size(104, 19);
            this.lblSelectedProjectCode.TabIndex = 2;
            this.lblSelectedProjectCode.Text = "Project Code :";
            // 
            // cmbProjectCode
            // 
            this.cmbProjectCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProjectCode.DropDownHeight = 160;
            this.cmbProjectCode.DropDownWidth = 121;
            this.cmbProjectCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProjectCode.FormattingEnabled = true;
            this.cmbProjectCode.IntegralHeight = false;
            this.cmbProjectCode.ItemHeight = 19;
            this.cmbProjectCode.Location = new System.Drawing.Point(108, 5);
            this.cmbProjectCode.Name = "cmbProjectCode";
            this.cmbProjectCode.Size = new System.Drawing.Size(294, 27);
            this.cmbProjectCode.Sorted = true;
            this.cmbProjectCode.TabIndex = 3;
            this.cmbProjectCode.SelectedIndexChanged += new System.EventHandler(this.cmbProjectCode_SelectedIndexChanged);
            // 
            // lblItemDiscription
            // 
            this.lblItemDiscription.AutoSize = true;
            this.lblItemDiscription.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemDiscription.Location = new System.Drawing.Point(280, 14);
            this.lblItemDiscription.Name = "lblItemDiscription";
            this.lblItemDiscription.Size = new System.Drawing.Size(0, 17);
            this.lblItemDiscription.TabIndex = 15;
            // 
            // lblTotalAmount
            // 
            this.lblTotalAmount.AutoSize = true;
            this.lblTotalAmount.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.lblTotalAmount.ForeColor = System.Drawing.Color.Red;
            this.lblTotalAmount.Location = new System.Drawing.Point(109, 4);
            this.lblTotalAmount.Name = "lblTotalAmount";
            this.lblTotalAmount.Size = new System.Drawing.Size(17, 19);
            this.lblTotalAmount.TabIndex = 204;
            this.lblTotalAmount.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(2, 4);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(107, 19);
            this.label7.TabIndex = 203;
            this.label7.Text = "Total Amount :";
            // 
            // pntotalamount
            // 
            this.pntotalamount.Controls.Add(this.label7);
            this.pntotalamount.Controls.Add(this.lblTotalAmount);
            this.pntotalamount.Location = new System.Drawing.Point(502, 8);
            this.pntotalamount.Name = "pntotalamount";
            this.pntotalamount.Size = new System.Drawing.Size(288, 31);
            this.pntotalamount.TabIndex = 205;
            // 
            // pnAllyears
            // 
            this.pnAllyears.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnAllyears.Controls.Add(this.pnoneyear);
            this.pnAllyears.Controls.Add(this.label6);
            this.pnAllyears.Controls.Add(this.lblToDate);
            this.pnAllyears.Controls.Add(this.dtpItemUsage);
            this.pnAllyears.Controls.Add(this.dtp6months);
            this.pnAllyears.Location = new System.Drawing.Point(835, 0);
            this.pnAllyears.Name = "pnAllyears";
            this.pnAllyears.Size = new System.Drawing.Size(244, 119);
            this.pnAllyears.TabIndex = 206;
            this.pnAllyears.Visible = false;
            // 
            // pnoneyear
            // 
            this.pnoneyear.Controls.Add(this.dtptwelve);
            this.pnoneyear.Controls.Add(this.lblTwelveMonths);
            this.pnoneyear.Location = new System.Drawing.Point(18, 72);
            this.pnoneyear.Name = "pnoneyear";
            this.pnoneyear.Size = new System.Drawing.Size(208, 39);
            this.pnoneyear.TabIndex = 241;
            // 
            // dtptwelve
            // 
            this.dtptwelve.Enabled = false;
            this.dtptwelve.Font = new System.Drawing.Font("Times New Roman", 11.25F);
            this.dtptwelve.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtptwelve.Location = new System.Drawing.Point(88, 6);
            this.dtptwelve.Name = "dtptwelve";
            this.dtptwelve.Size = new System.Drawing.Size(112, 25);
            this.dtptwelve.TabIndex = 22;
            // 
            // lblTwelveMonths
            // 
            this.lblTwelveMonths.AutoSize = true;
            this.lblTwelveMonths.Font = new System.Drawing.Font("Times New Roman", 11.25F);
            this.lblTwelveMonths.Location = new System.Drawing.Point(3, 8);
            this.lblTwelveMonths.Name = "lblTwelveMonths";
            this.lblTwelveMonths.Size = new System.Drawing.Size(79, 17);
            this.lblTwelveMonths.TabIndex = 25;
            this.lblTwelveMonths.Text = "1 Year Date";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 11.25F);
            this.label6.Location = new System.Drawing.Point(31, 10);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 17);
            this.label6.TabIndex = 4;
            this.label6.Text = "From Date";
            // 
            // lblToDate
            // 
            this.lblToDate.Font = new System.Drawing.Font("Times New Roman", 11.25F);
            this.lblToDate.Location = new System.Drawing.Point(3, 42);
            this.lblToDate.Name = "lblToDate";
            this.lblToDate.Size = new System.Drawing.Size(100, 17);
            this.lblToDate.TabIndex = 6;
            this.lblToDate.Text = "6 Months date";
            this.lblToDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // dtpItemUsage
            // 
            this.dtpItemUsage.Font = new System.Drawing.Font("Times New Roman", 11.25F);
            this.dtpItemUsage.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpItemUsage.Location = new System.Drawing.Point(109, 4);
            this.dtpItemUsage.Name = "dtpItemUsage";
            this.dtpItemUsage.Size = new System.Drawing.Size(109, 25);
            this.dtpItemUsage.TabIndex = 9;
            this.dtpItemUsage.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // dtp6months
            // 
            this.dtp6months.Enabled = false;
            this.dtp6months.Font = new System.Drawing.Font("Times New Roman", 11.25F);
            this.dtp6months.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp6months.Location = new System.Drawing.Point(109, 41);
            this.dtp6months.Name = "dtp6months";
            this.dtp6months.Size = new System.Drawing.Size(109, 25);
            this.dtp6months.TabIndex = 10;
            // 
            // frmKanBanReports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1274, 676);
            this.Controls.Add(this.pnAllyears);
            this.Controls.Add(this.pntotalamount);
            this.Controls.Add(this.pnProjectCodePanel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblItemcodeorName);
            this.Controls.Add(this.txtItemSearch);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.dgvReportView);
            this.Controls.Add(this.btnexcelreport);
            this.Controls.Add(this.cmbReport);
            this.Controls.Add(this.pnGenaralPanel);
            this.Controls.Add(this.lblTables);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmKanBanReports";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Transducer Reports";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmKanBanReports_FormClosing);
            this.Load += new System.EventHandler(this.frmKanBanReports_Load);
            this.pnGenaralPanel.ResumeLayout(false);
            this.pnGenaralPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReportView)).EndInit();
            this.pnProjectCodePanel.ResumeLayout(false);
            this.pnProjectCodePanel.PerformLayout();
            this.pntotalamount.ResumeLayout(false);
            this.pntotalamount.PerformLayout();
            this.pnAllyears.ResumeLayout(false);
            this.pnAllyears.PerformLayout();
            this.pnoneyear.ResumeLayout(false);
            this.pnoneyear.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbReport;
        private System.Windows.Forms.Label lblFromdate;
        private System.Windows.Forms.DateTimePicker dtpFromDate;
        private System.Windows.Forms.DateTimePicker dptToDate;
        private System.Windows.Forms.Label lblTables;
        private System.Windows.Forms.Button btnexcelreport;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnGenaralPanel;
        private System.Windows.Forms.DataGridView dgvReportView;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label lblItemcodeorName;
        private System.Windows.Forms.TextBox txtItemSearch;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pnProjectCodePanel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtProjectCode;
        private System.Windows.Forms.Label lblSelectedProjectCode;
        private System.Windows.Forms.ComboBox cmbProjectCode;
        private System.Windows.Forms.Label lblItemDiscription;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnProjectView;
        private System.Windows.Forms.Label lblTotalAmount;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel pntotalamount;
        private System.Windows.Forms.Panel pnAllyears;
        private System.Windows.Forms.Panel pnoneyear;
        private System.Windows.Forms.DateTimePicker dtptwelve;
        private System.Windows.Forms.Label lblTwelveMonths;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblToDate;
        private System.Windows.Forms.DateTimePicker dtpItemUsage;
        private System.Windows.Forms.DateTimePicker dtp6months;
    }
}