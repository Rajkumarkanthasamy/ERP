﻿namespace Erp_Project_With_Buttons.KanBanProduct
{
    partial class frmElectronicsBOM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmElectronicsBOM));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnExporttoExcel = new System.Windows.Forms.Button();
            this.btnAddProduct = new System.Windows.Forms.Button();
            this.btnAddFolder = new System.Windows.Forms.Button();
            this.chkTrIssue = new System.Windows.Forms.CheckBox();
            this.btnQuoteTreeSave = new System.Windows.Forms.Button();
            this.txtName = new System.Windows.Forms.TextBox();
            this.chkEleFM = new System.Windows.Forms.CheckBox();
            this.chkProductCode = new System.Windows.Forms.CheckBox();
            this.chkProductIssue = new System.Windows.Forms.CheckBox();
            this.cleartreeview = new System.Windows.Forms.Button();
            this.txtsearchtree = new System.Windows.Forms.TextBox();
            this.btnsearchtree = new System.Windows.Forms.Button();
            this.tvProduct = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.dgItemList = new System.Windows.Forms.DataGridView();
            this.ItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uncost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.add = new System.Windows.Forms.DataGridViewButtonColumn();
            this.dgBOMList = new System.Windows.Forms.DataGridView();
            this.pnItemSearch = new System.Windows.Forms.Panel();
            this.chkItemDesc = new System.Windows.Forms.CheckBox();
            this.chkItemCode = new System.Windows.Forms.CheckBox();
            this.txtItemDescription = new System.Windows.Forms.TextBox();
            this.lblItemDescription = new System.Windows.Forms.Label();
            this.pnProductcode = new System.Windows.Forms.Panel();
            this.btnUpdateProduct = new System.Windows.Forms.Button();
            this.txtProductCost = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtProductCode = new System.Windows.Forms.TextBox();
            this.txtProductName = new System.Windows.Forms.TextBox();
            this.lblpname = new System.Windows.Forms.Label();
            this.lblpcode = new System.Windows.Forms.Label();
            this.lblIPTotalAmount = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.lblItemcodeorName = new System.Windows.Forms.Label();
            this.txtItemSearch = new System.Windows.Forms.TextBox();
            this.txtInsatallationCommision = new System.Windows.Forms.TextBox();
            this.btnAddExtra = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.uItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BOMQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AvailableQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RequiredQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Diffrence = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgItemList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgBOMList)).BeginInit();
            this.pnItemSearch.SuspendLayout();
            this.pnProductcode.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.btnExporttoExcel);
            this.panel3.Controls.Add(this.btnAddProduct);
            this.panel3.Controls.Add(this.btnAddFolder);
            this.panel3.Controls.Add(this.chkTrIssue);
            this.panel3.Controls.Add(this.btnQuoteTreeSave);
            this.panel3.Controls.Add(this.txtName);
            this.panel3.Controls.Add(this.chkEleFM);
            this.panel3.Controls.Add(this.chkProductCode);
            this.panel3.Controls.Add(this.chkProductIssue);
            this.panel3.Controls.Add(this.cleartreeview);
            this.panel3.Controls.Add(this.txtsearchtree);
            this.panel3.Controls.Add(this.btnsearchtree);
            this.panel3.Controls.Add(this.tvProduct);
            this.panel3.Location = new System.Drawing.Point(2, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(423, 680);
            this.panel3.TabIndex = 133;
            // 
            // btnExporttoExcel
            // 
            this.btnExporttoExcel.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExporttoExcel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExporttoExcel.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExporttoExcel.Location = new System.Drawing.Point(240, 638);
            this.btnExporttoExcel.Name = "btnExporttoExcel";
            this.btnExporttoExcel.Size = new System.Drawing.Size(126, 33);
            this.btnExporttoExcel.TabIndex = 202;
            this.btnExporttoExcel.Text = "Export to Excel";
            this.btnExporttoExcel.UseVisualStyleBackColor = false;
            this.btnExporttoExcel.Click += new System.EventHandler(this.btnExporttoExcel_Click);
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAddProduct.Enabled = false;
            this.btnAddProduct.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAddProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddProduct.Location = new System.Drawing.Point(140, 567);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(112, 31);
            this.btnAddProduct.TabIndex = 201;
            this.btnAddProduct.Text = "Add Product";
            this.btnAddProduct.UseVisualStyleBackColor = false;
            this.btnAddProduct.Click += new System.EventHandler(this.btnAddProduct_Click);
            // 
            // btnAddFolder
            // 
            this.btnAddFolder.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAddFolder.Enabled = false;
            this.btnAddFolder.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAddFolder.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddFolder.Location = new System.Drawing.Point(8, 567);
            this.btnAddFolder.Name = "btnAddFolder";
            this.btnAddFolder.Size = new System.Drawing.Size(116, 31);
            this.btnAddFolder.TabIndex = 200;
            this.btnAddFolder.Text = "Add Folder";
            this.btnAddFolder.UseVisualStyleBackColor = false;
            this.btnAddFolder.Click += new System.EventHandler(this.btnAddFolder_Click);
            // 
            // chkTrIssue
            // 
            this.chkTrIssue.AutoSize = true;
            this.chkTrIssue.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkTrIssue.ForeColor = System.Drawing.Color.DarkGreen;
            this.chkTrIssue.Location = new System.Drawing.Point(8, 63);
            this.chkTrIssue.Name = "chkTrIssue";
            this.chkTrIssue.Size = new System.Drawing.Size(265, 27);
            this.chkTrIssue.TabIndex = 229;
            this.chkTrIssue.Text = "Transducer Input Item Master";
            this.chkTrIssue.UseVisualStyleBackColor = true;
            this.chkTrIssue.CheckedChanged += new System.EventHandler(this.chkTrIssue_CheckedChanged);
            // 
            // btnQuoteTreeSave
            // 
            this.btnQuoteTreeSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnQuoteTreeSave.Enabled = false;
            this.btnQuoteTreeSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnQuoteTreeSave.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuoteTreeSave.Location = new System.Drawing.Point(370, 599);
            this.btnQuoteTreeSave.Name = "btnQuoteTreeSave";
            this.btnQuoteTreeSave.Size = new System.Drawing.Size(46, 33);
            this.btnQuoteTreeSave.TabIndex = 199;
            this.btnQuoteTreeSave.Text = "Save";
            this.btnQuoteTreeSave.UseVisualStyleBackColor = false;
            this.btnQuoteTreeSave.Click += new System.EventHandler(this.btnQuoteTreeSave_Click);
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(3, 604);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(361, 26);
            this.txtName.TabIndex = 198;
            this.txtName.Visible = false;
            this.txtName.Enter += new System.EventHandler(this.txtName_Enter);
            this.txtName.Leave += new System.EventHandler(this.txtName_Leave);
            // 
            // chkEleFM
            // 
            this.chkEleFM.AutoSize = true;
            this.chkEleFM.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkEleFM.ForeColor = System.Drawing.Color.DarkGreen;
            this.chkEleFM.Location = new System.Drawing.Point(8, 35);
            this.chkEleFM.Name = "chkEleFM";
            this.chkEleFM.Size = new System.Drawing.Size(290, 27);
            this.chkEleFM.TabIndex = 228;
            this.chkEleFM.Text = "Electronics Finished Item Master";
            this.chkEleFM.UseVisualStyleBackColor = true;
            this.chkEleFM.CheckedChanged += new System.EventHandler(this.chkEleFM_CheckedChanged);
            // 
            // chkProductCode
            // 
            this.chkProductCode.AutoSize = true;
            this.chkProductCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.chkProductCode.Location = new System.Drawing.Point(8, 129);
            this.chkProductCode.Name = "chkProductCode";
            this.chkProductCode.Size = new System.Drawing.Size(121, 23);
            this.chkProductCode.TabIndex = 134;
            this.chkProductCode.Text = "Product Code";
            this.chkProductCode.UseVisualStyleBackColor = true;
            // 
            // chkProductIssue
            // 
            this.chkProductIssue.AutoSize = true;
            this.chkProductIssue.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkProductIssue.ForeColor = System.Drawing.Color.DarkGreen;
            this.chkProductIssue.Location = new System.Drawing.Point(8, 6);
            this.chkProductIssue.Name = "chkProductIssue";
            this.chkProductIssue.Size = new System.Drawing.Size(265, 27);
            this.chkProductIssue.TabIndex = 227;
            this.chkProductIssue.Text = "Electronics Input Item Master";
            this.chkProductIssue.UseVisualStyleBackColor = true;
            this.chkProductIssue.CheckedChanged += new System.EventHandler(this.chkProductIssue_CheckedChanged);
            // 
            // cleartreeview
            // 
            this.cleartreeview.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cleartreeview.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.cleartreeview.Location = new System.Drawing.Point(355, 125);
            this.cleartreeview.Name = "cleartreeview";
            this.cleartreeview.Size = new System.Drawing.Size(61, 29);
            this.cleartreeview.TabIndex = 131;
            this.cleartreeview.Text = "Clear";
            this.cleartreeview.UseVisualStyleBackColor = true;
            // 
            // txtsearchtree
            // 
            this.txtsearchtree.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsearchtree.Location = new System.Drawing.Point(8, 96);
            this.txtsearchtree.Name = "txtsearchtree";
            this.txtsearchtree.Size = new System.Drawing.Size(408, 27);
            this.txtsearchtree.TabIndex = 130;
            // 
            // btnsearchtree
            // 
            this.btnsearchtree.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearchtree.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnsearchtree.Location = new System.Drawing.Point(282, 125);
            this.btnsearchtree.Name = "btnsearchtree";
            this.btnsearchtree.Size = new System.Drawing.Size(67, 29);
            this.btnsearchtree.TabIndex = 129;
            this.btnsearchtree.Text = "Search";
            this.btnsearchtree.UseVisualStyleBackColor = true;
            this.btnsearchtree.Click += new System.EventHandler(this.btnsearchtree_Click);
            // 
            // tvProduct
            // 
            this.tvProduct.Cursor = System.Windows.Forms.Cursors.Default;
            this.tvProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tvProduct.HideSelection = false;
            this.tvProduct.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.tvProduct.Location = new System.Drawing.Point(3, 157);
            this.tvProduct.Name = "tvProduct";
            this.tvProduct.Size = new System.Drawing.Size(413, 404);
            this.tvProduct.StateImageList = this.imageList1;
            this.tvProduct.TabIndex = 9;
            this.tvProduct.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.tvProduct_NodeMouseClick);
            this.tvProduct.KeyUp += new System.Windows.Forms.KeyEventHandler(this.tvProduct_KeyUp);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "folderopened_yellow.ico");
            this.imageList1.Images.SetKeyName(1, "diagram_v2_17.ico");
            this.imageList1.Images.SetKeyName(2, "Dryicons-Aesthetica-2-Process-accept.ico");
            this.imageList1.Images.SetKeyName(3, "Dryicons-Aesthetica-2-Process-remove.ico");
            this.imageList1.Images.SetKeyName(4, "Rafiqul-Hassan-Blogger-Settings.ico");
            // 
            // dgItemList
            // 
            this.dgItemList.AllowUserToAddRows = false;
            this.dgItemList.AllowUserToDeleteRows = false;
            this.dgItemList.AllowUserToResizeRows = false;
            this.dgItemList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgItemList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgItemList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgItemList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgItemList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgItemList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ItemCode,
            this.ItemDescription,
            this.Quantity,
            this.uncost,
            this.add});
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.ControlLightLight;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgItemList.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgItemList.EnableHeadersVisualStyles = false;
            this.dgItemList.Location = new System.Drawing.Point(431, 150);
            this.dgItemList.MultiSelect = false;
            this.dgItemList.Name = "dgItemList";
            this.dgItemList.RowHeadersVisible = false;
            this.dgItemList.Size = new System.Drawing.Size(866, 191);
            this.dgItemList.TabIndex = 139;
            this.dgItemList.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgItemList_CellBeginEdit);
            this.dgItemList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgItemList_CellClick);
            this.dgItemList.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgItemList_CellEndEdit);
            this.dgItemList.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgItemList_EditingControlShowing);
            // 
            // ItemCode
            // 
            this.ItemCode.DataPropertyName = "ItemCode";
            this.ItemCode.HeaderText = "Item Code";
            this.ItemCode.Name = "ItemCode";
            this.ItemCode.ReadOnly = true;
            this.ItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemCode.Width = 81;
            // 
            // ItemDescription
            // 
            this.ItemDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ItemDescription.DataPropertyName = "ItemDescription";
            this.ItemDescription.HeaderText = "Item Desc";
            this.ItemDescription.Name = "ItemDescription";
            this.ItemDescription.ReadOnly = true;
            this.ItemDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemDescription.Width = 84;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "Qty";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle2.NullValue = null;
            this.Quantity.DefaultCellStyle = dataGridViewCellStyle2;
            this.Quantity.HeaderText = "Qty";
            this.Quantity.Name = "Quantity";
            this.Quantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Quantity.Width = 38;
            // 
            // uncost
            // 
            this.uncost.DataPropertyName = "UnitCost";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.uncost.DefaultCellStyle = dataGridViewCellStyle3;
            this.uncost.HeaderText = "UnitCost";
            this.uncost.Name = "uncost";
            this.uncost.ReadOnly = true;
            this.uncost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.uncost.Width = 71;
            // 
            // add
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.add.DefaultCellStyle = dataGridViewCellStyle4;
            this.add.HeaderText = "Add";
            this.add.Name = "add";
            this.add.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.add.Width = 40;
            // 
            // dgBOMList
            // 
            this.dgBOMList.AllowUserToAddRows = false;
            this.dgBOMList.AllowUserToDeleteRows = false;
            this.dgBOMList.AllowUserToResizeRows = false;
            this.dgBOMList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgBOMList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgBOMList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgBOMList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgBOMList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgBOMList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.uItemCode,
            this.uItemDescription,
            this.BOMQuantity,
            this.UnitCost,
            this.Amount,
            this.AvailableQty,
            this.RequiredQty,
            this.Diffrence});
            this.dgBOMList.EnableHeadersVisualStyles = false;
            this.dgBOMList.Location = new System.Drawing.Point(431, 380);
            this.dgBOMList.MultiSelect = false;
            this.dgBOMList.Name = "dgBOMList";
            this.dgBOMList.RowHeadersVisible = false;
            this.dgBOMList.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgBOMList.Size = new System.Drawing.Size(866, 304);
            this.dgBOMList.TabIndex = 138;
            this.dgBOMList.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgBOMList_CellBeginEdit);
            this.dgBOMList.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgBOMList_CellEndEdit);
            this.dgBOMList.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgBOMList_EditingControlShowing);
            this.dgBOMList.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgBOMList_KeyUp);
            // 
            // pnItemSearch
            // 
            this.pnItemSearch.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnItemSearch.Controls.Add(this.chkItemDesc);
            this.pnItemSearch.Controls.Add(this.chkItemCode);
            this.pnItemSearch.Controls.Add(this.txtItemDescription);
            this.pnItemSearch.Controls.Add(this.lblItemDescription);
            this.pnItemSearch.Location = new System.Drawing.Point(431, 115);
            this.pnItemSearch.Name = "pnItemSearch";
            this.pnItemSearch.Size = new System.Drawing.Size(866, 32);
            this.pnItemSearch.TabIndex = 140;
            // 
            // chkItemDesc
            // 
            this.chkItemDesc.AutoSize = true;
            this.chkItemDesc.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemDesc.ForeColor = System.Drawing.Color.Black;
            this.chkItemDesc.Location = new System.Drawing.Point(223, 4);
            this.chkItemDesc.Name = "chkItemDesc";
            this.chkItemDesc.Size = new System.Drawing.Size(140, 23);
            this.chkItemDesc.TabIndex = 213;
            this.chkItemDesc.Text = "Item Description";
            this.chkItemDesc.UseVisualStyleBackColor = true;
            this.chkItemDesc.CheckedChanged += new System.EventHandler(this.chkItemDesc_CheckedChanged);
            // 
            // chkItemCode
            // 
            this.chkItemCode.AutoSize = true;
            this.chkItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemCode.ForeColor = System.Drawing.Color.Black;
            this.chkItemCode.Location = new System.Drawing.Point(120, 3);
            this.chkItemCode.Name = "chkItemCode";
            this.chkItemCode.Size = new System.Drawing.Size(97, 23);
            this.chkItemCode.TabIndex = 212;
            this.chkItemCode.Text = "Item Code";
            this.chkItemCode.UseVisualStyleBackColor = true;
            this.chkItemCode.CheckedChanged += new System.EventHandler(this.chkItemCode_CheckedChanged);
            // 
            // txtItemDescription
            // 
            this.txtItemDescription.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemDescription.Location = new System.Drawing.Point(369, 3);
            this.txtItemDescription.Name = "txtItemDescription";
            this.txtItemDescription.Size = new System.Drawing.Size(490, 23);
            this.txtItemDescription.TabIndex = 3;
            this.txtItemDescription.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtItemDescription_MouseClick);
            this.txtItemDescription.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtItemDescription_KeyPress);
            this.txtItemDescription.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemDescription_KeyUp);
            // 
            // lblItemDescription
            // 
            this.lblItemDescription.AutoSize = true;
            this.lblItemDescription.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemDescription.ForeColor = System.Drawing.Color.Black;
            this.lblItemDescription.Location = new System.Drawing.Point(3, 3);
            this.lblItemDescription.Name = "lblItemDescription";
            this.lblItemDescription.Size = new System.Drawing.Size(111, 19);
            this.lblItemDescription.TabIndex = 2;
            this.lblItemDescription.Text = "Search Item by";
            // 
            // pnProductcode
            // 
            this.pnProductcode.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnProductcode.Controls.Add(this.btnUpdateProduct);
            this.pnProductcode.Controls.Add(this.txtProductCost);
            this.pnProductcode.Controls.Add(this.label2);
            this.pnProductcode.Controls.Add(this.txtProductCode);
            this.pnProductcode.Controls.Add(this.txtProductName);
            this.pnProductcode.Controls.Add(this.lblpname);
            this.pnProductcode.Controls.Add(this.lblpcode);
            this.pnProductcode.Location = new System.Drawing.Point(431, 7);
            this.pnProductcode.Name = "pnProductcode";
            this.pnProductcode.Size = new System.Drawing.Size(861, 103);
            this.pnProductcode.TabIndex = 141;
            // 
            // btnUpdateProduct
            // 
            this.btnUpdateProduct.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateProduct.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnUpdateProduct.Location = new System.Drawing.Point(757, 55);
            this.btnUpdateProduct.Name = "btnUpdateProduct";
            this.btnUpdateProduct.Size = new System.Drawing.Size(97, 38);
            this.btnUpdateProduct.TabIndex = 75;
            this.btnUpdateProduct.Text = "Update";
            this.btnUpdateProduct.UseVisualStyleBackColor = true;
            this.btnUpdateProduct.Click += new System.EventHandler(this.btnUpdateProduct_Click);
            // 
            // txtProductCost
            // 
            this.txtProductCost.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProductCost.Location = new System.Drawing.Point(487, 7);
            this.txtProductCost.MaxLength = 14;
            this.txtProductCost.Name = "txtProductCost";
            this.txtProductCost.Size = new System.Drawing.Size(220, 27);
            this.txtProductCost.TabIndex = 74;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(375, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 19);
            this.label2.TabIndex = 73;
            this.label2.Text = "Product Price:";
            // 
            // txtProductCode
            // 
            this.txtProductCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProductCode.Location = new System.Drawing.Point(149, 7);
            this.txtProductCode.MaxLength = 25;
            this.txtProductCode.Name = "txtProductCode";
            this.txtProductCode.Size = new System.Drawing.Size(220, 27);
            this.txtProductCode.TabIndex = 70;
            // 
            // txtProductName
            // 
            this.txtProductName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProductName.Location = new System.Drawing.Point(149, 40);
            this.txtProductName.MaxLength = 150;
            this.txtProductName.Multiline = true;
            this.txtProductName.Name = "txtProductName";
            this.txtProductName.Size = new System.Drawing.Size(558, 53);
            this.txtProductName.TabIndex = 69;
            // 
            // lblpname
            // 
            this.lblpname.AutoSize = true;
            this.lblpname.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpname.ForeColor = System.Drawing.Color.Black;
            this.lblpname.Location = new System.Drawing.Point(31, 43);
            this.lblpname.Name = "lblpname";
            this.lblpname.Size = new System.Drawing.Size(112, 19);
            this.lblpname.TabIndex = 64;
            this.lblpname.Text = "Product Name:";
            // 
            // lblpcode
            // 
            this.lblpcode.AutoSize = true;
            this.lblpcode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpcode.ForeColor = System.Drawing.Color.Black;
            this.lblpcode.Location = new System.Drawing.Point(39, 11);
            this.lblpcode.Name = "lblpcode";
            this.lblpcode.Size = new System.Drawing.Size(106, 19);
            this.lblpcode.TabIndex = 65;
            this.lblpcode.Text = "Product Code:";
            // 
            // lblIPTotalAmount
            // 
            this.lblIPTotalAmount.AutoSize = true;
            this.lblIPTotalAmount.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblIPTotalAmount.ForeColor = System.Drawing.Color.Black;
            this.lblIPTotalAmount.Location = new System.Drawing.Point(1205, 351);
            this.lblIPTotalAmount.Name = "lblIPTotalAmount";
            this.lblIPTotalAmount.Size = new System.Drawing.Size(17, 19);
            this.lblIPTotalAmount.TabIndex = 203;
            this.lblIPTotalAmount.Text = "0";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(1097, 350);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(111, 19);
            this.label19.TabIndex = 202;
            this.label19.Text = "Total Amount :";
            // 
            // lblItemcodeorName
            // 
            this.lblItemcodeorName.AutoSize = true;
            this.lblItemcodeorName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemcodeorName.ForeColor = System.Drawing.Color.Black;
            this.lblItemcodeorName.Location = new System.Drawing.Point(424, 350);
            this.lblItemcodeorName.Name = "lblItemcodeorName";
            this.lblItemcodeorName.Size = new System.Drawing.Size(63, 19);
            this.lblItemcodeorName.TabIndex = 231;
            this.lblItemcodeorName.Text = "Search :";
            // 
            // txtItemSearch
            // 
            this.txtItemSearch.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtItemSearch.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemSearch.Location = new System.Drawing.Point(493, 347);
            this.txtItemSearch.Name = "txtItemSearch";
            this.txtItemSearch.Size = new System.Drawing.Size(340, 27);
            this.txtItemSearch.TabIndex = 230;
            this.txtItemSearch.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemSearch_KeyUp);
            // 
            // txtInsatallationCommision
            // 
            this.txtInsatallationCommision.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtInsatallationCommision.Location = new System.Drawing.Point(961, 350);
            this.txtInsatallationCommision.Name = "txtInsatallationCommision";
            this.txtInsatallationCommision.Size = new System.Drawing.Size(59, 26);
            this.txtInsatallationCommision.TabIndex = 234;
            this.txtInsatallationCommision.Text = "0";
            // 
            // btnAddExtra
            // 
            this.btnAddExtra.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAddExtra.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnAddExtra.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAddExtra.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddExtra.Location = new System.Drawing.Point(1026, 345);
            this.btnAddExtra.Name = "btnAddExtra";
            this.btnAddExtra.Size = new System.Drawing.Size(64, 31);
            this.btnAddExtra.TabIndex = 233;
            this.btnAddExtra.Text = "Check";
            this.btnAddExtra.UseVisualStyleBackColor = false;
            this.btnAddExtra.Click += new System.EventHandler(this.btnAddExtra_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(851, 351);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 19);
            this.label1.TabIndex = 232;
            this.label1.Text = "O/P Quantity :";
            // 
            // uItemCode
            // 
            this.uItemCode.DataPropertyName = "ItemCode";
            this.uItemCode.HeaderText = "Item Code";
            this.uItemCode.Name = "uItemCode";
            this.uItemCode.ReadOnly = true;
            this.uItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.uItemCode.Width = 81;
            // 
            // uItemDescription
            // 
            this.uItemDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.uItemDescription.DataPropertyName = "ItemDescription";
            this.uItemDescription.HeaderText = "Item Desc";
            this.uItemDescription.Name = "uItemDescription";
            this.uItemDescription.ReadOnly = true;
            this.uItemDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.uItemDescription.Width = 84;
            // 
            // BOMQuantity
            // 
            this.BOMQuantity.DataPropertyName = "Quantity";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle7.NullValue = "0";
            this.BOMQuantity.DefaultCellStyle = dataGridViewCellStyle7;
            this.BOMQuantity.HeaderText = "Quantity";
            this.BOMQuantity.Name = "BOMQuantity";
            this.BOMQuantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.BOMQuantity.Width = 71;
            // 
            // UnitCost
            // 
            this.UnitCost.DataPropertyName = "UnitCost";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.Format = "N2";
            dataGridViewCellStyle8.NullValue = null;
            this.UnitCost.DefaultCellStyle = dataGridViewCellStyle8;
            this.UnitCost.HeaderText = "Unit Cost";
            this.UnitCost.Name = "UnitCost";
            this.UnitCost.ReadOnly = true;
            this.UnitCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitCost.Width = 75;
            // 
            // Amount
            // 
            this.Amount.DataPropertyName = "Amount";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.Format = "N2";
            dataGridViewCellStyle9.NullValue = null;
            this.Amount.DefaultCellStyle = dataGridViewCellStyle9;
            this.Amount.HeaderText = "Amount";
            this.Amount.Name = "Amount";
            this.Amount.ReadOnly = true;
            this.Amount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Amount.Width = 65;
            // 
            // AvailableQty
            // 
            this.AvailableQty.DataPropertyName = "AvailableQty";
            this.AvailableQty.HeaderText = "AvailableQty";
            this.AvailableQty.Name = "AvailableQty";
            this.AvailableQty.ReadOnly = true;
            this.AvailableQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.AvailableQty.Width = 98;
            // 
            // RequiredQty
            // 
            this.RequiredQty.DataPropertyName = "RequiredQty";
            dataGridViewCellStyle10.Format = "N2";
            this.RequiredQty.DefaultCellStyle = dataGridViewCellStyle10;
            this.RequiredQty.HeaderText = "RequiredQty";
            this.RequiredQty.Name = "RequiredQty";
            this.RequiredQty.ReadOnly = true;
            this.RequiredQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RequiredQty.Width = 96;
            // 
            // Diffrence
            // 
            this.Diffrence.DataPropertyName = "Diffrence";
            dataGridViewCellStyle11.Format = "N2";
            this.Diffrence.DefaultCellStyle = dataGridViewCellStyle11;
            this.Diffrence.HeaderText = "Stock Diffrence";
            this.Diffrence.Name = "Diffrence";
            this.Diffrence.ReadOnly = true;
            this.Diffrence.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Diffrence.Width = 112;
            // 
            // frmElectronicsBOM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1299, 688);
            this.Controls.Add(this.txtInsatallationCommision);
            this.Controls.Add(this.btnAddExtra);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblItemcodeorName);
            this.Controls.Add(this.txtItemSearch);
            this.Controls.Add(this.lblIPTotalAmount);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.pnProductcode);
            this.Controls.Add(this.pnItemSearch);
            this.Controls.Add(this.dgItemList);
            this.Controls.Add(this.dgBOMList);
            this.Controls.Add(this.panel3);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmElectronicsBOM";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Electronics BOM";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmElectronicsBOM_FormClosing);
            this.Load += new System.EventHandler(this.frmElectronicsBOM_Load);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgItemList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgBOMList)).EndInit();
            this.pnItemSearch.ResumeLayout(false);
            this.pnItemSearch.PerformLayout();
            this.pnProductcode.ResumeLayout(false);
            this.pnProductcode.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnAddProduct;
        private System.Windows.Forms.Button btnAddFolder;
        private System.Windows.Forms.Button btnQuoteTreeSave;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.CheckBox chkProductCode;
        private System.Windows.Forms.Button cleartreeview;
        private System.Windows.Forms.TextBox txtsearchtree;
        private System.Windows.Forms.Button btnsearchtree;
        private System.Windows.Forms.TreeView tvProduct;
        private System.Windows.Forms.DataGridView dgItemList;
        private System.Windows.Forms.DataGridView dgBOMList;
        private System.Windows.Forms.Panel pnItemSearch;
        private System.Windows.Forms.CheckBox chkItemDesc;
        private System.Windows.Forms.CheckBox chkItemCode;
        private System.Windows.Forms.TextBox txtItemDescription;
        private System.Windows.Forms.Label lblItemDescription;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Panel pnProductcode;
        private System.Windows.Forms.Button btnUpdateProduct;
        private System.Windows.Forms.TextBox txtProductCost;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtProductCode;
        private System.Windows.Forms.TextBox txtProductName;
        private System.Windows.Forms.Label lblpname;
        private System.Windows.Forms.Label lblpcode;
        private System.Windows.Forms.CheckBox chkEleFM;
        private System.Windows.Forms.CheckBox chkProductIssue;
        private System.Windows.Forms.CheckBox chkTrIssue;
        private System.Windows.Forms.Label lblIPTotalAmount;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label lblItemcodeorName;
        private System.Windows.Forms.TextBox txtItemSearch;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn uncost;
        private System.Windows.Forms.DataGridViewButtonColumn add;
        private System.Windows.Forms.Button btnExporttoExcel;
        private System.Windows.Forms.TextBox txtInsatallationCommision;
        private System.Windows.Forms.Button btnAddExtra;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn uItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn uItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn BOMQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn AvailableQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn RequiredQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn Diffrence;
    }
}