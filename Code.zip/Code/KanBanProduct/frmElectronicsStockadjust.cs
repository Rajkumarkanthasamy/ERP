﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.KanBanProduct
{
    public partial class frmElectronicsStockadjust : Form
    {
        public frmElectronicsStockadjust()
        {
            InitializeComponent();
        }
        frmForm2 Home = new frmForm2();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        Global GlobalClass = new Global();
        DataTable dtProjectList = new DataTable();
        DataView dvItemList = new DataView();
        DataTable dtItemList = new DataTable();

        private void RowFilter()
        {
            chklbItemList.Items.Clear();
            foreach (DataRowView dv in dvItemList)
            {
                chklbItemList.Items.Add(string.Concat(dv["ID"].ToString(), ") ", dv["ItemCode"].ToString(), ", ", dv["ItemDescription"].ToString(), ", ", dv["AvailableQty"].ToString()));
            }
        }

        private void frmElectronicsStockadjust_Load(object sender, EventArgs e)
        {

        }

        private void txtItemDescription_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar == '%' || e.KeyChar == '['))
            {
                e.Handled = true;
            }
        }

        private void txtItemDescription_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GlobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);
                    RowFilter();

                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GlobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
                    RowFilter();
                }
            }
            else
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GlobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);
                    RowFilter();
                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GlobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
                    RowFilter();
                }
            }
        }
        string[] sItemCode;
        DataTable dtItemcode = new DataTable();
        DataTable dtItemAdd = new DataTable();
        private void chklbItemList_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            try
            {
                int i = 0;
                if (chkProductIssue.Checked)
                {
                    sItemCode = chklbItemList.SelectedItem.ToString().Trim().Split(')');
                    string sID = sItemCode[0];
                    dtItemcode = DAL.fnKanBanElectronicsFGItemList(1, sID).Tables[0];
                    if (dtItemcode.Rows.Count > 0)
                    {
                        if (!chklbItemList.CheckedItems.Contains(chklbItemList.SelectedItem))
                        {
                            foreach (DataGridViewRow DGVR in dgIndentList.Rows)
                            {
                                if (DGVR.Cells["ItemCode"].Value.ToString().Equals(dtItemcode.Rows[0]["ItemCode"].ToString()))
                                {
                                    i = 1;
                                    break;
                                }
                            }
                            if (i != 1)
                            {
                                if (dtItemAdd.Rows.Count == 0)
                                {
                                    dtItemAdd = DAL.fnKanBanElectronicsFGItemList(1, "-9").Tables[0];
                                }

                                dtItemAdd.Rows.Add(dtItemcode.Rows[0]["ItemCode"].ToString(), dtItemcode.Rows[0]["ItemDescription"].ToString(),
                                                   dtItemcode.Rows[0]["Units"].ToString(), Convert.ToDouble(dtItemcode.Rows[0]["AvailableQty"].ToString()), dtItemcode.Rows[0]["UnitCost"].ToString(), dtItemcode.Rows[0]["ReqQty"].ToString());

                                dgIndentList.AutoGenerateColumns = false;
                                dgIndentList.DataSource = dtItemAdd;

                            }
                            else
                            {
                                MessageBox.Show("Selected Item already present in the list", "Error", 0, MessageBoxIcon.Error);
                                int k = chklbItemList.SelectedIndex;
                                chklbItemList.SetItemCheckState(k, CheckState.Unchecked);
                            }

                            foreach (DataGridViewRow dgr in dgIndentList.Rows)
                            {
                                if (Convert.ToDouble(dgr.Cells["AvailableQty"].Value) == Convert.ToDouble("0"))
                                {
                                    dgr.DefaultCellStyle.BackColor = Color.Red;
                                }
                            }
                        }
                        else
                        {
                            int rowIndex = -1;
                            bool bSelected;

                            foreach (DataGridViewRow row in dgIndentList.Rows)
                            {
                                bSelected = (row.Cells["ItemCode"].Value.ToString().Equals(dtItemcode.Rows[0]["ItemCode"].ToString()));
                                if (bSelected == true)
                                {
                                    rowIndex = row.Index;
                                    dgIndentList.Rows.Remove(dgIndentList.Rows[rowIndex]);
                                    break;
                                }
                            }
                        }
                    }
                }
                else if (chkRawMaterailIssue.Checked)
                {
                    sItemCode = chklbItemList.SelectedItem.ToString().Trim().Split(')');
                    string sID = sItemCode[0];
                    dtItemcode = DAL.fnKanBanElectronicsFGItemList(2, sID).Tables[0];
                    if (dtItemcode.Rows.Count > 0)
                    {
                        if (!chklbItemList.CheckedItems.Contains(chklbItemList.SelectedItem))
                        {
                            foreach (DataGridViewRow DGVR in dgIndentList.Rows)
                            {
                                if (DGVR.Cells["ItemCode"].Value.ToString().Equals(dtItemcode.Rows[0]["ItemCode"].ToString()))
                                {
                                    i = 1;
                                    break;
                                }
                            }
                            if (i != 1)
                            {
                                if (dtItemAdd.Rows.Count == 0)
                                {
                                    dtItemAdd = DAL.fnKanBanElectronicsFGItemList(2, "-9").Tables[0];
                                }

                                dtItemAdd.Rows.Add(dtItemcode.Rows[0]["ItemCode"].ToString(), dtItemcode.Rows[0]["ItemDescription"].ToString(),
                                                   dtItemcode.Rows[0]["Units"].ToString(), Convert.ToDouble(dtItemcode.Rows[0]["AvailableQty"].ToString()), dtItemcode.Rows[0]["UnitCost"].ToString(), dtItemcode.Rows[0]["ReqQty"].ToString());

                                dgIndentList.AutoGenerateColumns = false;
                                dgIndentList.DataSource = dtItemAdd;

                            }
                            else
                            {
                                MessageBox.Show("Selected Item already present in the list", "Error", 0, MessageBoxIcon.Error);
                                int k = chklbItemList.SelectedIndex;
                                chklbItemList.SetItemCheckState(k, CheckState.Unchecked);
                            }

                            foreach (DataGridViewRow dgr in dgIndentList.Rows)
                            {
                                if (Convert.ToDouble(dgr.Cells["AvailableQty"].Value) == Convert.ToDouble("0"))
                                {
                                    dgr.DefaultCellStyle.BackColor = Color.Red;
                                }
                            }
                        }
                        else
                        {
                            int rowIndex = -1;
                            bool bSelected;

                            foreach (DataGridViewRow row in dgIndentList.Rows)
                            {
                                bSelected = (row.Cells["ItemCode"].Value.ToString().Equals(dtItemcode.Rows[0]["ItemCode"].ToString()));
                                if (bSelected == true)
                                {
                                    rowIndex = row.Index;
                                    dgIndentList.Rows.Remove(dgIndentList.Rows[rowIndex]);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("PurchaseOrder_chklbItemList_ItemCheck" + ex.Message);
            }
        }

        private void fnExit()
        {
            this.Hide();
            Home.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            fnExit();
        }

        private void chkProductIssue_CheckedChanged(object sender, EventArgs e)
        {
            if (chkProductIssue.Checked)
            {
                chkRawMaterailIssue.Enabled = false;
                chkRawMaterailIssue.Checked = false;
                dtItemList.Rows.Clear();
                dtItemList = DAL.fnKanBanElectronicsFGItemList(0, null).Tables[0];
                RowFilter();
            }
        }

        private void chkRawMaterailIssue_CheckedChanged(object sender, EventArgs e)
        {
            if (chkRawMaterailIssue.Checked)
            {
                chkProductIssue.Enabled = false;
                chkProductIssue.Checked = false;
                dtItemList.Rows.Clear();
                dtItemList = DAL.fnKanBanElectronicsRawItemList(null).Tables[0];
                RowFilter();
            }
        }

        private void chkItemCode_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemCode.Checked)
            {
                chkItemDesc.Checked = false;
            }
        }

        private void chkItemDesc_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemDesc.Checked)
            {
                chkItemCode.Checked = false;
            }
        }

        private void frmElectronicsStockadjust_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnExit();
        }
        double oldvalue;
        private void dgIndentList_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            oldvalue = Convert.ToDouble(dgIndentList.CurrentCell.Value);
        }

        private void dgIndentList_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if ((dgIndentList.CurrentCell.Value != null) && (dgIndentList.CurrentCell.Value.ToString() != "."))
            {
                dgIndentList.CurrentRow.Cells[5].Value = (Convert.ToDouble(dgIndentList.CurrentRow.Cells[4].Value) - Convert.ToDouble(dgIndentList.CurrentRow.Cells[3].Value)).ToString();
            }
            else
            {
                MessageBox.Show("Enter a Valid Value", "Error", 0, MessageBoxIcon.Error);
                dgIndentList.CurrentCell.Value = oldvalue;
            }
        }

        private void Control_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                e.Handled = true;
            }
        }

        private void dgIndentList_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
            }
        }
        DataTable dtTransNo = new DataTable();
        string sKanProductNo;
        string sNewProduct;
        int iLastPONo;
        private void btnSave_Click(object sender, EventArgs e)
        {
            bool bNullValuecheck = false;
            foreach (DataGridViewRow row in dgIndentList.Rows)
            {
                if ((row.Cells[4].Value) == null)
                {                  
                    bNullValuecheck = true;
                    break;
                }
            }
            if (!bNullValuecheck && !string.IsNullOrEmpty(txtRemarks.Text))
            {
                dtTransNo = DAL.KANElectronicsProductNo(3, null).Tables[0];
                if (dtTransNo.Rows.Count > 0)
                {
                    sKanProductNo = dtTransNo.Rows[0][1].ToString();
                    sNewProduct = sKanProductNo.Substring(03, 08);
                    iLastPONo = Convert.ToInt32(sNewProduct);
                    iLastPONo++;
                    sKanProductNo = "ESA" + iLastPONo;
                }
                else
                {
                    sKanProductNo = "ESA20200001";
                }

                foreach (DataGridViewRow row in dgIndentList.Rows)
                {
                    GlobalClass.iSuccess = DAL.fnStockAdjustElectronicsItems(0, row.Cells[0].Value.ToString(), row.Cells[2].Value.ToString(), Convert.ToDouble(row.Cells[5].Value.ToString()),
                          dtpReturndate.Text, login.GetUserDetails[2], sKanProductNo, txtRemarks.Text);

                   

                    if (chkRawMaterailIssue.Checked)
                    {
                        GlobalClass.iSuccess = DAL.fnUpdateKanaBanElectronicsItemDetails(1, Convert.ToDouble(row.Cells[5].Value.ToString()), row.Cells[0].Value.ToString());
                        GlobalClass.iSuccess = DAL.fnUpdateKanaBanElectronicsItemDetails(2, Convert.ToDouble(row.Cells[5].Value.ToString()), row.Cells[0].Value.ToString());
                    }
                    else if (chkProductIssue.Checked)
                    {
                        GlobalClass.iSuccess = DAL.fnUpdateKanaBanElectronicsItemDetails(4, Convert.ToDouble(row.Cells[5].Value.ToString()), row.Cells[0].Value.ToString());
                        GlobalClass.iSuccess = DAL.fnUpdateKanaBanElectronicsItemDetails(5, Convert.ToDouble(row.Cells[5].Value.ToString()), row.Cells[0].Value.ToString());
                    }
                }

                GlobalClass.iSuccess = DAL.fnAddERPLog(0, sKanProductNo, login.GetUserDetails[2], dtpReturndate.Text, "KanBanElectronics Stock Adjust", "KanBanElectronicsItemStockAdjust");

                MessageBox.Show("Items stock successfully adjusted", "Success", 0, MessageBoxIcon.Information);
                KanBanProduct.frmElectronicsStockadjust ESA = new frmElectronicsStockadjust();
                this.Hide();
                ESA.Show();
            }
            else
            {
                if (bNullValuecheck )
                {
                    MessageBox.Show("Required Quantity field is empty","Error", 0, MessageBoxIcon.Error);
                }
                else if(string.IsNullOrEmpty(txtRemarks.Text))
                {
                    MessageBox.Show("Please write remarks", "Error", 0, MessageBoxIcon.Error);
                    txtRemarks.Focus();
                }
            }
        }

        private void dgIndentList_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete) 
            {
                if (dgIndentList.Rows.Count > 0)
                {
                    dgIndentList.Rows.RemoveAt(dgIndentList.Rows.IndexOf(dgIndentList.CurrentRow));
                }
            }
        }
    }
}
