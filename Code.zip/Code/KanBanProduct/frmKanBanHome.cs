﻿using System;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.KanBanProduct
{
    public partial class frmKanBanHome : Form
    {
        public frmKanBanHome()
        {
            InitializeComponent();
        }
        frmForm2 frm = new frmForm2();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm frmLoginForm = new Login.frmLoginForm();

        #region Function to Show Please wait form & Switch to Selected From
        private void fnFormShow(Form Frm)
        {
            this.Hide();
            pleasewaitform pleaseWait = new pleasewaitform();
            pleaseWait.Show();
            Application.DoEvents();
            Frm.Show();
            pleaseWait.Hide();
        }
        #endregion

        private void frmKanBanHome_Load(object sender, EventArgs e)
        {
            //if (Login.frmLoginForm.sUserDetails[55] != "True")
            //{
            //    btnKanBanProduct.Enabled = false;
            //}
            //else
            //{
            //    btnKanBanProduct.Enabled = true;
            //}

            //if (Login.frmLoginForm.sUserDetails[56] != "True")
            //{
            //    btnReport.Enabled = false;
            //}
            //else
            //{
            //    btnReport.Enabled = true;
            //}

            //if (Login.frmLoginForm.sUserDetails[57] != "True")
            //{
            //    btnTraIssue.Enabled = false;
            //}
            //else
            //{
            //    btnTraIssue.Enabled = true;
            //}

            //if (Login.frmLoginForm.sUserDetails[62] != "True")
            //{
            //    btnEleProduct.Enabled = false;
            //}
            //else
            //{
            //    btnEleProduct.Enabled = true;
            //}
            //if (Login.frmLoginForm.sUserDetails[63] != "True")
            //{
            //    btnEleBOM.Enabled = false;
            //}
            //else
            //{
            //    btnEleBOM.Enabled = true;
            //}
            //if (Login.frmLoginForm.sUserDetails[64] != "True")
            //{
            //    btnEleIssue.Enabled = false;
            //    btnBOM.Enabled = false;
            //}
            //else
            //{
            //    btnBOM.Enabled = true;
            //    btnEleIssue.Enabled = true;
            //}
            //if (Login.frmLoginForm.sUserDetails[65] != "True")
            //{
            //    btnEleLedger.Enabled = false;
            //}
            //else
            //{
            //    btnEleLedger.Enabled = true;
            //}
            //if (Login.frmLoginForm.sUserDetails[67] != "True")
            //{
            //    btnElectronicsReturn.Enabled = false;
            //}
            //else
            //{
            //    btnElectronicsReturn.Enabled = true;
            //}
            //if (Login.frmLoginForm.sUserDetails[68] != "True")
            //{
            //    btnElectronicsStockAdjust.Enabled = false;
            //}
            //else
            //{
            //    btnElectronicsStockAdjust.Enabled = true;
            //}

            //if (Login.frmLoginForm.sUserDetails[70] != "True")
            //{
            //    btnTransducerItemReturn.Enabled = false;
            //}
            //else
            //{
            //    btnTransducerItemReturn.Enabled = true;
            //}

            //if (Login.frmLoginForm.sUserDetails[71] != "True")
            //{
            //    btnTransStockAdjust.Enabled = false;
            //}
            //else
            //{
            //    btnTransStockAdjust.Enabled = true;
            //}
        }

        private void frmKanBanHome_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            frm.Show();
        }

        private void btnKanBanProduct_Click(object sender, EventArgs e)
        {
            KanBanProduct.frmKanBanItems KbProduct = new frmKanBanItems();
            fnFormShow(KbProduct);
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            KanBanProduct.frmKanBanReports KbReports = new frmKanBanReports();
            fnFormShow(KbReports);
        }

        private void btnTraIssue_Click(object sender, EventArgs e)
        {
            KanBanProduct.frmKanbanIssue Kissue = new frmKanbanIssue();
            fnFormShow(Kissue);
        }

        private void btnEleBOM_Click(object sender, EventArgs e)
        {
            KanBanProduct.frmElectronicsBOM BOM = new frmElectronicsBOM();
            fnFormShow(BOM);
        }

        private void btnEleProduct_Click(object sender, EventArgs e)
        {
            KanBanProduct.frmElectronicsItems EI = new frmElectronicsItems();
            fnFormShow(EI);
        }

        private void btnEleIssue_Click(object sender, EventArgs e)
        {
            KanBanProduct.frmElectronicsissue EIssue = new frmElectronicsissue();
            fnFormShow(EIssue);
        }

        private void btnEleLedger_Click(object sender, EventArgs e)
        {
            KanBanProduct.frmKANBANLedger Ledger = new frmKANBANLedger();
            fnFormShow(Ledger);
        }

        private void btnElectronicsReturn_Click(object sender, EventArgs e)
        {
            KanBanProduct.frmKanBanEReturn Return = new frmKanBanEReturn();
            fnFormShow(Return);
        }

        private void btnElectronicsStockAdjust_Click(object sender, EventArgs e)
        {
            KanBanProduct.frmElectronicsStockadjust StockAdjust = new frmElectronicsStockadjust();
            fnFormShow(StockAdjust);
        }

        private void btnTransStockAdjust_Click(object sender, EventArgs e)
        {
            KanBanProduct.frmKanBanTransducerStockAdjust TRSAdjust = new frmKanBanTransducerStockAdjust();
            fnFormShow(TRSAdjust);
        }

        private void btnTransducerStockAdjust_Click(object sender, EventArgs e)
        {
            KanBanProduct.frmKanBanTransducerReturn TIR = new frmKanBanTransducerReturn();
            fnFormShow(TIR);
        }

        private void btnBOM_Click(object sender, EventArgs e)
        {
            KanBanProduct.frmProjectBOM frmProjectBOM = new frmProjectBOM();
            fnFormShow(frmProjectBOM);
        }
    }
}
