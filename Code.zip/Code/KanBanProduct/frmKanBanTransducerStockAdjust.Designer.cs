﻿namespace Erp_Project_With_Buttons.KanBanProduct
{
    partial class frmKanBanTransducerStockAdjust
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmKanBanTransducerStockAdjust));
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.lblRemarks = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dtpReturndate = new System.Windows.Forms.DateTimePicker();
            this.gpButtons = new System.Windows.Forms.GroupBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.dgIndentList = new System.Windows.Forms.DataGridView();
            this.ItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AvailableQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ActualQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Adjustqty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnitemlist = new System.Windows.Forms.Panel();
            this.chkRawMaterailIssue = new System.Windows.Forms.CheckBox();
            this.chkItemDesc = new System.Windows.Forms.CheckBox();
            this.chkProductIssue = new System.Windows.Forms.CheckBox();
            this.chkItemCode = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.chklbItemList = new System.Windows.Forms.CheckedListBox();
            this.txtItemDescription = new System.Windows.Forms.TextBox();
            this.gpButtons.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgIndentList)).BeginInit();
            this.pnitemlist.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtRemarks
            // 
            this.txtRemarks.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemarks.Location = new System.Drawing.Point(679, 224);
            this.txtRemarks.Multiline = true;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRemarks.Size = new System.Drawing.Size(286, 52);
            this.txtRemarks.TabIndex = 237;
            // 
            // lblRemarks
            // 
            this.lblRemarks.AutoSize = true;
            this.lblRemarks.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRemarks.ForeColor = System.Drawing.Color.Black;
            this.lblRemarks.Location = new System.Drawing.Point(605, 227);
            this.lblRemarks.Name = "lblRemarks";
            this.lblRemarks.Size = new System.Drawing.Size(68, 18);
            this.lblRemarks.TabIndex = 236;
            this.lblRemarks.Text = "Remarks :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(727, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 23);
            this.label2.TabIndex = 235;
            this.label2.Text = "Date :";
            // 
            // dtpReturndate
            // 
            this.dtpReturndate.Enabled = false;
            this.dtpReturndate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpReturndate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpReturndate.Location = new System.Drawing.Point(790, 27);
            this.dtpReturndate.Name = "dtpReturndate";
            this.dtpReturndate.Size = new System.Drawing.Size(121, 26);
            this.dtpReturndate.TabIndex = 234;
            // 
            // gpButtons
            // 
            this.gpButtons.Controls.Add(this.btnExit);
            this.gpButtons.Controls.Add(this.btnSave);
            this.gpButtons.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.gpButtons.Location = new System.Drawing.Point(124, 491);
            this.gpButtons.Name = "gpButtons";
            this.gpButtons.Size = new System.Drawing.Size(861, 69);
            this.gpButtons.TabIndex = 233;
            this.gpButtons.TabStop = false;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(753, 16);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(88, 44);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(601, 16);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(88, 44);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // dgIndentList
            // 
            this.dgIndentList.AllowUserToAddRows = false;
            this.dgIndentList.AllowUserToDeleteRows = false;
            this.dgIndentList.AllowUserToResizeRows = false;
            this.dgIndentList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgIndentList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgIndentList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgIndentList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgIndentList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgIndentList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ItemCode,
            this.ItemDesc,
            this.UnitCost,
            this.AvailableQty,
            this.ActualQty,
            this.Adjustqty});
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgIndentList.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgIndentList.EnableHeadersVisualStyles = false;
            this.dgIndentList.Location = new System.Drawing.Point(8, 305);
            this.dgIndentList.MultiSelect = false;
            this.dgIndentList.Name = "dgIndentList";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgIndentList.RowHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgIndentList.RowHeadersVisible = false;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgIndentList.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.dgIndentList.Size = new System.Drawing.Size(977, 180);
            this.dgIndentList.TabIndex = 232;
            this.dgIndentList.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgIndentList_CellBeginEdit);
            this.dgIndentList.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgIndentList_CellEndEdit);
            this.dgIndentList.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgIndentList_EditingControlShowing);
            // 
            // ItemCode
            // 
            this.ItemCode.DataPropertyName = "ItemCode";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ItemCode.DefaultCellStyle = dataGridViewCellStyle2;
            this.ItemCode.HeaderText = "Item Code";
            this.ItemCode.Name = "ItemCode";
            this.ItemCode.ReadOnly = true;
            this.ItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemCode.Width = 97;
            // 
            // ItemDesc
            // 
            this.ItemDesc.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ItemDesc.DataPropertyName = "ItemDescription";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ItemDesc.DefaultCellStyle = dataGridViewCellStyle3;
            this.ItemDesc.HeaderText = "Item Desc";
            this.ItemDesc.Name = "ItemDesc";
            this.ItemDesc.ReadOnly = true;
            this.ItemDesc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemDesc.Width = 99;
            // 
            // UnitCost
            // 
            this.UnitCost.DataPropertyName = "UnitCost";
            this.UnitCost.HeaderText = "UnitCost";
            this.UnitCost.Name = "UnitCost";
            this.UnitCost.ReadOnly = true;
            this.UnitCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitCost.Width = 85;
            // 
            // AvailableQty
            // 
            this.AvailableQty.DataPropertyName = "AvailableQty";
            this.AvailableQty.HeaderText = "Available Qty";
            this.AvailableQty.Name = "AvailableQty";
            this.AvailableQty.ReadOnly = true;
            this.AvailableQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.AvailableQty.Width = 123;
            // 
            // ActualQty
            // 
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ActualQty.DefaultCellStyle = dataGridViewCellStyle4;
            this.ActualQty.HeaderText = "Actual Qty";
            this.ActualQty.Name = "ActualQty";
            this.ActualQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Adjustqty
            // 
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.Adjustqty.DefaultCellStyle = dataGridViewCellStyle5;
            this.Adjustqty.HeaderText = "Adjust Qty";
            this.Adjustqty.Name = "Adjustqty";
            this.Adjustqty.ReadOnly = true;
            this.Adjustqty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Adjustqty.Width = 101;
            // 
            // pnitemlist
            // 
            this.pnitemlist.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnitemlist.Controls.Add(this.chkRawMaterailIssue);
            this.pnitemlist.Controls.Add(this.chkItemDesc);
            this.pnitemlist.Controls.Add(this.chkProductIssue);
            this.pnitemlist.Controls.Add(this.chkItemCode);
            this.pnitemlist.Controls.Add(this.label3);
            this.pnitemlist.Controls.Add(this.chklbItemList);
            this.pnitemlist.Controls.Add(this.txtItemDescription);
            this.pnitemlist.Location = new System.Drawing.Point(8, 6);
            this.pnitemlist.Name = "pnitemlist";
            this.pnitemlist.Size = new System.Drawing.Size(498, 293);
            this.pnitemlist.TabIndex = 231;
            // 
            // chkRawMaterailIssue
            // 
            this.chkRawMaterailIssue.AutoSize = true;
            this.chkRawMaterailIssue.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkRawMaterailIssue.ForeColor = System.Drawing.Color.Red;
            this.chkRawMaterailIssue.Location = new System.Drawing.Point(300, 3);
            this.chkRawMaterailIssue.Name = "chkRawMaterailIssue";
            this.chkRawMaterailIssue.Size = new System.Drawing.Size(132, 30);
            this.chkRawMaterailIssue.TabIndex = 215;
            this.chkRawMaterailIssue.Text = "Item Adjust";
            this.chkRawMaterailIssue.UseVisualStyleBackColor = true;
            this.chkRawMaterailIssue.CheckedChanged += new System.EventHandler(this.chkRawMaterailIssue_CheckedChanged);
            // 
            // chkItemDesc
            // 
            this.chkItemDesc.AutoSize = true;
            this.chkItemDesc.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemDesc.ForeColor = System.Drawing.Color.Black;
            this.chkItemDesc.Location = new System.Drawing.Point(254, 39);
            this.chkItemDesc.Name = "chkItemDesc";
            this.chkItemDesc.Size = new System.Drawing.Size(140, 23);
            this.chkItemDesc.TabIndex = 209;
            this.chkItemDesc.Text = "Item Description";
            this.chkItemDesc.UseVisualStyleBackColor = true;
            // 
            // chkProductIssue
            // 
            this.chkProductIssue.AutoSize = true;
            this.chkProductIssue.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkProductIssue.ForeColor = System.Drawing.Color.Red;
            this.chkProductIssue.Location = new System.Drawing.Point(100, 3);
            this.chkProductIssue.Name = "chkProductIssue";
            this.chkProductIssue.Size = new System.Drawing.Size(158, 30);
            this.chkProductIssue.TabIndex = 214;
            this.chkProductIssue.Text = "Product Adjust";
            this.chkProductIssue.UseVisualStyleBackColor = true;
            this.chkProductIssue.CheckedChanged += new System.EventHandler(this.chkProductIssue_CheckedChanged);
            // 
            // chkItemCode
            // 
            this.chkItemCode.AutoSize = true;
            this.chkItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemCode.ForeColor = System.Drawing.Color.Black;
            this.chkItemCode.Location = new System.Drawing.Point(129, 39);
            this.chkItemCode.Name = "chkItemCode";
            this.chkItemCode.Size = new System.Drawing.Size(97, 23);
            this.chkItemCode.TabIndex = 208;
            this.chkItemCode.Text = "Item Code";
            this.chkItemCode.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(3, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 19);
            this.label3.TabIndex = 124;
            this.label3.Text = "Search Item by";
            // 
            // chklbItemList
            // 
            this.chklbItemList.CheckOnClick = true;
            this.chklbItemList.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chklbItemList.FormattingEnabled = true;
            this.chklbItemList.HorizontalScrollbar = true;
            this.chklbItemList.Location = new System.Drawing.Point(3, 112);
            this.chklbItemList.Name = "chklbItemList";
            this.chklbItemList.Size = new System.Drawing.Size(488, 172);
            this.chklbItemList.TabIndex = 117;
            this.chklbItemList.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.chklbItemList_ItemCheck);
            // 
            // txtItemDescription
            // 
            this.txtItemDescription.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemDescription.Location = new System.Drawing.Point(7, 63);
            this.txtItemDescription.Multiline = true;
            this.txtItemDescription.Name = "txtItemDescription";
            this.txtItemDescription.Size = new System.Drawing.Size(483, 44);
            this.txtItemDescription.TabIndex = 121;
            this.txtItemDescription.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtItemDescription_KeyPress);
            this.txtItemDescription.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemDescription_KeyUp);
            // 
            // frmKanBanTransducerStockAdjust
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(993, 566);
            this.Controls.Add(this.txtRemarks);
            this.Controls.Add(this.lblRemarks);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dtpReturndate);
            this.Controls.Add(this.gpButtons);
            this.Controls.Add(this.dgIndentList);
            this.Controls.Add(this.pnitemlist);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmKanBanTransducerStockAdjust";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " KanBan Transducer StockAdjust";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmKanBanTransducerStockAdjust_FormClosing);
            this.gpButtons.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgIndentList)).EndInit();
            this.pnitemlist.ResumeLayout(false);
            this.pnitemlist.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.Label lblRemarks;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtpReturndate;
        private System.Windows.Forms.GroupBox gpButtons;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.DataGridView dgIndentList;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn AvailableQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn ActualQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn Adjustqty;
        private System.Windows.Forms.Panel pnitemlist;
        private System.Windows.Forms.CheckBox chkRawMaterailIssue;
        private System.Windows.Forms.CheckBox chkItemDesc;
        private System.Windows.Forms.CheckBox chkProductIssue;
        private System.Windows.Forms.CheckBox chkItemCode;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckedListBox chklbItemList;
        private System.Windows.Forms.TextBox txtItemDescription;
    }
}