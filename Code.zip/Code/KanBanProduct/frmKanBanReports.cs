﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Collections;

namespace Erp_Project_With_Buttons.KanBanProduct
{
    public partial class frmKanBanReports : Form
    {
        public frmKanBanReports()
        {
            InitializeComponent();
        }

        DataAccessLayer DAL = new DataAccessLayer();
        DataTable dtTransducerReport = new DataTable();
        DataTable DTProjectList = new DataTable();

        frmForm2 Home = new frmForm2();

        public int ElectronicsReportIssue = 0;
        private static string sProjectCode;
        public string fnProjectcode
        {
            get
            {
                return sProjectCode;
            }
            set
            {
                sProjectCode = value;
            }
        }

        private void cmbReport_SelectedIndexChanged(object sender, EventArgs e)
        {
            pnAllyears.Visible = false;
            pntotalamount.Visible = false;
            lblTotalAmount.Text = "0";
            switch (cmbReport.SelectedIndex)
            {
                case 0:
                case 6:
                case 5:
                case 11:
                    //case 18:
                    pntotalamount.Visible = true;
                    pnProjectCodePanel.Visible = false;
                    pnGenaralPanel.Visible = false;
                    break;

                case 1:
                case 2:
                case 3:
                case 4:
                case 7:
                case 8:
                case 9:
                case 10:
                case 13:
                case 14:
                case 16:
                case 17:
                case 18:
                case 19:
                    pnProjectCodePanel.Visible = false;
                    pnGenaralPanel.Visible = true;
                    break;

                case 20:
                case 21:
                    pnProjectCodePanel.Visible = false;
                    pnGenaralPanel.Visible = false;
                    pnAllyears.Visible = true;
                   // lblToDate.Text = "6 Months Date";
                    var sTodatydate = DateTime.Today;
                    dtpItemUsage.Value = sTodatydate;
                    break;

                case 12:

                    //if (DTProjectList.Rows.Count == 0)
                    // {
                    DTProjectList = DAL.fnElectronicsIssuedProjectList(0, null).Tables[0];
                    cmbProjectCode.Text = "";
                    cmbProjectCode.Items.Clear();
                    foreach (DataRow row in DTProjectList.Rows)
                    {
                        if (!cmbProjectCode.Items.Contains(row["ProjectCode"].ToString()))
                            cmbProjectCode.Items.Add(row["ProjectCode"].ToString());
                    }
                    // }
                    pnProjectCodePanel.Visible = true;
                    pnGenaralPanel.Visible = true;
                    break;

                case 15:
                    //  if (DTProjectList.Rows.Count == 0)
                    //  {
                    cmbProjectCode.Text = "";
                    cmbProjectCode.Items.Clear();
                    DTProjectList = DAL.fnElectronicsIssuedProjectList(1, null).Tables[0];

                    foreach (DataRow row in DTProjectList.Rows)
                    {
                        if (!cmbProjectCode.Items.Contains(row["ProjectCode"].ToString()))
                            cmbProjectCode.Items.Add(row["ProjectCode"].ToString());
                    }
                    //   }
                    pnProjectCodePanel.Visible = true;
                    pnGenaralPanel.Visible = true;
                    break;
            }
        }

        private void fnCustomDate(int SwitchCustom)
        {
            switch (SwitchCustom)
            {
                case 0:
                    Cursor.Current = Cursors.WaitCursor;
                    dtpFromDate.Format = DateTimePickerFormat.Custom;
                    dtpFromDate.CustomFormat = "yyyy-MM-dd";
                    dptToDate.Format = DateTimePickerFormat.Custom;
                    dptToDate.CustomFormat = "yyyy-MM-dd";
                    break;
                case 1:
                    dtpFromDate.Format = DateTimePickerFormat.Custom;
                    dtpFromDate.CustomFormat = "dd-MM-yyyy";
                    dptToDate.Format = DateTimePickerFormat.Custom;
                    dptToDate.CustomFormat = "dd-MM-yyyy";
                    Cursor.Current = Cursors.Default;
                    break;
            }
        }


        #region Excel Merge Function
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlMedium, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

        }
        #endregion

        private void btnexcelreport_Click(object sender, EventArgs e)
        {

            if (dtTransducerReport.Rows.Count > 0)
            {
                int iRowIndex = 1;
                string ExcelFolderPath;
                string FileFullPath;
                EXCEL.Workbook NewWorkBook;
                EXCEL.Worksheet NewWorkSheet;
                EXCEL.Application ExcelApp;
                EXCEL.Range CELLS, cell1, cell2;
                object misValue;

                ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\Transducer Report\\";
                FileFullPath = ExcelFolderPath + cmbReport.Text + "--" + DateTime.Now.ToString("dd/MM/yyyy hh/mm/ss") + ".xls";
                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);
                ExcelApp = new EXCEL.Application();
                misValue = System.Reflection.Missing.Value;
                try
                {
                    if (ExcelApp == null)
                        MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                    NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                    NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                    if (NewWorkSheet == null)
                        MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                    else
                        NewWorkSheet.Name = cmbReport.Text;
                    // Select the Excel cells, in the range c1 to c7 in the worksheet for cell access check.
                    EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                    if (RANGE == null)
                        MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                    NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlWorkbookNormal, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                    CELLS = NewWorkSheet.Cells;
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);

                    NewWorkSheet.Cells[iRowIndex, 1] = cmbReport.Text;
                    if (cmbReport.SelectedIndex == 12)
                    {
                        NewWorkSheet.Cells[4, 1] = "Isssued Amount : " + label5.Text;
                    }
                    iRowIndex++;
                    iRowIndex++;
                    iRowIndex++;

                    if (dtTransducerReport.Rows.Count > 0)
                    {
                        object[,] rawData = new object[dtTransducerReport.Rows.Count + 1, dtTransducerReport.Columns.Count];
                        for (int col = 0; col < dtTransducerReport.Columns.Count; col++)
                        {
                            rawData[0, col] = dtTransducerReport.Columns[col].ColumnName;
                        }
                        for (int row = 0; row < dtTransducerReport.Rows.Count; row++)
                        {
                            for (int col = 0; col < dtTransducerReport.Columns.Count; col++)
                            {
                                rawData[row + 1, col] = dtTransducerReport.Rows[row].ItemArray[col];
                            }
                        }
                        string excelRange = string.Empty;
                        string finalColLetter = string.Empty;
                        string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        int colCharsetLen = colCharset.Length;

                        if (dtTransducerReport.Columns.Count > colCharsetLen)
                        {
                            finalColLetter = colCharset.Substring((dtTransducerReport.Columns.Count - 1) / colCharsetLen - 1, 1);
                        }

                        finalColLetter += colCharset.Substring((dtTransducerReport.Columns.Count - 1) % colCharsetLen, 1);
                        excelRange = string.Format("A6:{0}{1}", finalColLetter, dtTransducerReport.Rows.Count + 6);
                        NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                    }
                    NewWorkSheet.Range["A1:S6"].Cells.Font.Bold = true;
                    NewWorkSheet.Range["A1:S6"].Cells.Font.Size = 16;

                    if ((cmbReport.SelectedIndex > 0 && cmbReport.SelectedIndex < 3) || (cmbReport.SelectedIndex > 6 && cmbReport.SelectedIndex < 9))
                    {
                        Microsoft.Office.Interop.Excel.Range r = NewWorkSheet.get_Range("F6", "F99999");
                        r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                    }
                    if (cmbReport.SelectedIndex == 4 || cmbReport.SelectedIndex == 10)
                    {
                        Microsoft.Office.Interop.Excel.Range r = NewWorkSheet.get_Range("G6", "G99999");
                        r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                    }

                    if (cmbReport.SelectedIndex == 20 || cmbReport.SelectedIndex == 21)
                    {
                        Microsoft.Office.Interop.Excel.Range r = NewWorkSheet.get_Range("C6", "C99999");
                        r.EntireColumn.NumberFormat = "DD/MM/YYYY";
                    }

                    NewWorkSheet.Rows.AutoFit();

                    NewWorkSheet.Columns.AutoFit();

                    if (cmbReport.SelectedIndex == 0 || cmbReport.SelectedIndex == 6 || cmbReport.SelectedIndex == 20 || cmbReport.SelectedIndex == 21)
                    {
                        NewWorkSheet.Columns[2].ColumnWidth = 50;
                        NewWorkSheet.Columns[2].WrapText = true;
                    }
                    else
                    {
                        NewWorkSheet.Columns[3].ColumnWidth = 50;
                        NewWorkSheet.Columns[3].WrapText = true;
                    }


                    NewWorkSheet.Rows.RowHeight = "18";
                    NewWorkSheet.PageSetup.PrintArea = "A1:N" + (dtTransducerReport.Rows.Count + iRowIndex + 6)+ "";
                    NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                    NewWorkSheet.PageSetup.PrintNotes = true;
                    NewWorkSheet.PageSetup.Zoom = 100;
                    NewWorkSheet.PageSetup.FitToPagesTall = 1;
                    NewWorkSheet.PageSetup.FitToPagesWide = 1;
                    NewWorkSheet.PageSetup.LeftMargin = 0;
                    NewWorkSheet.PageSetup.RightMargin = 0;
                    NewWorkSheet.PageSetup.TopMargin = 0.75;
                    NewWorkSheet.PageSetup.BottomMargin = 0.75;
                    NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                    NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                    string _stLOGO = ("C:\\Databasepath\\BissLogoTP.jpg");
                    EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 7];

                    Image oImage = Image.FromFile(_stLOGO);
                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    NewWorkSheet.Paste(oRange, _stLOGO);

                    NewWorkBook.Save();
                    ExcelApp.Visible = true;
                    System.Threading.Thread.Sleep(1000);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    //foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                    //{
                    //    GetProcess.Kill();
                    //}
                }
            }
            else
            {
                MessageBox.Show("No transactions on selected dates to generate report", "Information", 0, MessageBoxIcon.Question);
            }

        }

        private void frmKanBanReports_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            Home.Show();
        }

        //  private double sQty;
        DataTable dtReciept = new DataTable();
        private void fnInventoryGradingCount()
        {
            object value;
            foreach (DataRow dr in dtTransducerReport.Rows)
            {
                value = dr["6Months"];
                if (value == DBNull.Value)
                {
                    dr["6Months"] = 0;
                }
                value = dr["12Months"];
                if (value == DBNull.Value)
                {
                    dr["12Months"] = 0;
                }
            }

            if (dtTransducerReport.Rows.Count > 0)
            {
                Dictionary<string, double> dicSum = new Dictionary<string, double>();
                Dictionary<string, double> dicSum1 = new Dictionary<string, double>();
                Dictionary<string, double> dicSum2 = new Dictionary<string, double>();
                foreach (DataRow row in dtTransducerReport.Rows)
                {
                    string group = row["ItemCode"].ToString();
                    double rate = Convert.ToDouble(row["6Months"]);

                    string group1 = row["ItemCode"].ToString();
                    double rate1 = Convert.ToDouble(row["12Months"]);

                    string group2 = row["ItemCode"].ToString();
                    double rate2 = Convert.ToDouble(row["AvailableQty"]);


                    if (dicSum.ContainsKey(group))
                        dicSum[group] += rate;
                    else
                        dicSum.Add(group, rate);

                    if (dicSum1.ContainsKey(group1))
                        dicSum1[group1] += rate1;
                    else
                        dicSum1.Add(group1, rate1);

                    if (dicSum2.ContainsKey(group2))
                        dicSum2[group2] += rate2;
                    else
                        dicSum2.Add(group2, rate2);
                }

                DataTable UniqueRecords = RemoveDuplicateRows(dtTransducerReport, "ItemCode");

                foreach (var group in dicSum)
                {
                    foreach (DataRow FinalItems in dtTransducerReport.Rows)
                    {
                        if (FinalItems["ItemCode"].ToString() == group.Key.ToString())
                        {
                            sQty = group.Value;
                            FinalItems["6Months"] = sQty;
                            break;
                        }
                    }
                }
                sQty = 0;
                foreach (var group1 in dicSum1)
                {
                    foreach (DataRow FinalItems in dtTransducerReport.Rows)
                    {
                        if (FinalItems["ItemCode"].ToString() == group1.Key.ToString())
                        {
                            sQty = group1.Value;
                            FinalItems["12Months"] = sQty;
                            break;
                        }
                    }
                }

                sQty = 0;
                foreach (var group2 in dicSum2)
                {
                    foreach (DataRow FinalItems in dtTransducerReport.Rows)
                    {
                        if (FinalItems["ItemCode"].ToString() == group2.Key.ToString())
                        {
                            sQty = group2.Value;
                            FinalItems["AvailableQty"] = sQty;
                            break;
                        }
                    }
                }
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            fnCustomDate(0);
            dtTransducerReport.Clear();
            dgvReportView.DataSource = null;
            switch (cmbReport.SelectedIndex)
            {
                case 0:
                    dtTransducerReport = DAL.fnTransducerReport(0, dtpFromDate.Text, dptToDate.Text, "").Tables[0];
                    break;

                case 1:
                    dtTransducerReport = DAL.fnTransducerReport(1, dtpFromDate.Text, dptToDate.Text, "").Tables[0];
                    break;

                case 2:
                    dtTransducerReport = DAL.fnTransducerReport(2, dtpFromDate.Text, dptToDate.Text, "").Tables[0];
                    break;

                case 3:
                    dtTransducerReport = DAL.fnTransducerReport(3, dtpFromDate.Text, dptToDate.Text, "").Tables[0];
                    break;

                case 4:
                    dtTransducerReport = DAL.fnTransducerReport(4, dtpFromDate.Text, dptToDate.Text, "").Tables[0];
                    break;

                case 5:
                    dtTransducerReport = DAL.fnTransducerReport(5, dtpFromDate.Text, dptToDate.Text, "").Tables[0];
                    break;

                case 6:
                    dtTransducerReport = DAL.fnTransducerReport(6, dtpFromDate.Text, dptToDate.Text, "").Tables[0];
                    break;

                case 7:
                    dtTransducerReport = DAL.fnTransducerReport(7, dtpFromDate.Text, dptToDate.Text, "").Tables[0];
                    break;

                case 8:
                    dtTransducerReport = DAL.fnTransducerReport(8, dtpFromDate.Text, dptToDate.Text, "").Tables[0];
                    break;

                case 9:
                    dtTransducerReport = DAL.fnTransducerReport(9, dtpFromDate.Text, dptToDate.Text, "").Tables[0];
                    break;

                case 10:
                    dtTransducerReport = DAL.fnTransducerReport(10, dtpFromDate.Text, dptToDate.Text, "").Tables[0];
                    break;

                case 11:
                    dtTransducerReport = DAL.fnTransducerReport(11, dtpFromDate.Text, dptToDate.Text, "").Tables[0];
                    break;

                case 12:
                    dtTransducerReport = DAL.fnTransducerReport(12, dtpFromDate.Text, dptToDate.Text, cmbProjectCode.Text).Tables[0];
                    break;
                case 13:
                    dtTransducerReport = DAL.fnTransducerReport(13, dtpFromDate.Text, dptToDate.Text, "").Tables[0];
                    break;
                case 14:
                    dtTransducerReport = DAL.fnTransducerReport(14, dtpFromDate.Text, dptToDate.Text, "").Tables[0];
                    break;
                case 15:
                    dtTransducerReport = DAL.fnTransducerReport(15, dtpFromDate.Text, dptToDate.Text, cmbProjectCode.Text).Tables[0];
                    break;
                case 16:
                    dtTransducerReport = DAL.fnTransducerReport(16, dtpFromDate.Text, dptToDate.Text, "").Tables[0];
                    break;
                case 17:
                    dtTransducerReport = DAL.fnTransducerReport(17, dtpFromDate.Text, dptToDate.Text, "").Tables[0];
                    break;

                case 18:

                    var stodaydate = dtpFromDate.Value;
                    var s6MonthsDate = stodaydate.AddDays(181);
                    var s12MotnhsDate = stodaydate.AddDays(365);
                    dtTransducerReport = DAL.fnTransducerReport(18, stodaydate.ToString("yyyy-MM-dd"), s6MonthsDate.ToString("yyyy-MM-dd"), s12MotnhsDate.ToString("yyyy-MM-dd")).Tables[0];
                    if (dtTransducerReport.Rows.Count > 0)
                    {

                        fnUsageCount();
                        fnUsageRatio();
                    }
                    break;

                case 19:

                    var stodaydate1 = dtpFromDate.Value;
                    var s6MonthsDate1 = stodaydate1.AddDays(181);
                    var s12MotnhsDate1 = stodaydate1.AddDays(365);
                    dtTransducerReport = DAL.fnTransducerReport(19, stodaydate1.ToString("yyyy-MM-dd"), s6MonthsDate1.ToString("yyyy-MM-dd"), s12MotnhsDate1.ToString("yyyy-MM-dd")).Tables[0];
                    if (dtTransducerReport.Rows.Count > 0)
                    {
                        DataView view = dtTransducerReport.DefaultView;
                        view.Sort = "AvailableQty DESC";
                        dtTransducerReport = view.ToTable();
                        fnUsageCount();
                    }
                    break;

                case 20:
                case 21:
                    fnCustomDate1(0);
                    if (cmbReport.SelectedIndex == 20)
                    {
                        dtTransducerReport = DAL.fnItemUsageofAllStores(4, dtpItemUsage.Text, dtp6months.Text, dtptwelve.Text, null).Tables[0];
                    }
                    else if (cmbReport.SelectedIndex == 21)
                    {
                        dtTransducerReport = DAL.fnItemUsageofAllStores(5, dtpItemUsage.Text, dtp6months.Text, dtptwelve.Text, null).Tables[0];
                    }
                    fnInventoryGradingCount();

                    foreach (DataRow dr in dtTransducerReport.Rows)
                    {
                        if (Convert.ToDateTime(dr["CreatedDate"].ToString()) > Convert.ToDateTime(dtptwelve.Text) || Convert.ToDouble(dr["AvailableQty"].ToString()) == 0)
                        {
                            dr["Grading"] = "Active";
                        }
                        else if ((Convert.ToDouble(dr["12Months"].ToString()) == 0 && Convert.ToDouble(dr["AvailableQty"].ToString()) > 0) && Convert.ToDateTime(dr["CreatedDate"].ToString()) < Convert.ToDateTime(dtptwelve.Text))
                        {
                            dr["Grading"] = "Obsolute";
                        }
                        else if ((Convert.ToDouble(dr["AvailableQty"].ToString()) > Convert.ToDouble(dr["6Months"].ToString())))
                        {
                            dr["Grading"] = "Slow";
                        }
                        else
                        {
                            dr["Grading"] = "Active";
                        }
                    }

                    foreach (DataRow dr in dtTransducerReport.Rows)
                    {
                        dr["StockValue"] = (Convert.ToDouble(dr["AvailableQty"].ToString()) * Convert.ToDouble(dr["UnitCost"].ToString()));
                    }

                    foreach (DataRow dr in dtTransducerReport.Rows)
                    {
                        dr["Inventory Value with OH"] = (Convert.ToDouble(dr["StockValue"].ToString()) + (Convert.ToDouble(dr["StockValue"].ToString()) * 0.223269876));
                    }
                    foreach (DataRow dr in dtTransducerReport.Rows)
                    {
                        if (dr["Grading"].ToString() == "Slow")
                        {
                            dr["Reserve Amount"] = (Convert.ToDouble(dr["Inventory Value with OH"].ToString()) * 0.5);
                        }
                        else if (dr["Grading"].ToString() == "Obsolute")
                        {
                            dr["Reserve Amount"] = (Convert.ToDouble(dr["Inventory Value with OH"].ToString()) * 0.9);
                        }
                        else if (dr["Grading"].ToString() == "Active")
                        {
                            dr["Reserve Amount"] = ((Convert.ToDouble(dr["Inventory Value with OH"].ToString())) * 0);
                        }
                    }

                    fnCustomDate1(1);
                    break;

                  //  dgvReportView.AutoGenerateColumns = true;
                 //   dgvReportView.DataSource = dtReciept;

            }
            fnCustomDate(1);
            dgvReportView.AutoGenerateColumns = true;
            dgvReportView.DataSource = dtTransducerReport;
            if (cmbReport.SelectedIndex == 18)
            {
                Datagridviewcolor();
            }
            foreach (DataGridViewColumn column in dgvReportView.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
            double sTotalAmount = 0;
            if (cmbReport.SelectedIndex == 12 || cmbReport.SelectedIndex == 15)
            {
                sTotalAmount = 0;
                foreach (DataGridViewRow dgvr in dgvReportView.Rows)
                {
                    sTotalAmount += (Convert.ToDouble(dgvr.Cells[4].Value) * Convert.ToDouble(dgvr.Cells[5].Value));
                }
                label5.Text = Math.Round(sTotalAmount).ToString();
            }

            if (cmbReport.SelectedIndex == 0 || cmbReport.SelectedIndex == 5 || cmbReport.SelectedIndex == 6 || cmbReport.SelectedIndex == 11)
            {
                sTotalAmount = 0;
                foreach (DataGridViewRow dgvr in dgvReportView.Rows)
                {
                    sTotalAmount += (Convert.ToDouble(dgvr.Cells[4].Value));
                }
                lblTotalAmount.Text = Math.Round(sTotalAmount).ToString();
            }

        }
        private double sQty;
        private double sQty1;


        private void fnCustomDate1(int SwitchCustom)
        {
            switch (SwitchCustom)
            {
                case 0:
                    Cursor.Current = Cursors.WaitCursor;
                    dtpItemUsage.Format = DateTimePickerFormat.Custom;
                    dtpItemUsage.CustomFormat = "yyyy-MM-dd";
                    dtp6months.Format = DateTimePickerFormat.Custom;
                    dtp6months.CustomFormat = "yyyy-MM-dd";
                    dtptwelve.Format = DateTimePickerFormat.Custom;
                    dtptwelve.CustomFormat = "yyyy-MM-dd";
                    break;
                case 1:
                    dtpItemUsage.Format = DateTimePickerFormat.Custom;
                    dtpItemUsage.CustomFormat = "dd-MM-yyyy";
                    dtp6months.Format = DateTimePickerFormat.Custom;
                    dtp6months.CustomFormat = "dd-MM-yyyy";
                    dtptwelve.Format = DateTimePickerFormat.Custom;
                    dtptwelve.CustomFormat = "dd-MM-yyyy";
                    break;
            }
        }

        private void fnUsageRatio()
        {
            foreach (DataRow dr in dtTransducerReport.Rows)
            {
                if (Convert.ToDouble(dr[2]) > 0 && Convert.ToDouble(dr[5]) > 0)
                {
                    dr[4] = Math.Round((((Convert.ToDouble(dr[5]) / 6) * Convert.ToDouble(dr[3])) / Convert.ToDouble(dr[2])) * 100, 0);
                }
                else if (Convert.ToDouble(dr[2]) > 0 && Convert.ToDouble(dr[5]) == 0)
                {
                    dr[4] = Math.Round((((Convert.ToDouble(dr[6]) / 12) * Convert.ToDouble(dr[3])) / Convert.ToDouble(dr[2])) * 100, 0);
                }

                else if (Convert.ToDouble(dr[2]) == 0 && Convert.ToDouble(dr[5]) > 0)
                {
                    dr[4] = 100;
                }
            }


        }

        private void Datagridviewcolor()
        {
            DataView view = dtTransducerReport.DefaultView;
            view.Sort = "StockAvailableUsageRatio DESC";
            dtTransducerReport = view.ToTable();

            foreach (DataGridViewRow row in dgvReportView.Rows)
            {
                if (Convert.ToDouble(row.Cells[4].Value.ToString()) >= 80)
                {
                    row.DefaultCellStyle.BackColor = Color.LightPink;
                }
                else if (Convert.ToDouble(row.Cells[4].Value) >= 60)
                {
                    row.DefaultCellStyle.BackColor = Color.Yellow;
                }
                else if (Convert.ToDouble(row.Cells[4].Value) >= 0 && Convert.ToDouble(row.Cells[4].Value) < 60)
                {
                    row.DefaultCellStyle.BackColor = Color.LightGreen;
                    //  dgpolist.Rows[dgpolist.Rows.IndexOf(row)].Cells[1].Style.BackColor = Color.Red;
                    //  POLate++;
                }
            }
        }

        private void fnUsageCount()
        {
            object value;
            foreach (DataRow dr in dtTransducerReport.Rows)
            {
                value = dr["6Months"];
                if (value == DBNull.Value)
                {
                    dr["6Months"] = 0;
                }
                value = dr["12Months"];
                if (value == DBNull.Value)
                {
                    dr["12Months"] = 0;
                }
            }

            if (dtTransducerReport.Rows.Count > 0)
            {
                Dictionary<string, double> dicSum = new Dictionary<string, double>();
                Dictionary<string, double> dicSum1 = new Dictionary<string, double>();
                foreach (DataRow row in dtTransducerReport.Rows)
                {
                    string group = row["ItemCode"].ToString();
                    double rate = Convert.ToDouble(row["6Months"]);

                    string group1 = row["ItemCode"].ToString();
                    double rate1 = Convert.ToDouble(row["12Months"]);

                    if (dicSum.ContainsKey(group))
                        dicSum[group] += rate;
                    else
                        dicSum.Add(group, rate);

                    if (dicSum1.ContainsKey(group1))
                        dicSum1[group1] += rate1;
                    else
                        dicSum1.Add(group1, rate1);
                }

                DataTable UniqueRecords = RemoveDuplicateRows(dtTransducerReport, "ItemCode");

                foreach (var group in dicSum)
                {
                    foreach (DataRow FinalItems in dtTransducerReport.Rows)
                    {
                        if (FinalItems["ItemCode"].ToString() == group.Key.ToString())
                        {
                            sQty = group.Value;
                            FinalItems["6Months"] = sQty;
                            break;
                        }
                    }
                }
                sQty = 0;
                foreach (var group1 in dicSum1)
                {
                    foreach (DataRow FinalItems in dtTransducerReport.Rows)
                    {
                        if (FinalItems["ItemCode"].ToString() == group1.Key.ToString())
                        {
                            sQty = group1.Value;
                            FinalItems["12Months"] = sQty;
                            break;
                        }
                    }
                }
            }
        }

        public DataTable RemoveDuplicateRows(DataTable table, string DistinctColumn)
        {
            try
            {
                ArrayList UniqueRecords = new ArrayList();
                ArrayList DuplicateRecords = new ArrayList();


                foreach (DataRow dRow in table.Rows)
                {
                    if (UniqueRecords.Contains(dRow[DistinctColumn]))
                        DuplicateRecords.Add(dRow);
                    else
                        UniqueRecords.Add(dRow[DistinctColumn]);

                }
                // Remove dupliate rows from DataTable added to DuplicateRecords
                if (DuplicateRecords.Count > 0)
                {
                    foreach (DataRow dRow in DuplicateRecords)
                    {
                        table.Rows.Remove(dRow);
                    }
                }
                // Return the clean DataTable which contains unique records.
                return table;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;

            }
        }


        BindingSource bsIteSearch = new BindingSource();
        DataTable dtClone = new DataTable();


        private void txtItemSearch_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtItemSearch.TextLength > 2)
            {
                if (dtTransducerReport.Rows.Count > 0)
                {
                    dtClone = dtTransducerReport.Copy();
                    bsIteSearch.DataSource = dtClone;

                    if (cmbReport.SelectedIndex == 10 || cmbReport.SelectedIndex == 4)
                    {
                        bsIteSearch.Filter = string.Format("ItemCode LIKE '%{0}%' OR ItemDescription LIKE '%{0}%' OR Projectcode  LIKE '%{0}%' OR ProjectDescription LIKE '%{0}%'", txtItemSearch.Text);
                        dgvReportView.DataSource = bsIteSearch;
                    }
                    else
                    {
                        bsIteSearch.Filter = string.Format("ItemCode LIKE '%{0}%' OR ItemDescription LIKE '%{0}%'", txtItemSearch.Text);
                        dgvReportView.DataSource = bsIteSearch;
                    }

                }
            }
            else
            {
                bsIteSearch.RemoveFilter();
            }
        }

        private void cmbProjectCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbProjectCode.SelectedIndex >= 0)
            {
                DataTable dt = new DataTable();
                dt = DAL.fnProjectList(cmbProjectCode.Text).Tables[0];
                if (dt.Rows.Count > 0)
                {
                    txtProjectCode.Text = dt.Rows[0]["ProjectDescription"].ToString();
                }
            }
        }

        private void btnProjectView_Click(object sender, EventArgs e)
        {
            ElectronicsReportIssue = 1;
            Indent.frmProjectselect projectsearch = new Indent.frmProjectselect();
            projectsearch.fnElectronicReportIssue = ElectronicsReportIssue.ToString();
            projectsearch.ShowDialog();
            if (fnProjectcode != null)
            {
                cmbProjectCode.Text = sProjectCode;
            }
        }

        private void frmKanBanReports_Load(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            if (cmbReport.SelectedIndex == 20 || cmbReport.SelectedIndex == 21)
            {
                var s6MonthsDate1 = dtpFromDate.Value.AddDays(-182);
                var s12MotnhsDate1 = dtpFromDate.Value.AddDays(-365);

                dtp6months.Value = s6MonthsDate1;
                dtptwelve.Value = s12MotnhsDate1;
            }
        }
    }
}
