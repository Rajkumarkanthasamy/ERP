﻿namespace Erp_Project_With_Buttons.KanBanProduct
{
    partial class frmKanBanHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmKanBanHome));
            this.lblName = new System.Windows.Forms.Label();
            this.btnBOM = new System.Windows.Forms.Button();
            this.btnTransducerItemReturn = new System.Windows.Forms.Button();
            this.btnTransStockAdjust = new System.Windows.Forms.Button();
            this.btnElectronicsStockAdjust = new System.Windows.Forms.Button();
            this.btnElectronicsReturn = new System.Windows.Forms.Button();
            this.btnEleBOM = new System.Windows.Forms.Button();
            this.btnEleIssue = new System.Windows.Forms.Button();
            this.btnEleLedger = new System.Windows.Forms.Button();
            this.btnEleProduct = new System.Windows.Forms.Button();
            this.btnTraIssue = new System.Windows.Forms.Button();
            this.btnReport = new System.Windows.Forms.Button();
            this.btnKanBanProduct = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.Indigo;
            this.lblName.Location = new System.Drawing.Point(281, 9);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(294, 29);
            this.lblName.TabIndex = 41;
            this.lblName.Text = "BiSS Inventory Management";
            // 
            // btnBOM
            // 
            this.btnBOM.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnBOM.Enabled = false;
            this.btnBOM.FlatAppearance.BorderSize = 0;
            this.btnBOM.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBOM.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnBOM.ForeColor = System.Drawing.Color.Black;
            this.btnBOM.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_copy_482;
            this.btnBOM.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnBOM.Location = new System.Drawing.Point(920, 247);
            this.btnBOM.Name = "btnBOM";
            this.btnBOM.Size = new System.Drawing.Size(96, 93);
            this.btnBOM.TabIndex = 51;
            this.btnBOM.Text = "Electronics BOM";
            this.btnBOM.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBOM.UseVisualStyleBackColor = false;
            this.btnBOM.Click += new System.EventHandler(this.btnBOM_Click);
            // 
            // btnTransducerItemReturn
            // 
            this.btnTransducerItemReturn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnTransducerItemReturn.Enabled = false;
            this.btnTransducerItemReturn.FlatAppearance.BorderSize = 0;
            this.btnTransducerItemReturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTransducerItemReturn.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnTransducerItemReturn.ForeColor = System.Drawing.Color.Black;
            this.btnTransducerItemReturn.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_return_purchase_48;
            this.btnTransducerItemReturn.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnTransducerItemReturn.Location = new System.Drawing.Point(509, 81);
            this.btnTransducerItemReturn.Name = "btnTransducerItemReturn";
            this.btnTransducerItemReturn.Size = new System.Drawing.Size(109, 93);
            this.btnTransducerItemReturn.TabIndex = 50;
            this.btnTransducerItemReturn.Text = "Transducers \r\nItem Return";
            this.btnTransducerItemReturn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnTransducerItemReturn.UseVisualStyleBackColor = false;
            this.btnTransducerItemReturn.Click += new System.EventHandler(this.btnTransducerStockAdjust_Click);
            // 
            // btnTransStockAdjust
            // 
            this.btnTransStockAdjust.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnTransStockAdjust.Enabled = false;
            this.btnTransStockAdjust.FlatAppearance.BorderSize = 0;
            this.btnTransStockAdjust.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTransStockAdjust.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnTransStockAdjust.ForeColor = System.Drawing.Color.Black;
            this.btnTransStockAdjust.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_data_recovery_481;
            this.btnTransStockAdjust.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnTransStockAdjust.Location = new System.Drawing.Point(732, 81);
            this.btnTransStockAdjust.Name = "btnTransStockAdjust";
            this.btnTransStockAdjust.Size = new System.Drawing.Size(109, 93);
            this.btnTransStockAdjust.TabIndex = 49;
            this.btnTransStockAdjust.Text = "Transducers \r\nStock Adjust";
            this.btnTransStockAdjust.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnTransStockAdjust.UseVisualStyleBackColor = false;
            this.btnTransStockAdjust.Click += new System.EventHandler(this.btnTransStockAdjust_Click);
            // 
            // btnElectronicsStockAdjust
            // 
            this.btnElectronicsStockAdjust.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnElectronicsStockAdjust.Enabled = false;
            this.btnElectronicsStockAdjust.FlatAppearance.BorderSize = 0;
            this.btnElectronicsStockAdjust.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnElectronicsStockAdjust.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnElectronicsStockAdjust.ForeColor = System.Drawing.Color.Black;
            this.btnElectronicsStockAdjust.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_replicate_rows_482;
            this.btnElectronicsStockAdjust.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnElectronicsStockAdjust.Location = new System.Drawing.Point(732, 238);
            this.btnElectronicsStockAdjust.Name = "btnElectronicsStockAdjust";
            this.btnElectronicsStockAdjust.Size = new System.Drawing.Size(109, 93);
            this.btnElectronicsStockAdjust.TabIndex = 48;
            this.btnElectronicsStockAdjust.Text = "Electronics \r\nStock Adjust";
            this.btnElectronicsStockAdjust.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnElectronicsStockAdjust.UseVisualStyleBackColor = false;
            this.btnElectronicsStockAdjust.Click += new System.EventHandler(this.btnElectronicsStockAdjust_Click);
            // 
            // btnElectronicsReturn
            // 
            this.btnElectronicsReturn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnElectronicsReturn.Enabled = false;
            this.btnElectronicsReturn.FlatAppearance.BorderSize = 0;
            this.btnElectronicsReturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnElectronicsReturn.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnElectronicsReturn.ForeColor = System.Drawing.Color.Black;
            this.btnElectronicsReturn.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_transfer_482;
            this.btnElectronicsReturn.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnElectronicsReturn.Location = new System.Drawing.Point(509, 238);
            this.btnElectronicsReturn.Name = "btnElectronicsReturn";
            this.btnElectronicsReturn.Size = new System.Drawing.Size(109, 93);
            this.btnElectronicsReturn.TabIndex = 47;
            this.btnElectronicsReturn.Text = "Electronics \r\nItem Return";
            this.btnElectronicsReturn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnElectronicsReturn.UseVisualStyleBackColor = false;
            this.btnElectronicsReturn.Click += new System.EventHandler(this.btnElectronicsReturn_Click);
            // 
            // btnEleBOM
            // 
            this.btnEleBOM.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnEleBOM.Enabled = false;
            this.btnEleBOM.FlatAppearance.BorderSize = 0;
            this.btnEleBOM.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEleBOM.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnEleBOM.ForeColor = System.Drawing.Color.Black;
            this.btnEleBOM.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_product_481;
            this.btnEleBOM.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnEleBOM.Location = new System.Drawing.Point(45, 412);
            this.btnEleBOM.Name = "btnEleBOM";
            this.btnEleBOM.Size = new System.Drawing.Size(96, 93);
            this.btnEleBOM.TabIndex = 46;
            this.btnEleBOM.Text = "KANBAN \r\n BOM";
            this.btnEleBOM.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnEleBOM.UseVisualStyleBackColor = false;
            this.btnEleBOM.Click += new System.EventHandler(this.btnEleBOM_Click);
            // 
            // btnEleIssue
            // 
            this.btnEleIssue.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnEleIssue.Enabled = false;
            this.btnEleIssue.FlatAppearance.BorderSize = 0;
            this.btnEleIssue.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEleIssue.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnEleIssue.ForeColor = System.Drawing.Color.Black;
            this.btnEleIssue.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_paste_48__1_;
            this.btnEleIssue.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnEleIssue.Location = new System.Drawing.Point(276, 238);
            this.btnEleIssue.Name = "btnEleIssue";
            this.btnEleIssue.Size = new System.Drawing.Size(96, 102);
            this.btnEleIssue.TabIndex = 45;
            this.btnEleIssue.Text = "Electronic Issue";
            this.btnEleIssue.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnEleIssue.UseVisualStyleBackColor = false;
            this.btnEleIssue.Click += new System.EventHandler(this.btnEleIssue_Click);
            // 
            // btnEleLedger
            // 
            this.btnEleLedger.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnEleLedger.Enabled = false;
            this.btnEleLedger.FlatAppearance.BorderSize = 0;
            this.btnEleLedger.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEleLedger.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnEleLedger.ForeColor = System.Drawing.Color.Black;
            this.btnEleLedger.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_todo_list_482;
            this.btnEleLedger.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnEleLedger.Location = new System.Drawing.Point(263, 412);
            this.btnEleLedger.Name = "btnEleLedger";
            this.btnEleLedger.Size = new System.Drawing.Size(109, 93);
            this.btnEleLedger.TabIndex = 44;
            this.btnEleLedger.Text = "KANBAN \r\nItem Ledger";
            this.btnEleLedger.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnEleLedger.UseVisualStyleBackColor = false;
            this.btnEleLedger.Click += new System.EventHandler(this.btnEleLedger_Click);
            // 
            // btnEleProduct
            // 
            this.btnEleProduct.Enabled = false;
            this.btnEleProduct.FlatAppearance.BorderSize = 0;
            this.btnEleProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEleProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEleProduct.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnEleProduct.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_add_file_48__3_2;
            this.btnEleProduct.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnEleProduct.Location = new System.Drawing.Point(45, 238);
            this.btnEleProduct.Name = "btnEleProduct";
            this.btnEleProduct.Size = new System.Drawing.Size(109, 93);
            this.btnEleProduct.TabIndex = 43;
            this.btnEleProduct.Text = "Electronics Production";
            this.btnEleProduct.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnEleProduct.UseVisualStyleBackColor = true;
            this.btnEleProduct.Click += new System.EventHandler(this.btnEleProduct_Click);
            // 
            // btnTraIssue
            // 
            this.btnTraIssue.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnTraIssue.Enabled = false;
            this.btnTraIssue.FlatAppearance.BorderSize = 0;
            this.btnTraIssue.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTraIssue.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnTraIssue.ForeColor = System.Drawing.Color.Black;
            this.btnTraIssue.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_paste_48;
            this.btnTraIssue.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnTraIssue.Location = new System.Drawing.Point(276, 81);
            this.btnTraIssue.Name = "btnTraIssue";
            this.btnTraIssue.Size = new System.Drawing.Size(96, 93);
            this.btnTraIssue.TabIndex = 42;
            this.btnTraIssue.Text = "Transducer Issue";
            this.btnTraIssue.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnTraIssue.UseVisualStyleBackColor = false;
            this.btnTraIssue.Click += new System.EventHandler(this.btnTraIssue_Click);
            // 
            // btnReport
            // 
            this.btnReport.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnReport.Enabled = false;
            this.btnReport.FlatAppearance.BorderSize = 0;
            this.btnReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReport.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnReport.ForeColor = System.Drawing.Color.Black;
            this.btnReport.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_microsoft_excel_48;
            this.btnReport.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnReport.Location = new System.Drawing.Point(745, 429);
            this.btnReport.Name = "btnReport";
            this.btnReport.Size = new System.Drawing.Size(96, 93);
            this.btnReport.TabIndex = 12;
            this.btnReport.Text = "KANBAN \r\n Reports";
            this.btnReport.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnReport.UseVisualStyleBackColor = false;
            this.btnReport.Click += new System.EventHandler(this.btnReport_Click);
            // 
            // btnKanBanProduct
            // 
            this.btnKanBanProduct.Enabled = false;
            this.btnKanBanProduct.FlatAppearance.BorderSize = 0;
            this.btnKanBanProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKanBanProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKanBanProduct.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnKanBanProduct.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_add_list_481;
            this.btnKanBanProduct.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnKanBanProduct.Location = new System.Drawing.Point(45, 81);
            this.btnKanBanProduct.Name = "btnKanBanProduct";
            this.btnKanBanProduct.Size = new System.Drawing.Size(109, 100);
            this.btnKanBanProduct.TabIndex = 11;
            this.btnKanBanProduct.Text = "Transducer Production";
            this.btnKanBanProduct.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnKanBanProduct.UseVisualStyleBackColor = true;
            this.btnKanBanProduct.Click += new System.EventHandler(this.btnKanBanProduct_Click);
            // 
            // frmKanBanHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1052, 534);
            this.Controls.Add(this.btnBOM);
            this.Controls.Add(this.btnTransducerItemReturn);
            this.Controls.Add(this.btnTransStockAdjust);
            this.Controls.Add(this.btnElectronicsStockAdjust);
            this.Controls.Add(this.btnElectronicsReturn);
            this.Controls.Add(this.btnEleBOM);
            this.Controls.Add(this.btnEleIssue);
            this.Controls.Add(this.btnEleLedger);
            this.Controls.Add(this.btnEleProduct);
            this.Controls.Add(this.btnTraIssue);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.btnReport);
            this.Controls.Add(this.btnKanBanProduct);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmKanBanHome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "KANBAN Home";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmKanBanHome_FormClosing);
            this.Load += new System.EventHandler(this.frmKanBanHome_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnReport;
        private System.Windows.Forms.Button btnKanBanProduct;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Button btnTraIssue;
        private System.Windows.Forms.Button btnEleIssue;
        private System.Windows.Forms.Button btnEleLedger;
        private System.Windows.Forms.Button btnEleProduct;
        private System.Windows.Forms.Button btnEleBOM;
        private System.Windows.Forms.Button btnElectronicsReturn;
        private System.Windows.Forms.Button btnElectronicsStockAdjust;
        private System.Windows.Forms.Button btnTransStockAdjust;
        private System.Windows.Forms.Button btnTransducerItemReturn;
        private System.Windows.Forms.Button btnBOM;
    }
}