﻿namespace Erp_Project_With_Buttons.KanBanProduct
{
    partial class frmKanBanTransducerReturn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmKanBanTransducerReturn));
            this.lblUnitCost = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblAvailableQty = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblProjectCode = new System.Windows.Forms.Label();
            this.lblReturnedQty = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnrerurnExit = new System.Windows.Forms.Button();
            this.btnItemReturn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lblWorkOrderNo = new System.Windows.Forms.Label();
            this.cmbreturnItemcode = new System.Windows.Forms.ComboBox();
            this.lblItemcode = new System.Windows.Forms.Label();
            this.dtpReturndate = new System.Windows.Forms.DateTimePicker();
            this.lblIssuedQty = new System.Windows.Forms.Label();
            this.lblItemdescription = new System.Windows.Forms.Label();
            this.lblCustomer = new System.Windows.Forms.Label();
            this.lblProjdesc = new System.Windows.Forms.Label();
            this.lblItemDesc = new System.Windows.Forms.Label();
            this.lblNoofreturnitems = new System.Windows.Forms.Label();
            this.lbljobprojectcode = new System.Windows.Forms.Label();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.cmbIssuenumber = new System.Windows.Forms.ComboBox();
            this.txtreturnQuantity = new System.Windows.Forms.TextBox();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblUnitCost
            // 
            this.lblUnitCost.AutoSize = true;
            this.lblUnitCost.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUnitCost.ForeColor = System.Drawing.Color.Black;
            this.lblUnitCost.Location = new System.Drawing.Point(537, 243);
            this.lblUnitCost.Name = "lblUnitCost";
            this.lblUnitCost.Size = new System.Drawing.Size(20, 23);
            this.lblUnitCost.TabIndex = 242;
            this.lblUnitCost.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(439, 243);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 23);
            this.label5.TabIndex = 241;
            this.label5.Text = "Unit Cost :";
            // 
            // lblAvailableQty
            // 
            this.lblAvailableQty.AutoSize = true;
            this.lblAvailableQty.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAvailableQty.ForeColor = System.Drawing.Color.Black;
            this.lblAvailableQty.Location = new System.Drawing.Point(249, 243);
            this.lblAvailableQty.Name = "lblAvailableQty";
            this.lblAvailableQty.Size = new System.Drawing.Size(20, 23);
            this.lblAvailableQty.TabIndex = 240;
            this.lblAvailableQty.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(87, 243);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(166, 23);
            this.label3.TabIndex = 239;
            this.label3.Text = "Available Quantity :";
            // 
            // lblProjectCode
            // 
            this.lblProjectCode.AutoSize = true;
            this.lblProjectCode.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectCode.ForeColor = System.Drawing.Color.Black;
            this.lblProjectCode.Location = new System.Drawing.Point(255, 72);
            this.lblProjectCode.Name = "lblProjectCode";
            this.lblProjectCode.Size = new System.Drawing.Size(50, 23);
            this.lblProjectCode.TabIndex = 238;
            this.lblProjectCode.Text = "Code";
            // 
            // lblReturnedQty
            // 
            this.lblReturnedQty.AutoSize = true;
            this.lblReturnedQty.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturnedQty.ForeColor = System.Drawing.Color.Black;
            this.lblReturnedQty.Location = new System.Drawing.Point(249, 333);
            this.lblReturnedQty.Name = "lblReturnedQty";
            this.lblReturnedQty.Size = new System.Drawing.Size(20, 23);
            this.lblReturnedQty.TabIndex = 237;
            this.lblReturnedQty.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(22, 332);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(232, 23);
            this.label4.TabIndex = 236;
            this.label4.Text = "Number of Items Returned :";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnrerurnExit);
            this.groupBox4.Controls.Add(this.btnItemReturn);
            this.groupBox4.Location = new System.Drawing.Point(226, 425);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(830, 69);
            this.groupBox4.TabIndex = 235;
            this.groupBox4.TabStop = false;
            // 
            // btnrerurnExit
            // 
            this.btnrerurnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnrerurnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnrerurnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnrerurnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrerurnExit.Location = new System.Drawing.Point(709, 19);
            this.btnrerurnExit.Name = "btnrerurnExit";
            this.btnrerurnExit.Size = new System.Drawing.Size(76, 39);
            this.btnrerurnExit.TabIndex = 15;
            this.btnrerurnExit.Text = "Exit";
            this.btnrerurnExit.UseVisualStyleBackColor = false;
            this.btnrerurnExit.Click += new System.EventHandler(this.btnrerurnExit_Click);
            // 
            // btnItemReturn
            // 
            this.btnItemReturn.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnItemReturn.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnItemReturn.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItemReturn.Location = new System.Drawing.Point(522, 19);
            this.btnItemReturn.Name = "btnItemReturn";
            this.btnItemReturn.Size = new System.Drawing.Size(118, 39);
            this.btnItemReturn.TabIndex = 14;
            this.btnItemReturn.Text = "Return Item";
            this.btnItemReturn.UseVisualStyleBackColor = false;
            this.btnItemReturn.Click += new System.EventHandler(this.btnItemReturn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(813, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 23);
            this.label2.TabIndex = 234;
            this.label2.Text = "Return Date :";
            // 
            // lblWorkOrderNo
            // 
            this.lblWorkOrderNo.AutoSize = true;
            this.lblWorkOrderNo.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.lblWorkOrderNo.ForeColor = System.Drawing.Color.Black;
            this.lblWorkOrderNo.Location = new System.Drawing.Point(148, 25);
            this.lblWorkOrderNo.Name = "lblWorkOrderNo";
            this.lblWorkOrderNo.Size = new System.Drawing.Size(106, 23);
            this.lblWorkOrderNo.TabIndex = 233;
            this.lblWorkOrderNo.Text = "Issued No* :";
            // 
            // cmbreturnItemcode
            // 
            this.cmbreturnItemcode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbreturnItemcode.CausesValidation = false;
            this.cmbreturnItemcode.DropDownHeight = 130;
            this.cmbreturnItemcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbreturnItemcode.FormattingEnabled = true;
            this.cmbreturnItemcode.IntegralHeight = false;
            this.cmbreturnItemcode.Location = new System.Drawing.Point(259, 155);
            this.cmbreturnItemcode.Name = "cmbreturnItemcode";
            this.cmbreturnItemcode.Size = new System.Drawing.Size(272, 26);
            this.cmbreturnItemcode.TabIndex = 221;
            this.cmbreturnItemcode.SelectedIndexChanged += new System.EventHandler(this.cmbreturnItemcode_SelectedIndexChanged);
            // 
            // lblItemcode
            // 
            this.lblItemcode.AutoSize = true;
            this.lblItemcode.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemcode.ForeColor = System.Drawing.Color.Black;
            this.lblItemcode.Location = new System.Drawing.Point(144, 159);
            this.lblItemcode.Name = "lblItemcode";
            this.lblItemcode.Size = new System.Drawing.Size(109, 23);
            this.lblItemcode.TabIndex = 220;
            this.lblItemcode.Text = "Item Code* :";
            // 
            // dtpReturndate
            // 
            this.dtpReturndate.Enabled = false;
            this.dtpReturndate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpReturndate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpReturndate.Location = new System.Drawing.Point(935, 26);
            this.dtpReturndate.Name = "dtpReturndate";
            this.dtpReturndate.Size = new System.Drawing.Size(121, 26);
            this.dtpReturndate.TabIndex = 230;
            // 
            // lblIssuedQty
            // 
            this.lblIssuedQty.AutoSize = true;
            this.lblIssuedQty.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIssuedQty.ForeColor = System.Drawing.Color.Black;
            this.lblIssuedQty.Location = new System.Drawing.Point(249, 287);
            this.lblIssuedQty.Name = "lblIssuedQty";
            this.lblIssuedQty.Size = new System.Drawing.Size(20, 23);
            this.lblIssuedQty.TabIndex = 229;
            this.lblIssuedQty.Text = "0";
            // 
            // lblItemdescription
            // 
            this.lblItemdescription.AutoSize = true;
            this.lblItemdescription.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemdescription.ForeColor = System.Drawing.Color.Black;
            this.lblItemdescription.Location = new System.Drawing.Point(103, 205);
            this.lblItemdescription.Name = "lblItemdescription";
            this.lblItemdescription.Size = new System.Drawing.Size(151, 23);
            this.lblItemdescription.TabIndex = 222;
            this.lblItemdescription.Text = "Item Description :";
            // 
            // lblCustomer
            // 
            this.lblCustomer.AutoSize = true;
            this.lblCustomer.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomer.ForeColor = System.Drawing.Color.Black;
            this.lblCustomer.Location = new System.Drawing.Point(127, 112);
            this.lblCustomer.Name = "lblCustomer";
            this.lblCustomer.Size = new System.Drawing.Size(127, 23);
            this.lblCustomer.TabIndex = 228;
            this.lblCustomer.Text = "Project Name :";
            // 
            // lblProjdesc
            // 
            this.lblProjdesc.AutoSize = true;
            this.lblProjdesc.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjdesc.ForeColor = System.Drawing.Color.Black;
            this.lblProjdesc.Location = new System.Drawing.Point(255, 112);
            this.lblProjdesc.Name = "lblProjdesc";
            this.lblProjdesc.Size = new System.Drawing.Size(57, 23);
            this.lblProjdesc.TabIndex = 225;
            this.lblProjdesc.Text = "Name";
            // 
            // lblItemDesc
            // 
            this.lblItemDesc.AutoSize = true;
            this.lblItemDesc.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemDesc.ForeColor = System.Drawing.Color.Black;
            this.lblItemDesc.Location = new System.Drawing.Point(255, 205);
            this.lblItemDesc.Name = "lblItemDesc";
            this.lblItemDesc.Size = new System.Drawing.Size(48, 23);
            this.lblItemDesc.TabIndex = 224;
            this.lblItemDesc.Text = "Desc";
            // 
            // lblNoofreturnitems
            // 
            this.lblNoofreturnitems.AutoSize = true;
            this.lblNoofreturnitems.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoofreturnitems.ForeColor = System.Drawing.Color.Red;
            this.lblNoofreturnitems.Location = new System.Drawing.Point(46, 287);
            this.lblNoofreturnitems.Name = "lblNoofreturnitems";
            this.lblNoofreturnitems.Size = new System.Drawing.Size(208, 23);
            this.lblNoofreturnitems.TabIndex = 223;
            this.lblNoofreturnitems.Text = "Number of Items Issued :";
            // 
            // lbljobprojectcode
            // 
            this.lbljobprojectcode.AutoSize = true;
            this.lbljobprojectcode.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbljobprojectcode.ForeColor = System.Drawing.Color.Black;
            this.lbljobprojectcode.Location = new System.Drawing.Point(134, 72);
            this.lbljobprojectcode.Name = "lbljobprojectcode";
            this.lbljobprojectcode.Size = new System.Drawing.Size(120, 23);
            this.lbljobprojectcode.TabIndex = 232;
            this.lbljobprojectcode.Text = "Project Code :";
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantity.ForeColor = System.Drawing.Color.Black;
            this.lblQuantity.Location = new System.Drawing.Point(97, 373);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(156, 23);
            this.lblQuantity.TabIndex = 226;
            this.lblQuantity.Text = "Return Quantity* :";
            // 
            // cmbIssuenumber
            // 
            this.cmbIssuenumber.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbIssuenumber.DropDownHeight = 130;
            this.cmbIssuenumber.DropDownWidth = 181;
            this.cmbIssuenumber.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbIssuenumber.FormattingEnabled = true;
            this.cmbIssuenumber.IntegralHeight = false;
            this.cmbIssuenumber.Location = new System.Drawing.Point(260, 26);
            this.cmbIssuenumber.Name = "cmbIssuenumber";
            this.cmbIssuenumber.Size = new System.Drawing.Size(271, 26);
            this.cmbIssuenumber.TabIndex = 231;
            this.cmbIssuenumber.SelectedIndexChanged += new System.EventHandler(this.cmbIssuenumber_SelectedIndexChanged);
            // 
            // txtreturnQuantity
            // 
            this.txtreturnQuantity.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtreturnQuantity.Location = new System.Drawing.Point(253, 374);
            this.txtreturnQuantity.Name = "txtreturnQuantity";
            this.txtreturnQuantity.Size = new System.Drawing.Size(181, 26);
            this.txtreturnQuantity.TabIndex = 227;
            // 
            // frmKanBanTransducerReturn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1079, 518);
            this.Controls.Add(this.lblUnitCost);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblAvailableQty);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblProjectCode);
            this.Controls.Add(this.lblReturnedQty);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblWorkOrderNo);
            this.Controls.Add(this.cmbreturnItemcode);
            this.Controls.Add(this.lblItemcode);
            this.Controls.Add(this.dtpReturndate);
            this.Controls.Add(this.lblIssuedQty);
            this.Controls.Add(this.lblItemdescription);
            this.Controls.Add(this.lblCustomer);
            this.Controls.Add(this.lblProjdesc);
            this.Controls.Add(this.lblItemDesc);
            this.Controls.Add(this.lblNoofreturnitems);
            this.Controls.Add(this.lbljobprojectcode);
            this.Controls.Add(this.lblQuantity);
            this.Controls.Add(this.cmbIssuenumber);
            this.Controls.Add(this.txtreturnQuantity);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmKanBanTransducerReturn";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "KANBAN Transducer Return";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmKanBanTransducerReturn_FormClosing);
            this.Load += new System.EventHandler(this.frmKanBanTransducerReturn_Load);
            this.groupBox4.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblUnitCost;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblAvailableQty;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblProjectCode;
        private System.Windows.Forms.Label lblReturnedQty;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnrerurnExit;
        private System.Windows.Forms.Button btnItemReturn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblWorkOrderNo;
        private System.Windows.Forms.ComboBox cmbreturnItemcode;
        private System.Windows.Forms.Label lblItemcode;
        private System.Windows.Forms.DateTimePicker dtpReturndate;
        private System.Windows.Forms.Label lblIssuedQty;
        private System.Windows.Forms.Label lblItemdescription;
        private System.Windows.Forms.Label lblCustomer;
        private System.Windows.Forms.Label lblProjdesc;
        private System.Windows.Forms.Label lblItemDesc;
        private System.Windows.Forms.Label lblNoofreturnitems;
        private System.Windows.Forms.Label lbljobprojectcode;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.ComboBox cmbIssuenumber;
        private System.Windows.Forms.TextBox txtreturnQuantity;
    }
}