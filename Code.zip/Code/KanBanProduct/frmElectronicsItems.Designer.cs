﻿namespace Erp_Project_With_Buttons.KanBanProduct
{
    partial class frmElectronicsItems
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmElectronicsItems));
            this.lblIPTotalAmount = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.dgvopItemlist = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbControlButtons = new System.Windows.Forms.GroupBox();
            this.btnGenerateProduct = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.dgipitemlist = new System.Windows.Forms.DataGridView();
            this.IPItem = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IPItemDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IpUnits = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IPAvlbQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IPReqQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnItemAdd = new System.Windows.Forms.Panel();
            this.chkItemDesc = new System.Windows.Forms.CheckBox();
            this.chkItemCode = new System.Windows.Forms.CheckBox();
            this.chkopitem = new System.Windows.Forms.CheckBox();
            this.chkipitems = new System.Windows.Forms.CheckBox();
            this.lblItemDescription = new System.Windows.Forms.Label();
            this.txtItemDescription = new System.Windows.Forms.TextBox();
            this.chklbItemList = new System.Windows.Forms.CheckedListBox();
            this.tvProduct = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dgvopItemlist)).BeginInit();
            this.gbControlButtons.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgipitemlist)).BeginInit();
            this.pnItemAdd.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblIPTotalAmount
            // 
            this.lblIPTotalAmount.AutoSize = true;
            this.lblIPTotalAmount.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblIPTotalAmount.ForeColor = System.Drawing.Color.Black;
            this.lblIPTotalAmount.Location = new System.Drawing.Point(1095, 339);
            this.lblIPTotalAmount.Name = "lblIPTotalAmount";
            this.lblIPTotalAmount.Size = new System.Drawing.Size(17, 19);
            this.lblIPTotalAmount.TabIndex = 143;
            this.lblIPTotalAmount.Text = "0";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(1000, 338);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(97, 19);
            this.label19.TabIndex = 142;
            this.label19.Text = "I/P Amount :";
            // 
            // dgvopItemlist
            // 
            this.dgvopItemlist.AllowUserToAddRows = false;
            this.dgvopItemlist.AllowUserToDeleteRows = false;
            this.dgvopItemlist.AllowUserToResizeRows = false;
            this.dgvopItemlist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvopItemlist.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvopItemlist.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle29.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle29.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle29.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvopItemlist.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle29;
            this.dgvopItemlist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvopItemlist.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12});
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle35.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle35.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle35.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle35.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle35.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle35.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvopItemlist.DefaultCellStyle = dataGridViewCellStyle35;
            this.dgvopItemlist.EnableHeadersVisualStyles = false;
            this.dgvopItemlist.GridColor = System.Drawing.SystemColors.AppWorkspace;
            this.dgvopItemlist.Location = new System.Drawing.Point(619, 363);
            this.dgvopItemlist.MultiSelect = false;
            this.dgvopItemlist.Name = "dgvopItemlist";
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle36.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle36.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle36.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle36.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle36.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle36.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvopItemlist.RowHeadersDefaultCellStyle = dataGridViewCellStyle36;
            this.dgvopItemlist.RowHeadersVisible = false;
            this.dgvopItemlist.Size = new System.Drawing.Size(565, 201);
            this.dgvopItemlist.TabIndex = 141;
            this.dgvopItemlist.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgvopItemlist_CellBeginEdit);
            this.dgvopItemlist.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvopItemlist_CellEndEdit);
            this.dgvopItemlist.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvopItemlist_EditingControlShowing);
            this.dgvopItemlist.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvopItemlist_KeyUp);
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "ItemCode";
            this.dataGridViewTextBoxColumn6.HeaderText = "O/P Item";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn6.Width = 77;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn7.DataPropertyName = "ItemDescription";
            this.dataGridViewTextBoxColumn7.HeaderText = "Item Desc";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn7.Width = 86;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Units";
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn8.DefaultCellStyle = dataGridViewCellStyle30;
            this.dataGridViewTextBoxColumn8.HeaderText = "Unit";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn8.Width = 44;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "AvailableQty";
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn9.DefaultCellStyle = dataGridViewCellStyle31;
            this.dataGridViewTextBoxColumn9.HeaderText = "Stock Qty";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn9.Width = 82;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "ReqQty";
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.dataGridViewTextBoxColumn10.DefaultCellStyle = dataGridViewCellStyle32;
            this.dataGridViewTextBoxColumn10.HeaderText = "Produced Qty";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn10.Width = 110;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "UnitCost";
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn11.DefaultCellStyle = dataGridViewCellStyle33;
            this.dataGridViewTextBoxColumn11.HeaderText = "Unit Cost";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn11.Width = 77;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Amount";
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn12.DefaultCellStyle = dataGridViewCellStyle34;
            this.dataGridViewTextBoxColumn12.HeaderText = "Amount";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn12.Width = 71;
            // 
            // gbControlButtons
            // 
            this.gbControlButtons.Controls.Add(this.btnGenerateProduct);
            this.gbControlButtons.Controls.Add(this.btnExit);
            this.gbControlButtons.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.gbControlButtons.Location = new System.Drawing.Point(652, 570);
            this.gbControlButtons.Name = "gbControlButtons";
            this.gbControlButtons.Size = new System.Drawing.Size(532, 61);
            this.gbControlButtons.TabIndex = 140;
            this.gbControlButtons.TabStop = false;
            // 
            // btnGenerateProduct
            // 
            this.btnGenerateProduct.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnGenerateProduct.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnGenerateProduct.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnGenerateProduct.Location = new System.Drawing.Point(199, 12);
            this.btnGenerateProduct.Name = "btnGenerateProduct";
            this.btnGenerateProduct.Size = new System.Drawing.Size(194, 41);
            this.btnGenerateProduct.TabIndex = 11;
            this.btnGenerateProduct.Text = "Generate Product";
            this.btnGenerateProduct.UseVisualStyleBackColor = false;
            this.btnGenerateProduct.Click += new System.EventHandler(this.btnGenerateProduct_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnExit.Location = new System.Drawing.Point(408, 12);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(118, 41);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // dgipitemlist
            // 
            this.dgipitemlist.AllowUserToAddRows = false;
            this.dgipitemlist.AllowUserToDeleteRows = false;
            this.dgipitemlist.AllowUserToResizeRows = false;
            this.dgipitemlist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgipitemlist.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgipitemlist.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle37.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle37.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle37.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle37.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle37.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle37.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgipitemlist.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle37;
            this.dgipitemlist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgipitemlist.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IPItem,
            this.IPItemDesc,
            this.IpUnits,
            this.UnitCost,
            this.IPAvlbQty,
            this.IPReqQty});
            dataGridViewCellStyle41.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle41.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle41.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle41.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle41.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle41.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle41.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgipitemlist.DefaultCellStyle = dataGridViewCellStyle41;
            this.dgipitemlist.EnableHeadersVisualStyles = false;
            this.dgipitemlist.GridColor = System.Drawing.SystemColors.AppWorkspace;
            this.dgipitemlist.Location = new System.Drawing.Point(5, 240);
            this.dgipitemlist.MultiSelect = false;
            this.dgipitemlist.Name = "dgipitemlist";
            dataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle42.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle42.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle42.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle42.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle42.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle42.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgipitemlist.RowHeadersDefaultCellStyle = dataGridViewCellStyle42;
            this.dgipitemlist.RowHeadersVisible = false;
            this.dgipitemlist.Size = new System.Drawing.Size(608, 391);
            this.dgipitemlist.TabIndex = 139;
            this.dgipitemlist.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgipitemlist_CellBeginEdit);
            this.dgipitemlist.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgipitemlist_CellEndEdit);
            this.dgipitemlist.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgipitemlist_EditingControlShowing);
            this.dgipitemlist.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgipitemlist_KeyUp);
            // 
            // IPItem
            // 
            this.IPItem.DataPropertyName = "ItemCode";
            this.IPItem.HeaderText = "I/P Item";
            this.IPItem.Name = "IPItem";
            this.IPItem.ReadOnly = true;
            this.IPItem.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IPItem.Width = 70;
            // 
            // IPItemDesc
            // 
            this.IPItemDesc.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.IPItemDesc.DataPropertyName = "ItemDescription";
            this.IPItemDesc.HeaderText = "ItemDesc.";
            this.IPItemDesc.Name = "IPItemDesc";
            this.IPItemDesc.ReadOnly = true;
            this.IPItemDesc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IPItemDesc.Width = 82;
            // 
            // IpUnits
            // 
            this.IpUnits.DataPropertyName = "Units";
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.IpUnits.DefaultCellStyle = dataGridViewCellStyle38;
            this.IpUnits.HeaderText = "Units";
            this.IpUnits.Name = "IpUnits";
            this.IpUnits.ReadOnly = true;
            this.IpUnits.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IpUnits.Width = 50;
            // 
            // UnitCost
            // 
            this.UnitCost.DataPropertyName = "UnitCost";
            this.UnitCost.HeaderText = "UnitCost";
            this.UnitCost.Name = "UnitCost";
            this.UnitCost.ReadOnly = true;
            this.UnitCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitCost.Width = 73;
            // 
            // IPAvlbQty
            // 
            this.IPAvlbQty.DataPropertyName = "AvailableQty";
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.IPAvlbQty.DefaultCellStyle = dataGridViewCellStyle39;
            this.IPAvlbQty.HeaderText = "Avl Qty";
            this.IPAvlbQty.Name = "IPAvlbQty";
            this.IPAvlbQty.ReadOnly = true;
            this.IPAvlbQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IPAvlbQty.Width = 66;
            // 
            // IPReqQty
            // 
            this.IPReqQty.DataPropertyName = "ReqQty";
            dataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.IPReqQty.DefaultCellStyle = dataGridViewCellStyle40;
            this.IPReqQty.HeaderText = "Req Qty";
            this.IPReqQty.Name = "IPReqQty";
            this.IPReqQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IPReqQty.Width = 70;
            // 
            // pnItemAdd
            // 
            this.pnItemAdd.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnItemAdd.Controls.Add(this.chkItemDesc);
            this.pnItemAdd.Controls.Add(this.chkItemCode);
            this.pnItemAdd.Controls.Add(this.chkopitem);
            this.pnItemAdd.Controls.Add(this.chkipitems);
            this.pnItemAdd.Controls.Add(this.lblItemDescription);
            this.pnItemAdd.Controls.Add(this.txtItemDescription);
            this.pnItemAdd.Controls.Add(this.chklbItemList);
            this.pnItemAdd.Location = new System.Drawing.Point(5, 8);
            this.pnItemAdd.Name = "pnItemAdd";
            this.pnItemAdd.Size = new System.Drawing.Size(608, 226);
            this.pnItemAdd.TabIndex = 138;
            // 
            // chkItemDesc
            // 
            this.chkItemDesc.AutoSize = true;
            this.chkItemDesc.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemDesc.ForeColor = System.Drawing.Color.Black;
            this.chkItemDesc.Location = new System.Drawing.Point(265, -1);
            this.chkItemDesc.Name = "chkItemDesc";
            this.chkItemDesc.Size = new System.Drawing.Size(140, 23);
            this.chkItemDesc.TabIndex = 213;
            this.chkItemDesc.Text = "Item Description";
            this.chkItemDesc.UseVisualStyleBackColor = true;
            this.chkItemDesc.CheckedChanged += new System.EventHandler(this.chkItemDesc_CheckedChanged);
            // 
            // chkItemCode
            // 
            this.chkItemCode.AutoSize = true;
            this.chkItemCode.Checked = true;
            this.chkItemCode.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemCode.ForeColor = System.Drawing.Color.Black;
            this.chkItemCode.Location = new System.Drawing.Point(136, 0);
            this.chkItemCode.Name = "chkItemCode";
            this.chkItemCode.Size = new System.Drawing.Size(97, 23);
            this.chkItemCode.TabIndex = 212;
            this.chkItemCode.Text = "Item Code";
            this.chkItemCode.UseVisualStyleBackColor = true;
            this.chkItemCode.CheckedChanged += new System.EventHandler(this.chkItemCode_CheckedChanged);
            // 
            // chkopitem
            // 
            this.chkopitem.AutoSize = true;
            this.chkopitem.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkopitem.ForeColor = System.Drawing.Color.Black;
            this.chkopitem.Location = new System.Drawing.Point(236, 63);
            this.chkopitem.Name = "chkopitem";
            this.chkopitem.Size = new System.Drawing.Size(161, 23);
            this.chkopitem.TabIndex = 126;
            this.chkopitem.Text = "Add Output Item(s)";
            this.chkopitem.UseVisualStyleBackColor = true;
            this.chkopitem.CheckedChanged += new System.EventHandler(this.chkopitem_CheckedChanged);
            // 
            // chkipitems
            // 
            this.chkipitems.AutoSize = true;
            this.chkipitems.Checked = true;
            this.chkipitems.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkipitems.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkipitems.ForeColor = System.Drawing.Color.Black;
            this.chkipitems.Location = new System.Drawing.Point(11, 63);
            this.chkipitems.Name = "chkipitems";
            this.chkipitems.Size = new System.Drawing.Size(148, 23);
            this.chkipitems.TabIndex = 125;
            this.chkipitems.Text = "Add Input Item(s)";
            this.chkipitems.UseVisualStyleBackColor = true;
            this.chkipitems.CheckedChanged += new System.EventHandler(this.chkipitems_CheckedChanged);
            // 
            // lblItemDescription
            // 
            this.lblItemDescription.AutoSize = true;
            this.lblItemDescription.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblItemDescription.ForeColor = System.Drawing.Color.Black;
            this.lblItemDescription.Location = new System.Drawing.Point(7, 1);
            this.lblItemDescription.Name = "lblItemDescription";
            this.lblItemDescription.Size = new System.Drawing.Size(90, 19);
            this.lblItemDescription.TabIndex = 122;
            this.lblItemDescription.Text = "Search Item";
            // 
            // txtItemDescription
            // 
            this.txtItemDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemDescription.Location = new System.Drawing.Point(4, 22);
            this.txtItemDescription.Multiline = true;
            this.txtItemDescription.Name = "txtItemDescription";
            this.txtItemDescription.Size = new System.Drawing.Size(597, 38);
            this.txtItemDescription.TabIndex = 120;
            this.txtItemDescription.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemDescription_KeyUp);
            // 
            // chklbItemList
            // 
            this.chklbItemList.CheckOnClick = true;
            this.chklbItemList.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chklbItemList.FormattingEnabled = true;
            this.chklbItemList.HorizontalScrollbar = true;
            this.chklbItemList.Location = new System.Drawing.Point(4, 87);
            this.chklbItemList.Name = "chklbItemList";
            this.chklbItemList.Size = new System.Drawing.Size(597, 130);
            this.chklbItemList.TabIndex = 118;
            this.chklbItemList.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.chklbItemList_ItemCheck);
            // 
            // tvProduct
            // 
            this.tvProduct.Cursor = System.Windows.Forms.Cursors.Default;
            this.tvProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tvProduct.HideSelection = false;
            this.tvProduct.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.tvProduct.Location = new System.Drawing.Point(619, 8);
            this.tvProduct.Name = "tvProduct";
            this.tvProduct.Size = new System.Drawing.Size(366, 349);
            this.tvProduct.StateImageList = this.imageList1;
            this.tvProduct.TabIndex = 147;
            this.tvProduct.NodeMouseDoubleClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.tvProduct_NodeMouseDoubleClick);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "folderopened_yellow.ico");
            this.imageList1.Images.SetKeyName(1, "diagram_v2_17.ico");
            this.imageList1.Images.SetKeyName(2, "Dryicons-Aesthetica-2-Process-accept.ico");
            this.imageList1.Images.SetKeyName(3, "Dryicons-Aesthetica-2-Process-remove.ico");
            this.imageList1.Images.SetKeyName(4, "Rafiqul-Hassan-Blogger-Settings.ico");
            // 
            // frmElectronicsItems
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1189, 634);
            this.Controls.Add(this.tvProduct);
            this.Controls.Add(this.lblIPTotalAmount);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.dgvopItemlist);
            this.Controls.Add(this.gbControlButtons);
            this.Controls.Add(this.dgipitemlist);
            this.Controls.Add(this.pnItemAdd);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmElectronicsItems";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Electronics Production";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmElectronicsItems_FormClosing);
            this.Load += new System.EventHandler(this.frmElectronicsItems_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvopItemlist)).EndInit();
            this.gbControlButtons.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgipitemlist)).EndInit();
            this.pnItemAdd.ResumeLayout(false);
            this.pnItemAdd.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblIPTotalAmount;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.DataGridView dgvopItemlist;
        private System.Windows.Forms.GroupBox gbControlButtons;
        private System.Windows.Forms.Button btnGenerateProduct;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.DataGridView dgipitemlist;
        private System.Windows.Forms.Panel pnItemAdd;
        private System.Windows.Forms.CheckBox chkItemDesc;
        private System.Windows.Forms.CheckBox chkItemCode;
        private System.Windows.Forms.CheckBox chkopitem;
        private System.Windows.Forms.CheckBox chkipitems;
        private System.Windows.Forms.Label lblItemDescription;
        private System.Windows.Forms.TextBox txtItemDescription;
        private System.Windows.Forms.CheckedListBox chklbItemList;
        private System.Windows.Forms.TreeView tvProduct;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.DataGridViewTextBoxColumn IPItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn IPItemDesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn IpUnits;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn IPAvlbQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn IPReqQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
    }
}