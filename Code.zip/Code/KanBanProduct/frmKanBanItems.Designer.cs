﻿namespace Erp_Project_With_Buttons.KanBanProduct
{
    partial class frmKanBanItems
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmKanBanItems));
            this.pnItemAdd = new System.Windows.Forms.Panel();
            this.chkItemDesc = new System.Windows.Forms.CheckBox();
            this.chkItemCode = new System.Windows.Forms.CheckBox();
            this.chkopitem = new System.Windows.Forms.CheckBox();
            this.chkipitems = new System.Windows.Forms.CheckBox();
            this.lblItemDescription = new System.Windows.Forms.Label();
            this.txtItemDescription = new System.Windows.Forms.TextBox();
            this.chklbItemList = new System.Windows.Forms.CheckedListBox();
            this.dgipitemlist = new System.Windows.Forms.DataGridView();
            this.IPItem = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IPItemDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IpUnits = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IPAvlbQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IPReqQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnGenerateProduct = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.dgvopItemlist = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblIPTotalAmount = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.lblOPItemAmount = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnAddExtra = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtInsatallationCommision = new System.Windows.Forms.TextBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.tvProduct = new System.Windows.Forms.TreeView();
            this.btnAdd = new System.Windows.Forms.Button();
            this.pnItemAdd.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgipitemlist)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvopItemlist)).BeginInit();
            this.SuspendLayout();
            // 
            // pnItemAdd
            // 
            this.pnItemAdd.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnItemAdd.Controls.Add(this.chkItemDesc);
            this.pnItemAdd.Controls.Add(this.chkItemCode);
            this.pnItemAdd.Controls.Add(this.chkopitem);
            this.pnItemAdd.Controls.Add(this.chkipitems);
            this.pnItemAdd.Controls.Add(this.lblItemDescription);
            this.pnItemAdd.Controls.Add(this.txtItemDescription);
            this.pnItemAdd.Controls.Add(this.chklbItemList);
            this.pnItemAdd.Location = new System.Drawing.Point(10, 11);
            this.pnItemAdd.Name = "pnItemAdd";
            this.pnItemAdd.Size = new System.Drawing.Size(596, 226);
            this.pnItemAdd.TabIndex = 16;
            // 
            // chkItemDesc
            // 
            this.chkItemDesc.AutoSize = true;
            this.chkItemDesc.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemDesc.ForeColor = System.Drawing.Color.Black;
            this.chkItemDesc.Location = new System.Drawing.Point(265, -1);
            this.chkItemDesc.Name = "chkItemDesc";
            this.chkItemDesc.Size = new System.Drawing.Size(140, 23);
            this.chkItemDesc.TabIndex = 213;
            this.chkItemDesc.Text = "Item Description";
            this.chkItemDesc.UseVisualStyleBackColor = true;
            this.chkItemDesc.CheckedChanged += new System.EventHandler(this.chkItemDesc_CheckedChanged);
            // 
            // chkItemCode
            // 
            this.chkItemCode.AutoSize = true;
            this.chkItemCode.Checked = true;
            this.chkItemCode.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemCode.ForeColor = System.Drawing.Color.Black;
            this.chkItemCode.Location = new System.Drawing.Point(136, 0);
            this.chkItemCode.Name = "chkItemCode";
            this.chkItemCode.Size = new System.Drawing.Size(97, 23);
            this.chkItemCode.TabIndex = 212;
            this.chkItemCode.Text = "Item Code";
            this.chkItemCode.UseVisualStyleBackColor = true;
            this.chkItemCode.CheckedChanged += new System.EventHandler(this.chkItemCode_CheckedChanged);
            // 
            // chkopitem
            // 
            this.chkopitem.AutoSize = true;
            this.chkopitem.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkopitem.ForeColor = System.Drawing.Color.Black;
            this.chkopitem.Location = new System.Drawing.Point(236, 63);
            this.chkopitem.Name = "chkopitem";
            this.chkopitem.Size = new System.Drawing.Size(161, 23);
            this.chkopitem.TabIndex = 126;
            this.chkopitem.Text = "Add Output Item(s)";
            this.chkopitem.UseVisualStyleBackColor = true;
            this.chkopitem.CheckedChanged += new System.EventHandler(this.chkopitem_CheckedChanged);
            // 
            // chkipitems
            // 
            this.chkipitems.AutoSize = true;
            this.chkipitems.Checked = true;
            this.chkipitems.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkipitems.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkipitems.ForeColor = System.Drawing.Color.Black;
            this.chkipitems.Location = new System.Drawing.Point(11, 63);
            this.chkipitems.Name = "chkipitems";
            this.chkipitems.Size = new System.Drawing.Size(148, 23);
            this.chkipitems.TabIndex = 125;
            this.chkipitems.Text = "Add Input Item(s)";
            this.chkipitems.UseVisualStyleBackColor = true;
            this.chkipitems.CheckedChanged += new System.EventHandler(this.chkipitems_CheckedChanged);
            // 
            // lblItemDescription
            // 
            this.lblItemDescription.AutoSize = true;
            this.lblItemDescription.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblItemDescription.ForeColor = System.Drawing.Color.Black;
            this.lblItemDescription.Location = new System.Drawing.Point(7, 1);
            this.lblItemDescription.Name = "lblItemDescription";
            this.lblItemDescription.Size = new System.Drawing.Size(90, 19);
            this.lblItemDescription.TabIndex = 122;
            this.lblItemDescription.Text = "Search Item";
            // 
            // txtItemDescription
            // 
            this.txtItemDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemDescription.Location = new System.Drawing.Point(4, 22);
            this.txtItemDescription.Multiline = true;
            this.txtItemDescription.Name = "txtItemDescription";
            this.txtItemDescription.Size = new System.Drawing.Size(586, 38);
            this.txtItemDescription.TabIndex = 120;
            this.txtItemDescription.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemDescription_KeyUp);
            // 
            // chklbItemList
            // 
            this.chklbItemList.CheckOnClick = true;
            this.chklbItemList.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chklbItemList.FormattingEnabled = true;
            this.chklbItemList.HorizontalScrollbar = true;
            this.chklbItemList.Location = new System.Drawing.Point(4, 87);
            this.chklbItemList.Name = "chklbItemList";
            this.chklbItemList.Size = new System.Drawing.Size(586, 130);
            this.chklbItemList.TabIndex = 118;
            this.chklbItemList.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.chklbItemList_ItemCheck);
            // 
            // dgipitemlist
            // 
            this.dgipitemlist.AllowUserToAddRows = false;
            this.dgipitemlist.AllowUserToDeleteRows = false;
            this.dgipitemlist.AllowUserToResizeRows = false;
            this.dgipitemlist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgipitemlist.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgipitemlist.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgipitemlist.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgipitemlist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgipitemlist.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IPItem,
            this.IPItemDesc,
            this.IpUnits,
            this.UnitCost,
            this.IPAvlbQty,
            this.IPReqQty});
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgipitemlist.DefaultCellStyle = dataGridViewCellStyle7;
            this.dgipitemlist.EnableHeadersVisualStyles = false;
            this.dgipitemlist.GridColor = System.Drawing.SystemColors.AppWorkspace;
            this.dgipitemlist.Location = new System.Drawing.Point(10, 243);
            this.dgipitemlist.MultiSelect = false;
            this.dgipitemlist.Name = "dgipitemlist";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgipitemlist.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dgipitemlist.RowHeadersVisible = false;
            this.dgipitemlist.Size = new System.Drawing.Size(596, 347);
            this.dgipitemlist.TabIndex = 130;
            this.dgipitemlist.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgipitemlist_CellBeginEdit);
            this.dgipitemlist.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgipitemlist_CellEndEdit);
            this.dgipitemlist.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgipitemlist_CellEnter);
            this.dgipitemlist.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgipitemlist_EditingControlShowing);
            this.dgipitemlist.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgipitemlist_KeyUp);
            // 
            // IPItem
            // 
            this.IPItem.DataPropertyName = "ItemCode";
            this.IPItem.HeaderText = "I/P Item";
            this.IPItem.Name = "IPItem";
            this.IPItem.ReadOnly = true;
            this.IPItem.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IPItem.Width = 70;
            // 
            // IPItemDesc
            // 
            this.IPItemDesc.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.IPItemDesc.DataPropertyName = "ItemDescription";
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.IPItemDesc.DefaultCellStyle = dataGridViewCellStyle2;
            this.IPItemDesc.HeaderText = "ItemDesc.";
            this.IPItemDesc.Name = "IPItemDesc";
            this.IPItemDesc.ReadOnly = true;
            this.IPItemDesc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IPItemDesc.Width = 82;
            // 
            // IpUnits
            // 
            this.IpUnits.DataPropertyName = "Units";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.IpUnits.DefaultCellStyle = dataGridViewCellStyle3;
            this.IpUnits.HeaderText = "Units";
            this.IpUnits.Name = "IpUnits";
            this.IpUnits.ReadOnly = true;
            this.IpUnits.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IpUnits.Width = 50;
            // 
            // UnitCost
            // 
            this.UnitCost.DataPropertyName = "UnitCost";
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.UnitCost.DefaultCellStyle = dataGridViewCellStyle4;
            this.UnitCost.HeaderText = "UnitCost";
            this.UnitCost.Name = "UnitCost";
            this.UnitCost.ReadOnly = true;
            this.UnitCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitCost.Width = 73;
            // 
            // IPAvlbQty
            // 
            this.IPAvlbQty.DataPropertyName = "AvailableQty";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.IPAvlbQty.DefaultCellStyle = dataGridViewCellStyle5;
            this.IPAvlbQty.HeaderText = "Avl Qty";
            this.IPAvlbQty.Name = "IPAvlbQty";
            this.IPAvlbQty.ReadOnly = true;
            this.IPAvlbQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IPAvlbQty.Width = 66;
            // 
            // IPReqQty
            // 
            this.IPReqQty.DataPropertyName = "ReqQty";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.IPReqQty.DefaultCellStyle = dataGridViewCellStyle6;
            this.IPReqQty.HeaderText = "Req Qty";
            this.IPReqQty.Name = "IPReqQty";
            this.IPReqQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IPReqQty.Width = 70;
            // 
            // btnGenerateProduct
            // 
            this.btnGenerateProduct.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnGenerateProduct.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnGenerateProduct.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnGenerateProduct.Location = new System.Drawing.Point(880, 593);
            this.btnGenerateProduct.Name = "btnGenerateProduct";
            this.btnGenerateProduct.Size = new System.Drawing.Size(156, 41);
            this.btnGenerateProduct.TabIndex = 11;
            this.btnGenerateProduct.Text = "Generate Product";
            this.btnGenerateProduct.UseVisualStyleBackColor = false;
            this.btnGenerateProduct.Click += new System.EventHandler(this.btnWOGenerate_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnExit.Location = new System.Drawing.Point(1059, 593);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(118, 41);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // dgvopItemlist
            // 
            this.dgvopItemlist.AllowUserToAddRows = false;
            this.dgvopItemlist.AllowUserToDeleteRows = false;
            this.dgvopItemlist.AllowUserToResizeRows = false;
            this.dgvopItemlist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvopItemlist.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvopItemlist.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvopItemlist.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgvopItemlist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvopItemlist.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12});
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvopItemlist.DefaultCellStyle = dataGridViewCellStyle15;
            this.dgvopItemlist.EnableHeadersVisualStyles = false;
            this.dgvopItemlist.GridColor = System.Drawing.SystemColors.AppWorkspace;
            this.dgvopItemlist.Location = new System.Drawing.Point(612, 366);
            this.dgvopItemlist.MultiSelect = false;
            this.dgvopItemlist.Name = "dgvopItemlist";
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvopItemlist.RowHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.dgvopItemlist.RowHeadersVisible = false;
            this.dgvopItemlist.Size = new System.Drawing.Size(573, 224);
            this.dgvopItemlist.TabIndex = 132;
            this.dgvopItemlist.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgvopItemlist_CellBeginEdit);
            this.dgvopItemlist.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvopItemlist_CellEndEdit);
            this.dgvopItemlist.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvopItemlist_EditingControlShowing);
            this.dgvopItemlist.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvopItemlist_KeyUp);
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "ItemCode";
            this.dataGridViewTextBoxColumn6.HeaderText = "O/P Item";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn6.Width = 77;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn7.DataPropertyName = "ItemDescription";
            this.dataGridViewTextBoxColumn7.HeaderText = "Item Desc";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn7.Width = 86;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Units";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn8.DefaultCellStyle = dataGridViewCellStyle10;
            this.dataGridViewTextBoxColumn8.HeaderText = "Unit";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn8.Width = 44;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "AvailableQty";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn9.DefaultCellStyle = dataGridViewCellStyle11;
            this.dataGridViewTextBoxColumn9.HeaderText = "Stock Qty";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn9.Width = 82;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "ReqQty";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.dataGridViewTextBoxColumn10.DefaultCellStyle = dataGridViewCellStyle12;
            this.dataGridViewTextBoxColumn10.HeaderText = "Produced Qty";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn10.Width = 110;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "UnitCost";
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.dataGridViewTextBoxColumn11.DefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridViewTextBoxColumn11.HeaderText = "Unit Cost";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn11.Width = 77;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Amount";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn12.DefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridViewTextBoxColumn12.HeaderText = "Amount";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn12.Width = 71;
            // 
            // lblIPTotalAmount
            // 
            this.lblIPTotalAmount.AutoSize = true;
            this.lblIPTotalAmount.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblIPTotalAmount.ForeColor = System.Drawing.Color.Black;
            this.lblIPTotalAmount.Location = new System.Drawing.Point(1087, 293);
            this.lblIPTotalAmount.Name = "lblIPTotalAmount";
            this.lblIPTotalAmount.Size = new System.Drawing.Size(17, 19);
            this.lblIPTotalAmount.TabIndex = 134;
            this.lblIPTotalAmount.Text = "0";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(993, 293);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(97, 19);
            this.label19.TabIndex = 133;
            this.label19.Text = "I/P Amount :";
            // 
            // lblOPItemAmount
            // 
            this.lblOPItemAmount.AutoSize = true;
            this.lblOPItemAmount.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblOPItemAmount.ForeColor = System.Drawing.Color.Black;
            this.lblOPItemAmount.Location = new System.Drawing.Point(1087, 328);
            this.lblOPItemAmount.Name = "lblOPItemAmount";
            this.lblOPItemAmount.Size = new System.Drawing.Size(17, 19);
            this.lblOPItemAmount.TabIndex = 136;
            this.lblOPItemAmount.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(986, 327);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 19);
            this.label2.TabIndex = 135;
            this.label2.Text = "O/P Amount :";
            // 
            // btnAddExtra
            // 
            this.btnAddExtra.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAddExtra.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnAddExtra.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAddExtra.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnAddExtra.Location = new System.Drawing.Point(10, 596);
            this.btnAddExtra.Name = "btnAddExtra";
            this.btnAddExtra.Size = new System.Drawing.Size(161, 31);
            this.btnAddExtra.TabIndex = 137;
            this.btnAddExtra.Text = "Add Extra Charges";
            this.btnAddExtra.UseVisualStyleBackColor = false;
            this.btnAddExtra.Click += new System.EventHandler(this.btnAddExtra_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(281, 602);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 19);
            this.label1.TabIndex = 138;
            this.label1.Text = "O/P Quantity :";
            // 
            // txtInsatallationCommision
            // 
            this.txtInsatallationCommision.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtInsatallationCommision.Location = new System.Drawing.Point(389, 601);
            this.txtInsatallationCommision.Name = "txtInsatallationCommision";
            this.txtInsatallationCommision.Size = new System.Drawing.Size(57, 26);
            this.txtInsatallationCommision.TabIndex = 165;
            this.txtInsatallationCommision.Text = "0";
            this.txtInsatallationCommision.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtInsatallationCommision_KeyPress);
            this.txtInsatallationCommision.Leave += new System.EventHandler(this.txtInsatallationCommision_Leave);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "folderopened_yellow.ico");
            this.imageList1.Images.SetKeyName(1, "diagram_v2_17.ico");
            this.imageList1.Images.SetKeyName(2, "Dryicons-Aesthetica-2-Process-accept.ico");
            this.imageList1.Images.SetKeyName(3, "Dryicons-Aesthetica-2-Process-remove.ico");
            this.imageList1.Images.SetKeyName(4, "Rafiqul-Hassan-Blogger-Settings.ico");
            // 
            // tvProduct
            // 
            this.tvProduct.Cursor = System.Windows.Forms.Cursors.Default;
            this.tvProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tvProduct.HideSelection = false;
            this.tvProduct.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.tvProduct.Location = new System.Drawing.Point(612, 11);
            this.tvProduct.Name = "tvProduct";
            this.tvProduct.Size = new System.Drawing.Size(366, 349);
            this.tvProduct.StateImageList = this.imageList1;
            this.tvProduct.TabIndex = 166;
            this.tvProduct.NodeMouseDoubleClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.tvProduct_NodeMouseDoubleClick);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAdd.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAdd.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnAdd.Location = new System.Drawing.Point(453, 598);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(52, 31);
            this.btnAdd.TabIndex = 167;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // frmKanBanItems
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1189, 634);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.tvProduct);
            this.Controls.Add(this.txtInsatallationCommision);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnGenerateProduct);
            this.Controls.Add(this.btnAddExtra);
            this.Controls.Add(this.lblOPItemAmount);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblIPTotalAmount);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.dgvopItemlist);
            this.Controls.Add(this.dgipitemlist);
            this.Controls.Add(this.pnItemAdd);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.Name = "frmKanBanItems";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Transducer Production";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmKanBanItems_FormClosing);
            this.Load += new System.EventHandler(this.frmKanBanItems_Load);
            this.pnItemAdd.ResumeLayout(false);
            this.pnItemAdd.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgipitemlist)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvopItemlist)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnItemAdd;
        private System.Windows.Forms.CheckBox chkItemDesc;
        private System.Windows.Forms.CheckBox chkItemCode;
        private System.Windows.Forms.CheckBox chkopitem;
        private System.Windows.Forms.CheckBox chkipitems;
        private System.Windows.Forms.Label lblItemDescription;
        private System.Windows.Forms.TextBox txtItemDescription;
        private System.Windows.Forms.CheckedListBox chklbItemList;
        private System.Windows.Forms.DataGridView dgipitemlist;
        private System.Windows.Forms.Button btnGenerateProduct;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.DataGridView dgvopItemlist;
        private System.Windows.Forms.Label lblIPTotalAmount;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.Label lblOPItemAmount;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAddExtra;
        private System.Windows.Forms.DataGridViewTextBoxColumn IPItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn IPItemDesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn IpUnits;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn IPAvlbQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn IPReqQty;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtInsatallationCommision;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.TreeView tvProduct;
        private System.Windows.Forms.Button btnAdd;
    }
}