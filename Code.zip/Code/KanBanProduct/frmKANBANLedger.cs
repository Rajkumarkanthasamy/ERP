﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.KanBanProduct
{
    public partial class frmKANBANLedger : Form
    {
        public frmKANBANLedger()
        {
            InitializeComponent();
        }
        frmForm2 Home = new frmForm2();
        DataAccessLayer DAL = new DataAccessLayer();
        Global GLobalClass = new Global();
        Login.frmLoginForm LoginForm = new Login.frmLoginForm();
        DataView dvItemList = new DataView();
        DataTable dtItemList = new DataTable();
        DataTable dtIPItemList = new DataTable();

        private void chkItemCode_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemCode.CheckState == CheckState.Checked)
            {
                chkItemDesc.Checked = false;
            }
        }

        private void chkItemDesc_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemDesc.CheckState == CheckState.Checked)
            {
                chkItemCode.Checked = false;
            }
        }

        private void chkipitems_CheckedChanged(object sender, EventArgs e)
        {
            if (chkipitems.Checked)
            {
                chkopitem.Checked = false;
                dvItemList = GLobalClass.RowFilter(dtIPItemList, 0, txtItemDescription.Text);
                RowFilter();
            }
        }

        private void chkopitem_CheckedChanged(object sender, EventArgs e)
        {
            if (chkopitem.Checked)
            {
                chkipitems.Checked = false;
                dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);
                RowFilter();
            }
        }

        private void frmKANBANLedger_Load(object sender, EventArgs e)
        {
            fnLoadListLedger();
        }

        private void fnLoadListLedger()
        {
            if (chkElectronics.Checked)
            {
                dtIPItemList = DAL.fnKanBanElectronicsRawItemList(null).Tables[0];
                dtItemList = DAL.fnKanBanElectronicsFGItemList(0, null).Tables[0];
            }
            else if (chkTransducer.Checked)
            {
                dtIPItemList = DAL.fnKanBanItemList(null).Tables[0];
                dtItemList = DAL.fnKanBanFGItemList(0, null).Tables[0];
            }
        }

        #region ItemCode Filter Function
        private void RowFilter()
        {
            chklbItemList.Items.Clear();
            if (chkipitems.Checked == true)
            {
                foreach (DataRowView dv in dvItemList)
                {
                    chklbItemList.Items.Add(string.Concat(dv["ID"].ToString(), ") ", dv["ItemCode"].ToString(), ", ", dv["ItemDescription"].ToString(), ", ", dv["AvailableQty"].ToString()));
                }
            }
            else
            {
                foreach (DataRowView dv in dvItemList)
                {
                    chklbItemList.Items.Add(string.Concat(dv["ID"].ToString(), ") ", dv["ItemCode"].ToString(), ", ", dv["ItemDescription"].ToString(), ", ", dv["AvailableQty"].ToString()));
                }
            }
        }
        #endregion

        private void txtItemDescription_KeyUp(object sender, KeyEventArgs e)
        {
            if (chkipitems.Checked == true)
            {
                if (e.KeyCode == Keys.Back)
                {
                    if (chkItemCode.Checked == true)
                    {
                        if (txtItemDescription.TextLength > 2)
                        {
                            dvItemList = GLobalClass.RowFilter(dtIPItemList, 0, txtItemDescription.Text);

                            RowFilter();
                        }
                        else
                        {
                            RowFilter();
                        }
                    }
                    else if (chkItemDesc.Checked == true)
                    {
                        if (txtItemDescription.TextLength > 2)
                        {
                            dvItemList = GLobalClass.RowFilter(dtIPItemList, 1, txtItemDescription.Text);
                            RowFilter();
                        }
                        else
                        {
                            RowFilter();
                        }
                    }

                }
                else
                {
                    if (chkItemCode.Checked == true)
                    {
                        if (txtItemDescription.TextLength > 2)
                        {
                            dvItemList = GLobalClass.RowFilter(dtIPItemList, 0, txtItemDescription.Text);
                            RowFilter();
                        }
                        else
                        {
                            RowFilter();
                        }
                    }
                    else if (chkItemDesc.Checked == true)
                    {
                        if (txtItemDescription.TextLength > 2)
                        {
                            dvItemList = GLobalClass.RowFilter(dtIPItemList, 1, txtItemDescription.Text);
                            RowFilter();
                        }
                        else
                        {
                            RowFilter();
                        }
                    }
                }
            }
            else if (chkopitem.Checked)
            {
                if (e.KeyCode == Keys.Back)
                {
                    if (chkItemCode.Checked == true)
                    {
                        if (txtItemDescription.TextLength > 2)
                        {
                            dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);

                            RowFilter();
                        }
                        else
                        {
                            RowFilter();
                        }
                    }
                    else if (chkItemDesc.Checked == true)
                    {
                        if (txtItemDescription.TextLength > 2)
                        {
                            dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
                            RowFilter();
                        }
                        else
                        {
                            RowFilter();
                        }
                    }
                }
                else
                {
                    if (chkItemCode.Checked == true)
                    {
                        if (txtItemDescription.TextLength > 2)
                        {
                            dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);
                            RowFilter();
                        }
                        else
                        {
                            RowFilter();
                        }
                    }
                    else if (chkItemDesc.Checked == true)
                    {
                        if (txtItemDescription.TextLength > 2)
                        {
                            dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
                            RowFilter();
                        }
                        else
                        {
                            RowFilter();
                        }
                    }

                }
            }
        }
        string[] sItemCode;
        DataTable dtItemcode = new DataTable();
        double RecievedQTY;
        double IssuedQTY;
        double ReturnQTY;
        double StockAdjusted;
        bool bAllLedger = false;
        DataTable dtMaterialLedger = new DataTable();
        private void chklbItemList_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            try
            {
                bAllLedger = false;
                dgvALLLedgerReport.Visible = false;
                if (!chklbItemList.CheckedItems.Contains(chklbItemList.SelectedItem))
                {
                    sItemCode = chklbItemList.SelectedItem.ToString().Trim().Split(')');
                    string sID = sItemCode[0];
                    if (chkElectronics.Checked)
                    {
                        if (chkipitems.Checked)
                        {
                            dtItemcode = DAL.fnKanBanElectronicsItemList(22, sID).Tables[0];
                        }
                        else if (chkopitem.Checked)
                        {
                            dtItemcode = DAL.fnKanBanElectronicsItemList(33, sID).Tables[0];
                        }
                    }
                    else if (chkTransducer.Checked)
                    {
                        if (chkipitems.Checked)
                        {
                            dtItemcode = DAL.fnKanBanElectronicsItemList(221, sID).Tables[0];
                        }
                        else if (chkopitem.Checked)
                        {
                            dtItemcode = DAL.fnKanBanElectronicsItemList(331, sID).Tables[0];
                        }
                    }
                    if (dtItemcode.Rows.Count > 0)
                    {
                        lblRepeatitemcode.Text = dtItemcode.Rows[0]["Itemcode"].ToString();
                        lblitemname.Text = dtItemcode.Rows[0]["ItemDescription"].ToString();
                        lblrepeatCost.Text = dtItemcode.Rows[0]["UnitCost"].ToString() + " Rs";
                        lblavailableqty.Text = dtItemcode.Rows[0]["AvailableQty"].ToString(); //+ " " + dtItemcode.Rows[0]["Units"].ToString()
                        lblOpeningBalance.Text = dtItemcode.Rows[0]["OpeningQuantity"].ToString();
                        if (chkElectronics.Checked)
                        {
                            dtMaterialLedger = DAL.fnKanBanMaterialLedger(1, lblRepeatitemcode.Text, null, null).Tables[0];
                        }
                        else if (chkTransducer.Checked)
                        {
                            dtMaterialLedger = DAL.fnKanBanMaterialLedger(3, lblRepeatitemcode.Text, null, null).Tables[0];
                        }
                        if (dtMaterialLedger.Rows.Count > 0)
                        {
                            // lblNoitems.Visible = false;


                            DataView view = dtMaterialLedger.DefaultView;
                            view.Sort = "date ASC";
                            DataTable sortedDate = view.ToTable();

                            dgvmaterialLedger.AutoGenerateColumns = false;
                            dgvmaterialLedger.DataSource = sortedDate;

                            RecievedQTY = 0;
                            IssuedQTY = 0;
                            ReturnQTY = 0;
                            StockAdjusted = 0;
                            foreach (DataRow dgvr in dtMaterialLedger.Rows)
                            {
                                RecievedQTY += Convert.ToDouble(dgvr["RecievedQty"].ToString());
                                IssuedQTY += Convert.ToDouble(dgvr["IssuedQty"].ToString());
                                ReturnQTY += Convert.ToDouble(dgvr["OpeningQuantity"].ToString());
                                // StockAdjusted += Convert.ToDouble(dgvr["StockAdjsued"].ToString());
                            }
                            lblrecievqty.Text = (RecievedQTY + ReturnQTY).ToString();
                            lblissuedqty.Text = IssuedQTY.ToString();
                            // lblreturnqty.Text = ReturnQTY.ToString();
                            //  lblStockAdjusted.Text = StockAdjusted.ToString();
                            lblRecipt.Text = RecievedQTY.ToString();
                            lblIssue.Text = IssuedQTY.ToString();
                            //lblItemReturn.Text = ReturnQTY.ToString();
                            lblStockAdjused.Text = StockAdjusted.ToString();
                            lblClosingStock.Text = (Convert.ToDouble(lblOpeningBalance.Text) + RecievedQTY + IssuedQTY + StockAdjusted).ToString();

                        }
                        else
                        {
                            // lblNoitems.Visible = true;
                            dgvmaterialLedger.DataSource = null;
                            lblrecievqty.Text = "0";
                            lblissuedqty.Text = "0";
                            lblreturnqty.Text = "0";
                            lblStockAdjusted.Text = "0";
                            lblStockAdjused.Text = "0";

                            lblRecipt.Text = "0";
                            lblIssue.Text = "0";
                            lblStockAdjused.Text = "0";
                            lblClosingStock.Text = "0";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("PurchaseOrder_chklbItemList_ItemCheck" + ex.Message);
            }
        }

        private void btnmaterialledger_Click(object sender, EventArgs e)
        {

        }
        private void fnExit()
        {
            this.Hide();
            Home.Show();
        }
        private void frmKANBANLedger_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnExit();
        }

        private void chkElectronics_CheckedChanged(object sender, EventArgs e)
        {
            if (chkElectronics.Checked)
            {
                chkTransducer.Checked = false;
                chklbItemList.Items.Clear();
                fnLoadListLedger();
            }
        }

        private void chkTransducer_CheckedChanged(object sender, EventArgs e)
        {
            if (chkTransducer.Checked)
            {
                chkElectronics.Checked = false;
                chklbItemList.Items.Clear();
                fnLoadListLedger();
            }
        }
    }
}
