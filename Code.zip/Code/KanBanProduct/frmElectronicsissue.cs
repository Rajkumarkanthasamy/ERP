﻿using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.KanBanProduct
{
    public partial class frmElectronicsissue : Form
    {
        public frmElectronicsissue()
        {
            InitializeComponent();
        }

        frmForm2 Home = new frmForm2();
        DataAccessLayer DAL = new DataAccessLayer();
        Global GLobalClass = new Global();
        Login.frmLoginForm LoginForm = new Login.frmLoginForm();
        TreeNode tnCurrentParentNode = new TreeNode();
        DataTable dtTreeFromTable = new DataTable();
        DataTable dtProductItems = new DataTable();
        string[] sName;
        DataTable dtProjectList = new DataTable();

        public int ElectronicsIssue = 0;
        private static string sProjectCode;
        public string fnProjectcode
        {
            get
            {
                return sProjectCode;
            }
            set
            {
                sProjectCode = value;
            }
        }

        private bool bIPQuanity = true;
        private bool bIPQuanityHigh = true;
        private void fnQuantitycheck()
        {
            bIPQuanity = true;
            bIPQuanityHigh = true;

            int count = 0;
            foreach (DataGridViewRow row in dgIndentList.Rows)
            {
                dgIndentList.Rows[count].Cells[0].Style.BackColor = Color.White;
                dgIndentList.Rows[count].Cells[1].Style.BackColor = Color.White;
                dgIndentList.Rows[count].Cells[3].Style.BackColor = Color.White;
                count++;
            }
            count = 0;
            foreach (DataGridViewRow row in dgIndentList.Rows)
            {
                if (string.IsNullOrEmpty(row.Cells[5].Value.ToString()) || Convert.ToDouble(row.Cells[5].Value.ToString()) == 0)
                {
                    dgIndentList.Rows[count].Cells[0].Style.BackColor = Color.Red;
                    dgIndentList.Rows[count].Cells[1].Style.BackColor = Color.Red;
                    dgIndentList.Rows[count].Cells[3].Style.BackColor = Color.Red;
                }
                if (Convert.ToDouble(row.Cells[5].Value.ToString()) > Convert.ToDouble(row.Cells[3].Value.ToString()))
                {
                    dgIndentList.Rows[count].Cells[0].Style.BackColor = Color.Red;
                    dgIndentList.Rows[count].Cells[1].Style.BackColor = Color.Red;
                    dgIndentList.Rows[count].Cells[3].Style.BackColor = Color.Red;

                }
                count++;
            }

            foreach (DataGridViewRow row in dgIndentList.Rows)
            {
                if (string.IsNullOrEmpty(row.Cells[5].Value.ToString()) || Convert.ToDouble(row.Cells[5].Value.ToString()) == 0)
                {
                    bIPQuanity = false;
                    break;
                }

                if (Convert.ToDouble(row.Cells[5].Value.ToString()) > Convert.ToDouble(row.Cells[3].Value.ToString()))
                {
                    bIPQuanityHigh = false;
                    break;

                }
            }
        }

        DataTable dtProjectType = new DataTable();
        DataTable dtProjectAllCost = new DataTable();
        double dProjectCost = 0;
        double dCurrentIssuedAmount = 0;
        double dTotalProjectSum = 0;
        bool bProjectCost = true;
        private void fnProjectAmountCheck()
        {
            bProjectCost = true;
            dProjectCost = 0;
            dCurrentIssuedAmount = 0;
            dTotalProjectSum = 0;
            dtProjectType = DAL.fnProjectCostLimitCIP(0, cmbProjectCode.Text).Tables[0];
            if (dtProjectType.Rows.Count > 0)
            {
                if (dtProjectType.Rows[0]["ProjectType"].ToString() == "Fixed Asset (CIP)")
                {
                    dtProjectAllCost = DAL.fnProjectCostLimitCIP(2, cmbProjectCode.Text).Tables[0];

                    if (dtProjectAllCost.Rows.Count > 0)
                    {
                        dProjectCost = Convert.ToDouble(dtProjectAllCost.Rows[0]["TotalAmount"].ToString());
                        dTotalProjectSum = dtProjectAllCost.AsEnumerable().Sum(r => r.Field<double>("TotalAmount"));
                        dTotalProjectSum = dTotalProjectSum - dProjectCost;
                    }

                    dCurrentIssuedAmount = Convert.ToDouble(0);

                    foreach (DataGridViewRow drow in dgIndentList.Rows)
                    {
                        dCurrentIssuedAmount += Convert.ToDouble(drow.Cells["UnitCost"].Value) * Convert.ToDouble(drow.Cells["ReqQty"].Value);
                    }


                    if (dtProjectType.Rows[0]["Type"].ToString() == "Inhouse")
                    {
                        dProjectCost = (dProjectCost / 1.3);
                        if ((dTotalProjectSum + dCurrentIssuedAmount) < dProjectCost)
                        {
                            bProjectCost = true;
                        }
                        else
                        {
                            bProjectCost = false;
                        }
                    }
                }
            }
        }


        DataTable dtKanProductNo = new DataTable();
        string sKanProductNo;
        string sNewProduct;
        int iLastPONo;
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (cmbProjectCode.SelectedIndex >= 0 && dgIndentList.Rows.Count > 0 && !string.IsNullOrEmpty(txtRemarks.Text))
            {
                fnQuantitycheck();
                fnProjectAmountCheck();
                if (bIPQuanity && bIPQuanityHigh && bProjectCost)
                {
                    dtKanProductNo = DAL.KANElectronicsProductNo(1, null).Tables[0];
                    if (dtKanProductNo.Rows.Count > 0)
                    {
                        sKanProductNo = dtKanProductNo.Rows[0][1].ToString();
                        sNewProduct = sKanProductNo.Substring(02, 08);
                        iLastPONo = Convert.ToInt32(sNewProduct);
                        iLastPONo++;
                        sKanProductNo = "EI" + iLastPONo;

                        if (chkProductIssue.Checked)
                        {
                            foreach (DataGridViewRow row in dgIndentList.Rows)
                            {
                                GLobalClass.iSuccess = DAL.fnAddKanBanElectronicsIssued(1, row.Cells[0].Value.ToString(), "ElectronicsFG",
                                    Convert.ToDouble(row.Cells[5].Value.ToString()), Convert.ToDouble(row.Cells[4].Value.ToString()),
                                    LoginForm.GetUserDetails[2].ToString(), sKanProductNo, cmbProjectCode.Text, txtRemarks.Text);

                                GLobalClass.iSuccess = DAL.fnUpdateKanaBanElectronicsItemDetails(6, Convert.ToDouble(row.Cells[5].Value), row.Cells[0].Value.ToString());
                                GLobalClass.iSuccess = DAL.fnUpdateKanaBanElectronicsItemDetails(5, 0, row.Cells[0].Value.ToString());
                            }
                            GLobalClass.iSuccess = DAL.fnAddERPLog(0, sKanProductNo, LoginForm.GetUserDetails[2], dateTimePicker1.Text, "ElectronicsFG Issue", "KanBanElectronicsIssued");


                            if (cmbProjectCode.Text == "51423973035")
                            {
                                foreach (DataGridViewRow row in dgIndentList.Rows)
                                {
                                    GLobalClass.iSuccess = DAL.fnUpdateKanaBanItemDetails(1, Convert.ToDouble(row.Cells[5].Value), row.Cells[0].Value.ToString());
                                    GLobalClass.iSuccess = DAL.fnUpdateKanaBanItemDetails(2, Convert.ToDouble(row.Cells[5].Value), row.Cells[0].Value.ToString());

                                    if (GLobalClass.iSuccess > 0)
                                    {
                                        GLobalClass.iSuccess = DAL.fnAddKanBanReciept(0, row.Cells[0].Value.ToString(), Convert.ToDouble(row.Cells[5].Value),
                                           Convert.ToDouble(row.Cells[4].Value), dateTimePicker1.Text, sKanProductNo);
                                    }
                                }
                            }
                        }
                        else if (chkRawMaterailIssue.Checked)
                        {
                            foreach (DataGridViewRow row in dgIndentList.Rows)
                            {
                                GLobalClass.iSuccess = DAL.fnAddKanBanElectronicsIssued(1, row.Cells[0].Value.ToString(), "ElectronicsItem",
                                    Convert.ToDouble(row.Cells[5].Value.ToString()), Convert.ToDouble(row.Cells[4].Value.ToString()),
                                    LoginForm.GetUserDetails[2].ToString(), sKanProductNo, cmbProjectCode.Text, txtRemarks.Text);


                                GLobalClass.iSuccess = DAL.fnUpdateKanaBanElectronicsItemDetails(3, Convert.ToDouble(row.Cells[5].Value), row.Cells[0].Value.ToString());
                                GLobalClass.iSuccess = DAL.fnUpdateKanaBanElectronicsItemDetails(2, 0, row.Cells[0].Value.ToString());
                            }

                            GLobalClass.iSuccess = DAL.fnAddERPLog(0, sKanProductNo, LoginForm.GetUserDetails[2], dateTimePicker1.Text, "ElectronicsItem Issue", "KanBanElectronicsIssued");

                        }


                        MessageBox.Show("Items issued to the project successfully", "Success", 0, MessageBoxIcon.Information);
                        this.Hide();
                        frmElectronicsissue EI = new frmElectronicsissue();
                        EI.Show();
                    }
                }
                else
                {
                    if (!bIPQuanityHigh)
                    {
                        MessageBox.Show("Entered Item quantity is more than available quantity", "Error", 0, MessageBoxIcon.Error);
                    }
                    else if (!bIPQuanity)
                    {
                        MessageBox.Show("Enter Items quantity ", "Error", 0, MessageBoxIcon.Error);
                    }
                    else if (!bProjectCost)
                    {
                        MessageBox.Show("Issued items limit is more than capex amount.\nContact Accounts department for more details. \n \n Project Capex Amount : " + Math.Round(dProjectCost) + " \n Total Project Issued Amount : " + Math.Round(dTotalProjectSum) + " \n Current Project Issuing Amount : " + Math.Round(dCurrentIssuedAmount) + "", "Error", 0, MessageBoxIcon.Error);
                    }
                }

            }
            else
            {
                if (cmbProjectCode.SelectedIndex < 0)
                {
                    MessageBox.Show("Select the Project code", "Error", 0, MessageBoxIcon.Error);
                }
                else if (dgIndentList.Rows.Count == 0)
                {
                    MessageBox.Show("Select the items to issue", "Error", 0, MessageBoxIcon.Error);
                }
                else if (string.IsNullOrEmpty(txtRemarks.Text))
                {
                    MessageBox.Show("Enter remarks", "Error", 0, MessageBoxIcon.Error);
                    txtRemarks.Focus();
                }
            }
        }

        private void chkItemCode_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemCode.CheckState == CheckState.Checked)
            {
                chkItemDesc.Checked = false;
            }
        }

        private void frmElectronicsissue_Load(object sender, EventArgs e)
        {
            dtTreeFromTable = DAL.fnGetKBELProductTreeView().Tables[0];
            tvProduct.Nodes.AddRange(GLobalClass.fnTreeFromTable(dtTreeFromTable, "ParentID", "NodeID", "ProductName", "ImageIndex"));
            tnCurrentParentNode = null;
            tvProduct.Sort();

            dtProjectList = DAL.fnWIPProjectList(null).Tables[0];

            if (dtProjectList.Rows.Count > 0)
            {
                foreach (DataRow DR in dtProjectList.Rows)
                {
                    if (!cmbProjectCode.Items.Contains(DR["ProjectCode"].ToString()))
                        cmbProjectCode.Items.Add(DR["ProjectCode"].ToString());
                }
            }
            // chkProductIssue.Checked = true;
            chkItemCode.Checked = true;
        }

        private void btnProjectView_Click(object sender, EventArgs e)
        {
            ElectronicsIssue = 1;
            Indent.frmProjectselect projectsearch = new Indent.frmProjectselect();
            projectsearch.fnElectronicIssue = ElectronicsIssue.ToString();
            projectsearch.ShowDialog();
            if (fnProjectcode != null)
            {
                cmbProjectCode.Text = sProjectCode;
            }
        }

        DataTable dtProjectBOMdetails = new DataTable();
        private void cmbProjectCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtProjectBOMdetails = DAL.fnWIPProjectCode(cmbProjectCode.Text).Tables[0];
            if (dtProjectBOMdetails.Rows.Count > 0)
            {
                lblprojname.Text = dtProjectBOMdetails.Rows[0]["ProjectDescription"].ToString();
                lblcustomername.Text = dtProjectBOMdetails.Rows[0]["Customer"].ToString();
                lblProjectStatus.Text = dtProjectBOMdetails.Rows[0]["Status"].ToString();
            }
            else
            {
                lblprojname.ResetText();
                lblcustomername.ResetText();
                lblProjectStatus.ResetText();
            }
        }

        private void txtItemDescription_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar == '%' || e.KeyChar == '['))
            {
                e.Handled = true;
            }
        }
        DataView dvItemList = new DataView();
        DataTable dtItemList = new DataTable();

        private void RowFilter()
        {
            chklbItemList.Items.Clear();
            foreach (DataRowView dv in dvItemList)
            {
                chklbItemList.Items.Add(string.Concat(dv["ID"].ToString(), ") ", dv["ItemCode"].ToString(), ", ", dv["ItemDescription"].ToString(), ", ", dv["AvailableQty"].ToString()));
            }
        }

        private void chkProductIssue_CheckedChanged(object sender, EventArgs e)
        {
            if (chkProductIssue.Checked)
            {
                chkRawMaterailIssue.Enabled = false;
                chkRawMaterailIssue.Checked = false;
                dtItemList.Rows.Clear();
                dtItemList = DAL.fnKanBanElectronicsFGItemList(0, null).Tables[0];
                RowFilter();
            }
        }

        private void chkRawMaterailIssue_CheckedChanged(object sender, EventArgs e)
        {
            if (chkRawMaterailIssue.Checked)
            {
                chkProductIssue.Enabled = false;
                chkProductIssue.Checked = false;
                dtItemList.Rows.Clear();
                dtItemList = DAL.fnKanBanElectronicsRawItemList(null).Tables[0];
                RowFilter();
            }
        }

        private void txtItemDescription_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);
                    RowFilter();

                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
                    RowFilter();
                }
            }
            else
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);
                    RowFilter();
                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
                    RowFilter();
                }
            }
        }

        string[] sItemCode;
        DataTable dtItemcode = new DataTable();
        DataTable dtItemAdd = new DataTable();

        private void chklbItemList_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            try
            {
                int i = 0;
                if (chkProductIssue.Checked)
                {
                    sItemCode = chklbItemList.SelectedItem.ToString().Trim().Split(')');
                    string sID = sItemCode[0];
                    dtItemcode = DAL.fnKanBanElectronicsFGItemList(1, sID).Tables[0];
                    if (dtItemcode.Rows.Count > 0)
                    {
                        if (!chklbItemList.CheckedItems.Contains(chklbItemList.SelectedItem))
                        {
                            foreach (DataGridViewRow DGVR in dgIndentList.Rows)
                            {
                                if (DGVR.Cells["ItemCode"].Value.ToString().Equals(dtItemcode.Rows[0]["ItemCode"].ToString()))
                                {
                                    i = 1;
                                    break;
                                }
                            }
                            if (i != 1)
                            {
                                if (dtItemAdd.Rows.Count == 0)
                                {
                                    dtItemAdd = DAL.fnKanBanElectronicsFGItemList(1, "-9").Tables[0];
                                }

                                dtItemAdd.Rows.Add(dtItemcode.Rows[0]["ItemCode"].ToString(), dtItemcode.Rows[0]["ItemDescription"].ToString(),
                                                   dtItemcode.Rows[0]["Units"].ToString(), Convert.ToDouble(dtItemcode.Rows[0]["AvailableQty"].ToString()), dtItemcode.Rows[0]["UnitCost"].ToString(), dtItemcode.Rows[0]["ReqQty"].ToString());

                                dgIndentList.AutoGenerateColumns = false;
                                dgIndentList.DataSource = dtItemAdd;

                            }
                            else
                            {
                                MessageBox.Show("Selected Item already present in the list", "Error", 0, MessageBoxIcon.Error);
                                int k = chklbItemList.SelectedIndex;
                                chklbItemList.SetItemCheckState(k, CheckState.Unchecked);
                            }

                            foreach (DataGridViewRow dgr in dgIndentList.Rows)
                            {
                                if (Convert.ToDouble(dgr.Cells["AvailableQty"].Value) == Convert.ToDouble("0"))
                                {
                                    dgr.DefaultCellStyle.BackColor = Color.Red;
                                }
                            }
                        }
                        else
                        {
                            int rowIndex = -1;
                            bool bSelected;

                            foreach (DataGridViewRow row in dgIndentList.Rows)
                            {
                                bSelected = (row.Cells["ItemCode"].Value.ToString().Equals(dtItemcode.Rows[0]["ItemCode"].ToString()));
                                if (bSelected == true)
                                {
                                    rowIndex = row.Index;
                                    dgIndentList.Rows.Remove(dgIndentList.Rows[rowIndex]);
                                    break;
                                }
                            }
                        }
                    }
                }
                else if (chkRawMaterailIssue.Checked)
                {
                    sItemCode = chklbItemList.SelectedItem.ToString().Trim().Split(')');
                    string sID = sItemCode[0];
                    dtItemcode = DAL.fnKanBanElectronicsFGItemList(2, sID).Tables[0];
                    if (dtItemcode.Rows.Count > 0)
                    {
                        if (!chklbItemList.CheckedItems.Contains(chklbItemList.SelectedItem))
                        {
                            foreach (DataGridViewRow DGVR in dgIndentList.Rows)
                            {
                                if (DGVR.Cells["ItemCode"].Value.ToString().Equals(dtItemcode.Rows[0]["ItemCode"].ToString()))
                                {
                                    i = 1;
                                    break;
                                }
                            }
                            if (i != 1)
                            {
                                if (dtItemAdd.Rows.Count == 0)
                                {
                                    dtItemAdd = DAL.fnKanBanElectronicsFGItemList(2, "-9").Tables[0];
                                }

                                dtItemAdd.Rows.Add(dtItemcode.Rows[0]["ItemCode"].ToString(), dtItemcode.Rows[0]["ItemDescription"].ToString(),
                                                   dtItemcode.Rows[0]["Units"].ToString(), Convert.ToDouble(dtItemcode.Rows[0]["AvailableQty"].ToString()), dtItemcode.Rows[0]["UnitCost"].ToString(), dtItemcode.Rows[0]["ReqQty"].ToString());

                                dgIndentList.AutoGenerateColumns = false;
                                dgIndentList.DataSource = dtItemAdd;

                            }
                            else
                            {
                                MessageBox.Show("Selected Item already present in the list", "Error", 0, MessageBoxIcon.Error);
                                int k = chklbItemList.SelectedIndex;
                                chklbItemList.SetItemCheckState(k, CheckState.Unchecked);
                            }

                            foreach (DataGridViewRow dgr in dgIndentList.Rows)
                            {
                                if (Convert.ToDouble(dgr.Cells["AvailableQty"].Value) == Convert.ToDouble("0"))
                                {
                                    dgr.DefaultCellStyle.BackColor = Color.Red;
                                }
                            }
                        }
                        else
                        {
                            int rowIndex = -1;
                            bool bSelected;

                            foreach (DataGridViewRow row in dgIndentList.Rows)
                            {
                                bSelected = (row.Cells["ItemCode"].Value.ToString().Equals(dtItemcode.Rows[0]["ItemCode"].ToString()));
                                if (bSelected == true)
                                {
                                    rowIndex = row.Index;
                                    dgIndentList.Rows.Remove(dgIndentList.Rows[rowIndex]);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("PurchaseOrder_chklbItemList_ItemCheck" + ex.Message);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            fnExit();
        }

        private void fnExit()
        {
            this.Hide();
            Home.Show();
        }

        private void frmElectronicsissue_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnExit();
        }

        private void tvProduct_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Node.Parent != null && e.Node != null && (e.Node.StateImageIndex == 2 || e.Node.StateImageIndex == 3 || e.Node.StateImageIndex == 4))
            {
                //if (chkProductIssue.Checked)
                //{
                if (dgIndentList.Rows.Count == 0)
                {
                    sName = tvProduct.SelectedNode.Name.Split(')');
                    if (chkProductIssue.Checked)
                    {
                        dtProductItems = DAL.fnElectronicsProductMaster(3, sName[0]).Tables[0];
                    }
                    else if (chkRawMaterailIssue.Checked)
                    {
                        dtProductItems = DAL.fnElectronicsProductMaster(31, sName[0]).Tables[0];
                    }

                    if (dtItemAdd.Rows.Count == 0)
                    {
                        dtItemAdd = DAL.fnKanBanElectronicsFGItemList(2, "-9").Tables[0];
                    }


                    if (dtProductItems.Rows.Count > 0)
                    {
                        foreach (DataRow dr in dtProductItems.Rows)
                        {
                            dtItemAdd.Rows.Add(dr[0].ToString(), dr[1].ToString(),
                                dr[2].ToString(), Convert.ToDouble(dr[3].ToString()), Convert.ToDouble(dr[4].ToString()), Convert.ToDouble(dr[5].ToString()));
                        }
                    }

                    dgIndentList.AutoGenerateColumns = false;
                    dgIndentList.DataSource = dtItemAdd;
                }
                else
                {
                    MessageBox.Show("Remove other items to add the BOM directly", "Error", 0, MessageBoxIcon.Error);
                }
                //}
                //else
                //{
                //    MessageBox.Show("Only finished goods can be selected from BOM", "Error", 0, MessageBoxIcon.Error);
                //}
            }
        }

        private void chkItemDesc_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemDesc.CheckState == CheckState.Checked)
            {
                chkItemCode.Checked = false;
            }
        }
        double oldvalue;
        private void dgIndentList_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgIndentList.CurrentCell.OwningColumn.Name == "ReqQty")
            {
                oldvalue = Convert.ToDouble(dgIndentList.CurrentCell.Value);
            }
        }

        private void dgIndentList_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (!string.IsNullOrEmpty(dgIndentList.CurrentCell.Value.ToString()) && (dgIndentList.CurrentCell.Value.ToString() != "."))
            {
                if (Convert.ToDouble(dgIndentList.CurrentCell.Value.ToString()) != 0)
                {
                    if (Convert.ToDouble(dgIndentList.CurrentCell.Value.ToString()) <= Convert.ToDouble(dgIndentList.CurrentRow.Cells["AvailableQty"].Value.ToString()))
                    {

                    }
                    else
                    {
                        MessageBox.Show("Entered value should be equal or lesser than available quantity", "Error", 0, MessageBoxIcon.Error);
                        dgIndentList.CurrentCell.Value = oldvalue;
                    }
                }
                else
                {
                    MessageBox.Show("Entered value should be greater than 0", "Error", 0, MessageBoxIcon.Error);
                    dgIndentList.CurrentCell.Value = oldvalue;
                }
            }
            else
            {
                MessageBox.Show("Enter a Valid Value", "Error", 0, MessageBoxIcon.Error);
                dgIndentList.CurrentCell.Value = oldvalue;
            }
        }

        private void dgIndentList_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (dgIndentList.Rows.Count > 0)
                {
                    dgIndentList.Rows.RemoveAt(dgIndentList.Rows.IndexOf(dgIndentList.CurrentRow));
                }
            }
        }
        private void Control_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }
            // only allow one decimal point
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                e.Handled = true;
            }
        }
        private void dgIndentList_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show(" dgPackingTaxes_EditingControlShowing   " + ex.Message);
            }
        }

        private void btnAddExtra_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtInsatallationCommision.Text))
            {
                foreach (DataGridViewRow dgvr in dgIndentList.Rows)
                {
                    dgvr.Cells[5].Value = (Convert.ToDouble(dgvr.Cells[5].Value) * Convert.ToDouble(txtInsatallationCommision.Text)).ToString("0.##");
                }
                // fnIPTotal();
            }
        }
    }
}
