﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.KanBanProduct
{
    public partial class frmKanBanEReturn : Form
    {
        public frmKanBanEReturn()
        {
            InitializeComponent();
        }
        frmForm2 Home = new frmForm2();
        DataAccessLayer DAL = new DataAccessLayer();
        Global GLobalClass = new Global();
        Login.frmLoginForm LoginForm = new Login.frmLoginForm();
        DataTable dtEIssued = new DataTable();
        DataTable dtEIsssuedDetails = new DataTable();
        DataTable dtEIssuedItemQuantity = new DataTable();
        DataTable dtItemList = new DataTable();
        DataTable dtItemReturnList = new DataTable();

        private void fnExit()
        {
            this.Hide();
            Home.Show();
        }
        private void frmKanBanEReturn_Load(object sender, EventArgs e)
        {
            dtEIssued = DAL.fnTransducerReport(91, "", "", "").Tables[0];

            foreach (DataRow dr in dtEIssued.Rows)
            {
                if (!cmbIssuenumber.Items.Contains(dr["IssueNo"].ToString()))
                    cmbIssuenumber.Items.Add(dr["IssueNo"].ToString());
            }
        }

        private void frmKanBanEReturn_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnExit();
        }

        private void cmbIssuenumber_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtEIsssuedDetails = DAL.fnTransducerReport(92, cmbIssuenumber.Text, "", "").Tables[0];
            cmbreturnItemcode.Items.Clear();
            cmbreturnItemcode.Text = "";
            if (dtEIsssuedDetails.Rows.Count > 0)
            {
                foreach (DataRow dr in dtEIsssuedDetails.Rows)
                {
                    if (!cmbreturnItemcode.Items.Contains(dr["ItemCode"].ToString()))
                        cmbreturnItemcode.Items.Add(dr["ItemCode"].ToString());
                }

                DataView dvProjectList = new DataView(dtEIsssuedDetails);
                dvProjectList.RowFilter = "IssueNo Like'" + cmbIssuenumber.Text + "%'";
                DataTable dt = dvProjectList.ToTable();
                lblProjectCode.Text = dt.Rows[0]["Projectcode"].ToString();
                lblProjdesc.Text = dt.Rows[0]["ProjectDescription"].ToString();
            }
        }

        private void cmbreturnItemcode_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtItemList = DAL.fnTransducerReport(93, cmbreturnItemcode.Text, "", "").Tables[0];
            if (dtItemList.Rows.Count > 0)
            {
                lblItemDesc.Text = dtItemList.Rows[0]["ItemDescription"].ToString();
                lblAvailableQty.Text = dtItemList.Rows[0]["AvailableQty"].ToString();
                lblUnitCost.Text = dtItemList.Rows[0]["UnitCost"].ToString();
            }

            dtItemReturnList = DAL.fnTransducerReport(94, cmbreturnItemcode.Text, cmbIssuenumber.Text, "").Tables[0];

            if (!string.IsNullOrEmpty(dtItemReturnList.Rows[0][0].ToString()))
            {
                lblReturnedQty.Text = dtItemReturnList.Rows[0][0].ToString();
            }
            else
            {
                lblReturnedQty.Text = "0";
            }

            dtEIssuedItemQuantity = DAL.fnTransducerReport(95, cmbreturnItemcode.Text, cmbIssuenumber.Text, "").Tables[0];
            if (dtEIssuedItemQuantity.Rows.Count > 0)
            {
                lblIssuedQty.Text = dtEIssuedItemQuantity.Rows[0]["IssuedQuantity"].ToString();
            }
        }

        private void txtreturnQuantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        DataTable dtTransNo = new DataTable();
        string sKanProductNo;
        string sNewProduct;
        int iLastPONo;

        private void btnItemReturn_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtreturnQuantity.Text))
            {
                if (Convert.ToDouble(txtreturnQuantity.Text) > 0)
                {
                    if (Convert.ToDouble(txtreturnQuantity.Text) <= (Convert.ToDouble(lblIssuedQty.Text) - Convert.ToDouble(lblReturnedQty.Text)))
                    {
                        dtTransNo = DAL.KANElectronicsProductNo(2, null).Tables[0];
                        if (dtTransNo.Rows.Count > 0)
                        {
                            sKanProductNo = dtTransNo.Rows[0][1].ToString();
                            sNewProduct = sKanProductNo.Substring(03, 08);
                            iLastPONo = Convert.ToInt32(sNewProduct);
                            iLastPONo++;
                            sKanProductNo = "EIR" + iLastPONo;
                        }
                        else
                        {
                            sKanProductNo = "EIR20200001";
                        }

                        GLobalClass.iSuccess = DAL.fnItemReturnElectronicsIssued(0, cmbreturnItemcode.Text, lblUnitCost.Text, Convert.ToDouble(txtreturnQuantity.Text),
                            lblProjectCode.Text, (dtpReturndate.Text), LoginForm.GetUserDetails[2], sKanProductNo, cmbIssuenumber.Text);
                        GLobalClass.iSuccess = DAL.fnUpdateKanaBanElectronicsItemDetails(1, Convert.ToDouble(txtreturnQuantity.Text), cmbreturnItemcode.Text);
                        GLobalClass.iSuccess = DAL.fnUpdateKanaBanElectronicsItemDetails(2, Convert.ToDouble(txtreturnQuantity.Text), cmbreturnItemcode.Text);
                     //   if (GLobalClass.iSuccess == 0)
                        {
                            GLobalClass.iSuccess = DAL.fnUpdateKanaBanElectronicsItemDetails(4, Convert.ToDouble(txtreturnQuantity.Text), cmbreturnItemcode.Text);
                            GLobalClass.iSuccess = DAL.fnUpdateKanaBanElectronicsItemDetails(5, Convert.ToDouble(txtreturnQuantity.Text), cmbreturnItemcode.Text);
                        }

                        GLobalClass.iSuccess = DAL.fnAddERPLog(0, sKanProductNo, LoginForm.GetUserDetails[2], dtpReturndate.Text, "KanBanElectronics Item Return", "KanBanElectronicsItemReturn");

                        MessageBox.Show("Item " + lblItemDesc.Text + " quantity " + txtreturnQuantity.Text + " numbers returned.", "Success", 0, MessageBoxIcon.Information);
                        lblReturnedQty.Text = (Convert.ToDouble(lblReturnedQty.Text) + Convert.ToDouble(txtreturnQuantity.Text)).ToString();
                        txtreturnQuantity.Text="0";
                    }
                    else
                    {
                        MessageBox.Show("Return quantity more than Items Issued ! Items Not returned", "Error", 0, MessageBoxIcon.Error);
                        txtreturnQuantity.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Please Enter Quanity", "Error", 0, MessageBoxIcon.Error);
                    txtreturnQuantity.Focus();
                }
            }
            else
            {
                MessageBox.Show("Please Enter Quanity", "Error", 0, MessageBoxIcon.Error);
                txtreturnQuantity.Focus();
            }
        }

        private void btnrerurnExit_Click(object sender, EventArgs e)
        {
            fnExit();
        }
    }
}
