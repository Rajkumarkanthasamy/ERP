﻿
namespace Erp_Project_With_Buttons.KanBanProduct
{
    partial class frmProjectBOM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProjectBOM));
            this.chkRawMaterailIssue = new System.Windows.Forms.CheckBox();
            this.chkProductIssue = new System.Windows.Forms.CheckBox();
            this.dgIndentList = new System.Windows.Forms.DataGridView();
            this.ItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Unit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AvailableQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BOMQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LatestCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AddedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AddedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chkItemDesc = new System.Windows.Forms.CheckBox();
            this.chkItemCode = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.chklbItemList = new System.Windows.Forms.CheckedListBox();
            this.txtItemDescription = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.lblProjectStatus = new System.Windows.Forms.Label();
            this.lblcustomername = new System.Windows.Forms.Label();
            this.lblprojname = new System.Windows.Forms.Label();
            this.lblcustomer = new System.Windows.Forms.Label();
            this.lblProjectCode = new System.Windows.Forms.Label();
            this.cmbProjectCode = new System.Windows.Forms.ComboBox();
            this.lblProjectName = new System.Windows.Forms.Label();
            this.btnProjectView = new System.Windows.Forms.Button();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.tvProduct = new System.Windows.Forms.TreeView();
            this.lblItemcodeorName = new System.Windows.Forms.Label();
            this.txtItemSearch = new System.Windows.Forms.TextBox();
            this.lblIPTotalAmount = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.lblLatestCost = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnExporttoExcel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgIndentList)).BeginInit();
            this.SuspendLayout();
            // 
            // chkRawMaterailIssue
            // 
            this.chkRawMaterailIssue.AutoSize = true;
            this.chkRawMaterailIssue.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkRawMaterailIssue.ForeColor = System.Drawing.Color.Red;
            this.chkRawMaterailIssue.Location = new System.Drawing.Point(38, 8);
            this.chkRawMaterailIssue.Name = "chkRawMaterailIssue";
            this.chkRawMaterailIssue.Size = new System.Drawing.Size(102, 27);
            this.chkRawMaterailIssue.TabIndex = 245;
            this.chkRawMaterailIssue.Text = "Add Item";
            this.chkRawMaterailIssue.UseVisualStyleBackColor = true;
            this.chkRawMaterailIssue.CheckedChanged += new System.EventHandler(this.chkRawMaterailIssue_CheckedChanged);
            // 
            // chkProductIssue
            // 
            this.chkProductIssue.AutoSize = true;
            this.chkProductIssue.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkProductIssue.ForeColor = System.Drawing.Color.Red;
            this.chkProductIssue.Location = new System.Drawing.Point(172, 8);
            this.chkProductIssue.Name = "chkProductIssue";
            this.chkProductIssue.Size = new System.Drawing.Size(127, 27);
            this.chkProductIssue.TabIndex = 244;
            this.chkProductIssue.Text = "Add Product";
            this.chkProductIssue.UseVisualStyleBackColor = true;
            this.chkProductIssue.CheckedChanged += new System.EventHandler(this.chkProductIssue_CheckedChanged);
            // 
            // dgIndentList
            // 
            this.dgIndentList.AllowUserToAddRows = false;
            this.dgIndentList.AllowUserToDeleteRows = false;
            this.dgIndentList.AllowUserToResizeRows = false;
            this.dgIndentList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgIndentList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgIndentList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgIndentList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgIndentList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgIndentList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ItemCode,
            this.ItemDesc,
            this.ItemType,
            this.Unit,
            this.AvailableQty,
            this.BOMQuantity,
            this.UnitCost,
            this.LatestCost,
            this.AddedBy,
            this.AddedDate});
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgIndentList.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgIndentList.EnableHeadersVisualStyles = false;
            this.dgIndentList.Location = new System.Drawing.Point(403, 215);
            this.dgIndentList.MultiSelect = false;
            this.dgIndentList.Name = "dgIndentList";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgIndentList.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgIndentList.RowHeadersVisible = false;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgIndentList.RowsDefaultCellStyle = dataGridViewCellStyle7;
            this.dgIndentList.Size = new System.Drawing.Size(780, 405);
            this.dgIndentList.TabIndex = 242;
            this.dgIndentList.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgIndentList_CellBeginEdit);
            this.dgIndentList.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgIndentList_CellEndEdit);
            this.dgIndentList.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgIndentList_EditingControlShowing);
            this.dgIndentList.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgIndentList_KeyUp);
            // 
            // ItemCode
            // 
            this.ItemCode.DataPropertyName = "ItemCode";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ItemCode.DefaultCellStyle = dataGridViewCellStyle2;
            this.ItemCode.HeaderText = "Item Code";
            this.ItemCode.Name = "ItemCode";
            this.ItemCode.ReadOnly = true;
            this.ItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemCode.Width = 97;
            // 
            // ItemDesc
            // 
            this.ItemDesc.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ItemDesc.DataPropertyName = "ItemDescription";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ItemDesc.DefaultCellStyle = dataGridViewCellStyle3;
            this.ItemDesc.HeaderText = "Item Desc";
            this.ItemDesc.Name = "ItemDesc";
            this.ItemDesc.ReadOnly = true;
            this.ItemDesc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemDesc.Width = 99;
            // 
            // ItemType
            // 
            this.ItemType.DataPropertyName = "ItemType";
            this.ItemType.HeaderText = "ItemType";
            this.ItemType.Name = "ItemType";
            this.ItemType.ReadOnly = true;
            this.ItemType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemType.Width = 90;
            // 
            // Unit
            // 
            this.Unit.DataPropertyName = "Units";
            this.Unit.HeaderText = "Unit";
            this.Unit.Name = "Unit";
            this.Unit.ReadOnly = true;
            this.Unit.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Unit.Width = 50;
            // 
            // AvailableQty
            // 
            this.AvailableQty.DataPropertyName = "AvailableQty";
            this.AvailableQty.HeaderText = "Avl Qty";
            this.AvailableQty.Name = "AvailableQty";
            this.AvailableQty.ReadOnly = true;
            this.AvailableQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.AvailableQty.Width = 75;
            // 
            // BOMQuantity
            // 
            this.BOMQuantity.DataPropertyName = "BOMQuantity";
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.BOMQuantity.DefaultCellStyle = dataGridViewCellStyle4;
            this.BOMQuantity.HeaderText = "BOM Qty";
            this.BOMQuantity.Name = "BOMQuantity";
            this.BOMQuantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.BOMQuantity.Width = 90;
            // 
            // UnitCost
            // 
            this.UnitCost.DataPropertyName = "Unitprice";
            this.UnitCost.HeaderText = "Unit Cost";
            this.UnitCost.Name = "UnitCost";
            this.UnitCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitCost.Width = 89;
            // 
            // LatestCost
            // 
            this.LatestCost.DataPropertyName = "LatestCost";
            this.LatestCost.HeaderText = "Latest Cost";
            this.LatestCost.Name = "LatestCost";
            this.LatestCost.ReadOnly = true;
            this.LatestCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.LatestCost.Width = 104;
            // 
            // AddedBy
            // 
            this.AddedBy.DataPropertyName = "AddedBy";
            this.AddedBy.HeaderText = "Added By";
            this.AddedBy.Name = "AddedBy";
            this.AddedBy.ReadOnly = true;
            this.AddedBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.AddedBy.Width = 92;
            // 
            // AddedDate
            // 
            this.AddedDate.DataPropertyName = "AddedDate";
            this.AddedDate.HeaderText = "Added Date";
            this.AddedDate.Name = "AddedDate";
            this.AddedDate.ReadOnly = true;
            this.AddedDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.AddedDate.Width = 110;
            // 
            // chkItemDesc
            // 
            this.chkItemDesc.AutoSize = true;
            this.chkItemDesc.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemDesc.ForeColor = System.Drawing.Color.Black;
            this.chkItemDesc.Location = new System.Drawing.Point(263, 38);
            this.chkItemDesc.Name = "chkItemDesc";
            this.chkItemDesc.Size = new System.Drawing.Size(140, 23);
            this.chkItemDesc.TabIndex = 209;
            this.chkItemDesc.Text = "Item Description";
            this.chkItemDesc.UseVisualStyleBackColor = true;
            // 
            // chkItemCode
            // 
            this.chkItemCode.AutoSize = true;
            this.chkItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemCode.ForeColor = System.Drawing.Color.Black;
            this.chkItemCode.Location = new System.Drawing.Point(138, 38);
            this.chkItemCode.Name = "chkItemCode";
            this.chkItemCode.Size = new System.Drawing.Size(97, 23);
            this.chkItemCode.TabIndex = 208;
            this.chkItemCode.Text = "Item Code";
            this.chkItemCode.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(12, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 19);
            this.label3.TabIndex = 124;
            this.label3.Text = "Search Item by";
            // 
            // chklbItemList
            // 
            this.chklbItemList.CheckOnClick = true;
            this.chklbItemList.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chklbItemList.FormattingEnabled = true;
            this.chklbItemList.HorizontalScrollbar = true;
            this.chklbItemList.Location = new System.Drawing.Point(4, 111);
            this.chklbItemList.Name = "chklbItemList";
            this.chklbItemList.Size = new System.Drawing.Size(385, 172);
            this.chklbItemList.TabIndex = 117;
            this.chklbItemList.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.chklbItemList_ItemCheck);
            this.chklbItemList.SelectedIndexChanged += new System.EventHandler(this.chklbItemList_SelectedIndexChanged);
            // 
            // txtItemDescription
            // 
            this.txtItemDescription.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemDescription.Location = new System.Drawing.Point(4, 61);
            this.txtItemDescription.Multiline = true;
            this.txtItemDescription.Name = "txtItemDescription";
            this.txtItemDescription.Size = new System.Drawing.Size(385, 44);
            this.txtItemDescription.TabIndex = 121;
            this.txtItemDescription.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemDescription_KeyUp);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(430, 147);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(100, 18);
            this.label9.TabIndex = 240;
            this.label9.Text = "Project Status :";
            // 
            // lblProjectStatus
            // 
            this.lblProjectStatus.AutoSize = true;
            this.lblProjectStatus.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectStatus.ForeColor = System.Drawing.Color.Black;
            this.lblProjectStatus.Location = new System.Drawing.Point(528, 146);
            this.lblProjectStatus.Name = "lblProjectStatus";
            this.lblProjectStatus.Size = new System.Drawing.Size(12, 18);
            this.lblProjectStatus.TabIndex = 239;
            this.lblProjectStatus.Text = ".";
            // 
            // lblcustomername
            // 
            this.lblcustomername.AutoSize = true;
            this.lblcustomername.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcustomername.ForeColor = System.Drawing.Color.Black;
            this.lblcustomername.Location = new System.Drawing.Point(527, 115);
            this.lblcustomername.Name = "lblcustomername";
            this.lblcustomername.Size = new System.Drawing.Size(12, 18);
            this.lblcustomername.TabIndex = 238;
            this.lblcustomername.Text = ".";
            // 
            // lblprojname
            // 
            this.lblprojname.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprojname.ForeColor = System.Drawing.Color.Black;
            this.lblprojname.Location = new System.Drawing.Point(529, 51);
            this.lblprojname.Name = "lblprojname";
            this.lblprojname.Size = new System.Drawing.Size(515, 45);
            this.lblprojname.TabIndex = 237;
            this.lblprojname.Text = ".";
            // 
            // lblcustomer
            // 
            this.lblcustomer.AutoSize = true;
            this.lblcustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcustomer.ForeColor = System.Drawing.Color.Black;
            this.lblcustomer.Location = new System.Drawing.Point(455, 115);
            this.lblcustomer.Name = "lblcustomer";
            this.lblcustomer.Size = new System.Drawing.Size(75, 18);
            this.lblcustomer.TabIndex = 236;
            this.lblcustomer.Text = "Customer :";
            // 
            // lblProjectCode
            // 
            this.lblProjectCode.AutoSize = true;
            this.lblProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectCode.ForeColor = System.Drawing.Color.Black;
            this.lblProjectCode.Location = new System.Drawing.Point(436, 15);
            this.lblProjectCode.Name = "lblProjectCode";
            this.lblProjectCode.Size = new System.Drawing.Size(94, 18);
            this.lblProjectCode.TabIndex = 233;
            this.lblProjectCode.Text = "Project Code :";
            // 
            // cmbProjectCode
            // 
            this.cmbProjectCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProjectCode.DropDownHeight = 130;
            this.cmbProjectCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProjectCode.DropDownWidth = 239;
            this.cmbProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProjectCode.FormattingEnabled = true;
            this.cmbProjectCode.IntegralHeight = false;
            this.cmbProjectCode.Items.AddRange(new object[] {
            "None"});
            this.cmbProjectCode.Location = new System.Drawing.Point(532, 12);
            this.cmbProjectCode.Name = "cmbProjectCode";
            this.cmbProjectCode.Size = new System.Drawing.Size(286, 26);
            this.cmbProjectCode.TabIndex = 234;
            this.cmbProjectCode.SelectedIndexChanged += new System.EventHandler(this.cmbProjectCode_SelectedIndexChanged);
            // 
            // lblProjectName
            // 
            this.lblProjectName.AutoSize = true;
            this.lblProjectName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectName.ForeColor = System.Drawing.Color.Black;
            this.lblProjectName.Location = new System.Drawing.Point(434, 51);
            this.lblProjectName.Name = "lblProjectName";
            this.lblProjectName.Size = new System.Drawing.Size(99, 18);
            this.lblProjectName.TabIndex = 232;
            this.lblProjectName.Text = "Project Name :";
            // 
            // btnProjectView
            // 
            this.btnProjectView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnProjectView.Location = new System.Drawing.Point(824, 12);
            this.btnProjectView.Name = "btnProjectView";
            this.btnProjectView.Size = new System.Drawing.Size(24, 26);
            this.btnProjectView.TabIndex = 235;
            this.btnProjectView.Text = "....";
            this.btnProjectView.UseVisualStyleBackColor = false;
            this.btnProjectView.Click += new System.EventHandler(this.btnProjectView_Click);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "folderopened_yellow.ico");
            this.imageList1.Images.SetKeyName(1, "diagram_v2_17.ico");
            this.imageList1.Images.SetKeyName(2, "Dryicons-Aesthetica-2-Process-accept.ico");
            this.imageList1.Images.SetKeyName(3, "Dryicons-Aesthetica-2-Process-remove.ico");
            this.imageList1.Images.SetKeyName(4, "Rafiqul-Hassan-Blogger-Settings.ico");
            // 
            // tvProduct
            // 
            this.tvProduct.Cursor = System.Windows.Forms.Cursors.Default;
            this.tvProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tvProduct.HideSelection = false;
            this.tvProduct.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.tvProduct.Location = new System.Drawing.Point(4, 289);
            this.tvProduct.Name = "tvProduct";
            this.tvProduct.Size = new System.Drawing.Size(385, 331);
            this.tvProduct.StateImageList = this.imageList1;
            this.tvProduct.TabIndex = 246;
            this.tvProduct.NodeMouseDoubleClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.tvProduct_NodeMouseDoubleClick);
            // 
            // lblItemcodeorName
            // 
            this.lblItemcodeorName.AutoSize = true;
            this.lblItemcodeorName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemcodeorName.ForeColor = System.Drawing.Color.Black;
            this.lblItemcodeorName.Location = new System.Drawing.Point(409, 185);
            this.lblItemcodeorName.Name = "lblItemcodeorName";
            this.lblItemcodeorName.Size = new System.Drawing.Size(63, 19);
            this.lblItemcodeorName.TabIndex = 248;
            this.lblItemcodeorName.Text = "Search :";
            // 
            // txtItemSearch
            // 
            this.txtItemSearch.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtItemSearch.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemSearch.Location = new System.Drawing.Point(478, 182);
            this.txtItemSearch.Name = "txtItemSearch";
            this.txtItemSearch.Size = new System.Drawing.Size(295, 27);
            this.txtItemSearch.TabIndex = 247;
            this.txtItemSearch.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemSearch_KeyUp);
            // 
            // lblIPTotalAmount
            // 
            this.lblIPTotalAmount.AutoSize = true;
            this.lblIPTotalAmount.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblIPTotalAmount.ForeColor = System.Drawing.Color.Black;
            this.lblIPTotalAmount.Location = new System.Drawing.Point(1041, 147);
            this.lblIPTotalAmount.Name = "lblIPTotalAmount";
            this.lblIPTotalAmount.Size = new System.Drawing.Size(17, 19);
            this.lblIPTotalAmount.TabIndex = 250;
            this.lblIPTotalAmount.Text = "0";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(960, 147);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(84, 19);
            this.label19.TabIndex = 249;
            this.label19.Text = "Total Cost :";
            // 
            // lblLatestCost
            // 
            this.lblLatestCost.AutoSize = true;
            this.lblLatestCost.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblLatestCost.ForeColor = System.Drawing.Color.Black;
            this.lblLatestCost.Location = new System.Drawing.Point(1041, 182);
            this.lblLatestCost.Name = "lblLatestCost";
            this.lblLatestCost.Size = new System.Drawing.Size(17, 19);
            this.lblLatestCost.TabIndex = 252;
            this.lblLatestCost.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(915, 182);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 19);
            this.label2.TabIndex = 251;
            this.label2.Text = "Latest Total Cost :";
            // 
            // btnExporttoExcel
            // 
            this.btnExporttoExcel.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExporttoExcel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExporttoExcel.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExporttoExcel.Location = new System.Drawing.Point(1056, 8);
            this.btnExporttoExcel.Name = "btnExporttoExcel";
            this.btnExporttoExcel.Size = new System.Drawing.Size(126, 33);
            this.btnExporttoExcel.TabIndex = 253;
            this.btnExporttoExcel.Text = "Export to Excel";
            this.btnExporttoExcel.UseVisualStyleBackColor = false;
            this.btnExporttoExcel.Click += new System.EventHandler(this.btnExporttoExcel_Click);
            // 
            // frmProjectBOM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1194, 632);
            this.Controls.Add(this.btnExporttoExcel);
            this.Controls.Add(this.lblLatestCost);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblIPTotalAmount);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.lblItemcodeorName);
            this.Controls.Add(this.txtItemSearch);
            this.Controls.Add(this.tvProduct);
            this.Controls.Add(this.chkItemDesc);
            this.Controls.Add(this.chkItemCode);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.chklbItemList);
            this.Controls.Add(this.chkRawMaterailIssue);
            this.Controls.Add(this.txtItemDescription);
            this.Controls.Add(this.chkProductIssue);
            this.Controls.Add(this.dgIndentList);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lblProjectStatus);
            this.Controls.Add(this.lblcustomername);
            this.Controls.Add(this.lblprojname);
            this.Controls.Add(this.lblcustomer);
            this.Controls.Add(this.lblProjectCode);
            this.Controls.Add(this.cmbProjectCode);
            this.Controls.Add(this.lblProjectName);
            this.Controls.Add(this.btnProjectView);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmProjectBOM";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Electronics Project BOM";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmProjectBOM_FormClosing);
            this.Load += new System.EventHandler(this.frmProjectBOM_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgIndentList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.CheckBox chkRawMaterailIssue;
        private System.Windows.Forms.CheckBox chkProductIssue;
        private System.Windows.Forms.DataGridView dgIndentList;
        private System.Windows.Forms.CheckBox chkItemDesc;
        private System.Windows.Forms.CheckBox chkItemCode;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckedListBox chklbItemList;
        private System.Windows.Forms.TextBox txtItemDescription;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblProjectStatus;
        private System.Windows.Forms.Label lblcustomername;
        private System.Windows.Forms.Label lblprojname;
        private System.Windows.Forms.Label lblcustomer;
        private System.Windows.Forms.Label lblProjectCode;
        private System.Windows.Forms.ComboBox cmbProjectCode;
        private System.Windows.Forms.Label lblProjectName;
        private System.Windows.Forms.Button btnProjectView;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.TreeView tvProduct;
        private System.Windows.Forms.Label lblItemcodeorName;
        private System.Windows.Forms.TextBox txtItemSearch;
        private System.Windows.Forms.Label lblIPTotalAmount;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label lblLatestCost;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnExporttoExcel;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemType;
        private System.Windows.Forms.DataGridViewTextBoxColumn Unit;
        private System.Windows.Forms.DataGridViewTextBoxColumn AvailableQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn BOMQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn LatestCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn AddedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn AddedDate;
    }
}