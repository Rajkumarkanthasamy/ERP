﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.KanBanProduct
{
    public partial class frmElectronicsItems : Form
    {
        public frmElectronicsItems()
        {
            InitializeComponent();
        }
        frmForm2 Home = new frmForm2();
        DataAccessLayer DAL = new DataAccessLayer();
        Global GLobalClass = new Global();
        Login.frmLoginForm LoginForm = new Login.frmLoginForm();
        TreeNode tnCurrentParentNode = new TreeNode();
        DataTable dtTreeFromTable = new DataTable();
        DataTable dtProductItems = new DataTable();
        string[] sName;
        DataTable dtItemList = new DataTable();
        DataTable dtIPItemList = new DataTable();
        DataView dvItemList = new DataView();


        private bool bIPQuanity = true;
        private bool bOPQuanity = true;
        private bool bIPQuanityHigh = true;
        private void fnQuantitycheck()
        {
            bIPQuanity = true;
            bOPQuanity = true;
            bIPQuanityHigh = true;
            int count = 0;
            foreach (DataGridViewRow row in dgipitemlist.Rows)
            {
                dgipitemlist.Rows[count].Cells[0].Style.BackColor = Color.White;
                dgipitemlist.Rows[count].Cells[1].Style.BackColor = Color.White;
                dgipitemlist.Rows[count].Cells[4].Style.BackColor = Color.White;
                count++;
            }
            count = 0;

            foreach (DataGridViewRow row in dgipitemlist.Rows)
            {
                if (string.IsNullOrEmpty(row.Cells[5].Value.ToString()) || Convert.ToDouble(row.Cells[5].Value.ToString()) == 0)
                {
                    dgipitemlist.Rows[count].Cells[0].Style.BackColor = Color.Red;
                    dgipitemlist.Rows[count].Cells[1].Style.BackColor = Color.Red;
                    dgipitemlist.Rows[count].Cells[4].Style.BackColor = Color.Red;
                }

                if (Convert.ToDouble(row.Cells[5].Value.ToString()) > Convert.ToDouble(row.Cells[4].Value.ToString()))
                {
                    dgipitemlist.Rows[count].Cells[0].Style.BackColor = Color.Red;
                    dgipitemlist.Rows[count].Cells[1].Style.BackColor = Color.Red;
                    dgipitemlist.Rows[count].Cells[4].Style.BackColor = Color.Red;
                }
                count++;
            }
            foreach (DataGridViewRow row in dgipitemlist.Rows)
            {
                if (string.IsNullOrEmpty(row.Cells[5].Value.ToString()) || Convert.ToDouble(row.Cells[5].Value.ToString()) == 0)
                {
                    bIPQuanity = false;
                    break;
                }

                if (Convert.ToDouble(row.Cells[5].Value.ToString()) > Convert.ToDouble(row.Cells[4].Value.ToString()))
                {
                    bIPQuanityHigh = false;
                    break;
                }
            }

            foreach (DataGridViewRow row in dgvopItemlist.Rows)
            {
                if (string.IsNullOrEmpty(row.Cells[4].Value.ToString()) || Convert.ToDouble(row.Cells[4].Value.ToString()) == 0
                    || string.IsNullOrEmpty(row.Cells[5].Value.ToString()) || Convert.ToDouble(row.Cells[5].Value.ToString()) == 0)
                {
                    bOPQuanity = false;
                    break;
                }
            }
        }

        DataTable dtKanProductNo = new DataTable();
        string sKanProductNo = "";
        string sNewProduct = "";
        int iLastPONo;

        private void btnGenerateProduct_Click(object sender, EventArgs e)
        {
            if (dgipitemlist.Rows.Count > 0 && dgvopItemlist.Rows.Count > 0)
            {
                fnQuantitycheck();
                if (bOPQuanity && bIPQuanity & bIPQuanityHigh)
                {
                    dtKanProductNo = DAL.KANElectronicsProductNo(0, null).Tables[0];
                    if (dtKanProductNo.Rows.Count > 0)
                    {
                        sKanProductNo = dtKanProductNo.Rows[0][1].ToString();
                        sNewProduct = sKanProductNo.Substring(02, 08);
                        iLastPONo = Convert.ToInt32(sNewProduct);
                        iLastPONo++;
                        sKanProductNo = "EP" + iLastPONo;
                        string NowDate = DateTime.Now.ToString("dd-MM-yyyy");

                        foreach (DataGridViewRow row in dgipitemlist.Rows)
                        {
                            GLobalClass.iSuccess = DAL.fnAddKanBanElectronicsIssued(0, row.Cells[0].Value.ToString(), "ElectronicsItem",
                                Convert.ToDouble(row.Cells[5].Value.ToString()), Convert.ToDouble(row.Cells[3].Value.ToString()),
                                LoginForm.GetUserDetails[2].ToString(), sKanProductNo, row.Cells[1].Value.ToString(), "");

                            GLobalClass.iSuccess = DAL.fnUpdateKanaBanElectronicsItemDetails(3, Convert.ToDouble(row.Cells[5].Value), row.Cells[0].Value.ToString());
                        }

                        GLobalClass.iSuccess = DAL.fnAddERPLog(0, sKanProductNo, LoginForm.GetUserDetails[2], NowDate, "KanBanElectronics Item Issue", "KanBanElectronicsIssued");

                        foreach (DataGridViewRow row in dgvopItemlist.Rows)
                        {
                            GLobalClass.iSuccess = DAL.fnAddKanBanElectronicReciept(1, row.Cells[0].Value.ToString(), Convert.ToDouble(row.Cells[4].Value),
                                                                            Convert.ToDouble(row.Cells[5].Value), LoginForm.GetUserDetails[2].ToString(), sKanProductNo);

                            GLobalClass.iSuccess = DAL.fnUpdateKanaBanElectronicsItemDetails(4, Convert.ToDouble(row.Cells[4].Value), row.Cells[0].Value.ToString());
                            GLobalClass.iSuccess = DAL.fnUpdateKanaBanElectronicsItemDetails(5, Convert.ToDouble(row.Cells[4].Value), row.Cells[0].Value.ToString());
                        }

                        GLobalClass.iSuccess = DAL.fnAddERPLog(0, sKanProductNo, LoginForm.GetUserDetails[2], NowDate, "KanBanElectronics FG Production", "KanBanElectronicsProduction");
                        MessageBox.Show("Items added to the stock", "Success", 0, MessageBoxIcon.Information);
                        frmElectronicsItems EI = new frmElectronicsItems();
                        this.Hide();
                        EI.Show();
                    }
                }
                else
                {
                    if (!bOPQuanity)
                    {
                        MessageBox.Show("Enter Items quantity or unit price ", "Error", 0, MessageBoxIcon.Error);
                    }
                    else if (!bIPQuanityHigh)
                    {
                        MessageBox.Show("Entered Item quantity is more than available quantity", "Error", 0, MessageBoxIcon.Error);
                    }
                    else if (!bIPQuanity)
                    {
                        MessageBox.Show("Enter Items quantity ", "Error", 0, MessageBoxIcon.Error);
                    }

                }
            }
            else
            {
                if (dgvopItemlist.Rows.Count == 0)
                {
                    MessageBox.Show("Select Finished Product", "Error", 0, MessageBoxIcon.Error);
                }
                else if (dgipitemlist.Rows.Count == 0)
                {
                    MessageBox.Show("Select Items", "Error", 0, MessageBoxIcon.Error);
                }
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            fnExit();
        }

        private void frmElectronicsItems_Load(object sender, EventArgs e)
        {

            dtIPItemList = DAL.fnKanBanElectronicsRawItemList(null).Tables[0];
            dtItemList = DAL.fnKanBanElectronicsFGItemList(0, null).Tables[0];

            dtTreeFromTable = DAL.fnGetKBELProductTreeView().Tables[0];
            tvProduct.Nodes.AddRange(GLobalClass.fnTreeFromTable(dtTreeFromTable, "ParentID", "NodeID", "ProductName", "ImageIndex"));
            tnCurrentParentNode = null;
            tvProduct.Sort();
        }
        DataTable SalesProductMaster = new DataTable();
        private void tvProduct_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Node.Parent != null && e.Node != null && (e.Node.StateImageIndex == 2 || e.Node.StateImageIndex == 3 || e.Node.StateImageIndex == 4))
            {
                if (dgipitemlist.Rows.Count == 0)
                {
                    sName = tvProduct.SelectedNode.Name.Split(')');
                    dtProductItems = DAL.fnElectronicsProductMaster(2, sName[0]).Tables[0];


                    if (dtItemAdd.Rows.Count == 0)
                    {
                        dtItemAdd = DAL.fnKanBanElectronicsItemList(0, null).Tables[0];
                    }


                    if (dtProductItems.Rows.Count > 0)
                    {
                        foreach (DataRow dr in dtProductItems.Rows)
                        {
                            dtItemAdd.Rows.Add(dr[0].ToString(), dr[1].ToString(),
                                dr[2].ToString(), Convert.ToDouble(dr[3].ToString()), Convert.ToDouble(dr[4].ToString()), Convert.ToDouble(dr[5].ToString()));
                        }
                    }

                    dgipitemlist.AutoGenerateColumns = false;
                    dgipitemlist.DataSource = dtItemAdd;


                    SalesProductMaster = DAL.fnElectronicsProductMaster(0, sName[0]).Tables[0];
                    if (SalesProductMaster.Rows.Count > 0)
                    {
                        dtIPItem = new DataTable();

                        if (dtOPItemAdd.Rows.Count == 0)
                        {
                            dtOPItemAdd = DAL.fnKanBanElectronicsItemList(1, null).Tables[0];
                        }

                        dtIPItem = dtIPItem = DAL.fnKanBanElectronicsItemList(31, SalesProductMaster.Rows[0]["ProductCode"].ToString()).Tables[0];

                        if (dtIPItem.Rows.Count > 0)
                        {
                            dtOPItemAdd.Rows.Add(dtIPItem.Rows[0]["ItemCode"].ToString(), dtIPItem.Rows[0]["ItemDescription"].ToString(),
                                dtIPItem.Rows[0]["Units"].ToString(), Convert.ToDouble(dtIPItem.Rows[0]["AvailableQty"].ToString()), 0, Convert.ToDouble(dtIPItem.Rows[0]["UnitCost"].ToString()), 0);


                            dgvopItemlist.AutoGenerateColumns = false;
                            dgvopItemlist.DataSource = dtOPItemAdd;
                        }
                    }
                    fnIPTotal();
                }
                else
                {
                    MessageBox.Show("Remove other items to add the BOM directly", "Error", 0, MessageBoxIcon.Error);
                }
            }
        }
        string[] sItemCode;
        string sID;
        string sItemcodeCheck;
        DataTable dtItemAdd = new DataTable();
        DataTable dtOPItemAdd = new DataTable();
        DataTable dtIPItem = new DataTable();
        private void chklbItemList_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            if (chkipitems.Checked == true)
            {
                if (!chklbItemList.CheckedItems.Contains(chklbItemList.SelectedItem))
                {
                    sItemCode = chklbItemList.SelectedItem.ToString().Trim().Split(')');
                    sID = sItemCode[0];

                    // dtIPItem = dtItemList.Select("ID ='" + sID + "'").CopyToDataTable();

                    dtIPItem = DAL.fnKanBanElectronicsItemList(2, sID).Tables[0];
                    sItemcodeCheck = dtIPItem.Rows[0]["ItemCode"].ToString();
                    int i = 0;
                    foreach (DataGridViewRow DGVR in dgipitemlist.Rows)
                    {
                        if (DGVR.Cells["IPItem"].Value.ToString().Equals(sItemcodeCheck))
                        {
                            i = 1;
                            break;
                        }
                    }
                    if (i != 1)
                    {
                        if (dtItemAdd.Rows.Count == 0)
                        {
                            dtItemAdd = DAL.fnKanBanElectronicsItemList(0, null).Tables[0];
                        }

                        if (dtIPItem.Rows.Count > 0)
                        {
                            dtItemAdd.Rows.Add(dtIPItem.Rows[0]["ItemCode"].ToString(), dtIPItem.Rows[0]["ItemDescription"].ToString(),
                                dtIPItem.Rows[0]["Units"].ToString(), Convert.ToDouble(dtIPItem.Rows[0]["UnitCost"].ToString()), Convert.ToDouble(dtIPItem.Rows[0]["AvailableQty"].ToString()), 0);
                        }

                        dgipitemlist.AutoGenerateColumns = false;
                        dgipitemlist.DataSource = dtItemAdd;
                    }
                    else
                    {
                        MessageBox.Show("Selected Item already present in the list", "Error", 0, MessageBoxIcon.Error);
                        chklbItemList.SetItemCheckState(chklbItemList.SelectedIndex, CheckState.Unchecked);
                    }
                }
            }
            else if (chkopitem.Checked == true)
            {
                if (!chklbItemList.CheckedItems.Contains(chklbItemList.SelectedItem))
                {
                    sItemCode = chklbItemList.SelectedItem.ToString().Trim().Split(')');
                    sID = sItemCode[0];
                    dtIPItem = new DataTable();
                    // dtIPItem = dtItemList.Select("ID ='" + sID + "'").CopyToDataTable();

                    dtIPItem = DAL.fnKanBanElectronicsItemList(3, sID).Tables[0];
                    sItemcodeCheck = dtIPItem.Rows[0]["ItemCode"].ToString();
                    int i = 0;
                    foreach (DataGridViewRow DGVR in dgvopItemlist.Rows)
                    {
                        if (DGVR.Cells["dataGridViewTextBoxColumn6"].Value.ToString().Equals(sItemcodeCheck))
                        {
                            i = 1;
                            break;
                        }
                    }
                    if (i != 1)
                    {
                        if (dtOPItemAdd.Rows.Count == 0)
                        {
                            dtOPItemAdd = DAL.fnKanBanElectronicsItemList(1, null).Tables[0];
                        }

                        if (dtIPItem.Rows.Count > 0)
                        {
                            dtOPItemAdd.Rows.Add(dtIPItem.Rows[0]["ItemCode"].ToString(), dtIPItem.Rows[0]["ItemDescription"].ToString(),
                                dtIPItem.Rows[0]["Units"].ToString(), Convert.ToDouble(dtIPItem.Rows[0]["AvailableQty"].ToString()), 0, Convert.ToDouble(dtIPItem.Rows[0]["UnitCost"].ToString()), 0);
                        }

                        dgvopItemlist.AutoGenerateColumns = false;
                        dgvopItemlist.DataSource = dtOPItemAdd;
                    }
                    else
                    {
                        MessageBox.Show("Selected Item already present in the list", "Error", 0, MessageBoxIcon.Error);
                        chklbItemList.SetItemCheckState(chklbItemList.SelectedIndex, CheckState.Unchecked);
                    }
                }
            }
        }

        #region ItemCode Filter Function
        private void RowFilter()
        {
            chklbItemList.Items.Clear();
            if (chkipitems.Checked == true)
            {
                foreach (DataRowView dv in dvItemList)
                {
                    chklbItemList.Items.Add(string.Concat(dv["ID"].ToString(), ") ", dv["ItemCode"].ToString(), ", ", dv["ItemDescription"].ToString(), ", ", dv["AvailableQty"].ToString()));
                }
            }
            else
            {
                foreach (DataRowView dv in dvItemList)
                {
                    chklbItemList.Items.Add(string.Concat(dv["ID"].ToString(), ") ", dv["ItemCode"].ToString(), ", ", dv["ItemDescription"].ToString(), ", ", dv["AvailableQty"].ToString()));
                }
            }
        }
        #endregion

        private void chkItemCode_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemCode.CheckState == CheckState.Checked)
            {
                chkItemDesc.Checked = false;
            }
        }

        private void chkopitem_CheckedChanged(object sender, EventArgs e)
        {
            if (chkopitem.Checked)
            {
                chkipitems.Checked = false;
                dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);
                RowFilter();
            }
        }

        private void txtItemDescription_KeyUp(object sender, KeyEventArgs e)
        {
            if (chkipitems.Checked == true)
            {
                if (e.KeyCode == Keys.Back)
                {
                    if (chkItemCode.Checked == true)
                    {
                        if (txtItemDescription.TextLength > 2)
                        {
                            dvItemList = GLobalClass.RowFilter(dtIPItemList, 0, txtItemDescription.Text);

                            RowFilter();
                        }
                        else
                        {
                            RowFilter();
                        }
                    }
                    else if (chkItemDesc.Checked == true)
                    {
                        if (txtItemDescription.TextLength > 2)
                        {
                            dvItemList = GLobalClass.RowFilter(dtIPItemList, 1, txtItemDescription.Text);
                            RowFilter();
                        }
                        else
                        {
                            RowFilter();
                        }
                    }

                }
                else
                {
                    if (chkItemCode.Checked == true)
                    {
                        if (txtItemDescription.TextLength > 2)
                        {
                            dvItemList = GLobalClass.RowFilter(dtIPItemList, 0, txtItemDescription.Text);
                            RowFilter();
                        }
                        else
                        {
                            RowFilter();
                        }
                    }
                    else if (chkItemDesc.Checked == true)
                    {
                        if (txtItemDescription.TextLength > 2)
                        {
                            dvItemList = GLobalClass.RowFilter(dtIPItemList, 1, txtItemDescription.Text);
                            RowFilter();
                        }
                        else
                        {
                            RowFilter();
                        }
                    }
                }
            }
            else if (chkopitem.Checked)
            {
                if (e.KeyCode == Keys.Back)
                {
                    if (chkItemCode.Checked == true)
                    {
                        if (txtItemDescription.TextLength > 2)
                        {
                            dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);

                            RowFilter();
                        }
                        else
                        {
                            RowFilter();
                        }
                    }
                    else if (chkItemDesc.Checked == true)
                    {
                        if (txtItemDescription.TextLength > 2)
                        {
                            dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
                            RowFilter();
                        }
                        else
                        {
                            RowFilter();
                        }
                    }
                }
                else
                {
                    if (chkItemCode.Checked == true)
                    {
                        if (txtItemDescription.TextLength > 2)
                        {
                            dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);
                            RowFilter();
                        }
                        else
                        {
                            RowFilter();
                        }
                    }
                    else if (chkItemDesc.Checked == true)
                    {
                        if (txtItemDescription.TextLength > 2)
                        {
                            dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
                            RowFilter();
                        }
                        else
                        {
                            RowFilter();
                        }
                    }

                }
            }
        }

        private void chkItemDesc_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemDesc.CheckState == CheckState.Checked)
            {
                chkItemCode.Checked = false;
            }
        }

        private void chkipitems_CheckedChanged(object sender, EventArgs e)
        {
            if (chkipitems.Checked)
            {
                chkopitem.Checked = false;
                dvItemList = GLobalClass.RowFilter(dtIPItemList, 0, txtItemDescription.Text);
                RowFilter();
            }
        }
        private void fnExit()
        {
            this.Hide();
            Home.Show();
        }
        private void frmElectronicsItems_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnExit();
        }

        private void fnNumberKeyPressOnly(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            else if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
            if (e.KeyChar == 8)
            {
                if (((TextBox)sender).Text == "" || (((TextBox)sender).Text.Length < 1))
                {
                    ((TextBox)sender).Text = "0";
                }
            }
        }


        private void fnEmptyTextBox(object sender, EventArgs e)
        {
            if (((TextBox)sender).Text == "")
            {
                ((TextBox)sender).Text = "1";
            }
        }

        private void txtInsatallationCommision_TextChanged(object sender, EventArgs e)
        {

        }

        double dTotalIPAmount = 0;
        private void fnIPTotal()
        {
            dTotalIPAmount = 0;
            foreach (DataGridViewRow dgvr in dgipitemlist.Rows)
            {
                dTotalIPAmount += (Convert.ToDouble(dgvr.Cells[3].Value) * Convert.ToDouble(dgvr.Cells[5].Value));
            }

            lblIPTotalAmount.Text = dTotalIPAmount.ToString("0.##");

            if (dgvopItemlist.Rows.Count > 0)
            {
                if (Convert.ToDouble(dgvopItemlist.CurrentRow.Cells[4].Value) > 0)
                {
                    dgvopItemlist.CurrentRow.Cells[5].Value = (dTotalIPAmount / Convert.ToDouble(dgvopItemlist.CurrentRow.Cells[4].Value)).ToString("0.##");
                }
            }
        }

        double dOldQty = 0;
        private void dgipitemlist_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgipitemlist.CurrentCell.OwningColumn.Index == 5)
            {
                dOldQty = Convert.ToDouble(dgipitemlist.CurrentRow.Cells[5].Value);
            }
        }

        private void dgipitemlist_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (dgipitemlist.CurrentCell.OwningColumn.Index == 5 || dgipitemlist.CurrentCell.OwningColumn.Index == 3)
            {
                if (!string.IsNullOrEmpty(dgipitemlist.CurrentCell.Value.ToString()))
                {
                    if (!string.IsNullOrEmpty(dgipitemlist.CurrentCell.Value.ToString()) && (dgipitemlist.CurrentCell.Value.ToString() != ".") && Convert.ToDouble(dgipitemlist.CurrentCell.Value.ToString()) != 0)// )// && // != null)
                    {
                        if (Convert.ToDouble(dgipitemlist.CurrentRow.Cells[5].Value) <= Convert.ToDouble(dgipitemlist.CurrentRow.Cells[4].Value))
                        {
                            fnIPTotal();
                            //  dgipitemlist.CurrentRow.Cells[5].Value = (Convert.ToDouble(dgipitemlist.CurrentRow.Cells[4].Value) * Convert.ToDouble(dgipitemlist.CurrentRow.Cells[5].Value)).ToString();
                        }
                        else
                        {
                            MessageBox.Show("Enter Items quantity must be less than or equal to available quantity ", "Error", 0, MessageBoxIcon.Error);
                            dgipitemlist.CurrentCell.Value = dOldQty;
                        }
                    }
                    else
                    {
                        dgipitemlist.CurrentCell.Value = dOldQty;
                    }
                }
                else
                {
                    dgipitemlist.CurrentCell.Value = dOldQty;
                }
            }
        }

        private void Control_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }
            // only allow one decimal point
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                e.Handled = true;
            }
        }
        private void Control_KeyPress1(object sender, KeyPressEventArgs e)
        {
            e.Handled = false;
            //if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            //{
            //    e.Handled = true;
            //}
            //// only allow one decimal point
            //if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            //{
            //    e.Handled = true;
            //}
        }
        private void dgipitemlist_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (dgipitemlist.CurrentCell.OwningColumn.Index == 5 || dgipitemlist.CurrentCell.OwningColumn.Index == 3)
            {
                try
                {
                    e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(" dgPackingTaxes_EditingControlShowing   " + ex.Message);
                }
            }
            else
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress1);
            }
        }

        private void dgvopItemlist_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgvopItemlist.CurrentCell.OwningColumn.Index == 4 || dgvopItemlist.CurrentCell.OwningColumn.Index == 5)
            {
                dOldQty = Convert.ToDouble(dgvopItemlist.CurrentCell.Value);
            }
        }

        private void dgvopItemlist_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (!string.IsNullOrEmpty(dgvopItemlist.CurrentCell.Value.ToString()))
            {
                if (!string.IsNullOrEmpty(dgvopItemlist.CurrentCell.Value.ToString()) && (dgvopItemlist.CurrentCell.Value.ToString() != ".") && Convert.ToDouble(dgvopItemlist.CurrentCell.Value.ToString()) != 0)// )// && // != null)
                {
                    if (dgvopItemlist.CurrentCell.OwningColumn.Index == 4)
                    {
                        dtItemAdd = DAL.fnKanBanElectronicsItemList(0, null).Tables[0];
                        dgipitemlist.DataSource = null;
                        if (dtProductItems.Rows.Count > 0)
                        {
                            foreach (DataRow dr in dtProductItems.Rows)
                            {
                                dtItemAdd.Rows.Add(dr[0].ToString(), dr[1].ToString(),
                                    dr[2].ToString(), Convert.ToDouble(dr[3].ToString()), Convert.ToDouble(dr[4].ToString()), Convert.ToDouble(dr[5].ToString()));
                            }
                        }

                        dgipitemlist.AutoGenerateColumns = false;
                        dgipitemlist.DataSource = dtItemAdd;

                        foreach (DataGridViewRow dgvr in dgipitemlist.Rows)
                        {
                            dgvr.Cells[5].Value = (Convert.ToDouble(dgvr.Cells[5].Value) * Convert.ToDouble(dgvopItemlist.CurrentRow.Cells[4].Value)).ToString("0.##");
                        }
                        fnIPTotal();
                        dgvopItemlist.CurrentRow.Cells[6].Value = (Convert.ToDouble(dgvopItemlist.CurrentRow.Cells[4].Value) * Convert.ToDouble(dgvopItemlist.CurrentRow.Cells[5].Value)).ToString("0.##");

                    }

                }
                else
                {
                    dgvopItemlist.CurrentCell.Value = dOldQty;
                }
            }
            else
            {
                dgvopItemlist.CurrentCell.Value = dOldQty;
            }
        }

        private void dgvopItemlist_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show(" dgPackingTaxes_EditingControlShowing   " + ex.Message);
            }
        }

        private void dgvopItemlist_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (dgvopItemlist.Rows.Count > 0)
                {
                    dgvopItemlist.Rows.RemoveAt(dgvopItemlist.Rows.IndexOf(dgvopItemlist.CurrentRow));
                }
            }
        }

        private void dgipitemlist_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (dgipitemlist.Rows.Count > 0)
                {
                    dgipitemlist.Rows.RemoveAt(dgipitemlist.Rows.IndexOf(dgipitemlist.CurrentRow));
                }
            }
        }

    }
}
