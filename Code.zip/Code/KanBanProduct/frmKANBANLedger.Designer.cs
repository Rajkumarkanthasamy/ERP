﻿namespace Erp_Project_With_Buttons.KanBanProduct
{
    partial class frmKANBANLedger
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmKANBANLedger));
            this.dgvALLLedgerReport = new System.Windows.Forms.DataGridView();
            this.chkItemDesc = new System.Windows.Forms.CheckBox();
            this.chkItemCode = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtItemDescription = new System.Windows.Forms.TextBox();
            this.chklbItemList = new System.Windows.Forms.CheckedListBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnAllledger = new System.Windows.Forms.Button();
            this.lblItemReturn = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblStockAdjusted = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblClosingStock = new System.Windows.Forms.Label();
            this.lblIssue = new System.Windows.Forms.Label();
            this.lblRecipt = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblOpeningBalance = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnExportExcel = new System.Windows.Forms.Button();
            this.btnmaterialledger = new System.Windows.Forms.Button();
            this.dtpfromdate = new System.Windows.Forms.DateTimePicker();
            this.dtptodate = new System.Windows.Forms.DateTimePicker();
            this.lblavailableqty = new System.Windows.Forms.Label();
            this.lbltodate = new System.Windows.Forms.Label();
            this.lblfromdate = new System.Windows.Forms.Label();
            this.lblrepeatCost = new System.Windows.Forms.Label();
            this.lblavaqty = new System.Windows.Forms.Label();
            this.lblitemname = new System.Windows.Forms.Label();
            this.lblRepeatitemcode = new System.Windows.Forms.Label();
            this.lblitemdescrption = new System.Windows.Forms.Label();
            this.lblUnitCost = new System.Windows.Forms.Label();
            this.lblItemcode = new System.Windows.Forms.Label();
            this.chkopitem = new System.Windows.Forms.CheckBox();
            this.chkipitems = new System.Windows.Forms.CheckBox();
            this.lblStockAdjused = new System.Windows.Forms.Label();
            this.lblreturnqty = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblissuedqty = new System.Windows.Forms.Label();
            this.lblrecievqty = new System.Windows.Forms.Label();
            this.dgvmaterialLedger = new System.Windows.Forms.DataGridView();
            this.Date1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Return = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Recieved = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Issued = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitcost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TRNNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.refnumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.projectcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Customer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.User = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chkTransducer = new System.Windows.Forms.CheckBox();
            this.chkElectronics = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvALLLedgerReport)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvmaterialLedger)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvALLLedgerReport
            // 
            this.dgvALLLedgerReport.AllowUserToAddRows = false;
            this.dgvALLLedgerReport.AllowUserToDeleteRows = false;
            this.dgvALLLedgerReport.AllowUserToOrderColumns = true;
            this.dgvALLLedgerReport.AllowUserToResizeRows = false;
            this.dgvALLLedgerReport.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvALLLedgerReport.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvALLLedgerReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvALLLedgerReport.Location = new System.Drawing.Point(5, 221);
            this.dgvALLLedgerReport.Name = "dgvALLLedgerReport";
            this.dgvALLLedgerReport.ReadOnly = true;
            this.dgvALLLedgerReport.RowHeadersVisible = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvALLLedgerReport.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvALLLedgerReport.Size = new System.Drawing.Size(1299, 424);
            this.dgvALLLedgerReport.TabIndex = 223;
            this.dgvALLLedgerReport.Visible = false;
            // 
            // chkItemDesc
            // 
            this.chkItemDesc.AutoSize = true;
            this.chkItemDesc.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemDesc.ForeColor = System.Drawing.Color.Black;
            this.chkItemDesc.Location = new System.Drawing.Point(258, 67);
            this.chkItemDesc.Name = "chkItemDesc";
            this.chkItemDesc.Size = new System.Drawing.Size(98, 23);
            this.chkItemDesc.TabIndex = 222;
            this.chkItemDesc.Text = "Item Desc.";
            this.chkItemDesc.UseVisualStyleBackColor = true;
            this.chkItemDesc.CheckedChanged += new System.EventHandler(this.chkItemDesc_CheckedChanged);
            // 
            // chkItemCode
            // 
            this.chkItemCode.AutoSize = true;
            this.chkItemCode.Checked = true;
            this.chkItemCode.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemCode.ForeColor = System.Drawing.Color.Black;
            this.chkItemCode.Location = new System.Drawing.Point(125, 67);
            this.chkItemCode.Name = "chkItemCode";
            this.chkItemCode.Size = new System.Drawing.Size(97, 23);
            this.chkItemCode.TabIndex = 221;
            this.chkItemCode.Text = "Item Code";
            this.chkItemCode.UseVisualStyleBackColor = true;
            this.chkItemCode.CheckedChanged += new System.EventHandler(this.chkItemCode_CheckedChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(8, 67);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 19);
            this.label4.TabIndex = 220;
            this.label4.Text = "Search Item by";
            // 
            // txtItemDescription
            // 
            this.txtItemDescription.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemDescription.Location = new System.Drawing.Point(5, 94);
            this.txtItemDescription.Name = "txtItemDescription";
            this.txtItemDescription.Size = new System.Drawing.Size(498, 26);
            this.txtItemDescription.TabIndex = 217;
            this.txtItemDescription.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemDescription_KeyUp);
            // 
            // chklbItemList
            // 
            this.chklbItemList.CheckOnClick = true;
            this.chklbItemList.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chklbItemList.FormattingEnabled = true;
            this.chklbItemList.Location = new System.Drawing.Point(5, 123);
            this.chklbItemList.Name = "chklbItemList";
            this.chklbItemList.Size = new System.Drawing.Size(498, 88);
            this.chklbItemList.TabIndex = 218;
            this.chklbItemList.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.chklbItemList_ItemCheck);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.btnAllledger);
            this.panel1.Controls.Add(this.lblItemReturn);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.lblStockAdjusted);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.lblClosingStock);
            this.panel1.Controls.Add(this.lblIssue);
            this.panel1.Controls.Add(this.lblRecipt);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.lblOpeningBalance);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.btnExportExcel);
            this.panel1.Controls.Add(this.btnmaterialledger);
            this.panel1.Controls.Add(this.dtpfromdate);
            this.panel1.Controls.Add(this.dtptodate);
            this.panel1.Controls.Add(this.lblavailableqty);
            this.panel1.Controls.Add(this.lbltodate);
            this.panel1.Controls.Add(this.lblfromdate);
            this.panel1.Controls.Add(this.lblrepeatCost);
            this.panel1.Controls.Add(this.lblavaqty);
            this.panel1.Controls.Add(this.lblitemname);
            this.panel1.Controls.Add(this.lblRepeatitemcode);
            this.panel1.Controls.Add(this.lblitemdescrption);
            this.panel1.Controls.Add(this.lblUnitCost);
            this.panel1.Controls.Add(this.lblItemcode);
            this.panel1.Location = new System.Drawing.Point(509, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(795, 194);
            this.panel1.TabIndex = 219;
            // 
            // btnAllledger
            // 
            this.btnAllledger.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAllledger.Location = new System.Drawing.Point(359, 116);
            this.btnAllledger.Name = "btnAllledger";
            this.btnAllledger.Size = new System.Drawing.Size(145, 32);
            this.btnAllledger.TabIndex = 138;
            this.btnAllledger.Text = "All items Ledger";
            this.btnAllledger.UseVisualStyleBackColor = true;
            this.btnAllledger.Visible = false;
            // 
            // lblItemReturn
            // 
            this.lblItemReturn.AutoSize = true;
            this.lblItemReturn.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemReturn.ForeColor = System.Drawing.Color.Black;
            this.lblItemReturn.Location = new System.Drawing.Point(701, 65);
            this.lblItemReturn.Name = "lblItemReturn";
            this.lblItemReturn.Size = new System.Drawing.Size(20, 23);
            this.lblItemReturn.TabIndex = 137;
            this.lblItemReturn.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(592, 65);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(115, 23);
            this.label10.TabIndex = 136;
            this.label10.Text = "Item Return :";
            // 
            // lblStockAdjusted
            // 
            this.lblStockAdjusted.AutoSize = true;
            this.lblStockAdjusted.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStockAdjusted.ForeColor = System.Drawing.Color.Black;
            this.lblStockAdjusted.Location = new System.Drawing.Point(701, 122);
            this.lblStockAdjusted.Name = "lblStockAdjusted";
            this.lblStockAdjusted.Size = new System.Drawing.Size(20, 23);
            this.lblStockAdjusted.TabIndex = 135;
            this.lblStockAdjusted.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(568, 122);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(138, 23);
            this.label9.TabIndex = 134;
            this.label9.Text = "Stock Adjusted :";
            // 
            // lblClosingStock
            // 
            this.lblClosingStock.AutoSize = true;
            this.lblClosingStock.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClosingStock.ForeColor = System.Drawing.Color.Black;
            this.lblClosingStock.Location = new System.Drawing.Point(701, 151);
            this.lblClosingStock.Name = "lblClosingStock";
            this.lblClosingStock.Size = new System.Drawing.Size(20, 23);
            this.lblClosingStock.TabIndex = 133;
            this.lblClosingStock.Text = "0";
            // 
            // lblIssue
            // 
            this.lblIssue.AutoSize = true;
            this.lblIssue.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIssue.ForeColor = System.Drawing.Color.Black;
            this.lblIssue.Location = new System.Drawing.Point(701, 93);
            this.lblIssue.Name = "lblIssue";
            this.lblIssue.Size = new System.Drawing.Size(20, 23);
            this.lblIssue.TabIndex = 132;
            this.lblIssue.Text = "0";
            // 
            // lblRecipt
            // 
            this.lblRecipt.AutoSize = true;
            this.lblRecipt.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecipt.ForeColor = System.Drawing.Color.Black;
            this.lblRecipt.Location = new System.Drawing.Point(701, 35);
            this.lblRecipt.Name = "lblRecipt";
            this.lblRecipt.Size = new System.Drawing.Size(20, 23);
            this.lblRecipt.TabIndex = 131;
            this.lblRecipt.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(582, 151);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(123, 23);
            this.label7.TabIndex = 130;
            this.label7.Text = "Closing Stock :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(645, 93);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 23);
            this.label5.TabIndex = 129;
            this.label5.Text = "Issue :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(619, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 23);
            this.label2.TabIndex = 128;
            this.label2.Text = "Reciepts :";
            // 
            // lblOpeningBalance
            // 
            this.lblOpeningBalance.AutoSize = true;
            this.lblOpeningBalance.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOpeningBalance.ForeColor = System.Drawing.Color.Black;
            this.lblOpeningBalance.Location = new System.Drawing.Point(701, 6);
            this.lblOpeningBalance.Name = "lblOpeningBalance";
            this.lblOpeningBalance.Size = new System.Drawing.Size(20, 23);
            this.lblOpeningBalance.TabIndex = 127;
            this.lblOpeningBalance.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(555, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(152, 23);
            this.label3.TabIndex = 126;
            this.label3.Text = "Opening Balance :";
            // 
            // btnExportExcel
            // 
            this.btnExportExcel.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExportExcel.Location = new System.Drawing.Point(438, 156);
            this.btnExportExcel.Name = "btnExportExcel";
            this.btnExportExcel.Size = new System.Drawing.Size(132, 34);
            this.btnExportExcel.TabIndex = 125;
            this.btnExportExcel.Text = "Export to Excel";
            this.btnExportExcel.UseVisualStyleBackColor = true;
            this.btnExportExcel.Visible = false;
            // 
            // btnmaterialledger
            // 
            this.btnmaterialledger.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmaterialledger.Location = new System.Drawing.Point(359, 157);
            this.btnmaterialledger.Name = "btnmaterialledger";
            this.btnmaterialledger.Size = new System.Drawing.Size(73, 32);
            this.btnmaterialledger.TabIndex = 124;
            this.btnmaterialledger.Text = "Ledger";
            this.btnmaterialledger.UseVisualStyleBackColor = true;
            this.btnmaterialledger.Visible = false;
            this.btnmaterialledger.Click += new System.EventHandler(this.btnmaterialledger_Click);
            // 
            // dtpfromdate
            // 
            this.dtpfromdate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpfromdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpfromdate.Location = new System.Drawing.Point(81, 157);
            this.dtpfromdate.Name = "dtpfromdate";
            this.dtpfromdate.Size = new System.Drawing.Size(98, 27);
            this.dtpfromdate.TabIndex = 120;
            this.dtpfromdate.Visible = false;
            // 
            // dtptodate
            // 
            this.dtptodate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtptodate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtptodate.Location = new System.Drawing.Point(249, 157);
            this.dtptodate.Name = "dtptodate";
            this.dtptodate.Size = new System.Drawing.Size(96, 27);
            this.dtptodate.TabIndex = 121;
            this.dtptodate.Visible = false;
            // 
            // lblavailableqty
            // 
            this.lblavailableqty.AutoSize = true;
            this.lblavailableqty.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblavailableqty.ForeColor = System.Drawing.Color.Black;
            this.lblavailableqty.Location = new System.Drawing.Point(163, 116);
            this.lblavailableqty.Name = "lblavailableqty";
            this.lblavailableqty.Size = new System.Drawing.Size(20, 23);
            this.lblavailableqty.TabIndex = 117;
            this.lblavailableqty.Text = "0";
            // 
            // lbltodate
            // 
            this.lbltodate.AutoSize = true;
            this.lbltodate.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltodate.ForeColor = System.Drawing.Color.Black;
            this.lbltodate.Location = new System.Drawing.Point(207, 158);
            this.lbltodate.Name = "lbltodate";
            this.lbltodate.Size = new System.Drawing.Size(36, 23);
            this.lbltodate.TabIndex = 123;
            this.lbltodate.Text = "To :";
            this.lbltodate.Visible = false;
            // 
            // lblfromdate
            // 
            this.lblfromdate.AutoSize = true;
            this.lblfromdate.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfromdate.ForeColor = System.Drawing.Color.Black;
            this.lblfromdate.Location = new System.Drawing.Point(18, 158);
            this.lblfromdate.Name = "lblfromdate";
            this.lblfromdate.Size = new System.Drawing.Size(60, 23);
            this.lblfromdate.TabIndex = 122;
            this.lblfromdate.Text = "From :";
            this.lblfromdate.Visible = false;
            // 
            // lblrepeatCost
            // 
            this.lblrepeatCost.AutoSize = true;
            this.lblrepeatCost.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrepeatCost.ForeColor = System.Drawing.Color.Black;
            this.lblrepeatCost.Location = new System.Drawing.Point(457, 9);
            this.lblrepeatCost.Name = "lblrepeatCost";
            this.lblrepeatCost.Size = new System.Drawing.Size(19, 23);
            this.lblrepeatCost.TabIndex = 115;
            this.lblrepeatCost.Text = "*";
            // 
            // lblavaqty
            // 
            this.lblavaqty.AutoSize = true;
            this.lblavaqty.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblavaqty.ForeColor = System.Drawing.Color.Black;
            this.lblavaqty.Location = new System.Drawing.Point(36, 116);
            this.lblavaqty.Name = "lblavaqty";
            this.lblavaqty.Size = new System.Drawing.Size(126, 23);
            this.lblavaqty.TabIndex = 116;
            this.lblavaqty.Text = "Available Qty :";
            // 
            // lblitemname
            // 
            this.lblitemname.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblitemname.ForeColor = System.Drawing.Color.Black;
            this.lblitemname.Location = new System.Drawing.Point(163, 45);
            this.lblitemname.Name = "lblitemname";
            this.lblitemname.Size = new System.Drawing.Size(407, 43);
            this.lblitemname.TabIndex = 114;
            this.lblitemname.Text = "*";
            // 
            // lblRepeatitemcode
            // 
            this.lblRepeatitemcode.AutoSize = true;
            this.lblRepeatitemcode.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRepeatitemcode.ForeColor = System.Drawing.Color.Black;
            this.lblRepeatitemcode.Location = new System.Drawing.Point(161, 9);
            this.lblRepeatitemcode.Name = "lblRepeatitemcode";
            this.lblRepeatitemcode.Size = new System.Drawing.Size(19, 23);
            this.lblRepeatitemcode.TabIndex = 114;
            this.lblRepeatitemcode.Text = "*";
            // 
            // lblitemdescrption
            // 
            this.lblitemdescrption.AutoSize = true;
            this.lblitemdescrption.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblitemdescrption.ForeColor = System.Drawing.Color.Black;
            this.lblitemdescrption.Location = new System.Drawing.Point(11, 45);
            this.lblitemdescrption.Name = "lblitemdescrption";
            this.lblitemdescrption.Size = new System.Drawing.Size(151, 23);
            this.lblitemdescrption.TabIndex = 19;
            this.lblitemdescrption.Text = "Item Description :";
            // 
            // lblUnitCost
            // 
            this.lblUnitCost.AutoSize = true;
            this.lblUnitCost.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUnitCost.ForeColor = System.Drawing.Color.Black;
            this.lblUnitCost.Location = new System.Drawing.Point(370, 9);
            this.lblUnitCost.Name = "lblUnitCost";
            this.lblUnitCost.Size = new System.Drawing.Size(88, 23);
            this.lblUnitCost.TabIndex = 113;
            this.lblUnitCost.Text = "UnitCost :";
            // 
            // lblItemcode
            // 
            this.lblItemcode.AutoSize = true;
            this.lblItemcode.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemcode.ForeColor = System.Drawing.Color.Black;
            this.lblItemcode.Location = new System.Drawing.Point(62, 9);
            this.lblItemcode.Name = "lblItemcode";
            this.lblItemcode.Size = new System.Drawing.Size(100, 23);
            this.lblItemcode.TabIndex = 112;
            this.lblItemcode.Text = "Item Code :";
            // 
            // chkopitem
            // 
            this.chkopitem.AutoSize = true;
            this.chkopitem.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkopitem.ForeColor = System.Drawing.Color.Red;
            this.chkopitem.Location = new System.Drawing.Point(201, 35);
            this.chkopitem.Name = "chkopitem";
            this.chkopitem.Size = new System.Drawing.Size(192, 27);
            this.chkopitem.TabIndex = 225;
            this.chkopitem.Text = "Search Output Items";
            this.chkopitem.UseVisualStyleBackColor = true;
            this.chkopitem.CheckedChanged += new System.EventHandler(this.chkopitem_CheckedChanged);
            // 
            // chkipitems
            // 
            this.chkipitems.AutoSize = true;
            this.chkipitems.Checked = true;
            this.chkipitems.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkipitems.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkipitems.ForeColor = System.Drawing.Color.Red;
            this.chkipitems.Location = new System.Drawing.Point(21, 35);
            this.chkipitems.Name = "chkipitems";
            this.chkipitems.Size = new System.Drawing.Size(177, 27);
            this.chkipitems.TabIndex = 224;
            this.chkipitems.Text = "Search Input Items";
            this.chkipitems.UseVisualStyleBackColor = true;
            this.chkipitems.CheckedChanged += new System.EventHandler(this.chkipitems_CheckedChanged);
            // 
            // lblStockAdjused
            // 
            this.lblStockAdjused.AutoSize = true;
            this.lblStockAdjused.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStockAdjused.ForeColor = System.Drawing.Color.Black;
            this.lblStockAdjused.Location = new System.Drawing.Point(450, 654);
            this.lblStockAdjused.Name = "lblStockAdjused";
            this.lblStockAdjused.Size = new System.Drawing.Size(20, 23);
            this.lblStockAdjused.TabIndex = 230;
            this.lblStockAdjused.Text = "0";
            // 
            // lblreturnqty
            // 
            this.lblreturnqty.AutoSize = true;
            this.lblreturnqty.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblreturnqty.ForeColor = System.Drawing.Color.Black;
            this.lblreturnqty.Location = new System.Drawing.Point(329, 651);
            this.lblreturnqty.Name = "lblreturnqty";
            this.lblreturnqty.Size = new System.Drawing.Size(20, 23);
            this.lblreturnqty.TabIndex = 226;
            this.lblreturnqty.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(17, 654);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 23);
            this.label6.TabIndex = 227;
            this.label6.Text = "Total :";
            // 
            // lblissuedqty
            // 
            this.lblissuedqty.AutoSize = true;
            this.lblissuedqty.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblissuedqty.ForeColor = System.Drawing.Color.Black;
            this.lblissuedqty.Location = new System.Drawing.Point(214, 654);
            this.lblissuedqty.Name = "lblissuedqty";
            this.lblissuedqty.Size = new System.Drawing.Size(20, 23);
            this.lblissuedqty.TabIndex = 228;
            this.lblissuedqty.Text = "0";
            // 
            // lblrecievqty
            // 
            this.lblrecievqty.AutoSize = true;
            this.lblrecievqty.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrecievqty.ForeColor = System.Drawing.Color.Black;
            this.lblrecievqty.Location = new System.Drawing.Point(123, 651);
            this.lblrecievqty.Name = "lblrecievqty";
            this.lblrecievqty.Size = new System.Drawing.Size(20, 23);
            this.lblrecievqty.TabIndex = 229;
            this.lblrecievqty.Text = "0";
            // 
            // dgvmaterialLedger
            // 
            this.dgvmaterialLedger.AllowUserToAddRows = false;
            this.dgvmaterialLedger.AllowUserToDeleteRows = false;
            this.dgvmaterialLedger.AllowUserToOrderColumns = true;
            this.dgvmaterialLedger.AllowUserToResizeColumns = false;
            this.dgvmaterialLedger.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvmaterialLedger.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvmaterialLedger.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvmaterialLedger.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvmaterialLedger.ColumnHeadersHeight = 40;
            this.dgvmaterialLedger.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvmaterialLedger.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Date1,
            this.Return,
            this.Recieved,
            this.Issued,
            this.unitcost,
            this.amount,
            this.TRNNo,
            this.refnumber,
            this.projectcode,
            this.ProjectDesc,
            this.Customer,
            this.User});
            this.dgvmaterialLedger.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvmaterialLedger.DefaultCellStyle = dataGridViewCellStyle13;
            this.dgvmaterialLedger.EnableHeadersVisualStyles = false;
            this.dgvmaterialLedger.Location = new System.Drawing.Point(5, 210);
            this.dgvmaterialLedger.MultiSelect = false;
            this.dgvmaterialLedger.Name = "dgvmaterialLedger";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvmaterialLedger.RowHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.dgvmaterialLedger.RowHeadersVisible = false;
            this.dgvmaterialLedger.Size = new System.Drawing.Size(1299, 435);
            this.dgvmaterialLedger.TabIndex = 231;
            // 
            // Date1
            // 
            this.Date1.DataPropertyName = "Date";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Date1.DefaultCellStyle = dataGridViewCellStyle4;
            this.Date1.HeaderText = "Date";
            this.Date1.Name = "Date1";
            this.Date1.ReadOnly = true;
            this.Date1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Date1.Width = 54;
            // 
            // Return
            // 
            this.Return.DataPropertyName = "OpeningQuantity";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Return.DefaultCellStyle = dataGridViewCellStyle5;
            this.Return.HeaderText = "Opening Qty";
            this.Return.Name = "Return";
            this.Return.ReadOnly = true;
            this.Return.Width = 135;
            // 
            // Recieved
            // 
            this.Recieved.DataPropertyName = "RecievedQty";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Recieved.DefaultCellStyle = dataGridViewCellStyle6;
            this.Recieved.HeaderText = "RecievedQty";
            this.Recieved.Name = "Recieved";
            this.Recieved.ReadOnly = true;
            this.Recieved.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Recieved.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Recieved.Width = 118;
            // 
            // Issued
            // 
            this.Issued.DataPropertyName = "IssuedQty";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Issued.DefaultCellStyle = dataGridViewCellStyle7;
            this.Issued.HeaderText = "Issued Qty";
            this.Issued.Name = "Issued";
            this.Issued.ReadOnly = true;
            this.Issued.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // unitcost
            // 
            this.unitcost.DataPropertyName = "UnitCost";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.unitcost.DefaultCellStyle = dataGridViewCellStyle8;
            this.unitcost.HeaderText = "Unit Cost";
            this.unitcost.Name = "unitcost";
            this.unitcost.ReadOnly = true;
            this.unitcost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.unitcost.Width = 89;
            // 
            // amount
            // 
            this.amount.DataPropertyName = "Amount";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.amount.DefaultCellStyle = dataGridViewCellStyle9;
            this.amount.HeaderText = "Amount";
            this.amount.Name = "amount";
            this.amount.ReadOnly = true;
            this.amount.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.amount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.amount.Width = 80;
            // 
            // TRNNo
            // 
            this.TRNNo.DataPropertyName = "TRNNo";
            this.TRNNo.HeaderText = "Transaction No";
            this.TRNNo.Name = "TRNNo";
            this.TRNNo.ReadOnly = true;
            this.TRNNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.TRNNo.Width = 133;
            // 
            // refnumber
            // 
            this.refnumber.DataPropertyName = "TransactionType";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.refnumber.DefaultCellStyle = dataGridViewCellStyle10;
            this.refnumber.HeaderText = "Ref Number";
            this.refnumber.Name = "refnumber";
            this.refnumber.ReadOnly = true;
            this.refnumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.refnumber.Width = 112;
            // 
            // projectcode
            // 
            this.projectcode.DataPropertyName = "ProjectCode";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.projectcode.DefaultCellStyle = dataGridViewCellStyle11;
            this.projectcode.HeaderText = "Project Code";
            this.projectcode.Name = "projectcode";
            this.projectcode.ReadOnly = true;
            this.projectcode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.projectcode.Width = 117;
            // 
            // ProjectDesc
            // 
            this.ProjectDesc.DataPropertyName = "ProjectName";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ProjectDesc.DefaultCellStyle = dataGridViewCellStyle12;
            this.ProjectDesc.HeaderText = "Project Name";
            this.ProjectDesc.Name = "ProjectDesc";
            this.ProjectDesc.ReadOnly = true;
            this.ProjectDesc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectDesc.Width = 124;
            // 
            // Customer
            // 
            this.Customer.DataPropertyName = "Customer";
            this.Customer.HeaderText = "Customer";
            this.Customer.Name = "Customer";
            this.Customer.ReadOnly = true;
            this.Customer.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Customer.Width = 93;
            // 
            // User
            // 
            this.User.DataPropertyName = "User";
            this.User.HeaderText = "User";
            this.User.Name = "User";
            this.User.ReadOnly = true;
            this.User.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.User.Width = 53;
            // 
            // chkTransducer
            // 
            this.chkTransducer.AutoSize = true;
            this.chkTransducer.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkTransducer.ForeColor = System.Drawing.Color.DarkGreen;
            this.chkTransducer.Location = new System.Drawing.Point(258, 2);
            this.chkTransducer.Name = "chkTransducer";
            this.chkTransducer.Size = new System.Drawing.Size(223, 27);
            this.chkTransducer.TabIndex = 233;
            this.chkTransducer.Text = "Transducer Items Ledger";
            this.chkTransducer.UseVisualStyleBackColor = true;
            this.chkTransducer.CheckedChanged += new System.EventHandler(this.chkTransducer_CheckedChanged);
            // 
            // chkElectronics
            // 
            this.chkElectronics.AutoSize = true;
            this.chkElectronics.Checked = true;
            this.chkElectronics.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkElectronics.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkElectronics.ForeColor = System.Drawing.Color.DarkGreen;
            this.chkElectronics.Location = new System.Drawing.Point(21, 2);
            this.chkElectronics.Name = "chkElectronics";
            this.chkElectronics.Size = new System.Drawing.Size(223, 27);
            this.chkElectronics.TabIndex = 232;
            this.chkElectronics.Text = "Electronics Items Ledger";
            this.chkElectronics.UseVisualStyleBackColor = true;
            this.chkElectronics.CheckedChanged += new System.EventHandler(this.chkElectronics_CheckedChanged);
            // 
            // frmKANBANLedger
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1308, 686);
            this.Controls.Add(this.chkTransducer);
            this.Controls.Add(this.chkElectronics);
            this.Controls.Add(this.dgvmaterialLedger);
            this.Controls.Add(this.lblStockAdjused);
            this.Controls.Add(this.lblreturnqty);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblissuedqty);
            this.Controls.Add(this.lblrecievqty);
            this.Controls.Add(this.chkopitem);
            this.Controls.Add(this.chkipitems);
            this.Controls.Add(this.dgvALLLedgerReport);
            this.Controls.Add(this.chkItemDesc);
            this.Controls.Add(this.chkItemCode);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtItemDescription);
            this.Controls.Add(this.chklbItemList);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmKANBANLedger";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "KanBan Ledger";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmKANBANLedger_FormClosing);
            this.Load += new System.EventHandler(this.frmKANBANLedger_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvALLLedgerReport)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvmaterialLedger)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvALLLedgerReport;
        private System.Windows.Forms.CheckBox chkItemDesc;
        private System.Windows.Forms.CheckBox chkItemCode;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtItemDescription;
        private System.Windows.Forms.CheckedListBox chklbItemList;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnAllledger;
        private System.Windows.Forms.Label lblItemReturn;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblStockAdjusted;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblClosingStock;
        private System.Windows.Forms.Label lblIssue;
        private System.Windows.Forms.Label lblRecipt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblOpeningBalance;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnExportExcel;
        private System.Windows.Forms.Button btnmaterialledger;
        private System.Windows.Forms.DateTimePicker dtpfromdate;
        private System.Windows.Forms.DateTimePicker dtptodate;
        private System.Windows.Forms.Label lblavailableqty;
        private System.Windows.Forms.Label lbltodate;
        private System.Windows.Forms.Label lblfromdate;
        private System.Windows.Forms.Label lblrepeatCost;
        private System.Windows.Forms.Label lblavaqty;
        private System.Windows.Forms.Label lblitemname;
        private System.Windows.Forms.Label lblRepeatitemcode;
        private System.Windows.Forms.Label lblitemdescrption;
        private System.Windows.Forms.Label lblUnitCost;
        private System.Windows.Forms.Label lblItemcode;
        private System.Windows.Forms.CheckBox chkopitem;
        private System.Windows.Forms.CheckBox chkipitems;
        private System.Windows.Forms.Label lblStockAdjused;
        private System.Windows.Forms.Label lblreturnqty;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblissuedqty;
        private System.Windows.Forms.Label lblrecievqty;
        private System.Windows.Forms.DataGridView dgvmaterialLedger;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Return;
        private System.Windows.Forms.DataGridViewTextBoxColumn Recieved;
        private System.Windows.Forms.DataGridViewTextBoxColumn Issued;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitcost;
        private System.Windows.Forms.DataGridViewTextBoxColumn amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn TRNNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn refnumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn projectcode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectDesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn Customer;
        private System.Windows.Forms.DataGridViewTextBoxColumn User;
        private System.Windows.Forms.CheckBox chkTransducer;
        private System.Windows.Forms.CheckBox chkElectronics;
    }
}