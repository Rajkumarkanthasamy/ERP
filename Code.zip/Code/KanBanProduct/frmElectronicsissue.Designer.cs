﻿namespace Erp_Project_With_Buttons.KanBanProduct
{
    partial class frmElectronicsissue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmElectronicsissue));
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.lblRemarks = new System.Windows.Forms.Label();
            this.chkRawMaterailIssue = new System.Windows.Forms.CheckBox();
            this.chkProductIssue = new System.Windows.Forms.CheckBox();
            this.gpButtons = new System.Windows.Forms.GroupBox();
            this.txtInsatallationCommision = new System.Windows.Forms.TextBox();
            this.btnAddExtra = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClearAll = new System.Windows.Forms.Button();
            this.dgIndentList = new System.Windows.Forms.DataGridView();
            this.ItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Unit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AvailableQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReqQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnitemlist = new System.Windows.Forms.Panel();
            this.chkItemDesc = new System.Windows.Forms.CheckBox();
            this.chkItemCode = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.chklbItemList = new System.Windows.Forms.CheckedListBox();
            this.txtItemDescription = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.lblProjectStatus = new System.Windows.Forms.Label();
            this.lblcustomername = new System.Windows.Forms.Label();
            this.lblprojname = new System.Windows.Forms.Label();
            this.lblcustomer = new System.Windows.Forms.Label();
            this.lblProjectCode = new System.Windows.Forms.Label();
            this.cmbProjectCode = new System.Windows.Forms.ComboBox();
            this.lblProjectName = new System.Windows.Forms.Label();
            this.btnProjectView = new System.Windows.Forms.Button();
            this.tvProduct = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.label6 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.gpButtons.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgIndentList)).BeginInit();
            this.pnitemlist.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtRemarks
            // 
            this.txtRemarks.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemarks.Location = new System.Drawing.Point(888, 166);
            this.txtRemarks.Multiline = true;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRemarks.Size = new System.Drawing.Size(286, 52);
            this.txtRemarks.TabIndex = 228;
            // 
            // lblRemarks
            // 
            this.lblRemarks.AutoSize = true;
            this.lblRemarks.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRemarks.ForeColor = System.Drawing.Color.Black;
            this.lblRemarks.Location = new System.Drawing.Point(821, 166);
            this.lblRemarks.Name = "lblRemarks";
            this.lblRemarks.Size = new System.Drawing.Size(68, 18);
            this.lblRemarks.TabIndex = 227;
            this.lblRemarks.Text = "Remarks :";
            // 
            // chkRawMaterailIssue
            // 
            this.chkRawMaterailIssue.AutoSize = true;
            this.chkRawMaterailIssue.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkRawMaterailIssue.ForeColor = System.Drawing.Color.Red;
            this.chkRawMaterailIssue.Location = new System.Drawing.Point(258, 3);
            this.chkRawMaterailIssue.Name = "chkRawMaterailIssue";
            this.chkRawMaterailIssue.Size = new System.Drawing.Size(111, 27);
            this.chkRawMaterailIssue.TabIndex = 226;
            this.chkRawMaterailIssue.Text = "Item Issue";
            this.chkRawMaterailIssue.UseVisualStyleBackColor = true;
            this.chkRawMaterailIssue.CheckedChanged += new System.EventHandler(this.chkRawMaterailIssue_CheckedChanged);
            // 
            // chkProductIssue
            // 
            this.chkProductIssue.AutoSize = true;
            this.chkProductIssue.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkProductIssue.ForeColor = System.Drawing.Color.Red;
            this.chkProductIssue.Location = new System.Drawing.Point(41, 3);
            this.chkProductIssue.Name = "chkProductIssue";
            this.chkProductIssue.Size = new System.Drawing.Size(136, 27);
            this.chkProductIssue.TabIndex = 225;
            this.chkProductIssue.Text = "Product Issue";
            this.chkProductIssue.UseVisualStyleBackColor = true;
            this.chkProductIssue.CheckedChanged += new System.EventHandler(this.chkProductIssue_CheckedChanged);
            // 
            // gpButtons
            // 
            this.gpButtons.Controls.Add(this.txtInsatallationCommision);
            this.gpButtons.Controls.Add(this.btnAddExtra);
            this.gpButtons.Controls.Add(this.label2);
            this.gpButtons.Controls.Add(this.btnExit);
            this.gpButtons.Controls.Add(this.btnSave);
            this.gpButtons.Controls.Add(this.btnClearAll);
            this.gpButtons.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.gpButtons.Location = new System.Drawing.Point(399, 548);
            this.gpButtons.Name = "gpButtons";
            this.gpButtons.Size = new System.Drawing.Size(775, 69);
            this.gpButtons.TabIndex = 224;
            this.gpButtons.TabStop = false;
            // 
            // txtInsatallationCommision
            // 
            this.txtInsatallationCommision.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtInsatallationCommision.Location = new System.Drawing.Point(161, 25);
            this.txtInsatallationCommision.Name = "txtInsatallationCommision";
            this.txtInsatallationCommision.Size = new System.Drawing.Size(80, 26);
            this.txtInsatallationCommision.TabIndex = 169;
            this.txtInsatallationCommision.Text = "0";
            // 
            // btnAddExtra
            // 
            this.btnAddExtra.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAddExtra.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnAddExtra.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAddExtra.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnAddExtra.Location = new System.Drawing.Point(247, 20);
            this.btnAddExtra.Name = "btnAddExtra";
            this.btnAddExtra.Size = new System.Drawing.Size(43, 31);
            this.btnAddExtra.TabIndex = 168;
            this.btnAddExtra.Text = "Add";
            this.btnAddExtra.UseVisualStyleBackColor = false;
            this.btnAddExtra.Click += new System.EventHandler(this.btnAddExtra_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(51, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 19);
            this.label2.TabIndex = 167;
            this.label2.Text = "O/P Quantity :";
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(656, 12);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(88, 44);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(351, 15);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(88, 44);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClearAll
            // 
            this.btnClearAll.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnClearAll.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnClearAll.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearAll.Location = new System.Drawing.Point(504, 12);
            this.btnClearAll.Name = "btnClearAll";
            this.btnClearAll.Size = new System.Drawing.Size(88, 44);
            this.btnClearAll.TabIndex = 7;
            this.btnClearAll.Text = "Clear All";
            this.btnClearAll.UseVisualStyleBackColor = false;
            // 
            // dgIndentList
            // 
            this.dgIndentList.AllowUserToAddRows = false;
            this.dgIndentList.AllowUserToDeleteRows = false;
            this.dgIndentList.AllowUserToResizeRows = false;
            this.dgIndentList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgIndentList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgIndentList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgIndentList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgIndentList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgIndentList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ItemCode,
            this.ItemDesc,
            this.Unit,
            this.AvailableQty,
            this.UnitCost,
            this.ReqQty});
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgIndentList.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgIndentList.EnableHeadersVisualStyles = false;
            this.dgIndentList.Location = new System.Drawing.Point(399, 293);
            this.dgIndentList.MultiSelect = false;
            this.dgIndentList.Name = "dgIndentList";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgIndentList.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgIndentList.RowHeadersVisible = false;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgIndentList.RowsDefaultCellStyle = dataGridViewCellStyle7;
            this.dgIndentList.Size = new System.Drawing.Size(775, 249);
            this.dgIndentList.TabIndex = 223;
            this.dgIndentList.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgIndentList_CellBeginEdit);
            this.dgIndentList.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgIndentList_CellEndEdit);
            this.dgIndentList.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgIndentList_EditingControlShowing);
            this.dgIndentList.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgIndentList_KeyUp);
            // 
            // ItemCode
            // 
            this.ItemCode.DataPropertyName = "ItemCode";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ItemCode.DefaultCellStyle = dataGridViewCellStyle2;
            this.ItemCode.HeaderText = "Item Code";
            this.ItemCode.Name = "ItemCode";
            this.ItemCode.ReadOnly = true;
            this.ItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemCode.Width = 97;
            // 
            // ItemDesc
            // 
            this.ItemDesc.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ItemDesc.DataPropertyName = "ItemDescription";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ItemDesc.DefaultCellStyle = dataGridViewCellStyle3;
            this.ItemDesc.HeaderText = "Item Desc";
            this.ItemDesc.Name = "ItemDesc";
            this.ItemDesc.ReadOnly = true;
            this.ItemDesc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemDesc.Width = 99;
            // 
            // Unit
            // 
            this.Unit.DataPropertyName = "Units";
            this.Unit.HeaderText = "UOM";
            this.Unit.Name = "Unit";
            this.Unit.ReadOnly = true;
            this.Unit.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Unit.Width = 58;
            // 
            // AvailableQty
            // 
            this.AvailableQty.DataPropertyName = "AvailableQty";
            this.AvailableQty.HeaderText = "Available Qty";
            this.AvailableQty.Name = "AvailableQty";
            this.AvailableQty.ReadOnly = true;
            this.AvailableQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.AvailableQty.Width = 123;
            // 
            // UnitCost
            // 
            this.UnitCost.DataPropertyName = "UnitCost";
            this.UnitCost.HeaderText = "UnitCost";
            this.UnitCost.Name = "UnitCost";
            this.UnitCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitCost.Width = 85;
            // 
            // ReqQty
            // 
            this.ReqQty.DataPropertyName = "ReqQty";
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ReqQty.DefaultCellStyle = dataGridViewCellStyle4;
            this.ReqQty.HeaderText = "Issue Qty";
            this.ReqQty.Name = "ReqQty";
            this.ReqQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ReqQty.Width = 90;
            // 
            // pnitemlist
            // 
            this.pnitemlist.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnitemlist.Controls.Add(this.chkItemDesc);
            this.pnitemlist.Controls.Add(this.chkItemCode);
            this.pnitemlist.Controls.Add(this.label3);
            this.pnitemlist.Controls.Add(this.chklbItemList);
            this.pnitemlist.Controls.Add(this.txtItemDescription);
            this.pnitemlist.Location = new System.Drawing.Point(2, 36);
            this.pnitemlist.Name = "pnitemlist";
            this.pnitemlist.Size = new System.Drawing.Size(498, 251);
            this.pnitemlist.TabIndex = 222;
            // 
            // chkItemDesc
            // 
            this.chkItemDesc.AutoSize = true;
            this.chkItemDesc.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemDesc.ForeColor = System.Drawing.Color.Black;
            this.chkItemDesc.Location = new System.Drawing.Point(254, 2);
            this.chkItemDesc.Name = "chkItemDesc";
            this.chkItemDesc.Size = new System.Drawing.Size(140, 23);
            this.chkItemDesc.TabIndex = 209;
            this.chkItemDesc.Text = "Item Description";
            this.chkItemDesc.UseVisualStyleBackColor = true;
            this.chkItemDesc.CheckedChanged += new System.EventHandler(this.chkItemDesc_CheckedChanged);
            // 
            // chkItemCode
            // 
            this.chkItemCode.AutoSize = true;
            this.chkItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemCode.ForeColor = System.Drawing.Color.Black;
            this.chkItemCode.Location = new System.Drawing.Point(129, 2);
            this.chkItemCode.Name = "chkItemCode";
            this.chkItemCode.Size = new System.Drawing.Size(97, 23);
            this.chkItemCode.TabIndex = 208;
            this.chkItemCode.Text = "Item Code";
            this.chkItemCode.UseVisualStyleBackColor = true;
            this.chkItemCode.CheckedChanged += new System.EventHandler(this.chkItemCode_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(3, 2);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 19);
            this.label3.TabIndex = 124;
            this.label3.Text = "Search Item by";
            // 
            // chklbItemList
            // 
            this.chklbItemList.CheckOnClick = true;
            this.chklbItemList.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chklbItemList.FormattingEnabled = true;
            this.chklbItemList.HorizontalScrollbar = true;
            this.chklbItemList.Location = new System.Drawing.Point(3, 75);
            this.chklbItemList.Name = "chklbItemList";
            this.chklbItemList.Size = new System.Drawing.Size(488, 172);
            this.chklbItemList.TabIndex = 117;
            this.chklbItemList.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.chklbItemList_ItemCheck);
            // 
            // txtItemDescription
            // 
            this.txtItemDescription.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemDescription.Location = new System.Drawing.Point(7, 26);
            this.txtItemDescription.Multiline = true;
            this.txtItemDescription.Name = "txtItemDescription";
            this.txtItemDescription.Size = new System.Drawing.Size(483, 44);
            this.txtItemDescription.TabIndex = 121;
            this.txtItemDescription.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtItemDescription_KeyPress);
            this.txtItemDescription.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemDescription_KeyUp);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(566, 166);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(100, 18);
            this.label9.TabIndex = 221;
            this.label9.Text = "Project Status :";
            // 
            // lblProjectStatus
            // 
            this.lblProjectStatus.AutoSize = true;
            this.lblProjectStatus.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectStatus.ForeColor = System.Drawing.Color.Black;
            this.lblProjectStatus.Location = new System.Drawing.Point(663, 166);
            this.lblProjectStatus.Name = "lblProjectStatus";
            this.lblProjectStatus.Size = new System.Drawing.Size(12, 18);
            this.lblProjectStatus.TabIndex = 220;
            this.lblProjectStatus.Text = ".";
            // 
            // lblcustomername
            // 
            this.lblcustomername.AutoSize = true;
            this.lblcustomername.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcustomername.ForeColor = System.Drawing.Color.Black;
            this.lblcustomername.Location = new System.Drawing.Point(660, 129);
            this.lblcustomername.Name = "lblcustomername";
            this.lblcustomername.Size = new System.Drawing.Size(12, 18);
            this.lblcustomername.TabIndex = 219;
            this.lblcustomername.Text = ".";
            // 
            // lblprojname
            // 
            this.lblprojname.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprojname.ForeColor = System.Drawing.Color.Black;
            this.lblprojname.Location = new System.Drawing.Point(659, 53);
            this.lblprojname.Name = "lblprojname";
            this.lblprojname.Size = new System.Drawing.Size(515, 45);
            this.lblprojname.TabIndex = 218;
            this.lblprojname.Text = ".";
            // 
            // lblcustomer
            // 
            this.lblcustomer.AutoSize = true;
            this.lblcustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcustomer.ForeColor = System.Drawing.Color.Black;
            this.lblcustomer.Location = new System.Drawing.Point(588, 129);
            this.lblcustomer.Name = "lblcustomer";
            this.lblcustomer.Size = new System.Drawing.Size(75, 18);
            this.lblcustomer.TabIndex = 217;
            this.lblcustomer.Text = "Customer :";
            // 
            // lblProjectCode
            // 
            this.lblProjectCode.AutoSize = true;
            this.lblProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectCode.ForeColor = System.Drawing.Color.Black;
            this.lblProjectCode.Location = new System.Drawing.Point(566, 19);
            this.lblProjectCode.Name = "lblProjectCode";
            this.lblProjectCode.Size = new System.Drawing.Size(94, 18);
            this.lblProjectCode.TabIndex = 214;
            this.lblProjectCode.Text = "Project Code :";
            // 
            // cmbProjectCode
            // 
            this.cmbProjectCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProjectCode.DropDownHeight = 130;
            this.cmbProjectCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProjectCode.DropDownWidth = 239;
            this.cmbProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProjectCode.FormattingEnabled = true;
            this.cmbProjectCode.IntegralHeight = false;
            this.cmbProjectCode.Items.AddRange(new object[] {
            "None"});
            this.cmbProjectCode.Location = new System.Drawing.Point(662, 14);
            this.cmbProjectCode.Name = "cmbProjectCode";
            this.cmbProjectCode.Size = new System.Drawing.Size(286, 26);
            this.cmbProjectCode.TabIndex = 215;
            this.cmbProjectCode.SelectedIndexChanged += new System.EventHandler(this.cmbProjectCode_SelectedIndexChanged);
            // 
            // lblProjectName
            // 
            this.lblProjectName.AutoSize = true;
            this.lblProjectName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectName.ForeColor = System.Drawing.Color.Black;
            this.lblProjectName.Location = new System.Drawing.Point(564, 53);
            this.lblProjectName.Name = "lblProjectName";
            this.lblProjectName.Size = new System.Drawing.Size(99, 18);
            this.lblProjectName.TabIndex = 213;
            this.lblProjectName.Text = "Project Name :";
            // 
            // btnProjectView
            // 
            this.btnProjectView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnProjectView.Location = new System.Drawing.Point(954, 15);
            this.btnProjectView.Name = "btnProjectView";
            this.btnProjectView.Size = new System.Drawing.Size(24, 26);
            this.btnProjectView.TabIndex = 216;
            this.btnProjectView.Text = "....";
            this.btnProjectView.UseVisualStyleBackColor = false;
            this.btnProjectView.Click += new System.EventHandler(this.btnProjectView_Click);
            // 
            // tvProduct
            // 
            this.tvProduct.Cursor = System.Windows.Forms.Cursors.Default;
            this.tvProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tvProduct.HideSelection = false;
            this.tvProduct.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.tvProduct.Location = new System.Drawing.Point(12, 293);
            this.tvProduct.Name = "tvProduct";
            this.tvProduct.Size = new System.Drawing.Size(381, 324);
            this.tvProduct.StateImageList = this.imageList1;
            this.tvProduct.TabIndex = 229;
            this.tvProduct.NodeMouseDoubleClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.tvProduct_NodeMouseDoubleClick);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "folderopened_yellow.ico");
            this.imageList1.Images.SetKeyName(1, "diagram_v2_17.ico");
            this.imageList1.Images.SetKeyName(2, "Dryicons-Aesthetica-2-Process-accept.ico");
            this.imageList1.Images.SetKeyName(3, "Dryicons-Aesthetica-2-Process-remove.ico");
            this.imageList1.Images.SetKeyName(4, "Rafiqul-Hassan-Blogger-Settings.ico");
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(954, 237);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 19);
            this.label6.TabIndex = 231;
            this.label6.Text = "Issued Date :";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarFont = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.CustomFormat = "";
            this.dateTimePicker1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(1055, 234);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(118, 27);
            this.dateTimePicker1.TabIndex = 230;
            // 
            // frmElectronicsissue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1186, 619);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.tvProduct);
            this.Controls.Add(this.txtRemarks);
            this.Controls.Add(this.lblRemarks);
            this.Controls.Add(this.chkRawMaterailIssue);
            this.Controls.Add(this.chkProductIssue);
            this.Controls.Add(this.gpButtons);
            this.Controls.Add(this.dgIndentList);
            this.Controls.Add(this.pnitemlist);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lblProjectStatus);
            this.Controls.Add(this.lblcustomername);
            this.Controls.Add(this.lblprojname);
            this.Controls.Add(this.lblcustomer);
            this.Controls.Add(this.lblProjectCode);
            this.Controls.Add(this.cmbProjectCode);
            this.Controls.Add(this.lblProjectName);
            this.Controls.Add(this.btnProjectView);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmElectronicsissue";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Electronic Issue";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmElectronicsissue_FormClosing);
            this.Load += new System.EventHandler(this.frmElectronicsissue_Load);
            this.gpButtons.ResumeLayout(false);
            this.gpButtons.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgIndentList)).EndInit();
            this.pnitemlist.ResumeLayout(false);
            this.pnitemlist.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.Label lblRemarks;
        private System.Windows.Forms.CheckBox chkRawMaterailIssue;
        private System.Windows.Forms.CheckBox chkProductIssue;
        private System.Windows.Forms.GroupBox gpButtons;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClearAll;
        private System.Windows.Forms.DataGridView dgIndentList;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn Unit;
        private System.Windows.Forms.DataGridViewTextBoxColumn AvailableQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReqQty;
        private System.Windows.Forms.Panel pnitemlist;
        private System.Windows.Forms.CheckBox chkItemDesc;
        private System.Windows.Forms.CheckBox chkItemCode;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckedListBox chklbItemList;
        private System.Windows.Forms.TextBox txtItemDescription;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblProjectStatus;
        private System.Windows.Forms.Label lblcustomername;
        private System.Windows.Forms.Label lblprojname;
        private System.Windows.Forms.Label lblcustomer;
        private System.Windows.Forms.Label lblProjectCode;
        private System.Windows.Forms.ComboBox cmbProjectCode;
        private System.Windows.Forms.Label lblProjectName;
        private System.Windows.Forms.Button btnProjectView;
        private System.Windows.Forms.TreeView tvProduct;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.TextBox txtInsatallationCommision;
        private System.Windows.Forms.Button btnAddExtra;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
    }
}