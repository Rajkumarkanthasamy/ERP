﻿using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.KanBanProduct
{
    public partial class frmKanbanIssue : Form
    {
        public frmKanbanIssue()
        {
            InitializeComponent();
        }
        frmForm2 Home = new frmForm2();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        Global GlobalClass = new Global();
        DataTable dtProjectList = new DataTable();
        DataView dvItemList = new DataView();
        DataTable dtItemList = new DataTable();

        public int TransducerIssue = 0;
        private static string sProjectCode;
        public string fnProjectcode
        {
            get
            {
                return sProjectCode;
            }
            set
            {
                sProjectCode = value;
            }
        }

        private void frmKanbanIssue_Load(object sender, EventArgs e)
        {
            dtProjectList = DAL.fnWIPProjectList(null).Tables[0];

            if (dtProjectList.Rows.Count > 0)
            {
                foreach (DataRow DR in dtProjectList.Rows)
                {
                    if (!cmbProjectCode.Items.Contains(DR["ProjectCode"].ToString()))
                        cmbProjectCode.Items.Add(DR["ProjectCode"].ToString());
                }
            }
            // chkProductIssue.Checked = true;
            chkItemCode.Checked = true;

        }

        private void RowFilter()
        {
            chklbItemList.Items.Clear();
            foreach (DataRowView dv in dvItemList)
            {
                chklbItemList.Items.Add(string.Concat(dv["ID"].ToString(), ") ", dv["ItemCode"].ToString(), ", ", dv["ItemDescription"].ToString(), ", ", dv["AvailableQty"].ToString()));
            }
        }

        private void txtItemDescription_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar == '%' || e.KeyChar == '['))
            {
                e.Handled = true;
            }
        }

        private void txtItemDescription_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GlobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);
                    RowFilter();

                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GlobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
                    RowFilter();
                }
            }
            else
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GlobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);
                    RowFilter();
                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GlobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
                    RowFilter();
                }
            }
        }
        string[] sItemCode;
        DataTable dtItemcode = new DataTable();
        DataTable dtItemAdd = new DataTable();
        private void chklbItemList_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            try
            {
                int i = 0;
                if (chkProductIssue.Checked)
                {
                    sItemCode = chklbItemList.SelectedItem.ToString().Trim().Split(')');
                    string sID = sItemCode[0];
                    dtItemcode = DAL.fnKanBanFGItemList(1, sID).Tables[0];
                    if (dtItemcode.Rows.Count > 0)
                    {
                        if (!chklbItemList.CheckedItems.Contains(chklbItemList.SelectedItem))
                        {
                            foreach (DataGridViewRow DGVR in dgIndentList.Rows)
                            {
                                if (DGVR.Cells["ItemCode"].Value.ToString().Equals(dtItemcode.Rows[0]["ItemCode"].ToString()))
                                {
                                    i = 1;
                                    break;
                                }
                            }
                            if (i != 1)
                            {
                                if (dtItemAdd.Rows.Count == 0)
                                {
                                    dtItemAdd = DAL.fnKanBanFGItemList(1, "-9").Tables[0];
                                }

                                dtItemAdd.Rows.Add(dtItemcode.Rows[0]["ItemCode"].ToString(), dtItemcode.Rows[0]["ItemDescription"].ToString(),
                                                   dtItemcode.Rows[0]["Units"].ToString(), Convert.ToDouble(dtItemcode.Rows[0]["AvailableQty"].ToString()), dtItemcode.Rows[0]["UnitCost"].ToString(), dtItemcode.Rows[0]["ReqQty"].ToString());

                                dgIndentList.AutoGenerateColumns = false;
                                dgIndentList.DataSource = dtItemAdd;

                            }
                            else
                            {
                                MessageBox.Show("Selected Item already present in the list", "Error", 0, MessageBoxIcon.Error);
                                int k = chklbItemList.SelectedIndex;
                                chklbItemList.SetItemCheckState(k, CheckState.Unchecked);
                            }

                            foreach (DataGridViewRow dgr in dgIndentList.Rows)
                            {
                                if (Convert.ToDouble(dgr.Cells["AvailableQty"].Value) == Convert.ToDouble("0"))
                                {
                                    dgr.DefaultCellStyle.BackColor = Color.Red;
                                }
                            }
                        }
                        else
                        {
                            int rowIndex = -1;
                            bool bSelected;

                            foreach (DataGridViewRow row in dgIndentList.Rows)
                            {
                                bSelected = (row.Cells["ItemCode"].Value.ToString().Equals(dtItemcode.Rows[0]["ItemCode"].ToString()));
                                if (bSelected == true)
                                {
                                    rowIndex = row.Index;
                                    dgIndentList.Rows.Remove(dgIndentList.Rows[rowIndex]);
                                    break;
                                }
                            }
                        }
                    }
                }
                else if (chkRawMaterailIssue.Checked)
                {
                    sItemCode = chklbItemList.SelectedItem.ToString().Trim().Split(')');
                    string sID = sItemCode[0];
                    dtItemcode = DAL.fnKanBanFGItemList(2, sID).Tables[0];
                    if (dtItemcode.Rows.Count > 0)
                    {
                        if (!chklbItemList.CheckedItems.Contains(chklbItemList.SelectedItem))
                        {
                            foreach (DataGridViewRow DGVR in dgIndentList.Rows)
                            {
                                if (DGVR.Cells["ItemCode"].Value.ToString().Equals(dtItemcode.Rows[0]["ItemCode"].ToString()))
                                {
                                    i = 1;
                                    break;
                                }
                            }
                            if (i != 1)
                            {
                                if (dtItemAdd.Rows.Count == 0)
                                {
                                    dtItemAdd = DAL.fnKanBanFGItemList(2, "-9").Tables[0];
                                }

                                dtItemAdd.Rows.Add(dtItemcode.Rows[0]["ItemCode"].ToString(), dtItemcode.Rows[0]["ItemDescription"].ToString(),
                                                   dtItemcode.Rows[0]["Units"].ToString(), Convert.ToDouble(dtItemcode.Rows[0]["AvailableQty"].ToString()), dtItemcode.Rows[0]["UnitCost"].ToString(), dtItemcode.Rows[0]["ReqQty"].ToString());

                                dgIndentList.AutoGenerateColumns = false;
                                dgIndentList.DataSource = dtItemAdd;

                            }
                            else
                            {
                                MessageBox.Show("Selected Item already present in the list", "Error", 0, MessageBoxIcon.Error);
                                int k = chklbItemList.SelectedIndex;
                                chklbItemList.SetItemCheckState(k, CheckState.Unchecked);
                            }

                            foreach (DataGridViewRow dgr in dgIndentList.Rows)
                            {
                                if (Convert.ToDouble(dgr.Cells["AvailableQty"].Value) == Convert.ToDouble("0"))
                                {
                                    dgr.DefaultCellStyle.BackColor = Color.Red;
                                }
                            }
                        }
                        else
                        {
                            int rowIndex = -1;
                            bool bSelected;

                            foreach (DataGridViewRow row in dgIndentList.Rows)
                            {
                                bSelected = (row.Cells["ItemCode"].Value.ToString().Equals(dtItemcode.Rows[0]["ItemCode"].ToString()));
                                if (bSelected == true)
                                {
                                    rowIndex = row.Index;
                                    dgIndentList.Rows.Remove(dgIndentList.Rows[rowIndex]);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("PurchaseOrder_chklbItemList_ItemCheck" + ex.Message);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            fnExit();
        }

        private void fnExit()
        {
            this.Hide();
            Home.Show();
        }

        private void frmKanbanIssue_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnExit();
        }

        private void btnProjectView_Click(object sender, EventArgs e)
        {
            TransducerIssue = 1;
            Indent.frmProjectselect projectsearch = new Indent.frmProjectselect();
            projectsearch.fnTransIssue = TransducerIssue.ToString();
            projectsearch.ShowDialog();
            if (fnProjectcode != null)
            {
                cmbProjectCode.Text = sProjectCode;
            }
        }
        DataTable dtProjectBOMdetails = new DataTable();
        private void cmbProjectCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtProjectBOMdetails = DAL.fnWIPProjectCode(cmbProjectCode.Text).Tables[0];
            if (dtProjectBOMdetails.Rows.Count > 0)
            {
                lblprojname.Text = dtProjectBOMdetails.Rows[0]["ProjectDescription"].ToString();
                lblcustomername.Text = dtProjectBOMdetails.Rows[0]["Customer"].ToString();
                lblProjectStatus.Text = dtProjectBOMdetails.Rows[0]["Status"].ToString();
            }
            else
            {
                lblprojname.ResetText();
                lblcustomername.ResetText();
                lblProjectStatus.ResetText();
            }
        }
        double oldvalue;
        private void dgIndentList_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgIndentList.CurrentCell.OwningColumn.Name == "ReqQty")
            {
                oldvalue = Convert.ToDouble(dgIndentList.CurrentCell.Value);
            }
        }

        private void dgIndentList_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (!string.IsNullOrEmpty(dgIndentList.CurrentCell.Value.ToString()) && (dgIndentList.CurrentCell.Value.ToString() != "."))
            {
                if (Convert.ToDouble(dgIndentList.CurrentCell.Value.ToString()) != 0)
                {
                    if (Convert.ToDouble(dgIndentList.CurrentCell.Value.ToString()) <= Convert.ToDouble(dgIndentList.CurrentRow.Cells["AvailableQty"].Value.ToString()))
                    {

                    }
                    else
                    {
                        MessageBox.Show("Entered value should be equal or lesser than available quantity", "Error", 0, MessageBoxIcon.Error);
                        dgIndentList.CurrentCell.Value = oldvalue;
                    }
                }
                else
                {
                    MessageBox.Show("Entered value should be greater than 0", "Error", 0, MessageBoxIcon.Error);
                    dgIndentList.CurrentCell.Value = oldvalue;
                }
            }
            else
            {
                MessageBox.Show("Enter a Valid Value", "Error", 0, MessageBoxIcon.Error);
                dgIndentList.CurrentCell.Value = oldvalue;
            }
        }

        private bool bIPQuanity = true;
        private bool bIPQuanityHigh = true;
        private void fnQuantitycheck()
        {
            bIPQuanity = true;
            bIPQuanityHigh = true;
            foreach (DataGridViewRow row in dgIndentList.Rows)
            {
                if (string.IsNullOrEmpty(row.Cells[5].Value.ToString()) || Convert.ToDouble(row.Cells[5].Value.ToString()) == 0)
                {
                    bIPQuanity = false;
                    break;
                }

                if (Convert.ToDouble(row.Cells[5].Value.ToString()) > Convert.ToDouble(row.Cells[3].Value.ToString()))
                {
                    bIPQuanityHigh = false;
                    break;

                }
            }
        }

        DataTable dtKanProductNo = new DataTable();
        string sKanProductNo;
        string sNewProduct;
        int iLastPONo;

        DataTable dtProjectType = new DataTable();
        DataTable dtProjectAllCost = new DataTable();
        double dProjectCost = 0;
        double dCurrentIssuedAmount = 0;
        double dTotalProjectSum = 0;
        bool bProjectCost = true;
        private void fnProjectAmountCheck()
        {
            bProjectCost = true;
            dProjectCost = 0;
            dCurrentIssuedAmount = 0;
            dTotalProjectSum = 0;
            dtProjectType = DAL.fnProjectCostLimitCIP(0, cmbProjectCode.Text).Tables[0];
            if (dtProjectType.Rows.Count > 0)
            {
                if (dtProjectType.Rows[0]["ProjectType"].ToString() == "Fixed Asset (CIP)")
                {
                    dtProjectAllCost = DAL.fnProjectCostLimitCIP(2, cmbProjectCode.Text).Tables[0];

                    if (dtProjectAllCost.Rows.Count > 0)
                    {
                        dProjectCost = Convert.ToDouble(dtProjectAllCost.Rows[0]["TotalAmount"].ToString());
                        dTotalProjectSum = dtProjectAllCost.AsEnumerable().Sum(r => r.Field<double>("TotalAmount"));
                        dTotalProjectSum = dTotalProjectSum - dProjectCost;
                    }

                    dCurrentIssuedAmount = Convert.ToDouble(0);

                    foreach (DataGridViewRow drow in dgIndentList.Rows)
                    {
                        dCurrentIssuedAmount += Convert.ToDouble(drow.Cells["UnitCost"].Value) * Convert.ToDouble(drow.Cells["ReqQty"].Value);
                    }


                    if (dtProjectType.Rows[0]["Type"].ToString() == "Inhouse")
                    {
                        dProjectCost = (dProjectCost / 1.3);
                        if ((dTotalProjectSum + dCurrentIssuedAmount) < dProjectCost)
                        {
                            bProjectCost = true;
                        }
                        else
                        {
                            bProjectCost = false;
                        }
                    }
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (cmbProjectCode.SelectedIndex >= 0 && dgIndentList.Rows.Count > 0 && !string.IsNullOrEmpty(txtRemarks.Text))
            {
                fnQuantitycheck();
                fnProjectAmountCheck();
                if (bIPQuanity && bIPQuanityHigh&& bProjectCost)
                {
                    string NowDate = DateTime.Now.ToString("dd-MM-yyyy");
                    dtKanProductNo = DAL.KANProductNo(1, null).Tables[0];
                    if (dtKanProductNo.Rows.Count > 0)
                    {
                        sKanProductNo = dtKanProductNo.Rows[0][1].ToString();
                        sNewProduct = sKanProductNo.Substring(02, 08);
                        iLastPONo = Convert.ToInt32(sNewProduct);
                        iLastPONo++;
                        sKanProductNo = "KI" + iLastPONo;
                    }
                    else
                    {
                        sKanProductNo = "KI20200001";
                    }
                    if (chkProductIssue.Checked)
                    {
                        foreach (DataGridViewRow row in dgIndentList.Rows)
                        {
                            GlobalClass.iSuccess = DAL.fnAddKanBanIssued(1, row.Cells[0].Value.ToString(), "TransducerFG",
                                Convert.ToDouble(row.Cells[5].Value.ToString()), Convert.ToDouble(row.Cells[4].Value.ToString()),
                                login.GetUserDetails[2].ToString(), sKanProductNo, cmbProjectCode.Text, txtRemarks.Text);

                            GlobalClass.iSuccess = DAL.fnUpdateKanaBanItemDetails(6, Convert.ToDouble(row.Cells[5].Value), row.Cells[0].Value.ToString());
                        }

                        GlobalClass.iSuccess = DAL.fnAddERPLog(0, sKanProductNo, login.GetUserDetails[2], NowDate, "KanBan TransducerFG Item Issue", "KanBanIssued");
                    }
                    else if (chkRawMaterailIssue.Checked)
                    {
                        foreach (DataGridViewRow row in dgIndentList.Rows)
                        {
                            GlobalClass.iSuccess = DAL.fnAddKanBanIssued(1, row.Cells[0].Value.ToString(), "TransducerItem",
                                Convert.ToDouble(row.Cells[5].Value.ToString()), Convert.ToDouble(row.Cells[4].Value.ToString()),
                                login.GetUserDetails[2].ToString(), sKanProductNo, cmbProjectCode.Text, txtRemarks.Text);

                            GlobalClass.iSuccess = DAL.fnUpdateKanaBanItemDetails(3, Convert.ToDouble(row.Cells[5].Value), row.Cells[0].Value.ToString());
                        }

                        GlobalClass.iSuccess = DAL.fnAddERPLog(0, sKanProductNo, login.GetUserDetails[2], NowDate, "KanBan Transducer Item Issue", "KanBanIssued");
                    }

                   

                    MessageBox.Show("Items issued to the project successfully", "Success", 0, MessageBoxIcon.Information);
                    this.Hide();
                    frmKanbanIssue KIssue = new frmKanbanIssue();
                    KIssue.Show();
                }
                else
                {
                    if (!bIPQuanityHigh)
                    {
                        MessageBox.Show("Entered Item quantity is more than available quantity", "Error", 0, MessageBoxIcon.Error);
                    }
                    else if (!bIPQuanity)
                    {
                        MessageBox.Show("Enter Items quantity ", "Error", 0, MessageBoxIcon.Error);
                    }
                    else if (!bProjectCost)
                    {
                        MessageBox.Show("Issued items limit is more than capex amount.\nContact Accounts department for more details. \n \n Project Capex Amount : " + Math.Round(dProjectCost) + " \n Total Project Issued Amount : " + Math.Round(dTotalProjectSum ) + " \n Current Project Issuing Amount : " + Math.Round(dCurrentIssuedAmount) + "", "Error", 0, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                if (cmbProjectCode.SelectedIndex < 0)
                {
                    MessageBox.Show("Select the Project code", "Error", 0, MessageBoxIcon.Error);
                }
                else if (dgIndentList.Rows.Count == 0)
                {
                    MessageBox.Show("Select the items to issue", "Error", 0, MessageBoxIcon.Error);
                }
                else if (string.IsNullOrEmpty(txtRemarks.Text))
                {
                    MessageBox.Show("Enter remarks", "Error", 0, MessageBoxIcon.Error);
                    txtRemarks.Focus();
                }
            }
        }

        private void chkProductIssue_CheckedChanged(object sender, EventArgs e)
        {
            if (chkProductIssue.Checked)
            {
                chkRawMaterailIssue.Enabled = false;
                chkRawMaterailIssue.Checked = false;
                dtItemList.Rows.Clear();
                dtItemList = DAL.fnKanBanFGItemList(0, null).Tables[0];
                RowFilter();
            }
        }

        private void chkRawMaterailIssue_CheckedChanged(object sender, EventArgs e)
        {
            if (chkRawMaterailIssue.Checked)
            {
                chkProductIssue.Enabled = false;
                chkProductIssue.Checked = false;
                dtItemList.Rows.Clear();
                dtItemList = DAL.fnKanBanItemList(null).Tables[0];
                RowFilter();
            }
        }

        private void chkItemCode_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemCode.Checked)
            {
                chkItemDesc.Checked = false;
            }
        }

        private void chkItemDesc_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemDesc.Checked)
            {
                chkItemCode.Checked = false;
            }
        }

        private void btnClearAll_Click(object sender, EventArgs e)
        {
            fnExit();
        }

        private void dgIndentList_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (dgIndentList.Rows.Count > 0)
                {
                    dgIndentList.Rows.RemoveAt(dgIndentList.Rows.IndexOf(dgIndentList.CurrentRow));
                }
            }
        }
        private void Control_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }
            // only allow one decimal point
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                e.Handled = true;
            }
        }
        private void dgIndentList_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show(" dgPackingTaxes_EditingControlShowing   " + ex.Message);
            }
        }

    }
}