﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Purchase_Order
{
    public partial class BOMPR : Form
    {
        public BOMPR()
        {
            InitializeComponent();
        }

        private void materialTabSelector1_Click(object sender, EventArgs e)
        {

        }

        private void BOMPR_Load(object sender, EventArgs e)
        {

        }
    }
}
