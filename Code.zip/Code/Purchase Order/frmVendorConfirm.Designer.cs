﻿namespace Erp_Project_With_Buttons.Purchase_Order
{
    partial class frmVendorConfirm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmVendorConfirm));
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.dgvCopyEmail = new System.Windows.Forms.DataGridView();
            this.pnPOWO = new System.Windows.Forms.Panel();
            this.lblpowoby = new System.Windows.Forms.Label();
            this.lblVendor = new System.Windows.Forms.Label();
            this.txtVendorcode = new System.Windows.Forms.Label();
            this.lblprojcode = new System.Windows.Forms.Label();
            this.lblprojectdesc = new System.Windows.Forms.Label();
            this.lblcustomername = new System.Windows.Forms.Label();
            this.lblCustomer = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblpogenaratedby = new System.Windows.Forms.Label();
            this.lblVendorcode = new System.Windows.Forms.Label();
            this.lblprojectcode = new System.Windows.Forms.Label();
            this.lblprojectname = new System.Windows.Forms.Label();
            this.lblVendorname = new System.Windows.Forms.Label();
            this.cmbPonumber = new System.Windows.Forms.ComboBox();
            this.lblWonumber = new System.Windows.Forms.Label();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.POQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lstusers = new System.Windows.Forms.ListBox();
            this.dtpSentdate = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCopyEmail)).BeginInit();
            this.pnPOWO.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(961, 516);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(90, 39);
            this.btnExit.TabIndex = 193;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(793, 516);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(108, 39);
            this.btnSave.TabIndex = 192;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // dgvCopyEmail
            // 
            this.dgvCopyEmail.AllowUserToAddRows = false;
            this.dgvCopyEmail.AllowUserToDeleteRows = false;
            this.dgvCopyEmail.AllowUserToResizeRows = false;
            this.dgvCopyEmail.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.Desktop;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCopyEmail.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvCopyEmail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCopyEmail.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.POQty});
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvCopyEmail.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgvCopyEmail.EnableHeadersVisualStyles = false;
            this.dgvCopyEmail.Location = new System.Drawing.Point(12, 187);
            this.dgvCopyEmail.MultiSelect = false;
            this.dgvCopyEmail.Name = "dgvCopyEmail";
            this.dgvCopyEmail.RowHeadersVisible = false;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvCopyEmail.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvCopyEmail.Size = new System.Drawing.Size(1039, 321);
            this.dgvCopyEmail.TabIndex = 191;
            // 
            // pnPOWO
            // 
            this.pnPOWO.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnPOWO.Controls.Add(this.dtpSentdate);
            this.pnPOWO.Controls.Add(this.lstusers);
            this.pnPOWO.Controls.Add(this.lblpowoby);
            this.pnPOWO.Controls.Add(this.lblVendor);
            this.pnPOWO.Controls.Add(this.txtVendorcode);
            this.pnPOWO.Controls.Add(this.lblprojcode);
            this.pnPOWO.Controls.Add(this.lblprojectdesc);
            this.pnPOWO.Controls.Add(this.lblcustomername);
            this.pnPOWO.Controls.Add(this.lblCustomer);
            this.pnPOWO.Controls.Add(this.textBox1);
            this.pnPOWO.Controls.Add(this.lblpogenaratedby);
            this.pnPOWO.Controls.Add(this.lblVendorcode);
            this.pnPOWO.Controls.Add(this.lblprojectcode);
            this.pnPOWO.Controls.Add(this.lblprojectname);
            this.pnPOWO.Controls.Add(this.lblVendorname);
            this.pnPOWO.Controls.Add(this.cmbPonumber);
            this.pnPOWO.Controls.Add(this.lblWonumber);
            this.pnPOWO.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pnPOWO.Location = new System.Drawing.Point(12, 12);
            this.pnPOWO.Name = "pnPOWO";
            this.pnPOWO.Size = new System.Drawing.Size(1039, 169);
            this.pnPOWO.TabIndex = 190;
            // 
            // lblpowoby
            // 
            this.lblpowoby.AutoSize = true;
            this.lblpowoby.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpowoby.ForeColor = System.Drawing.Color.Black;
            this.lblpowoby.Location = new System.Drawing.Point(558, 102);
            this.lblpowoby.Name = "lblpowoby";
            this.lblpowoby.Size = new System.Drawing.Size(16, 18);
            this.lblpowoby.TabIndex = 183;
            this.lblpowoby.Text = "C";
            // 
            // lblVendor
            // 
            this.lblVendor.AutoSize = true;
            this.lblVendor.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVendor.ForeColor = System.Drawing.Color.Black;
            this.lblVendor.Location = new System.Drawing.Point(558, 41);
            this.lblVendor.Name = "lblVendor";
            this.lblVendor.Size = new System.Drawing.Size(16, 18);
            this.lblVendor.TabIndex = 183;
            this.lblVendor.Text = "C";
            // 
            // txtVendorcode
            // 
            this.txtVendorcode.AutoSize = true;
            this.txtVendorcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVendorcode.ForeColor = System.Drawing.Color.Black;
            this.txtVendorcode.Location = new System.Drawing.Point(178, 42);
            this.txtVendorcode.Name = "txtVendorcode";
            this.txtVendorcode.Size = new System.Drawing.Size(16, 18);
            this.txtVendorcode.TabIndex = 183;
            this.txtVendorcode.Text = "C";
            // 
            // lblprojcode
            // 
            this.lblprojcode.AutoSize = true;
            this.lblprojcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprojcode.ForeColor = System.Drawing.Color.Black;
            this.lblprojcode.Location = new System.Drawing.Point(178, 72);
            this.lblprojcode.Name = "lblprojcode";
            this.lblprojcode.Size = new System.Drawing.Size(16, 18);
            this.lblprojcode.TabIndex = 183;
            this.lblprojcode.Text = "C";
            // 
            // lblprojectdesc
            // 
            this.lblprojectdesc.AutoSize = true;
            this.lblprojectdesc.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprojectdesc.ForeColor = System.Drawing.Color.Black;
            this.lblprojectdesc.Location = new System.Drawing.Point(558, 72);
            this.lblprojectdesc.Name = "lblprojectdesc";
            this.lblprojectdesc.Size = new System.Drawing.Size(16, 18);
            this.lblprojectdesc.TabIndex = 183;
            this.lblprojectdesc.Text = "C";
            // 
            // lblcustomername
            // 
            this.lblcustomername.AutoSize = true;
            this.lblcustomername.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcustomername.ForeColor = System.Drawing.Color.Black;
            this.lblcustomername.Location = new System.Drawing.Point(178, 103);
            this.lblcustomername.Name = "lblcustomername";
            this.lblcustomername.Size = new System.Drawing.Size(16, 18);
            this.lblcustomername.TabIndex = 183;
            this.lblcustomername.Text = "C";
            // 
            // lblCustomer
            // 
            this.lblCustomer.AutoSize = true;
            this.lblCustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomer.ForeColor = System.Drawing.Color.Black;
            this.lblCustomer.Location = new System.Drawing.Point(103, 103);
            this.lblCustomer.Name = "lblCustomer";
            this.lblCustomer.Size = new System.Drawing.Size(75, 18);
            this.lblCustomer.TabIndex = 183;
            this.lblCustomer.Text = "Customer :";
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(1261, -63);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(86, 21);
            this.textBox1.TabIndex = 154;
            // 
            // lblpogenaratedby
            // 
            this.lblpogenaratedby.AutoSize = true;
            this.lblpogenaratedby.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpogenaratedby.ForeColor = System.Drawing.Color.Black;
            this.lblpogenaratedby.Location = new System.Drawing.Point(474, 102);
            this.lblpogenaratedby.Name = "lblpogenaratedby";
            this.lblpogenaratedby.Size = new System.Drawing.Size(87, 18);
            this.lblpogenaratedby.TabIndex = 176;
            this.lblpogenaratedby.Text = "Prepared By:";
            // 
            // lblVendorcode
            // 
            this.lblVendorcode.AutoSize = true;
            this.lblVendorcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVendorcode.ForeColor = System.Drawing.Color.Black;
            this.lblVendorcode.Location = new System.Drawing.Point(52, 42);
            this.lblVendorcode.Name = "lblVendorcode";
            this.lblVendorcode.Size = new System.Drawing.Size(126, 18);
            this.lblVendorcode.TabIndex = 164;
            this.lblVendorcode.Text = "Vendor Code, GST :";
            // 
            // lblprojectcode
            // 
            this.lblprojectcode.AutoSize = true;
            this.lblprojectcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprojectcode.ForeColor = System.Drawing.Color.Black;
            this.lblprojectcode.Location = new System.Drawing.Point(84, 72);
            this.lblprojectcode.Name = "lblprojectcode";
            this.lblprojectcode.Size = new System.Drawing.Size(94, 18);
            this.lblprojectcode.TabIndex = 173;
            this.lblprojectcode.Text = "Project Code :";
            // 
            // lblprojectname
            // 
            this.lblprojectname.AutoSize = true;
            this.lblprojectname.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprojectname.ForeColor = System.Drawing.Color.Black;
            this.lblprojectname.Location = new System.Drawing.Point(462, 72);
            this.lblprojectname.Name = "lblprojectname";
            this.lblprojectname.Size = new System.Drawing.Size(99, 18);
            this.lblprojectname.TabIndex = 172;
            this.lblprojectname.Text = "Project Name :";
            // 
            // lblVendorname
            // 
            this.lblVendorname.AutoSize = true;
            this.lblVendorname.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVendorname.ForeColor = System.Drawing.Color.Black;
            this.lblVendorname.Location = new System.Drawing.Point(462, 41);
            this.lblVendorname.Name = "lblVendorname";
            this.lblVendorname.Size = new System.Drawing.Size(100, 18);
            this.lblVendorname.TabIndex = 166;
            this.lblVendorname.Text = "Vendor Name :";
            // 
            // cmbPonumber
            // 
            this.cmbPonumber.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbPonumber.DropDownHeight = 130;
            this.cmbPonumber.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPonumber.FormattingEnabled = true;
            this.cmbPonumber.IntegralHeight = false;
            this.cmbPonumber.ItemHeight = 15;
            this.cmbPonumber.Location = new System.Drawing.Point(183, 7);
            this.cmbPonumber.Name = "cmbPonumber";
            this.cmbPonumber.Size = new System.Drawing.Size(184, 23);
            this.cmbPonumber.TabIndex = 168;
            this.cmbPonumber.SelectedIndexChanged += new System.EventHandler(this.cmbPonumber_SelectedIndexChanged);
            // 
            // lblWonumber
            // 
            this.lblWonumber.AutoSize = true;
            this.lblWonumber.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWonumber.ForeColor = System.Drawing.Color.Black;
            this.lblWonumber.Location = new System.Drawing.Point(91, 10);
            this.lblWonumber.Name = "lblWonumber";
            this.lblWonumber.Size = new System.Drawing.Size(87, 18);
            this.lblWonumber.TabIndex = 158;
            this.lblWonumber.Text = "PO Number :";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "ItemCode";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewTextBoxColumn2.HeaderText = "Item Code";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn2.Width = 84;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn3.DataPropertyName = "ItemDescription";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewTextBoxColumn3.HeaderText = "Item Description";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn3.Width = 132;
            // 
            // POQty
            // 
            this.POQty.DataPropertyName = "RequariedQty";
            this.POQty.HeaderText = "PO Qty";
            this.POQty.Name = "POQty";
            this.POQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.POQty.Width = 64;
            // 
            // lstusers
            // 
            this.lstusers.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstusers.FormattingEnabled = true;
            this.lstusers.ItemHeight = 19;
            this.lstusers.Location = new System.Drawing.Point(808, 36);
            this.lstusers.Name = "lstusers";
            this.lstusers.ScrollAlwaysVisible = true;
            this.lstusers.Size = new System.Drawing.Size(110, 23);
            this.lstusers.TabIndex = 199;
            this.lstusers.Visible = false;
            // 
            // dtpSentdate
            // 
            this.dtpSentdate.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpSentdate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSentdate.Location = new System.Drawing.Point(808, 5);
            this.dtpSentdate.Name = "dtpSentdate";
            this.dtpSentdate.Size = new System.Drawing.Size(90, 23);
            this.dtpSentdate.TabIndex = 200;
            this.dtpSentdate.ValueChanged += new System.EventHandler(this.dtpSentdate_ValueChanged);
            // 
            // frmVendorConfirm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1058, 567);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.dgvCopyEmail);
            this.Controls.Add(this.pnPOWO);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmVendorConfirm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PO Vendor Confirm";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmVendorConfirm_FormClosing);
            this.Load += new System.EventHandler(this.frmVendorConfirm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCopyEmail)).EndInit();
            this.pnPOWO.ResumeLayout(false);
            this.pnPOWO.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.DataGridView dgvCopyEmail;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn POQty;
        private System.Windows.Forms.Panel pnPOWO;
        private System.Windows.Forms.Label lblpowoby;
        private System.Windows.Forms.Label lblVendor;
        private System.Windows.Forms.Label txtVendorcode;
        private System.Windows.Forms.Label lblprojcode;
        private System.Windows.Forms.Label lblprojectdesc;
        private System.Windows.Forms.Label lblcustomername;
        private System.Windows.Forms.Label lblCustomer;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblpogenaratedby;
        private System.Windows.Forms.Label lblVendorcode;
        private System.Windows.Forms.Label lblprojectcode;
        private System.Windows.Forms.Label lblprojectname;
        private System.Windows.Forms.Label lblVendorname;
        private System.Windows.Forms.ComboBox cmbPonumber;
        private System.Windows.Forms.Label lblWonumber;
        private System.Windows.Forms.ListBox lstusers;
        private System.Windows.Forms.DateTimePicker dtpSentdate;
    }
}