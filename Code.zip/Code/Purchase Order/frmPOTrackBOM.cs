﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Purchase_Order
{
    public partial class frmPOTrackBOM : Form
    {
        public frmPOTrackBOM()
        {
            InitializeComponent();
        }
        DataAccessLayer DAL = new DataAccessLayer();
        Global GLobalClass = new Global();
        frmForm2 form = new frmForm2();
        Login.frmLoginForm login = new Login.frmLoginForm();
        DataTable dtWIPProjectlist = new DataTable();
        DataTable dtDGDatatable = new DataTable();
       private static string sViewBOMProjectCode;
        public string fnViewBOMProjectcode
        {
            get
            {
                return sViewBOMProjectCode;
            }
            set
            {
                sViewBOMProjectCode = value;
            }
        }

        private void frmPOTrackBOM_Load(object sender, EventArgs e)
        {
            dtWIPProjectlist = DAL.fnWIPProjectList(null).Tables[0];

            foreach (DataRow DR in dtWIPProjectlist.Rows)
            {
                if (!cmbProjectCode.Items.Contains(DR["ProjectCode"].ToString()))
                    cmbProjectCode.Items.Add(DR["ProjectCode"].ToString());
            }
        }
        DataView dvProjectName = new DataView();
        private void cmbProjectCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            dvProjectName = new DataView(dtWIPProjectlist);

            dvProjectName.RowFilter = "ProjectCode='" + cmbProjectCode.Text + "'";
            if (dvProjectName.ToTable().Rows.Count > 0)
            {
                txtProjectName.Text = dvProjectName.ToTable().Rows[0]["ProjectDescription"].ToString();
            }

            dtDGDatatable = DAL.fnDirectViewProjectBOMList(cmbProjectCode.Text).Tables[0];

            if (dtDGDatatable.Rows.Count > 0)
            {
                dgItemOrProductList.AutoGenerateColumns = false;
                dgItemOrProductList.DataSource = dtDGDatatable;
            }
            else
            {
                dgItemOrProductList.DataSource = null;
                dgBOMList.DataSource = null;
            }
        }

        DataTable dtNewGridviewItems = new DataTable();
        DataTable dtItemsofMachineBOM = new DataTable();
        DataTable dtLatestCost = new DataTable();
        private void dgItemOrProductList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (!string.IsNullOrEmpty(dgItemOrProductList.CurrentRow.Cells["PProductCode"].Value.ToString()))
            {
                dtNewGridviewItems = DAL.fnProjectViewBOMProdutnamenumber(1, dgItemOrProductList.CurrentRow.Cells["SLNO"].Value.ToString()).Tables[0];
                if (dtNewGridviewItems.Rows.Count > 0)
                {
                    dtItemsofMachineBOM = DAL.fnMachineBOMProdutViewItems(1, dtNewGridviewItems.Rows[0]["ProductNo"].ToString(), cmbProjectCode.Text).Tables[0];


                    if (dtItemsofMachineBOM.Rows.Count > 0)
                    {
                        dgBOMList.AutoGenerateColumns = false;

                        dgBOMList.DataSource = dtItemsofMachineBOM;
                        dataGridView1.DataSource = null;
                        Datagridviewcolor(dgBOMList);
                    }
                    else
                    {
                        dgBOMList.DataSource = null;
                        dataGridView1.DataSource = null;
                    }
                }
            }
        }

        private void Datagridviewcolor(DataGridView dgDataGridView)
        {
            foreach (DataGridViewRow dgr in dgDataGridView.Rows)
            {
                if (Convert.ToDouble(dgr.Cells[4].Value.ToString()) == 0 && Convert.ToDouble(dgr.Cells[7].Value.ToString()) == 0)
                {
                    dgr.DefaultCellStyle.BackColor = Color.Red;
                }
                 if (Convert.ToDouble(dgr.Cells[5].Value.ToString()) ==Convert.ToDouble(dgr.Cells[6].Value.ToString()))
                {
                    dgr.DefaultCellStyle.BackColor = Color.Green;
                }
                 if (Convert.ToDouble(dgr.Cells[4].Value.ToString()) == 0 && Convert.ToDouble(dgr.Cells[5].Value.ToString()) == Convert.ToDouble(dgr.Cells[6].Value.ToString()))
                {
                    dgr.DefaultCellStyle.BackColor = Color.Green;
                }
                 if (Convert.ToDouble(dgr.Cells[4].Value.ToString()) == 0 && Convert.ToDouble(dgr.Cells[5].Value.ToString()) <= Convert.ToDouble(dgr.Cells[7].Value.ToString()))
                {
                    dgr.DefaultCellStyle.BackColor = Color.Yellow;
                }
                 if (Convert.ToDouble(dgr.Cells[4].Value.ToString()) == 0 && Convert.ToDouble(dgr.Cells[7].Value.ToString()) == 0)
                {
                    dgr.DefaultCellStyle.BackColor = Color.Red;
                }

                else if (Convert.ToDouble(dgr.Cells[4].Value.ToString()) == 0 && Convert.ToDouble(dgr.Cells[7].Value.ToString()) > 0 && Convert.ToDouble(dgr.Cells[5].Value.ToString()) < Convert.ToDouble(dgr.Cells[6].Value.ToString()))
                {
                    dgr.DefaultCellStyle.BackColor = Color.Yellow;
                }
                else if (Convert.ToDouble(dgr.Cells[4].Value.ToString()) == (Convert.ToDouble(dgr.Cells[5].Value.ToString()) - Convert.ToDouble(dgr.Cells[6].Value.ToString())))
                {
                    dgr.DefaultCellStyle.BackColor = Color.LightGreen;
                }
                else if (Convert.ToDouble(dgr.Cells[4].Value.ToString()) > 0 && Convert.ToDouble(dgr.Cells[7].Value.ToString()) > 0 && Convert.ToDouble(dgr.Cells[4].Value.ToString()) < Convert.ToDouble(dgr.Cells[5].Value.ToString()))
                {
                    dgr.DefaultCellStyle.BackColor = Color.Yellow;
                }

                else if (Convert.ToDouble(dgr.Cells[4].Value.ToString()) >= Convert.ToDouble(dgr.Cells[5].Value.ToString()))
                {
                    dgr.DefaultCellStyle.BackColor = Color.LightGreen;
                }
            }
        }

        private void frmPOTrackBOM_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            form.Show();
        }
        DataTable dtViewItems = new DataTable();
        private void dgBOMList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dtNewGridviewItems.Rows.Count > 0)
            {
                dtViewItems = DAL.fnMachineBOMProdutViewItemsHistory(0, dtNewGridviewItems.Rows[0]["ProductNo"].ToString(), cmbProjectCode.Text, dgBOMList.CurrentRow.Cells["uItemCode"].Value.ToString()).Tables[0];
                if (dtViewItems.Rows.Count > 0)
                {
                    dataGridView1.AutoGenerateColumns = false;
                    dataGridView1.DataSource = dtViewItems;
                }
                else
                {
                    dataGridView1.DataSource = null;
                }
            }
        }
        BindingSource bsIteSearch = new BindingSource();
        DataTable dtClone = new DataTable();
        private void txtItemSearch_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtItemSearch.TextLength > 2)
            {
                if (dtItemsofMachineBOM.Rows.Count > 0)
                {
                    dtClone = dtItemsofMachineBOM.Copy();
                    bsIteSearch.DataSource = dtClone;

                    bsIteSearch.Filter = string.Format("ItemName LIKE '%{0}%' OR ItemDescription LIKE '%{0}%' or ProductType LIKE '%{0}%'", txtItemSearch.Text);
                    dgBOMList.DataSource = bsIteSearch;
                    Datagridviewcolor(dgBOMList);
                }
            }
            else
            {
                bsIteSearch.RemoveFilter();
                Datagridviewcolor(dgBOMList);
            }
        }

        private void btnProjectView_Click(object sender, EventArgs e)
        {
            Indent.frmProjectselect projectsearch = new Indent.frmProjectselect();
            projectsearch.fnViewProjectBOM = "1";
            projectsearch.ShowDialog();
            if (fnViewBOMProjectcode != null)
            {
                cmbProjectCode.Text = sViewBOMProjectCode;
            }
        }
    }
}
