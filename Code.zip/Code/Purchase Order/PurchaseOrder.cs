﻿
#region Purchase Order NameSpaces
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;
using System.IO;
using System.Diagnostics;
using System.Globalization;
using Outlook = Microsoft.Office.Interop.Outlook;





//using iTextSharp.text;
using iTextSharp.text.pdf;
#endregion

namespace Erp_Project_With_Buttons.Purchase_Order
{
    public partial class PurchaseOrder : Form
    {
        #region Purchase Order Tables and Local Variables
        frmForm2 frm = new frmForm2();
        DataAccessLayer DAL = new DataAccessLayer();
        Global GLobalClass = new Global();
        frmForm2 form = new frmForm2();
        Login.frmLoginForm login = new Login.frmLoginForm();


     

        DataTable dtItemList = new DataTable();
        DataTable dtTableFilter = new DataTable();
        DataTable dtvendorList = new DataTable();
        DataTable dttaxreturn = new DataTable();
        DataTable dtPOReport = new DataTable();
        DataTable dtWIPProjectlist = new DataTable();
        DataTable dtItemType = new DataTable();
        DataTable dtItemColor = new DataTable();
        DataTable PONoDetails = new DataTable();
        DataTable dtPOPendinglist = new DataTable();
        DataTable dtPrintPODetails = new DataTable();
        DataTable dtPOFilter = new DataTable();
        DataTable dtItemAdd = new DataTable();
        DataTable dtCustomerlist = new DataTable();
        DataTable dtMasterList = new DataTable();
        DataView dvItemList = new DataView();
        DataTable dtBOMProjectList = new DataTable();
        DataTable dtPaymentTerms = new DataTable();
        DataTable dtDeliveryTerms = new DataTable();
        DataTable dtGstCode = new DataTable();
        DataTable currencyData= new DataTable();
        DataTable POdetailsHistory = new DataTable();
        SqlConnection SQLCon;

        List<string> lstBOMProjects = new List<string>();

        string sDBOMID;
        string sDBOMNo;
        string PONo = string.Empty;
        string sDot = ".";
        private static string sPONumber;
        double dBOMTotalQuantity = 0;
        double dOldBOMQty = 0;
        private double totalcost = 0.0;
        public int sPOform = 0;

        public string fnAdjustPurchaseOrder
        {
            get
            {
                return sPONumber;
            }
            set
            {
                sPONumber = value;
            }
        }
        private static string sProjectCode;
        public string fnProjectcode
        {
            get
            {
                return sProjectCode;
            }
            set
            {
                sProjectCode = value;
            }
        }

        public PurchaseOrder()
        {
            InitializeComponent();
            dtpdelivery.ValueChanged += new EventHandler(dtpdelivery_ValueChanged);
        }
        #endregion
        #region PO Item Color
        private void Datagridviewcolor()
        {
            int count = 0;
            foreach (DataGridViewRow dgr in dgbomlist.Rows)
            {
                dtItemColor = DAL.purchaseOrderRepeatColor(dgr.Cells["ItemCode"].Value.ToString()).Tables[0];
                if (dtItemColor.Rows.Count > 0)
                {
                    dgbomlist.Rows[count].Cells[0].Style.BackColor = Color.Yellow;
                    dgbomlist.Rows[count].Cells[1].Style.BackColor = Color.Yellow;
                }

                if (Convert.ToDouble(dgr.Cells[17].Value) > 0)
                {
                    dgbomlist.Rows[count].Cells[2].Style.BackColor = Color.Red;
                    dgbomlist.Rows[count].Cells[17].Style.BackColor = Color.Red;
                    dgbomlist.Rows[count].Cells[18].Style.BackColor = Color.Red;
                }
                else if (Convert.ToDouble(dgr.Cells[17].Value) < 0)
                {
                    dgbomlist.Rows[count].Cells[2].Style.BackColor = Color.LightGreen;
                    dgbomlist.Rows[count].Cells[17].Style.BackColor = Color.LightGreen;
                    dgbomlist.Rows[count].Cells[18].Style.BackColor = Color.LightGreen;
                }

                count++;
            }
        }
        #endregion

        #region PO Number Select Function
        private void fnPOSelectedindexChanged(string sPONUM)
        {
            txtAuthorizedBy.ResetText();
            txtRemarks.Enabled = true;
            totalcost = Convert.ToDouble("0.0");
            //  cmbProjectcode.Enabled = false;

            if (chkUpdatePO.Checked != true)
            {
                if (chkPrintPO.Checked != true)
                {
                    PONoDetails = DAL.purchaseOrderList2(sPONUM).Tables[0];

                    //shreeshail is added below code when After GM approval, the data should not be updated at the time of PO generation
                    
                    
                    if (PONoDetails.Rows.Count > 0)
                    {
                        /*
                        if (PONoDetails.Rows[0]["GMName"].ToString() == "--")
                        {
                            sq
                            for (int i = 13; i <= 27; i++)
                            {
                                if (i == 14 || i == 20 || i == 22 || i == 24 || i == 26)
                                {
                                    dgbomlist.Columns[i].Visible = true;
                                    dgbomlist.Columns[i].ReadOnly = false;
                                }
                                else
                                {
                                    dgbomlist.Columns[i].Visible = true;
                                    dgbomlist.Columns[i].ReadOnly = true;
                                   
                                }

                            }
                        }
                        
                         if(PONoDetails.Rows[0]["GMName"].ToString() == "Hebbarrk")
                        {
                           
                            for (int i = ; i <= 27; i++)
                            {
                                dgbomlist.Columns[i].Visible = true;
                                dgbomlist.Columns[i].ReadOnly = true;
                            }
                        }
                        */

                        if (PONoDetails.Rows[0]["GMName"].ToString() == "Hebbarrk")
                        {
                            llbViewPOGeneralTerms.Enabled = false;
                            dgbomlist.ReadOnly = true;
                        }
                        else
                        {
                            llbViewPOGeneralTerms.Enabled = true;
                            dgbomlist.ReadOnly = false;
                        }
                    }
                    //shreeshail is added above code
                    
                }
                else
                {
                    PONoDetails = DAL.purchaseOrderList3(1, sPONUM).Tables[0];
                }
            }
            else
            {
                PONoDetails = DAL.purchaseOrderList3(2, sPONUM).Tables[0];
            }
            if (PONoDetails.Rows.Count > 0)
            {
                if (login.GetUserDetails[2].ToLower() == "muthuramalingam" || login.GetUserDetails[2].ToLower() == "suresh kumar" || login.GetUserDetails[2].ToLower() == "lizzy" || login.GetUserDetails[2].ToLower() == "veena" || login.GetUserDetails[2].ToLower() == "pavana" || login.GetUserDetails[2].ToLower() == "hemanth reddy")
                {
                    

                }

                dtPOGeneralTerms = DAL.fnPOPendingList(3, "", "", sPONUM).Tables[0];
                if (dtPOGeneralTerms.Rows.Count > 0)
                {
                }
                else
                {
                    dtPOGeneralTerms = DAL.fnPOPendingList(3, "", "", "PO1").Tables[0];
                }

                if (dtPOGeneralTerms.Rows.Count > 0)
                {
                    dgvPOGeneralTerms.AutoGenerateColumns = false;
                    dgvPOGeneralTerms.DataSource = dtPOGeneralTerms;
                }
                cmbPONO.Text = sPONUM.ToString();
                lblPrepareBy.Text = PONoDetails.Rows[0]["PreparedBy"].ToString();
                //txtAuthorizedBy.Text = PONoDetails.Rows[0]["PMName"].ToString() + ", " + PONoDetails.Rows[0]["MHName"].ToString() + ", " + PONoDetails.Rows[0]["PurchaseCommitee"].ToString();
                  txtAuthorizedBy.Text = PONoDetails.Rows[0]["PMName"].ToString() + "," + PONoDetails.Rows[0]["PurchaseCommitee"].ToString() + ", " + PONoDetails.Rows[0]["OMName"].ToString();
                if (chkPrintPO.Checked != true)
                {
                    //  txtRemarks.Text = PONoDetails.Rows[0]["Remarks"].ToString();
                }
                else
                {
                    cmbEmailAlert.Items.Clear();
                    cmbEmailAlert.Text = "";
                    cmbEmailAlert.Items.Add(PONoDetails.Rows[0]["PurchaseCommitee"].ToString());
                    if (cmbEmailAlert.Items.Count > 0)
                    {
                        cmbEmailAlert.SelectedIndex = 0;
                    }
                    txtRemarks.ResetText();
                }

                if (chkUpdatePO.Checked == true)
                {
                    cmbEmailAlert.Items.Clear();
                    cmbEmailAlert.Text = "";
                    cmbEmailAlert.Items.Add(PONoDetails.Rows[0]["POUpdateRequestBy"].ToString());
                    if (cmbEmailAlert.Items.Count > 0)
                    {
                        cmbEmailAlert.SelectedIndex = 0;
                    }
                }

                cmbVendorName.SelectedItem = PONoDetails.Rows[0]["VendorName"].ToString();
                txtvendorcode.Text = PONoDetails.Rows[0]["VendorCode"].ToString();
                cmbProjectcode.Text = PONoDetails.Rows[0]["ProjectCode"].ToString();

                if (login.GetUserDetails[2].ToLower() == "muthuramalingam" || login.GetUserDetails[2].ToLower() == "suresh kumar" || login.GetUserDetails[23] == "Accounts" || login.GetUserDetails[2].ToLower() == "lizzy" || login.GetUserDetails[2].ToLower() == "veena" || login.GetUserDetails[2].ToLower() == "pavana" || login.GetUserDetails[2].ToLower() == "hemanth reddy")
                {
                    if (!string.IsNullOrEmpty(PONoDetails.Rows[0]["POGeneratedDate"].ToString()))
                    {
                        dtppreparedate.Value = Convert.ToDateTime(PONoDetails.Rows[0]["POGeneratedDate"]);
                    }
                }
                if (!string.IsNullOrEmpty(PONoDetails.Rows[0]["PODeliveryDate"].ToString()))
                {
                    dtpdelivery.Value = Convert.ToDateTime(PONoDetails.Rows[0]["PODeliveryDate"]);
                }


                if (string.IsNullOrEmpty(PONoDetails.Rows[0]["Currency"].ToString()))
                {
                    cmbcurrency.SelectedIndex = 0;
                }
                else
                {
                    cmbcurrency.SelectedItem = PONoDetails.Rows[0]["Currency"].ToString();
                }

                dgbomlist.AutoGenerateColumns = false;
                dgbomlist.DataSource = PONoDetails;

                DataTable dtPOApproveCheck = DAL.purchaseOrderApproveCheck(0, sPONUM).Tables[0];
                if (dtPOApproveCheck.Rows.Count > 0)
                {
                    // if (!string.IsNullOrEmpty(dtPOApproveCheck.Rows[0]["POGeneratedBy"].ToString()) && chkUpdatePO.Checked == false)
                    {
                        //dgbomlist.Columns["Unitprice"].ReadOnly = true;
                    }
                }

                //if (chkUpdatePO.Checked == false)
                //{
                //    dgbomlist.Columns["Unitprice"].ReadOnly = true;
                //}

                foreach (DataRow DR in PONoDetails.Rows)
                {
                    DataTable dtItemTypeCheck = DAL.fnItemTypeCheck(0, DR["ItemCode"].ToString()).Tables[0];
                    if (dtItemTypeCheck.Rows[0]["Type"].ToString() == "Consumable" || dtItemTypeCheck.Rows[0]["Type"].ToString() == "Maintenance" || dtItemTypeCheck.Rows[0]["Type"].ToString() == "KanBan")
                    {
                        dgbomlist.Columns["Unitprice"].ReadOnly = false;
                        break;
                    }
                }



                Datagridviewcolor();
                fnTotalPOCost();

                dtGstCode = DAL.fngetvendorgstcode(txtvendorcode.Text.Trim()).Tables[0];
                if (dtGstCode.Rows.Count > 0)
                {

                        if (dtGstCode.Rows[0]["StateCode"].ToString() == "29")
                        {
                            dgbomlist.Columns["IGSTRate"].ReadOnly = true;
                            dgbomlist.Columns["SGSTRate"].ReadOnly = false;
                            dgbomlist.Columns["CGSTRate"].ReadOnly = false;
                        }
                        else
                        {
                            dgbomlist.Columns["IGSTRate"].ReadOnly = false;
                            dgbomlist.Columns["SGSTRate"].ReadOnly = true;
                            dgbomlist.Columns["CGSTRate"].ReadOnly = true;
                        }
                    
                   
                }




               

               // case "IGSTRate":
              //                  dgbomlist.CurrentRow.Cells["IGSTAmount"].Value = ((Convert.ToDouble(dgbomlist.CurrentRow.Cells["Amount"].Value) - Convert.ToDouble(dgbomlist.CurrentRow.Cells["DiscAmount"].Value)) / 100) * Convert.ToDouble(dgbomlist.CurrentRow.Cells["IGSTRate"].Value);
               // break;

                //            case "SGSTRate":
                //                dgbomlist.CurrentRow.Cells["SGSTAmount"].Value = ((Convert.ToDouble(dgbomlist.CurrentRow.Cells["Amount"].Value) - Convert.ToDouble(dgbomlist.CurrentRow.Cells["DiscAmount"].Value)) / 100) * Convert.ToDouble(dgbomlist.CurrentRow.Cells["SGSTRate"].Value);
               // break;
                  //          case "CGSTRate":
                  //              dgbomlist.CurrentRow.Cells["CGSTAmount"].Value = ((Convert.ToDouble(dgbomlist.CurrentRow.Cells["Amount"].Value) - Convert.ToDouble(dgbomlist.CurrentRow.Cells["DiscAmount"].Value)) / 100) * Convert.ToDouble(dgbomlist.CurrentRow.Cells["CGSTRate"].Value);
                //break;


                if (!string.IsNullOrEmpty(PONoDetails.Rows[0]["WithoutBOM"].ToString()))
                {
                    if (PONoDetails.Rows[0]["WithoutBOM"].ToString() == "True")
                    {
                        chkWithoutBOM.Checked = true;
                        chkWithoutBOM.Enabled = false;
                    }
                    else
                    {
                        chkWithoutBOM.Checked = false;
                        chkWithoutBOM.Enabled = false;
                    }
                }
                else
                {
                    chkWithoutBOM.Checked = false;
                    chkWithoutBOM.Enabled = false;
                }

                foreach (DataGridViewRow DR in dgbomlist.Rows)
                {
                    if (chkWithoutBOM.CheckState == CheckState.Checked)
                    {
                        if (DR.Cells["dBOMQty"].Value != DBNull.Value)
                        {
                            DR.Cells["ReqQty"].ReadOnly = false;
                            DR.Cells["ReqQty"].Style.BackColor = Color.LightGreen;
                        }
                    }
                    else
                    {
                        if (DR.Cells["dBOMQty"].Value != DBNull.Value)
                        {
                            //  if (Convert.ToDouble(DR.Cells["dBOMQty"].Value) > 0)
                            //  {
                            DR.Cells["ReqQty"].ReadOnly = true;
                            DR.Cells["ReqQty"].Style.BackColor = Color.White;
                            //  }
                        }
                        
                    }
                }

                if (chkPrintPO.CheckState == CheckState.Checked)
                {
                    pnPOReport.Enabled = false;
                }
                else
                {
                    pnPOReport.Enabled = true;
                }
            }
            else
            {
                pnPOReport.Enabled = false;
            }
            //     dttaxreturn = DAL.TaxRetturn(sPONUM).Tables[0];

            dtPOReport = DAL.POReport(sPONUM).Tables[0];
            dtGetPOGSTDetails = DAL.fnPOReportGST(cmbPONO.Text).Tables[0];
            DataTable fnGetVedorDetailsList = DAL.fnGetVedorDetails(txtvendorcode.Text).Tables[0];


            if (fnGetVedorDetailsList.Rows.Count > 0 && dtGetPOGSTDetails.Rows.Count > 0)
            {
                
                if (fnGetVedorDetailsList.Rows[0]["TransactionType"].ToString() != dtGetPOGSTDetails.Rows[0]["TransactionType"].ToString())
                {
                   // MessageBox.Show(dtGetPOGSTDetails.Rows[0]["TransactionType"].ToString(), cmbPONO.Text+ txtvendorcode.Text);

                    cmbtransactiontype.SelectedItem = dtGetPOGSTDetails.Rows[0]["TransactionType"].ToString();

                }

                if (dtGetPOGSTDetails.Rows[0]["NatureofTransaction"].ToString() != fnGetVedorDetailsList.Rows[0]["NatureTransaction"].ToString())
                {
                    cmbNatureofTransaction.SelectedItem = dtGetPOGSTDetails.Rows[0]["NatureofTransaction"].ToString();
                }

                if (dtGetPOGSTDetails.Rows[0]["NatureofSupply"].ToString() != fnGetVedorDetailsList.Rows[0]["NatureSupply"].ToString())
                {
                    cmbNatureofSupply.SelectedItem = dtGetPOGSTDetails.Rows[0]["NatureofSupply"].ToString();
                }

                if (dtGetPOGSTDetails.Rows[0]["Incoterm"].ToString() != fnGetVedorDetailsList.Rows[0]["Incoterms"].ToString())
                {
                    cmbIncoterm.SelectedItem = dtGetPOGSTDetails.Rows[0]["Incoterm"].ToString();
                }

                if (dtGetPOGSTDetails.Rows[0]["Incodetails"].ToString() != fnGetVedorDetailsList.Rows[0]["Blank"].ToString())
                {
                    txtIncoterm.Text = dtGetPOGSTDetails.Rows[0]["Incodetails"].ToString();
                }

                if (fnGetVedorDetailsList.Rows[0]["PaymentTerms"].ToString() != dtGetPOGSTDetails.Rows[0]["PaymentTerm"].ToString())
                {
                    cmbPaymentTerms.SelectedItem = dtGetPOGSTDetails.Rows[0]["PaymentTerm"].ToString();
                }

                if (dtGetPOGSTDetails.Rows[0]["DeliveryTerm"].ToString() != fnGetVedorDetailsList.Rows[0]["DeliveryTerms"].ToString())
                {
                    cmbDeliverTerms.SelectedItem = dtGetPOGSTDetails.Rows[0]["DeliveryTerm"].ToString();
                }
            }
            else if ((dtGetPOGSTDetails.Rows.Count > 0))
            {
                cmbtransactiontype.SelectedItem = dtGetPOGSTDetails.Rows[0]["TransactionType"].ToString();
                cmbNatureofTransaction.SelectedItem = dtGetPOGSTDetails.Rows[0]["NatureofTransaction"].ToString();
                cmbNatureofSupply.SelectedItem = dtGetPOGSTDetails.Rows[0]["NatureofSupply"].ToString();
                cmbIncoterm.SelectedItem = dtGetPOGSTDetails.Rows[0]["Incoterm"].ToString();
                txtIncoterm.Text = dtGetPOGSTDetails.Rows[0]["Incodetails"].ToString();
                cmbPaymentTerms.SelectedItem = dtGetPOGSTDetails.Rows[0]["PaymentTerm"].ToString();
               // cmbDeliverTerms.SelectedItem = dtGetPOGSTDetails.Rows[0]["DeliveryTerm"].ToString();
            }

            if (dtGetPOGSTDetails.Rows.Count > 0 )
            {
                
                txtShippedFrom.Text = dtGetPOGSTDetails.Rows[0]["ShippedFrom"].ToString();
                txtShippedFrom1.Text = dtGetPOGSTDetails.Rows[0]["ShippedFrom1"].ToString();
                txtShippedStateCode.Text = dtGetPOGSTDetails.Rows[0]["ShippedStateCode"].ToString();
                txtShippedGSTIn.Text = dtGetPOGSTDetails.Rows[0]["ShippedGSTIN"].ToString();
                txtInvoiceTotal.Text = dtGetPOGSTDetails.Rows[0]["InvoiceTotal"].ToString();
                txtAmountPaid.Text = dtGetPOGSTDetails.Rows[0]["AmountPaid"].ToString();
                txtBalanceDue.Text = dtGetPOGSTDetails.Rows[0]["BalanceDue"].ToString();
                txtShippedCountry.Text = dtGetPOGSTDetails.Rows[0]["ShippedCountry"].ToString();
                
            }

            if (cmbPaymentTerms.SelectedIndex == -1)
            {
                DataTable dtPaymenterm = new DataTable();
                dtPaymenterm = DAL.fnVedorList(txtvendorcode.Text).Tables[0];
                if (dtPaymenterm.Rows.Count > 0)
                {
                    cmbPaymentTerms.SelectedItem = dtPaymenterm.Rows[0]["PaymentTerm"].ToString();
                }
            }

        }
        #endregion

        DataTable dtPOApproverList = new DataTable();
        DataTable dtPOGeneralTerms = new DataTable();
        DataTable dtIncoterms = new DataTable();
        DataTable dtPOTerms = new DataTable();
        DataTable CurrencyCode = new DataTable();
        #region Purchase Order Form Load Function
        private void PurchaseOrder_Load(object sender, EventArgs e)
        {

            string loggedInUser = login.GetUserDetails[2];

           // string message = string.Join(Environment.NewLine,
           //      login.GetUserDetails.Select((val, i) => $"{i}: {val}")
           //  );

           // Form form = new Form();
           // //form.Text = "User Details";
           // form.Width = 600;
           // form.Height = 400;

            //TextBox textBox = new TextBox();
           // textBox.Multiline = true;
          //  textBox.ScrollBars = ScrollBars.Vertical;
           // textBox.ReadOnly = true;
            //textBox.Dock = DockStyle.Fill;
           // textBox.Text = message;

            //form.Controls.Add(textBox);
            //form.ShowDialog();



            // Only show the button if the user is Veena
            if (loggedInUser == "Veena" || loggedInUser.ToLower() == "pavana" || loggedInUser.ToLower() == "hemanth reddy")
            {
                btnClosePO.Visible = true;
                btnCancelPO.Visible = true;
                btnSendReminder.Visible = true;
            }
            else
            {
                btnClosePO.Visible = false;
                btnCancelPO.Visible = false;
                btnSendReminder.Visible = false;
            }
            CurrencyCode = DAL.Currency_Code(0).Tables[0];
            cmbcurrency.Items.Clear();

            if (CurrencyCode.Rows.Count > 0)
            {
                foreach (DataRow DR in CurrencyCode.Rows)
                {
                    if (!cmbcurrency.Items.Contains(DR[0].ToString()))
                        cmbcurrency.Items.Add(DR[0].ToString());
                }
            }

            try
            {
                cmbcurrency.SelectedIndex = 20;
                curratetext.Text = "1";
                chkItemCode.Checked = true;
                dtPaymentTerms = DAL.fnPaymentTermMasterList(null).Tables[0];

                foreach (DataRow dr in dtPaymentTerms.Rows)
                {
                    if (!cmbPaymentTerms.Items.Contains(dr["PaymentTerms"].ToString()))
                    {
                        cmbPaymentTerms.Items.Add(dr["PaymentTerms"].ToString());
                    }
                }

                dtIncoterms = DAL.fnPOIncoTerms(0, "").Tables[0];
                foreach (DataRow dr in dtIncoterms.Rows)
                {
                    if (!cmbIncoterm.Items.Contains(dr[0].ToString()))
                    {
                        cmbIncoterm.Items.Add(dr[0].ToString());
                    }
                }

                dtPOTerms = DAL.fnPOPendingList(4, "", "", "").Tables[0];
                if (dtPOTerms.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtPOTerms.Rows)
                    {
                        if (!cmbPOTerms.Items.Contains(dr[0].ToString()))
                        {
                            cmbPOTerms.Items.Add(dr[0].ToString());
                        }

                    }
                  
                        cmbPOTerms.SelectedIndex = 3;

                    
                }
               

                dtPOApproverList = DAL.fnActiveUserList(2, login.GetUserDetails[2]).Tables[0];
                if (dtPOApproverList.Rows.Count > 0)
                {
                    foreach (DataRow DR in dtPOApproverList.Rows)
                    {
                        if (!cmbEmailAlert.Items.Contains(DR["POApprover"].ToString()))
                            cmbEmailAlert.Items.Add(DR["POApprover"].ToString());
                    }
                    cmbEmailAlert.SelectedIndex = 0;
                }
                else
                {
                    DataTable dtUserName = DAL.fnActiveUserList(0, null).Tables[0];

                    foreach (DataRow DR in dtUserName.Rows)
                    {
                        if (!cmbEmailAlert.Items.Contains(DR["UserName"].ToString()))
                            cmbEmailAlert.Items.Add(DR["UserName"].ToString());
                    }
                }
                dtDeliveryTerms = DAL.fnDeliveryTermMasterList(null).Tables[0];

                foreach (DataRow dr in dtDeliveryTerms.Rows)
                {
                    if (!cmbDeliverTerms.Items.Contains(dr["DeliveryTerms"].ToString()))
                    {
                        cmbDeliverTerms.Items.Add(dr["DeliveryTerms"].ToString());
                    }
                }
                
                for (int i = 13; i <= 27; i++)
                {
                    dgbomlist.Columns[i].Visible = false;
                }
                
                if (login.GetUserDetails[23] == "Testlab")
                {
                    dgbomlist.Columns[13].Visible = true;
                    dgbomlist.Columns[14].Visible = true;
                    dgbomlist.Columns[15].Visible = true;
                    dgbomlist.Columns[16].Visible = true;
                    dgbomlist.Columns[17].Visible = true;
                    dgbomlist.Columns[18].Visible = true;
                    dgbomlist.Columns[19].Visible = true;
                }
                if (login.GetUserDetails[23] == "Electricals" || login.GetUserDetails[23] == "Hydraulics" || login.GetUserDetails[23] == "Mechanical")
                {
                    chkWithoutBOM.Visible = false;
                }
                else
                {
                    chkWithoutBOM.Visible = true;
                }

                lblTotalAmount.Visible = false;
                dtppreparedate.Format = DateTimePickerFormat.Custom;
                dtppreparedate.CustomFormat = "dd-MM-yyyy";
                dtpdelivery.Format = DateTimePickerFormat.Custom;
                dtpdelivery.CustomFormat = "dd-MM-yyyy";
                dgbomlist.Columns[1].Width = 680;
                lblPrepareBy.Text = login.GetUserDetails[2];
                if (Convert.ToBoolean(login.GetUserDetails[30]) == true || Convert.ToBoolean(login.GetUserDetails[29]) == true || Convert.ToBoolean(login.GetUserDetails[82]) == true || Convert.ToBoolean(login.GetUserDetails[31]) == true || Convert.ToBoolean(login.GetUserDetails[32]) == true || Convert.ToBoolean(login.GetUserDetails[80]) == true || Convert.ToBoolean(login.GetUserDetails[16]) == true || login.GetUserDetails[2].ToLower() == "lizzy" || login.GetUserDetails[2].ToLower() == "veena" || login.GetUserDetails[2].ToLower() == "pavana" || login.GetUserDetails[2].ToLower() == "hemanth reddy" || login.GetUserDetails[2].ToLower() == "vivek g")    //  lblPrepareBy.Text.ToLower() == "hebbarrk")
                {
                    lblTotalAmount.Visible = true;
                    pnauthorise.Visible = true;
                    btnLoadPCList.Visible = true;
                    btnLoadPCList_Click(sender, e);
                }

                if (login.GetUserDetails[2].ToLower() == "muthuramalingam" || login.GetUserDetails[2].ToLower() == "suresh kumar" || login.GetUserDetails[2].ToLower() == "lizzy" || login.GetUserDetails[2].ToLower() == "veena" || login.GetUserDetails[2].ToLower() == "pavana" ||  login.GetUserDetails[2].ToLower() == "hemanth reddy" || Convert.ToBoolean(login.GetUserDetails[16]) == true)
                {
                    chkUpdatePO.Visible = true;
                    POExpirationDate.Visible = true;
                    PurchaseOrdervaliduptoDate.Visible = true;
                    AmeandPO.Visible = true;


                }
                else
                {
                    chkUpdatePO.Visible = false;
                    AmeandPO.Visible = false;
                }

                dtvendorList = DAL.fnVedorNameList(0, null).Tables[0];
                foreach (DataRow dr in dtvendorList.Rows)
                {
                    if (!cmbVendorName.Items.Contains(dr["VendorName"].ToString()))
                    {
                        cmbVendorName.Items.Add(dr["VendorName"].ToString());
                    }
                }

                dtWIPProjectlist = DAL.fnWIPProjectList(null).Tables[0];


                if (Convert.ToBoolean(login.GetUserDetails[16]) == true || login.GetUserDetails[2].ToLower() == "lizzy" || login.GetUserDetails[2].ToLower() == "veena" || login.GetUserDetails[2].ToLower() == "pavana" || login.GetUserDetails[2].ToLower() == "hemanth reddy")//shreeshail is added or condition lizzy
                {

                    if (Convert.ToBoolean(login.GetUserDetails[30]) != true)
                    {
                        if (Convert.ToBoolean(login.GetUserDetails[80]) != true)
                        {
                            //btnloadpolist_Click(sender, e);
                        }
                        btnLoadPCList.Visible = true;
                        btnLoadPCList_Click(sender, e);
                        btnGenaratePO.Enabled = true;
                       

                    }
                    else
                    {
                        btnLoadPCList_Click(sender, e);
                        cmbPONO.DroppedDown = true;
                    }
                                      
                    
                    for (int i = 13; i <= 27; i++)
                    {
                        dgbomlist.Columns[i].Visible = true;
                    }
                    
                    
                    lblTotalAmount.Visible = true;
                    pnauthorise.Visible = true;

                    pnloadpo.Visible = true;
                   //rk pnitemadd.Enabled = false;
                    btnviewpolist.Enabled = true;

                    if (login.GetUserDetails[2] == "Hebbarrk" || login.GetUserDetails[23] == "Accounts")
                    {
                        pnloadpo.Visible = true;
                        btnGenaratePO.Enabled = false;
                    }
                }

                if (!string.IsNullOrEmpty(fnAdjustPurchaseOrder))
                {
                    fnPOSelectedindexChanged(sPONumber);
                    cmbPONO.Text = Convert.ToString(sPONumber);
                   //rk pnitemadd.Enabled = false;
                    cmbPONO.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("PurchaseOrder_PurchaseOrder_Load " + ex.Message);
            }
        }
        #endregion
        #region Item Select Function
        private void chklbItemList_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (Convert.ToBoolean(login.GetUserDetails[16]) != true)
            {
                btnSave.Enabled = true;
                cmbProjectcode.Enabled = true;
            }
            else
            {
                btnSave.Enabled = false;
                cmbProjectcode.Enabled = false;
            }

        }
        #endregion
        #region Select Item
        DataTable dtItemcode = new DataTable();
        string[] sItemCode;
        double TwelveMonthsIssue = 0;
        double SixMonthsIssue = 0;
        double dBOMTotalQty = 0;
        double LatestPurcPrice = 0;
        DataTable dt12Month = new DataTable();
        DataTable dt6Month = new DataTable();
        DataTable dtLatestPurchase = new DataTable();

        private void chklbItemList_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            if (!string.IsNullOrEmpty(cmbProjectcode.Text) && cmbVendorName.SelectedIndex >= 0)
            {
                try
                {
                    btncopmletepoview.Enabled = false;
                    btnviewpolist.Enabled = false;
                    btnrepeatorder.Enabled = false;
                    string[] sitemtype;
                    bool ctreate = true;
                    int i = 0;
                    sItemCode = chklbItemList.SelectedItem.ToString().Trim().Split(')');
                    string sID = sItemCode[0];
                    string item = sItemCode[1];
                    sitemtype = sItemCode[1].ToString().Trim().Split('-');
                    string project = cmbProjectcode.Text;
                    dtItemcode = DAL.fnStandardCostItemList(sID).Tables[0];
                    if (project != "613201177001" && project != "51423973035")
                    {
                        string[] authorsList = project.Split('-');
                        var protype = authorsList[0];
                        var protype1 = authorsList[3];
                        string itemtyp = sitemtype[0];
                        if (itemtyp != "FA" && protype == "CIP" && protype1 == "CAP")
                        {
                            ctreate = false;
                        }
                        if (itemtyp == "FA" && (protype != "CIP" || protype1 != "CAP"))
                        {
                            ctreate = false;
                        }
                        //if(itemtyp=="CON" && protype!="EXP")
                        //{
                        //    ctreate = false;
                        //}
                        //if (itemtyp != "CON" && protype == "EXP")
                        //{
                        //    ctreate = false;
                        //}
                    }
                    if (ctreate == true)
                    {

                        if (dtItemcode.Rows.Count > 0)
                        {
                            if (!chklbItemList.CheckedItems.Contains(chklbItemList.SelectedItem))
                            {
                                foreach (DataGridViewRow DGVR in dgbomlist.Rows)
                                {
                                    if (DGVR.Cells["ItemCode"].Value.ToString().Equals(dtItemcode.Rows[0]["ItemCode"].ToString()))
                                    {
                                        i = 1;
                                        break;
                                    }


                                }
                                if (i != 1)
                                {
                                    if (dtItemAdd.Rows.Count == 0)
                                    {
                                        dtItemAdd = DAL.fnStandardCostItemList(null).Tables[0];
                                    }
                                    TwelveMonthsIssue = 0;
                                    SixMonthsIssue = 0;
                                    dBOMTotalQty = 0;
                                    LatestPurcPrice = 0;
                                    var TwelveMonths = DateTime.Today.AddDays(-365);
                                    var SixMonths = DateTime.Today.AddDays(-182);
                                    var Today = DateTime.Today;
                                    dt12Month = DAL.fnItemUsage(TwelveMonths.ToString("yyyy-MM-dd"), SixMonths.ToString("yyyy-MM-dd"), Today.ToString("yyyy-MM-dd"), dtItemcode.Rows[0]["ItemCode"].ToString()).Tables[0];
                                    if (dt12Month.Rows.Count > 0)
                                    {
                                        if (!string.IsNullOrEmpty(dt12Month.Rows[0][3].ToString()))
                                        {
                                            SixMonthsIssue = Convert.ToDouble(dt12Month.Rows[0][3].ToString());
                                        }
                                        if (!string.IsNullOrEmpty(dt12Month.Rows[0][4].ToString()))
                                        {
                                            TwelveMonthsIssue = Convert.ToDouble(dt12Month.Rows[0][4].ToString());
                                        }

                                        if (dt12Month.Rows.Count > 1)
                                        {
                                            if (!string.IsNullOrEmpty(dt12Month.Rows[1][3].ToString()))
                                            {
                                                SixMonthsIssue += Convert.ToDouble(dt12Month.Rows[1][3].ToString());
                                            }
                                            if (!string.IsNullOrEmpty(dt12Month.Rows[1][4].ToString()))
                                            {
                                                TwelveMonthsIssue += Convert.ToDouble(dt12Month.Rows[1][4].ToString());
                                            }
                                        }
                                    }

                                    dtLatestPurchase = DAL.fnLatestPurchaseList(dtItemcode.Rows[0]["ItemCode"].ToString()).Tables[0];
                                    if (dtLatestPurchase.Rows.Count > 0)
                                    {
                                        LatestPurcPrice = Convert.ToDouble(dtLatestPurchase.Rows[0][1].ToString());
                                    }
                                    else
                                    {
                                        LatestPurcPrice = 0;
                                    }

                                    DataTable dtBOMUsage = new DataTable();
                                    dtBOMUsage = DAL.fnBOMItemPurchase(dtItemcode.Rows[0]["ItemCode"].ToString(), null).Tables[0];
                                    if (dtBOMUsage.Rows.Count > 0)
                                    {
                                        dBOMTotalQty = Convert.ToDouble(dtBOMUsage.Rows[0][1].ToString());
                                    }
                                    lstBOMProjects.Clear();
                                    if (dBOMTotalQty > 0)
                                    {
                                        dtItemAdd.Rows.Add(dtItemcode.Rows[0]["HSNSACCode"].ToString(), dtItemcode.Rows[0]["ItemCode"].ToString(), dtItemcode.Rows[0]["ItemDescription"].ToString(),
                                                           dtItemcode.Rows[0]["UnitCost"].ToString(), dtItemcode.Rows[0]["Units"].ToString(), Convert.ToDouble(dtItemcode.Rows[0]["AvailableQty"].ToString()),
                                                           SixMonthsIssue, TwelveMonthsIssue, 0, 0, 0, 0, 0, 0, 0, dBOMTotalQty, "", dtItemcode.Rows[0]["UnitCost"].ToString(), 0, 0, LatestPurcPrice);
                                    }
                                    else
                                    {
                                        dtItemAdd.Rows.Add(dtItemcode.Rows[0]["HSNSACCode"].ToString(), dtItemcode.Rows[0]["ItemCode"].ToString(), dtItemcode.Rows[0]["ItemDescription"].ToString(),
                                                       dtItemcode.Rows[0]["UnitCost"].ToString(), dtItemcode.Rows[0]["Units"].ToString(), Convert.ToDouble(dtItemcode.Rows[0]["AvailableQty"].ToString()),
                                                       SixMonthsIssue, TwelveMonthsIssue, dtItemcode.Rows[0]["ReqQty"].ToString(), 0, 0, 0, 0, 0, 0, dBOMTotalQty, "", dtItemcode.Rows[0]["UnitCost"].ToString(), 0, 0, LatestPurcPrice);
                                    }
                                    dgbomlist.AutoGenerateColumns = false;
                                    dgbomlist.DataSource = dtItemAdd;
                                    Datagridviewcolor();

                                    //if (dgbomlist.Rows.Count == 1)
                                    //{
                                    //    if (chkWithoutBOM.CheckState == CheckState.Checked)
                                    //    {
                                    //        dgbomlist.Columns["ReqQty"].ReadOnly = false;
                                    //        dgbomlist.Columns["ReqQty"].DefaultCellStyle.BackColor = Color.LightGreen;
                                    //    }
                                    //    else
                                    //    {
                                    //        dgbomlist.Columns["ReqQty"].ReadOnly = true;
                                    //        dgbomlist.Columns["ReqQty"].DefaultCellStyle.BackColor = Color.White;
                                    //    }
                                    //}

                                    foreach (DataGridViewRow DR in dgbomlist.Rows)
                                    {
                                        DR.Cells["RemQty"].Value = DR.Cells["ReqQty"].Value;
                                        DR.Cells["Amount"].Value = DR.Cells["Unitprice"].Value;
                                        if (chkWithoutBOM.CheckState == CheckState.Checked)
                                        {
                                            if (Convert.ToDouble(DR.Cells["dBOMQty"].Value) > 0 || Convert.ToDouble(DR.Cells["SixMonths"].Value) == 0)
                                            {
                                                DR.Cells["ReqQty"].ReadOnly = false;
                                                DR.Cells["ReqQty"].Style.BackColor = Color.LightGreen;
                                                //if (Convert.ToDouble(DR.Cells["SixMonths"].Value) == 0 && Convert.ToDouble(DR.Cells["dBOMQty"].Value) == 0)
                                                //{
                                                //    //  DR.Cells["RemQty"].Value = 0;
                                                //    // DR.Cells["ReqQty"].Value = 0;
                                                //}
                                            }
                                        }
                                        else
                                        {
                                            if (Convert.ToDouble(DR.Cells["dBOMQty"].Value) > 0 || Convert.ToDouble(DR.Cells["SixMonths"].Value) == 0)
                                            {
                                                DR.Cells["ReqQty"].ReadOnly = true;
                                                DR.Cells["ReqQty"].Style.BackColor = Color.White;
                                                if (Convert.ToDouble(DR.Cells["SixMonths"].Value) == 0 && Convert.ToDouble(DR.Cells["dBOMQty"].Value) == 0)
                                                {
                                                    DR.Cells["RemQty"].Value = 0;
                                                    DR.Cells["ReqQty"].Value = 0;
                                                }
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Selected Item already present in the list", "Error", 0, MessageBoxIcon.Error);
                                    chklbItemList.SetItemCheckState(chklbItemList.SelectedIndex, CheckState.Unchecked);
                                }
                            }
                            else
                            {
                                //int rowIndex = -1;
                                //bool bSelected;
                                //foreach (DataGridViewRow row in dgbomlist.Rows)
                                //{
                                //    bSelected = (row.Cells["ItemCode"].Value.ToString().Equals(dtItemcode.Rows[0]["ItemCode"].ToString()));
                                //    if (bSelected == true)
                                //    {
                                //        rowIndex = row.Index;
                                //        dgbomlist.Rows.Remove(dgbomlist.Rows[rowIndex]);
                                //        break;
                                //    }
                                //}
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please Check selected Item Code Type\n 1)Item created under Fixed Asset(FA-) is only for CAP projects code.\n 2) Item created under Consumable(CON-) is only for EXP projects code.", "Error", 0, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("PurchaseOrder_chklbItemList_ItemCheck" + ex.Message);
                }
            }
            else
            {
                if (string.IsNullOrEmpty(cmbProjectcode.Text))
                {
                    MessageBox.Show("Select project code to start purchase order", "Error", 0, MessageBoxIcon.Error);
                }

                else if (cmbVendorName.SelectedIndex < 0)
                {
                    MessageBox.Show("Select vendor name to start purchase order", "Error", 0, MessageBoxIcon.Error);
                    cmbVendorName.DroppedDown = true;
                }
            }
        }
        #endregion
        #region ItemCode Type Select
        private void cmbItemType_SelectedIndexChanged(object sender, EventArgs e)
        {
        }
        #endregion
        #region PO Item Selection
        private void txtItemCode_KeyUp(object sender, KeyEventArgs e)
        {
        }

        //private void txtItemDescription_KeyUp(object sender, KeyEventArgs e)
        //{
        //    if (e.KeyCode == Keys.Back)
        //    {
        //        if (chkItemCode.Checked == true)
        //        {
        //            dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);

        //            RowFilter();

        //        }
        //        else if (chkItemDesc.Checked == true)
        //        {
        //            dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
        //            RowFilter();
        //        }

        //    }
        //    else
        //    {
        //        if (chkItemCode.Checked == true)
        //        {
        //            dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);
        //            RowFilter();
        //        }
        //        else if (chkItemDesc.Checked == true)
        //        {
        //            dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
        //            RowFilter();
        //        }
        //    }
        //}
        private void txtItemDescription_KeyUp(object sender, KeyEventArgs e)
        {
            bool bomproject = Convert.ToBoolean(dtProjectBOMdetails.Rows[0]["BOMProject"].ToString());
            if (Convert.ToBoolean(dtProjectBOMdetails.Rows[0]["BOMProject"].ToString()) == true && dtProjectBOM.Rows.Count == 0)
            {
                bomproject = false;
            }

            if (e.KeyCode == Keys.Back)
            {
                if (chkItemCode.Checked == true)
                {
                    if (bomproject == false)
                    {
                        dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);
                        RowFilter();
                    }
                    else
                    {
                        if (txtItemDescription.Text.Length > 5)
                        {
                            dvItemList = GLobalClass.RowFilter(dtMachineBOMProduct, 0, txtItemDescription.Text);
                            RowFilter();
                        }
                        else if (txtItemDescription.Text.Length <= 5)
                        {
                            BOMRowFilter();
                        }
                    }
                }
                else if (chkItemDesc.Checked == true)
                {
                    if (bomproject == false)
                    {
                        dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
                        RowFilter();
                    }
                    else
                    {
                        if (txtItemDescription.Text.Length > 3)
                        {
                            dvItemList = GLobalClass.RowFilter(dtMachineBOMProduct, 1, txtItemDescription.Text);
                            RowFilter();
                        }
                        else if (txtItemDescription.Text.Length <= 3)
                        {
                            BOMRowFilter();
                        }
                    }
                }
            }
            else
            {
                if (chkItemCode.Checked == true)
                {
                    if (bomproject == false)
                    {
                        dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);
                        RowFilter();
                    }
                    else
                    {
                        if (txtItemDescription.Text.Length > 5)
                        {
                            dvItemList = GLobalClass.RowFilter(dtMachineBOMProduct, 0, txtItemDescription.Text);
                            RowFilter();
                        }
                        else if (txtItemDescription.Text.Length <= 5)
                        {
                            BOMRowFilter();
                        }
                    }
                }
                else if (chkItemDesc.Checked == true)
                {
                    if (bomproject == false)
                    {
                        dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
                        RowFilter();
                    }
                    else
                    {
                        if (txtItemDescription.Text.Length > 3)
                        {
                            dvItemList = GLobalClass.RowFilter(dtMachineBOMProduct, 1, txtItemDescription.Text);
                            RowFilter();
                        }
                        else if (txtItemDescription.Text.Length <= 3)
                        {
                            BOMRowFilter();
                        }
                    }
                }
            }
        }

        #endregion
        #region Rowfilter Funtion to select Item
        //private void RowFilter()
        //{
        //    chklbItemList.Items.Clear();
        //    foreach (DataRowView dv in dvItemList)
        //    {
        //        chklbItemList.Items.Add(string.Concat(dv[17].ToString(), ") ", dv[0].ToString(), ", ", dv[1].ToString(), ", ", dv[12].ToString()));
        //    }
        //}
        private void RowFilter()
        {
            bool bomproject = Convert.ToBoolean(dtProjectBOMdetails.Rows[0]["BOMProject"].ToString());
            if (Convert.ToBoolean(dtProjectBOMdetails.Rows[0]["BOMProject"].ToString()) == true && dtProjectBOM.Rows.Count == 0)
            {
                bomproject = false;
            }
            chklbItemList.Items.Clear();
            if (bomproject == false)
            {
                foreach (DataRowView dv in dvItemList)
                {
                    chklbItemList.Items.Add(string.Concat(dv[17].ToString(), ") ", dv[0].ToString(), ", ", dv[1].ToString(), ", ", dv[12].ToString()));
                }
            }
            else
            {
                foreach (DataRowView dv in dvItemList)
                {
                    chklbItemList.Items.Add(string.Concat(dv[8].ToString(), ") ", dv[0].ToString(), ", ", dv[1].ToString(), ", ", dv[6].ToString()));
                }
            }

        }
        private void BOMRowFilter()
        {
            chklbItemList.Items.Clear();
            foreach (DataRow dr in dtMachineBOMProduct.Rows)
            {
                chklbItemList.Items.Add(string.Concat(dr["ID"].ToString(), ") ", dr["ItemCode"].ToString(), ", ", dr["ItemDescription"].ToString(), ", ", dr["AvailableQty"].ToString()));
            }
        }
        #endregion
        #region Vendor Name Project Name Select
        string sProjectType = "";
        private void cmbProjectDescription_SelectedIndexChanged(object sender, EventArgs e)
        {

        }




        private void cmbVendorName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbVendorName.SelectedIndex >= 0)
            {
                DataView dvVendor = new DataView(dtvendorList);
                dvVendor.RowFilter = "VendorName Like'" + cmbVendorName.Text + "'";
                DataTable dtrow = dvVendor.ToTable();
                txtvendorcode.Text = dtrow.Rows[0]["VendorCode"].ToString();

                //MessageBox.Show(txtvendorcode.Text);

                //the code for auto update the vendor details

                DataTable fnGetVedorDetailsList = DAL.fnGetVedorDetails(txtvendorcode.Text).Tables[0];


                if (fnGetVedorDetailsList.Rows.Count > 0)
                {
                    cmbtransactiontype.SelectedItem = fnGetVedorDetailsList.Rows[0]["TransactionType"].ToString();//Done
                    cmbNatureofTransaction.SelectedItem = fnGetVedorDetailsList.Rows[0]["NatureTransaction"].ToString();//Done
                    cmbNatureofSupply.SelectedItem = fnGetVedorDetailsList.Rows[0]["NatureSupply"].ToString();//Done
                    cmbIncoterm.SelectedItem = fnGetVedorDetailsList.Rows[0]["Incoterms"].ToString();//Done
                    txtIncoterm.Text = fnGetVedorDetailsList.Rows[0]["Blank"].ToString();//Done
                    cmbPaymentTerms.SelectedItem = fnGetVedorDetailsList.Rows[0]["PaymentTerms"].ToString();//Done
                   // cmbDeliverTerms.SelectedItem = fnGetVedorDetailsList.Rows[0]["DeliveryTerms"].ToString();//Done
                   // MessageBox.Show(fnGetVedorDetailsList.Rows[0]["DeliveryTerms"].ToString(), "DeliveryTerms");

                    if (cmbPONO.Text != "" && cmbPONO.Text != null)
                    {
                       // MessageBox.Show(cmbPONO.Text);
                        try
                        {
                            int fnUpdatePurchaseOrderVendorDeatilsStatus = DAL.fnUpdatePurchaseOrderVendorDeatils("UPDATE", cmbPONO.Text, Convert.ToDouble(fnGetVedorDetailsList.Rows[0]["IGST"].ToString()), Convert.ToDouble(fnGetVedorDetailsList.Rows[0]["CGST"].ToString()), Convert.ToDouble(fnGetVedorDetailsList.Rows[0]["SGST"].ToString()));
                           // MessageBox.Show("updated-GST", fnUpdatePurchaseOrderVendorDeatilsStatus.ToString());
                        }
                        catch(Exception error) {
                            MessageBox.Show( error.Message,"this issue happing from update GST...!");
                        }
                       
                    }

                }
                else {
                    MessageBox.Show("Vendor not found in Vendor Details...!");
                }

               

              

                string sPONUM = cmbPONO.Text;
                //this code start
                txtAuthorizedBy.ResetText();
                txtRemarks.Enabled = true;
                totalcost = Convert.ToDouble("0.0");
                //  cmbProjectcode.Enabled = false;

                if (chkUpdatePO.Checked != true)
                {
                    if (chkPrintPO.Checked != true)
                    {
                        PONoDetails = DAL.purchaseOrderList2(sPONUM).Tables[0];

                        //shreeshail is added below code when After GM approval, the data should not be updated at the time of PO generation


                        if (PONoDetails.Rows.Count > 0)
                        {
                            /*
                            if (PONoDetails.Rows[0]["GMName"].ToString() == "--")
                            {
                                sq
                                for (int i = 13; i <= 27; i++)
                                {
                                    if (i == 14 || i == 20 || i == 22 || i == 24 || i == 26)
                                    {
                                        dgbomlist.Columns[i].Visible = true;
                                        dgbomlist.Columns[i].ReadOnly = false;
                                    }
                                    else
                                    {
                                        dgbomlist.Columns[i].Visible = true;
                                        dgbomlist.Columns[i].ReadOnly = true;

                                    }

                                }
                            }

                             if(PONoDetails.Rows[0]["GMName"].ToString() == "Hebbarrk")
                            {

                                for (int i = ; i <= 27; i++)
                                {
                                    dgbomlist.Columns[i].Visible = true;
                                    dgbomlist.Columns[i].ReadOnly = true;
                                }
                            }
                            */

                            if (PONoDetails.Rows[0]["GMName"].ToString() == "Hebbarrk")
                            {
                                llbViewPOGeneralTerms.Enabled = false;
                                dgbomlist.ReadOnly = true;
                            }
                            else
                            {
                                llbViewPOGeneralTerms.Enabled = true;
                                dgbomlist.ReadOnly = false;
                            }
                        }
                        //shreeshail is added above code

                    }
                    else
                    {
                        PONoDetails = DAL.purchaseOrderList3(1, sPONUM).Tables[0];
                    }
                }
                else
                {
                    PONoDetails = DAL.purchaseOrderList3(2, sPONUM).Tables[0];
                }
                if (PONoDetails.Rows.Count > 0)
                {
                    if (login.GetUserDetails[2].ToLower() == "muthuramalingam" || login.GetUserDetails[2].ToLower() == "suresh kumar" || login.GetUserDetails[2].ToLower() == "lizzy" || login.GetUserDetails[2].ToLower() == "veena" || login.GetUserDetails[2].ToLower() == "pavana" || login.GetUserDetails[2].ToLower() == "hemanth reddy")
                    {


                    }

                    dtPOGeneralTerms = DAL.fnPOPendingList(3, "", "", sPONUM).Tables[0];
                    if (dtPOGeneralTerms.Rows.Count > 0)
                    {
                    }
                    else
                    {
                        dtPOGeneralTerms = DAL.fnPOPendingList(3, "", "", "PO1").Tables[0];
                    }

                    if (dtPOGeneralTerms.Rows.Count > 0)
                    {
                        dgvPOGeneralTerms.AutoGenerateColumns = false;
                        dgvPOGeneralTerms.DataSource = dtPOGeneralTerms;
                    }
                    cmbPONO.Text = sPONUM.ToString();
                    lblPrepareBy.Text = PONoDetails.Rows[0]["PreparedBy"].ToString();
                    //txtAuthorizedBy.Text = PONoDetails.Rows[0]["PMName"].ToString() + ", " + PONoDetails.Rows[0]["MHName"].ToString() + ", " + PONoDetails.Rows[0]["PurchaseCommitee"].ToString();
                    txtAuthorizedBy.Text = PONoDetails.Rows[0]["PMName"].ToString() + "," + PONoDetails.Rows[0]["PurchaseCommitee"].ToString() + ", " + PONoDetails.Rows[0]["OMName"].ToString();
                    if (chkPrintPO.Checked != true)
                    {
                        //  txtRemarks.Text = PONoDetails.Rows[0]["Remarks"].ToString();
                    }
                    else
                    {
                        cmbEmailAlert.Items.Clear();
                        cmbEmailAlert.Text = "";
                        cmbEmailAlert.Items.Add(PONoDetails.Rows[0]["PurchaseCommitee"].ToString());
                        if (cmbEmailAlert.Items.Count > 0)
                        {
                            cmbEmailAlert.SelectedIndex = 0;
                        }
                        txtRemarks.ResetText();
                    }

                    if (chkUpdatePO.Checked == true)
                    {
                        cmbEmailAlert.Items.Clear();
                        cmbEmailAlert.Text = "";
                        cmbEmailAlert.Items.Add(PONoDetails.Rows[0]["POUpdateRequestBy"].ToString());
                        if (cmbEmailAlert.Items.Count > 0)
                        {
                            cmbEmailAlert.SelectedIndex = 0;
                        }
                    }

                    //cmbVendorName.SelectedItem = PONoDetails.Rows[0]["VendorName"].ToString();
                    //txtvendorcode.Text = PONoDetails.Rows[0]["VendorCode"].ToString();
                    cmbProjectcode.Text = PONoDetails.Rows[0]["ProjectCode"].ToString();

                    if (login.GetUserDetails[2].ToLower() == "muthuramalingam" || login.GetUserDetails[2].ToLower() == "suresh kumar" || login.GetUserDetails[23] == "Accounts" || login.GetUserDetails[2].ToLower() == "lizzy" || login.GetUserDetails[2].ToLower() == "veena" || login.GetUserDetails[2].ToLower() == "pavana" || login.GetUserDetails[2].ToLower() == "hemanth reddy")
                    {
                        if (!string.IsNullOrEmpty(PONoDetails.Rows[0]["POGeneratedDate"].ToString()))
                        {
                            dtppreparedate.Value = Convert.ToDateTime(PONoDetails.Rows[0]["POGeneratedDate"]);
                        }
                    }
                    if (!string.IsNullOrEmpty(PONoDetails.Rows[0]["PODeliveryDate"].ToString()))
                    {
                        dtpdelivery.Value = Convert.ToDateTime(PONoDetails.Rows[0]["PODeliveryDate"]);
                    }


                    if (string.IsNullOrEmpty(PONoDetails.Rows[0]["Currency"].ToString()))
                    {
                        cmbcurrency.SelectedIndex = 0;
                    }
                    else
                    {
                        cmbcurrency.SelectedItem = PONoDetails.Rows[0]["Currency"].ToString();
                    }

                    dgbomlist.AutoGenerateColumns = false;
                    dgbomlist.DataSource = PONoDetails;

                    DataTable dtPOApproveCheck = DAL.purchaseOrderApproveCheck(0, sPONUM).Tables[0];
                    if (dtPOApproveCheck.Rows.Count > 0)
                    {
                        // if (!string.IsNullOrEmpty(dtPOApproveCheck.Rows[0]["POGeneratedBy"].ToString()) && chkUpdatePO.Checked == false)
                        {
                            //dgbomlist.Columns["Unitprice"].ReadOnly = true;
                        }
                    }

                    //if (chkUpdatePO.Checked == false)
                    //{
                    //    dgbomlist.Columns["Unitprice"].ReadOnly = true;
                    //}

                    foreach (DataRow DR in PONoDetails.Rows)
                    {
                        DataTable dtItemTypeCheck = DAL.fnItemTypeCheck(0, DR["ItemCode"].ToString()).Tables[0];
                        if (dtItemTypeCheck.Rows[0]["Type"].ToString() == "Consumable" || dtItemTypeCheck.Rows[0]["Type"].ToString() == "Maintenance" || dtItemTypeCheck.Rows[0]["Type"].ToString() == "KanBan")
                        {
                            dgbomlist.Columns["Unitprice"].ReadOnly = false;
                            break;
                        }
                    }



                    Datagridviewcolor();
                    fnTotalPOCost();

                    dtGstCode = DAL.fngetvendorgstcode(txtvendorcode.Text.Trim()).Tables[0];
                    if (dtGstCode.Rows.Count > 0)
                    {

                        if (dtGstCode.Rows[0]["StateCode"].ToString() == "29")
                        {
                            dgbomlist.Columns["IGSTRate"].ReadOnly = true;
                            dgbomlist.Columns["SGSTRate"].ReadOnly = false;
                            dgbomlist.Columns["CGSTRate"].ReadOnly = false;
                        }
                        else
                        {
                            dgbomlist.Columns["IGSTRate"].ReadOnly = false;
                            dgbomlist.Columns["SGSTRate"].ReadOnly = true;
                            dgbomlist.Columns["CGSTRate"].ReadOnly = true;
                        }


                    }


                    foreach (DataGridViewRow DR in dgbomlist.Rows)
                    {
                        if (DR.Cells["IGSTRate"].Value != DBNull.Value && DR.Cells["IGSTRate"].Value != "0")
                        {
                            DR.Cells["IGSTAmount"].Value = ((Convert.ToDouble(DR.Cells["Amount"].Value) - Convert.ToDouble(DR.Cells["DiscAmount"].Value)) / 100) * Convert.ToDouble(DR.Cells["IGSTRate"].Value);
                        }

                        if (DR.Cells["SGSTRate"].Value != DBNull.Value && DR.Cells["SGSTRate"].Value != "0")
                        {
                            DR.Cells["SGSTAmount"].Value = ((Convert.ToDouble(DR.Cells["Amount"].Value) - Convert.ToDouble(DR.Cells["DiscAmount"].Value)) / 100) * Convert.ToDouble(DR.Cells["SGSTRate"].Value);
                        }

                        if (DR.Cells["CGSTRate"].Value != DBNull.Value && DR.Cells["IGSTRate"].Value != "0")
                        {
                            DR.Cells["CGSTAmount"].Value = ((Convert.ToDouble(DR.Cells["Amount"].Value) - Convert.ToDouble(DR.Cells["DiscAmount"].Value)) / 100) * Convert.ToDouble(DR.Cells["CGSTRate"].Value);
                        }

                    }





                    // case "IGSTRate":
                    //                  dgbomlist.CurrentRow.Cells["IGSTAmount"].Value = ((Convert.ToDouble(dgbomlist.CurrentRow.Cells["Amount"].Value) - Convert.ToDouble(dgbomlist.CurrentRow.Cells["DiscAmount"].Value)) / 100) * Convert.ToDouble(dgbomlist.CurrentRow.Cells["IGSTRate"].Value);
                    // break;

                    //            case "SGSTRate":
                    //                dgbomlist.CurrentRow.Cells["SGSTAmount"].Value = ((Convert.ToDouble(dgbomlist.CurrentRow.Cells["Amount"].Value) - Convert.ToDouble(dgbomlist.CurrentRow.Cells["DiscAmount"].Value)) / 100) * Convert.ToDouble(dgbomlist.CurrentRow.Cells["SGSTRate"].Value);
                    // break;
                    //          case "CGSTRate":
                    //              dgbomlist.CurrentRow.Cells["CGSTAmount"].Value = ((Convert.ToDouble(dgbomlist.CurrentRow.Cells["Amount"].Value) - Convert.ToDouble(dgbomlist.CurrentRow.Cells["DiscAmount"].Value)) / 100) * Convert.ToDouble(dgbomlist.CurrentRow.Cells["CGSTRate"].Value);
                    //break;


                    if (!string.IsNullOrEmpty(PONoDetails.Rows[0]["WithoutBOM"].ToString()))
                    {
                        if (PONoDetails.Rows[0]["WithoutBOM"].ToString() == "True")
                        {
                            chkWithoutBOM.Checked = true;
                            chkWithoutBOM.Enabled = false;
                        }
                        else
                        {
                            chkWithoutBOM.Checked = false;
                            chkWithoutBOM.Enabled = false;
                        }
                    }
                    else
                    {
                        chkWithoutBOM.Checked = false;
                        chkWithoutBOM.Enabled = false;
                    }

                    foreach (DataGridViewRow DR in dgbomlist.Rows)
                    {
                        if (chkWithoutBOM.CheckState == CheckState.Checked)
                        {
                            if (DR.Cells["dBOMQty"].Value != DBNull.Value)
                            {
                                DR.Cells["ReqQty"].ReadOnly = false;
                                DR.Cells["ReqQty"].Style.BackColor = Color.LightGreen;
                            }
                        }
                        else
                        {
                            if (DR.Cells["dBOMQty"].Value != DBNull.Value)
                            {
                                //  if (Convert.ToDouble(DR.Cells["dBOMQty"].Value) > 0)
                                //  {
                                DR.Cells["ReqQty"].ReadOnly = true;
                                DR.Cells["ReqQty"].Style.BackColor = Color.White;
                                //  }
                            }

                        }
                    }

                    if (chkPrintPO.CheckState == CheckState.Checked)
                    {
                        pnPOReport.Enabled = false;
                    }
                    else
                    {
                        pnPOReport.Enabled = true;
                    }
                }
                else
                {
                    pnPOReport.Enabled = false;
                }
                //     dttaxreturn = DAL.TaxRetturn(sPONUM).Tables[0];

                dtPOReport = DAL.POReport(sPONUM).Tables[0];
                dtGetPOGSTDetails = DAL.fnPOReportGST(cmbPONO.Text).Tables[0];
              


                

                if (cmbPaymentTerms.SelectedIndex == -1)
                {
                    DataTable dtPaymenterm = new DataTable();
                    dtPaymenterm = DAL.fnVedorList(txtvendorcode.Text).Tables[0];
                    if (dtPaymenterm.Rows.Count > 0)
                    {
                        cmbPaymentTerms.SelectedItem = dtPaymenterm.Rows[0]["PaymentTerm"].ToString();
                    }
                }
                //this code end






            }
                else
            {
                cmbVendorName.Text = "";
            }
        }

        #endregion
        CultureInfo india = new CultureInfo("hi-IN");
        CultureInfo USA = new CultureInfo("en-US");
        CultureInfo Europe = new CultureInfo("fr-FR");

        DataTable dtGetVendorDetails = new DataTable();
        DataTable dtGetPOGSTDetails = new DataTable();
        DataTable dtPackingForwarding = new DataTable();
        DataTable dtCurrencyPO = new DataTable();
        DataTable dtCurrencyPoSybal = new DataTable();
        DataTable dtApprovedby = new DataTable();
        string sApprovedby = "";
        string sGMAppr = "";
        string FileFul;
        #region New PO

        private void GSTPurchaseOrder()
        {
            try
            {
                sApprovedby = "";
                sGMAppr = "";
                dtPrintPODetails = DAL.purchaseOrderList2(cmbPONO.Text).Tables[0];
                dtGetVendorDetails = DAL.fnVedorList(dtPrintPODetails.Rows[0]["VendorCode"].ToString()).Tables[0];
                dtGetPOGSTDetails = DAL.fnPOReportGST(cmbPONO.Text).Tables[0];
                dtApprovedby = DAL.POWOCCList(3, cmbPONO.Text).Tables[0];
                if (dtApprovedby.Rows.Count > 0)
                {
                    sApprovedby = "Approved By : " + dtApprovedby.Rows[0][0].ToString();
                }


                // Step 1: Fetch conversion rate for selected currency to INR

                currencyData = DAL.Currency_IN_INR(0, cmbcurrency.Text).Tables[0];

                if (currencyData.Rows.Count > 0)
                {
                    // Convert the fetched rate to a double
                    double conversionRate = Convert.ToDouble(currencyData.Rows[0]["TO_INR"]);

                    // Step 2: Convert the total amount from label to double
                    double totalAmount = Convert.ToDouble(lblTotalAmount.Text);

                    // Step 3: Calculate the converted amount
                    double convertedAmount = totalAmount * conversionRate;

                    // Step 4: Check if the converted amount is less than 150000
                    if (convertedAmount > 50000)
                    {
                        sGMAppr = "GM Approval : " + Convert.ToString(dtPrintPODetails.Rows[0]["GMName"]);
                    }
                    
                }
                /*
                 if (cmbcurrency.SelectedIndex == 0)
                {
                    if (Convert.ToDouble(lblTotalAmount.Text) >= 150000)
                    {
                        sGMAppr = "GM Approval : " + Convert.ToString(dtPrintPODetails.Rows[0]["GMName"]);
                    }
                }

                else if (cmbcurrency.SelectedIndex == 1)
                {
                    if (Convert.ToDouble(lblTotalAmount.Text) >= 1709)
                    {
                        sGMAppr = "GM Approval : " + Convert.ToString(dtPrintPODetails.Rows[0]["GMName"]);
                    }
                }

                else if (cmbcurrency.SelectedIndex == 2)
                {
                    if (Convert.ToDouble(lblTotalAmount.Text) >= 1802)
                    {
                        sGMAppr = "GM Approval : " + Convert.ToString(dtPrintPODetails.Rows[0]["GMName"]);
                    }
                }

                else if (cmbcurrency.SelectedIndex == 3)
                {
                    if (Convert.ToDouble(lblTotalAmount.Text) >= 2464)
                    {
                        sGMAppr = "GM Approval : " + Convert.ToString(dtPrintPODetails.Rows[0]["GMName"]);
                    }
                }
                else if (cmbcurrency.SelectedIndex == 4)
                {
                    if (Convert.ToDouble(lblTotalAmount.Text) >= 1408.02)
                    {
                        sGMAppr = "GM Approval : " + Convert.ToString(dtPrintPODetails.Rows[0]["GMName"]);
                    }
                }
                 */

                int iRowIndex = 1;
                string ExcelFolderName;
                string ExcelFolderPath;
                string FileFullPath;

                EXCEL.Workbook NewWorkBook;
                EXCEL.Worksheet NewWorkSheet;
                EXCEL.Application ExcelApp;
                EXCEL.Range CELLS, cell1, cell2;
                {
                    object misValue;
                    ExcelFolderName = "\\Purchase Order";
                    ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + ExcelFolderName + "\\";
                    FileFullPath = ExcelFolderPath + cmbVendorName.Text + " " + (cmbPONO.Text).Replace("/", "_") + "_" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + ".xlsx";
                    FileFul = ExcelFolderPath + cmbVendorName.Text + " " + (cmbPONO.Text).Replace("/", "_") + "_" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + ".pdf";


                     dtPrintPODetails = DAL.purchaseOrderPrint(cmbPONO.Text).Tables[0];
                    string[] Text ={"","",
                                Global.sCompanyName,
                                "NO.497E, 14th Cross, 4th Phase, Peenya Industrial Area,",
                                "Bangalore-560 058, Karnataka,  India. ",
                                "Phone:91(080) 28360184. FAX: (080) 28360047.",
                               "PO No: "+cmbPONO.Text+"",
                                "PO Date: "+dtppreparedate.Text +"",
                                "PO Expiry Date: " + dtPrintPODetails.Rows[0]["POUptoDate"].ToString(),
                        ""
                               };
                    string[] Textn ={ "Transaction Type : "+dtGetPOGSTDetails.Rows[0]["TransactionType"].ToString() +"",
                                "Nature of Transaction : "+dtGetPOGSTDetails.Rows[0]["NatureofTransaction"].ToString() +"",
                                "Nature of Supply : "+dtGetPOGSTDetails.Rows[0]["NatureofSupply"].ToString() +""};

                    string[] Text2 = { "BILL TO", Global.sCompanyName,"NO.497E, 14th Cross, 4th Phase, Peenya Industrial Area,", "Bangalore-560 058, Karnataka.","","Country : India",
                                          "GSTIN : 29AAACI4550Q2Z1","CIN No: U32301HR1979PTC038643","SHIP TO", Global.sCompanyName,"NO.497E, 14th Cross, 4th Phase, Peenya Industrial Area,", "BANGALORE-560 058, Karnataka.","","Country : India",
                                          "", "GSTIN : 29AAACI4550Q2Z1"};

                    string[] Text22 = { "BILLED BY", ""+dtGetVendorDetails.Rows[0]["VendorName"].ToString() +"",""+dtGetVendorDetails.Rows[0]["Address1"].ToString() +"", ""+dtGetVendorDetails.Rows[0]["Address2"].ToString() +"",""+dtGetVendorDetails.Rows[0]["Address3"].ToString() +"","Country :  "+dtGetVendorDetails.Rows[0]["Country"].ToString() +""
                                          , "GSTIN : "+dtGetVendorDetails.Rows[0]["GSTCode"].ToString() +"","VendorCode : " + dtGetVendorDetails.Rows[0]["VendorCode"].ToString()+"","SHIPPED FROM", ""+dtGetVendorDetails.Rows[0]["VendorName"].ToString() +"",""+dtGetVendorDetails.Rows[0]["Address1"].ToString() +"",""+dtGetVendorDetails.Rows[0]["Address2"].ToString()+""
                                          ,""+dtGetVendorDetails.Rows[0]["Address3"].ToString() +"","Country : "+dtGetVendorDetails.Rows[0]["Country"].ToString() +"","Ph No : " + dtGetVendorDetails.Rows[0]["MobileNo"].ToString()+"",
                                          "", "GSTIN : "+dtGetVendorDetails.Rows[0]["GSTCode"].ToString() +""};

                    string sRemarks = "";
                    if (btnprintpo.Text == "Print PO")
                    {
                        sRemarks = txtRemarks.Text.Trim();
                    }
                    //"Payment Terms : "+dtGetPOGSTDetails.Rows[0]["PaymentTerm"].ToString()+"",
                    string[] Text9 ={
                                "Delivery Schedule : "+dtGetPOGSTDetails.Rows[0]["DeliveryTerm"].ToString() +" ("+dtpdelivery.Text +")","INCO Terms : "+cmbIncoterm.Text+""};

                    string[] Text89 ={Global.sCompanyName,
                                "NO.497E, 14th Cross, 4th Phase, Peenya Industrial Area,",
                                "Bangalore-560 058, Karnataka,  India. ",
                                "Phone:91(080) 28360184. FAX: (080) 28360047."};

                    string[] Text4 = { "Sub Total :", "Grand Total :" };

                    if (!Directory.Exists(ExcelFolderPath))
                        Directory.CreateDirectory(ExcelFolderPath);

                    ExcelApp = new EXCEL.Application();
                    misValue = System.Reflection.Missing.Value;
                    try
                    {
                        if (ExcelApp == null)
                            MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                        NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                        NewWorkSheet = NewWorkBook.Sheets.Add(misValue, misValue, 1, misValue);

                        if (NewWorkSheet == null)
                            MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                        else
                        {
                            NewWorkSheet.Name = "Purchase Order";
                        }
                        EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                        if (RANGE == null)
                            MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                        NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        CELLS = NewWorkSheet.Cells;
                        NewWorkSheet.PageSetup.PrintGridlines = false;

                        NewWorkSheet.Cells[iRowIndex, 1] = "Purchase Order";
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 10);
                        NewWorkSheet.Range["A1:B1"].Cells.Font.Size = 16;
                        NewWorkSheet.Range["A1:B1"].Cells.Font.Bold = 16;
                        iRowIndex++;
                        foreach (string str in Text)
                        {
                            NewWorkSheet.Cells[iRowIndex, 1] = str;
                            if (iRowIndex < 8)
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                            else
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);
                            iRowIndex++;
                        }
                        iRowIndex = iRowIndex - 3;
                        foreach (string str in Textn)
                        {
                            NewWorkSheet.Cells[iRowIndex, 6] = str;
                            iRowIndex++;
                        }

                        //if (cmbcurrency.SelectedIndex > 0)
                        //{
                        //    NewWorkSheet.Cells[27, 2] = "All prices are in " + cmbcurrency.Text +" only";
                        //}
                        //else
                        //{
                        //    NewWorkSheet.Cells[27, 2] = "All prices are in rupee only";
                        //}
                        //NewWorkSheet.Range["B27:B27"].Cells.Font.Size = 9;

                        NewWorkSheet.Cells[27, 7] = "Discount";
                        //  CellMerge("Merge", NewWorkSheet, 27, 27, 7, 8);
                        NewWorkSheet.Cells[27, 8] = "SGST";
                        //  CellMerge("Merge", NewWorkSheet, 27, 27, 9, 10);

                        NewWorkSheet.Cells[27, 9] = "CGST";
                        // CellMerge("Merge", NewWorkSheet, 27, 27, 11, 12);

                        NewWorkSheet.Cells[27, 10] = "IGST";
                        // CellMerge("Merge", NewWorkSheet, 27, 27, 13, 14);


                        iRowIndex = 11;

                        foreach (string str in Text22)
                        {
                            NewWorkSheet.Cells[iRowIndex, 1] = str;

                            if (str.Length > 48)
                            {
                                NewWorkSheet.Rows[iRowIndex].RowHeight = 36;
                                NewWorkSheet.Rows[iRowIndex].WrapText = true;
                            }

                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                            iRowIndex++;
                        }

                        iRowIndex = 11;

                        foreach (string str in Text2)
                        {
                            NewWorkSheet.Cells[iRowIndex, 6] = str;
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 6, 10);
                            iRowIndex++;
                        }

                        dtPrintPODetails = DAL.purchaseOrderPrint(cmbPONO.Text).Tables[0];
                        string finalColLetter = string.Empty;
                        int j = 28;
                        if (dtPrintPODetails.Rows.Count > 0)
                        {
                            object[,] rawData = new object[dtPrintPODetails.Rows.Count + 1, dtPrintPODetails.Columns.Count];
                            for (int col = 0; col < dtPrintPODetails.Columns.Count; col++)
                            {
                                rawData[0, col] = dtPrintPODetails.Columns[col].ColumnName;
                            }
                            for (int row = 0; row < dtPrintPODetails.Rows.Count; row++)
                            {
                                for (int col = 0; col < dtPrintPODetails.Columns.Count; col++)
                                {
                                    rawData[row + 1, col] = dtPrintPODetails.Rows[row].ItemArray[col];
                                }
                            }
                            string excelRange = string.Empty;
                            finalColLetter = string.Empty;
                            string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                            int colCharsetLen = colCharset.Length;

                            if (dtPrintPODetails.Columns.Count > colCharsetLen)
                            {
                                finalColLetter = colCharset.Substring((dtPrintPODetails.Columns.Count - 1) / colCharsetLen - 1, 1);
                            }
                            finalColLetter += colCharset.Substring((dtPrintPODetails.Columns.Count - 1) % colCharsetLen, 1);
                            excelRange = string.Format("A28:{0}{1}", finalColLetter, dtPrintPODetails.Rows.Count + j);
                            NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        }

                        NewWorkSheet.Cells[28, 7] = "Amt - Rate(%)";
                        NewWorkSheet.Cells[28, 8] = "Amt - Rate(%)";
                        NewWorkSheet.Cells[28, 9] = "Amt - Rate(%)";
                        NewWorkSheet.Cells[28, 10] = "Amt - Rate(%)";
                        //NewWorkSheet.Cells[28, 11] = "%";
                        //NewWorkSheet.Cells[28, 12] = "Amount";
                        //NewWorkSheet.Cells[28, 13] = "%";
                        //NewWorkSheet.Cells[28, 14] = "Amount";

                        CellMerge("AlignCenter", NewWorkSheet, 27, 28, 1, 10);

                        for (int i = 29; i < 29 + dtPrintPODetails.Rows.Count; i++)
                        {
                            NewWorkSheet.Rows[i].WrapText = true;
                        }


                        if (dtPrintPODetails.Rows.Count < 3)
                        {
                            NewWorkSheet.Rows[(28 + dtPrintPODetails.Rows.Count)].RowHeight = 300;
                        }
                        //else if (dtPrintPODetails.Rows.Count > 4)
                        //{
                        //    NewWorkSheet.Rows[(28 + dtPrintPODetails.Rows.Count)].RowHeight = 50;
                        //}


                        CellMerge("AlignTop", NewWorkSheet, 29, (29 + dtPrintPODetails.Rows.Count), 1, 10);

                        CellMerge("Merge", NewWorkSheet, 29 + dtPrintPODetails.Rows.Count, 29 + dtPrintPODetails.Rows.Count, 3, 5);

                        dtPackingForwarding = DAL.fnPOPackingForwardGST(cmbPONO.Text, "Packing & Forwarding").Tables[0];

                        double Packing = 0;
                        double PIGST = 0;
                        double PSGST = 0;
                        double PCGST = 0;
                        double freight = 0;
                        double TIGST = 0;
                        double TSGST = 0;
                        double TCGST = 0;

                        iRowIndex = 29 + dtPrintPODetails.Rows.Count;
                        if (dtPackingForwarding.Rows.Count > 0)
                        {
                            if (Convert.ToDouble(dtPackingForwarding.Rows[0]["Amount"].ToString()) > 0)
                            {
                                NewWorkSheet.Cells[iRowIndex, 3] = "Packing and Forwarding :";
                                CellMerge("AlignRight", NewWorkSheet, (iRowIndex), (iRowIndex), 3, 3);
                                CellMerge("Bold", NewWorkSheet, (iRowIndex), (iRowIndex), 3, 3);
                                NewWorkSheet.Cells[iRowIndex, 6] = dtPackingForwarding.Rows[0]["Amount"].ToString();
                                NewWorkSheet.Cells[iRowIndex, 7] = 0;
                                NewWorkSheet.Cells[iRowIndex, 8] = 0;
                                NewWorkSheet.Cells[iRowIndex, 9] = dtPackingForwarding.Rows[0]["SGSTRate"].ToString();
                                NewWorkSheet.Cells[iRowIndex, 10] = dtPackingForwarding.Rows[0]["SGSTAmount"].ToString();
                                NewWorkSheet.Cells[iRowIndex, 11] = dtPackingForwarding.Rows[0]["CGSTRate"].ToString();
                                NewWorkSheet.Cells[iRowIndex, 12] = dtPackingForwarding.Rows[0]["CGSTAmount"].ToString();
                                NewWorkSheet.Cells[iRowIndex, 13] = dtPackingForwarding.Rows[0]["IGSTRate"].ToString();
                                NewWorkSheet.Cells[iRowIndex, 14] = dtPackingForwarding.Rows[0]["IGSTAmount"].ToString();
                                Packing = Convert.ToDouble(dtPackingForwarding.Rows[0]["Amount"].ToString());
                                PIGST = Convert.ToDouble(dtPackingForwarding.Compute("Sum(IGSTAmount)", "").ToString());
                                PSGST = Convert.ToDouble(dtPackingForwarding.Compute("Sum(SGSTAmount)", "").ToString());
                                PCGST = Convert.ToDouble(dtPackingForwarding.Compute("Sum(CGSTAmount)", "").ToString());
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 5);
                                CellMerge("GridLines", NewWorkSheet, (iRowIndex), (iRowIndex), 3, 10);
                                iRowIndex++;
                            }
                        }

                        dtPackingForwarding = DAL.fnPOPackingForwardGST(cmbPONO.Text, "Transportation / Freight").Tables[0];
                        if (dtPackingForwarding.Rows.Count > 0)
                        {
                            if (Convert.ToDouble(dtPackingForwarding.Rows[0]["Amount"].ToString()) > 0)
                            {
                                NewWorkSheet.Cells[iRowIndex, 3] = "Transportation / Freight :";
                                CellMerge("AlignRight", NewWorkSheet, (iRowIndex), (iRowIndex), 3, 3);
                                CellMerge("Bold", NewWorkSheet, (iRowIndex), (iRowIndex), 3, 3);
                                NewWorkSheet.Cells[iRowIndex, 6] = dtPackingForwarding.Rows[0]["Amount"].ToString();
                                NewWorkSheet.Cells[iRowIndex, 7] = 0;
                                NewWorkSheet.Cells[iRowIndex, 8] = 0;
                                NewWorkSheet.Cells[iRowIndex, 9] = dtPackingForwarding.Rows[0]["SGSTRate"].ToString();
                                NewWorkSheet.Cells[iRowIndex, 10] = dtPackingForwarding.Rows[0]["SGSTAmount"].ToString();
                                NewWorkSheet.Cells[iRowIndex, 11] = dtPackingForwarding.Rows[0]["CGSTRate"].ToString();
                                NewWorkSheet.Cells[iRowIndex, 12] = dtPackingForwarding.Rows[0]["CGSTAmount"].ToString();
                                NewWorkSheet.Cells[iRowIndex, 13] = dtPackingForwarding.Rows[0]["IGSTRate"].ToString();
                                NewWorkSheet.Cells[iRowIndex, 14] = dtPackingForwarding.Rows[0]["IGSTAmount"].ToString();
                                freight = Convert.ToDouble(dtPackingForwarding.Rows[0]["Amount"].ToString());
                                TIGST = Convert.ToDouble(dtPackingForwarding.Compute("Sum(IGSTAmount)", "").ToString());
                                TSGST = Convert.ToDouble(dtPackingForwarding.Compute("Sum(SGSTAmount)", "").ToString());
                                TCGST = Convert.ToDouble(dtPackingForwarding.Compute("Sum(CGSTAmount)", "").ToString());
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 5);
                                CellMerge("GridLines", NewWorkSheet, (iRowIndex), (iRowIndex), 3, 10);
                                iRowIndex++;
                            }
                        }

                        CellMerge("GridLines", NewWorkSheet, 27, 27, 7, 10);

                        CellMerge("GridLines", NewWorkSheet, 28, (28 + dtPrintPODetails.Rows.Count), 1, 10);
                        CellMerge("AlignRight", NewWorkSheet, 28, (28 + dtPrintPODetails.Rows.Count), 3, 10);

                        foreach (string str in Text4)
                        {
                            NewWorkSheet.Cells[iRowIndex, 3] = str;
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 5);
                            CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex, 3, 5);
                            CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 3, 5);
                            CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 3, 10);
                            CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex, 5, 10);
                            CellMerge("GridLines", NewWorkSheet, iRowIndex, iRowIndex, 5, 10);
                            iRowIndex++;
                        }
                        iRowIndex--;
                        iRowIndex--;

                        string[] Text41 = { ""+(Convert.ToDouble(dtPrintPODetails.Compute("Sum(Amount)", "").ToString())+Packing+freight)+"",
                                               ""+(Convert.ToDouble(lbltotaldiscount.Text).ToString())+"",
                                             ""+(Convert.ToDouble(lbltotalSGST.Text)+PSGST+TSGST)+"",
                                             ""+(Convert.ToDouble(lbltotalCGST.Text)+PCGST+TCGST)+"",
                                             ""+(Convert.ToDouble(lbltotalIGST.Text)+PIGST+TIGST)+"" };



                        //iRowIndex = 31 + dtPrintPODetails.Rows.Count;
                        int Irow = 6;
                        foreach (string str in Text41)
                        {
                            //if (Irow == 6)
                            //{
                            NewWorkSheet.Cells[iRowIndex, Irow] = str;
                            //}
                            //else
                            //{
                            //    NewWorkSheet.Cells[iRowIndex, Irow - 1] = str;
                            //}
                            Irow++;
                            // Irow++;

                            // CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, Irow - 1, Irow);
                        }
                        /*
                        iRowIndex++;
                        //iRowIndex = 32 + dtPrintPODetails.Rows.Count;
                        Microsoft.Office.Interop.Excel.Range range2 = NewWorkSheet.get_Range("E28", "F" + (32 + dtPrintPODetails.Rows.Count) + "");
                        
                        dtCurrencyPO = DAL.fnCurrencyPO(cmbPONO.Text, cmbcurrency.Text).Tables[0];

                        if (dtCurrencyPO != null && dtCurrencyPO.Rows.Count > 0)
                        {
                            // Assuming dtCurrencyPO contains a column named "Currency" which holds the currency type
                            string currencyType = dtCurrencyPO.Rows[0]["Currency"].ToString();

                            // Fetch the currency symbol based on the currency type
                            DataTable dtCurrencyPoSybal = DAL.fnCurrencyPoSybal(currencyType).Tables[0];

                            // Assuming dtCurrencyPoSybal contains a column named "CurrencySymbol" which holds the currency symbol
                            string currencySymbol = dtCurrencyPoSybal.Rows[0]["CurrencySymbol"].ToString();
                            // Perform your calculations and formatting
                            double totalAmount = Convert.ToDouble(dtPrintPODetails.Compute("Sum(Amount)", "").ToString())
                                                 - Convert.ToDouble(lbltotaldiscount.Text)
                                                 + Convert.ToDouble(lbltotalSGST.Text)
                                                 + Convert.ToDouble(lbltotalCGST.Text)
                                                 + Convert.ToDouble(lbltotalIGST.Text)
                                                 + freight + Packing + PIGST + PSGST + PCGST + TIGST + TSGST + TCGST;

                            // Format the output string to include both the calculated value and currency formatting
                            //string formattedValue = string.Format("{0} {1:c}", currencyType, totalAmount);
                            
                            string formattedValue = string.Format(CultureInfo.InvariantCulture, "{0} {1:N2}", currencySymbol, totalAmount);
                            //string formattedValue = totalAmount.ToString("F2");

                            // Assuming iRowIndex is your row index for the output
                            NewWorkSheet.Cells[iRowIndex, 6] = formattedValue;
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 6, 10);
                            CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 6, 10);
                        }

                        */
                        
                      iRowIndex++;

                        Microsoft.Office.Interop.Excel.Range range2 = NewWorkSheet.get_Range("E28", "F" + (32 + dtPrintPODetails.Rows.Count) + "");

                        dtCurrencyPO = DAL.fnCurrencyPO(cmbPONO.Text, cmbcurrency.Text).Tables[0];

                        if (dtCurrencyPO != null && dtCurrencyPO.Rows.Count > 0)

                        {

                            string currencyType = dtCurrencyPO.Rows[0]["Currency"].ToString();

                            DataTable dtCurrencyPoSybal = DAL.fnCurrencyPoSybal(currencyType).Tables[0];

                            if (dtCurrencyPoSybal != null && dtCurrencyPoSybal.Rows.Count > 0 && dtCurrencyPoSybal.Columns.Contains("CurrencySymbol"))

                            {

                                string currencySymbol = dtCurrencyPoSybal.Rows[0]["CurrencySymbol"].ToString();

                                double totalAmount = Convert.ToDouble(dtPrintPODetails.Compute("Sum(Amount)", "").ToString())

                                                     - Convert.ToDouble(lbltotaldiscount.Text)

                                                     + Convert.ToDouble(lbltotalSGST.Text)

                                                     + Convert.ToDouble(lbltotalCGST.Text)

                                                     + Convert.ToDouble(lbltotalIGST.Text)

                                                     + freight + Packing + PIGST + PSGST + PCGST + TIGST + TSGST + TCGST;

                                string formattedValue = string.Format(CultureInfo.InvariantCulture, "{0} {1:N2}", currencySymbol, totalAmount);

                                NewWorkSheet.Cells[iRowIndex, 6].NumberFormat = "@"; // Ensure the cell is formatted as text

                                NewWorkSheet.Cells[iRowIndex, 6].Value = formattedValue;

                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 6, 10);

                                CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 6, 10);
                            }

                            else
                            {
                             MessageBox.Show("Currency symbol not found.");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Currency type not found.");
                        }


                        /*
                        else if (cmbcurrency.SelectedIndex == 13)
                        {
                            Europe.NumberFormat.CurrencyPositivePattern = 0;
                            Europe.NumberFormat.CurrencyNegativePattern = 2;
                            Europe.NumberFormat.CurrencyDecimalSeparator = CultureInfo.InvariantCulture.NumberFormat.CurrencyDecimalSeparator;
                            string[] Text142 = { ""+string.Format(Europe, "{0:c}",(Convert.ToDouble(dtPrintPODetails.Compute("Sum(Amount)", "").ToString())-Convert.ToDouble(lbltotaldiscount.Text)+ Convert.ToDouble(lbltotalSGST.Text)+Convert.ToDouble(lbltotalCGST.Text)+Convert.ToDouble(lbltotalIGST.Text)+
                                              freight+Packing+PIGST+PSGST+PCGST+TIGST+TSGST+TCGST))+""};

                            NewWorkSheet.Cells[iRowIndex, 6] = Text142;
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 6, 10);
                            CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 6, 10);
                        }
                        else if (cmbcurrency.SelectedIndex == 2)
                        {
                            string[] Text242 = { ""+string.Format(USA, "{0:c}",(Convert.ToDouble(dtPrintPODetails.Compute("Sum(Amount)", "").ToString())-Convert.ToDouble(lbltotaldiscount.Text)+ Convert.ToDouble(lbltotalSGST.Text)+Convert.ToDouble(lbltotalCGST.Text)+Convert.ToDouble(lbltotalIGST.Text)+
                                              freight+Packing+PIGST+PSGST+PCGST+TIGST+TSGST+TCGST))+""};
                            NewWorkSheet.Cells[iRowIndex, 6] = Text242;
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 6, 10);
                            CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 6, 10);
                        }
                        //shreeshail is added cad and GBP below
                        else if (cmbcurrency.SelectedIndex == 5)
                        {
                            string[] Text242 = { "" + string.Format(CultureInfo.CreateSpecificCulture("en-CA"), "{0:C}", (Convert.ToDouble(dtPrintPODetails.Compute("Sum(Amount)", "").ToString()) - Convert.ToDouble(lbltotaldiscount.Text) + Convert.ToDouble(lbltotalSGST.Text) + Convert.ToDouble(lbltotalCGST.Text) + Convert.ToDouble(lbltotalIGST.Text) +
                                          freight + Packing + PIGST + PSGST + PCGST + TIGST + TSGST + TCGST)) + "" };
                            NewWorkSheet.Cells[iRowIndex, 6] = Text242;
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 6, 10);
                            CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 6, 10);
                        }

                        else if (cmbcurrency.SelectedIndex == 14)
                        {
                            string[] Text242 = { "" + string.Format(CultureInfo.CreateSpecificCulture("en-GB"), "{0:C}", (Convert.ToDouble(dtPrintPODetails.Compute("Sum(Amount)", "").ToString()) - Convert.ToDouble(lbltotaldiscount.Text) + Convert.ToDouble(lbltotalSGST.Text) + Convert.ToDouble(lbltotalCGST.Text) + Convert.ToDouble(lbltotalIGST.Text) +
                                          freight + Packing + PIGST + PSGST + PCGST + TIGST + TSGST + TCGST)) + "" };
                            NewWorkSheet.Cells[iRowIndex, 6] = Text242;
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 6, 10);
                            CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 6, 10);
                        }
                        else if(cmbcurrency.SelectedIndex == 40)
                        {
                            string[] Text242 = { ""+string.Format(USA, "{0:c}",(Convert.ToDouble(dtPrintPODetails.Compute("Sum(Amount)", "").ToString())-Convert.ToDouble(lbltotaldiscount.Text)+ Convert.ToDouble(lbltotalSGST.Text)+Convert.ToDouble(lbltotalCGST.Text)+Convert.ToDouble(lbltotalIGST.Text)+
                                              freight+Packing+PIGST+PSGST+PCGST+TIGST+TSGST+TCGST))+""};
                            NewWorkSheet.Cells[iRowIndex, 6] = Text242;
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 6, 10);
                            CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 6, 10);
                        }
                        
                        */




                        //// iRowIndex = 33 + dtPrintPODetails.Rows.Count;

                        CellMerge("BorderAround", NewWorkSheet, 1, (iRowIndex), 1, 10);
                        iRowIndex++;


                        //iRowIndex++;
                        // iRowIndex++;
                        // iRowIndex++;



                        NewWorkSheet.HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);



                        //   int ilogoindex = iRowIndex + 2;
                        //  iRowIndex++;
                        //NewWorkSheet.Cells[iRowIndex, 1] = "Purchase Order";
                        //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 14);
                        //NewWorkSheet.Range["A" + iRowIndex + ":B" + iRowIndex + ""].Cells.Font.Size = 16;
                        //NewWorkSheet.Range["A" + iRowIndex + ":B" + iRowIndex + ""].Cells.Font.Bold = 16;
                        //CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 14);

                        int NewIrowindex = iRowIndex;
                        // iRowIndex++;
                        //  iRowIndex++;
                        //foreach (string str in Text89)
                        //{
                        //    NewWorkSheet.Cells[iRowIndex, 1] = str;
                        //    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                        //    iRowIndex++;
                        //}

                        //iRowIndex = 10 + iRowIndex;

                        // CellMerge("BorderAround", NewWorkSheet, (iRowIndex), (iRowIndex), 1, 14);
                        CellMerge("Merge", NewWorkSheet, iRowIndex, (iRowIndex), 1, 10);
                        NewWorkSheet.Cells[iRowIndex, 1] = "Terms and Conditions";
                        CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 10);
                        // NewWorkSheet.Range["A" + iRowIndex + ":B" + iRowIndex + ""].Cells.Font.Size = 16;
                        // NewWorkSheet.Range["A" + iRowIndex + ":B" + iRowIndex + ""].Cells.Font.Bold = 16;

                        //NewWorkSheet.Range["A"+ iRowIndex + ":F" + iRowIndex + ""].Cells.Font.Size = 18;
                        //NewWorkSheet.Rows[iRowIndex].RowHeight = 26;
                        // NewWorkSheet.Cells[(iRowIndex), 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                        CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 10);
                        iRowIndex++;

                                             

                        NewWorkSheet.Cells[iRowIndex, 1] = "Payment Terms :";
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 10);
                        CellMerge("AlignLeft", NewWorkSheet, iRowIndex, (iRowIndex), 1, 10);
                        //CellMerge("Bold", NewWorkSheet, iRowIndex, (iRowIndex), 1, 10);
                        iRowIndex++;
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 10);
                        CellMerge("AlignLeft", NewWorkSheet, iRowIndex, (iRowIndex), 1, 10);
                        //CellMerge("Bold", NewWorkSheet, iRowIndex, (iRowIndex), 1, 10);
                        for (int i = 0; i < dtGetPOGSTDetails.Rows.Count; i++)
                        {
                           
                            for (int m = 0; m < dtGetPOGSTDetails.Columns.Count; m++)
                            {
                                NewWorkSheet.Cells[iRowIndex, m + 1] = dtGetPOGSTDetails.Rows[0]["PaymentTerm"].ToString();

                                
                                if (dtGetPOGSTDetails.Rows[0]["PaymentTerm"].ToString().Length > 130)
                                {
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 36;
                                    NewWorkSheet.Rows[iRowIndex].WrapText = true;
                                }
                                
                            }
                            
                            
                        }
                        
                        iRowIndex++;
                        foreach (string str in Text9)
                         {
                            NewWorkSheet.Cells[iRowIndex, 1] = str;
                             iRowIndex++;
                         }


                        //MessageBox.Show(str);
                        /*
                       string paymentTermsString = dtGetPOGSTDetails.Rows[0]["PaymentTerm"].ToString();
                       string[] delimiters = { "." };
                       string[] paymentTermsArray = paymentTermsString.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);

                       iRowIndex++;

                       foreach (string paymentTerm in paymentTermsArray)
                       {
                           string paymentTermStr1 = "Payment Terms: " + paymentTerm;
                           // Logic to handle strings exceeding maxAllowedLength
                           NewWorkSheet.Cells[iRowIndex, 2] = paymentTermStr1;
                           iRowIndex++;
                       }
                        */


                        for (int i = 0; i < dgvPOGeneralTerms.Rows.Count; i++)
                        {
                            for (int m = 0; m < dgvPOGeneralTerms.Columns.Count; m++)
                            {
                                NewWorkSheet.Cells[iRowIndex, m + 1] = dgvPOGeneralTerms.Rows[i].Cells[m].Value.ToString();


                                if (dgvPOGeneralTerms.Rows[i].Cells[m].Value.ToString().Length > 130)
                                {
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 36;
                                    NewWorkSheet.Rows[iRowIndex].WrapText = true;
                                }
                            }
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 10);
                            iRowIndex++;
                        }

                        //  CellMerge("BorderAround", NewWorkSheet, iRowIndex, (iRowIndex + 3), 1, 14);

                        iRowIndex++;
                      //  NewWorkSheet.Cells[iRowIndex, 1] = "for ITW India Private Limited - BISS Division";
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 10);
                        CellMerge("AlignRight", NewWorkSheet, iRowIndex, (iRowIndex + 3), 1, 1);
                        CellMerge("Bold", NewWorkSheet, iRowIndex, (iRowIndex + 3), 1, 10);
                        iRowIndex++;
                       // int Sign = iRowIndex;

                        if (login.GetUserDetails[23] == "Accounts")
                        {
                            NewWorkSheet.Cells[iRowIndex, 1] = sApprovedby;
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 10);
                            CellMerge("AlignLeft", NewWorkSheet, iRowIndex, (iRowIndex), 1, 1);
                            iRowIndex++;
                            if (!string.IsNullOrEmpty(sGMAppr))
                            {
                                // sGMAppr = "GM Approval :" + Convert.ToString(dtPrintPODetails.Rows[0]["GMName"]);
                                NewWorkSheet.Cells[iRowIndex, 1] = sGMAppr;
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 10);
                                CellMerge("AlignLeft", NewWorkSheet, iRowIndex, (iRowIndex), 1, 1);
                            }

                            iRowIndex++;

                        }
                        else
                        {
                            iRowIndex++;
                            iRowIndex++;
                        }
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 10);
                       // NewWorkSheet.Cells[iRowIndex, 1] = "( Purchase Manager )                         ";
                        iRowIndex++;
                        /*bhavya
                        NewWorkSheet.Cells[iRowIndex, 1] = "I hear by confirm above purchase order reviewed and accepted";
                        iRowIndex++;
                        iRowIndex++;
                        iRowIndex++;
                        NewWorkSheet.Cells[iRowIndex, 1] = "( Seal & Signature of Vendor )";
                        */
                        CellMerge("BorderAround", NewWorkSheet, (NewIrowindex), (iRowIndex), 1, 10);
                        //  CellMerge("BorderAround", NewWorkSheet, (NewIrowindex), (NewIrowindex + 5), 1, 14);
                        CellMerge("BorderAround", NewWorkSheet, 1, 7, 1, 10);
                        // CellMerge("BorderAround", NewWorkSheet, 8, 10, 1, 14);
                        // CellMerge("BorderAround", NewWorkSheet, 11, 11, 1, 14);
                        CellMerge("BorderAround", NewWorkSheet, 11, 18, 1, 5);
                        CellMerge("BorderAround", NewWorkSheet, 11, 18, 6, 10);
                        // CellMerge("BorderAround", NewWorkSheet, 19, 19, 1, 14);
                        CellMerge("BorderAround", NewWorkSheet, 19, 26, 1, 5);
                        CellMerge("BorderAround", NewWorkSheet, 19, 26, 6, 10);
                        CellMerge("BorderAround", NewWorkSheet, 28, 28, 1, 10);

                        // CellMerge("Merge", NewWorkSheet, 1, 1, 1, 14);


                        NewWorkSheet.Cells[1, 1].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;

                        NewWorkSheet.get_Range("C1", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;

                        range2.NumberFormat = "0.00";
                        range2 = NewWorkSheet.get_Range("G28", "G" + (31 + dtPrintPODetails.Rows.Count) + "");
                        range2.NumberFormat = "0.00";
                        range2 = NewWorkSheet.get_Range("H28", "H" + (31 + dtPrintPODetails.Rows.Count) + "");
                        range2.NumberFormat = "0.00";
                        range2 = NewWorkSheet.get_Range("I28", "I" + (31 + dtPrintPODetails.Rows.Count) + "");
                        range2.NumberFormat = "0.00";
                        range2 = NewWorkSheet.get_Range("J28", "J" + (31 + dtPrintPODetails.Rows.Count) + "");
                        range2.NumberFormat = "0.00";

                        /*
                        //shreeshail is added bellow code
                        string before = range2.Value2;
                        string cleanV = System.Text.RegularExpressions.Regex.Replace(before, @"\s+", "");
                        range2.set_Value(cleanV);
                        //shreeshail is added above code
                        */

                        NewWorkSheet.Range["A1:F1"].Cells.Font.Size = 15;
                        NewWorkSheet.Range["A1:F1"].Cells.Font.Bold = true;
                        NewWorkSheet.Range["A2:F2"].Cells.Font.Size = 3;
                        NewWorkSheet.Range["A2:F2"].Cells.Font.Bold = true;
                        NewWorkSheet.Range["A3:F3"].Cells.Font.Size = 36;
                        NewWorkSheet.Range["A3:F3"].Cells.Font.Bold = true;
                        NewWorkSheet.Range["A4:F13"].Cells.Font.Size = 13;
                        NewWorkSheet.Range["A4:F12"].Cells.Font.Bold = true;
                        NewWorkSheet.Range["A17:J20"].Cells.Font.Bold = true;
                        NewWorkSheet.Range["A26:J28"].Cells.Font.Bold = true;
                        NewWorkSheet.Cells[8, 1].Cells.Font.Color = Color.Blue;
                        NewWorkSheet.Cells[9, 1].Cells.Font.Color = Color.Blue;
                        NewWorkSheet.Cells[10, 1].Cells.Font.Color = Color.Blue;

                        NewWorkSheet.Columns.AutoFit();

                        NewWorkSheet.get_Range("A6", "B9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignGeneral;


                        CellMerge("AlignTop", NewWorkSheet, 4, 7, 1, 5);
                        NewWorkSheet.Columns[1].ColumnWidth = 4;
                        //if (Convert.ToDouble(lblTotalAmount.Text) > 149999)
                        //{
                        //    NewWorkSheet.Columns[2].ColumnWidth = 24;               
                        //}
                        //else
                        //{
                        // NewWorkSheet.Columns[1].WrapText = true;
                        NewWorkSheet.Columns[2].ColumnWidth = 26;
                        //}
                        NewWorkSheet.Columns[2].WrapText = true;
                        NewWorkSheet.Columns[3].ColumnWidth = 6;
                        NewWorkSheet.Columns[4].ColumnWidth = 9;
                        NewWorkSheet.Columns[5].ColumnWidth = 14;
                        NewWorkSheet.Columns[6].ColumnWidth = 14;
                        NewWorkSheet.Columns[7].ColumnWidth = 13;
                        NewWorkSheet.Columns[8].ColumnWidth = 13;
                        NewWorkSheet.Columns[9].ColumnWidth = 13;
                        NewWorkSheet.Columns[10].ColumnWidth = 14;

                        //borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle = Excel.XlLineStyle.xlContinuous;



                        // NewWorkSheet.PrinterSet.RepeatRows = new ExcelAddress("$1:$1");

                        NewWorkSheet.Rows[7].RowHeight = 30;

                        NewWorkSheet.get_Range("A9", "J9999").Cells.Font.Size = 13;
                        NewWorkSheet.get_Range("A1", "J9999").Cells.Font.Name = "Calibri";
                        NewWorkSheet.get_Range("A" + NewIrowindex + "", "N" + NewIrowindex + "").Cells.Font.Size = 18;
                        NewWorkSheet.get_Range("A1", "J1").Cells.Font.Size = 18;

                        NewWorkSheet.PageSetup.PrintArea = "A1:J" + (iRowIndex) + "";

                        // NewWorkSheet.PageSetup.CenterHeaderPicture.Filename = "C:\\Databasepath\\POHeader.jpg";
                        // NewWorkSheet.PageSetup.CenterHeader = "&G";

                        //NewWorkSheet.PageSetup.LeftHeader = "&\"Arial\"&10 .. " + cmbVendorName.Text.Trim() + "";
                        //NewWorkSheet.PageSetup.RightHeader = "&\"Arial\"&10 " + cmbPONO.Text + "";
                       // NewWorkSheet.PageSetup.RightFooter = "Page &P of &N";
                        NewWorkSheet.PageSetup.PrintNotes = true;
                        NewWorkSheet.PageSetup.Zoom = 65;

                        NewWorkSheet.PageSetup.AlignMarginsHeaderFooter = true;
                        //NewWorkSheet.PageSetup.LeftMargin = 0.3;
                        // NewWorkSheet.PageSetup.RightMargin = 0.3;

                        NewWorkSheet.PageSetup.TopMargin = 2 * 28.35;
                        NewWorkSheet.PageSetup.BottomMargin = 1 * 28.35;
                        NewWorkSheet.PageSetup.LeftMargin = 1 * 28.35;
                        NewWorkSheet.PageSetup.RightMargin = 1 * 28.35;
                        NewWorkSheet.PageSetup.HeaderMargin = 1 * 28.35;
                        NewWorkSheet.PageSetup.FooterMargin = 1 * 28.35;

                        NewWorkSheet.PageSetup.CenterHorizontally = true;

                        // create the header range
                        //  Range headerRange = worksheet.Range["A1:J10"];

                        // set the header to repeat on each page
                        NewWorkSheet.PageSetup.PrintTitleRows = "A1:J7";

                        //for (int i = ExcelApp.ActiveWorkbook.Worksheets.Count; i > 0; i--)
                        //{
                        //    EXCEL.Worksheet wkSheet = (EXCEL.Worksheet)ExcelApp.ActiveWorkbook.Worksheets[i];
                        //    if (wkSheet.Name == "Sheet1")
                        //    {
                        //        wkSheet.Delete();
                        //    }
                        //}



                        NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                        NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                        if (btnprintpo.Text == "Draft PO")
                        {
                            EXCEL.Range oRange2 = (EXCEL.Range)NewWorkSheet.Cells[3, 6];

                            Image oImage2 = Image.FromFile("C:\\Databasepath\\Draftwatermark.JPG");
                            System.Windows.Forms.Clipboard.SetDataObject(oImage2, true);

                            System.Threading.Thread.Sleep(500);

                            //  NewWorkSheet.Paste(oRange2, "C:\\Databasepath\\Draftwatermark.JPG");
                            NewWorkSheet.Paste(oRange2);



                            //EXCEL.Range oRange1 = (EXCEL.Range)NewWorkSheet.Cells[3, 2];
                            //Image oImage1 = Image.FromFile(Global.sITWLogo);
                            //System.Windows.Forms.Clipboard.SetDataObject(oImage1, true);
                            //NewWorkSheet.Paste(oRange1, Global.sITWLogo);
                            //MessageBox.Show("Draft");
                        }
                        else if (btnprintpo.Text == "Print PO")
                        {
                            //MessageBox.Show("Print PO");
                            System.Threading.Thread.Sleep(100);
                            EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[3, 8];
                            Image oImage = Image.FromFile(Global.sInsronLogo);
                            System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                        
                           
                            System.Threading.Thread.Sleep(500);
                            //   NewWorkSheet.Paste(oRange, oImage);

                            NewWorkSheet.Paste(oRange);

                            /* EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[3, 8];
                             Image oImage = Image.FromFile(Global.sLogo1);
                             System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                             //NewWorkSheet.Paste(oRange, Global.sLogo1);
                             NewWorkSheet.PasteSpecial(oRange, Global.sLogo1); */

                            /* EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[3, 8];
                             Image oImage = Image.FromFile(Global.sLogo);
                             System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                             NewWorkSheet.Paste(oRange, oImage);*/
                            //NewWorkSheet.Paste(oRange, Global.sTQBiSSLogo);
                            // NewWorkSheet.PasteSpecial(oRange, Global.sTQBiSSLogo);

                            //EXCEL.Range oRange88 = (EXCEL.Range)NewWorkSheet.Cells[ilogoindex, 9];
                            //Image oImage4 = Image.FromFile(Global.sLogo);
                            //System.Windows.Forms.Clipboard.SetDataObject(oImage4, true);
                            //NewWorkSheet.Paste(oRange88, Global.sLogo);


                            EXCEL.Range oRange1 = (EXCEL.Range)NewWorkSheet.Cells[3, 2];
                             Image oImage1 = Image.FromFile(Global.sITWLogo);
                             System.Windows.Forms.Clipboard.SetDataObject(oImage1, true);

                            System.Threading.Thread.Sleep(500);
                          //  NewWorkSheet.Paste(oRange1,  Global.sITWLogo);

                            NewWorkSheet.Paste(oRange1);



                            /*EXCEL.Range oRange1 = (EXCEL.Range)NewWorkSheet.Cells[3, 2];
                            Image oImage1 = Image.FromFile(Global.sITWLogo);
                            System.Windows.Forms.Clipboard.SetDataObject(oImage1, true);
                            // NewWorkSheet.Paste(oRange1, Global.sITWLogo);
                            NewWorkSheet.PasteSpecial(oRange1, Global.sITWLogo); */


                            /*

                            if (login.GetUserDetails[2] == "Muthu")
                            {
                                EXCEL.Range oRange2 = (EXCEL.Range)NewWorkSheet.Cells[Sign, 9];
                                Image oImage2 = Image.FromFile("C:\\Databasepath\\MuthuramalingamSign.jpg");
                                System.Windows.Forms.Clipboard.SetDataObject(oImage2, true);

                                System.Threading.Thread.Sleep(500);
                                // NewWorkSheet.Paste(oRange2, Global.sITWLogo);
                                NewWorkSheet.Paste(oRange2);


                            }
                            else if (login.GetUserDetails[2] == "Lizzy")
                            {
                                EXCEL.Range oRange2 = (EXCEL.Range)NewWorkSheet.Cells[Sign, 9];
                                Image oImage2 = Image.FromFile("C:\\Databasepath\\MuthuramalingamSign.jpg");
                                System.Windows.Forms.Clipboard.SetDataObject(oImage2, true);

                                System.Threading.Thread.Sleep(500);
                               // NewWorkSheet.Paste(oRange2, Global.sITWLogo);
                                NewWorkSheet.Paste(oRange2);


                            }
                            else if (login.GetUserDetails[2] == "Veena")
                            {
                                EXCEL.Range oRange2 = (EXCEL.Range)NewWorkSheet.Cells[Sign, 9];
                                Image oImage2 = Image.FromFile("C:\\Databasepath\\veenasignature1.jpg");
                                System.Windows.Forms.Clipboard.SetDataObject(oImage2, true);

                                System.Threading.Thread.Sleep(500);
                                // NewWorkSheet.Paste(oRange2, Global.sITWLogo);
                                NewWorkSheet.Paste(oRange2);


                            }
                            */

                           // if (login.GetUserDetails[2] == "pavana")
                            //{
                              //  EXCEL.Range oRange2 = (EXCEL.Range)NewWorkSheet.Cells[3, 9];
                                //Image oImage2 = Image.FromFile("C:\\Databasepath\\veenasignature1pavana.jpg");
                                //System.Windows.Forms.Clipboard.SetDataObject(oImage2, true);

                                //System.Threading.Thread.Sleep(500);
                                //// NewWorkSheet.Paste(oRange2, Global.sITWLogo);
                                //NewWorkSheet.Paste(oRange2);


                            //}
                        }

                        
                       

                        NewWorkBook.Save();
                        ExcelApp.Visible = false;
                        /*
                                              //  NewWorkBook.ExportAsFixedFormat(EXCEL.XlFixedFormatType.xlTypePDF, FileFul);
                                                // Export as PDF FIRST, before closing anything
                                                NewWorkBook.ExportAsFixedFormat(
                                                    EXCEL.XlFixedFormatType.xlTypePDF,
                                                    FileFul,
                                                    EXCEL.XlFixedFormatQuality.xlQualityStandard
                                                );

                                                // Close workbook & quit Excel
                                                NewWorkBook.Close(SaveChanges: false);
                                                ExcelApp.Quit();

                                                // Merge PDFs AFTER Excel is closed
                                                string termsPdf = @"C:\Temp\TermsAndConditions.pdf";
                                                string tempMergedPdf = FileFul + ".temp";

                                                using (FileStream fs = new FileStream(tempMergedPdf, FileMode.Create))
                                                using (iTextSharp.text.Document doc = new iTextSharp.text.Document())
                                                using (iTextSharp.text.pdf.PdfCopy copy = new iTextSharp.text.pdf.PdfCopy(doc, fs))
                                                {
                                                    doc.Open();

                                                    foreach (string file in new[] { FileFul, termsPdf })
                                                    {
                                                        using (iTextSharp.text.pdf.PdfReader reader = new iTextSharp.text.pdf.PdfReader(file))
                                                        {
                                                            for (int i = 1; i <= reader.NumberOfPages; i++)
                                                            {
                                                                copy.AddPage(copy.GetImportedPage(reader, i));
                                                            }
                                                        }
                                                    }

                                                    doc.Close();
                                                }

                                                // Replace the file
                                                File.Delete(FileFul);             // Delete original
                                                File.Move(tempMergedPdf, FileFul); // Rename temp to original file name

                                                */

                        string workbookPdf = FileFul;
                        string termsPdf = @"C:\Temp\TermsAndConditions.pdf";
                        string borderedTermsPdf = Path.Combine(Path.GetDirectoryName(termsPdf), "TermsAndConditions_Bordered.pdf");
                        string mergedPdf = FileFul + ".merged";
                        string finalPdf = FileFul; // final output path

                        // Step 1: Export Excel as usual
                        NewWorkBook.ExportAsFixedFormat(EXCEL.XlFixedFormatType.xlTypePDF, workbookPdf);

                        // Step 2: Add border to TermsAndConditions.pdf
                        using (var reader = new iTextSharp.text.pdf.PdfReader(termsPdf))
                        using (var fs = new FileStream(borderedTermsPdf, FileMode.Create))
                        using (var stamper = new iTextSharp.text.pdf.PdfStamper(reader, fs))
                        {
                            int pageCount = reader.NumberOfPages;
                            for (int i = 1; i <= pageCount; i++)
                            {
                                var cb = stamper.GetOverContent(i);
                                cb.SetLineWidth(1f); // Border thickness
                                cb.SetRGBColorStroke(0, 0, 0); // Black color
                                cb.Rectangle(36, 36, reader.GetPageSize(i).Width - 72, reader.GetPageSize(i).Height - 72); // 1-inch margin
                                cb.Stroke();
                            }
                            stamper.Close();
                        }

                        // Step 3: Merge workbookPdf and borderedTermsPdf
                        using (var fs = new FileStream(mergedPdf, FileMode.Create))
                        using (var doc = new iTextSharp.text.Document())
                        using (var copy = new iTextSharp.text.pdf.PdfSmartCopy(doc, fs))
                        {
                            doc.Open();
                            foreach (var pdf in new[] { workbookPdf, borderedTermsPdf })
                            {
                                using (var reader = new iTextSharp.text.pdf.PdfReader(pdf))
                                {
                                    for (int i = 1; i <= reader.NumberOfPages; i++)
                                    {
                                        copy.AddPage(copy.GetImportedPage(reader, i));
                                    }
                                }
                            }
                            doc.Close();
                        }

                        // Step 4: Add footer with continuous page numbers
                        using (var reader = new iTextSharp.text.pdf.PdfReader(mergedPdf))
                        using (var fs = new FileStream(finalPdf, FileMode.Create))
                        using (var stamper = new iTextSharp.text.pdf.PdfStamper(reader, fs))
                        {
                            int totalPages = reader.NumberOfPages;
                            for (int i = 1; i <= totalPages; i++)
                            {
                                var cb = stamper.GetOverContent(i);
                                cb.BeginText();
                                cb.SetFontAndSize(BaseFont.CreateFont(BaseFont.HELVETICA, BaseFont.CP1252, false), 10);
                                cb.ShowTextAligned(iTextSharp.text.Element.ALIGN_RIGHT, $"Page {i} of {totalPages}", 560, 20, 0);
                                cb.EndText();
                            }
                            stamper.Close();
                        }


                        //File.Delete(workbookPdf);      // Clean up intermediate files
                        //File.Delete(mergedPdf);


                        if (btnprintpo.Text == "Draft PO")
                        {
                            System.Diagnostics.Process.Start(FileFul);
                        }
                        NewWorkBook.Close(true, misValue, misValue);
                        ExcelApp.Quit();
                        releaseObject(NewWorkSheet);
                        releaseObject(NewWorkBook);
                        releaseObject(ExcelApp);

                        if (btnprintpo.Text == "Print PO")
                        {
                            if (!string.IsNullOrEmpty(dtGetVendorDetails.Rows[0]["EmailAddress"].ToString()))
                            {
                                VendorEMail(dtGetVendorDetails.Rows[0]["EmailAddress"].ToString(), FileFul);
                            }
                            else
                            {
                                VendorEMail("hemanth_reddy@instron.com", FileFul);
                                MessageBox.Show("Vendor email id not available. Update email id in vendor master", "Error", 0, MessageBoxIcon.Error);
                            }
                        }

                        if (File.Exists(FileFullPath))
                        {
                            File.Delete(FileFullPath);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("PurchaseOrder_btnReport_Click  " + ex.Message);
                foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                {
                    GetProcess.Kill();
                }
            }
        }


        #region Excel App Release Object Function
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
        #endregion
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlHairline, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }

                case "GridLines":
                    {
                        CELLS.Borders.Color = System.Drawing.Color.Black;
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlHairline, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignCenter":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                        break;
                    }
                case "AlignTop":
                    {
                        CELLS.VerticalAlignment = EXCEL.XlVAlign.xlVAlignTop;
                        break;
                    }

                case "AlignRight":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                        break;
                    }
                case "AlignLeft":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignLeft;
                        break;
                    }
                case "Bold":
                    {
                        CELLS.Font.Bold = true;
                        break;
                    }
                default:
                    {
                        break;
                    }
            }
        }

        #endregion


        private void fnClearRemovePOitems()
        {
            if (string.IsNullOrEmpty(cmbPONO.Text))
            {
                fnRemoveAddedPOItem();
            }
        }

        #region Purchase Order Exit Function
        private void btnExit_Click(object sender, EventArgs e)
        {
            fnClearRemovePOitems();
            sPONumber = string.Empty;
            this.Hide();
            form.Show();
        }

        private void PurchaseOrder_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnClearRemovePOitems();
            fnAdjustPurchaseOrder = string.Empty;
            this.Hide();
            frm.Show();
        }


        #endregion

        #region PO Number Select Function
        int mountingCout = 0;
        private void cmbDetailedBOMno_SelectedIndexChanged(object sender, EventArgs e)
        {
            llbViewRemakrs.Visible = true;
            mountingCout = 0;
            cmbcurrency.SelectedIndex = 0;
            cmbcurrency.Enabled = true;
            curratetext.Text = "1";
            fnPOSelectedindexChanged(cmbPONO.Text);
            btnPackingAmount.Enabled = true;
        }
        #endregion


        #region PO Quantiy Cost Edit
        private void dgbomlist_CellEndEdit_1(object sender, DataGridViewCellEventArgs e)
        {
            if (dgbomlist.CurrentCell.Value != null)
            {
                if ((dgbomlist.CurrentCell.OwningColumn.Name == "Unitprice") || dgbomlist.CurrentCell.OwningColumn.Name == "Amount" || dgbomlist.CurrentCell.OwningColumn.Name == "ReqQty" || dgbomlist.CurrentCell.OwningColumn.Name == "IGSTRate" || dgbomlist.CurrentCell.OwningColumn.Name == "SGSTRate" || dgbomlist.CurrentCell.OwningColumn.Name == "CGSTRate" || dgbomlist.CurrentCell.OwningColumn.Name == "DiscRate")
                {
                    if (!string.IsNullOrEmpty(dgbomlist.CurrentCell.Value.ToString()) && (dgbomlist.CurrentCell.Value.ToString() != sDot) && Convert.ToDouble(dgbomlist.CurrentCell.Value.ToString()) != 0)// )// && // != null)
                    {
                        switch (dgbomlist.CurrentCell.OwningColumn.Name)
                        {
                            case "Unitprice":
                                dgbomlist.CurrentRow.Cells["Amount"].Value = Convert.ToDouble(dgbomlist.CurrentRow.Cells["Unitprice"].Value) * Convert.ToDouble(dgbomlist.CurrentRow.Cells["ReqQty"].Value);
                                dgbomlist.CurrentRow.Cells["DiffrenceinPer"].Value = Math.Round((((Convert.ToDouble(dgbomlist.CurrentRow.Cells["Unitprice"].Value) - Convert.ToDouble(dgbomlist.CurrentRow.Cells["StandardCost"].Value)) / Convert.ToDouble(dgbomlist.CurrentRow.Cells["StandardCost"].Value)) * 100), 0);
                                dgbomlist.CurrentRow.Cells["DiffrenceinRs"].Value = Math.Round((Convert.ToDouble(dgbomlist.CurrentRow.Cells["Unitprice"].Value) - Convert.ToDouble(dgbomlist.CurrentRow.Cells["StandardCost"].Value)), 2);
                                Datagridviewcolor();
                                fnGSTTaxChange();
                                break;
                            case "Amount":
                                dgbomlist.CurrentRow.Cells["Unitprice"].Value = Convert.ToDouble(dgbomlist.CurrentRow.Cells["Amount"].Value) / Convert.ToDouble(dgbomlist.CurrentRow.Cells["ReqQty"].Value);
                                fnGSTTaxChange();
                                break;
                            case "ReqQty":
                                dgbomlist.CurrentRow.Cells["Amount"].Value = (Convert.ToDouble(dgbomlist.CurrentRow.Cells["ReqQty"].Value) * Convert.ToDouble(dgbomlist.CurrentRow.Cells["Unitprice"].Value)).ToString();
                                dgbomlist.CurrentRow.Cells["RemQty"].Value = dgbomlist.CurrentRow.Cells["ReqQty"].Value;
                                fnGSTTaxChange();
                                break;

                            case "IGSTRate":
                                dgbomlist.CurrentRow.Cells["IGSTAmount"].Value = ((Convert.ToDouble(dgbomlist.CurrentRow.Cells["Amount"].Value) - Convert.ToDouble(dgbomlist.CurrentRow.Cells["DiscAmount"].Value)) / 100) * Convert.ToDouble(dgbomlist.CurrentRow.Cells["IGSTRate"].Value);
                                break;

                            case "SGSTRate":
                                dgbomlist.CurrentRow.Cells["SGSTAmount"].Value = ((Convert.ToDouble(dgbomlist.CurrentRow.Cells["Amount"].Value) - Convert.ToDouble(dgbomlist.CurrentRow.Cells["DiscAmount"].Value)) / 100) * Convert.ToDouble(dgbomlist.CurrentRow.Cells["SGSTRate"].Value);
                                break;
                            case "CGSTRate":
                                dgbomlist.CurrentRow.Cells["CGSTAmount"].Value = ((Convert.ToDouble(dgbomlist.CurrentRow.Cells["Amount"].Value) - Convert.ToDouble(dgbomlist.CurrentRow.Cells["DiscAmount"].Value)) / 100) * Convert.ToDouble(dgbomlist.CurrentRow.Cells["CGSTRate"].Value);
                                break;
                            case "DiscRate":
                                dgbomlist.CurrentRow.Cells["DiscAmount"].Value = (Convert.ToDouble(dgbomlist.CurrentRow.Cells["Amount"].Value) / 100) * Convert.ToDouble(dgbomlist.CurrentRow.Cells["DiscRate"].Value);

                                break;
                        }
                    }
                    else
                    {
                        if (dgbomlist.CurrentCell.OwningColumn.Name == "Unitprice" || dgbomlist.CurrentCell.OwningColumn.Name == "Amount" || dgbomlist.CurrentCell.OwningColumn.Name == "ReqQty")
                        {
                            dgbomlist.CurrentCell.Value = oldvalue;
                        }
                        else
                        {
                            dgbomlist.CurrentCell.Value = 0;
                            fnGSTTaxChange();
                        }
                    }
                }
                fnTotalPOCost();
            }
        }

        private void fnGSTTaxChange()
        {
            dgbomlist.CurrentRow.Cells["IGSTAmount"].Value = ((Convert.ToDouble(dgbomlist.CurrentRow.Cells["Amount"].Value) - Convert.ToDouble(dgbomlist.CurrentRow.Cells["DiscAmount"].Value)) / 100) * Convert.ToDouble(dgbomlist.CurrentRow.Cells["IGSTRate"].Value);
            dgbomlist.CurrentRow.Cells["SGSTAmount"].Value = ((Convert.ToDouble(dgbomlist.CurrentRow.Cells["Amount"].Value) - Convert.ToDouble(dgbomlist.CurrentRow.Cells["DiscAmount"].Value)) / 100) * Convert.ToDouble(dgbomlist.CurrentRow.Cells["SGSTRate"].Value);
            dgbomlist.CurrentRow.Cells["CGSTAmount"].Value = ((Convert.ToDouble(dgbomlist.CurrentRow.Cells["Amount"].Value) - Convert.ToDouble(dgbomlist.CurrentRow.Cells["DiscAmount"].Value)) / 100) * Convert.ToDouble(dgbomlist.CurrentRow.Cells["CGSTRate"].Value);
            dgbomlist.CurrentRow.Cells["DiscAmount"].Value = (Convert.ToDouble(dgbomlist.CurrentRow.Cells["Amount"].Value) / 100) * Convert.ToDouble(dgbomlist.CurrentRow.Cells["DiscRate"].Value);
        }

        double dTotalAmount = 0;
        double dTotalDiscount = 0;
        double dTotalSgst = 0;
        double dTotalCgst = 0;
        double dTotalIgst = 0;
        private void fnTotalPOCost()
        {
            totalcost = 0;
            dTotalAmount = 0;
            dTotalDiscount = 0;
            dTotalSgst = 0;
            dTotalCgst = 0;
            dTotalIgst = 0;
            foreach (DataGridViewRow dgvr in dgbomlist.Rows)
            {
                totalcost += Convert.ToDouble(dgvr.Cells["Amount"].Value) - Convert.ToDouble(dgvr.Cells["DiscAmount"].Value) + Convert.ToDouble(dgvr.Cells["IGSTAmount"].Value) + Convert.ToDouble(dgvr.Cells["SGSTAmount"].Value) + Convert.ToDouble(dgvr.Cells["CGSTAmount"].Value);
                dTotalAmount += Convert.ToDouble(dgvr.Cells["Amount"].Value);
                dTotalDiscount += Convert.ToDouble(dgvr.Cells["DiscAmount"].Value);
                dTotalSgst += Convert.ToDouble(dgvr.Cells["SGSTAmount"].Value);
                dTotalCgst += Convert.ToDouble(dgvr.Cells["CGSTAmount"].Value);
                dTotalIgst += Convert.ToDouble(dgvr.Cells["IGSTAmount"].Value);
            }

            foreach (DataGridViewRow dgvr in dgPackingTaxes.Rows)
            {
                totalcost += Convert.ToDouble(dgvr.Cells["taxamount"].Value) + Convert.ToDouble(dgvr.Cells["taxIGSTAmount"].Value) + Convert.ToDouble(dgvr.Cells["taxSGSTAmount"].Value) + Convert.ToDouble(dgvr.Cells["taxCGSTAmount"].Value);
            }

            txtInvoiceTotal.Text = Math.Round(totalcost, 2).ToString();
            txtBalanceDue.Text = (Convert.ToDouble(txtInvoiceTotal.Text) - Convert.ToDouble(txtAmountPaid.Text)).ToString();
            lblTotalAmount.Text = dTotalAmount.ToString();
            lbltotaldiscount.Text = dTotalDiscount.ToString();
            lbltotalSGST.Text = dTotalSgst.ToString();
            lbltotalCGST.Text = dTotalCgst.ToString();
            lbltotalIGST.Text = dTotalIgst.ToString();
        }

        private void dgbomlist_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (dgbomlist.Rows.Count > 0)
                {
                    DialogResult DR = MessageBox.Show("Do you want to delete selected row", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (DR == DialogResult.Yes)
                    {
                        if (chkWithoutBOM.Checked == false)
                        {
                            fnDeleteAddedPOItem();
                            // Get BOMProjectCode (e.g., "BOMProjectCodes CUS-2022-08-OTS-113580/15/1")
                            string bomProjectCode = dgbomlist.CurrentRow.Cells["BOMProjectCodes"].Value.ToString();

                            // Split the string into an array based on the comma separator
                            string[] projectCodes = bomProjectCode.Split(',');

                            // Optionally, loop through the project codes
                            foreach (string code in projectCodes)
                            {
                                // Trim any leading or trailing whitespace around each project code
                                string trimmedCode = code.Trim();

                                // Split the individual projectCode by "/"
                                string[] parts = trimmedCode.Split('/');

                                // First part will be the projectCode
                                string projectCode = parts[0];

                                // Middle number is the ProductNo (second part after splitting by "/")
                                string productNo = parts.Length > 1 ? parts[1] : string.Empty;

                                DAL.purchaseOrderListDeleted(0, cmbPONO.Text, dgbomlist.CurrentRow.Cells["ItemCode"].Value.ToString(), login.GetUserDetails[2], dtppreparedate.Text, projectCode, productNo);
                                GLobalClass.iStatus = DAL.fnAddPurchaseOrderBOM(3, cmbPONO.Text, projectCode, productNo, dgbomlist.CurrentRow.Cells["ItemCode"].Value.ToString(), 0, 0, 0, "");
                            }
                                DAL.purchaseOrderListDeleted(1, cmbPONO.Text, dgbomlist.CurrentRow.Cells["ItemCode"].Value.ToString(), "", "","","");
                            dgbomlist.Rows.RemoveAt(dgbomlist.Rows.IndexOf(dgbomlist.CurrentRow));
                            fnTotalPOCost();
                        }

                        else
                        {
                            if (!string.IsNullOrEmpty(cmbPONO.Text))
                            {
                                DAL.purchaseOrderListDeleted(0, cmbPONO.Text, dgbomlist.CurrentRow.Cells["ItemCode"].Value.ToString(), login.GetUserDetails[2], dtppreparedate.Text, "", "");
                                DAL.purchaseOrderListDeleted(1, cmbPONO.Text, dgbomlist.CurrentRow.Cells["ItemCode"].Value.ToString(), "", "","","");
                                GLobalClass.iStatus = DAL.fnAddPurchaseOrderBOM(3, cmbPONO.Text, "", "", dgbomlist.CurrentRow.Cells["ItemCode"].Value.ToString(), 0, 0, 0, "");
                            }
                            dgbomlist.Rows.RemoveAt(dgbomlist.Rows.IndexOf(dgbomlist.CurrentRow));
                            fnTotalPOCost();
                        }
                    }
                }
            }
        }
        #endregion

        bool bNewPOItem = false;
        #region PO Items Added Function
        private void dgbomlist_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            if (dgbomlist.Rows.Count > 0 && cmbPONO.Text == null)
            {
                btnSave.Enabled = true;
            }
            if (dgbomlist.Rows.Count == 1)
            {
                chkWithoutBOM.Enabled = false;
            }
            bNewPOItem = true;

        }
        #endregion


        #region Authorized PO List ready to send vendors
        private void btnloadpolist_Click(object sender, EventArgs e)
        {
            cmbPONO.Text = "";
            cmbPONO.Items.Clear();
            cmbPONO.Enabled = true;
           
            btnprintpo.Text = "Print PO";
            if (Convert.ToBoolean(login.GetUserDetails[16]) == true && Convert.ToBoolean(login.GetUserDetails[30]) != true || login.GetUserDetails[2].ToLower() == "lizzy" && Convert.ToBoolean(login.GetUserDetails[30]) != true || login.GetUserDetails[2].ToLower() == "veena" || login.GetUserDetails[2].ToLower() == "pavana" || login.GetUserDetails[2].ToLower() == "hemanth reddy" && Convert.ToBoolean(login.GetUserDetails[30]) != true)  //lblPrepareBy.Text.ToLower() != "hebbarrk")
            {
                btnAcceptPO.Enabled = false;
                btnRejectPO.Enabled = false;
                btnGenaratePO.Enabled = true;
                dgbomlist.DataSource = null;
                chkPrintPO.Checked = false;
                llbViewPOGeneralTerms.Visible = true;
                dtPOFilter = DAL.fnPOOrderFilter(4, "").Tables[0];
                DataView dvPOOrderFilter1 = new DataView(dtPOFilter);
                dvPOOrderFilter1.Sort = "DBOMNo desc";
                dtPOFilter = dvPOOrderFilter1.ToTable();
                if (dtPOFilter.Rows.Count > 0)
                {
                    foreach (DataRow DR in dtPOFilter.Rows)
                    {
                        if (!cmbPONO.Items.Contains(DR["DBOMNo"].ToString()))
                            cmbPONO.Items.Add(DR["DBOMNo"].ToString());
                    }
                }
                
            }
        }
        #endregion

        #region View PO List
        private void btnviewpolist_Click(object sender, EventArgs e)
        {
            sPONumber = string.Empty;
            this.Hide();
            pleasewaitform pleaseWait = new pleasewaitform();
            // Display form modelessly
            pleaseWait.Show();
            //  ALlow main UI thread to properly display please wait form.
            Application.DoEvents();
            POView POView = new POView();
            POView.Show();
            pleaseWait.Hide();
        }
        #endregion

        #region PO Items Removed Function
        private void dgbomlist_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            if (dgbomlist.Rows.Count == 0)
            {
                chkWithoutBOM.Enabled = true;
            }
        }
        #endregion
        #region Print Option funtion

        private void chkPrintPO_CheckedChanged(object sender, EventArgs e)
        {
            if (chkPrintPO.CheckState == CheckState.Checked)
            {
                cmbPONO.Text = "";
                cmbPONO.Items.Clear();
                btnprintpo.Text = "Print PO";
                if (Convert.ToBoolean(login.GetUserDetails[16]) == true || login.GetUserDetails[2].ToLower() == "lizzy" || login.GetUserDetails[2].ToLower() == "veena" || login.GetUserDetails[2].ToLower() == "pavana" || login.GetUserDetails[2].ToLower() == "hemanth reddy" ) //added shreeshail or condition lizzy
                {
                    dgbomlist.DataSource = null;
                    dgbomlist.ReadOnly = true;
                    dtPOFilter = DAL.fnPOOrderFilter(2, "").Tables[0];
                    DataView dvPOOrderFilter1 = new DataView(dtPOFilter);
                    dvPOOrderFilter1.Sort = "DBOMNo desc";
                    dtPOFilter = dvPOOrderFilter1.ToTable();
                    if (dtPOFilter.Rows.Count > 0)
                    {
                        foreach (DataRow DR in dtPOFilter.Rows)
                        {
                            if (!cmbPONO.Items.Contains(DR["DBOMNo"].ToString()))
                                cmbPONO.Items.Add(DR["DBOMNo"].ToString());
                        }
                        cmbPONO.Enabled = true;
                    }

                    btnGenaratePO.Enabled = false;
                    btnprintpo.Enabled = true;
                    btnRejectPO.Enabled = true;
                }
            }
            else
            {
                dgbomlist.ReadOnly = false;
                btnprintpo.Enabled = false;
                btnloadpolist_Click(sender, e);
            }
        }
        #endregion

        #region View Repeat Order
        private void btnrepeatorder_Click(object sender, EventArgs e)
        {
            pleasewaitform pleaseWait = new pleasewaitform();
            pleaseWait.Show();
            Application.DoEvents();
            RepeatOrder repeatorder = new RepeatOrder();
            repeatorder.Show();
            pleaseWait.Hide();
        }
        #endregion


        #region PO Delivery Date Validation
        bool bDeliverDate = false;
        private void dtpdelivery_ValueChanged(object sender, EventArgs e)
        {
            bDeliverDate = true;
            if (!chkPrintPO.Checked)
            {
                if (dtpdelivery.Value < dtppreparedate.Value)
                {
                    bDeliverDate = false;
                    //MessageBox.Show("Delivery date should be greater than PO date");
                }
            }

            // Get the selected date from the DateTimePicker
            DateTime selectedDate = dtpdelivery.Value;

            // Add one month to the selected date
            DateTime newDate = selectedDate.AddMonths(1);

            // Set the new date to the PurchaseOrderValidUptoDate DateTimePicker
            PurchaseOrdervaliduptoDate.Value = newDate;
            string sqlDate = selectedDate.ToString("yyyy-MM-dd");

            DataTable fnDeliveryTermPOData = DAL.fnDeliveryTermPO(sqlDate).Tables[0];
            if (fnDeliveryTermPOData.Rows.Count > 0)
            {
                cmbDeliverTerms.SelectedItem = fnDeliveryTermPOData.Rows[0]["DeliveryTerms"];

            }
            else
            {
                if(login.GetUserDetails[2].ToLower() == "pavana" && mountingCout == 0)
                {
                    MessageBox.Show("Can't able to set the Delivery term. Can you manually Update..!", "Delivery Term");
                    mountingCout = 1;
                }
            }
            //MessageBox.Show(sqlDate, "Delivery Term");
        }
        #endregion


        //if (Convert.ToDouble(row.Cells["dBOMQty"].Value) > 0 )
        //          {
        //              if (string.IsNullOrEmpty(row.Cells["BOMProjectCodes"].Value.ToString()))
        //              {
        //                  MessageBox.Show("Please select Project BOM list for the item '" + row.Cells["ItemDescription"].Value.ToString() + "'", "Information", 0, MessageBoxIcon.Warning);
        //                  bSixMonths = true;
        //                  break;
        //              }
        //              else if (Convert.ToDouble(row.Cells["ReqQty"].Value) > Convert.ToDouble(row.Cells["dBOMQty"].Value))
        //              {
        //                  MessageBox.Show("Selected item '" + row.Cells["ItemDescription"].Value.ToString() + "' required quantity is more than BOM Quantity. PO not allowed \nContact authorise person for order quantity details ", "Information", 0, MessageBoxIcon.Warning);
        //                  bSixMonths = true;
        //                  break;
        //              }
        //          }
        //          else if (Convert.ToDouble(row.Cells["SixMonths"].Value) > 0)
        //          {
        //              if (Convert.ToDouble(row.Cells["ReqQty"].Value) > (Convert.ToDouble(row.Cells["SixMonths"].Value) + Convert.ToDouble(row.Cells["AvaQty"].Value)))
        //              {
        //                  MessageBox.Show("Selected item '" + row.Cells["ItemDescription"].Value.ToString() + "' required quantity is greater than 6 months usage + Available quantity. PO not allowed \nContact authorise person for order quantity details", "Information", 0, MessageBoxIcon.Warning);
        //                  bSixMonths = true;
        //                  break;
        //              }
        //          }

        bool bPOBOMQty = false;
        private void fnQunatityCheckofBOMPO()
        {
            bPOBOMQty = false;
            foreach (DataGridViewRow row in dgbomlist.Rows)
            {
                if (Convert.ToDouble(row.Cells["dBOMQty"].Value) > 0)
                {
                    pnBOMQtyCheck.Visible = true;
                    dtBOMProjectList = DAL.fnBOMItemPurchase(row.Cells["ItemCode"].Value.ToString(), " ").Tables[0];
                    dgvBOMQty.AutoGenerateColumns = false;
                    dgvBOMQty.DataSource = dtBOMProjectList;
                    dBOMTotalQuantity = 0;
                    if (!string.IsNullOrEmpty(row.Cells["BOMProjectCodes"].Value.ToString()))
                    {
                        dBOMTotalQuantity = Convert.ToDouble(row.Cells["ReqQty"].Value);
                        lstBOMProjects.Clear();
                        lstBOMProjects = row.Cells["BOMProjectCodes"].Value.ToString().Split(',').ToList();
                        DataTable dtEnterdQty = new DataTable();
                        dtEnterdQty = convertStringToDataTable(row.Cells["BOMProjectCodes"].Value.ToString());

                        foreach (DataRow dr in dtEnterdQty.Rows)
                        {
                            GLobalClass.iStatus = DAL.fnUpdateMachinBOMPO(2, (dr[2].ToString()), row.Cells["ItemCode"].Value.ToString(),
                                                                                                             dr[0].ToString(), dr[1].ToString());
                        }
                        //  dtEnterdQty.Columns[2].DataType = typeof(double);
                        //for (int k = 0; k < dtEnterdQty.Rows.Count; k++)
                        //{
                        //    for (int i = 0; i < dtBOMProjectList.Rows.Count; i++)
                        //    {
                        //        if (dtEnterdQty.Rows[k]["ProjectCode"].ToString().Trim() == dtBOMProjectList.Rows[i]["ProjectCode"].ToString().Trim() && dtEnterdQty.Rows[k]["ProductNo"].ToString().Trim() == dtBOMProjectList.Rows[i]["ProductNo"].ToString().Trim())
                        //        {
                        //            {
                        //                int nIndex = dtBOMProjectList.Rows.IndexOf(dtBOMProjectList.Rows[i]);
                        //                DataRow dr1 = dtBOMProjectList.Rows[nIndex];
                        //                dr1["ReqQty"] = dtEnterdQty.Rows[k]["ReqQty"].ToString();
                        //                break;
                        //            }
                        //        }
                        //    }
                        //}
                    }
                }
            }
        }

        bool bSixMonthMessage = false;
        private void fnQunatityCheck()
        {
            if (chkWithoutBOM.CheckState == CheckState.Checked)
            {
                bSixMonthMessage = false;

                bSixMonths = false;
                foreach (DataGridViewRow row in dgbomlist.Rows)
                {
                    if (Convert.ToDouble(row.Cells["SixMonths"].Value) > 0)
                    {
                        if (Convert.ToDouble(row.Cells["ReqQty"].Value) > (Convert.ToDouble(row.Cells["SixMonths"].Value) + Convert.ToDouble(row.Cells["AvaQty"].Value)))
                        {
                            // MessageBox.Show("Selected item '" + row.Cells["ItemDescription"].Value.ToString() + "' required quantity is greater than 6 months usage + Available quantity. PO not allowed \nContact authorise person for order quantity details", "Information", 0, MessageBoxIcon.Warning);
                            bSixMonthMessage = true;
                            // break;
                        }
                    }
                    if (Convert.ToDouble(row.Cells["ReqQty"].Value) == 0)
                    {
                        MessageBox.Show("Selected item '" + row.Cells["ItemDescription"].Value.ToString() + "' required quantity is '0' PO not allowed \nPlease enter the required quantity.", "Error", 0, MessageBoxIcon.Error);
                        bSixMonths = true;
                        break;
                    }
                }
            }
            else
            {
                bSixMonths = false;
                bSixMonthMessage = false;
                foreach (DataGridViewRow row in dgbomlist.Rows)
                {
                    if (row.Cells["dBOMQty"].Value != DBNull.Value)
                    {
                        if (Convert.ToDouble(row.Cells["ReqQty"].Value) == 0)
                        {
                            MessageBox.Show("Selected item '" + row.Cells["ItemDescription"].Value.ToString() + "' required quantity is '0' PO not allowed \nPlease add the item in Project BOM.", "Information", 0, MessageBoxIcon.Warning);
                            bSixMonths = true;
                            break;
                        }
                        else if (Convert.ToDouble(row.Cells["dBOMQty"].Value) > 0)
                        {
                            if (string.IsNullOrEmpty(row.Cells["BOMProjectCodes"].Value.ToString()))
                            {
                                MessageBox.Show("Please select Project BOM list for the item '" + row.Cells["ItemDescription"].Value.ToString() + "'", "Information", 0, MessageBoxIcon.Warning);
                                bSixMonths = true;
                                break;
                            }
                            else if (Convert.ToDouble(row.Cells["ReqQty"].Value) > Convert.ToDouble(row.Cells["dBOMQty"].Value))
                            {
                                MessageBox.Show("Selected item '" + row.Cells["ItemDescription"].Value.ToString() + "' required quantity is more than BOM Quantity. PO not allowed \nContact authorise person for order quantity details ", "Information", 0, MessageBoxIcon.Warning);
                                bSixMonths = true;
                                break;
                            }
                            if (Convert.ToDouble(row.Cells["ReqQty"].Value) > (Convert.ToDouble(row.Cells["SixMonths"].Value) + Convert.ToDouble(row.Cells["AvaQty"].Value)))
                            {
                                //    MessageBox.Show("Selected item '" + row.Cells["ItemDescription"].Value.ToString() + "' required quantity is greater than 6 months usage + Available quantity. PO not allowed \nContact authorise person for order quantity details", "Information", 0, MessageBoxIcon.Warning);
                                bSixMonthMessage = true;
                                //break;
                            }
                        }

                    }
                }
            }

            if (bSixMonthMessage)
            {
                MessageBox.Show("Please note some po item quantity is more than six months usage quantity.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (chkWithoutBOM.CheckState == CheckState.Checked)
                {
                    sSixMonthsMessage = "<br /><br /> <b> Please note the PO is created without BOM. <b> <br /> <br /> <b> Please note that some PO items are more than the 6 months usage + available quantity. </b> <br />";
                }
                else
                {
                    sSixMonthsMessage = "<br /><br /> <b> Please note that some PO items are more than the 6 months usage + available quantity. </b> <br />";
                }
            }
            else
            {
                if (chkWithoutBOM.CheckState == CheckState.Checked)
                {
                    sSixMonthsMessage = "<br /><br /> <b> Please note the PO is created without BOM. </b> <br />";
                }
                else
                {
                    sSixMonthsMessage = "";
                }
            }
        }
        string sWithoutBOM = "0";

        DataTable dtProjectType = new DataTable();
        DataTable dtProjectAllCost = new DataTable();
        double dProjectCost = 0;
        double dTotalPOAmount = 0;
        double dCurrentPOAmount = 0;
        bool bProjectCost = true;
        private void fnProjectAmountCheck()
        {
            bProjectCost = true;
            dProjectCost = 0;
            dTotalPOAmount = 0;
            dCurrentPOAmount = 0;

            dtProjectType = DAL.fnProjectCostLimitCIP(0, cmbProjectcode.Text).Tables[0];
            if (dtProjectType.Rows.Count > 0)
            {
                if (dtProjectType.Rows[0]["ProjectType"].ToString() == "Fixed Asset (CIP)")
                {
                    dtProjectAllCost = DAL.fnProjectCostLimitCIP(1, cmbProjectcode.Text).Tables[0];

                    if (dtProjectAllCost.Rows.Count > 0)
                    {
                        dProjectCost = Convert.ToDouble(dtProjectAllCost.Rows[0]["TotalAmount"].ToString());
                        dTotalPOAmount = Convert.ToDouble(dtProjectAllCost.Rows[1]["TotalAmount"].ToString());
                    }

                    dCurrentPOAmount = Convert.ToDouble(lblTotalAmount.Text);

                    if (dtProjectType.Rows[0]["Type"].ToString() != "Inhouse")
                    {
                        if ((dTotalPOAmount + dCurrentPOAmount) <= dProjectCost)
                        {
                            bProjectCost = true;
                        }
                        else
                        {
                            bProjectCost = false;
                        }
                    }
                }
            }
        }

        #region Genarate New PO

        private void btnSave_Click(object sender, EventArgs e)
        {
          
            int iLastPONo = 0;
            fnQunatityCheck();
            fnProjectAmountCheck();
            if (!string.IsNullOrEmpty(txtRemarks.Text) && !string.IsNullOrEmpty(cmbProjectcode.Text) && cmbVendorName.SelectedIndex >= 0 && dgbomlist.Rows.Count > 0 && !bSixMonths && bDeliverDate == true && cmbEmailAlert.SelectedIndex >= 0 && bProjectCost) //&& cmbPOTerms.SelectedIndex >= 0
            {
                try
                {
                    sDBOMID = DAL.fnpurchaseOrder(null);
                    if (!string.IsNullOrEmpty(sDBOMID))
                    {
                        sDBOMNo = sDBOMID.Substring(03, 08);
                        iLastPONo = Convert.ToInt32(sDBOMNo);
                    }
                    if (chkWithoutBOM.CheckState == CheckState.Checked)
                    {
                        sWithoutBOM = "1";
                    }
                    else
                    {
                        sWithoutBOM = "0";
                    }

                    if (iLastPONo > 0)
                    {
                        iLastPONo++;
                        PONo = ("PO/" + iLastPONo);
                        cmbPONO.Text = PONo;

                        fnAddedPOBOMItemPrice();




                        foreach (DataGridViewRow row in dgbomlist.Rows)
                        {
                            if (Convert.ToString(row.Cells["OtherProjects"].Value) == string.Empty || Convert.ToString(row.Cells["OtherProjects"].Value) == null)
                            {
                                row.Cells["OtherProjects"].Value = "";
                            }
                            GLobalClass.iSuccess = DAL.fnAddPurchaseOrder(Global.uINSERT, PONo, cmbProjectcode.Text, txtvendorcode.Text, lblPrepareBy.Text, lblPrepareBy.Text, row.Cells["ItemCode"].Value.ToString(), row.Cells["UOM"].Value.ToString(),
                                                    Convert.ToDouble(row.Cells["ReqQty"].Value), Convert.ToDouble(row.Cells["RemQty"].Value), Convert.ToDouble(row.Cells["Unitprice"].Value),
                                                    Convert.ToDouble(row.Cells["Amount"].Value), txtRemarks.Text, dtppreparedate.Text, dtppreparedate.Text, lblProjectStatus.Text,
                                                    0, 0, 0, 0, 0, 0, 0, 0, Convert.ToDouble(row.Cells["SixMonths"].Value), Convert.ToDouble(row.Cells["TwelveMonths"].Value),
                                                    Convert.ToDouble(row.Cells["dBOMQty"].Value), row.Cells["BOMProjectCodes"].Value.ToString(), dtpdelivery.Text,
                                                    row.Cells["OtherProjects"].Value.ToString(), Convert.ToDouble(row.Cells["LatestPurchasePrice"].Value), sWithoutBOM, cmbcurrency.Text, Convert.ToDouble(curratetext.Text), PurchaseOrdervaliduptoDate.Text);

                        }


                        try {
                            DataTable fnGetVedorDetailsList = DAL.fnGetVedorDetails(txtvendorcode.Text).Tables[0];


                            if (fnGetVedorDetailsList.Rows.Count > 0)
                            {
                               
                                                                                                                         // MessageBox.Show(fnGetVedorDetailsList.Rows[0]["DeliveryTerms"].ToString(), "DeliveryTerms");

                                if (PONo != "" && PONo != null)
                                {
                                    // MessageBox.Show(cmbPONO.Text);
                                    try
                                    {
                                        int fnUpdatePurchaseOrderVendorDeatilsStatus = DAL.fnUpdatePurchaseOrderVendorDeatils("UPDATE", PONo, Convert.ToDouble(fnGetVedorDetailsList.Rows[0]["IGST"].ToString()), Convert.ToDouble(fnGetVedorDetailsList.Rows[0]["CGST"].ToString()), Convert.ToDouble(fnGetVedorDetailsList.Rows[0]["SGST"].ToString()));
                                        // MessageBox.Show("updated-GST", fnUpdatePurchaseOrderVendorDeatilsStatus.ToString());
                                    }
                                    catch (Exception error)
                                    {
                                        MessageBox.Show(error.Message, "this issue happing from update GST...!");
                                    }

                                }

                            }
                            else
                            {
                                MessageBox.Show("Vendor not found in Vendor Details...!");
                            }
                        }
                        catch
                        {

                        }



                        //shreeshail is added bellow code
                        DataTable dtPMnameandHmname = DAL.fuHeadandmanager(login.GetUserDetails[2]).Tables[0];
                        if (dtPMnameandHmname.Rows[0]["Department"].ToString() != "Testlab")
                        {
                            GLobalClass.iSuccess = DAL.purchaseOrderApprovalfirstlevel(0, cmbPONO.Text, login.GetUserDetails[2], dtppreparedate.Text);
                        }

                        //shreeshail is added above code

                        if (GLobalClass.iSuccess > 0)
                        {
                            fnLoadComments();
                            if (dtPMnameandHmname.Rows[0]["Department"].ToString() == "Testlab")
                            {
                                fnAlertMail(cmbEmailAlert.Text, txtRemarks.Text, lstusers);
                                GLobalClass.iSuccess = DAL.fnAddERPLog(0, PONo, login.GetUserDetails[2], dtppreparedate.Text, "PO Created", "PurchaseOrder");
                                MessageBox.Show("'" + PONo + "' request generated successfully. \nEmail alert sent to " + cmbEmailAlert.Text + "", "Success", 0, MessageBoxIcon.Information);
                                FormReload();
                            }
                            else if (dtPMnameandHmname.Rows[0]["Department"].ToString() != "Testlab")
                            {
                         //-       fnAlertMail("Veena", txtRemarks.Text, lstusers);
                     fnAlertMail("pavana", txtRemarks.Text, lstusers);
                                GLobalClass.iSuccess = DAL.fnAddERPLog(0, PONo, login.GetUserDetails[2], dtppreparedate.Text, "PO Created", "PurchaseOrder");
                                MessageBox.Show("'" + PONo + "' request generated successfully. \nEmail alert sent to Sourcing Manager.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                // GlobalClass.iSuccess = DAL.fnAddERPLog(0, sWONUmber, login.GetUserDetails[2], dtpWODate.Text, "Work Order Created", "WorkOrder");

                                FormReload();
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("Something went wrong please try to save the PO again", "Error", 0, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("PurchaseOrder_btnAuthorize_Click" + ex.Message);
                }
            }
            else
            {
                if (string.IsNullOrEmpty(cmbProjectcode.Text))
                {
                    MessageBox.Show("Please Select Project", "Error", 0, MessageBoxIcon.Error);
                }
                else if (cmbVendorName.SelectedIndex < 0)
                {
                    MessageBox.Show("Please Select the Vendor", "Error", 0, MessageBoxIcon.Error);
                    cmbVendorName.DroppedDown = true;
                }
                else if (dgbomlist.Rows.Count == 0)
                {
                    MessageBox.Show("Please select the items", "Error", 0, MessageBoxIcon.Error);
                }
                else if (!bDeliverDate)
                {
                    MessageBox.Show("Please select the delivery date", "Error", 0, MessageBoxIcon.Error);
                    dtpdelivery.Show();// = true;
                }
                else if (string.IsNullOrEmpty(txtRemarks.Text))
                {
                    MessageBox.Show("Please write the remarks", "Error", 0, MessageBoxIcon.Error);
                    txtRemarks.Focus();
                }
                else if (cmbEmailAlert.SelectedIndex < 0)
                {
                    MessageBox.Show("Please select email alert sender name", "Error", 0, MessageBoxIcon.Error);
                    cmbEmailAlert.DroppedDown = true;
                }

                //else if (cmbPOTerms.SelectedIndex < 0)
                //{
                //    MessageBox.Show("Please select PO terms", "Error", 0, MessageBoxIcon.Error);
                //    fnViewTerms();
                //    cmbPOTerms.DroppedDown = true;
                //}
                else if (!bProjectCost)
                {
                    MessageBox.Show("Capex project cost limit is exceeded.", "Error", 0, MessageBoxIcon.Error);
                }
                //else if (bSixMonths)
                //{

                //}

            }
        }


        //private void btnSave_Click(object sender, EventArgs e)
        //{
        //    int iLastPONo = 0;
        //    fnQunatityCheck();
        //    fnProjectAmountCheck();

        //    if (!string.IsNullOrEmpty(txtRemarks.Text) && !string.IsNullOrEmpty(cmbProjectcode.Text) && cmbVendorName.SelectedIndex >= 0 && dgbomlist.Rows.Count > 0 && !bSixMonths && bDeliverDate == true && cmbEmailAlert.SelectedIndex >= 0 && bProjectCost) //&& cmbPOTerms.SelectedIndex >= 0
        //    {
        //        try
        //        {
        //            sDBOMID = DAL.fnpurchaseOrder(null);
        //            if (!string.IsNullOrEmpty(sDBOMID))
        //            {
        //                sDBOMNo = sDBOMID.Substring(03, 08);
        //                iLastPONo = Convert.ToInt32(sDBOMNo);
        //            }
        //            if (chkWithoutBOM.CheckState == CheckState.Checked)
        //            {
        //                sWithoutBOM = "1";
        //            }
        //            else
        //            {
        //                sWithoutBOM = "0";
        //            }
        //            if (iLastPONo > 0)
        //            {
        //                iLastPONo++;
        //                PONo = ("PO/" + iLastPONo);
        //                cmbPONO.Text = PONo;

        //                fnAddedPOBOMItemPrice();

        //                foreach (DataGridViewRow row in dgbomlist.Rows)
        //                {
        //                    if (Convert.ToString(row.Cells["OtherProjects"].Value) == string.Empty || Convert.ToString(row.Cells["OtherProjects"].Value) == null)
        //                    {
        //                        row.Cells["OtherProjects"].Value = "";
        //                    }
        //                    GLobalClass.iSuccess = DAL.fnAddPurchaseOrder(Global.uINSERT, PONo, cmbProjectcode.Text, txtvendorcode.Text, lblPrepareBy.Text, lblPrepareBy.Text, row.Cells["ItemCode"].Value.ToString(), row.Cells["UOM"].Value.ToString(),
        //                                            Convert.ToDouble(row.Cells["ReqQty"].Value), Convert.ToDouble(row.Cells["RemQty"].Value), Convert.ToDouble(row.Cells["Unitprice"].Value),
        //                                            Convert.ToDouble(row.Cells["Amount"].Value), txtRemarks.Text, dtppreparedate.Text, dtppreparedate.Text, lblProjectStatus.Text,
        //                                            0, 0, 0, 0, 0, 0, 0, 0, Convert.ToDouble(row.Cells["SixMonths"].Value), Convert.ToDouble(row.Cells["TwelveMonths"].Value),
        //                                            Convert.ToDouble(row.Cells["dBOMQty"].Value), row.Cells["BOMProjectCodes"].Value.ToString(), dtpdelivery.Text,
        //                                            row.Cells["OtherProjects"].Value.ToString(), Convert.ToDouble(row.Cells["LatestPurchasePrice"].Value), sWithoutBOM, cmbcurrency.Text, Convert.ToDouble(curratetext.Text), PurchaseOrdervaliduptoDate.Text);

        //                }

        //                //shreeshail is added bellow code
        //                DataTable dtPMnameandHmname = DAL.fuHeadandmanager(login.GetUserDetails[2]).Tables[0];
        //                if (dtPMnameandHmname.Rows[0]["Department"].ToString() != "Testlab")
        //                {
        //                    GLobalClass.iSuccess = DAL.purchaseOrderApprovalfirstlevel(0, cmbPONO.Text, login.GetUserDetails[2], dtppreparedate.Text);
        //                }

        //                //shreeshail is added above code

        //                if (GLobalClass.iSuccess > 0)
        //                {
        //                    fnLoadComments();
        //                    if (dtPMnameandHmname.Rows[0]["Department"].ToString() == "Testlab")
        //                    {
        //                        fnAlertMail(cmbEmailAlert.Text, txtRemarks.Text, lstusers);
        //                        GLobalClass.iSuccess = DAL.fnAddERPLog(0, PONo, login.GetUserDetails[2], dtppreparedate.Text, "PO Created", "PurchaseOrder");
        //                        MessageBox.Show("'" + PONo + "' request generated successfully. \nEmail alert sent to " + cmbEmailAlert.Text + "", "Success", 0, MessageBoxIcon.Information);
        //                        FormReload();
        //                    }
        //                    else if(dtPMnameandHmname.Rows[0]["Department"].ToString() != "Testlab")
        //                    {
        //                        //fnAlertMail("Veena", txtRemarks.Text, lstusers);
        //                        fnAlertMail("BiSS", txtRemarks.Text, lstusers);
        //                        GLobalClass.iSuccess = DAL.fnAddERPLog(0, PONo, login.GetUserDetails[2], dtppreparedate.Text, "PO Created", "PurchaseOrder");
        //                        MessageBox.Show("'" + PONo + "' request generated successfully. \nEmail alert sent to Sourcing Manager.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //                        // GlobalClass.iSuccess = DAL.fnAddERPLog(0, sWONUmber, login.GetUserDetails[2], dtpWODate.Text, "Work Order Created", "WorkOrder");

        //                        FormReload();
        //                    }

        //                 }
        //            }
        //            else
        //            {
        //                MessageBox.Show("Something went wrong please try to save the PO again", "Error", 0, MessageBoxIcon.Error);
        //            }
        //        }
        //        catch (Exception ex)
        //        {
        //            MessageBox.Show("PurchaseOrder_btnAuthorize_Click" + ex.Message);
        //        }
        //    }
        //    else
        //    {
        //        if (string.IsNullOrEmpty(cmbProjectcode.Text))
        //        {
        //            MessageBox.Show("Please Select Project", "Error", 0, MessageBoxIcon.Error);
        //        }
        //        else if (cmbVendorName.SelectedIndex < 0)
        //        {
        //            MessageBox.Show("Please Select the Vendor", "Error", 0, MessageBoxIcon.Error);
        //            cmbVendorName.DroppedDown = true;
        //        }
        //        else if (dgbomlist.Rows.Count == 0)
        //        {
        //            MessageBox.Show("Please select the items", "Error", 0, MessageBoxIcon.Error);
        //        }
        //        else if (!bDeliverDate)
        //        {
        //            MessageBox.Show("Please select the delivery date", "Error", 0, MessageBoxIcon.Error);
        //            dtpdelivery.Show();// = true;
        //        }
        //        else if (string.IsNullOrEmpty(txtRemarks.Text))
        //        {
        //            MessageBox.Show("Please write the remarks", "Error", 0, MessageBoxIcon.Error);
        //            txtRemarks.Focus();
        //        }
        //        else if (cmbEmailAlert.SelectedIndex < 0)
        //        {
        //            MessageBox.Show("Please select email alert sender name", "Error", 0, MessageBoxIcon.Error);
        //            cmbEmailAlert.DroppedDown = true;
        //        }

        //        //else if (cmbPOTerms.SelectedIndex < 0)
        //        //{
        //        //    MessageBox.Show("Please select PO terms", "Error", 0, MessageBoxIcon.Error);
        //        //    fnViewTerms();
        //        //    cmbPOTerms.DroppedDown = true;
        //        //}
        //        else if (!bProjectCost)
        //        {
        //            MessageBox.Show("Capex project cost limit is exceeded.", "Error", 0, MessageBoxIcon.Error);
        //        }
        //        //else if (bSixMonths)
        //        //{

        //        //}

        //    }
        //}





        #endregion

        bool bSixMonths = false;
        DataTable dtPOAuthorisedforCost = new DataTable();
        bool bPOCompleteApproved = true;
        #region Excel PO Report
        private void btnprintpo_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(cmbPONO.Text))
            {
                //dtPOAuthorisedforCost = DAL.purchaseOrderApproved(1, cmbPONO.Text).Tables[0];
                GSTPurchaseOrder();
                // fnClear();
            }
            
            else
            {
                MessageBox.Show("Select PO Number to print purachase order", "Error", 0, MessageBoxIcon.Error);
            }
        }
        #endregion

        private void fnClear()
        {
            cmbVendorName.Enabled = false;
            dgbomlist.DataSource = null;
            txtAuthorizedBy.ResetText();
            cmbVendorName.SelectedIndex = -1;
            cmbProjectcode.Text = "";
            lblprojname.ResetText();
            cmbPONO.Text = "";
        }

        #region Purchase Order Form Reload
        private void FormReload()
        {
            this.Hide();
            Purchase_Order.PurchaseOrder PurchaseOrder = new Purchase_Order.PurchaseOrder();
            PurchaseOrder.Show();
        }
        #endregion

        #region Genarate PO to send vendors
        private void btnGenaratePO_Click(object sender, EventArgs e)
        {
            string selectedTransactionTypeCheck = cmbtransactiontype.Text.Trim().ToLower();
            //MessageBox.Show(selectedTransactionTypeCheck, "Transaction Type");
            //if(selectedTransactionTypeCheck == "international")
            //{
                btnPackingAmount_Click(null, null);
                btnAddTransport_Click(null, null);
                btnViewTax_Click(null, null);
           //}
            
            if (btnGenaratePO.Text == "Generate PO")
            {
                fnQunatityCheck();
                if (!string.IsNullOrEmpty(txtRemarks.Text) && !string.IsNullOrEmpty(cmbPONO.Text) && bDeliverDate == true && !string.IsNullOrEmpty(cmbProjectcode.Text) && !string.IsNullOrEmpty(cmbVendorName.Text) && !bSixMonths && cmbcurrency.SelectedIndex >= 0
                    && cmbDeliverTerms.SelectedIndex >= 0 && cmbPaymentTerms.SelectedIndex >= 0 && cmbIncoterm.SelectedIndex >= 0 && !string.IsNullOrEmpty(txtIncoterm.Text))
                {
                    try
                    {
                        //foreach (DataGridViewRow row in dgbomlist.Rows)
                        //{
                        //    if (!string.IsNullOrEmpty(row.Cells["ItemCode"].Value.ToString()))
                        //    {
                        //        if (row.Cells["dBOMQty"].Value == DBNull.Value)
                        //        {
                        //            row.Cells["dBOMQty"].Value = 0;
                        //        }
                        //        if (row.Cells["BOMProjectCodes"].Value == DBNull.Value)
                        //        {
                        //            row.Cells["BOMProjectCodes"].Value = "";
                        //        }
                        //        if ((row.Cells["OtherProjects"].Value) == DBNull.Value)
                        //        {
                        //            row.Cells["OtherProjects"].Value = "";
                        //        }

                        //        GLobalClass.iSuccess = DAL.fnAddPurchaseOrder(99, cmbPONO.Text, cmbProjectcode.Text, txtvendorcode.Text, null, login.GetUserDetails[2], row.Cells["ItemCode"].Value.ToString(), null,
                        //                                    Convert.ToDouble(row.Cells["ReqQty"].Value), Convert.ToDouble(row.Cells["RemQty"].Value), Convert.ToDouble(row.Cells["Unitprice"].Value),
                        //                                    Convert.ToDouble(row.Cells["Amount"].Value), txtRemarks.Text, dtppreparedate.Text, "", lblProjectStatus.Text,
                        //                                    Convert.ToDouble(row.Cells["IGSTRate"].Value), Convert.ToDouble(row.Cells["IGSTAmount"].Value), Convert.ToDouble(row.Cells["SGSTRate"].Value),
                        //                                    Convert.ToDouble(row.Cells["SGSTAmount"].Value), Convert.ToDouble(row.Cells["CGSTRate"].Value), Convert.ToDouble(row.Cells["CGSTAmount"].Value),
                        //                                    Convert.ToDouble(row.Cells["DiscRate"].Value), Convert.ToDouble(row.Cells["DiscAmount"].Value), 0, 0,
                        //                                    Convert.ToDouble(row.Cells["dBOMQty"].Value), row.Cells["BOMProjectCodes"].Value.ToString(), dtpdelivery.Text, row.Cells["OtherProjects"].Value.ToString(), 0, "", cmbcurrency.Text, Convert.ToDouble(curratetext.Text));

                        //        GLobalClass.iSuccess = DAL.fnAddPurchaseOrderPricing(1, cmbPONO.Text, row.Cells["ItemCode"].Value.ToString(), Convert.ToDouble(row.Cells["StandardCost"].Value.ToString()),
                        //                               Convert.ToDouble(row.Cells["DiffrenceinPer"].Value.ToString()), Convert.ToDouble(row.Cells["DiffrenceinRs"].Value.ToString()));

                        //    }
                        //}



                        // 1. Get vendor dataset
                        DataSet dsVendor = DAL.fnVedorList(txtvendorcode.Text);
                        if (dsVendor == null || dsVendor.Tables[0].Rows.Count == 0)
                        {
                            MessageBox.Show("Vendor details not found.");
                            return;
                        }

                        string vendorCountry = dsVendor.Tables[0].Rows[0]["Country"].ToString().Trim();
                        string selectedTransactionType = cmbtransactiontype.Text.Trim().ToLower();

                        // 2. Check transaction type matches country
                        if (vendorCountry.Equals("India", StringComparison.OrdinalIgnoreCase))
                        {
                            if (selectedTransactionType != "domestic")
                            {
                                MessageBox.Show("Transaction Type must be 'Domestic' for vendors from India.");
                                return;
                            }
                        }
                        else
                        {
                            if (selectedTransactionType != "international")
                            {
                                MessageBox.Show("Transaction Type must be 'International' for vendors outside India.");
                                return;
                            }
                        }

                     
                        fnUpdatePOtax(login.GetUserDetails[2], dtppreparedate.Text);
                        dtPOReport = DAL.POReport(cmbPONO.Text).Tables[0];
                        if (dtPOReport.Rows.Count > 0)
                        {
                            GLobalClass.iSuccess = DAL.fnAddPOReport(Global.uUPDATE, cmbPONO.Text, cmbtransactiontype.Text, cmbNatureofTransaction.Text, cmbNatureofSupply.Text, txtShippedFrom.Text,
                                txtShippedStateCode.Text, txtShippedGSTIn.Text, Convert.ToDouble(txtInvoiceTotal.Text), Convert.ToDouble(txtAmountPaid.Text), Convert.ToDouble(txtBalanceDue.Text), txtShippedCountry.Text, cmbDeliverTerms.Text, cmbPaymentTerms.Text, txtShippedFrom1.Text, cmbIncoterm.Text, txtIncoterm.Text);
                        }
                        else
                        {
                            GLobalClass.iSuccess = DAL.fnAddPOReport(Global.uINSERT, cmbPONO.Text, cmbtransactiontype.Text, cmbNatureofTransaction.Text, cmbNatureofSupply.Text, txtShippedFrom.Text,
                            txtShippedStateCode.Text, txtShippedGSTIn.Text, Convert.ToDouble(txtInvoiceTotal.Text), Convert.ToDouble(txtAmountPaid.Text), Convert.ToDouble(txtBalanceDue.Text), txtShippedCountry.Text, cmbDeliverTerms.Text, cmbPaymentTerms.Text, txtShippedFrom1.Text, cmbIncoterm.Text, txtIncoterm.Text);
                        }
                        if (chkWithoutBOM.Checked == false)
                        {
                            // fnAddedPOBOMItemPrice();

                            fnAddedPOBOMItemPriceUpdate();
                        }
                        if (GLobalClass.iSuccess > 0)
                        {
                            GLobalClass.iSuccess = DAL.fnAddERPLog(0, cmbPONO.Text, login.GetUserDetails[2], dtppreparedate.Text, "PO Generated", "PurchaseOrder");
                            MessageBox.Show("PO successfully generated " + cmbPONO.Text + "", "Success", 0, MessageBoxIcon.Information);
                            btnprintpo_Click(sender, e);
                            
                           
                            //string lstusers2 = ;
                            //fnApprovetMailPMalert("shreeshail", txtRemarks.Text, lstusers2, null);
                            //shreeshail is added code above

                            sPONumber = null;
                            FormReload();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("PurchaseOrder_btnReport_Click   " + ex.Message);
                    }
                }
                
                else
                {
                    
                    if (string.IsNullOrEmpty(cmbPONO.Text))
                    {
                        MessageBox.Show("Select PO Number to generate purachase order", "Error", 0, MessageBoxIcon.Error);
                    }

                    else if (string.IsNullOrEmpty(txtRemarks.Text))
                    {
                        MessageBox.Show("Write the remarks", "Error", 0, MessageBoxIcon.Error);
                        txtRemarks.Focus();
                    }
                    else if (string.IsNullOrEmpty(cmbVendorName.Text))
                    {
                        MessageBox.Show("Select the Vendor", "Error", 0, MessageBoxIcon.Error);
                    }
                    else if (string.IsNullOrEmpty(cmbProjectcode.Text))
                    {
                        MessageBox.Show("Select the Project", "Error", 0, MessageBoxIcon.Error);
                    }
                    else if (bDeliverDate != true)
                    {
                        MessageBox.Show("Please select the delivery date", "Error", 0, MessageBoxIcon.Error);
                    }
                    else if (cmbcurrency.SelectedIndex < 0)
                    {
                        MessageBox.Show("Please select the Currency", "Error", 0, MessageBoxIcon.Error);
                    }
                    else if (cmbPaymentTerms.SelectedIndex < 0)
                    {
                        MessageBox.Show("Please select the Payment Term", "Error", 0, MessageBoxIcon.Error);
                    }
                    else if (cmbDeliverTerms.SelectedIndex < 0)
                    {
                        MessageBox.Show("Please select the Deliver Term", "Error", 0, MessageBoxIcon.Error);
                    }
                    else if (cmbIncoterm.SelectedIndex < 0)
                    {
                        MessageBox.Show("Please select the Inco term", "Error", 0, MessageBoxIcon.Error);
                    }
                    else if (string.IsNullOrEmpty(txtIncoterm.Text))
                    {
                        MessageBox.Show("Enter the inco term  details", "Error", 0, MessageBoxIcon.Error);
                    }
                    // Check if Purchase Order valid upto date is today and visible
                    if((PurchaseOrdervaliduptoDate.Value.Date == DateTime.Today) && PurchaseOrdervaliduptoDate.Visible==true && btnGenaratePO.Visible==true)
                    {
                        MessageBox.Show("Please enter a valid future Expiry Date", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        PurchaseOrdervaliduptoDate.Focus();
                    }
                    // Check if selected date is in the past and Purchase Order valid upto date is visible
                    else if ((PurchaseOrdervaliduptoDate.Value.Date < DateTime.Today) && PurchaseOrdervaliduptoDate.Visible && btnGenaratePO.Visible == true)
                    {
                        MessageBox.Show("Please enter a valid future Expiry Date", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        PurchaseOrdervaliduptoDate.Focus();
                    }



                }
            }
            else if (btnGenaratePO.Text == "Update PO")
            {
                SQLCon = new SqlConnection(DataAccessLayer.cs);
                SqlCommand cmd4 = new SqlCommand("select COUNT(InwardDocumentNo) from SecurityInward where InwardDocumentNo='" + cmbPONO.Text + "'", SQLCon);
                SQLCon.Open();
                Int32 count = (Int32)cmd4.ExecuteScalar();
                SQLCon.Close();
                if (count == 0)
                {
                    foreach (DataGridViewRow row in dgbomlist.Rows)
                    {
                        if (!string.IsNullOrEmpty(row.Cells["ItemCode"].Value.ToString()))
                        {
                            //shreeshail added PurchaseOrdervaliduptoDate
                            GLobalClass.iSuccess = DAL.fnAddPurchaseOrder(101, cmbPONO.Text, cmbProjectcode.Text, txtvendorcode.Text, null, login.GetUserDetails[2], row.Cells["ItemCode"].Value.ToString(), null,
                                                           Convert.ToDouble(row.Cells["ReqQty"].Value), Convert.ToDouble(row.Cells["RemQty"].Value), Convert.ToDouble(row.Cells["Unitprice"].Value),
                                                           Convert.ToDouble(row.Cells["Amount"].Value), txtRemarks.Text, dtppreparedate.Text, "", lblProjectStatus.Text,
                                                           Convert.ToDouble(row.Cells["IGSTRate"].Value), Convert.ToDouble(row.Cells["IGSTAmount"].Value), Convert.ToDouble(row.Cells["SGSTRate"].Value),
                                                           Convert.ToDouble(row.Cells["SGSTAmount"].Value), Convert.ToDouble(row.Cells["CGSTRate"].Value), Convert.ToDouble(row.Cells["CGSTAmount"].Value),
                                                           Convert.ToDouble(row.Cells["DiscRate"].Value), Convert.ToDouble(row.Cells["DiscAmount"].Value), 0, 0,
                                                           Convert.ToDouble(row.Cells["dBOMQty"].Value), row.Cells["BOMProjectCodes"].Value.ToString(), dtpdelivery.Text, row.Cells["OtherProjects"].Value.ToString(), 0, "", "", 0, PurchaseOrdervaliduptoDate.Text);

                            GLobalClass.iSuccess = DAL.fnAddPurchaseOrderPricing(1, cmbPONO.Text, row.Cells["ItemCode"].Value.ToString(), Convert.ToDouble(row.Cells["StandardCost"].Value.ToString()),
                                                Convert.ToDouble(row.Cells["DiffrenceinPer"].Value.ToString()), Convert.ToDouble(row.Cells["DiffrenceinRs"].Value.ToString()));
                        }

                    }
                    GLobalClass.iSuccess = DAL.purchaseOrderApproval(10, cmbPONO.Text, dtppreparedate.Text, login.GetUserDetails[2], txtRemarks.Text);
                    GLobalClass.iStatus = DAL.fnAddPurchaseOrderBOM(4, cmbPONO.Text, "", "", "", 0, 0, 0, "");
                    if (chkWithoutBOM.Checked == false)
                    {
                        //  fnAddedPOBOMItemPrice();
                        fnAddedPOBOMItemPriceUpdate();
                    }
                    CreateUpdateEMail(cmbEmailAlert.Text, txtRemarks.Text, "Clear");
                    MessageBox.Show("PO " + cmbPONO.Text + " updated successfully", "Success", 0, MessageBoxIcon.Information);
                    FormReload();
                }
                else
                {
                    SQLCon = new SqlConnection(DataAccessLayer.cs);
                    SqlCommand cmd6 = new SqlCommand("UPDATE PurchaseOrder SET POUpdate = '0', POUpdateRequestBy = null, POUpdateRemarks = null WHERE DBOMNo='" + cmbPONO.Text + "'", SQLCon);
                    SQLCon.Open();
                    cmd6.ExecuteNonQuery();
                    SQLCon.Close();
                    MessageBox.Show("The selected'" + cmbPONO.Text + "' already inwarded. PO details not updated.", "Error", 0, MessageBoxIcon.Error);
                }

            }
        }
        #endregion

        #region PO quantity cost validating function
        private void Control_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (dgbomlist.CurrentCell.OwningColumn.Name == "OtherProjects")
            {

            }
            else
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
                {
                    e.Handled = true;
                }
                // only allow one decimal point
                if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
                {
                    e.Handled = true;
                }
            }
        }

        private void dgbomlist_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
            }
        }
        double oldvalue;
        private void dgbomlist_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {

        }

        #endregion

        #region CompleteView of PO Function
        private void btncopmletepoview_Click(object sender, EventArgs e)
        {
            sPONumber = string.Empty;
            this.Hide();
            pleasewaitform pleaseWait = new pleasewaitform();
            pleaseWait.Show(); Application.DoEvents();
            POfullView POfullView = new POfullView();
            POfullView.Show();
            pleaseWait.Hide();
        }
        #endregion
        #region ItemCode Charater Check
        private void txtItemCode_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void txtItemDescription_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar == '%'))
            {
                e.Handled = true;
            }
        }
        #endregion

        DataTable dtPackingForwardingTax = new DataTable();
        private void btnPackingAmount_Click(object sender, EventArgs e)
        {
            dtPackingForwardingTax = DAL.PackingForwardingTax(cmbPONO.Text, "Packing & Forwarding").Tables[0];

            if (dtPackingForwardingTax.Rows.Count > 0)
            {
                dtPackingForwardingTax = DAL.PackingForwardingTax(cmbPONO.Text, null).Tables[0];
                dgPackingTaxes.AutoGenerateColumns = false;
                dgPackingTaxes.DataSource = dtPackingForwardingTax;
                dgPackingTaxes.Visible = true;
                btnViewTax.Text = "Close Tax";
            }
            else
            {
                GLobalClass.iSuccess = DAL.fnAddPOPackingForward(Global.uINSERT, cmbPONO.Text, "Packing & Forwarding", 0, 0, 0, 0, 0, 0, 0);
                dtPackingForwardingTax = DAL.PackingForwardingTax(cmbPONO.Text, null).Tables[0];
                if (dtPackingForwardingTax.Rows.Count > 0)
                {
                    dgPackingTaxes.AutoGenerateColumns = false;
                    dgPackingTaxes.DataSource = dtPackingForwardingTax;
                    dgPackingTaxes.Visible = true;
                    btnViewTax.Text = "Close Tax";
                }
            }

        }

        private void txtAmountPaid_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            else if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
            else
            {
                if (!string.IsNullOrEmpty(txtInvoiceTotal.Text) && !string.IsNullOrEmpty(txtAmountPaid.Text))
                {
                    txtBalanceDue.Text = (Convert.ToDouble(txtInvoiceTotal.Text) - Convert.ToDouble(txtAmountPaid.Text)).ToString();
                }
            }
        }

        private void txtAmountPaid_KeyUp(object sender, KeyEventArgs e)
        {
            if (!string.IsNullOrEmpty(txtInvoiceTotal.Text) && !string.IsNullOrEmpty(txtAmountPaid.Text))
            {
                txtBalanceDue.Text = (Convert.ToDouble(txtInvoiceTotal.Text) - Convert.ToDouble(txtAmountPaid.Text)).ToString();
            }
        }

        private void txtAmountPaid_Validated(object sender, EventArgs e)
        {
            if (((TextBox)sender).Text == "")
            {
                ((TextBox)sender).Text = "0";
                txtBalanceDue.Text = (Convert.ToDouble(txtInvoiceTotal.Text) - Convert.ToDouble(txtAmountPaid.Text)).ToString();
            }
        }

        private void dgPackingTaxes_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show(" dgPackingTaxes_EditingControlShowing   " + ex.Message);
            }
        }
        double dOldTaxRate;
        private void dgPackingTaxes_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgPackingTaxes.CurrentCell.OwningColumn.Index == 1)
            {
                dOldTaxRate = Convert.ToDouble(dgPackingTaxes.CurrentCell.Value);
            }
        }
        //GLobalClass.iSuccess = DAL.fnAddPOPackingForward(Global.uDELETE, cmbPONO.Text, dgbomlist.CurrentRow.Cells["ItemDescription"].Value.ToString(), 0, 0, 0, 0, 0, 0);
        private void dgPackingTaxes_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (dgPackingTaxes.CurrentCell.Value != null)
            {
                if (!string.IsNullOrEmpty(dgPackingTaxes.CurrentCell.Value.ToString()) && (dgPackingTaxes.CurrentCell.Value.ToString() != sDot))
                {
                    switch (dgPackingTaxes.CurrentCell.OwningColumn.Index)
                    {
                        case 1:

                            dgPackingTaxes.CurrentRow.Cells[3].Value = (Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[1].Value) / 100) * Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[2].Value);
                            dgPackingTaxes.CurrentRow.Cells[5].Value = (Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[1].Value) / 100) * Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[4].Value);
                            dgPackingTaxes.CurrentRow.Cells[7].Value = (Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[1].Value) / 100) * Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[6].Value);

                            break;

                        case 2:
                            dgPackingTaxes.CurrentRow.Cells[3].Value = (Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[1].Value) / 100) * Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[2].Value);
                            break;
                        case 4:
                            dgPackingTaxes.CurrentRow.Cells[5].Value = (Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[1].Value) / 100) * Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[4].Value);
                            break;
                        case 6:
                            dgPackingTaxes.CurrentRow.Cells[7].Value = (Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[1].Value) / 100) * Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[6].Value);
                            break;

                    }

                    GLobalClass.iSuccess = DAL.fnAddPOPackingForward(Global.uUPDATE, cmbPONO.Text, dgPackingTaxes.CurrentRow.Cells[0].Value.ToString(), Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[2].Value), Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[3].Value), Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[4].Value), Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[5].Value), Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[6].Value),
                                           Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[7].Value), Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[1].Value));
                }
                else
                {
                    if (dgPackingTaxes.CurrentCell.OwningColumn.Index == 1)
                    {
                        dgPackingTaxes.CurrentCell.Value = dOldTaxRate;
                    }
                    else
                    {
                        dgPackingTaxes.CurrentCell.Value = 0;
                    }
                }
            }
        }

        private void btnViewTax_Click(object sender, EventArgs e)
        {
            if (dgPackingTaxes.Visible == true)
            {
                dgPackingTaxes.Visible = false;
                btnViewTax.Text = "View Tax";
            }
            else
            {
                dgPackingTaxes.Visible = true;
                btnViewTax.Text = "Close Tax";
            }
        }

        private void btnAddTransport_Click(object sender, EventArgs e)
        {
            dtPackingForwardingTax = DAL.PackingForwardingTax(cmbPONO.Text, "Transportation / Freight").Tables[0];

            if (dtPackingForwardingTax.Rows.Count > 0)
            {
                dtPackingForwardingTax = DAL.PackingForwardingTax(cmbPONO.Text, null).Tables[0];
                dgPackingTaxes.AutoGenerateColumns = false;
                dgPackingTaxes.DataSource = dtPackingForwardingTax;
                dgPackingTaxes.Visible = true;
                btnViewTax.Text = "Close Tax";
            }
            else
            {
                GLobalClass.iSuccess = DAL.fnAddPOPackingForward(Global.uINSERT, cmbPONO.Text, "Transportation / Freight", 0, 0, 0, 0, 0, 0, 0);
                dtPackingForwardingTax = DAL.PackingForwardingTax(cmbPONO.Text, null).Tables[0];
                if (dtPackingForwardingTax.Rows.Count > 0)
                {
                    dgPackingTaxes.AutoGenerateColumns = false;
                    dgPackingTaxes.DataSource = dtPackingForwardingTax;
                    dgPackingTaxes.Visible = true;
                    btnViewTax.Text = "Close Tax";
                }
            }
        }

        private void dgPackingTaxes_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (dgbomlist.Rows.Count > 0)
                {
                    DialogResult DR = MessageBox.Show("Do you want to delete selected row", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (DR == DialogResult.Yes)
                    {
                        GLobalClass.iSuccess = DAL.fnAddPOPackingForward(Global.uDELETE, cmbPONO.Text, dgPackingTaxes.CurrentRow.Cells[0].Value.ToString(), 0, 0, 0, 0, 0, 0, 0);

                        dgPackingTaxes.Rows.RemoveAt(dgPackingTaxes.Rows.IndexOf(dgPackingTaxes.CurrentRow));

                    }
                }
            }
        }

        private void chkItemCode_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemCode.CheckState == CheckState.Checked)
            {
                chkItemDesc.Checked = false;

                llbViewPOGeneralTerms.Visible = true;
            }
        }

        private void chkItemDesc_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemDesc.CheckState == CheckState.Checked)
            {
                chkItemCode.Checked = false;
            }
        }

        private void fnDeleteAddedPOItem()
        {
            if (Convert.ToDouble(dgbomlist.CurrentRow.Cells["dBOMQty"].Value) > 0)
            {
                // pnBOMQtyCheck.Visible = true;
                dtBOMProjectList = DAL.fnBOMItemPurchase(dgbomlist.CurrentRow.Cells["ItemCode"].Value.ToString(), " ").Tables[0];
                dgvBOMQty.AutoGenerateColumns = false;
                dgvBOMQty.DataSource = dtBOMProjectList;
                dBOMTotalQuantity = 0;
                if (!string.IsNullOrEmpty(dgbomlist.CurrentRow.Cells["BOMProjectCodes"].Value.ToString()))
                {
                    dBOMTotalQuantity = Convert.ToDouble(dgbomlist.CurrentRow.Cells["ReqQty"].Value);
                    lstBOMProjects.Clear();
                    lstBOMProjects = dgbomlist.CurrentRow.Cells["BOMProjectCodes"].Value.ToString().Split(',').ToList();
                    DataTable dtEnterdQty = new DataTable();
                    dtEnterdQty = convertStringToDataTable(dgbomlist.CurrentRow.Cells["BOMProjectCodes"].Value.ToString());

                    for (int k = 0; k < dtEnterdQty.Rows.Count; k++)
                    {
                        for (int i = 0; i < dtBOMProjectList.Rows.Count; i++)
                        {
                            if (dtEnterdQty.Rows[k]["ProjectCode"].ToString().Trim() == dtBOMProjectList.Rows[i]["ProjectCode"].ToString().Trim() && dtEnterdQty.Rows[k]["ProductNo"].ToString().Trim() == dtBOMProjectList.Rows[i]["ProductNo"].ToString().Trim())
                            {
                                {
                                    int nIndex = dtBOMProjectList.Rows.IndexOf(dtBOMProjectList.Rows[i]);
                                    DataRow dr1 = dtBOMProjectList.Rows[nIndex];
                                    dr1["ReqQty"] = dtEnterdQty.Rows[k]["ReqQty"].ToString();
                                    break;
                                }
                            }
                        }
                    }
                }
                foreach (DataGridViewRow row in dgvBOMQty.Rows)
                {
                    row.Cells[7].Value = row.Cells[8].Value;
                }

                foreach (DataGridViewRow dr in dgvBOMQty.Rows)
                {
                    if (Convert.ToDouble(dr.Cells[8].Value) > 0)
                    {
                        if (Convert.ToDouble(dr.Cells[5].Value) == 0)
                        {
                            //GLobalClass.iStatus = DAL.fnUpdateMachinBOMPO(1, dr.Cells[8].Value.ToString(), dgbomlist.CurrentRow.Cells["ItemCode"].Value.ToString(),
                            //                                                 dr.Cells[0].Value.ToString(), dr.Cells[2].Value.ToString());

                        }
                        else
                        {
                            GLobalClass.iStatus = DAL.fnUpdateMachinBOMPO(2, (Convert.ToDouble(dr.Cells[7].Value)).ToString(), dgbomlist.CurrentRow.Cells["ItemCode"].Value.ToString(),
                                                                                                           dr.Cells[0].Value.ToString(), dr.Cells[2].Value.ToString());
                            //GLobalClass.iStatus = DAL.fnUpdateMachinBOMPO(1, (Convert.ToDouble(dr.Cells[8].Value)).ToString(), dgbomlist.CurrentRow.Cells["ItemCode"].Value.ToString(),
                            //                                                                               dr.Cells[0].Value.ToString(), dr.Cells[2].Value.ToString());
                        }

                    }
                }

            }
        }

        private void fnAddedPOBOMItemPrice()
        {
            foreach (DataGridViewRow row in dgbomlist.Rows)
            {
                if (Convert.ToDouble(row.Cells["dBOMQty"].Value) > 0)
                {
                    dtBOMProjectList = DAL.fnBOMItemPurchase(row.Cells["ItemCode"].Value.ToString(), " ").Tables[0];
                    dgvBOMQty.AutoGenerateColumns = false;
                    dgvBOMQty.DataSource = dtBOMProjectList;
                    dBOMTotalQuantity = 0;
                    if (!string.IsNullOrEmpty(row.Cells["BOMProjectCodes"].Value.ToString()))
                    {
                        dBOMTotalQuantity = Convert.ToDouble(row.Cells["ReqQty"].Value);
                        lstBOMProjects.Clear();
                        lstBOMProjects = row.Cells["BOMProjectCodes"].Value.ToString().Split(',').ToList();
                        DataTable dtEnterdQty = new DataTable();
                        dtEnterdQty = convertStringToDataTable(row.Cells["BOMProjectCodes"].Value.ToString());

                        for (int k = 0; k < dtEnterdQty.Rows.Count; k++)
                        {
                            for (int i = 0; i < dtBOMProjectList.Rows.Count; i++)
                            {
                                if (dtEnterdQty.Rows[k]["ProjectCode"].ToString().Trim() == dtBOMProjectList.Rows[i]["ProjectCode"].ToString().Trim() && dtEnterdQty.Rows[k]["ProductNo"].ToString().Trim() == dtBOMProjectList.Rows[i]["ProductNo"].ToString().Trim())
                                {
                                    {
                                        int nIndex = dtBOMProjectList.Rows.IndexOf(dtBOMProjectList.Rows[i]);
                                        DataRow dr1 = dtBOMProjectList.Rows[nIndex];
                                        dr1["ReqQty"] = dtEnterdQty.Rows[k]["ReqQty"].ToString();
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    foreach (DataGridViewRow row2 in dgvBOMQty.Rows)
                    {
                        row2.Cells[7].Value = row2.Cells[8].Value;
                    }
                }

                foreach (DataGridViewRow dr in dgvBOMQty.Rows)
                {
                    if (Convert.ToDouble(dr.Cells[8].Value) > 0)
                    {
                        //if (Convert.ToDouble(dr.Cells[5].Value) > 0)
                        //{
                        GLobalClass.iStatus = DAL.fnAddPurchaseOrderBOM(1, cmbPONO.Text, dr.Cells[0].Value.ToString(), dr.Cells[2].Value.ToString(), row.Cells["ItemCode"].Value.ToString(),
                                                                     Convert.ToDouble(row.Cells["Unitprice"].Value), Convert.ToDouble(dr.Cells[7].Value), Convert.ToDouble(dr.Cells[6].Value), login.GetUserDetails[2].ToString());
                        //}
                    }
                }
            }
        }



        //---added by bhavya-------------------------------

        private void fnAddedPOBOMItemPriceUpdate()
        {
            foreach (DataGridViewRow row in dgbomlist.Rows)
            {
                if (Convert.ToDouble(row.Cells["dBOMQty"].Value) > 0)
                {
                    dtBOMProjectList = DAL.fnBOMItemPurchase(row.Cells["ItemCode"].Value.ToString(), " ").Tables[0];
                    dgvBOMQty.AutoGenerateColumns = false;
                    dgvBOMQty.DataSource = dtBOMProjectList;
                    dBOMTotalQuantity = 0;
                    if (!string.IsNullOrEmpty(row.Cells["BOMProjectCodes"].Value.ToString()))
                    {
                        dBOMTotalQuantity = Convert.ToDouble(row.Cells["ReqQty"].Value);
                        lstBOMProjects.Clear();
                        lstBOMProjects = row.Cells["BOMProjectCodes"].Value.ToString().Split(',').ToList();
                        DataTable dtEnterdQty = new DataTable();
                        dtEnterdQty = convertStringToDataTable(row.Cells["BOMProjectCodes"].Value.ToString());

                        for (int k = 0; k < dtEnterdQty.Rows.Count; k++)
                        {
                            for (int i = 0; i < dtBOMProjectList.Rows.Count; i++)
                            {
                                if (dtEnterdQty.Rows[k]["ProjectCode"].ToString().Trim() == dtBOMProjectList.Rows[i]["ProjectCode"].ToString().Trim() && dtEnterdQty.Rows[k]["ProductNo"].ToString().Trim() == dtBOMProjectList.Rows[i]["ProductNo"].ToString().Trim())
                                {
                                    {
                                        int nIndex = dtBOMProjectList.Rows.IndexOf(dtBOMProjectList.Rows[i]);
                                        DataRow dr1 = dtBOMProjectList.Rows[nIndex];
                                        dr1["ReqQty"] = dtEnterdQty.Rows[k]["ReqQty"].ToString();
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    foreach (DataGridViewRow row2 in dgvBOMQty.Rows)
                    {
                        row2.Cells[7].Value = row2.Cells[8].Value;
                    }
                }
                //bhavya testing
                //foreach (DataGridViewRow dr in dgvBOMQty.Rows)
                //{
                //    if (Convert.ToDouble(dr.Cells[8].Value) > 0)
                //    {
                //        //if (Convert.ToDouble(dr.Cells[5].Value) > 0)
                //        //{
                //        GLobalClass.iStatus = DAL.fnAddPurchaseOrderBOM(5, cmbPONO.Text, dr.Cells[0].Value.ToString(), dr.Cells[2].Value.ToString(), row.Cells["ItemCode"].Value.ToString(),
                //                                                     Convert.ToDouble(row.Cells["Unitprice"].Value), Convert.ToDouble(dr.Cells[7].Value), Convert.ToDouble(dr.Cells[6].Value), login.GetUserDetails[2].ToString());
                //        //}
                //    }
                //}--------bhavya testing

                foreach (DataGridViewRow dr in dgvBOMQty.Rows)
                {
                    if (Convert.ToDouble(dr.Cells[8].Value) > 0)
                    {
                        // Check if the item already exists in the database
                        bool exists = DAL.CheckIfItemExists(cmbPONO.Text, row.Cells["ItemCode"].Value.ToString(), dr.Cells[0].Value.ToString(), dr.Cells[2].Value.ToString());

                        if (exists)
                        {
                            // If the item exists, update it
                            GLobalClass.iStatus = DAL.fnAddPurchaseOrderBOM(5, cmbPONO.Text, dr.Cells[0].Value.ToString(), dr.Cells[2].Value.ToString(), row.Cells["ItemCode"].Value.ToString(),
                                                                             Convert.ToDouble(row.Cells["Unitprice"].Value), Convert.ToDouble(dr.Cells[7].Value), Convert.ToDouble(dr.Cells[6].Value), login.GetUserDetails[2].ToString());
                        }
                        else
                        {
                            // If the item doesn't exist, insert it
                            GLobalClass.iStatus = DAL.fnAddPurchaseOrderBOM(1, cmbPONO.Text, dr.Cells[0].Value.ToString(), dr.Cells[2].Value.ToString(), row.Cells["ItemCode"].Value.ToString(),
                                                                             Convert.ToDouble(row.Cells["Unitprice"].Value), Convert.ToDouble(dr.Cells[7].Value), Convert.ToDouble(dr.Cells[6].Value), login.GetUserDetails[2].ToString());
                        }
                    }
                    else if (Convert.ToDouble(dr.Cells[8].Value) <= 0)
                    {
                        // If the item exists, update it
                        GLobalClass.iStatus = DAL.fnAddPurchaseOrderBOM(3, cmbPONO.Text, dr.Cells[0].Value.ToString(), dr.Cells[2].Value.ToString(), row.Cells["ItemCode"].Value.ToString(),
                                                                         Convert.ToDouble(row.Cells["Unitprice"].Value), Convert.ToDouble(dr.Cells[7].Value), Convert.ToDouble(dr.Cells[6].Value), login.GetUserDetails[2].ToString());

                    }
                }

            }
        }

        private bool CheckIfItemExists(string PONumber, string ItemCode, string ProjectCode, string ProductNo)
        {
            // Query the database to check if the item exists
            string query = "SELECT COUNT(1) FROM PurchaseOrderBOM WHERE PONumber = @PONumber AND ItemCode = @ItemCode AND ProjectCode = @ProjectCode AND ProductNo = @ProductNo";
            using (SqlCommand cmd = new SqlCommand(query, SQLCon))
            {
                cmd.Parameters.AddWithValue("@PONumber", PONumber);
                cmd.Parameters.AddWithValue("@ItemCode", ItemCode);
                cmd.Parameters.AddWithValue("@ProjectCode", ProjectCode);
                cmd.Parameters.AddWithValue("@ProductNo", ProductNo);

                SQLCon.Open();
                int count = Convert.ToInt32(cmd.ExecuteScalar());
                SQLCon.Close();

                return count > 0;
            }
        }


   



        /// </summary>


        private void fnRemoveAddedPOItem()
        {
            foreach (DataGridViewRow row in dgbomlist.Rows)
            {

                //GLobalClass.iSuccess = DAL.fnAddPurchaseOrder(Global.uINSERT, PONo, cmbProjectcode.Text, txtvendorcode.Text, lblPrepareBy.Text,
                //                        login.GetUserDetails[14], row.Cells["ItemCode"].Value.ToString(), row.Cells["UOM"].Value.ToString(),
                //                        Convert.ToDouble(row.Cells["ReqQty"].Value), Convert.ToDouble(row.Cells["RemQty"].Value), Convert.ToDouble(row.Cells["Unitprice"].Value),
                //                        Convert.ToDouble(row.Cells["Amount"].Value), txtRemarks.Text, dtppreparedate.Text, dtppreparedate.Text, lblProjectStatus.Text,
                //                        0, 0, 0, 0, 0, 0, 0, 0, Convert.ToDouble(row.Cells["SixMonths"].Value), Convert.ToDouble(row.Cells["TwelveMonths"].Value),
                //                        Convert.ToDouble(row.Cells["dBOMQty"].Value), row.Cells["BOMProjectCodes"].Value.ToString(), dtpdelivery.Text,
                //                        row.Cells["OtherProjects"].Value.ToString(), Convert.ToDouble(row.Cells["LatestPurchasePrice"].Value));

                if (Convert.ToDouble(row.Cells["dBOMQty"].Value) > 0)
                {
                    //  pnBOMQtyCheck.Visible = true;
                    dtBOMProjectList = DAL.fnBOMItemPurchase(row.Cells["ItemCode"].Value.ToString(), " ").Tables[0];
                    dgvBOMQty.AutoGenerateColumns = false;
                    dgvBOMQty.DataSource = dtBOMProjectList;
                    dBOMTotalQuantity = 0;
                    if (!string.IsNullOrEmpty(row.Cells["BOMProjectCodes"].Value.ToString()))
                    {
                        dBOMTotalQuantity = Convert.ToDouble(row.Cells["ReqQty"].Value);
                        lstBOMProjects.Clear();
                        lstBOMProjects = row.Cells["BOMProjectCodes"].Value.ToString().Split(',').ToList();
                        DataTable dtEnterdQty = new DataTable();
                        dtEnterdQty = convertStringToDataTable(row.Cells["BOMProjectCodes"].Value.ToString());

                        for (int k = 0; k < dtEnterdQty.Rows.Count; k++)
                        {
                            for (int i = 0; i < dtBOMProjectList.Rows.Count; i++)
                            {
                                if (dtEnterdQty.Rows[k]["ProjectCode"].ToString().Trim() == dtBOMProjectList.Rows[i]["ProjectCode"].ToString().Trim() && dtEnterdQty.Rows[k]["ProductNo"].ToString().Trim() == dtBOMProjectList.Rows[i]["ProductNo"].ToString().Trim())
                                {
                                    {
                                        int nIndex = dtBOMProjectList.Rows.IndexOf(dtBOMProjectList.Rows[i]);
                                        DataRow dr1 = dtBOMProjectList.Rows[nIndex];
                                        dr1["ReqQty"] = dtEnterdQty.Rows[k]["ReqQty"].ToString();
                                        break;
                                    }
                                }
                            }
                        }

                        //foreach (DataGridViewRow row1 in dgvBOMQty.Rows)
                        //{
                        //    row1.Cells[7].Value = row1.Cells[8].Value;
                        //}
                    }
                    //else
                    //{
                    foreach (DataGridViewRow row2 in dgvBOMQty.Rows)
                    {
                        row2.Cells[7].Value = row2.Cells[8].Value;
                    }
                    // }

                }

                foreach (DataGridViewRow dr in dgvBOMQty.Rows)
                {
                    if (Convert.ToDouble(dr.Cells[8].Value) > 0)
                    {
                        if (Convert.ToDouble(dr.Cells[5].Value) == 0)
                        {
                            //GLobalClass.iStatus = DAL.fnUpdateMachinBOMPO(1, dr.Cells[8].Value.ToString(), dgbomlist.CurrentRow.Cells["ItemCode"].Value.ToString(),
                            //                                                 dr.Cells[0].Value.ToString(), dr.Cells[2].Value.ToString());

                        }
                        else
                        {
                            GLobalClass.iStatus = DAL.fnUpdateMachinBOMPO(2, (Convert.ToDouble(dr.Cells[7].Value)).ToString(), row.Cells["ItemCode"].Value.ToString(),
                                                                                                           dr.Cells[0].Value.ToString(), dr.Cells[2].Value.ToString());
                            //GLobalClass.iStatus = DAL.fnUpdateMachinBOMPO(1, (Convert.ToDouble(dr.Cells[8].Value)).ToString(), dgbomlist.CurrentRow.Cells["ItemCode"].Value.ToString(),
                            //                                                                               dr.Cells[0].Value.ToString(), dr.Cells[2].Value.ToString());
                        }
                    }
                }
            }
        }


        private void dgbomlist_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (chkPrintPO.Checked != true && chkWithoutBOM.Checked != true && dgbomlist.Rows.Count > 0)
            {
                pnBOMQtyCheck.Visible = false;
                if (dgbomlist.CurrentCell.OwningColumn.Name == "BOMbutton" && dgbomlist.CurrentRow.Cells["dBOMQty"].Value != DBNull.Value)
                {
                    if (Convert.ToDouble(dgbomlist.CurrentRow.Cells["dBOMQty"].Value) > 0)
                    {
                        pnBOMQtyCheck.Visible = true;
                        dtBOMProjectList = DAL.fnBOMItemPurchase(dgbomlist.CurrentRow.Cells["ItemCode"].Value.ToString(), " ").Tables[0];
                        dgvBOMQty.AutoGenerateColumns = false;
                        dgvBOMQty.DataSource = dtBOMProjectList;
                        dBOMTotalQuantity = 0;
                        if (!string.IsNullOrEmpty(dgbomlist.CurrentRow.Cells["BOMProjectCodes"].Value.ToString()))
                        {
                            dBOMTotalQuantity = Convert.ToDouble(dgbomlist.CurrentRow.Cells["ReqQty"].Value);
                            lstBOMProjects.Clear();
                            lstBOMProjects = dgbomlist.CurrentRow.Cells["BOMProjectCodes"].Value.ToString().Split(',').ToList();
                            DataTable dtEnterdQty = new DataTable();
                            dtEnterdQty = convertStringToDataTable(dgbomlist.CurrentRow.Cells["BOMProjectCodes"].Value.ToString());

                            //  dtEnterdQty.Columns[2].DataType = typeof(double);
                            for (int k = 0; k < dtEnterdQty.Rows.Count; k++)
                            {
                                for (int i = 0; i < dtBOMProjectList.Rows.Count; i++)
                                {
                                    if (dtEnterdQty.Rows[k]["ProjectCode"].ToString().Trim() == dtBOMProjectList.Rows[i]["ProjectCode"].ToString().Trim() && dtEnterdQty.Rows[k]["ProductNo"].ToString().Trim() == dtBOMProjectList.Rows[i]["ProductNo"].ToString().Trim())
                                    {
                                        {
                                            int nIndex = dtBOMProjectList.Rows.IndexOf(dtBOMProjectList.Rows[i]);
                                            DataRow dr1 = dtBOMProjectList.Rows[nIndex];
                                            dr1["ReqQty"] = dtEnterdQty.Rows[k]["ReqQty"].ToString();
                                            break;
                                        }
                                    }
                                }
                            }

                        }
                        foreach (DataGridViewRow row in dgvBOMQty.Rows)
                        {
                            row.Cells[7].Value = row.Cells[8].Value;
                        }
                        int countn = 0;
                        foreach (DataGridViewRow dgr in dgvBOMQty.Rows)
                        {
                            if (Convert.ToDouble(dgr.Cells[6].Value) == Convert.ToDouble(dgr.Cells[5].Value))
                            {
                                dgvBOMQty.Rows[countn].Cells[8].Style.BackColor = Color.Red;
                            }
                            countn++;
                        }


                        lblBOMTotal.Text = dBOMTotalQuantity.ToString();
                    }
                }
            }
        }

        public static DataTable convertStringToDataTable(string data)
        {
            DataTable dtStringtoTable = new DataTable();
            DataColumn dataColumn = new DataColumn("ProjectCode");
            DataColumn dataColumn1 = new DataColumn("ProductNo");
            DataColumn dataColumn2 = new DataColumn("ReqQty");

            dtStringtoTable.Columns.Add(dataColumn);
            dtStringtoTable.Columns.Add(dataColumn1);
            dtStringtoTable.Columns.Add(dataColumn2);
            dtStringtoTable.Columns[2].DataType = typeof(double);
            foreach (string row in data.Split(','))
            {
                DataRow dataRow = dtStringtoTable.NewRow();
                {
                    string[] keyValue = row.Split('/');
                    {
                        //   keyValue.Length
                        dataRow[0] = keyValue[0];
                        dataRow[1] = keyValue[1];
                        dataRow[2] = keyValue[2];
                    }
                }
                dtStringtoTable.Rows.Add(dataRow);
            }
            return dtStringtoTable;
        }


        private void btnAddPOBOMQty_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow dr in dgvBOMQty.Rows)
            {
               
               
                if (Convert.ToDouble(dr.Cells[8].Value) > 0)
                {
                    if (Convert.ToDouble(dr.Cells[5].Value) == 0)
                    {
                        GLobalClass.iStatus = DAL.fnUpdateMachinBOMPO(1, dr.Cells[8].Value.ToString(), dgbomlist.CurrentRow.Cells["ItemCode"].Value.ToString(),
                                                                         dr.Cells[0].Value.ToString(), dr.Cells[2].Value.ToString());
                    }
                    else
                    {
                        GLobalClass.iStatus = DAL.fnUpdateMachinBOMPO(2, (Convert.ToDouble(dr.Cells[7].Value)).ToString(), dgbomlist.CurrentRow.Cells["ItemCode"].Value.ToString(),
                                                                                                       dr.Cells[0].Value.ToString(), dr.Cells[2].Value.ToString());
                        GLobalClass.iStatus = DAL.fnUpdateMachinBOMPO(1, (Convert.ToDouble(dr.Cells[8].Value)).ToString(), dgbomlist.CurrentRow.Cells["ItemCode"].Value.ToString(),
                                                                                                       dr.Cells[0].Value.ToString(), dr.Cells[2].Value.ToString());
                    }
                }
            }
            dgbomlist.CurrentRow.Cells["ReqQty"].Value = lblBOMTotal.Text;
            dgbomlist.CurrentRow.Cells["RemQty"].Value = lblBOMTotal.Text;
            lstBOMProjects.Clear();
            foreach (DataGridViewRow dr in dgvBOMQty.Rows)
            {
               // MessageBox.Show(dr.Cells[8].Value.ToString() + "//"+ dr.Cells[2].Value.ToString(), dgbomlist.CurrentRow.Cells["ItemCode"].Value.ToString());
                if (Convert.ToDouble(dr.Cells[8].Value) > 0)
                {
                    lstBOMProjects.Add(dr.Cells[0].Value + "/" + dr.Cells[2].Value + "/" + dr.Cells[8].Value + " ");
                }
            }
           // MessageBox.Show(string.Join(",", lstBOMProjects.ToArray()));

            dgbomlist.CurrentRow.Cells["BOMProjectCodes"].Value = string.Join(",", lstBOMProjects.ToArray());


            var val = dgbomlist.CurrentRow.Cells["BOMProjectCodes"].Value?.ToString();

           // MessageBox.Show(val, "BOMProjectCodes");


            dgbomlist.CurrentRow.Cells["Amount"].Value = (Convert.ToDouble(dgbomlist.CurrentRow.Cells["ReqQty"].Value) * Convert.ToDouble(dgbomlist.CurrentRow.Cells["Unitprice"].Value)).ToString();
            pnBOMQtyCheck.Visible = false;
            dgbomlist.CurrentRow.Cells["ReqQty"].ReadOnly = true;
            fnTotalPOCost();
        }


        private void dgvBOMQty_CellEndEdit_1(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvBOMQty.CurrentCell.Value != null)
            {
                if (!string.IsNullOrEmpty(dgvBOMQty.CurrentCell.Value.ToString()))
                {
                    if (Convert.ToDouble(dgvBOMQty.CurrentRow.Cells[5].Value) == 0)
                    {
                        if (Convert.ToDouble(dgvBOMQty.CurrentCell.Value) > Convert.ToDouble(dgvBOMQty.CurrentRow.Cells[6].Value))
                        //  if (Convert.ToDouble(dgvBOMQty.CurrentCell.Value) > (Convert.ToDouble(dgvBOMQty.CurrentRow.Cells["BOMQty"].Value)+Convert.ToDouble(dgvBOMQty.CurrentRow.Cells[5].Value)))
                        {
                            MessageBox.Show("Quantity must be less than or equal to BOM + PO Quantity");
                            dgvBOMQty.CurrentCell.Value = dOldBOMQty;
                        }
                        else
                        {
                            dBOMTotalQuantity = 0;
                            foreach (DataGridViewRow dr in dgvBOMQty.Rows)
                            {
                                dBOMTotalQuantity += Convert.ToDouble(dr.Cells[8].Value);
                            }
                            lblBOMTotal.Text = dBOMTotalQuantity.ToString();
                        }
                    }
                    else
                    {
                        if (Convert.ToDouble(dgvBOMQty.CurrentRow.Cells[8].Value) == 0)
                        {
                            GLobalClass.iStatus = DAL.fnUpdateMachinBOMPO(2, (Convert.ToDouble(dgvBOMQty.CurrentRow.Cells[7].Value)).ToString(), dgbomlist.CurrentRow.Cells["ItemCode"].Value.ToString(),
                                                                         dgvBOMQty.CurrentRow.Cells[0].Value.ToString(), dgvBOMQty.CurrentRow.Cells[2].Value.ToString());
                        }
                        if (Convert.ToDouble(dgvBOMQty.CurrentRow.Cells[7].Value) == 0)
                        {
                            if (Convert.ToDouble(dgvBOMQty.CurrentCell.Value) > (Convert.ToDouble(dgvBOMQty.CurrentRow.Cells[6].Value) - Convert.ToDouble(dgvBOMQty.CurrentRow.Cells[5].Value)))
                            //  if (Convert.ToDouble(dgvBOMQty.CurrentCell.Value) > (Convert.ToDouble(dgvBOMQty.CurrentRow.Cells["BOMQty"].Value)+Convert.ToDouble(dgvBOMQty.CurrentRow.Cells[5].Value)))
                            {
                                MessageBox.Show("Quantity must be less than or equal to BOM + PO Quantity");
                                dgvBOMQty.CurrentCell.Value = dOldBOMQty;
                            }
                            else
                            {
                                dBOMTotalQuantity = 0;
                                foreach (DataGridViewRow dr in dgvBOMQty.Rows)
                                {
                                    dBOMTotalQuantity += Convert.ToDouble(dr.Cells[8].Value);
                                }
                                lblBOMTotal.Text = dBOMTotalQuantity.ToString();
                            }
                        }
                        else if (Convert.ToDouble(dgvBOMQty.CurrentRow.Cells[7].Value) > 0)
                        {
                            if (Convert.ToDouble(dgvBOMQty.CurrentCell.Value) > (Convert.ToDouble(dgvBOMQty.CurrentRow.Cells[6].Value) - (Convert.ToDouble(dgvBOMQty.CurrentRow.Cells[5].Value) - Convert.ToDouble(dgvBOMQty.CurrentRow.Cells[7].Value))))
                            //  if (Convert.ToDouble(dgvBOMQty.CurrentCell.Value) > (Convert.ToDouble(dgvBOMQty.CurrentRow.Cells["BOMQty"].Value)+Convert.ToDouble(dgvBOMQty.CurrentRow.Cells[5].Value)))
                            {
                                MessageBox.Show("Quantity must be less than or equal to BOM + PO Quantity");
                                dgvBOMQty.CurrentCell.Value = dOldBOMQty;
                            }
                            else
                            {
                                dBOMTotalQuantity = 0;
                                foreach (DataGridViewRow dr in dgvBOMQty.Rows)
                                {
                                    dBOMTotalQuantity += Convert.ToDouble(dr.Cells[8].Value);
                                }
                                lblBOMTotal.Text = dBOMTotalQuantity.ToString();
                            }
                        }
                    }
                }
                else
                {
                    dgvBOMQty.CurrentCell.Value = dOldBOMQty;
                }
            }
            else
            {
                dgvBOMQty.CurrentCell.Value = dOldBOMQty;
            }
        }

        private void dgvBOMQty_CellBeginEdit_1(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgvBOMQty.CurrentCell.OwningColumn.Index == 8)
            {
                dOldBOMQty = Convert.ToDouble(dgvBOMQty.CurrentCell.Value);
            }
        }

        private void dgvBOMQty_EditingControlShowing_1(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show(" dgPackingTaxes_EditingControlShowing   " + ex.Message);
            }
        }

        public string GetTableFromDataGridWorkOrder()
        {
            StringBuilder strTable = new StringBuilder();
            try
            {
                strTable.Append("<table border='1' cellpadding='0' cellspacing='0'>");
                strTable.Append("<tr>");
                // dgvPOItemList.Columns[0].Visible = false;
                //Create Header Row for Table
                foreach (DataGridViewColumn col in dgvRemarks.Columns)
                {
                    strTable.AppendFormat("<th bgcolor='Gainsboro'>{0}  </th>", col.HeaderText);
                }
                strTable.Append("</tr>");
                //Create Table Rows
                for (int i = 0; i < dgvRemarks.Rows.Count; i++)
                {
                    strTable.Append("<tr>");
                    foreach (DataGridViewCell cell in dgvRemarks.Rows[i].Cells)
                    {
                        if (cell.Value != null)
                        {
                            strTable.AppendLine("<td align='center' valign='middle' bgcolor='AliceBlue'>" + cell.Value.ToString() + "</td>");
                            // strTable.AppendFormat("<td>{0}</td>", cell.Value.ToString());
                        }

                    }
                    strTable.Append("</tr>");
                }
                strTable.Append("</table>");
                //dgvPOItemList.Columns[0].Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            return strTable.ToString();
        }

        private void fnUpdatePOtax(string sPOgeneratedby, string sPOGendate)
        {
            if (!string.IsNullOrEmpty(sPOgeneratedby))
            {
                foreach (DataGridViewRow row in dgbomlist.Rows)
                {
                    if (!string.IsNullOrEmpty(row.Cells["ItemCode"].Value.ToString()))
                    {
                        if (row.Cells["dBOMQty"].Value == DBNull.Value)
                        {
                            row.Cells["dBOMQty"].Value = 0;
                        }
                        if (row.Cells["BOMProjectCodes"].Value == DBNull.Value)
                        {
                            row.Cells["BOMProjectCodes"].Value = "";
                        }
                        if ((row.Cells["OtherProjects"].Value) == DBNull.Value)
                        {
                            row.Cells["OtherProjects"].Value = "";
                        }

                        //shreeshail is added PurchaseOrdervaliduptoDate
                        GLobalClass.iSuccess = DAL.fnAddPurchaseOrder(99, cmbPONO.Text, cmbProjectcode.Text, txtvendorcode.Text, null, sPOgeneratedby, row.Cells["ItemCode"].Value.ToString(), null,
                                                    Convert.ToDouble(row.Cells["ReqQty"].Value), Convert.ToDouble(row.Cells["RemQty"].Value), Convert.ToDouble(row.Cells["Unitprice"].Value),
                                                    Convert.ToDouble(row.Cells["Amount"].Value), txtRemarks.Text, sPOGendate, "", lblProjectStatus.Text,
                                                    Convert.ToDouble(row.Cells["IGSTRate"].Value), Convert.ToDouble(row.Cells["IGSTAmount"].Value), Convert.ToDouble(row.Cells["SGSTRate"].Value),
                                                    Convert.ToDouble(row.Cells["SGSTAmount"].Value), Convert.ToDouble(row.Cells["CGSTRate"].Value), Convert.ToDouble(row.Cells["CGSTAmount"].Value),
                                                    Convert.ToDouble(row.Cells["DiscRate"].Value), Convert.ToDouble(row.Cells["DiscAmount"].Value), 0, 0,
                                                    Convert.ToDouble(row.Cells["dBOMQty"].Value), row.Cells["BOMProjectCodes"].Value.ToString(), dtpdelivery.Text, row.Cells["OtherProjects"].Value.ToString(), 0, "", cmbcurrency.Text, Convert.ToDouble(curratetext.Text), PurchaseOrdervaliduptoDate.Text);

                        GLobalClass.iSuccess = DAL.fnAddPurchaseOrderPricing(1, cmbPONO.Text, row.Cells["ItemCode"].Value.ToString(), Convert.ToDouble(row.Cells["StandardCost"].Value.ToString()),
                                               Convert.ToDouble(row.Cells["DiffrenceinPer"].Value.ToString()), Convert.ToDouble(row.Cells["DiffrenceinRs"].Value.ToString()));

                    }
                }
            }

            else
            {
                foreach (DataGridViewRow row in dgbomlist.Rows)
                {
                    if (!string.IsNullOrEmpty(row.Cells["ItemCode"].Value.ToString()))
                    {
                        if (row.Cells["dBOMQty"].Value == DBNull.Value)
                        {
                            row.Cells["dBOMQty"].Value = 0;
                        }
                        if (row.Cells["BOMProjectCodes"].Value == DBNull.Value)
                        {
                            row.Cells["BOMProjectCodes"].Value = "";
                        }
                        if ((row.Cells["OtherProjects"].Value) == DBNull.Value)
                        {
                            row.Cells["OtherProjects"].Value = "";
                        }
                        //shreeshail is added PurchaseOrdervaliduptoDate
                        GLobalClass.iSuccess = DAL.fnAddPurchaseOrder(991, cmbPONO.Text, cmbProjectcode.Text, txtvendorcode.Text, null, sPOgeneratedby, row.Cells["ItemCode"].Value.ToString(), null,
                                                    Convert.ToDouble(row.Cells["ReqQty"].Value), Convert.ToDouble(row.Cells["RemQty"].Value), Convert.ToDouble(row.Cells["Unitprice"].Value),
                                                    Convert.ToDouble(row.Cells["Amount"].Value), txtRemarks.Text, sPOGendate, "", lblProjectStatus.Text,
                                                    Convert.ToDouble(row.Cells["IGSTRate"].Value), Convert.ToDouble(row.Cells["IGSTAmount"].Value), Convert.ToDouble(row.Cells["SGSTRate"].Value),
                                                    Convert.ToDouble(row.Cells["SGSTAmount"].Value), Convert.ToDouble(row.Cells["CGSTRate"].Value), Convert.ToDouble(row.Cells["CGSTAmount"].Value),
                                                    Convert.ToDouble(row.Cells["DiscRate"].Value), Convert.ToDouble(row.Cells["DiscAmount"].Value), 0, 0,
                                                    Convert.ToDouble(row.Cells["dBOMQty"].Value), row.Cells["BOMProjectCodes"].Value.ToString(), dtpdelivery.Text, row.Cells["OtherProjects"].Value.ToString(), 0, "", cmbcurrency.Text, Convert.ToDouble(curratetext.Text), PurchaseOrdervaliduptoDate.Text);

                        GLobalClass.iSuccess = DAL.fnAddPurchaseOrderPricing(1, cmbPONO.Text, row.Cells["ItemCode"].Value.ToString(), Convert.ToDouble(row.Cells["StandardCost"].Value.ToString()),
                                               Convert.ToDouble(row.Cells["DiffrenceinPer"].Value.ToString()), Convert.ToDouble(row.Cells["DiffrenceinRs"].Value.ToString()));

                    }
                }
            }

        }

        private void fnUpdatePO()
        {
            foreach (DataGridViewRow row in dgbomlist.Rows)
            {
                if (row.Cells["dBOMQty"].Value == DBNull.Value)
                {
                    row.Cells["dBOMQty"].Value = 0;
                }
                if (row.Cells["BOMProjectCodes"].Value == DBNull.Value)
                {
                    row.Cells["BOMProjectCodes"].Value = "";
                }
                if ((row.Cells["OtherProjects"].Value) == DBNull.Value)
                {
                    row.Cells["OtherProjects"].Value = "";
                }
                //shreeshail added PurchaseOrdervaliduptoDate
                GLobalClass.iSuccess = DAL.fnAddPurchaseOrder(98, cmbPONO.Text, cmbProjectcode.Text, txtvendorcode.Text, null, login.GetUserDetails[2].ToString(),
                                                            row.Cells["ItemCode"].Value.ToString(), null, Convert.ToDouble(row.Cells["ReqQty"].Value), Convert.ToDouble(row.Cells["RemQty"].Value),
                                                            Convert.ToDouble(row.Cells["Unitprice"].Value), Convert.ToDouble(row.Cells["Amount"].Value), txtRemarks.Text, null, dtppreparedate.Text,
                                                            lblProjectStatus.Text, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, Convert.ToDouble(row.Cells["dBOMQty"].Value), row.Cells["BOMProjectCodes"].Value.ToString(),
                                                            dtpdelivery.Text, row.Cells["OtherProjects"].Value.ToString(), 0, "", cmbcurrency.Text, Convert.ToDouble(curratetext.Text), PurchaseOrdervaliduptoDate.Text);
            }
        }

        DataTable dtEMailID = new DataTable();
        DataTable dtEMailIDPMalert = new DataTable();
        string sSixMonthsMessage;


        private void btnAcceptPO_Click(object sender, EventArgs e)
        {
            fnQunatityCheck();

            if (!bSixMonths)
            {

                if (!string.IsNullOrEmpty(txtRemarks.Text) && !string.IsNullOrEmpty(cmbPONO.Text) && !string.IsNullOrEmpty(cmbProjectcode.Text) && !string.IsNullOrEmpty(cmbVendorName.Text) && !bSixMonths && bDeliverDate == true && cmbEmailAlert.SelectedIndex >= 0)
                {
                    if (chkWithoutBOM.Checked == false)
                    {
                        // fnAddedPOBOMItemPrice();
                        fnAddedPOBOMItemPriceUpdate();
                    }

                    if (Convert.ToBoolean(login.GetUserDetails[29]) == true)
                    {
                        currencyData = DAL.Currency_IN_INR(0, cmbcurrency.Text).Tables[0];

                        if (currencyData.Rows.Count > 0)
                        {
                            // Convert the fetched rate to a double
                            double conversionRate = Convert.ToDouble(currencyData.Rows[0]["TO_INR"]);

                            // Step 2: Convert the total amount from label to double
                            double totalAmount = Convert.ToDouble(lblTotalAmount.Text);

                            // Step 3: Calculate the converted amount
                            double convertedAmount = totalAmount * conversionRate;

                            if (convertedAmount <= 50000)
                            {
                                if (dgbomlist.Rows.Count > 0)
                                {
                                    fnUpdatePO();
                                    GLobalClass.iSuccess = DAL.fnUpdatePoProcess(9, cmbPONO.Text, login.GetUserDetails[2].ToString(), dtppreparedate.Text, txtRemarks.Text);

                                    fnLoadComments();

                                    GLobalClass.iSuccess = DAL.purchaseOrderApproval(0, cmbPONO.Text, "", "", "");
                                    GLobalClass.iSuccess = DAL.fnAddERPLog(0, cmbPONO.Text, login.GetUserDetails[2], dtppreparedate.Text, "PO Approved", "PurchaseOrder");
                                    //fnApprovetMail("Veena", txtRemarks.Text, lstusers, null);
                              fnAlertMailPOGenrate("Pavana", txtRemarks.Text);
                                //-   fnAlertMailPOGenrate("biss", txtRemarks.Text);
                                    
                                    MessageBox.Show("PO " + cmbPONO.Text + " is approved & email alert sent to Pavana ", "Success", 0, MessageBoxIcon.Information);
                                }

                            }
                            else if (convertedAmount > 50000 && convertedAmount <= 250000)
                            {
                                fnUpdatePO();
                                //GLobalClass.iSuccess = DAL.purchaseOrderApproval(4, cmbPONO.Text, "", "", "");
                                GLobalClass.iSuccess = DAL.fnUpdatePoProcess(10, cmbPONO.Text, login.GetUserDetails[2].ToString(), dtppreparedate.Text, txtRemarks.Text);

                                dtEMailID = DAL.PORemarksHistory(5, cmbPONO.Text).Tables[0];
                                if (dtEMailID.Rows.Count > 0)
                                {
                                    for (int i = 0; i < dtEMailID.Rows.Count; i++)
                                    {
                                        if (!lstusers.Items.Contains(dtEMailID.Rows[i]["emailid"].ToString()))
                                        {
                                            lstusers.Items.Add(dtEMailID.Rows[i]["emailid"].ToString());
                                        }
                                    }
                                    //  btnprintpo_Click(sender, e);
                                //-    fnApprovetMail("biss", txtRemarks.Text, lstusers, null);
                               fnApprovetMail("Vivek G", txtRemarks.Text, lstusers, null);
                                    GLobalClass.iSuccess = DAL.fnAddERPLog(0, cmbPONO.Text, login.GetUserDetails[2], dtppreparedate.Text, "PO Approved", "PurchaseOrder");
                                    MessageBox.Show("PO " + cmbPONO.Text + " is approved & email alert sent to Vivek G ", "Success", 0, MessageBoxIcon.Information);

                                }
                            }
                            else if (convertedAmount > 250000)
                            {
                                fnUpdatePO();

                                fnLoadComments();
                                GLobalClass.iSuccess = DAL.purchaseOrderApproval(20, cmbPONO.Text, "", "", "");
                                GLobalClass.iSuccess = DAL.fnUpdatePoProcess(11, cmbPONO.Text, login.GetUserDetails[2].ToString(), dtppreparedate.Text, txtRemarks.Text);

                                dtEMailID = DAL.PORemarksHistory(5, cmbPONO.Text).Tables[0];
                                if (dtEMailID.Rows.Count > 0)
                                {

                                    for (int i = 0; i < dtEMailID.Rows.Count; i++)
                                    {
                                        if (!lstusers.Items.Contains(dtEMailID.Rows[i]["emailid"].ToString()))
                                        {
                                            lstusers.Items.Add(dtEMailID.Rows[i]["emailid"].ToString());
                                        }
                                    }

                                    //  btnprintpo_Click(sender, e);
                                //   fnApprovetMail("biss", txtRemarks.Text, lstusers, null);
                                    //fnApprovetMail("shreeshail", txtRemarks.Text, lstusers, FileFul);
                            fnApprovetMail("Vivek G", txtRemarks.Text, lstusers, null);
                                    GLobalClass.iSuccess = DAL.fnAddERPLog(0, cmbPONO.Text, login.GetUserDetails[2], dtppreparedate.Text, "PO Approved", "PurchaseOrder");
                                    MessageBox.Show("PO " + cmbPONO.Text + " is approved & email alert sent to Vivek G ", "Success", 0, MessageBoxIcon.Information);

                                }

                            }
                            sPONumber = null;
                            FormReload();

                        }
                        
                    }

                    

                        //Rakesh
                    if (Convert.ToBoolean(login.GetUserDetails[31]) == true)
                    {
                        if (dgbomlist.Rows.Count > 0)
                        {
                            fnUpdatePO();
                            GLobalClass.iSuccess = DAL.fnUpdatePoProcess(1, cmbPONO.Text, login.GetUserDetails[2].ToString(), dtppreparedate.Text, txtRemarks.Text);
                            fnLoadComments();
                            fnApprovetMail(cmbEmailAlert.Text, txtRemarks.Text, lstusers, null);
                            GLobalClass.iSuccess = DAL.fnAddERPLog(0, cmbPONO.Text, login.GetUserDetails[2], dtppreparedate.Text, "PO Approved", "PurchaseOrder");
                            MessageBox.Show("PO " + cmbPONO.Text + " is approved & email alert sent to " + cmbEmailAlert.Text + "", "Success", 0, MessageBoxIcon.Information);
                            sPONumber = null;
                            FormReload();
                        }
                    }

                    //Ravi
                    else if (Convert.ToBoolean(login.GetUserDetails[32]) == true)
                    {
                        if (dgbomlist.Rows.Count > 0)
                        {
                            fnUpdatePO();
                            GLobalClass.iSuccess = DAL.fnUpdatePoProcess(2, cmbPONO.Text, login.GetUserDetails[2].ToString(), dtppreparedate.Text, txtRemarks.Text);
                            fnLoadComments();
                            fnApprovetMail(cmbEmailAlert.Text, txtRemarks.Text, lstusers, null);
                            GLobalClass.iSuccess = DAL.fnAddERPLog(0, cmbPONO.Text, login.GetUserDetails[2], dtppreparedate.Text, "PO Approved", "PurchaseOrder");
                            MessageBox.Show("PO " + cmbPONO.Text + " is approved & email alert sent to " + cmbEmailAlert.Text + "", "Success", 0, MessageBoxIcon.Information);
                            sPONumber = null;
                            FormReload();
                        }

                    }
                    /*
                    //--VISHAL-- Thilak 
                    else if (Convert.ToBoolean(login.GetUserDetails[29]) == true)
                    {
                        if (dgbomlist.Rows.Count > 0)
                        {
                            fnUpdatePO();
                            GLobalClass.iSuccess = DAL.fnUpdatePoProcess(3, cmbPONO.Text, login.GetUserDetails[2].ToString(), dtppreparedate.Text, txtRemarks.Text);

                            fnLoadComments();

                            currencyData = DAL.Currency_IN_INR(0, cmbcurrency.Text).Tables[0];

                            if (currencyData.Rows.Count > 0)
                            {
                                // Convert the fetched rate to a double
                                double conversionRate = Convert.ToDouble(currencyData.Rows[0]["TO_INR"]);

                                // Step 2: Convert the total amount from label to double
                                double totalAmount = Convert.ToDouble(lblTotalAmount.Text);

                                // Step 3: Calculate the converted amount
                                double convertedAmount = totalAmount * conversionRate;

                                if (convertedAmount < 150000)
                                {
                                    GLobalClass.iSuccess = DAL.purchaseOrderApproval(0, cmbPONO.Text, "", "", "");
                                    GLobalClass.iSuccess = DAL.fnAddERPLog(0, cmbPONO.Text, login.GetUserDetails[2], dtppreparedate.Text, "PO Approved", "PurchaseOrder");
                                    fnApprovetMail("Muthuramalingam", txtRemarks.Text, lstusers, null);
                                    //fnApprovetMail("shreeshail", txtRemarks.Text, lstusers, null);
                                    MessageBox.Show("PO " + cmbPONO.Text + " is approved & email alert sent to Muthuramalingam ", "Success", 0, MessageBoxIcon.Information);
                                }
                                else if(convertedAmount > 150000)
                                {
                                    GLobalClass.iSuccess = DAL.purchaseOrderApproval(4, cmbPONO.Text, "", "", "");

                                    dtEMailID = DAL.PORemarksHistory(2, cmbPONO.Text).Tables[0];
                                    if (dtEMailID.Rows.Count > 0)
                                    {
                                        for (int i = 0; i < dtEMailID.Rows.Count; i++)
                                        {
                                            if (!lstusers.Items.Contains(dtEMailID.Rows[i]["emailid"].ToString()))
                                            {
                                                lstusers.Items.Add(dtEMailID.Rows[i]["emailid"].ToString());
                                            }
                                        }
                                        //  btnprintpo_Click(sender, e);
                                        //fnApprovetMail("shreeshail", txtRemarks.Text, lstusers, null);
                                        fnApprovetMail("Hebbarrk", txtRemarks.Text, lstusers, null);
                                        GLobalClass.iSuccess = DAL.fnAddERPLog(0, cmbPONO.Text, login.GetUserDetails[2], dtppreparedate.Text, "PO Approved", "PurchaseOrder");
                                        MessageBox.Show("PO " + cmbPONO.Text + " is approved & email alert sent to Hebbarrk ", "Success", 0, MessageBoxIcon.Information);

                                    }
                                }
                            }


                            
                            sPONumber = null;
                            FormReload();
                        }
                    }
                    */
                    
                    //Theertha Rao
                    else if (Convert.ToBoolean(login.GetUserDetails[80]) == true)
                    {
                        if (!string.IsNullOrEmpty(cmbPONO.Text) && !string.IsNullOrEmpty(cmbProjectcode.Text) && !string.IsNullOrEmpty(cmbVendorName.Text) && !bSixMonths && bDeliverDate == true && cmbEmailAlert.SelectedIndex >= 0)
                        {

                            if (dgbomlist.Rows.Count > 0)
                            {
                                fnUpdatePO();
                                GLobalClass.iSuccess = DAL.fnUpdatePoProcess(4, cmbPONO.Text, login.GetUserDetails[2].ToString(), dtppreparedate.Text, txtRemarks.Text);

                                fnLoadComments();

                                GLobalClass.iSuccess = DAL.fnUpdatePoProcess(7, cmbPONO.Text, login.GetUserDetails[2].ToString(), "", "");

                                foreach (DataGridViewRow row in dgvPOGeneralTerms.Rows)
                                {
                                    GLobalClass.iSuccess = DAL.fnUpdatePoProcess(6, cmbPONO.Text, login.GetUserDetails[2].ToString(), "", row.Cells["POTerms"].Value.ToString().Trim());
                                }

                                GLobalClass.iSuccess = DAL.purchaseOrderApproval(4, cmbPONO.Text, "", "", "");
                                //btnprintpo_Click(sender, e);

                            fnApprovetMail("Hebbarrk", txtRemarks.Text, lstusers, FileFul);
                            //   fnApprovetMail("biss", txtRemarks.Text, lstusers, null);
                                sGM = "GM";
                                dtEMailID = DAL.PORemarksHistory(5, cmbPONO.Text).Tables[0];
                                if (dtEMailID.Rows.Count > 0)
                                {
                                    for (int i = 0; i < dtEMailID.Rows.Count; i++)
                                    {
                                        if (!lstusers.Items.Contains(dtEMailID.Rows[i]["emailid"].ToString()))
                                        {
                                            lstusers.Items.Add(dtEMailID.Rows[i]["emailid"].ToString());
                                        }
                                    }
                                    
                                    fnApprovetMail("Pavana", txtRemarks.Text, lstusers, FileFul);
                                }

                                MessageBox.Show("PO " + cmbPONO.Text + " is approved & email alert sent to " + cmbEmailAlert.Text + "", "Success", 0, MessageBoxIcon.Information);
                                sPONumber = null;
                                FormReload();
                            }
                        }
                    }

                    //RAMAKRISHNA
                    else if (Convert.ToBoolean(login.GetUserDetails[30]) == true)
                    {
                        GLobalClass.iSuccess = DAL.purchaseOrderApproval(35, cmbPONO.Text, dtppreparedate.Text, login.GetUserDetails[2], txtRemarks.Text);

                        GLobalClass.iSuccess = DAL.fnUpdatePoProcess(7, cmbPONO.Text, login.GetUserDetails[2].ToString(), "", "");

                        foreach (DataGridViewRow row in dgvPOGeneralTerms.Rows)
                        {
                            GLobalClass.iSuccess = DAL.fnUpdatePoProcess(6, cmbPONO.Text, login.GetUserDetails[2].ToString(), "", row.Cells["POTerms"].Value.ToString().Trim());
                        }

                        dtEMailID = DAL.PORemarksHistory(5, cmbPONO.Text).Tables[0];
                        if (dtEMailID.Rows.Count > 0)
                        {
                            for (int i = 0; i < dtEMailID.Rows.Count; i++)
                            {
                                if (!lstusers.Items.Contains(dtEMailID.Rows[i]["emailid"].ToString()))
                                {
                                    lstusers.Items.Add(dtEMailID.Rows[i]["emailid"].ToString());
                                }
                            }
                            
                          fnApprovetMail("Pavana", txtRemarks.Text, lstusers, null);
                          // fnApprovetMail("biss", txtRemarks.Text, lstusers, null);
                        }
                        GLobalClass.iSuccess = DAL.fnAddERPLog(0, cmbPONO.Text, login.GetUserDetails[2], dtppreparedate.Text, "PO Approved", "PurchaseOrder");
                        MessageBox.Show("'" + cmbPONO.Text + "' approved", "Success", 0, MessageBoxIcon.Information);
                        sPONumber = null;
                        lstusers.Items.Clear();
                        FormReload();
                    }


                    
                    //Vivek G
                    else if (Convert.ToBoolean(login.GetUserDetails[85]) == true)
                    {
                        currencyData = DAL.Currency_IN_INR(0, cmbcurrency.Text).Tables[0];

                        if (currencyData.Rows.Count > 0)
                        {
                            // Convert the fetched rate to a double
                            double conversionRate = Convert.ToDouble(currencyData.Rows[0]["TO_INR"]);

                            // Step 2: Convert the total amount from label to double
                            double totalAmount = Convert.ToDouble(lblTotalAmount.Text);

                            // Step 3: Calculate the converted amount
                            double convertedAmount = totalAmount * conversionRate;
                            if (convertedAmount <= 50000)
                            {
                                GLobalClass.iSuccess = DAL.purchaseOrderApproval(19, cmbPONO.Text, dtppreparedate.Text, login.GetUserDetails[2], txtRemarks.Text);

                                GLobalClass.iSuccess = DAL.fnUpdatePoProcess(7, cmbPONO.Text, login.GetUserDetails[2].ToString(), "", "");
                                fnLoadComments();
                                foreach (DataGridViewRow row in dgvPOGeneralTerms.Rows)
                                {
                                    GLobalClass.iSuccess = DAL.fnUpdatePoProcess(6, cmbPONO.Text, login.GetUserDetails[2].ToString(), "", row.Cells["POTerms"].Value.ToString().Trim());
                                }

                                GLobalClass.iSuccess = DAL.fnAddERPLog(0, cmbPONO.Text, login.GetUserDetails[2], dtppreparedate.Text, "PO Approved", "PurchaseOrder");
                                //fnApprovetMail("Veena", txtRemarks.Text, lstusers, null);
                              fnAlertMailPOGenrate("Pavana", txtRemarks.Text);
                             //   fnAlertMailPOGenrate("biss", txtRemarks.Text);
                                //fnApprovetMail("Veena", txtRemarks.Text, lstusers, null);
                                MessageBox.Show("PO " + cmbPONO.Text + " is approved & email alert sent to Pavana ", "Success", 0, MessageBoxIcon.Information);
                            }
                            else if(convertedAmount > 50000 && convertedAmount <= 250000)
                            {
                                GLobalClass.iSuccess = DAL.purchaseOrderApproval(19, cmbPONO.Text, dtppreparedate.Text, login.GetUserDetails[2], txtRemarks.Text);

                                GLobalClass.iSuccess = DAL.fnUpdatePoProcess(7, cmbPONO.Text, login.GetUserDetails[2].ToString(), "", "");
                                fnLoadComments();
                                foreach (DataGridViewRow row in dgvPOGeneralTerms.Rows)
                                {
                                    GLobalClass.iSuccess = DAL.fnUpdatePoProcess(6, cmbPONO.Text, login.GetUserDetails[2].ToString(), "", row.Cells["POTerms"].Value.ToString().Trim());
                                }

                                GLobalClass.iSuccess = DAL.fnAddERPLog(0, cmbPONO.Text, login.GetUserDetails[2], dtppreparedate.Text, "PO Approved", "PurchaseOrder");
                                /*
                                dtEMailID = DAL.PORemarksHistory(5, cmbPONO.Text).Tables[0];
                                if (dtEMailID.Rows.Count > 0)
                                {

                                    for (int i = 0; i < dtEMailID.Rows.Count; i++)
                                    {
                                        if (!lstusers.Items.Contains(dtEMailID.Rows[i]["emailid"].ToString()))
                                        {
                                            lstusers.Items.Add(dtEMailID.Rows[i]["emailid"].ToString());
                                        }
                                    }
                                    //fnApprovetMail("Veena", txtRemarks.Text, lstusers, null);
                                    fnApprovetMail("shreeshail", txtRemarks.Text, lstusers, null);
                                }
                                 */
                          //    fnAlertMailPOGenrate("biss", txtRemarks.Text);
                             fnAlertMailPOGenrate("Pavana", txtRemarks.Text);
                                MessageBox.Show("PO " + cmbPONO.Text + " is approved & email alert sent to Pavana ", "Success", 0, MessageBoxIcon.Information);
                                
                            }
                            else if(convertedAmount > 250000)
                            {
                                GLobalClass.iSuccess = DAL.purchaseOrderApproval(17, cmbPONO.Text,dtppreparedate.Text, login.GetUserDetails[2], txtRemarks.Text);

                                fnLoadComments();
                                //  btnprintpo_Click(sender, e);
                                
                                //fnAlertMailOM("shreeshail", txtRemarks.Text);
                                //fnApprovetMail("Hebbarrk", txtRemarks.Text, lstusers, null);
                            //  fnApprovetMail("biss", txtRemarks.Text, lstusers, null);
                             fnApprovetMail("Hebbarrk", txtRemarks.Text, lstusers, null);
                                GLobalClass.iSuccess = DAL.fnAddERPLog(0, cmbPONO.Text, login.GetUserDetails[2], dtppreparedate.Text, "PO Approved", "PurchaseOrder");
                                MessageBox.Show("PO " + cmbPONO.Text + " is approved & email alert sent to Hebbarrk ", "Success", 0, MessageBoxIcon.Information);


                            }
                        }
                        sPONumber = null;
                        lstusers.Items.Clear();
                        FormReload();
                    }

                    
                    //Test Lab
                    else if (Convert.ToBoolean(login.GetUserDetails[82]) == true)
                    {
                        
                        if (dgbomlist.Rows.Count > 0)
                        {
                            if (cmbDeliverTerms.SelectedIndex >= 0 && cmbPaymentTerms.SelectedIndex >= 0)
                            {
                                fnUpdatePO();
                                GLobalClass.iSuccess = DAL.fnUpdatePoProcess(2, cmbPONO.Text, login.GetUserDetails[2].ToString(), dtppreparedate.Text, txtRemarks.Text);

                                GLobalClass.iSuccess = DAL.fnUpdatePoProcess(3, cmbPONO.Text, login.GetUserDetails[2].ToString(), dtppreparedate.Text, txtRemarks.Text);

                                GLobalClass.iSuccess = DAL.fnUpdatePoProcess(5, cmbPONO.Text, login.GetUserDetails[2].ToString(), dtppreparedate.Text, txtRemarks.Text);

                                fnLoadComments();

                                GLobalClass.iSuccess = DAL.fnUpdatePoProcess(7, cmbPONO.Text, login.GetUserDetails[2].ToString(), "", "");

                                foreach (DataGridViewRow row in dgvPOGeneralTerms.Rows)
                                {
                                    if (row.Cells["POTerms"].Value.ToString().Trim() != "")
                                    {
                                        GLobalClass.iSuccess = DAL.fnUpdatePoProcess(6, cmbPONO.Text, login.GetUserDetails[2].ToString(), "", row.Cells["POTerms"].Value.ToString());
                                    }
                                }
                                dtPOReport = DAL.POReport(cmbPONO.Text).Tables[0];
                                if (dtPOReport.Rows.Count > 0)
                                {
                                        GLobalClass.iSuccess = DAL.fnAddPOReport(Global.uUPDATE, cmbPONO.Text, cmbtransactiontype.Text, cmbNatureofTransaction.Text, cmbNatureofSupply.Text, txtShippedFrom.Text,
                                        txtShippedStateCode.Text, txtShippedGSTIn.Text, Convert.ToDouble(txtInvoiceTotal.Text), Convert.ToDouble(txtAmountPaid.Text), Convert.ToDouble(txtBalanceDue.Text), txtShippedCountry.Text, cmbDeliverTerms.Text, cmbPaymentTerms.Text, txtShippedFrom1.Text, cmbIncoterm.Text, txtIncoterm.Text);
                                }
                                else
                                {
                                    GLobalClass.iSuccess = DAL.fnAddPOReport(Global.uINSERT, cmbPONO.Text, cmbtransactiontype.Text, cmbNatureofTransaction.Text, cmbNatureofSupply.Text, txtShippedFrom.Text,
                                    txtShippedStateCode.Text, txtShippedGSTIn.Text, Convert.ToDouble(txtInvoiceTotal.Text), Convert.ToDouble(txtAmountPaid.Text), Convert.ToDouble(txtBalanceDue.Text), txtShippedCountry.Text, cmbDeliverTerms.Text, cmbPaymentTerms.Text, txtShippedFrom1.Text, cmbIncoterm.Text, txtIncoterm.Text);
                                }
                                //  btnprintpo_Click(sender, e);

                                currencyData = DAL.Currency_IN_INR(0, cmbcurrency.Text).Tables[0];

                                if (currencyData.Rows.Count > 0)
                                {
                                    // Convert the fetched rate to a double
                                    double conversionRate = Convert.ToDouble(currencyData.Rows[0]["TO_INR"]);

                                    // Step 2: Convert the total amount from label to double
                                    double totalAmount = Convert.ToDouble(lblTotalAmount.Text);

                                    // Step 3: Calculate the converted amount
                                    double convertedAmount = totalAmount * conversionRate;

                                    if (convertedAmount < 150000)
                                    {
                                        GLobalClass.iSuccess = DAL.purchaseOrderApproval(0, cmbPONO.Text, "", "", "");
                                        dtEMailID = DAL.PORemarksHistory(2, cmbPONO.Text).Tables[0];
                                        if (dtEMailID.Rows.Count > 0)
                                        {
                                            
                                            for (int i = 0; i < dtEMailID.Rows.Count; i++)
                                            {
                                                if (!lstusers.Items.Contains(dtEMailID.Rows[i]["emailid"].ToString()))
                                                {
                                                    lstusers.Items.Add(dtEMailID.Rows[i]["emailid"].ToString());
                                                }
                                            }
                                            
                                        }
                                        GLobalClass.iSuccess = DAL.fnAddERPLog(0, cmbPONO.Text, login.GetUserDetails[2], dtppreparedate.Text, "PO Approved", "PurchaseOrder");
                                      fnApprovetMail("Pavana", txtRemarks.Text, lstusers, null);
                                     //  fnApprovetMail("biss", txtRemarks.Text, lstusers, null);
                                        MessageBox.Show("PO " + cmbPONO.Text + " is approved & email alert sent to Hemanth ", "Success", 0, MessageBoxIcon.Information);
                                    }

                                    else if(convertedAmount > 150000)
                                    {
                                        GLobalClass.iSuccess = DAL.purchaseOrderApproval(4, cmbPONO.Text, "", "", "");

                                        dtEMailID = DAL.PORemarksHistory(2, cmbPONO.Text).Tables[0];
                                        if (dtEMailID.Rows.Count > 0)
                                        {
                                            
                                            for (int i = 0; i < dtEMailID.Rows.Count; i++)
                                            {
                                                if (!lstusers.Items.Contains(dtEMailID.Rows[i]["emailid"].ToString()))
                                                {
                                                    lstusers.Items.Add(dtEMailID.Rows[i]["emailid"].ToString());
                                                }
                                            }
                                            
                                        }
                                        GLobalClass.iSuccess = DAL.fnAddERPLog(0, cmbPONO.Text, login.GetUserDetails[2], dtppreparedate.Text, "PO Approved", "PurchaseOrder");
                                    fnApprovetMail("Hebbarrk", txtRemarks.Text, lstusers, null);
                                   //  fnApprovetMail("biss", txtRemarks.Text, lstusers, null);
                                        MessageBox.Show("PO " + cmbPONO.Text + " is approved & email alert sent to Hebbarrk", "Success", 0, MessageBoxIcon.Information);
                                    }
                                }
                                 
                                sPONumber = null;
                                FormReload();
                            }
                            else
                            {
                                if (cmbPaymentTerms.SelectedIndex < 0)
                                {
                                    MessageBox.Show("Please select the Payment Term", "Error", 0, MessageBoxIcon.Error);
                                }
                                else if (cmbDeliverTerms.SelectedIndex < 0)
                                {
                                    MessageBox.Show("Please select the Deliver Term", "Error", 0, MessageBoxIcon.Error);
                                }
                            }
                        }
                    }

                    //MuthuRamalingam
                    else if (Convert.ToBoolean(login.GetUserDetails[16]) == true && Convert.ToBoolean(login.GetUserDetails[30]) != true || login.GetUserDetails[2].ToLower() == "lizzy" && Convert.ToBoolean(login.GetUserDetails[30]) != true || login.GetUserDetails[2].ToLower() == "veena" || login.GetUserDetails[2].ToLower() == "pavana" || login.GetUserDetails[2].ToLower() == "hemanth reddy" && Convert.ToBoolean(login.GetUserDetails[30]) != true) //shreeshail is added or lizzy condition//Veena
                    {
                        if (dgbomlist.Rows.Count > 0)
                        {
                            if (cmbcurrency.SelectedIndex >= 0 && cmbDeliverTerms.SelectedIndex >= 0 && cmbPaymentTerms.SelectedIndex >= 0 && cmbIncoterm.SelectedIndex >= 0 && !string.IsNullOrEmpty(txtIncoterm.Text))
                            {
                                fnUpdatePO();
                                fnUpdatePOtax(null, null);
                               
                                // Step 1: Fetch conversion rate for selected currency to INR

                                 currencyData = DAL.Currency_IN_INR(0, cmbcurrency.Text).Tables[0];
                                
                                if (currencyData.Rows.Count > 0)
                                {
                                    // Convert the fetched rate to a double
                                    double conversionRate = Convert.ToDouble(currencyData.Rows[0]["TO_INR"]);

                                    // Step 2: Convert the total amount from label to double
                                    double totalAmount = Convert.ToDouble(lblTotalAmount.Text);

                                    // Step 3: Calculate the converted amount
                                    double convertedAmount = totalAmount * conversionRate;

                                    // Step 4: Check if the converted amount is less than 150000
                                    if (convertedAmount < 50000)
                                    {
                                        GLobalClass.iSuccess = DAL.fnUpdatePoProcess(8, cmbPONO.Text, login.GetUserDetails[2].ToString(), dtppreparedate.Text, txtRemarks.Text);
                                        // Add your code here if needed
                                    }
                                    else
                                    {
                                        GLobalClass.iSuccess = DAL.fnUpdatePoProcess(5, cmbPONO.Text, login.GetUserDetails[2].ToString(), dtppreparedate.Text, txtRemarks.Text);
                                        //MessageBox.Show("The converted amount exceeds 150,000 INR.");
                                    }
                                }
                                else
                                {
                                    // Handle case where conversionTable is empty
                                    MessageBox.Show("Failed to fetch conversion rate.");
                                }

                                fnLoadComments();

                                    GLobalClass.iSuccess = DAL.fnUpdatePoProcess(7, cmbPONO.Text, login.GetUserDetails[2].ToString(), "", "");

                                    foreach (DataGridViewRow row in dgvPOGeneralTerms.Rows)
                                    {
                                        if (row.Cells["POTerms"].Value.ToString().Trim() != "")
                                        {
                                            GLobalClass.iSuccess = DAL.fnUpdatePoProcess(6, cmbPONO.Text, login.GetUserDetails[2].ToString(), "", row.Cells["POTerms"].Value.ToString().Trim());
                                        }
                                    }
                                    dtPOReport = DAL.POReport(cmbPONO.Text).Tables[0];
                                    if (dtPOReport.Rows.Count > 0)
                                    {
                                        GLobalClass.iSuccess = DAL.fnAddPOReport(Global.uUPDATE, cmbPONO.Text, cmbtransactiontype.Text, cmbNatureofTransaction.Text, cmbNatureofSupply.Text, txtShippedFrom.Text,
                                            txtShippedStateCode.Text, txtShippedGSTIn.Text, Convert.ToDouble(txtInvoiceTotal.Text), Convert.ToDouble(txtAmountPaid.Text), Convert.ToDouble(txtBalanceDue.Text), txtShippedCountry.Text, cmbDeliverTerms.Text, cmbPaymentTerms.Text, txtShippedFrom1.Text, cmbIncoterm.Text, txtIncoterm.Text);
                                    }
                                    else
                                    {
                                        GLobalClass.iSuccess = DAL.fnAddPOReport(Global.uINSERT, cmbPONO.Text, cmbtransactiontype.Text, cmbNatureofTransaction.Text, cmbNatureofSupply.Text, txtShippedFrom.Text,
                                        txtShippedStateCode.Text, txtShippedGSTIn.Text, Convert.ToDouble(txtInvoiceTotal.Text), Convert.ToDouble(txtAmountPaid.Text), Convert.ToDouble(txtBalanceDue.Text), txtShippedCountry.Text, cmbDeliverTerms.Text, cmbPaymentTerms.Text, txtShippedFrom1.Text, cmbIncoterm.Text, txtIncoterm.Text);
                                    }

                                    btnprintpo_Click(sender, e);
                                //shreeshail is added bellow code
                                List<string> lstusers1 = new List<string>
                                    {
                                 "thilak_jaganath@instron.com",
                                 "Vishal_Raina@instron.com",
                                    
                                    //"Karjol_GT@instron.com"
                                    };
                        fnApprovetMailPMalert("Thilak Kumar", txtRemarks.Text, lstusers1, null);
                             //  fnApprovetMailPMalert("BiSS", txtRemarks.Text, lstusers1, null);
                                DataTable dtCheckDepartment = new DataTable();
                                    dtCheckDepartment = DAL.fnUserList(lblPrepareBy.Text).Tables[0];
                                    GLobalClass.iSuccess = DAL.fnAddERPLog(0, cmbPONO.Text, login.GetUserDetails[2], dtppreparedate.Text, "PO Approved", "PurchaseOrder");
                                    if (dtCheckDepartment.Rows.Count > 0)
                                    {

                                        if (dtCheckDepartment.Rows[0]["Department"].ToString() == "Testlab")
                                        {
                                     //  fnApprovetMail("biss", txtRemarks.Text, lstusers, FileFul);
                                      fnApprovetMail("Manoj", txtRemarks.Text, lstusers, FileFul);
                                        MessageBox.Show("PO " + cmbPONO.Text + " is approved & email alert sent to Manoj", "Success", 0, MessageBoxIcon.Information);
                                        }
                                        else if (dtCheckDepartment.Rows[0]["Department"].ToString() == "RnD" || dtCheckDepartment.Rows[0]["Department"].ToString() == "Electronics R&D")
                                        {
                                      //  fnApprovetMail("biss", txtRemarks.Text, lstusers, FileFul);
                                     fnApprovetMail("Somayya", txtRemarks.Text, lstusers, FileFul);
                                        MessageBox.Show("PO " + cmbPONO.Text + " is approved & email alert sent to Somayya", "Success", 0, MessageBoxIcon.Information);
                                        }
                                        else if(dtCheckDepartment.Rows[0]["Department"].ToString() == "Support" || dtCheckDepartment.Rows[0]["Department"].ToString()=="Design" || dtCheckDepartment.Rows[0]["Department"].ToString() == "Transducer")
                                        {
                                     //   fnApprovetMail("biss", txtRemarks.Text, lstusers, FileFul);
                                       fnApprovetMail("vishal raina", txtRemarks.Text, lstusers, FileFul);
                                        MessageBox.Show("PO " + cmbPONO.Text + " is approved & email alert sent to vishal raina", "Success", 0, MessageBoxIcon.Information);
                                        }
                                        else if (dtCheckDepartment.Rows[0]["Department"].ToString() == "Support" || dtCheckDepartment.Rows[0]["Department"].ToString() == "Design" || dtCheckDepartment.Rows[0]["Department"].ToString() == "Production" || dtCheckDepartment.Rows[0]["Department"].ToString() == "Assembly")
                                        {
                                     //   fnApprovetMail("biss", txtRemarks.Text, lstusers, FileFul);
                                       fnApprovetMail("Santhoshdj", txtRemarks.Text, lstusers, FileFul);
                                        MessageBox.Show("PO " + cmbPONO.Text + " is approved & email alert sent to Santhosh", "Success", 0, MessageBoxIcon.Information);
                                        }
                                        else if (dtCheckDepartment.Rows[0]["Department"].ToString() == "Electrical" || dtCheckDepartment.Rows[0]["Department"].ToString() == "Stores" || dtCheckDepartment.Rows[0]["Department"].ToString() == "Maintenance")
                                        {
                                      //  fnApprovetMail("biss", txtRemarks.Text, lstusers, FileFul);
                                       fnApprovetMail("Ravi", txtRemarks.Text, lstusers, FileFul);
                                        MessageBox.Show("PO " + cmbPONO.Text + " is approved & email alert sent to Ravi", "Success", 0, MessageBoxIcon.Information);
                                        }
                                        else if (dtCheckDepartment.Rows[0]["Department"].ToString() == "Validation")
                                        {
                                     //   fnApprovetMail("biss", txtRemarks.Text, lstusers, FileFul);
                                      fnApprovetMail("Megha", txtRemarks.Text, lstusers, FileFul);
                                        MessageBox.Show("PO " + cmbPONO.Text + " is approved & email alert sent to Megha", "Success", 0, MessageBoxIcon.Information);
                                        }
                                        else if (dtCheckDepartment.Rows[0]["Department"].ToString() == "Marketing" || dtCheckDepartment.Rows[0]["Department"].ToString() == "BT" || dtCheckDepartment.Rows[0]["Department"].ToString() == "Order Processing")
                                        {
                                        GLobalClass.iSuccess = DAL.purchaseOrderApproval(18, cmbPONO.Text, dtppreparedate.Text, login.GetUserDetails[2], txtRemarks.Text);
                                      //  fnApprovetMail("biss", txtRemarks.Text, lstusers, FileFul);
                                        fnApprovetMail("Pavana", txtRemarks.Text, lstusers, FileFul);
                                        MessageBox.Show("PO " + cmbPONO.Text + " is approved & email alert sent to Pavana", "Success", 0, MessageBoxIcon.Information);
                                        }
                                        else if (dtCheckDepartment.Rows[0]["Department"].ToString() == "Stores")
                                        {
                                       //  fnApprovetMail("biss", txtRemarks.Text, lstusers, FileFul);
                                      fnApprovetMail("hemanth", txtRemarks.Text, lstusers, FileFul);
                                        MessageBox.Show("PO " + cmbPONO.Text + " is approved & email alert sent to Hemanth", "Success", 0, MessageBoxIcon.Information);
                                        }
                                        /*
                                        else
                                        {
                                            //fnApprovetMail("shreeshail", txtRemarks.Text, lstusers, FileFul);
                                            fnApprovetMail("Thilak Kumar", txtRemarks.Text, lstusers, FileFul);
                                            MessageBox.Show("PO " + cmbPONO.Text + " is approved & email alert sent to Thilak Kumar", "Success", 0, MessageBoxIcon.Information);
                                        }
                                        */

                                    }
                                
                                    sPONumber = null;
                                    FormReload();
                                
                            }
                            else
                            {
                                if (cmbcurrency.SelectedIndex < 0)
                                {
                                    MessageBox.Show("Please select the Currency", "Error", 0, MessageBoxIcon.Error);
                                }
                                else if (cmbPaymentTerms.SelectedIndex < 0)
                                {
                                    MessageBox.Show("Please select the Payment Term", "Error", 0, MessageBoxIcon.Error);
                                }
                                else if (cmbDeliverTerms.SelectedIndex < 0)
                                {
                                    MessageBox.Show("Please select the Deliver Term", "Error", 0, MessageBoxIcon.Error);
                                }
                                else if (cmbIncoterm.SelectedIndex < 0)
                                {
                                    MessageBox.Show("Please select the Inco term", "Error", 0, MessageBoxIcon.Error);
                                }
                                else if (string.IsNullOrEmpty(txtIncoterm.Text))
                                {
                                    MessageBox.Show("Enter the inco term  details", "Error", 0, MessageBoxIcon.Error);
                                }
                            }
                        }
                    }
                }
                else
                {
                    if (string.IsNullOrEmpty(txtRemarks.Text))
                    {
                        MessageBox.Show("Please write the remarks", "Error", 0, MessageBoxIcon.Error);
                        txtRemarks.Focus();
                    }
                    else if (string.IsNullOrEmpty(cmbPONO.Text))
                    {
                        MessageBox.Show("Select PO Number to Authorise", "Error", 0, MessageBoxIcon.Error);
                    }
                    else if (string.IsNullOrEmpty(cmbProjectcode.Text))
                    {
                        MessageBox.Show("Please Select Project", "Error", 0, MessageBoxIcon.Error);
                    }
                    else if (string.IsNullOrEmpty(cmbVendorName.Text))
                    {
                        MessageBox.Show("Please Select the Vendor", "Error", 0, MessageBoxIcon.Error);
                    }
                    else if (!bDeliverDate)
                    {
                        MessageBox.Show("Please select the delivery date", "Error", 0, MessageBoxIcon.Error);
                    }
                    else if (cmbEmailAlert.SelectedIndex < 0)
                    {
                        MessageBox.Show("Please select email alert sender name", "Error", 0, MessageBoxIcon.Error);
                        cmbEmailAlert.Focus();
                    }
                }
            }
        }


        //private void fnPOGenralTerms()
        //{
        //    foreach (DataGridViewRow row in dgvPOGeneralTerms.Rows)
        //    {
        //        if (row.Cells["POTerms"].Value.ToString().Trim() != "")
        //        {
        //            GLobalClass.iSuccess = DAL.fnUpdatePoProcess(6, cmbPONO.Text, login.GetUserDetails[2].ToString(), "", row.Cells["POTerms"].Value.ToString().Trim());
        //        }
        //    }
        //}

        private void btnRejectPO_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(cmbPONO.Text))
            {
                if (!string.IsNullOrEmpty(txtRemarks.Text.Trim()))
                {
                    //--VISHAL-- Thilak Kumar
                    if (Convert.ToBoolean(login.GetUserDetails[29]) == true)
                    {
                        //ReviewEmail(PONoDetails.Rows[0]["PMName"].ToString(), txtRemarks.Text);
                        ReviewEmail("Pavana", txtRemarks.Text);
                    
                        GLobalClass.iSuccess = DAL.POReview(29, cmbPONO.Text, txtRemarks.Text);
                        sPONumber = null;
                        FormReload();
                    }
                    
                    //--Vivek G
                    if (Convert.ToBoolean(login.GetUserDetails[85]) == true)
                    {
                        //ReviewEmail(PONoDetails.Rows[0]["PMName"].ToString(), txtRemarks.Text);
                        ReviewEmail("Pavana", txtRemarks.Text);
                        GLobalClass.iSuccess = DAL.POReview(29, cmbPONO.Text, txtRemarks.Text);
                        sPONumber = null;
                        FormReload();
                    }
                    

                    //Theertha Rao
                    else if (Convert.ToBoolean(login.GetUserDetails[80]) == true)
                    {
                        ReviewEmail("Pavana", txtRemarks.Text);
                        GLobalClass.iSuccess = DAL.POReview(29, cmbPONO.Text, txtRemarks.Text);
                        sPONumber = null;
                        FormReload();
                    }



                    //RAMAKRISHNA
                    else if (Convert.ToBoolean(login.GetUserDetails[30]) == true)
                    {
                        ReviewEmail("Pavana", txtRemarks.Text);
                        GLobalClass.iSuccess = DAL.POReview(29, cmbPONO.Text, txtRemarks.Text);
                        sPONumber = null;
                        FormReload();
                    }

                    //RAKESH
                    else if (Convert.ToBoolean(login.GetUserDetails[31]) == true)
                    {
                        MessageBox.Show("You cannot review purachase order. You can edit or delete the PO items if not required.", "Error", 0, MessageBoxIcon.Error);
                    }

                    //RAVI
                    else if (Convert.ToBoolean(login.GetUserDetails[32]) == true)
                    {
                        ReviewEmail(PONoDetails.Rows[0]["PMName"].ToString(), txtRemarks.Text);
                        GLobalClass.iSuccess = DAL.POReview(29, cmbPONO.Text, txtRemarks.Text);
                        sPONumber = null;
                        FormReload();
                    }

                    else if (Convert.ToBoolean(login.GetUserDetails[16]) == true && chkPrintPO.Checked)
                    {
                        if (!string.IsNullOrEmpty(txtRemarks.Text.Trim()) && !string.IsNullOrEmpty(cmbPONO.Text))
                        {
                            GLobalClass.iSuccess = DAL.purchaseOrderApproval(29, cmbPONO.Text, dtppreparedate.Text, login.GetUserDetails[2], txtRemarks.Text);
                            string sEmialUser = "Pavana";
                            CreateUpdateEMail(sEmialUser, txtRemarks.Text, "Request");
                        }

                        else
                        {
                            if (string.IsNullOrEmpty(cmbPONO.Text))
                            {
                                MessageBox.Show("Select PO Number to accept purachase order", "Error", 0, MessageBoxIcon.Error);
                            }
                            else if (string.IsNullOrEmpty(txtRemarks.Text))
                            {
                                MessageBox.Show("Please write the po amend remarks", "Error", 0, MessageBoxIcon.Error);
                                txtRemarks.Focus();
                            }
                            else if (cmbEmailAlert.SelectedIndex < 0)
                            {
                                MessageBox.Show("Please select email alert sender name", "Error", 0, MessageBoxIcon.Error);
                            }
                        }
                    }

                    //shreeshail is added code lizzy below code
                    else if (login.GetUserDetails[2].ToLower() == "lizzy" && chkPrintPO.Checked)
                    {
                        if (!string.IsNullOrEmpty(txtRemarks.Text.Trim()) && !string.IsNullOrEmpty(cmbPONO.Text))
                        {
                            GLobalClass.iSuccess = DAL.purchaseOrderApproval(29, cmbPONO.Text, dtppreparedate.Text, login.GetUserDetails[2], txtRemarks.Text);
                            string sEmialUser = "lizzy";
                            CreateUpdateEMail(sEmialUser, txtRemarks.Text, "Request");
                        }

                        else
                        {
                            if (string.IsNullOrEmpty(cmbPONO.Text))
                            {
                                MessageBox.Show("Select PO Number to accept purachase order", "Error", 0, MessageBoxIcon.Error);
                            }
                            else if (string.IsNullOrEmpty(txtRemarks.Text))
                            {
                                MessageBox.Show("Please write the po amend remarks", "Error", 0, MessageBoxIcon.Error);
                                txtRemarks.Focus();
                            }
                            else if (cmbEmailAlert.SelectedIndex < 0)
                            {
                                MessageBox.Show("Please select email alert sender name", "Error", 0, MessageBoxIcon.Error);
                            }
                        }
                    }
                    //shreeshail is added above else if condition

                    //shreeshail is added code venna below code
                    else if (login.GetUserDetails[2].ToLower() == "veena" || login.GetUserDetails[2].ToLower() == "pavana" || login.GetUserDetails[2].ToLower() == "hemanth reddy" && chkPrintPO.Checked)
                    {
                        if (!string.IsNullOrEmpty(txtRemarks.Text.Trim()) && !string.IsNullOrEmpty(cmbPONO.Text))
                        {
                            GLobalClass.iSuccess = DAL.purchaseOrderApproval(29, cmbPONO.Text, dtppreparedate.Text, login.GetUserDetails[2], txtRemarks.Text);
                            string sEmialUser = "Pavana";
                            CreateUpdateEMail(sEmialUser, txtRemarks.Text, "Request");
                        }

                        else
                        {
                            if (string.IsNullOrEmpty(cmbPONO.Text))
                            {
                                MessageBox.Show("Select PO Number to accept purachase order", "Error", 0, MessageBoxIcon.Error);
                            }
                            else if (string.IsNullOrEmpty(txtRemarks.Text))
                            {
                                MessageBox.Show("Please write the po amend remarks", "Error", 0, MessageBoxIcon.Error);
                                txtRemarks.Focus();
                            }
                            else if (cmbEmailAlert.SelectedIndex < 0)
                            {
                                MessageBox.Show("Please select email alert sender name", "Error", 0, MessageBoxIcon.Error);
                            }
                        }
                    }
                    //shreeshail is added above else if condition

                    //MuthuRamalingam
                    else if (Convert.ToBoolean(login.GetUserDetails[16]) == true && Convert.ToBoolean(login.GetUserDetails[30]) != true || login.GetUserDetails[2].ToLower() == "lizzy" && Convert.ToBoolean(login.GetUserDetails[30]) != true || login.GetUserDetails[2].ToLower() == "veena" || login.GetUserDetails[2].ToLower() == "pavana" || login.GetUserDetails[2].ToLower() == "hemanth reddy" && Convert.ToBoolean(login.GetUserDetails[30]) != true)
                    {
                        ReviewEmail(PONoDetails.Rows[0]["FinalizedBy"].ToString(), txtRemarks.Text);
                        GLobalClass.iSuccess = DAL.POReview(29, cmbPONO.Text, txtRemarks.Text);
                        sPONumber = null;
                        FormReload();
                    }



                }
                else
                {
                    MessageBox.Show("Please write review reason to review purachase order", "Error", 0, MessageBoxIcon.Error);
                    txtRemarks.Focus();
                }
            }
            else
            {
                MessageBox.Show("Select PO Number to review purachase order", "Error", 0, MessageBoxIcon.Error);
            }






            //else if (Convert.ToBoolean(login.GetUserDetails[16]) == true)
            //{
            //    if (!string.IsNullOrEmpty(txtRemarks.Text.Trim()) && !string.IsNullOrEmpty(cmbPONO.Text))
            //    {
            //        GLobalClass.iSuccess = DAL.purchaseOrderApproval(9, cmbPONO.Text, dtppreparedate.Text, login.GetUserDetails[2], txtRemarks.Text);
            //        string sEmialUser = PONoDetails.Rows[0]["PurchaseCommitee"].ToString();
            //        CreateUpdateEMail(sEmialUser, txtRemarks.Text, "Request");
            //    }
            //    else
            //    {
            //        if (string.IsNullOrEmpty(cmbPONO.Text))
            //        {
            //            MessageBox.Show("Select PO Number to accept purachase order", "Error", 0, MessageBoxIcon.Error);
            //        }
            //        else if (string.IsNullOrEmpty(txtRemarks.Text))
            //        {
            //            MessageBox.Show("Please write the po amend remarks", "Error", 0, MessageBoxIcon.Error);
            //            txtRemarks.Focus();
            //        }
            //        else if (cmbEmailAlert.SelectedIndex < 0)
            //        {
            //            MessageBox.Show("Please select email alert sender name", "Error", 0, MessageBoxIcon.Error);
            //        }
            //    }
            //}
            //Rakesh
            //else if (Convert.ToBoolean(login.GetUserDetails[31]) == true)
            //{
            //    if (!string.IsNullOrEmpty(cmbPONO.Text))
            //    {
            //        if (!string.IsNullOrEmpty(txtRemarks.Text))
            //        {

            //        }
            //        else
            //        {
            //            MessageBox.Show("Please write review reason to review purachase order", "Error", 0, MessageBoxIcon.Error);
            //            txtRejectReason.Focus();
            //        }
            //    }
            //    else
            //    {
            //        MessageBox.Show("Select PO Number to review purachase order", "Error", 0, MessageBoxIcon.Error);
            //    }
            //}
            //Ravi
            //else if (Convert.ToBoolean(login.GetUserDetails[32]) == true)
            //{
            //    if (!string.IsNullOrEmpty(cmbPONO.Text))
            //    {
            //        if (!string.IsNullOrEmpty(txtPMMHRemarks.Text))
            //        {
            //         
            //        }
            //        else
            //        {
            //            MessageBox.Show("Please write review reason to review purachase order", "Error", 0, MessageBoxIcon.Error);
            //            txtRejectReason.Focus();
            //        }
            //    }
            //    else
            //    {
            //        MessageBox.Show("Select PO Number to review purachase order", "Error", 0, MessageBoxIcon.Error);
            //    }
            //}
        }




        private void VendorEMail(string sUser, string attachmentFilename)
        {
            try
            {
                bMail = false;
                lstusers.Items.Clear();
                DataTable dtsCCUsers = DAL.POWOCCList(1, cmbPONO.Text).Tables[0];
                if (dtsCCUsers.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtsCCUsers.Rows[0]["emailid"].ToString()) && !lstusers.Items.Contains(dtsCCUsers.Rows[0]["emailid"].ToString()))
                    {
                        lstusers.Items.Add(dtsCCUsers.Rows[0]["emailid"].ToString());
                    }
                    if (!string.IsNullOrEmpty(dtsCCUsers.Rows[0]["emailid1"].ToString()) && !lstusers.Items.Contains(dtsCCUsers.Rows[0]["emailid1"].ToString()))
                    {
                        lstusers.Items.Add(dtsCCUsers.Rows[0]["emailid1"].ToString());
                    }
                    if (!string.IsNullOrEmpty(dtsCCUsers.Rows[0]["emailid2"].ToString()) && !lstusers.Items.Contains(dtsCCUsers.Rows[0]["emailid2"].ToString()))
                    {
                        lstusers.Items.Add(dtsCCUsers.Rows[0]["emailid2"].ToString());
                    }
                    if (!string.IsNullOrEmpty(dtsCCUsers.Rows[0]["emailid3"].ToString()) && !lstusers.Items.Contains(dtsCCUsers.Rows[0]["emailid3"].ToString()))
                    {
                        lstusers.Items.Add(dtsCCUsers.Rows[0]["emailid3"].ToString());
                    }

                    string pmName = dtsCCUsers.Rows[0]["PMName"].ToString().ToLower();
                    string purchaseCommittee = dtsCCUsers.Rows[0]["PurchaseCommitee"].ToString().ToLower();

                    if (pmName == "dinesh" && purchaseCommittee == "santhoshdj")
                    {
                        string extraEmail = "ravindra_naiker@instron.com";
                        if (!lstusers.Items.Contains(extraEmail))
                            lstusers.Items.Add(extraEmail);
                    }
                }


                Outlook.Application oApp = new Outlook.Application();
                Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);


                oMsg.Subject = "" + cmbPONO.Text + " to : " + cmbVendorName.Text + "";
                //oMsg.HTMLBody = "Dear Sir/Madam, <br /><br />  Please find attached Purchase Order "+cmbPONO.Text+" dated "+ dtppreparedate.Text + " for your reference. <br />  We request you to share your Order Acceptance / Order Acknowledgement including the following details: <br /><br />  <li>Our Purchase Order Number<li/> <li>Item Description and Quantity<li/><li>Estimated Date of Readiness for Supply<li/> <br/> Kindly ensure this confirmation is sent within 7 working days from the date of this communication. If we do not receive your acknowledgment within the stipulated time, it will be deemed that our Purchase Order and its Terms & Conditions have been fully accepted without any changes.<br/> Important Instructions <br/> <li>Please provide the signed hard copy of the Purchase Order, duly stamped with your company seal, and signed on the last page, at the time of supply.<li/><li>For invoices exceeding ₹50,000, ensure that the hard copy of the waybill is attached along with your invoice during delivery.<li/> <li>Materials will not be accepted/in-warded without Our PO copy, Checklist / Packing slip (where applicable)<li/> <br/> Kindly treat this request as urgent and acknowledge receipt of the PO at the earliest. For any clarification or deviation, please contact us with the PO reference number. <br/> Thank you for your cooperation.";


                oMsg.HTMLBody = $@"
                    <html>
                    <body style='font-family:Arial; font-size:14px;'>
                    <p>Dear Sir/Madam,</p>

                    <p>Please find attached Purchase Order <b>{cmbPONO.Text}</b> dated <b>{dtppreparedate.Text}</b> for your reference.</p>

                    <p>We request you to share your Order Acceptance / Order Acknowledgement including the following details:</p>
                    <ul>
                        <li>Our Purchase Order Number</li>
                        <li>Item Description and Quantity</li>
                        <li>Estimated Date of Readiness for Supply</li>
                    </ul>

                    <p>Kindly ensure this confirmation is sent within 7 working days from the date of this communication. 
                    If we do not receive your acknowledgment within the stipulated time, it will be deemed that our Purchase Order and its Terms &amp; Conditions have been fully accepted without any changes.</p>

                    <p><b>Important Instructions:</b></p>
                    <ul>
                        <li>Please provide the signed hard copy of the Purchase Order, duly stamped with your company seal, and signed on the last page, at the time of supply.</li>
                        <li>For invoices exceeding ₹50,000, ensure that the hard copy of the waybill is attached along with your invoice during delivery.</li>
                        <li>Materials will not be accepted/in-warded without Our PO copy, Checklist / Packing slip (where applicable).</li>
                    </ul>

                    <p>Kindly treat this request as urgent and acknowledge receipt of the PO at the earliest. 
                    For any clarification or deviation, please contact us with the PO reference number.</p>

                    <p>Thank you for your cooperation.</p>
                    </body>
                    </html>";

                oMsg.HTMLBody += ReadSignature();
                // Add a recipient.
                Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                oRecips.Add(sUser);
                oRecips.ResolveAll();

                try
                {
                   // string termsPdf = @"C:\Temp\TermsAndConditions.pdf";
                    if (attachmentFilename != null)
                        oMsg.Attachments.Add(attachmentFilename);
                   // oMsg.Attachments.Add(termsPdf);
                    // Your file attachment logic
                }
                catch (FileNotFoundException ex)
                {
                    MessageBox.Show($"Attachment file not found: {ex.Message}");
                }


                

                if (lstusers.Items.Count > 0)
                {
                    Outlook.Recipient oRecip;
                    List<string> sCCRecipsList = new List<string>();
                    foreach (string tempTO in lstusers.Items)
                    {
                        if (tempTO != null)
                            sCCRecipsList.Add(tempTO);
                    }
                    foreach (string t in sCCRecipsList)
                    {
                        oRecip = (Outlook.Recipient)oRecips.Add(t);
                        oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                        oRecip.Resolve();
                    }
                }
                //Outlook.Recipient oRecip;

                //oRecip = (Outlook.Recipient)oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                //oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                //oRecip.Resolve();


                // Send.
                oMsg.Display();

                // // var msg = Item as Outlook.MailItem;
                //   string newPath = @"\\D:\shivand RT\\";
                //// string newPath = @"\\192.168.1.81\ERP_Project_Document\Vendor Email\\" + "" + cmbPONO.Text + " to " + cmbVendorName.Text + ""; 
                // oMsg.SaveAs(newPath, Outlook.OlSaveAsType.olMSG);

                // oMsg.Send();
                bMail = true;
                // Clean up.
                oRecips = null;
                oMsg = null;
                oApp = null;
                //oRecip = null;
                //}
                //}

            }
            catch (Exception ex)
            {
                MessageBox.Show("Catch '" + ex + "' ", "Error", 0, MessageBoxIcon.Information);
            }
        }

        //\\192.168.1.81\ERP_Project_Document\Vendor Email
        private string ReadSignature()
        {
            string appDataDir = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\Microsoft\\Signatures";
            string signature = string.Empty;
            DirectoryInfo diInfo = new DirectoryInfo(appDataDir);

            if (diInfo.Exists)
            {
                FileInfo[] fiSignature = diInfo.GetFiles("*.htm");

                if (fiSignature.Length > 0)
                {
                    StreamReader sr = new StreamReader(fiSignature[0].FullName, Encoding.Default);
                    signature = sr.ReadToEnd();

                    if (!string.IsNullOrEmpty(signature))
                    {
                        string fileName = fiSignature[0].Name.Replace(fiSignature[0].Extension, string.Empty);
                        signature = signature.Replace(fileName + "_files/", appDataDir + "/" + fileName + "_files/");
                    }
                }
            }
            return signature;
        }

        private void CreateUpdateEMail(string sUser, string sRemarks, string sReqeust)
        {
            try
            {
                bMail = false;
                DataTable dtlogindetails = DAL.fnloginemail(sUser).Tables[0]; ;
                if (dtlogindetails.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
                    {
                        Outlook.Application oApp = new Outlook.Application();
                        Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);

                        if (sReqeust != "Request")
                        {
                            oMsg.Subject = "" + cmbPONO.Text + " amend";
                            oMsg.HTMLBody = " Dear " + sUser.ToUpper() + ", <br /><br /> Purchase Order " + cmbPONO.Text + " requested details changed. <br /><br /><br /><br /><b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";
                        }
                        else
                        {
                            oMsg.Subject = "" + cmbPONO.Text + " amend";
                            oMsg.HTMLBody = " Dear " + sUser.ToUpper() + ", <br /><br /> Purchase Order " + cmbPONO.Text + " requested to do amend. <br /> The changes required are : " + sRemarks + ".<br /><br /><br /><br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";
                        }
                        // Add a recipient.
                        Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                        oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                        oRecips.ResolveAll();
                        // Send.
                        oMsg.Send();
                        bMail = true;
                        // Clean up.
                        oRecips = null;
                        oMsg = null;
                        oApp = null;
                    }
                }

                if (bMail == true)
                {
                    MessageBox.Show("Mail alert sent to '" + sUser + "' successfully!", "Success", 0, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void CreateEMail(string sUser, string sRemarks)
        {
            try
            {
                bMail = false;
                DataTable dtlogindetails = DAL.fnloginemail(sUser).Tables[0]; ;
                if (dtlogindetails.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
                    {
                        Outlook.Application oApp = new Outlook.Application();
                        Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);

                        if (sUser != "Hebbarrk")
                        {
                            oMsg.Subject = "" + cmbPONO.Text + " sent back for review";
                            oMsg.HTMLBody = " Dear " + sUser.ToUpper() + ", <br /><br /><font color='red'> Purchase order " + cmbPONO.Text + " sent back for review . <br/> <br/> Review reason : " + sRemarks + " </font><br /> <br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";
                        }
                        else
                        {
                            oMsg.Subject = "" + cmbPONO.Text + " sent for approval";
                            oMsg.HTMLBody = " Dear " + sUser.ToUpper() + ", <br /><br /> Purchase order <font color='blue'>" + cmbPONO.Text + "</font> sent for approval.<br />   <b> <font color='red'>" + sSixMonthsMessage + "</font><br />   <b>";

                            oMsg.HTMLBody += GetTableFromDataGridWorkOrder();

                            oMsg.HTMLBody += "<br /><br /><br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /><br /><br /><br /><br /> <b>**** This is an auto generated E-mail. Please do not reply. ****</b>";
                        }
                        // Add a recipient.
                        Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                        oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                        oRecips.ResolveAll();
                        // Send.
                        oMsg.Send();
                        bMail = true;
                        // Clean up.
                        oRecips = null;
                        oMsg = null;
                        oApp = null;
                    }
                }

                if (bMail == true)
                {
                    MessageBox.Show("Mail alert sent to '" + sUser + "' successfully!", "Success", 0, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {

            }
        }

        public void fnApprovetMail(string sUser, string sRemarks, ListBox sCC, string attachmentFilename)
        {

            bMail = false;
            DataTable dtlogindetails = DAL.fnloginemail(sUser.Trim()).Tables[0];
            if (dtlogindetails.Rows.Count > 0)
            {
                if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
                {
                    Outlook.Application oApp = new Outlook.Application();
                    Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);

                    if (login.GetUserDetails[2] == "Hebbarrk")
                    {
                        oMsg.Subject = "" + cmbPONO.Text + " approved";
                        oMsg.HTMLBody = " Dear " + sUser.ToUpper() + ", <br /><br /><font color='blue'> Purchase order " + cmbPONO.Text + " approved </font>. <font color='red'>" + sSixMonthsMessage + "</font><br /> Remarks : " + sRemarks + " <br /> <br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";
                    }
                    else
                    {
                        oMsg.Subject = "" + cmbPONO.Text + " sent for " + sGM + " approval";
                        oMsg.HTMLBody = " Dear " + sUser.ToUpper() + ", <br /><br /> Purchase order <font color='blue'>" + cmbPONO.Text + " </font> sent for " + sGM + " approval. <font color='red'> " + sSixMonthsMessage + "<br /></font> Remarks : <br /> <br />";

                        oMsg.HTMLBody += GetTableFromDataGridWorkOrder();

                        oMsg.HTMLBody += "<br /><br /><br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /><br /><br /><br /><br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";
                    }
                    Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                    oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                    oRecips.ResolveAll();

                    

                    try
                    {
                        if (File.Exists(attachmentFilename))
                        {
                            if (attachmentFilename != null)
                                oMsg.Attachments.Add(attachmentFilename);
                        }

                    }
                    catch (FileNotFoundException ex)
                    {
                        MessageBox.Show($"Attachment file not found: {ex.Message}");
                    }

                    if (sCC.Items.Count > 0)
                    {
                        Outlook.Recipient oRecip;
                        List<string> sCCRecipsList = new List<string>();
                        foreach (string tempTO in sCC.Items)
                        {
                            if (tempTO != null)
                                sCCRecipsList.Add(tempTO);
                        }
                        foreach (string t in sCCRecipsList)
                        {
                            oRecip = (Outlook.Recipient)oRecips.Add(t);
                            oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                            oRecip.Resolve();
                        }
                        oMsg.Send();
                        oRecip = null;
                    }
                    else
                    {
                        oMsg.Send();
                        oRecips = null;
                    }
                    bMail = true;
                    oMsg = null;
                    oApp = null;
                }
            }
            sGM = "";
        }








        public void fnAlertMailPOGenrate(string sUser, string sRemarks)
        {
            try
            {
                bMail = false;
                DataTable dtlogindetails = DAL.fnloginemail(sUser).Tables[0]; ;
                if (dtlogindetails.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
                    {
                        Outlook.Application oApp = new Outlook.Application();
                        Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                        oMsg.Subject = "" + cmbPONO.Text + " Sent for generating a purchase order.";
                        oMsg.HTMLBody = " Dear " + sUser.ToUpper() + ", <br /><br /> purchase order <font color='blue'>" + cmbPONO.Text + "</font>  has been sent for processing.<br /> <br /><b> <font color='red'>" + sSixMonthsMessage + "</font></b><br /> <br /> Remarks : " + sRemarks + " <br /> <br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";
                        // Add a recipient.
                        Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                        oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                        oRecips.ResolveAll();
                        // Send.
                        oMsg.Send();
                        bMail = true;
                        // Clean up.
                        oRecips = null;
                        oMsg = null;
                        oApp = null;
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        public void fnAlertMailOM(string sUser, string sRemarks)
        {
            try
            {
                bMail = false;
                DataTable dtlogindetails = DAL.fnloginemail(sUser).Tables[0]; ;
                if (dtlogindetails.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
                    {
                        Outlook.Application oApp = new Outlook.Application();
                        Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                        oMsg.Subject = "" + cmbPONO.Text + " Sent for Approval.";
                        oMsg.HTMLBody = " Dear " + sUser.ToUpper() + ", <br /><br /> purchase order <font color='blue'>" + cmbPONO.Text + "</font>  has been sent for Approval.<br /> <br /><b> <font color='red'>" + sSixMonthsMessage + "</font></b><br /> <br /> Remarks : " + sRemarks + " <br /> <br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";
                        // Add a recipient.
                        Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                        oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                        oRecips.ResolveAll();
                        // Send.
                        oMsg.Send();
                        bMail = true;
                        // Clean up.
                        oRecips = null;
                        oMsg = null;
                        oApp = null;
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }


        //shreeshail is added bllow code
        /*
        public void fnApprovetMailPMalert(string sUser, string sRemarks, ListBox sCC, string attachmentFilename)
        {
            bool bMail = false;
            DataTable dtLoginDetails = DAL.fnloginemail(sUser.Trim()).Tables[0];
            DataTable dtCurrencyPO = DAL.fnCurrencyPO(cmbPONO.Text, cmbcurrency.Text).Tables[0];
            string currencyType = dtCurrencyPO.Rows[0]["Currency"].ToString();

            DataTable dtCurrencyPoSybal = DAL.fnCurrencyPoSybal(currencyType).Tables[0];

            if (dtLoginDetails.Rows.Count > 0)
            {
                string emailID = dtLoginDetails.Rows[0]["emailid"].ToString();
                if (!string.IsNullOrEmpty(emailID))
                {
                    Outlook.Application oApp = null;
                    Outlook.MailItem oMsg = null;

                    try
                    {
                        oApp = new Outlook.Application();
                        oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);

                        // Fetching purchase order details and total amount using POdetailsHistory method
                        DataSet dsPOdetailsHistory = DAL.POdetailsHistory(1, cmbProjectcode.Text, cmbPONO.Text);
                        DataSet dsTotalAmount = DAL.POdetailsHistory(2, cmbProjectcode.Text, cmbPONO.Text);

                        DataTable POdetailsHistory = dsPOdetailsHistory.Tables[0];
                        string totalAmount = dsTotalAmount.Tables[0].Rows[0]["TotalAmount"].ToString();
                        string currencySymbol = dtCurrencyPoSybal.Rows[0]["CurrencySymbol"].ToString();
                        string formattedTotalAmount = string.Format(CultureInfo.InvariantCulture, "{0} {1:N2}", currencySymbol, Convert.ToDecimal(totalAmount));

                        // Generating the HTML table from the DataTable
                        string htmlTable = GenerateHTMLTable(POdetailsHistory);

                        oMsg.Subject = $"{cmbPONO.Text} sent for PO Information";
                        oMsg.HTMLBody = $@"
            Dear {sUser.ToUpper()},<br /><br />
            Purchase order <font color='blue'>{cmbPONO.Text}</font> has been sent for generating information.
            <font color='red'>{sSixMonthsMessage}</font><br />
            PODetails:<br /><br />
            {htmlTable}
            <br /><br />
            <b>Total Amount:</b> {formattedTotalAmount}<br /><br />
            Regards,<br />
            {login.GetUserDetails[2].ToUpper()}<br /><br /><br /><br /><br />
            <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";

                        Outlook.Recipients oRecips = oMsg.Recipients;
                        oRecips.Add(emailID);
                        oRecips.ResolveAll();

                        if (!string.IsNullOrEmpty(attachmentFilename) && File.Exists(attachmentFilename))
                        {
                            oMsg.Attachments.Add(attachmentFilename);
                        }

                        Outlook.Recipient oRecip = oRecips.Add(sCC);
                        oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                        oRecip.Resolve();

                        oMsg.Send();
                        bMail = true;
                    }
                    catch (Exception ex)
                    {
                        // Log the exception or handle it as necessary
                        Console.WriteLine($"An error occurred: {ex.Message}");
                    }
                    finally
                    {
                        // Release COM objects to avoid memory leaks.
                        if (oMsg != null) Marshal.ReleaseComObject(oMsg);
                        if (oApp != null) Marshal.ReleaseComObject(oApp);
                    }
                }
            }

            sGM = string.Empty;
        }
        */

        public void fnApprovetMailPMalert(string sUser, string sRemarks, List<string> sCC, string attachmentFilename)
        {
            bool bMail = false;
            DataTable dtLoginDetails = DAL.fnloginemail(sUser.Trim()).Tables[0];
            DataTable dtCurrencyPO = DAL.fnCurrencyPO(cmbPONO.Text, cmbcurrency.Text).Tables[0];
            string currencyType = dtCurrencyPO.Rows[0]["Currency"].ToString();

            DataTable dtCurrencyPoSybal = DAL.fnCurrencyPoSybal(currencyType).Tables[0];

            if (dtLoginDetails.Rows.Count > 0)
            {
                string emailID = dtLoginDetails.Rows[0]["emailid"].ToString();
                if (!string.IsNullOrEmpty(emailID))
                {
                    Outlook.Application oApp = null;
                    Outlook.MailItem oMsg = null;

                    try
                    {
                        oApp = new Outlook.Application();
                        oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);

                        // Fetching purchase order details and total amount using POdetailsHistory method
                        DataSet dsPOdetailsHistory = DAL.POdetailsHistory(1, cmbProjectcode.Text, cmbPONO.Text);
                        DataSet dsTotalAmount = DAL.POdetailsHistory(2, cmbProjectcode.Text, cmbPONO.Text);

                        DataTable POdetailsHistory = dsPOdetailsHistory.Tables[0];
                        string totalAmount = dsTotalAmount.Tables[0].Rows[0]["TotalAmount"].ToString();
                        string currencySymbol = dtCurrencyPoSybal.Rows[0]["CurrencySymbol"].ToString();
                        string formattedTotalAmount = string.Format(CultureInfo.InvariantCulture, "{0} {1:N2}", currencySymbol, Convert.ToDecimal(totalAmount));

                        // Generating the HTML table from the DataTable
                        string htmlTable = GenerateHTMLTable(POdetailsHistory);

                        oMsg.Subject = $"{cmbPONO.Text} sent for PO Information";
                        oMsg.HTMLBody = $@"
                    Dear Sir/Madam,<br /><br />
                    Purchase order <font color='blue'>{cmbPONO.Text}</font> has been sent for generating information.
                    <font color='red'>{sSixMonthsMessage}</font><br />
                    PODetails:<br /><br />
                    {htmlTable}
                    <br /><br />
                    <b>Total Amount:</b> {formattedTotalAmount}<br /><br />
                    Regards,<br />
                    {login.GetUserDetails[2].ToUpper()}<br /><br /><br /><br /><br />
                    <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";

                        Outlook.Recipients oRecips = oMsg.Recipients;
                        oRecips.Add(emailID);
                        oRecips.ResolveAll();

                        


                        try
                        {
                            if (!string.IsNullOrEmpty(attachmentFilename) && File.Exists(attachmentFilename))
                            {
                                oMsg.Attachments.Add(attachmentFilename);
                            }
                        }
                        catch (FileNotFoundException ex)
                        {
                            MessageBox.Show($"Attachment file not found: {ex.Message}");
                        }

                        // Add each CC email address to the recipients
                        foreach (var ccEmail in sCC)
                        {
                            Outlook.Recipient oRecip = oRecips.Add(ccEmail);
                            oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                            oRecip.Resolve();
                        }

                        oMsg.Send();
                        bMail = true;
                    }
                    catch (Exception ex)
                    {
                        // Log the exception or handle it as necessary
                        Console.WriteLine($"An error occurred: {ex.Message}");
                    }
                    finally
                    {
                        // Release COM objects to avoid memory leaks.
                        if (oMsg != null) Marshal.ReleaseComObject(oMsg);
                        if (oApp != null) Marshal.ReleaseComObject(oApp);
                    }
                }
            }

            sGM = string.Empty;
        }

        // Helper method to generate HTML table from a DataTable
        private string GenerateHTMLTable(DataTable dataTable)
        {
            StringBuilder html = new StringBuilder();

            // Start the table
            html.Append("<table border='1' cellpadding='5' cellspacing='0'>");

            // Add header row
            html.Append("<tr>");
            foreach (DataColumn column in dataTable.Columns)
            {
                html.Append("<th>").Append(column.ColumnName).Append("</th>");
            }
            html.Append("</tr>");

            // Add data rows
            foreach (DataRow row in dataTable.Rows)
            {
                html.Append("<tr>");
                foreach (var item in row.ItemArray)
                {
                    html.Append("<td>").Append(item.ToString()).Append("</td>");
                }
                html.Append("</tr>");
            }

            // End the table
            html.Append("</table>");

            return html.ToString();
        }

        //shreeshail is added above code
        private void ReviewEmail_old(string sUser, string sRemarks)
        {
            bMail = false;
            DataTable dtlogindetails = DAL.fnloginemail(sUser).Tables[0]; 
            if (dtlogindetails.Rows.Count > 0)
            {
                if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
                {
                    Outlook.Application oApp = new Outlook.Application();
                    Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);

                    oMsg.Subject = "" + cmbPONO.Text + " sent back for review";
                    oMsg.HTMLBody = " Dear " + sUser.ToUpper() + ", <br /><br /><font color='red'> Purchase order " + cmbPONO.Text + " sent back for review . <br/> <br/> Review reason : " + sRemarks + " </font><br /> <br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";

                    // Add a recipient.
                    Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                    oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                    oRecips.ResolveAll();
                    // Send.
                    oMsg.Send();
                    bMail = true;
                    // Clean up.
                    oRecips = null;
                    oMsg = null;
                    oApp = null;
                }
            }

            if (bMail == true)
            {
                MessageBox.Show("Mail alert sent to '" + sUser + "' successfully!", "Success", 0, MessageBoxIcon.Information);
            }
        }


        
private void ReviewEmail(string sUser, string sRemarks)
    {
        bMail = false;
        DataTable dtlogindetails = DAL.fnloginemail(sUser).Tables[0];

        if (dtlogindetails.Rows.Count > 0)
        {
            if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
            {
                Outlook.Application oApp = null;

                // FIX: Load Outlook safely for all Office versions
                try
                {
                    oApp = Marshal.GetActiveObject("Outlook.Application") as Outlook.Application;
                }
                catch
                {
                    oApp = new Outlook.Application();
                }

                Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);

                oMsg.Subject = $"{cmbPONO.Text} sent back for review";
                oMsg.HTMLBody = $" Dear {sUser.ToUpper()}, <br /><br /><font color='red'> " +
                                $"Purchase order {cmbPONO.Text} sent back for review.<br/> <br/>" +
                                $"Review reason : {sRemarks} </font><br /><br />Regards,<br />" +
                                $"{login.GetUserDetails[2].ToUpper()}<br /><br />" +
                                "<b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";

                Outlook.Recipients oRecips = oMsg.Recipients;
                oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                oRecips.ResolveAll();

                oMsg.Send();
                bMail = true;

                oRecips = null;
                oMsg = null;
                oApp = null;
            }
        }

        if (bMail)
        {
            MessageBox.Show($"Mail alert sent to '{sUser}' successfully!", "Success",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
    bool bMail = false;
        #region Unawanted Email
        //public void fnMail(string sUser, string sRemarks)
        //{
        //    bMail = false;
        //    DataTable dtlogindetails = DAL.fnloginemail(sUser).Tables[0]; ;
        //    if (dtlogindetails.Rows.Count > 0)
        //    {
        //        if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
        //        {
        //            try
        //            {
        //                MailMessage mail = new MailMessage();
        //                mail.From = new MailAddress("erpbiss@gmail.com");
        //                mail.To.Add(new MailAddress("" + dtlogindetails.Rows[0]["emailid"].ToString() + ""));

        //                if (sUser != "Hebbarrk")
        //                {
        //                    mail.Subject = "'" + cmbPONO.Text + "' sent back for review";
        //                    mail.IsBodyHtml = true;
        //                    string sLink = "";
        //                    mail.Body = " Dear " + sUser.ToUpper() + ", <br /><br /> Purchase Order ' " + cmbPONO.Text + " ' sent back for review. <br/> <a href='\\C:\\Users\\SOFTWARE8\\Desktop\\BiSS ERP v2.0.exe'></a>  <br /> Review reason : " + sRemarks + " <br /> <br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /> ** THIS IS AN AUTO GENARATED EMAIL. PLEASE DO NOT REPLY **";
        //                }
        //                else
        //                {
        //                    mail.Subject = "'" + cmbPONO.Text + "' sent for approval";
        //                    mail.IsBodyHtml = true;
        //                    mail.Body = " Dear " + sUser.ToUpper() + ", <br /><br /> Purchase Order ' " + cmbPONO.Text + " ' sent for approval.<br /> Purchase commitee : " + sRemarks + " <br /> <br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /> ** THIS IS AN AUTO GENARATED EMAIL. PLEASE DO NOT REPLY **";
        //                }
        //                SmtpClient SmtpServer = new SmtpClient();
        //                SmtpServer.Host = "smtp.gmail.com";
        //                SmtpServer.Port = 587;
        //                SmtpServer.Credentials = new System.Net.NetworkCredential("erpbiss@gmail.com", "erpbiss1");
        //                SmtpServer.EnableSsl = true;
        //                SmtpServer.Send(mail);
        //                bMail = true;
        //            }
        //            catch (Exception ex)
        //            {
        //                bMail = false;
        //                MessageBox.Show("Error: " + ex.Message);
        //            }
        //        }
        //    }

        //    if (bMail == true)
        //    {
        //        MessageBox.Show("Mail alert sent to '" + sUser + "' successfully!", "Success", 0, MessageBoxIcon.Information);
        //    }
        //}

        #endregion

        string sGM = "";
        public void fnAlertMail(string sUser, string sRemarks, ListBox sCC)
        {

            bMail = false;
            DataTable dtlogindetails = DAL.fnloginemail(sUser.Trim()).Tables[0]; 
            if (dtlogindetails.Rows.Count > 0)
            {
                if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
                {
                    Outlook.Application oApp = new Outlook.Application();
                    Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);

                    if (login.GetUserDetails[2] == "Hebbarrk")
                    {
                        oMsg.Subject = "" + cmbPONO.Text + " approved";
                        oMsg.HTMLBody = " Dear " + sUser.ToUpper() + ", <br /><br /><font color='blue'> Purchase order " + cmbPONO.Text + " approved </font>. <font color='red'>" + sSixMonthsMessage + "</font><br /> Remarks : " + sRemarks + " <br /> <br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";
                    }
                    else
                    {
                        oMsg.Subject = "" + cmbPONO.Text + " sent for " + sGM + " approval";
                        oMsg.HTMLBody = " Dear " + sUser.ToUpper() + ", <br /><br /> Purchase order <font color='blue'>" + cmbPONO.Text + " </font> sent for " + sGM + " approval. <font color='red'> " + sSixMonthsMessage + "<br /></font> Remarks : <br /> <br />";
                        oMsg.HTMLBody += GetTableFromDataGridWorkOrder();

                        oMsg.HTMLBody += "<br /><br /><br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /><br /><br /><br /><br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";

                    }
                    Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                    oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                    oRecips.ResolveAll();


                    if (sCC.Items.Count > 0)
                    {
                        Outlook.Recipient oRecip;
                        List<string> sCCRecipsList = new List<string>();
                        foreach (string tempTO in sCC.Items)
                        {
                            if (tempTO != null)
                                sCCRecipsList.Add(tempTO);
                        }
                        foreach (string t in sCCRecipsList)
                        {
                            oRecip = (Outlook.Recipient)oRecips.Add(t);
                            oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                            oRecip.Resolve();
                        }
                        oMsg.Send();
                        oRecip = null;
                    }
                    else
                    {
                        oMsg.Send();
                        oRecips = null;
                    }
                    bMail = true;
                    oMsg = null;
                    oApp = null;
                }
            }
            sGM = "";
        }


        private void cbViewRemarks_CheckedChanged(object sender, EventArgs e)
        {
            if (cbViewRemarks.CheckState == CheckState.Checked)
            {
                cbViewRemarks.Text = "View Remarks";
                pnRemarks.Visible = false;
            }
            else if (cbViewRemarks.CheckState == CheckState.Unchecked)
            {
                cbViewRemarks.Text = "View Tax";
                pnRemarks.Visible = true;

            }
        }

        DataTable dtPOUserlist = new DataTable();
        private void btnLoadPCList_Click(object sender, EventArgs e)
        {

            
            if (Convert.ToBoolean(login.GetUserDetails[29]) == true || Convert.ToBoolean(login.GetUserDetails[31]) == true || Convert.ToBoolean(login.GetUserDetails[82]) == true || Convert.ToBoolean(login.GetUserDetails[32]) == true || Convert.ToBoolean(login.GetUserDetails[80]) == true || Convert.ToBoolean(login.GetUserDetails[16]) == true || login.GetUserDetails[2].ToLower() == "santhoshdj" || Convert.ToBoolean(login.GetUserDetails[85]) == true || login.GetUserDetails[2].ToLower() == "lizzy" || login.GetUserDetails[2].ToLower() == "veena" || login.GetUserDetails[2].ToLower() == "pavana" || login.GetUserDetails[2].ToLower() == "hemanth reddy" ||login.GetUserDetails[2].ToLower()=="girish")
            {
              
                btnAcceptPO.Enabled = true;
                btnRejectPO.Enabled = true;
                cmbPONO.Enabled = true;
                cmbPONO.Text = "";
                cmbPONO.Items.Clear();
                dgbomlist.DataSource = null;
                chkPrintPO.Checked = false;
                //chkPrintPO.Checked = true;
                btnprintpo.Text = "Draft PO";
                btnGenaratePO.Enabled = false;
                
                dtPOUserlist = DAL.fnPOOrderFilter(9, login.GetUserDetails[2]).Tables[0];
               //rk pnitemadd.Enabled = false;

                for (int i = 13; i <= 19; i++)
                {
                    dgbomlist.Columns[i].Visible = true;
                }
            }

            //(all ProductionManager)
            if (Convert.ToBoolean(login.GetUserDetails[31]) == true)
            {
                
                foreach (DataRow DT in dtPOUserlist.Rows)
                {
                    dtPOFilter = DAL.fnPOOrderFilter(1, DT["POUserName"].ToString()).Tables[0];
                    DataView dvPOOrderFilter1 = new DataView(dtPOFilter);
                    dvPOOrderFilter1.Sort = "DBOMNo desc";
                    dtPOFilter = dvPOOrderFilter1.ToTable();
                    if (dtPOFilter.Rows.Count > 0)
                    {
                        foreach (DataRow DR in dtPOFilter.Rows)
                        {
                            if (!cmbPONO.Items.Contains(DR["DBOMNo"].ToString()))
                                cmbPONO.Items.Add(DR["DBOMNo"].ToString());
                        }
                    }
                }
            }
            //(all ManufacturingHead)
            else if (Convert.ToBoolean(login.GetUserDetails[32]) == true)
            {

               
                foreach (DataRow DT in dtPOUserlist.Rows)
                {
                    dtPOFilter = DAL.fnPOOrderFilter(5, DT["POUserName"].ToString()).Tables[0];
                    DataView dvPOOrderFilter1 = new DataView(dtPOFilter);
                    dvPOOrderFilter1.Sort = "DBOMNo desc";
                    dtPOFilter = dvPOOrderFilter1.ToTable();
                    if (dtPOFilter.Rows.Count > 0)
                    {
                        foreach (DataRow DR in dtPOFilter.Rows)
                        {
                            if (!cmbPONO.Items.Contains(DR["DBOMNo"].ToString()))
                                cmbPONO.Items.Add(DR["DBOMNo"].ToString());
                        }
                    }
                }
            }

            //Vishal Thilak Kumar(all PurchaseManager)
            else if (Convert.ToBoolean(login.GetUserDetails[29]) == true)
            {
              

                llbViewPOGeneralTerms.Visible = true;
                foreach (DataRow DT in dtPOUserlist.Rows)
                {
                    dtPOFilter = DAL.fnPOOrderFilter(6, DT["POUserName"].ToString()).Tables[0];
                    DataView dvPOOrderFilter1 = new DataView(dtPOFilter);
                    dvPOOrderFilter1.Sort = "DBOMNo desc";
                    dtPOFilter = dvPOOrderFilter1.ToTable();
                    if (dtPOFilter.Rows.Count > 0)
                    {
                        foreach (DataRow DR in dtPOFilter.Rows)
                        {
                            if (!cmbPONO.Items.Contains(DR["DBOMNo"].ToString()))
                                cmbPONO.Items.Add(DR["DBOMNo"].ToString());
                        }
                    }
                }
                btnprintpo.Enabled = true;
            }
            
            //Vivek G
            else if (Convert.ToBoolean(login.GetUserDetails[85]) == true)
            {

              

                llbViewPOGeneralTerms.Visible = true;
                foreach (DataRow DT in dtPOUserlist.Rows)
                {
                    dtPOFilter = DAL.fnPOOrderFilter(13, DT["POUserName"].ToString()).Tables[0];
                    DataView dvPOOrderFilter1 = new DataView(dtPOFilter);
                    dvPOOrderFilter1.Sort = "DBOMNo desc";
                    dtPOFilter = dvPOOrderFilter1.ToTable();
                    if (dtPOFilter.Rows.Count > 0)
                    {
                        foreach (DataRow DR in dtPOFilter.Rows)
                        {
                            if (!cmbPONO.Items.Contains(DR["DBOMNo"].ToString()))
                                cmbPONO.Items.Add(DR["DBOMNo"].ToString());
                        }
                    }
                }
                btnprintpo.Enabled = true;
            }
            //Theertha Rao
            else if (Convert.ToBoolean(login.GetUserDetails[80]) == true)
            {
                

                llbViewPOGeneralTerms.Visible = true;
                dtPOFilter = DAL.fnPOOrderFilter(10, "").Tables[0];
                DataView dvPOOrderFilter1 = new DataView(dtPOFilter);
                dvPOOrderFilter1.Sort = "DBOMNo desc";
                dtPOFilter = dvPOOrderFilter1.ToTable();
                if (dtPOFilter.Rows.Count > 0)
                {
                    foreach (DataRow DR in dtPOFilter.Rows)
                    {
                        if (!cmbPONO.Items.Contains(DR["DBOMNo"].ToString()))
                            cmbPONO.Items.Add(DR["DBOMNo"].ToString());
                    }
                }
                btnprintpo.Enabled = true;
            }

            //Test Lab
            else if (Convert.ToBoolean(login.GetUserDetails[82]) == true)
            {


                foreach (DataRow DT in dtPOUserlist.Rows)
                {
                    dtPOFilter = DAL.fnPOOrderFilter(82, DT["POUserName"].ToString()).Tables[0];
                    DataView dvPOOrderFilter1 = new DataView(dtPOFilter);
                    dvPOOrderFilter1.Sort = "DBOMNo desc";
                    dtPOFilter = dvPOOrderFilter1.ToTable();
                    if (dtPOFilter.Rows.Count > 0)
                    {
                        foreach (DataRow DR in dtPOFilter.Rows)
                        {
                            if (!cmbPONO.Items.Contains(DR["DBOMNo"].ToString()))
                                cmbPONO.Items.Add(DR["DBOMNo"].ToString());
                        }
                    }
                }
                btnprintpo.Enabled = true;
                llbViewPOGeneralTerms.Visible = true;
            }
            //Ramakrishna
            else if (Convert.ToBoolean(login.GetUserDetails[16]) == true && Convert.ToBoolean(login.GetUserDetails[30]) == true)//  lblPrepareBy.Text.ToLower() == "hebbarrk")
            {
               
                llbViewPOGeneralTerms.Visible = true;
                dtPOFilter = DAL.fnPOOrderFilter(3, "").Tables[0];
                DataView dvPOOrderFilter1 = new DataView(dtPOFilter);
                dvPOOrderFilter1.Sort = "DBOMNo desc";
                dtPOFilter = dvPOOrderFilter1.ToTable();
                if (dtPOFilter.Rows.Count > 0)
                {
                    foreach (DataRow DR in dtPOFilter.Rows)
                    {
                        if (!cmbPONO.Items.Contains(DR["DBOMNo"].ToString()))
                            cmbPONO.Items.Add(DR["DBOMNo"].ToString());
                    }
                }
                btnprintpo.Enabled = true;
            }

            //MuthuRamalingam // pavana
            else if (Convert.ToBoolean(login.GetUserDetails[16]) == true && Convert.ToBoolean(login.GetUserDetails[30]) != true || login.GetUserDetails[2].ToLower() == "lizzy" && Convert.ToBoolean(login.GetUserDetails[30]) != true || login.GetUserDetails[2].ToLower() == "veena" || login.GetUserDetails[2].ToLower() == "pavana" || login.GetUserDetails[2].ToLower() == "hemanth reddy" && Convert.ToBoolean(login.GetUserDetails[30]) != true)//  lblPrepareBy.Text.ToLower() == "hebbarrk")
            {

              
                dtPOFilter = DAL.fnPOOrderFilter(11, "").Tables[0];

                llbViewPOGeneralTerms.Visible = true;
                DataView dvPOOrderFilter1 = new DataView(dtPOFilter);
                dvPOOrderFilter1.Sort = "DBOMNo desc";
                dtPOFilter = dvPOOrderFilter1.ToTable();
                if (dtPOFilter.Rows.Count > 0)
                {
                    foreach (DataRow DR in dtPOFilter.Rows)
                    {
                        if (!cmbPONO.Items.Contains(DR["DBOMNo"].ToString()))
                            cmbPONO.Items.Add(DR["DBOMNo"].ToString());
                    }
                }

                llbViewPOGeneralTerms.Visible = true;
                dtPOGeneralTerms = DAL.fnPOPendingList(3, "", "", "PO1").Tables[0];
                dgvPOGeneralTerms.AutoGenerateColumns = false;
                dgvPOGeneralTerms.DataSource = dtPOGeneralTerms;
                             
            }
        }

        private void txtItemDescription_MouseClick(object sender, MouseEventArgs e)
        {
            if (dtItemList.Rows.Count == 0)
            {
                dtItemList = DAL.fnItemListWith6and12(null).Tables[0];
                dtTableFilter = dtItemList;
            }
        }

        private void chkWithoutBOM_CheckedChanged(object sender, EventArgs e)
        {
            //if (chkWithoutBOM.CheckState == CheckState.Checked)
            //{
            //    dgbomlist.Columns["ReqQty"].ReadOnly = false;
            //    dgbomlist.Columns["ReqQty"].DefaultCellStyle.BackColor = Color.LightGreen;
            //}
            //else
            //{
            //    dgbomlist.Columns["ReqQty"].ReadOnly = true;
            //    dgbomlist.Columns["ReqQty"].DefaultCellStyle.BackColor = Color.White;
            //}
        }

        private void chkUpdatePO_CheckedChanged(object sender, EventArgs e)
        {
            cmbPONO.Text = "";
            cmbPONO.Items.Clear();
            if (login.GetUserDetails[2].ToLower() == "muthuramalingam" || login.GetUserDetails[2].ToLower() == "suresh kumar" || login.GetUserDetails[2].ToLower() == "lizzy" || login.GetUserDetails[2].ToLower() == "veena" || login.GetUserDetails[2].ToLower() == "pavana" || login.GetUserDetails[2].ToLower() == "hemanth reddy" )//shreeshail is added or lizzy condtion
            {
                for (int i = 13; i <= 27; i++)
                {
                    dgbomlist.Columns[i].Visible = true;
                    
                }
                dgbomlist.Columns[14].ReadOnly = false;
                
                dgbomlist.DataSource = null;
                //dgbomlist.ReadOnly = true;
                dtPOFilter = DAL.fnPOOrderFilter(8, "").Tables[0];
                DataView dvPOOrderFilter1 = new DataView(dtPOFilter);
                dvPOOrderFilter1.Sort = "DBOMNo desc";
                dtPOFilter = dvPOOrderFilter1.ToTable();
                if (dtPOFilter.Rows.Count > 0)
                {
                    foreach (DataRow DR in dtPOFilter.Rows)
                    {
                        if (!cmbPONO.Items.Contains(DR["DBOMNo"].ToString()))
                            cmbPONO.Items.Add(DR["DBOMNo"].ToString());
                    }
                    cmbPONO.Enabled = true;
                }

                btnGenaratePO.Text = "Update PO";
                btnGenaratePO.Enabled = true;
            }
            else
            {
                for (int i = 13; i <= 27; i++)
                {
                    dgbomlist.Columns[i].Visible = false;
                    
                }
            }
        }
        DataTable dtProjectBOMdetails = new DataTable();
        DataTable dtProjectBOM = new DataTable();
        private void cmbProjectcode_TextChanged(object sender, EventArgs e)
        {

            cmbbomname.Items.Clear();
            cmbbomname.ResetText();
            chklbItemList.Items.Clear();
            DataView dvProject = new DataView(dtWIPProjectlist);
            dvProject.RowFilter = "ProjectCode Like'" + cmbProjectcode.Text + "'";
            DataTable dtrow = dvProject.ToTable();
            if (dtrow.Rows.Count > 0)
            {
                lblProjectStatus.Text = dtrow.Rows[0]["Status"].ToString();
                lblprojname.Text = dtrow.Rows[0]["ProjectDescription"].ToString();
                sProjectType = dtrow.Rows[0]["ProjectType"].ToString();
            }
            //if (cmbProjectcode.Text == "EXP-2021-01-OTS-000208-07")
            //{
            //    chkWithoutBOM.Visible = true;
            //    chkWithoutBOM.Enabled = true;
            //}
            dtProjectBOMdetails = DAL.fnWIPProjectCode(cmbProjectcode.Text).Tables[0];
            dtProjectBOM = DAL.fnProjectBOMIndentList(cmbProjectcode.Text).Tables[0];

            foreach (DataRow DR in dtProjectBOM.Rows)
            {
                cmbbomname.Items.Add(DR["ProductCode"].ToString() + "`" + DR["ProductType"].ToString() + "`" + DR["ProductName"].ToString());
            }
            if (cmbbomname.Items.Count > 0)
            {
                cmbbomname.Enabled = true;
            }
            else
            {
                cmbbomname.Enabled = false;
            }
        }

        private void cmbProjectcode_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            sPOform = 1;
            Indent.frmProjectselect projectsearch = new Indent.frmProjectselect();
            projectsearch.fnPOform = sPOform.ToString();
            projectsearch.ShowDialog();
            if (fnProjectcode != null)
            {
                cmbProjectcode.Text = sProjectCode;
            }
        }
        string[] sProductCode;
        DataTable dtprojectBOMItems = new DataTable();
        DataTable dtMachineBOMProduct = new DataTable();
        private void cmbbomname_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            sProductCode = cmbbomname.Text.Split('`');

            dtprojectBOMItems = DAL.fnProjectBOMProdutnamenumber(sProductCode[0], cmbProjectcode.Text, sProductCode[1], sProductCode[2]).Tables[0];
            if (dtprojectBOMItems.Rows.Count > 0)
            {
                //  lblProductName.Text = dtprojectBOMItems.Rows[0]["ProductName"].ToString() + " - " + dtprojectBOMItems.Rows[0]["ProductType"].ToString();
                //lblVersion.Text = dtprojectBOMItems.Rows[0]["Version"].ToString();

                dtMachineBOMProduct = DAL.fnGetIndentMachineBOM(dtprojectBOMItems.Rows[0]["ProjectBOMCode"].ToString(), dtprojectBOMItems.Rows[0]["ProductNo"].ToString(), cmbProjectcode.Text, null).Tables[0];

                if (dtMachineBOMProduct.Rows.Count > 0)
                {
                    chklbItemList.Items.Clear();
                    foreach (DataRow dr in dtMachineBOMProduct.Rows)
                    {
                        if (Convert.ToDouble(dr["IndentQty"].ToString()) > Convert.ToDouble(dr["AvailableQty"].ToString()))
                        {
                            dr["IndentQty"] = Convert.ToDouble(dr["AvailableQty"].ToString());
                        }
                    }
                }
                //dgBOMIndent.ReadOnly = false;

                foreach (DataRow dr in dtMachineBOMProduct.Rows)
                {
                    chklbItemList.Items.Add(string.Concat(dr["ID"].ToString(), ") ", dr["ItemCode"].ToString(), ", ", dr["ItemDescription"].ToString(), ", ", dr["AvailableQty"].ToString()));

                }
                //pnitemlist.Enabled = true;
            }
        }
        DataTable dtcurrcy = new DataTable();
        private void cmbcurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            //switch (cmbcurrency.SelectedIndex)
            //{
            //    case 0:
            //        curratetext.Text = "1";
            //        curratetext.Visible = true;
            //        break;
            //    case 1:
            //cmbcurrency.Enabled = false;
            dtcurrcy = DAL.DTPegRate(cmbcurrency.SelectedItem.ToString()).Tables[0];
            if (dtcurrcy.Rows.Count > 0)
            {
                curratetext.Text = dtcurrcy.Rows[0][6].ToString();
                //curratetext.Text = dtcurrcy.Rows[0][2].ToString();
            }
            else
            {
                curratetext.Text = "1";
            }
            curratetext.Visible = true;

            //break;

            //case 2:

            //    // cmbcurrency.Enabled = false;
            //    dtcurrcy = DAL.DTPegRate(cmbcurrency.SelectedItem.ToString()).Tables[0];
            //    if (dtcurrcy.Rows.Count > 0)
            //    {
            //        curratetext.Text = dtcurrcy.Rows[0][2].ToString();
            //    }
            //    else
            //    {
            //        curratetext.Text = ".5";
            //    }
            //    curratetext.Visible = true;

            //    break;
            //}
        }
        DataTable dtRemarksHistory = new DataTable();

        private void fnLoadComments()
        {
            dtRemarksHistory = DAL.PORemarksHistory(1, cmbPONO.Text).Tables[0];
            dgvRemarks.Visible = true;
            if (dtRemarksHistory.Rows.Count > 0)
            {
                for (int i = dtRemarksHistory.Rows.Count - 1; i >= 0; i--)
                {
                    if (dtRemarksHistory.Rows[i][0] == DBNull.Value)
                    {
                        dtRemarksHistory.Rows[i].Delete();
                    }
                    else if (dtRemarksHistory.Rows[i][0].ToString() == "" || dtRemarksHistory.Rows[i][0].ToString() == "--")
                    {
                        dtRemarksHistory.Rows[i].Delete();
                    }
                }
                dtRemarksHistory.AcceptChanges();
                dgvRemarks.AutoGenerateColumns = false;
                dgvRemarks.DataSource = dtRemarksHistory;
            }
        }

        private void llbViewRemakrs_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (llbViewRemakrs.Text == "View remarks of all users")
            {
                fnLoadComments();
                llbViewRemakrs.Text = "Hide remarks of all users";
                pnGeneralTerms.Visible = false;
            }
            else if (llbViewRemakrs.Text == "Hide remarks of all users")
            {
                dgvRemarks.Visible = false;
                llbViewRemakrs.Text = "View remarks of all users";
            }

        }

        bool bGeneralTerms = false;
        private void llbViewPOGeneralTerms_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            fnViewTerms();
        }

        private void fnViewTerms()
        {
            bGeneralTerms = true;
            if (llbViewPOGeneralTerms.Text == "View PO General Terms")
            {
                dgvRemarks.Visible = false;
                pnGeneralTerms.Visible = true;
                llbViewPOGeneralTerms.Text = "Hide PO General Terms";
            }
            else if (llbViewPOGeneralTerms.Text == "Hide PO General Terms")
            {
                pnGeneralTerms.Visible = false;
                llbViewPOGeneralTerms.Text = "View PO General Terms";
            }
        }

        private void btnAddNewRow_Click(object sender, EventArgs e)
        {
            bool bBlank = false;
            foreach (DataRow row in dtPOGeneralTerms.Rows)
            {
                object value = row[0];
                if (value.ToString() == "")
                {
                    bBlank = true;
                    break;
                }
                else
                {
                    bBlank = false;
                }
            }
            if (!bBlank)
            {
                dtPOGeneralTerms.Rows.Add("");
            }
            else
            {
                MessageBox.Show("Add a term to the blank cell", "Error", 0, MessageBoxIcon.Error);
            }
        }

        private void dgvPOGeneralTerms_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (dgvPOGeneralTerms.Rows.Count > 0)
                {
                    dgvPOGeneralTerms.Rows.RemoveAt(dgvPOGeneralTerms.Rows.IndexOf(dgvPOGeneralTerms.CurrentRow));
                }
            }
        }

        DataTable dtPOSelectedTerms = new DataTable();
        private void cmbPOTerms_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtPOGeneralTerms = DAL.fnPOPendingList(5, "", "", cmbPOTerms.Text).Tables[0];

            if (dtPOGeneralTerms.Rows.Count > 0)
            {
                dgvPOGeneralTerms.AutoGenerateColumns = false;
                dgvPOGeneralTerms.DataSource = dtPOGeneralTerms;
            }
        }

        private void lstusers_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lblprojname_Click(object sender, EventArgs e)
        {

        }

        private void cmbEmailAlert_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void PurchaseOrdervaliduptoDate_ValueChanged(object sender, EventArgs e)
        {
            DateTime selectedDate = PurchaseOrdervaliduptoDate.Value; 

            if (selectedDate.Date <= DateTime.Today)
            {
               // MessageBox.Show("Please select a Expiry date.", "Invalid Date", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                PurchaseOrdervaliduptoDate.Value = DateTime.Today.AddDays(90); // Set the date to tomorrow's date or any default future date
            }
        }

        private void curratetext_TextChanged(object sender, EventArgs e)
        {

        }

        private void pnBOMQtyCheck_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dgvBOMQty_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvPOGeneralTerms_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void lblAuthorisedBy_Click(object sender, EventArgs e)
        {

        }

        private void txtAuthorizedBy_Click(object sender, EventArgs e)
        {

        }

      

        private void AmeandPO_CheckedChanged_1(object sender, EventArgs e)
        {
            if (AmeandPO.CheckState == CheckState.Checked)
            {
                butAmend.Visible = true;
                button1.Visible = true;
                button1.Enabled = true;
                cmbPONO.Text = "";
                cmbPONO.Items.Clear();
                btnloadpolist.Enabled = false;
                btnLoadPCList.Enabled = false;
                butAmend.Enabled = true;
                if (Convert.ToBoolean(login.GetUserDetails[16]) == true)
                {
                    dgbomlist.DataSource = null;
                    dgbomlist.ReadOnly = true;
                    dtPOFilter = DAL.fnPOOrderFilter(15, "").Tables[0];
                    DataView dvPOOrderFilter1 = new DataView(dtPOFilter);
                    dvPOOrderFilter1.Sort = "DBOMNo desc";
                    dtPOFilter = dvPOOrderFilter1.ToTable();
                    if (dtPOFilter.Rows.Count > 0)
                    {
                        foreach (DataRow DR in dtPOFilter.Rows)
                        {
                            if (!cmbPONO.Items.Contains(DR["DBOMNo"].ToString()))
                                cmbPONO.Items.Add(DR["DBOMNo"].ToString());
                        }
                        cmbPONO.Enabled = true;
                    }

                    btnGenaratePO.Enabled = false;
                    btnprintpo.Enabled = false;
                    btnRejectPO.Enabled = false;
                }
            }
            else
            {
                dgbomlist.ReadOnly = false;
                btnprintpo.Enabled = false;
                butAmend.Visible = true;
                button1.Visible = true;
                //btnloadpolist_Click(sender, e);
            }
        }

        private void butAmend_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(cmbPONO.Text))
            {
                //dtPOAuthorisedforCost = DAL.purchaseOrderApproved(1, cmbPONO.Text).Tables[0];
                GLobalClass.iSuccess = DAL.purchaseOrderApproval(21, cmbPONO.Text, dtppreparedate.Text, login.GetUserDetails[2], txtRemarks.Text);
                //GSTPurchaseOrder();
                GLobalClass.iSuccess = DAL.fnAddERPLog(0, cmbPONO.Text, login.GetUserDetails[2], dtppreparedate.Text, "PO Amended", "PurchaseOrder");
                MessageBox.Show("PO Amended successfully " + cmbPONO.Text + "", "Success", 0, MessageBoxIcon.Information);
                FormReload();

            }

            else
            {
                MessageBox.Show("Select PO Number to Amend purachase order", "Error", 0, MessageBoxIcon.Error);
            }
        }

        private void btnCancelPO_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(cmbPONO.Text))
            {
                Form inputForm = new Form()
                {
                    Width = 400,
                    Height = 220,
                    FormBorderStyle = FormBorderStyle.FixedDialog,
                    Text = "Cancel Purchase Order",
                    StartPosition = FormStartPosition.CenterScreen
                };

                Label lbl = new Label() { Left = 20, Top = 20, Text = "Final Comment:", AutoSize = true };
                TextBox txt = new TextBox() { Left = 20, Top = 45, Width = 340, Height = 60, Multiline = true };
                Button ok = new Button() { Text = "OK", Left = 200, Width = 75, Top = 130, DialogResult = DialogResult.OK };
                Button cancel = new Button() { Text = "Cancel", Left = 285, Width = 75, Top = 130, DialogResult = DialogResult.Cancel };

                inputForm.Controls.Add(lbl);
                inputForm.Controls.Add(txt);
                inputForm.Controls.Add(ok);
                inputForm.Controls.Add(cancel);
                inputForm.AcceptButton = ok;
                inputForm.CancelButton = cancel;

                DialogResult result = inputForm.ShowDialog();

                if (result == DialogResult.OK)
                {
                    string comment = txt.Text.Trim();
                    if (string.IsNullOrWhiteSpace(comment))
                    {
                        MessageBox.Show("Final Comment is mandatory for cancellation.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    string poNumber = cmbPONO.Text;
                    string cancelledBy = login.GetUserDetails[2];
                    string cancelledDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                    int status = DAL.CancelPurchaseOrder(poNumber, "Cancelled", comment, cancelledBy, cancelledDate);

                    if (status > 0)
                    {
                        MessageBox.Show("Purchase Order cancelled successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Failed to cancel Purchase Order.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a PO Number to cancel.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        //bhavya added this reminder code logic
        // 📧 Main logic to get POs and send email
        private void SendPendingPOReminders()
        {
            try
            {
                DataSet dsPOs = DAL.fnGetReminderPOs();
                if (dsPOs == null || dsPOs.Tables.Count == 0 || dsPOs.Tables[0].Rows.Count == 0)
                {
                    MessageBox.Show("No pending POs found for reminder.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                DataTable dtPOs = dsPOs.Tables[0];

                foreach (DataRow row in dtPOs.Rows)
                {
                    string poNumber = row["DBOMNo"].ToString();
                    string PODeliveryDate = row["PODeliveryDate"].ToString();
                    string vendorEmail = row["VendorEmail"].ToString();
                    string preparedByEmail = row["PreparedByEmail"].ToString();
                    string purchaseCommitteeEmail = row["PurchaseCommiteeEmail"].ToString();
                    // string poGeneratedByEmail = row["POGeneratedByEmail"].ToString();


                    // ✅ Skip if vendor email is missing
                    if (string.IsNullOrWhiteSpace(vendorEmail))
                        continue;

                    List<string> ccEmails = new List<string>();
                    if (!string.IsNullOrWhiteSpace(preparedByEmail)) ccEmails.Add(preparedByEmail);
                    if (!string.IsNullOrWhiteSpace(purchaseCommitteeEmail)) ccEmails.Add(purchaseCommitteeEmail);
                    // ccEmails.Add("bhavya_hugar@instron.com");


                    // Send email only if not already sent
                    bool emailSent = SendOutlookEmail(poNumber, PODeliveryDate, vendorEmail, ccEmails);

                  //  bool emailSent = SendOutlookEmail(poNumber, PODeliveryDate, "bhavya_hugar@instron.com", ccEmails);

                    if (emailSent)
                    {
                        DAL.UpdateReminderStatus(poNumber); // ✅ Cleaned DAL call
                    }
                }

                MessageBox.Show("PO Reminder Emails Processed.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        // 📨 Send Email without attachments
        private bool SendOutlookEmail(string poNumber, string PODeliveryDate, string toEmail, List<string> ccEmails)
        {
            try
            {
                Outlook.Application oApp = new Outlook.Application();
                Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);

                oMsg.Subject = $"Update Required - PO No: {poNumber}";

                string imageCid = "companylogo";

                string htmlBody = $@"
            Dear Sir/Madam,<br/><br/>
            <b>PO Number:</b> {poNumber}<br/>
            <b>Scheduled Delivery Date:</b> {PODeliveryDate}<br/><br/>

            We kindly request an update on the dispatch status of the above-mentioned Purchase Order.<br/>
            If the material has already been dispatched, please share the docket details.<br/><br/>
            Timely delivery is appreciated to avoid any project delays.<br/><br/>
            {ReadSignature(imageCid)}";

                oMsg.HTMLBody = htmlBody;

                Outlook.Recipients oRecips = oMsg.Recipients;

                Outlook.Recipient oRecipTo = oRecips.Add(toEmail);
                oRecipTo.Type = (int)Outlook.OlMailRecipientType.olTo;

                foreach (string cc in ccEmails)
                {
                    if (!string.IsNullOrWhiteSpace(cc))
                    {
                        Outlook.Recipient oRecipCC = oRecips.Add(cc);
                        oRecipCC.Type = (int)Outlook.OlMailRecipientType.olCC;
                    }
                }

                oRecips.ResolveAll();

                string logoPath = @"C:\Databasepath\InstronLogo3.jpg";
                if (File.Exists(logoPath))
                {
                    Outlook.Attachment imageAttachment = oMsg.Attachments.Add(logoPath,
                        Outlook.OlAttachmentType.olEmbeddeditem, null, "Company Logo");
                    imageAttachment.PropertyAccessor.SetProperty(
                        "http://schemas.microsoft.com/mapi/proptag/0x3712001F", imageCid);
                }

                oMsg.Send(); // Send without displaying
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Email sending failed: " + ex.Message, "Email Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
        }

        // ✍️ Signature with image reference
        private string ReadSignature(string imageCid)
        {
            return $@"
                <br/><br/>
                Best Regards,<br/>
                <b>Pavana D</b><br/>
                Sourcing Manager<br/>
                Tel: +91 80 28360184<br/>
                Mob: +91 6366951638<br/>
                <br/>
                <img src=""cid:{imageCid}"" height='40'/><br/><br/>
                <span style='color:gray; font-size:10pt;'> #497E, 14th Cross, 4th Phase,<br/>
        Peenya Industrial Area, Bangalore - 560058, India.<br/>
        <a href='https://www.instron.com'>www.instron.com</a>   </span><br/><br/>

        <span style='color:green; font-size:10pt;'>
            Please consider your environmental responsibility. Before printing this e-mail message, 
            ask yourself whether you really need a hard copy.<br/>
            <b><i>“Goal of Zero Accident is our Shared Responsibility”</i></b>
        </span>
            ";
        }



        //bhavya added this reminder code logic 



        private void btnClosePO_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(cmbPONO.Text))
            {
                Form inputForm = new Form()
                {
                    Width = 400,
                    Height = 220,
                    FormBorderStyle = FormBorderStyle.FixedDialog,
                    Text = "Close Purchase Order",
                    StartPosition = FormStartPosition.CenterScreen
                };

                Label lbl = new Label() { Left = 20, Top = 20, Text = "Final Comment:", AutoSize = true };
                TextBox txt = new TextBox() { Left = 20, Top = 45, Width = 340, Height = 60, Multiline = true };
                Button ok = new Button() { Text = "OK", Left = 200, Width = 75, Top = 130, DialogResult = DialogResult.OK };
                Button cancel = new Button() { Text = "Cancel", Left = 285, Width = 75, Top = 130, DialogResult = DialogResult.Cancel };

                inputForm.Controls.Add(lbl);
                inputForm.Controls.Add(txt);
                inputForm.Controls.Add(ok);
                inputForm.Controls.Add(cancel);
                inputForm.AcceptButton = ok;
                inputForm.CancelButton = cancel;

                DialogResult result = inputForm.ShowDialog();

                if (result == DialogResult.OK)
                {
                    string comment = txt.Text.Trim();
                    if (string.IsNullOrWhiteSpace(comment))
                    {
                        MessageBox.Show("Final Comment is mandatory for closing.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    string poNumber = cmbPONO.Text;
                    string closedBy = login.GetUserDetails[2];
                    string closedDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                    int status = DAL.ClosePurchaseOrder(poNumber, "Closed", comment, closedBy, closedDate);

                    if (status > 0)
                    {
                        MessageBox.Show("Purchase Order closed successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Failed to close Purchase Order.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a PO Number to close.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        

        private void btnSendReminder_Click(object sender, EventArgs e)
        {
            SendPendingPOReminders();
        }

        private void ViewVendorList_Click(object sender, EventArgs e)
        {

            sPONumber = string.Empty;
            this.Hide(); // Hide the current form (Page3)

            pleasewaitform pleaseWait = new pleasewaitform();
            pleaseWait.Show();
            Application.DoEvents(); // Allow UI to render

            // Load the vendor delay form
            VendorDealyList vendorDelayList = new VendorDealyList();

            // Close the "please wait" form
            pleaseWait.Close();

            // Show vendor delay list as modal dialog
            vendorDelayList.ShowDialog();

            // When vendorDelayList is closed, show this form again
            this.Show();
        }

        private void dtppreparedate_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
                if (!string.IsNullOrEmpty(cmbPONO.Text))
                {
                    //dtPOAuthorisedforCost = DAL.purchaseOrderApproved(1, cmbPONO.Text).Tables[0];
                    GLobalClass.iSuccess = DAL.purchaseOrderApproval(212, cmbPONO.Text, dtppreparedate.Text, login.GetUserDetails[2], txtRemarks.Text);
                    //GSTPurchaseOrder();
                    GLobalClass.iSuccess = DAL.fnAddERPLog(0, cmbPONO.Text, login.GetUserDetails[2], dtppreparedate.Text, "PO Amended", "PurchaseOrder");
                    MessageBox.Show("PO Amended successfully " + cmbPONO.Text + "", "Success", 0, MessageBoxIcon.Information);
                    FormReload();

                }

                else
                {
                    MessageBox.Show("Select PO Number to Amend purachase order", "Error", 0, MessageBoxIcon.Error);
                }
            
        }
    }
}
