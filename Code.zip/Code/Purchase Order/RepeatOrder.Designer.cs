﻿namespace Erp_Project_With_Buttons.Purchase_Order
{
    partial class RepeatOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RepeatOrder));
            this.lblitemdescrption = new System.Windows.Forms.Label();
            this.lblItemcode = new System.Windows.Forms.Label();
            this.lblUnitCost = new System.Windows.Forms.Label();
            this.lblRepeatitemcode = new System.Windows.Forms.Label();
            this.lblrepeatCost = new System.Windows.Forms.Label();
            this.dgvRepeaOrder = new System.Windows.Forms.DataGridView();
            this.Itemcode1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GINNumber1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitCost1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SupplierName1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Date1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SupplierInvoiceNumber1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Type1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RefNumber1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblavailableqty = new System.Windows.Forms.Label();
            this.lblavaqty = new System.Windows.Forms.Label();
            this.lblNoitems = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblitemname = new System.Windows.Forms.Label();
            this.txtItemDescription = new System.Windows.Forms.TextBox();
            this.chklbItemList = new System.Windows.Forms.CheckedListBox();
            this.lblitemdescription = new System.Windows.Forms.Label();
            this.chkItemDesc = new System.Windows.Forms.CheckBox();
            this.chkItemCode = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtUnitCost = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnSave = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRepeaOrder)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblitemdescrption
            // 
            this.lblitemdescrption.AutoSize = true;
            this.lblitemdescrption.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblitemdescrption.ForeColor = System.Drawing.Color.Black;
            this.lblitemdescrption.Location = new System.Drawing.Point(3, 50);
            this.lblitemdescrption.Name = "lblitemdescrption";
            this.lblitemdescrption.Size = new System.Drawing.Size(151, 23);
            this.lblitemdescrption.TabIndex = 17;
            this.lblitemdescrption.Text = "Item Description :";
            // 
            // lblItemcode
            // 
            this.lblItemcode.AutoSize = true;
            this.lblItemcode.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemcode.ForeColor = System.Drawing.Color.Black;
            this.lblItemcode.Location = new System.Drawing.Point(54, 105);
            this.lblItemcode.Name = "lblItemcode";
            this.lblItemcode.Size = new System.Drawing.Size(100, 23);
            this.lblItemcode.TabIndex = 19;
            this.lblItemcode.Text = "Item Code :";
            // 
            // lblUnitCost
            // 
            this.lblUnitCost.AutoSize = true;
            this.lblUnitCost.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUnitCost.ForeColor = System.Drawing.Color.Black;
            this.lblUnitCost.Location = new System.Drawing.Point(67, 147);
            this.lblUnitCost.Name = "lblUnitCost";
            this.lblUnitCost.Size = new System.Drawing.Size(88, 23);
            this.lblUnitCost.TabIndex = 20;
            this.lblUnitCost.Text = "UnitCost :";
            // 
            // lblRepeatitemcode
            // 
            this.lblRepeatitemcode.AutoSize = true;
            this.lblRepeatitemcode.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRepeatitemcode.ForeColor = System.Drawing.Color.Black;
            this.lblRepeatitemcode.Location = new System.Drawing.Point(155, 105);
            this.lblRepeatitemcode.Name = "lblRepeatitemcode";
            this.lblRepeatitemcode.Size = new System.Drawing.Size(19, 23);
            this.lblRepeatitemcode.TabIndex = 21;
            this.lblRepeatitemcode.Text = "*";
            // 
            // lblrepeatCost
            // 
            this.lblrepeatCost.AutoSize = true;
            this.lblrepeatCost.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrepeatCost.ForeColor = System.Drawing.Color.Black;
            this.lblrepeatCost.Location = new System.Drawing.Point(157, 147);
            this.lblrepeatCost.Name = "lblrepeatCost";
            this.lblrepeatCost.Size = new System.Drawing.Size(19, 23);
            this.lblrepeatCost.TabIndex = 22;
            this.lblrepeatCost.Text = "*";
            // 
            // dgvRepeaOrder
            // 
            this.dgvRepeaOrder.AllowUserToAddRows = false;
            this.dgvRepeaOrder.AllowUserToDeleteRows = false;
            this.dgvRepeaOrder.AllowUserToOrderColumns = true;
            this.dgvRepeaOrder.AllowUserToResizeColumns = false;
            this.dgvRepeaOrder.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvRepeaOrder.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvRepeaOrder.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRepeaOrder.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvRepeaOrder.ColumnHeadersHeight = 40;
            this.dgvRepeaOrder.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvRepeaOrder.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Itemcode1,
            this.GINNumber1,
            this.Quantity1,
            this.UnitCost1,
            this.SupplierName1,
            this.Date1,
            this.SupplierInvoiceNumber1,
            this.Type1,
            this.RefNumber1});
            this.dgvRepeaOrder.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvRepeaOrder.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvRepeaOrder.EnableHeadersVisualStyles = false;
            this.dgvRepeaOrder.Location = new System.Drawing.Point(12, 262);
            this.dgvRepeaOrder.MultiSelect = false;
            this.dgvRepeaOrder.Name = "dgvRepeaOrder";
            this.dgvRepeaOrder.RowHeadersVisible = false;
            this.dgvRepeaOrder.Size = new System.Drawing.Size(1280, 408);
            this.dgvRepeaOrder.TabIndex = 109;
            // 
            // Itemcode1
            // 
            this.Itemcode1.DataPropertyName = "Itemcode";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomCenter;
            this.Itemcode1.DefaultCellStyle = dataGridViewCellStyle2;
            this.Itemcode1.HeaderText = "Item Code";
            this.Itemcode1.Name = "Itemcode1";
            this.Itemcode1.ReadOnly = true;
            this.Itemcode1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Itemcode1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // GINNumber1
            // 
            this.GINNumber1.DataPropertyName = "GINNumber";
            this.GINNumber1.HeaderText = "GIN Number";
            this.GINNumber1.Name = "GINNumber1";
            this.GINNumber1.ReadOnly = true;
            this.GINNumber1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Quantity1
            // 
            this.Quantity1.DataPropertyName = "Quantity";
            this.Quantity1.HeaderText = "Quantity";
            this.Quantity1.Name = "Quantity1";
            this.Quantity1.ReadOnly = true;
            this.Quantity1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // UnitCost1
            // 
            this.UnitCost1.DataPropertyName = "UnitCost";
            this.UnitCost1.HeaderText = "Unit Cost";
            this.UnitCost1.Name = "UnitCost1";
            this.UnitCost1.ReadOnly = true;
            this.UnitCost1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.UnitCost1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // SupplierName1
            // 
            this.SupplierName1.DataPropertyName = "SupplierName";
            this.SupplierName1.HeaderText = "Supplier Name";
            this.SupplierName1.Name = "SupplierName1";
            this.SupplierName1.ReadOnly = true;
            this.SupplierName1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Date1
            // 
            this.Date1.DataPropertyName = "Date";
            this.Date1.HeaderText = "Date";
            this.Date1.Name = "Date1";
            this.Date1.ReadOnly = true;
            this.Date1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // SupplierInvoiceNumber1
            // 
            this.SupplierInvoiceNumber1.DataPropertyName = "SupplierInvoiceNumber";
            this.SupplierInvoiceNumber1.HeaderText = "Invoice No";
            this.SupplierInvoiceNumber1.Name = "SupplierInvoiceNumber1";
            this.SupplierInvoiceNumber1.ReadOnly = true;
            this.SupplierInvoiceNumber1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Type1
            // 
            this.Type1.DataPropertyName = "Type";
            this.Type1.HeaderText = "Type";
            this.Type1.Name = "Type1";
            this.Type1.ReadOnly = true;
            this.Type1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // RefNumber1
            // 
            this.RefNumber1.DataPropertyName = "RefNumber";
            this.RefNumber1.HeaderText = "RefNumber";
            this.RefNumber1.Name = "RefNumber1";
            this.RefNumber1.ReadOnly = true;
            this.RefNumber1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // lblavailableqty
            // 
            this.lblavailableqty.AutoSize = true;
            this.lblavailableqty.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblavailableqty.ForeColor = System.Drawing.Color.Black;
            this.lblavailableqty.Location = new System.Drawing.Point(610, 147);
            this.lblavailableqty.Name = "lblavailableqty";
            this.lblavailableqty.Size = new System.Drawing.Size(19, 23);
            this.lblavailableqty.TabIndex = 111;
            this.lblavailableqty.Text = "*";
            // 
            // lblavaqty
            // 
            this.lblavaqty.AutoSize = true;
            this.lblavaqty.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblavaqty.ForeColor = System.Drawing.Color.Black;
            this.lblavaqty.Location = new System.Drawing.Point(484, 147);
            this.lblavaqty.Name = "lblavaqty";
            this.lblavaqty.Size = new System.Drawing.Size(126, 23);
            this.lblavaqty.TabIndex = 110;
            this.lblavaqty.Text = "Available Qty :";
            // 
            // lblNoitems
            // 
            this.lblNoitems.AutoSize = true;
            this.lblNoitems.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoitems.ForeColor = System.Drawing.Color.Red;
            this.lblNoitems.Location = new System.Drawing.Point(516, 437);
            this.lblNoitems.Name = "lblNoitems";
            this.lblNoitems.Size = new System.Drawing.Size(405, 33);
            this.lblNoitems.TabIndex = 112;
            this.lblNoitems.Text = "No Repeat Order for Selected Item";
            this.lblNoitems.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(327, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(166, 33);
            this.label1.TabIndex = 113;
            this.label1.Text = "Repeat Order";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.lblitemname);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lblitemdescrption);
            this.panel1.Controls.Add(this.lblItemcode);
            this.panel1.Controls.Add(this.lblavailableqty);
            this.panel1.Controls.Add(this.lblUnitCost);
            this.panel1.Controls.Add(this.lblavaqty);
            this.panel1.Controls.Add(this.lblRepeatitemcode);
            this.panel1.Controls.Add(this.lblrepeatCost);
            this.panel1.ForeColor = System.Drawing.Color.Gold;
            this.panel1.Location = new System.Drawing.Point(522, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(770, 190);
            this.panel1.TabIndex = 114;
            // 
            // lblitemname
            // 
            this.lblitemname.AutoSize = true;
            this.lblitemname.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblitemname.ForeColor = System.Drawing.Color.Black;
            this.lblitemname.Location = new System.Drawing.Point(159, 50);
            this.lblitemname.Name = "lblitemname";
            this.lblitemname.Size = new System.Drawing.Size(17, 29);
            this.lblitemname.TabIndex = 115;
            this.lblitemname.Text = "*";
            this.lblitemname.UseCompatibleTextRendering = true;
            // 
            // txtItemDescription
            // 
            this.txtItemDescription.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemDescription.Location = new System.Drawing.Point(12, 26);
            this.txtItemDescription.Multiline = true;
            this.txtItemDescription.Name = "txtItemDescription";
            this.txtItemDescription.Size = new System.Drawing.Size(503, 33);
            this.txtItemDescription.TabIndex = 115;
            this.txtItemDescription.Enter += new System.EventHandler(this.txtItemDescription_Enter);
            this.txtItemDescription.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtItemDescription_KeyPress);
            this.txtItemDescription.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemDescription_KeyUp);
            // 
            // chklbItemList
            // 
            this.chklbItemList.CheckOnClick = true;
            this.chklbItemList.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chklbItemList.FormattingEnabled = true;
            this.chklbItemList.HorizontalScrollbar = true;
            this.chklbItemList.Location = new System.Drawing.Point(12, 63);
            this.chklbItemList.Name = "chklbItemList";
            this.chklbItemList.Size = new System.Drawing.Size(503, 193);
            this.chklbItemList.TabIndex = 116;
            this.chklbItemList.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.chklbItemList_ItemCheck);
            // 
            // lblitemdescription
            // 
            this.lblitemdescription.AutoSize = true;
            this.lblitemdescription.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblitemdescription.ForeColor = System.Drawing.Color.Black;
            this.lblitemdescription.Location = new System.Drawing.Point(12, 4);
            this.lblitemdescription.Name = "lblitemdescription";
            this.lblitemdescription.Size = new System.Drawing.Size(99, 18);
            this.lblitemdescription.TabIndex = 118;
            this.lblitemdescription.Text = "Search Item by";
            // 
            // chkItemDesc
            // 
            this.chkItemDesc.AutoSize = true;
            this.chkItemDesc.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemDesc.ForeColor = System.Drawing.Color.Black;
            this.chkItemDesc.Location = new System.Drawing.Point(255, 2);
            this.chkItemDesc.Name = "chkItemDesc";
            this.chkItemDesc.Size = new System.Drawing.Size(140, 23);
            this.chkItemDesc.TabIndex = 211;
            this.chkItemDesc.Text = "Item Description";
            this.chkItemDesc.UseVisualStyleBackColor = true;
            this.chkItemDesc.CheckedChanged += new System.EventHandler(this.chkItemDesc_CheckedChanged);
            // 
            // chkItemCode
            // 
            this.chkItemCode.AutoSize = true;
            this.chkItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemCode.ForeColor = System.Drawing.Color.Black;
            this.chkItemCode.Location = new System.Drawing.Point(133, 2);
            this.chkItemCode.Name = "chkItemCode";
            this.chkItemCode.Size = new System.Drawing.Size(97, 23);
            this.chkItemCode.TabIndex = 210;
            this.chkItemCode.Text = "Item Code";
            this.chkItemCode.UseVisualStyleBackColor = true;
            this.chkItemCode.CheckedChanged += new System.EventHandler(this.chkItemCode_CheckedChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(37, 16);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 19);
            this.label7.TabIndex = 212;
            this.label7.Text = "Unit Cost *:";
            // 
            // txtUnitCost
            // 
            this.txtUnitCost.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUnitCost.Location = new System.Drawing.Point(132, 13);
            this.txtUnitCost.Name = "txtUnitCost";
            this.txtUnitCost.Size = new System.Drawing.Size(187, 26);
            this.txtUnitCost.TabIndex = 213;
            this.txtUnitCost.Text = "0";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.btnSave);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.txtUnitCost);
            this.panel2.Location = new System.Drawing.Point(522, 199);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(770, 55);
            this.panel2.TabIndex = 212;
            this.panel2.Visible = false;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(348, 9);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(96, 31);
            this.btnSave.TabIndex = 214;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // RepeatOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1304, 682);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.chkItemDesc);
            this.Controls.Add(this.chkItemCode);
            this.Controls.Add(this.txtItemDescription);
            this.Controls.Add(this.chklbItemList);
            this.Controls.Add(this.lblitemdescription);
            this.Controls.Add(this.lblNoitems);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dgvRepeaOrder);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "RepeatOrder";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Repeat Order";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.RepeatOrder_FormClosing);
            this.Load += new System.EventHandler(this.RepeatOrder_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRepeaOrder)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblitemdescrption;
        private System.Windows.Forms.Label lblItemcode;
        private System.Windows.Forms.Label lblUnitCost;
        private System.Windows.Forms.Label lblRepeatitemcode;
        private System.Windows.Forms.Label lblrepeatCost;
        private System.Windows.Forms.DataGridView dgvRepeaOrder;
        private System.Windows.Forms.Label lblavailableqty;
        private System.Windows.Forms.Label lblavaqty;
        private System.Windows.Forms.Label lblNoitems;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtItemDescription;
        private System.Windows.Forms.CheckedListBox chklbItemList;
        private System.Windows.Forms.Label lblitemdescription;
        private System.Windows.Forms.Label lblitemname;
        private System.Windows.Forms.CheckBox chkItemDesc;
        private System.Windows.Forms.CheckBox chkItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn Itemcode1;
        private System.Windows.Forms.DataGridViewTextBoxColumn GINNumber1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity1;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitCost1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SupplierName1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SupplierInvoiceNumber1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Type1;
        private System.Windows.Forms.DataGridViewTextBoxColumn RefNumber1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtUnitCost;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnSave;
    }
}