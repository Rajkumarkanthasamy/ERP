﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Diagnostics;

namespace Erp_Project_With_Buttons.Purchase_Order
{
    public partial class VendorDealyList : Form
    {
        public VendorDealyList()
        {
            InitializeComponent();
        }
        DataTable dtPolist = new DataTable();
        DataTable dtExcelTable = new DataTable();
        DataAccessLayer DAL = new DataAccessLayer();
        DataView dvPOViewList = new DataView();
        BindingSource bsItemList = new BindingSource();
        Login.frmLoginForm login = new Login.frmLoginForm();
        Global GLobalClass = new Global();
        Purchase_Order.PurchaseOrder PurchaseOrderForm = new PurchaseOrder();

        private void VendorDealyList_Load(object sender, EventArgs e)
        {

        }

        List<string> lTreeviewList = new List<string>();
        private void Datagridviewcolor()
        {
            // dgpolist.Columns[4].Width = 45;
            int GIN = 0, PartialGIN = 0, Pending = 0;
            lTreeviewList.Clear();
            foreach (DataGridViewRow row in dgpolist.Rows)
            {
                if (row.Cells[11].Value.ToString() == "GIN")
                {
                    // NewPO++;
                }
                else if (row.Cells[11].Value.ToString() == "Partial GIN")
                {
                    dgpolist.Rows[dgpolist.Rows.IndexOf(row)].Cells[1].Style.BackColor = Color.Gold;
                    // POComingToday++;
                }
                else if (row.Cells[11].Value.ToString() == "Pending")
                {
                    dgpolist.Rows[dgpolist.Rows.IndexOf(row)].Cells[1].Style.BackColor = Color.Red;
                    //POLate++;
                }


                if (!lTreeviewList.Contains(row.Cells[0].Value.ToString()))
                {
                    lTreeviewList.Add(row.Cells[0].Value.ToString());

                    if (row.Cells[11].Value.ToString() == "GIN")
                    {
                        GIN++;
                    }
                    else if (row.Cells[11].Value.ToString() == "Partial GIN")
                    {
                        PartialGIN++;
                    }
                    else if (row.Cells[11].Value.ToString() == "Pending")
                    {
                        Pending++;
                    }

                }
            }

            btnComingToday.Text = GIN.ToString();
            btnArrivinglaterthanweek.Text = PartialGIN.ToString();
            btnLate.Text = Pending.ToString();
        }

        private void btnrecentlist_Click(object sender, EventArgs e)
        {
            dtpFromDate.Format = DateTimePickerFormat.Custom;
            dtpFromDate.CustomFormat = "yyyy-MM-dd";
            dtpToDate.Format = DateTimePickerFormat.Custom;
            dtpToDate.CustomFormat = "yyyy-MM-dd";
            dtPolist = DAL.fnPOlistforview(2, dtpFromDate.Text, dtpToDate.Text).Tables[0];
            dtExcelTable = new DataTable();
            Datagridviewcolor();
            dtpFromDate.Format = DateTimePickerFormat.Custom;
            dtpFromDate.CustomFormat = "dd-MM-yyyy";
            dtpToDate.Format = DateTimePickerFormat.Custom;
            dtpToDate.CustomFormat = "dd-MM-yyyy";
            // Step 2: Create DataView
            dvPOViewList = new DataView(dtPolist);

            dgpolist.AutoGenerateColumns = true;
            dgpolist.DataSource = dtPolist;
        }
        #region Excel Merge Function

        public void fnDateFormatstring(EXCEL.Worksheet worksheet, string column1, string column2)
        {
            Microsoft.Office.Interop.Excel.Range date = worksheet.get_Range(column1, column2);
            date.EntireColumn.NumberFormat = "DD/MM/YYYY";
        }

        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlMedium, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignCentre":
                    {
                        CELLS.VerticalAlignment = EXCEL.XlVAlign.xlVAlignCenter;
                        break;
                    }
                case "HAlignCentre":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                        break;
                    }
                case "Left":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignLeft;
                        break;
                    }
                case "Right":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                        break;
                    }
                case "Bold":
                    {
                        CELLS.Font.Bold = true;
                        break;
                    }
                case "GridLines":
                    {
                        CELLS.Borders.Color = System.Drawing.Color.Black;
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }

                default:
                    {
                        break;
                    }
            }

        }
        #endregion
        private void btnExcelExceport_Click(object sender, EventArgs e)
        {
            int iRowIndex = 1;
            string ExcelFolderPath;
            string FileFullPath;
            EXCEL.Workbook NewWorkBook;
            EXCEL.Worksheet NewWorkSheet;
            EXCEL.Application ExcelApp;
            EXCEL.Range CELLS, cell1, cell2;
            object misValue;

            dtPolist = dvPOViewList.ToTable();
            // ✅ Make sure dvPOViewList is not null and has rows
            if (dvPOViewList != null && dvPOViewList.Count > 0)
            {
                dtExcelTable = dvPOViewList.ToTable(); // ✅ Assign it here

                if (dtExcelTable.Rows.Count > 0)
                {
                    ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\";
                    FileFullPath = "PO Pending List" + "--" + DateTime.Now.ToString("dd/MM/yyyy hh/mm/ss") + ".xls";
                    if (!Directory.Exists(ExcelFolderPath))
                        Directory.CreateDirectory(ExcelFolderPath);
                    ExcelApp = new EXCEL.Application();
                    misValue = System.Reflection.Missing.Value;
                    try
                    {
                        if (ExcelApp == null)
                            MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                        NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                        NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                        if (NewWorkSheet == null)
                            MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                        else
                            NewWorkSheet.Name = "PO Pending List";
                        // Select the Excel cells, in the range c1 to c7 in the worksheet for cell access check.
                        EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                        if (RANGE == null)
                            MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                        NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlWorkbookNormal, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        CELLS = NewWorkSheet.Cells;

                        // dtIndentItems = DAL.fnIndentExcel(cmbIndentNo.Text, null).Tables[0];

                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);

                        NewWorkSheet.Cells[iRowIndex, 1] = "Po Pending List";
                        iRowIndex++;
                        iRowIndex++;
                        iRowIndex++;

                        if (dtExcelTable.Rows.Count > 0)
                        {
                            object[,] rawData = new object[dtExcelTable.Rows.Count + 1, dtExcelTable.Columns.Count];
                            for (int col = 0; col < dtExcelTable.Columns.Count; col++)
                            {
                                rawData[0, col] = dtExcelTable.Columns[col].ColumnName;
                            }
                            for (int row = 0; row < dtExcelTable.Rows.Count; row++)
                            {
                                for (int col = 0; col < dtExcelTable.Columns.Count; col++)
                                {
                                    rawData[row + 1, col] = dtExcelTable.Rows[row].ItemArray[col];
                                }
                            }
                            string excelRange = string.Empty;
                            string finalColLetter = string.Empty;
                            string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                            int colCharsetLen = colCharset.Length;

                            if (dtExcelTable.Columns.Count > colCharsetLen)
                            {
                                finalColLetter = colCharset.Substring(
                                    (dtExcelTable.Columns.Count - 1) / colCharsetLen - 1, 1);
                            }

                            finalColLetter += colCharset.Substring((dtExcelTable.Columns.Count - 1) % colCharsetLen, 1);
                            excelRange = string.Format("A6:{0}{1}", finalColLetter, dtExcelTable.Rows.Count + 6);

                            NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        }


                        NewWorkSheet.Range["A1:T6"].Cells.Font.Bold = true;
                        NewWorkSheet.Range["A1:B2"].Cells.Font.Size = 16;
                        fnDateFormatstring(NewWorkSheet, "C1", "C9999");
                        fnDateFormatstring(NewWorkSheet, "I1", "I9999");
                        fnDateFormatstring(NewWorkSheet, "K1", "K9999");
                        fnDateFormatstring(NewWorkSheet, "T1", "T9999");


                        NewWorkSheet.Rows.AutoFit();
                        NewWorkSheet.Columns.AutoFit();
                        NewWorkSheet.Rows.RowHeight = "18";

                        NewWorkSheet.Columns[5].ColumnWidth = 50;
                        NewWorkSheet.Columns[5].WrapText = true;
                        NewWorkSheet.Columns[7].ColumnWidth = 50;
                        NewWorkSheet.Columns[7].WrapText = true;
                        NewWorkSheet.Columns[13].ColumnWidth = 50;
                        NewWorkSheet.Columns[13].WrapText = true;
                        NewWorkSheet.Columns[21].ColumnWidth = 50;
                        NewWorkSheet.Columns[21].WrapText = true;


                        NewWorkSheet.PageSetup.PrintArea = "A1:U" + (dtExcelTable.Rows.Count + iRowIndex + 12) + "";
                        NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                        NewWorkSheet.PageSetup.PrintNotes = true;
                        NewWorkSheet.PageSetup.Zoom = 100;
                        NewWorkSheet.PageSetup.FitToPagesTall = 1;
                        NewWorkSheet.PageSetup.FitToPagesWide = 1;
                        NewWorkSheet.PageSetup.LeftMargin = 0;
                        NewWorkSheet.PageSetup.RightMargin = 0;
                        NewWorkSheet.PageSetup.TopMargin = 0.75;
                        NewWorkSheet.PageSetup.BottomMargin = 0.75;
                        NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                        NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                        string _stLOGO = ("C:\\Databasepath\\Bisslogo.jpg");
                        EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 7];

                        Image oImage = Image.FromFile(_stLOGO);
                        System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                        NewWorkSheet.Paste(oRange, _stLOGO);

                        NewWorkBook.Save();
                        ExcelApp.Visible = true;
                        System.Threading.Thread.Sleep(1000);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                        foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                        {
                            GetProcess.Kill();
                        }
                    }
                }
                else
                    MessageBox.Show("No items to save", "Error", 0, MessageBoxIcon.Question);
            }
        }
    }
}
