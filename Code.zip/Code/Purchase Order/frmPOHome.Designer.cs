﻿namespace Erp_Project_With_Buttons.Purchase_Order
{
    partial class frmPOHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPOHome));
            this.lblName = new System.Windows.Forms.Label();
            this.btncurrency = new System.Windows.Forms.Button();
            this.btnVendorDelayList = new System.Windows.Forms.Button();
            this.BOMPOTrack = new System.Windows.Forms.Button();
            this.btnPOConfirm = new System.Windows.Forms.Button();
            this.btnPOTrack = new System.Windows.Forms.Button();
            this.btnPurchaseOrder = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.Indigo;
            this.lblName.Location = new System.Drawing.Point(289, 9);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(294, 29);
            this.lblName.TabIndex = 41;
            this.lblName.Text = "BiSS Inventory Management";
            // 
            // btncurrency
            // 
            this.btncurrency.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btncurrency.FlatAppearance.BorderSize = 0;
            this.btncurrency.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncurrency.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btncurrency.ForeColor = System.Drawing.Color.MediumBlue;
            this.btncurrency.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_sales_performance_482;
            this.btncurrency.Location = new System.Drawing.Point(617, 415);
            this.btncurrency.Name = "btncurrency";
            this.btncurrency.Size = new System.Drawing.Size(132, 92);
            this.btncurrency.TabIndex = 45;
            this.btncurrency.Text = "Currency Rate";
            this.btncurrency.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btncurrency.UseVisualStyleBackColor = true;
            this.btncurrency.Click += new System.EventHandler(this.btncurrency_Click);
            // 
            // btnVendorDelayList
            // 
            this.btnVendorDelayList.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnVendorDelayList.FlatAppearance.BorderSize = 0;
            this.btnVendorDelayList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVendorDelayList.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnVendorDelayList.ForeColor = System.Drawing.Color.MediumBlue;
            this.btnVendorDelayList.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_leave_481;
            this.btnVendorDelayList.Location = new System.Drawing.Point(75, 386);
            this.btnVendorDelayList.Name = "btnVendorDelayList";
            this.btnVendorDelayList.Size = new System.Drawing.Size(150, 121);
            this.btnVendorDelayList.TabIndex = 44;
            this.btnVendorDelayList.Text = "PO Vendor Delay List";
            this.btnVendorDelayList.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnVendorDelayList.UseVisualStyleBackColor = true;
            this.btnVendorDelayList.Click += new System.EventHandler(this.btnVendorDelayList_Click);
            // 
            // BOMPOTrack
            // 
            this.BOMPOTrack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.BOMPOTrack.FlatAppearance.BorderSize = 0;
            this.BOMPOTrack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BOMPOTrack.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.BOMPOTrack.ForeColor = System.Drawing.Color.MediumBlue;
            this.BOMPOTrack.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_order_history_48__1_1;
            this.BOMPOTrack.Location = new System.Drawing.Point(617, 254);
            this.BOMPOTrack.Name = "BOMPOTrack";
            this.BOMPOTrack.Size = new System.Drawing.Size(132, 92);
            this.BOMPOTrack.TabIndex = 43;
            this.BOMPOTrack.Text = "BOM PO Track";
            this.BOMPOTrack.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BOMPOTrack.UseVisualStyleBackColor = true;
            this.BOMPOTrack.Click += new System.EventHandler(this.BOMPOTrack_Click);
            // 
            // btnPOConfirm
            // 
            this.btnPOConfirm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnPOConfirm.FlatAppearance.BorderSize = 0;
            this.btnPOConfirm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPOConfirm.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnPOConfirm.ForeColor = System.Drawing.Color.MediumBlue;
            this.btnPOConfirm.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_leadership_481;
            this.btnPOConfirm.Location = new System.Drawing.Point(75, 233);
            this.btnPOConfirm.Name = "btnPOConfirm";
            this.btnPOConfirm.Size = new System.Drawing.Size(150, 113);
            this.btnPOConfirm.TabIndex = 42;
            this.btnPOConfirm.Text = "PO Vendor Sent\r\nConfirmation";
            this.btnPOConfirm.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPOConfirm.UseVisualStyleBackColor = true;
            this.btnPOConfirm.Click += new System.EventHandler(this.btnPOConfirm_Click);
            // 
            // btnPOTrack
            // 
            this.btnPOTrack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnPOTrack.FlatAppearance.BorderSize = 0;
            this.btnPOTrack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPOTrack.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnPOTrack.ForeColor = System.Drawing.Color.MediumBlue;
            this.btnPOTrack.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_view_48;
            this.btnPOTrack.Location = new System.Drawing.Point(617, 97);
            this.btnPOTrack.Name = "btnPOTrack";
            this.btnPOTrack.Size = new System.Drawing.Size(132, 92);
            this.btnPOTrack.TabIndex = 10;
            this.btnPOTrack.Text = "PO Track Update";
            this.btnPOTrack.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPOTrack.UseVisualStyleBackColor = true;
            this.btnPOTrack.Click += new System.EventHandler(this.btnPOTrack_Click);
            // 
            // btnPurchaseOrder
            // 
            this.btnPurchaseOrder.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnPurchaseOrder.FlatAppearance.BorderSize = 0;
            this.btnPurchaseOrder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPurchaseOrder.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnPurchaseOrder.ForeColor = System.Drawing.Color.MediumBlue;
            this.btnPurchaseOrder.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_purchase_order_48;
            this.btnPurchaseOrder.Location = new System.Drawing.Point(101, 97);
            this.btnPurchaseOrder.Name = "btnPurchaseOrder";
            this.btnPurchaseOrder.Size = new System.Drawing.Size(124, 92);
            this.btnPurchaseOrder.TabIndex = 8;
            this.btnPurchaseOrder.Text = "Purchase Order";
            this.btnPurchaseOrder.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPurchaseOrder.UseVisualStyleBackColor = true;
            this.btnPurchaseOrder.Click += new System.EventHandler(this.btnPurchaseOrder_Click);
            // 
            // frmPOHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(947, 530);
            this.Controls.Add(this.btncurrency);
            this.Controls.Add(this.btnVendorDelayList);
            this.Controls.Add(this.BOMPOTrack);
            this.Controls.Add(this.btnPOConfirm);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.btnPOTrack);
            this.Controls.Add(this.btnPurchaseOrder);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmPOHome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Purchase Order Home";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmPOHome_FormClosing);
            this.Load += new System.EventHandler(this.frmPOHome_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPurchaseOrder;
        private System.Windows.Forms.Button btnPOTrack;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Button btnPOConfirm;
        private System.Windows.Forms.Button BOMPOTrack;
        private System.Windows.Forms.Button btnVendorDelayList;
        private System.Windows.Forms.Button btncurrency;
    }
}