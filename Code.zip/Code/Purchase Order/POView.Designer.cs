﻿namespace Erp_Project_With_Buttons.Purchase_Order
{
    partial class POView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(POView));
            this.dgpolist = new System.Windows.Forms.DataGridView();
            this.gbSearchOptions = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dtpFromDate = new System.Windows.Forms.DateTimePicker();
            this.dtpToDate = new System.Windows.Forms.DateTimePicker();
            this.lblToDate = new System.Windows.Forms.Label();
            this.lblFromdate = new System.Windows.Forms.Label();
            this.btnrecentlist = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnArrivinglaterthanweek = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.btnTotal = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.btnArrivinginaweek = new System.Windows.Forms.Button();
            this.btnLate = new System.Windows.Forms.Button();
            this.btnComingToday = new System.Windows.Forms.Button();
            this.btnNewPO = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.pnOADate = new System.Windows.Forms.Panel();
            this.btnUpdateOADate = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.dtpdelivery = new System.Windows.Forms.DateTimePicker();
            this.dtpOADate = new System.Windows.Forms.DateTimePicker();
            this.btnloadcompletePOlist = new System.Windows.Forms.Button();
            this.btnExcelExceport = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPODelayDays = new System.Windows.Forms.TextBox();
            this.txtAuthorisedBy = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtPreparedBy = new System.Windows.Forms.TextBox();
            this.lblIteType = new System.Windows.Forms.Label();
            this.txtProjectcode = new System.Windows.Forms.TextBox();
            this.lblItemDescription = new System.Windows.Forms.Label();
            this.txtDBOMNo = new System.Windows.Forms.TextBox();
            this.lblItemCode = new System.Windows.Forms.Label();
            this.DBOMNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.POLateBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DeliveryDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VendorName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RequariedQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RemainingQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PreparedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.POPreparedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AuthorisedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.POAuthoriseDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MHName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MHApprovedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FinalizedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FinalizedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PurchaseCommitee = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PCAuthoriseDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FinanceApproverName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FinanceApprovedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.POGeneratedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.POGeneratedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgpolist)).BeginInit();
            this.gbSearchOptions.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.pnOADate.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgpolist
            // 
            this.dgpolist.AllowUserToAddRows = false;
            this.dgpolist.AllowUserToDeleteRows = false;
            this.dgpolist.AllowUserToResizeRows = false;
            this.dgpolist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgpolist.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgpolist.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgpolist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgpolist.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DBOMNO,
            this.POLateBy,
            this.DeliveryDate,
            this.ProjectCode,
            this.ProjectDescription,
            this.VendorName,
            this.ItemCode,
            this.ItemDescription,
            this.UnitCost,
            this.RequariedQty,
            this.RemainingQty,
            this.Amount,
            this.PreparedBy,
            this.POPreparedDate,
            this.AuthorisedBy,
            this.POAuthoriseDate,
            this.MHName,
            this.MHApprovedDate,
            this.FinalizedBy,
            this.FinalizedDate,
            this.PurchaseCommitee,
            this.PCAuthoriseDate,
            this.FinanceApproverName,
            this.FinanceApprovedDate,
            this.POGeneratedBy,
            this.POGeneratedDate});
            this.dgpolist.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgpolist.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgpolist.EnableHeadersVisualStyles = false;
            this.dgpolist.Location = new System.Drawing.Point(4, 238);
            this.dgpolist.Margin = new System.Windows.Forms.Padding(4);
            this.dgpolist.MultiSelect = false;
            this.dgpolist.Name = "dgpolist";
            this.dgpolist.ReadOnly = true;
            this.dgpolist.RowHeadersVisible = false;
            this.dgpolist.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgpolist.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgpolist.Size = new System.Drawing.Size(1298, 440);
            this.dgpolist.TabIndex = 8;
            this.dgpolist.Click += new System.EventHandler(this.dgpolist_Click);
            this.dgpolist.DoubleClick += new System.EventHandler(this.dgpolist_DoubleClick);
            // 
            // gbSearchOptions
            // 
            this.gbSearchOptions.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.gbSearchOptions.Controls.Add(this.panel2);
            this.gbSearchOptions.Controls.Add(this.panel1);
            this.gbSearchOptions.Controls.Add(this.pnOADate);
            this.gbSearchOptions.Controls.Add(this.btnloadcompletePOlist);
            this.gbSearchOptions.Controls.Add(this.btnExcelExceport);
            this.gbSearchOptions.Controls.Add(this.label2);
            this.gbSearchOptions.Controls.Add(this.txtPODelayDays);
            this.gbSearchOptions.Controls.Add(this.txtAuthorisedBy);
            this.gbSearchOptions.Controls.Add(this.label1);
            this.gbSearchOptions.Controls.Add(this.txtPreparedBy);
            this.gbSearchOptions.Controls.Add(this.lblIteType);
            this.gbSearchOptions.Controls.Add(this.txtProjectcode);
            this.gbSearchOptions.Controls.Add(this.lblItemDescription);
            this.gbSearchOptions.Controls.Add(this.txtDBOMNo);
            this.gbSearchOptions.Controls.Add(this.lblItemCode);
            this.gbSearchOptions.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.gbSearchOptions.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbSearchOptions.Location = new System.Drawing.Point(4, 5);
            this.gbSearchOptions.Margin = new System.Windows.Forms.Padding(4);
            this.gbSearchOptions.Name = "gbSearchOptions";
            this.gbSearchOptions.Padding = new System.Windows.Forms.Padding(4);
            this.gbSearchOptions.Size = new System.Drawing.Size(1298, 232);
            this.gbSearchOptions.TabIndex = 7;
            this.gbSearchOptions.TabStop = false;
            this.gbSearchOptions.Text = "Search Options";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.dtpFromDate);
            this.panel2.Controls.Add(this.dtpToDate);
            this.panel2.Controls.Add(this.lblToDate);
            this.panel2.Controls.Add(this.lblFromdate);
            this.panel2.Controls.Add(this.btnrecentlist);
            this.panel2.Location = new System.Drawing.Point(22, 128);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(474, 53);
            this.panel2.TabIndex = 201;
            this.panel2.Visible = false;
            // 
            // dtpFromDate
            // 
            this.dtpFromDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.dtpFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFromDate.Location = new System.Drawing.Point(73, 10);
            this.dtpFromDate.Margin = new System.Windows.Forms.Padding(4);
            this.dtpFromDate.Name = "dtpFromDate";
            this.dtpFromDate.Size = new System.Drawing.Size(124, 27);
            this.dtpFromDate.TabIndex = 26;
            // 
            // dtpToDate
            // 
            this.dtpToDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.dtpToDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpToDate.Location = new System.Drawing.Point(250, 10);
            this.dtpToDate.Margin = new System.Windows.Forms.Padding(4);
            this.dtpToDate.Name = "dtpToDate";
            this.dtpToDate.Size = new System.Drawing.Size(124, 27);
            this.dtpToDate.TabIndex = 27;
            // 
            // lblToDate
            // 
            this.lblToDate.AutoSize = true;
            this.lblToDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblToDate.Location = new System.Drawing.Point(205, 15);
            this.lblToDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblToDate.Name = "lblToDate";
            this.lblToDate.Size = new System.Drawing.Size(33, 19);
            this.lblToDate.TabIndex = 25;
            this.lblToDate.Text = "To :";
            this.lblToDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblFromdate
            // 
            this.lblFromdate.AutoSize = true;
            this.lblFromdate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblFromdate.Location = new System.Drawing.Point(4, 15);
            this.lblFromdate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFromdate.Name = "lblFromdate";
            this.lblFromdate.Size = new System.Drawing.Size(52, 19);
            this.lblFromdate.TabIndex = 24;
            this.lblFromdate.Text = "From :";
            // 
            // btnrecentlist
            // 
            this.btnrecentlist.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrecentlist.ForeColor = System.Drawing.Color.Indigo;
            this.btnrecentlist.Location = new System.Drawing.Point(385, 8);
            this.btnrecentlist.Margin = new System.Windows.Forms.Padding(4);
            this.btnrecentlist.Name = "btnrecentlist";
            this.btnrecentlist.Size = new System.Drawing.Size(76, 32);
            this.btnrecentlist.TabIndex = 28;
            this.btnrecentlist.Text = "Search";
            this.btnrecentlist.UseVisualStyleBackColor = true;
            this.btnrecentlist.Click += new System.EventHandler(this.btnrecentlist_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightGray;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.btnArrivinglaterthanweek);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.btnTotal);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.btnArrivinginaweek);
            this.panel1.Controls.Add(this.btnLate);
            this.panel1.Controls.Add(this.btnComingToday);
            this.panel1.Controls.Add(this.btnNewPO);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(8, 188);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1285, 36);
            this.panel1.TabIndex = 200;
            // 
            // btnArrivinglaterthanweek
            // 
            this.btnArrivinglaterthanweek.BackColor = System.Drawing.Color.Gold;
            this.btnArrivinglaterthanweek.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnArrivinglaterthanweek.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnArrivinglaterthanweek.ForeColor = System.Drawing.Color.Black;
            this.btnArrivinglaterthanweek.Location = new System.Drawing.Point(912, -2);
            this.btnArrivinglaterthanweek.Margin = new System.Windows.Forms.Padding(4);
            this.btnArrivinglaterthanweek.Name = "btnArrivinglaterthanweek";
            this.btnArrivinglaterthanweek.Size = new System.Drawing.Size(54, 32);
            this.btnArrivinglaterthanweek.TabIndex = 197;
            this.btnArrivinglaterthanweek.UseVisualStyleBackColor = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(677, 4);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(227, 19);
            this.label8.TabIndex = 196;
            this.label8.Text = "Items arriving later than a week";
            // 
            // btnTotal
            // 
            this.btnTotal.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnTotal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTotal.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTotal.ForeColor = System.Drawing.Color.Black;
            this.btnTotal.Location = new System.Drawing.Point(1583, 0);
            this.btnTotal.Margin = new System.Windows.Forms.Padding(4);
            this.btnTotal.Name = "btnTotal";
            this.btnTotal.Size = new System.Drawing.Size(101, 32);
            this.btnTotal.TabIndex = 195;
            this.btnTotal.UseVisualStyleBackColor = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(1517, 4);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 19);
            this.label5.TabIndex = 194;
            this.label5.Text = "Total";
            // 
            // btnArrivinginaweek
            // 
            this.btnArrivinginaweek.BackColor = System.Drawing.Color.GreenYellow;
            this.btnArrivinginaweek.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnArrivinginaweek.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnArrivinginaweek.ForeColor = System.Drawing.Color.Black;
            this.btnArrivinginaweek.Location = new System.Drawing.Point(604, 0);
            this.btnArrivinginaweek.Margin = new System.Windows.Forms.Padding(4);
            this.btnArrivinginaweek.Name = "btnArrivinginaweek";
            this.btnArrivinginaweek.Size = new System.Drawing.Size(59, 32);
            this.btnArrivinginaweek.TabIndex = 193;
            this.btnArrivinginaweek.UseVisualStyleBackColor = false;
            // 
            // btnLate
            // 
            this.btnLate.BackColor = System.Drawing.Color.Red;
            this.btnLate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLate.ForeColor = System.Drawing.Color.Black;
            this.btnLate.Location = new System.Drawing.Point(1125, 0);
            this.btnLate.Margin = new System.Windows.Forms.Padding(4);
            this.btnLate.Name = "btnLate";
            this.btnLate.Size = new System.Drawing.Size(62, 32);
            this.btnLate.TabIndex = 192;
            this.btnLate.UseVisualStyleBackColor = false;
            // 
            // btnComingToday
            // 
            this.btnComingToday.BackColor = System.Drawing.Color.LightGreen;
            this.btnComingToday.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnComingToday.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnComingToday.ForeColor = System.Drawing.Color.Black;
            this.btnComingToday.Location = new System.Drawing.Point(312, 2);
            this.btnComingToday.Margin = new System.Windows.Forms.Padding(4);
            this.btnComingToday.Name = "btnComingToday";
            this.btnComingToday.Size = new System.Drawing.Size(57, 32);
            this.btnComingToday.TabIndex = 191;
            this.btnComingToday.UseVisualStyleBackColor = false;
            // 
            // btnNewPO
            // 
            this.btnNewPO.BackColor = System.Drawing.Color.White;
            this.btnNewPO.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNewPO.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewPO.ForeColor = System.Drawing.Color.Black;
            this.btnNewPO.Location = new System.Drawing.Point(85, 0);
            this.btnNewPO.Margin = new System.Windows.Forms.Padding(4);
            this.btnNewPO.Name = "btnNewPO";
            this.btnNewPO.Size = new System.Drawing.Size(51, 32);
            this.btnNewPO.TabIndex = 190;
            this.btnNewPO.UseVisualStyleBackColor = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(393, 4);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(203, 19);
            this.label4.TabIndex = 182;
            this.label4.Text = "Items arriving within a week";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(994, 5);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 19);
            this.label3.TabIndex = 181;
            this.label3.Text = "Items Delayed";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(157, 4);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(147, 19);
            this.label6.TabIndex = 180;
            this.label6.Text = "Items arriving today";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(8, 4);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(81, 19);
            this.label7.TabIndex = 179;
            this.label7.Text = "New Items";
            // 
            // pnOADate
            // 
            this.pnOADate.Controls.Add(this.btnUpdateOADate);
            this.pnOADate.Controls.Add(this.label9);
            this.pnOADate.Controls.Add(this.label10);
            this.pnOADate.Controls.Add(this.dtpdelivery);
            this.pnOADate.Controls.Add(this.dtpOADate);
            this.pnOADate.Location = new System.Drawing.Point(832, 83);
            this.pnOADate.Name = "pnOADate";
            this.pnOADate.Size = new System.Drawing.Size(461, 100);
            this.pnOADate.TabIndex = 30;
            this.pnOADate.Visible = false;
            // 
            // btnUpdateOADate
            // 
            this.btnUpdateOADate.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateOADate.ForeColor = System.Drawing.Color.Indigo;
            this.btnUpdateOADate.Location = new System.Drawing.Point(332, 41);
            this.btnUpdateOADate.Margin = new System.Windows.Forms.Padding(4);
            this.btnUpdateOADate.Name = "btnUpdateOADate";
            this.btnUpdateOADate.Size = new System.Drawing.Size(123, 38);
            this.btnUpdateOADate.TabIndex = 32;
            this.btnUpdateOADate.Text = "Update";
            this.btnUpdateOADate.UseVisualStyleBackColor = true;
            this.btnUpdateOADate.Click += new System.EventHandler(this.btnUpdateOADate_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label9.Location = new System.Drawing.Point(10, 10);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(109, 19);
            this.label9.TabIndex = 28;
            this.label9.Text = "Delivery Date :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label10.Location = new System.Drawing.Point(52, 60);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(74, 19);
            this.label10.TabIndex = 29;
            this.label10.Text = "OA Date :";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dtpdelivery
            // 
            this.dtpdelivery.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.dtpdelivery.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpdelivery.Location = new System.Drawing.Point(161, 4);
            this.dtpdelivery.Margin = new System.Windows.Forms.Padding(4);
            this.dtpdelivery.Name = "dtpdelivery";
            this.dtpdelivery.Size = new System.Drawing.Size(163, 27);
            this.dtpdelivery.TabIndex = 30;
            // 
            // dtpOADate
            // 
            this.dtpOADate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.dtpOADate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpOADate.Location = new System.Drawing.Point(161, 52);
            this.dtpOADate.Margin = new System.Windows.Forms.Padding(4);
            this.dtpOADate.Name = "dtpOADate";
            this.dtpOADate.Size = new System.Drawing.Size(163, 27);
            this.dtpOADate.TabIndex = 31;
            this.dtpOADate.ValueChanged += new System.EventHandler(this.dtpOADate_ValueChanged);
            // 
            // btnloadcompletePOlist
            // 
            this.btnloadcompletePOlist.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnloadcompletePOlist.ForeColor = System.Drawing.Color.Indigo;
            this.btnloadcompletePOlist.Location = new System.Drawing.Point(530, 138);
            this.btnloadcompletePOlist.Margin = new System.Windows.Forms.Padding(4);
            this.btnloadcompletePOlist.Name = "btnloadcompletePOlist";
            this.btnloadcompletePOlist.Size = new System.Drawing.Size(102, 38);
            this.btnloadcompletePOlist.TabIndex = 29;
            this.btnloadcompletePOlist.Text = "Search All";
            this.btnloadcompletePOlist.UseVisualStyleBackColor = true;
            this.btnloadcompletePOlist.Click += new System.EventHandler(this.btnloadcompletePOlist_Click);
            // 
            // btnExcelExceport
            // 
            this.btnExcelExceport.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcelExceport.ForeColor = System.Drawing.Color.Indigo;
            this.btnExcelExceport.Location = new System.Drawing.Point(650, 138);
            this.btnExcelExceport.Margin = new System.Windows.Forms.Padding(4);
            this.btnExcelExceport.Name = "btnExcelExceport";
            this.btnExcelExceport.Size = new System.Drawing.Size(153, 38);
            this.btnExcelExceport.TabIndex = 23;
            this.btnExcelExceport.Text = "Export to Excel";
            this.btnExcelExceport.UseVisualStyleBackColor = true;
            this.btnExcelExceport.Click += new System.EventHandler(this.btnExcelExceport_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(31, 83);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 19);
            this.label2.TabIndex = 8;
            this.label2.Text = "PO Delay Days :";
            // 
            // txtPODelayDays
            // 
            this.txtPODelayDays.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPODelayDays.Location = new System.Drawing.Point(154, 80);
            this.txtPODelayDays.Margin = new System.Windows.Forms.Padding(4);
            this.txtPODelayDays.Name = "txtPODelayDays";
            this.txtPODelayDays.Size = new System.Drawing.Size(172, 26);
            this.txtPODelayDays.TabIndex = 7;
            this.txtPODelayDays.Enter += new System.EventHandler(this.txtPODelayDays_Enter);
            this.txtPODelayDays.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtPODelayDays_KeyUp);
            // 
            // txtAuthorisedBy
            // 
            this.txtAuthorisedBy.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAuthorisedBy.Location = new System.Drawing.Point(513, 89);
            this.txtAuthorisedBy.Margin = new System.Windows.Forms.Padding(4);
            this.txtAuthorisedBy.Name = "txtAuthorisedBy";
            this.txtAuthorisedBy.Size = new System.Drawing.Size(202, 26);
            this.txtAuthorisedBy.TabIndex = 6;
            this.txtAuthorisedBy.Enter += new System.EventHandler(this.txtAuthorisedBy_Enter);
            this.txtAuthorisedBy.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtAuthorisedBy_KeyUp);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(369, 92);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 19);
            this.label1.TabIndex = 5;
            this.label1.Text = "Authorised By:";
            // 
            // txtPreparedBy
            // 
            this.txtPreparedBy.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPreparedBy.Location = new System.Drawing.Point(948, 36);
            this.txtPreparedBy.Margin = new System.Windows.Forms.Padding(4);
            this.txtPreparedBy.Name = "txtPreparedBy";
            this.txtPreparedBy.Size = new System.Drawing.Size(339, 26);
            this.txtPreparedBy.TabIndex = 4;
            this.txtPreparedBy.Enter += new System.EventHandler(this.txtPreparedBy_Enter);
            this.txtPreparedBy.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtPreparedBy_KeyUp);
            // 
            // lblIteType
            // 
            this.lblIteType.AutoSize = true;
            this.lblIteType.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIteType.Location = new System.Drawing.Point(804, 39);
            this.lblIteType.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIteType.Name = "lblIteType";
            this.lblIteType.Size = new System.Drawing.Size(110, 19);
            this.lblIteType.TabIndex = 1;
            this.lblIteType.Text = "Vendor Name :";
            // 
            // txtProjectcode
            // 
            this.txtProjectcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProjectcode.Location = new System.Drawing.Point(513, 36);
            this.txtProjectcode.Margin = new System.Windows.Forms.Padding(4);
            this.txtProjectcode.Name = "txtProjectcode";
            this.txtProjectcode.Size = new System.Drawing.Size(269, 26);
            this.txtProjectcode.TabIndex = 3;
            this.txtProjectcode.Enter += new System.EventHandler(this.txtProjectcode_Enter);
            this.txtProjectcode.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtProjectcode_KeyUp);
            // 
            // lblItemDescription
            // 
            this.lblItemDescription.AutoSize = true;
            this.lblItemDescription.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemDescription.Location = new System.Drawing.Point(376, 39);
            this.lblItemDescription.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblItemDescription.Name = "lblItemDescription";
            this.lblItemDescription.Size = new System.Drawing.Size(104, 19);
            this.lblItemDescription.TabIndex = 2;
            this.lblItemDescription.Text = "Project Code :";
            // 
            // txtDBOMNo
            // 
            this.txtDBOMNo.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDBOMNo.Location = new System.Drawing.Point(154, 36);
            this.txtDBOMNo.Margin = new System.Windows.Forms.Padding(4);
            this.txtDBOMNo.Name = "txtDBOMNo";
            this.txtDBOMNo.Size = new System.Drawing.Size(207, 26);
            this.txtDBOMNo.TabIndex = 1;
            this.txtDBOMNo.Enter += new System.EventHandler(this.txtDBOMNo_Enter);
            this.txtDBOMNo.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtDBOMNo_KeyUp);
            // 
            // lblItemCode
            // 
            this.lblItemCode.AutoSize = true;
            this.lblItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemCode.Location = new System.Drawing.Point(85, 43);
            this.lblItemCode.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblItemCode.Name = "lblItemCode";
            this.lblItemCode.Size = new System.Drawing.Size(61, 19);
            this.lblItemCode.TabIndex = 0;
            this.lblItemCode.Text = "PO No :";
            // 
            // DBOMNO
            // 
            this.DBOMNO.DataPropertyName = "DBOMNo";
            this.DBOMNO.Frozen = true;
            this.DBOMNO.HeaderText = "PONo";
            this.DBOMNO.Name = "DBOMNO";
            this.DBOMNO.ReadOnly = true;
            this.DBOMNO.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DBOMNO.Width = 55;
            // 
            // POLateBy
            // 
            this.POLateBy.DataPropertyName = "POLateBy";
            this.POLateBy.HeaderText = "PO Late By";
            this.POLateBy.Name = "POLateBy";
            this.POLateBy.ReadOnly = true;
            this.POLateBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.POLateBy.Width = 89;
            // 
            // DeliveryDate
            // 
            this.DeliveryDate.DataPropertyName = "PODeliveryDate";
            this.DeliveryDate.HeaderText = "Delivery Date";
            this.DeliveryDate.Name = "DeliveryDate";
            this.DeliveryDate.ReadOnly = true;
            this.DeliveryDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DeliveryDate.Width = 107;
            // 
            // ProjectCode
            // 
            this.ProjectCode.DataPropertyName = "ProjectCode";
            this.ProjectCode.HeaderText = "Project Code";
            this.ProjectCode.Name = "ProjectCode";
            this.ProjectCode.ReadOnly = true;
            this.ProjectCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectCode.Width = 102;
            // 
            // ProjectDescription
            // 
            this.ProjectDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ProjectDescription.DataPropertyName = "ProjectDescription";
            this.ProjectDescription.HeaderText = "Project Name";
            this.ProjectDescription.Name = "ProjectDescription";
            this.ProjectDescription.ReadOnly = true;
            this.ProjectDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectDescription.Width = 143;
            // 
            // VendorName
            // 
            this.VendorName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.VendorName.DataPropertyName = "VendorName";
            this.VendorName.HeaderText = "Vendor";
            this.VendorName.Name = "VendorName";
            this.VendorName.ReadOnly = true;
            this.VendorName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.VendorName.Width = 103;
            // 
            // ItemCode
            // 
            this.ItemCode.DataPropertyName = "ItemCode";
            this.ItemCode.HeaderText = "Item Code";
            this.ItemCode.Name = "ItemCode";
            this.ItemCode.ReadOnly = true;
            this.ItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemCode.Width = 84;
            // 
            // ItemDescription
            // 
            this.ItemDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ItemDescription.DataPropertyName = "ItemDescription";
            this.ItemDescription.HeaderText = "Item Desc";
            this.ItemDescription.Name = "ItemDescription";
            this.ItemDescription.ReadOnly = true;
            this.ItemDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemDescription.Width = 123;
            // 
            // UnitCost
            // 
            this.UnitCost.DataPropertyName = "UnitPrice";
            this.UnitCost.HeaderText = "UnitCost";
            this.UnitCost.Name = "UnitCost";
            this.UnitCost.ReadOnly = true;
            this.UnitCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitCost.Width = 73;
            // 
            // RequariedQty
            // 
            this.RequariedQty.DataPropertyName = "RequariedQty";
            this.RequariedQty.HeaderText = "Req Qty";
            this.RequariedQty.Name = "RequariedQty";
            this.RequariedQty.ReadOnly = true;
            this.RequariedQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RequariedQty.Width = 70;
            // 
            // RemainingQty
            // 
            this.RemainingQty.DataPropertyName = "RemainingQty";
            this.RemainingQty.HeaderText = "Rem Qty";
            this.RemainingQty.Name = "RemainingQty";
            this.RemainingQty.ReadOnly = true;
            this.RemainingQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RemainingQty.Width = 74;
            // 
            // Amount
            // 
            this.Amount.DataPropertyName = "Amount";
            this.Amount.HeaderText = "Amount";
            this.Amount.Name = "Amount";
            this.Amount.ReadOnly = true;
            this.Amount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Amount.Width = 71;
            // 
            // PreparedBy
            // 
            this.PreparedBy.DataPropertyName = "PreparedBy";
            this.PreparedBy.HeaderText = "PreparedBy";
            this.PreparedBy.Name = "PreparedBy";
            this.PreparedBy.ReadOnly = true;
            this.PreparedBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PreparedBy.Width = 95;
            // 
            // POPreparedDate
            // 
            this.POPreparedDate.DataPropertyName = "POPreparedDate";
            this.POPreparedDate.HeaderText = "Date";
            this.POPreparedDate.Name = "POPreparedDate";
            this.POPreparedDate.ReadOnly = true;
            this.POPreparedDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.POPreparedDate.Width = 47;
            // 
            // AuthorisedBy
            // 
            this.AuthorisedBy.DataPropertyName = "PMName";
            this.AuthorisedBy.HeaderText = "PM Name";
            this.AuthorisedBy.Name = "AuthorisedBy";
            this.AuthorisedBy.ReadOnly = true;
            this.AuthorisedBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.AuthorisedBy.Width = 82;
            // 
            // POAuthoriseDate
            // 
            this.POAuthoriseDate.DataPropertyName = "PMApprovedDate";
            this.POAuthoriseDate.HeaderText = "Date";
            this.POAuthoriseDate.Name = "POAuthoriseDate";
            this.POAuthoriseDate.ReadOnly = true;
            this.POAuthoriseDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.POAuthoriseDate.Width = 47;
            // 
            // MHName
            // 
            this.MHName.DataPropertyName = "MHName";
            this.MHName.HeaderText = "MHName";
            this.MHName.Name = "MHName";
            this.MHName.ReadOnly = true;
            this.MHName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.MHName.Width = 79;
            // 
            // MHApprovedDate
            // 
            this.MHApprovedDate.DataPropertyName = "MHApprovedDate";
            this.MHApprovedDate.HeaderText = "Date";
            this.MHApprovedDate.Name = "MHApprovedDate";
            this.MHApprovedDate.ReadOnly = true;
            this.MHApprovedDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.MHApprovedDate.Width = 47;
            // 
            // FinalizedBy
            // 
            this.FinalizedBy.DataPropertyName = "FinalizedBy";
            this.FinalizedBy.HeaderText = "FinalizedBy";
            this.FinalizedBy.Name = "FinalizedBy";
            this.FinalizedBy.ReadOnly = true;
            this.FinalizedBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.FinalizedBy.Width = 91;
            // 
            // FinalizedDate
            // 
            this.FinalizedDate.DataPropertyName = "FinalizedDate";
            this.FinalizedDate.HeaderText = "Date";
            this.FinalizedDate.Name = "FinalizedDate";
            this.FinalizedDate.ReadOnly = true;
            this.FinalizedDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.FinalizedDate.Width = 47;
            // 
            // PurchaseCommitee
            // 
            this.PurchaseCommitee.DataPropertyName = "PurchaseCommitee";
            this.PurchaseCommitee.HeaderText = "Project manager";
            this.PurchaseCommitee.Name = "PurchaseCommitee";
            this.PurchaseCommitee.ReadOnly = true;
            this.PurchaseCommitee.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PurchaseCommitee.Width = 128;
            // 
            // PCAuthoriseDate
            // 
            this.PCAuthoriseDate.DataPropertyName = "PCAuthoriseDate";
            this.PCAuthoriseDate.HeaderText = "Date";
            this.PCAuthoriseDate.Name = "PCAuthoriseDate";
            this.PCAuthoriseDate.ReadOnly = true;
            this.PCAuthoriseDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PCAuthoriseDate.Width = 47;
            // 
            // FinanceApproverName
            // 
            this.FinanceApproverName.DataPropertyName = "FinanceApproverName";
            this.FinanceApproverName.HeaderText = "Finance Approver";
            this.FinanceApproverName.Name = "FinanceApproverName";
            this.FinanceApproverName.ReadOnly = true;
            this.FinanceApproverName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.FinanceApproverName.Width = 136;
            // 
            // FinanceApprovedDate
            // 
            this.FinanceApprovedDate.DataPropertyName = "FinanceApprovedDate";
            this.FinanceApprovedDate.HeaderText = "Date";
            this.FinanceApprovedDate.Name = "FinanceApprovedDate";
            this.FinanceApprovedDate.ReadOnly = true;
            this.FinanceApprovedDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.FinanceApprovedDate.Width = 47;
            // 
            // POGeneratedBy
            // 
            this.POGeneratedBy.DataPropertyName = "POGeneratedBy";
            this.POGeneratedBy.HeaderText = "POGeneratedBy";
            this.POGeneratedBy.Name = "POGeneratedBy";
            this.POGeneratedBy.ReadOnly = true;
            this.POGeneratedBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.POGeneratedBy.Width = 124;
            // 
            // POGeneratedDate
            // 
            this.POGeneratedDate.DataPropertyName = "POGeneratedDate";
            this.POGeneratedDate.HeaderText = "Date";
            this.POGeneratedDate.Name = "POGeneratedDate";
            this.POGeneratedDate.ReadOnly = true;
            this.POGeneratedDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.POGeneratedDate.Width = 47;
            // 
            // POView
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1309, 684);
            this.Controls.Add(this.dgpolist);
            this.Controls.Add(this.gbSearchOptions);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "POView";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "View Purchase Order ";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.POView_FormClosing);
            this.Load += new System.EventHandler(this.POView_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgpolist)).EndInit();
            this.gbSearchOptions.ResumeLayout(false);
            this.gbSearchOptions.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnOADate.ResumeLayout(false);
            this.pnOADate.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgpolist;
        private System.Windows.Forms.GroupBox gbSearchOptions;
        private System.Windows.Forms.Label lblIteType;
        private System.Windows.Forms.TextBox txtProjectcode;
        private System.Windows.Forms.Label lblItemDescription;
        private System.Windows.Forms.TextBox txtDBOMNo;
        private System.Windows.Forms.Label lblItemCode;
        private System.Windows.Forms.TextBox txtAuthorisedBy;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPreparedBy;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPODelayDays;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnTotal;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnArrivinginaweek;
        private System.Windows.Forms.Button btnLate;
        private System.Windows.Forms.Button btnComingToday;
        private System.Windows.Forms.Button btnNewPO;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnArrivinglaterthanweek;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnExcelExceport;
        private System.Windows.Forms.Label lblFromdate;
        private System.Windows.Forms.Label lblToDate;
        private System.Windows.Forms.DateTimePicker dtpFromDate;
        private System.Windows.Forms.DateTimePicker dtpToDate;
        private System.Windows.Forms.Button btnrecentlist;
        private System.Windows.Forms.Button btnloadcompletePOlist;
        private System.Windows.Forms.Panel pnOADate;
        private System.Windows.Forms.Button btnUpdateOADate;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker dtpdelivery;
        private System.Windows.Forms.DateTimePicker dtpOADate;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridViewTextBoxColumn DBOMNO;
        private System.Windows.Forms.DataGridViewTextBoxColumn POLateBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn DeliveryDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn VendorName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn RequariedQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn RemainingQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn PreparedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn POPreparedDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn AuthorisedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn POAuthoriseDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn MHName;
        private System.Windows.Forms.DataGridViewTextBoxColumn MHApprovedDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn FinalizedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn FinalizedDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn PurchaseCommitee;
        private System.Windows.Forms.DataGridViewTextBoxColumn PCAuthoriseDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn FinanceApproverName;
        private System.Windows.Forms.DataGridViewTextBoxColumn FinanceApprovedDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn POGeneratedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn POGeneratedDate;
    }
}