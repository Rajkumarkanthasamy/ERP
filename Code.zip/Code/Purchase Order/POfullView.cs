﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Diagnostics;
using System.Text;

namespace Erp_Project_With_Buttons.Purchase_Order
{
    public partial class POfullView : Form
    {
        DataTable dtPolist = new DataTable();
        DataTable dtProjectList = new DataTable();
        DataAccessLayer DAL = new DataAccessLayer();
        DataView dvPOViewList = new DataView();
        BindingSource bsItemList = new BindingSource();
        DataView dvPOList = new DataView();
        Global GlobalClass = new Global();
        Login.frmLoginForm login = new Login.frmLoginForm();
        Purchase_Order.PurchaseOrder PurchaseOrderForm = new PurchaseOrder();

        public POfullView()
        {
            InitializeComponent();
        }

        private void POfullView_Load(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(login.GetUserDetails[16]) == true || Convert.ToBoolean(login.GetUserDetails[30]) == true || Convert.ToBoolean(login.GetUserDetails[29]) == true || Convert.ToBoolean(login.GetUserDetails[31]) == true || Convert.ToBoolean(login.GetUserDetails[32]) == true)    //  lblPrepareBy.Text.ToLower() == "hebbarrk")
            {
               
                dgpolist.Columns[24].Visible = true;
                
                btnExcelExceport.Visible = true; 
            }
            else
            {
                
                dgpolist.Columns[24].Visible = true;
                
                btnExcelExceport.Visible = true;
            }
        }

        BindingSource bsIteSearch = new BindingSource();
        DataTable dtClone = new DataTable();

        private void fnRowFilter(uint uSearchOption, string sRowFilter)    //filter the Item list depends upon the user inpts
        {
            // DataView dvPOViewList = new DataView(dtPolist);
            if (dtPolist.Rows.Count > 0)
            {

                switch (uSearchOption)
                {
                    case Global.uITEM_CODE_SEARCH:
                        {
                            bsIteSearch.Filter = string.Format("ProjectCode LIKE '%{0}%' or ProjectDescription LIKE '%{0}%' or DBOMNo LIKE '%{0}%'  or VendorCode LIKE '%{0}%' or VendorName LIKE '%{0}%' or PreparedBy LIKE '%{0}%' or ItemCode LIKE '%{0}%' or ItemDescription LIKE '%{0}%'", sRowFilter);
                            break;
                        }
                }

            }
        }

        private void POfullView_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            //   this.Hide();
            pleasewaitform pleaseWait = new pleasewaitform();
            // Display form modelessly
            pleaseWait.Show();
            //  ALlow main UI thread to properly display please wait form.
            Application.DoEvents();
            PurchaseOrder PurchaseOrder = new PurchaseOrder();
            PurchaseOrder.Show();
            pleaseWait.Hide();
        }

        private void txtDBOMNo_Enter(object sender, EventArgs e)
        {
        }

        private void txtDBOMNo_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtDBOMNo.Text.Length > 2)
            {
                fnRowFilter(0, txtDBOMNo.Text);
                dgpolist.DataSource = bsIteSearch;
            }
            else
            {
                bsIteSearch.RemoveFilter();
            }
        }



        private void btnrecentlist_Click(object sender, EventArgs e)
        {
            dtpFromDate.Format = DateTimePickerFormat.Custom;
            dtpFromDate.CustomFormat = "yyyy-MM-dd";
            dtpToDate.Format = DateTimePickerFormat.Custom;
            dtpToDate.CustomFormat = "yyyy-MM-dd";
            if (chkIncludePrice.CheckState == CheckState.Unchecked)
            {
                dtPolist = DAL.fnPOlistCompleteview(0, dtpFromDate.Text, dtpToDate.Text).Tables[0];
            }
            else
            {
                if (!string.IsNullOrEmpty(txtDBOMNo.Text) && txtDBOMNo.Text.Length==11)
                {
                    dtPolist = DAL.fnPOlistCompleteview(1, txtDBOMNo.Text, dtpToDate.Text).Tables[0];
                }
                else
                {
                    MessageBox.Show("Please enter correct PO number","Error",0,MessageBoxIcon.Error);
                }
            }
            dtpFromDate.Format = DateTimePickerFormat.Custom;
            dtpFromDate.CustomFormat = "dd-MM-yyyy";
            dtpToDate.Format = DateTimePickerFormat.Custom;
            dtpToDate.CustomFormat = "dd-MM-yyyy";


            dgpolist.AutoGenerateColumns = false;

            if (dtPolist != null && dtPolist.Rows.Count > 0)
            {
                //MessageBox.Show("Testing code condition is working...");
                StringBuilder sb = new StringBuilder();
                // Add column headers
                foreach (DataColumn col in dtPolist.Columns)
                {
                    sb.Append(col.ColumnName + "\t");
                }
                sb.AppendLine();
                // Add row data
                foreach (DataRow row in dtPolist.Rows)
                {
                    foreach (var item in row.ItemArray)
                    {
                        sb.Append(item?.ToString() + "\t");
                    }
                    sb.AppendLine();
                }

                //MessageBox.Show(sb.ToString(), "dtPolist Before");
            }
            else
            {
                MessageBox.Show("dtPolist is empty.");
            }

            dgpolist.DataSource = dtPolist;
            bsItemList.DataSource = dtPolist;

            dtClone = dtPolist.Copy();
            bsIteSearch.DataSource = dtClone;
            //   btnloadcompletePOlist.Enabled = true;
            //   btnrecentlist.Enabled = false;
        }

   
        DataTable dtProcurmentRequest = new DataTable();


        #region Excel Merge Function
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlMedium, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignCentre":
                    {
                        CELLS.VerticalAlignment = EXCEL.XlVAlign.xlVAlignCenter;
                        break;
                    }
                case "HAlignCentre":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                        break;
                    }
                case "Left":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignLeft;
                        break;
                    }
                case "Right":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                        break;
                    }
                case "Bold":
                    {
                        CELLS.Font.Bold = true;
                        break;
                    }
                case "GridLines":
                    {
                        CELLS.Borders.Color = System.Drawing.Color.Black;
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }

                default:
                    {
                        break;
                    }
            }

        }
        #endregion


        private void exportThedata(object sender, EventArgs e)
        {
           // MessageBox.Show("function is called");
            try
            {
                string path = Path.Combine(
                       Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                       $"POList--{DateTime.Now:yyyyMMdd_HHmmss}.xlsx"
                   );
                CsvExporter.DataTableToXlsx(dtPolist, path);

            }
            catch(Exception error)
            {
                MessageBox.Show($"Some error {error}");
            }
        }
        private void btnExcelExceport_Click(object sender, EventArgs e)
        {

            if (dtPolist != null && dtPolist.Rows.Count > 0)
            {
                //MessageBox.Show("Testing code condition is working...");
                StringBuilder sb = new StringBuilder();
                // Add column headers
                foreach (DataColumn col in dtPolist.Columns)
                {
                    sb.Append(col.ColumnName + "\t");
                }
                sb.AppendLine();
                // Add row data
                foreach (DataRow row in dtPolist.Rows)
                {
                    foreach (var item in row.ItemArray)
                    {
                        sb.Append(item?.ToString() + "\t");
                    }
                    sb.AppendLine();
                }

                // MessageBox.Show(sb.ToString(), "dtPolist");
            }
            else
            {
                MessageBox.Show("dtPolist is empty.");
            }



            int iRowIndex = 1;
            string ExcelFolderPath;
            string FileFullPath;
            EXCEL.Workbook NewWorkBook;
            EXCEL.Worksheet NewWorkSheet;
            EXCEL.Application ExcelApp;
            EXCEL.Range CELLS, cell1, cell2;
            object misValue;
            if (dtPolist.Rows.Count > 0)
            {
                ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\";
                FileFullPath = "PO Full List" + "--" + DateTime.Now.ToString("dd/MM/yyyy hh/mm/ss") + ".xls";
                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);
                ExcelApp = new EXCEL.Application();
                misValue = System.Reflection.Missing.Value;
                try
                {
                    if (ExcelApp == null)
                        MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                    NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                    NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                    if (NewWorkSheet == null)
                        MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                    else
                        NewWorkSheet.Name = "PO Full List";
                    // Select the Excel cells, in the range c1 to c7 in the worksheet for cell access check.
                    EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                    if (RANGE == null)
                        MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                    NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlWorkbookNormal, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                    CELLS = NewWorkSheet.Cells;

                    // dtIndentItems = DAL.fnIndentExcel(cmbIndentNo.Text, null).Tables[0];

                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);

                    NewWorkSheet.Cells[iRowIndex, 1] = "Po Full List";
                    iRowIndex++;
                    iRowIndex++;
                    iRowIndex++;
                    if (dtPolist.Rows.Count > 0)
                    {
                        object[,] rawData = new object[dtPolist.Rows.Count + 1, dtPolist.Columns.Count];
                        for (int col = 0; col < dtPolist.Columns.Count; col++)
                        {
                            rawData[0, col] = dtPolist.Columns[col].ColumnName;
                        }
                        for (int row = 0; row < dtPolist.Rows.Count; row++)
                        {
                            for (int col = 0; col < dtPolist.Columns.Count; col++)
                            {
                                rawData[row + 1, col] = dtPolist.Rows[row].ItemArray[col];
                            }
                        }
                        string excelRange = string.Empty;
                        string finalColLetter = string.Empty;
                        string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        int colCharsetLen = colCharset.Length;

                        if (dtPolist.Columns.Count > colCharsetLen)
                        {
                            finalColLetter = colCharset.Substring(
                                (dtPolist.Columns.Count - 1) / colCharsetLen - 1, 1);
                        }

                        finalColLetter += colCharset.Substring((dtPolist.Columns.Count - 1) % colCharsetLen, 1);
                        excelRange = string.Format("A6:{0}{1}", finalColLetter, dtPolist.Rows.Count + 6);


                        NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                    }


                    NewWorkSheet.Range["A1:AK6"].Cells.Font.Bold = true;
                    NewWorkSheet.Range["A1:AK6"].Cells.Font.Size = 16;



                    //NewWorkSheet.get_Range("A6:B999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    // NewWorkSheet.get_Range("A6", "B999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;

                    //  Microsoft.Office.Interop.Excel.Range Range = NewWorkSheet.get_Range("C6", "E399");
                    //  Range.EntireColumn.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;

                    NewWorkSheet.Rows.AutoFit();

                    NewWorkSheet.Columns.AutoFit();
                    NewWorkSheet.Rows.RowHeight = "18";


                    NewWorkSheet.PageSetup.PrintArea = "A1:Z" + (dtPolist.Rows.Count + iRowIndex + 6 )+ "";
                    NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                    NewWorkSheet.PageSetup.PrintNotes = true;
                    NewWorkSheet.PageSetup.Zoom = 100;
                    NewWorkSheet.PageSetup.FitToPagesTall = 1;
                    NewWorkSheet.PageSetup.FitToPagesWide = 1;
                    NewWorkSheet.PageSetup.LeftMargin = 0;
                    NewWorkSheet.PageSetup.RightMargin = 0;
                    NewWorkSheet.PageSetup.TopMargin = 0.75;
                    NewWorkSheet.PageSetup.BottomMargin = 0.75;
                    NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                    NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                    string _stLOGO = ("C:\\Databasepath\\Bisslogo.jpg");
                    EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 7];

                    Image oImage = Image.FromFile(_stLOGO);
                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);

                    System.Threading.Thread.Sleep(100);
                    NewWorkSheet.Paste(oRange);
                   // NewWorkSheet.Paste(oRange, _stLOGO);

                   // NewWorkBook.Save();
                    
                  //  System.Threading.Thread.Sleep(1000);

                    //NewWorkBook.SaveAs(outputPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                    //           Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive,
                    //           Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                    NewWorkBook.Save();
                    //NewWorkBook.Close(true, Type.Missing, Type.Missing);
                    ExcelApp.Visible = true;
                    //excelApp.Quit();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                    {
                        GetProcess.Kill();
                    }
                }
            }
            else
                MessageBox.Show("No items to save", "Error", 0, MessageBoxIcon.Question);
        }

        private void dgpolist_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (Convert.ToBoolean(login.GetUserDetails[16]) == true)
            {
                if (dgpolist.Rows.Count > 0)
                {
                    btnActivatePO.Visible = true;
                }
            }
        }

        private void btnActivatePO_Click(object sender, EventArgs e)
        {
            GlobalClass.iStatus = DAL.fnActivatePO(0, dgpolist.CurrentRow.Cells["DBOMNO"].Value.ToString(), login.GetUserDetails[2].ToString());

            MessageBox.Show("Selected PO is activated", "Success", 0, MessageBoxIcon.Information);
        }

        private void dgpolist_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtDBOMNo_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
