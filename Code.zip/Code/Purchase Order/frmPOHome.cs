﻿using System;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Purchase_Order
{
    public partial class frmPOHome : Form
    {
        public frmPOHome()
        {
            InitializeComponent();
        }
        Login.frmLoginForm Loginfrm = new Login.frmLoginForm();
        DataAccessLayer DAL = new DataAccessLayer();
        Global GlobalClass = new Global();
        frmForm2 frm = new frmForm2();
        private void btnPurchaseOrder_Click(object sender, EventArgs e)
        {
           
            Purchase_Order.PurchaseOrder frmPurchaseOrder = new Purchase_Order.PurchaseOrder();
            fnFormShow(frmPurchaseOrder);
        }
        #region Function to Show Please wait form & Switch to Selected From
        private void fnFormShow(Form Frm)
        {
            this.Hide();
            pleasewaitform pleaseWait = new pleasewaitform();
            pleaseWait.Show();
            Application.DoEvents();
            Frm.Show();
            pleaseWait.Hide();
        }
        #endregion
        private void frmPOHome_Load(object sender, EventArgs e)
        {
            if (Login.frmLoginForm.sUserDetails[11] != "True")
            {
                btnPurchaseOrder.Enabled = false;
            }
            else
            {
                btnPurchaseOrder.Enabled = true;
            }

            if (Login.frmLoginForm.sUserDetails[53] != "True")
            {
                btnPOTrack.Enabled = false;
                btnPOConfirm.Enabled = false;
            }
            else
            {
                btnPOTrack.Enabled = true;
                btnPOConfirm.Enabled = true;
            }
        }

        private void btnPOTrack_Click(object sender, EventArgs e)
        {
            Purchase_Order.frmPOTrack frmPOTrack = new Purchase_Order.frmPOTrack();
            fnFormShow(frmPOTrack);
        }

        private void frmPOHome_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            frm.Show();
        }

        private void btnPOConfirm_Click(object sender, EventArgs e)
        {
            Purchase_Order.frmVendorConfirm Vendor = new frmVendorConfirm();
            fnFormShow(Vendor);
        }

        private void btnVendorDelayList_Click(object sender, EventArgs e)
        {
            Purchase_Order.VendorDealyList vendorDealy = new VendorDealyList();
            fnFormShow(vendorDealy);
        }

        private void BOMPOTrack_Click(object sender, EventArgs e)
        {
            Purchase_Order.frmPOTrackBOM POBOM = new frmPOTrackBOM();
            fnFormShow(POBOM);
        }

        private void btncurrency_Click(object sender, EventArgs e)
        {
            CurrencyRate cr = new CurrencyRate();
            fnFormShow(cr);
        }
    }
}
