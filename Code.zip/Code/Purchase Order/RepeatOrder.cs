﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Purchase_Order
{
    public partial class RepeatOrder : Form
    {
        frmForm2 frm = new frmForm2();
        DataAccessLayer DAL = new DataAccessLayer();
        Global GLobalClass = new Global();
        Login.frmLoginForm login = new Login.frmLoginForm();
        DataView dvItemList = new DataView();
        DataTable dtItemList = new DataTable();
        DataTable dtTableFilter = new DataTable();
        DataTable dtItemcode = new DataTable();
        DataTable DTDBOM = new DataTable();
        public RepeatOrder()
        {
            InitializeComponent();
        }

        private void RepeatOrder_Load(object sender, EventArgs e)
        {
            chkItemCode.Checked = true;
            dtItemList = DAL.fnItemList(null).Tables[0];
            dtTableFilter = dtItemList;

            if (Convert.ToBoolean(login.GetUserDetails[16]) == true || Convert.ToBoolean(login.GetUserDetails[30]) == true || Convert.ToBoolean(login.GetUserDetails[29]) == true || Convert.ToBoolean(login.GetUserDetails[31]) == true || Convert.ToBoolean(login.GetUserDetails[32]) == true)    //  lblPrepareBy.Text.ToLower() == "hebbarrk")
            {
                dgvRepeaOrder.Columns[3].Visible = true;
                lblUnitCost.Visible = true;
                lblrepeatCost.Visible = true;
            }
            else
            {
                dgvRepeaOrder.Columns[3].Visible = false;
                lblUnitCost.Visible = false;
                lblrepeatCost.Visible = false;
            }
        }
        private void RepeatOrder_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
        }

        #region Rowfilter Funtion to select Item
        private void RowFilter()
        {
            chklbItemList.Items.Clear();
            foreach (DataRowView dv in dvItemList)
            {
                chklbItemList.Items.Add(string.Concat(dv[17].ToString(), ") ", dv[0].ToString(), ", ", dv[1].ToString(), ", ", dv[12].ToString()));
            }
        }
        #endregion


        private void txtItemDescription_Enter(object sender, EventArgs e)
        {
        }

        private void txtItemDescription_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar == '%'))
            {
                e.Handled = true;
            }
        }

        private void txtItemDescription_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);

                    RowFilter();

                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
                    RowFilter();
                }
            }
            else
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);
                    RowFilter();
                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
                    RowFilter();
                }
            }
        }

        private void txtItemCode_KeyUp(object sender, KeyEventArgs e)
        {
            
        }

        string[] sItemCode;
        private void chklbItemList_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            try
            {
                if (!chklbItemList.CheckedItems.Contains(chklbItemList.SelectedItem))
                {
                    sItemCode = chklbItemList.SelectedItem.ToString().Trim().Split(')');
                    string sID = sItemCode[0];
                    dtItemcode = DAL.fnStandardCostItemList(sID).Tables[0];
                    if (dtItemcode.Rows.Count > 0)
                    {
                        lblNoitems.Visible = false;
                        lblRepeatitemcode.Text = dtItemcode.Rows[0]["Itemcode"].ToString();
                        lblitemname.Text = dtItemcode.Rows[0]["ItemDescription"].ToString();
                        lblrepeatCost.Text = dtItemcode.Rows[0]["UnitCost"].ToString() + " Rs";
                        lblavailableqty.Text = dtItemcode.Rows[0]["AvailableQty"].ToString() + " " + dtItemcode.Rows[0]["Units"].ToString();
                        
                        DTDBOM = DAL.fnRepeatOrderlist(lblRepeatitemcode.Text).Tables[0];
                        if (DTDBOM.Rows.Count > 0)
                        {
                            
                            dgvRepeaOrder.AutoGenerateColumns = false;
                            dgvRepeaOrder.DataSource = DTDBOM;
                        }
                        else
                        {
                            lblNoitems.Visible = true;
                            dgvRepeaOrder.DataSource = null;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("PurchaseOrder_chklbItemList_ItemCheck" + ex.Message);
            }
        }

        private void chkItemCode_CheckedChanged(object sender, EventArgs e)
        {

            if (chkItemCode.CheckState == CheckState.Checked)
            {
                chkItemDesc.Checked = false;
            }
        }

        private void chkItemDesc_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemDesc.CheckState == CheckState.Checked)
            {
                chkItemCode.Checked = false;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

        }
    }
}
