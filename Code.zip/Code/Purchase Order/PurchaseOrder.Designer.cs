﻿using System.Drawing;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Purchase_Order
{
    partial class PurchaseOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PurchaseOrder));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle89 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle113 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle90 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle91 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle92 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle93 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle94 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle95 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle96 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle97 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle98 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle99 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle100 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle101 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle102 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle103 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle104 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle105 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle106 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle107 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle108 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle109 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle110 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle111 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle112 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle114 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle122 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle115 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle116 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle117 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle118 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle119 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle120 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle121 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle123 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle127 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle124 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle125 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle126 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle128 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle129 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle130 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle132 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle131 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblPre = new System.Windows.Forms.Label();
            this.btnprintpo = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnGenaratePO = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dtppreparedate = new System.Windows.Forms.DateTimePicker();
            this.btnrepeatorder = new System.Windows.Forms.Button();
            this.chkPrintPO = new System.Windows.Forms.CheckBox();
            this.btnloadpolist = new System.Windows.Forms.Button();
            this.lblProjectDescription = new System.Windows.Forms.Label();
            this.cmbVendorName = new System.Windows.Forms.ComboBox();
            this.lblVendorName = new System.Windows.Forms.Label();
            this.cmbPONO = new System.Windows.Forms.ComboBox();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.lblRemarks = new System.Windows.Forms.Label();
            this.lblProjectCode = new System.Windows.Forms.Label();
            this.lblDetaiedBOM = new System.Windows.Forms.Label();
            this.lblAuthorisedBy = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnCancelPO = new System.Windows.Forms.Button();
            this.btnClosePO = new System.Windows.Forms.Button();
            this.butAmend = new System.Windows.Forms.Button();
            this.btnRejectPO = new System.Windows.Forms.Button();
            this.btnAcceptPO = new System.Windows.Forms.Button();
            this.chklbItemList = new System.Windows.Forms.CheckedListBox();
            this.txtItemDescription = new System.Windows.Forms.TextBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.dgbomlist = new System.Windows.Forms.DataGridView();
            this.HSNSACCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UOM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AvaQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SixMonths = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TwelveMonths = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dBOMQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BOMbutton = new System.Windows.Forms.DataGridViewButtonColumn();
            this.BOMProjectCodes = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OtherProjects = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReqQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RemQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TargetCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Unitprice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StandardCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LatestPurchasePrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiffrenceinPer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiffrenceinRs = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiscRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiscAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnviewpolist = new System.Windows.Forms.Button();
            this.pnvendor = new System.Windows.Forms.Panel();
            this.ViewVendorList = new System.Windows.Forms.Button();
            this.btnSendReminder = new System.Windows.Forms.Button();
            this.txtvendorcode = new System.Windows.Forms.Label();
            this.PurchaseOrdervaliduptoDate = new System.Windows.Forms.DateTimePicker();
            this.POExpirationDate = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.curratetext = new System.Windows.Forms.TextBox();
            this.lblcurrency = new System.Windows.Forms.Label();
            this.cmbcurrency = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbbomname = new System.Windows.Forms.ComboBox();
            this.cmbProjectcode = new System.Windows.Forms.TextBox();
            this.dtpdelivery = new System.Windows.Forms.DateTimePicker();
            this.lbldeliverydate = new System.Windows.Forms.Label();
            this.cmbEmailAlert = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.cbViewRemarks = new System.Windows.Forms.CheckBox();
            this.lblProjectStatus = new System.Windows.Forms.Label();
            this.lblprojname = new System.Windows.Forms.Label();
            this.txtAuthorizedBy = new System.Windows.Forms.Label();
            this.lblPrepareBy = new System.Windows.Forms.Label();
            this.chkWithoutBOM = new System.Windows.Forms.CheckBox();
            this.btncopmletepoview = new System.Windows.Forms.Button();
            this.pnitemadd = new System.Windows.Forms.Panel();
            this.lstusers = new System.Windows.Forms.ListBox();
            this.chkItemDesc = new System.Windows.Forms.CheckBox();
            this.chkItemCode = new System.Windows.Forms.CheckBox();
            this.pnauthorise = new System.Windows.Forms.Panel();
            this.pnloadpo = new System.Windows.Forms.Panel();
            this.btnPackingAmount = new System.Windows.Forms.Button();
            this.cmbtransactiontype = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.pnPOReport = new System.Windows.Forms.Panel();
            this.txtIncoterm = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbIncoterm = new System.Windows.Forms.ComboBox();
            this.btnViewTax = new System.Windows.Forms.Button();
            this.btnAddTransport = new System.Windows.Forms.Button();
            this.txtShippedFrom1 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.cmbDeliverTerms = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.cmbPaymentTerms = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtShippedCountry = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtShippedGSTIn = new System.Windows.Forms.TextBox();
            this.txtShippedStateCode = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtShippedFrom = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtBalanceDue = new System.Windows.Forms.TextBox();
            this.txtAmountPaid = new System.Windows.Forms.TextBox();
            this.txtInvoiceTotal = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbNatureofSupply = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbNatureofTransaction = new System.Windows.Forms.ComboBox();
            this.dgPackingTaxes = new System.Windows.Forms.DataGridView();
            this.TaxDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxamount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxIGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxIGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxSGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxSGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxCGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxCGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnBOMQtyCheck = new System.Windows.Forms.Panel();
            this.dgvBOMQty = new System.Windows.Forms.DataGridView();
            this.ProjectCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.POQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BOMQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PreviousQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BOMReqQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label17 = new System.Windows.Forms.Label();
            this.lblBOMTotal = new System.Windows.Forms.Label();
            this.btnAddPOBOMQty = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbltotalIGST = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.lbltotalCGST = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.lbltotalSGST = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.lbltotaldiscount = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lblTotalAmount = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.pnRemarks = new System.Windows.Forms.Panel();
            this.llbViewPOGeneralTerms = new System.Windows.Forms.LinkLabel();
            this.llbViewRemakrs = new System.Windows.Forms.LinkLabel();
            this.btnLoadPCList = new System.Windows.Forms.Button();
            this.chkUpdatePO = new System.Windows.Forms.CheckBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.dgvRemarks = new System.Windows.Forms.DataGridView();
            this.RemarksBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RemarksDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Remarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvPOGeneralTerms = new System.Windows.Forms.DataGridView();
            this.POTerms = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnGeneralTerms = new System.Windows.Forms.Panel();
            this.cmbPOTerms = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnAddNewRow = new System.Windows.Forms.Button();
            this.AmeandPO = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgbomlist)).BeginInit();
            this.pnvendor.SuspendLayout();
            this.panel2.SuspendLayout();
            this.pnitemadd.SuspendLayout();
            this.pnauthorise.SuspendLayout();
            this.pnloadpo.SuspendLayout();
            this.pnPOReport.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgPackingTaxes)).BeginInit();
            this.pnBOMQtyCheck.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBOMQty)).BeginInit();
            this.panel1.SuspendLayout();
            this.pnRemarks.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRemarks)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPOGeneralTerms)).BeginInit();
            this.pnGeneralTerms.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblPre
            // 
            this.lblPre.AutoSize = true;
            this.lblPre.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPre.ForeColor = System.Drawing.Color.Black;
            this.lblPre.Location = new System.Drawing.Point(370, 45);
            this.lblPre.Name = "lblPre";
            this.lblPre.Size = new System.Drawing.Size(81, 15);
            this.lblPre.TabIndex = 0;
            this.lblPre.Text = "Prepared By :";
            // 
            // btnprintpo
            // 
            this.btnprintpo.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnprintpo.Enabled = false;
            this.btnprintpo.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnprintpo.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnprintpo.Location = new System.Drawing.Point(401, 10);
            this.btnprintpo.Name = "btnprintpo";
            this.btnprintpo.Size = new System.Drawing.Size(76, 30);
            this.btnprintpo.TabIndex = 12;
            this.btnprintpo.Text = "Print PO";
            this.btnprintpo.UseVisualStyleBackColor = false;
            this.btnprintpo.Click += new System.EventHandler(this.btnprintpo_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.Enabled = false;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(203, 10);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(73, 30);
            this.btnSave.TabIndex = 11;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(869, 10);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(90, 30);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnGenaratePO
            // 
            this.btnGenaratePO.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnGenaratePO.Enabled = false;
            this.btnGenaratePO.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnGenaratePO.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenaratePO.Location = new System.Drawing.Point(282, 8);
            this.btnGenaratePO.Name = "btnGenaratePO";
            this.btnGenaratePO.Size = new System.Drawing.Size(113, 30);
            this.btnGenaratePO.TabIndex = 96;
            this.btnGenaratePO.Text = "Generate PO";
            this.btnGenaratePO.UseVisualStyleBackColor = false;
            this.btnGenaratePO.Click += new System.EventHandler(this.btnGenaratePO_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(8, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 19);
            this.label1.TabIndex = 105;
            this.label1.Text = "Search Item by";
            // 
            // dtppreparedate
            // 
            this.dtppreparedate.Enabled = false;
            this.dtppreparedate.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtppreparedate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtppreparedate.Location = new System.Drawing.Point(744, 97);
            this.dtppreparedate.Name = "dtppreparedate";
            this.dtppreparedate.Size = new System.Drawing.Size(85, 23);
            this.dtppreparedate.TabIndex = 109;
            this.dtppreparedate.ValueChanged += new System.EventHandler(this.dtppreparedate_ValueChanged);
            // 
            // btnrepeatorder
            // 
            this.btnrepeatorder.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnrepeatorder.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnrepeatorder.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrepeatorder.ForeColor = System.Drawing.Color.Black;
            this.btnrepeatorder.Location = new System.Drawing.Point(189, 595);
            this.btnrepeatorder.Name = "btnrepeatorder";
            this.btnrepeatorder.Size = new System.Drawing.Size(138, 34);
            this.btnrepeatorder.TabIndex = 116;
            this.btnrepeatorder.Text = "Repeat Order";
            this.btnrepeatorder.UseVisualStyleBackColor = false;
            this.btnrepeatorder.Click += new System.EventHandler(this.btnrepeatorder_Click);
            // 
            // chkPrintPO
            // 
            this.chkPrintPO.AutoSize = true;
            this.chkPrintPO.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPrintPO.ForeColor = System.Drawing.Color.Red;
            this.chkPrintPO.Location = new System.Drawing.Point(1064, 4);
            this.chkPrintPO.Name = "chkPrintPO";
            this.chkPrintPO.Size = new System.Drawing.Size(62, 23);
            this.chkPrintPO.TabIndex = 123;
            this.chkPrintPO.Text = "Print";
            this.chkPrintPO.UseVisualStyleBackColor = true;
            this.chkPrintPO.CheckedChanged += new System.EventHandler(this.chkPrintPO_CheckedChanged);
            // 
            // btnloadpolist
            // 
            this.btnloadpolist.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnloadpolist.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnloadpolist.Location = new System.Drawing.Point(4, 1);
            this.btnloadpolist.Name = "btnloadpolist";
            this.btnloadpolist.Size = new System.Drawing.Size(103, 29);
            this.btnloadpolist.TabIndex = 113;
            this.btnloadpolist.Text = "Load PO List";
            this.btnloadpolist.UseVisualStyleBackColor = false;
            this.btnloadpolist.Click += new System.EventHandler(this.btnloadpolist_Click);
            // 
            // lblProjectDescription
            // 
            this.lblProjectDescription.AutoSize = true;
            this.lblProjectDescription.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectDescription.ForeColor = System.Drawing.Color.Black;
            this.lblProjectDescription.Location = new System.Drawing.Point(360, 7);
            this.lblProjectDescription.Name = "lblProjectDescription";
            this.lblProjectDescription.Size = new System.Drawing.Size(47, 15);
            this.lblProjectDescription.TabIndex = 18;
            this.lblProjectDescription.Text = "Name :";
            // 
            // cmbVendorName
            // 
            this.cmbVendorName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbVendorName.DropDownHeight = 130;
            this.cmbVendorName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbVendorName.FormattingEnabled = true;
            this.cmbVendorName.IntegralHeight = false;
            this.cmbVendorName.Location = new System.Drawing.Point(85, 34);
            this.cmbVendorName.Name = "cmbVendorName";
            this.cmbVendorName.Size = new System.Drawing.Size(273, 26);
            this.cmbVendorName.TabIndex = 17;
            this.cmbVendorName.SelectedIndexChanged += new System.EventHandler(this.cmbVendorName_SelectedIndexChanged);
            // 
            // lblVendorName
            // 
            this.lblVendorName.AutoSize = true;
            this.lblVendorName.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVendorName.ForeColor = System.Drawing.Color.Black;
            this.lblVendorName.Location = new System.Drawing.Point(31, 39);
            this.lblVendorName.Name = "lblVendorName";
            this.lblVendorName.Size = new System.Drawing.Size(54, 15);
            this.lblVendorName.TabIndex = 16;
            this.lblVendorName.Text = "Vendor :";
            // 
            // cmbPONO
            // 
            this.cmbPONO.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbPONO.DropDownHeight = 100;
            this.cmbPONO.DropDownWidth = 200;
            this.cmbPONO.Enabled = false;
            this.cmbPONO.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPONO.FormattingEnabled = true;
            this.cmbPONO.IntegralHeight = false;
            this.cmbPONO.ItemHeight = 16;
            this.cmbPONO.Location = new System.Drawing.Point(87, 5);
            this.cmbPONO.Name = "cmbPONO";
            this.cmbPONO.Size = new System.Drawing.Size(215, 24);
            this.cmbPONO.TabIndex = 15;
            this.cmbPONO.SelectedIndexChanged += new System.EventHandler(this.cmbDetailedBOMno_SelectedIndexChanged);
            // 
            // txtRemarks
            // 
            this.txtRemarks.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemarks.Location = new System.Drawing.Point(99, 11);
            this.txtRemarks.Multiline = true;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRemarks.Size = new System.Drawing.Size(385, 66);
            this.txtRemarks.TabIndex = 14;
            // 
            // lblRemarks
            // 
            this.lblRemarks.AutoSize = true;
            this.lblRemarks.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRemarks.ForeColor = System.Drawing.Color.Black;
            this.lblRemarks.Location = new System.Drawing.Point(5, 18);
            this.lblRemarks.Name = "lblRemarks";
            this.lblRemarks.Size = new System.Drawing.Size(95, 19);
            this.lblRemarks.TabIndex = 13;
            this.lblRemarks.Text = "PO Remarks:";
            // 
            // lblProjectCode
            // 
            this.lblProjectCode.AutoSize = true;
            this.lblProjectCode.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectCode.ForeColor = System.Drawing.Color.Black;
            this.lblProjectCode.Location = new System.Drawing.Point(5, 7);
            this.lblProjectCode.Name = "lblProjectCode";
            this.lblProjectCode.Size = new System.Drawing.Size(81, 15);
            this.lblProjectCode.TabIndex = 9;
            this.lblProjectCode.Text = "Project Code:";
            // 
            // lblDetaiedBOM
            // 
            this.lblDetaiedBOM.AutoSize = true;
            this.lblDetaiedBOM.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblDetaiedBOM.ForeColor = System.Drawing.Color.Black;
            this.lblDetaiedBOM.Location = new System.Drawing.Point(22, 7);
            this.lblDetaiedBOM.Name = "lblDetaiedBOM";
            this.lblDetaiedBOM.Size = new System.Drawing.Size(57, 19);
            this.lblDetaiedBOM.TabIndex = 5;
            this.lblDetaiedBOM.Text = "PO No:";
            // 
            // lblAuthorisedBy
            // 
            this.lblAuthorisedBy.AutoSize = true;
            this.lblAuthorisedBy.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAuthorisedBy.ForeColor = System.Drawing.Color.Black;
            this.lblAuthorisedBy.Location = new System.Drawing.Point(370, 68);
            this.lblAuthorisedBy.Name = "lblAuthorisedBy";
            this.lblAuthorisedBy.Size = new System.Drawing.Size(84, 15);
            this.lblAuthorisedBy.TabIndex = 2;
            this.lblAuthorisedBy.Text = "Approved By :";
            this.lblAuthorisedBy.Click += new System.EventHandler(this.lblAuthorisedBy_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.btnCancelPO);
            this.groupBox2.Controls.Add(this.btnClosePO);
            this.groupBox2.Controls.Add(this.butAmend);
            this.groupBox2.Controls.Add(this.btnRejectPO);
            this.groupBox2.Controls.Add(this.btnAcceptPO);
            this.groupBox2.Controls.Add(this.btnGenaratePO);
            this.groupBox2.Controls.Add(this.btnprintpo);
            this.groupBox2.Controls.Add(this.btnSave);
            this.groupBox2.Controls.Add(this.btnExit);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox2.Location = new System.Drawing.Point(326, 589);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(971, 43);
            this.groupBox2.TabIndex = 99;
            this.groupBox2.TabStop = false;
            // 
            // btnCancelPO
            // 
            this.btnCancelPO.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnCancelPO.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCancelPO.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelPO.Location = new System.Drawing.Point(567, 10);
            this.btnCancelPO.Name = "btnCancelPO";
            this.btnCancelPO.Size = new System.Drawing.Size(90, 30);
            this.btnCancelPO.TabIndex = 169;
            this.btnCancelPO.Text = "CancelPO";
            this.btnCancelPO.UseVisualStyleBackColor = false;
            this.btnCancelPO.Click += new System.EventHandler(this.btnCancelPO_Click);
            // 
            // btnClosePO
            // 
            this.btnClosePO.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnClosePO.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnClosePO.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClosePO.Location = new System.Drawing.Point(483, 10);
            this.btnClosePO.Name = "btnClosePO";
            this.btnClosePO.Size = new System.Drawing.Size(78, 30);
            this.btnClosePO.TabIndex = 169;
            this.btnClosePO.Text = "ClosePO";
            this.btnClosePO.UseVisualStyleBackColor = false;
            this.btnClosePO.Click += new System.EventHandler(this.btnClosePO_Click);
            // 
            // butAmend
            // 
            this.butAmend.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.butAmend.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.butAmend.Enabled = false;
            this.butAmend.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.butAmend.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butAmend.Location = new System.Drawing.Point(663, 10);
            this.butAmend.Name = "butAmend";
            this.butAmend.Size = new System.Drawing.Size(90, 30);
            this.butAmend.TabIndex = 169;
            this.butAmend.Text = "Amend";
            this.butAmend.UseVisualStyleBackColor = false;
            this.butAmend.Visible = false;
            this.butAmend.Click += new System.EventHandler(this.butAmend_Click);
            // 
            // btnRejectPO
            // 
            this.btnRejectPO.BackColor = System.Drawing.Color.Red;
            this.btnRejectPO.Enabled = false;
            this.btnRejectPO.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnRejectPO.ForeColor = System.Drawing.SystemColors.Window;
            this.btnRejectPO.Location = new System.Drawing.Point(99, 10);
            this.btnRejectPO.Name = "btnRejectPO";
            this.btnRejectPO.Size = new System.Drawing.Size(98, 30);
            this.btnRejectPO.TabIndex = 168;
            this.btnRejectPO.Text = "Return";
            this.btnRejectPO.UseVisualStyleBackColor = false;
            this.btnRejectPO.Click += new System.EventHandler(this.btnRejectPO_Click);
            // 
            // btnAcceptPO
            // 
            this.btnAcceptPO.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnAcceptPO.Enabled = false;
            this.btnAcceptPO.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnAcceptPO.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnAcceptPO.Location = new System.Drawing.Point(0, 10);
            this.btnAcceptPO.Name = "btnAcceptPO";
            this.btnAcceptPO.Size = new System.Drawing.Size(98, 30);
            this.btnAcceptPO.TabIndex = 167;
            this.btnAcceptPO.Text = "Approve";
            this.btnAcceptPO.UseVisualStyleBackColor = false;
            this.btnAcceptPO.Click += new System.EventHandler(this.btnAcceptPO_Click);
            // 
            // chklbItemList
            // 
            this.chklbItemList.CheckOnClick = true;
            this.chklbItemList.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chklbItemList.FormattingEnabled = true;
            this.chklbItemList.HorizontalScrollbar = true;
            this.chklbItemList.Location = new System.Drawing.Point(3, 56);
            this.chklbItemList.Name = "chklbItemList";
            this.chklbItemList.Size = new System.Drawing.Size(439, 88);
            this.chklbItemList.TabIndex = 101;
            this.chklbItemList.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.chklbItemList_ItemCheck);
            this.chklbItemList.SelectedIndexChanged += new System.EventHandler(this.chklbItemList_SelectedIndexChanged);
            // 
            // txtItemDescription
            // 
            this.txtItemDescription.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemDescription.Location = new System.Drawing.Point(3, 27);
            this.txtItemDescription.Multiline = true;
            this.txtItemDescription.Name = "txtItemDescription";
            this.txtItemDescription.Size = new System.Drawing.Size(439, 25);
            this.txtItemDescription.TabIndex = 100;
            this.txtItemDescription.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtItemDescription_MouseClick);
            this.txtItemDescription.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtItemDescription_KeyPress);
            this.txtItemDescription.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemDescription_KeyUp);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "folderopened_yellow.ico");
            this.imageList1.Images.SetKeyName(1, "diagram_v2_17.ico");
            // 
            // dgbomlist
            // 
            this.dgbomlist.AllowUserToAddRows = false;
            this.dgbomlist.AllowUserToDeleteRows = false;
            this.dgbomlist.AllowUserToOrderColumns = true;
            this.dgbomlist.AllowUserToResizeRows = false;
            this.dgbomlist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgbomlist.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle89.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle89.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle89.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle89.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle89.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle89.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle89.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgbomlist.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle89;
            this.dgbomlist.ColumnHeadersHeight = 30;
            this.dgbomlist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgbomlist.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.HSNSACCode,
            this.ItemCode,
            this.ItemDescription,
            this.UOM,
            this.AvaQty,
            this.SixMonths,
            this.TwelveMonths,
            this.dBOMQty,
            this.BOMbutton,
            this.BOMProjectCodes,
            this.OtherProjects,
            this.ReqQty,
            this.RemQty,
            this.TargetCost,
            this.Unitprice,
            this.StandardCost,
            this.LatestPurchasePrice,
            this.DiffrenceinPer,
            this.DiffrenceinRs,
            this.Amount,
            this.DiscRate,
            this.DiscAmount,
            this.SGSTRate,
            this.SGSTAmount,
            this.CGSTRate,
            this.CGSTAmount,
            this.IGSTRate,
            this.IGSTAmount});
            this.dgbomlist.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle113.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle113.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle113.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle113.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle113.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle113.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle113.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgbomlist.DefaultCellStyle = dataGridViewCellStyle113;
            this.dgbomlist.EnableHeadersVisualStyles = false;
            this.dgbomlist.Location = new System.Drawing.Point(2, 178);
            this.dgbomlist.MultiSelect = false;
            this.dgbomlist.Name = "dgbomlist";
            this.dgbomlist.RowHeadersVisible = false;
            this.dgbomlist.RowHeadersWidth = 62;
            this.dgbomlist.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dgbomlist.Size = new System.Drawing.Size(1299, 255);
            this.dgbomlist.TabIndex = 108;
            this.dgbomlist.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgbomlist_CellBeginEdit);
            this.dgbomlist.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgbomlist_CellClick);
            this.dgbomlist.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgbomlist_CellEndEdit_1);
            this.dgbomlist.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgbomlist_EditingControlShowing);
            this.dgbomlist.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.dgbomlist_RowsAdded);
            this.dgbomlist.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.dgbomlist_RowsRemoved);
            this.dgbomlist.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgbomlist_KeyUp);
            // 
            // HSNSACCode
            // 
            this.HSNSACCode.DataPropertyName = "HSNSACCode";
            this.HSNSACCode.Frozen = true;
            this.HSNSACCode.HeaderText = "HSN/SAC";
            this.HSNSACCode.MinimumWidth = 8;
            this.HSNSACCode.Name = "HSNSACCode";
            this.HSNSACCode.ReadOnly = true;
            this.HSNSACCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.HSNSACCode.Width = 70;
            // 
            // ItemCode
            // 
            this.ItemCode.DataPropertyName = "ItemCode";
            this.ItemCode.Frozen = true;
            this.ItemCode.HeaderText = "Item Code";
            this.ItemCode.MinimumWidth = 8;
            this.ItemCode.Name = "ItemCode";
            this.ItemCode.ReadOnly = true;
            this.ItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemCode.Width = 78;
            // 
            // ItemDescription
            // 
            this.ItemDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ItemDescription.DataPropertyName = "ItemDescription";
            this.ItemDescription.Frozen = true;
            this.ItemDescription.HeaderText = "Item Description";
            this.ItemDescription.MinimumWidth = 8;
            this.ItemDescription.Name = "ItemDescription";
            this.ItemDescription.ReadOnly = true;
            this.ItemDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemDescription.Width = 127;
            // 
            // UOM
            // 
            this.UOM.DataPropertyName = "Units";
            dataGridViewCellStyle90.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.UOM.DefaultCellStyle = dataGridViewCellStyle90;
            this.UOM.HeaderText = "UOM";
            this.UOM.MinimumWidth = 8;
            this.UOM.Name = "UOM";
            this.UOM.ReadOnly = true;
            this.UOM.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UOM.Width = 47;
            // 
            // AvaQty
            // 
            this.AvaQty.DataPropertyName = "AvailableQty";
            dataGridViewCellStyle91.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.AvaQty.DefaultCellStyle = dataGridViewCellStyle91;
            this.AvaQty.HeaderText = "Avl Qty";
            this.AvaQty.MinimumWidth = 2;
            this.AvaQty.Name = "AvaQty";
            this.AvaQty.ReadOnly = true;
            this.AvaQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.AvaQty.Width = 59;
            // 
            // SixMonths
            // 
            this.SixMonths.DataPropertyName = "SixMonths";
            dataGridViewCellStyle92.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.SixMonths.DefaultCellStyle = dataGridViewCellStyle92;
            this.SixMonths.HeaderText = "6 Months";
            this.SixMonths.MinimumWidth = 8;
            this.SixMonths.Name = "SixMonths";
            this.SixMonths.ReadOnly = true;
            this.SixMonths.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SixMonths.Width = 72;
            // 
            // TwelveMonths
            // 
            this.TwelveMonths.DataPropertyName = "TwelveMonths";
            dataGridViewCellStyle93.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.TwelveMonths.DefaultCellStyle = dataGridViewCellStyle93;
            this.TwelveMonths.HeaderText = "12 Months";
            this.TwelveMonths.MinimumWidth = 8;
            this.TwelveMonths.Name = "TwelveMonths";
            this.TwelveMonths.ReadOnly = true;
            this.TwelveMonths.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.TwelveMonths.Width = 79;
            // 
            // dBOMQty
            // 
            this.dBOMQty.DataPropertyName = "BOMQty";
            dataGridViewCellStyle94.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dBOMQty.DefaultCellStyle = dataGridViewCellStyle94;
            this.dBOMQty.HeaderText = "BOM Qty";
            this.dBOMQty.MinimumWidth = 8;
            this.dBOMQty.Name = "dBOMQty";
            this.dBOMQty.ReadOnly = true;
            this.dBOMQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dBOMQty.Width = 70;
            // 
            // BOMbutton
            // 
            this.BOMbutton.HeaderText = "View BOM";
            this.BOMbutton.MinimumWidth = 8;
            this.BOMbutton.Name = "BOMbutton";
            this.BOMbutton.Width = 80;
            // 
            // BOMProjectCodes
            // 
            this.BOMProjectCodes.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.BOMProjectCodes.DataPropertyName = "BOMProjectList";
            dataGridViewCellStyle95.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle95.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.BOMProjectCodes.DefaultCellStyle = dataGridViewCellStyle95;
            this.BOMProjectCodes.HeaderText = "BOM Project Codes";
            this.BOMProjectCodes.MinimumWidth = 8;
            this.BOMProjectCodes.Name = "BOMProjectCodes";
            this.BOMProjectCodes.ReadOnly = true;
            this.BOMProjectCodes.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.BOMProjectCodes.Width = 133;
            // 
            // OtherProjects
            // 
            this.OtherProjects.DataPropertyName = "OtherProjects";
            dataGridViewCellStyle96.BackColor = System.Drawing.Color.LightGreen;
            this.OtherProjects.DefaultCellStyle = dataGridViewCellStyle96;
            this.OtherProjects.HeaderText = "Other Projects";
            this.OtherProjects.MinimumWidth = 8;
            this.OtherProjects.Name = "OtherProjects";
            this.OtherProjects.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OtherProjects.Width = 103;
            // 
            // ReqQty
            // 
            this.ReqQty.DataPropertyName = "ReqQty";
            dataGridViewCellStyle97.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle97.BackColor = System.Drawing.Color.LightGreen;
            this.ReqQty.DefaultCellStyle = dataGridViewCellStyle97;
            this.ReqQty.HeaderText = "Req Qty";
            this.ReqQty.MinimumWidth = 8;
            this.ReqQty.Name = "ReqQty";
            this.ReqQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ReqQty.Width = 63;
            // 
            // RemQty
            // 
            this.RemQty.DataPropertyName = "RemainingQty";
            dataGridViewCellStyle98.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.RemQty.DefaultCellStyle = dataGridViewCellStyle98;
            this.RemQty.HeaderText = "Rem Qty";
            this.RemQty.MinimumWidth = 8;
            this.RemQty.Name = "RemQty";
            this.RemQty.ReadOnly = true;
            this.RemQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RemQty.Width = 67;
            // 
            // TargetCost
            // 
            this.TargetCost.DataPropertyName = "TargetCost";
            this.TargetCost.HeaderText = "Target Cost";
            this.TargetCost.MinimumWidth = 8;
            this.TargetCost.Name = "TargetCost";
            this.TargetCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.TargetCost.Width = 82;
            // 
            // Unitprice
            // 
            this.Unitprice.DataPropertyName = "UnitCost";
            dataGridViewCellStyle99.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle99.BackColor = System.Drawing.Color.LightGreen;
            dataGridViewCellStyle99.Format = "N2";
            dataGridViewCellStyle99.NullValue = null;
            this.Unitprice.DefaultCellStyle = dataGridViewCellStyle99;
            this.Unitprice.HeaderText = "Unit Price";
            this.Unitprice.MinimumWidth = 8;
            this.Unitprice.Name = "Unitprice";
            this.Unitprice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Unitprice.Width = 75;
            // 
            // StandardCost
            // 
            this.StandardCost.DataPropertyName = "StandardCost";
            dataGridViewCellStyle100.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle100.Format = "N2";
            this.StandardCost.DefaultCellStyle = dataGridViewCellStyle100;
            this.StandardCost.HeaderText = "Standard Cost";
            this.StandardCost.MinimumWidth = 8;
            this.StandardCost.Name = "StandardCost";
            this.StandardCost.ReadOnly = true;
            this.StandardCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.StandardCost.Width = 99;
            // 
            // LatestPurchasePrice
            // 
            this.LatestPurchasePrice.DataPropertyName = "LatestPurchasePrice";
            dataGridViewCellStyle101.Format = "N2";
            this.LatestPurchasePrice.DefaultCellStyle = dataGridViewCellStyle101;
            this.LatestPurchasePrice.HeaderText = "Last Purchase Price";
            this.LatestPurchasePrice.MinimumWidth = 8;
            this.LatestPurchasePrice.Name = "LatestPurchasePrice";
            this.LatestPurchasePrice.ReadOnly = true;
            this.LatestPurchasePrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.LatestPurchasePrice.Width = 131;
            // 
            // DiffrenceinPer
            // 
            this.DiffrenceinPer.DataPropertyName = "DiffrenceinPer";
            dataGridViewCellStyle102.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle102.Format = "N0";
            dataGridViewCellStyle102.NullValue = null;
            this.DiffrenceinPer.DefaultCellStyle = dataGridViewCellStyle102;
            this.DiffrenceinPer.HeaderText = "Difference (%)";
            this.DiffrenceinPer.MinimumWidth = 8;
            this.DiffrenceinPer.Name = "DiffrenceinPer";
            this.DiffrenceinPer.ReadOnly = true;
            this.DiffrenceinPer.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DiffrenceinPer.Width = 103;
            // 
            // DiffrenceinRs
            // 
            this.DiffrenceinRs.DataPropertyName = "DiffrenceinRs";
            dataGridViewCellStyle103.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle103.Format = "N2";
            this.DiffrenceinRs.DefaultCellStyle = dataGridViewCellStyle103;
            this.DiffrenceinRs.HeaderText = "Diffrence (Rs)";
            this.DiffrenceinRs.MinimumWidth = 8;
            this.DiffrenceinRs.Name = "DiffrenceinRs";
            this.DiffrenceinRs.ReadOnly = true;
            this.DiffrenceinRs.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DiffrenceinRs.Width = 98;
            // 
            // Amount
            // 
            this.Amount.DataPropertyName = "Amount";
            dataGridViewCellStyle104.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle104.Format = "N2";
            dataGridViewCellStyle104.NullValue = null;
            this.Amount.DefaultCellStyle = dataGridViewCellStyle104;
            this.Amount.HeaderText = "Amount";
            this.Amount.MinimumWidth = 8;
            this.Amount.Name = "Amount";
            this.Amount.ReadOnly = true;
            this.Amount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Amount.Width = 64;
            // 
            // DiscRate
            // 
            this.DiscRate.DataPropertyName = "DiscRate";
            dataGridViewCellStyle105.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle105.BackColor = System.Drawing.Color.LightGreen;
            dataGridViewCellStyle105.NullValue = "0";
            this.DiscRate.DefaultCellStyle = dataGridViewCellStyle105;
            this.DiscRate.HeaderText = "Disc %";
            this.DiscRate.MinimumWidth = 8;
            this.DiscRate.Name = "DiscRate";
            this.DiscRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DiscRate.Width = 53;
            // 
            // DiscAmount
            // 
            this.DiscAmount.DataPropertyName = "DiscAmount";
            dataGridViewCellStyle106.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle106.Format = "N2";
            dataGridViewCellStyle106.NullValue = "0";
            this.DiscAmount.DefaultCellStyle = dataGridViewCellStyle106;
            this.DiscAmount.HeaderText = "Disc Amt";
            this.DiscAmount.MinimumWidth = 8;
            this.DiscAmount.Name = "DiscAmount";
            this.DiscAmount.ReadOnly = true;
            this.DiscAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DiscAmount.Width = 68;
            // 
            // SGSTRate
            // 
            this.SGSTRate.DataPropertyName = "SGSTRate";
            dataGridViewCellStyle107.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle107.BackColor = System.Drawing.Color.LightGreen;
            dataGridViewCellStyle107.NullValue = "0";
            this.SGSTRate.DefaultCellStyle = dataGridViewCellStyle107;
            this.SGSTRate.HeaderText = "SGST %";
            this.SGSTRate.MinimumWidth = 8;
            this.SGSTRate.Name = "SGSTRate";
            this.SGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SGSTRate.Width = 59;
            // 
            // SGSTAmount
            // 
            this.SGSTAmount.DataPropertyName = "SGSTAmount";
            dataGridViewCellStyle108.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle108.Format = "N2";
            dataGridViewCellStyle108.NullValue = "0";
            this.SGSTAmount.DefaultCellStyle = dataGridViewCellStyle108;
            this.SGSTAmount.HeaderText = "SGST Amt";
            this.SGSTAmount.MinimumWidth = 8;
            this.SGSTAmount.Name = "SGSTAmount";
            this.SGSTAmount.ReadOnly = true;
            this.SGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SGSTAmount.Width = 74;
            // 
            // CGSTRate
            // 
            this.CGSTRate.DataPropertyName = "CGSTRate";
            dataGridViewCellStyle109.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle109.BackColor = System.Drawing.Color.LightGreen;
            dataGridViewCellStyle109.NullValue = "0";
            this.CGSTRate.DefaultCellStyle = dataGridViewCellStyle109;
            this.CGSTRate.HeaderText = "CGST %";
            this.CGSTRate.MinimumWidth = 8;
            this.CGSTRate.Name = "CGSTRate";
            this.CGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CGSTRate.Width = 60;
            // 
            // CGSTAmount
            // 
            this.CGSTAmount.DataPropertyName = "CGSTAmount";
            dataGridViewCellStyle110.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle110.Format = "N2";
            dataGridViewCellStyle110.NullValue = "0";
            this.CGSTAmount.DefaultCellStyle = dataGridViewCellStyle110;
            this.CGSTAmount.HeaderText = "CGST Amt";
            this.CGSTAmount.MinimumWidth = 8;
            this.CGSTAmount.Name = "CGSTAmount";
            this.CGSTAmount.ReadOnly = true;
            this.CGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CGSTAmount.Width = 75;
            // 
            // IGSTRate
            // 
            this.IGSTRate.DataPropertyName = "IGSTRate";
            dataGridViewCellStyle111.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle111.BackColor = System.Drawing.Color.LightGreen;
            dataGridViewCellStyle111.NullValue = "0";
            this.IGSTRate.DefaultCellStyle = dataGridViewCellStyle111;
            this.IGSTRate.HeaderText = "IGST %";
            this.IGSTRate.MinimumWidth = 8;
            this.IGSTRate.Name = "IGSTRate";
            this.IGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IGSTRate.Width = 56;
            // 
            // IGSTAmount
            // 
            this.IGSTAmount.DataPropertyName = "IGSTAmount";
            dataGridViewCellStyle112.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle112.Format = "N2";
            dataGridViewCellStyle112.NullValue = "0";
            this.IGSTAmount.DefaultCellStyle = dataGridViewCellStyle112;
            this.IGSTAmount.HeaderText = "IGST Amt";
            this.IGSTAmount.MinimumWidth = 8;
            this.IGSTAmount.Name = "IGSTAmount";
            this.IGSTAmount.ReadOnly = true;
            this.IGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IGSTAmount.Width = 71;
            // 
            // btnviewpolist
            // 
            this.btnviewpolist.BackColor = System.Drawing.Color.Chocolate;
            this.btnviewpolist.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnviewpolist.Location = new System.Drawing.Point(96, 595);
            this.btnviewpolist.Name = "btnviewpolist";
            this.btnviewpolist.Size = new System.Drawing.Size(91, 34);
            this.btnviewpolist.TabIndex = 115;
            this.btnviewpolist.Text = "Edit PO";
            this.btnviewpolist.UseVisualStyleBackColor = false;
            this.btnviewpolist.Click += new System.EventHandler(this.btnviewpolist_Click);
            // 
            // pnvendor
            // 
            this.pnvendor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnvendor.Controls.Add(this.ViewVendorList);
            this.pnvendor.Controls.Add(this.btnSendReminder);
            this.pnvendor.Controls.Add(this.txtvendorcode);
            this.pnvendor.Controls.Add(this.PurchaseOrdervaliduptoDate);
            this.pnvendor.Controls.Add(this.POExpirationDate);
            this.pnvendor.Controls.Add(this.panel2);
            this.pnvendor.Controls.Add(this.label8);
            this.pnvendor.Controls.Add(this.cmbbomname);
            this.pnvendor.Controls.Add(this.cmbProjectcode);
            this.pnvendor.Controls.Add(this.dtpdelivery);
            this.pnvendor.Controls.Add(this.lbldeliverydate);
            this.pnvendor.Controls.Add(this.dtppreparedate);
            this.pnvendor.Controls.Add(this.cmbEmailAlert);
            this.pnvendor.Controls.Add(this.label27);
            this.pnvendor.Controls.Add(this.cbViewRemarks);
            this.pnvendor.Controls.Add(this.lblProjectStatus);
            this.pnvendor.Controls.Add(this.lblprojname);
            this.pnvendor.Controls.Add(this.cmbVendorName);
            this.pnvendor.Controls.Add(this.lblAuthorisedBy);
            this.pnvendor.Controls.Add(this.lblVendorName);
            this.pnvendor.Controls.Add(this.txtAuthorizedBy);
            this.pnvendor.Controls.Add(this.lblPrepareBy);
            this.pnvendor.Controls.Add(this.lblPre);
            this.pnvendor.Controls.Add(this.lblProjectCode);
            this.pnvendor.Controls.Add(this.lblProjectDescription);
            this.pnvendor.Location = new System.Drawing.Point(463, 47);
            this.pnvendor.Name = "pnvendor";
            this.pnvendor.Size = new System.Drawing.Size(836, 131);
            this.pnvendor.TabIndex = 118;
            // 
            // ViewVendorList
            // 
            this.ViewVendorList.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ViewVendorList.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.ViewVendorList.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ViewVendorList.Location = new System.Drawing.Point(635, 37);
            this.ViewVendorList.Name = "ViewVendorList";
            this.ViewVendorList.Size = new System.Drawing.Size(96, 30);
            this.ViewVendorList.TabIndex = 177;
            this.ViewVendorList.Text = "ViewVendorDelayList";
            this.ViewVendorList.UseVisualStyleBackColor = false;
            this.ViewVendorList.Click += new System.EventHandler(this.ViewVendorList_Click);
            // 
            // btnSendReminder
            // 
            this.btnSendReminder.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSendReminder.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSendReminder.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSendReminder.Location = new System.Drawing.Point(739, 37);
            this.btnSendReminder.Name = "btnSendReminder";
            this.btnSendReminder.Size = new System.Drawing.Size(81, 30);
            this.btnSendReminder.TabIndex = 176;
            this.btnSendReminder.Text = "SendReminder";
            this.btnSendReminder.UseVisualStyleBackColor = false;
            this.btnSendReminder.Click += new System.EventHandler(this.btnSendReminder_Click);
            // 
            // txtvendorcode
            // 
            this.txtvendorcode.AutoSize = true;
            this.txtvendorcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtvendorcode.ForeColor = System.Drawing.Color.Black;
            this.txtvendorcode.Location = new System.Drawing.Point(10, 39);
            this.txtvendorcode.Name = "txtvendorcode";
            this.txtvendorcode.Size = new System.Drawing.Size(15, 18);
            this.txtvendorcode.TabIndex = 175;
            this.txtvendorcode.Text = "*";
            this.txtvendorcode.Visible = false;
            // 
            // PurchaseOrdervaliduptoDate
            // 
            this.PurchaseOrdervaliduptoDate.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PurchaseOrdervaliduptoDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.PurchaseOrdervaliduptoDate.Location = new System.Drawing.Point(737, 7);
            this.PurchaseOrdervaliduptoDate.Name = "PurchaseOrdervaliduptoDate";
            this.PurchaseOrdervaliduptoDate.Size = new System.Drawing.Size(92, 23);
            this.PurchaseOrdervaliduptoDate.TabIndex = 174;
            this.PurchaseOrdervaliduptoDate.Visible = false;
            this.PurchaseOrdervaliduptoDate.ValueChanged += new System.EventHandler(this.PurchaseOrdervaliduptoDate_ValueChanged);
            // 
            // POExpirationDate
            // 
            this.POExpirationDate.AutoSize = true;
            this.POExpirationDate.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.POExpirationDate.ForeColor = System.Drawing.Color.Black;
            this.POExpirationDate.Location = new System.Drawing.Point(630, 13);
            this.POExpirationDate.Name = "POExpirationDate";
            this.POExpirationDate.Size = new System.Drawing.Size(101, 15);
            this.POExpirationDate.TabIndex = 173;
            this.POExpirationDate.Text = "PO Expiry Date *:";
            this.POExpirationDate.Visible = false;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.curratetext);
            this.panel2.Controls.Add(this.lblcurrency);
            this.panel2.Controls.Add(this.cmbcurrency);
            this.panel2.Location = new System.Drawing.Point(365, 87);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(213, 36);
            this.panel2.TabIndex = 172;
            // 
            // curratetext
            // 
            this.curratetext.Enabled = false;
            this.curratetext.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.curratetext.Location = new System.Drawing.Point(147, 4);
            this.curratetext.Name = "curratetext";
            this.curratetext.Size = new System.Drawing.Size(63, 26);
            this.curratetext.TabIndex = 174;
            this.curratetext.Visible = false;
            this.curratetext.TextChanged += new System.EventHandler(this.curratetext_TextChanged);
            // 
            // lblcurrency
            // 
            this.lblcurrency.AutoSize = true;
            this.lblcurrency.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcurrency.ForeColor = System.Drawing.Color.Black;
            this.lblcurrency.Location = new System.Drawing.Point(0, 9);
            this.lblcurrency.Name = "lblcurrency";
            this.lblcurrency.Size = new System.Drawing.Size(63, 15);
            this.lblcurrency.TabIndex = 172;
            this.lblcurrency.Text = "Currency :";
            // 
            // cmbcurrency
            // 
            this.cmbcurrency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbcurrency.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbcurrency.FormattingEnabled = true;
            this.cmbcurrency.ItemHeight = 18;
            this.cmbcurrency.Items.AddRange(new object[] {
            "Rupee",
            "EURO",
            "USD",
            "CAD",
            "GBP"});
            this.cmbcurrency.Location = new System.Drawing.Point(64, 4);
            this.cmbcurrency.Name = "cmbcurrency";
            this.cmbcurrency.Size = new System.Drawing.Size(82, 26);
            this.cmbcurrency.TabIndex = 173;
            this.cmbcurrency.SelectedIndexChanged += new System.EventHandler(this.cmbcurrency_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(-2, 70);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 15);
            this.label8.TabIndex = 171;
            this.label8.Text = "BOM Product :";
            // 
            // cmbbomname
            // 
            this.cmbbomname.DropDownHeight = 130;
            this.cmbbomname.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbbomname.DropDownWidth = 600;
            this.cmbbomname.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbbomname.FormattingEnabled = true;
            this.cmbbomname.IntegralHeight = false;
            this.cmbbomname.Location = new System.Drawing.Point(85, 64);
            this.cmbbomname.Name = "cmbbomname";
            this.cmbbomname.Size = new System.Drawing.Size(273, 26);
            this.cmbbomname.TabIndex = 170;
            this.cmbbomname.SelectedIndexChanged += new System.EventHandler(this.cmbbomname_SelectedIndexChanged_1);
            // 
            // cmbProjectcode
            // 
            this.cmbProjectcode.BackColor = System.Drawing.Color.LightGreen;
            this.cmbProjectcode.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.cmbProjectcode.Location = new System.Drawing.Point(86, 3);
            this.cmbProjectcode.Name = "cmbProjectcode";
            this.cmbProjectcode.ReadOnly = true;
            this.cmbProjectcode.Size = new System.Drawing.Size(273, 26);
            this.cmbProjectcode.TabIndex = 169;
            this.toolTip1.SetToolTip(this.cmbProjectcode, "Double click to view project list");
            this.cmbProjectcode.TextChanged += new System.EventHandler(this.cmbProjectcode_TextChanged);
            this.cmbProjectcode.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.cmbProjectcode_MouseDoubleClick);
            // 
            // dtpdelivery
            // 
            this.dtpdelivery.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpdelivery.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpdelivery.Location = new System.Drawing.Point(648, 97);
            this.dtpdelivery.Name = "dtpdelivery";
            this.dtpdelivery.Size = new System.Drawing.Size(90, 23);
            this.dtpdelivery.TabIndex = 128;
            this.dtpdelivery.ValueChanged += new System.EventHandler(this.dtpdelivery_ValueChanged);
            // 
            // lbldeliverydate
            // 
            this.lbldeliverydate.AutoSize = true;
            this.lbldeliverydate.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldeliverydate.ForeColor = System.Drawing.Color.Black;
            this.lbldeliverydate.Location = new System.Drawing.Point(585, 101);
            this.lbldeliverydate.Name = "lbldeliverydate";
            this.lbldeliverydate.Size = new System.Drawing.Size(62, 15);
            this.lbldeliverydate.TabIndex = 127;
            this.lbldeliverydate.Text = "Delivery*:";
            // 
            // cmbEmailAlert
            // 
            this.cmbEmailAlert.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbEmailAlert.DropDownHeight = 130;
            this.cmbEmailAlert.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbEmailAlert.FormattingEnabled = true;
            this.cmbEmailAlert.IntegralHeight = false;
            this.cmbEmailAlert.Location = new System.Drawing.Point(204, 98);
            this.cmbEmailAlert.Name = "cmbEmailAlert";
            this.cmbEmailAlert.Size = new System.Drawing.Size(155, 26);
            this.cmbEmailAlert.TabIndex = 168;
            this.cmbEmailAlert.SelectedIndexChanged += new System.EventHandler(this.cmbEmailAlert_SelectedIndexChanged);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.Black;
            this.label27.Location = new System.Drawing.Point(117, 103);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(86, 15);
            this.label27.TabIndex = 167;
            this.label27.Text = "Email Alert to:";
            // 
            // cbViewRemarks
            // 
            this.cbViewRemarks.AutoSize = true;
            this.cbViewRemarks.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbViewRemarks.ForeColor = System.Drawing.Color.Blue;
            this.cbViewRemarks.Location = new System.Drawing.Point(8, 94);
            this.cbViewRemarks.Name = "cbViewRemarks";
            this.cbViewRemarks.Size = new System.Drawing.Size(87, 23);
            this.cbViewRemarks.TabIndex = 166;
            this.cbViewRemarks.Text = "View Tax";
            this.cbViewRemarks.UseVisualStyleBackColor = true;
            this.cbViewRemarks.CheckedChanged += new System.EventHandler(this.cbViewRemarks_CheckedChanged);
            // 
            // lblProjectStatus
            // 
            this.lblProjectStatus.AutoSize = true;
            this.lblProjectStatus.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectStatus.ForeColor = System.Drawing.Color.Black;
            this.lblProjectStatus.Location = new System.Drawing.Point(350, -8);
            this.lblProjectStatus.Name = "lblProjectStatus";
            this.lblProjectStatus.Size = new System.Drawing.Size(15, 18);
            this.lblProjectStatus.TabIndex = 135;
            this.lblProjectStatus.Text = "*";
            this.lblProjectStatus.Visible = false;
            // 
            // lblprojname
            // 
            this.lblprojname.AutoSize = true;
            this.lblprojname.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprojname.ForeColor = System.Drawing.Color.Black;
            this.lblprojname.Location = new System.Drawing.Point(407, 7);
            this.lblprojname.MaximumSize = new System.Drawing.Size(300, 0);
            this.lblprojname.Name = "lblprojname";
            this.lblprojname.Size = new System.Drawing.Size(16, 18);
            this.lblprojname.TabIndex = 134;
            this.lblprojname.Text = "P";
            this.lblprojname.Click += new System.EventHandler(this.lblprojname_Click);
            // 
            // txtAuthorizedBy
            // 
            this.txtAuthorizedBy.AutoSize = true;
            this.txtAuthorizedBy.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAuthorizedBy.ForeColor = System.Drawing.Color.Blue;
            this.txtAuthorizedBy.Location = new System.Drawing.Point(450, 66);
            this.txtAuthorizedBy.Name = "txtAuthorizedBy";
            this.txtAuthorizedBy.Size = new System.Drawing.Size(12, 18);
            this.txtAuthorizedBy.TabIndex = 0;
            this.txtAuthorizedBy.Text = ".";
            this.txtAuthorizedBy.Click += new System.EventHandler(this.txtAuthorizedBy_Click);
            // 
            // lblPrepareBy
            // 
            this.lblPrepareBy.AutoSize = true;
            this.lblPrepareBy.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrepareBy.ForeColor = System.Drawing.Color.Blue;
            this.lblPrepareBy.Location = new System.Drawing.Point(450, 45);
            this.lblPrepareBy.Name = "lblPrepareBy";
            this.lblPrepareBy.Size = new System.Drawing.Size(12, 18);
            this.lblPrepareBy.TabIndex = 0;
            this.lblPrepareBy.Text = ".";
            this.lblPrepareBy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkWithoutBOM
            // 
            this.chkWithoutBOM.AutoSize = true;
            this.chkWithoutBOM.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkWithoutBOM.ForeColor = System.Drawing.Color.Blue;
            this.chkWithoutBOM.Location = new System.Drawing.Point(1144, 5);
            this.chkWithoutBOM.Name = "chkWithoutBOM";
            this.chkWithoutBOM.Size = new System.Drawing.Size(134, 22);
            this.chkWithoutBOM.TabIndex = 176;
            this.chkWithoutBOM.Text = "PO Without BOM";
            this.chkWithoutBOM.UseVisualStyleBackColor = true;
            this.chkWithoutBOM.CheckedChanged += new System.EventHandler(this.chkWithoutBOM_CheckedChanged);
            // 
            // btncopmletepoview
            // 
            this.btncopmletepoview.BackColor = System.Drawing.Color.Silver;
            this.btncopmletepoview.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncopmletepoview.ForeColor = System.Drawing.Color.Black;
            this.btncopmletepoview.Location = new System.Drawing.Point(0, 595);
            this.btncopmletepoview.Name = "btncopmletepoview";
            this.btncopmletepoview.Size = new System.Drawing.Size(95, 34);
            this.btncopmletepoview.TabIndex = 119;
            this.btncopmletepoview.Text = "View PO";
            this.btncopmletepoview.UseVisualStyleBackColor = false;
            this.btncopmletepoview.Click += new System.EventHandler(this.btncopmletepoview_Click);
            // 
            // pnitemadd
            // 
            this.pnitemadd.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnitemadd.Controls.Add(this.lstusers);
            this.pnitemadd.Controls.Add(this.chkItemDesc);
            this.pnitemadd.Controls.Add(this.chkItemCode);
            this.pnitemadd.Controls.Add(this.txtItemDescription);
            this.pnitemadd.Controls.Add(this.label1);
            this.pnitemadd.Controls.Add(this.chklbItemList);
            this.pnitemadd.Location = new System.Drawing.Point(2, 5);
            this.pnitemadd.Name = "pnitemadd";
            this.pnitemadd.Size = new System.Drawing.Size(454, 173);
            this.pnitemadd.TabIndex = 122;
            // 
            // lstusers
            // 
            this.lstusers.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstusers.FormattingEnabled = true;
            this.lstusers.ItemHeight = 19;
            this.lstusers.Location = new System.Drawing.Point(392, 2);
            this.lstusers.Name = "lstusers";
            this.lstusers.ScrollAlwaysVisible = true;
            this.lstusers.Size = new System.Drawing.Size(50, 23);
            this.lstusers.TabIndex = 199;
            this.lstusers.Visible = false;
            this.lstusers.SelectedIndexChanged += new System.EventHandler(this.lstusers_SelectedIndexChanged);
            // 
            // chkItemDesc
            // 
            this.chkItemDesc.AutoSize = true;
            this.chkItemDesc.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemDesc.ForeColor = System.Drawing.Color.Black;
            this.chkItemDesc.Location = new System.Drawing.Point(248, 3);
            this.chkItemDesc.Name = "chkItemDesc";
            this.chkItemDesc.Size = new System.Drawing.Size(140, 23);
            this.chkItemDesc.TabIndex = 213;
            this.chkItemDesc.Text = "Item Description";
            this.chkItemDesc.UseVisualStyleBackColor = true;
            this.chkItemDesc.CheckedChanged += new System.EventHandler(this.chkItemDesc_CheckedChanged);
            // 
            // chkItemCode
            // 
            this.chkItemCode.AutoSize = true;
            this.chkItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemCode.ForeColor = System.Drawing.Color.Black;
            this.chkItemCode.Location = new System.Drawing.Point(133, 3);
            this.chkItemCode.Name = "chkItemCode";
            this.chkItemCode.Size = new System.Drawing.Size(97, 23);
            this.chkItemCode.TabIndex = 212;
            this.chkItemCode.Text = "Item Code";
            this.chkItemCode.UseVisualStyleBackColor = true;
            this.chkItemCode.CheckedChanged += new System.EventHandler(this.chkItemCode_CheckedChanged);
            // 
            // pnauthorise
            // 
            this.pnauthorise.Controls.Add(this.cmbPONO);
            this.pnauthorise.Controls.Add(this.lblDetaiedBOM);
            this.pnauthorise.Location = new System.Drawing.Point(466, 8);
            this.pnauthorise.Name = "pnauthorise";
            this.pnauthorise.Size = new System.Drawing.Size(307, 36);
            this.pnauthorise.TabIndex = 163;
            this.pnauthorise.Visible = false;
            // 
            // pnloadpo
            // 
            this.pnloadpo.Controls.Add(this.btnloadpolist);
            this.pnloadpo.Location = new System.Drawing.Point(936, 8);
            this.pnloadpo.Name = "pnloadpo";
            this.pnloadpo.Size = new System.Drawing.Size(107, 30);
            this.pnloadpo.TabIndex = 164;
            this.pnloadpo.Visible = false;
            // 
            // btnPackingAmount
            // 
            this.btnPackingAmount.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnPackingAmount.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPackingAmount.ForeColor = System.Drawing.Color.Black;
            this.btnPackingAmount.Location = new System.Drawing.Point(914, 86);
            this.btnPackingAmount.Name = "btnPackingAmount";
            this.btnPackingAmount.Size = new System.Drawing.Size(149, 25);
            this.btnPackingAmount.TabIndex = 167;
            this.btnPackingAmount.Text = "Add Packing Forwarding";
            this.btnPackingAmount.UseVisualStyleBackColor = false;
            this.btnPackingAmount.Click += new System.EventHandler(this.btnPackingAmount_Click);
            // 
            // cmbtransactiontype
            // 
            this.cmbtransactiontype.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbtransactiontype.DropDownHeight = 130;
            this.cmbtransactiontype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbtransactiontype.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbtransactiontype.FormattingEnabled = true;
            this.cmbtransactiontype.IntegralHeight = false;
            this.cmbtransactiontype.Items.AddRange(new object[] {
            "Domestic",
            "International"});
            this.cmbtransactiontype.Location = new System.Drawing.Point(140, 3);
            this.cmbtransactiontype.Name = "cmbtransactiontype";
            this.cmbtransactiontype.Size = new System.Drawing.Size(151, 23);
            this.cmbtransactiontype.TabIndex = 169;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(32, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 15);
            this.label4.TabIndex = 168;
            this.label4.Text = "Transaction Type :";
            // 
            // pnPOReport
            // 
            this.pnPOReport.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnPOReport.Controls.Add(this.txtIncoterm);
            this.pnPOReport.Controls.Add(this.label2);
            this.pnPOReport.Controls.Add(this.cmbIncoterm);
            this.pnPOReport.Controls.Add(this.btnViewTax);
            this.pnPOReport.Controls.Add(this.btnAddTransport);
            this.pnPOReport.Controls.Add(this.txtShippedFrom1);
            this.pnPOReport.Controls.Add(this.label15);
            this.pnPOReport.Controls.Add(this.cmbDeliverTerms);
            this.pnPOReport.Controls.Add(this.label16);
            this.pnPOReport.Controls.Add(this.cmbPaymentTerms);
            this.pnPOReport.Controls.Add(this.label14);
            this.pnPOReport.Controls.Add(this.txtShippedCountry);
            this.pnPOReport.Controls.Add(this.label13);
            this.pnPOReport.Controls.Add(this.txtShippedGSTIn);
            this.pnPOReport.Controls.Add(this.txtShippedStateCode);
            this.pnPOReport.Controls.Add(this.label12);
            this.pnPOReport.Controls.Add(this.txtShippedFrom);
            this.pnPOReport.Controls.Add(this.label11);
            this.pnPOReport.Controls.Add(this.txtBalanceDue);
            this.pnPOReport.Controls.Add(this.txtAmountPaid);
            this.pnPOReport.Controls.Add(this.txtInvoiceTotal);
            this.pnPOReport.Controls.Add(this.label7);
            this.pnPOReport.Controls.Add(this.label9);
            this.pnPOReport.Controls.Add(this.label10);
            this.pnPOReport.Controls.Add(this.label6);
            this.pnPOReport.Controls.Add(this.cmbNatureofSupply);
            this.pnPOReport.Controls.Add(this.label5);
            this.pnPOReport.Controls.Add(this.cmbNatureofTransaction);
            this.pnPOReport.Controls.Add(this.label4);
            this.pnPOReport.Controls.Add(this.btnPackingAmount);
            this.pnPOReport.Controls.Add(this.cmbtransactiontype);
            this.pnPOReport.Enabled = false;
            this.pnPOReport.Location = new System.Drawing.Point(2, 471);
            this.pnPOReport.Name = "pnPOReport";
            this.pnPOReport.Size = new System.Drawing.Size(1293, 118);
            this.pnPOReport.TabIndex = 170;
            // 
            // txtIncoterm
            // 
            this.txtIncoterm.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIncoterm.Location = new System.Drawing.Point(448, 89);
            this.txtIncoterm.Name = "txtIncoterm";
            this.txtIncoterm.Size = new System.Drawing.Size(194, 23);
            this.txtIncoterm.TabIndex = 197;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(63, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 15);
            this.label2.TabIndex = 195;
            this.label2.Text = "Inco Terms :";
            // 
            // cmbIncoterm
            // 
            this.cmbIncoterm.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbIncoterm.DropDownHeight = 130;
            this.cmbIncoterm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbIncoterm.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbIncoterm.FormattingEnabled = true;
            this.cmbIncoterm.IntegralHeight = false;
            this.cmbIncoterm.Location = new System.Drawing.Point(140, 90);
            this.cmbIncoterm.Name = "cmbIncoterm";
            this.cmbIncoterm.Size = new System.Drawing.Size(302, 23);
            this.cmbIncoterm.TabIndex = 196;
            // 
            // btnViewTax
            // 
            this.btnViewTax.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnViewTax.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold);
            this.btnViewTax.ForeColor = System.Drawing.Color.Black;
            this.btnViewTax.Location = new System.Drawing.Point(1220, 84);
            this.btnViewTax.Name = "btnViewTax";
            this.btnViewTax.Size = new System.Drawing.Size(61, 24);
            this.btnViewTax.TabIndex = 194;
            this.btnViewTax.Text = "View Tax";
            this.btnViewTax.UseVisualStyleBackColor = false;
            this.btnViewTax.Click += new System.EventHandler(this.btnViewTax_Click);
            // 
            // btnAddTransport
            // 
            this.btnAddTransport.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddTransport.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold);
            this.btnAddTransport.ForeColor = System.Drawing.Color.Black;
            this.btnAddTransport.Location = new System.Drawing.Point(1069, 84);
            this.btnAddTransport.Name = "btnAddTransport";
            this.btnAddTransport.Size = new System.Drawing.Size(149, 24);
            this.btnAddTransport.TabIndex = 193;
            this.btnAddTransport.Text = "Add Transportation/Freight";
            this.btnAddTransport.UseVisualStyleBackColor = false;
            this.btnAddTransport.Click += new System.EventHandler(this.btnAddTransport_Click);
            // 
            // txtShippedFrom1
            // 
            this.txtShippedFrom1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtShippedFrom1.Location = new System.Drawing.Point(386, 31);
            this.txtShippedFrom1.Name = "txtShippedFrom1";
            this.txtShippedFrom1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtShippedFrom1.Size = new System.Drawing.Size(256, 26);
            this.txtShippedFrom1.TabIndex = 192;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(911, 37);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(95, 15);
            this.label15.TabIndex = 190;
            this.label15.Text = "Delivery Terms :";
            // 
            // cmbDeliverTerms
            // 
            this.cmbDeliverTerms.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbDeliverTerms.DropDownHeight = 130;
            this.cmbDeliverTerms.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDeliverTerms.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDeliverTerms.FormattingEnabled = true;
            this.cmbDeliverTerms.IntegralHeight = false;
            this.cmbDeliverTerms.Location = new System.Drawing.Point(1008, 31);
            this.cmbDeliverTerms.Name = "cmbDeliverTerms";
            this.cmbDeliverTerms.Size = new System.Drawing.Size(276, 23);
            this.cmbDeliverTerms.TabIndex = 191;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(900, 6);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(99, 15);
            this.label16.TabIndex = 188;
            this.label16.Text = "Payment Terms :";
            // 
            // cmbPaymentTerms
            // 
            this.cmbPaymentTerms.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbPaymentTerms.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbPaymentTerms.DropDownHeight = 130;
            this.cmbPaymentTerms.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPaymentTerms.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPaymentTerms.FormattingEnabled = true;
            this.cmbPaymentTerms.IntegralHeight = false;
            this.cmbPaymentTerms.Location = new System.Drawing.Point(1008, 3);
            this.cmbPaymentTerms.Name = "cmbPaymentTerms";
            this.cmbPaymentTerms.Size = new System.Drawing.Size(276, 23);
            this.cmbPaymentTerms.TabIndex = 189;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(640, 1);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(105, 15);
            this.label14.TabIndex = 187;
            this.label14.Text = "Shipped Country :";
            // 
            // txtShippedCountry
            // 
            this.txtShippedCountry.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtShippedCountry.Location = new System.Drawing.Point(745, 0);
            this.txtShippedCountry.Name = "txtShippedCountry";
            this.txtShippedCountry.Size = new System.Drawing.Size(139, 23);
            this.txtShippedCountry.TabIndex = 186;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(426, 64);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(34, 15);
            this.label13.TabIndex = 185;
            this.label13.Text = "GST :";
            // 
            // txtShippedGSTIn
            // 
            this.txtShippedGSTIn.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtShippedGSTIn.Location = new System.Drawing.Point(461, 61);
            this.txtShippedGSTIn.Name = "txtShippedGSTIn";
            this.txtShippedGSTIn.Size = new System.Drawing.Size(183, 23);
            this.txtShippedGSTIn.TabIndex = 184;
            // 
            // txtShippedStateCode
            // 
            this.txtShippedStateCode.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtShippedStateCode.Location = new System.Drawing.Point(386, 61);
            this.txtShippedStateCode.Name = "txtShippedStateCode";
            this.txtShippedStateCode.Size = new System.Drawing.Size(40, 23);
            this.txtShippedStateCode.TabIndex = 183;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(306, 61);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(74, 15);
            this.label12.TabIndex = 182;
            this.label12.Text = "State Code :";
            // 
            // txtShippedFrom
            // 
            this.txtShippedFrom.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtShippedFrom.Location = new System.Drawing.Point(386, 1);
            this.txtShippedFrom.Name = "txtShippedFrom";
            this.txtShippedFrom.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtShippedFrom.Size = new System.Drawing.Size(256, 26);
            this.txtShippedFrom.TabIndex = 181;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(301, 19);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(87, 15);
            this.label11.TabIndex = 180;
            this.label11.Text = "Shipped From:";
            // 
            // txtBalanceDue
            // 
            this.txtBalanceDue.Enabled = false;
            this.txtBalanceDue.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBalanceDue.Location = new System.Drawing.Point(745, 88);
            this.txtBalanceDue.Name = "txtBalanceDue";
            this.txtBalanceDue.Size = new System.Drawing.Size(139, 23);
            this.txtBalanceDue.TabIndex = 179;
            // 
            // txtAmountPaid
            // 
            this.txtAmountPaid.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAmountPaid.Location = new System.Drawing.Point(745, 58);
            this.txtAmountPaid.Name = "txtAmountPaid";
            this.txtAmountPaid.Size = new System.Drawing.Size(139, 23);
            this.txtAmountPaid.TabIndex = 178;
            this.txtAmountPaid.Text = "0";
            this.txtAmountPaid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAmountPaid_KeyPress);
            this.txtAmountPaid.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtAmountPaid_KeyUp);
            this.txtAmountPaid.Validated += new System.EventHandler(this.txtAmountPaid_Validated);
            // 
            // txtInvoiceTotal
            // 
            this.txtInvoiceTotal.Enabled = false;
            this.txtInvoiceTotal.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInvoiceTotal.Location = new System.Drawing.Point(745, 28);
            this.txtInvoiceTotal.Name = "txtInvoiceTotal";
            this.txtInvoiceTotal.Size = new System.Drawing.Size(139, 23);
            this.txtInvoiceTotal.TabIndex = 177;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(661, 91);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(80, 15);
            this.label7.TabIndex = 176;
            this.label7.Text = "Balance Due :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(658, 62);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(85, 15);
            this.label9.TabIndex = 175;
            this.label9.Text = "Amount Paid :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(663, 29);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(81, 15);
            this.label10.TabIndex = 174;
            this.label10.Text = "Invoice Total :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(30, 64);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(106, 15);
            this.label6.TabIndex = 172;
            this.label6.Text = "Nature of Supply :";
            // 
            // cmbNatureofSupply
            // 
            this.cmbNatureofSupply.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbNatureofSupply.DropDownHeight = 130;
            this.cmbNatureofSupply.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNatureofSupply.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbNatureofSupply.FormattingEnabled = true;
            this.cmbNatureofSupply.IntegralHeight = false;
            this.cmbNatureofSupply.Items.AddRange(new object[] {
            "Goods",
            "Services",
            "Goods & Services"});
            this.cmbNatureofSupply.Location = new System.Drawing.Point(140, 61);
            this.cmbNatureofSupply.Name = "cmbNatureofSupply";
            this.cmbNatureofSupply.Size = new System.Drawing.Size(151, 23);
            this.cmbNatureofSupply.TabIndex = 173;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(5, 34);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(131, 15);
            this.label5.TabIndex = 170;
            this.label5.Text = "Nature of Transaction :";
            // 
            // cmbNatureofTransaction
            // 
            this.cmbNatureofTransaction.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbNatureofTransaction.DropDownHeight = 130;
            this.cmbNatureofTransaction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNatureofTransaction.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbNatureofTransaction.FormattingEnabled = true;
            this.cmbNatureofTransaction.IntegralHeight = false;
            this.cmbNatureofTransaction.Items.AddRange(new object[] {
            "Import",
            "Export",
            "Intra State",
            "Inter State",
            "Stock Transfer"});
            this.cmbNatureofTransaction.Location = new System.Drawing.Point(140, 32);
            this.cmbNatureofTransaction.Name = "cmbNatureofTransaction";
            this.cmbNatureofTransaction.Size = new System.Drawing.Size(151, 23);
            this.cmbNatureofTransaction.TabIndex = 171;
            // 
            // dgPackingTaxes
            // 
            this.dgPackingTaxes.AllowUserToAddRows = false;
            this.dgPackingTaxes.AllowUserToDeleteRows = false;
            this.dgPackingTaxes.AllowUserToResizeRows = false;
            this.dgPackingTaxes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgPackingTaxes.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgPackingTaxes.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle114.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle114.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle114.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle114.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle114.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle114.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle114.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgPackingTaxes.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle114;
            this.dgPackingTaxes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgPackingTaxes.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TaxDesc,
            this.taxamount,
            this.taxIGSTRate,
            this.taxIGSTAmount,
            this.taxSGSTRate,
            this.taxSGSTAmount,
            this.taxCGSTRate,
            this.taxCGSTAmount});
            dataGridViewCellStyle122.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle122.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle122.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle122.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle122.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle122.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle122.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgPackingTaxes.DefaultCellStyle = dataGridViewCellStyle122;
            this.dgPackingTaxes.EnableHeadersVisualStyles = false;
            this.dgPackingTaxes.Location = new System.Drawing.Point(117, 272);
            this.dgPackingTaxes.MultiSelect = false;
            this.dgPackingTaxes.Name = "dgPackingTaxes";
            this.dgPackingTaxes.RowHeadersVisible = false;
            this.dgPackingTaxes.RowHeadersWidth = 62;
            this.dgPackingTaxes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgPackingTaxes.Size = new System.Drawing.Size(975, 152);
            this.dgPackingTaxes.TabIndex = 171;
            this.dgPackingTaxes.Visible = false;
            this.dgPackingTaxes.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgPackingTaxes_CellBeginEdit);
            this.dgPackingTaxes.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgPackingTaxes_CellEndEdit);
            this.dgPackingTaxes.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgPackingTaxes_EditingControlShowing);
            this.dgPackingTaxes.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgPackingTaxes_KeyUp);
            // 
            // TaxDesc
            // 
            this.TaxDesc.DataPropertyName = "TaxDescription";
            this.TaxDesc.HeaderText = "Tax Name";
            this.TaxDesc.MinimumWidth = 8;
            this.TaxDesc.Name = "TaxDesc";
            this.TaxDesc.ReadOnly = true;
            this.TaxDesc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxamount
            // 
            this.taxamount.DataPropertyName = "Amount";
            dataGridViewCellStyle115.BackColor = System.Drawing.Color.LightGreen;
            this.taxamount.DefaultCellStyle = dataGridViewCellStyle115;
            this.taxamount.HeaderText = "Amount";
            this.taxamount.MinimumWidth = 8;
            this.taxamount.Name = "taxamount";
            this.taxamount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxIGSTRate
            // 
            this.taxIGSTRate.DataPropertyName = "IGSTRate";
            dataGridViewCellStyle116.BackColor = System.Drawing.Color.LightGreen;
            this.taxIGSTRate.DefaultCellStyle = dataGridViewCellStyle116;
            this.taxIGSTRate.HeaderText = "IGST Rate";
            this.taxIGSTRate.MinimumWidth = 8;
            this.taxIGSTRate.Name = "taxIGSTRate";
            this.taxIGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxIGSTAmount
            // 
            this.taxIGSTAmount.DataPropertyName = "IGSTAmount";
            dataGridViewCellStyle117.Format = "N2";
            this.taxIGSTAmount.DefaultCellStyle = dataGridViewCellStyle117;
            this.taxIGSTAmount.HeaderText = "IGST Amount";
            this.taxIGSTAmount.MinimumWidth = 8;
            this.taxIGSTAmount.Name = "taxIGSTAmount";
            this.taxIGSTAmount.ReadOnly = true;
            this.taxIGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxSGSTRate
            // 
            this.taxSGSTRate.DataPropertyName = "SGSTRate";
            dataGridViewCellStyle118.BackColor = System.Drawing.Color.LightGreen;
            this.taxSGSTRate.DefaultCellStyle = dataGridViewCellStyle118;
            this.taxSGSTRate.HeaderText = "SGST Rate";
            this.taxSGSTRate.MinimumWidth = 8;
            this.taxSGSTRate.Name = "taxSGSTRate";
            this.taxSGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxSGSTAmount
            // 
            this.taxSGSTAmount.DataPropertyName = "SGSTAmount";
            dataGridViewCellStyle119.Format = "N2";
            this.taxSGSTAmount.DefaultCellStyle = dataGridViewCellStyle119;
            this.taxSGSTAmount.HeaderText = "SGST Amount";
            this.taxSGSTAmount.MinimumWidth = 8;
            this.taxSGSTAmount.Name = "taxSGSTAmount";
            this.taxSGSTAmount.ReadOnly = true;
            this.taxSGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxCGSTRate
            // 
            this.taxCGSTRate.DataPropertyName = "CGSTRate";
            dataGridViewCellStyle120.BackColor = System.Drawing.Color.LightGreen;
            this.taxCGSTRate.DefaultCellStyle = dataGridViewCellStyle120;
            this.taxCGSTRate.HeaderText = "CGST Rate";
            this.taxCGSTRate.MinimumWidth = 8;
            this.taxCGSTRate.Name = "taxCGSTRate";
            this.taxCGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxCGSTAmount
            // 
            this.taxCGSTAmount.DataPropertyName = "CGSTAmount";
            dataGridViewCellStyle121.Format = "N2";
            this.taxCGSTAmount.DefaultCellStyle = dataGridViewCellStyle121;
            this.taxCGSTAmount.HeaderText = "CGST Amount";
            this.taxCGSTAmount.MinimumWidth = 8;
            this.taxCGSTAmount.Name = "taxCGSTAmount";
            this.taxCGSTAmount.ReadOnly = true;
            this.taxCGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // pnBOMQtyCheck
            // 
            this.pnBOMQtyCheck.Controls.Add(this.dgvBOMQty);
            this.pnBOMQtyCheck.Controls.Add(this.label17);
            this.pnBOMQtyCheck.Controls.Add(this.lblBOMTotal);
            this.pnBOMQtyCheck.Controls.Add(this.btnAddPOBOMQty);
            this.pnBOMQtyCheck.Location = new System.Drawing.Point(103, 182);
            this.pnBOMQtyCheck.Name = "pnBOMQtyCheck";
            this.pnBOMQtyCheck.Size = new System.Drawing.Size(1103, 242);
            this.pnBOMQtyCheck.TabIndex = 172;
            this.pnBOMQtyCheck.Visible = false;
            this.pnBOMQtyCheck.Paint += new System.Windows.Forms.PaintEventHandler(this.pnBOMQtyCheck_Paint);
            // 
            // dgvBOMQty
            // 
            this.dgvBOMQty.AllowUserToAddRows = false;
            this.dgvBOMQty.AllowUserToDeleteRows = false;
            this.dgvBOMQty.AllowUserToOrderColumns = true;
            this.dgvBOMQty.AllowUserToResizeColumns = false;
            this.dgvBOMQty.AllowUserToResizeRows = false;
            this.dgvBOMQty.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvBOMQty.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle123.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle123.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle123.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle123.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle123.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle123.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle123.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvBOMQty.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle123;
            this.dgvBOMQty.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBOMQty.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProjectCode,
            this.ProjectName,
            this.ProductNo,
            this.ProductCode,
            this.ProductName,
            this.POQty,
            this.BOMQty,
            this.PreviousQty,
            this.BOMReqQty});
            dataGridViewCellStyle127.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle127.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle127.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle127.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle127.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle127.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle127.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvBOMQty.DefaultCellStyle = dataGridViewCellStyle127;
            this.dgvBOMQty.EnableHeadersVisualStyles = false;
            this.dgvBOMQty.Location = new System.Drawing.Point(3, 2);
            this.dgvBOMQty.Name = "dgvBOMQty";
            this.dgvBOMQty.RowHeadersVisible = false;
            this.dgvBOMQty.RowHeadersWidth = 62;
            this.dgvBOMQty.Size = new System.Drawing.Size(1097, 204);
            this.dgvBOMQty.TabIndex = 168;
            this.dgvBOMQty.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgvBOMQty_CellBeginEdit_1);
            this.dgvBOMQty.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvBOMQty_CellContentClick);
            this.dgvBOMQty.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvBOMQty_CellEndEdit_1);
            this.dgvBOMQty.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvBOMQty_EditingControlShowing_1);
            // 
            // ProjectCode
            // 
            this.ProjectCode.DataPropertyName = "ProjectCode";
            dataGridViewCellStyle124.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ProjectCode.DefaultCellStyle = dataGridViewCellStyle124;
            this.ProjectCode.HeaderText = "Project Code";
            this.ProjectCode.MinimumWidth = 8;
            this.ProjectCode.Name = "ProjectCode";
            this.ProjectCode.ReadOnly = true;
            this.ProjectCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectCode.Width = 83;
            // 
            // ProjectName
            // 
            this.ProjectName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ProjectName.DataPropertyName = "ProjectDescription";
            this.ProjectName.HeaderText = "Project Name";
            this.ProjectName.MinimumWidth = 8;
            this.ProjectName.Name = "ProjectName";
            this.ProjectName.ReadOnly = true;
            this.ProjectName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectName.Width = 196;
            // 
            // ProductNo
            // 
            this.ProductNo.DataPropertyName = "ProductNo";
            this.ProductNo.HeaderText = "ProductNo";
            this.ProductNo.MinimumWidth = 8;
            this.ProductNo.Name = "ProductNo";
            this.ProductNo.ReadOnly = true;
            this.ProductNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductNo.Width = 72;
            // 
            // ProductCode
            // 
            this.ProductCode.DataPropertyName = "ProductCode";
            this.ProductCode.HeaderText = "ProductCode";
            this.ProductCode.MinimumWidth = 8;
            this.ProductCode.Name = "ProductCode";
            this.ProductCode.ReadOnly = true;
            this.ProductCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductCode.Width = 84;
            // 
            // ProductName
            // 
            this.ProductName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ProductName.DataPropertyName = "ProductName";
            this.ProductName.HeaderText = "ProductName";
            this.ProductName.MinimumWidth = 8;
            this.ProductName.Name = "ProductName";
            this.ProductName.ReadOnly = true;
            this.ProductName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductName.Width = 89;
            // 
            // POQty
            // 
            this.POQty.DataPropertyName = "POQty";
            this.POQty.HeaderText = "POQty";
            this.POQty.MinimumWidth = 8;
            this.POQty.Name = "POQty";
            this.POQty.ReadOnly = true;
            this.POQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.POQty.Width = 49;
            // 
            // BOMQty
            // 
            this.BOMQty.DataPropertyName = "BOMQty";
            dataGridViewCellStyle125.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.BOMQty.DefaultCellStyle = dataGridViewCellStyle125;
            this.BOMQty.HeaderText = "BOM Qty";
            this.BOMQty.MinimumWidth = 8;
            this.BOMQty.Name = "BOMQty";
            this.BOMQty.ReadOnly = true;
            this.BOMQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.BOMQty.Width = 63;
            // 
            // PreviousQty
            // 
            this.PreviousQty.DataPropertyName = "PreviousQty";
            this.PreviousQty.HeaderText = "PreviousQty";
            this.PreviousQty.MinimumWidth = 8;
            this.PreviousQty.Name = "PreviousQty";
            this.PreviousQty.ReadOnly = true;
            this.PreviousQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PreviousQty.Width = 80;
            // 
            // BOMReqQty
            // 
            this.BOMReqQty.DataPropertyName = "ReqQty";
            dataGridViewCellStyle126.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle126.BackColor = System.Drawing.Color.LightGreen;
            dataGridViewCellStyle126.NullValue = null;
            this.BOMReqQty.DefaultCellStyle = dataGridViewCellStyle126;
            this.BOMReqQty.HeaderText = "Req Qty";
            this.BOMReqQty.MinimumWidth = 8;
            this.BOMReqQty.Name = "BOMReqQty";
            this.BOMReqQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.BOMReqQty.Width = 57;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(12, 216);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(90, 23);
            this.label17.TabIndex = 167;
            this.label17.Text = "Total Qty :";
            // 
            // lblBOMTotal
            // 
            this.lblBOMTotal.AutoSize = true;
            this.lblBOMTotal.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBOMTotal.ForeColor = System.Drawing.Color.Black;
            this.lblBOMTotal.Location = new System.Drawing.Point(100, 216);
            this.lblBOMTotal.Name = "lblBOMTotal";
            this.lblBOMTotal.Size = new System.Drawing.Size(20, 23);
            this.lblBOMTotal.TabIndex = 166;
            this.lblBOMTotal.Text = "0";
            // 
            // btnAddPOBOMQty
            // 
            this.btnAddPOBOMQty.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAddPOBOMQty.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAddPOBOMQty.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddPOBOMQty.Location = new System.Drawing.Point(987, 210);
            this.btnAddPOBOMQty.Name = "btnAddPOBOMQty";
            this.btnAddPOBOMQty.Size = new System.Drawing.Size(106, 25);
            this.btnAddPOBOMQty.TabIndex = 104;
            this.btnAddPOBOMQty.Text = "Add/Close";
            this.btnAddPOBOMQty.UseVisualStyleBackColor = false;
            this.btnAddPOBOMQty.Click += new System.EventHandler(this.btnAddPOBOMQty_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lbltotalIGST);
            this.panel1.Controls.Add(this.label25);
            this.panel1.Controls.Add(this.lbltotalCGST);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.lbltotalSGST);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.lbltotaldiscount);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.lblTotalAmount);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Location = new System.Drawing.Point(2, 435);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1293, 30);
            this.panel1.TabIndex = 173;
            // 
            // lbltotalIGST
            // 
            this.lbltotalIGST.AutoSize = true;
            this.lbltotalIGST.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lbltotalIGST.ForeColor = System.Drawing.Color.Black;
            this.lbltotalIGST.Location = new System.Drawing.Point(1138, 4);
            this.lbltotalIGST.Name = "lbltotalIGST";
            this.lbltotalIGST.Size = new System.Drawing.Size(17, 19);
            this.lbltotalIGST.TabIndex = 128;
            this.lbltotalIGST.Text = "0";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(1059, 4);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(80, 19);
            this.label25.TabIndex = 127;
            this.label25.Text = "Total IGST:";
            // 
            // lbltotalCGST
            // 
            this.lbltotalCGST.AutoSize = true;
            this.lbltotalCGST.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lbltotalCGST.ForeColor = System.Drawing.Color.Black;
            this.lbltotalCGST.Location = new System.Drawing.Point(897, 6);
            this.lbltotalCGST.Name = "lbltotalCGST";
            this.lbltotalCGST.Size = new System.Drawing.Size(17, 19);
            this.lbltotalCGST.TabIndex = 126;
            this.lbltotalCGST.Text = "0";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(815, 6);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(84, 19);
            this.label21.TabIndex = 125;
            this.label21.Text = "Total CGST:";
            // 
            // lbltotalSGST
            // 
            this.lbltotalSGST.AutoSize = true;
            this.lbltotalSGST.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lbltotalSGST.ForeColor = System.Drawing.Color.Black;
            this.lbltotalSGST.Location = new System.Drawing.Point(677, 7);
            this.lbltotalSGST.Name = "lbltotalSGST";
            this.lbltotalSGST.Size = new System.Drawing.Size(17, 19);
            this.lbltotalSGST.TabIndex = 124;
            this.lbltotalSGST.Text = "0";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label23.ForeColor = System.Drawing.Color.Black;
            this.label23.Location = new System.Drawing.Point(591, 6);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(89, 19);
            this.label23.TabIndex = 123;
            this.label23.Text = "Total SGST :";
            // 
            // lbltotaldiscount
            // 
            this.lbltotaldiscount.AutoSize = true;
            this.lbltotaldiscount.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lbltotaldiscount.ForeColor = System.Drawing.Color.Black;
            this.lbltotaldiscount.Location = new System.Drawing.Point(400, 6);
            this.lbltotaldiscount.Name = "lbltotaldiscount";
            this.lbltotaldiscount.Size = new System.Drawing.Size(17, 19);
            this.lbltotaldiscount.TabIndex = 122;
            this.lbltotaldiscount.Text = "0";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(293, 6);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(111, 19);
            this.label18.TabIndex = 121;
            this.label18.Text = "Total Discount:";
            // 
            // lblTotalAmount
            // 
            this.lblTotalAmount.AutoSize = true;
            this.lblTotalAmount.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblTotalAmount.ForeColor = System.Drawing.Color.Black;
            this.lblTotalAmount.Location = new System.Drawing.Point(117, 4);
            this.lblTotalAmount.Name = "lblTotalAmount";
            this.lblTotalAmount.Size = new System.Drawing.Size(17, 19);
            this.lblTotalAmount.TabIndex = 120;
            this.lblTotalAmount.Text = "0";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(9, 3);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(111, 19);
            this.label19.TabIndex = 119;
            this.label19.Text = "Total Amount :";
            // 
            // pnRemarks
            // 
            this.pnRemarks.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnRemarks.Controls.Add(this.llbViewPOGeneralTerms);
            this.pnRemarks.Controls.Add(this.llbViewRemakrs);
            this.pnRemarks.Controls.Add(this.txtRemarks);
            this.pnRemarks.Controls.Add(this.lblRemarks);
            this.pnRemarks.Location = new System.Drawing.Point(2, 461);
            this.pnRemarks.Name = "pnRemarks";
            this.pnRemarks.Size = new System.Drawing.Size(1295, 129);
            this.pnRemarks.TabIndex = 174;
            // 
            // llbViewPOGeneralTerms
            // 
            this.llbViewPOGeneralTerms.AutoSize = true;
            this.llbViewPOGeneralTerms.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbViewPOGeneralTerms.Location = new System.Drawing.Point(499, 95);
            this.llbViewPOGeneralTerms.Name = "llbViewPOGeneralTerms";
            this.llbViewPOGeneralTerms.Size = new System.Drawing.Size(167, 19);
            this.llbViewPOGeneralTerms.TabIndex = 177;
            this.llbViewPOGeneralTerms.TabStop = true;
            this.llbViewPOGeneralTerms.Text = "View PO General Terms";
            this.llbViewPOGeneralTerms.Visible = false;
            this.llbViewPOGeneralTerms.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbViewPOGeneralTerms_LinkClicked);
            // 
            // llbViewRemakrs
            // 
            this.llbViewRemakrs.AutoSize = true;
            this.llbViewRemakrs.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbViewRemakrs.Location = new System.Drawing.Point(98, 91);
            this.llbViewRemakrs.Name = "llbViewRemakrs";
            this.llbViewRemakrs.Size = new System.Drawing.Size(178, 19);
            this.llbViewRemakrs.TabIndex = 176;
            this.llbViewRemakrs.TabStop = true;
            this.llbViewRemakrs.Text = "View remarks of all users";
            this.llbViewRemakrs.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbViewRemakrs_LinkClicked);
            // 
            // btnLoadPCList
            // 
            this.btnLoadPCList.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnLoadPCList.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnLoadPCList.Location = new System.Drawing.Point(782, 8);
            this.btnLoadPCList.Name = "btnLoadPCList";
            this.btnLoadPCList.Size = new System.Drawing.Size(139, 30);
            this.btnLoadPCList.TabIndex = 175;
            this.btnLoadPCList.Text = "Load approve PO";
            this.btnLoadPCList.UseVisualStyleBackColor = false;
            this.btnLoadPCList.Visible = false;
            this.btnLoadPCList.Click += new System.EventHandler(this.btnLoadPCList_Click);
            // 
            // chkUpdatePO
            // 
            this.chkUpdatePO.AutoSize = true;
            this.chkUpdatePO.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkUpdatePO.ForeColor = System.Drawing.Color.Blue;
            this.chkUpdatePO.Location = new System.Drawing.Point(1144, 23);
            this.chkUpdatePO.Name = "chkUpdatePO";
            this.chkUpdatePO.Size = new System.Drawing.Size(94, 22);
            this.chkUpdatePO.TabIndex = 177;
            this.chkUpdatePO.Text = "Update PO";
            this.chkUpdatePO.UseVisualStyleBackColor = true;
            this.chkUpdatePO.CheckedChanged += new System.EventHandler(this.chkUpdatePO_CheckedChanged);
            // 
            // dgvRemarks
            // 
            this.dgvRemarks.AllowUserToAddRows = false;
            this.dgvRemarks.AllowUserToOrderColumns = true;
            this.dgvRemarks.AllowUserToResizeRows = false;
            this.dgvRemarks.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvRemarks.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvRemarks.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvRemarks.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            dataGridViewCellStyle128.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle128.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle128.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle128.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle128.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle128.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle128.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRemarks.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle128;
            this.dgvRemarks.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRemarks.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.RemarksBy,
            this.RemarksDate,
            this.Remarks});
            dataGridViewCellStyle129.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle129.BackColor = System.Drawing.Color.LavenderBlush;
            dataGridViewCellStyle129.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle129.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle129.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle129.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle129.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRemarks.DefaultCellStyle = dataGridViewCellStyle129;
            this.dgvRemarks.Location = new System.Drawing.Point(507, 180);
            this.dgvRemarks.Name = "dgvRemarks";
            this.dgvRemarks.RowHeadersVisible = false;
            this.dgvRemarks.RowHeadersWidth = 62;
            this.dgvRemarks.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvRemarks.Size = new System.Drawing.Size(781, 366);
            this.dgvRemarks.TabIndex = 247;
            this.dgvRemarks.Visible = false;
            // 
            // RemarksBy
            // 
            this.RemarksBy.DataPropertyName = "Preparedby";
            this.RemarksBy.HeaderText = "Remarks By";
            this.RemarksBy.MinimumWidth = 8;
            this.RemarksBy.Name = "RemarksBy";
            this.RemarksBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RemarksBy.Width = 94;
            // 
            // RemarksDate
            // 
            this.RemarksDate.DataPropertyName = "POPreparedDate";
            this.RemarksDate.HeaderText = "Date";
            this.RemarksDate.MinimumWidth = 8;
            this.RemarksDate.Name = "RemarksDate";
            this.RemarksDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RemarksDate.Width = 47;
            // 
            // Remarks
            // 
            this.Remarks.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Remarks.DataPropertyName = "Remarks";
            this.Remarks.HeaderText = "Remarks";
            this.Remarks.MinimumWidth = 8;
            this.Remarks.Name = "Remarks";
            this.Remarks.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dgvPOGeneralTerms
            // 
            this.dgvPOGeneralTerms.AllowUserToAddRows = false;
            this.dgvPOGeneralTerms.AllowUserToOrderColumns = true;
            this.dgvPOGeneralTerms.AllowUserToResizeRows = false;
            this.dgvPOGeneralTerms.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvPOGeneralTerms.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvPOGeneralTerms.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvPOGeneralTerms.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            dataGridViewCellStyle130.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle130.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle130.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle130.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle130.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle130.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle130.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPOGeneralTerms.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle130;
            this.dgvPOGeneralTerms.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPOGeneralTerms.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.POTerms});
            dataGridViewCellStyle132.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle132.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle132.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle132.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle132.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle132.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle132.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPOGeneralTerms.DefaultCellStyle = dataGridViewCellStyle132;
            this.dgvPOGeneralTerms.Location = new System.Drawing.Point(7, 38);
            this.dgvPOGeneralTerms.Name = "dgvPOGeneralTerms";
            this.dgvPOGeneralTerms.RowHeadersVisible = false;
            this.dgvPOGeneralTerms.RowHeadersWidth = 62;
            this.dgvPOGeneralTerms.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvPOGeneralTerms.Size = new System.Drawing.Size(758, 309);
            this.dgvPOGeneralTerms.TabIndex = 248;
            this.dgvPOGeneralTerms.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPOGeneralTerms_CellContentClick);
            this.dgvPOGeneralTerms.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvPOGeneralTerms_KeyUp);
            // 
            // POTerms
            // 
            this.POTerms.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.POTerms.DataPropertyName = "POGeneralTerms";
            dataGridViewCellStyle131.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.POTerms.DefaultCellStyle = dataGridViewCellStyle131;
            this.POTerms.HeaderText = "PO General Terms and Condition";
            this.POTerms.MinimumWidth = 8;
            this.POTerms.Name = "POTerms";
            this.POTerms.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // pnGeneralTerms
            // 
            this.pnGeneralTerms.Controls.Add(this.cmbPOTerms);
            this.pnGeneralTerms.Controls.Add(this.label3);
            this.pnGeneralTerms.Controls.Add(this.btnAddNewRow);
            this.pnGeneralTerms.Controls.Add(this.dgvPOGeneralTerms);
            this.pnGeneralTerms.Location = new System.Drawing.Point(520, 195);
            this.pnGeneralTerms.Name = "pnGeneralTerms";
            this.pnGeneralTerms.Size = new System.Drawing.Size(772, 353);
            this.pnGeneralTerms.TabIndex = 169;
            this.pnGeneralTerms.Visible = false;
            // 
            // cmbPOTerms
            // 
            this.cmbPOTerms.DropDownHeight = 130;
            this.cmbPOTerms.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPOTerms.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPOTerms.FormattingEnabled = true;
            this.cmbPOTerms.IntegralHeight = false;
            this.cmbPOTerms.Location = new System.Drawing.Point(99, 8);
            this.cmbPOTerms.Name = "cmbPOTerms";
            this.cmbPOTerms.Size = new System.Drawing.Size(273, 26);
            this.cmbPOTerms.TabIndex = 251;
            this.cmbPOTerms.SelectedIndexChanged += new System.EventHandler(this.cmbPOTerms_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(27, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 15);
            this.label3.TabIndex = 250;
            this.label3.Text = "PO Terms :";
            // 
            // btnAddNewRow
            // 
            this.btnAddNewRow.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAddNewRow.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAddNewRow.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnAddNewRow.Location = new System.Drawing.Point(492, 3);
            this.btnAddNewRow.Name = "btnAddNewRow";
            this.btnAddNewRow.Size = new System.Drawing.Size(169, 30);
            this.btnAddNewRow.TabIndex = 249;
            this.btnAddNewRow.Text = "Add new term";
            this.btnAddNewRow.UseVisualStyleBackColor = false;
            this.btnAddNewRow.Click += new System.EventHandler(this.btnAddNewRow_Click);
            // 
            // AmeandPO
            // 
            this.AmeandPO.AutoSize = true;
            this.AmeandPO.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AmeandPO.ForeColor = System.Drawing.Color.Red;
            this.AmeandPO.Location = new System.Drawing.Point(1064, 22);
            this.AmeandPO.Name = "AmeandPO";
            this.AmeandPO.Size = new System.Drawing.Size(77, 23);
            this.AmeandPO.TabIndex = 124;
            this.AmeandPO.Text = "Amend";
            this.AmeandPO.UseVisualStyleBackColor = true;
            this.AmeandPO.Visible = false;
            this.AmeandPO.CheckedChanged += new System.EventHandler(this.AmeandPO_CheckedChanged_1);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(755, 10);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 30);
            this.button1.TabIndex = 170;
            this.button1.Text = "GMAmend";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            this.button1.Visible = false;
            this.button1.Enabled = false;
            // 
            // PurchaseOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1300, 632);
            this.Controls.Add(this.AmeandPO);
            this.Controls.Add(this.pnGeneralTerms);
            this.Controls.Add(this.chkPrintPO);
            this.Controls.Add(this.dgvRemarks);
            this.Controls.Add(this.chkWithoutBOM);
            this.Controls.Add(this.chkUpdatePO);
            this.Controls.Add(this.pnBOMQtyCheck);
            this.Controls.Add(this.dgPackingTaxes);
            this.Controls.Add(this.pnloadpo);
            this.Controls.Add(this.pnauthorise);
            this.Controls.Add(this.btncopmletepoview);
            this.Controls.Add(this.pnvendor);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnviewpolist);
            this.Controls.Add(this.btnrepeatorder);
            this.Controls.Add(this.dgbomlist);
            this.Controls.Add(this.btnLoadPCList);
            this.Controls.Add(this.pnitemadd);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnRemarks);
            this.Controls.Add(this.pnPOReport);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "PurchaseOrder";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Purchase Order";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.PurchaseOrder_FormClosing);
            this.Load += new System.EventHandler(this.PurchaseOrder_Load);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgbomlist)).EndInit();
            this.pnvendor.ResumeLayout(false);
            this.pnvendor.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.pnitemadd.ResumeLayout(false);
            this.pnitemadd.PerformLayout();
            this.pnauthorise.ResumeLayout(false);
            this.pnauthorise.PerformLayout();
            this.pnloadpo.ResumeLayout(false);
            this.pnPOReport.ResumeLayout(false);
            this.pnPOReport.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgPackingTaxes)).EndInit();
            this.pnBOMQtyCheck.ResumeLayout(false);
            this.pnBOMQtyCheck.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBOMQty)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnRemarks.ResumeLayout(false);
            this.pnRemarks.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRemarks)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPOGeneralTerms)).EndInit();
            this.pnGeneralTerms.ResumeLayout(false);
            this.pnGeneralTerms.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPre;
        private System.Windows.Forms.Button btnprintpo;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnGenaratePO;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblProjectDescription;
        private System.Windows.Forms.ComboBox cmbVendorName;
        private System.Windows.Forms.Label lblVendorName;
        private System.Windows.Forms.ComboBox cmbPONO;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.Label lblRemarks;
        private System.Windows.Forms.Label lblProjectCode;
        private System.Windows.Forms.Label lblDetaiedBOM;
        private System.Windows.Forms.Label lblAuthorisedBy;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckedListBox chklbItemList;
        private System.Windows.Forms.TextBox txtItemDescription;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.DataGridView dgbomlist;
        private System.Windows.Forms.Button btnloadpolist;
        private System.Windows.Forms.Button btnviewpolist;
        private System.Windows.Forms.CheckBox chkPrintPO;
        private System.Windows.Forms.Button btnrepeatorder;
        private System.Windows.Forms.DateTimePicker dtppreparedate;
        private System.Windows.Forms.Panel pnvendor;
        private System.Windows.Forms.Button btncopmletepoview;
        private System.Windows.Forms.Label lbldeliverydate;
        private System.Windows.Forms.DateTimePicker dtpdelivery;
        private System.Windows.Forms.Panel pnitemadd;
        private System.Windows.Forms.Panel pnauthorise;
        private System.Windows.Forms.Panel pnloadpo;
        private System.Windows.Forms.Label lblprojname;
        private System.Windows.Forms.Label txtAuthorizedBy;
        private System.Windows.Forms.Label lblPrepareBy;
        private System.Windows.Forms.Label lblProjectStatus;
        private System.Windows.Forms.Button btnPackingAmount;
        private System.Windows.Forms.ComboBox cmbtransactiontype;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel pnPOReport;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbNatureofSupply;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbNatureofTransaction;
        private System.Windows.Forms.TextBox txtBalanceDue;
        private System.Windows.Forms.TextBox txtAmountPaid;
        private System.Windows.Forms.TextBox txtInvoiceTotal;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtShippedGSTIn;
        private System.Windows.Forms.TextBox txtShippedStateCode;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtShippedFrom;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView dgPackingTaxes;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtShippedCountry;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox cmbDeliverTerms;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox cmbPaymentTerms;
        private System.Windows.Forms.TextBox txtShippedFrom1;
        private System.Windows.Forms.Button btnViewTax;
        private System.Windows.Forms.Button btnAddTransport;
        private System.Windows.Forms.CheckBox chkItemDesc;
        private System.Windows.Forms.CheckBox chkItemCode;
        private System.Windows.Forms.Panel pnBOMQtyCheck;
        private System.Windows.Forms.Button btnAddPOBOMQty;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lblBOMTotal;
        private System.Windows.Forms.DataGridView dgvBOMQty;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbltotalIGST;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label lbltotalCGST;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lbltotalSGST;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label lbltotaldiscount;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lblTotalAmount;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btnAcceptPO;
        private System.Windows.Forms.Button btnRejectPO;
        private System.Windows.Forms.Panel pnRemarks;
        private System.Windows.Forms.CheckBox cbViewRemarks;
        private System.Windows.Forms.Button btnLoadPCList;
        private System.Windows.Forms.ComboBox cmbEmailAlert;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.DataGridViewTextBoxColumn TaxDesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxamount;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxIGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxIGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxSGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxSGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxCGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxCGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn POQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn BOMQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn PreviousQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn BOMReqQty;
        private System.Windows.Forms.ListBox lstusers;
        private System.Windows.Forms.CheckBox chkWithoutBOM;
        private System.Windows.Forms.CheckBox chkUpdatePO;
        private System.Windows.Forms.DataGridViewTextBoxColumn HSNSACCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn UOM;
        private System.Windows.Forms.DataGridViewTextBoxColumn AvaQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn SixMonths;
        private System.Windows.Forms.DataGridViewTextBoxColumn TwelveMonths;
        private System.Windows.Forms.DataGridViewTextBoxColumn dBOMQty;
        private System.Windows.Forms.DataGridViewButtonColumn BOMbutton;
        private System.Windows.Forms.DataGridViewTextBoxColumn BOMProjectCodes;
        private System.Windows.Forms.DataGridViewTextBoxColumn OtherProjects;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReqQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn RemQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn TargetCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn Unitprice;
        private System.Windows.Forms.DataGridViewTextBoxColumn StandardCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn LatestPurchasePrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiffrenceinPer;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiffrenceinRs;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiscRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiscAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn SGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn SGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn CGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn CGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn IGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn IGSTAmount;
        private System.Windows.Forms.TextBox cmbProjectcode;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ComboBox cmbbomname;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblcurrency;
        private System.Windows.Forms.ComboBox cmbcurrency;
        private System.Windows.Forms.TextBox curratetext;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dgvRemarks;
        private System.Windows.Forms.LinkLabel llbViewRemakrs;
        private System.Windows.Forms.DataGridView dgvPOGeneralTerms;
        private System.Windows.Forms.Panel pnGeneralTerms;
        private System.Windows.Forms.Button btnAddNewRow;
        private System.Windows.Forms.LinkLabel llbViewPOGeneralTerms;
        private System.Windows.Forms.DataGridViewTextBoxColumn POTerms;
        private System.Windows.Forms.DataGridViewTextBoxColumn RemarksBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn RemarksDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Remarks;
        private System.Windows.Forms.TextBox txtIncoterm;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbIncoterm;
        private System.Windows.Forms.ComboBox cmbPOTerms;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker PurchaseOrdervaliduptoDate;
        private System.Windows.Forms.Label POExpirationDate;
        private System.Windows.Forms.Label txtvendorcode;
        private System.Windows.Forms.Button butAmend;
        private System.Windows.Forms.CheckBox AmeandPO;
        private System.Windows.Forms.Button btnClosePO;
        private System.Windows.Forms.Button btnCancelPO;
        private System.Windows.Forms.Button btnSendReminder;
        private System.Windows.Forms.Button ViewVendorList;
        private Button button1;
    }
}
