﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Diagnostics;
using System.Text;

namespace Erp_Project_With_Buttons.Purchase_Order
{
    public partial class POView : Form
    {
        DataTable dtPolist = new DataTable();
        DataTable dtProjectList = new DataTable();
        DataAccessLayer DAL = new DataAccessLayer();
        DataView dvPOViewList = new DataView();
        DataTable dtExcelTable = new DataTable();
        BindingSource bsItemList = new BindingSource();
        Login.frmLoginForm login = new Login.frmLoginForm();
        Global GLobalClass = new Global();
        Purchase_Order.PurchaseOrder PurchaseOrderForm = new PurchaseOrder();
        //  Global GlobalClass = new Global();

        public POView()
        {
            InitializeComponent();
        }

        private void fnRowFilter(uint uSearchOption, string sRowFilter)    //filter the Item list depends upon the user inpts
        {
            DataView dvPOViewList = new DataView(dtPolist);
            dtExcelTable = new DataTable();
            //dvPOViewList.ToTable = dtPolist; ;
            if (dtPolist.Rows.Count > 0)
            {
                switch (uSearchOption)
                {
                    case Global.uITEM_CODE_SEARCH:
                        {
                            dvPOViewList.RowFilter = "DBOMNo like '" + sRowFilter + "%'";
                            break;
                        }
                    case Global.uITEM_DESCRIPTION_SEARCH:
                        {
                            dvPOViewList.RowFilter = "ProjectCode like '" + sRowFilter + "%'";
                            break;
                        }
                    case Global.uITEM_TYPE_SEARCH:
                        {
                            dvPOViewList.RowFilter = "VendorName like '" + sRowFilter + "%'";
                            break;
                        }
                    case Global.uITEM_STATUS_SEARCH:
                        {
                            dvPOViewList.RowFilter = "AuthoriedBy like '" + sRowFilter + "%'";
                            break;
                        }
                    case 7:
                        {
                            dvPOViewList.RowFilter = " CONVERT(POLateBy, System.String) = '" + sRowFilter + "'";
                            break;
                        }
                }

                dgpolist.DataSource = dvPOViewList.ToTable();
                dtExcelTable = dvPOViewList.ToTable();
                Datagridviewcolor();
            }
        }

        private void POView_Load(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(login.GetUserDetails[16]) == true || Convert.ToBoolean(login.GetUserDetails[30]) == true || Convert.ToBoolean(login.GetUserDetails[29]) == true || Convert.ToBoolean(login.GetUserDetails[31]) == true || Convert.ToBoolean(login.GetUserDetails[32]) == true)    //  lblPrepareBy.Text.ToLower() == "hebbarrk")
            {
                dgpolist.Columns[8].Visible = true;
                dgpolist.Columns[11].Visible = true;
                btnExcelExceport.Visible = true;
            }
            else
            {
                dgpolist.Columns[8].Visible = false;
                dgpolist.Columns[11].Visible = false;
                btnExcelExceport.Visible = false;
            }
        }

        private void POView_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            //   this.Hide();
            pleasewaitform pleaseWait = new pleasewaitform();
            // Display form modelessly
            pleaseWait.Show();
            //  ALlow main UI thread to properly display please wait form.
            Application.DoEvents();
            PurchaseOrder PurchaseOrder = new PurchaseOrder();
            PurchaseOrder.Show();
            pleaseWait.Hide();
        }

        private void txtDBOMNo_Enter(object sender, EventArgs e)
        {
            txtDBOMNo.Text = string.Empty;
            dgpolist.DataSource = bsItemList;
            Datagridviewcolor();
        }

        private void txtProjectcode_Enter(object sender, EventArgs e)
        {
            txtProjectcode.Text = string.Empty;
            dgpolist.DataSource = bsItemList;
            Datagridviewcolor();
        }

        private void txtPreparedBy_Enter(object sender, EventArgs e)
        {
            txtPreparedBy.Text = string.Empty;
            dgpolist.DataSource = bsItemList;
            Datagridviewcolor();
        }

        private void txtAuthorisedBy_Enter(object sender, EventArgs e)
        {
            txtAuthorisedBy.Text = string.Empty;
            dgpolist.DataSource = bsItemList;
            Datagridviewcolor();
        }

        private void txtDBOMNo_KeyUp(object sender, KeyEventArgs e)
        {
            fnRowFilter(0, txtDBOMNo.Text);
        }

        private void txtProjectcode_KeyUp(object sender, KeyEventArgs e)
        {
            fnRowFilter(1, txtProjectcode.Text);
        }

        private void txtPreparedBy_KeyUp(object sender, KeyEventArgs e)
        {
            fnRowFilter(2, txtPreparedBy.Text);
        }

        private void txtAuthorisedBy_KeyUp(object sender, KeyEventArgs e)
        {
            fnRowFilter(3, txtAuthorisedBy.Text);
        }

        private void dgpolist_DoubleClick(object sender, EventArgs e)
        {
            PurchaseOrderForm.fnAdjustPurchaseOrder = string.Empty;
            bool create = false;
            try
            {
                // if ((dgpolist.CurrentRow.Cells["AuthorisedBy"].Value.ToString().ToLower() == login.GetUserDetails[2].ToLower()) && string.IsNullOrEmpty(dgpolist.CurrentRow.Cells["POGeneratedBy"].Value.ToString()))
                if (string.IsNullOrEmpty(dgpolist.CurrentRow.Cells["POGeneratedBy"].Value.ToString()) || string.IsNullOrEmpty(dgpolist.CurrentRow.Cells["POGeneratedDate"].Value.ToString()))
                {
                   create = true;
                }
                if ((!string.IsNullOrEmpty(dgpolist.CurrentRow.Cells["POGeneratedBy"].Value.ToString()) || !string.IsNullOrEmpty(dgpolist.CurrentRow.Cells["POGeneratedDate"].Value.ToString())) && (login.GetUserDetails[2]== "Muthuramalingam" || login.GetUserDetails[2] == "Suresh Kumar"))
                {
                    create = true;
                }

                if (create)
                  { 
                    if (Convert.ToBoolean(login.GetUserDetails[16]) == true )
                    {
                        dtProjectList = DAL.fnProjectList(dgpolist.CurrentRow.Cells["ProjectCode"].Value.ToString()).Tables[0];
                        DataView dvproject = new DataView(dtProjectList);
                        dvproject.RowFilter = "Status not like 'Revenue Recognised'";
                        if (dvproject.ToTable().Rows.Count > 0)
                        {
                            PurchaseOrderForm.fnAdjustPurchaseOrder = dgpolist.CurrentRow.Cells["DBOMNo"].Value.ToString();
                            this.Hide();
                            pleasewaitform pleaseWait = new pleasewaitform();
                            // Display form modelessly
                            pleaseWait.Show();
                            //  ALlow main UI thread to properly display please wait form.
                            Application.DoEvents();
                            PurchaseOrder PurchaseOrder = new PurchaseOrder();
                            PurchaseOrder.Show();
                            pleaseWait.Hide();
                        }
                        else
                        {
                            PurchaseOrderForm.fnAdjustPurchaseOrder = string.Empty;
                            MessageBox.Show("The Selected ProjectCode '" + dgpolist.CurrentRow.Cells["ProjectCode"].Value.ToString() + "' is under Revenue Recognised Further Process is not allowed", "Information", 0, MessageBoxIcon.Information);
                        }
                    }
                    else if ((Convert.ToBoolean(login.GetUserDetails[16]) == true) && !string.IsNullOrEmpty(dgpolist.CurrentRow.Cells["AuthorisedBy"].Value.ToString()))
                    {
                        dtProjectList = DAL.fnProjectList(dgpolist.CurrentRow.Cells["ProjectCode"].Value.ToString()).Tables[0];
                        DataView dvproject = new DataView(dtProjectList);
                        dvproject.RowFilter = "Status not like 'Revenue Recognised'";
                        if (dvproject.ToTable().Rows.Count > 0)
                        {
                            PurchaseOrderForm.fnAdjustPurchaseOrder = dgpolist.CurrentRow.Cells["DBOMNo"].Value.ToString();
                            this.Hide();
                            pleasewaitform pleaseWait = new pleasewaitform();
                            // Display form modelessly
                            pleaseWait.Show();
                            //  ALlow main UI thread to properly display please wait form.
                            Application.DoEvents();
                            PurchaseOrder PurchaseOrder = new PurchaseOrder();
                            PurchaseOrder.Show();
                            pleaseWait.Hide();
                        }
                        else
                        {
                            PurchaseOrderForm.fnAdjustPurchaseOrder = string.Empty;
                            MessageBox.Show("The Selected ProjectCode '" + dgpolist.CurrentRow.Cells["ProjectCode"].Value.ToString() + "' is under Revenue Recognised Further Process is not allowed", "Information", 0, MessageBoxIcon.Information);
                        }

                    }
                    else
                    {
                        MessageBox.Show("The slected'" + dgpolist.CurrentRow.Cells["DBOMNo"].Value.ToString() + "' already genarated on '" + dgpolist.CurrentRow.Cells["POGeneratedDate"].Value.ToString() + "' by stores. \n Please contact Mr.' " + dgpolist.CurrentRow.Cells["POGeneratedBy"].Value.ToString().ToUpper() + " '  ", "Information", 0, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("The slected'" + dgpolist.CurrentRow.Cells["DBOMNo"].Value.ToString() + "' already genarated on '" + dgpolist.CurrentRow.Cells["POGeneratedDate"].Value.ToString() + "' by stores. ", "Information", 0, MessageBoxIcon.Information);
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("CustomerSearchForm_dgCustomerList_DoubleClick " + ex.Message, "Error", 0, MessageBoxIcon.Error);
            }
        }

        private void txtPODelayDays_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtPODelayDays.Text.Length > 0)
            {
                fnRowFilter(7, txtPODelayDays.Text);
            }
            else
            {
                dgpolist.DataSource = bsItemList;
                Datagridviewcolor();
            }
        }

        private void txtPODelayDays_Enter(object sender, EventArgs e)
        {
            txtPODelayDays.Text = string.Empty;
            dgpolist.DataSource = bsItemList;
            Datagridviewcolor();
        }

        private void Datagridviewcolor()
        {
            int NewPO = 0, POComingToday = 0, POcomingthisweek = 0, PONextWeek = 0, POLate = 0;
            foreach (DataGridViewRow row in dgpolist.Rows)
            {
                if (row.Cells[1].Value.ToString() == "")
                {
                    NewPO++;
                }
                else if (Convert.ToDouble(row.Cells[1].Value) == 0)
                {
                    dgpolist.Rows[dgpolist.Rows.IndexOf(row)].Cells[1].Style.BackColor = Color.LightGreen;
                    POComingToday++;
                }
                else if (Convert.ToDouble(row.Cells[1].Value) > 0)
                {
                    dgpolist.Rows[dgpolist.Rows.IndexOf(row)].Cells[1].Style.BackColor = Color.Red;
                    POLate++;
                }
                else if (Convert.ToDouble(row.Cells[1].Value) > -8)
                {
                    dgpolist.Rows[dgpolist.Rows.IndexOf(row)].Cells[1].Style.BackColor = Color.GreenYellow;
                    POcomingthisweek++;
                }
                else if (Convert.ToDouble(row.Cells[1].Value) < -7)
                {
                    dgpolist.Rows[dgpolist.Rows.IndexOf(row)].Cells[1].Style.BackColor = Color.Gold;
                    PONextWeek++;
                }
            }

            btnNewPO.Text = NewPO.ToString();
            btnComingToday.Text = POComingToday.ToString();
            btnArrivinginaweek.Text = POcomingthisweek.ToString();
            btnArrivinglaterthanweek.Text = PONextWeek.ToString();
            btnLate.Text = POLate.ToString();
            btnTotal.Text = (NewPO + POComingToday + POcomingthisweek + PONextWeek + POLate).ToString();
        }

        #region Excel Merge Function
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlMedium, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignCentre":
                    {
                        CELLS.VerticalAlignment = EXCEL.XlVAlign.xlVAlignCenter;
                        break;
                    }
                case "HAlignCentre":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                        break;
                    }
                case "Left":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignLeft;
                        break;
                    }
                case "Right":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                        break;
                    }
                case "Bold":
                    {
                        CELLS.Font.Bold = true;
                        break;
                    }
                case "GridLines":
                    {
                        CELLS.Borders.Color = System.Drawing.Color.Black;
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }

                default:
                    {
                        break;
                    }
            }

        }
        #endregion

        private void btnExcelExceport_Click(object sender, EventArgs e)
        {
           // MessageBox.Show("The export fuction is called!");
            int iRowIndex = 1;
            string ExcelFolderPath;
            string FileFullPath;
            EXCEL.Workbook NewWorkBook;
            EXCEL.Worksheet NewWorkSheet;
            EXCEL.Application ExcelApp;
            EXCEL.Range CELLS, cell1, cell2;
            object misValue;
            // dtPolist = dvPOViewList.ToTable();

            // Add this code after you assign dtIndentItems
            

            if (dtExcelTable.Rows.Count > 0)
            {
                ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\";
                FileFullPath = "PO Pending List" + "--" + DateTime.Now.ToString("dd/MM/yyyy hh/mm/ss") + ".xls";
                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);
                ExcelApp = new EXCEL.Application();
                misValue = System.Reflection.Missing.Value;
                try
                {
                    if (ExcelApp == null)
                        MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                    NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                    NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                    if (NewWorkSheet == null)
                        MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                    else
                        NewWorkSheet.Name = "PO Pending List";
                    // Select the Excel cells, in the range c1 to c7 in the worksheet for cell access check.
                    EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                    if (RANGE == null)
                        MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                    NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlWorkbookNormal, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                    CELLS = NewWorkSheet.Cells;

                    // dtIndentItems = DAL.fnIndentExcel(cmbIndentNo.Text, null).Tables[0];

                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);

                    NewWorkSheet.Cells[iRowIndex, 1] = "Po Pending List";
                    iRowIndex++;
                    iRowIndex++;
                    iRowIndex++;

                    if (dtExcelTable.Rows.Count > 0)
                    {
                        object[,] rawData = new object[dtExcelTable.Rows.Count + 1, dtExcelTable.Columns.Count];
                        for (int col = 0; col < dtExcelTable.Columns.Count; col++)
                        {
                            rawData[0, col] = dtExcelTable.Columns[col].ColumnName;
                        }
                        for (int row = 0; row < dtExcelTable.Rows.Count; row++)
                        {
                            for (int col = 0; col < dtExcelTable.Columns.Count; col++)
                            {
                                rawData[row + 1, col] = dtExcelTable.Rows[row].ItemArray[col];
                            }
                        }
                        string excelRange = string.Empty;
                        string finalColLetter = string.Empty;
                        string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        int colCharsetLen = colCharset.Length;

                        if (dtExcelTable.Columns.Count > colCharsetLen)
                        {
                            finalColLetter = colCharset.Substring(
                                (dtExcelTable.Columns.Count - 1) / colCharsetLen - 1, 1);
                        }

                        finalColLetter += colCharset.Substring((dtExcelTable.Columns.Count - 1) % colCharsetLen, 1);
                        excelRange = string.Format("A6:{0}{1}", finalColLetter, dtExcelTable.Rows.Count + 6);

                        NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                    }


                    NewWorkSheet.Range["A1:T6"].Cells.Font.Bold = true;
                    NewWorkSheet.Range["A1:B2"].Cells.Font.Size = 16;
                    fnDateFormatstring(NewWorkSheet, "C1", "C9999");
                    fnDateFormatstring(NewWorkSheet, "I1", "I9999");
                    fnDateFormatstring(NewWorkSheet, "K1", "K9999");
                    fnDateFormatstring(NewWorkSheet, "T1", "T9999");


                    NewWorkSheet.Rows.AutoFit();
                    NewWorkSheet.Columns.AutoFit();
                    NewWorkSheet.Rows.RowHeight = "18";

                    NewWorkSheet.Columns[5].ColumnWidth = 50;
                    NewWorkSheet.Columns[5].WrapText = true;
                    NewWorkSheet.Columns[7].ColumnWidth = 50;
                    NewWorkSheet.Columns[7].WrapText = true;
                    NewWorkSheet.Columns[13].ColumnWidth = 50;
                    NewWorkSheet.Columns[13].WrapText = true;
                    NewWorkSheet.Columns[21].ColumnWidth = 50;
                    NewWorkSheet.Columns[21].WrapText = true;


                    NewWorkSheet.PageSetup.PrintArea = "A1:U" + (dtExcelTable.Rows.Count + iRowIndex + 12) + "";
                    NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                    NewWorkSheet.PageSetup.PrintNotes = true;
                    NewWorkSheet.PageSetup.Zoom = 100;
                    NewWorkSheet.PageSetup.FitToPagesTall = 1;
                    NewWorkSheet.PageSetup.FitToPagesWide = 1;
                    NewWorkSheet.PageSetup.LeftMargin = 0;
                    NewWorkSheet.PageSetup.RightMargin = 0;
                    NewWorkSheet.PageSetup.TopMargin = 0.75;
                    NewWorkSheet.PageSetup.BottomMargin = 0.75;
                    NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                    NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                    string _stLOGO = ("C:\\Databasepath\\Bisslogo.jpg");
                    EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 7];

                    Image oImage = Image.FromFile(_stLOGO);
                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    NewWorkSheet.Paste(oRange, _stLOGO);

                    NewWorkBook.Save();
                    ExcelApp.Visible = true;
                    System.Threading.Thread.Sleep(1000);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                    {
                        GetProcess.Kill();
                    }
                }
            }
            else
                MessageBox.Show("No items to save", "Error", 0, MessageBoxIcon.Question);
        }
        public void fnDateFormatstring(EXCEL.Worksheet worksheet, string column1, string column2)
        {
            Microsoft.Office.Interop.Excel.Range date = worksheet.get_Range(column1, column2);
            date.EntireColumn.NumberFormat = "DD/MM/YYYY";
        }

        private void btnrecentlist_Click(object sender, EventArgs e)
        {
            dtpFromDate.Format = DateTimePickerFormat.Custom;
            dtpFromDate.CustomFormat = "yyyy-MM-dd";
            dtpToDate.Format = DateTimePickerFormat.Custom;
            dtpToDate.CustomFormat = "yyyy-MM-dd";
            dtPolist = DAL.fnPOlistforview(1,dtpFromDate.Text, dtpToDate.Text).Tables[0];
            dtExcelTable = new DataTable();
            dtpFromDate.Format = DateTimePickerFormat.Custom;
            dtpFromDate.CustomFormat = "dd-MM-yyyy";
            dtpToDate.Format = DateTimePickerFormat.Custom;
            dtpToDate.CustomFormat = "dd-MM-yyyy";

            bsItemList.DataSource = dtPolist;

            dgpolist.AutoGenerateColumns = false;
            dtExcelTable = dtPolist.Copy();
            dgpolist.DataSource = bsItemList;
            Datagridviewcolor();
        }

        private void btnloadcompletePOlist_Click(object sender, EventArgs e)
        {
            dtExcelTable = new DataTable();
            dtPolist = DAL.fnPOlistforview(0,null, null).Tables[0];

            dgpolist.AutoGenerateColumns = false;
            dgpolist.DataSource = dtPolist;
            dtExcelTable = dtPolist.Copy();
            bsItemList.DataSource = dtPolist;
            Datagridviewcolor();
        }
        DataTable PONoDetails = new DataTable();
        private void dgpolist_Click(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(login.GetUserDetails[16]) == true)
            {
                if (dgpolist.Rows.Count > 0)
                {
                    btnUpdateOADate.Enabled = true;
                    PONoDetails = DAL.purchaseOrderCost(2, dgpolist.CurrentRow.Cells["DBOMNO"].Value.ToString()).Tables[0];

                    if (PONoDetails.Rows.Count > 0)
                    {
                        if (!string.IsNullOrEmpty(PONoDetails.Rows[0]["PODeliveryDate"].ToString()))
                        {
                            dtpdelivery.Value = Convert.ToDateTime(PONoDetails.Rows[0]["PODeliveryDate"]);
                        }
                        if (!string.IsNullOrEmpty(PONoDetails.Rows[0]["OADate"].ToString()))
                        {
                            dtpOADate.Value = Convert.ToDateTime(PONoDetails.Rows[0]["OADate"]);
                        }
                        pnOADate.Visible = true;
                    }
                }
            }
        }

        private void btnUpdateOADate_Click(object sender, EventArgs e)
        {
            if (bOADate)
            {
                GLobalClass.iSuccess = DAL.purchaseOrderApproval(8, dgpolist.CurrentRow.Cells["DBOMNO"].Value.ToString(), dtpOADate.Text, "", "");
                MessageBox.Show("OA date updated for PO number " + dgpolist.CurrentRow.Cells["DBOMNO"].Value.ToString() + "", "Success", 0, MessageBoxIcon.Information);
                btnUpdateOADate.Enabled = false;
            }
            else
            {
                MessageBox.Show("Select OA date to Update", "Error", 0, MessageBoxIcon.Error);
            }
        }
        bool bOADate = false;
        private void dtpOADate_ValueChanged(object sender, EventArgs e)
        {
            bOADate = true;
        }

    }
}
