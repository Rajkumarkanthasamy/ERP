﻿namespace Erp_Project_With_Buttons.Purchase_Order
{
    partial class frmPOTrackBOM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPOTrackBOM));
            this.dgItemOrProductList = new System.Windows.Forms.DataGridView();
            this.btnProjectView = new System.Windows.Forms.Button();
            this.txtProjectName = new System.Windows.Forms.Label();
            this.lblProjectName = new System.Windows.Forms.Label();
            this.cmbProjectCode = new System.Windows.Forms.ComboBox();
            this.lblProjectCode = new System.Windows.Forms.Label();
            this.dgBOMList = new System.Windows.Forms.DataGridView();
            this.lblItemcodeorName = new System.Windows.Forms.Label();
            this.txtItemSearch = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.SLNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PProductCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Version = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IProductType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AvailableQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uBOMQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IssuedQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.POQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GeneratedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DeliveryDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PreparedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VendorName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgItemOrProductList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgBOMList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dgItemOrProductList
            // 
            this.dgItemOrProductList.AllowUserToAddRows = false;
            this.dgItemOrProductList.AllowUserToDeleteRows = false;
            this.dgItemOrProductList.AllowUserToResizeRows = false;
            this.dgItemOrProductList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgItemOrProductList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgItemOrProductList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgItemOrProductList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgItemOrProductList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgItemOrProductList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SLNO,
            this.PProductCode,
            this.ProductName,
            this.Version,
            this.Quantity});
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgItemOrProductList.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgItemOrProductList.EnableHeadersVisualStyles = false;
            this.dgItemOrProductList.Location = new System.Drawing.Point(12, 70);
            this.dgItemOrProductList.MultiSelect = false;
            this.dgItemOrProductList.Name = "dgItemOrProductList";
            this.dgItemOrProductList.RowHeadersVisible = false;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgItemOrProductList.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dgItemOrProductList.Size = new System.Drawing.Size(562, 256);
            this.dgItemOrProductList.TabIndex = 62;
            this.dgItemOrProductList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgItemOrProductList_CellClick);
            // 
            // btnProjectView
            // 
            this.btnProjectView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnProjectView.Location = new System.Drawing.Point(463, 4);
            this.btnProjectView.Name = "btnProjectView";
            this.btnProjectView.Size = new System.Drawing.Size(24, 29);
            this.btnProjectView.TabIndex = 77;
            this.btnProjectView.Text = "....";
            this.btnProjectView.UseVisualStyleBackColor = false;
            this.btnProjectView.Click += new System.EventHandler(this.btnProjectView_Click);
            // 
            // txtProjectName
            // 
            this.txtProjectName.AutoSize = true;
            this.txtProjectName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProjectName.ForeColor = System.Drawing.Color.Black;
            this.txtProjectName.Location = new System.Drawing.Point(125, 37);
            this.txtProjectName.Name = "txtProjectName";
            this.txtProjectName.Size = new System.Drawing.Size(12, 18);
            this.txtProjectName.TabIndex = 75;
            this.txtProjectName.Text = ".";
            // 
            // lblProjectName
            // 
            this.lblProjectName.AutoSize = true;
            this.lblProjectName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectName.ForeColor = System.Drawing.Color.Black;
            this.lblProjectName.Location = new System.Drawing.Point(31, 37);
            this.lblProjectName.Name = "lblProjectName";
            this.lblProjectName.Size = new System.Drawing.Size(96, 18);
            this.lblProjectName.TabIndex = 76;
            this.lblProjectName.Text = "Project Name:";
            // 
            // cmbProjectCode
            // 
            this.cmbProjectCode.DropDownHeight = 130;
            this.cmbProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProjectCode.FormattingEnabled = true;
            this.cmbProjectCode.IntegralHeight = false;
            this.cmbProjectCode.Location = new System.Drawing.Point(127, 6);
            this.cmbProjectCode.Name = "cmbProjectCode";
            this.cmbProjectCode.Size = new System.Drawing.Size(330, 26);
            this.cmbProjectCode.TabIndex = 74;
            this.cmbProjectCode.SelectedIndexChanged += new System.EventHandler(this.cmbProjectCode_SelectedIndexChanged);
            // 
            // lblProjectCode
            // 
            this.lblProjectCode.AutoSize = true;
            this.lblProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectCode.ForeColor = System.Drawing.Color.Black;
            this.lblProjectCode.Location = new System.Drawing.Point(31, 9);
            this.lblProjectCode.Name = "lblProjectCode";
            this.lblProjectCode.Size = new System.Drawing.Size(98, 18);
            this.lblProjectCode.TabIndex = 73;
            this.lblProjectCode.Text = "Project Code*:";
            // 
            // dgBOMList
            // 
            this.dgBOMList.AllowUserToAddRows = false;
            this.dgBOMList.AllowUserToDeleteRows = false;
            this.dgBOMList.AllowUserToResizeRows = false;
            this.dgBOMList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgBOMList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgBOMList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgBOMList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgBOMList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgBOMList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.IProductType,
            this.uItemCode,
            this.uItemDescription,
            this.AvailableQty,
            this.uBOMQty,
            this.IssuedQuantity,
            this.POQty});
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgBOMList.DefaultCellStyle = dataGridViewCellStyle12;
            this.dgBOMList.EnableHeadersVisualStyles = false;
            this.dgBOMList.Location = new System.Drawing.Point(598, 70);
            this.dgBOMList.MultiSelect = false;
            this.dgBOMList.Name = "dgBOMList";
            this.dgBOMList.RowHeadersVisible = false;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgBOMList.RowsDefaultCellStyle = dataGridViewCellStyle13;
            this.dgBOMList.Size = new System.Drawing.Size(718, 256);
            this.dgBOMList.TabIndex = 78;
            this.dgBOMList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgBOMList_CellClick);
            // 
            // lblItemcodeorName
            // 
            this.lblItemcodeorName.AutoSize = true;
            this.lblItemcodeorName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemcodeorName.ForeColor = System.Drawing.Color.Black;
            this.lblItemcodeorName.Location = new System.Drawing.Point(711, 33);
            this.lblItemcodeorName.Name = "lblItemcodeorName";
            this.lblItemcodeorName.Size = new System.Drawing.Size(98, 19);
            this.lblItemcodeorName.TabIndex = 114;
            this.lblItemcodeorName.Text = "Search Item :";
            // 
            // txtItemSearch
            // 
            this.txtItemSearch.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtItemSearch.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemSearch.Location = new System.Drawing.Point(812, 33);
            this.txtItemSearch.Name = "txtItemSearch";
            this.txtItemSearch.Size = new System.Drawing.Size(340, 22);
            this.txtItemSearch.TabIndex = 113;
            this.txtItemSearch.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemSearch_KeyUp);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3,
            this.GeneratedDate,
            this.DeliveryDate,
            this.PreparedBy,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.VendorName});
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle19;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.Location = new System.Drawing.Point(12, 332);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle20;
            this.dataGridView1.Size = new System.Drawing.Size(1304, 349);
            this.dataGridView1.TabIndex = 115;
            // 
            // SLNO
            // 
            this.SLNO.DataPropertyName = "ID";
            this.SLNO.HeaderText = "SlNo";
            this.SLNO.Name = "SLNO";
            this.SLNO.ReadOnly = true;
            this.SLNO.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SLNO.Visible = false;
            this.SLNO.Width = 47;
            // 
            // PProductCode
            // 
            this.PProductCode.DataPropertyName = "ProductCode";
            this.PProductCode.HeaderText = "ProductCode";
            this.PProductCode.Name = "PProductCode";
            this.PProductCode.ReadOnly = true;
            this.PProductCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PProductCode.Width = 104;
            // 
            // ProductName
            // 
            this.ProductName.DataPropertyName = "ProductName";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ProductName.DefaultCellStyle = dataGridViewCellStyle2;
            this.ProductName.HeaderText = "Product Name";
            this.ProductName.Name = "ProductName";
            this.ProductName.ReadOnly = true;
            this.ProductName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductName.Width = 114;
            // 
            // Version
            // 
            this.Version.DataPropertyName = "Version";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Version.DefaultCellStyle = dataGridViewCellStyle3;
            this.Version.HeaderText = "Version";
            this.Version.Name = "Version";
            this.Version.ReadOnly = true;
            this.Version.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Version.Width = 65;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "Quantity";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Quantity.DefaultCellStyle = dataGridViewCellStyle4;
            this.Quantity.HeaderText = "Qty";
            this.Quantity.Name = "Quantity";
            this.Quantity.ReadOnly = true;
            this.Quantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Quantity.Width = 40;
            // 
            // ID
            // 
            this.ID.DataPropertyName = "ID";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ID.Visible = false;
            this.ID.Width = 29;
            // 
            // IProductType
            // 
            this.IProductType.DataPropertyName = "ProductType";
            this.IProductType.HeaderText = "ProductType";
            this.IProductType.Name = "IProductType";
            this.IProductType.ReadOnly = true;
            this.IProductType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IProductType.Width = 103;
            // 
            // uItemCode
            // 
            this.uItemCode.DataPropertyName = "ItemName";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.uItemCode.DefaultCellStyle = dataGridViewCellStyle8;
            this.uItemCode.HeaderText = "Item Code";
            this.uItemCode.Name = "uItemCode";
            this.uItemCode.ReadOnly = true;
            this.uItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.uItemCode.Width = 84;
            // 
            // uItemDescription
            // 
            this.uItemDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.uItemDescription.DataPropertyName = "ItemDescription";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.uItemDescription.DefaultCellStyle = dataGridViewCellStyle9;
            this.uItemDescription.HeaderText = "Item Description";
            this.uItemDescription.Name = "uItemDescription";
            this.uItemDescription.ReadOnly = true;
            this.uItemDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.uItemDescription.Width = 125;
            // 
            // AvailableQty
            // 
            this.AvailableQty.DataPropertyName = "AvailableQty";
            this.AvailableQty.HeaderText = "Avl Qty";
            this.AvailableQty.Name = "AvailableQty";
            this.AvailableQty.ReadOnly = true;
            this.AvailableQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.AvailableQty.Width = 59;
            // 
            // uBOMQty
            // 
            this.uBOMQty.DataPropertyName = "Quantity";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.uBOMQty.DefaultCellStyle = dataGridViewCellStyle10;
            this.uBOMQty.HeaderText = "BOM Qty";
            this.uBOMQty.Name = "uBOMQty";
            this.uBOMQty.ReadOnly = true;
            this.uBOMQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.uBOMQty.Width = 70;
            // 
            // IssuedQuantity
            // 
            this.IssuedQuantity.DataPropertyName = "IssuedQuantity";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.IssuedQuantity.DefaultCellStyle = dataGridViewCellStyle11;
            this.IssuedQuantity.HeaderText = "Issued Qty";
            this.IssuedQuantity.Name = "IssuedQuantity";
            this.IssuedQuantity.ReadOnly = true;
            this.IssuedQuantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IssuedQuantity.Width = 77;
            // 
            // POQty
            // 
            this.POQty.DataPropertyName = "POQty";
            this.POQty.HeaderText = "PO Qty";
            this.POQty.Name = "POQty";
            this.POQty.ReadOnly = true;
            this.POQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.POQty.Width = 58;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "PO/WO/Indent No";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle15;
            this.dataGridViewTextBoxColumn3.HeaderText = "PO/WO/Indent No";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn3.Width = 130;
            // 
            // GeneratedDate
            // 
            this.GeneratedDate.DataPropertyName = "GeneratedDate";
            this.GeneratedDate.HeaderText = "GeneratedDate";
            this.GeneratedDate.Name = "GeneratedDate";
            this.GeneratedDate.ReadOnly = true;
            this.GeneratedDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.GeneratedDate.Width = 119;
            // 
            // DeliveryDate
            // 
            this.DeliveryDate.DataPropertyName = "DeliveryDate";
            this.DeliveryDate.HeaderText = "DeliveryDate";
            this.DeliveryDate.Name = "DeliveryDate";
            this.DeliveryDate.ReadOnly = true;
            this.DeliveryDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DeliveryDate.Width = 103;
            // 
            // PreparedBy
            // 
            this.PreparedBy.DataPropertyName = "PreparedBy";
            this.PreparedBy.HeaderText = "PreparedBy";
            this.PreparedBy.Name = "PreparedBy";
            this.PreparedBy.ReadOnly = true;
            this.PreparedBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PreparedBy.Width = 95;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn4.DataPropertyName = "IPOrderQty";
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle16;
            this.dataGridViewTextBoxColumn4.HeaderText = "Order Qty";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn4.Width = 125;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "ProjectCode";
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle17;
            this.dataGridViewTextBoxColumn5.HeaderText = "ProjectCode";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn5.Width = 98;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "ProjectDescription";
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn6.DefaultCellStyle = dataGridViewCellStyle18;
            this.dataGridViewTextBoxColumn6.HeaderText = "ProjectDescription";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn6.Width = 141;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Customer";
            this.dataGridViewTextBoxColumn7.HeaderText = "Customer";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn7.Width = 80;
            // 
            // VendorName
            // 
            this.VendorName.DataPropertyName = "VendorName";
            this.VendorName.HeaderText = "VendorName";
            this.VendorName.Name = "VendorName";
            this.VendorName.ReadOnly = true;
            this.VendorName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.VendorName.Width = 104;
            // 
            // frmPOTrackBOM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1328, 686);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lblItemcodeorName);
            this.Controls.Add(this.txtItemSearch);
            this.Controls.Add(this.dgBOMList);
            this.Controls.Add(this.btnProjectView);
            this.Controls.Add(this.txtProjectName);
            this.Controls.Add(this.lblProjectName);
            this.Controls.Add(this.cmbProjectCode);
            this.Controls.Add(this.lblProjectCode);
            this.Controls.Add(this.dgItemOrProductList);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmPOTrackBOM";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PO Track BOM";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmPOTrackBOM_FormClosing);
            this.Load += new System.EventHandler(this.frmPOTrackBOM_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgItemOrProductList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgBOMList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgItemOrProductList;
        private System.Windows.Forms.Button btnProjectView;
        private System.Windows.Forms.Label txtProjectName;
        private System.Windows.Forms.Label lblProjectName;
        private System.Windows.Forms.ComboBox cmbProjectCode;
        private System.Windows.Forms.Label lblProjectCode;
        private System.Windows.Forms.DataGridView dgBOMList;
        private System.Windows.Forms.Label lblItemcodeorName;
        private System.Windows.Forms.TextBox txtItemSearch;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SLNO;
        private System.Windows.Forms.DataGridViewTextBoxColumn PProductCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Version;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn IProductType;
        private System.Windows.Forms.DataGridViewTextBoxColumn uItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn uItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn AvailableQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn uBOMQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssuedQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn POQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn GeneratedDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn DeliveryDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn PreparedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn VendorName;
    }
}