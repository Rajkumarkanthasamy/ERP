﻿
namespace Erp_Project_With_Buttons.Purchase_Order
{
    partial class CurrencyRate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CurrencyRate));
            this.textBoxrate = new System.Windows.Forms.TextBox();
            this.comboxcur = new System.Windows.Forms.ComboBox();
            this.labelcurrency = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSavePegRate = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBoxrate
            // 
            this.textBoxrate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxrate.Location = new System.Drawing.Point(140, 123);
            this.textBoxrate.Name = "textBoxrate";
            this.textBoxrate.Size = new System.Drawing.Size(162, 27);
            this.textBoxrate.TabIndex = 0;
            this.textBoxrate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxrate_KeyPress);
            // 
            // comboxcur
            // 
            this.comboxcur.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboxcur.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboxcur.FormattingEnabled = true;
            this.comboxcur.Items.AddRange(new object[] {
            "Rupee - ₹",
            "EURO - €",
            "USD - $"});
            this.comboxcur.Location = new System.Drawing.Point(140, 72);
            this.comboxcur.Name = "comboxcur";
            this.comboxcur.Size = new System.Drawing.Size(162, 27);
            this.comboxcur.TabIndex = 1;
            // 
            // labelcurrency
            // 
            this.labelcurrency.AutoSize = true;
            this.labelcurrency.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelcurrency.Location = new System.Drawing.Point(56, 72);
            this.labelcurrency.Name = "labelcurrency";
            this.labelcurrency.Size = new System.Drawing.Size(78, 19);
            this.labelcurrency.TabIndex = 4;
            this.labelcurrency.Text = "Currency :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(86, 126);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 19);
            this.label2.TabIndex = 5;
            this.label2.Text = "Rate :";
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnExit.Location = new System.Drawing.Point(259, 193);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(119, 31);
            this.btnExit.TabIndex = 197;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSavePegRate
            // 
            this.btnSavePegRate.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnSavePegRate.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSavePegRate.Location = new System.Drawing.Point(97, 193);
            this.btnSavePegRate.Name = "btnSavePegRate";
            this.btnSavePegRate.Size = new System.Drawing.Size(129, 31);
            this.btnSavePegRate.TabIndex = 196;
            this.btnSavePegRate.Text = "Save Rate";
            this.btnSavePegRate.UseVisualStyleBackColor = false;
            this.btnSavePegRate.Click += new System.EventHandler(this.btnSavePegRate_Click);
            // 
            // CurrencyRate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(689, 450);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnSavePegRate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.labelcurrency);
            this.Controls.Add(this.comboxcur);
            this.Controls.Add(this.textBoxrate);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CurrencyRate";
            this.Text = "CurrencyRate";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CurrencyRate_FormClosing);
            this.Load += new System.EventHandler(this.CurrencyRate_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxrate;
        private System.Windows.Forms.ComboBox comboxcur;
        private System.Windows.Forms.Label labelcurrency;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSavePegRate;
    }
}