﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Purchase_Order
{
    public partial class CurrencyRate : Form
    {
        Global GLobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        public CurrencyRate()
        {
            InitializeComponent();
        }

        private void CurrencyRate_Load(object sender, EventArgs e)
        {

        }
        DataTable dtPegRate = new DataTable();
        private void btnSavePegRate_Click(object sender, EventArgs e)
        {
            if(!string.IsNullOrEmpty(comboxcur.Text) && !string.IsNullOrEmpty(textBoxrate.Text))
                {
                          
                  GLobalClass.iSuccess = DAL.fnAddPegRate(4,Math.Round(Convert.ToDouble(1/Convert.ToDouble(textBoxrate.Text)),3), comboxcur.Text,0);
                   MessageBox.Show("PegRate added successfully.", "Success", 0, MessageBoxIcon.Information);
                         
                }
        }

        private void textBoxrate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void CurrencyRate_FormClosing(object sender, FormClosingEventArgs e)
        {

            frmPOHome POHome = new frmPOHome();
                this.Hide();
            POHome.Show();
        
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            frmPOHome POHome = new frmPOHome();
            this.Hide();
            POHome.Show();
        }
    }
}
