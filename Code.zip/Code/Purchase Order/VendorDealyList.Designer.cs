﻿
namespace Erp_Project_With_Buttons.Purchase_Order
{
    partial class VendorDealyList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VendorDealyList));
            this.btnArrivinglaterthanweek = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.btnLate = new System.Windows.Forms.Button();
            this.btnComingToday = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dgpolist = new System.Windows.Forms.DataGridView();
            this.btnrecentlist = new System.Windows.Forms.Button();
            this.lblFromdate = new System.Windows.Forms.Label();
            this.lblToDate = new System.Windows.Forms.Label();
            this.dtpFromDate = new System.Windows.Forms.DateTimePicker();
            this.dtpToDate = new System.Windows.Forms.DateTimePicker();
            this.btnExcelExceport = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgpolist)).BeginInit();
            this.SuspendLayout();
            // 
            // btnArrivinglaterthanweek
            // 
            this.btnArrivinglaterthanweek.BackColor = System.Drawing.Color.Gold;
            this.btnArrivinglaterthanweek.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnArrivinglaterthanweek.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnArrivinglaterthanweek.ForeColor = System.Drawing.Color.Black;
            this.btnArrivinglaterthanweek.Location = new System.Drawing.Point(311, 13);
            this.btnArrivinglaterthanweek.Margin = new System.Windows.Forms.Padding(4);
            this.btnArrivinglaterthanweek.Name = "btnArrivinglaterthanweek";
            this.btnArrivinglaterthanweek.Size = new System.Drawing.Size(54, 32);
            this.btnArrivinglaterthanweek.TabIndex = 197;
            this.btnArrivinglaterthanweek.UseVisualStyleBackColor = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(183, 18);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(120, 19);
            this.label8.TabIndex = 196;
            this.label8.Text = "Total Partial GIN";
            // 
            // btnLate
            // 
            this.btnLate.BackColor = System.Drawing.Color.Red;
            this.btnLate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLate.ForeColor = System.Drawing.Color.Black;
            this.btnLate.Location = new System.Drawing.Point(555, 11);
            this.btnLate.Margin = new System.Windows.Forms.Padding(4);
            this.btnLate.Name = "btnLate";
            this.btnLate.Size = new System.Drawing.Size(62, 32);
            this.btnLate.TabIndex = 192;
            this.btnLate.UseVisualStyleBackColor = false;
            // 
            // btnComingToday
            // 
            this.btnComingToday.BackColor = System.Drawing.Color.LightGreen;
            this.btnComingToday.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnComingToday.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnComingToday.ForeColor = System.Drawing.Color.Black;
            this.btnComingToday.Location = new System.Drawing.Point(88, 13);
            this.btnComingToday.Margin = new System.Windows.Forms.Padding(4);
            this.btnComingToday.Name = "btnComingToday";
            this.btnComingToday.Size = new System.Drawing.Size(57, 32);
            this.btnComingToday.TabIndex = 191;
            this.btnComingToday.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(424, 18);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 19);
            this.label3.TabIndex = 181;
            this.label3.Text = "Total Pending";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(14, 17);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 19);
            this.label6.TabIndex = 180;
            this.label6.Text = "Total GIN";
            // 
            // dgpolist
            // 
            this.dgpolist.AllowUserToAddRows = false;
            this.dgpolist.AllowUserToDeleteRows = false;
            this.dgpolist.AllowUserToResizeRows = false;
            this.dgpolist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgpolist.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgpolist.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgpolist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgpolist.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgpolist.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgpolist.EnableHeadersVisualStyles = false;
            this.dgpolist.Location = new System.Drawing.Point(9, 53);
            this.dgpolist.Margin = new System.Windows.Forms.Padding(4);
            this.dgpolist.MultiSelect = false;
            this.dgpolist.Name = "dgpolist";
            this.dgpolist.ReadOnly = true;
            this.dgpolist.RowHeadersVisible = false;
            this.dgpolist.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgpolist.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgpolist.Size = new System.Drawing.Size(1270, 556);
            this.dgpolist.TabIndex = 201;
            // 
            // btnrecentlist
            // 
            this.btnrecentlist.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrecentlist.ForeColor = System.Drawing.Color.Indigo;
            this.btnrecentlist.Location = new System.Drawing.Point(1041, 7);
            this.btnrecentlist.Margin = new System.Windows.Forms.Padding(4);
            this.btnrecentlist.Name = "btnrecentlist";
            this.btnrecentlist.Size = new System.Drawing.Size(76, 30);
            this.btnrecentlist.TabIndex = 207;
            this.btnrecentlist.Text = "Search";
            this.btnrecentlist.UseVisualStyleBackColor = true;
            this.btnrecentlist.Click += new System.EventHandler(this.btnrecentlist_Click);
            // 
            // lblFromdate
            // 
            this.lblFromdate.AutoSize = true;
            this.lblFromdate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblFromdate.Location = new System.Drawing.Point(684, 15);
            this.lblFromdate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFromdate.Name = "lblFromdate";
            this.lblFromdate.Size = new System.Drawing.Size(52, 19);
            this.lblFromdate.TabIndex = 203;
            this.lblFromdate.Text = "From :";
            // 
            // lblToDate
            // 
            this.lblToDate.AutoSize = true;
            this.lblToDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblToDate.Location = new System.Drawing.Point(876, 15);
            this.lblToDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblToDate.Name = "lblToDate";
            this.lblToDate.Size = new System.Drawing.Size(33, 19);
            this.lblToDate.TabIndex = 204;
            this.lblToDate.Text = "To :";
            this.lblToDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dtpFromDate
            // 
            this.dtpFromDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.dtpFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFromDate.Location = new System.Drawing.Point(744, 10);
            this.dtpFromDate.Margin = new System.Windows.Forms.Padding(4);
            this.dtpFromDate.Name = "dtpFromDate";
            this.dtpFromDate.Size = new System.Drawing.Size(111, 27);
            this.dtpFromDate.TabIndex = 205;
            // 
            // dtpToDate
            // 
            this.dtpToDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.dtpToDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpToDate.Location = new System.Drawing.Point(917, 10);
            this.dtpToDate.Margin = new System.Windows.Forms.Padding(4);
            this.dtpToDate.Name = "dtpToDate";
            this.dtpToDate.Size = new System.Drawing.Size(116, 27);
            this.dtpToDate.TabIndex = 206;
            // 
            // btnExcelExceport
            // 
            this.btnExcelExceport.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcelExceport.ForeColor = System.Drawing.Color.Indigo;
            this.btnExcelExceport.Location = new System.Drawing.Point(1139, 10);
            this.btnExcelExceport.Margin = new System.Windows.Forms.Padding(4);
            this.btnExcelExceport.Name = "btnExcelExceport";
            this.btnExcelExceport.Size = new System.Drawing.Size(140, 27);
            this.btnExcelExceport.TabIndex = 202;
            this.btnExcelExceport.Text = "Export to Excel";
            this.btnExcelExceport.UseVisualStyleBackColor = true;
            this.btnExcelExceport.Click += new System.EventHandler(this.btnExcelExceport_Click);
            // 
            // VendorDealyList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1292, 622);
            this.Controls.Add(this.btnArrivinglaterthanweek);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btnLate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dgpolist);
            this.Controls.Add(this.btnrecentlist);
            this.Controls.Add(this.lblFromdate);
            this.Controls.Add(this.btnComingToday);
            this.Controls.Add(this.lblToDate);
            this.Controls.Add(this.dtpFromDate);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dtpToDate);
            this.Controls.Add(this.btnExcelExceport);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "VendorDealyList";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Vendor Delay List";
            this.Load += new System.EventHandler(this.VendorDealyList_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgpolist)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnArrivinglaterthanweek;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnLate;
        private System.Windows.Forms.Button btnComingToday;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dgpolist;
        private System.Windows.Forms.Button btnrecentlist;
        private System.Windows.Forms.Label lblFromdate;
        private System.Windows.Forms.Label lblToDate;
        private System.Windows.Forms.DateTimePicker dtpFromDate;
        private System.Windows.Forms.DateTimePicker dtpToDate;
        private System.Windows.Forms.Button btnExcelExceport;
    }
}