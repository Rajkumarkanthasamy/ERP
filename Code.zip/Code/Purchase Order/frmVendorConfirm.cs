﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using Outlook = Microsoft.Office.Interop.Outlook;

namespace Erp_Project_With_Buttons.Purchase_Order
{
    public partial class frmVendorConfirm : Form
    {
        public frmVendorConfirm()
        {
            InitializeComponent();
        }
        frmForm2 frm = new frmForm2();
        Global GLobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        DataTable dtPOlist = new DataTable();
        Purchase_Order.frmPOHome POHome = new frmPOHome();

        private void frmVendorConfirm_Load(object sender, EventArgs e)
        {
            dtPOlist = DAL.purchaseOrderListVendor(0, null).Tables[0];

            foreach (DataRow dr in dtPOlist.Rows)
            {
                if (!cmbPonumber.Items.Contains(dr["DBOMNo"].ToString()))
                    cmbPonumber.Items.Add(dr["DBOMNo"].ToString());
            }
        }
        DataTable DTPOItemList = new DataTable();
        private void cmbPonumber_SelectedIndexChanged(object sender, EventArgs e)
        {
            DTPOItemList = DAL.purchaseOrderListVendor(1, cmbPonumber.Text).Tables[0];

            if (DTPOItemList.Rows.Count > 0)
            {
                txtVendorcode.Text = DTPOItemList.Rows[0]["VendorCode"].ToString() + ", " + DTPOItemList.Rows[0]["GSTCode"].ToString();
                lblVendor.Text = DTPOItemList.Rows[0]["VendorName"].ToString();
                lblprojcode.Text = DTPOItemList.Rows[0]["ProjectCode"].ToString();
                lblprojectdesc.Text = DTPOItemList.Rows[0]["ProjectDescription"].ToString();
                lblpowoby.Text = DTPOItemList.Rows[0]["PreparedBy"].ToString();
                lblcustomername.Text = DTPOItemList.Rows[0]["Customer"].ToString();
                dgvCopyEmail.AutoGenerateColumns = false;
                dgvCopyEmail.DataSource = DTPOItemList;
            }
        }

        private void frmVendorConfirm_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnExit();
        }

        private void fnExit()
        {
            this.Hide();
            POHome.Show();
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (bSentdate && cmbPonumber.SelectedIndex >= 0)
            {
                GLobalClass.iSuccess = DAL.purchaseOrderApproval(11, cmbPonumber.Text, "", login.GetUserDetails[2], dtpSentdate.Text);
                fnAlertMail(lblpowoby.Text, lstusers);
             
                cmbPonumber.Items.RemoveAt(cmbPonumber.SelectedIndex);
                MessageBox.Show("Mail sent to the user '" + lblpowoby.Text + "' successfully!", "E-mail Sent", 0, MessageBoxIcon.Information);
                dgvCopyEmail.DataSource = null;
                cmbPonumber.SelectedIndex = -1;
                bSentdate = false;
                cmbPonumber.Text = "";
            }
            else
            {
                if (!bSentdate)
                {
                    MessageBox.Show("Select PO Sent date of the vendor", "Error", 0, MessageBoxIcon.Error);
                }
                else if (cmbPonumber.SelectedIndex < 0)
                {
                    MessageBox.Show("Select PO number", "Error", 0, MessageBoxIcon.Error);
                }
            }
        }

        public void fnAlertMail(string sUser, ListBox sCC)
        {
            try
            {
                DataTable dtlogindetails = DAL.fnloginemail(sUser.Trim()).Tables[0]; ;
                if (dtlogindetails.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
                    {
                        Outlook.Application oApp = new Outlook.Application();
                        Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);


                        {
                            oMsg.Subject = "" + cmbPonumber.Text + " sent to vendor";
                            oMsg.HTMLBody = " Dear " + sUser.ToUpper() + ", <br /><br /> Purchase order <font color='blue'>" + cmbPonumber.Text + " </font> sent to vendor.<br /> <br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";
                        }

                        Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                        oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                        oRecips.ResolveAll();


                        if (sCC.Items.Count > 0)
                        {
                            Outlook.Recipient oRecip;
                            List<string> sCCRecipsList = new List<string>();
                            foreach (string tempTO in sCC.Items)
                            {
                                if (tempTO != null)
                                    sCCRecipsList.Add(tempTO);
                            }
                            foreach (string t in sCCRecipsList)
                            {
                                oRecip = (Outlook.Recipient)oRecips.Add(t);
                                oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                                oRecip.Resolve();
                            }
                            oMsg.Send();
                            oRecip = null;
                        }
                        else
                        {
                            // Send.
                            oMsg.Send();
                            // Clean up.
                            oRecips = null;
                        }
                        oMsg = null;
                        oApp = null;
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            fnExit();
        }
        bool bSentdate = false;
        private void dtpSentdate_ValueChanged(object sender, EventArgs e)
        {
            bSentdate = true;
        }
    }
}
