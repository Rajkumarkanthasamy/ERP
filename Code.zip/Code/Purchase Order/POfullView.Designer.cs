﻿namespace Erp_Project_With_Buttons.Purchase_Order
{
    partial class POfullView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(POfullView));
            this.gbSearchOptions = new System.Windows.Forms.GroupBox();
            this.btnActivatePO = new System.Windows.Forms.Button();
            this.chkIncludePrice = new System.Windows.Forms.CheckBox();
            this.btnExcelExceport = new System.Windows.Forms.Button();
            this.lblFromdate = new System.Windows.Forms.Label();
            this.lblToDate = new System.Windows.Forms.Label();
            this.dtpFromDate = new System.Windows.Forms.DateTimePicker();
            this.dtpToDate = new System.Windows.Forms.DateTimePicker();
            this.btnrecentlist = new System.Windows.Forms.Button();
            this.lblItemDescription = new System.Windows.Forms.Label();
            this.txtDBOMNo = new System.Windows.Forms.TextBox();
            this.lblItemCode = new System.Windows.Forms.Label();
            this.dgpolist = new System.Windows.Forms.DataGridView();
            this.DBOMNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PreparedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Remarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PreparedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PMName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PMAD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PurchaseCommitee = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FinalizedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FinalizedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PCAD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OMName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OMApprovedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OMApproved = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GMApprovedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.POApproved = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.POGeneratedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.POGeneratedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PODeliverDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VendorName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RequariedQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RemainingQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FinalComment = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FinalStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbSearchOptions.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgpolist)).BeginInit();
            this.SuspendLayout();
            // 
            // gbSearchOptions
            // 
            this.gbSearchOptions.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.gbSearchOptions.Controls.Add(this.btnActivatePO);
            this.gbSearchOptions.Controls.Add(this.chkIncludePrice);
            this.gbSearchOptions.Controls.Add(this.btnExcelExceport);
            this.gbSearchOptions.Controls.Add(this.lblFromdate);
            this.gbSearchOptions.Controls.Add(this.lblToDate);
            this.gbSearchOptions.Controls.Add(this.dtpFromDate);
            this.gbSearchOptions.Controls.Add(this.dtpToDate);
            this.gbSearchOptions.Controls.Add(this.btnrecentlist);
            this.gbSearchOptions.Controls.Add(this.lblItemDescription);
            this.gbSearchOptions.Controls.Add(this.txtDBOMNo);
            this.gbSearchOptions.Controls.Add(this.lblItemCode);
            this.gbSearchOptions.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.gbSearchOptions.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbSearchOptions.Location = new System.Drawing.Point(7, 10);
            this.gbSearchOptions.Name = "gbSearchOptions";
            this.gbSearchOptions.Size = new System.Drawing.Size(1290, 130);
            this.gbSearchOptions.TabIndex = 8;
            this.gbSearchOptions.TabStop = false;
            this.gbSearchOptions.Text = "Search Options";
            // 
            // btnActivatePO
            // 
            this.btnActivatePO.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnActivatePO.ForeColor = System.Drawing.Color.Indigo;
            this.btnActivatePO.Location = new System.Drawing.Point(6, 91);
            this.btnActivatePO.Name = "btnActivatePO";
            this.btnActivatePO.Size = new System.Drawing.Size(174, 31);
            this.btnActivatePO.TabIndex = 120;
            this.btnActivatePO.Text = "Activate PO";
            this.btnActivatePO.UseVisualStyleBackColor = true;
            this.btnActivatePO.Visible = false;
            this.btnActivatePO.Click += new System.EventHandler(this.btnActivatePO_Click);
            // 
            // chkIncludePrice
            // 
            this.chkIncludePrice.AutoSize = true;
            this.chkIncludePrice.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIncludePrice.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.chkIncludePrice.Location = new System.Drawing.Point(835, 65);
            this.chkIncludePrice.Name = "chkIncludePrice";
            this.chkIncludePrice.Size = new System.Drawing.Size(141, 23);
            this.chkIncludePrice.TabIndex = 119;
            this.chkIncludePrice.Text = "Search Exact PO";
            this.chkIncludePrice.UseVisualStyleBackColor = true;
            // 
            // btnExcelExceport
            // 
            this.btnExcelExceport.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcelExceport.ForeColor = System.Drawing.Color.Indigo;
            this.btnExcelExceport.Location = new System.Drawing.Point(1095, 93);
            this.btnExcelExceport.Name = "btnExcelExceport";
            this.btnExcelExceport.Size = new System.Drawing.Size(174, 31);
            this.btnExcelExceport.TabIndex = 22;
            this.btnExcelExceport.Text = "Export to Excel";
            this.btnExcelExceport.UseVisualStyleBackColor = true;
             this.btnExcelExceport.Click += new System.EventHandler(this.btnExcelExceport_Click);
            // this.btnExcelExceport.Click += new System.EventHandler(this.exportThedata);
            // 
            // lblFromdate
            // 
            this.lblFromdate.AutoSize = true;
            this.lblFromdate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblFromdate.Location = new System.Drawing.Point(783, 20);
            this.lblFromdate.Name = "lblFromdate";
            this.lblFromdate.Size = new System.Drawing.Size(52, 19);
            this.lblFromdate.TabIndex = 18;
            this.lblFromdate.Text = "From :";
            // 
            // lblToDate
            // 
            this.lblToDate.AutoSize = true;
            this.lblToDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblToDate.Location = new System.Drawing.Point(931, 19);
            this.lblToDate.Name = "lblToDate";
            this.lblToDate.Size = new System.Drawing.Size(33, 19);
            this.lblToDate.TabIndex = 19;
            this.lblToDate.Text = "To :";
            this.lblToDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dtpFromDate
            // 
            this.dtpFromDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.dtpFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFromDate.Location = new System.Drawing.Point(835, 18);
            this.dtpFromDate.Name = "dtpFromDate";
            this.dtpFromDate.Size = new System.Drawing.Size(94, 27);
            this.dtpFromDate.TabIndex = 20;
            // 
            // dtpToDate
            // 
            this.dtpToDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.dtpToDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpToDate.Location = new System.Drawing.Point(970, 17);
            this.dtpToDate.Name = "dtpToDate";
            this.dtpToDate.Size = new System.Drawing.Size(94, 27);
            this.dtpToDate.TabIndex = 21;
            // 
            // btnrecentlist
            // 
            this.btnrecentlist.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrecentlist.ForeColor = System.Drawing.Color.Indigo;
            this.btnrecentlist.Location = new System.Drawing.Point(1095, 17);
            this.btnrecentlist.Name = "btnrecentlist";
            this.btnrecentlist.Size = new System.Drawing.Size(174, 31);
            this.btnrecentlist.TabIndex = 13;
            this.btnrecentlist.Text = "Load PO List";
            this.btnrecentlist.UseVisualStyleBackColor = true;
            this.btnrecentlist.Click += new System.EventHandler(this.btnrecentlist_Click);
            // 
            // lblItemDescription
            // 
            this.lblItemDescription.AutoSize = true;
            this.lblItemDescription.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemDescription.Location = new System.Drawing.Point(105, 50);
            this.lblItemDescription.Name = "lblItemDescription";
            this.lblItemDescription.Size = new System.Drawing.Size(624, 38);
            this.lblItemDescription.TabIndex = 2;
            this.lblItemDescription.Text = "Search results include : PO Number, Item code, Item Desc, \r\nVendor Name , Vendor " +
    "Code, Project Code, Project Desc and PO Prepared By,GM Approvel";
            // 
            // txtDBOMNo
            // 
            this.txtDBOMNo.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDBOMNo.Location = new System.Drawing.Point(109, 21);
            this.txtDBOMNo.Name = "txtDBOMNo";
            this.txtDBOMNo.Size = new System.Drawing.Size(587, 26);
            this.txtDBOMNo.TabIndex = 1;
            this.txtDBOMNo.TextChanged += new System.EventHandler(this.txtDBOMNo_TextChanged);
            this.txtDBOMNo.Enter += new System.EventHandler(this.txtDBOMNo_Enter);
            this.txtDBOMNo.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtDBOMNo_KeyUp);
            // 
            // lblItemCode
            // 
            this.lblItemCode.AutoSize = true;
            this.lblItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemCode.Location = new System.Drawing.Point(46, 23);
            this.lblItemCode.Name = "lblItemCode";
            this.lblItemCode.Size = new System.Drawing.Size(63, 19);
            this.lblItemCode.TabIndex = 0;
            this.lblItemCode.Text = "Search :";
            // 
            // dgpolist
            // 
            this.dgpolist.AllowUserToAddRows = false;
            this.dgpolist.AllowUserToDeleteRows = false;
            this.dgpolist.AllowUserToResizeRows = false;
            this.dgpolist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgpolist.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgpolist.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgpolist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgpolist.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DBOMNO,
            this.PreparedBy,
            this.Remarks,
            this.PreparedDate,
            this.PMName,
            this.PMAD,
            this.PurchaseCommitee,
            this.FinalizedDate,
            this.FinalizedBy,
            this.PCAD,
            this.OMName,
            this.OMApprovedDate,
            this.OMApproved,
            this.GMApprovedDate,
            this.POApproved,
            this.POGeneratedBy,
            this.POGeneratedDate,
            this.PODeliverDate,
            this.ProjectCode,
            this.ProjectDescription,
            this.VendorName,
            this.ItemCode,
            this.ItemDescription,
            this.RequariedQty,
            this.RemainingQty,
            this.UnitPrice,
            this.Amount,
            this.FinalComment,
            this.FinalStatus});
            this.dgpolist.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgpolist.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgpolist.EnableHeadersVisualStyles = false;
            this.dgpolist.Location = new System.Drawing.Point(7, 146);
            this.dgpolist.MultiSelect = false;
            this.dgpolist.Name = "dgpolist";
            this.dgpolist.ReadOnly = true;
            this.dgpolist.RowHeadersVisible = false;
            this.dgpolist.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgpolist.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgpolist.Size = new System.Drawing.Size(1290, 534);
            this.dgpolist.TabIndex = 9;
            this.dgpolist.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgpolist_CellClick);
            this.dgpolist.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgpolist_CellContentClick);
            // 
            // DBOMNO
            // 
            this.DBOMNO.DataPropertyName = "DBOMNo";
            this.DBOMNO.Frozen = true;
            this.DBOMNO.HeaderText = "PONo";
            this.DBOMNO.Name = "DBOMNO";
            this.DBOMNO.ReadOnly = true;
            this.DBOMNO.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DBOMNO.Width = 55;
            // 
            // PreparedBy
            // 
            this.PreparedBy.DataPropertyName = "PreparedBy";
            this.PreparedBy.HeaderText = "Prepared By";
            this.PreparedBy.Name = "PreparedBy";
            this.PreparedBy.ReadOnly = true;
            this.PreparedBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PreparedBy.Width = 99;
            // 
            // Remarks
            // 
            this.Remarks.DataPropertyName = "Remarks";
            this.Remarks.HeaderText = "Remarks";
            this.Remarks.Name = "Remarks";
            this.Remarks.ReadOnly = true;
            this.Remarks.Width = 92;
            // 
            // PreparedDate
            // 
            this.PreparedDate.DataPropertyName = "POPreparedDate";
            this.PreparedDate.HeaderText = "Date";
            this.PreparedDate.Name = "PreparedDate";
            this.PreparedDate.ReadOnly = true;
            this.PreparedDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PreparedDate.Width = 47;
            // 
            // PMName
            // 
            this.PMName.DataPropertyName = "PMName";
            this.PMName.HeaderText = "Production Manager";
            this.PMName.Name = "PMName";
            this.PMName.ReadOnly = true;
            this.PMName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PMName.Width = 156;
            // 
            // PMAD
            // 
            this.PMAD.DataPropertyName = "PMApprovedDate";
            this.PMAD.HeaderText = "Date";
            this.PMAD.Name = "PMAD";
            this.PMAD.ReadOnly = true;
            this.PMAD.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PMAD.Width = 47;
            // 
            // PurchaseCommitee
            // 
            this.PurchaseCommitee.DataPropertyName = "PurchaseCommitee";
            this.PurchaseCommitee.HeaderText = "Project manager";
            this.PurchaseCommitee.Name = "PurchaseCommitee";
            this.PurchaseCommitee.ReadOnly = true;
            this.PurchaseCommitee.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PurchaseCommitee.Width = 128;
            // 
            // FinalizedDate
            // 
            this.FinalizedDate.DataPropertyName = "FinalizedDate";
            this.FinalizedDate.HeaderText = "Date";
            this.FinalizedDate.Name = "FinalizedDate";
            this.FinalizedDate.ReadOnly = true;
            this.FinalizedDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.FinalizedDate.Width = 47;
            // 
            // FinalizedBy
            // 
            this.FinalizedBy.DataPropertyName = "FinalizedBy";
            this.FinalizedBy.HeaderText = "FinalizedBy";
            this.FinalizedBy.Name = "FinalizedBy";
            this.FinalizedBy.ReadOnly = true;
            this.FinalizedBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.FinalizedBy.Width = 91;
            // 
            // PCAD
            // 
            this.PCAD.DataPropertyName = "PCAuthoriseDate";
            this.PCAD.HeaderText = "Date";
            this.PCAD.Name = "PCAD";
            this.PCAD.ReadOnly = true;
            this.PCAD.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PCAD.Width = 47;
            // 
            // OMName
            // 
            this.OMName.DataPropertyName = "OMName";
            this.OMName.HeaderText = "OMName";
            this.OMName.Name = "OMName";
            this.OMName.ReadOnly = true;
            this.OMName.Width = 99;
            // 
            // OMApprovedDate
            // 
            this.OMApprovedDate.DataPropertyName = "OMApprovedDate";
            this.OMApprovedDate.HeaderText = "OMApprovedDate";
            this.OMApprovedDate.Name = "OMApprovedDate";
            this.OMApprovedDate.ReadOnly = true;
            this.OMApprovedDate.Width = 159;
            // 
            // OMApproved
            // 
            this.OMApproved.DataPropertyName = "OMApproved";
            this.OMApproved.HeaderText = "OMApproved";
            this.OMApproved.Name = "OMApproved";
            this.OMApproved.ReadOnly = true;
            this.OMApproved.Width = 127;
            // 
            // GMApprovedDate
            // 
            this.GMApprovedDate.DataPropertyName = "GMApprovedDate";
            this.GMApprovedDate.HeaderText = "GMApprovedDate";
            this.GMApprovedDate.Name = "GMApprovedDate";
            this.GMApprovedDate.ReadOnly = true;
            this.GMApprovedDate.Width = 158;
            // 
            // POApproved
            // 
            this.POApproved.DataPropertyName = "POApproved";
            this.POApproved.HeaderText = "GM Approved";
            this.POApproved.Name = "POApproved";
            this.POApproved.ReadOnly = true;
            this.POApproved.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.POApproved.Width = 111;
            // 
            // POGeneratedBy
            // 
            this.POGeneratedBy.DataPropertyName = "POGeneratedBy";
            this.POGeneratedBy.HeaderText = "PO Generated By";
            this.POGeneratedBy.Name = "POGeneratedBy";
            this.POGeneratedBy.ReadOnly = true;
            this.POGeneratedBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.POGeneratedBy.Width = 132;
            // 
            // POGeneratedDate
            // 
            this.POGeneratedDate.DataPropertyName = "POGeneratedDate";
            this.POGeneratedDate.HeaderText = "Date";
            this.POGeneratedDate.Name = "POGeneratedDate";
            this.POGeneratedDate.ReadOnly = true;
            this.POGeneratedDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.POGeneratedDate.Width = 47;
            // 
            // PODeliverDate
            // 
            this.PODeliverDate.DataPropertyName = "PODeliveryDate";
            this.PODeliverDate.HeaderText = "Delivery Date";
            this.PODeliverDate.Name = "PODeliverDate";
            this.PODeliverDate.ReadOnly = true;
            this.PODeliverDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PODeliverDate.Width = 107;
            // 
            // ProjectCode
            // 
            this.ProjectCode.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ProjectCode.DataPropertyName = "ProjectCode";
            this.ProjectCode.HeaderText = "Project Code";
            this.ProjectCode.Name = "ProjectCode";
            this.ProjectCode.ReadOnly = true;
            this.ProjectCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectCode.Width = 101;
            // 
            // ProjectDescription
            // 
            this.ProjectDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ProjectDescription.DataPropertyName = "ProjectDescription";
            this.ProjectDescription.HeaderText = "Project Name";
            this.ProjectDescription.Name = "ProjectDescription";
            this.ProjectDescription.ReadOnly = true;
            this.ProjectDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectDescription.Width = 143;
            // 
            // VendorName
            // 
            this.VendorName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.VendorName.DataPropertyName = "VendorName";
            this.VendorName.HeaderText = "Vendor";
            this.VendorName.Name = "VendorName";
            this.VendorName.ReadOnly = true;
            this.VendorName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.VendorName.Width = 103;
            // 
            // ItemCode
            // 
            this.ItemCode.DataPropertyName = "ItemCode";
            this.ItemCode.HeaderText = "Item Code";
            this.ItemCode.Name = "ItemCode";
            this.ItemCode.ReadOnly = true;
            this.ItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemCode.Width = 84;
            // 
            // ItemDescription
            // 
            this.ItemDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ItemDescription.DataPropertyName = "ItemDescription";
            this.ItemDescription.HeaderText = "Item Description";
            this.ItemDescription.Name = "ItemDescription";
            this.ItemDescription.ReadOnly = true;
            this.ItemDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemDescription.Width = 123;
            // 
            // RequariedQty
            // 
            this.RequariedQty.DataPropertyName = "RequariedQty";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.RequariedQty.DefaultCellStyle = dataGridViewCellStyle2;
            this.RequariedQty.HeaderText = "ReqQty";
            this.RequariedQty.Name = "RequariedQty";
            this.RequariedQty.ReadOnly = true;
            this.RequariedQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RequariedQty.Width = 66;
            // 
            // RemainingQty
            // 
            this.RemainingQty.DataPropertyName = "RemainingQty";
            this.RemainingQty.HeaderText = "Rem Qty";
            this.RemainingQty.Name = "RemainingQty";
            this.RemainingQty.ReadOnly = true;
            this.RemainingQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RemainingQty.Width = 74;
            // 
            // UnitPrice
            // 
            this.UnitPrice.DataPropertyName = "UnitPrice";
            this.UnitPrice.HeaderText = "UnitPrice";
            this.UnitPrice.Name = "UnitPrice";
            this.UnitPrice.ReadOnly = true;
            this.UnitPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitPrice.Width = 78;
            // 
            // Amount
            // 
            this.Amount.DataPropertyName = "Amount";
            this.Amount.HeaderText = "Amount";
            this.Amount.Name = "Amount";
            this.Amount.ReadOnly = true;
            this.Amount.Width = 90;
            // 
            // FinalComment
            // 
            this.FinalComment.HeaderText = "FinalComment";
            this.FinalComment.Name = "FinalComment";
            this.FinalComment.ReadOnly = true;
            this.FinalComment.Width = 132;
            // 
            // FinalStatus
            // 
            this.FinalStatus.HeaderText = "FinalStatus";
            this.FinalStatus.Name = "FinalStatus";
            this.FinalStatus.ReadOnly = true;
            this.FinalStatus.Width = 109;
            // 
            // POfullView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1304, 682);
            this.Controls.Add(this.gbSearchOptions);
            this.Controls.Add(this.dgpolist);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "POfullView";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "View Purchase Order";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.POfullView_FormClosing);
            this.Load += new System.EventHandler(this.POfullView_Load);
            this.gbSearchOptions.ResumeLayout(false);
            this.gbSearchOptions.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgpolist)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbSearchOptions;
        private System.Windows.Forms.Label lblItemDescription;
        private System.Windows.Forms.TextBox txtDBOMNo;
        private System.Windows.Forms.Label lblItemCode;
        private System.Windows.Forms.DataGridView dgpolist;
        private System.Windows.Forms.Button btnrecentlist;
        private System.Windows.Forms.Label lblFromdate;
        private System.Windows.Forms.Label lblToDate;
        private System.Windows.Forms.DateTimePicker dtpFromDate;
        private System.Windows.Forms.DateTimePicker dtpToDate;
        private System.Windows.Forms.Button btnExcelExceport;
        private System.Windows.Forms.CheckBox chkIncludePrice;
        private System.Windows.Forms.Button btnActivatePO;
        private System.Windows.Forms.DataGridViewTextBoxColumn DBOMNO;
        private System.Windows.Forms.DataGridViewTextBoxColumn PreparedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn Remarks;
        private System.Windows.Forms.DataGridViewTextBoxColumn PreparedDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn PMName;
        private System.Windows.Forms.DataGridViewTextBoxColumn PMAD;
        private System.Windows.Forms.DataGridViewTextBoxColumn PurchaseCommitee;
        private System.Windows.Forms.DataGridViewTextBoxColumn FinalizedDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn FinalizedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn PCAD;
        private System.Windows.Forms.DataGridViewTextBoxColumn OMName;
        private System.Windows.Forms.DataGridViewTextBoxColumn OMApprovedDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn OMApproved;
        private System.Windows.Forms.DataGridViewTextBoxColumn GMApprovedDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn POApproved;
        private System.Windows.Forms.DataGridViewTextBoxColumn POGeneratedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn POGeneratedDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn PODeliverDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn VendorName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn RequariedQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn RemainingQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn FinalComment;
        private System.Windows.Forms.DataGridViewTextBoxColumn FinalStatus;
    }
}