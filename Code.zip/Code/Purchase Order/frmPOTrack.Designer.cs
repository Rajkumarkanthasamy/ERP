﻿namespace Erp_Project_With_Buttons.Purchase_Order
{
    partial class frmPOTrack
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPOTrack));
            this.dgvPOTrack = new System.Windows.Forms.DataGridView();
            this.gbSearchOptions = new System.Windows.Forms.GroupBox();
            this.oDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtDBOMNo = new System.Windows.Forms.TextBox();
            this.lblItemCode = new System.Windows.Forms.Label();
            this.DBOMNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VendorName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PurchaseType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GINStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.POLateBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FinalRemarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OADate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPOTrack)).BeginInit();
            this.gbSearchOptions.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvPOTrack
            // 
            this.dgvPOTrack.AllowUserToAddRows = false;
            this.dgvPOTrack.AllowUserToDeleteRows = false;
            this.dgvPOTrack.AllowUserToResizeRows = false;
            this.dgvPOTrack.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvPOTrack.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPOTrack.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvPOTrack.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvPOTrack.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DBOMNO,
            this.ProjectDescription,
            this.VendorName,
            this.ItemCode,
            this.ItemDescription,
            this.PurchaseType,
            this.GINStatus,
            this.POLateBy,
            this.FinalRemarks,
            this.OADate});
            this.dgvPOTrack.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPOTrack.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgvPOTrack.EnableHeadersVisualStyles = false;
            this.dgvPOTrack.Location = new System.Drawing.Point(22, 68);
            this.dgvPOTrack.MultiSelect = false;
            this.dgvPOTrack.Name = "dgvPOTrack";
            this.dgvPOTrack.RowHeadersVisible = false;
            this.dgvPOTrack.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvPOTrack.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvPOTrack.Size = new System.Drawing.Size(1298, 530);
            this.dgvPOTrack.TabIndex = 11;
            this.dgvPOTrack.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPOTrack_CellClick);
            this.dgvPOTrack.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPOTrack_CellEndEdit);
            // 
            // gbSearchOptions
            // 
            this.gbSearchOptions.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.gbSearchOptions.Controls.Add(this.oDateTimePicker);
            this.gbSearchOptions.Controls.Add(this.btnSearch);
            this.gbSearchOptions.Controls.Add(this.txtDBOMNo);
            this.gbSearchOptions.Controls.Add(this.lblItemCode);
            this.gbSearchOptions.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.gbSearchOptions.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbSearchOptions.Location = new System.Drawing.Point(6, 8);
            this.gbSearchOptions.Name = "gbSearchOptions";
            this.gbSearchOptions.Size = new System.Drawing.Size(1314, 54);
            this.gbSearchOptions.TabIndex = 10;
            this.gbSearchOptions.TabStop = false;
            this.gbSearchOptions.Text = "Search Options";
            // 
            // oDateTimePicker
            // 
            this.oDateTimePicker.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.oDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.oDateTimePicker.Location = new System.Drawing.Point(527, 21);
            this.oDateTimePicker.Margin = new System.Windows.Forms.Padding(4);
            this.oDateTimePicker.Name = "oDateTimePicker";
            this.oDateTimePicker.Size = new System.Drawing.Size(53, 27);
            this.oDateTimePicker.TabIndex = 32;
            this.oDateTimePicker.Visible = false;
            this.oDateTimePicker.CloseUp += new System.EventHandler(this.oDateTimePicker_CloseUp);
            this.oDateTimePicker.TabIndexChanged += new System.EventHandler(this.oDateTimePicker_TabIndexChanged);
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSearch.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(355, 22);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(87, 27);
            this.btnSearch.TabIndex = 13;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtDBOMNo
            // 
            this.txtDBOMNo.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDBOMNo.Location = new System.Drawing.Point(109, 21);
            this.txtDBOMNo.Name = "txtDBOMNo";
            this.txtDBOMNo.Size = new System.Drawing.Size(229, 26);
            this.txtDBOMNo.TabIndex = 1;
            // 
            // lblItemCode
            // 
            this.lblItemCode.AutoSize = true;
            this.lblItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemCode.Location = new System.Drawing.Point(46, 23);
            this.lblItemCode.Name = "lblItemCode";
            this.lblItemCode.Size = new System.Drawing.Size(63, 19);
            this.lblItemCode.TabIndex = 0;
            this.lblItemCode.Text = "Search :";
            // 
            // DBOMNO
            // 
            this.DBOMNO.DataPropertyName = "PO/WO No";
            this.DBOMNO.HeaderText = "PONo";
            this.DBOMNO.Name = "DBOMNO";
            this.DBOMNO.ReadOnly = true;
            this.DBOMNO.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DBOMNO.Width = 55;
            // 
            // ProjectDescription
            // 
            this.ProjectDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ProjectDescription.DataPropertyName = "ProjectDescription";
            this.ProjectDescription.HeaderText = "Project Name";
            this.ProjectDescription.Name = "ProjectDescription";
            this.ProjectDescription.ReadOnly = true;
            this.ProjectDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectDescription.Width = 143;
            // 
            // VendorName
            // 
            this.VendorName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.VendorName.DataPropertyName = "VendorName";
            this.VendorName.HeaderText = "VendorName";
            this.VendorName.Name = "VendorName";
            this.VendorName.ReadOnly = true;
            this.VendorName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.VendorName.Width = 103;
            // 
            // ItemCode
            // 
            this.ItemCode.DataPropertyName = "ItemCode";
            this.ItemCode.HeaderText = "Item Code";
            this.ItemCode.Name = "ItemCode";
            this.ItemCode.ReadOnly = true;
            this.ItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemCode.Width = 84;
            // 
            // ItemDescription
            // 
            this.ItemDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ItemDescription.DataPropertyName = "ItemDescription";
            this.ItemDescription.HeaderText = "ItemDescription";
            this.ItemDescription.Name = "ItemDescription";
            this.ItemDescription.ReadOnly = true;
            this.ItemDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemDescription.Width = 123;
            // 
            // PurchaseType
            // 
            this.PurchaseType.DataPropertyName = "PurchaseType";
            this.PurchaseType.HeaderText = "PurchaseType";
            this.PurchaseType.Name = "PurchaseType";
            this.PurchaseType.ReadOnly = true;
            this.PurchaseType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PurchaseType.Width = 110;
            // 
            // GINStatus
            // 
            this.GINStatus.DataPropertyName = "GINStatus";
            this.GINStatus.HeaderText = "GINStatus";
            this.GINStatus.Name = "GINStatus";
            this.GINStatus.ReadOnly = true;
            this.GINStatus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.GINStatus.Width = 83;
            // 
            // POLateBy
            // 
            this.POLateBy.DataPropertyName = "POLateBy";
            this.POLateBy.HeaderText = "POLateBy";
            this.POLateBy.Name = "POLateBy";
            this.POLateBy.ReadOnly = true;
            this.POLateBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.POLateBy.Width = 81;
            // 
            // FinalRemarks
            // 
            this.FinalRemarks.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.FinalRemarks.DataPropertyName = "FinalRemarks";
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.FinalRemarks.DefaultCellStyle = dataGridViewCellStyle2;
            this.FinalRemarks.HeaderText = "Remarks";
            this.FinalRemarks.Name = "FinalRemarks";
            this.FinalRemarks.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.FinalRemarks.Width = 73;
            // 
            // OADate
            // 
            this.OADate.DataPropertyName = "OADate";
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.OADate.DefaultCellStyle = dataGridViewCellStyle3;
            this.OADate.HeaderText = "OADate";
            this.OADate.Name = "OADate";
            this.OADate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OADate.Width = 68;
            // 
            // frmPOTrack
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1332, 601);
            this.Controls.Add(this.dgvPOTrack);
            this.Controls.Add(this.gbSearchOptions);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmPOTrack";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PO Track";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmPOTrack_FormClosing);
            this.Load += new System.EventHandler(this.frmPOTrack_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPOTrack)).EndInit();
            this.gbSearchOptions.ResumeLayout(false);
            this.gbSearchOptions.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvPOTrack;
        private System.Windows.Forms.GroupBox gbSearchOptions;
        private System.Windows.Forms.TextBox txtDBOMNo;
        private System.Windows.Forms.Label lblItemCode;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.DateTimePicker oDateTimePicker;
        private System.Windows.Forms.DataGridViewTextBoxColumn DBOMNO;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn VendorName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn PurchaseType;
        private System.Windows.Forms.DataGridViewTextBoxColumn GINStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn POLateBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn FinalRemarks;
        private System.Windows.Forms.DataGridViewTextBoxColumn OADate;
    }
}