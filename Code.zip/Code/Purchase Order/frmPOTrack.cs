﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Purchase_Order
{
    public partial class frmPOTrack : Form
    {
        public frmPOTrack()
        {
            InitializeComponent();
        }
        Login.frmLoginForm Loginfrm = new Login.frmLoginForm();
        DataAccessLayer DAL = new DataAccessLayer();
        Global GlobalClass = new Global();
        Purchase_Order.frmPOHome POHome = new frmPOHome();

        DataTable dtPOTrack = new DataTable();

        private void frmPOTrack_Load(object sender, EventArgs e)
        {

        }

        private void frmPOTrack_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            POHome.Show();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            dtPOTrack = DAL.fnPOTrackList(1, txtDBOMNo.Text.Trim()).Tables[0];
            dgvPOTrack.AutoGenerateColumns = false;
            dgvPOTrack.DataSource = dtPOTrack;
        }

        private void dgvPOTrack_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvPOTrack.CurrentRow.Cells["PurchaseType"].Value.ToString() == "Purahase Order")
            {
                GlobalClass.iSuccess = DAL.fnAddPOTrackRemarks(1, dgvPOTrack.CurrentRow.Cells["DBOMNO"].Value.ToString(), dgvPOTrack.CurrentRow.Cells["ItemCode"].Value.ToString(),
                    dgvPOTrack.CurrentRow.Cells["FinalRemarks"].Value.ToString());
            }
            else if (dgvPOTrack.CurrentRow.Cells["PurchaseType"].Value.ToString() == "Work Order")
            {
                GlobalClass.iSuccess = DAL.fnAddPOTrackRemarks(2, dgvPOTrack.CurrentRow.Cells["DBOMNO"].Value.ToString(), dgvPOTrack.CurrentRow.Cells["ItemCode"].Value.ToString(),
                    dgvPOTrack.CurrentRow.Cells["FinalRemarks"].Value.ToString());
            }
        }

        private void dgvPOTrack_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 9)
            {
                oDateTimePicker.Visible = false;
                oDateTimePicker = new DateTimePicker();
                dgvPOTrack.Controls.Add(oDateTimePicker);
                oDateTimePicker.Format = DateTimePickerFormat.Custom;
                oDateTimePicker.CustomFormat = "dd-MM-yyyy";
                Rectangle oRectangle = dgvPOTrack.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, true);
                oDateTimePicker.Size = new Size(oRectangle.Width, oRectangle.Height);
                oDateTimePicker.Location = new Point(oRectangle.X, oRectangle.Y);
                oDateTimePicker.CloseUp += new EventHandler(oDateTimePicker_CloseUp);
                oDateTimePicker.TextChanged += new EventHandler(oDateTimePicker_TabIndexChanged);
                oDateTimePicker.Visible = true;
            }
            else
            {
                oDateTimePicker.Visible = false;
            }
        }

        private void oDateTimePicker_CloseUp(object sender, EventArgs e)
        {
            oDateTimePicker.Visible = false;
        }

        private void oDateTimePicker_TabIndexChanged(object sender, EventArgs e)
        {
            if (dgvPOTrack.CurrentCell.OwningColumn.Name == "OADate")
            {
                dgvPOTrack.CurrentCell.Value = oDateTimePicker.Text.ToString();

                GlobalClass.iSuccess = DAL.fnAddPOTrackRemarks(3, dgvPOTrack.CurrentRow.Cells["DBOMNO"].Value.ToString(), dgvPOTrack.CurrentRow.Cells["ItemCode"].Value.ToString(),
                    dgvPOTrack.CurrentRow.Cells["OADate"].Value.ToString());
            }
        }
    }
}
