﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Part_Master
{
    public partial class frmAdduser : Form
    {
        #region Intialization of Local Datatables, Variables Daclaration
        DataTable dtUserName = new DataTable();
        DataTable dtOldUserNames = new DataTable();
        DataTable dtUsercheck = new DataTable();
        DataAccessLayer DAL = new DataAccessLayer();
        DataView dvUserList = new DataView();
        Global GLobalClass = new Global();
        Login.frmLoginForm LoginForm = new Login.frmLoginForm();
        bool bUserexist = false;
        string sparent = string.Empty;
        public frmAdduser()
        {
            InitializeComponent();
        }
        #endregion

        #region Code for Add User Form Load datagrdivew Data
        private void frmAdduser_Load(object sender, EventArgs e)
        {
            txtusername.ResetText();
            DataGridViewColumn column = dgvadduser.Columns[0];
            column.Width = 5;
            DataGridViewColumn column1 = dgvadduser.Columns[1];
            column1.Width = 220;

            dtUserName = DAL.fnUserList(null).Tables[0];

            if (!string.IsNullOrEmpty(lblProductName.Text))
            {
                dtOldUserNames = DAL.fnBOMUserList(lblProductName.Text, sparent,null).Tables[0];
            }

            dgvoldusers.AutoGenerateColumns = false;
            dgvoldusers.DataSource = dtOldUserNames;
            dgvoldusers.Columns["oUserName"].DefaultCellStyle.BackColor = Color.FromArgb(255, 128, 128);

            dgvadduser.AutoGenerateColumns = false;
            dgvadduser.DataSource = dtUserName;

            dgvadduser.Columns["Select"].DefaultCellStyle.BackColor = Color.FromArgb(128, 255, 128);
            dgvadduser.Columns["UserName"].DefaultCellStyle.BackColor = Color.FromArgb(255, 128, 128);
        }
        #endregion

        #region Function to Filter the User Name
        private void fnRowFilter(string sRowFilter)
        {
            dvUserList = new DataView(dtUserName);
            dvUserList.RowFilter = "UserName like '" + sRowFilter + "%'";
            dvUserList.Sort = "UserName asc";
            dgvadduser.DataSource = dvUserList.ToTable();
        }     
        private void txtusername_KeyUp(object sender, KeyEventArgs e)
        {
            fnRowFilter(txtusername.Text);
        }
        #endregion

        #region Function to Get Product Code and Product Name
        public void fnProductName(string ProductName)
        {
            lblProductName.Text = ProductName;
        }   
        public void fnParentName(string ParentName)
        {
            sparent = ParentName;
        }
        #endregion

        #region Code to Delete Existing UserNames
        private void dgvoldusers_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
               // dtUsercheck = DAL.fnDeleteBOMUserList(sparent,lblProductName.Text).Tables[0];
              //  if (dtUsercheck.Rows.Count > 0)
              //  {
                    if (LoginForm.GetUserDetails[2] == "megha" || LoginForm.GetUserDetails[2] == "ravi" || LoginForm.GetUserDetails[2] == "vivek g" || LoginForm.GetUserDetails[2] == "abhilash" || LoginForm.GetUserDetails[2] == "jaibarath" || LoginForm.GetUserDetails[2] == "abhilash" || LoginForm.GetUserDetails[2] == "rohit")
                   // if (dtUsercheck.Rows[0]["BOMCreatedBy"].ToString() == LoginForm.GetUserDetails[2].ToString())
                    {
                        GLobalClass.iSuccess = DAL.fnAddBOMUsers(Global.uDELETE, dgvoldusers.CurrentRow.Cells["oUserName"].Value.ToString(), lblProductName.Text, sparent);
                        dgvoldusers.Rows.RemoveAt(dgvoldusers.Rows.IndexOf(dgvoldusers.CurrentRow));
                    }
              //  }
            }
        }
        #endregion

        #region Code to Add New User Permission to the Product
        private void dgvadduser_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvadduser.CurrentCell.OwningColumn.Name == "Select")
            {
                foreach (DataRow dtusernames in dtOldUserNames.Rows)
                {
                    if (dgvadduser.CurrentRow.Cells["UserName"].Value.ToString() == dtusernames["UserName"].ToString())
                    {
                        bUserexist = true;
                        break;
                    }
                    else
                    {
                        bUserexist = false;
                    }
                }

                if (bUserexist == false)
                {
                    GLobalClass.iSuccess = DAL.fnAddBOMUsers(Global.uINSERT, dgvadduser.CurrentRow.Cells["UserName"].Value.ToString(), lblProductName.Text, sparent);
                    dgvadduser.Rows.RemoveAt(dgvadduser.Rows.IndexOf(dgvadduser.CurrentRow));
                    dtOldUserNames = DAL.fnBOMUserList(lblProductName.Text, sparent,null).Tables[0];
                    dgvoldusers.AutoGenerateColumns = false;
                    dgvoldusers.DataSource = dtOldUserNames;
                }

                else
                {
                    MessageBox.Show("User " + dgvadduser.CurrentRow.Cells["UserName"].Value.ToString() + " Already Exist");
                }
            }
        }
        #endregion
    }
}
