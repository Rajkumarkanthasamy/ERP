﻿using System;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Erp_Project_With_Buttons.Part_Master
{
    public partial class frmStandardCost : Form
    {
        frmForm2 frm = new frmForm2();
        Global GLobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        DataView dvItemList = new DataView();
        DataTable dtItemList = new DataTable();
        public frmStandardCost()
        {
            InitializeComponent();
        }

        private void txtsearchitemdesc_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtsearchitemdesc.Text);
                    RowFilter();
                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtsearchitemdesc.Text);
                    RowFilter();
                }
            }
            else
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtsearchitemdesc.Text);
                    RowFilter();
                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtsearchitemdesc.Text);
                    RowFilter();
                }

            }
        }
        private void RowFilter()
        {
            chklbItemList.Items.Clear();
            foreach (DataRowView dv in dvItemList)
            {
                chklbItemList.Items.Add(string.Concat(dv[17].ToString(), ") ", dv[0].ToString(), ", ", dv[1].ToString(), ", ", dv[2].ToString()));
            }
        }
        private void txtsearchitemdesc_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar == '%'))
            {
                e.Handled = true;
            }
        }

        private void frmStandardCost_Load(object sender, EventArgs e)
        {
            if (login.GetUserDetails[54] == "True" && login.GetUserDetails[2] == "Jebaraj")
            {
                chkElectronics.Visible = true;
                chkUpdateUnitPrice.Visible = false;
                chkExcelUpload.Visible = false;
                chkTransducer.Visible = false;
                BtnFreezeItem.Visible = false;
                chkItemCode.Checked = true;
                chkElectronics.Checked = true;
                dtItemList = DAL.fnKanBanFilnishedItemMasterLoadList(0, null).Tables[0];
            }
            else if (login.GetUserDetails[54] == "True" && login.GetUserDetails[2] == "Pavannaik")
            {
                chkElectronics.Visible = false;
                chkExcelUpload.Visible = false;
                chkTransducer.Visible = true;
                BtnFreezeItem.Visible = false;
                chkItemCode.Checked = true;
                chkUpdateUnitPrice.Visible = false;
                chkTransducer.Checked = true;
                dtItemList = DAL.fnKanBanFilnishedItemMasterLoadList(2, null).Tables[0];
            }
            else
            {
                chkElectronics.Visible = false;
                chkTransducer.Visible = false;
                BtnFreezeItem.Visible = true;
                chkItemCode.Checked = true;
                chkUpdateUnitPrice.Checked = true;
                dtItemList = DAL.fnItemMasterLoadList(null).Tables[0];
            }
        }

        private void fnOnlynumber(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void textunit_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber(sender, e);
        }
        string[] sItemCode;
        DataTable dtItemCode = new DataTable();
        DataTable dtGinDetails = new DataTable();
        private void chklbItemList_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            dataGridViewgin.DataSource = null;
            if (!chklbItemList.CheckedItems.Contains(chklbItemList.SelectedItem))
            {
                sItemCode = chklbItemList.SelectedItem.ToString().Trim().Split(')');
                string sID = sItemCode[0];

                if (login.GetUserDetails[54] == "True" && login.GetUserDetails[2] == "Jebaraj")
                {
                    dtItemCode = DAL.fnKanBanFilnishedItemMasterLoadList(1, sID).Tables[0];
                }
                else if (login.GetUserDetails[54] == "True" && login.GetUserDetails[2] == "Pavannaik")
                {
                    dtItemCode = DAL.fnKanBanFilnishedItemMasterLoadList(3, sID).Tables[0];
                }

                else
                {
                    dtItemCode = DAL.fnItemMasterList(sID).Tables[0];
                }




                if (dtItemCode.Rows.Count > 0)
                {
                    txtItemCode.Text = dtItemCode.Rows[0]["ItemCode"].ToString();
                    txtItemDescription.Text = dtItemCode.Rows[0]["ItemDescription"].ToString();
                    textpresentcost.Text = dtItemCode.Rows[0]["UnitCost"].ToString();

                    if (login.GetUserDetails[54] == "True" && login.GetUserDetails[2] == "Jebaraj")
                    {
                        dtGinDetails = DAL.fnItemGinDetail(5, txtItemCode.Text.Trim()).Tables[0];
                    }
                    else if (login.GetUserDetails[54] == "True" && login.GetUserDetails[2] == "Pavannaik")
                    {
                        dtGinDetails = DAL.fnItemGinDetail(6, txtItemCode.Text.Trim()).Tables[0];
                    }
                    else
                    {
                        dtGinDetails = DAL.fnItemGinDetail(1, txtItemCode.Text.Trim()).Tables[0];
                    }

                    if (dtGinDetails.Rows.Count > 0)
                    {
                        dataGridViewgin.AutoGenerateColumns = false;
                        dataGridViewgin.DataSource = dtGinDetails;
                    }
                }
            }
            else
            {
                dataGridViewgin.DataSource = null;
                txtItemCode.ResetText();
                txtItemDescription.ResetText();
                textpresentcost.ResetText();

            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string NowDate = DateTime.Now.ToString("dd-MM-yyyy");
            if (!string.IsNullOrEmpty(textunitcost.Text) && !string.IsNullOrEmpty(txtItemCode.Text) && !string.IsNullOrEmpty(txtRemarks.Text))
            {
                if (login.GetUserDetails[54] == "True" && login.GetUserDetails[2] == "Jebaraj")
                {
                    
                    GLobalClass.iSuccess = DAL.fnadditemstdcost(0, txtItemCode.Text.Trim(), Convert.ToDouble(textunitcost.Text), login.GetUserDetails[2], txtRemarks.Text);
                    if (GLobalClass.iSuccess > 0)
                    {
                        GLobalClass.iSuccess = DAL.fnadditemstdcost(4, txtItemCode.Text.Trim(), Convert.ToDouble(textunitcost.Text), login.GetUserDetails[2], "");
                        GLobalClass.iSuccess = DAL.fnAddERPLog(0, txtItemCode.Text, login.GetUserDetails[2], NowDate, "Item Code Standard Cost Updated", "ItemMaster");
                        MessageBox.Show("Item code Unit Price updated", "Success", 0, MessageBoxIcon.Information);
                        txtItemCode.ResetText();
                        textunitcost.ResetText();
                        txtRemarks.ResetText();
                    }
                }
                else if (login.GetUserDetails[54] == "True" && login.GetUserDetails[2] == "Pavannaik")
                {
                    GLobalClass.iSuccess = DAL.fnadditemstdcost(0, txtItemCode.Text.Trim(), Convert.ToDouble(textunitcost.Text), login.GetUserDetails[2], txtRemarks.Text);
                    if (GLobalClass.iSuccess > 0)
                    {
                        GLobalClass.iSuccess = DAL.fnadditemstdcost(5, txtItemCode.Text.Trim(), Convert.ToDouble(textunitcost.Text), login.GetUserDetails[2], "");
                        GLobalClass.iSuccess = DAL.fnAddERPLog(0, txtItemCode.Text, login.GetUserDetails[2], NowDate, "Item Code Standard Cost Updated", "ItemMaster");

                        MessageBox.Show("Item code Unit Price updated", "Success", 0, MessageBoxIcon.Information);
                        txtItemCode.ResetText();
                        textunitcost.ResetText();
                        txtRemarks.ResetText();
                    }
                }
                else
                {

                    GLobalClass.iSuccess = DAL.fnadditemstdcost(0, txtItemCode.Text.Trim(), Convert.ToDouble(textunitcost.Text), login.GetUserDetails[2], txtRemarks.Text);
                    if (GLobalClass.iSuccess > 0)
                    {
                        GLobalClass.iSuccess = DAL.fnadditemstdcost(1, txtItemCode.Text.Trim(), Convert.ToDouble(textunitcost.Text), login.GetUserDetails[2], "");
                        GLobalClass.iSuccess = DAL.fnadditemstdcost(2, txtItemCode.Text.Trim(), Convert.ToDouble(textunitcost.Text), login.GetUserDetails[2], "");
                        GLobalClass.iSuccess = DAL.fnadditemstdcost(3, txtItemCode.Text.Trim(), Convert.ToDouble(textunitcost.Text), login.GetUserDetails[2], "");
                        GLobalClass.iSuccess = DAL.fnAddERPLog(0, txtItemCode.Text, login.GetUserDetails[2], NowDate, "Item Code Standard Cost Updated", "ItemMaster");
                        MessageBox.Show("Item code Unit Price updated", "Success", 0, MessageBoxIcon.Information);
                        txtItemCode.ResetText();
                        textunitcost.ResetText();
                        txtRemarks.ResetText();
                    }
                }
            }
            else
            {
                if (string.IsNullOrEmpty(txtItemCode.Text))
                {
                    MessageBox.Show("Please select item code", "Error", 0, MessageBoxIcon.Error);
                }
                else if (string.IsNullOrEmpty(textunitcost.Text))
                {
                    MessageBox.Show("Please enter unit cost", "Error", 0, MessageBoxIcon.Error);
                    textunitcost.Focus();
                }
                else if (string.IsNullOrEmpty(txtRemarks.Text))
                {
                    MessageBox.Show("Please write remarks", "Error", 0, MessageBoxIcon.Error);
                    txtRemarks.Focus();
                }
            }
        }

        private void chkExcelUpload_CheckedChanged(object sender, EventArgs e)
        {
            if (chkExcelUpload.Checked)
            {
                pnExcelUpload.Visible = true;
                pnItemUpdate.Visible = false;

                chkUpdateUnitPrice.Checked = false;
            }
            else
            {
                chkUpdateUnitPrice.Checked = true;
            }
        }
        DataTable dtExcelImport = new DataTable();
        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            try
            {
                string smessageItemCode = string.Empty;
                string str = string.Empty;
                string sheetname = "";
                string constr = "Provider = Microsoft.Jet.OLEDB.4.0; Data Source=" + openFileDialog1.FileName + ";Extended Properties= \"Excel 8.0;HDR=YES;\";";
                OleDbConnection con = new OleDbConnection(constr);
                con.Open();
                DataTable Sheets = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                foreach (DataRow dr in Sheets.Rows)
                {
                    sheetname = dr[2].ToString().Replace("'", "");
                    break;
                }
                if (!string.IsNullOrEmpty(sheetname))
                {
                    OleDbDataAdapter sda = new OleDbDataAdapter("select * from [" + sheetname + "]", con);
                    sda.Fill(dtExcelImport);
                }
                con.Close();
                if (dtExcelImport.Rows.Count > 0 && dtExcelImport.Columns.Count == 4 && !string.IsNullOrEmpty(dtExcelImport.Rows[0][1].ToString()))
                {
                    for (int i = 0; i < dtExcelImport.Columns.Count; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                str = "slno";
                                break;
                            case 1:
                                str = "ItemCode";
                                break;
                            case 2:
                                str = "UnitCost";
                                break;
                            case 3:
                                str = "Remarks";
                                break;
                        }
                        dtExcelImport.Columns[i].ColumnName = str;
                    }

                    for (int i = dtExcelImport.Rows.Count - 1; i >= 0; i--)
                    {
                        if (dtExcelImport.Rows[i][1] == DBNull.Value)
                            dtExcelImport.Rows[i].Delete();
                    }
                    dtExcelImport.AcceptChanges();

                    for (int i = 0; i < dtExcelImport.Rows.Count; i++)
                    {
                        string sItemCodex = dtExcelImport.Rows[i]["ItemCode"].ToString();
                        DataTable dtItemSearch = DAL.fnItemListItemsearch(sItemCodex).Tables[0];

                        if (dtItemSearch.Rows.Count > 0)
                        {
                            dtExcelImport.Rows[i]["ItemCode"] = dtItemSearch.Rows[0]["ItemCode"].ToString();

                            if (string.IsNullOrEmpty(dtExcelImport.Rows[i]["UnitCost"].ToString()) || Convert.ToDouble(dtExcelImport.Rows[i]["UnitCost"].ToString()) == 0.0)
                            {
                                dtExcelImport.Rows[i]["UnitCost"] = "0.01";
                            }
                        }
                        else
                        {
                            dtExcelImport.Rows.RemoveAt(i);
                            i--;
                            if (smessageItemCode.Length > 0)
                            {
                                smessageItemCode += "," + sItemCodex.ToString();
                            }
                            else
                            {
                                smessageItemCode = sItemCodex.ToString();
                            }
                        }
                    }
                    if (dtExcelImport.Rows.Count > 0)
                    {
                        dgvExcelUpdate.AutoGenerateColumns = false;
                        dgvExcelUpdate.DataSource = dtExcelImport;
                        if (smessageItemCode.Length > 0)
                        {
                            MessageBox.Show("The listed item(s) are not exist in item master \n " + smessageItemCode + "");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Uploaded Excel file not contains any valid details matching with the Item master requirements. \n\n Please note these columns are mandatory to fill. \n Slno \n ItemCode \n UnitCost", "Error", 0, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Uploaded Excel file is not in expected format.\n 1) Excel file should contain 3 columns with Names on the first Row \n 2) Items details to be start from the Second Row ", "Error", 0, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("btnUpload_Click" + ex.Message);
            }
        }

        private void chkUpdateUnitPrice_CheckedChanged(object sender, EventArgs e)
        {
            if (chkUpdateUnitPrice.Checked)
            {
                pnExcelUpload.Visible = false;
                pnItemUpdate.Visible = true;
                chkExcelUpload.Checked = false;
            }
            else
            {
                chkExcelUpload.Checked = true;
            }
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Excel Files (*.xls)|*.xls";
            openFileDialog1.InitialDirectory = @"c:\";
            openFileDialog1.FileName = "Select File";
            openFileDialog1.Title = "Select excel file..";
            openFileDialog1.ShowDialog();
        }

        private void btnExcelUpdate_Click(object sender, EventArgs e)
        {
            if (dgvExcelUpdate.Rows.Count > 0)
            {
                bool bwrongvalue = false;
                foreach (DataRow dr in dtExcelImport.Rows)
                {
                    if (Convert.ToDouble(dr["UnitCost"].ToString()) <= 0)
                    {
                        bwrongvalue = true;
                        break;
                    }
                }
                if (!bwrongvalue)
                {
                    foreach (DataRow dr in dtExcelImport.Rows)
                    {
                        GLobalClass.iSuccess = DAL.fnadditemstdcost(0, dr["ItemCode"].ToString().Trim(), Convert.ToDouble(dr["UnitCost"].ToString()), login.GetUserDetails[2], dr["Remarks"].ToString().Trim());
                        GLobalClass.iSuccess = DAL.fnadditemstdcost(1, dr["ItemCode"].ToString().Trim(), Convert.ToDouble(dr["UnitCost"].ToString()), login.GetUserDetails[2], "");
                        GLobalClass.iSuccess = DAL.fnadditemstdcost(2, dr["ItemCode"].ToString().Trim(), Convert.ToDouble(dr["UnitCost"].ToString()), login.GetUserDetails[2], "");
                        GLobalClass.iSuccess = DAL.fnadditemstdcost(3, dr["ItemCode"].ToString().Trim(), Convert.ToDouble(dr["UnitCost"].ToString()), login.GetUserDetails[2], "");
                    }
                    dgvExcelUpdate.DataSource = null;

                    MessageBox.Show("Item Codes Unit Price updates successfully", "Success", 0, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Please Enter Unit cost to Update the unit cost", "Warning", 0, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Please upload the excel file to update the unit cost", "Warning", 0, MessageBoxIcon.Warning);
            }
        }

        private void chkItemCode_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemCode.Checked)
            {
                chkItemDesc.Checked = false;
            }
            else
            {
                chkItemDesc.Checked = true;
            }
        }

        private void chkItemDesc_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemDesc.Checked)
            {
                chkItemCode.Checked = false;
            }
            else
            {
                chkItemCode.Checked = true;
            }
        }


        private void frmStandardCost_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            frm.Show();
        }

        private void BtnFreezeItem_Click(object sender, EventArgs e)
        {
            GLobalClass.iSuccess = DAL.insertItemAvailableQty();
        }

        private void chkElectronics_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm.Show();
        }
    }
}
