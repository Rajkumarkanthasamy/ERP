﻿using System;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using System.Data.OleDb;
using Outlook = Microsoft.Office.Interop.Outlook;

namespace Erp_Project_With_Buttons.Part_Master
{
    public partial class FrmTargetCost : Form
    {
        frmForm2 frm = new frmForm2();
        Global GLobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        DataView dvItemList = new DataView();
        DataTable dtItemList = new DataTable();
        DataTable TargetItems = new DataTable();
        public FrmTargetCost()
        {
            InitializeComponent();
        }
        private void txtsearchitemdesc_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtsearchitemdesc.Text);
                    RowFilter();
                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtsearchitemdesc.Text);
                    RowFilter();
                }
            }
            else
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtsearchitemdesc.Text);
                    RowFilter();
                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtsearchitemdesc.Text);
                    RowFilter();
                }

            }
        }
        private void RowFilter()
        {
            chklbItemList.Items.Clear();
            foreach (DataRowView dv in dvItemList)
            {
                chklbItemList.Items.Add(string.Concat(dv[17].ToString(), ") ", dv[0].ToString(), ", ", dv[1].ToString(), ", ", dv[12].ToString()));
            }
        }
        private void txtsearchitemdesc_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar == '%'))
            {
                e.Handled = true;
            }
        }
        private void FrmTargetCost_Load(object sender, EventArgs e)
        {
            if (login.GetUserDetails[2].ToLower() == "hebbarrk")
            {
                TargetApprovePanel.Visible = true;
                chkItemCode.Enabled = false;
                chkItemDesc.Enabled = false;
                chkUpdateUnitPrice.Enabled = false;
                chkExcelUpload.Enabled = false;

                TargetItems = DAL.fngettaregetcost().Tables[0];
                TargetApproveList.AutoGenerateColumns = false;
                TargetApproveList.DataSource = TargetItems;
            }
            else
            {
                chkItemCode.Checked = true;
                chkUpdateUnitPrice.Checked = true;
                dtItemList = DAL.fnItemMasterLoadList(null).Tables[0];
            }

        }
        private void fnOnlynumber(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void textunit_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber(sender, e);
        }
        string[] sItemCode;
        DataTable dtItemCode = new DataTable();
        DataTable dtGinDetails = new DataTable();
        private void chklbItemList_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            if (!chklbItemList.CheckedItems.Contains(chklbItemList.SelectedItem))
            {
                sItemCode = chklbItemList.SelectedItem.ToString().Trim().Split(')');
                string sID = sItemCode[0];
                dtItemCode = DAL.fnItemMasterList(sID).Tables[0];

                if (dtItemCode.Rows.Count > 0)
                {
                    txtItemCode.Text = dtItemCode.Rows[0]["ItemCode"].ToString();
                    txtItemDescription.Text = dtItemCode.Rows[0]["ItemDescription"].ToString();
                    textpresentcost.Text = dtItemCode.Rows[0]["TargetCost"].ToString();

                    dtGinDetails = DAL.fnItemGinDetail(4, txtItemCode.Text.Trim()).Tables[0];
                    if (dtGinDetails.Rows.Count > 0)
                    {
                        dataGridViewgin.AutoGenerateColumns = false;
                        dataGridViewgin.DataSource = dtGinDetails;
                    }
                    else
                    {
                        dataGridViewgin.DataSource = null;
                    }
                }
            }
            else
            {
                dataGridViewgin.DataSource = null;
                txtItemCode.ResetText();
                txtItemDescription.ResetText();
                textpresentcost.ResetText();
            }
        }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
           
            if (!string.IsNullOrEmpty(textunitcost.Text) && !string.IsNullOrEmpty(txtItemCode.Text) && !string.IsNullOrEmpty(txtRemarks.Text))
            {
                GLobalClass.iSuccess = DAL.fnaddtargetcost(0, txtItemCode.Text.Trim(), Convert.ToDouble(textunitcost.Text), login.GetUserDetails[2], txtRemarks.Text);
                if (GLobalClass.iSuccess > 0)
                {
                    //GLobalClass.iSuccess = DAL.fnaddtargetcost(1, txtItemCode.Text.Trim(), Convert.ToDouble(textunitcost.Text), login.GetUserDetails[2], "");
                    //GLobalClass.iSuccess = DAL.fnaddtargetcost(2, txtItemCode.Text.Trim(), Convert.ToDouble(textunitcost.Text), login.GetUserDetails[2], "");
                    //GLobalClass.iSuccess = DAL.fnaddtargetcost(3, txtItemCode.Text.Trim(), Convert.ToDouble(textunitcost.Text), login.GetUserDetails[2], "");
                    MessageBox.Show("Item code Target Price updated", "Success", 0, MessageBoxIcon.Information);
                    fnAlertMail1("biss");
                    txtItemCode.ResetText();
                    textunitcost.ResetText();
                    txtRemarks.ResetText();
                    txtItemDescription.ResetText();
                    textpresentcost.ResetText();
                    dataGridViewgin.DataSource = null;
                }
            }
            else
            {
                if (string.IsNullOrEmpty(txtItemCode.Text))
                {
                    MessageBox.Show("Please Select Item Code", "Error", 0, MessageBoxIcon.Error);
                }
                else if (string.IsNullOrEmpty(textunitcost.Text))
                {
                    MessageBox.Show("Please Enter Target Cost", "Error", 0, MessageBoxIcon.Error);
                    textunitcost.Focus();
                }
                else if (string.IsNullOrEmpty(txtRemarks.Text))
                {
                    MessageBox.Show("Please Write Remarks", "Error", 0, MessageBoxIcon.Error);
                    txtRemarks.Focus();
                }
            }
        }
       
        private void chkExcelUpload_CheckedChanged(object sender, EventArgs e)
        {
            if (chkExcelUpload.Checked)
            {
                pnExcelUpload.Visible = true;
                pnItemUpdate.Visible = false;

                chkUpdateUnitPrice.Checked = false;
            }
            else
            {
                chkUpdateUnitPrice.Checked = true;
            }
        }
        DataTable dtExcelImport = new DataTable();
        string smessageItemCode = string.Empty;
        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            try
            {
               // string smessageItemCode = string.Empty;
                string str = string.Empty;
                string sheetname = "";
                string constr = "Provider = Microsoft.Jet.OLEDB.4.0; Data Source=" + openFileDialog1.FileName + ";Extended Properties= \"Excel 8.0;HDR=YES;\";";
                OleDbConnection con = new OleDbConnection(constr);
                con.Open();
                DataTable Sheets = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                foreach (DataRow dr in Sheets.Rows)
                {
                    sheetname = dr[2].ToString().Replace("'", "");
                    break;
                }
                if (!string.IsNullOrEmpty(sheetname))
                {
                    OleDbDataAdapter sda = new OleDbDataAdapter("select * from [" + sheetname + "]", con);
                    sda.Fill(dtExcelImport);
                }
                con.Close();
                if (dtExcelImport.Rows.Count > 0 && dtExcelImport.Columns.Count == 4 && !string.IsNullOrEmpty(dtExcelImport.Rows[0][1].ToString()))
                {
                    for (int i = 0; i < dtExcelImport.Columns.Count; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                str = "slno";
                                break;
                            case 1:
                                str = "ItemCode";
                                break;
                            case 2:
                                str = "UnitCost";
                                break;
                            case 3:
                                str = "Remarks";
                                break;
                        }
                        dtExcelImport.Columns[i].ColumnName = str;
                    }

                    for (int i = dtExcelImport.Rows.Count - 1; i >= 0; i--)
                    {
                        if (dtExcelImport.Rows[i][1] == DBNull.Value)
                            dtExcelImport.Rows[i].Delete();
                    }
                    dtExcelImport.AcceptChanges();

                    for (int i = 0; i < dtExcelImport.Rows.Count; i++)
                    {
                        string sItemCodex = dtExcelImport.Rows[i]["ItemCode"].ToString();
                        DataTable dtItemSearch = DAL.fnItemListItemsearch(sItemCodex).Tables[0];

                        if (dtItemSearch.Rows.Count > 0)
                        {
                            dtExcelImport.Rows[i]["ItemCode"] = dtItemSearch.Rows[0]["ItemCode"].ToString();

                            if (string.IsNullOrEmpty(dtExcelImport.Rows[i]["UnitCost"].ToString()) || Convert.ToDouble(dtExcelImport.Rows[i]["UnitCost"].ToString()) == 0.0)
                            {
                                dtExcelImport.Rows[i]["UnitCost"] = "0.01";
                            }
                        }
                        else
                        {
                            dtExcelImport.Rows.RemoveAt(i);
                            i--;
                            if (smessageItemCode.Length > 0)
                            {
                                smessageItemCode += "," + sItemCodex.ToString();
                            }
                            else
                            {
                                smessageItemCode = sItemCodex.ToString();
                            }
                        }
                    }
                    if (dtExcelImport.Rows.Count > 0)
                    {
                        dgvExcelUpdate.AutoGenerateColumns = false;
                        dgvExcelUpdate.DataSource = dtExcelImport;
                        if (smessageItemCode.Length > 0)
                        {
                            MessageBox.Show("The listed item(s) are not exist in item master \n " + smessageItemCode + "");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Uploaded Excel file not contains any valid details matching with the Item master requirements. \n\n Please note these columns are mandatory to fill. \n Slno \n ItemCode \n UnitCost", "Error", 0, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Uploaded Excel file is not in expected format.\n 1) Excel file should contain 3 columns with Names on the first Row \n 2) Items details to be start from the Second Row ", "Error", 0, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("btnUpload_Click" + ex.Message);
            }
        }

        private void chkUpdateUnitPrice_CheckedChanged(object sender, EventArgs e)
        {
            if (chkUpdateUnitPrice.Checked)
            {
                pnExcelUpload.Visible = false;
                pnItemUpdate.Visible = true;
                chkExcelUpload.Checked = false;
            }
            else
            {
                chkExcelUpload.Checked = true;
            }
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Excel Files (*.xls)|*.xls";
            openFileDialog1.InitialDirectory = @"c:\";
            openFileDialog1.FileName = "Select File";
            openFileDialog1.Title = "Select excel file..";
            openFileDialog1.ShowDialog();
        }

        private void btnExcelUpdate_Click(object sender, EventArgs e)
        {
            if (dgvExcelUpdate.Rows.Count > 0)
            {
                bool bwrongvalue = false;
                foreach (DataRow dr in dtExcelImport.Rows)
                {
                    if (Convert.ToDouble(dr["UnitCost"].ToString()) <= 0)
                    {
                        bwrongvalue = true;
                        break;
                    }
                }
                if (!bwrongvalue)
                {
                    foreach (DataRow dr in dtExcelImport.Rows)
                    {
                        GLobalClass.iSuccess = DAL.fnadditemstdcost(0, dr["ItemCode"].ToString().Trim(), Convert.ToDouble(dr["UnitCost"].ToString()), login.GetUserDetails[2], dr["Remarks"].ToString().Trim());
                        GLobalClass.iSuccess = DAL.fnadditemstdcost(1, dr["ItemCode"].ToString().Trim(), Convert.ToDouble(dr["UnitCost"].ToString()), login.GetUserDetails[2], "");
                        GLobalClass.iSuccess = DAL.fnadditemstdcost(2, dr["ItemCode"].ToString().Trim(), Convert.ToDouble(dr["UnitCost"].ToString()), login.GetUserDetails[2], "");
                        GLobalClass.iSuccess = DAL.fnadditemstdcost(3, dr["ItemCode"].ToString().Trim(), Convert.ToDouble(dr["UnitCost"].ToString()), login.GetUserDetails[2], "");
                    }
                    dgvExcelUpdate.DataSource = null;

                    MessageBox.Show("Item Codes Unit Price updates successfully", "Success", 0, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Please Enter Unit cost to Update the unit cost", "Warning", 0, MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("Please upload the excel file to update the unit cost", "Warning", 0, MessageBoxIcon.Warning);
            }
        }

        private void chkItemCode_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemCode.Checked)
            {
                chkItemDesc.Checked = false;
            }
            else
            {
                chkItemDesc.Checked = true;
            }
        }

        private void chkItemDesc_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemDesc.Checked)
            {
                chkItemCode.Checked = false;
            }
            else
            {
                chkItemCode.Checked = true;
            }
        }

       

        string smailItemCode = string.Empty;
        private void BtnTargetApprove_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in TargetApproveList.Rows)
            {
                bool isSelected = Convert.ToBoolean(row.Cells["CheckboxColumn"].Value);
                if (isSelected)
                {
                  GLobalClass.iSuccess = DAL.fnaddtargetcost(4, row.Cells["Id"].Value.ToString(), 0.0, row.Cells["ItemCode"].Value.ToString(), "");
                  GLobalClass.iSuccess = DAL.fnaddtargetcost(1, row.Cells["ItemCode"].Value.ToString(),Convert.ToDouble(row.Cells["TargetCost"].Value.ToString()),login.GetUserDetails[2], "");
                //GLobalClass.iSuccess = DAL.fnaddtargetcost(2, txtItemCode.Text.Trim(), Convert.ToDouble(textunitcost.Text), login.GetUserDetails[2], "");
                //GLobalClass.iSuccess = DAL.fnaddtargetcost(3, txtItemCode.Text.Trim(), Convert.ToDouble(textunitcost.Text), login.GetUserDetails[2], "");
                    if (smailItemCode.Length > 0)
                    {
                        smailItemCode += "," + row.Cells["ItemCode"].Value.ToString();
                    }
                    else
                    {
                        smailItemCode = row.Cells["ItemCode"].Value.ToString();
                    }
                }
            }
          
            if (GLobalClass.iSuccess > 0)
            {
                fnAlertMail("biss");
                MessageBox.Show("Item target Price approved successfully", "Success", 0, MessageBoxIcon.Information);
            }
           
        }

        private void BtnReject_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in TargetApproveList.Rows)
            {
                bool isSelected = Convert.ToBoolean(row.Cells["CheckboxColumn"].Value);
                if (isSelected)
                {
                    GLobalClass.iSuccess = DAL.fnaddtargetcost(5, row.Cells["Id"].Value.ToString(), 0.0, row.Cells["ItemCode"].Value.ToString(), "");

                }
            }
            if (GLobalClass.iSuccess > 0)
            {
               MessageBox.Show("Item target Price Rejected", "Success", 0, MessageBoxIcon.Information);
            }
            
        }
        public void fnAlertMail(string sUser)
        {
            try
            {
                DataTable dtlogindetails = DAL.fnloginemail(sUser).Tables[0]; ;
                if (dtlogindetails.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
                    {
                        Outlook.Application oApp = new Outlook.Application();
                        Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);


                        Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                        oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                        oRecips.ResolveAll();

                        oMsg.Subject = "Project " + txtItemCode.Text + " sent for approval";
                        oMsg.HTMLBody = "Dear " + sUser + ", <br /><br />Target Price of the ItemCode is Approved.<br />  <font color='blue'>" + smailItemCode + " </font> <br /> <br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";

                        oMsg.Send();
                        oRecips = null;


                        oMsg = null;
                        oApp = null;
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }
        public void fnAlertMail1(string sUser)
        {
            try
            {
                DataTable dtlogindetails = DAL.fnloginemail(sUser).Tables[0]; ;
                if (dtlogindetails.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
                    {
                        Outlook.Application oApp = new Outlook.Application();
                        Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);


                        oMsg.Subject = "ItemCode " + txtItemCode.Text + " sent for approval";
                        oMsg.HTMLBody = "Dear " + sUser + ", <br /><br />Target Price Updated Successfully  <font color='blue'>" + txtItemCode.Text + " </font> sent for  approval. <br /> <br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";

                        Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                        oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                        oRecips.ResolveAll();

                        oMsg.Send();
                        oRecips = null;


                        oMsg = null;
                        oApp = null;
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }
        private void frmTargetCost_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            frm.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
        }
    }
}
