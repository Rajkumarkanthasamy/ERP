﻿
namespace Erp_Project_With_Buttons.Part_Master
{
    partial class frmStandardCost
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmStandardCost));
            this.chkItemDesc = new System.Windows.Forms.CheckBox();
            this.chkItemCode = new System.Windows.Forms.CheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.chklbItemList = new System.Windows.Forms.CheckedListBox();
            this.txtsearchitemdesc = new System.Windows.Forms.TextBox();
            this.txtItemDescription = new System.Windows.Forms.TextBox();
            this.textpresentcost = new System.Windows.Forms.TextBox();
            this.Labelpresentcost = new System.Windows.Forms.Label();
            this.labeldescription = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.textunitcost = new System.Windows.Forms.TextBox();
            this.labelunitcost = new System.Windows.Forms.Label();
            this.lblitemcode = new System.Windows.Forms.Label();
            this.txtItemCode = new System.Windows.Forms.TextBox();
            this.pnItemUpdate = new System.Windows.Forms.Panel();
            this.btnExit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.dataGridViewgin = new System.Windows.Forms.DataGridView();
            this.GINNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GINDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chkUpdateUnitPrice = new System.Windows.Forms.CheckBox();
            this.chkExcelUpload = new System.Windows.Forms.CheckBox();
            this.pnExcelUpload = new System.Windows.Forms.Panel();
            this.btnExcelUpdate = new System.Windows.Forms.Button();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.dgvExcelUpdate = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Remarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.BtnFreezeItem = new System.Windows.Forms.Button();
            this.chkTransducer = new System.Windows.Forms.CheckBox();
            this.chkElectronics = new System.Windows.Forms.CheckBox();
            this.pnItemUpdate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewgin)).BeginInit();
            this.pnExcelUpload.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvExcelUpdate)).BeginInit();
            this.SuspendLayout();
            // 
            // chkItemDesc
            // 
            this.chkItemDesc.AutoSize = true;
            this.chkItemDesc.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemDesc.ForeColor = System.Drawing.Color.Black;
            this.chkItemDesc.Location = new System.Drawing.Point(241, 42);
            this.chkItemDesc.Name = "chkItemDesc";
            this.chkItemDesc.Size = new System.Drawing.Size(140, 23);
            this.chkItemDesc.TabIndex = 218;
            this.chkItemDesc.Text = "Item Description";
            this.chkItemDesc.UseVisualStyleBackColor = true;
            this.chkItemDesc.CheckedChanged += new System.EventHandler(this.chkItemDesc_CheckedChanged);
            // 
            // chkItemCode
            // 
            this.chkItemCode.AutoSize = true;
            this.chkItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemCode.ForeColor = System.Drawing.Color.Black;
            this.chkItemCode.Location = new System.Drawing.Point(138, 41);
            this.chkItemCode.Name = "chkItemCode";
            this.chkItemCode.Size = new System.Drawing.Size(97, 23);
            this.chkItemCode.TabIndex = 217;
            this.chkItemCode.Text = "Item Code";
            this.chkItemCode.UseVisualStyleBackColor = true;
            this.chkItemCode.CheckedChanged += new System.EventHandler(this.chkItemCode_CheckedChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(21, 42);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(111, 19);
            this.label10.TabIndex = 216;
            this.label10.Text = "Search Item by";
            // 
            // chklbItemList
            // 
            this.chklbItemList.CheckOnClick = true;
            this.chklbItemList.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chklbItemList.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chklbItemList.FormattingEnabled = true;
            this.chklbItemList.HorizontalScrollbar = true;
            this.chklbItemList.Location = new System.Drawing.Point(12, 147);
            this.chklbItemList.Name = "chklbItemList";
            this.chklbItemList.Size = new System.Drawing.Size(365, 403);
            this.chklbItemList.TabIndex = 215;
            this.chklbItemList.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.chklbItemList_ItemCheck);
            // 
            // txtsearchitemdesc
            // 
            this.txtsearchitemdesc.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsearchitemdesc.Location = new System.Drawing.Point(12, 80);
            this.txtsearchitemdesc.Multiline = true;
            this.txtsearchitemdesc.Name = "txtsearchitemdesc";
            this.txtsearchitemdesc.Size = new System.Drawing.Size(365, 61);
            this.txtsearchitemdesc.TabIndex = 214;
            this.txtsearchitemdesc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtsearchitemdesc_KeyPress);
            this.txtsearchitemdesc.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtsearchitemdesc_KeyUp);
            // 
            // txtItemDescription
            // 
            this.txtItemDescription.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemDescription.Location = new System.Drawing.Point(117, 98);
            this.txtItemDescription.Multiline = true;
            this.txtItemDescription.Name = "txtItemDescription";
            this.txtItemDescription.ReadOnly = true;
            this.txtItemDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtItemDescription.Size = new System.Drawing.Size(250, 82);
            this.txtItemDescription.TabIndex = 227;
            // 
            // textpresentcost
            // 
            this.textpresentcost.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textpresentcost.Location = new System.Drawing.Point(117, 203);
            this.textpresentcost.Name = "textpresentcost";
            this.textpresentcost.ReadOnly = true;
            this.textpresentcost.Size = new System.Drawing.Size(250, 26);
            this.textpresentcost.TabIndex = 226;
            // 
            // Labelpresentcost
            // 
            this.Labelpresentcost.AutoSize = true;
            this.Labelpresentcost.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Labelpresentcost.ForeColor = System.Drawing.Color.Black;
            this.Labelpresentcost.Location = new System.Drawing.Point(7, 206);
            this.Labelpresentcost.Name = "Labelpresentcost";
            this.Labelpresentcost.Size = new System.Drawing.Size(102, 19);
            this.Labelpresentcost.TabIndex = 225;
            this.Labelpresentcost.Text = "Present Cost :";
            // 
            // labeldescription
            // 
            this.labeldescription.AutoSize = true;
            this.labeldescription.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeldescription.ForeColor = System.Drawing.Color.Black;
            this.labeldescription.Location = new System.Drawing.Point(17, 98);
            this.labeldescription.Name = "labeldescription";
            this.labeldescription.Size = new System.Drawing.Size(92, 19);
            this.labeldescription.TabIndex = 220;
            this.labeldescription.Text = "Item Name :";
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnUpdate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.Location = new System.Drawing.Point(587, 383);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(107, 35);
            this.btnUpdate.TabIndex = 224;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // textunitcost
            // 
            this.textunitcost.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textunitcost.Location = new System.Drawing.Point(117, 255);
            this.textunitcost.Name = "textunitcost";
            this.textunitcost.Size = new System.Drawing.Size(250, 27);
            this.textunitcost.TabIndex = 223;
            this.textunitcost.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textunit_KeyPress);
            // 
            // labelunitcost
            // 
            this.labelunitcost.AutoSize = true;
            this.labelunitcost.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelunitcost.ForeColor = System.Drawing.Color.Black;
            this.labelunitcost.Location = new System.Drawing.Point(22, 258);
            this.labelunitcost.Name = "labelunitcost";
            this.labelunitcost.Size = new System.Drawing.Size(87, 19);
            this.labelunitcost.TabIndex = 222;
            this.labelunitcost.Text = "Unit Cost *:";
            // 
            // lblitemcode
            // 
            this.lblitemcode.AutoSize = true;
            this.lblitemcode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblitemcode.ForeColor = System.Drawing.Color.Black;
            this.lblitemcode.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.lblitemcode.Location = new System.Drawing.Point(23, 49);
            this.lblitemcode.Name = "lblitemcode";
            this.lblitemcode.Size = new System.Drawing.Size(86, 19);
            this.lblitemcode.TabIndex = 221;
            this.lblitemcode.Text = "Item Code :";
            // 
            // txtItemCode
            // 
            this.txtItemCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemCode.Location = new System.Drawing.Point(117, 47);
            this.txtItemCode.Name = "txtItemCode";
            this.txtItemCode.ReadOnly = true;
            this.txtItemCode.Size = new System.Drawing.Size(250, 26);
            this.txtItemCode.TabIndex = 228;
            // 
            // pnItemUpdate
            // 
            this.pnItemUpdate.Controls.Add(this.btnExit);
            this.pnItemUpdate.Controls.Add(this.label1);
            this.pnItemUpdate.Controls.Add(this.txtRemarks);
            this.pnItemUpdate.Controls.Add(this.dataGridViewgin);
            this.pnItemUpdate.Controls.Add(this.txtItemCode);
            this.pnItemUpdate.Controls.Add(this.lblitemcode);
            this.pnItemUpdate.Controls.Add(this.txtItemDescription);
            this.pnItemUpdate.Controls.Add(this.labelunitcost);
            this.pnItemUpdate.Controls.Add(this.textpresentcost);
            this.pnItemUpdate.Controls.Add(this.textunitcost);
            this.pnItemUpdate.Controls.Add(this.Labelpresentcost);
            this.pnItemUpdate.Controls.Add(this.btnUpdate);
            this.pnItemUpdate.Controls.Add(this.labeldescription);
            this.pnItemUpdate.Location = new System.Drawing.Point(401, 39);
            this.pnItemUpdate.Name = "pnItemUpdate";
            this.pnItemUpdate.Size = new System.Drawing.Size(838, 508);
            this.pnItemUpdate.TabIndex = 229;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(739, 383);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(90, 35);
            this.btnExit.TabIndex = 232;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(26, 305);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 19);
            this.label1.TabIndex = 230;
            this.label1.Text = "Reamrks *:";
            // 
            // txtRemarks
            // 
            this.txtRemarks.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemarks.Location = new System.Drawing.Point(117, 302);
            this.txtRemarks.MaxLength = 254;
            this.txtRemarks.Multiline = true;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Size = new System.Drawing.Size(712, 46);
            this.txtRemarks.TabIndex = 231;
            // 
            // dataGridViewgin
            // 
            this.dataGridViewgin.AllowUserToAddRows = false;
            this.dataGridViewgin.AllowUserToDeleteRows = false;
            this.dataGridViewgin.AllowUserToResizeRows = false;
            this.dataGridViewgin.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridViewgin.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridViewgin.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewgin.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewgin.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewgin.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.GINNumber,
            this.GINDate,
            this.Quantity,
            this.UnitCost});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewgin.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewgin.Location = new System.Drawing.Point(388, 49);
            this.dataGridViewgin.MultiSelect = false;
            this.dataGridViewgin.Name = "dataGridViewgin";
            this.dataGridViewgin.ReadOnly = true;
            this.dataGridViewgin.RowHeadersVisible = false;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.ControlLight;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewgin.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewgin.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dataGridViewgin.Size = new System.Drawing.Size(441, 233);
            this.dataGridViewgin.TabIndex = 229;
            // 
            // GINNumber
            // 
            this.GINNumber.DataPropertyName = "GINNumber";
            this.GINNumber.HeaderText = "GIN Number";
            this.GINNumber.Name = "GINNumber";
            this.GINNumber.ReadOnly = true;
            this.GINNumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.GINNumber.Width = 115;
            // 
            // GINDate
            // 
            this.GINDate.DataPropertyName = "GINDate";
            this.GINDate.HeaderText = "GIN Date";
            this.GINDate.Name = "GINDate";
            this.GINDate.ReadOnly = true;
            this.GINDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.GINDate.Width = 88;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "Quantity";
            this.Quantity.HeaderText = "Quantity";
            this.Quantity.Name = "Quantity";
            this.Quantity.ReadOnly = true;
            this.Quantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Quantity.Width = 85;
            // 
            // UnitCost
            // 
            this.UnitCost.DataPropertyName = "UnitCost";
            this.UnitCost.HeaderText = "Unit Cost";
            this.UnitCost.Name = "UnitCost";
            this.UnitCost.ReadOnly = true;
            this.UnitCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitCost.Width = 89;
            // 
            // chkUpdateUnitPrice
            // 
            this.chkUpdateUnitPrice.AutoSize = true;
            this.chkUpdateUnitPrice.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkUpdateUnitPrice.ForeColor = System.Drawing.Color.Black;
            this.chkUpdateUnitPrice.Location = new System.Drawing.Point(403, 9);
            this.chkUpdateUnitPrice.Name = "chkUpdateUnitPrice";
            this.chkUpdateUnitPrice.Size = new System.Drawing.Size(149, 23);
            this.chkUpdateUnitPrice.TabIndex = 231;
            this.chkUpdateUnitPrice.Text = "Update Unit Price";
            this.chkUpdateUnitPrice.UseVisualStyleBackColor = true;
            this.chkUpdateUnitPrice.CheckedChanged += new System.EventHandler(this.chkUpdateUnitPrice_CheckedChanged);
            // 
            // chkExcelUpload
            // 
            this.chkExcelUpload.AutoSize = true;
            this.chkExcelUpload.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkExcelUpload.ForeColor = System.Drawing.Color.Black;
            this.chkExcelUpload.Location = new System.Drawing.Point(663, 9);
            this.chkExcelUpload.Name = "chkExcelUpload";
            this.chkExcelUpload.Size = new System.Drawing.Size(158, 23);
            this.chkExcelUpload.TabIndex = 230;
            this.chkExcelUpload.Text = "Upload Excel Sheet";
            this.chkExcelUpload.UseVisualStyleBackColor = true;
            this.chkExcelUpload.CheckedChanged += new System.EventHandler(this.chkExcelUpload_CheckedChanged);
            // 
            // pnExcelUpload
            // 
            this.pnExcelUpload.Controls.Add(this.btnExcelUpdate);
            this.pnExcelUpload.Controls.Add(this.btnBrowse);
            this.pnExcelUpload.Controls.Add(this.dgvExcelUpdate);
            this.pnExcelUpload.Location = new System.Drawing.Point(405, 46);
            this.pnExcelUpload.Name = "pnExcelUpload";
            this.pnExcelUpload.Size = new System.Drawing.Size(818, 501);
            this.pnExcelUpload.TabIndex = 230;
            // 
            // btnExcelUpdate
            // 
            this.btnExcelUpdate.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExcelUpdate.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExcelUpdate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcelUpdate.Location = new System.Drawing.Point(685, 460);
            this.btnExcelUpdate.Name = "btnExcelUpdate";
            this.btnExcelUpdate.Size = new System.Drawing.Size(107, 35);
            this.btnExcelUpdate.TabIndex = 232;
            this.btnExcelUpdate.Text = "Update";
            this.btnExcelUpdate.UseVisualStyleBackColor = false;
            this.btnExcelUpdate.Click += new System.EventHandler(this.btnExcelUpdate_Click);
            // 
            // btnBrowse
            // 
            this.btnBrowse.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnBrowse.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnBrowse.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowse.Location = new System.Drawing.Point(525, 460);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(107, 35);
            this.btnBrowse.TabIndex = 231;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = false;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // dgvExcelUpdate
            // 
            this.dgvExcelUpdate.AllowUserToAddRows = false;
            this.dgvExcelUpdate.AllowUserToDeleteRows = false;
            this.dgvExcelUpdate.AllowUserToResizeRows = false;
            this.dgvExcelUpdate.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvExcelUpdate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvExcelUpdate.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvExcelUpdate.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvExcelUpdate.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvExcelUpdate.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn4,
            this.Remarks});
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvExcelUpdate.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgvExcelUpdate.Location = new System.Drawing.Point(3, 3);
            this.dgvExcelUpdate.MultiSelect = false;
            this.dgvExcelUpdate.Name = "dgvExcelUpdate";
            this.dgvExcelUpdate.ReadOnly = true;
            this.dgvExcelUpdate.RowHeadersVisible = false;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.ControlLight;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvExcelUpdate.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvExcelUpdate.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvExcelUpdate.Size = new System.Drawing.Size(812, 451);
            this.dgvExcelUpdate.TabIndex = 230;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "slno";
            this.dataGridViewTextBoxColumn1.HeaderText = "SL No";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Width = 60;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "ItemCode";
            this.dataGridViewTextBoxColumn2.HeaderText = "ItemCode";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn2.Width = 93;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "UnitCost";
            this.dataGridViewTextBoxColumn4.HeaderText = "Unit Cost";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn4.Width = 89;
            // 
            // Remarks
            // 
            this.Remarks.DataPropertyName = "Remarks";
            this.Remarks.HeaderText = "Remarks";
            this.Remarks.Name = "Remarks";
            this.Remarks.ReadOnly = true;
            this.Remarks.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Remarks.Width = 85;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // BtnFreezeItem
            // 
            this.BtnFreezeItem.BackColor = System.Drawing.Color.PaleGreen;
            this.BtnFreezeItem.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnFreezeItem.Location = new System.Drawing.Point(890, 3);
            this.BtnFreezeItem.Name = "BtnFreezeItem";
            this.BtnFreezeItem.Size = new System.Drawing.Size(135, 32);
            this.BtnFreezeItem.TabIndex = 232;
            this.BtnFreezeItem.Text = "Freeze Items ";
            this.BtnFreezeItem.UseVisualStyleBackColor = false;
            this.BtnFreezeItem.Visible = false;
            this.BtnFreezeItem.Click += new System.EventHandler(this.BtnFreezeItem_Click);
            // 
            // chkTransducer
            // 
            this.chkTransducer.AutoSize = true;
            this.chkTransducer.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkTransducer.ForeColor = System.Drawing.Color.DarkGreen;
            this.chkTransducer.Location = new System.Drawing.Point(191, 6);
            this.chkTransducer.Name = "chkTransducer";
            this.chkTransducer.Size = new System.Drawing.Size(190, 27);
            this.chkTransducer.TabIndex = 235;
            this.chkTransducer.Text = "Transducer Products";
            this.chkTransducer.UseVisualStyleBackColor = true;
            // 
            // chkElectronics
            // 
            this.chkElectronics.AutoSize = true;
            this.chkElectronics.Checked = true;
            this.chkElectronics.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkElectronics.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkElectronics.ForeColor = System.Drawing.Color.DarkGreen;
            this.chkElectronics.Location = new System.Drawing.Point(5, 6);
            this.chkElectronics.Name = "chkElectronics";
            this.chkElectronics.Size = new System.Drawing.Size(190, 27);
            this.chkElectronics.TabIndex = 234;
            this.chkElectronics.Text = "Electronics Products";
            this.chkElectronics.UseVisualStyleBackColor = true;
            this.chkElectronics.CheckedChanged += new System.EventHandler(this.chkElectronics_CheckedChanged);
            // 
            // frmStandardCost
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1244, 552);
            this.Controls.Add(this.chkTransducer);
            this.Controls.Add(this.chkElectronics);
            this.Controls.Add(this.BtnFreezeItem);
            this.Controls.Add(this.pnItemUpdate);
            this.Controls.Add(this.chkUpdateUnitPrice);
            this.Controls.Add(this.chkExcelUpload);
            this.Controls.Add(this.chkItemDesc);
            this.Controls.Add(this.chkItemCode);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.chklbItemList);
            this.Controls.Add(this.txtsearchitemdesc);
            this.Controls.Add(this.pnExcelUpload);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmStandardCost";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Standard Cost";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmStandardCost_FormClosing);
            this.Load += new System.EventHandler(this.frmStandardCost_Load);
            this.pnItemUpdate.ResumeLayout(false);
            this.pnItemUpdate.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewgin)).EndInit();
            this.pnExcelUpload.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvExcelUpdate)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox chkItemDesc;
        private System.Windows.Forms.CheckBox chkItemCode;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckedListBox chklbItemList;
        private System.Windows.Forms.TextBox txtsearchitemdesc;
        private System.Windows.Forms.TextBox txtItemDescription;
        private System.Windows.Forms.TextBox textpresentcost;
        private System.Windows.Forms.Label Labelpresentcost;
        private System.Windows.Forms.Label labeldescription;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.TextBox textunitcost;
        private System.Windows.Forms.Label labelunitcost;
        private System.Windows.Forms.Label lblitemcode;
        private System.Windows.Forms.TextBox txtItemCode;
        private System.Windows.Forms.Panel pnItemUpdate;
        private System.Windows.Forms.DataGridView dataGridViewgin;
        private System.Windows.Forms.DataGridViewTextBoxColumn GINNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn GINDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitCost;
        private System.Windows.Forms.CheckBox chkUpdateUnitPrice;
        private System.Windows.Forms.CheckBox chkExcelUpload;
        private System.Windows.Forms.Panel pnExcelUpload;
        private System.Windows.Forms.DataGridView dgvExcelUpdate;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btnExcelUpdate;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Remarks;
        private System.Windows.Forms.Button BtnFreezeItem;
        private System.Windows.Forms.CheckBox chkTransducer;
        private System.Windows.Forms.CheckBox chkElectronics;
        private System.Windows.Forms.Button btnExit;
    }
}
