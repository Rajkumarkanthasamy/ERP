﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Part_Master
{
    public partial class frmFoldeename : Form
    {
        #region Intialization of Local Datatables, Variables Daclaration
        DataAccessLayer DAL = new DataAccessLayer();
        DataTable dtTreeviewProductcheck = new DataTable();
        DataTable dtProductCode = new DataTable();
        bool bProductcheck = false;
        bool bProductCodecheck = false;
        string sMFolder = string.Empty;
        string sMProduct = string.Empty;
        string iImageIndex = "0";
        string sFolderTreeName = string.Empty;
        public frmFoldeename()
        {
            InitializeComponent();
        }
        #endregion

        #region Code to Verify Product or Folder Name Already Exist 
        private void btnfoldernameok_Click(object sender, EventArgs e)
        {
            frmProductMasterForm ProductMaster = new frmProductMasterForm();
            if (chkMainfolder.Checked == true)
            {
                if (!string.IsNullOrEmpty(txtproductname.Text))
                {
                    string sProductName = txtproductname.Text;
                    // txtproductcode.Text.Trim();
                    ProductMaster.fnFolderFormat = sProductName.Trim();
                    ProductMaster.fnProductCode = txtproductcode.Text;
                    ProductMaster.fnImageIndex = iImageIndex;
                    dtTreeviewProductcheck = DAL.fnGetTreeName(sProductName.Trim()).Tables[0];
                    if (dtTreeviewProductcheck.Rows.Count == 0)
                    {
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Folder Name '" + sProductName.Trim() + "' Already created. " + Environment.NewLine + " Add Prefix or Suffix to The Folder Name", "Error", 0, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    ProductMaster.fnFolderFormat = string.Empty;
                    ProductMaster.fnProductCode = string.Empty;
                    ProductMaster.fnImageIndex = string.Empty;
                    MessageBox.Show("Please Enter a Folder Name", "Error", 0, MessageBoxIcon.Error);
                }
            }
            else if (chkProduct.Checked == true )
            {
                if (!string.IsNullOrEmpty(txtproductname.Text) && !string.IsNullOrEmpty(txtproductcode.Text))
                {
                    bProductcheck = false;
                    bProductCodecheck = false;
                    string sName = txtproductname.Text;
                    string sTrimProductName = txtproductname.Text;
                    ProductMaster.fnFolderFormat = sTrimProductName.Trim();
                    string sTrimProductCode = txtproductcode.Text;
                    ProductMaster.fnProductCode = sTrimProductCode.Trim();
                    ProductMaster.fnImageIndex = iImageIndex;
                    iImageIndex = "3";
                    dtTreeviewProductcheck = DAL.fnGetLastNodeId(sFolderTreeName).Tables["LastNodeId"];

                    dtTreeviewProductcheck = DAL.fnParentId(dtTreeviewProductcheck.Rows[0]["NodeID"].ToString()).Tables[0];

                    foreach (DataRow dr in dtTreeviewProductcheck.Rows)
                    {
                        if (dr["Name"].ToString().ToUpper() == sTrimProductName.Trim().ToUpper())
                        {
                            bProductcheck = true;
                        }
                    }

                    dtProductCode = DAL.fnProductCode(sTrimProductCode).Tables[0];
                    foreach (DataRow dr in dtProductCode.Rows)
                    {
                        if (dr["ProductCode"].ToString().ToUpper() == sTrimProductCode.Trim().ToUpper())
                        {
                            bProductCodecheck = true;
                        }
                    }
                    if (bProductcheck == false && bProductCodecheck == false)
                    {
                        this.Close();
                    }
                    if (bProductcheck == true)
                    {
                        MessageBox.Show("Same Product name '" + sTrimProductName.Trim() + "' already created in '" + sFolderTreeName + "' folder. " + Environment.NewLine + "Add Prefix or Suffix to The Product Name", "Error", 0, MessageBoxIcon.Error);
                    }
                    if (bProductCodecheck == true)
                    {
                        MessageBox.Show("The Product Code '" + sTrimProductCode.Trim() + "' already used for Prodcut '" + dtProductCode.Rows[0]["name"].ToString() + "' .", "Error", 0, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    ProductMaster.fnFolderFormat = string.Empty;
                    ProductMaster.fnProductCode = string.Empty;
                    ProductMaster.fnImageIndex = string.Empty;
                    MessageBox.Show("Please Enter a Product Code or Product Name", "Error", 0, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please Select Folder Type", "Error", 0, MessageBoxIcon.Error);
            }
        }
        #endregion

        #region Function to Get Base Product Name or Folder Name
        public void fnName(string FolderAddress)
        {
            lbladdressbar.Text = FolderAddress;
        }

        public void fnFolderorProduct(string sMainFolder, string sProduct)
        {
            sMFolder = string.Empty;
            sMProduct = string.Empty;

            sMFolder = sMainFolder;
            sMProduct = sProduct;
        }
        public void fnFolderorProductLoad(string sMainFolder, string sProduct)
        {
            this.chkKanban.Checked = false;

            if (string.IsNullOrEmpty(sProduct) && !string.IsNullOrEmpty(sMainFolder))
            {
                this.chkMainfolder.Checked = true;
                chkMainfolder.Enabled = false;
                chkProduct.Visible = false;
                txtproductcode.Visible = false;
                chkMainfolder.Visible = true;
                chkMainfolder.ForeColor = Color.BurlyWood;
                chkKanban.Visible = false;
            }
            else if (!string.IsNullOrEmpty(sProduct) && string.IsNullOrEmpty(sMainFolder))
            {
                this.chkProduct.Checked = true;
                chkProduct.Enabled = false;
                chkMainfolder.Visible = false;
                chkProduct.Visible = true;
                txtproductcode.Visible = true;
                chkMainfolder.ForeColor = Color.BurlyWood;
                chkKanban.Visible = true;
            }
            else if (string.IsNullOrEmpty(sProduct) && string.IsNullOrEmpty(sMainFolder))
            {
                chkMainfolder.Enabled = true;
                chkProduct.Enabled = true;
                chkMainfolder.Visible = true;
                chkProduct.Visible = true;
                txtproductcode.Visible = true;
                this.chkMainfolder.Checked = true;
            }
        }
       
        public void fnTreeName(string TreeName)
        {
            sFolderTreeName = TreeName;
        }
        #endregion

        #region Code to Cancel Adding a Folder or Product
        private void btncancel_Click(object sender, EventArgs e)
        {
            frmProductMasterForm ProductMaster = new frmProductMasterForm();
            ProductMaster.fnFolderFormat = string.Empty;
            ProductMaster.fnProductCode = string.Empty;
            ProductMaster.fnImageIndex = string.Empty;
            this.Close();
        }
        #endregion

        #region Code to Load Form With Root Folder Details
        private void frmFoldeename_Load(object sender, EventArgs e)
        {
            txtproductcode.Text = string.Empty;
            txtproductname.Text = string.Empty;
            fnFolderorProductLoad(sMFolder, sMProduct);
        }
        #endregion

        #region Code to Create  Folder
        private void chkMainfolder_CheckedChanged(object sender, EventArgs e)
        {
            if (chkMainfolder.CheckState == CheckState.Checked)
            {
                txtproductcode.Enabled = false;
                iImageIndex = "0";
                chkProduct.Checked = false;
                txtproductcode.Text = string.Empty;
                txtproductname.Text = string.Empty;
            }
            else
            {
                chkProduct.Checked = true;
            }
        }
        #endregion

        #region Code to Create a Product
        private void chkProduct_CheckedChanged(object sender, EventArgs e)
        {
            if (chkProduct.CheckState == CheckState.Checked && chkKanban.CheckState==CheckState.Unchecked)
            {
                iImageIndex = "3";
                txtproductcode.Enabled = true;
                chkMainfolder.Checked = false;
                txtproductcode.Text = string.Empty;
                txtproductname.Text = string.Empty;

            }
           
            else
            {
                chkMainfolder.Checked = true;
            }
        }
        #endregion

        #region Code to Create KanBan Product
        private void chkKanban_CheckedChanged(object sender, EventArgs e)
        {
            if (chkProduct.CheckState == CheckState.Checked && chkKanban.CheckState == CheckState.Checked)
            {
                iImageIndex = "4";
            }
            else
            {
                iImageIndex = "3";
            }
        }
        #endregion

    }
}
