﻿namespace Erp_Project_With_Buttons.Part_Master
{
    partial class frmProductMasterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProductMasterForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            this.gbSearchOptions = new System.Windows.Forms.GroupBox();
            this.pnCost = new System.Windows.Forms.Panel();
            this.lbllatest = new System.Windows.Forms.Label();
            this.lblproductcost = new System.Windows.Forms.Label();
            this.lblLatestCost = new System.Windows.Forms.Label();
            this.lblpcost = new System.Windows.Forms.Label();
            this.cmbWorkDescription = new System.Windows.Forms.ComboBox();
            this.chkxcelupload = new System.Windows.Forms.CheckBox();
            this.lblItemcodeorName = new System.Windows.Forms.Label();
            this.chkItemSaerch = new System.Windows.Forms.CheckBox();
            this.btnaddtobom = new System.Windows.Forms.Button();
            this.dgBOMList = new System.Windows.Forms.DataGridView();
            this.ProductType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BOMQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uFixedCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LatestCost1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BSpecification = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BMfgPartNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BMake = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BLocation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BVendor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BDrawingNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lbltotalitems = new System.Windows.Forms.Label();
            this.txtItemSearch = new System.Windows.Forms.TextBox();
            this.lblitemcount = new System.Windows.Forms.Label();
            this.pnexcelupload = new System.Windows.Forms.Panel();
            this.lbladditemcount = new System.Windows.Forms.Label();
            this.lblbomitemlist = new System.Windows.Forms.Label();
            this.btnbrowse = new System.Windows.Forms.Button();
            this.txtbrowseaddres = new System.Windows.Forms.TextBox();
            this.dgItemList = new System.Windows.Forms.DataGridView();
            this.add = new System.Windows.Forms.DataGridViewButtonColumn();
            this.ItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uncost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Type = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DrawingNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MfgPartNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.make = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.specification = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Location = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vendorname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IProductType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FixedCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvxcelupload = new System.Windows.Forms.DataGridView();
            this.xslno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xItemDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xMfgPartNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xMake = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xUnitcost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xSpecification = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xItemType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xLocation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xVendor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xDrawingno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Version = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.XProductType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnItemSearch = new System.Windows.Forms.Panel();
            this.chkItemDesc = new System.Windows.Forms.CheckBox();
            this.chkItemCode = new System.Windows.Forms.CheckBox();
            this.txtItemDescription = new System.Windows.Forms.TextBox();
            this.lblItemDescription = new System.Windows.Forms.Label();
            this.pnProductcode = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.comspecification = new System.Windows.Forms.TextBox();
            this.btnSaveSubProduct = new System.Windows.Forms.Button();
            this.txtProductCost = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtProductCode = new System.Windows.Forms.TextBox();
            this.txtProductName = new System.Windows.Forms.TextBox();
            this.lblpname = new System.Windows.Forms.Label();
            this.lblpcode = new System.Windows.Forms.Label();
            this.btnUpdateProduct = new System.Windows.Forms.Button();
            this.tvProduct = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.gbControlButtons = new System.Windows.Forms.GroupBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnexcelexport = new System.Windows.Forms.Button();
            this.btnAuthorise = new System.Windows.Forms.Button();
            this.btnAddProduct = new System.Windows.Forms.Button();
            this.lblFolderMessage = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblIndent = new System.Windows.Forms.Label();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.lblbomby = new System.Windows.Forms.Label();
            this.btnassignuser = new System.Windows.Forms.Button();
            this.dgvallBOM = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Allitemtype = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LatestCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.allAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ParentID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnrename = new System.Windows.Forms.Button();
            this.txtsearchtree = new System.Windows.Forms.TextBox();
            this.btnsearchtree = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnAddSubProduct = new System.Windows.Forms.Button();
            this.chkProductCode = new System.Windows.Forms.CheckBox();
            this.cmbVersion = new System.Windows.Forms.ComboBox();
            this.lblVersion = new System.Windows.Forms.Label();
            this.cleartreeview = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.gbSearchOptions.SuspendLayout();
            this.pnCost.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgBOMList)).BeginInit();
            this.pnexcelupload.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgItemList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvxcelupload)).BeginInit();
            this.pnItemSearch.SuspendLayout();
            this.pnProductcode.SuspendLayout();
            this.gbControlButtons.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvallBOM)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbSearchOptions
            // 
            this.gbSearchOptions.Controls.Add(this.pnCost);
            this.gbSearchOptions.Controls.Add(this.cmbWorkDescription);
            this.gbSearchOptions.Controls.Add(this.chkxcelupload);
            this.gbSearchOptions.Controls.Add(this.lblItemcodeorName);
            this.gbSearchOptions.Controls.Add(this.chkItemSaerch);
            this.gbSearchOptions.Controls.Add(this.btnaddtobom);
            this.gbSearchOptions.Controls.Add(this.dgBOMList);
            this.gbSearchOptions.Controls.Add(this.lbltotalitems);
            this.gbSearchOptions.Controls.Add(this.txtItemSearch);
            this.gbSearchOptions.Controls.Add(this.lblitemcount);
            this.gbSearchOptions.Controls.Add(this.pnexcelupload);
            this.gbSearchOptions.Controls.Add(this.dgItemList);
            this.gbSearchOptions.Controls.Add(this.dgvxcelupload);
            this.gbSearchOptions.Controls.Add(this.pnItemSearch);
            this.gbSearchOptions.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.gbSearchOptions.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbSearchOptions.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.gbSearchOptions.Location = new System.Drawing.Point(377, 133);
            this.gbSearchOptions.Name = "gbSearchOptions";
            this.gbSearchOptions.Size = new System.Drawing.Size(922, 511);
            this.gbSearchOptions.TabIndex = 7;
            this.gbSearchOptions.TabStop = false;
            // 
            // pnCost
            // 
            this.pnCost.Controls.Add(this.lbllatest);
            this.pnCost.Controls.Add(this.lblproductcost);
            this.pnCost.Controls.Add(this.lblLatestCost);
            this.pnCost.Controls.Add(this.lblpcost);
            this.pnCost.Location = new System.Drawing.Point(346, 487);
            this.pnCost.Name = "pnCost";
            this.pnCost.Size = new System.Drawing.Size(577, 24);
            this.pnCost.TabIndex = 133;
            // 
            // lbllatest
            // 
            this.lbllatest.AutoSize = true;
            this.lbllatest.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbllatest.ForeColor = System.Drawing.Color.Black;
            this.lbllatest.Location = new System.Drawing.Point(26, 0);
            this.lbllatest.Name = "lbllatest";
            this.lbllatest.Size = new System.Drawing.Size(103, 23);
            this.lbllatest.TabIndex = 131;
            this.lbllatest.Text = "Latest Cost:";
            this.lbllatest.Visible = false;
            // 
            // lblproductcost
            // 
            this.lblproductcost.AutoSize = true;
            this.lblproductcost.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblproductcost.ForeColor = System.Drawing.Color.Red;
            this.lblproductcost.Location = new System.Drawing.Point(400, 0);
            this.lblproductcost.Name = "lblproductcost";
            this.lblproductcost.Size = new System.Drawing.Size(20, 23);
            this.lblproductcost.TabIndex = 69;
            this.lblproductcost.Text = "0";
            this.lblproductcost.Visible = false;
            // 
            // lblLatestCost
            // 
            this.lblLatestCost.AutoSize = true;
            this.lblLatestCost.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLatestCost.ForeColor = System.Drawing.Color.Red;
            this.lblLatestCost.Location = new System.Drawing.Point(124, 0);
            this.lblLatestCost.Name = "lblLatestCost";
            this.lblLatestCost.Size = new System.Drawing.Size(20, 23);
            this.lblLatestCost.TabIndex = 132;
            this.lblLatestCost.Text = "0";
            this.lblLatestCost.Visible = false;
            // 
            // lblpcost
            // 
            this.lblpcost.AutoSize = true;
            this.lblpcost.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpcost.ForeColor = System.Drawing.Color.Black;
            this.lblpcost.Location = new System.Drawing.Point(288, 0);
            this.lblpcost.Name = "lblpcost";
            this.lblpcost.Size = new System.Drawing.Size(116, 23);
            this.lblpcost.TabIndex = 66;
            this.lblpcost.Text = "Product Cost:";
            this.lblpcost.Visible = false;
            // 
            // cmbWorkDescription
            // 
            this.cmbWorkDescription.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbWorkDescription.DropDownHeight = 130;
            this.cmbWorkDescription.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbWorkDescription.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbWorkDescription.FormattingEnabled = true;
            this.cmbWorkDescription.IntegralHeight = false;
            this.cmbWorkDescription.Items.AddRange(new object[] {
            "Boughtout",
            "Machining",
            "BoughtoutMachining"});
            this.cmbWorkDescription.Location = new System.Drawing.Point(5, 251);
            this.cmbWorkDescription.Name = "cmbWorkDescription";
            this.cmbWorkDescription.Size = new System.Drawing.Size(105, 26);
            this.cmbWorkDescription.TabIndex = 172;
            this.cmbWorkDescription.Visible = false;
            this.cmbWorkDescription.SelectedIndexChanged += new System.EventHandler(this.cmbWorkDescription_SelectedIndexChanged);
            // 
            // chkxcelupload
            // 
            this.chkxcelupload.AutoSize = true;
            this.chkxcelupload.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkxcelupload.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.chkxcelupload.Location = new System.Drawing.Point(660, 191);
            this.chkxcelupload.Name = "chkxcelupload";
            this.chkxcelupload.Size = new System.Drawing.Size(158, 23);
            this.chkxcelupload.TabIndex = 66;
            this.chkxcelupload.Text = "Add BOM by EXCEL";
            this.chkxcelupload.UseVisualStyleBackColor = true;
            this.chkxcelupload.CheckedChanged += new System.EventHandler(this.chkxcelupload_CheckedChanged_1);
            // 
            // lblItemcodeorName
            // 
            this.lblItemcodeorName.AutoSize = true;
            this.lblItemcodeorName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemcodeorName.ForeColor = System.Drawing.Color.Black;
            this.lblItemcodeorName.Location = new System.Drawing.Point(159, 191);
            this.lblItemcodeorName.Name = "lblItemcodeorName";
            this.lblItemcodeorName.Size = new System.Drawing.Size(63, 19);
            this.lblItemcodeorName.TabIndex = 130;
            this.lblItemcodeorName.Text = "Search :";
            this.lblItemcodeorName.Visible = false;
            // 
            // chkItemSaerch
            // 
            this.chkItemSaerch.AutoSize = true;
            this.chkItemSaerch.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemSaerch.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.chkItemSaerch.Location = new System.Drawing.Point(510, 191);
            this.chkItemSaerch.Name = "chkItemSaerch";
            this.chkItemSaerch.Size = new System.Drawing.Size(150, 23);
            this.chkItemSaerch.TabIndex = 65;
            this.chkItemSaerch.Text = "Add BOM by Item";
            this.chkItemSaerch.UseVisualStyleBackColor = true;
            this.chkItemSaerch.CheckedChanged += new System.EventHandler(this.chkItemSaerch_CheckedChanged_1);
            // 
            // btnaddtobom
            // 
            this.btnaddtobom.Enabled = false;
            this.btnaddtobom.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaddtobom.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnaddtobom.Location = new System.Drawing.Point(823, 190);
            this.btnaddtobom.Name = "btnaddtobom";
            this.btnaddtobom.Size = new System.Drawing.Size(93, 25);
            this.btnaddtobom.TabIndex = 3;
            this.btnaddtobom.Text = "Add to BOM";
            this.btnaddtobom.UseVisualStyleBackColor = true;
            this.btnaddtobom.Click += new System.EventHandler(this.btnaddtobom_Click);
            // 
            // dgBOMList
            // 
            this.dgBOMList.AllowUserToAddRows = false;
            this.dgBOMList.AllowUserToDeleteRows = false;
            this.dgBOMList.AllowUserToResizeRows = false;
            this.dgBOMList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgBOMList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgBOMList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgBOMList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgBOMList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgBOMList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProductType,
            this.uItemCode,
            this.uItemDescription,
            this.uType,
            this.BOMQuantity,
            this.uFixedCost,
            this.UnitCost,
            this.LatestCost1,
            this.Amount,
            this.BSpecification,
            this.BMfgPartNo,
            this.BMake,
            this.BLocation,
            this.BVendor,
            this.BDrawingNo});
            this.dgBOMList.EnableHeadersVisualStyles = false;
            this.dgBOMList.Location = new System.Drawing.Point(5, 221);
            this.dgBOMList.MultiSelect = false;
            this.dgBOMList.Name = "dgBOMList";
            this.dgBOMList.RowHeadersVisible = false;
            this.dgBOMList.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgBOMList.Size = new System.Drawing.Size(911, 250);
            this.dgBOMList.TabIndex = 61;
            this.dgBOMList.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgBOMList_CellBeginEdit);
            this.dgBOMList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgBOMList_CellClick);
            this.dgBOMList.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgBOMList_CellEndEdit);
            this.dgBOMList.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgBOMList_EditingControlShowing);
            this.dgBOMList.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgBOMList_KeyUp);
            // 
            // ProductType
            // 
            this.ProductType.DataPropertyName = "ProductType";
            this.ProductType.HeaderText = "ProductType";
            this.ProductType.Name = "ProductType";
            this.ProductType.ReadOnly = true;
            this.ProductType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductType.Width = 94;
            // 
            // uItemCode
            // 
            this.uItemCode.DataPropertyName = "ItemCode";
            this.uItemCode.HeaderText = "Item Code";
            this.uItemCode.Name = "uItemCode";
            this.uItemCode.ReadOnly = true;
            this.uItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.uItemCode.Width = 81;
            // 
            // uItemDescription
            // 
            this.uItemDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.uItemDescription.DataPropertyName = "ItemDescription";
            this.uItemDescription.HeaderText = "Item Desc";
            this.uItemDescription.Name = "uItemDescription";
            this.uItemDescription.ReadOnly = true;
            this.uItemDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.uItemDescription.Width = 84;
            // 
            // uType
            // 
            this.uType.DataPropertyName = "Type";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.uType.DefaultCellStyle = dataGridViewCellStyle2;
            this.uType.HeaderText = "ItemType";
            this.uType.Name = "uType";
            this.uType.ReadOnly = true;
            this.uType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.uType.Width = 74;
            // 
            // BOMQuantity
            // 
            this.BOMQuantity.DataPropertyName = "Quantity";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle3.NullValue = "0";
            this.BOMQuantity.DefaultCellStyle = dataGridViewCellStyle3;
            this.BOMQuantity.HeaderText = "Quantity";
            this.BOMQuantity.Name = "BOMQuantity";
            this.BOMQuantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.BOMQuantity.Width = 71;
            // 
            // uFixedCost
            // 
            this.uFixedCost.DataPropertyName = "FixedCost";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.uFixedCost.DefaultCellStyle = dataGridViewCellStyle4;
            this.uFixedCost.HeaderText = "FixedCost";
            this.uFixedCost.Name = "uFixedCost";
            this.uFixedCost.Width = 97;
            // 
            // UnitCost
            // 
            this.UnitCost.DataPropertyName = "UnitCost";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.Format = "N2";
            dataGridViewCellStyle5.NullValue = null;
            this.UnitCost.DefaultCellStyle = dataGridViewCellStyle5;
            this.UnitCost.HeaderText = "Unit Cost";
            this.UnitCost.Name = "UnitCost";
            this.UnitCost.ReadOnly = true;
            this.UnitCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitCost.Width = 75;
            // 
            // LatestCost1
            // 
            this.LatestCost1.DataPropertyName = "LatestCost";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.Format = "N2";
            dataGridViewCellStyle6.NullValue = null;
            this.LatestCost1.DefaultCellStyle = dataGridViewCellStyle6;
            this.LatestCost1.HeaderText = "Latest Cost";
            this.LatestCost1.Name = "LatestCost1";
            this.LatestCost1.ReadOnly = true;
            this.LatestCost1.Visible = false;
            this.LatestCost1.Width = 107;
            // 
            // Amount
            // 
            this.Amount.DataPropertyName = "Amount";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.Format = "N2";
            dataGridViewCellStyle7.NullValue = null;
            this.Amount.DefaultCellStyle = dataGridViewCellStyle7;
            this.Amount.HeaderText = "Amount";
            this.Amount.Name = "Amount";
            this.Amount.ReadOnly = true;
            this.Amount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Amount.Width = 65;
            // 
            // BSpecification
            // 
            this.BSpecification.DataPropertyName = "Specification";
            this.BSpecification.HeaderText = "Specification";
            this.BSpecification.Name = "BSpecification";
            this.BSpecification.ReadOnly = true;
            this.BSpecification.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.BSpecification.Width = 97;
            // 
            // BMfgPartNo
            // 
            this.BMfgPartNo.DataPropertyName = "MfgPartNo";
            this.BMfgPartNo.HeaderText = "MfgPartNo";
            this.BMfgPartNo.Name = "BMfgPartNo";
            this.BMfgPartNo.ReadOnly = true;
            this.BMfgPartNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.BMfgPartNo.Width = 85;
            // 
            // BMake
            // 
            this.BMake.DataPropertyName = "Make";
            this.BMake.HeaderText = "Make";
            this.BMake.Name = "BMake";
            this.BMake.ReadOnly = true;
            this.BMake.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.BMake.Width = 50;
            // 
            // BLocation
            // 
            this.BLocation.DataPropertyName = "Location";
            this.BLocation.HeaderText = "Location";
            this.BLocation.Name = "BLocation";
            this.BLocation.ReadOnly = true;
            this.BLocation.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.BLocation.Width = 70;
            // 
            // BVendor
            // 
            this.BVendor.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.BVendor.DataPropertyName = "Vendor";
            this.BVendor.HeaderText = "Vendor";
            this.BVendor.Name = "BVendor";
            this.BVendor.ReadOnly = true;
            this.BVendor.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.BVendor.Width = 82;
            // 
            // BDrawingNo
            // 
            this.BDrawingNo.DataPropertyName = "DrawingNo";
            this.BDrawingNo.HeaderText = "DrawingNo";
            this.BDrawingNo.Name = "BDrawingNo";
            this.BDrawingNo.ReadOnly = true;
            this.BDrawingNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.BDrawingNo.Width = 87;
            // 
            // lbltotalitems
            // 
            this.lbltotalitems.AutoSize = true;
            this.lbltotalitems.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotalitems.ForeColor = System.Drawing.Color.Black;
            this.lbltotalitems.Location = new System.Drawing.Point(5, 191);
            this.lbltotalitems.Name = "lbltotalitems";
            this.lbltotalitems.Size = new System.Drawing.Size(126, 19);
            this.lbltotalitems.TabIndex = 62;
            this.lbltotalitems.Text = "Total BOM Items:";
            this.lbltotalitems.Visible = false;
            // 
            // txtItemSearch
            // 
            this.txtItemSearch.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.txtItemSearch.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemSearch.Location = new System.Drawing.Point(221, 190);
            this.txtItemSearch.Name = "txtItemSearch";
            this.txtItemSearch.Size = new System.Drawing.Size(283, 23);
            this.txtItemSearch.TabIndex = 129;
            this.txtItemSearch.Visible = false;
            this.txtItemSearch.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemSearch_KeyUp);
            // 
            // lblitemcount
            // 
            this.lblitemcount.AutoSize = true;
            this.lblitemcount.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblitemcount.ForeColor = System.Drawing.Color.Red;
            this.lblitemcount.Location = new System.Drawing.Point(129, 191);
            this.lblitemcount.Name = "lblitemcount";
            this.lblitemcount.Size = new System.Drawing.Size(17, 19);
            this.lblitemcount.TabIndex = 63;
            this.lblitemcount.Text = "0";
            this.lblitemcount.Visible = false;
            // 
            // pnexcelupload
            // 
            this.pnexcelupload.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnexcelupload.Controls.Add(this.lbladditemcount);
            this.pnexcelupload.Controls.Add(this.lblbomitemlist);
            this.pnexcelupload.Controls.Add(this.btnbrowse);
            this.pnexcelupload.Controls.Add(this.txtbrowseaddres);
            this.pnexcelupload.Location = new System.Drawing.Point(9, 17);
            this.pnexcelupload.Name = "pnexcelupload";
            this.pnexcelupload.Size = new System.Drawing.Size(910, 32);
            this.pnexcelupload.TabIndex = 8;
            // 
            // lbladditemcount
            // 
            this.lbladditemcount.AutoSize = true;
            this.lbladditemcount.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbladditemcount.ForeColor = System.Drawing.Color.Red;
            this.lbladditemcount.Location = new System.Drawing.Point(867, 5);
            this.lbladditemcount.Name = "lbladditemcount";
            this.lbladditemcount.Size = new System.Drawing.Size(20, 23);
            this.lbladditemcount.TabIndex = 64;
            this.lbladditemcount.Text = "0";
            // 
            // lblbomitemlist
            // 
            this.lblbomitemlist.AutoSize = true;
            this.lblbomitemlist.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbomitemlist.ForeColor = System.Drawing.Color.Black;
            this.lblbomitemlist.Location = new System.Drawing.Point(687, 4);
            this.lblbomitemlist.Name = "lblbomitemlist";
            this.lblbomitemlist.Size = new System.Drawing.Size(187, 23);
            this.lblbomitemlist.TabIndex = 63;
            this.lblbomitemlist.Text = "No of Items Uploaded:";
            // 
            // btnbrowse
            // 
            this.btnbrowse.BackColor = System.Drawing.Color.PaleGreen;
            this.btnbrowse.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnbrowse.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbrowse.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnbrowse.Location = new System.Drawing.Point(626, 0);
            this.btnbrowse.Name = "btnbrowse";
            this.btnbrowse.Size = new System.Drawing.Size(64, 27);
            this.btnbrowse.TabIndex = 1;
            this.btnbrowse.Text = "Browse";
            this.btnbrowse.UseVisualStyleBackColor = false;
            this.btnbrowse.Click += new System.EventHandler(this.btnbrowse_Click);
            // 
            // txtbrowseaddres
            // 
            this.txtbrowseaddres.Location = new System.Drawing.Point(1, 1);
            this.txtbrowseaddres.Name = "txtbrowseaddres";
            this.txtbrowseaddres.ReadOnly = true;
            this.txtbrowseaddres.Size = new System.Drawing.Size(619, 27);
            this.txtbrowseaddres.TabIndex = 0;
            // 
            // dgItemList
            // 
            this.dgItemList.AllowUserToAddRows = false;
            this.dgItemList.AllowUserToDeleteRows = false;
            this.dgItemList.AllowUserToResizeRows = false;
            this.dgItemList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgItemList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgItemList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgItemList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dgItemList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgItemList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.add,
            this.ItemCode,
            this.ItemDescription,
            this.Quantity,
            this.uncost,
            this.Type,
            this.DrawingNo,
            this.MfgPartNo,
            this.make,
            this.specification,
            this.Location,
            this.vendorname,
            this.IProductType,
            this.FixedCost});
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.ControlLightLight;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgItemList.DefaultCellStyle = dataGridViewCellStyle19;
            this.dgItemList.EnableHeadersVisualStyles = false;
            this.dgItemList.Location = new System.Drawing.Point(6, 49);
            this.dgItemList.MultiSelect = false;
            this.dgItemList.Name = "dgItemList";
            this.dgItemList.RowHeadersVisible = false;
            this.dgItemList.Size = new System.Drawing.Size(911, 133);
            this.dgItemList.TabIndex = 136;
            this.dgItemList.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgItemList_CellBeginEdit);
            this.dgItemList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgItemList_CellClick);
            this.dgItemList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgItemList_CellContentClick);
            this.dgItemList.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgItemList_CellEndEdit);
            this.dgItemList.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgItemList_EditingControlShowing);
            // 
            // add
            // 
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.add.DefaultCellStyle = dataGridViewCellStyle9;
            this.add.HeaderText = "Add";
            this.add.Name = "add";
            this.add.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.add.Width = 40;
            // 
            // ItemCode
            // 
            this.ItemCode.DataPropertyName = "ItemCode";
            this.ItemCode.HeaderText = "Item Code";
            this.ItemCode.Name = "ItemCode";
            this.ItemCode.ReadOnly = true;
            this.ItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemCode.Width = 81;
            // 
            // ItemDescription
            // 
            this.ItemDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ItemDescription.DataPropertyName = "ItemDescription";
            this.ItemDescription.HeaderText = "Item Desc";
            this.ItemDescription.Name = "ItemDescription";
            this.ItemDescription.ReadOnly = true;
            this.ItemDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemDescription.Width = 84;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "Qty";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle10.NullValue = null;
            this.Quantity.DefaultCellStyle = dataGridViewCellStyle10;
            this.Quantity.HeaderText = "Qty";
            this.Quantity.Name = "Quantity";
            this.Quantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Quantity.Width = 38;
            // 
            // uncost
            // 
            this.uncost.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.uncost.DataPropertyName = "UnitCost";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.uncost.DefaultCellStyle = dataGridViewCellStyle11;
            this.uncost.HeaderText = "UnitCost";
            this.uncost.Name = "uncost";
            this.uncost.ReadOnly = true;
            this.uncost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.uncost.Width = 93;
            // 
            // Type
            // 
            this.Type.DataPropertyName = "Type";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Type.DefaultCellStyle = dataGridViewCellStyle12;
            this.Type.HeaderText = "Item Type";
            this.Type.Name = "Type";
            this.Type.ReadOnly = true;
            this.Type.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Type.Width = 78;
            // 
            // DrawingNo
            // 
            this.DrawingNo.DataPropertyName = "DrawingNo";
            dataGridViewCellStyle13.NullValue = " ";
            this.DrawingNo.DefaultCellStyle = dataGridViewCellStyle13;
            this.DrawingNo.HeaderText = "DrawingNo";
            this.DrawingNo.Name = "DrawingNo";
            this.DrawingNo.ReadOnly = true;
            this.DrawingNo.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.DrawingNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DrawingNo.Width = 87;
            // 
            // MfgPartNo
            // 
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle14.NullValue = " ";
            this.MfgPartNo.DefaultCellStyle = dataGridViewCellStyle14;
            this.MfgPartNo.HeaderText = "MfgPartNo";
            this.MfgPartNo.Name = "MfgPartNo";
            this.MfgPartNo.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.MfgPartNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.MfgPartNo.Width = 85;
            // 
            // make
            // 
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle15.NullValue = " ";
            this.make.DefaultCellStyle = dataGridViewCellStyle15;
            this.make.HeaderText = "Make";
            this.make.Name = "make";
            this.make.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.make.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.make.Width = 50;
            // 
            // specification
            // 
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle16.NullValue = " ";
            this.specification.DefaultCellStyle = dataGridViewCellStyle16;
            this.specification.HeaderText = "Specification";
            this.specification.Name = "specification";
            this.specification.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.specification.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.specification.Width = 97;
            // 
            // Location
            // 
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle17.NullValue = " ";
            this.Location.DefaultCellStyle = dataGridViewCellStyle17;
            this.Location.HeaderText = "Location";
            this.Location.Name = "Location";
            this.Location.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Location.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Location.Width = 70;
            // 
            // vendorname
            // 
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.vendorname.DefaultCellStyle = dataGridViewCellStyle18;
            this.vendorname.HeaderText = "Vendorname";
            this.vendorname.Name = "vendorname";
            this.vendorname.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.vendorname.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.vendorname.Width = 96;
            // 
            // IProductType
            // 
            this.IProductType.DataPropertyName = "ItemTypeCode";
            this.IProductType.HeaderText = "ProductType";
            this.IProductType.Name = "IProductType";
            this.IProductType.ReadOnly = true;
            this.IProductType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IProductType.Width = 94;
            // 
            // FixedCost
            // 
            this.FixedCost.DataPropertyName = "FixedCost";
            this.FixedCost.HeaderText = "FixedCost";
            this.FixedCost.Name = "FixedCost";
            this.FixedCost.Width = 97;
            // 
            // dgvxcelupload
            // 
            this.dgvxcelupload.AllowUserToAddRows = false;
            this.dgvxcelupload.AllowUserToResizeRows = false;
            this.dgvxcelupload.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dgvxcelupload.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvxcelupload.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle20;
            this.dgvxcelupload.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvxcelupload.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.xslno,
            this.xItemCode,
            this.xItemDesc,
            this.xMfgPartNo,
            this.xMake,
            this.xQty,
            this.xUnitcost,
            this.xSpecification,
            this.xItemType,
            this.xLocation,
            this.xVendor,
            this.xDrawingno,
            this.Version,
            this.XProductType});
            this.dgvxcelupload.EnableHeadersVisualStyles = false;
            this.dgvxcelupload.Location = new System.Drawing.Point(7, 52);
            this.dgvxcelupload.Name = "dgvxcelupload";
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvxcelupload.RowHeadersDefaultCellStyle = dataGridViewCellStyle24;
            this.dgvxcelupload.RowHeadersVisible = false;
            this.dgvxcelupload.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvxcelupload.Size = new System.Drawing.Size(911, 132);
            this.dgvxcelupload.TabIndex = 64;
            this.dgvxcelupload.Visible = false;
            this.dgvxcelupload.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgvxcelupload_CellBeginEdit);
            this.dgvxcelupload.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvxcelupload_CellEndEdit);
            this.dgvxcelupload.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvxcelupload_EditingControlShowing);
            this.dgvxcelupload.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvxcelupload_KeyUp);
            // 
            // xslno
            // 
            this.xslno.DataPropertyName = "slno";
            this.xslno.HeaderText = "SlNo";
            this.xslno.Name = "xslno";
            this.xslno.ReadOnly = true;
            this.xslno.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xslno.Width = 44;
            // 
            // xItemCode
            // 
            this.xItemCode.DataPropertyName = "ItemCode";
            this.xItemCode.HeaderText = "ItemCode";
            this.xItemCode.Name = "xItemCode";
            this.xItemCode.ReadOnly = true;
            this.xItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xItemCode.Width = 77;
            // 
            // xItemDesc
            // 
            this.xItemDesc.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.xItemDesc.DataPropertyName = "ItemDesc";
            this.xItemDesc.HeaderText = "ItemDesc";
            this.xItemDesc.Name = "xItemDesc";
            this.xItemDesc.ReadOnly = true;
            this.xItemDesc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xItemDesc.Width = 99;
            // 
            // xMfgPartNo
            // 
            this.xMfgPartNo.DataPropertyName = "MfgPartNo";
            this.xMfgPartNo.HeaderText = "MfgPartNo";
            this.xMfgPartNo.Name = "xMfgPartNo";
            this.xMfgPartNo.ReadOnly = true;
            this.xMfgPartNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xMfgPartNo.Width = 85;
            // 
            // xMake
            // 
            this.xMake.DataPropertyName = "Make";
            this.xMake.HeaderText = "Make";
            this.xMake.Name = "xMake";
            this.xMake.ReadOnly = true;
            this.xMake.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xMake.Width = 50;
            // 
            // xQty
            // 
            this.xQty.DataPropertyName = "Qty";
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.xQty.DefaultCellStyle = dataGridViewCellStyle21;
            this.xQty.HeaderText = "Qty";
            this.xQty.Name = "xQty";
            this.xQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xQty.Width = 38;
            // 
            // xUnitcost
            // 
            this.xUnitcost.DataPropertyName = "Unitcost";
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.xUnitcost.DefaultCellStyle = dataGridViewCellStyle22;
            this.xUnitcost.HeaderText = "Unitcost ";
            this.xUnitcost.Name = "xUnitcost";
            this.xUnitcost.ReadOnly = true;
            this.xUnitcost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xUnitcost.Width = 73;
            // 
            // xSpecification
            // 
            this.xSpecification.DataPropertyName = "Specification";
            this.xSpecification.HeaderText = "Specification";
            this.xSpecification.Name = "xSpecification";
            this.xSpecification.ReadOnly = true;
            this.xSpecification.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xSpecification.Width = 97;
            // 
            // xItemType
            // 
            this.xItemType.DataPropertyName = "ItemType";
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.xItemType.DefaultCellStyle = dataGridViewCellStyle23;
            this.xItemType.HeaderText = "ItemType";
            this.xItemType.Name = "xItemType";
            this.xItemType.ReadOnly = true;
            this.xItemType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xItemType.Width = 74;
            // 
            // xLocation
            // 
            this.xLocation.DataPropertyName = "Location";
            this.xLocation.HeaderText = "Location";
            this.xLocation.Name = "xLocation";
            this.xLocation.ReadOnly = true;
            this.xLocation.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xLocation.Width = 70;
            // 
            // xVendor
            // 
            this.xVendor.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.xVendor.DataPropertyName = "Vendor";
            this.xVendor.HeaderText = "Vendor";
            this.xVendor.Name = "xVendor";
            this.xVendor.ReadOnly = true;
            this.xVendor.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xVendor.Width = 82;
            // 
            // xDrawingno
            // 
            this.xDrawingno.DataPropertyName = "Drawingno";
            this.xDrawingno.HeaderText = "Drawingno";
            this.xDrawingno.Name = "xDrawingno";
            this.xDrawingno.ReadOnly = true;
            this.xDrawingno.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xDrawingno.Width = 85;
            // 
            // Version
            // 
            this.Version.DataPropertyName = "Version";
            this.Version.HeaderText = "Version";
            this.Version.Name = "Version";
            this.Version.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Version.Width = 63;
            // 
            // XProductType
            // 
            this.XProductType.DataPropertyName = "ProductType";
            this.XProductType.HeaderText = "ProdcutType";
            this.XProductType.Name = "XProductType";
            this.XProductType.ReadOnly = true;
            this.XProductType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.XProductType.Width = 94;
            // 
            // pnItemSearch
            // 
            this.pnItemSearch.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnItemSearch.Controls.Add(this.chkItemDesc);
            this.pnItemSearch.Controls.Add(this.chkItemCode);
            this.pnItemSearch.Controls.Add(this.txtItemDescription);
            this.pnItemSearch.Controls.Add(this.lblItemDescription);
            this.pnItemSearch.Location = new System.Drawing.Point(8, 17);
            this.pnItemSearch.Name = "pnItemSearch";
            this.pnItemSearch.Size = new System.Drawing.Size(909, 32);
            this.pnItemSearch.TabIndex = 76;
            // 
            // chkItemDesc
            // 
            this.chkItemDesc.AutoSize = true;
            this.chkItemDesc.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemDesc.ForeColor = System.Drawing.Color.Black;
            this.chkItemDesc.Location = new System.Drawing.Point(223, 4);
            this.chkItemDesc.Name = "chkItemDesc";
            this.chkItemDesc.Size = new System.Drawing.Size(140, 23);
            this.chkItemDesc.TabIndex = 213;
            this.chkItemDesc.Text = "Item Description";
            this.chkItemDesc.UseVisualStyleBackColor = true;
            this.chkItemDesc.CheckedChanged += new System.EventHandler(this.chkItemDesc_CheckedChanged);
            // 
            // chkItemCode
            // 
            this.chkItemCode.AutoSize = true;
            this.chkItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemCode.ForeColor = System.Drawing.Color.Black;
            this.chkItemCode.Location = new System.Drawing.Point(120, 3);
            this.chkItemCode.Name = "chkItemCode";
            this.chkItemCode.Size = new System.Drawing.Size(97, 23);
            this.chkItemCode.TabIndex = 212;
            this.chkItemCode.Text = "Item Code";
            this.chkItemCode.UseVisualStyleBackColor = true;
            this.chkItemCode.CheckedChanged += new System.EventHandler(this.chkItemCode_CheckedChanged);
            // 
            // txtItemDescription
            // 
            this.txtItemDescription.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemDescription.Location = new System.Drawing.Point(374, 3);
            this.txtItemDescription.Name = "txtItemDescription";
            this.txtItemDescription.Size = new System.Drawing.Size(527, 23);
            this.txtItemDescription.TabIndex = 3;
            this.txtItemDescription.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtItemDescription_MouseClick);
            this.txtItemDescription.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemDescription_KeyUp);
            // 
            // lblItemDescription
            // 
            this.lblItemDescription.AutoSize = true;
            this.lblItemDescription.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemDescription.ForeColor = System.Drawing.Color.Black;
            this.lblItemDescription.Location = new System.Drawing.Point(3, 3);
            this.lblItemDescription.Name = "lblItemDescription";
            this.lblItemDescription.Size = new System.Drawing.Size(111, 19);
            this.lblItemDescription.TabIndex = 2;
            this.lblItemDescription.Text = "Search Item by";
            // 
            // pnProductcode
            // 
            this.pnProductcode.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnProductcode.Controls.Add(this.label1);
            this.pnProductcode.Controls.Add(this.comspecification);
            this.pnProductcode.Controls.Add(this.btnSaveSubProduct);
            this.pnProductcode.Controls.Add(this.txtProductCost);
            this.pnProductcode.Controls.Add(this.label2);
            this.pnProductcode.Controls.Add(this.txtProductCode);
            this.pnProductcode.Controls.Add(this.txtProductName);
            this.pnProductcode.Controls.Add(this.lblpname);
            this.pnProductcode.Controls.Add(this.lblpcode);
            this.pnProductcode.Controls.Add(this.btnUpdateProduct);
            this.pnProductcode.Location = new System.Drawing.Point(378, 4);
            this.pnProductcode.Name = "pnProductcode";
            this.pnProductcode.Size = new System.Drawing.Size(922, 132);
            this.pnProductcode.TabIndex = 70;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(9, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 19);
            this.label1.TabIndex = 497;
            this.label1.Text = "Description:";
            // 
            // comspecification
            // 
            this.comspecification.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.comspecification.Location = new System.Drawing.Point(105, 65);
            this.comspecification.MaxLength = 1000;
            this.comspecification.Multiline = true;
            this.comspecification.Name = "comspecification";
            this.comspecification.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.comspecification.Size = new System.Drawing.Size(799, 60);
            this.comspecification.TabIndex = 496;
            // 
            // btnSaveSubProduct
            // 
            this.btnSaveSubProduct.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSaveSubProduct.Enabled = false;
            this.btnSaveSubProduct.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSaveSubProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveSubProduct.Location = new System.Drawing.Point(779, 36);
            this.btnSaveSubProduct.Name = "btnSaveSubProduct";
            this.btnSaveSubProduct.Size = new System.Drawing.Size(81, 27);
            this.btnSaveSubProduct.TabIndex = 130;
            this.btnSaveSubProduct.Text = "Save";
            this.btnSaveSubProduct.UseVisualStyleBackColor = false;
            this.btnSaveSubProduct.Visible = false;
            this.btnSaveSubProduct.Click += new System.EventHandler(this.btnSaveSubProduct_Click);
            // 
            // txtProductCost
            // 
            this.txtProductCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProductCost.Location = new System.Drawing.Point(609, 38);
            this.txtProductCost.Name = "txtProductCost";
            this.txtProductCost.Size = new System.Drawing.Size(153, 21);
            this.txtProductCost.TabIndex = 74;
            this.txtProductCost.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtProductCost_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(504, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 19);
            this.label2.TabIndex = 73;
            this.label2.Text = "Product Price:";
            // 
            // txtProductCode
            // 
            this.txtProductCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProductCode.Location = new System.Drawing.Point(108, 36);
            this.txtProductCode.Name = "txtProductCode";
            this.txtProductCode.Size = new System.Drawing.Size(263, 21);
            this.txtProductCode.TabIndex = 70;
            // 
            // txtProductName
            // 
            this.txtProductName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProductName.Location = new System.Drawing.Point(108, 9);
            this.txtProductName.Name = "txtProductName";
            this.txtProductName.Size = new System.Drawing.Size(801, 21);
            this.txtProductName.TabIndex = 69;
            // 
            // lblpname
            // 
            this.lblpname.AutoSize = true;
            this.lblpname.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpname.ForeColor = System.Drawing.Color.Black;
            this.lblpname.Location = new System.Drawing.Point(-4, 10);
            this.lblpname.Name = "lblpname";
            this.lblpname.Size = new System.Drawing.Size(112, 19);
            this.lblpname.TabIndex = 64;
            this.lblpname.Text = "Product Name:";
            // 
            // lblpcode
            // 
            this.lblpcode.AutoSize = true;
            this.lblpcode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpcode.ForeColor = System.Drawing.Color.Black;
            this.lblpcode.Location = new System.Drawing.Point(2, 38);
            this.lblpcode.Name = "lblpcode";
            this.lblpcode.Size = new System.Drawing.Size(106, 19);
            this.lblpcode.TabIndex = 65;
            this.lblpcode.Text = "Product Code:";
            // 
            // btnUpdateProduct
            // 
            this.btnUpdateProduct.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateProduct.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnUpdateProduct.Location = new System.Drawing.Point(880, 10);
            this.btnUpdateProduct.Name = "btnUpdateProduct";
            this.btnUpdateProduct.Size = new System.Drawing.Size(16, 20);
            this.btnUpdateProduct.TabIndex = 75;
            this.btnUpdateProduct.Text = "Update";
            this.btnUpdateProduct.UseVisualStyleBackColor = true;
            this.btnUpdateProduct.Visible = false;
            this.btnUpdateProduct.Click += new System.EventHandler(this.btnUpdateProduct_Click);
            // 
            // tvProduct
            // 
            this.tvProduct.Cursor = System.Windows.Forms.Cursors.Default;
            this.tvProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tvProduct.HideSelection = false;
            this.tvProduct.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.tvProduct.Location = new System.Drawing.Point(1, 122);
            this.tvProduct.Name = "tvProduct";
            this.tvProduct.Size = new System.Drawing.Size(364, 458);
            this.tvProduct.StateImageList = this.imageList1;
            this.tvProduct.TabIndex = 9;
            this.tvProduct.AfterLabelEdit += new System.Windows.Forms.NodeLabelEditEventHandler(this.tvProduct_AfterLabelEdit);
            this.tvProduct.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvProduct_AfterSelect);
            this.tvProduct.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.tvProduct_NodeMouseClick);
            this.tvProduct.KeyUp += new System.Windows.Forms.KeyEventHandler(this.tvProduct_KeyUp);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "folderopened_yellow.ico");
            this.imageList1.Images.SetKeyName(1, "diagram_v2_17.ico");
            this.imageList1.Images.SetKeyName(2, "Dryicons-Aesthetica-2-Process-accept.ico");
            this.imageList1.Images.SetKeyName(3, "Dryicons-Aesthetica-2-Process-remove.ico");
            this.imageList1.Images.SetKeyName(4, "Rafiqul-Hassan-Blogger-Settings.ico");
            // 
            // gbControlButtons
            // 
            this.gbControlButtons.Controls.Add(this.btnExit);
            this.gbControlButtons.Controls.Add(this.btnexcelexport);
            this.gbControlButtons.Controls.Add(this.btnAuthorise);
            this.gbControlButtons.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.gbControlButtons.Location = new System.Drawing.Point(378, 641);
            this.gbControlButtons.Name = "gbControlButtons";
            this.gbControlButtons.Size = new System.Drawing.Size(922, 42);
            this.gbControlButtons.TabIndex = 59;
            this.gbControlButtons.TabStop = false;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(767, 10);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(125, 43);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnexcelexport
            // 
            this.btnexcelexport.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnexcelexport.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnexcelexport.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexcelexport.Location = new System.Drawing.Point(432, 9);
            this.btnexcelexport.Name = "btnexcelexport";
            this.btnexcelexport.Size = new System.Drawing.Size(140, 44);
            this.btnexcelexport.TabIndex = 8;
            this.btnexcelexport.Text = "Export to Excel ";
            this.btnexcelexport.UseVisualStyleBackColor = false;
            this.btnexcelexport.Visible = false;
            this.btnexcelexport.Click += new System.EventHandler(this.btnexcelexport_Click);
            // 
            // btnAuthorise
            // 
            this.btnAuthorise.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAuthorise.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAuthorise.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAuthorise.Location = new System.Drawing.Point(607, 10);
            this.btnAuthorise.Name = "btnAuthorise";
            this.btnAuthorise.Size = new System.Drawing.Size(125, 43);
            this.btnAuthorise.TabIndex = 8;
            this.btnAuthorise.Text = "Authorise";
            this.btnAuthorise.UseVisualStyleBackColor = false;
            this.btnAuthorise.Visible = false;
            this.btnAuthorise.Click += new System.EventHandler(this.btnAuthorise_Click);
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAddProduct.Enabled = false;
            this.btnAddProduct.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAddProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddProduct.Location = new System.Drawing.Point(2, 590);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(24, 32);
            this.btnAddProduct.TabIndex = 11;
            this.btnAddProduct.Text = "Add Product";
            this.btnAddProduct.UseVisualStyleBackColor = false;
            this.btnAddProduct.Visible = false;
            this.btnAddProduct.Click += new System.EventHandler(this.btnAddProduct_Click);
            // 
            // lblFolderMessage
            // 
            this.lblFolderMessage.AutoSize = true;
            this.lblFolderMessage.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFolderMessage.ForeColor = System.Drawing.Color.Red;
            this.lblFolderMessage.Location = new System.Drawing.Point(628, 301);
            this.lblFolderMessage.Name = "lblFolderMessage";
            this.lblFolderMessage.Size = new System.Drawing.Size(385, 26);
            this.lblFolderMessage.TabIndex = 60;
            this.lblFolderMessage.Text = "select a product to view or add items";
            this.lblFolderMessage.Visible = false;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.lblIndent);
            this.panel2.Location = new System.Drawing.Point(3, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(371, 39);
            this.panel2.TabIndex = 121;
            // 
            // lblIndent
            // 
            this.lblIndent.AutoSize = true;
            this.lblIndent.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndent.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblIndent.Location = new System.Drawing.Point(69, 3);
            this.lblIndent.Name = "lblIndent";
            this.lblIndent.Size = new System.Drawing.Size(189, 33);
            this.lblIndent.TabIndex = 11;
            this.lblIndent.Text = "Product Master";
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.ForeColor = System.Drawing.Color.Black;
            this.lblWelcome.Location = new System.Drawing.Point(-3, 4);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(92, 22);
            this.lblWelcome.TabIndex = 123;
            this.lblWelcome.Text = "Welcome :";
            // 
            // lblbomby
            // 
            this.lblbomby.AutoSize = true;
            this.lblbomby.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbomby.ForeColor = System.Drawing.Color.Black;
            this.lblbomby.Location = new System.Drawing.Point(88, 4);
            this.lblbomby.Name = "lblbomby";
            this.lblbomby.Size = new System.Drawing.Size(0, 22);
            this.lblbomby.TabIndex = 122;
            // 
            // btnassignuser
            // 
            this.btnassignuser.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnassignuser.Enabled = false;
            this.btnassignuser.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnassignuser.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnassignuser.Location = new System.Drawing.Point(49, 590);
            this.btnassignuser.Name = "btnassignuser";
            this.btnassignuser.Size = new System.Drawing.Size(151, 32);
            this.btnassignuser.TabIndex = 126;
            this.btnassignuser.Text = "Add Product Users";
            this.btnassignuser.UseVisualStyleBackColor = false;
            this.btnassignuser.Click += new System.EventHandler(this.btnassignuser_Click);
            // 
            // dgvallBOM
            // 
            this.dgvallBOM.AllowUserToAddRows = false;
            this.dgvallBOM.AllowUserToDeleteRows = false;
            this.dgvallBOM.AllowUserToResizeRows = false;
            this.dgvallBOM.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvallBOM.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            this.dgvallBOM.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvallBOM.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle25.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle25.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvallBOM.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle25;
            this.dgvallBOM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvallBOM.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.Allitemtype,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.LatestCost,
            this.allAmount,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.ParentID});
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle33.BackColor = System.Drawing.Color.Gainsboro;
            dataGridViewCellStyle33.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle33.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle33.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle33.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle33.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvallBOM.DefaultCellStyle = dataGridViewCellStyle33;
            this.dgvallBOM.Location = new System.Drawing.Point(375, 232);
            this.dgvallBOM.MultiSelect = false;
            this.dgvallBOM.Name = "dgvallBOM";
            this.dgvallBOM.ReadOnly = true;
            this.dgvallBOM.RowHeadersVisible = false;
            this.dgvallBOM.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvallBOM.Size = new System.Drawing.Size(920, 475);
            this.dgvallBOM.TabIndex = 127;
            this.dgvallBOM.Visible = false;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ItemCode";
            dataGridViewCellStyle26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle26;
            this.dataGridViewTextBoxColumn1.HeaderText = "Item Code";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Width = 84;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn2.DataPropertyName = "ItemDescription";
            dataGridViewCellStyle27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle27;
            this.dataGridViewTextBoxColumn2.HeaderText = "Item Desc";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn2.Width = 160;
            // 
            // Allitemtype
            // 
            this.Allitemtype.DataPropertyName = "Type";
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Allitemtype.DefaultCellStyle = dataGridViewCellStyle28;
            this.Allitemtype.HeaderText = "ItemType";
            this.Allitemtype.Name = "Allitemtype";
            this.Allitemtype.ReadOnly = true;
            this.Allitemtype.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Allitemtype.Width = 79;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Quantity";
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle29.NullValue = "1";
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle29;
            this.dataGridViewTextBoxColumn4.HeaderText = "BOM Qty";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn4.Width = 78;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "UnitCost";
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle30.Format = "N2";
            dataGridViewCellStyle30.NullValue = null;
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle30;
            this.dataGridViewTextBoxColumn5.HeaderText = "Unit Cost";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn5.Width = 77;
            // 
            // LatestCost
            // 
            this.LatestCost.DataPropertyName = "LatestCost";
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle31.Format = "N2";
            dataGridViewCellStyle31.NullValue = null;
            this.LatestCost.DefaultCellStyle = dataGridViewCellStyle31;
            this.LatestCost.HeaderText = "Latest Cost";
            this.LatestCost.Name = "LatestCost";
            this.LatestCost.ReadOnly = true;
            this.LatestCost.Width = 108;
            // 
            // allAmount
            // 
            this.allAmount.DataPropertyName = "Amount";
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle32.Format = "N2";
            dataGridViewCellStyle32.NullValue = null;
            this.allAmount.DefaultCellStyle = dataGridViewCellStyle32;
            this.allAmount.HeaderText = "Amount";
            this.allAmount.Name = "allAmount";
            this.allAmount.ReadOnly = true;
            this.allAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.allAmount.Width = 71;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "MfgPartNo";
            this.dataGridViewTextBoxColumn7.HeaderText = "MfgPartNo";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn7.Width = 91;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Make";
            this.dataGridViewTextBoxColumn8.HeaderText = "Make";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn8.Width = 53;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Specification";
            this.dataGridViewTextBoxColumn9.HeaderText = "Specification";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn9.Width = 102;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Location";
            this.dataGridViewTextBoxColumn10.HeaderText = "Location";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn10.Width = 73;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Vendor";
            this.dataGridViewTextBoxColumn11.HeaderText = "Vendor";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn11.Width = 63;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "DrawingNo";
            this.dataGridViewTextBoxColumn12.HeaderText = "DrawingNo";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn12.Width = 92;
            // 
            // ParentID
            // 
            this.ParentID.DataPropertyName = "ParentID";
            this.ParentID.HeaderText = "ParentID";
            this.ParentID.Name = "ParentID";
            this.ParentID.ReadOnly = true;
            this.ParentID.Visible = false;
            this.ParentID.Width = 94;
            // 
            // btnrename
            // 
            this.btnrename.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnrename.Enabled = false;
            this.btnrename.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnrename.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrename.Location = new System.Drawing.Point(8, 586);
            this.btnrename.Name = "btnrename";
            this.btnrename.Size = new System.Drawing.Size(31, 32);
            this.btnrename.TabIndex = 129;
            this.btnrename.Text = "Rename Product";
            this.btnrename.UseVisualStyleBackColor = false;
            this.btnrename.Visible = false;
            this.btnrename.Click += new System.EventHandler(this.btnrename_Click);
            // 
            // txtsearchtree
            // 
            this.txtsearchtree.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsearchtree.Location = new System.Drawing.Point(0, 57);
            this.txtsearchtree.Name = "txtsearchtree";
            this.txtsearchtree.Size = new System.Drawing.Size(243, 25);
            this.txtsearchtree.TabIndex = 130;
            this.txtsearchtree.TextChanged += new System.EventHandler(this.txtsearchtree_TextChanged);
            this.txtsearchtree.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtsearchtree_KeyUp);
            // 
            // btnsearchtree
            // 
            this.btnsearchtree.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearchtree.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnsearchtree.Location = new System.Drawing.Point(249, 56);
            this.btnsearchtree.Name = "btnsearchtree";
            this.btnsearchtree.Size = new System.Drawing.Size(67, 29);
            this.btnsearchtree.TabIndex = 129;
            this.btnsearchtree.Text = "Search";
            this.btnsearchtree.UseVisualStyleBackColor = true;
            this.btnsearchtree.Click += new System.EventHandler(this.btnsearchtree_Click);
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.btnAddSubProduct);
            this.panel3.Controls.Add(this.chkProductCode);
            this.panel3.Controls.Add(this.cmbVersion);
            this.panel3.Controls.Add(this.lblVersion);
            this.panel3.Controls.Add(this.cleartreeview);
            this.panel3.Controls.Add(this.txtsearchtree);
            this.panel3.Controls.Add(this.btnrename);
            this.panel3.Controls.Add(this.btnsearchtree);
            this.panel3.Controls.Add(this.lblWelcome);
            this.panel3.Controls.Add(this.lblbomby);
            this.panel3.Controls.Add(this.tvProduct);
            this.panel3.Controls.Add(this.btnassignuser);
            this.panel3.Controls.Add(this.btnAddProduct);
            this.panel3.Location = new System.Drawing.Point(3, 49);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(371, 629);
            this.panel3.TabIndex = 129;
            // 
            // btnAddSubProduct
            // 
            this.btnAddSubProduct.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAddSubProduct.Enabled = false;
            this.btnAddSubProduct.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAddSubProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddSubProduct.Location = new System.Drawing.Point(214, 590);
            this.btnAddSubProduct.Name = "btnAddSubProduct";
            this.btnAddSubProduct.Size = new System.Drawing.Size(151, 31);
            this.btnAddSubProduct.TabIndex = 202;
            this.btnAddSubProduct.Text = "Add Product";
            this.btnAddSubProduct.UseVisualStyleBackColor = false;
            this.btnAddSubProduct.Click += new System.EventHandler(this.btnAddSubProduct_Click);
            // 
            // chkProductCode
            // 
            this.chkProductCode.AutoSize = true;
            this.chkProductCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.chkProductCode.Location = new System.Drawing.Point(3, 29);
            this.chkProductCode.Name = "chkProductCode";
            this.chkProductCode.Size = new System.Drawing.Size(121, 23);
            this.chkProductCode.TabIndex = 134;
            this.chkProductCode.Text = "Product Code";
            this.chkProductCode.UseVisualStyleBackColor = true;
            // 
            // cmbVersion
            // 
            this.cmbVersion.DropDownHeight = 60;
            this.cmbVersion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbVersion.DropDownWidth = 150;
            this.cmbVersion.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbVersion.FormattingEnabled = true;
            this.cmbVersion.IntegralHeight = false;
            this.cmbVersion.ItemHeight = 18;
            this.cmbVersion.Location = new System.Drawing.Point(110, 89);
            this.cmbVersion.Name = "cmbVersion";
            this.cmbVersion.Size = new System.Drawing.Size(78, 26);
            this.cmbVersion.Sorted = true;
            this.cmbVersion.TabIndex = 133;
            this.cmbVersion.SelectedIndexChanged += new System.EventHandler(this.cmbVersion_SelectedIndexChanged);
            // 
            // lblVersion
            // 
            this.lblVersion.AutoSize = true;
            this.lblVersion.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVersion.ForeColor = System.Drawing.Color.Black;
            this.lblVersion.Location = new System.Drawing.Point(4, 91);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(108, 19);
            this.lblVersion.TabIndex = 132;
            this.lblVersion.Text = "Select Version:";
            // 
            // cleartreeview
            // 
            this.cleartreeview.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cleartreeview.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.cleartreeview.Location = new System.Drawing.Point(315, 56);
            this.cleartreeview.Name = "cleartreeview";
            this.cleartreeview.Size = new System.Drawing.Size(51, 29);
            this.cleartreeview.TabIndex = 131;
            this.cleartreeview.Text = "Clear";
            this.cleartreeview.UseVisualStyleBackColor = true;
            this.cleartreeview.Click += new System.EventHandler(this.cleartreeview_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // frmProductMasterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1304, 682);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.pnProductcode);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.gbSearchOptions);
            this.Controls.Add(this.gbControlButtons);
            this.Controls.Add(this.lblFolderMessage);
            this.Controls.Add(this.dgvallBOM);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmProductMasterForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Product Master";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmProductMasterForm_FormClosing);
            this.Load += new System.EventHandler(this.frmProductMasterForm_Load);
            this.gbSearchOptions.ResumeLayout(false);
            this.gbSearchOptions.PerformLayout();
            this.pnCost.ResumeLayout(false);
            this.pnCost.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgBOMList)).EndInit();
            this.pnexcelupload.ResumeLayout(false);
            this.pnexcelupload.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgItemList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvxcelupload)).EndInit();
            this.pnItemSearch.ResumeLayout(false);
            this.pnItemSearch.PerformLayout();
            this.pnProductcode.ResumeLayout(false);
            this.pnProductcode.PerformLayout();
            this.gbControlButtons.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvallBOM)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbSearchOptions;
        private System.Windows.Forms.TreeView tvProduct;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.GroupBox gbControlButtons;
        private System.Windows.Forms.Button btnAddProduct;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnAuthorise;
        private System.Windows.Forms.Label lblFolderMessage;
        private System.Windows.Forms.DataGridView dgBOMList;
        private System.Windows.Forms.Label lbltotalitems;
        private System.Windows.Forms.Label lblitemcount;
        private System.Windows.Forms.Panel pnexcelupload;
        private System.Windows.Forms.Button btnbrowse;
        private System.Windows.Forms.TextBox txtbrowseaddres;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.DataGridView dgvxcelupload;
        private System.Windows.Forms.Button btnaddtobom;
        private System.Windows.Forms.Label lbladditemcount;
        private System.Windows.Forms.Label lblbomitemlist;
        private System.Windows.Forms.Label lblproductcost;
        private System.Windows.Forms.Label lblpcode;
        private System.Windows.Forms.Label lblpname;
        private System.Windows.Forms.Panel pnProductcode;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblIndent;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Label lblbomby;
        private System.Windows.Forms.Button btnassignuser;
        private System.Windows.Forms.DataGridView dgvallBOM;
        private System.Windows.Forms.Button btnrename;
        private System.Windows.Forms.TextBox txtsearchtree;
        private System.Windows.Forms.Button btnsearchtree;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button cleartreeview;
        private System.Windows.Forms.Button btnexcelexport;
        private System.Windows.Forms.Label lblItemcodeorName;
        private System.Windows.Forms.TextBox txtItemSearch;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Allitemtype;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn LatestCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn allAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn ParentID;
        private System.Windows.Forms.Label lbllatest;
        private System.Windows.Forms.Label lblLatestCost;
        private System.Windows.Forms.TextBox txtProductCode;
        private System.Windows.Forms.TextBox txtProductName;
        private System.Windows.Forms.Button btnUpdateProduct;
        private System.Windows.Forms.TextBox txtProductCost;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblpcost;
        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.ComboBox cmbVersion;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.CheckBox chkProductCode;
        private System.Windows.Forms.CheckBox chkxcelupload;
        private System.Windows.Forms.CheckBox chkItemSaerch;
        private System.Windows.Forms.Panel pnItemSearch;
        private System.Windows.Forms.CheckBox chkItemDesc;
        private System.Windows.Forms.CheckBox chkItemCode;
        private System.Windows.Forms.TextBox txtItemDescription;
        private System.Windows.Forms.Label lblItemDescription;
        private System.Windows.Forms.DataGridView dgItemList;
        private System.Windows.Forms.Panel pnCost;
        private System.Windows.Forms.Button btnSaveSubProduct;
        private System.Windows.Forms.Button btnAddSubProduct;
        private System.Windows.Forms.DataGridViewTextBoxColumn xslno;
        private System.Windows.Forms.DataGridViewTextBoxColumn xItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn xItemDesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn xMfgPartNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn xMake;
        private System.Windows.Forms.DataGridViewTextBoxColumn xQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn xUnitcost;
        private System.Windows.Forms.DataGridViewTextBoxColumn xSpecification;
        private System.Windows.Forms.DataGridViewTextBoxColumn xItemType;
        private System.Windows.Forms.DataGridViewTextBoxColumn xLocation;
        private System.Windows.Forms.DataGridViewTextBoxColumn xVendor;
        private System.Windows.Forms.DataGridViewTextBoxColumn xDrawingno;
        private System.Windows.Forms.DataGridViewTextBoxColumn Version;
        private System.Windows.Forms.DataGridViewTextBoxColumn XProductType;
        private System.Windows.Forms.ComboBox cmbWorkDescription;
        private System.Windows.Forms.TextBox comspecification;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewButtonColumn add;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn uncost;
        private System.Windows.Forms.DataGridViewTextBoxColumn Type;
        private System.Windows.Forms.DataGridViewTextBoxColumn DrawingNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn MfgPartNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn make;
        private System.Windows.Forms.DataGridViewTextBoxColumn specification;
        private System.Windows.Forms.DataGridViewTextBoxColumn Location;
        private System.Windows.Forms.DataGridViewTextBoxColumn vendorname;
        private System.Windows.Forms.DataGridViewTextBoxColumn IProductType;
        private System.Windows.Forms.DataGridViewTextBoxColumn FixedCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductType;
        private System.Windows.Forms.DataGridViewTextBoxColumn uItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn uItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn uType;
        private System.Windows.Forms.DataGridViewTextBoxColumn BOMQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn uFixedCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn LatestCost1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn BSpecification;
        private System.Windows.Forms.DataGridViewTextBoxColumn BMfgPartNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn BMake;
        private System.Windows.Forms.DataGridViewTextBoxColumn BLocation;
        private System.Windows.Forms.DataGridViewTextBoxColumn BVendor;
        private System.Windows.Forms.DataGridViewTextBoxColumn BDrawingNo;
    }
}