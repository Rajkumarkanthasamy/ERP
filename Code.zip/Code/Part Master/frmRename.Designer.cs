﻿namespace Erp_Project_With_Buttons.Part_Master
{
    partial class frmRename
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRename));
            this.txtproductname = new System.Windows.Forms.TextBox();
            this.txtproductcode = new System.Windows.Forms.TextBox();
            this.lblmainfoldername = new System.Windows.Forms.Label();
            this.lblsubfoldername = new System.Windows.Forms.Label();
            this.btncancel = new System.Windows.Forms.Button();
            this.btnfoldernameok = new System.Windows.Forms.Button();
            this.lblAddres = new System.Windows.Forms.Label();
            this.lbladdressbar = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtproductname
            // 
            this.txtproductname.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtproductname.Location = new System.Drawing.Point(342, 134);
            this.txtproductname.Multiline = true;
            this.txtproductname.Name = "txtproductname";
            this.txtproductname.Size = new System.Drawing.Size(370, 60);
            this.txtproductname.TabIndex = 10;
            // 
            // txtproductcode
            // 
            this.txtproductcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtproductcode.Location = new System.Drawing.Point(35, 147);
            this.txtproductcode.Name = "txtproductcode";
            this.txtproductcode.Size = new System.Drawing.Size(273, 26);
            this.txtproductcode.TabIndex = 9;
            // 
            // lblmainfoldername
            // 
            this.lblmainfoldername.AutoSize = true;
            this.lblmainfoldername.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmainfoldername.ForeColor = System.Drawing.Color.BurlyWood;
            this.lblmainfoldername.Location = new System.Drawing.Point(97, 84);
            this.lblmainfoldername.Name = "lblmainfoldername";
            this.lblmainfoldername.Size = new System.Drawing.Size(129, 38);
            this.lblmainfoldername.TabIndex = 12;
            this.lblmainfoldername.Text = "PRODUCTCODE\r\nEx: AC-01-0050-01\r\n";
            this.lblmainfoldername.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblsubfoldername
            // 
            this.lblsubfoldername.AutoSize = true;
            this.lblsubfoldername.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsubfoldername.ForeColor = System.Drawing.Color.BurlyWood;
            this.lblsubfoldername.Location = new System.Drawing.Point(461, 33);
            this.lblsubfoldername.Name = "lblsubfoldername";
            this.lblsubfoldername.Size = new System.Drawing.Size(162, 95);
            this.lblsubfoldername.TabIndex = 11;
            this.lblsubfoldername.Text = "PRODUCT NAME\r\nEx: Load Frame\r\nor\r\nPRODUCT SUB TYPE\r\nEx: 100 kN Load Frame\r\n";
            this.lblsubfoldername.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btncancel
            // 
            this.btncancel.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncancel.Location = new System.Drawing.Point(627, 223);
            this.btncancel.Name = "btncancel";
            this.btncancel.Size = new System.Drawing.Size(75, 33);
            this.btncancel.TabIndex = 14;
            this.btncancel.Text = "Cancel";
            this.btncancel.UseVisualStyleBackColor = true;
            this.btncancel.Click += new System.EventHandler(this.btncancel_Click);
            // 
            // btnfoldernameok
            // 
            this.btnfoldernameok.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnfoldernameok.Location = new System.Drawing.Point(528, 223);
            this.btnfoldernameok.Name = "btnfoldernameok";
            this.btnfoldernameok.Size = new System.Drawing.Size(75, 33);
            this.btnfoldernameok.TabIndex = 13;
            this.btnfoldernameok.Text = "Rename";
            this.btnfoldernameok.UseVisualStyleBackColor = true;
            this.btnfoldernameok.Click += new System.EventHandler(this.btnfoldernameok_Click);
            // 
            // lblAddres
            // 
            this.lblAddres.AutoSize = true;
            this.lblAddres.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddres.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblAddres.Location = new System.Drawing.Point(12, 256);
            this.lblAddres.Name = "lblAddres";
            this.lblAddres.Size = new System.Drawing.Size(108, 18);
            this.lblAddres.TabIndex = 16;
            this.lblAddres.Text = "Renaming Path :";
            // 
            // lbladdressbar
            // 
            this.lbladdressbar.AutoSize = true;
            this.lbladdressbar.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbladdressbar.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbladdressbar.Location = new System.Drawing.Point(128, 256);
            this.lbladdressbar.Name = "lbladdressbar";
            this.lbladdressbar.Size = new System.Drawing.Size(12, 18);
            this.lbladdressbar.TabIndex = 15;
            this.lbladdressbar.Text = ":";
            // 
            // frmRename
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(724, 293);
            this.Controls.Add(this.lblAddres);
            this.Controls.Add(this.lbladdressbar);
            this.Controls.Add(this.btncancel);
            this.Controls.Add(this.btnfoldernameok);
            this.Controls.Add(this.lblmainfoldername);
            this.Controls.Add(this.lblsubfoldername);
            this.Controls.Add(this.txtproductname);
            this.Controls.Add(this.txtproductcode);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmRename";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BIM v1.0006";
            this.Load += new System.EventHandler(this.frmRename_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtproductname;
        private System.Windows.Forms.TextBox txtproductcode;
        private System.Windows.Forms.Label lblmainfoldername;
        private System.Windows.Forms.Label lblsubfoldername;
        private System.Windows.Forms.Button btncancel;
        private System.Windows.Forms.Button btnfoldernameok;
        private System.Windows.Forms.Label lblAddres;
        private System.Windows.Forms.Label lbladdressbar;
    }
}