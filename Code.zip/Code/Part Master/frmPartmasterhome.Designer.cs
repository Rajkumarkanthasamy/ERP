﻿
namespace Erp_Project_With_Buttons.Part_Master
{
    partial class frmPartmasterhome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPartmasterhome));
            this.btnStandardCost = new System.Windows.Forms.Button();
            this.btnPartMaster = new System.Windows.Forms.Button();
            this.btnTargetCost = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnStandardCost
            // 
            this.btnStandardCost.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnStandardCost.FlatAppearance.BorderSize = 0;
            this.btnStandardCost.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStandardCost.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStandardCost.ForeColor = System.Drawing.Color.MediumBlue;
            this.btnStandardCost.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_sales_performance_481;
            this.btnStandardCost.Location = new System.Drawing.Point(362, 119);
            this.btnStandardCost.Name = "btnStandardCost";
            this.btnStandardCost.Size = new System.Drawing.Size(100, 123);
            this.btnStandardCost.TabIndex = 5;
            this.btnStandardCost.Text = "Standard Cost Update";
            this.btnStandardCost.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnStandardCost.UseVisualStyleBackColor = true;
            this.btnStandardCost.Click += new System.EventHandler(this.btnStandardCost_Click);
            // 
            // btnPartMaster
            // 
            this.btnPartMaster.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnPartMaster.Enabled = false;
            this.btnPartMaster.FlatAppearance.BorderSize = 0;
            this.btnPartMaster.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPartMaster.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPartMaster.ForeColor = System.Drawing.Color.MediumBlue;
            this.btnPartMaster.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_add_list_48;
            this.btnPartMaster.Location = new System.Drawing.Point(95, 151);
            this.btnPartMaster.Name = "btnPartMaster";
            this.btnPartMaster.Size = new System.Drawing.Size(100, 91);
            this.btnPartMaster.TabIndex = 4;
            this.btnPartMaster.Text = "Item Master";
            this.btnPartMaster.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPartMaster.UseVisualStyleBackColor = true;
            this.btnPartMaster.Click += new System.EventHandler(this.btnPartMaster_Click);
            // 
            // btnTargetCost
            // 
            this.btnTargetCost.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnTargetCost.FlatAppearance.BorderSize = 0;
            this.btnTargetCost.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTargetCost.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTargetCost.ForeColor = System.Drawing.Color.MediumBlue;
           // this.btnTargetCost.Image = global::Erp_Project_With_Buttons.Properties.Resources.Bar_chart_icon;
            this.btnTargetCost.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnTargetCost.Location = new System.Drawing.Point(602, 151);
            this.btnTargetCost.Name = "btnTargetCost";
            this.btnTargetCost.Size = new System.Drawing.Size(107, 115);
            this.btnTargetCost.TabIndex = 6;
            this.btnTargetCost.Text = "Target Cost Update";
            this.btnTargetCost.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnTargetCost.UseVisualStyleBackColor = true;
            this.btnTargetCost.Click += new System.EventHandler(this.btnTargetCost_Click);
            // 
            // frmPartmasterhome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(909, 487);
            this.Controls.Add(this.btnTargetCost);
            this.Controls.Add(this.btnStandardCost);
            this.Controls.Add(this.btnPartMaster);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmPartmasterhome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmPartmasterhome";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmPartmasterhome_FormClosing);
            this.Load += new System.EventHandler(this.frmPartmasterhome_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnPartMaster;
        private System.Windows.Forms.Button btnStandardCost;
        private System.Windows.Forms.Button btnTargetCost;
    }
}
