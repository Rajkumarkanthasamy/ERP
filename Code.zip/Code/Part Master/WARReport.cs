﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Part_Master
{
    public partial class WARReport : Form
    {

        #region Intialization of Local Datatables, Variables Daclaration
        private const uint uITEM_NAME_SEARCH = 0;
        private const uint uCUSTOMER_TYPE_SEARCH = 1;
        private const uint uCUSTOMER_STATUS_SEARCH = 2;
        DataTable dtItemList = new DataTable();
        DataView dvItemList = new DataView();
        BindingSource bsItemList = new BindingSource();
        //Customer_Master.CustomerMasterForm CustomerMasterForm = new CustomerMasterForm();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        private string sCustomerName;
        public WARReport()
        {
            InitializeComponent();
        }
        #region Function to Filter Customer Details
        private void fnRowFilter(uint uSearchOption, string sRowFilter)
        {
            try
            {
               DataView dvItemList = new DataView(dtItemList);
                switch (uSearchOption)
                {

                    case uITEM_NAME_SEARCH:
                        {
                            dvItemList.RowFilter = "ItemCode like '" + sRowFilter + "%'";
                            dgCustomerList.DataSource = dvItemList.ToTable();
                            break;
                        }
                        //case uCUSTOMER_TYPE_SEARCH:
                        //    {
                        //        dvCustomerList.RowFilter = "CustomerType like '" + sRowFilter + "%'";
                        //        dgCustomerList.DataSource = dvCustomerList.ToTable();
                        //        break;
                        //    }
                        //case uCUSTOMER_STATUS_SEARCH:
                        //    {
                        //        dvCustomerList.RowFilter = "Status like '" + sRowFilter + "%'";
                        //        dgCustomerList.DataSource = dvCustomerList.ToTable();
                        //        break;
                        //    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ItemSearchForm_fnRowFilter " + ex.Message, "Error", 0, MessageBoxIcon.Error);
            }
        }
        #endregion
        private void WARReport_Load(object sender, EventArgs e)
        {

        }
        private void ItemSearchForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
           // CustomerMasterForm.Show();
        }



        private void txtItemName_KeyUp(object sender, KeyEventArgs e)
        {
           fnRowFilter(uITEM_NAME_SEARCH, txtItemName.Text);
        }

        private void txtItemName_Enter(object sender, EventArgs e)
        {
            dgCustomerList.DataSource = bsItemList;
        }

        #region ITEM Fom Load
        private void ItemSearchForm_Load(object sender, EventArgs e)
        {
            try
            {
              txtItemName.Focus();
                dtItemList = DAL.fnWARItemList(5, null).Tables[0]; //get all WAR list from database
                bsItemList.DataSource = dtItemList;
                dgCustomerList.AutoGenerateColumns = false;
                dgCustomerList.DataSource = bsItemList;
            }
            catch (Exception ex)
            {
                MessageBox.Show("CustomerSearchForm_CustomerSearchForm_Load " + ex.Message, "Error", 0, MessageBoxIcon.Error);
            }
        }
        #endregion

    }
}
#endregion