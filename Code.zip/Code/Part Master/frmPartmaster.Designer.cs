﻿namespace Erp_Project_With_Buttons
{
    partial class frmPartmaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPartmaster));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.txtItemTypeCode = new System.Windows.Forms.TextBox();
            this.cmbPurchaseType = new System.Windows.Forms.ComboBox();
            this.lblPurchaseType = new System.Windows.Forms.Label();
            this.cmbUnit = new System.Windows.Forms.ComboBox();
            this.chkActive = new System.Windows.Forms.CheckBox();
            this.txtOthers = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cmbItemType = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtItemCode = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.gbControlButtons = new System.Windows.Forms.GroupBox();
            this.btnNewItemCode = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClearAll = new System.Windows.Forms.Button();
            this.txtItemDescription = new System.Windows.Forms.TextBox();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.txtUnitCost = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pnMain = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.txtFixedCost = new System.Windows.Forms.TextBox();
            this.cmbStorageType = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.lblAvailableQty = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.cmbBougtMachine = new System.Windows.Forms.ComboBox();
            this.txtDrawingNo = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtHSNSACCode = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cmblocation = new System.Windows.Forms.ComboBox();
            this.lbllocation = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.pnBIM = new System.Windows.Forms.Panel();
            this.lbltime = new System.Windows.Forms.Label();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.lblReturnedby = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.cmbProcess = new System.Windows.Forms.ComboBox();
            this.btnItemCode = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.ckbClickToAddItemsDirectly = new System.Windows.Forms.CheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.chklbItemList = new System.Windows.Forms.CheckedListBox();
            this.txtsearchitemdesc = new System.Windows.Forms.TextBox();
            this.chkItemDesc = new System.Windows.Forms.CheckBox();
            this.chkItemCode = new System.Windows.Forms.CheckBox();
            this.btnUpdateItem = new System.Windows.Forms.Button();
            this.cbWorkOrder = new System.Windows.Forms.CheckBox();
            this.label13 = new System.Windows.Forms.Label();
            this.pnworkorder = new System.Windows.Forms.Panel();
            this.chkExcelUpload = new System.Windows.Forms.CheckBox();
            this.pnExcelItemCode = new System.Windows.Forms.Panel();
            this.pnexcelupload = new System.Windows.Forms.Panel();
            this.btnUpload = new System.Windows.Forms.Button();
            this.btnbrowse = new System.Windows.Forms.Button();
            this.txtbrowseaddres = new System.Windows.Forms.TextBox();
            this.dgvxcelupload = new System.Windows.Forms.DataGridView();
            this.xslno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xItemType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xItemDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xUnitCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xDrawingNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xUnits = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xPurchaseType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xHsnCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.chkUpdateUnitPrice = new System.Windows.Forms.CheckBox();
            this.gbControlButtons.SuspendLayout();
            this.pnMain.SuspendLayout();
            this.pnBIM.SuspendLayout();
            this.pnworkorder.SuspendLayout();
            this.pnExcelItemCode.SuspendLayout();
            this.pnexcelupload.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvxcelupload)).BeginInit();
            this.SuspendLayout();
            // 
            // txtItemTypeCode
            // 
            this.txtItemTypeCode.Enabled = false;
            this.txtItemTypeCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemTypeCode.Location = new System.Drawing.Point(109, 91);
            this.txtItemTypeCode.Name = "txtItemTypeCode";
            this.txtItemTypeCode.ReadOnly = true;
            this.txtItemTypeCode.Size = new System.Drawing.Size(82, 26);
            this.txtItemTypeCode.TabIndex = 74;
            this.toolTip1.SetToolTip(this.txtItemTypeCode, "Enter Item Code");
            // 
            // cmbPurchaseType
            // 
            this.cmbPurchaseType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbPurchaseType.DropDownHeight = 150;
            this.cmbPurchaseType.DropDownWidth = 181;
            this.cmbPurchaseType.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPurchaseType.FormattingEnabled = true;
            this.cmbPurchaseType.IntegralHeight = false;
            this.cmbPurchaseType.Items.AddRange(new object[] {
            "Local",
            "OutStation",
            "Import",
            "Inter Company"});
            this.cmbPurchaseType.Location = new System.Drawing.Point(539, 86);
            this.cmbPurchaseType.Name = "cmbPurchaseType";
            this.cmbPurchaseType.Size = new System.Drawing.Size(186, 26);
            this.cmbPurchaseType.TabIndex = 72;
            this.toolTip1.SetToolTip(this.cmbPurchaseType, "Select Purchase Type");
            // 
            // lblPurchaseType
            // 
            this.lblPurchaseType.AutoSize = true;
            this.lblPurchaseType.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPurchaseType.ForeColor = System.Drawing.Color.Black;
            this.lblPurchaseType.Location = new System.Drawing.Point(421, 87);
            this.lblPurchaseType.Name = "lblPurchaseType";
            this.lblPurchaseType.Size = new System.Drawing.Size(112, 19);
            this.lblPurchaseType.TabIndex = 71;
            this.lblPurchaseType.Text = "Purchase Type:";
            // 
            // cmbUnit
            // 
            this.cmbUnit.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbUnit.DropDownHeight = 150;
            this.cmbUnit.DropDownWidth = 181;
            this.cmbUnit.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbUnit.FormattingEnabled = true;
            this.cmbUnit.IntegralHeight = false;
            this.cmbUnit.Location = new System.Drawing.Point(540, 43);
            this.cmbUnit.Name = "cmbUnit";
            this.cmbUnit.Size = new System.Drawing.Size(186, 26);
            this.cmbUnit.TabIndex = 70;
            this.toolTip1.SetToolTip(this.cmbUnit, "Select Unit");
            // 
            // chkActive
            // 
            this.chkActive.AutoSize = true;
            this.chkActive.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkActive.ForeColor = System.Drawing.Color.Black;
            this.chkActive.Location = new System.Drawing.Point(605, 384);
            this.chkActive.Name = "chkActive";
            this.chkActive.Size = new System.Drawing.Size(86, 30);
            this.chkActive.TabIndex = 69;
            this.chkActive.Text = "Active";
            this.chkActive.UseVisualStyleBackColor = true;
            this.chkActive.CheckedChanged += new System.EventHandler(this.chkActive_CheckedChanged);
            // 
            // txtOthers
            // 
            this.txtOthers.AcceptsReturn = true;
            this.txtOthers.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOthers.Location = new System.Drawing.Point(109, 284);
            this.txtOthers.Multiline = true;
            this.txtOthers.Name = "txtOthers";
            this.txtOthers.Size = new System.Drawing.Size(288, 55);
            this.txtOthers.TabIndex = 66;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(47, 286);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 19);
            this.label9.TabIndex = 65;
            this.label9.Text = "Others:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cmbItemType
            // 
            this.cmbItemType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbItemType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbItemType.DropDownHeight = 150;
            this.cmbItemType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbItemType.DropDownWidth = 181;
            this.cmbItemType.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbItemType.FormattingEnabled = true;
            this.cmbItemType.IntegralHeight = false;
            this.cmbItemType.Items.AddRange(new object[] {
            "Consumable",
            "Electricals",
            "Electronics",
            "Electronics RnD",
            "FixedAsset",
            "Hydraulics",
            "KanBan",
            "Maintenance",
            "Mechanical",
            "Packing Materials",
            "Service(Non-Inventory)",
            "Transducers",
            "Tools",
            "TGT",
            "Testlab",
            "LFA Dynamics",
            "LFA – Machines",
            "HFA- Machines",
            "OTC – Accessories",
            "Service Spares",
            "Consumable- Non-Inventory",
            "DTM- Drop tower Machines",
            "PTI- Plastic testing Machines",
            "OTC – US",
            "OTC – UK",
            "OTC – Italy",
            "OTC – SG",
            "OTC – Germany",
            "Civil work"});
            this.cmbItemType.Location = new System.Drawing.Point(109, 41);
            this.cmbItemType.Name = "cmbItemType";
            this.cmbItemType.Size = new System.Drawing.Size(131, 26);
            this.cmbItemType.TabIndex = 62;
            this.toolTip1.SetToolTip(this.cmbItemType, "Select Item Type");
            this.cmbItemType.SelectedIndexChanged += new System.EventHandler(this.cmbItemType_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(20, 43);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 19);
            this.label8.TabIndex = 61;
            this.label8.Text = "Item Type*:";
            // 
            // txtItemCode
            // 
            this.txtItemCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemCode.Location = new System.Drawing.Point(197, 91);
            this.txtItemCode.Name = "txtItemCode";
            this.txtItemCode.ReadOnly = true;
            this.txtItemCode.Size = new System.Drawing.Size(200, 26);
            this.txtItemCode.TabIndex = 60;
            this.toolTip1.SetToolTip(this.txtItemCode, "Enter Item Code");
            this.txtItemCode.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemCode_KeyUp);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(15, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 19);
            this.label2.TabIndex = 59;
            this.label2.Text = "Item Code *:";
            // 
            // gbControlButtons
            // 
            this.gbControlButtons.Controls.Add(this.btnNewItemCode);
            this.gbControlButtons.Controls.Add(this.btnDelete);
            this.gbControlButtons.Controls.Add(this.btnExit);
            this.gbControlButtons.Controls.Add(this.btnSave);
            this.gbControlButtons.Controls.Add(this.btnClearAll);
            this.gbControlButtons.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.gbControlButtons.Location = new System.Drawing.Point(11, 429);
            this.gbControlButtons.Name = "gbControlButtons";
            this.gbControlButtons.Size = new System.Drawing.Size(744, 59);
            this.gbControlButtons.TabIndex = 58;
            this.gbControlButtons.TabStop = false;
            // 
            // btnNewItemCode
            // 
            this.btnNewItemCode.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnNewItemCode.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnNewItemCode.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewItemCode.Location = new System.Drawing.Point(29, 12);
            this.btnNewItemCode.Name = "btnNewItemCode";
            this.btnNewItemCode.Size = new System.Drawing.Size(128, 39);
            this.btnNewItemCode.TabIndex = 12;
            this.btnNewItemCode.Text = "New Item Code";
            this.toolTip1.SetToolTip(this.btnNewItemCode, "Click Here To Add New Item");
            this.btnNewItemCode.UseVisualStyleBackColor = false;
            this.btnNewItemCode.Visible = false;
            this.btnNewItemCode.Click += new System.EventHandler(this.btnNewItemCode_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnDelete.Enabled = false;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnDelete.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(365, 12);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(91, 39);
            this.btnDelete.TabIndex = 11;
            this.btnDelete.Text = "Delete";
            this.toolTip1.SetToolTip(this.btnDelete, "Click Here To Delete The Selected Part");
            this.btnDelete.UseVisualStyleBackColor = false;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(625, 12);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(90, 39);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.toolTip1.SetToolTip(this.btnExit, "Click Here To Exit This Tab");
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(231, 12);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(96, 39);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "Save";
            this.toolTip1.SetToolTip(this.btnSave, "Click Here To Add New Item");
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClearAll
            // 
            this.btnClearAll.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnClearAll.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnClearAll.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearAll.Location = new System.Drawing.Point(492, 12);
            this.btnClearAll.Name = "btnClearAll";
            this.btnClearAll.Size = new System.Drawing.Size(96, 39);
            this.btnClearAll.TabIndex = 7;
            this.btnClearAll.Text = "Clear All";
            this.toolTip1.SetToolTip(this.btnClearAll, "Click Here To Clear All The Fields");
            this.btnClearAll.UseVisualStyleBackColor = false;
            this.btnClearAll.Click += new System.EventHandler(this.btnClearAll_Click);
            // 
            // txtItemDescription
            // 
            this.txtItemDescription.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemDescription.Location = new System.Drawing.Point(109, 132);
            this.txtItemDescription.MaxLength = 255;
            this.txtItemDescription.Multiline = true;
            this.txtItemDescription.Name = "txtItemDescription";
            this.txtItemDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtItemDescription.Size = new System.Drawing.Size(288, 67);
            this.txtItemDescription.TabIndex = 54;
            this.toolTip1.SetToolTip(this.txtItemDescription, "Enter Item Description");
            this.txtItemDescription.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemDescription_KeyUp);
            this.txtItemDescription.Leave += new System.EventHandler(this.txtItemDescription_Leave);
            // 
            // txtRemarks
            // 
            this.txtRemarks.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemarks.Location = new System.Drawing.Point(109, 215);
            this.txtRemarks.Multiline = true;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Size = new System.Drawing.Size(288, 52);
            this.txtRemarks.TabIndex = 52;
            this.toolTip1.SetToolTip(this.txtRemarks, "Enter Remarks");
            // 
            // txtUnitCost
            // 
            this.txtUnitCost.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUnitCost.Location = new System.Drawing.Point(538, 169);
            this.txtUnitCost.Name = "txtUnitCost";
            this.txtUnitCost.Size = new System.Drawing.Size(187, 26);
            this.txtUnitCost.TabIndex = 50;
            this.txtUnitCost.Text = "0";
            this.toolTip1.SetToolTip(this.txtUnitCost, "Enter Cost in Rupees");
            this.txtUnitCost.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUnitCost_KeyPress);
            this.txtUnitCost.Leave += new System.EventHandler(this.txtUnitCost_Leave);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(489, 45);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 19);
            this.label5.TabIndex = 5;
            this.label5.Text = "Unit:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(35, 217);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 19);
            this.label6.TabIndex = 4;
            this.label6.Text = "Remarks:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(443, 172);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 19);
            this.label7.TabIndex = 3;
            this.label7.Text = "Unit Cost *:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(7, 135);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 19);
            this.label3.TabIndex = 1;
            this.label3.Text = "Description *:";
            // 
            // pnMain
            // 
            this.pnMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnMain.Controls.Add(this.label1);
            this.pnMain.Controls.Add(this.txtFixedCost);
            this.pnMain.Controls.Add(this.cmbStorageType);
            this.pnMain.Controls.Add(this.label14);
            this.pnMain.Controls.Add(this.lblAvailableQty);
            this.pnMain.Controls.Add(this.label12);
            this.pnMain.Controls.Add(this.cmbBougtMachine);
            this.pnMain.Controls.Add(this.txtDrawingNo);
            this.pnMain.Controls.Add(this.label4);
            this.pnMain.Controls.Add(this.txtHSNSACCode);
            this.pnMain.Controls.Add(this.label11);
            this.pnMain.Controls.Add(this.cmblocation);
            this.pnMain.Controls.Add(this.lbllocation);
            this.pnMain.Controls.Add(this.txtOthers);
            this.pnMain.Controls.Add(this.label9);
            this.pnMain.Controls.Add(this.txtRemarks);
            this.pnMain.Controls.Add(this.label6);
            this.pnMain.Controls.Add(this.txtItemCode);
            this.pnMain.Controls.Add(this.gbControlButtons);
            this.pnMain.Controls.Add(this.cmbPurchaseType);
            this.pnMain.Controls.Add(this.label3);
            this.pnMain.Controls.Add(this.lblPurchaseType);
            this.pnMain.Controls.Add(this.cmbUnit);
            this.pnMain.Controls.Add(this.label7);
            this.pnMain.Controls.Add(this.chkActive);
            this.pnMain.Controls.Add(this.label5);
            this.pnMain.Controls.Add(this.txtUnitCost);
            this.pnMain.Controls.Add(this.txtItemDescription);
            this.pnMain.Controls.Add(this.label2);
            this.pnMain.Controls.Add(this.label8);
            this.pnMain.Controls.Add(this.cmbItemType);
            this.pnMain.Controls.Add(this.txtItemTypeCode);
            this.pnMain.Location = new System.Drawing.Point(533, 185);
            this.pnMain.Name = "pnMain";
            this.pnMain.Size = new System.Drawing.Size(762, 495);
            this.pnMain.TabIndex = 12;
            this.pnMain.Paint += new System.Windows.Forms.PaintEventHandler(this.pnMain_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(436, 352);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 19);
            this.label1.TabIndex = 88;
            this.label1.Text = "Fixed Cost:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtFixedCost
            // 
            this.txtFixedCost.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFixedCost.Location = new System.Drawing.Point(538, 352);
            this.txtFixedCost.Name = "txtFixedCost";
            this.txtFixedCost.Size = new System.Drawing.Size(187, 26);
            this.txtFixedCost.TabIndex = 87;
            this.txtFixedCost.Text = "0";
            this.toolTip1.SetToolTip(this.txtFixedCost, "Enter Cost in Rupees");
            // 
            // cmbStorageType
            // 
            this.cmbStorageType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbStorageType.DropDownHeight = 150;
            this.cmbStorageType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStorageType.DropDownWidth = 181;
            this.cmbStorageType.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbStorageType.FormattingEnabled = true;
            this.cmbStorageType.IntegralHeight = false;
            this.cmbStorageType.Items.AddRange(new object[] {
            "NOT BIN",
            "STOCK BIN"});
            this.cmbStorageType.Location = new System.Drawing.Point(538, 252);
            this.cmbStorageType.Name = "cmbStorageType";
            this.cmbStorageType.Size = new System.Drawing.Size(186, 26);
            this.cmbStorageType.TabIndex = 86;
            this.toolTip1.SetToolTip(this.cmbStorageType, "Select Unit");
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(428, 254);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(115, 19);
            this.label14.TabIndex = 85;
            this.label14.Text = "Storage Type* :";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblAvailableQty
            // 
            this.lblAvailableQty.AutoSize = true;
            this.lblAvailableQty.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAvailableQty.ForeColor = System.Drawing.Color.Black;
            this.lblAvailableQty.Location = new System.Drawing.Point(109, 395);
            this.lblAvailableQty.Name = "lblAvailableQty";
            this.lblAvailableQty.Size = new System.Drawing.Size(17, 19);
            this.lblAvailableQty.TabIndex = 84;
            this.lblAvailableQty.Text = "0";
            this.lblAvailableQty.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(-2, 395);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(109, 19);
            this.label12.TabIndex = 83;
            this.label12.Text = "Available Qty :";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cmbBougtMachine
            // 
            this.cmbBougtMachine.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbBougtMachine.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbBougtMachine.DropDownHeight = 150;
            this.cmbBougtMachine.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBougtMachine.DropDownWidth = 181;
            this.cmbBougtMachine.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbBougtMachine.FormattingEnabled = true;
            this.cmbBougtMachine.IntegralHeight = false;
            this.cmbBougtMachine.Items.AddRange(new object[] {
            "Boughtout",
            "Machining",
            "BoughtoutMachining"});
            this.cmbBougtMachine.Location = new System.Drawing.Point(241, 41);
            this.cmbBougtMachine.Name = "cmbBougtMachine";
            this.cmbBougtMachine.Size = new System.Drawing.Size(156, 26);
            this.cmbBougtMachine.TabIndex = 82;
            this.toolTip1.SetToolTip(this.cmbBougtMachine, "Select Item Type");
            this.cmbBougtMachine.SelectedIndexChanged += new System.EventHandler(this.cmbBougtMachine_SelectedIndexChanged);
            // 
            // txtDrawingNo
            // 
            this.txtDrawingNo.AcceptsReturn = true;
            this.txtDrawingNo.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDrawingNo.Location = new System.Drawing.Point(539, 284);
            this.txtDrawingNo.Multiline = true;
            this.txtDrawingNo.Name = "txtDrawingNo";
            this.txtDrawingNo.Size = new System.Drawing.Size(186, 55);
            this.txtDrawingNo.TabIndex = 81;
            this.toolTip1.SetToolTip(this.txtDrawingNo, "Enter Draawing Number");
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(436, 286);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 19);
            this.label4.TabIndex = 80;
            this.label4.Text = "Drawing No:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtHSNSACCode
            // 
            this.txtHSNSACCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHSNSACCode.Location = new System.Drawing.Point(538, 212);
            this.txtHSNSACCode.MaxLength = 8;
            this.txtHSNSACCode.Name = "txtHSNSACCode";
            this.txtHSNSACCode.Size = new System.Drawing.Size(187, 26);
            this.txtHSNSACCode.TabIndex = 79;
            this.toolTip1.SetToolTip(this.txtHSNSACCode, "Enter Hsn/Sac Code");
            this.txtHSNSACCode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtHSNSACCode_KeyPress);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(414, 217);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(121, 19);
            this.label11.TabIndex = 77;
            this.label11.Text = "HSN / SAC Code:";
            // 
            // cmblocation
            // 
            this.cmblocation.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmblocation.DropDownHeight = 150;
            this.cmblocation.DropDownWidth = 181;
            this.cmblocation.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmblocation.FormattingEnabled = true;
            this.cmblocation.IntegralHeight = false;
            this.cmblocation.Location = new System.Drawing.Point(540, 128);
            this.cmblocation.Name = "cmblocation";
            this.cmblocation.Size = new System.Drawing.Size(186, 26);
            this.cmblocation.TabIndex = 76;
            this.toolTip1.SetToolTip(this.cmblocation, "Select Item Type");
            // 
            // lbllocation
            // 
            this.lbllocation.AutoSize = true;
            this.lbllocation.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbllocation.ForeColor = System.Drawing.Color.Black;
            this.lbllocation.Location = new System.Drawing.Point(460, 130);
            this.lbllocation.Name = "lbllocation";
            this.lbllocation.Size = new System.Drawing.Size(71, 19);
            this.lbllocation.TabIndex = 75;
            this.lbllocation.Text = "Location:";
            this.lbllocation.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.Indigo;
            this.lblName.Location = new System.Drawing.Point(242, 13);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(294, 29);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "BiSS Inventory Management";
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Add-icon.png");
            this.imageList1.Images.SetKeyName(1, "table-add-icon.png");
            this.imageList1.Images.SetKeyName(2, "order-history-icon.png");
            this.imageList1.Images.SetKeyName(3, "Package-Add-icon.png");
            this.imageList1.Images.SetKeyName(4, "Excel-icon.png");
            this.imageList1.Images.SetKeyName(5, "Actions-address-book-new-icon.png");
            this.imageList1.Images.SetKeyName(6, "invoice-icon.png");
            this.imageList1.Images.SetKeyName(7, "Apps-kspread-icon.png");
            this.imageList1.Images.SetKeyName(8, "Apps-klipper-icon.png");
            this.imageList1.Images.SetKeyName(9, "Upline-icon.png");
            this.imageList1.Images.SetKeyName(10, "reports-icon.png");
            this.imageList1.Images.SetKeyName(11, "Mimetypes-application-vnd-sun-xml-calc-template-icon.png");
            this.imageList1.Images.SetKeyName(12, "catalog-icon.png");
            this.imageList1.Images.SetKeyName(13, "Add-icon.png");
            // 
            // pnBIM
            // 
            this.pnBIM.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnBIM.Controls.Add(this.lbltime);
            this.pnBIM.Controls.Add(this.lblWelcome);
            this.pnBIM.Controls.Add(this.lblReturnedby);
            this.pnBIM.Controls.Add(this.lblName);
            this.pnBIM.Location = new System.Drawing.Point(533, 12);
            this.pnBIM.Name = "pnBIM";
            this.pnBIM.Size = new System.Drawing.Size(762, 93);
            this.pnBIM.TabIndex = 10;
            // 
            // lbltime
            // 
            this.lbltime.AutoSize = true;
            this.lbltime.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltime.ForeColor = System.Drawing.Color.Black;
            this.lbltime.Location = new System.Drawing.Point(629, 60);
            this.lbltime.Name = "lbltime";
            this.lbltime.Size = new System.Drawing.Size(0, 23);
            this.lbltime.TabIndex = 26;
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.ForeColor = System.Drawing.Color.Black;
            this.lblWelcome.Location = new System.Drawing.Point(7, 58);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(98, 24);
            this.lblWelcome.TabIndex = 22;
            this.lblWelcome.Text = "Welcome :";
            // 
            // lblReturnedby
            // 
            this.lblReturnedby.AutoSize = true;
            this.lblReturnedby.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturnedby.ForeColor = System.Drawing.Color.Black;
            this.lblReturnedby.Location = new System.Drawing.Point(103, 58);
            this.lblReturnedby.Name = "lblReturnedby";
            this.lblReturnedby.Size = new System.Drawing.Size(0, 24);
            this.lblReturnedby.TabIndex = 21;
            // 
            // cmbProcess
            // 
            this.cmbProcess.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbProcess.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProcess.DropDownHeight = 150;
            this.cmbProcess.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProcess.DropDownWidth = 181;
            this.cmbProcess.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProcess.FormattingEnabled = true;
            this.cmbProcess.IntegralHeight = false;
            this.cmbProcess.Items.AddRange(new object[] {
            "Machining",
            "Coating",
            "Painting",
            "Rework",
            "HeatTreatment",
            "ScreenPrinting"});
            this.cmbProcess.Location = new System.Drawing.Point(338, 8);
            this.cmbProcess.Name = "cmbProcess";
            this.cmbProcess.Size = new System.Drawing.Size(157, 26);
            this.cmbProcess.TabIndex = 216;
            this.toolTip1.SetToolTip(this.cmbProcess, "Select Item Type");
            this.cmbProcess.SelectedIndexChanged += new System.EventHandler(this.cmbProcess_SelectedIndexChanged);
            // 
            // btnItemCode
            // 
            this.btnItemCode.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnItemCode.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnItemCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItemCode.Location = new System.Drawing.Point(529, 4);
            this.btnItemCode.Name = "btnItemCode";
            this.btnItemCode.Size = new System.Drawing.Size(120, 33);
            this.btnItemCode.TabIndex = 218;
            this.btnItemCode.Text = "WO Item Code";
            this.toolTip1.SetToolTip(this.btnItemCode, "Click Here To Add New Item");
            this.btnItemCode.UseVisualStyleBackColor = false;
            this.btnItemCode.Click += new System.EventHandler(this.btnItemCode_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // ckbClickToAddItemsDirectly
            // 
            this.ckbClickToAddItemsDirectly.AutoSize = true;
            this.ckbClickToAddItemsDirectly.Checked = true;
            this.ckbClickToAddItemsDirectly.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ckbClickToAddItemsDirectly.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ckbClickToAddItemsDirectly.ForeColor = System.Drawing.Color.Black;
            this.ckbClickToAddItemsDirectly.Location = new System.Drawing.Point(12, 12);
            this.ckbClickToAddItemsDirectly.Name = "ckbClickToAddItemsDirectly";
            this.ckbClickToAddItemsDirectly.Size = new System.Drawing.Size(271, 23);
            this.ckbClickToAddItemsDirectly.TabIndex = 110;
            this.ckbClickToAddItemsDirectly.Text = "Click here to Check or Update Items";
            this.ckbClickToAddItemsDirectly.UseVisualStyleBackColor = true;
            this.ckbClickToAddItemsDirectly.CheckedChanged += new System.EventHandler(this.ckbClickToAddItemsDirectly_CheckedChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(9, 47);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(111, 19);
            this.label10.TabIndex = 113;
            this.label10.Text = "Search Item by";
            // 
            // chklbItemList
            // 
            this.chklbItemList.CheckOnClick = true;
            this.chklbItemList.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chklbItemList.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chklbItemList.FormattingEnabled = true;
            this.chklbItemList.HorizontalScrollbar = true;
            this.chklbItemList.Location = new System.Drawing.Point(4, 143);
            this.chklbItemList.Name = "chklbItemList";
            this.chklbItemList.Size = new System.Drawing.Size(523, 508);
            this.chklbItemList.TabIndex = 109;
            this.chklbItemList.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.chklbItemList_ItemCheck);
            // 
            // txtsearchitemdesc
            // 
            this.txtsearchitemdesc.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsearchitemdesc.Location = new System.Drawing.Point(4, 76);
            this.txtsearchitemdesc.Multiline = true;
            this.txtsearchitemdesc.Name = "txtsearchitemdesc";
            this.txtsearchitemdesc.Size = new System.Drawing.Size(523, 61);
            this.txtsearchitemdesc.TabIndex = 108;
            this.txtsearchitemdesc.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtsearchitemdesc_MouseClick);
            this.txtsearchitemdesc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtsearchitemdesc_KeyPress);
            this.txtsearchitemdesc.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtsearchitemdesc_KeyUp);
            // 
            // chkItemDesc
            // 
            this.chkItemDesc.AutoSize = true;
            this.chkItemDesc.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemDesc.ForeColor = System.Drawing.Color.Black;
            this.chkItemDesc.Location = new System.Drawing.Point(229, 47);
            this.chkItemDesc.Name = "chkItemDesc";
            this.chkItemDesc.Size = new System.Drawing.Size(140, 23);
            this.chkItemDesc.TabIndex = 213;
            this.chkItemDesc.Text = "Item Description";
            this.chkItemDesc.UseVisualStyleBackColor = true;
            this.chkItemDesc.CheckedChanged += new System.EventHandler(this.chkItemDesc_CheckedChanged);
            // 
            // chkItemCode
            // 
            this.chkItemCode.AutoSize = true;
            this.chkItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemCode.ForeColor = System.Drawing.Color.Black;
            this.chkItemCode.Location = new System.Drawing.Point(126, 46);
            this.chkItemCode.Name = "chkItemCode";
            this.chkItemCode.Size = new System.Drawing.Size(97, 23);
            this.chkItemCode.TabIndex = 212;
            this.chkItemCode.Text = "Item Code";
            this.chkItemCode.UseVisualStyleBackColor = true;
            this.chkItemCode.CheckedChanged += new System.EventHandler(this.chkItemCode_CheckedChanged);
            // 
            // btnUpdateItem
            // 
            this.btnUpdateItem.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnUpdateItem.Enabled = false;
            this.btnUpdateItem.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnUpdateItem.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnUpdateItem.Location = new System.Drawing.Point(329, 12);
            this.btnUpdateItem.Name = "btnUpdateItem";
            this.btnUpdateItem.Size = new System.Drawing.Size(141, 23);
            this.btnUpdateItem.TabIndex = 214;
            this.btnUpdateItem.Text = "Update Items";
            this.btnUpdateItem.UseVisualStyleBackColor = false;
            this.btnUpdateItem.Click += new System.EventHandler(this.btnUpdateItem_Click);
            // 
            // cbWorkOrder
            // 
            this.cbWorkOrder.AutoSize = true;
            this.cbWorkOrder.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbWorkOrder.ForeColor = System.Drawing.Color.Black;
            this.cbWorkOrder.Location = new System.Drawing.Point(18, 11);
            this.cbWorkOrder.Name = "cbWorkOrder";
            this.cbWorkOrder.Size = new System.Drawing.Size(182, 23);
            this.cbWorkOrder.TabIndex = 215;
            this.cbWorkOrder.Text = "Work Order Item Code";
            this.cbWorkOrder.UseVisualStyleBackColor = true;
            this.cbWorkOrder.CheckedChanged += new System.EventHandler(this.cbWorkOrder_CheckedChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(260, 12);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(76, 19);
            this.label13.TabIndex = 217;
            this.label13.Text = "Process *:";
            // 
            // pnworkorder
            // 
            this.pnworkorder.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnworkorder.Controls.Add(this.btnItemCode);
            this.pnworkorder.Controls.Add(this.cbWorkOrder);
            this.pnworkorder.Controls.Add(this.cmbProcess);
            this.pnworkorder.Controls.Add(this.label13);
            this.pnworkorder.Enabled = false;
            this.pnworkorder.Location = new System.Drawing.Point(533, 106);
            this.pnworkorder.Name = "pnworkorder";
            this.pnworkorder.Size = new System.Drawing.Size(762, 43);
            this.pnworkorder.TabIndex = 219;
            // 
            // chkExcelUpload
            // 
            this.chkExcelUpload.AutoSize = true;
            this.chkExcelUpload.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkExcelUpload.ForeColor = System.Drawing.Color.Black;
            this.chkExcelUpload.Location = new System.Drawing.Point(534, 157);
            this.chkExcelUpload.Name = "chkExcelUpload";
            this.chkExcelUpload.Size = new System.Drawing.Size(158, 23);
            this.chkExcelUpload.TabIndex = 220;
            this.chkExcelUpload.Text = "Upload Excel Sheet";
            this.chkExcelUpload.UseVisualStyleBackColor = true;
            this.chkExcelUpload.CheckedChanged += new System.EventHandler(this.chkExcelUpload_CheckedChanged);
            // 
            // pnExcelItemCode
            // 
            this.pnExcelItemCode.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnExcelItemCode.Controls.Add(this.pnexcelupload);
            this.pnExcelItemCode.Controls.Add(this.dgvxcelupload);
            this.pnExcelItemCode.Location = new System.Drawing.Point(533, 185);
            this.pnExcelItemCode.Name = "pnExcelItemCode";
            this.pnExcelItemCode.Size = new System.Drawing.Size(759, 495);
            this.pnExcelItemCode.TabIndex = 221;
            this.pnExcelItemCode.Visible = false;
            // 
            // pnexcelupload
            // 
            this.pnexcelupload.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnexcelupload.Controls.Add(this.btnUpload);
            this.pnexcelupload.Controls.Add(this.btnbrowse);
            this.pnexcelupload.Controls.Add(this.txtbrowseaddres);
            this.pnexcelupload.Location = new System.Drawing.Point(6, 9);
            this.pnexcelupload.Name = "pnexcelupload";
            this.pnexcelupload.Size = new System.Drawing.Size(746, 35);
            this.pnexcelupload.TabIndex = 222;
            // 
            // btnUpload
            // 
            this.btnUpload.BackColor = System.Drawing.Color.PaleGreen;
            this.btnUpload.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnUpload.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpload.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnUpload.Location = new System.Drawing.Point(681, 1);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(50, 27);
            this.btnUpload.TabIndex = 65;
            this.btnUpload.Text = "Upload";
            this.btnUpload.UseVisualStyleBackColor = false;
            this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click);
            // 
            // btnbrowse
            // 
            this.btnbrowse.BackColor = System.Drawing.Color.PaleGreen;
            this.btnbrowse.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnbrowse.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbrowse.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnbrowse.Location = new System.Drawing.Point(624, 1);
            this.btnbrowse.Name = "btnbrowse";
            this.btnbrowse.Size = new System.Drawing.Size(50, 27);
            this.btnbrowse.TabIndex = 1;
            this.btnbrowse.Text = "Browse";
            this.btnbrowse.UseVisualStyleBackColor = false;
            this.btnbrowse.Click += new System.EventHandler(this.btnbrowse_Click);
            // 
            // txtbrowseaddres
            // 
            this.txtbrowseaddres.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbrowseaddres.Location = new System.Drawing.Point(3, 4);
            this.txtbrowseaddres.Name = "txtbrowseaddres";
            this.txtbrowseaddres.ReadOnly = true;
            this.txtbrowseaddres.Size = new System.Drawing.Size(616, 22);
            this.txtbrowseaddres.TabIndex = 0;
            this.txtbrowseaddres.TextChanged += new System.EventHandler(this.txtbrowseaddres_TextChanged);
            // 
            // dgvxcelupload
            // 
            this.dgvxcelupload.AllowUserToAddRows = false;
            this.dgvxcelupload.AllowUserToResizeRows = false;
            this.dgvxcelupload.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dgvxcelupload.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvxcelupload.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvxcelupload.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvxcelupload.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.xslno,
            this.xItemType,
            this.xItemDesc,
            this.xUnitCost,
            this.xType,
            this.xDrawingNo,
            this.xUnits,
            this.xPurchaseType,
            this.xHsnCode});
            this.dgvxcelupload.EnableHeadersVisualStyles = false;
            this.dgvxcelupload.Location = new System.Drawing.Point(6, 47);
            this.dgvxcelupload.Name = "dgvxcelupload";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvxcelupload.RowHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvxcelupload.RowHeadersVisible = false;
            this.dgvxcelupload.RowHeadersWidth = 51;
            this.dgvxcelupload.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvxcelupload.Size = new System.Drawing.Size(746, 436);
            this.dgvxcelupload.TabIndex = 220;
            // 
            // xslno
            // 
            this.xslno.DataPropertyName = "slno";
            this.xslno.HeaderText = "SlNo";
            this.xslno.MinimumWidth = 6;
            this.xslno.Name = "xslno";
            this.xslno.ReadOnly = true;
            this.xslno.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xslno.Width = 44;
            // 
            // xItemType
            // 
            this.xItemType.DataPropertyName = "ItemType";
            this.xItemType.HeaderText = "ItemType";
            this.xItemType.MinimumWidth = 6;
            this.xItemType.Name = "xItemType";
            this.xItemType.ReadOnly = true;
            this.xItemType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xItemType.Width = 74;
            // 
            // xItemDesc
            // 
            this.xItemDesc.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.xItemDesc.DataPropertyName = "ItemDesc";
            this.xItemDesc.HeaderText = "ItemDesc";
            this.xItemDesc.MinimumWidth = 6;
            this.xItemDesc.Name = "xItemDesc";
            this.xItemDesc.ReadOnly = true;
            this.xItemDesc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xItemDesc.Width = 99;
            // 
            // xUnitCost
            // 
            this.xUnitCost.DataPropertyName = "UnitCost";
            this.xUnitCost.HeaderText = "Unit Cost";
            this.xUnitCost.MinimumWidth = 6;
            this.xUnitCost.Name = "xUnitCost";
            this.xUnitCost.ReadOnly = true;
            this.xUnitCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xUnitCost.Width = 75;
            // 
            // xType
            // 
            this.xType.DataPropertyName = "Type";
            this.xType.HeaderText = "Type";
            this.xType.MinimumWidth = 6;
            this.xType.Name = "xType";
            this.xType.ReadOnly = true;
            this.xType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xType.Width = 45;
            // 
            // xDrawingNo
            // 
            this.xDrawingNo.DataPropertyName = "DrawingNo";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.xDrawingNo.DefaultCellStyle = dataGridViewCellStyle2;
            this.xDrawingNo.HeaderText = "DrawingNo";
            this.xDrawingNo.MinimumWidth = 6;
            this.xDrawingNo.Name = "xDrawingNo";
            this.xDrawingNo.ReadOnly = true;
            this.xDrawingNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xDrawingNo.Width = 87;
            // 
            // xUnits
            // 
            this.xUnits.DataPropertyName = "Unit";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.xUnits.DefaultCellStyle = dataGridViewCellStyle3;
            this.xUnits.HeaderText = "Units";
            this.xUnits.MinimumWidth = 6;
            this.xUnits.Name = "xUnits";
            this.xUnits.ReadOnly = true;
            this.xUnits.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xUnits.Width = 49;
            // 
            // xPurchaseType
            // 
            this.xPurchaseType.DataPropertyName = "PurchaseType";
            this.xPurchaseType.HeaderText = "PurchaseType";
            this.xPurchaseType.MinimumWidth = 6;
            this.xPurchaseType.Name = "xPurchaseType";
            this.xPurchaseType.ReadOnly = true;
            this.xPurchaseType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xPurchaseType.Width = 104;
            // 
            // xHsnCode
            // 
            this.xHsnCode.DataPropertyName = "xHsnCode";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.xHsnCode.DefaultCellStyle = dataGridViewCellStyle4;
            this.xHsnCode.HeaderText = "HsnCode";
            this.xHsnCode.MinimumWidth = 6;
            this.xHsnCode.Name = "xHsnCode";
            this.xHsnCode.ReadOnly = true;
            this.xHsnCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.xHsnCode.Width = 73;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // chkUpdateUnitPrice
            // 
            this.chkUpdateUnitPrice.AutoSize = true;
            this.chkUpdateUnitPrice.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkUpdateUnitPrice.ForeColor = System.Drawing.Color.Black;
            this.chkUpdateUnitPrice.Location = new System.Drawing.Point(713, 157);
            this.chkUpdateUnitPrice.Name = "chkUpdateUnitPrice";
            this.chkUpdateUnitPrice.Size = new System.Drawing.Size(149, 23);
            this.chkUpdateUnitPrice.TabIndex = 222;
            this.chkUpdateUnitPrice.Text = "Update Unit Price";
            this.chkUpdateUnitPrice.UseVisualStyleBackColor = true;
            this.chkUpdateUnitPrice.CheckedChanged += new System.EventHandler(this.chkUpdateUnitPrice_CheckedChanged);
            // 
            // frmPartmaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1300, 685);
            this.Controls.Add(this.chkUpdateUnitPrice);
            this.Controls.Add(this.chkExcelUpload);
            this.Controls.Add(this.btnUpdateItem);
            this.Controls.Add(this.chkItemDesc);
            this.Controls.Add(this.chkItemCode);
            this.Controls.Add(this.ckbClickToAddItemsDirectly);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.chklbItemList);
            this.Controls.Add(this.txtsearchitemdesc);
            this.Controls.Add(this.pnBIM);
            this.Controls.Add(this.pnworkorder);
            this.Controls.Add(this.pnMain);
            this.Controls.Add(this.pnExcelItemCode);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmPartmaster";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Item Master";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmPartmaster_FormClosing);
            this.Load += new System.EventHandler(this.frmPartmaster_Load);
            this.gbControlButtons.ResumeLayout(false);
            this.pnMain.ResumeLayout(false);
            this.pnMain.PerformLayout();
            this.pnBIM.ResumeLayout(false);
            this.pnBIM.PerformLayout();
            this.pnworkorder.ResumeLayout(false);
            this.pnworkorder.PerformLayout();
            this.pnExcelItemCode.ResumeLayout(false);
            this.pnexcelupload.ResumeLayout(false);
            this.pnexcelupload.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvxcelupload)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox chkActive;
        private System.Windows.Forms.TextBox txtOthers;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmbItemType;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtItemCode;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox gbControlButtons;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClearAll;
        private System.Windows.Forms.TextBox txtItemDescription;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.TextBox txtUnitCost;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel pnMain;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Panel pnBIM;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ComboBox cmbUnit;
        private System.Windows.Forms.ComboBox cmbPurchaseType;
        private System.Windows.Forms.Label lblPurchaseType;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Label lblReturnedby;
        private System.Windows.Forms.TextBox txtItemTypeCode;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lbltime;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.CheckBox ckbClickToAddItemsDirectly;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckedListBox chklbItemList;
        private System.Windows.Forms.TextBox txtsearchitemdesc;
        private System.Windows.Forms.ComboBox cmblocation;
        private System.Windows.Forms.Label lbllocation;
        private System.Windows.Forms.TextBox txtHSNSACCode;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.CheckBox chkItemDesc;
        private System.Windows.Forms.CheckBox chkItemCode;
        private System.Windows.Forms.TextBox txtDrawingNo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbBougtMachine;
        private System.Windows.Forms.Label lblAvailableQty;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnUpdateItem;
        private System.Windows.Forms.Button btnNewItemCode;
        private System.Windows.Forms.CheckBox cbWorkOrder;
        private System.Windows.Forms.ComboBox cmbProcess;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnItemCode;
        private System.Windows.Forms.Panel pnworkorder;
        private System.Windows.Forms.CheckBox chkExcelUpload;
        private System.Windows.Forms.Panel pnExcelItemCode;
        private System.Windows.Forms.DataGridView dgvxcelupload;
        private System.Windows.Forms.Panel pnexcelupload;
        private System.Windows.Forms.Button btnUpload;
        private System.Windows.Forms.Button btnbrowse;
        private System.Windows.Forms.TextBox txtbrowseaddres;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.CheckBox chkUpdateUnitPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn xslno;
        private System.Windows.Forms.DataGridViewTextBoxColumn xItemType;
        private System.Windows.Forms.DataGridViewTextBoxColumn xItemDesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn xUnitCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn xType;
        private System.Windows.Forms.DataGridViewTextBoxColumn xDrawingNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn xUnits;
        private System.Windows.Forms.DataGridViewTextBoxColumn xPurchaseType;
        private System.Windows.Forms.DataGridViewTextBoxColumn xHsnCode;
        private System.Windows.Forms.ComboBox cmbStorageType;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtFixedCost;
    }
}
