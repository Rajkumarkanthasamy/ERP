﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Customer_Master
{
    public partial class CustomerSearchForm : Form
    {
        #region Intialization of Local Datatables, Variables Daclaration
        private const uint uCUSTOMER_NAME_SEARCH = 0;
        private const uint uCUSTOMER_TYPE_SEARCH = 1;
        private const uint uCUSTOMER_STATUS_SEARCH = 2;
        DataTable dtCustomerList = new DataTable();
        DataView dvCustomerList = new DataView();
        BindingSource bsCustomerList = new BindingSource();
        Customer_Master.CustomerMasterForm CustomerMasterForm = new CustomerMasterForm();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        private string sCustomerName;

        public CustomerSearchForm()
        {
            InitializeComponent();
        }
        #endregion
        #region Function to Filter Customer Details
        private void fnRowFilter(uint uSearchOption, string sRowFilter)
        {
            try
            {
                DataView dvCustomerList = new DataView(dtCustomerList);
                switch (uSearchOption)
                {
                    case uCUSTOMER_NAME_SEARCH:
                        {
                            dvCustomerList.RowFilter = "CustomerName like '" + sRowFilter + "%'";
                            dgCustomerList.DataSource = dvCustomerList.ToTable();
                            break;
                        }
                    case uCUSTOMER_TYPE_SEARCH:
                        {
                            dvCustomerList.RowFilter = "CustomerType like '" + sRowFilter + "%'";
                            dgCustomerList.DataSource = dvCustomerList.ToTable();
                            break;
                        }
                    case uCUSTOMER_STATUS_SEARCH:
                        {
                            dvCustomerList.RowFilter = "Status like '" + sRowFilter + "%'";
                            dgCustomerList.DataSource = dvCustomerList.ToTable();
                            break;
                        }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("CustomerSearchForm_fnRowFilter " + ex.Message, "Error", 0, MessageBoxIcon.Error);
            }
        }
        #endregion
        #region Customer Fom Load
        private void CustomerSearchForm_Load(object sender, EventArgs e)
        {
            try
            {
                txtCustomerName.Focus();
                dtCustomerList = DAL.fnCustomerList(5, null).Tables[0]; //get all Customer list from database
                bsCustomerList.DataSource = dtCustomerList;
                dgCustomerList.AutoGenerateColumns = false;
                dgCustomerList.DataSource = bsCustomerList;
            }
            catch (Exception ex)
            {
                MessageBox.Show("CustomerSearchForm_CustomerSearchForm_Load " + ex.Message, "Error", 0, MessageBoxIcon.Error);
            }
        }
        #endregion
        #region Code to Select a Customer
        private void dgCustomerList_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                sCustomerName = dgCustomerList.CurrentRow.Cells["CustomerName"].Value.ToString();
                dvCustomerList = new DataView(dtCustomerList);
                dvCustomerList.RowFilter = "CustomerName Like '" + sCustomerName + "' and  MobileNo Like '" + dgCustomerList.CurrentRow.Cells["MobileNo"].Value.ToString() + "' and ContactPerson Like '" + dgCustomerList.CurrentRow.Cells["ContactPerson"].Value.ToString() + "'";

                if (dvCustomerList.Count > 0)
                {
                    dtCustomerList = dvCustomerList.ToTable();
                    CustomerMasterForm.fnGetCustomerCode = dtCustomerList.Rows[0];
                }
                this.Hide();
                CustomerMasterForm.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("CustomerSearchForm_dgCustomerList_DoubleClick " + ex.Message, "Error", 0, MessageBoxIcon.Error);
            }
        }
        #endregion
        #region Code to Filter Customer Details
        private void txtCustomerName_KeyUp(object sender, KeyEventArgs e)
        {
            fnRowFilter(uCUSTOMER_NAME_SEARCH, txtCustomerName.Text);
        }

        private void checkShowInactive_CheckedChanged(object sender, EventArgs e)
        {
            if (checkShowInactive.Checked)
                fnRowFilter(uCUSTOMER_STATUS_SEARCH, "InActive");
            else
                fnRowFilter(uCUSTOMER_STATUS_SEARCH, "Active");
        }

        private void txtCustomerName_Enter(object sender, EventArgs e)
        {
            dgCustomerList.DataSource = bsCustomerList;
        }

        private void CustomerSearchForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            CustomerMasterForm.Show();
        }

        private void cmbCustomerType_SelectedIndexChanged(object sender, EventArgs e)
        {
            fnRowFilter(uCUSTOMER_TYPE_SEARCH, cmbCustomerType.Text);
        }
        #endregion
    }
}
