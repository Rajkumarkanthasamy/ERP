﻿
namespace Erp_Project_With_Buttons.Part_Master
{
    partial class WARReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WARReport));
            this.dgCustomerList = new System.Windows.Forms.DataGridView();
            this.gbSearchOptions = new System.Windows.Forms.GroupBox();
            this.txtItemName = new System.Windows.Forms.TextBox();
            this.lblItemName = new System.Windows.Forms.Label();
            this.TransactionNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TransactionBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TransactionDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Action = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemCode1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WARCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgCustomerList)).BeginInit();
            this.gbSearchOptions.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgCustomerList
            // 
            this.dgCustomerList.AllowUserToAddRows = false;
            this.dgCustomerList.AllowUserToDeleteRows = false;
            this.dgCustomerList.AllowUserToResizeRows = false;
            this.dgCustomerList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgCustomerList.BackgroundColor = System.Drawing.SystemColors.ControlDark;
            this.dgCustomerList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgCustomerList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgCustomerList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgCustomerList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgCustomerList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TransactionNumber,
            this.TransactionBy,
            this.TransactionDate,
            this.Action,
            this.ItemCode1,
            this.WARCost});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgCustomerList.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgCustomerList.EnableHeadersVisualStyles = false;
            this.dgCustomerList.Location = new System.Drawing.Point(9, 91);
            this.dgCustomerList.MultiSelect = false;
            this.dgCustomerList.Name = "dgCustomerList";
            this.dgCustomerList.ReadOnly = true;
            this.dgCustomerList.RowHeadersVisible = false;
            this.dgCustomerList.Size = new System.Drawing.Size(1288, 579);
            this.dgCustomerList.TabIndex = 8;
            // 
            // gbSearchOptions
            // 
            this.gbSearchOptions.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.gbSearchOptions.Controls.Add(this.txtItemName);
            this.gbSearchOptions.Controls.Add(this.lblItemName);
            this.gbSearchOptions.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.gbSearchOptions.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbSearchOptions.Location = new System.Drawing.Point(9, 4);
            this.gbSearchOptions.Name = "gbSearchOptions";
            this.gbSearchOptions.Size = new System.Drawing.Size(1288, 81);
            this.gbSearchOptions.TabIndex = 7;
            this.gbSearchOptions.TabStop = false;
            // 
            // txtItemName
            // 
            this.txtItemName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemName.Location = new System.Drawing.Point(140, 29);
            this.txtItemName.Name = "txtItemName";
            this.txtItemName.Size = new System.Drawing.Size(419, 26);
            this.txtItemName.TabIndex = 1;
            this.txtItemName.Enter += new System.EventHandler(this.txtItemName_Enter);
            this.txtItemName.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemName_KeyUp);
            // 
            // lblItemName
            // 
            this.lblItemName.AutoSize = true;
            this.lblItemName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemName.Location = new System.Drawing.Point(11, 32);
            this.lblItemName.Name = "lblItemName";
            this.lblItemName.Size = new System.Drawing.Size(82, 19);
            this.lblItemName.TabIndex = 0;
            this.lblItemName.Text = "Item Code:";
            // 
            // TransactionNumber
            // 
            this.TransactionNumber.DataPropertyName = "TransactionNumber";
            this.TransactionNumber.HeaderText = "TransactionNumber";
            this.TransactionNumber.Name = "TransactionNumber";
            this.TransactionNumber.ReadOnly = true;
            this.TransactionNumber.Width = 168;
            // 
            // TransactionBy
            // 
            this.TransactionBy.DataPropertyName = "TransactionBy";
            this.TransactionBy.HeaderText = "TransactionBy";
            this.TransactionBy.Name = "TransactionBy";
            this.TransactionBy.ReadOnly = true;
            this.TransactionBy.Width = 129;
            // 
            // TransactionDate
            // 
            this.TransactionDate.DataPropertyName = "TransactionDate";
            this.TransactionDate.HeaderText = "TransactionDate";
            this.TransactionDate.Name = "TransactionDate";
            this.TransactionDate.ReadOnly = true;
            this.TransactionDate.Width = 144;
            // 
            // Action
            // 
            this.Action.DataPropertyName = "Action";
            this.Action.HeaderText = "Action";
            this.Action.Name = "Action";
            this.Action.ReadOnly = true;
            this.Action.Width = 78;
            // 
            // ItemCode1
            // 
            this.ItemCode1.DataPropertyName = "ItemCode";
            this.ItemCode1.HeaderText = "ItemCode";
            this.ItemCode1.Name = "ItemCode1";
            this.ItemCode1.ReadOnly = true;
            this.ItemCode1.Width = 99;
            // 
            // WARCost
            // 
            this.WARCost.DataPropertyName = "WARCost";
            this.WARCost.HeaderText = "WARCost";
            this.WARCost.Name = "WARCost";
            this.WARCost.ReadOnly = true;
            this.WARCost.Width = 96;
            // 
            // WARReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1304, 682);
            this.Controls.Add(this.dgCustomerList);
            this.Controls.Add(this.gbSearchOptions);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "WARReport";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Item Search";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ItemSearchForm_FormClosing);
            this.Load += new System.EventHandler(this.ItemSearchForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgCustomerList)).EndInit();
            this.gbSearchOptions.ResumeLayout(false);
            this.gbSearchOptions.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgCustomerList;
        private System.Windows.Forms.GroupBox gbSearchOptions;
      
        private System.Windows.Forms.TextBox txtItemName;
        private System.Windows.Forms.Label lblItemName;
       
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemName;
        private System.Windows.Forms.DataGridViewTextBoxColumn TransactionNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn TransactionBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn TransactionDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Action;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCode1;
        private System.Windows.Forms.DataGridViewTextBoxColumn WARCost;
    }
}