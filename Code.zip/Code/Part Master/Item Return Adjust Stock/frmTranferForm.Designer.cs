﻿namespace Erp_Project_With_Buttons.Item_Return_Adjust_Stock
{
    partial class frmTranferForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTranferForm));
            this.cmbCopyProjCode = new System.Windows.Forms.ComboBox();
            this.lblProjectStausNew = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblProjectStaus = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnProjectView = new System.Windows.Forms.Button();
            this.txtcopycustomer = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtProjDesc = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtcustomer = new System.Windows.Forms.Label();
            this.lblcustomer = new System.Windows.Forms.Label();
            this.txtProjectName = new System.Windows.Forms.Label();
            this.lblProjectName = new System.Windows.Forms.Label();
            this.cmbProjectCode = new System.Windows.Forms.ComboBox();
            this.lblProjectCode = new System.Windows.Forms.Label();
            this.btnTransfer = new System.Windows.Forms.Button();
            this.dtpReturndate = new System.Windows.Forms.DateTimePicker();
            this.lblWarning = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cmbCopyProjCode
            // 
            this.cmbCopyProjCode.DropDownHeight = 130;
            this.cmbCopyProjCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCopyProjCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCopyProjCode.FormattingEnabled = true;
            this.cmbCopyProjCode.IntegralHeight = false;
            this.cmbCopyProjCode.Location = new System.Drawing.Point(703, 18);
            this.cmbCopyProjCode.Name = "cmbCopyProjCode";
            this.cmbCopyProjCode.Size = new System.Drawing.Size(316, 26);
            this.cmbCopyProjCode.TabIndex = 85;
            this.cmbCopyProjCode.SelectedIndexChanged += new System.EventHandler(this.cmbCopyProjCode_SelectedIndexChanged);
            // 
            // lblProjectStausNew
            // 
            this.lblProjectStausNew.AutoSize = true;
            this.lblProjectStausNew.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectStausNew.ForeColor = System.Drawing.Color.Black;
            this.lblProjectStausNew.Location = new System.Drawing.Point(693, 126);
            this.lblProjectStausNew.Name = "lblProjectStausNew";
            this.lblProjectStausNew.Size = new System.Drawing.Size(12, 18);
            this.lblProjectStausNew.TabIndex = 95;
            this.lblProjectStausNew.Text = ".";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(614, 126);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 18);
            this.label6.TabIndex = 96;
            this.label6.Text = "Proj Status :";
            // 
            // lblProjectStaus
            // 
            this.lblProjectStaus.AutoSize = true;
            this.lblProjectStaus.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectStaus.ForeColor = System.Drawing.Color.Black;
            this.lblProjectStaus.Location = new System.Drawing.Point(127, 112);
            this.lblProjectStaus.Name = "lblProjectStaus";
            this.lblProjectStaus.Size = new System.Drawing.Size(12, 18);
            this.lblProjectStaus.TabIndex = 92;
            this.lblProjectStaus.Text = ".";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(48, 112);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 18);
            this.label5.TabIndex = 94;
            this.label5.Text = "Proj Status :";
            // 
            // btnProjectView
            // 
            this.btnProjectView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnProjectView.Location = new System.Drawing.Point(425, 14);
            this.btnProjectView.Name = "btnProjectView";
            this.btnProjectView.Size = new System.Drawing.Size(24, 29);
            this.btnProjectView.TabIndex = 91;
            this.btnProjectView.Text = "....";
            this.btnProjectView.UseVisualStyleBackColor = false;
            this.btnProjectView.Click += new System.EventHandler(this.btnProjectView_Click);
            // 
            // txtcopycustomer
            // 
            this.txtcopycustomer.AutoSize = true;
            this.txtcopycustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcopycustomer.ForeColor = System.Drawing.Color.Black;
            this.txtcopycustomer.Location = new System.Drawing.Point(693, 96);
            this.txtcopycustomer.Name = "txtcopycustomer";
            this.txtcopycustomer.Size = new System.Drawing.Size(12, 18);
            this.txtcopycustomer.TabIndex = 89;
            this.txtcopycustomer.Text = ".";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(620, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 18);
            this.label3.TabIndex = 88;
            this.label3.Text = "Customer :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(599, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 18);
            this.label1.TabIndex = 87;
            this.label1.Text = "Project Name:";
            // 
            // txtProjDesc
            // 
            this.txtProjDesc.AutoSize = true;
            this.txtProjDesc.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProjDesc.ForeColor = System.Drawing.Color.Black;
            this.txtProjDesc.Location = new System.Drawing.Point(693, 67);
            this.txtProjDesc.Name = "txtProjDesc";
            this.txtProjDesc.Size = new System.Drawing.Size(12, 18);
            this.txtProjDesc.TabIndex = 86;
            this.txtProjDesc.Text = ".";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(599, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 18);
            this.label2.TabIndex = 84;
            this.label2.Text = "Project Code*:";
            // 
            // txtcustomer
            // 
            this.txtcustomer.AutoSize = true;
            this.txtcustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcustomer.ForeColor = System.Drawing.Color.Black;
            this.txtcustomer.Location = new System.Drawing.Point(126, 83);
            this.txtcustomer.Name = "txtcustomer";
            this.txtcustomer.Size = new System.Drawing.Size(12, 18);
            this.txtcustomer.TabIndex = 82;
            this.txtcustomer.Text = ".";
            // 
            // lblcustomer
            // 
            this.lblcustomer.AutoSize = true;
            this.lblcustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcustomer.ForeColor = System.Drawing.Color.Black;
            this.lblcustomer.Location = new System.Drawing.Point(54, 83);
            this.lblcustomer.Name = "lblcustomer";
            this.lblcustomer.Size = new System.Drawing.Size(75, 18);
            this.lblcustomer.TabIndex = 81;
            this.lblcustomer.Text = "Customer :";
            // 
            // txtProjectName
            // 
            this.txtProjectName.AutoSize = true;
            this.txtProjectName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProjectName.ForeColor = System.Drawing.Color.Black;
            this.txtProjectName.Location = new System.Drawing.Point(127, 53);
            this.txtProjectName.Name = "txtProjectName";
            this.txtProjectName.Size = new System.Drawing.Size(12, 18);
            this.txtProjectName.TabIndex = 80;
            this.txtProjectName.Text = ".";
            this.txtProjectName.Click += new System.EventHandler(this.txtProjectName_Click);
            // 
            // lblProjectName
            // 
            this.lblProjectName.AutoSize = true;
            this.lblProjectName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectName.ForeColor = System.Drawing.Color.Black;
            this.lblProjectName.Location = new System.Drawing.Point(33, 53);
            this.lblProjectName.Name = "lblProjectName";
            this.lblProjectName.Size = new System.Drawing.Size(96, 18);
            this.lblProjectName.TabIndex = 79;
            this.lblProjectName.Text = "Project Name:";
            this.lblProjectName.Click += new System.EventHandler(this.lblProjectName_Click);
            // 
            // cmbProjectCode
            // 
            this.cmbProjectCode.DropDownHeight = 130;
            this.cmbProjectCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProjectCode.FormattingEnabled = true;
            this.cmbProjectCode.IntegralHeight = false;
            this.cmbProjectCode.Location = new System.Drawing.Point(137, 16);
            this.cmbProjectCode.Name = "cmbProjectCode";
            this.cmbProjectCode.Size = new System.Drawing.Size(282, 26);
            this.cmbProjectCode.TabIndex = 78;
            this.cmbProjectCode.SelectedIndexChanged += new System.EventHandler(this.cmbProjectCode_SelectedIndexChanged);
            // 
            // lblProjectCode
            // 
            this.lblProjectCode.AutoSize = true;
            this.lblProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectCode.ForeColor = System.Drawing.Color.Black;
            this.lblProjectCode.Location = new System.Drawing.Point(33, 19);
            this.lblProjectCode.Name = "lblProjectCode";
            this.lblProjectCode.Size = new System.Drawing.Size(98, 18);
            this.lblProjectCode.TabIndex = 77;
            this.lblProjectCode.Text = "Project Code*:";
            this.lblProjectCode.Click += new System.EventHandler(this.lblProjectCode_Click);
            // 
            // btnTransfer
            // 
            this.btnTransfer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnTransfer.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTransfer.Location = new System.Drawing.Point(438, 268);
            this.btnTransfer.Name = "btnTransfer";
            this.btnTransfer.Size = new System.Drawing.Size(193, 41);
            this.btnTransfer.TabIndex = 98;
            this.btnTransfer.Text = "Transfer Items";
            this.btnTransfer.UseVisualStyleBackColor = false;
            this.btnTransfer.Click += new System.EventHandler(this.btnTransfer_Click);
            // 
            // dtpReturndate
            // 
            this.dtpReturndate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpReturndate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpReturndate.Location = new System.Drawing.Point(1144, 11);
            this.dtpReturndate.Name = "dtpReturndate";
            this.dtpReturndate.Size = new System.Drawing.Size(121, 26);
            this.dtpReturndate.TabIndex = 164;
            // 
            // lblWarning
            // 
            this.lblWarning.AutoSize = true;
            this.lblWarning.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWarning.ForeColor = System.Drawing.Color.Black;
            this.lblWarning.Location = new System.Drawing.Point(284, 213);
            this.lblWarning.Name = "lblWarning";
            this.lblWarning.Size = new System.Drawing.Size(631, 33);
            this.lblWarning.TabIndex = 165;
            this.lblWarning.Text = "No project assigned to transfer for the selected project";
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(1197, 560);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(90, 39);
            this.btnExit.TabIndex = 166;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // frmTranferForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1337, 626);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblWarning);
            this.Controls.Add(this.dtpReturndate);
            this.Controls.Add(this.btnTransfer);
            this.Controls.Add(this.cmbCopyProjCode);
            this.Controls.Add(this.lblProjectStausNew);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblProjectStaus);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnProjectView);
            this.Controls.Add(this.txtcopycustomer);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtProjDesc);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtcustomer);
            this.Controls.Add(this.lblcustomer);
            this.Controls.Add(this.txtProjectName);
            this.Controls.Add(this.lblProjectName);
            this.Controls.Add(this.cmbProjectCode);
            this.Controls.Add(this.lblProjectCode);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmTranferForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Transfer Form";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmTranferForm_FormClosing);
            this.Load += new System.EventHandler(this.frmTranferForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbCopyProjCode;
        private System.Windows.Forms.Label lblProjectStausNew;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblProjectStaus;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnProjectView;
        private System.Windows.Forms.Label txtcopycustomer;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label txtProjDesc;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label txtcustomer;
        private System.Windows.Forms.Label lblcustomer;
        private System.Windows.Forms.Label txtProjectName;
        private System.Windows.Forms.Label lblProjectName;
        private System.Windows.Forms.ComboBox cmbProjectCode;
        private System.Windows.Forms.Label lblProjectCode;
        private System.Windows.Forms.Button btnTransfer;
        private System.Windows.Forms.DateTimePicker dtpReturndate;
        private System.Windows.Forms.Label lblWarning;
        private System.Windows.Forms.Button btnExit;
    }
}
