﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Erp_Project_With_Buttons.Item_Return_Adjust_Stock
{
    public partial class AdjustStock : Form
    {
        #region Intialization of Local Datatables, Variables Daclaration
        frmForm2 frm = new frmForm2();
        Global GLobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        //frmForm2 form = new frmForm2();
        Login.frmLoginForm login = new Login.frmLoginForm();
        DataTable dtItemList = new DataTable();
        DataTable dtProjectList = new DataTable();
        DataTable dtjobissuedlist = new DataTable();
        DataTable dtIssuedList = new DataTable();
        DataTable dtItemType = new DataTable();
        DataView dvItemList = new DataView();
        DataTable dtItemcode = new DataTable();
        DataTable dtItemAdd = new DataTable();
        DataTable dtnonprojectItemList = new DataTable();
        DataTable dtjobissuedmaterials = new DataTable();
        DataTable dtjobProjectList = new DataTable();
        DataTable dtItemReurndetails = new DataTable();
        DataTable dtTableFilter = new DataTable();
        DataTable InventoryIndent = new DataTable();
        DataTable oldIndent = new DataTable();
        double dAvailableQty;
        double dReceipt;
        double dStockValue;
        string[] sItemCode;
        int check = 0;
        double oldvalue;
        SqlConnection SQLCon;
        public AdjustStock()
        {
            InitializeComponent();
        }
        #endregion
        #region Code to Check Project Issued Items Check
        private void chkProjectIssuedReturn_CheckedChanged(object sender, EventArgs e)
        {
            txtjobprojectcode.ResetText();
            txtreturnedby.ResetText();
            lblProjectStatus.ResetText();
            if (chkProjectIssuedReturn.CheckState == CheckState.Checked)
            {
                cmbjobwonumber.ResetText();
                cmbjobwonumber.Items.Clear();
                lblWorkOrderNo.Text = "Indent No :";
                dtjobissuedlist = DAL.fnProjectIndentIssuereturnlist(1, null).Tables[0];

                foreach (DataRow dr in dtjobissuedlist.Rows)
                {
                    if (!cmbjobwonumber.Items.Contains(dr["Indent_Number"].ToString()))
                        cmbjobwonumber.Items.Add(dr["Indent_Number"].ToString());

                }

                txtrecieveQuantity.ResetText();
                // cmbreturnProjnum.ResetText();
                // cmbreturnProjnum.Items.Clear();
                txtreturnProjdesc.ResetText();
                dtProjectList = DAL.fnProjectList(null).Tables[0];
                //DataView dvproject = new DataView(dtProjectList);
                //dvproject.RowFilter = "Status not like 'Revenue Recognised'";
                //dtProjectList = dvproject.ToTable();
                //foreach (DataRow dr in dtProjectList.Rows)
                //{
                //    if (!cmbreturnProjnum.Items.Contains(dr["ProjectCode"].ToString()))
                //        cmbreturnProjnum.Items.Add(dr["ProjectCode"].ToString());
                //}
                lblReturnvalue.ResetText();
                txtreturnItemDescription.ResetText();
                this.chkJobReturn.Checked = false;
                this.chknonprojmaterial.Checked = false;
                txtReciepttype.Text = "Project Issued Return";
                //   lbljobprojectcode.Visible = false;
                // txtjobprojectcode.Visible = false;
                pnlprojreturn.Enabled = true;
                // lblProjnum.Text = "Indent Number*";
                // cmbjobwonumber.Visible = false;
                // cmbreturnProjnum.Visible = true;
                cmbreturnItemcode.Items.Clear();
                cmbreturnItemcode.Text = string.Empty;
            }
            else
            {
                this.chkJobReturn.Checked = true;
            }
        }
        #endregion
        #region Adjust Stock Form Load & Initialising the Components
        private void AdjustStock_Load(object sender, EventArgs e)
        {
            chkItemCode.Checked = true;
            dtpReturndate.Format = DateTimePickerFormat.Custom;
            dtpReturndate.CustomFormat = "dd-MM-yyyy";
            dtpsadate.Format = DateTimePickerFormat.Custom;
            dtpsadate.CustomFormat = "dd-MM-yyyy";
            dtItemList = DAL.fnItemList(null).Tables[0];
            dtTableFilter = dtItemList;
            chkProjectIssuedReturn.Checked = true;
        }
        #endregion
        #region Code to View Item Return Project Select
        private void cmbreturnProjnum_SelectedIndexChanged(object sender, EventArgs e)
        {
            //lblwarningmessage.Visible = false;
            //DataView dvProjectList = new DataView(dtProjectList);
            //cmbreturnItemcode.Enabled = true;
            //if (cmbreturnProjnum.SelectedItem.Equals("None"))
            //{
            //    txtreturnProjdesc.Text = string.Empty;
            //}
            //else
            //{
            //    dvProjectList.RowFilter = "ProjectCode Like'" + cmbreturnProjnum.Text + "%'";
            //    DataTable dt = dvProjectList.ToTable();
            //    txtreturnProjdesc.Text = dt.Rows[0]["ProjectDescription"].ToString();
            //    lblProjectStatus.Text = dt.Rows[0]["Status"].ToString();
            //}
            //cmbreturnItemcode.Items.Clear();
            //cmbreturnItemcode.Text = string.Empty;
            //dtIssuedList = DAL.fnIsuuedItemList(cmbreturnProjnum.Text).Tables[0];
            //if (dtIssuedList.Rows.Count > 0)
            //{
            //    foreach (DataRow dr in dtIssuedList.Rows)
            //    {
            //        if (!cmbreturnItemcode.Items.Contains(dr["Item_Code"].ToString()))
            //            cmbreturnItemcode.Items.Add(dr["Item_Code"].ToString());
            //    }
            //}
            //else
            //{
            //    cmbreturnItemcode.Enabled = false;
            //    lblwarningmessage.Visible = true;
            //    lblReturnvalue.ResetText();
            //    txtreturnItemDescription.ResetText();
            //}
        }
        #endregion
        #region Code to View Item Returned List
        double unitprice = 0;
        private void cmbreturnItemcode_SelectedIndexChanged(object sender, EventArgs e)
        {
            unitprice = 0;
            if (chkProjectIssuedReturn.CheckState == CheckState.Checked)
            {
                double freturnlist = 0.0;
                double fCount = 0;
                double freturncount = 0.0;
                DataView dv = new DataView(dtItemList);
                dtIssuedList = DAL.fnIsuuedItemList(cmbreturnItemcode.Text, cmbjobwonumber.Text).Tables[0];
                DataView dvItemQtyfilter = new DataView(dtIssuedList);
                dv.RowFilter = "ItemCode Like'" + cmbreturnItemcode.Text + "%'";
                DataTable dtItemDesc = dv.ToTable();
                txtreturnItemDescription.Text = dtItemDesc.Rows[0]["ItemDescription"].ToString();
                unitprice = Convert.ToDouble(dtItemDesc.Rows[0]["UnitCost"].ToString());
                dvItemQtyfilter.RowFilter = "Item_Code like'" + cmbreturnItemcode.Text + "%'";

                foreach (DataRow DR in dvItemQtyfilter.ToTable().Rows)
                {
                    fCount += Convert.ToDouble(DR["IssuedQuantity"].ToString());
                }
                freturncount = DAL.fnReturnItemList(txtjobprojectcode.Text, cmbreturnItemcode.Text, cmbjobwonumber.Text);
                freturnlist = fCount - freturncount;
                lblReturnvalue.Text = freturnlist.ToString();
            }

            else if (chkJobReturn.CheckState == CheckState.Checked)
            {
                double fjobreturnlist = 0.0;
                double fjobCount = 0;
                double fjobreturncount = 0.0;

                DataView dv = new DataView(dtItemList);
                dtjobissuedmaterials = DAL.fnJobIssuereturnlist(2, cmbjobwonumber.Text, cmbreturnItemcode.Text).Tables[0];
                if (dtjobissuedmaterials.Rows.Count > 0)
                {
                    DataView dvItemQtyfilter = new DataView(dtjobissuedmaterials);

                    // txtjobjwnumber.Text = dtjobissuedmaterials.Rows[0]["JWNumber"].ToString();
                    dv.RowFilter = "ItemCode Like'" + cmbreturnItemcode.Text + "%'";
                    DataTable dt = dv.ToTable();
                    txtreturnItemDescription.Text = dt.Rows[0]["ItemDescription"].ToString();
                    unitprice = Convert.ToDouble(dt.Rows[0]["UnitCost"].ToString());
                    dvItemQtyfilter.RowFilter = "ItemCode like'" + cmbreturnItemcode.Text + "%'";
                    foreach (DataRow DR in dvItemQtyfilter.ToTable().Rows)
                    {
                        fjobCount += Convert.ToDouble(DR["issuedQuantity"].ToString());
                    }
                    fjobreturncount = DAL.fnReturnItemListJobIssued(txtjobprojectcode.Text, cmbreturnItemcode.Text, cmbjobwonumber.Text);
                    fjobreturnlist = fjobCount - fjobreturncount;
                    lblReturnvalue.Text = fjobreturnlist.ToString();
                }
            }
            else if (chknonprojmaterial.CheckState == CheckState.Checked)
            {
                DataView dv = new DataView(dtnonprojectItemList);
                dtnonprojectItemList = DAL.fnItemList(null).Tables[0];
                if (dtnonprojectItemList.Rows.Count > 0)
                {
                    DataView dvItemQtyfilter = new DataView(dtnonprojectItemList);
                    dv.RowFilter = "ItemCode Like'" + cmbreturnItemcode.Text + "%'";
                    DataTable dt = dv.ToTable();
                    txtreturnItemDescription.Text = dt.Rows[0]["ItemDescription"].ToString();
                }
            }
            else
            {

            }
        }
        #endregion
        #region Code to Enter only Numbers & a Decimal
        private void txtrecieveQuantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
        #endregion
        #region Code to Load Job Retun Item
        private void chkJobReturn_CheckedChanged(object sender, EventArgs e)
        {
            if (chkJobReturn.CheckState == CheckState.Checked)
            {
                cmbjobwonumber.ResetText();
                cmbjobwonumber.Items.Clear();
                lblWorkOrderNo.Text = "WorkOrder No:";
                cmbjobwonumber.ResetText();
                txtrecieveQuantity.ResetText();
                cmbjobwonumber.Items.Clear();
                dtjobissuedlist = DAL.fnJobIssuereturnlist(0, null, null).Tables[0];

                foreach (DataRow dr in dtjobissuedlist.Rows)
                {
                    if (!cmbjobwonumber.Items.Contains(dr["WONumber"].ToString()))
                        cmbjobwonumber.Items.Add(dr["WONumber"].ToString());

                }
                txtreturnProjdesc.ResetText();
                //  txtjobprojectcode.ResetText();
                this.chkProjectIssuedReturn.Checked = false;
                this.chknonprojmaterial.Checked = false;
                txtReciepttype.Text = "Job Issued Return";
                //  lbljobprojectcode.Visible = true;
                // txtjobprojectcode.Visible = true;
                pnlprojreturn.Enabled = true;
                // lblProjnum.Text = "Work Order No*";
                //  cmbjobwonumber.Visible = true;
                // cmbreturnProjnum.Visible = false;
                cmbreturnItemcode.Items.Clear();
                cmbreturnItemcode.Text = string.Empty;
                lblwarningmessage.Visible = false;
                lblReturnvalue.ResetText();
                txtreturnItemDescription.ResetText();
            }
            else
            {
                this.chkProjectIssuedReturn.Checked = true;
            }
        }
        #endregion
        #region Code to Load Items Retun on WorkOrder Number Selected
        private void cmbjobwonumber_SelectedIndexChanged(object sender, EventArgs e)
        {
            // cmbreturnProjnum.ResetText();
            // cmbreturnProjnum.Items.Clear();
            txtjobprojectcode.ResetText();
            txtreturnedby.ResetText();
            lblProjectStatus.ResetText();
            //  txtjobjwnumber.ResetText();
            txtrecieveQuantity.ResetText();
            lblReturnvalue.ResetText();
            lblProjectStatus.ResetText();
            txtjobprojectcode.ResetText();
            txtreturnItemDescription.ResetText();
            cmbreturnItemcode.Items.Clear();
            cmbreturnItemcode.Text = string.Empty;
            cmbreturnItemcode.Enabled = true;
            DataTable dtIssuedList = new DataTable();
            if (chkProjectIssuedReturn.CheckState == CheckState.Checked)
            {
                dtIssuedList = DAL.fnProjectIndentIssuereturnlist(2, cmbjobwonumber.Text).Tables[0];

                if (dtIssuedList.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtIssuedList.Rows)
                    {
                        if (!cmbreturnItemcode.Items.Contains(dr["Item_Code"].ToString()))
                            cmbreturnItemcode.Items.Add(dr["Item_Code"].ToString());
                    }

                    txtjobprojectcode.Text = dtIssuedList.Rows[0]["Project_Code"].ToString();
                    DataView dvProjectList = new DataView(dtProjectList);
                    dvProjectList.RowFilter = "ProjectCode Like'" + txtjobprojectcode.Text + "%'";
                    DataTable dt = dvProjectList.ToTable();
                    txtreturnProjdesc.Text = dt.Rows[0]["ProjectDescription"].ToString();
                    lblProjectStatus.Text = dt.Rows[0]["Status"].ToString();

                    //foreach (DataRow dr in dtIssuedList.Rows)
                    //{
                    //    if (!cmbreturnProjnum.Items.Contains(dr["ProjectCode"].ToString()))
                    //        cmbreturnProjnum.Items.Add(dr["ProjectCode"].ToString());
                    //}
                }
            }
            else if (chkJobReturn.CheckState == CheckState.Checked)
            {
                dtjobissuedmaterials = DAL.fnJobIssuereturnlist(1, cmbjobwonumber.Text, "").Tables[0];
                if (dtjobissuedmaterials.Rows.Count > 0)
                {
                    txtjobprojectcode.Text = dtjobissuedmaterials.Rows[0]["ProjectCode"].ToString();
                    DataView dvProjectList = new DataView(dtProjectList);
                    dvProjectList.RowFilter = "ProjectCode Like'" + txtjobprojectcode.Text + "%'";
                    DataTable dt = dvProjectList.ToTable();
                    txtreturnProjdesc.Text = dt.Rows[0]["ProjectDescription"].ToString();
                    lblProjectStatus.Text = dt.Rows[0]["Status"].ToString();

                    foreach (DataRow dr in dtjobissuedmaterials.Rows)
                    {
                        if (!cmbreturnItemcode.Items.Contains(dr["ItemCode"].ToString()))
                            cmbreturnItemcode.Items.Add(dr["ItemCode"].ToString());
                    }
                }
            }
        }
        #endregion
        #region Code to Load Items on JobWork Project Changed
        private void txtjobprojectcode_TextChanged(object sender, EventArgs e)
        {
            dtjobProjectList = DAL.fnProjectList(null).Tables[0];
            DataView dvprojectlist = new DataView(dtjobProjectList);
            dvprojectlist.RowFilter = "ProjectCode ='" + txtjobprojectcode.Text + "'";
            DataTable dtProject = dvprojectlist.ToTable();
            if (dtProject.Rows.Count > 0)
            {
                txtreturnProjdesc.Text = dtProject.Rows[0]["ProjectDescription"].ToString();
            }
        }
        #endregion
        #region Code to Return Non Project Items
        private void chknonprojmaterial_CheckedChanged(object sender, EventArgs e)
        {
            if (chknonprojmaterial.CheckState == CheckState.Checked)
            {
                txtReciepttype.Text = "Non Project Material";
                // lbljobprojectcode.Visible = false;
                // txtjobprojectcode.Visible = false;
                lblwarningmessage.Visible = false;
                txtrecieveQuantity.ResetText();
            }
        }
        #endregion

        DataTable dtCheckBOMReturn = new DataTable();
        #region Code to Save Item Return Details

        private void testing_Return_button(object sender, EventArgs e)
        {
            if (comboBoxReturnType.Text == string.Empty)
            {
                MessageBox.Show("Please Select the Return Type for the future process...!");
                comboBoxReturnType.Focus();
                return;
            }
            else
            {
                MessageBox.Show(comboBoxReturnType.Text);
            }
            MessageBox.Show("check the access for the next line code...!");
        }

        private void btnItemReturn_Click(object sender, EventArgs e)
        {
            if (chkProjectIssuedReturn.CheckState == CheckState.Checked || chkJobReturn.CheckState == CheckState.Checked)
            {
                try
                {
                    if (string.IsNullOrEmpty(txtrecieveQuantity.Text) || Convert.ToDouble(txtrecieveQuantity.Text) == 0)
                    {
                        MessageBox.Show("Please Enter Quanity", "Error", 0, MessageBoxIcon.Error);
                        txtrecieveQuantity.Focus();
                    }
                    else if (Convert.ToDouble(txtrecieveQuantity.Text) > Convert.ToDouble(lblReturnvalue.Text))
                    {
                        MessageBox.Show("Return quantity more than Items Issued ! Items Not returned", "Error", 0, MessageBoxIcon.Error);
                        txtrecieveQuantity.ResetText();
                        txtrecieveQuantity.Focus();
                    }
                    else if (comboBoxReturnType.Text == string.Empty)
                    {
                        MessageBox.Show("Please Select the Return Type for the future process...!");
                        comboBoxReturnType.Focus();
                        return;
                    }
                   
                    else
                    {
                        //MessageBox.Show(cmbreturnItemcode.Text,"1");
                        //MessageBox.Show(txtjobprojectcode.Text, "2");
                       // MessageBox.Show(txtreturnedby.Text, "3");
                     
                        if (cmbreturnItemcode.Text != string.Empty && (!string.IsNullOrEmpty(txtjobprojectcode.Text)) && txtreturnedby.Text != string.Empty && txtjobprojectcode.Text != "613201177001" && txtjobprojectcode.Text != "51423973035")
                        {
                            if (chkProjectIssuedReturn.CheckState == CheckState.Checked)
                            {
                                dtCheckBOMReturn = DAL.fnProjectIndentIssuereturnlist(3, cmbjobwonumber.Text).Tables[0];
                                if (dtCheckBOMReturn.Rows.Count > 0)
                                {
                                    if (!string.IsNullOrEmpty(dtCheckBOMReturn.Rows[0]["ProductNo"].ToString()))
                                    {
                                       GLobalClass.iSuccess = DAL.fnItemReturn(4, cmbreturnItemcode.Text, txtjobprojectcode.Text, Convert.ToDouble(txtrecieveQuantity.Text), (dtpReturndate.Text), dtCheckBOMReturn.Rows[0]["ProductNo"].ToString(), lblProjectStatus.Text, unitprice, "ItemReturn", cmbjobwonumber.Text);
                                    }
                                }
                                GLobalClass.iSuccess = DAL.fnAddERPLog(0, cmbjobwonumber.Text, login.GetUserDetails[2], dtpReturndate.Text, "Item Return", "ItemReturn");
                                GLobalClass.iSuccess = DAL.fnItemReturn(Global.uINSERT, cmbreturnItemcode.Text, txtjobprojectcode.Text, Convert.ToDouble(txtrecieveQuantity.Text), (dtpReturndate.Text), txtreturnedby.Text, lblProjectStatus.Text, unitprice, "ItemReturn", cmbjobwonumber.Text);
                                try
                                {
                                   // MessageBox.Show(cmbreturnItemcode.Text, cmbjobwonumber.Text);

                                    InventoryIndent = DAL.fnIndentAndItemToPickLocation(cmbreturnItemcode.Text, cmbjobwonumber.Text).Tables[0];
                                   // MessageBox.Show(InventoryIndent.Rows.Count.ToString(), "Indent Count");
                                    if (InventoryIndent.Rows.Count > 0)
                                    {
                                        // MessageBox.Show("Indent Existing!!");
                                        // MessageBox.Show(InventoryIndent.Rows.Count.ToString(), "InventoryIndent Count");

                                        DataTable getIndentInventoryDetails = DAL.fnIndentAndItemToPickLocation(cmbreturnItemcode.Text, cmbjobwonumber.Text).Tables[0];

                                        double utilistedQty = Convert.ToDouble(getIndentInventoryDetails.Rows[0]["UtilisedQuantity"].ToString()) - Convert.ToDouble(txtrecieveQuantity.Text);
                                        double retuenQty = string.IsNullOrEmpty(getIndentInventoryDetails.Rows[0]["ItemReturnQty"].ToString()) ? 0 : Convert.ToDouble(getIndentInventoryDetails.Rows[0]["ItemReturnQty"].ToString()) + Convert.ToDouble(txtrecieveQuantity.Text);
                                       // MessageBox.Show(retuenQty.ToString());
                                        int fnUpdateInventoryIndentReturnStatus = DAL.fnUpdateInventoryIndentReturn("UPDATE", cmbreturnItemcode.Text, cmbjobwonumber.Text, utilistedQty, retuenQty);

                                        // MessageBox.Show(fnUpdateInventoryIndentReturnStatus.ToString(), "Updated Status");

                                        try
                                        {

                                            foreach (DataRow IndentLog in InventoryIndent.Rows)
                                            {
                                                //fnAddERPInventoryReturnLogs
                                                //MessageBox.Show(IndentLog["ProjectCode"].ToString(), "ProjectCode");
                                                int fnAddERPInventoryReturnLogsStatus = DAL.fnAddERPInventoryReturnLogs(Global.uINSERT, cmbreturnItemcode.Text, cmbjobwonumber.Text, IndentLog["ProjectCode"].ToString(),
                                                Convert.ToDouble(txtrecieveQuantity.Text), dtpReturndate.Text, login.GetUserDetails[2].ToString().ToLower(), lblProjectStatus.Text, IndentLog["GINNumber"].ToString(),
                                                IndentLog["BatchCode"].ToString(), IndentLog["Location"].ToString(), "", comboBoxReturnType.Text
                                                );

                                                //here need to add the update the 
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            MessageBox.Show("Error happaning Because issue with Create Inventory Return with existing Indent" + ex.Message);
                                        }
                                        //fnUpdateERPInventoryIndentAssignQty


                                        try
                                        {

                                            if (comboBoxReturnType.Text == "Quality issue")
                                            {
                                                int fnAddERPInventoryReturnLogsStatus = DAL.fnAddERPInventoryScrapLogs(Global.uINSERT, cmbreturnItemcode.Text, cmbjobwonumber.Text, txtjobprojectcode.Text,
                                                                                               Convert.ToDouble(txtrecieveQuantity.Text), dtpReturndate.Text, login.GetUserDetails[2].ToString().ToLower(), lblProjectStatus.Text,
                                                                                               InventoryIndent.Rows[0]["GINNumber"].ToString(), InventoryIndent.Rows[0]["BatchCode"].ToString() , "Quarantined", comboBoxReturnType.Text
                                                                                               );
                                               // MessageBox.Show("The Item Moved to the Scrap...!");
                                            }
                                            else
                                            {

                                                try
                                                {
                                                  

                                                    //I want to add this quantities and - cmbreturnItemcode.text
                                                    //i want to convert string in to array

                                                  

                                                    List<string> collectedGINnumbers = InventoryIndent.Rows[0]["GINNumber"].ToString().Split(',').ToList();

                                                   // List<string> collectedLocations = locations.Split(',').ToList();
                                                   // List<int> collectedQuantities = quantities.Split(',').Select(int.Parse).ToList();




                                                    foreach (DataRow IndentLog in InventoryIndent.Rows)
                                                    {
                                                        DataTable getInventoryGINDeatils = DAL.getERPInventoryGINDeatils(cmbreturnItemcode.Text, collectedGINnumbers[0]?.ToString(), null).Tables[0];

                                                        double returnAddedQty = Convert.ToDouble(getInventoryGINDeatils.Rows[0]["RemainingQty"].ToString()) + Convert.ToDouble(txtrecieveQuantity.Text);

                                                        int fnUpdateInventoryGINLog_status = DAL.fnUpdateInventoryGINLog("UPDATE", cmbreturnItemcode.Text, collectedGINnumbers[0]?.ToString(), returnAddedQty);

                                                        // int fnUpdateERPInventoryIndentAssignQty_status = DAL.fnUpdateERPInventoryIndentAssignQty("UPDATE" );
                                                        //here need to add the update the 
                                                    }
                                                }
                                                catch (Exception ex)
                                                {
                                                    MessageBox.Show("Error happaning Because issue with Create Inventory Ident Update - AssignQty" + ex.Message);
                                                }
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            MessageBox.Show("Error happaning Because issue with creating Inventory Scrap log" + ex.Message);
                                        }


                                    }
                                    else
                                    {
                                        //oldIndent
                                        //MessageBox.Show("Indent Not Present in the Existing ERP IndentTable...!");
                                        oldIndent = DAL.fnGetERPIndentLogs(cmbreturnItemcode.Text, cmbjobwonumber.Text).Tables[0];
                                        if (oldIndent.Rows.Count > 0)
                                        {
                                            foreach (DataRow row in oldIndent.Rows)
                                            {
                                                double utilistedQty = Convert.ToDouble(row["IndentQty"].ToString()) - Convert.ToDouble(txtrecieveQuantity.Text);
                                                int successValue = DAL.fnAddERPInventoryIndentForReturn(Global.uINSERT, row["IndentNo"].ToString(), row["ItemCode"].ToString(), row["ProjectCode"].ToString(), row["IndentBy"].ToString(), row["IndentDate"].ToString(),
                                                  Convert.ToDouble(row["IndentQty"].ToString()), Convert.ToDouble(row["IndentRemainingQty"].ToString()), "Item Return", "closed", row["ProjectBOMCode"].ToString(),
                                                  row["ProductNo"].ToString(), 0, row["ProjectStatus"].ToString(), "", row["ApprovedBy"].ToString(), row["ApprovedDate"].ToString()
                                                  , "NO GINNUMBER", "NO BatchCode", "NO Location", utilistedQty, Convert.ToDouble(txtrecieveQuantity.Text));
                                            }
                                        }
                                        try
                                        {
                                            foreach (DataRow IndentLog in oldIndent.Rows)
                                            {
                                                //fnAddERPInventoryReturnLogs
                                                int fnAddERPInventoryReturnLogsStatus = DAL.fnAddERPInventoryReturnLogs(Global.uINSERT, cmbreturnItemcode.Text, cmbjobwonumber.Text, IndentLog["ProjectCode"].ToString(),
                                                Convert.ToDouble(txtrecieveQuantity.Text), dtpReturndate.Text, login.GetUserDetails[2].ToString().ToLower(), lblProjectStatus.Text, "NO GINNUMBER", "NO BatchCode", "NO Location", "", comboBoxReturnType.Text
                                                );
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            MessageBox.Show("Error happaning Because issue with Create Inventory Return with old Indent" + ex.Message);
                                        }

                                    }

                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show("Error happaning Because issue with update Inventory Indent" + ex.Message);
                                }


                               


                            }
                            else if (chkJobReturn.CheckState == CheckState.Checked)
                            {
                                dtCheckBOMReturn = DAL.fnProjectIndentIssuereturnlist(4, cmbjobwonumber.Text).Tables[0];
                                if (dtCheckBOMReturn.Rows.Count > 0)
                                {
                                    if (!string.IsNullOrEmpty(dtCheckBOMReturn.Rows[0]["ProductNo"].ToString()))
                                    {
                                        GLobalClass.iSuccess = DAL.fnItemReturn(4, cmbreturnItemcode.Text, txtjobprojectcode.Text, Convert.ToDouble(txtrecieveQuantity.Text), (dtpReturndate.Text), dtCheckBOMReturn.Rows[0]["ProductNo"].ToString(), lblProjectStatus.Text, unitprice, "ItemReturn", cmbjobwonumber.Text);
                                    }
                                }
                                GLobalClass.iSuccess = DAL.fnAddERPLog(0, cmbjobwonumber.Text, login.GetUserDetails[2], dtpReturndate.Text, "Item Job Return", "ItemReturnJobIssued");
                                GLobalClass.iSuccess = DAL.fnItemReturnJObIssued(Global.uINSERT, cmbreturnItemcode.Text, txtjobprojectcode.Text, Convert.ToDouble(txtrecieveQuantity.Text), (dtpReturndate.Text), txtreturnedby.Text, lblProjectStatus.Text, unitprice, cmbjobwonumber.Text);
                            }

                             if (GLobalClass.iSuccess > 0 && comboBoxReturnType.Text != "Quality issue")
                             {
                               dtItemReurndetails = DAL.fnReturnItemDetails(cmbreturnItemcode.Text).Tables[0];
                                     if (dtItemReurndetails.Rows.Count > 0)
                                     {
                                       if (string.IsNullOrEmpty(dtItemReurndetails.Rows[0]["AvailableQty"].ToString()))
                                     {
                                       dAvailableQty = Convert.ToDouble(txtrecieveQuantity.Text);
                                     }
                                     else
                                     {
                                        dAvailableQty = Convert.ToDouble(dtItemReurndetails.Rows[0]["AvailableQty"].ToString()) + Convert.ToDouble(txtrecieveQuantity.Text);
                                     }
                                      }


                                        if (string.IsNullOrEmpty(dtItemReurndetails.Rows[0]["Receipt"].ToString()))
                                         {

                                           dReceipt = Convert.ToDouble(txtrecieveQuantity.Text);
                                         }
                                         else
                                         {
                                             dReceipt = Convert.ToDouble(dtItemReurndetails.Rows[0]["Receipt"].ToString()) + Convert.ToDouble(txtrecieveQuantity.Text);
                                         }

                                         if (string.IsNullOrEmpty(dtItemReurndetails.Rows[0]["UnitCost"].ToString()))
                                         {
                                             dStockValue = 0;
                                         }
                                         else
                                         {
                                            dStockValue = Convert.ToDouble(dtItemReurndetails.Rows[0]["UnitCost"].ToString()) * dAvailableQty;
                                         }

                                          GLobalClass.iSuccess = DAL.fnReturnItemUpdate(Global.uUPDATE, dAvailableQty, dReceipt, dStockValue, cmbreturnItemcode.Text);


                                        MessageBox.Show("Success..  " + txtreturnItemDescription.Text + "  Items of " + txtrecieveQuantity.Text + " numbers returned!", "Success", 0, MessageBoxIcon.Information);
                                         lblReturnvalue.Text = (Convert.ToDouble(lblReturnvalue.Text) - Convert.ToDouble(txtrecieveQuantity.Text)).ToString();
                                         txtrecieveQuantity.ResetText();
                                          reSetAll();
                            }
                            else
                            {
                                MessageBox.Show("The Item Moved to the Quarantined...!");
                                reSetAll();
                            }
                        }
                        else
                        {
                            MessageBox.Show("One are more fields of following are empty (ItemCode,Quantity,ProjectCode,ItemType,Returned By)", "Error", 0, MessageBoxIcon.Error);
                            if (cmbreturnItemcode.SelectedIndex == -1)
                            {
                                cmbreturnItemcode.Focus();
                            }
                            //else if (cmbreturnProjnum.SelectedIndex == -1)
                            //{
                            //    cmbreturnProjnum.Focus();
                            //}
                            else if (txtreturnedby.Text == "")
                            {
                                txtreturnedby.Focus();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("btnItemReturn_Click" + ex.Message);
                }
            }
        }
        #endregion
        #region Code to Filter Item Type
        private void cmbItemType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        #endregion
        #region Code to Filter Item Search
        private void RowFilter()
        {
            chklbItemList.Items.Clear();
            foreach (DataRowView dv in dvItemList)
            {
                chklbItemList.Items.Add(string.Concat(dv[17].ToString(), ") ", dv[0].ToString(), ", ", dv[1].ToString(), ", ", dv[12].ToString()));
            }
        }
        #endregion
        #region Code to Load Items
        private void chklbItemList_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            int i = 0;
            try
            {
                sItemCode = chklbItemList.SelectedItem.ToString().Trim().Split(')');
                string sID = sItemCode[0];
                dtItemcode = DAL.fnStandardCostItemList(sID).Tables[0];
                if (dtItemcode.Rows.Count > 0)
                {
                    if (!chklbItemList.CheckedItems.Contains(chklbItemList.SelectedItem))
                    {
                        foreach (DataGridViewRow DGVR in dgStockAdjust.Rows)
                        {
                            if (DGVR.Cells["ItemCode"].Value.ToString().Equals(dtItemcode.Rows[0]["ItemCode"].ToString()))
                            {
                                i = 1;
                                break;
                            }
                        }
                        if (i != 1)
                        {
                            if (dtItemAdd.Rows.Count == 0)
                            {
                                dtItemAdd = DAL.fnStandardCostItemList(null).Tables[0];
                            }

                            dtItemAdd.Rows.Add("", dtItemcode.Rows[0]["ItemCode"].ToString(), dtItemcode.Rows[0]["ItemDescription"].ToString(),
                                               Convert.ToDouble(dtItemcode.Rows[0]["UnitCost"].ToString()), dtItemcode.Rows[0]["Units"].ToString(),
                                               Convert.ToDouble(dtItemcode.Rows[0]["AvailableQty"].ToString()), 0, 0, dtItemcode.Rows[0]["ReqQty"].ToString(), 0, 0, 0, 0, 0, 0, "");

                            dgStockAdjust.AutoGenerateColumns = false;
                            dgStockAdjust.DataSource = dtItemAdd;
                        }
                        else
                        {
                            MessageBox.Show("Selected Item already present in the list", "Error", 0, MessageBoxIcon.Error);
                            int k = chklbItemList.SelectedIndex;
                            chklbItemList.SetItemCheckState(k, CheckState.Unchecked);
                        }
                    }
                    else
                    {
                        int rowIndex = -1;
                        bool bSelected;

                        foreach (DataGridViewRow row in dgStockAdjust.Rows)
                        {
                            bSelected = (row.Cells["ItemCode"].Value.ToString().Equals(dtItemcode.Rows[0]["ItemCode"].ToString()));
                            if (bSelected == true)
                            {
                                rowIndex = row.Index;
                                dgStockAdjust.Rows.Remove(dgStockAdjust.Rows[rowIndex]);
                                break;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("PurchaseOrder_chklbItemList_ItemCheck" + ex.Message);
            }
        }
        #endregion
        #region Code to Validate Numeric value Entered
        private void dgStockAdjust_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if ((dgStockAdjust.CurrentCell.OwningColumn.Name == "ActualQty"))
            {
                oldvalue = Convert.ToDouble(dgStockAdjust.CurrentCell.Value);
            }
        }

        private void dgStockAdjust_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
            }
        }

        private void Control_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }
            // only allow one decimal point
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                e.Handled = true;
            }
        }

        private void dgStockAdjust_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if ((dgStockAdjust.CurrentCell.Value != null) && (dgStockAdjust.CurrentCell.Value.ToString() != "."))
            {
                dgStockAdjust.CurrentRow.Cells["AdjustedQty"].Value = (Convert.ToDouble(dgStockAdjust.CurrentRow.Cells["ActualQty"].Value) - Convert.ToDouble(dgStockAdjust.CurrentRow.Cells["AvailableQty"].Value)).ToString();
            }
            else
            {
                MessageBox.Show("Enter a Valid Value", "Error", 0, MessageBoxIcon.Error);
                dgStockAdjust.CurrentCell.Value = oldvalue;
            }
        }
        #endregion
        #region Code to Update the Stock
        private void btnUpdateStock_Click(object sender, EventArgs e)
        {
            bool bNullValuecheck = false;
            SQLCon = new SqlConnection(DataAccessLayer.cs);
            foreach (DataGridViewRow row in dgStockAdjust.Rows)
            {
                if ((row.Cells["ActualQty"].Value.ToString()) == null)
                {
                    MessageBox.Show("Required Quantity field is empty in item code: " + row.Cells["ItemCode"].Value.ToString(), "Error", 0, MessageBoxIcon.Error);
                    bNullValuecheck = true;
                    break;
                }
            }
            if (!bNullValuecheck)
            {
                foreach (DataGridViewRow row in dgStockAdjust.Rows)
                {
                    GLobalClass.iSuccess = DAL.fnAddReciept(Global.uINSERT, row.Cells["ItemCode"].Value.ToString(), row.Cells["ProjectCode"].Value.ToString(), 0, "0", Convert.ToDouble(row.Cells["AdjustedQty"].Value), Convert.ToDouble(row.Cells["unitprice1"].Value),
                        "0", dtpsadate.Text, "0", "Stock Adjusted", "0", "", "", 0, 0, 0, 0, 0, 0, "", "", 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", 0, 0);

                    GLobalClass.iSuccess = DAL.fnAddERPLog(0, row.Cells["ItemCode"].Value.ToString(), login.GetUserDetails[2], dtpsadate.Text, "Stock Adjusted", "Receipt");

                    try
                    {
                        SqlCommand cmd = new SqlCommand("UPDATE ItemMaster SET AvailableQty='" + Convert.ToDouble(row.Cells["ActualQty"].Value) + "' WHERE ItemCode='" + row.Cells["ItemCode"].Value.ToString() + "'", SQLCon);
                        SQLCon.Open();
                        cmd.ExecuteNonQuery();
                        SQLCon.Close();
                        SqlCommand cmdupdate = new SqlCommand("UPDATE ItemMaster SET StockValue=(UnitCost*AvailableQty) WHERE ItemCode='" + row.Cells["ItemCode"].Value.ToString() + "'", SQLCon);
                        SQLCon.Open();
                        cmdupdate.ExecuteNonQuery();
                        SQLCon.Close();
                        check = 1;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                        SQLCon.Close();
                    }
                }
            }
            if (check == 1)
            {


                MessageBox.Show("Items Successfully Updated", "Success", 0, MessageBoxIcon.Information);
                btnUpdateStock.Enabled = false;
            }
        }
        #endregion
        #region Code to Filter the Item Code


        private void txtItemDescription_Enter(object sender, EventArgs e)
        {
            //  RowFilter(1, txtItemDescription.Text);
        }
        private void reSetAll()
        {
            cmbjobwonumber.Text = "";
            txtjobprojectcode.Text = "";
            txtreturnProjdesc.Text = "";
            lblProjectStatus.Text = "";
            lblReturnvalue.Text = "";
            txtreturnItemDescription.Text = "";
            txtreturnedby.Text = "";
            txtrecieveQuantity.Text = "";
            comboBoxReturnType.Text = "";
            itemLocationQu.Text = "";
            cmbreturnItemcode.Text = "";
            itemLocationQu.Visible = false;
            ItemLocationLabel.Visible = false;
        }

        private void txtItemDescription_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar == '%'))
            {
                e.Handled = true;
            }
        }
        private void txtItemDescription_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);

                    RowFilter();

                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
                    RowFilter();
                }

            }
            else
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);
                    RowFilter();
                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
                    RowFilter();
                }
            }
        }
        #endregion
        #region Function to Exit Form
        private void fnFormExit()
        {
            this.Hide();
            frm.Show();
        }
        private void btnstockexit_Click(object sender, EventArgs e)
        {
            fnFormExit();
        }

        private void AdjustStock_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnFormExit();
        }

        private void btnrerurnExit_Click(object sender, EventArgs e)
        {
            fnFormExit();
        }
        #endregion

        private void chkItemCode_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemCode.CheckState == CheckState.Checked)
            {
                chkItemDesc.Checked = false;
            }
        }

        private void chkItemDesc_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemDesc.CheckState == CheckState.Checked)
            {
                chkItemCode.Checked = false;
            }
        }

        private void comboBoxReturnType_SelectedIndexChanged(object sender, EventArgs e)
        {
           // if(comboBoxReturnType.Text == "Quality issue")
            //{
            //    itemLocationQu.Visible = true;
            //    ItemLocationLabel.Visible = true;
           // }
            //else
           // {
             //   itemLocationQu.Visible = false;
              //  ItemLocationLabel.Visible = false;
            //}
        }
    }
}
