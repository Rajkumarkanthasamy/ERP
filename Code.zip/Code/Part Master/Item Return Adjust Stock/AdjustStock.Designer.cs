﻿namespace Erp_Project_With_Buttons.Item_Return_Adjust_Stock
{
    partial class AdjustStock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdjustStock));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.chknonprojmaterial = new System.Windows.Forms.CheckBox();
            this.chkProjectIssuedReturn = new System.Windows.Forms.CheckBox();
            this.chkJobReturn = new System.Windows.Forms.CheckBox();
            this.pnlprojreturn = new System.Windows.Forms.Panel();
            this.comboBoxReturnType = new System.Windows.Forms.ComboBox();
            this.InevtoryReturnType = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblWorkOrderNo = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblProjectStatus = new System.Windows.Forms.Label();
            this.txtreturnedby = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.cmbreturnItemcode = new System.Windows.Forms.ComboBox();
            this.lblwarningmessage = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnrerurnExit = new System.Windows.Forms.Button();
            this.btnItemReturn = new System.Windows.Forms.Button();
            this.lblItemcode = new System.Windows.Forms.Label();
            this.dtpReturndate = new System.Windows.Forms.DateTimePicker();
            this.txtReciepttype = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblReturnvalue = new System.Windows.Forms.Label();
            this.lblItemdescription = new System.Windows.Forms.Label();
            this.lblCustomer = new System.Windows.Forms.Label();
            this.txtreturnProjdesc = new System.Windows.Forms.Label();
            this.txtreturnItemDescription = new System.Windows.Forms.Label();
            this.lblNoofreturnitems = new System.Windows.Forms.Label();
            this.txtjobprojectcode = new System.Windows.Forms.TextBox();
            this.lbljobprojectcode = new System.Windows.Forms.Label();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.cmbjobwonumber = new System.Windows.Forms.ComboBox();
            this.txtrecieveQuantity = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.pnitemadd = new System.Windows.Forms.Panel();
            this.chkItemDesc = new System.Windows.Forms.CheckBox();
            this.chkItemCode = new System.Windows.Forms.CheckBox();
            this.txtItemDescription = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.chklbItemList = new System.Windows.Forms.CheckedListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dtpsadate = new System.Windows.Forms.DateTimePicker();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnUpdateStock = new System.Windows.Forms.Button();
            this.btnstockexit = new System.Windows.Forms.Button();
            this.dgStockAdjust = new System.Windows.Forms.DataGridView();
            this.ItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitprice1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Unit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AvailableQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ActualQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AdjustedQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemLocationLabel = new System.Windows.Forms.Label();
            this.itemLocationQu = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.pnlprojreturn.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.pnitemadd.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgStockAdjust)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(6, 13);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1298, 670);
            this.tabControl1.TabIndex = 73;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Silver;
            this.tabPage2.Controls.Add(this.chknonprojmaterial);
            this.tabPage2.Controls.Add(this.chkProjectIssuedReturn);
            this.tabPage2.Controls.Add(this.chkJobReturn);
            this.tabPage2.Controls.Add(this.pnlprojreturn);
            this.tabPage2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.tabPage2.Location = new System.Drawing.Point(4, 28);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1290, 638);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Return";
            // 
            // chknonprojmaterial
            // 
            this.chknonprojmaterial.AutoSize = true;
            this.chknonprojmaterial.Enabled = false;
            this.chknonprojmaterial.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chknonprojmaterial.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.chknonprojmaterial.Location = new System.Drawing.Point(590, 6);
            this.chknonprojmaterial.Name = "chknonprojmaterial";
            this.chknonprojmaterial.Size = new System.Drawing.Size(238, 30);
            this.chknonprojmaterial.TabIndex = 169;
            this.chknonprojmaterial.Text = "Non Project Item return";
            this.chknonprojmaterial.UseVisualStyleBackColor = true;
            this.chknonprojmaterial.CheckedChanged += new System.EventHandler(this.chknonprojmaterial_CheckedChanged);
            // 
            // chkProjectIssuedReturn
            // 
            this.chkProjectIssuedReturn.AutoSize = true;
            this.chkProjectIssuedReturn.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkProjectIssuedReturn.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.chkProjectIssuedReturn.Location = new System.Drawing.Point(36, 6);
            this.chkProjectIssuedReturn.Name = "chkProjectIssuedReturn";
            this.chkProjectIssuedReturn.Size = new System.Drawing.Size(216, 30);
            this.chkProjectIssuedReturn.TabIndex = 167;
            this.chkProjectIssuedReturn.Text = "Project Issued Return";
            this.chkProjectIssuedReturn.UseVisualStyleBackColor = true;
            this.chkProjectIssuedReturn.CheckedChanged += new System.EventHandler(this.chkProjectIssuedReturn_CheckedChanged);
            // 
            // chkJobReturn
            // 
            this.chkJobReturn.AutoSize = true;
            this.chkJobReturn.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkJobReturn.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.chkJobReturn.Location = new System.Drawing.Point(334, 6);
            this.chkJobReturn.Name = "chkJobReturn";
            this.chkJobReturn.Size = new System.Drawing.Size(184, 30);
            this.chkJobReturn.TabIndex = 165;
            this.chkJobReturn.Text = "Job Issued Return";
            this.chkJobReturn.UseVisualStyleBackColor = true;
            this.chkJobReturn.CheckedChanged += new System.EventHandler(this.chkJobReturn_CheckedChanged);
            // 
            // pnlprojreturn
            // 
            this.pnlprojreturn.BackColor = System.Drawing.Color.Silver;
            this.pnlprojreturn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlprojreturn.Controls.Add(this.itemLocationQu);
            this.pnlprojreturn.Controls.Add(this.ItemLocationLabel);
            this.pnlprojreturn.Controls.Add(this.comboBoxReturnType);
            this.pnlprojreturn.Controls.Add(this.InevtoryReturnType);
            this.pnlprojreturn.Controls.Add(this.label2);
            this.pnlprojreturn.Controls.Add(this.lblWorkOrderNo);
            this.pnlprojreturn.Controls.Add(this.label6);
            this.pnlprojreturn.Controls.Add(this.lblProjectStatus);
            this.pnlprojreturn.Controls.Add(this.txtreturnedby);
            this.pnlprojreturn.Controls.Add(this.label20);
            this.pnlprojreturn.Controls.Add(this.cmbreturnItemcode);
            this.pnlprojreturn.Controls.Add(this.lblwarningmessage);
            this.pnlprojreturn.Controls.Add(this.groupBox4);
            this.pnlprojreturn.Controls.Add(this.lblItemcode);
            this.pnlprojreturn.Controls.Add(this.dtpReturndate);
            this.pnlprojreturn.Controls.Add(this.txtReciepttype);
            this.pnlprojreturn.Controls.Add(this.label1);
            this.pnlprojreturn.Controls.Add(this.lblReturnvalue);
            this.pnlprojreturn.Controls.Add(this.lblItemdescription);
            this.pnlprojreturn.Controls.Add(this.lblCustomer);
            this.pnlprojreturn.Controls.Add(this.txtreturnProjdesc);
            this.pnlprojreturn.Controls.Add(this.txtreturnItemDescription);
            this.pnlprojreturn.Controls.Add(this.lblNoofreturnitems);
            this.pnlprojreturn.Controls.Add(this.txtjobprojectcode);
            this.pnlprojreturn.Controls.Add(this.lbljobprojectcode);
            this.pnlprojreturn.Controls.Add(this.lblQuantity);
            this.pnlprojreturn.Controls.Add(this.cmbjobwonumber);
            this.pnlprojreturn.Controls.Add(this.txtrecieveQuantity);
            this.pnlprojreturn.Location = new System.Drawing.Point(6, 41);
            this.pnlprojreturn.Name = "pnlprojreturn";
            this.pnlprojreturn.Size = new System.Drawing.Size(1267, 582);
            this.pnlprojreturn.TabIndex = 166;
            // 
            // comboBoxReturnType
            // 
            this.comboBoxReturnType.FormattingEnabled = true;
            this.comboBoxReturnType.Items.AddRange(new object[] {
            "Quality issue",
            "Customer Replacement",
            "Wrong Part Issued",
            "Extra Quality"});
            this.comboBoxReturnType.Location = new System.Drawing.Point(196, 366);
            this.comboBoxReturnType.Name = "comboBoxReturnType";
            this.comboBoxReturnType.Size = new System.Drawing.Size(272, 27);
            this.comboBoxReturnType.TabIndex = 191;
            this.comboBoxReturnType.SelectedIndexChanged += new System.EventHandler(this.comboBoxReturnType_SelectedIndexChanged);
            // 
            // InevtoryReturnType
            // 
            this.InevtoryReturnType.AutoSize = true;
            this.InevtoryReturnType.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.InevtoryReturnType.Location = new System.Drawing.Point(64, 370);
            this.InevtoryReturnType.Name = "InevtoryReturnType";
            this.InevtoryReturnType.Size = new System.Drawing.Size(120, 23);
            this.InevtoryReturnType.TabIndex = 190;
            this.InevtoryReturnType.Text = "Return Type*:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(990, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 23);
            this.label2.TabIndex = 189;
            this.label2.Text = "Return Date :";
            // 
            // lblWorkOrderNo
            // 
            this.lblWorkOrderNo.AutoSize = true;
            this.lblWorkOrderNo.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.lblWorkOrderNo.ForeColor = System.Drawing.Color.Black;
            this.lblWorkOrderNo.Location = new System.Drawing.Point(37, 19);
            this.lblWorkOrderNo.Name = "lblWorkOrderNo";
            this.lblWorkOrderNo.Size = new System.Drawing.Size(148, 23);
            this.lblWorkOrderNo.TabIndex = 188;
            this.lblWorkOrderNo.Text = "Work Order No* :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(545, 124);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(130, 23);
            this.label6.TabIndex = 187;
            this.label6.Text = "Project Status :";
            // 
            // lblProjectStatus
            // 
            this.lblProjectStatus.AutoSize = true;
            this.lblProjectStatus.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectStatus.ForeColor = System.Drawing.Color.Black;
            this.lblProjectStatus.Location = new System.Drawing.Point(672, 124);
            this.lblProjectStatus.Name = "lblProjectStatus";
            this.lblProjectStatus.Size = new System.Drawing.Size(19, 23);
            this.lblProjectStatus.TabIndex = 186;
            this.lblProjectStatus.Text = "*";
            // 
            // txtreturnedby
            // 
            this.txtreturnedby.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtreturnedby.Location = new System.Drawing.Point(195, 306);
            this.txtreturnedby.Name = "txtreturnedby";
            this.txtreturnedby.Size = new System.Drawing.Size(269, 26);
            this.txtreturnedby.TabIndex = 185;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(57, 305);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(127, 23);
            this.label20.TabIndex = 184;
            this.label20.Text = "Returned By* :";
            // 
            // cmbreturnItemcode
            // 
            this.cmbreturnItemcode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbreturnItemcode.CausesValidation = false;
            this.cmbreturnItemcode.DropDownHeight = 130;
            this.cmbreturnItemcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbreturnItemcode.FormattingEnabled = true;
            this.cmbreturnItemcode.IntegralHeight = false;
            this.cmbreturnItemcode.Location = new System.Drawing.Point(196, 199);
            this.cmbreturnItemcode.Name = "cmbreturnItemcode";
            this.cmbreturnItemcode.Size = new System.Drawing.Size(272, 26);
            this.cmbreturnItemcode.TabIndex = 129;
            this.cmbreturnItemcode.SelectedIndexChanged += new System.EventHandler(this.cmbreturnItemcode_SelectedIndexChanged);
            // 
            // lblwarningmessage
            // 
            this.lblwarningmessage.AutoSize = true;
            this.lblwarningmessage.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblwarningmessage.ForeColor = System.Drawing.Color.Red;
            this.lblwarningmessage.Location = new System.Drawing.Point(524, 447);
            this.lblwarningmessage.Name = "lblwarningmessage";
            this.lblwarningmessage.Size = new System.Drawing.Size(476, 29);
            this.lblwarningmessage.TabIndex = 164;
            this.lblwarningmessage.Text = "No items are Issued for the selected project !!!";
            this.lblwarningmessage.Visible = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnrerurnExit);
            this.groupBox4.Controls.Add(this.btnItemReturn);
            this.groupBox4.Location = new System.Drawing.Point(33, 479);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1207, 87);
            this.groupBox4.TabIndex = 145;
            this.groupBox4.TabStop = false;
            // 
            // btnrerurnExit
            // 
            this.btnrerurnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnrerurnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnrerurnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnrerurnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrerurnExit.Location = new System.Drawing.Point(1050, 34);
            this.btnrerurnExit.Name = "btnrerurnExit";
            this.btnrerurnExit.Size = new System.Drawing.Size(76, 39);
            this.btnrerurnExit.TabIndex = 15;
            this.btnrerurnExit.Text = "Exit";
            this.btnrerurnExit.UseVisualStyleBackColor = false;
            this.btnrerurnExit.Click += new System.EventHandler(this.btnrerurnExit_Click);
            // 
            // btnItemReturn
            // 
            this.btnItemReturn.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnItemReturn.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnItemReturn.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItemReturn.Location = new System.Drawing.Point(863, 34);
            this.btnItemReturn.Name = "btnItemReturn";
            this.btnItemReturn.Size = new System.Drawing.Size(118, 39);
            this.btnItemReturn.TabIndex = 14;
            this.btnItemReturn.Text = "Return Item";
            this.btnItemReturn.UseVisualStyleBackColor = false;
            this.btnItemReturn.Click += new System.EventHandler(this.btnItemReturn_Click);
            // 
            // lblItemcode
            // 
            this.lblItemcode.AutoSize = true;
            this.lblItemcode.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemcode.ForeColor = System.Drawing.Color.Black;
            this.lblItemcode.Location = new System.Drawing.Point(76, 204);
            this.lblItemcode.Name = "lblItemcode";
            this.lblItemcode.Size = new System.Drawing.Size(109, 23);
            this.lblItemcode.TabIndex = 128;
            this.lblItemcode.Text = "Item Code* :";
            // 
            // dtpReturndate
            // 
            this.dtpReturndate.Enabled = false;
            this.dtpReturndate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpReturndate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpReturndate.Location = new System.Drawing.Point(1107, 16);
            this.dtpReturndate.Name = "dtpReturndate";
            this.dtpReturndate.Size = new System.Drawing.Size(121, 26);
            this.dtpReturndate.TabIndex = 163;
            // 
            // txtReciepttype
            // 
            this.txtReciepttype.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReciepttype.Location = new System.Drawing.Point(196, 65);
            this.txtReciepttype.Name = "txtReciepttype";
            this.txtReciepttype.ReadOnly = true;
            this.txtReciepttype.Size = new System.Drawing.Size(271, 26);
            this.txtReciepttype.TabIndex = 146;
            this.txtReciepttype.Text = "Project Issued Return";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(64, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 23);
            this.label1.TabIndex = 127;
            this.label1.Text = "Return Type :";
            // 
            // lblReturnvalue
            // 
            this.lblReturnvalue.AutoSize = true;
            this.lblReturnvalue.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturnvalue.ForeColor = System.Drawing.Color.Black;
            this.lblReturnvalue.Location = new System.Drawing.Point(817, 204);
            this.lblReturnvalue.Name = "lblReturnvalue";
            this.lblReturnvalue.Size = new System.Drawing.Size(20, 23);
            this.lblReturnvalue.TabIndex = 144;
            this.lblReturnvalue.Text = "0";
            // 
            // lblItemdescription
            // 
            this.lblItemdescription.AutoSize = true;
            this.lblItemdescription.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemdescription.ForeColor = System.Drawing.Color.Black;
            this.lblItemdescription.Location = new System.Drawing.Point(34, 254);
            this.lblItemdescription.Name = "lblItemdescription";
            this.lblItemdescription.Size = new System.Drawing.Size(151, 23);
            this.lblItemdescription.TabIndex = 134;
            this.lblItemdescription.Text = "Item Description :";
            // 
            // lblCustomer
            // 
            this.lblCustomer.AutoSize = true;
            this.lblCustomer.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomer.ForeColor = System.Drawing.Color.Black;
            this.lblCustomer.Location = new System.Drawing.Point(57, 161);
            this.lblCustomer.Name = "lblCustomer";
            this.lblCustomer.Size = new System.Drawing.Size(127, 23);
            this.lblCustomer.TabIndex = 143;
            this.lblCustomer.Text = "Project Name :";
            // 
            // txtreturnProjdesc
            // 
            this.txtreturnProjdesc.AutoSize = true;
            this.txtreturnProjdesc.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtreturnProjdesc.ForeColor = System.Drawing.Color.Black;
            this.txtreturnProjdesc.Location = new System.Drawing.Point(191, 161);
            this.txtreturnProjdesc.Name = "txtreturnProjdesc";
            this.txtreturnProjdesc.Size = new System.Drawing.Size(19, 23);
            this.txtreturnProjdesc.TabIndex = 135;
            this.txtreturnProjdesc.Text = "*";
            // 
            // txtreturnItemDescription
            // 
            this.txtreturnItemDescription.AutoSize = true;
            this.txtreturnItemDescription.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtreturnItemDescription.ForeColor = System.Drawing.Color.Red;
            this.txtreturnItemDescription.Location = new System.Drawing.Point(191, 254);
            this.txtreturnItemDescription.Name = "txtreturnItemDescription";
            this.txtreturnItemDescription.Size = new System.Drawing.Size(19, 23);
            this.txtreturnItemDescription.TabIndex = 135;
            this.txtreturnItemDescription.Text = "*";
            // 
            // lblNoofreturnitems
            // 
            this.lblNoofreturnitems.AutoSize = true;
            this.lblNoofreturnitems.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoofreturnitems.ForeColor = System.Drawing.Color.Red;
            this.lblNoofreturnitems.Location = new System.Drawing.Point(545, 203);
            this.lblNoofreturnitems.Name = "lblNoofreturnitems";
            this.lblNoofreturnitems.Size = new System.Drawing.Size(277, 23);
            this.lblNoofreturnitems.TabIndex = 135;
            this.lblNoofreturnitems.Text = "Number of Items to be Returned :";
            // 
            // txtjobprojectcode
            // 
            this.txtjobprojectcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtjobprojectcode.Location = new System.Drawing.Point(196, 121);
            this.txtjobprojectcode.Name = "txtjobprojectcode";
            this.txtjobprojectcode.ReadOnly = true;
            this.txtjobprojectcode.Size = new System.Drawing.Size(270, 26);
            this.txtjobprojectcode.TabIndex = 171;
            this.txtjobprojectcode.TextChanged += new System.EventHandler(this.txtjobprojectcode_TextChanged);
            // 
            // lbljobprojectcode
            // 
            this.lbljobprojectcode.AutoSize = true;
            this.lbljobprojectcode.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbljobprojectcode.ForeColor = System.Drawing.Color.Black;
            this.lbljobprojectcode.Location = new System.Drawing.Point(64, 121);
            this.lbljobprojectcode.Name = "lbljobprojectcode";
            this.lbljobprojectcode.Size = new System.Drawing.Size(120, 23);
            this.lbljobprojectcode.TabIndex = 170;
            this.lbljobprojectcode.Text = "Project Code :";
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantity.ForeColor = System.Drawing.Color.Black;
            this.lblQuantity.Location = new System.Drawing.Point(501, 309);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(97, 23);
            this.lblQuantity.TabIndex = 136;
            this.lblQuantity.Text = "Quantity* :";
            // 
            // cmbjobwonumber
            // 
            this.cmbjobwonumber.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbjobwonumber.DropDownHeight = 130;
            this.cmbjobwonumber.DropDownWidth = 181;
            this.cmbjobwonumber.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbjobwonumber.FormattingEnabled = true;
            this.cmbjobwonumber.IntegralHeight = false;
            this.cmbjobwonumber.Items.AddRange(new object[] {
            "None"});
            this.cmbjobwonumber.Location = new System.Drawing.Point(196, 19);
            this.cmbjobwonumber.Name = "cmbjobwonumber";
            this.cmbjobwonumber.Size = new System.Drawing.Size(271, 26);
            this.cmbjobwonumber.TabIndex = 166;
            this.cmbjobwonumber.SelectedIndexChanged += new System.EventHandler(this.cmbjobwonumber_SelectedIndexChanged);
            // 
            // txtrecieveQuantity
            // 
            this.txtrecieveQuantity.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtrecieveQuantity.Location = new System.Drawing.Point(604, 306);
            this.txtrecieveQuantity.Name = "txtrecieveQuantity";
            this.txtrecieveQuantity.Size = new System.Drawing.Size(186, 26);
            this.txtrecieveQuantity.TabIndex = 137;
            this.txtrecieveQuantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtrecieveQuantity_KeyPress);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Silver;
            this.tabPage3.Controls.Add(this.pnitemadd);
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Controls.Add(this.dtpsadate);
            this.tabPage3.Controls.Add(this.groupBox1);
            this.tabPage3.Controls.Add(this.dgStockAdjust);
            this.tabPage3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            this.tabPage3.Location = new System.Drawing.Point(4, 28);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1290, 638);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Stock Adjustment";
            // 
            // pnitemadd
            // 
            this.pnitemadd.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnitemadd.Controls.Add(this.chkItemDesc);
            this.pnitemadd.Controls.Add(this.chkItemCode);
            this.pnitemadd.Controls.Add(this.txtItemDescription);
            this.pnitemadd.Controls.Add(this.label4);
            this.pnitemadd.Controls.Add(this.chklbItemList);
            this.pnitemadd.Location = new System.Drawing.Point(6, 6);
            this.pnitemadd.Name = "pnitemadd";
            this.pnitemadd.Size = new System.Drawing.Size(352, 626);
            this.pnitemadd.TabIndex = 165;
            // 
            // chkItemDesc
            // 
            this.chkItemDesc.AutoSize = true;
            this.chkItemDesc.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemDesc.ForeColor = System.Drawing.Color.Black;
            this.chkItemDesc.Location = new System.Drawing.Point(212, 9);
            this.chkItemDesc.Name = "chkItemDesc";
            this.chkItemDesc.Size = new System.Drawing.Size(140, 23);
            this.chkItemDesc.TabIndex = 211;
            this.chkItemDesc.Text = "Item Description";
            this.chkItemDesc.UseVisualStyleBackColor = true;
            this.chkItemDesc.CheckedChanged += new System.EventHandler(this.chkItemDesc_CheckedChanged);
            // 
            // chkItemCode
            // 
            this.chkItemCode.AutoSize = true;
            this.chkItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemCode.ForeColor = System.Drawing.Color.Black;
            this.chkItemCode.Location = new System.Drawing.Point(120, 8);
            this.chkItemCode.Name = "chkItemCode";
            this.chkItemCode.Size = new System.Drawing.Size(97, 23);
            this.chkItemCode.TabIndex = 210;
            this.chkItemCode.Text = "Item Code";
            this.chkItemCode.UseVisualStyleBackColor = true;
            this.chkItemCode.CheckedChanged += new System.EventHandler(this.chkItemCode_CheckedChanged);
            // 
            // txtItemDescription
            // 
            this.txtItemDescription.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemDescription.Location = new System.Drawing.Point(3, 37);
            this.txtItemDescription.Multiline = true;
            this.txtItemDescription.Name = "txtItemDescription";
            this.txtItemDescription.Size = new System.Drawing.Size(342, 55);
            this.txtItemDescription.TabIndex = 100;
            this.txtItemDescription.Enter += new System.EventHandler(this.txtItemDescription_Enter);
            this.txtItemDescription.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtItemDescription_KeyPress);
            this.txtItemDescription.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemDescription_KeyUp);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(3, 10);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 19);
            this.label4.TabIndex = 105;
            this.label4.Text = "Search Item by";
            // 
            // chklbItemList
            // 
            this.chklbItemList.CheckOnClick = true;
            this.chklbItemList.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chklbItemList.FormattingEnabled = true;
            this.chklbItemList.Location = new System.Drawing.Point(3, 101);
            this.chklbItemList.Name = "chklbItemList";
            this.chklbItemList.Size = new System.Drawing.Size(342, 508);
            this.chklbItemList.TabIndex = 101;
            this.chklbItemList.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.chklbItemList_ItemCheck);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(995, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(152, 19);
            this.label3.TabIndex = 164;
            this.label3.Text = "Stock Adjusted Date:";
            // 
            // dtpsadate
            // 
            this.dtpsadate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpsadate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpsadate.Location = new System.Drawing.Point(1150, 18);
            this.dtpsadate.Name = "dtpsadate";
            this.dtpsadate.Size = new System.Drawing.Size(110, 27);
            this.dtpsadate.TabIndex = 163;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnUpdateStock);
            this.groupBox1.Controls.Add(this.btnstockexit);
            this.groupBox1.Location = new System.Drawing.Point(365, 561);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(919, 71);
            this.groupBox1.TabIndex = 97;
            this.groupBox1.TabStop = false;
            // 
            // btnUpdateStock
            // 
            this.btnUpdateStock.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnUpdateStock.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnUpdateStock.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateStock.Location = new System.Drawing.Point(628, 22);
            this.btnUpdateStock.Name = "btnUpdateStock";
            this.btnUpdateStock.Size = new System.Drawing.Size(127, 39);
            this.btnUpdateStock.TabIndex = 97;
            this.btnUpdateStock.Text = "Update Stock";
            this.btnUpdateStock.UseVisualStyleBackColor = false;
            this.btnUpdateStock.Click += new System.EventHandler(this.btnUpdateStock_Click);
            // 
            // btnstockexit
            // 
            this.btnstockexit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnstockexit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnstockexit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnstockexit.Location = new System.Drawing.Point(785, 22);
            this.btnstockexit.Name = "btnstockexit";
            this.btnstockexit.Size = new System.Drawing.Size(90, 39);
            this.btnstockexit.TabIndex = 96;
            this.btnstockexit.Text = "Exit";
            this.btnstockexit.UseVisualStyleBackColor = false;
            this.btnstockexit.Click += new System.EventHandler(this.btnstockexit_Click);
            // 
            // dgStockAdjust
            // 
            this.dgStockAdjust.AllowUserToAddRows = false;
            this.dgStockAdjust.AllowUserToDeleteRows = false;
            this.dgStockAdjust.AllowUserToResizeRows = false;
            this.dgStockAdjust.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgStockAdjust.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgStockAdjust.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.Desktop;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgStockAdjust.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgStockAdjust.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgStockAdjust.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ItemCode,
            this.ItemDescription,
            this.unitprice1,
            this.Unit,
            this.AvailableQty,
            this.ActualQty,
            this.AdjustedQty});
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgStockAdjust.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgStockAdjust.EnableHeadersVisualStyles = false;
            this.dgStockAdjust.Location = new System.Drawing.Point(364, 67);
            this.dgStockAdjust.MultiSelect = false;
            this.dgStockAdjust.Name = "dgStockAdjust";
            this.dgStockAdjust.RowHeadersVisible = false;
            this.dgStockAdjust.Size = new System.Drawing.Size(920, 488);
            this.dgStockAdjust.TabIndex = 94;
            this.dgStockAdjust.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgStockAdjust_CellBeginEdit);
            this.dgStockAdjust.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgStockAdjust_CellEndEdit);
            this.dgStockAdjust.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgStockAdjust_EditingControlShowing);
            // 
            // ItemCode
            // 
            this.ItemCode.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.ItemCode.DataPropertyName = "ItemCode";
            this.ItemCode.HeaderText = "Item Code";
            this.ItemCode.Name = "ItemCode";
            this.ItemCode.ReadOnly = true;
            this.ItemCode.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemCode.Width = 77;
            // 
            // ItemDescription
            // 
            this.ItemDescription.DataPropertyName = "ItemDescription";
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ItemDescription.DefaultCellStyle = dataGridViewCellStyle2;
            this.ItemDescription.HeaderText = "Item Desc";
            this.ItemDescription.Name = "ItemDescription";
            this.ItemDescription.ReadOnly = true;
            this.ItemDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // unitprice1
            // 
            this.unitprice1.DataPropertyName = "UnitCost";
            this.unitprice1.HeaderText = "UnitPrice";
            this.unitprice1.Name = "unitprice1";
            this.unitprice1.ReadOnly = true;
            this.unitprice1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // Unit
            // 
            this.Unit.DataPropertyName = "Units";
            this.Unit.HeaderText = "Unit";
            this.Unit.Name = "Unit";
            this.Unit.ReadOnly = true;
            this.Unit.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // AvailableQty
            // 
            this.AvailableQty.DataPropertyName = "AvailableQty";
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.AvailableQty.DefaultCellStyle = dataGridViewCellStyle3;
            this.AvailableQty.HeaderText = "Ava Qty";
            this.AvailableQty.Name = "AvailableQty";
            this.AvailableQty.ReadOnly = true;
            this.AvailableQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ActualQty
            // 
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ActualQty.DefaultCellStyle = dataGridViewCellStyle4;
            this.ActualQty.HeaderText = "Actual Count Qty";
            this.ActualQty.Name = "ActualQty";
            this.ActualQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // AdjustedQty
            // 
            dataGridViewCellStyle5.Format = "N2";
            dataGridViewCellStyle5.NullValue = null;
            this.AdjustedQty.DefaultCellStyle = dataGridViewCellStyle5;
            this.AdjustedQty.HeaderText = "Adjusted Qty";
            this.AdjustedQty.Name = "AdjustedQty";
            this.AdjustedQty.ReadOnly = true;
            this.AdjustedQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ItemLocationLabel
            // 
            this.ItemLocationLabel.AutoSize = true;
            this.ItemLocationLabel.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.ItemLocationLabel.Location = new System.Drawing.Point(508, 370);
            this.ItemLocationLabel.Name = "ItemLocationLabel";
            this.ItemLocationLabel.Size = new System.Drawing.Size(90, 23);
            this.ItemLocationLabel.TabIndex = 192;
            this.ItemLocationLabel.Text = "Location*:";
            this.ItemLocationLabel.Visible = false;
            // 
            // itemLocationQu
            // 
            this.itemLocationQu.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemLocationQu.Location = new System.Drawing.Point(604, 370);
            this.itemLocationQu.Name = "itemLocationQu";
            this.itemLocationQu.Size = new System.Drawing.Size(269, 26);
            this.itemLocationQu.TabIndex = 193;
            this.itemLocationQu.Visible = false;
            // 
            // AdjustStock
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1308, 686);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AdjustStock";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Adjust Stock";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AdjustStock_FormClosing);
            this.Load += new System.EventHandler(this.AdjustStock_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.pnlprojreturn.ResumeLayout(false);
            this.pnlprojreturn.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.pnitemadd.ResumeLayout(false);
            this.pnitemadd.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgStockAdjust)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.CheckBox chknonprojmaterial;
        private System.Windows.Forms.TextBox txtjobprojectcode;
        private System.Windows.Forms.Label lbljobprojectcode;
        private System.Windows.Forms.ComboBox cmbjobwonumber;
        private System.Windows.Forms.CheckBox chkProjectIssuedReturn;
        private System.Windows.Forms.CheckBox chkJobReturn;
        private System.Windows.Forms.Panel pnlprojreturn;
        private System.Windows.Forms.TextBox txtreturnedby;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox cmbreturnItemcode;
        private System.Windows.Forms.Label lblwarningmessage;
        private System.Windows.Forms.Label lblItemcode;
        private System.Windows.Forms.DateTimePicker dtpReturndate;
        private System.Windows.Forms.TextBox txtReciepttype;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblReturnvalue;
        private System.Windows.Forms.Label lblItemdescription;
        private System.Windows.Forms.Label lblCustomer;
        private System.Windows.Forms.Label lblNoofreturnitems;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.TextBox txtrecieveQuantity;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnrerurnExit;
        private System.Windows.Forms.Button btnItemReturn;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtpsadate;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnUpdateStock;
        private System.Windows.Forms.Button btnstockexit;
        private System.Windows.Forms.DataGridView dgStockAdjust;
        private System.Windows.Forms.Panel pnitemadd;
        private System.Windows.Forms.TextBox txtItemDescription;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckedListBox chklbItemList;
        private System.Windows.Forms.Label txtreturnProjdesc;
        private System.Windows.Forms.Label txtreturnItemDescription;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblProjectStatus;
        private System.Windows.Forms.CheckBox chkItemDesc;
        private System.Windows.Forms.CheckBox chkItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitprice1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Unit;
        private System.Windows.Forms.DataGridViewTextBoxColumn AvailableQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn ActualQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn AdjustedQty;
        private System.Windows.Forms.Label lblWorkOrderNo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label InevtoryReturnType;
        private System.Windows.Forms.ComboBox comboBoxReturnType;
        private System.Windows.Forms.TextBox itemLocationQu;
        private System.Windows.Forms.Label ItemLocationLabel;
    }
}