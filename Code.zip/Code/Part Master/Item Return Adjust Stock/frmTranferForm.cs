﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Erp_Project_With_Buttons.Item_Return_Adjust_Stock
{
    public partial class frmTranferForm : Form
    {
        public frmTranferForm()
        {
            InitializeComponent();
        }
        SqlConnection SQLCon;
        DataAccessLayer DAL = new DataAccessLayer();
        Global GLobalClass = new Global();
        frmForm2 form = new frmForm2();
        Login.frmLoginForm login = new Login.frmLoginForm();
        DataTable dtItemList = new DataTable();
        DataTable dtProjectList = new DataTable();
        DataTable dtWIPProjectlist = new DataTable();
        DataTable dtProjectTransferlist = new DataTable();
        DataView dvProjectName = new DataView();
        DataView dvProjectBOMList = new DataView();
        DataTable dtDGDatatable = new DataTable();
        DataTable dtIssuedCost = new DataTable();

        public int sTransferform = 0;

        private static string sProjectCode;
        public string fnProjectcode
        {
            get
            {
                return sProjectCode;
            }
            set
            {
                sProjectCode = value;
            }
        }

        private void frmTranferForm_Load(object sender, EventArgs e)
        {
            dtWIPProjectlist = DAL.fnWIPProjectList(null).Tables[0];

            foreach (DataRow DR in dtWIPProjectlist.Rows)
            {
                if (!cmbProjectCode.Items.Contains(DR["ProjectCode"].ToString()))
                    cmbProjectCode.Items.Add(DR["ProjectCode"].ToString());
            }

        }

        private void cmbProjectCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            dvProjectBOMList = new DataView(dtWIPProjectlist);
            dvProjectBOMList.RowFilter = "ProjectCode='" + cmbProjectCode.Text + "'";
            if (dvProjectBOMList.ToTable().Rows.Count > 0)
            {
                txtProjectName.Text = dvProjectBOMList.ToTable().Rows[0]["ProjectDescription"].ToString();
                txtcustomer.Text = dvProjectBOMList.ToTable().Rows[0]["Customer"].ToString();
                lblProjectStaus.Text = dvProjectBOMList.ToTable().Rows[0]["Status"].ToString();
            }

            cmbCopyProjCode.Items.Clear();
            cmbCopyProjCode.Text = "";
            txtProjDesc.ResetText();
            txtcopycustomer.ResetText();
            lblProjectStausNew.ResetText();
            dtProjectTransferlist = DAL.fnProjectTransferList(cmbProjectCode.Text).Tables[0];
            foreach (DataRow DR in dtProjectTransferlist.Rows)
            {
                if (!cmbCopyProjCode.Items.Contains(DR["ProjectCode"].ToString()))
                    cmbCopyProjCode.Items.Add(DR["ProjectCode"].ToString());
            }
            if (dtProjectTransferlist.Rows.Count > 0)
            {
                cmbCopyProjCode.SelectedIndex = 0;
                cmbCopyProjCode.Enabled = false;
                btnTransfer.Enabled = true;
                lblWarning.Visible = false;
            }
            else
            {
                lblWarning.Visible = true;
                btnTransfer.Enabled = false;
            }
        }

        private void cmbCopyProjCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbCopyProjCode.Text != cmbProjectCode.Text)
            {
                dvProjectBOMList = new DataView(dtWIPProjectlist);
                dvProjectBOMList.RowFilter = "ProjectCode='" + cmbCopyProjCode.Text + "'";
                if (dvProjectBOMList.ToTable().Rows.Count > 0)
                {
                    txtProjDesc.Text = dvProjectBOMList.ToTable().Rows[0]["ProjectDescription"].ToString();
                    txtcopycustomer.Text = dvProjectBOMList.ToTable().Rows[0]["Customer"].ToString();
                    lblProjectStausNew.Text = dvProjectBOMList.ToTable().Rows[0]["Status"].ToString();
                }
            }
        }

        DataTable dtTransferProjectNo = new DataTable();
        DataTable dtProjectTransferCheck = new DataTable();
        private void btnTransfer_Click(object sender, EventArgs e)
        {
            string TransactionNo = "";
            dtTransferProjectNo = DAL.fnTransferProjectNo(0, "").Tables[0];
            dtProjectTransferCheck = DAL.fnTransferProjectNo(1, cmbCopyProjCode.Text).Tables[0];

            if (dtProjectTransferCheck.Rows.Count ==0)
            {
                if (dtTransferProjectNo.Rows.Count > 0)
                {
                    TransactionNo = dtTransferProjectNo.Rows[0]["TransactionNo"].ToString();
                    TransactionNo = TransactionNo.Substring(02, 08);
                    int iLastPONo = Convert.ToInt32(TransactionNo);
                    iLastPONo++;
                    TransactionNo = "TP" + iLastPONo;
                    fnCost();

                    //cmbProjectCode.Text = "CIP-2021-11-CIN-112948";
                    //cmbCopyProjCode.Items.Add("STO-2016-05-OTS-00071-01");
                    //cmbCopyProjCode.SelectedIndex = 0;
                    for (uint i = 0; i < 15; i++)
                    {
                        GLobalClass.iSuccess = DAL.fnAddProjectTransfer(i, cmbProjectCode.Text, cmbCopyProjCode.Text, login.GetUserDetails[2], TransactionNo, TotalSum.ToString(), dtpReturndate.Text);
                    }

                    GLobalClass.iStatus = DAL.fnAddProjectStatus(0, cmbProjectCode.Text, txtProjectName.Text, login.GetUserDetails[2], "Transferred", dtpReturndate.Text);

                    MessageBox.Show("Project transferred succefully", "Success", 0, MessageBoxIcon.Information);
                    btnTransfer.Enabled = false;
                }
            }
            else
            {
                MessageBox.Show("Selected project has Project BOM, Project transfer not accepeted \n\n Delete the project BOM to transfer the project", "Error", 0, MessageBoxIcon.Error);
            }
        }


        DataTable dtJobIssued = new DataTable();
        DataTable dtJobIssuedItemReturn = new DataTable();
        DataTable dtGinJobCost = new DataTable();
        DataTable dtProjectItemReturn = new DataTable();
        DataTable DtProjectIssued = new DataTable();

        double TotalSum;
        object sumProjectIndentCost;
        object sumProjectItemReturnCost;
        object sumProjectJobCost;
        object sumProjectJobReturnCost;

        private void fnCost()
        {
            TotalSum = 0;
            double dSumGinCost = 0;
            dtpReturndate.Format = DateTimePickerFormat.Custom;
            dtpReturndate.CustomFormat = "yyyy-MM-dd";
            DtProjectIssued = DAL.fnProjectIssued(0,cmbProjectCode.Text, "2010-01-01", dtpReturndate.Text).Tables[0];
            dtJobIssued = DAL.fnProjectIssued(1,cmbProjectCode.Text, "2010-01-01", dtpReturndate.Text).Tables[0];
            dtProjectItemReturn = DAL.fnProjectItemReturn(cmbProjectCode.Text, "2010-01-01", dtpReturndate.Text, "Project").Tables[0];
            dtJobIssuedItemReturn = DAL.fnProjectItemReturn(cmbProjectCode.Text, "2010-01-01", dtpReturndate.Text, "Job").Tables[0];
            dtGinJobCost = DAL.GINJobReciept(cmbProjectCode.Text, "2010-01-01", dtpReturndate.Text).Tables[0];
            dtpReturndate.Format = DateTimePickerFormat.Custom;
            dtpReturndate.CustomFormat = "dd-MM-yyyy";

            if (DtProjectIssued.Rows.Count > 0)
            {
                sumProjectIndentCost = DtProjectIssued.Compute("Sum(Amount)", "");
            }
            else
            {
                sumProjectIndentCost = 0;
            }
            if (dtProjectItemReturn.Rows.Count > 0)
            {
                sumProjectItemReturnCost = dtProjectItemReturn.Compute("Sum(Amount)", "");
            }
            else
            {
                sumProjectItemReturnCost = 0;
            }
            if (dtJobIssued.Rows.Count > 0)
            {
                sumProjectJobCost = dtJobIssued.Compute("Sum(Amount)", "");
            }
            else
            {
                sumProjectJobCost = 0;
            }
            if (dtJobIssuedItemReturn.Rows.Count > 0)
            {
                sumProjectJobReturnCost = dtJobIssuedItemReturn.Compute("Sum(Amount)", "");
            }
            else
            {
                sumProjectJobReturnCost = 0;
            }
            if (dtGinJobCost.Rows.Count > 0)
            {
                dSumGinCost = Convert.ToDouble(dtGinJobCost.Compute("Sum(Amount)", ""));
            }
            else
            {
                dSumGinCost = 0;
            }

            TotalSum = (Convert.ToDouble(sumProjectIndentCost) + Convert.ToDouble(sumProjectJobCost)) - (Convert.ToDouble(sumProjectItemReturnCost) + dSumGinCost + Convert.ToDouble(sumProjectJobReturnCost));
        }


        private void btnProjectView_Click(object sender, EventArgs e)
        {
            sTransferform = 1;
            Indent.frmProjectselect projectsearch = new Indent.frmProjectselect();
            projectsearch.fnTransferform = sTransferform.ToString();
            projectsearch.ShowDialog();
            if (fnProjectcode != null)
            {
                cmbProjectCode.Text = sProjectCode;
            }
        }


        private void frmTranferForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            form.Show();
        }

        private void lblProjectName_Click(object sender, EventArgs e)
        {

        }

        private void txtProjectName_Click(object sender, EventArgs e)
        {

        }

        private void lblProjectCode_Click(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            form.Show();
        }
    }
}
