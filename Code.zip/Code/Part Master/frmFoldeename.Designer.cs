﻿namespace Erp_Project_With_Buttons.Part_Master
{
    partial class frmFoldeename
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmFoldeename));
            this.lblsubfoldername = new System.Windows.Forms.Label();
            this.lblmainfoldername = new System.Windows.Forms.Label();
            this.txtproductcode = new System.Windows.Forms.TextBox();
            this.btnfoldernameok = new System.Windows.Forms.Button();
            this.lbladdressbar = new System.Windows.Forms.Label();
            this.lblAddres = new System.Windows.Forms.Label();
            this.btncancel = new System.Windows.Forms.Button();
            this.lblwarning = new System.Windows.Forms.Label();
            this.txtproductname = new System.Windows.Forms.TextBox();
            this.chkMainfolder = new System.Windows.Forms.CheckBox();
            this.chkProduct = new System.Windows.Forms.CheckBox();
            this.chkKanban = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // lblsubfoldername
            // 
            this.lblsubfoldername.AutoSize = true;
            this.lblsubfoldername.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsubfoldername.ForeColor = System.Drawing.Color.BurlyWood;
            this.lblsubfoldername.Location = new System.Drawing.Point(283, 13);
            this.lblsubfoldername.Name = "lblsubfoldername";
            this.lblsubfoldername.Size = new System.Drawing.Size(185, 95);
            this.lblsubfoldername.TabIndex = 0;
            this.lblsubfoldername.Text = "PRODUCT NAME\r\nEx: Load Frame\r\nor\r\nMAIN PRODUCT SUB TYPE\r\nEx: 100 kN Load Frame\r\n";
            this.lblsubfoldername.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblmainfoldername
            // 
            this.lblmainfoldername.AutoSize = true;
            this.lblmainfoldername.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmainfoldername.ForeColor = System.Drawing.Color.BurlyWood;
            this.lblmainfoldername.Location = new System.Drawing.Point(38, 64);
            this.lblmainfoldername.Name = "lblmainfoldername";
            this.lblmainfoldername.Size = new System.Drawing.Size(129, 38);
            this.lblmainfoldername.TabIndex = 1;
            this.lblmainfoldername.Text = "PRODUCTCODE\r\nEx: AC-01-0050-01\r\n";
            this.lblmainfoldername.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtproductcode
            // 
            this.txtproductcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtproductcode.Location = new System.Drawing.Point(12, 146);
            this.txtproductcode.Name = "txtproductcode";
            this.txtproductcode.Size = new System.Drawing.Size(256, 26);
            this.txtproductcode.TabIndex = 2;
            // 
            // btnfoldernameok
            // 
            this.btnfoldernameok.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnfoldernameok.Location = new System.Drawing.Point(632, 160);
            this.btnfoldernameok.Name = "btnfoldernameok";
            this.btnfoldernameok.Size = new System.Drawing.Size(75, 33);
            this.btnfoldernameok.TabIndex = 3;
            this.btnfoldernameok.Text = "Add";
            this.btnfoldernameok.UseVisualStyleBackColor = true;
            this.btnfoldernameok.Click += new System.EventHandler(this.btnfoldernameok_Click);
            // 
            // lbladdressbar
            // 
            this.lbladdressbar.AutoSize = true;
            this.lbladdressbar.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbladdressbar.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbladdressbar.Location = new System.Drawing.Point(178, 223);
            this.lbladdressbar.Name = "lbladdressbar";
            this.lbladdressbar.Size = new System.Drawing.Size(13, 19);
            this.lbladdressbar.TabIndex = 4;
            this.lbladdressbar.Text = ":";
            // 
            // lblAddres
            // 
            this.lblAddres.AutoSize = true;
            this.lblAddres.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddres.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblAddres.Location = new System.Drawing.Point(9, 223);
            this.lblAddres.Name = "lblAddres";
            this.lblAddres.Size = new System.Drawing.Size(172, 19);
            this.lblAddres.TabIndex = 5;
            this.lblAddres.Text = "New Item Adding Path :";
            // 
            // btncancel
            // 
            this.btncancel.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncancel.Location = new System.Drawing.Point(735, 160);
            this.btncancel.Name = "btncancel";
            this.btncancel.Size = new System.Drawing.Size(75, 33);
            this.btncancel.TabIndex = 6;
            this.btncancel.Text = "Cancel";
            this.btncancel.UseVisualStyleBackColor = true;
            this.btncancel.Click += new System.EventHandler(this.btncancel_Click);
            // 
            // lblwarning
            // 
            this.lblwarning.AutoSize = true;
            this.lblwarning.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblwarning.ForeColor = System.Drawing.Color.Red;
            this.lblwarning.Location = new System.Drawing.Point(616, 260);
            this.lblwarning.Name = "lblwarning";
            this.lblwarning.Size = new System.Drawing.Size(194, 26);
            this.lblwarning.TabIndex = 7;
            this.lblwarning.Text = "Enter Folder Name !!";
            this.lblwarning.Visible = false;
            // 
            // txtproductname
            // 
            this.txtproductname.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtproductname.Location = new System.Drawing.Point(295, 146);
            this.txtproductname.Multiline = true;
            this.txtproductname.Name = "txtproductname";
            this.txtproductname.Size = new System.Drawing.Size(318, 60);
            this.txtproductname.TabIndex = 8;
            // 
            // chkMainfolder
            // 
            this.chkMainfolder.AutoSize = true;
            this.chkMainfolder.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkMainfolder.ForeColor = System.Drawing.Color.BurlyWood;
            this.chkMainfolder.Location = new System.Drawing.Point(327, 117);
            this.chkMainfolder.Name = "chkMainfolder";
            this.chkMainfolder.Size = new System.Drawing.Size(106, 23);
            this.chkMainfolder.TabIndex = 9;
            this.chkMainfolder.Text = "MainFolder";
            this.chkMainfolder.UseVisualStyleBackColor = true;
            this.chkMainfolder.CheckedChanged += new System.EventHandler(this.chkMainfolder_CheckedChanged);
            // 
            // chkProduct
            // 
            this.chkProduct.AutoSize = true;
            this.chkProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkProduct.ForeColor = System.Drawing.Color.BurlyWood;
            this.chkProduct.Location = new System.Drawing.Point(56, 117);
            this.chkProduct.Name = "chkProduct";
            this.chkProduct.Size = new System.Drawing.Size(83, 23);
            this.chkProduct.TabIndex = 10;
            this.chkProduct.Text = "Product";
            this.chkProduct.UseVisualStyleBackColor = true;
            this.chkProduct.CheckedChanged += new System.EventHandler(this.chkProduct_CheckedChanged);
            // 
            // chkKanban
            // 
            this.chkKanban.AutoSize = true;
            this.chkKanban.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkKanban.ForeColor = System.Drawing.Color.BurlyWood;
            this.chkKanban.Location = new System.Drawing.Point(504, 117);
            this.chkKanban.Name = "chkKanban";
            this.chkKanban.Size = new System.Drawing.Size(151, 23);
            this.chkKanban.TabIndex = 11;
            this.chkKanban.Text = "KAN BAN Product";
            this.chkKanban.UseVisualStyleBackColor = true;
            this.chkKanban.CheckedChanged += new System.EventHandler(this.chkKanban_CheckedChanged);
            // 
            // frmFoldeename
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.ClientSize = new System.Drawing.Size(815, 302);
            this.Controls.Add(this.chkKanban);
            this.Controls.Add(this.chkProduct);
            this.Controls.Add(this.chkMainfolder);
            this.Controls.Add(this.txtproductname);
            this.Controls.Add(this.lblwarning);
            this.Controls.Add(this.btncancel);
            this.Controls.Add(this.lblAddres);
            this.Controls.Add(this.lbladdressbar);
            this.Controls.Add(this.btnfoldernameok);
            this.Controls.Add(this.txtproductcode);
            this.Controls.Add(this.lblmainfoldername);
            this.Controls.Add(this.lblsubfoldername);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmFoldeename";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BIM v1.0004";
            this.Load += new System.EventHandler(this.frmFoldeename_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblsubfoldername;
        private System.Windows.Forms.Label lblmainfoldername;
        private System.Windows.Forms.TextBox txtproductcode;
        private System.Windows.Forms.Button btnfoldernameok;
        private System.Windows.Forms.Label lbladdressbar;
        private System.Windows.Forms.Label lblAddres;
        private System.Windows.Forms.Button btncancel;
        private System.Windows.Forms.Label lblwarning;
        private System.Windows.Forms.TextBox txtproductname;
        private System.Windows.Forms.CheckBox chkMainfolder;
        private System.Windows.Forms.CheckBox chkProduct;
        private System.Windows.Forms.CheckBox chkKanban;
    }
}