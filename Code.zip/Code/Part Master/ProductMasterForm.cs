﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Globalization;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Data.OleDb;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Diagnostics;
namespace Erp_Project_With_Buttons.Part_Master
{
    public partial class frmProductMasterForm : Form
    {
        #region Intialization of Local Datatables, Variables Daclaration

        DataAccessLayer DAL = new DataAccessLayer();
        Global GLobalClass = new Global();
        frmRename Rename = new frmRename();
        frmForm2 form = new frmForm2();
        frmFoldeename FolderName = new frmFoldeename();
        frmAdduser AddUser = new frmAdduser();
        Login.frmLoginForm LoginForm = new Login.frmLoginForm();
        DataTable dtItemList = new DataTable();
        DataTable dtTableFilter = new DataTable();
        DataTable dtTreeFromTable = new DataTable();
        DataTable dtParentAndNodeID = new DataTable();
        DataView dvItemList = new DataView();
        TreeNode tnCurrentParentNode = new TreeNode();
        CultureInfo india = new CultureInfo("hi-IN");
        DataTable dtClone = new DataTable();
        BindingSource bsIteSearch = new BindingSource();
        DataTable dtParentName = new DataTable();
        DataTable dtProductCode = new DataTable();
        DataTable dtPName = new DataTable();
        DataTable dtEXCELData = new DataTable();
        DataTable dtItemSearch = new DataTable();

        private double sQty;
        private int iLastNodeID = 0;
        double oldvalue;
        private const int _blinkFrequency = 250;
        private const int _maxNumberOfBlinks = 1000;
        private int _blinkCount = 0;
        private int iCurrentParentID = 0;
        List<string> lTreeviewList = new List<string>();
        List<string> lExistingTreeviewList = new List<string>();
        List<string> lRowColor = new List<string>();

        private static string sFolderName;
        private static string sProductCode;
        private static string sImageIndex;
        private static string sMainfolder;
        private static string sProduct;
        string sTreeParentName = string.Empty;
        string sTreeChildName = string.Empty;
        string sPasteTreeParentName = string.Empty;
        string sPasteTreeChildName = string.Empty;
        string sNodeName;
        bool bUserstatus = false;
        string sNName = string.Empty;
        DataTable dtProductName = new DataTable();
        DataTable dtProductTreeview = new DataTable();
        public double sTotalAmount;
        int iUpdateParentID;
        DataTable dtUpdateParentID = new DataTable();
        string excelMfgPartNo = string.Empty;
        string excelmake = string.Empty;
        string excelspecification = string.Empty;
        string excelLocation = string.Empty;
        string excelVendor = string.Empty;
        string excelDrawingNo = string.Empty;
        string excelVersion = string.Empty;
        string excelProdType = string.Empty;
        string sDot = ".";
        private List<TreeNode> CurrentNodeMatches = new List<TreeNode>();
        private int LastNodeIndex = 0;
        private string LastSearchText;
        private static string sRenameFolder;

        public string fnRenameFormat
        {
            get
            {
                return sRenameFolder;
            }
            set
            {
                sRenameFolder = value;
            }

        }

        public string fnFolderFormat
        {
            get
            {
                return sFolderName;
            }
            set
            {
                sFolderName = value;
            }

        }
        public string fnProductCode
        {
            get
            {
                return sProductCode;
            }
            set
            {
                sProductCode = value;
            }

        }
        public string fnImageIndex
        {
            get
            {
                return sImageIndex;
            }
            set
            {
                sImageIndex = value;
            }

        }

        public string fnMainFolder
        {
            get
            {
                return sProduct;
            }
            set
            {
                sProduct = value;
            }

        }

        public string fnProduct
        {
            get
            {
                return sMainfolder;
            }
            set
            {
                sMainfolder = value;
            }

        }
        private void RowFilter() //filter the item list by user selected options
        {
            if (dvItemList.Count > 0)
            {
                dgItemList.AutoGenerateColumns = false;
                dgItemList.DataSource = dvItemList.ToTable();
            }
        }

        public frmProductMasterForm()
        {
            InitializeComponent();
        }

        #endregion

        #region Code to Load Local Variables on  Product Master Form Load
        private void frmProductMasterForm_Load(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToBoolean(LoginForm.GetUserDetails[26]) == true)
                {
                    txtProductCost.Visible = true;
                    label2.Visible = true;
                    //    txtSalesCost.Visible = true;
                    // label3.Visible = true;
                }
                else
                {
                    txtProductCost.Visible = false;
                    label2.Visible = false;
                    //  txtSalesCost.Visible = false;
                    // label3.Visible = false;
                }
                chkItemCode.Checked = true;
                lblbomby.Text = LoginForm.GetUserDetails[2];
                chkItemSaerch.Checked = true;
                lbltotalitems.Visible = false;
                lblitemcount.Visible = false;
                gbSearchOptions.Visible = false;
                pnProductcode.Visible = false;

                // dtTreeFromTable = DAL.fnGetProductTreeView().Tables["ProductTreeView"]; //get the tree folders and sub-folders from database 

                dtTreeFromTable = DAL.fnGetSalesMasterProductTreeView(1).Tables[0];
                tvProduct.Nodes.AddRange(GLobalClass.fnTreeFromTable(dtTreeFromTable, "ParentID", "NodeID", "ProductName", "ImageIndex")); // display the folders in the treeview
                tnCurrentParentNode = null;
                tvProduct.Sort();

                //add below code  Convert.ToBoolean(LoginForm.GetUserDetails[26]) == true || Convert.ToBoolean(LoginForm.GetUserDetails[16]) == true || Convert.ToBoolean(LoginForm.GetUserDetails[30]) == true || Convert.ToBoolean(LoginForm.GetUserDetails[29]) == true || Convert.ToBoolean(LoginForm.GetUserDetails[31]) == true || Convert.ToBoolean(LoginForm.GetUserDetails[32]) == true
                
                if (Convert.ToBoolean(LoginForm.GetUserDetails[26]) == true || Convert.ToBoolean(LoginForm.GetUserDetails[16]) == true || Convert.ToBoolean(LoginForm.GetUserDetails[30]) == true || Convert.ToBoolean(LoginForm.GetUserDetails[29]) == true || Convert.ToBoolean(LoginForm.GetUserDetails[31]) == true || Convert.ToBoolean(LoginForm.GetUserDetails[32]) == true)    //  lblPrepareBy.Text.ToLower() == "hebbarrk")
                {
                    dgItemList.Columns[3].Visible = true;
                    dgBOMList.Columns[4].Visible = true;
                    dgBOMList.Columns[5].Visible = true;
                    dgBOMList.Columns[6].Visible = true;
                    pnCost.Visible = true;
                }
                else
                {
                    //shreeshail added true Columns[3]
                    dgItemList.Columns[3].Visible = true;
                    dgBOMList.Columns[4].Visible = false;
                    dgBOMList.Columns[5].Visible = false;
                    dgBOMList.Columns[6].Visible = false;
                    pnCost.Visible = false;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ProductMasterForm_frmProductMasterForm_Load " + ex.Message, "Error", 0, MessageBoxIcon.Error);
            }
        }

        #endregion

        #region Code to Add New Product Folder in  Tree View
        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            iLastNodeID = 0;
            iCurrentParentID = 0;
            DataTable dtProductCheck = new DataTable();
            try
            {
                if (tvProduct.SelectedNode.Nodes.Count > 0 && tvProduct.SelectedNode.StateImageIndex == 0)
                {
                    if (tvProduct.SelectedNode.Name != "All Product")
                    {
                        dtProductCheck = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Parent.Name).Tables["LastNodeId"];
                        dtProductCheck = DAL.fnGetTreeNodeForFolder(tvProduct.SelectedNode.Name, dtProductCheck.Rows[0]["NodeID"].ToString()).Tables[0];
                        dtProductCheck = DAL.fnGetTreeNodeForFolder(null, dtProductCheck.Rows[0]["NodeID"].ToString()).Tables[0];
                        if (dtProductCheck.Rows.Count > 0)
                        {
                            foreach (DataRow dr in dtProductCheck.Rows)
                            {
                                if (dr["ImageIndex"].ToString() == "2" || dr["ImageIndex"].ToString() == "3")
                                {
                                    sProduct = "2";
                                    sMainfolder = string.Empty;
                                    break;
                                }
                            }
                            if (!string.IsNullOrEmpty(sProduct))
                            {
                                foreach (DataRow dr in dtProductCheck.Rows)
                                {
                                    if (dr["ImageIndex"].ToString() == "0")
                                    {
                                        sProduct = string.Empty;
                                        sMainfolder = "0";
                                        break;
                                    }
                                }
                            }
                        }
                        else
                        {
                            sProduct = string.Empty;
                            sMainfolder = string.Empty;
                        }
                    }
                    else
                    {
                        sProduct = string.Empty;
                        sMainfolder = "0";
                    }
                }
                else
                {
                    sProduct = string.Empty;
                    sMainfolder = string.Empty;
                }
                if (tvProduct.SelectedNode != null && tvProduct.SelectedNode.StateImageIndex == 0)
                {
                    FolderName.fnFolderorProduct(sMainfolder, sProduct);
                    fnNameChange();
                }
                else
                {
                    MessageBox.Show("Please Select the folder", "Error", 0, MessageBoxIcon.Error);
                }
            }
            catch
            {
                MessageBox.Show("ProduectMasterForm_btnAddProduct_Click", "Error", 0, MessageBoxIcon.Error);
            }
        }
        #endregion


        #region Code to Disable Edit Names of Treeview Items
        private void tvProduct_AfterLabelEdit(object sender, NodeLabelEditEventArgs e)
        {
            tvProduct.LabelEdit = false;
        }
        #endregion
        DataTable dtReciept = new DataTable();
        DataTable dtVersion = new DataTable();
        string[] sName;
        #region Code to Display The Treeview Items Based on The User
        private void tvProduct_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            try
            {
                txtItemSearch.ResetText();
                txtProductCode.ResetText();
                txtProductName.ResetText();
                comspecification.ResetText();
                txtProductCost.ResetText();
                //txtSalesCost.ResetText();
                sNName = e.Node.Name;
                tvProduct.SelectedNode = e.Node;
                tvProduct.LabelEdit = false;
                if (e.Node.Parent != null && e.Node != null && e.Node.Name != "All Product" && e.Node.StateImageIndex == 1)
                {
                    dgBOMList.DataSource = null;
                    sNName = e.Node.Name;
                    sName = e.Node.Name.Split(')');
                    pnCost.Visible = true;
                    btnAddSubProduct.Enabled = false;
                    if (LoginForm.GetUserDetails[28] == "True")
                    {
                        btnSaveSubProduct.Text = "Update";
                        btnSaveSubProduct.Enabled = true;
                        btnSaveSubProduct.Visible = true;
                    }
                    dtProductName = DAL.fnGetSalesProductTreeDetails(sName[0]).Tables[0];

                    if (dtProductName.Rows.Count > 0)
                    {
                        txtProductName.Text = dtProductName.Rows[0]["Name"].ToString();
                        
                        if (!string.IsNullOrEmpty(dtProductName.Rows[0]["ProductCode"].ToString()))
                        {
                            txtProductCode.Text = dtProductName.Rows[0]["ProductCode"].ToString();
                            txtProductCost.Text = dtProductName.Rows[0]["ProductCost"].ToString();
                            comspecification.Text = dtProductName.Rows[0]["ProductDescription"].ToString();
                            
                        }
                        else
                        {
                            txtProductCode.ResetText();
                            txtProductName.ResetText();
                            txtProductCost.ResetText();
                        }
                        //   dtBOMUsers = DAL.fnBOMUserList(sProductName, dtProductName.Rows[0]["NodeId"].ToString(), lblbomby.Text).Tables[0];
                    }
                    else
                    {
                        txtProductName.Text = tvProduct.SelectedNode.Name;
                    }

                    if (dtProductName.Rows.Count > 0)
                    {
                        lExistingTreeviewList.Clear();
                        dtVersion = DAL.fnFullVersionList(sName[0]).Tables[0];
                        cmbVersion.Items.Clear();
                        foreach (DataRow DR in dtVersion.Rows)
                        {
                            if (!cmbVersion.Items.Contains(DR["Version"].ToString()))
                                cmbVersion.Items.Add(DR["Version"].ToString());
                        }
                        timer1.Interval = _blinkFrequency;
                        lblVersion.Visible = true;
                        cmbVersion.Visible = true;
                        timer1.Start();
                        if (dtVersion.Rows.Count > 0)
                        {
                            cmbVersion.SelectedIndex = 0;
                        }
                        else
                        {
                            cmbVersion.Items.Add("1");
                            cmbVersion.SelectedIndex = 0;
                        }
                        // dtProductName = DAL.fnGetTreeNode(tvProduct.SelectedNode.Name, dtProductName.Rows[0]["NodeID"].ToString()).Tables[0];

                    }
                    else
                    {
                        fnAuthorised(e.Node.Name);
                    }
                }
                else if (e.Node.StateImageIndex == 3 || e.Node.StateImageIndex == 2)
                {
                    if (LoginForm.GetUserDetails[28] == "True")
                    {
                        btnAddSubProduct.Enabled = true;
                    }

                    pnProductcode.Visible = true;
                    gbSearchOptions.Visible = false;
                    pnCost.Visible = false;
                    dgBOMList.DataSource = null;
                    sNName = e.Node.Name;
                    sName = e.Node.Name.Split(')');
                    dtProductName = DAL.fnGetSalesProductTreeDetails(sName[0]).Tables[0];
                    btnSaveSubProduct.Enabled = false;
                    if (dtProductName.Rows.Count > 0)
                    {
                        txtProductName.Text = dtProductName.Rows[0]["Name"].ToString();
                        
                        if (!string.IsNullOrEmpty(dtProductName.Rows[0]["ProductCode"].ToString()))
                        {
                            txtProductCode.Text = dtProductName.Rows[0]["ProductCode"].ToString();                    
                            txtProductCost.Text = dtProductName.Rows[0]["ProductCost"].ToString();
                            comspecification.Text = dtProductName.Rows[0]["ProductDescription"].ToString();
            
                        }
                        
                        

                        else
                        {
                            txtProductCode.ResetText();
                            txtProductName.ResetText();
                            txtProductCost.ResetText();
                        }
                        //   dtBOMUsers = DAL.fnBOMUserList(sProductName, dtProductName.Rows[0]["NodeId"].ToString(), lblbomby.Text).Tables[0];
                    }
                    else
                    {
                        txtProductName.Text = tvProduct.SelectedNode.Name;
                    }
                    //sName = e.Node.Name.Split(')');
                    //timer1.Stop();
                    //lblVersion.ForeColor = Color.Black;
                    //lblVersion.Visible = true;
                    //cmbVersion.Visible = true;
                    //cmbVersion.Items.Clear();
                    //fnAuthorised(e.Node.Name);
                    //lblitemcount.Text = "0";
                    //lblproductcost.Text = "0";
                    //lblLatestCost.Text = "0";
                    //lblLatestCost.Visible = true;
                    //lblpcost.Visible = true;
                    //lblproductcost.Visible = true;
                    //lbllatest.Visible = true;
                    //dgvallBOM.DataSource = null;
                    //btnexcelexport.Visible = true; //change to false
                    //btnAuthorise.Visible = false;
                    //dgBOMList.DataSource = null;
                    //dgvallBOM.DataSource = null;
                }
                else
                {
                    btnAddSubProduct.Enabled = false;
                    timer1.Stop();
                    lblVersion.ForeColor = Color.Black;
                    lblVersion.Visible = false;
                    cmbVersion.Visible = false;
                    cmbVersion.Items.Clear();
                    dgBOMList.DataSource = null;
                    lblitemcount.Text = dgBOMList.Rows.Count.ToString();
                    txtProductCode.ResetText();
                    txtProductName.ResetText();
                    lblproductcost.ResetText();
                    lblLatestCost.ResetText();
                    lExistingTreeviewList.Clear();
                    gbSearchOptions.Visible = false;
                    dgvallBOM.Visible = false;
                    lblFolderMessage.Visible = true;
                    pnProductcode.Visible = false;
                    lbltotalitems.Visible = false;
                    lblitemcount.Visible = false;
                    lblpcost.Visible = false;
                    lbllatest.Visible = false;
                    btnexcelexport.Visible = false;
                    txtItemSearch.Visible = false;
                    lblItemcodeorName.Visible = false;
                    btnAuthorise.Visible = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ProduectMasterForm_tvProduct_NodeMouseClick" + ex.Message, "Error", 0, MessageBoxIcon.Error);
            }
        }
        #endregion

        #region Function to Group Multiple Products By Color
        private void Datagridviewcolor()
        {
            lRowColor.Clear();
            foreach (DataGridViewRow dgr in dgvallBOM.Rows)
            {
                if (!lRowColor.Contains(dgr.Cells["ParentID"].Value.ToString()))
                {
                    lRowColor.Add(dgr.Cells["ParentID"].Value.ToString());
                }
            }

            lRowColor.Sort();

            for (int i = 0; i <= lRowColor.Count - 1; i++)
            {
                if (i % 2 == 0)
                {
                    {
                        foreach (DataGridViewRow dgr in dgvallBOM.Rows)
                        {
                            if (lRowColor[i] == (dgr.Cells["ParentID"].Value.ToString()))
                            {
                                dgr.DefaultCellStyle.BackColor = Color.BurlyWood;

                            }
                        }
                    }
                }
                else
                {
                    if (i < lRowColor.Count)
                    {
                        foreach (DataGridViewRow dgr in dgvallBOM.Rows)
                        {
                            if (lRowColor[i] == (dgr.Cells["ParentID"].Value.ToString()))
                            {
                                dgr.DefaultCellStyle.BackColor = Color.MediumAquamarine;

                            }
                        }
                    }
                }
            }
        }
        #endregion
        DataTable dtChildProdcut = new DataTable();
        #region Code to Delete Product or Folder
        private void tvProduct_KeyUp(object sender, KeyEventArgs e)
        {
            //if (e.KeyCode == Keys.Delete)   //delete selected row from the list
            //{
            //    if (Convert.ToBoolean(LoginForm.GetUserDetails[26]))
            //    {
            //        if (tvProduct.SelectedNode.Name != "All Product" && (tvProduct.SelectedNode.StateImageIndex == 2 || tvProduct.SelectedNode.StateImageIndex == 3))
            //        {
            //            DialogResult DR = MessageBox.Show("Do you want to delete the selected Product ' " + tvProduct.SelectedNode.Name + " ' from ERP", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            //            if (DR == DialogResult.Yes)
            //            {
            //                dtParentAndNodeID = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Parent.Name).Tables["LastNodeId"];
            //                dtParentAndNodeID = DAL.fnGetTreeNode(tvProduct.SelectedNode.Name, dtParentAndNodeID.Rows[0]["NodeID"].ToString()).Tables[0];
            //                if (dtParentAndNodeID.Rows.Count > 0)
            //                    iCurrentParentID = Convert.ToInt32(dtParentAndNodeID.Rows[0]["NodeID"].ToString());
            //                if (iCurrentParentID != 0)
            //                {
            //                    GLobalClass.iSuccess = DAL.fnAddProductName(Global.uDELETE, 0, iCurrentParentID, tvProduct.SelectedNode.Name, "2", "", "", "");
            //                }
            //                if (GLobalClass.iSuccess > 0)
            //                    tvProduct.SelectedNode.Remove();
            //            }
            //        }
            //        else
            //        {
            //            MessageBox.Show("You can't delete this folder ", "Warning", 0, MessageBoxIcon.Warning);
            //        }
            //    }
            //}
            //else if (e.KeyCode == Keys.Enter)
            //{
            //    btnsearchtree_Click(sender, e);
            //}

            //else if (e.Control && e.KeyCode == Keys.X)
            //{
            //    if (Convert.ToBoolean(LoginForm.GetUserDetails[26]))
            //    {
            //        if (tvProduct.SelectedNode.StateImageIndex != 0)
            //        {
            //            sTreeChildName = tvProduct.SelectedNode.Name;
            //            PasteImageIndex = tvProduct.SelectedNode.StateImageIndex;
            //            dtProductName = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Parent.Name).Tables["LastNodeId"];
            //            if (dtProductName.Rows.Count > 0)
            //            {
            //                dtProductName = DAL.fnGetTreeNode(tvProduct.SelectedNode.Name, dtProductName.Rows[0]["NodeID"].ToString()).Tables[0];
            //                NodeID = Convert.ToInt32(dtProductName.Rows[0]["NodeID"].ToString());
            //                tvProduct.SelectedNode.Remove();
            //            }
            //            else
            //            {
            //                NodeID = 0;
            //            }
            //        }
            //        else
            //        {
            //            // MessageBox.Show("Selected a Product to be copied. Dont copy the folder", "Error", 0, MessageBoxIcon.Error);
            //            sTreeChildName = tvProduct.SelectedNode.Name;
            //            PasteImageIndex = tvProduct.SelectedNode.StateImageIndex;
            //            dtProductName = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Name).Tables["LastNodeId"];
            //            dtChildProdcut = DAL.fnGetCopyFolderNodeId(dtProductName.Rows[0]["NodeID"].ToString()).Tables[0];
            //            //  if (dtChildProdcut.Rows.Count > 0)
            //            //   {
            //            // dtProductName = DAL.fnGetTreeNode(tvProduct.SelectedNode.Name, dtProductName.Rows[0]["NodeID"].ToString()).Tables[0];
            //            NodeID = Convert.ToInt32(dtProductName.Rows[0]["NodeID"].ToString());
            //            tvProduct.SelectedNode.Remove();
            //            // }
            //            //  else
            //            //  {

            //            //  }
            //        }
            //    }
            //}
            //else if (e.Control && e.KeyCode == Keys.V)
            //{
            //    if (Convert.ToBoolean(LoginForm.GetUserDetails[26]))
            //    {

            //        //  if (tvProduct.SelectedNode.Name != "All Product" && tvProduct.SelectedNode.StateImageIndex == 0)
            //        {
            //            if (!string.IsNullOrEmpty(sTreeChildName))
            //            {
            //                if ((tvProduct.SelectedNode.Parent) != null)
            //                {
            //                    dtProductName = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Parent.Name).Tables["LastNodeId"];
            //                }
            //                else
            //                {
            //                    dtProductName = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Name).Tables["LastNodeId"];
            //                }
            //                if (dtProductName.Rows.Count > 0)
            //                {
            //                    if ((tvProduct.SelectedNode.Parent) != null)
            //                    {
            //                        dtProductName = DAL.fnGetPasteTreeNode(tvProduct.SelectedNode.Name, dtProductName.Rows[0]["NodeID"].ToString()).Tables[0];
            //                    }
            //                    else
            //                    {
            //                        dtProductName = DAL.fnGetPasteTreeNode(tvProduct.SelectedNode.Name, "0").Tables[0];
            //                    }
            //                    if (dtProductName.Rows.Count > 0)
            //                    {
            //                        PasteParentID = Convert.ToInt32(dtProductName.Rows[0]["NodeID"].ToString());
            //                        GLobalClass.iSuccess = DAL.fnPasteProduct(Global.uUPDATE, PasteParentID, NodeID);
            //                        TreeNode TN = new TreeNode();
            //                        tvProduct.BeginUpdate();
            //                        TN.Name = sTreeChildName;
            //                        TN.Text = sTreeChildName;
            //                        TN.ForeColor = Color.Black;
            //                        TN.StateImageIndex = PasteImageIndex;
            //                        tvProduct.SelectedNode.Nodes.Add(TN);
            //                        tvProduct.EndUpdate();
            //                        sTreeChildName = "";
            //                    }
            //                    else
            //                    {
            //                        MessageBox.Show("Selected a folder to paste", "Error", 0, MessageBoxIcon.Error);
            //                    }
            //                }
            //            }
            //            else
            //            {
            //                MessageBox.Show("Selected a Product to be copied", "Error", 0, MessageBoxIcon.Error);
            //            }
            //        }
            //    }
            //}
        }

        int NodeID;
        int PasteParentID;
        int PasteImageIndex;
        #endregion

        #region Code to Exit the Product Master Form
        private void btnExit_Click(object sender, EventArgs e)
        {
           // if (GLobalClass.fnMessageResult() == Global.sCLOSE_MESSAGE_RESULT_YES)
            {
                this.Hide();
                form.Show();
            }
        }

        private void frmProductMasterForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            //if (GLobalClass.fnMessageResult() == Global.sCLOSE_MESSAGE_RESULT_YES)
            //{
                this.Hide();
                form.Show();
            //}
            //else
            //{
            //    e.Cancel = true;
            //}
        }
        #endregion

        #region Function to Check for User Permission to Add or View Product
        public void fnAuthorised(string sProductName)
        {
            DataTable dtlogintable = new DataTable();
            DataTable dtBOMUsers = new DataTable();

            // dtProductName = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Parent.Name).Tables["LastNodeId"];
            //if (dtProductName.Rows.Count > 0)
            //{
            dtProductName = DAL.fnGetSalesProductTreeDetails(sName[0]).Tables[0];

            dtBOMUsers = DAL.fnBOMUserList(sProductName, dtProductName.Rows[0]["NodeId"].ToString(), lblbomby.Text).Tables[0];

            dgvallBOM.Visible = false;
            lblFolderMessage.Visible = false;
            pnProductcode.Visible = true;
            //  if (dtBOMUsers.Rows.Count > 0 || LoginForm.GetUserDetails[28] == "True")
            {
                dgBOMList.ReadOnly = false;
                foreach (DataGridViewRow row in dgBOMList.Rows)
                {
                    row.Cells["BOMQuantity"].Style.BackColor = Color.FromArgb(128, 255, 128);
                }
                btnassignuser.Enabled = true;
                bUserstatus = true;

                if (Convert.ToBoolean(LoginForm.GetUserDetails[26]) || LoginForm.GetUserDetails[2] == "Vishal")
                {
                    btnUpdateProduct.Visible = true;
                    btnUpdateProduct.Enabled = true;
                }
                else
                {
                    btnUpdateProduct.Visible = false;
                }
            }
            //else
            //{
            //    btnassignuser.Enabled = false;
            //    bUserstatus = false;
            //    btnUpdateProduct.Visible = false;
            //}
            if (!bUserstatus)
            {
                dgvallBOM.Visible = true;
                pnProductcode.Visible = true;
                Datagridviewcolor();
                gbSearchOptions.Visible = false;
                lbltotalitems.Visible = true;
                lblitemcount.Visible = true;
                lblpcost.Visible = true;
            }
            else
            {
                lblFolderMessage.Visible = false;
                pnProductcode.Visible = true;
                lbltotalitems.Visible = true;
                lblitemcount.Visible = true;
                dgvallBOM.Visible = false;
                gbSearchOptions.Visible = true;
                dgvxcelupload.Visible = true;
                txtProductCode.Text = dtProductName.Rows[0]["ProductCode"].ToString();
                comspecification.Text = dtProductName.Rows[0]["ProductDescription"].ToString();

            }
        }
        #endregion

        #region Code for Treeview After Select Options To Users
        private void tvProduct_AfterSelect(object sender, TreeViewEventArgs e)
        {
            //if (e.Node.Name != "All Product" && (e.Node.StateImageIndex == 2 || e.Node.StateImageIndex == 3 || e.Node.StateImageIndex == 4))
            //{
            //    btnAddProduct.Enabled = false;
            //}
            //else 
            if (e.Node.Name != "All Product" && e.Node.StateImageIndex == 0)
            {
                btnassignuser.Enabled = false;
                /*  if (lblbomby.Text == "megha" || lblbomby.Text == "ravi" || lblbomby.Text == "vivek g" || lblbomby.Text == "abhilash" || lblbomby.Text == "jaibarath" || lblbomby.Text == "abhilash" || lblbomby.Text == "rohit")
                  {
                      btnAddProduct.Enabled = true;
                  }
                  if (lblbomby.Text == "megha" || lblbomby.Text == "ravi" || lblbomby.Text == "vivek g" || lblbomby.Text == "abhilash" || lblbomby.Text == "jaibarath" || lblbomby.Text == "abhilash" || lblbomby.Text == "rohit")
                  {
                      btnrename.Enabled = true;
                  }*/

                if (Convert.ToBoolean(LoginForm.GetUserDetails[26]))
                {
                    btnrename.Enabled = true;
                    btnAddProduct.Enabled = true;
                }
            }

            else if (e.Node.Name != "All Product" && e.Node.StateImageIndex != 0)
            {
                btnassignuser.Enabled = false;
                //   if (lblbomby.Text == "megha" || lblbomby.Text == "ravi" || lblbomby.Text == "vivek g" || lblbomby.Text == "abhilash" || lblbomby.Text == "jaibarath" || lblbomby.Text == "abhilash" || lblbomby.Text == "rohit")
                //   {
                btnAddProduct.Enabled = false;
                //   }
                //   if (lblbomby.Text == "megha" || lblbomby.Text == "ravi" || lblbomby.Text == "vivek g" || lblbomby.Text == "abhilash" || lblbomby.Text == "jaibarath" || lblbomby.Text == "abhilash" || lblbomby.Text == "rohit")
                //  {
                btnrename.Enabled = false;
                //  }
            }

            else if (e.Node.Name == "All Product")
            {
                dgvallBOM.Visible = false;
                //    if (lblbomby.Text == "megha" || lblbomby.Text == "ravi" || lblbomby.Text == "vivek g" || lblbomby.Text == "abhilash" || lblbomby.Text == "jaibarath" || lblbomby.Text == "abhilash" || lblbomby.Text == "rohit")
                //    {
                btnrename.Enabled = false;
                //   }
            }
        }
        #endregion

        #region Function to Change Product or Folder Name
        private void fnNameChange()
        {
            FolderName.fnName(tvProduct.SelectedNode.FullPath);
            FolderName.fnTreeName(tvProduct.SelectedNode.Name);
            FolderName.ShowDialog();
            if (!string.IsNullOrEmpty(sFolderName) && string.IsNullOrEmpty(sProductCode))
            {
                TreeNode TN = new TreeNode();
                tvProduct.BeginUpdate();
                TN.Name = sFolderName;
                TN.Text = sFolderName;
                TN.ForeColor = Color.Black;
                TN.StateImageIndex = Convert.ToInt32(sImageIndex.ToString());
                tvProduct.SelectedNode.Nodes.Add(TN);
                tvProduct.EndUpdate();
                dtParentAndNodeID = DAL.fnGetLastNodeId(null).Tables["LastNodeId"];
                if (dtParentAndNodeID.Rows.Count > 0)
                    iLastNodeID = Convert.ToInt32(dtParentAndNodeID.Rows[0]["NodeID"].ToString());
                dtParentAndNodeID = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Name).Tables["LastNodeId"];
                if (dtParentAndNodeID.Rows.Count > 0)
                    iCurrentParentID = Convert.ToInt32(dtParentAndNodeID.Rows[0]["NodeID"].ToString());
                if (iLastNodeID != 0)
                {
                    GLobalClass.iSuccess = DAL.fnAddProductName(Global.uINSERT, iCurrentParentID, iLastNodeID + 1, TN.Name, sImageIndex, "", lblbomby.Text, sProductCode);

                    GLobalClass.iSuccess = DAL.fnAddBOMUsers(Global.uINSERT, lblbomby.Text, TN.Name, (iLastNodeID + 1).ToString());

                    if (GLobalClass.iSuccess > 0)
                    {
                        MessageBox.Show("Folder '" + sFolderName + "'  Created Successfully.", "Success", 0, MessageBoxIcon.Information);
                    }
                }

            }
            else if (!string.IsNullOrEmpty(sFolderName) && !string.IsNullOrEmpty(sProductCode))
            {
                TreeNode TN = new TreeNode();
                tvProduct.BeginUpdate();
                TN.Name = sFolderName;
                TN.Text = sFolderName;
                TN.ForeColor = Color.Black;
                TN.StateImageIndex = Convert.ToInt32(sImageIndex.ToString());
                tvProduct.SelectedNode.Nodes.Add(TN);
                tvProduct.EndUpdate();
                dtParentAndNodeID = DAL.fnGetLastNodeId(null).Tables["LastNodeId"];
                if (dtParentAndNodeID.Rows.Count > 0)
                    iLastNodeID = Convert.ToInt32(dtParentAndNodeID.Rows[0]["NodeID"].ToString());
                dtParentAndNodeID = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Name).Tables["LastNodeId"];
                if (dtParentAndNodeID.Rows.Count > 0)
                    iCurrentParentID = Convert.ToInt32(dtParentAndNodeID.Rows[0]["NodeID"].ToString());

                if (iLastNodeID != 0)
                {
                    GLobalClass.iSuccess = DAL.fnAddProductName(Global.uINSERT, iCurrentParentID, iLastNodeID + 1, TN.Name, sImageIndex, lblbomby.Text, "", sProductCode);

                    GLobalClass.iSuccess = DAL.fnAddBOMUsers(Global.uINSERT, lblbomby.Text, TN.Name, (iLastNodeID + 1).ToString());

                    if (GLobalClass.iSuccess > 0)
                    {
                        MessageBox.Show("Product '" + sFolderName + "'  Created Successfully.", "Success", 0, MessageBoxIcon.Information);
                    }
                }


            }
        }
        #endregion

        #region Code to Update BOM Quantity
        private void dgBOMList_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            // dtParentName = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Parent.Name).Tables["LastNodeId"];
            // if (dtParentName.Rows.Count > 0)
            //  {
            dtProductCode = DAL.fnGetSalesProductTreeDetails(sName[0]).Tables[0];
            if (dtProductCode.Rows.Count > 0)
            {
                //if ((string.IsNullOrEmpty(dtProductCode.Rows[0]["BOMAuthorisedBy"].ToString()) || dtProductCode.Rows[0]["BOMAuthorisedBy"].ToString().ToUpper() == lblbomby.Text.ToUpper()) || Convert.ToBoolean(LoginForm.GetUserDetails[27]) == true)
                //{
                if (dgBOMList.CurrentCell.OwningColumn.Name == "BOMQuantity")
                {
                    if (!string.IsNullOrEmpty(dgBOMList.CurrentCell.Value.ToString()) && (dgBOMList.CurrentCell.Value.ToString() != sDot))// != null)
                    {
                        if (Convert.ToDouble(dgBOMList.CurrentCell.Value.ToString()) != 0)
                        {
                            // DialogResult DR = MessageBox.Show("Do you want to update of the quantity selected Item", "Information", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                            //if (DR == DialogResult.Yes)
                            //{
                            //dgBOMList.CurrentRow.Cells["Amount"].Value = Convert.ToDouble(dgBOMList.CurrentRow.Cells["BOMQuantity"].Value) * Convert.ToDouble(dgBOMList.CurrentRow.Cells["UnitCost"].Value);
                            dgBOMList.CurrentRow.Cells["Amount"].Value = Convert.ToDouble(dgBOMList.CurrentRow.Cells["BOMQuantity"].Value) * Convert.ToDouble(dgBOMList.CurrentRow.Cells["uFixedCost"].Value);

                            if (!string.IsNullOrEmpty(txtProductCode.Text))
                            {
                                //  dtUpdateParentID = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Parent.Name).Tables["LastNodeId"];
                                //   dtUpdateParentID = DAL.fnGetTreeNode(tvProduct.SelectedNode.Name, dtUpdateParentID.Rows[0]["NodeID"].ToString()).Tables[0];
                                dtUpdateParentID = DAL.fnGetSalesTreeProductCode(txtProductCode.Text).Tables[0];
                                if (dtUpdateParentID.Rows.Count > 0)
                                {
                                    iUpdateParentID = Convert.ToInt32(sName[0]);

                                    GLobalClass.iSuccess = DAL.fnAddProductTreeView(Global.uUPDATE, iUpdateParentID, dgBOMList.CurrentRow.Cells["uItemCode"].Value.ToString(), Convert.ToDouble(dgBOMList.CurrentRow.Cells["BOMQuantity"].Value), null, null, null, null, null, null, null, null,
                                        cmbVersion.Text, null, 0);
                                }

                                sTotalAmount = 0;
                                foreach (DataGridViewRow dgvr in dgBOMList.Rows)
                                {
                                    sTotalAmount += Convert.ToDouble(dgvr.Cells["Amount"].Value);
                                }

                                fnTotalAmount(sTotalAmount);
                                CultureInfo india = new CultureInfo("hi-IN");
                                string text = string.Format(india, "{0:c}", sTotalAmount); // ₹ 3,20,000 
                                lblproductcost.Text = text;

                                sTotalAmount = Convert.ToDouble("0.0");
                                foreach (DataGridViewRow dgvr in dgBOMList.Rows)
                                {
                                    //sTotalAmount += (Convert.ToDouble(dgvr.Cells["BOMQuantity"].Value) * Convert.ToDouble(dgvr.Cells["LatestCost1"].Value));
                                    sTotalAmount += (Convert.ToDouble(dgvr.Cells["BOMQuantity"].Value) * Convert.ToDouble(dgvr.Cells["UnitCost"].Value));
                                }

                                fnTotalAmount(sTotalAmount);
                                text = string.Format(india, "{0:c}", sTotalAmount); // ₹ 3,20,000 
                                lblLatestCost.Text = text;// sTotalAmount.ToString();
                            }
                            // }
                            //else
                            //{
                            //    dgBOMList.CurrentCell.Value = oldvalue;
                            //}
                        }
                        else
                        {
                            MessageBox.Show("Quantity should be greater than 0", "Error", 0, MessageBoxIcon.Error);
                            dgBOMList.CurrentCell.Value = oldvalue;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please enter valid quantity ", "Error", 0, MessageBoxIcon.Error);
                        dgBOMList.CurrentCell.Value = oldvalue;
                    }
                }
                else if (dgBOMList.CurrentCell.OwningColumn.Name == "ProductType")
                {
                    iUpdateParentID = Convert.ToInt32(sName[0]);
                    GLobalClass.iSuccess = DAL.fnAddProductTreeView(6, iUpdateParentID, dgBOMList.CurrentRow.Cells["uItemCode"].Value.ToString(), Convert.ToDouble(dgBOMList.CurrentRow.Cells["BOMQuantity"].Value), null, null, null, null, null, null, null, null,
                                       cmbVersion.Text, dgBOMList.CurrentRow.Cells["ProductType"].Value.ToString(), 0);
                }

                else if (LoginForm.GetUserDetails[2].ToLower() == "vivek g" || LoginForm.GetUserDetails[2].ToLower() == "ravi"|| LoginForm.GetUserDetails[2].ToLower() == "thilak kumar"|| LoginForm.GetUserDetails[2].ToLower() == "kumar ravi" || LoginForm.GetUserDetails[2].ToLower() == "santhoshdj" || LoginForm.GetUserDetails[2].ToLower() == "veena" || LoginForm.GetUserDetails[2].ToLower() == "pavana" || LoginForm.GetUserDetails[2].ToLower() == "hemanth reddy" || LoginForm.GetUserDetails[2].ToLower() == "vishal raina")
                {
                    if (dgBOMList.CurrentCell.OwningColumn.Name == "FixedCost")
                    {

                        iUpdateParentID = Convert.ToInt32(sName[0]);
                        GLobalClass.iSuccess = DAL.fnAddProductTreeView(8, iUpdateParentID, dgBOMList.CurrentRow.Cells["uItemCode"].Value.ToString(), Convert.ToDouble(dgBOMList.CurrentRow.Cells["BOMQuantity"].Value), null, null, null, null, null, null, null, null,
                      cmbVersion.Text, dgBOMList.CurrentRow.Cells["ProductType"].Value.ToString(), 0);
                    }
                }
            
                //}
                //else
                //{
                //    MessageBox.Show("The Quantity Cannot be Updated. \n The BOM is Authorized.\n Please Contatct '" + dtProductCode.Rows[0]["BOMAuthorisedBy"].ToString() + "' to update the quantity.", "Error", 0, MessageBoxIcon.Error);
                //    dgBOMList.CurrentCell.Value = oldvalue;
                //}
            }
            // }

        }
        #endregion

        #region Code to Browse & Upload a Product BOM
        private void btnbrowse_Click(object sender, EventArgs e)
        {
            txtbrowseaddres.ResetText();
            openFileDialog1.Filter = "Excel Files (*.xls)|*.xls";
            openFileDialog1.InitialDirectory = @"c:\";
            openFileDialog1.FileName = "Select File";
            openFileDialog1.Title = "Select excel file..";
            openFileDialog1.ShowDialog();
        }


        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            txtbrowseaddres.Text = openFileDialog1.FileName;

            if (!string.IsNullOrEmpty(txtbrowseaddres.Text))
            {
                try
                {
                    string smessageItemCode = string.Empty;
                    string str = string.Empty;
                    DataTable dtExcelImport = new DataTable();
                    string sheetname = "";
                    string constr = "Provider = Microsoft.Jet.OLEDB.4.0; Data Source=" + txtbrowseaddres.Text + ";Extended Properties= \"Excel 8.0;HDR=YES;\";";
                    OleDbConnection con = new OleDbConnection(constr);
                    con.Open();
                    DataTable Sheets = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

                    foreach (DataRow dr in Sheets.Rows)
                    {
                        sheetname = dr[2].ToString().Replace("'", "");
                        break;
                    }
                    if (!string.IsNullOrEmpty(sheetname))
                    {
                        OleDbDataAdapter sda = new OleDbDataAdapter("select * from [" + sheetname + "]", con);
                        sda.Fill(dtExcelImport);
                    }
                    con.Close();
                    if (dtExcelImport.Rows.Count > 0 && dtExcelImport.Columns.Count == 14 && !string.IsNullOrEmpty(dtExcelImport.Rows[0][0].ToString()))
                    {
                        for (int i = 0; i < dtExcelImport.Columns.Count; i++)
                        {
                            switch (i)
                            {
                                case 0:
                                    str = "slno";
                                    break;
                                case 1:
                                    str = "ItemCode";
                                    break;
                                case 2:
                                    str = "ItemDesc";
                                    break;
                                case 3:
                                    str = "MfgPartNo";
                                    break;
                                case 4:
                                    str = "Make";
                                    break;
                                case 5:
                                    str = "Qty";
                                    break;
                                case 6:
                                    str = "Unitcost";
                                    break;
                                case 7:
                                    str = "Specification";
                                    break;
                                case 8:
                                    str = "ItemType";
                                    break;
                                case 9:
                                    str = "Location";
                                    break;
                                case 10:
                                    str = "Vendor";
                                    break;
                                case 11:
                                    str = "Drawingno";
                                    break;
                                case 12:
                                    str = "Version";
                                    break;
                                case 13:
                                    str = "ProductType";
                                    break;
                                case 14:
                                    str = "FixedCost";
                                    break;

                            }
                            dtExcelImport.Columns[i].ColumnName = str;
                        }

                        for (int i = dtExcelImport.Rows.Count - 1; i >= 0; i--)
                        {
                            if (dtExcelImport.Rows[i][1] == DBNull.Value)
                                dtExcelImport.Rows[i].Delete();
                        }
                        dtExcelImport.AcceptChanges();

                        for (int i = 0; i < dtExcelImport.Rows.Count; i++)
                        {
                            string sItemCodex = dtExcelImport.Rows[i]["ItemCode"].ToString();
                            dtItemSearch = DAL.fnItemListItemsearch(dtExcelImport.Rows[i]["ItemCode"].ToString().Trim()).Tables[0];

                            if (dtItemSearch.Rows.Count > 0)
                            {
                                dtExcelImport.Rows[i]["ItemCode"] = dtItemSearch.Rows[0]["ItemCode"].ToString();
                                dtExcelImport.Rows[i]["ItemDesc"] = dtItemSearch.Rows[0]["ItemDescription"].ToString();
                                dtExcelImport.Rows[i]["Drawingno"] = dtItemSearch.Rows[0]["DrawingNo"].ToString();
                                if (string.IsNullOrEmpty(dtExcelImport.Rows[i]["Qty"].ToString()) || Convert.ToDouble(dtExcelImport.Rows[i]["Qty"].ToString()) == 0.0)
                                {
                                    dtExcelImport.Rows[i]["Qty"] = "1";
                                }

                                if (string.IsNullOrEmpty(dtExcelImport.Rows[0]["Version"].ToString()) || Convert.ToDouble(dtExcelImport.Rows[0]["Version"].ToString()) < 1)
                                {
                                    dtExcelImport.Rows[0]["Version"] = "1";
                                }

                                dtExcelImport.Rows[i]["Version"] = dtExcelImport.Rows[0]["Version"].ToString();
                            }
                            else
                            {
                                dtExcelImport.Rows.RemoveAt(i);
                                i--;
                                if (smessageItemCode.Length > 0)
                                {
                                    smessageItemCode += "," + sItemCodex.ToString();
                                }
                                else
                                {
                                    smessageItemCode = sItemCodex.ToString();
                                }
                            }
                        }

                        if (dtExcelImport.Rows.Count > 0)
                        {
                            Dictionary<string, int> dicSum = new Dictionary<string, int>();
                            foreach (DataRow row in dtExcelImport.Rows)
                            {
                                string group = row["ItemCode"].ToString();
                                int rate = Convert.ToInt32(row["Qty"]);
                                if (dicSum.ContainsKey(group))
                                    dicSum[group] += rate;
                                else
                                    dicSum.Add(group, rate);
                            }

                            DataTable UniqueRecords = RemoveDuplicateRows(dtExcelImport, "ItemCode");

                            foreach (var group in dicSum)
                            {
                                foreach (DataRow FinalItems in dtExcelImport.Rows)
                                {
                                    if (FinalItems["ItemCode"].ToString() == group.Key.ToString())
                                    {
                                        sQty = group.Value;
                                        FinalItems["Qty"] = sQty;
                                        break;
                                    }
                                }
                            }

                            dgvxcelupload.AutoGenerateColumns = false;
                            dgvxcelupload.DataSource = dtExcelImport;
                            btnaddtobom.Enabled = true;
                            lbladditemcount.Text = dgvxcelupload.Rows.Count.ToString();
                            string s = dtExcelImport.Rows.Count.ToString();

                            if (smessageItemCode.Length > 0)
                            {
                                MessageBox.Show("The listed items are not exist in itemmaster " + smessageItemCode + "");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Uploaded Excel file not contains any valid Itemcode(s) matching with the Item master", "Error", 0, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Uploaded Excel file is not in expected format.\n 1) Excel file should contain 13 columns with Names on the first Row \n 2) Items details to be start from the Second Row ", "Error", 0, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("btnUpload_Click" + ex.Message);
                }
            }
            else
            {
                btnaddtobom.Enabled = false;
                MessageBox.Show("Please Select Excel File to Upload the Items", "Warning", 0, MessageBoxIcon.Warning);
            }
        }

        public DataTable RemoveDuplicateRows(DataTable table, string DistinctColumn)
        {
            try
            {
                ArrayList UniqueRecords = new ArrayList();
                ArrayList DuplicateRecords = new ArrayList();


                foreach (DataRow dRow in table.Rows)
                {
                    if (UniqueRecords.Contains(dRow[DistinctColumn]))
                        DuplicateRecords.Add(dRow);
                    else
                        UniqueRecords.Add(dRow[DistinctColumn]);

                }
                // Remove dupliate rows from DataTable added to DuplicateRecords
                if (DuplicateRecords.Count > 0)
                {
                    foreach (DataRow dRow in DuplicateRecords)
                    {
                        table.Rows.Remove(dRow);
                    }
                }
                // Return the clean DataTable which contains unique records.
                return table;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;

            }
        }
        #endregion


        #region Code to Save BOM Items from Excel Uploaded
        private void btnaddtobom_Click(object sender, EventArgs e)
        {
            string sFilteredItems = string.Empty;
            DataTable dtProductParentid = new DataTable();
            DataTable dtTreeviewItems = new DataTable();
            lTreeviewList.Clear();

            DialogResult DR = MessageBox.Show("All existing BOM items will be Deleted. \nDo you want to replace with the uploaded excel items ? ", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (DR == DialogResult.Yes)
            {
                if (sNName != null && dgvxcelupload.Rows.Count > 0)
                {
                    //dtProductParentid = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Parent.Name).Tables["LastNodeId"];

                    //if (dtProductParentid.Rows.Count > 0)
                    //{
                    //    dtProductParentid = DAL.fnGetTreeNode(tvProduct.SelectedNode.Name, dtProductParentid.Rows[0]["NodeID"].ToString()).Tables[0];
                    //}

                    // if (dtProductParentid.Rows.Count > 0)

                    // {
                    //  if (cmbVersion.SelectedIndex >= 0)
                    {
                        GLobalClass.iSuccess = DAL.fnDeleteProductTreeForExcel(Global.uDELETE, Convert.ToInt32(sName[0]), 0);
                    }
                    dtTreeviewItems = DAL.fnVersionProductBOMList(sName[0], dgvxcelupload.Rows[0].Cells["Version"].Value.ToString()).Tables[0];

                    foreach (DataRow dr in dtTreeviewItems.Rows)
                    {
                        lTreeviewList.Add(dr["ItemCode"].ToString());
                    }
                    //}
                    if (lTreeviewList.Count > 0)
                    {
                        for (int i = 0; i < dgvxcelupload.Rows.Count; i++)
                        {
                            foreach (string s in lTreeviewList)
                            {
                                if (!lTreeviewList.Contains(dgvxcelupload.Rows[i].Cells["xItemCode"].Value.ToString()))
                                {
                                    lTreeviewList.Add(dgvxcelupload.Rows[i].Cells["xItemCode"].Value.ToString());
                                    break;
                                }
                                else
                                {
                                    if (sFilteredItems.Length > 0)
                                    {
                                        sFilteredItems += "," + dgvxcelupload.Rows[i].Cells["xItemCode"].Value.ToString();
                                    }
                                    else
                                    {
                                        sFilteredItems = dgvxcelupload.Rows[i].Cells["xItemCode"].Value.ToString();
                                    }

                                    dgvxcelupload.Rows.RemoveAt(i);
                                    i--;
                                    break;
                                }
                            }
                        }
                    }
                    if (dgvxcelupload.Rows.Count > 0)
                    {
                        fnAddExcelItemsToTree();
                        btnaddtobom.Enabled = false;
                        lbladditemcount.Text = "";
                    }
                    else
                    {
                        MessageBox.Show("The uploading Items are already exist in the BOM list", "Message", 0, MessageBoxIcon.Information);
                        lbladditemcount.Text = dgvxcelupload.Rows.Count.ToString();
                        btnaddtobom.Enabled = true;
                    }
                    dgvxcelupload.DataSource = null;

                }
                else
                {
                    if (tnCurrentParentNode != null)
                    {
                        tvProduct.SelectedNode = tnCurrentParentNode;
                        MessageBox.Show("Please upload Excel file to Add BOM to the folder '" + tnCurrentParentNode.Text + "'", "Error", 0, MessageBoxIcon.Error);
                        lbladditemcount.Text = dgvxcelupload.Rows.Count.ToString();
                    }
                    else
                    {
                        if (tnCurrentParentNode == null)
                        {
                            MessageBox.Show("Please Select the folder", "Error", 0, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }
        #endregion

        #region FUnction to Save BOM Items from Excel Uploaded
        private void fnAddExcelItemsToTree()
        {
            try
            {
                //dtParentAndNodeID = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Parent.Name).Tables["LastNodeId"];
                // dtParentAndNodeID = DAL.fnGetTreeNode(tvProduct.SelectedNode.Name, dtParentAndNodeID.Rows[0]["NodeID"].ToString()).Tables[0];
                // if (dtParentAndNodeID.Rows.Count > 0)
                iCurrentParentID = Convert.ToInt32(sName[0]);
                if (iCurrentParentID != 0)
                {
                    //if (tvProduct.SelectedNode.StateImageIndex == 3)
                    //{
                    //    GLobalClass.iSuccess = DAL.fnAddProductName(Global.uUPDATE, 0, iCurrentParentID, tvProduct.SelectedNode.Name, "2", "", "", "");
                    //    GLobalClass.iSuccess = DAL.fnUpdateAuthorise(Global.uUPDATE, iCurrentParentID.ToString(), tvProduct.SelectedNode.Name, "");
                    //    tvProduct.SelectedNode.StateImageIndex = 2;
                    //}

                    foreach (DataGridViewRow LDGVR in dgvxcelupload.Rows)
                    {
                        if (Convert.ToString(LDGVR.Cells["xQty"].Value) == string.Empty || Convert.ToString(LDGVR.Cells["xQty"].Value) == "0")
                        {
                            LDGVR.Cells["xQty"].Value = 1;
                        }

                        if (Convert.ToString(LDGVR.Cells["xMfgPartNo"].Value) == string.Empty || Convert.ToString(LDGVR.Cells["xMfgPartNo"].Value) == null)
                        {
                            excelMfgPartNo = null;
                        }
                        else
                        {
                            excelMfgPartNo = LDGVR.Cells["xMfgPartNo"].Value.ToString();
                        }
                        if (Convert.ToString(LDGVR.Cells["xMake"].Value) == string.Empty || Convert.ToString(LDGVR.Cells["xMake"].Value) == null)
                        {
                            excelmake = null;
                        }
                        else
                        {
                            excelmake = LDGVR.Cells["xMake"].Value.ToString();
                        }
                        if (Convert.ToString(LDGVR.Cells["xSpecification"].Value) == string.Empty || Convert.ToString(LDGVR.Cells["xSpecification"].Value) == null)
                        {
                            excelspecification = null;
                        }
                        else
                        {
                            excelspecification = LDGVR.Cells["xSpecification"].Value.ToString();
                        }
                        if (Convert.ToString(LDGVR.Cells["xLocation"].Value) == string.Empty || Convert.ToString(LDGVR.Cells["xLocation"].Value) == null)
                        {
                            excelLocation = null;
                        }
                        else
                        {
                            excelLocation = LDGVR.Cells["xLocation"].Value.ToString();
                        }
                        if (Convert.ToString(LDGVR.Cells["xVendor"].Value) == string.Empty || Convert.ToString(LDGVR.Cells["xVendor"].Value) == null)
                        {
                            excelVendor = null;
                        }
                        else
                        {
                            excelVendor = LDGVR.Cells["xVendor"].Value.ToString();
                        }
                        if (Convert.ToString(LDGVR.Cells["xDrawingno"].Value) == string.Empty || Convert.ToString(LDGVR.Cells["xDrawingno"].Value) == null)
                        {
                            excelDrawingNo = null;
                        }
                        else
                        {
                            excelDrawingNo = LDGVR.Cells["xDrawingno"].Value.ToString();
                        }
                        if (Convert.ToString(LDGVR.Cells["Version"].Value) == string.Empty || Convert.ToString(LDGVR.Cells["Version"].Value) == null)
                        {
                            excelVersion = null;
                        }
                        else
                        {
                            excelVersion = LDGVR.Cells["Version"].Value.ToString();
                        }
                        if (Convert.ToString(LDGVR.Cells["XProductType"].Value) == string.Empty || Convert.ToString(LDGVR.Cells["XProductType"].Value) == null)
                        {
                            excelProdType = null;
                        }
                        else
                        {
                            excelProdType = LDGVR.Cells["XProductType"].Value.ToString();
                        }


                        GLobalClass.iSuccess = DAL.fnAddProductTreeView(Global.uINSERT, iCurrentParentID, LDGVR.Cells["xItemCode"].Value.ToString(), Convert.ToDouble(LDGVR.Cells["xQty"].Value.ToString()),
                                               excelMfgPartNo, excelmake, excelspecification, excelLocation, excelVendor, excelDrawingNo, lblbomby.Text, lblbomby.Text, excelVersion, excelProdType, Convert.ToDecimal(LDGVR.Cells["xFixedCost"].Value.ToString()));

                    }
                    if (GLobalClass.iSuccess == 1)
                    {
                        MessageBox.Show("Uploaded Items added to the '" + tvProduct.SelectedNode.Name + "' BOM successfully", "Success", 0, MessageBoxIcon.Information);
                        TreeNode tn = this.tvProduct.SelectedNode;
                        int x = tn.Bounds.X;
                        int y = tn.Bounds.Y;
                        TreeNodeMouseClickEventArgs treeNodeMouseClickEventArgs = new TreeNodeMouseClickEventArgs(tn, MouseButtons.Left, 1, x, y);
                        this.tvProduct_NodeMouseClick(tn, treeNodeMouseClickEventArgs);
                    }
                }
                else
                    MessageBox.Show("Please select the  folder", "Error", 0, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("ProduectMasterForm_btnAddItems_Click " + ex.Message, "Error", 0, MessageBoxIcon.Error);
            }
        }
        #endregion

        #region Code to Assign Users for Product BOM
        private void btnassignuser_Click(object sender, EventArgs e)
        {
            try
            {
                if (tvProduct.SelectedNode != null && (tvProduct.SelectedNode.StateImageIndex == 2 || tvProduct.SelectedNode.StateImageIndex == 3 || tvProduct.SelectedNode.StateImageIndex == 4))
                {
                    //dtParentAndNodeID = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Parent.Name).Tables["LastNodeId"];
                    //  dtParentAndNodeID = DAL.fnGetTreeNode(tvProduct.SelectedNode.Name, dtParentAndNodeID.Rows[0]["NodeID"].ToString()).Tables[0];
                    //  if (dtParentAndNodeID.Rows.Count > 0)
                    iCurrentParentID = Convert.ToInt32(sName[0]);
                    AddUser.fnParentName(iCurrentParentID.ToString());
                    AddUser.fnProductName(tvProduct.SelectedNode.Name);
                    AddUser.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Please Select the folder", "Error", 0, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("btnassignuser_Click " + ex.Message, "Error", 0, MessageBoxIcon.Error);
            }
        }
        #endregion

        #region Code to Validate Numbers in DataGrid View entered
        private void Control_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (dgBOMList.CurrentCell.OwningColumn.Name == "BOMQuantity")
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
                {
                    e.Handled = true;
                }
                // only allow one decimal point
                if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
                {
                    e.Handled = true;
                }
            }
        }

        private void Control_KeyPress12(object sender, KeyPressEventArgs e)
        {
            if (dgvxcelupload.CurrentCell.OwningColumn.Name == "xQty")
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
                {
                    e.Handled = true;
                }
                // only allow one decimal point
                if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
                {
                    e.Handled = true;
                }
            }
        }

        private void Control_KeyPress13(object sender, KeyPressEventArgs e)
        {
            if (dgItemList.CurrentCell.OwningColumn.Name == "Quantity" || dgItemList.CurrentCell.OwningColumn.Name == "uncost")
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
                {
                    e.Handled = true;
                }
                // only allow one decimal point
                if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
                {
                    e.Handled = true;
                }
            }
        }

        private void dgvxcelupload_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvxcelupload.CurrentCell.OwningColumn.Name == "xQty")
            {
                if (!string.IsNullOrEmpty(dgvxcelupload.CurrentCell.Value.ToString()) && (dgvxcelupload.CurrentCell.Value.ToString() != sDot))// != null)
                {
                    if (Convert.ToDouble(dgvxcelupload.CurrentCell.Value.ToString()) != 0)
                    {
                        //   dgvxcelupload.CurrentCell.Value = Convert.ToString(GLobalClass.fnDGVIsFloatingNumber(Convert.ToString(dgvxcelupload.Rows[e.RowIndex].Cells["xQty"].Value)));

                        //   if (Convert.ToString(dgvxcelupload.CurrentCell.Value) == "0")
                        //   {
                        //      dgvxcelupload.CurrentCell.Value = 1;
                        //   }
                    }
                    else
                    {
                        MessageBox.Show("Entered value should be greater than 0", "Error", 0, MessageBoxIcon.Error);
                        dgvxcelupload.CurrentCell.Value = oldvalue;
                    }
                }
                else
                {
                    MessageBox.Show("Enter a Valid Value", "Error", 0, MessageBoxIcon.Error);
                    dgvxcelupload.CurrentCell.Value = oldvalue;
                }
            }
        }
        #endregion

        #region Code to Add New Folder or Product to TreeView

        #endregion


        #region Code to Delete a Product BOM Item
        private void dgBOMList_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                // dtParentAndNodeID = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Parent.Name).Tables["LastNodeId"];
                //  dtParentAndNodeID = DAL.fnGetTreeNode(tvProduct.SelectedNode.Name, dtParentAndNodeID.Rows[0]["NodeID"].ToString()).Tables[0];
                //if (dtParentAndNodeID.Rows.Count > 0 && string.IsNullOrEmpty(dtParentAndNodeID.Rows[0]["BOMAuthorisedBy"].ToString()))
                //{
                DialogResult DR = MessageBox.Show("Do you want to delete selected Item?  " + dgBOMList.CurrentRow.Cells["uItemDescription"].Value.ToString() + "", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DR == DialogResult.Yes)
                {
                    GLobalClass.iSuccess = DAL.fnAddProductTreeView(Global.uDELETE, Convert.ToInt32(sName[0]), dgBOMList.CurrentRow.Cells["uItemCode"].Value.ToString(), Convert.ToDouble("0"),
                                                                                 null, null, null, null, null, null, null, null, cmbVersion.Text, null,0);
                    MessageBox.Show("Slected Item '" + dgBOMList.CurrentRow.Cells["uItemDescription"].Value.ToString() + "' Deleted successfully", "Success", 0, MessageBoxIcon.Information);
                    dgBOMList.Rows.RemoveAt(dgBOMList.Rows.IndexOf(dgBOMList.CurrentRow));

                    cmbVersion_SelectedIndexChanged(sender, e);

                    //lblitemcount.Text = dgBOMList.Rows.Count.ToString();
                    //sTotalAmount = 0;
                    //foreach (DataGridViewRow dgvr in dgBOMList.Rows)
                    //{
                    //    sTotalAmount += Convert.ToDouble(dgvr.Cells["Amount"].Value);
                    //}

                    //fnTotalAmount(sTotalAmount);
                    //CultureInfo india = new CultureInfo("hi-IN");
                    //string text = string.Format(india, "{0:c}", sTotalAmount); // ₹ 3,20,000 
                    //lblproductcost.Text = text;

                    //sTotalAmount = Convert.ToDouble("0.0");
                    //foreach (DataGridViewRow dgvr in dgBOMList.Rows)
                    //{
                    //    sTotalAmount += Convert.ToDouble(dgvr.Cells["BOMQuantity"].Value) * Convert.ToDouble(dgvr.Cells["LatestCost1"].Value);
                    //}

                    //fnTotalAmount(sTotalAmount);
                    //text = string.Format(india, "{0:c}", sTotalAmount); // ₹ 3,20,000 
                    //lblLatestCost.Text = text;// sTotalAmount.ToString();
                    //   lblproductcost.Text = sTotalAmount.ToString();


                }
                //  }
                //else
                //{
                //    MessageBox.Show("Dear '" + lblbomby.Text.ToUpper() + "' you dont have permission to delete items. Please contact '" + dtParentAndNodeID.Rows[0]["BOMCreatedBy"].ToString().ToUpper() + "' to delete the selected item. ", "Inforamation", 0, MessageBoxIcon.Error);
                //}
            }
        }
        #endregion

        #region Function to Calcualate Amount with exact 2 decimals
        private void fnTotalAmount(double sAmount)
        {
            double number = Convert.ToDouble(sAmount);

            int intPortion = (int)number;

            decimal fraction = (decimal)(number - intPortion) * 100;

            int decPortion = (int)Math.Round(fraction);
            if (decPortion < 50)
            {
                double number1 = (double)Math.Round(number);
                sTotalAmount = number1;
            }
            else
            {
                double number1 = (double)Math.Ceiling(number);
                sTotalAmount = number1;
            }
        }
        #endregion

        #region Code to Rename a Product or Folder
        private void btnrename_Click(object sender, EventArgs e)
        {
            if ((tvProduct.SelectedNode.Name != "All Product") && tvProduct.SelectedNode.StateImageIndex == 0)
            {
                Rename.fnFolderandProduct(tvProduct.SelectedNode.Text, "");
                Rename.ShowDialog();
                if (!string.IsNullOrEmpty(sRenameFolder))
                {
                    MessageBox.Show("Slected Folder '" + tvProduct.SelectedNode.Text + "' Renamed successfully to ' " + sRenameFolder + " '", "Success", 0, MessageBoxIcon.Information);
                    tvProduct.BeginUpdate();
                    tvProduct.SelectedNode.Name = sRenameFolder;
                    tvProduct.SelectedNode.Text = sRenameFolder;
                    tvProduct.SelectedNode.StateImageIndex = 0;
                    tvProduct.EndUpdate();
                }

            }
            else if ((tvProduct.SelectedNode.Name != "All Product") && (tvProduct.SelectedNode.StateImageIndex == 2 || tvProduct.SelectedNode.StateImageIndex == 3))
            {
                Rename.fnFolderandProduct(tvProduct.SelectedNode.Parent.Text, tvProduct.SelectedNode.Text);
                Rename.ShowDialog();
                if (!string.IsNullOrEmpty(sRenameFolder))
                {
                    MessageBox.Show("Slected Product '" + tvProduct.SelectedNode.Text + "' Renamed successfully to ' " + sRenameFolder + " '", "Success", 0, MessageBoxIcon.Information);
                    tvProduct.BeginUpdate();
                    tvProduct.SelectedNode.Name = sRenameFolder;
                    tvProduct.SelectedNode.Text = sRenameFolder;
                    if (tvProduct.SelectedNode.StateImageIndex == 2)
                    {
                        tvProduct.SelectedNode.StateImageIndex = 2;
                    }
                    else
                    {
                        tvProduct.SelectedNode.StateImageIndex = 3;
                    }
                    tvProduct.EndUpdate();
                }
            }
        }
        #endregion

        #region Function to Search a Tree Item
        private void SearchNodes(string SearchText, TreeNode StartNode)
        {
            while (StartNode != null)
            {
                if (StartNode.Text.ToLower().Contains(SearchText.ToLower()))
                {
                    CurrentNodeMatches.Add(StartNode);
                };
                if (StartNode.Nodes.Count != 0)
                {
                    SearchNodes(SearchText, StartNode.Nodes[0]);//Recursive Search 
                };
                StartNode = StartNode.NextNode;
            };

        }
        DataTable dtProductCodeSearch = new DataTable();
        private void btnsearchtree_Click(object sender, EventArgs e)
        {
            string searchText = this.txtsearchtree.Text;
            if (String.IsNullOrEmpty(searchText))
            {
                return;
            };

            if (LastSearchText != searchText)
            {
                //It's a new Search
                CurrentNodeMatches.Clear();
                if (chkProductCode.CheckState == CheckState.Checked)
                {
                    dtProductCodeSearch = DAL.fnSalesProductCodeName(searchText).Tables[0];
                    LastSearchText = searchText;
                    if (dtProductCodeSearch.Rows.Count > 0)
                    {
                        searchText = dtProductCodeSearch.Rows[0]["Name"].ToString().Trim();
                        LastNodeIndex = 0;
                        SearchNodes(searchText, tvProduct.Nodes[0]);
                    }
                }
                else
                {
                    LastSearchText = searchText;
                    LastNodeIndex = 0;
                    SearchNodes(searchText, tvProduct.Nodes[0]);
                }

            }

            if (LastNodeIndex >= 0 && CurrentNodeMatches.Count > 0 && LastNodeIndex < CurrentNodeMatches.Count)
            {
                TreeNode selectedNode = CurrentNodeMatches[LastNodeIndex];
                LastNodeIndex++;
                tvProduct.SelectedNode = selectedNode;
                tvProduct.SelectedNode.Expand();
                tvProduct.Select();
                TreeNode tn = this.tvProduct.SelectedNode;
                int x = tn.Bounds.X;
                int y = tn.Bounds.Y;
                TreeNodeMouseClickEventArgs treeNodeMouseClickEventArgs = new TreeNodeMouseClickEventArgs(tn, MouseButtons.Left, 1, x, y);
                tvProduct_NodeMouseClick(tn, treeNodeMouseClickEventArgs);

            }
        }


        private void txtsearchtree_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnsearchtree_Click(sender, e);
            }
        }

        private void cleartreeview_Click(object sender, EventArgs e)
        {
            txtsearchtree.ResetText();
            LastSearchText = "";
            tvProduct.CollapseAll();
            if ((tvProduct.SelectedNode) != null)
            {
                TreeNode tn = this.tvProduct.SelectedNode;
                int x = tn.Bounds.X;
                int y = tn.Bounds.Y;
                TreeNodeMouseClickEventArgs treeNodeMouseClickEventArgs = new TreeNodeMouseClickEventArgs(tn, MouseButtons.Left, 1, x, y);
                this.tvProduct_NodeMouseClick(tn, treeNodeMouseClickEventArgs);
            }
        }

        #endregion

        #region Code to Validate Numeric Values in BOM Quantity
        private void dgvxcelupload_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if ((dgvxcelupload.CurrentCell.OwningColumn.Name == "xQty")) //dgbomlist.CurrentCell.OwningColumn.Name == "Amount" || dgbomlist.CurrentCell.OwningColumn.Name == "ReqQty")
            {
                oldvalue = Convert.ToDouble(dgvxcelupload.CurrentCell.Value);
            }
        }

        private void dgvxcelupload_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress12);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
            }
        }

        private void dgBOMList_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            //if ((dgBOMList.CurrentCell.OwningColumn.Name == "BOMQuantity") && dgBOMList.CurrentCell.Value.ToString() != string.Empty) //dgbomlist.CurrentCell.OwningColumn.Name == "Amount" || dgbomlist.CurrentCell.OwningColumn.Name == "ReqQty")
            //{
            //    oldvalue = Convert.ToDouble(dgBOMList.CurrentCell.Value);
            //}
            // Get the column name being edited
            //string columnName = dgBOMList.Columns[e.ColumnIndex].Name;

            //// Allow everyone to edit "uBOMQty" and store its old value
            //if (columnName == "BOMQuantity")
            //{
            //    oldvalue = Convert.ToDouble(dgBOMList.CurrentCell.Value);
            //}

            //// If column is "FixedCost"
            //if (columnName == "FixedCost")
            //{
            //    // Check if user is "vivek g"
            //    if (LoginForm.GetUserDetails[2].ToLower() == "vivek g" || LoginForm.GetUserDetails[2].ToLower() == "ravi" || LoginForm.GetUserDetails[2].ToLower() == "thilak kumar" || LoginForm.GetUserDetails[2].ToLower() == "kumar ravi")
            //    {
            //        // Store old value
            //        oldvalue = Convert.ToDouble(dgBOMList.CurrentCell.Value);
            //    }
            //    else
            //    {
            //        // Block editing for other users
            //        e.Cancel = true;

            //        // Optional: Inform the user
            //        MessageBox.Show("Only authorized persons are allowed to edit the 'FixedCost'",
            //                        "Access Denied",
            //                        MessageBoxButtons.OK,
            //                        MessageBoxIcon.Warning);
            //    }
            //}





            // Get the column name being edited
            string columnName = dgBOMList.Columns[e.ColumnIndex].Name;

            // Allow everyone to edit "uBOMQty" and store its old value
            if (columnName == "BOMQuantity")
            {
                oldvalue = Convert.ToDouble(dgBOMList.CurrentCell.Value);
            }

            // If column is "FixedCost"
            if (columnName == "uFixedCost")
            {
                // Check if user is "vivek g"
                if (LoginForm.GetUserDetails[2].ToLower() == "vivek g" || LoginForm.GetUserDetails[2].ToLower() == "ravi" || LoginForm.GetUserDetails[2].ToLower() == "thilak kumar" || LoginForm.GetUserDetails[2].ToLower() == "kumar ravi" || LoginForm.GetUserDetails[2].ToLower() == "santhoshdj" || LoginForm.GetUserDetails[2].ToLower() == "veena" || LoginForm.GetUserDetails[2].ToLower() == "pavana" || LoginForm.GetUserDetails[2].ToLower() == "hemanth reddy" || LoginForm.GetUserDetails[2].ToLower() == "vishal raina")

                {
                    // Store old value
                    oldvalue = Convert.ToDouble(dgBOMList.CurrentCell.Value);
                }
                else
                {
                    // Block editing for other users
                    e.Cancel = true;

                    // Optional: Inform the user
                    MessageBox.Show("Only authorized persons are allowed to edit the 'FixedCost'",
                                    "Access Denied",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning);
                }
            }
        }

        private void dgBOMList_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
            }
        }
        #endregion

        #region Code to Authorise BOM Added
        private void btnAuthorise_Click(object sender, EventArgs e)
        {
            // dtParentName = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Parent.Name).Tables["LastNodeId"];
            // if (dtParentName.Rows.Count > 0)
            // {
            dtProductCode = DAL.fnGetSalesProductTreeDetails(sName[0]).Tables[0];
            if (dtProductCode.Rows.Count > 0)
            {
                //if (string.IsNullOrEmpty(dtProductCode.Rows[0]["BOMAuthorisedBy"].ToString()))
                //{
                GLobalClass.iSuccess = DAL.fnUpdateAuthorise(Global.uUPDATE, dtProductCode.Rows[0]["NodeID"].ToString(), tvProduct.SelectedNode.Name, lblbomby.Text);
                MessageBox.Show("Slected Product '" + tvProduct.SelectedNode.Text + "' authorised successfully.", "Success", 0, MessageBoxIcon.Information);
                //}
                //else
                //{
                //    //DialogResult DR = MessageBox.Show("Slected product '" + tvProduct.SelectedNode.Text + "' already authorised by '" + dtProductCode.Rows[0]["BOMAuthorisedBy"].ToString() + "'. \n do you want to replace?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                //   // if (DR == DialogResult.Yes)
                //    {
                //        GLobalClass.iSuccess = DAL.fnUpdateAuthorise(Global.uUPDATE, dtProductCode.Rows[0]["NodeID"].ToString(), tvProduct.SelectedNode.Name, lblbomby.Text);
                //    }
                //}
            }
            // }
        }
        #endregion

        #region Function to Remove Special Characters in Searchin Items
        public string RemoveSpecialChars(string str)
        {
            string[] chars = new string[] { "/", "\"", "?", "*", "[", "]", ":", "|" };

            for (int i = 0; i < chars.Length; i++)
            {
                if (str.Contains(chars[i]))
                    str = str.Replace(chars[i], " ");
            }
            return str;
        }

        #endregion

        #region Code to Genarate the Excel file from Uploaded  BOM
        private void btnexcelexport_Click(object sender, EventArgs e)
        {
            sNodeName = tvProduct.SelectedNode.Name;
            //  dtPName = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Parent.Name).Tables["LastNodeId"];
            //  dtPName = DAL.fnGetTreeNode(sNodeName, dtPName.Rows[0]["NodeID"].ToString()).Tables[0];

            //dtPName = DAL.fnGetSalesProductTreeDetails(sName[0]).Tables[0];
            //  if (dtPName.Rows.Count > 0)
            // {
            //  dtEXCELData = DAL.fnEXCELProductBOMList(sName[0], cmbVersion.Text).Tables[0];
            //dtEXCELData = DAL.fnEXCELProductBOMList(dtProductName.Rows[0]["ParentID"].ToString(), cmbVersion.Text).Tables[0];
            // }
            // if (dtEXCELData.Rows.Count > 0) dtProductTreeview
            dtEXCELData = DAL.fnEXCELProductBOMList(sName[0], cmbVersion.Text).Tables[0];
          //  dtEXCELData = dtProductTreeview.Copy();
            if (dtEXCELData.Rows.Count > 0)
            {
                int iRowIndex = 1;
                string ExcelFolderPath;
                string FileFullPath;
                EXCEL.Workbook NewWorkBook;
                EXCEL.Worksheet NewWorkSheet;
                EXCEL.Application ExcelApp;
                object misValue;
                string excelfilename;
                string Productname = sNodeName;

                //  string Productname = tvProduct.SelectedNode.Parent.Name;

                Productname = RemoveSpecialChars(Productname);
                Productname = Productname.Replace(System.Environment.NewLine, string.Empty);
                string Productcode = txtProductCode.Text;
                Productcode = RemoveSpecialChars(txtProductCode.Text);
                excelfilename = Productname + "-" + Productcode;

                ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\BOM\\";
                FileFullPath = ExcelFolderPath + excelfilename + "-" + DateTime.Now.ToString("dd/MM/yyyy") + ".xls";
                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);
                ExcelApp = new EXCEL.Application();
                misValue = System.Reflection.Missing.Value;
                try
                {
                    if (ExcelApp == null)
                        MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                    NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                    NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                    if (NewWorkSheet == null)
                        MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                    else
                        NewWorkSheet.Name = "Sheet1";
                    EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                    if (RANGE == null)
                        MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                    //Commnet here for Design teams
                    // if (Convert.ToBoolean(LoginForm.GetUserDetails[27]) == false)
                    {
                        NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlWorkbookNormal, misValue, misValue, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, misValue, misValue, misValue, misValue, misValue);
                    }
                    if (dtEXCELData.Rows.Count > 0)
                    {
                        object[,] rawData = new object[dtEXCELData.Rows.Count + 1, dtEXCELData.Columns.Count];
                        for (int col = 0; col < dtEXCELData.Columns.Count; col++)
                        {
                            rawData[0, col] = dtEXCELData.Columns[col].ColumnName;
                        }
                        for (int row = 0; row < dtEXCELData.Rows.Count; row++)
                        {
                            for (int col = 0; col < dtEXCELData.Columns.Count; col++)
                            {
                                rawData[row + 1, col] = dtEXCELData.Rows[row].ItemArray[col];
                            }
                        }
                        string excelRange = string.Empty;
                        string finalColLetter = string.Empty;
                        string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        int colCharsetLen = colCharset.Length;

                        if (dtEXCELData.Columns.Count > colCharsetLen)
                        {
                            finalColLetter = colCharset.Substring(
                                (dtEXCELData.Columns.Count - 1) / colCharsetLen - 1, 1);
                        }

                        finalColLetter += colCharset.Substring(
                                (dtEXCELData.Columns.Count - 1) % colCharsetLen, 1);
                        excelRange = string.Format("A1:{0}{1}", finalColLetter, dtEXCELData.Rows.Count + iRowIndex);


                        NewWorkSheet.get_Range(excelRange, misValue).Value2 = rawData;
                    }

                    NewWorkSheet.get_Range("A6:F999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    NewWorkSheet.get_Range("A6", "F999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;

                    NewWorkSheet.Rows.AutoFit();
                    NewWorkSheet.Columns.AutoFit();
                    NewWorkSheet.Rows.RowHeight = "18";
                    NewWorkSheet.PageSetup.PrintArea = "A1:D" + dtEXCELData.Rows.Count + iRowIndex + 3 + "";
                    NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                    NewWorkSheet.PageSetup.PrintNotes = true;
                    NewWorkSheet.PageSetup.Zoom = 100;
                    NewWorkSheet.PageSetup.FitToPagesTall = 1;
                    NewWorkSheet.PageSetup.FitToPagesWide = 1;
                    NewWorkSheet.PageSetup.LeftMargin = 0;
                    NewWorkSheet.PageSetup.RightMargin = 0;
                    NewWorkSheet.PageSetup.TopMargin = 0.75;
                    NewWorkSheet.PageSetup.BottomMargin = 0.75;
                    NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                    NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                    NewWorkBook.Save();
                    //Commnet here for Design teams
                    //  if (Convert.ToBoolean(LoginForm.GetUserDetails[27]) == false)
                    {
                        ExcelApp.Visible = false;
                        NewWorkBook.Close(true, misValue, misValue);
                        ExcelApp.Quit();

                        releaseObject(NewWorkSheet);
                        releaseObject(NewWorkBook);
                        releaseObject(ExcelApp);
                    }
                    //else
                    //{
                    //    ExcelApp.Visible = true;
                    //}
                    if (Directory.Exists(ExcelFolderPath))
                    {
                        Process.Start(ExcelFolderPath);
                    }
                }
                catch (Exception ex)
                {
                    ExcelApp.Quit();
                    MessageBox.Show(ex.Message);

                }
            }
            else
                MessageBox.Show("No items to save", "Error", 0, MessageBoxIcon.Question);
        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
        #endregion

        #region Code to Delete a Excel Uploaded BOM Item
        private void dgvxcelupload_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                DialogResult DR = MessageBox.Show("Do you want to delete selected Item?  " + dgvxcelupload.CurrentRow.Cells["xItemDesc"].Value.ToString() + "", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DR == DialogResult.Yes)
                {
                    dgvxcelupload.Rows.RemoveAt(dgvxcelupload.Rows.IndexOf(dgvxcelupload.CurrentRow));
                    lbladditemcount.Text = dgvxcelupload.Rows.Count.ToString();
                }
            }
        }
        #endregion

        #region Code to Search an Item in Uploaded BOM
        private void txtItemSearch_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtItemSearch.TextLength > 2)
            {
                dtClone = dtProductTreeview.Copy();
                bsIteSearch.DataSource = dtClone;

                bsIteSearch.Filter = string.Format("ItemCode LIKE '%{0}%' OR ItemDescription LIKE '%{0}%'  or ProductType LIKE '%{0}%'", txtItemSearch.Text);
                dgBOMList.DataSource = bsIteSearch;
                if (dgvallBOM.Visible == true)
                {
                    dgvallBOM.DataSource = bsIteSearch;
                    bsIteSearch.Filter = string.Format("ItemCode LIKE '%{0}%' OR ItemDescription LIKE '%{0}%'  or ProductType LIKE '%{0}%'", txtItemSearch.Text);
                    dgvallBOM.DataSource = bsIteSearch;
                    Datagridviewcolor();
                }
                fnCostDetails();
            }
            else
            {
                bsIteSearch.RemoveFilter();
                Datagridviewcolor();
                fnCostDetails();
            }
        }
        #endregion

        #region Code to Select a Item to Add BOM

        #endregion

        private void fnUpadateTreeDetails(uint SaveorUpdate)
        {
            // DAL.fnUpdateProductDetails(dtProductName.Rows[0]["ProductCode"].ToString(), txtProductCode.Text.Trim(), txtProductName.Text.Trim(), txtProductDesc.Text.Trim(), txtProductCost.Text, txtSalesCost.Text);


            if (SaveorUpdate == Global.uINSERT)
            {
                dtParentAndNodeID = DAL.fnGetCopySalesFolderNodeId(null).Tables[0];
                if (dtParentAndNodeID.Rows.Count > 0)
                {
                    iLastNodeID = Convert.ToInt32(dtParentAndNodeID.Rows[0]["NodeID"].ToString());
                    iLastNodeID++;
                }
                if (iLastNodeID != 0)
                {
                    GLobalClass.iSuccess = DAL.fnAddSalesProductName(SaveorUpdate, Convert.ToInt32(sName[0]), iLastNodeID, txtProductName.Text, "1", LoginForm.GetUserDetails[2], LoginForm.GetUserDetails[2], txtProductCode.Text, "", txtProductCost.Text, "");
                }

                MessageBox.Show("Product successfully saved.", "Information", 0, MessageBoxIcon.Information);
                TreeNode TN = new TreeNode();
                tvProduct.BeginUpdate();
                TN.Name = iLastNodeID + ")" + txtProductName.Text.Trim(); ;
                TN.Text = iLastNodeID + ")" + txtProductName.Text.Trim(); ;
                TN.ForeColor = Color.Black;
                TN.StateImageIndex = 1;
                tvProduct.SelectedNode.Nodes.Add(TN);
                tvProduct.EndUpdate();
            }

            else if (SaveorUpdate == Global.uUPDATE)
            {
                GLobalClass.iSuccess = DAL.fnAddSalesProductName(SaveorUpdate, 0, Convert.ToInt32(sName[0]), txtProductName.Text, "1", "", "", txtProductCode.Text, "", txtProductCost.Text, "");
                tvProduct.BeginUpdate();
                tvProduct.SelectedNode.Name = sName[0] + ")" + txtProductName.Text.Trim();
                tvProduct.SelectedNode.Text = sName[0] + ")" + txtProductName.Text.Trim();
                tvProduct.SelectedNode.StateImageIndex = 1;

                tvProduct.EndUpdate();
                MessageBox.Show("Product successfully updated.", "Information", 0, MessageBoxIcon.Information);
            }
        }

        DataTable dtProductCodeCheck = new DataTable();
        DataTable dtProductNameCheck = new DataTable();

        DataTable dtNewProductCodeCheck = new DataTable();
        DataTable dtNewProductNameCheck = new DataTable();
        // 
        private void btnUpdateProduct_Click(object sender, EventArgs e)
        {
            //if (!string.IsNullOrEmpty(dtProductName.Rows[0]["ProductCode"].ToString()))
            //{
            //    dtProductCodeCheck = DAL.fnProductCode(dtProductName.Rows[0]["ProductCode"].ToString()).Tables[0];
            //    if (dtProductCodeCheck.Rows.Count < 2)
            //    {
            //        if (dtProductName.Rows[0]["ProductCode"].ToString().Trim() != txtProductCode.Text.Trim())
            //        {
            //            dtNewProductCodeCheck = DAL.fnProductCode(txtProductCode.Text).Tables[0];
            //            if (dtNewProductCodeCheck.Rows.Count == 0)
            //            {
            //                fnUpadateTreeDetails();
            //            }
            //            else
            //            {
            //                MessageBox.Show("Entered new product code alreday used for product '" + dtNewProductCodeCheck.Rows[0]["Name"].ToString() + "'. Please enter a unique product code.", "Information", 0, MessageBoxIcon.Warning);
            //            }
            //        }
            //        else
            //        {
            //            fnUpadateTreeDetails();
            //        }
            //    }
            //    else
            //    {
            //        MessageBox.Show("Selected Product has duplicate product code. Please contact the admin.", "Information", 0, MessageBoxIcon.Warning);
            //    }

            //}
        }

        //private void fnUpadateTreeDetails()
        //{
        //    DAL.fnUpdateProductDetails(dtProductName.Rows[0]["ProductCode"].ToString(), txtProductCode.Text.Trim(), txtProductName.Text.Trim(), txtProductDesc.Text.Trim(), txtProductCost.Text, txtSalesCost.Text);

        //    DAL.fnBOMUserNameProduct(txtProductName.Text.Trim(), dtProductName.Rows[0]["Name"].ToString().Trim(), dtProductName.Rows[0]["NodeID"].ToString());

        //    DAL.fnProjectRenameProduct(txtProductName.Text.Trim(), txtProductCode.Text.Trim(), dtProductName.Rows[0]["Name"].ToString().Trim(), dtProductName.Rows[0]["ProductCode"].ToString().Trim());

        //    tvProduct.BeginUpdate();
        //    tvProduct.SelectedNode.Name = txtProductName.Text.Trim();
        //    tvProduct.SelectedNode.Text = txtProductName.Text.Trim();
        //    if (tvProduct.SelectedNode.StateImageIndex == 2)
        //    {
        //        tvProduct.SelectedNode.StateImageIndex = 2;
        //    }
        //    else
        //    {
        //        tvProduct.SelectedNode.StateImageIndex = 3;
        //    }
        //    tvProduct.EndUpdate();
        //    MessageBox.Show("Selected Product has successfully updated.", "Information", 0, MessageBoxIcon.Information);
        //}



        private void txtProductCost_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void cmbVersion_SelectedIndexChanged(object sender, EventArgs e)
        {
            lExistingTreeviewList.Clear();
            dtProductTreeview = DAL.fnVersionProductBOMList(sName[0], cmbVersion.Text).Tables[0];
            timer1.Stop();
            lblVersion.Visible = true;
            if (dtProductTreeview.Rows.Count > 0)
            {
                dtReciept = DAL.fnLatestCost().Tables[0];
                foreach (DataRow rowSampleOne in dtReciept.Rows)
                {
                    foreach (DataRow rowSampleTwo in dtProductTreeview.Rows)
                    {
                        if (rowSampleTwo["ItemCode"].ToString().Equals(rowSampleOne["ItemCode"].ToString()))
                        {
                            rowSampleTwo["LatestCost"] = Convert.ToDouble(rowSampleOne["PurchaseCost"].ToString());
                        }
                    }
                }
                foreach (DataRow rowSampleTwo in dtProductTreeview.Rows)
                {
                    if (rowSampleTwo["LatestCost"].ToString().Equals("0"))
                    {
                        rowSampleTwo["LatestCost"] = Convert.ToDouble(rowSampleTwo["UnitCost"].ToString());
                    }
                }

                dgBOMList.AutoGenerateColumns = false;
                dgBOMList.DataSource = dtProductTreeview;
                dgvallBOM.DataSource = null;
                dgvallBOM.AutoGenerateColumns = false;
                dgvallBOM.DataSource = dtProductTreeview;

                int nRowIndex = dgBOMList.Rows.Count;
                if (nRowIndex > 0)
                    dgBOMList.CurrentCell = dgBOMList.Rows[nRowIndex - 1].Cells[0];

                btnexcelexport.Visible = true;
                if (Convert.ToBoolean(LoginForm.GetUserDetails[24]) == true)
                {
                    btnAuthorise.Visible = true;
                }

                fnAuthorised(sNName);

                foreach (DataRow dr in dtProductTreeview.Rows)
                {
                    lExistingTreeviewList.Add(dr["ItemCode"].ToString());
                }
                fnCostDetails();
            }
            else
            {
                fnAuthorised(sNName);
            }
        }


        private void fnCostDetails()
        {
            lblitemcount.Text = dgBOMList.Rows.Count.ToString();

            if (dgBOMList.Rows.Count > 0)
            {
                sTotalAmount = Convert.ToDouble("0.0");
                foreach (DataGridViewRow dgvr in dgBOMList.Rows)
                {
                    sTotalAmount += Convert.ToDouble(dgvr.Cells["Amount"].Value);
                }

                fnTotalAmount(sTotalAmount);
                string text = string.Format(india, "{0:c}", sTotalAmount); // ₹ 3,20,000 
                lblproductcost.Text = text;// sTotalAmount.ToString();

                sTotalAmount = Convert.ToDouble("0.0");
                foreach (DataGridViewRow dgvr in dgBOMList.Rows)
                {
                    sTotalAmount += Convert.ToDouble(dgvr.Cells["BOMQuantity"].Value) * Convert.ToDouble(dgvr.Cells["Unitcost"].Value);
                }

                fnTotalAmount(sTotalAmount);
                text = string.Format(india, "{0:c}", sTotalAmount); // ₹ 3,20,000 
                lblLatestCost.Text = text;// sTotalAmount.ToString();
                lblpcost.Visible = true;
                lblproductcost.Visible = true;
                lbllatest.Visible = true;
                lblLatestCost.Visible = true;
                lbltotalitems.Visible = true;
                lblitemcount.Visible = true;
                txtItemSearch.Visible = true;
                lblItemcodeorName.Visible = true;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblVersion.ForeColor = Color.Red;
            lblVersion.Visible = !lblVersion.Visible;
            _blinkCount++;
            if (_blinkCount == _maxNumberOfBlinks * 2)
            {
                timer1.Stop();
                lblVersion.Visible = true;
            }
        }


        private void chkItemSaerch_CheckedChanged_1(object sender, EventArgs e)
        {
            if (chkItemSaerch.CheckState == CheckState.Checked)
            {
                chkxcelupload.Checked = false;
                pnItemSearch.Visible = true;
                pnexcelupload.Visible = false;
                dgItemList.Visible = true;
                dgvxcelupload.Visible = false;
                btnaddtobom.Visible = false;
            }
        }

        private void chkxcelupload_CheckedChanged_1(object sender, EventArgs e)
        {
            if (chkxcelupload.CheckState == CheckState.Checked)
            {
                chkItemSaerch.Checked = false;
                pnItemSearch.Visible = false;
                pnexcelupload.Visible = true;
                dgvxcelupload.Visible = true;
                dgItemList.Visible = false;
                btnaddtobom.Visible = true;
                lbladditemcount.Text = dgvxcelupload.Rows.Count.ToString();
            }
            else
            {
                dgItemList.Visible = true;
                btnaddtobom.Visible = false;
                dgvxcelupload.Visible = false;
                pnItemSearch.Visible = true;
                pnexcelupload.Visible = false;
            }
        }

        private void txtItemDescription_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);

                    RowFilter();

                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
                    RowFilter();
                }

            }
            else
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);
                    RowFilter();
                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
                    RowFilter();
                }
            }
        }

        private void dgItemList_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if ((dgItemList.CurrentCell.OwningColumn.Name == "Quantity"))
            {
                oldvalue = Convert.ToDouble(dgItemList.CurrentCell.Value);
            }
        }

        private void dgItemList_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (dgItemList.CurrentCell.OwningColumn.Name == "Quantity")
            {
                if (!string.IsNullOrEmpty(dgItemList.CurrentCell.Value.ToString()) && (dgItemList.CurrentCell.Value.ToString() != sDot))// != null)
                {
                    if (Convert.ToDouble(dgItemList.CurrentCell.Value.ToString()) <= 0)
                    {
                        dgItemList.CurrentCell.Value = oldvalue;
                    }
                }
                else
                {
                    MessageBox.Show("Enter a Valid Value", "Error", 0, MessageBoxIcon.Error);
                    dgItemList.CurrentCell.Value = oldvalue;
                }
            }
        }

        private void dgItemList_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress13);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
            }
        }
        List<DataGridViewRow> lcheckedRow = new List<DataGridViewRow>();
        string[] sItemType;
        private void dgItemList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgItemList.CurrentCell.OwningColumn.Name == "add")
            {
                if (!lExistingTreeviewList.Contains(dgItemList.CurrentRow.Cells["ItemCode"].Value.ToString()))
                {
                    if (!lcheckedRow.Contains(dgItemList.CurrentRow))//check wheater the selected item is already present in the folder
                    {
                        lcheckedRow.Add(dgItemList.CurrentRow);
                    }
                    lExistingTreeviewList.Add(dgItemList.CurrentRow.Cells["ItemCode"].Value.ToString());
                    string MfgPartNo = string.Empty;
                    string make = string.Empty;
                    string specification = string.Empty;
                    string Location = string.Empty;
                    string DrawingNo = string.Empty;
                    string Vendorname = string.Empty;

                    string fixedCostStr = dgItemList.CurrentRow.Cells["FixedCost"].Value?.ToString();

                    // Validate FixedCost
                     if (string.IsNullOrWhiteSpace(fixedCostStr) ||    !decimal.TryParse(fixedCostStr, out decimal validatedFixedCost) || validatedFixedCost <= 0.01m)
                        {
                        MessageBox.Show("Fixed cost is not updated. Please get it done by the project managers.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return; // Prevent further execution
                    }

                    //   dtParentAndNodeID = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Parent.Name).Tables["LastNodeId"];
                    //  dtParentAndNodeID = DAL.fnGetTreeNode(tvProduct.SelectedNode.Name, dtParentAndNodeID.Rows[0]["NodeID"].ToString()).Tables[0];
                    //  if (dtParentAndNodeID.Rows.Count > 0)
                    iCurrentParentID = Convert.ToInt32(sName[0]);
                    if (iCurrentParentID != 0)
                    {
                        if (tvProduct.SelectedNode.StateImageIndex == 3)
                        {
                            GLobalClass.iSuccess = DAL.fnAddProductName(Global.uUPDATE, 0, iCurrentParentID, tvProduct.SelectedNode.Name, "2", "", "", "");
                            tvProduct.SelectedNode.StateImageIndex = 2;
                        }
                        //foreach (DataGridViewRow LDGVR in lcheckedRow)
                        //{
                        if (Convert.ToString(dgItemList.CurrentRow.Cells["Quantity"].Value) == string.Empty && Convert.ToString(dgItemList.CurrentRow.Cells["Quantity"].Value) != "0")
                        {
                            dgItemList.CurrentRow.Cells["Quantity"].Value = 1;
                        }

                        if (Convert.ToString(dgItemList.CurrentRow.Cells["MfgPartNo"].Value) == string.Empty || Convert.ToString(dgItemList.CurrentRow.Cells["MfgPartNo"].Value) == null)
                        {
                            MfgPartNo = null;
                        }
                        else
                        {
                            MfgPartNo = dgItemList.CurrentRow.Cells["MfgPartNo"].Value.ToString();
                        }
                        if (Convert.ToString(dgItemList.CurrentRow.Cells["make"].Value) == string.Empty || Convert.ToString(dgItemList.CurrentRow.Cells["make"].Value) == null)
                        {
                            make = null;
                        }
                        else
                        {
                            make = dgItemList.CurrentRow.Cells["make"].Value.ToString();
                        }
                        if (Convert.ToString(dgItemList.CurrentRow.Cells["specification"].Value) == string.Empty || Convert.ToString(dgItemList.CurrentRow.Cells["specification"].Value) == null)
                        {
                            specification = null;
                        }
                        else
                        {
                            specification = dgItemList.CurrentRow.Cells["specification"].Value.ToString();
                        }
                        if (Convert.ToString(dgItemList.CurrentRow.Cells["Location"].Value) == string.Empty || Convert.ToString(dgItemList.CurrentRow.Cells["Location"].Value) == null)
                        {
                            Location = null;
                        }
                        else
                        {
                            Location = dgItemList.CurrentRow.Cells["Location"].Value.ToString();
                        }
                        if (Convert.ToString(dgItemList.CurrentRow.Cells["DrawingNo"].Value) == string.Empty || Convert.ToString(dgItemList.CurrentRow.Cells["DrawingNo"].Value) == null)
                        {
                            DrawingNo = null;
                        }
                        else
                        {
                            DrawingNo = dgItemList.CurrentRow.Cells["DrawingNo"].Value.ToString();
                        }
                        if (Convert.ToString(dgItemList.CurrentRow.Cells["vendorname"].Value) == string.Empty || Convert.ToString(dgItemList.CurrentRow.Cells["vendorname"].Value) == null)
                        {
                            Vendorname = null;
                        }
                        else
                        {
                            Vendorname = dgItemList.CurrentRow.Cells["vendorname"].Value.ToString();
                        }
                        if (Convert.ToString(dgItemList.CurrentRow.Cells["IProductType"].Value) == string.Empty || Convert.ToString(dgItemList.CurrentRow.Cells["IProductType"].Value) == null)
                        {
                            excelProdType = null;
                        }
                        else
                        {
                            sItemType = dgItemList.CurrentRow.Cells["IProductType"].Value.ToString().Split('-');
                            if (sItemType.Length > 1)
                            {
                                if (sItemType[1] == "B")
                                {
                                    excelProdType = "Boughtout";
                                }
                                else if (sItemType[1] == "M")
                                {
                                    excelProdType = "Machining";
                                }
                                else if (sItemType[1] == "BM")
                                {
                                    excelProdType = "BoughtoutMachining";
                                }
                            }
                            else
                            {
                                excelProdType = "Boughtout";
                            }
                        }

                        GLobalClass.iSuccess = DAL.fnAddProductTreeView(Global.uINSERT, iCurrentParentID, dgItemList.CurrentRow.Cells["ItemCode"].Value.ToString(), Convert.ToDouble(dgItemList.CurrentRow.Cells["Quantity"].Value.ToString()),
                                               MfgPartNo, make, specification, Location, Vendorname, DrawingNo, lblbomby.Text, lblbomby.Text, cmbVersion.Text, excelProdType, Convert.ToDecimal(dgItemList.CurrentRow.Cells["FixedCost"].Value.ToString()));


                        if (GLobalClass.iSuccess == 1)
                        {
                            MessageBox.Show("Slected Item added to the '" + tvProduct.SelectedNode.Name + "' BOM successfully", "Success", 0, MessageBoxIcon.Information);

                            cmbVersion_SelectedIndexChanged(sender, e);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Selected item already added in BOM", "Information", 0, MessageBoxIcon.Error);
                }
            }

        }

        private void txtItemDescription_MouseClick(object sender, MouseEventArgs e)
        {
            if (dtItemList.Rows.Count == 0)
            {
                dtItemList = DAL.fnBOMItemList(null).Tables[0];
            }
        }

        private void txtSalesCost_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void btnAddSubProduct_Click(object sender, EventArgs e)
        {
            btnSaveSubProduct.Visible = true;
            btnSaveSubProduct.Text = "Save";
            btnSaveSubProduct.Enabled = true;
            //txtProductCode.ResetText();
            txtProductName.ResetText();
            txtProductCost.ResetText();
        }

        private void btnSaveSubProduct_Click(object sender, EventArgs e)
        {

            if (btnSaveSubProduct.Text == "Save")
            {
                dtNewProductCodeCheck = DAL.fnSalesProductCode(txtProductCode.Text).Tables[0];
                if (dtNewProductCodeCheck.Rows.Count == 0)
                {
                    fnUpadateTreeDetails(Global.uINSERT);
                    btnSaveSubProduct.Enabled = false;
                }
                else
                {
                    MessageBox.Show("Entered new product code alreday used for product '" + dtNewProductCodeCheck.Rows[0]["Name"].ToString() + "'. Please enter a unique product code.", "Information", 0, MessageBoxIcon.Warning);
                }
            }

            else if (btnSaveSubProduct.Text == "Update")
            {
                dtProductCodeCheck = DAL.fnGetPasteSlalesProductTreeNode(0, sName[0].ToString()).Tables[0];
                dtNewProductCodeCheck = DAL.fnSalesProductCode(dtProductCodeCheck.Rows[0]["ProductCode"].ToString().Trim()).Tables[0];
                if (dtProductCodeCheck.Rows.Count < 2)
                {
                    if (dtProductCodeCheck.Rows[0]["ProductCode"].ToString().Trim() != txtProductCode.Text.Trim())
                    {
                        dtNewProductCodeCheck = DAL.fnSalesProductCodeCheck(txtProductCode.Text).Tables[0];
                        if (dtNewProductCodeCheck.Rows.Count == 0)
                        {
                            fnUpadateTreeDetails(Global.uUPDATE);
                            btnSaveSubProduct.Enabled = false;
                        }
                        else
                        {
                            MessageBox.Show("Entered new product code alreday used for product '" + dtNewProductCodeCheck.Rows[0]["Name"].ToString() + "'. Please enter a unique product code.", "Information", 0, MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        fnUpadateTreeDetails(Global.uUPDATE);
                    }
                }
                else
                {
                    MessageBox.Show("Selected Product has duplicate product code. Please contact the admin.", "Information", 0, MessageBoxIcon.Warning);
                }
            }
        }

        private void chkItemCode_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemCode.Checked)
            {
                chkItemDesc.Checked = false;
            }
        }

        private void chkItemDesc_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemDesc.Checked)
            {
                chkItemCode.Checked = false;
            }
        }

        private void dgBOMList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            cmbWorkDescription.Visible = false;
            if (dgBOMList.CurrentCell.ColumnIndex == 0)
            {
                Show_Combobox(dgBOMList.CurrentCell.RowIndex, 0);
            }
        }

        private void cmbWorkDescription_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbWorkDescription.Visible == true)
            {
                if (dgBOMList.CurrentCell.OwningColumn.Name == "ProductType")
                {
                    dgBOMList.CurrentCell.Value = cmbWorkDescription.Text.ToString();
                    cmbWorkDescription.Visible = false;

                    iUpdateParentID = Convert.ToInt32(sName[0]);
                    GLobalClass.iSuccess = DAL.fnAddProductTreeView(6, iUpdateParentID, dgBOMList.CurrentRow.Cells["uItemCode"].Value.ToString(), Convert.ToDouble(dgBOMList.CurrentRow.Cells["BOMQuantity"].Value), null, null, null, null, null, null, null, null,
                                       cmbVersion.Text, dgBOMList.CurrentRow.Cells["ProductType"].Value.ToString(),0);
                }
            }
        }

        private void Show_Combobox(int iRowIndex, int iColumnIndex)
        {
            // DESCRIPTION: SHOW THE COMBO BOX IN THE SELECTED CELL OF THE GRID.
            // PARAMETERS: iRowIndex - THE ROW ID OF THE GRID.
            //             iColumnIndex - THE COLUMN ID OF THE GRID.

            int x = 0;
            int y = 0;
            int Width = 0;
            int height = 0;

            // GET THE ACTIVE CELL'S DIMENTIONS TO BIND THE COMBOBOX WITH IT.
            Rectangle rect = default(Rectangle);
            rect = dgBOMList.GetCellDisplayRectangle(iColumnIndex, iRowIndex, false);
            x = rect.X + dgBOMList.Left;
            y = rect.Y + dgBOMList.Top;

            Width = rect.Width;
            height = rect.Height;

            cmbWorkDescription.SetBounds(x, y, Width, height);
            cmbWorkDescription.Visible = true;
            cmbWorkDescription.DroppedDown = true;
        }

        private void dgItemList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtsearchtree_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
