﻿using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Erp_Project_With_Buttons
{
    public partial class frmPartmaster : Form
    {
        #region Intialization of Local Datatables, Variables Daclaration

        frmForm2 frm = new frmForm2();
        Global GLobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        DataTable dtItemID = new DataTable();
        DataTable dtItemUnit = new DataTable();
        DataTable dtItemList = new DataTable();
        DataTable dtVendorlist = new DataTable();
        DataTable dtItemlocation = new DataTable();
        string[] sItemCode;
        string[] sItemType;
        DataTable dtItemCode = new DataTable();
        DataView dvItemList = new DataView();
        public frmPartmaster()
        {
            InitializeComponent();
        }
        #endregion

        #region Code to Load all Local Variables to Create Item Code
        private void frmPartmaster_Load(object sender, EventArgs e)
        {
            try
            {
                timer1.Interval = 1000;
                timer1.Enabled = true;
                chkItemCode.Checked = true;

                lblReturnedby.Text = login.GetUserDetails[2];
                ckbClickToAddItemsDirectly.Checked = false;

                dtItemUnit = DAL.fnItemUnit(null).Tables[0];
                dtItemlocation = DAL.fnItemUnit("s").Tables[0];

                foreach (DataRow DR in dtItemUnit.Rows)
                {
                    if (!cmbUnit.Items.Contains(DR["Units"].ToString()))
                        cmbUnit.Items.Add(DR["Units"].ToString());
                }

                foreach (DataRow DR in dtItemlocation.Rows)
                {
                    if (!cmblocation.Items.Contains(DR["Location"].ToString()))
                        cmblocation.Items.Add(DR["Location"].ToString());
                }
                chkActive.Checked = true;
                cmbItemType.SelectedIndex = -1;
                cmbUnit.SelectedIndex = 0;
                cmbPurchaseType.SelectedIndex = 0;

                if (login.GetUserDetails[2].ToLower() == "theertha rao" || login.GetUserDetails[2].ToLower() == "mohan")
                {
                    chkUpdateUnitPrice.Visible = true;
                }
                else
                {
                    chkUpdateUnitPrice.Visible = false;
                }
            }
            catch (Exception ex)
            { MessageBox.Show("frmPartmaster_frmPartmaster_Load   " + ex.Message); }
        }
        #endregion

        #region Code to Create Clear the Form
        private void btnClearAll_Click(object sender, EventArgs e)
        {
            ClearTextBoxes(this.Controls);
            cmbItemType.Enabled = true;
            cmbItemType.SelectedIndex = -1;
            cmbBougtMachine.SelectedIndex = -1;
            txtUnitCost.Enabled = true;
            this.ckbClickToAddItemsDirectly.Checked = false;
            lblAvailableQty.Text = "0";
            btnSave.Text = Global.sBUTTON_SAVE_TEXT_ISSAVE;

        }
        #endregion
        string sActive;
        bool bDeactive = true;
        DataTable dtPendingPO = new DataTable();
        DataTable dtDrawingNo = new DataTable();
        #region Code to Create a New Item Code
        private void btnSave_Click(object sender, EventArgs e)
        {
           
            try
            {
                string NowDate = DateTime.Now.ToString("dd-MM-yyyy");
                if (chkActive.Checked == true)
                    sActive = "Active";
                else
                    sActive = "Deactive";
                if (btnSave.Text == Global.sBUTTON_SAVE_TEXT_ISSAVE)
                {
                    if (txtItemDescription.Text != string.Empty && txtUnitCost.Text != string.Empty && cmbItemType.SelectedIndex >= 0 && cmbBougtMachine.SelectedIndex >= 0 && !string.IsNullOrEmpty(txtItemTypeCode.Text)
                        && cmbPurchaseType.Text != string.Empty && cmbUnit.Text != string.Empty && cmbStorageType.SelectedIndex >= 0) //check all required fields are filled or not
                    {
                        if (txtDrawingNo.Text.Length > 0)
                        {
                            dtDrawingNo = DAL.fnItemID(txtDrawingNo.Text.Trim(), null).Tables[0];
                        }

                        dtItemID = DAL.fnItemID(null, null).Tables[0];
                        if (dtItemID.Rows.Count > 0 && dtDrawingNo.Rows.Count == 0)
                        {
                            txtItemCode.Text = string.Concat(txtItemTypeCode.Text, dtItemID.Rows[0][0].ToString());
                            if (login.GetUserDetails[2].ToLower() == "vivek g" || login.GetUserDetails[2].ToLower() == "chethan c v" || login.GetUserDetails[23].ToLower() == "design" || login.GetUserDetails[2].ToLower() == "manoj" || login.GetUserDetails[2].ToLower() == "ravi" || login.GetUserDetails[2].ToLower() == "kumar ravi" || login.GetUserDetails[23].ToLower() == "projects")
                            {
                                if (string.IsNullOrWhiteSpace(txtFixedCost.Text))
                                {
                                    txtFixedCost.Text = "0.01";
                                }
                                GLobalClass.iSuccess = DAL.fnAddItem(Global.uINSERT, txtItemCode.Text.Trim(), txtItemDescription.Text, NowDate,
                                    Convert.ToDouble(txtUnitCost.Text), cmbItemType.Text, sActive, txtRemarks.Text, cmbUnit.Text, txtOthers.Text, 0,
                                    cmbPurchaseType.Text, txtItemTypeCode.Text, lblReturnedby.Text, cmblocation.Text, txtHSNSACCode.Text, txtDrawingNo.Text, cmbStorageType.Text, Convert.ToDecimal(txtFixedCost.Text));//Add new item to the item master database// String.Format("{0:MM/dd/yyyy}", dtpCreatedDate56.Text)
                            }
                            else
                            {

                                GLobalClass.iSuccess = DAL.fnAddItem(Global.uINSERT, txtItemCode.Text.Trim(), txtItemDescription.Text, NowDate,
                                    Convert.ToDouble(txtUnitCost.Text), cmbItemType.Text, sActive, txtRemarks.Text, cmbUnit.Text, txtOthers.Text, 0,
                                    cmbPurchaseType.Text, txtItemTypeCode.Text, lblReturnedby.Text, cmblocation.Text, txtHSNSACCode.Text, txtDrawingNo.Text, cmbStorageType.Text,0);//Add new item to the item master database// String.Format("{0:MM/dd/yyyy}", dtpCreatedDate56.Text)
                            }
                            if (cmbItemType.Text == "Transducers")
                            {
                                GLobalClass.iSuccess = DAL.fnAddKanBanItem(Global.uINSERT, txtItemCode.Text.Trim(), txtItemDescription.Text, string.Empty,
                                    Convert.ToDouble(txtUnitCost.Text), cmbItemType.Text, sActive, txtRemarks.Text, cmbUnit.Text, 0,
                                    cmbPurchaseType.Text, txtItemTypeCode.Text, lblReturnedby.Text, cmblocation.Text, txtHSNSACCode.Text, txtDrawingNo.Text, cmbStorageType.Text);
                            }

                            if (GLobalClass.iSuccess > 0)
                            {
                                GLobalClass.iSuccess = DAL.fnAddERPLog(0, txtItemCode.Text, login.GetUserDetails[2], NowDate, "Item Code Created", "ItemMaster");

                                MessageBox.Show("New item " + txtItemCode.Text + " created successfully", "Success", 0, MessageBoxIcon.Information);

                                if (!cmbUnit.Items.Contains(cmbUnit.Text))
                                {
                                    cmbUnit.Items.Add(cmbUnit.Text);
                                }
                                ClearTextBoxes(this.Controls);
                                cmbItemType.Enabled = true;

                                frmPartmaster PM = new frmPartmaster();
                                this.Hide();
                                PM.Show();

                            }
                        }
                        else
                        {
                            if (dtDrawingNo.Rows.Count > 0)
                            {
                                MessageBox.Show("Entered drawing number already used for a Item '" + dtDrawingNo.Rows[0][0] + "- " + dtDrawingNo.Rows[0][1] + "'", "Error", 0, MessageBoxIcon.Error);
                            }
                        }
                    }
                    else
                    {
                        fnErrorMessage();
                    }
                }
                else
                {
                    txtFixedCost.ReadOnly = true;

                    if (login.GetUserDetails[2].ToLower() == "vivek g" || login.GetUserDetails[2].ToLower() == "chethan c v" || login.GetUserDetails[23].ToLower() == "design" || login.GetUserDetails[2].ToLower() == "manoj" || login.GetUserDetails[2].ToLower() == "ravi" || login.GetUserDetails[2].ToLower() == "kumar ravi" || login.GetUserDetails[23].ToLower() == "projects")
                    {
                        txtFixedCost.Visible = true;
                        label1.Visible = true;
                        txtFixedCost.ReadOnly = false;
                    }
                   



                    if (txtItemDescription.Text != string.Empty && txtUnitCost.Text != "0" && txtItemTypeCode.Text != string.Empty
                        && cmbUnit.Text != string.Empty) //check all required fields are filled or not
                    {
                        if (sActive == "Deactive")
                        {
                            bDeactive = true;
                            dtPendingPO = new DataTable();
                            if (Convert.ToDouble(lblAvailableQty.Text) > 0)
                            {
                                bDeactive = false;
                            }
                            else
                            {
                                bDeactive = true;
                            }

                            if (bDeactive)
                            {
                                dtPendingPO = DAL.fnItemPOPending(txtItemCode.Text).Tables[0];
                                if (dtPendingPO.Rows.Count > 0)
                                {
                                    bDeactive = false;
                                }
                                else
                                {
                                    bDeactive = true;
                                }
                            }
                        }

                        if (txtDrawingNo.Text.Length > 0)
                        {
                            dtDrawingNo = DAL.fnItemID(txtDrawingNo.Text.Trim(), txtItemCode.Text).Tables[0];
                        }
                        if (dtDrawingNo.Rows.Count == 0 && bDeactive)
                        {
                            DataTable dtOldUnitCost = DAL.fnItemList2(txtItemCode.Text).Tables[0];
                            if (dtOldUnitCost.Rows.Count > 0)
                            {
                                if (Convert.ToDouble(dtOldUnitCost.Rows[0]["UnitCost"].ToString()) != Convert.ToDouble(txtUnitCost.Text))
                                {
                                    GLobalClass.iSuccess = DAL.fnAddItemCostHistory(0, txtItemCode.Text, Convert.ToDouble(dtOldUnitCost.Rows[0]["UnitCost"].ToString()),
                                        Convert.ToDouble(txtUnitCost.Text), login.GetUserDetails[2]);
                                }
                            }

                            GLobalClass.iSuccess = DAL.fnAddItem(Global.uUPDATE, txtItemCode.Text, txtItemDescription.Text, string.Empty, Convert.ToDouble(txtUnitCost.Text),
                                cmbItemType.Text, sActive, txtRemarks.Text, cmbUnit.Text, txtOthers.Text, 0, cmbPurchaseType.Text, txtItemTypeCode.Text, lblReturnedby.Text,
                                cmblocation.Text, txtHSNSACCode.Text, txtDrawingNo.Text, cmbStorageType.Text, Convert.ToDecimal(txtFixedCost.Text));

                            //if (cmbItemType.Text == "Transducers")
                            //{
                            //    GLobalClass.iSuccess = DAL.fnAddKanBanItem(4, txtItemCode.Text.Trim(), txtItemDescription.Text, string.Empty,
                            //        Convert.ToDouble(txtUnitCost.Text), cmbItemType.Text, sActive, txtRemarks.Text, cmbUnit.Text, 0,
                            //        cmbPurchaseType.Text, txtItemTypeCode.Text, lblReturnedby.Text, cmblocation.Text, txtHSNSACCode.Text, txtDrawingNo.Text, cmbStorageType.Text);
                            //}
                            if (GLobalClass.iSuccess > 0)
                            {
                                MessageBox.Show(" Item '" + txtItemCode.Text + "' Updated Successfully", "Success", 0, MessageBoxIcon.Information);
                                ClearTextBoxes(this.Controls);
                                btnSave.Text = Global.sBUTTON_SAVE_TEXT_ISSAVE;
                                txtItemCode.ReadOnly = true;
                                txtUnitCost.Enabled = true;
                                cmbItemType.Enabled = true;
                                cmbItemType.SelectedIndex = -1;
                            }
                        }
                        else
                        {
                            if (dtDrawingNo.Rows.Count > 0)
                            {
                                MessageBox.Show("Entered drawing number already used for a Item '" + dtDrawingNo.Rows[0][0] + "'  '" + dtDrawingNo.Rows[0][1] + "'", "Error", 0, MessageBoxIcon.Error);
                            }
                            else if (!bDeactive)
                            {
                                if (dtPendingPO.Rows.Count > 0)
                                {
                                    MessageBox.Show("Selected Item code cannot be deactivated. PO raised on the code", "Error", 0, MessageBoxIcon.Error);
                                }
                                else if (Convert.ToDouble(lblAvailableQty.Text) > 0)
                                {
                                    MessageBox.Show("Selected Item code cannot be deactivated. Item available in stock", "Error", 0, MessageBoxIcon.Error);
                                }
                            }
                        }
                    }
                    else
                    {
                        fnErrorMessage();
                    }
                }

            }
            catch (Exception ex)
            { MessageBox.Show("frmPartmaster_btnSave_Click   " + ex.Message); }
        }
        #endregion

        public void fnErrorMessage()
        {
            //MessageBox.Show("One are more fields are empty (Item description, Unit cost, Item type, Unit, Purchase type]", "Error", 0, MessageBoxIcon.Error);

            if (string.IsNullOrEmpty(txtItemDescription.Text))
            {
                MessageBox.Show("Please enter Item description", "Error", 0, MessageBoxIcon.Error);
                txtItemDescription.Focus();
            }
            else if (string.IsNullOrEmpty(txtUnitCost.Text))
            {
                MessageBox.Show("Please enter Unit cost", "Error", 0, MessageBoxIcon.Error);
                txtUnitCost.Focus();
            }
            else if (cmbItemType.SelectedIndex < 0)
            {
                MessageBox.Show("Please select Item type", "Error", 0, MessageBoxIcon.Error);
                cmbItemType.DroppedDown = true;
            }
            else if (cmbBougtMachine.SelectedIndex < 0)
            {
                MessageBox.Show("Please select Purchase type", "Error", 0, MessageBoxIcon.Error);
                cmbBougtMachine.DroppedDown = true;
            }
            else if (cmbStorageType.SelectedIndex < 0)
            {
                MessageBox.Show("Please select storage type", "Error", 0, MessageBoxIcon.Error);
                cmbStorageType.DroppedDown = true;
            }
        }

        #region Function to Clear all TextBoxes
        private void ClearTextBoxes(Control.ControlCollection ClearAll)
        {
            foreach (Control ctrl in ClearAll)
            {
                TextBox tb = ctrl as TextBox;
                if (tb != null)
                    tb.Text = string.Empty;
                else
                    ClearTextBoxes(ctrl.Controls);
            }
        }
        #endregion

        #region Code to Check FLoating Number
        private void txtUnit_KeyUp(object sender, KeyEventArgs e)
        {
            GLobalClass.fnIsFloatingNumber(txtUnitCost);
        }

        private void txtUnitCost_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtUnitCost.Text))
                txtUnitCost.Text = "0.01";
        }
        #endregion

        #region Code to Exit the Form
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm.Show();
        }


        private void frmPartmaster_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            frm.Show();
        }
        #endregion

        #region Code to Load Item Type to Create Item Code
        private void cmbItemType_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            cmbBougtMachine.SelectedIndex = -1;
            switch (cmbItemType.Text)
            {
                //case "Chennai Stock":
                //    txtItemTypeCode.Text = "CHE";
                //    break;

                case "Mechanical":
                    txtItemTypeCode.Text = "MEC";
                    break;

                case "TGT":
                    txtItemTypeCode.Text = "TGT";
                    break;

                case "Hydraulics":
                    txtItemTypeCode.Text = "HYD";
                    break;

                case "Transducers":
                    txtItemTypeCode.Text = "TRS";
                    break;

                case "Tools":
                    txtItemTypeCode.Text = "TLS";
                    break;

                case "Electronics":
                    txtItemTypeCode.Text = "ELC";
                    break;
                case "Electronics RnD":
                    txtItemTypeCode.Text = "RND";
                    break;
                case "Electricals":
                    txtItemTypeCode.Text = "ELE";
                    break;

                case "KanBan":
                    txtItemTypeCode.Text = "KAN";
                    break;
                case "Maintenance":
                    txtItemTypeCode.Text = "MNT";
                    break;

                case "Consumable":
                    txtItemTypeCode.Text = "CON";
                    break;

                case "FixedAsset":
                    txtItemTypeCode.Text = "FA";
                    break;

                case "Service(Non-Inventory)":
                    txtItemTypeCode.Text = "SER";
                    break;
                case "Testlab":
                    txtItemTypeCode.Text = "TEL";
                    break;
                case "Packing Materials":
                    txtItemTypeCode.Text = "PM";
                    break;


                //added by bhavya----------
                case "LFA Dynamics":
                    txtItemTypeCode.Text = "DYN";
                    break;

                case "LFA – Machines":
                    txtItemTypeCode.Text = "LFA";
                    break;
                case "HFA- Machines":
                    txtItemTypeCode.Text = "HFA";
                    break;
                case "OTC–Accessories":
                    txtItemTypeCode.Text = "OTC";
                    break;
                case "Service Spares":
                    txtItemTypeCode.Text = "PRT";
                    break;
                case "Consumable- Non-Inventory":
                    txtItemTypeCode.Text = "NOI";
                    break;
                //case "CEAST – Machines":
                //    txtItemTypeCode.Text = "CEAST";
                //    break;


                case "DTM- Drop tower Machines":
                    txtItemTypeCode.Text = "DTM";
                    break;

                case "PTI- Plastic testing Machines":
                    txtItemTypeCode.Text = "PTI";
                    break;

                case "OTC – US":
                    txtItemTypeCode.Text = "OTU";
                    break;

                case "OTC – UK":
                    txtItemTypeCode.Text = "OTK";
                    break;

                case "OTC – Italy":
                    txtItemTypeCode.Text = "OTI";
                    break;

                case "OTC – SG":
                    txtItemTypeCode.Text = "OTS";
                    break;

                case "OTC – Germany":
                    txtItemTypeCode.Text = "OTG";
                    break;

                case "Civil work":
                    txtItemTypeCode.Text = "CIV";
                    break;
                    //------------------------------
            }
        }
        #endregion

        #region Code to Validate Item Code & Item Description Entered
        private void txtItemCode_KeyUp(object sender, KeyEventArgs e)
        {
            GLobalClass.fnTextBoxValidation(txtItemCode);
        }

        private void txtItemDescription_KeyUp(object sender, KeyEventArgs e)
        {
            GLobalClass.fnTextBoxValidation(txtItemDescription);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lbltime.Text = DateTime.Now.ToString("hh:mm:ss tt");
        }

        private void txtItemDescription_Leave(object sender, EventArgs e)
        {
            txtItemDescription.Text = txtItemDescription.Text.Replace(",", " ");
        }
        #endregion

        #region Code to Enable the Item Update
        private void ckbClickToAddItemsDirectly_CheckedChanged(object sender, EventArgs e)
        {
            if (ckbClickToAddItemsDirectly.Checked == true)
            {
                txtsearchitemdesc.Enabled = true;
                chklbItemList.Enabled = true;
                btnUpdateItem.Enabled = true;
                btnNewItemCode.Visible = true;
                pnworkorder.Enabled = true;
                txtUnitCost.Enabled = false;
                if (login.GetUserDetails[2].ToLower() == "vivek g" || login.GetUserDetails[2].ToLower() == "chethan c v" || login.GetUserDetails[23].ToLower() == "design" || login.GetUserDetails[2].ToLower() == "manoj" || login.GetUserDetails[2].ToLower() == "ravi" || login.GetUserDetails[2].ToLower() == "kumar ravi" || login.GetUserDetails[23].ToLower() == "projects")
                {
                    txtFixedCost.Enabled = true;
                    txtFixedCost.ReadOnly = false;
                }
              txtFixedCost.Enabled = false;
                txtFixedCost.ReadOnly = true;

            }
            else
            {
                txtsearchitemdesc.Enabled = false;
                chklbItemList.Enabled = false;
                btnUpdateItem.Enabled = false;
                btnNewItemCode.Visible = false;
                pnworkorder.Enabled = false;
                txtUnitCost.Enabled = true;
                btnClearAll_Click(sender, e);
            }
        }
        #endregion

        #region Code to Show Type of Items On Selection Changed
        private void cmbupdateitemtype_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        #endregion

        #region Code to Load Selected Item From CheckListBox
        private void chklbItemList_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            if (!chklbItemList.CheckedItems.Contains(chklbItemList.SelectedItem))
            {
                sItemCode = chklbItemList.SelectedItem.ToString().Trim().Split(')');
                string sID = sItemCode[0];
                dtItemCode = DAL.fnItemMasterList(sID).Tables[0];

                if (dtItemCode.Rows.Count > 0)
                {
                    txtItemCode.Text = dtItemCode.Rows[0]["ItemCode"].ToString();

                    sItemType = txtItemCode.Text.Trim().Split('-');
                    ////if (sItemType[1] == "B")
                    ////{
                    ////    cmbBougtMachine.SelectedIndex = 0;
                    ////}
                    ////else if (sItemType[1] == "M")
                    ////{
                    ////    cmbBougtMachine.SelectedIndex = 1;
                    ////}
                    ////else if (sItemType[1] == "BM")
                    ////{
                    ////    cmbBougtMachine.SelectedIndex = 2;
                    ////}
                    ////else
                    ////{
                    ////    cmbBougtMachine.SelectedIndex = 0;
                    ////}
                    txtItemDescription.Text = dtItemCode.Rows[0]["ItemDescription"].ToString();
                    if (!string.IsNullOrEmpty(dtItemCode.Rows[0]["TypeofStorage"].ToString()))
                    {
                        cmbStorageType.SelectedItem = dtItemCode.Rows[0]["TypeofStorage"].ToString();
                    }
                    else
                    {
                        cmbStorageType.SelectedIndex = -1;
                    }
                    cmbUnit.Text = dtItemCode.Rows[0]["Units"].ToString();
                    txtRemarks.Text = dtItemCode.Rows[0]["Remarks"].ToString();
                    txtUnitCost.Text = dtItemCode.Rows[0]["UnitCost"].ToString();
                    txtOthers.Text = dtItemCode.Rows[0]["Others"].ToString();
                    lblAvailableQty.Text = dtItemCode.Rows[0]["AvailableQty"].ToString();
                    cmbItemType.Text = dtItemCode.Rows[0]["Type"].ToString();
                    cmblocation.Text = dtItemCode.Rows[0]["Location"].ToString();
                    txtItemTypeCode.Text = dtItemCode.Rows[0]["ItemTypeCode"].ToString();
                    cmbPurchaseType.Text = dtItemCode.Rows[0]["PurchaseType"].ToString();
                    txtHSNSACCode.Text = dtItemCode.Rows[0]["HSNSACCode"].ToString();
                    txtDrawingNo.Text = dtItemCode.Rows[0]["DrawingNo"].ToString();
                    txtFixedCost.Text = dtItemCode.Rows[0]["FixedCost"].ToString();
                    if (dtItemCode.Rows[0]["Status"].ToString() == "Active")
                        chkActive.Checked = true;
                    else if (dtItemCode.Rows[0]["Status"].ToString() == "Deactive")
                        chkActive.Checked = false;


                    chkActive.Enabled = false;
                    if (login.GetUserDetails[2].ToLower() == "muthuramalingam" || login.GetUserDetails[2].ToLower() == "theertha rao")
                    {
                        chkActive.Enabled = true;
                    }



                    txtItemCode.ReadOnly = true;
                    txtItemTypeCode.Enabled = false;
                    cmbItemType.Enabled = false;
                    
                    btnSave.Text = Global.sBUTTON_SAVE_TEXT_ISUPDATE;
                    if (login.GetUserDetails[2].ToLower() == "vivek g" || login.GetUserDetails[2].ToLower() == "chethan c v" || login.GetUserDetails[23].ToLower() == "design" || login.GetUserDetails[2].ToLower() == "manoj" || login.GetUserDetails[2].ToLower() == "ravi" || login.GetUserDetails[2].ToLower() == "kumar ravi" || login.GetUserDetails[23].ToLower() == "projects")

                    {
                        txtFixedCost.Enabled = true;
                        txtFixedCost.Visible = true;
                        label1.Visible = true;
                        txtFixedCost.ReadOnly = false;
                    }


                }
            }
            else
            {

            }
        }
        #endregion

        #region Function to Filter Options to Select a Item


        private void RowFilter()
        {
            chklbItemList.Items.Clear();
            foreach (DataRowView dv in dvItemList)
            {
                chklbItemList.Items.Add(string.Concat(dv[17].ToString(), ") ", dv[0].ToString(), ", ", dv[1].ToString(), ", ", dv[12].ToString()));
            }
        }

        private void txtsearchitemdesc_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtsearchitemdesc.Text);
                    RowFilter();
                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtsearchitemdesc.Text);
                    RowFilter();
                }
            }
            else
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 0, txtsearchitemdesc.Text);
                    RowFilter();
                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GLobalClass.RowFilter(dtItemList, 1, txtsearchitemdesc.Text);
                    RowFilter();
                }

            }
        }


        private void txtsearchitemdesc_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar == '%'))
            {
                e.Handled = true;
            }
        }
        #endregion

        private void chkItemCode_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemCode.CheckState == CheckState.Checked)
            {
                chkItemDesc.Checked = false;
            }
        }

        private void chkItemDesc_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemDesc.CheckState == CheckState.Checked)
            {
                chkItemCode.Checked = false;
            }
        }

        private void cmbBougtMachine_SelectedIndexChanged(object sender, EventArgs e)
        {
            string[] sItemType;
            sItemType = txtItemTypeCode.Text.Split('-');

            switch (cmbBougtMachine.Text)
            {
                case "Boughtout":
                    txtItemTypeCode.Text = sItemType[0] + "-B-";
                    break;
                case "Machining":
                    txtItemTypeCode.Text = sItemType[0] + "-M-";
                    break;
                case "BoughtoutMachining":
                    txtItemTypeCode.Text = sItemType[0] + "-BM-";
                    break;
            }
        }

        private void btnUpdateItem_Click(object sender, EventArgs e)
        {
            dtItemList = DAL.fnItemMasterLoadList(null).Tables[0];
        }

        private void btnNewItemCode_Click(object sender, EventArgs e)
        {
            if (chkActive.Checked == true)
                sActive = "Active";
            else
                sActive = "Deactive";

            if (txtItemDescription.Text != string.Empty && txtUnitCost.Text != string.Empty && cmbItemType.Text != string.Empty && cmbBougtMachine.Text != string.Empty && txtItemTypeCode.Text != string.Empty
                    && cmbItemType.Text != string.Empty && cmbPurchaseType.Text != string.Empty && cmbUnit.Text != string.Empty) //check all required fields are filled or not
            {
                if (txtDrawingNo.Text.Length > 0)
                {
                    dtDrawingNo = DAL.fnItemID(txtDrawingNo.Text.Trim(), null).Tables[0];
                }

                dtItemID = DAL.fnItemID(null, null).Tables[0];
                if (dtItemID.Rows.Count > 0 && dtDrawingNo.Rows.Count == 0)
                {
                    txtItemCode.Text = string.Concat(txtItemTypeCode.Text, dtItemID.Rows[0][0].ToString());
                    GLobalClass.iSuccess = DAL.fnAddItem(Global.uINSERT, txtItemCode.Text.Trim(), txtItemDescription.Text, string.Empty,
                        Convert.ToDouble(txtUnitCost.Text), cmbItemType.Text, sActive, txtRemarks.Text, cmbUnit.Text, txtOthers.Text, 0,
                        cmbPurchaseType.Text, txtItemTypeCode.Text, lblReturnedby.Text, cmblocation.Text, txtHSNSACCode.Text, txtDrawingNo.Text, cmbStorageType.Text,0);//Add new item to the item master database// String.Format("{0:MM/dd/yyyy}", dtpCreatedDate56.Text)
                    if (GLobalClass.iSuccess > 0)
                    {
                        MessageBox.Show("New item " + txtItemCode.Text + " Inserted Successfully", "Success", 0, MessageBoxIcon.Information);
                        if (!cmbUnit.Items.Contains(cmbUnit.Text))
                        {
                            cmbUnit.Items.Add(cmbUnit.Text);
                        }
                        ClearTextBoxes(this.Controls);
                        cmbItemType.Enabled = true;
                    }
                }
                else
                {
                    if (dtDrawingNo.Rows.Count > 0)
                    {
                        MessageBox.Show("Entered drawing number already used for a Item '" + dtDrawingNo.Rows[0][0] + "- " + dtDrawingNo.Rows[0][1] + "'", "Error", 0, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                fnErrorMessage();
            }
        }

        private void chkActive_CheckedChanged(object sender, EventArgs e)
        {
            if (chkActive.Checked)
            {
                chkActive.Text = "Active";
                chkActive.ForeColor = Color.Black;
            }
            else
            {
                chkActive.Text = "DeActive";
                chkActive.ForeColor = Color.Red;
            }
        }

        private void cbWorkOrder_CheckedChanged(object sender, EventArgs e)
        {
            if (cbWorkOrder.Checked)
            {
                pnMain.Enabled = false;
            }
            else
            {
                pnMain.Enabled = true;
            }

        }

        private void btnItemCode_Click(object sender, EventArgs e)
        {
            // if (chkActive.Checked == true)
            sActive = "Active";
            //  else
            //    sActive = "Deactive";
            if (cmbProcess.SelectedIndex != -1)
            {
                if (txtItemDescription.Text != string.Empty && txtUnitCost.Text != string.Empty && cmbItemType.Text != string.Empty && txtItemTypeCode.Text != string.Empty
                        && cmbItemType.Text != string.Empty && cmbPurchaseType.Text != string.Empty && cmbUnit.Text != string.Empty) //check all required fields are filled or not
                {
                    string NowDate = DateTime.Now.ToString("dd-MM-yyyy");
                    //    if (txtDrawingNo.Text.Length > 0)
                    //    {
                    //        dtDrawingNo = DAL.fnItemID(txtDrawingNo.Text.Trim(), null).Tables[0];
                    //    }

                    //    dtItemID = DAL.fnItemID(null, null).Tables[0];

                    txtItemCode.Text = string.Concat(txtItemCode.Text, "-", cmbProcess.Text.Substring(0, 1));
                    GLobalClass.iSuccess = DAL.fnAddItem(Global.uINSERT, txtItemCode.Text.Trim(), (txtItemDescription.Text + " - " + cmbProcess.Text), string.Empty,
                        Convert.ToDouble(1), cmbItemType.Text, sActive, txtRemarks.Text, cmbUnit.Text, txtOthers.Text, 0,
                        cmbPurchaseType.Text, txtItemTypeCode.Text, lblReturnedby.Text, cmblocation.Text, txtHSNSACCode.Text, "", null,0);//Add new item to the item master database// String.Format("{0:MM/dd/yyyy}", dtpCreatedDate56.Text)
                    if (GLobalClass.iSuccess > 0)
                    {
                        GLobalClass.iSuccess = DAL.fnAddERPLog(0, txtItemCode.Text, login.GetUserDetails[2], NowDate, "Item Code Created", "ItemMaster");
                        MessageBox.Show("New work order item " + txtItemCode.Text + " created successfully", "Success", 0, MessageBoxIcon.Information);
                        if (!cmbUnit.Items.Contains(cmbUnit.Text))
                        {
                            cmbUnit.Items.Add(cmbUnit.Text);
                        }
                        ClearTextBoxes(this.Controls);
                        cmbItemType.Enabled = true;
                    }

                }
                else
                {
                    fnErrorMessage();
                }
            }
            else
            {
                MessageBox.Show("Please select a work order process to create item code", "Error", 0, MessageBoxIcon.Error);
            }
        }

        private void chkExcelUpload_CheckedChanged(object sender, EventArgs e)
        {
            if (chkExcelUpload.CheckState == CheckState.Checked)
            {
                pnMain.Visible = false;
                btnUpload.Enabled = true;
                pnExcelItemCode.Visible = true;
            }
            else
            {
                pnMain.Visible = true;
                pnExcelItemCode.Visible = false;
            }
        }

        private void btnExcelSave_Click(object sender, EventArgs e)
        {

        }

        private void btnbrowse_Click(object sender, EventArgs e)
        {
            txtbrowseaddres.ResetText();
            openFileDialog1.Filter = "Excel Files (*.xls)|*.xls";
            openFileDialog1.InitialDirectory = @"c:\";
            openFileDialog1.FileName = "Select File";
            openFileDialog1.Title = "Select excel file..";
            openFileDialog1.ShowDialog();
        }
        DataTable dtExcelImport = new DataTable();
        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            txtbrowseaddres.Text = openFileDialog1.FileName;

            if (chkUpdateUnitPrice.CheckState == CheckState.Checked)
            {
                if (!string.IsNullOrEmpty(txtbrowseaddres.Text))
                {
                    try
                    {
                        string smessageItemCode = string.Empty;
                        string str = string.Empty;
                        dtExcelImport = new DataTable();
                        string sheetname = "";
                        string constr = "Provider = Microsoft.Jet.OLEDB.4.0; Data Source=" + txtbrowseaddres.Text + ";Extended Properties= \"Excel 8.0;HDR=YES;\";";
                        OleDbConnection con = new OleDbConnection(constr);
                        con.Open();
                        DataTable Sheets = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

                        foreach (DataRow dr in Sheets.Rows)
                        {
                            sheetname = dr[2].ToString().Replace("'", "");
                            break;
                        }
                        if (!string.IsNullOrEmpty(sheetname))
                        {
                            OleDbDataAdapter sda = new OleDbDataAdapter("select * from [" + sheetname + "]", con);
                            sda.Fill(dtExcelImport);
                        }
                        con.Close();
                        if (dtExcelImport.Rows.Count > 0 && dtExcelImport.Columns.Count == 3 && !string.IsNullOrEmpty(dtExcelImport.Rows[0][0].ToString()))
                        {
                            for (int i = 0; i < dtExcelImport.Columns.Count; i++)
                            {
                                switch (i)
                                {
                                    case 0:
                                        str = "slno";
                                        break;
                                    case 1:
                                        str = "ItemType";
                                        break;
                                    case 2:
                                        str = "UnitCost";
                                        break;
                                }
                                dtExcelImport.Columns[i].ColumnName = str;
                            }

                            for (int i = dtExcelImport.Rows.Count - 1; i >= 0; i--)
                            {
                                if (dtExcelImport.Rows[i][1] == DBNull.Value)
                                    dtExcelImport.Rows[i].Delete();
                            }
                            dtExcelImport.AcceptChanges();

                            for (int i = 0; i < dtExcelImport.Rows.Count; i++)
                            {
                                string sItemCodex = dtExcelImport.Rows[i]["ItemType"].ToString();
                                DataTable dtItemSearch = DAL.fnItemListItemsearch(sItemCodex).Tables[0];

                                if (dtItemSearch.Rows.Count > 0)
                                {
                                    dtExcelImport.Rows[i]["ItemType"] = dtItemSearch.Rows[0]["ItemCode"].ToString();

                                    if (string.IsNullOrEmpty(dtExcelImport.Rows[i]["UnitCost"].ToString()) || Convert.ToDouble(dtExcelImport.Rows[i]["UnitCost"].ToString()) == 0.0)
                                    {
                                        dtExcelImport.Rows[i]["UnitCost"] = "0";
                                    }
                                }
                                else
                                {
                                    dtExcelImport.Rows.RemoveAt(i);
                                    i--;
                                    if (smessageItemCode.Length > 0)
                                    {
                                        smessageItemCode += "," + sItemCodex.ToString();
                                    }
                                    else
                                    {
                                        smessageItemCode = sItemCodex.ToString();
                                    }
                                }
                            }
                            if (dtExcelImport.Rows.Count > 0)
                            {
                                btnUpload.Enabled = true;
                                dgvxcelupload.AutoGenerateColumns = false;
                                dgvxcelupload.DataSource = dtExcelImport;

                                if (smessageItemCode.Length > 0)
                                {
                                    MessageBox.Show("The listed drawing number item(s) are not exist in item master \n " + smessageItemCode + "");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Uploaded Excel file not contains any valid details matching with the Item master requirements. \n\n Please note these columns are mandatory to fill. \n ItemType \n ItemDescription \n Unit \n PurchaseType ", "Error", 0, MessageBoxIcon.Error);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Uploaded Excel file is not in expected format.\n 1) Excel file should contain 3 columns with Names on the first Row \n 2) Items details to be start from the Second Row ", "Error", 0, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("btnUpload_Click" + ex.Message);
                    }
                }
            }
            else
            {

                if (!string.IsNullOrEmpty(txtbrowseaddres.Text))
                {
                    try
                    {
                        string smessageItemCode = string.Empty;
                        string str = string.Empty;
                        dtExcelImport = new DataTable();
                        string sheetname = "";
                        string constr = "Provider = Microsoft.Jet.OLEDB.4.0; Data Source=" + txtbrowseaddres.Text + ";Extended Properties= \"Excel 8.0;HDR=YES;\";";
                        OleDbConnection con = new OleDbConnection(constr);
                        con.Open();
                        DataTable Sheets = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

                        foreach (DataRow dr in Sheets.Rows)
                        {
                            sheetname = dr[2].ToString().Replace("'", "");
                            break;
                        }
                        if (!string.IsNullOrEmpty(sheetname))
                        {
                            OleDbDataAdapter sda = new OleDbDataAdapter("select * from [" + sheetname + "]", con);
                            sda.Fill(dtExcelImport);
                        }
                        con.Close();
                        if (dtExcelImport.Rows.Count > 0 && dtExcelImport.Columns.Count == 9 && !string.IsNullOrEmpty(dtExcelImport.Rows[0][0].ToString()))
                        {
                            for (int i = 0; i < dtExcelImport.Columns.Count; i++)
                            {
                                switch (i)
                                {
                                    case 0:
                                        str = "slno";
                                        break;
                                    case 1:
                                        str = "ItemType";
                                        break;
                                    case 2:
                                        str = "ItemDesc";
                                        break;
                                    case 3:
                                        str = "UnitCost";
                                        break;
                                    case 4:
                                        str = "Type";
                                        break;
                                    case 5:
                                        str = "DrawingNo";
                                        break;
                                    case 6:
                                        str = "Unit";
                                        break;
                                    case 7:
                                        str = "PurchaseType";
                                        break;
                                    case 8:
                                        str = "xHsnCode";
                                        break;
                                }
                                dtExcelImport.Columns[i].ColumnName = str;
                            }

                            for (int i = dtExcelImport.Rows.Count - 1; i >= 0; i--)
                            {
                                if (dtExcelImport.Rows[i][1] == DBNull.Value || dtExcelImport.Rows[i][2] == DBNull.Value || dtExcelImport.Rows[i][6] == DBNull.Value || dtExcelImport.Rows[i][7] == DBNull.Value
                                    || string.IsNullOrEmpty(dtExcelImport.Rows[i][1].ToString()) || string.IsNullOrEmpty(dtExcelImport.Rows[i][2].ToString()) || string.IsNullOrEmpty(dtExcelImport.Rows[i][6].ToString()) || string.IsNullOrEmpty(dtExcelImport.Rows[i][7].ToString()))
                                {
                                    dtExcelImport.Rows[i].Delete();
                                }
                            }
                            dtExcelImport.AcceptChanges();
                            DataTable dtItemSearch = new DataTable();
                            for (int i = 0; i < dtExcelImport.Rows.Count; i++)
                            {
                                string sItemCodex = dtExcelImport.Rows[i]["DrawingNo"].ToString().Trim();
                                dtItemSearch = DAL.fnItemID(sItemCodex, null).Tables[0];

                                if (dtItemSearch.Rows.Count == 0)
                                {
                                    if (string.IsNullOrEmpty(dtExcelImport.Rows[i]["UnitCost"].ToString()) || Convert.ToDouble(dtExcelImport.Rows[i]["UnitCost"].ToString()) == 0.0)
                                    {
                                        dtExcelImport.Rows[i]["UnitCost"] = "0.01";
                                    }
                                }
                                else
                                {
                                    if (!string.IsNullOrEmpty(sItemCodex))
                                    {
                                        dtExcelImport.Rows.RemoveAt(i);
                                        i--;
                                        if (smessageItemCode.Length > 0)
                                        {
                                            smessageItemCode += "," + sItemCodex.ToString();
                                        }
                                        else
                                        {
                                            smessageItemCode = sItemCodex.ToString();
                                        }
                                    }
                                    else
                                    {
                                        if (string.IsNullOrEmpty(dtExcelImport.Rows[i]["UnitCost"].ToString()) || Convert.ToDouble(dtExcelImport.Rows[i]["UnitCost"].ToString()) == 0.0)
                                        {
                                            dtExcelImport.Rows[i]["UnitCost"] = "0.01";
                                        }
                                    }
                                }
                            }

                            if (dtExcelImport.Rows.Count > 0)
                            {
                                btnUpload.Enabled = true;
                                dgvxcelupload.AutoGenerateColumns = false;
                                dgvxcelupload.DataSource = dtExcelImport;

                                if (smessageItemCode.Length > 0)
                                {
                                    MessageBox.Show("The listed drawing number item(s) are already exist in item master \n " + smessageItemCode + "");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Uploaded Excel file not contains any valid details matching with the Item master requirements. \n\n Please note these columns are mandatory to fill. \n ItemType \n ItemDescription \n Unit \n PurchaseType ", "Error", 0, MessageBoxIcon.Error);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Uploaded Excel file is not in expected format.\n 1) Excel file should contain 13 columns with Names on the first Row \n 2) Items details to be start from the Second Row ", "Error", 0, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("btnUpload_Click" + ex.Message);
                    }
                }
                else
                {
                    //  btnaddtobom.Enabled = false;
                    MessageBox.Show("Please Select Excel File to Upload the Items", "Warning", 0, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            if (chkUpdateUnitPrice.CheckState == CheckState.Checked)
            {
                bool bwrongvalue = false;

                if (dgvxcelupload.Rows.Count > 0)
                {
                    foreach (DataGridViewRow dr in dgvxcelupload.Rows)
                    {
                        if (Convert.ToDouble(dr.Cells["xUnitCost"].Value.ToString()) <= 0)
                        {
                            bwrongvalue = true;
                            break;
                        }
                    }
                    if (!bwrongvalue)
                    {
                        foreach (DataGridViewRow dr in dgvxcelupload.Rows)
                        {
                            DataTable dtOldUnitCost = DAL.fnItemList2(dr.Cells["xItemType"].Value.ToString().Trim()).Tables[0];
                            if (dtOldUnitCost.Rows.Count > 0)
                            {
                                GLobalClass.iSuccess = DAL.fnAddItemCostHistory(0, dr.Cells["xItemType"].Value.ToString().Trim(), Convert.ToDouble(dtOldUnitCost.Rows[0]["UnitCost"].ToString()),
                                    Convert.ToDouble(dr.Cells["xUnitCost"].Value.ToString()), login.GetUserDetails[2]);
                            }

                            GLobalClass.iSuccess = DAL.fnAddItem(5, dr.Cells["xItemType"].Value.ToString().Trim(), "", string.Empty,
                                    Convert.ToDouble(dr.Cells["xUnitCost"].Value.ToString()), "", "", "", "", txtOthers.Text, 0,
                                   "", "", login.GetUserDetails[2], "", "", "", null,0);//Add new item to the item master database// String.Format("{0:MM/dd/yyyy}", dtpCreatedDate56.Text)


                        }

                        //foreach (DataGridViewRow dr in dgvxcelupload.Rows)
                        //{
                        //    DataTable dtOldUnitCost = DAL.fnItemList2(dr.Cells["xItemType"].Value.ToString().Trim()).Tables[0];
                        //    if (dtOldUnitCost.Rows.Count > 0)
                        //    {
                        //        GLobalClass.iSuccess = DAL.fnAddItemCostHistory(0, dr.Cells["xItemType"].Value.ToString().Trim(), Convert.ToDouble(dtOldUnitCost.Rows[0]["UnitCost"].ToString()),
                        //            Convert.ToDouble(dr.Cells["xUnitCost"].Value.ToString()), login.GetUserDetails[2]);
                        //    }

                        //    GLobalClass.iSuccess = DAL.fnAddItem(6, dr.Cells["xItemType"].Value.ToString().Trim(), "", string.Empty,
                        //            Convert.ToDouble(dr.Cells["xUnitCost"].Value.ToString()), "", "", "", "", txtOthers.Text, 0,
                        //           "", "", login.GetUserDetails[2], "", "", "", null);//Add new item to the item master database// String.Format("{0:MM/dd/yyyy}", dtpCreatedDate56.Text)


                        //}

                        //foreach (DataGridViewRow dr in dgvxcelupload.Rows)
                        //{
                        //    DataTable dtOldUnitCost = DAL.fnItemList2(dr.Cells["xItemType"].Value.ToString().Trim()).Tables[0];
                        //    if (dtOldUnitCost.Rows.Count > 0)
                        //    {
                        //        GLobalClass.iSuccess = DAL.fnAddItemCostHistory(0, dr.Cells["xItemType"].Value.ToString().Trim(), Convert.ToDouble(dtOldUnitCost.Rows[0]["UnitCost"].ToString()),
                        //            Convert.ToDouble(dr.Cells["xUnitCost"].Value.ToString()), login.GetUserDetails[2]);
                        //    }

                        //    GLobalClass.iSuccess = DAL.fnAddItem(7, dr.Cells["xItemType"].Value.ToString().Trim(), "", string.Empty,
                        //            Convert.ToDouble(dr.Cells["xUnitCost"].Value.ToString()), "", "", "", "", txtOthers.Text, 0,
                        //           "", "", login.GetUserDetails[2], "", "", "", null);//Add new item to the item master database// String.Format("{0:MM/dd/yyyy}", dtpCreatedDate56.Text)


                        //}

                        if (GLobalClass.iSuccess > 0)
                        {
                            MessageBox.Show("Item Codes Unit Price updates successfully", "Success", 0, MessageBoxIcon.Information);
                            dgvxcelupload.DataSource = null;
                            btnUpload.Enabled = false;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please Enter Unit cost to Update the unit cost", "Warning", 0, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("Please Select Excel File to Upload the Items", "Warning", 0, MessageBoxIcon.Warning);
                }
            }
            else
            {
                sActive = "Active";
                if (dgvxcelupload.Rows.Count > 0)
                {
                    bool bwrongvalue = false;
                    foreach (DataGridViewRow dr in dgvxcelupload.Rows)
                    {
                        if ((dr.Cells["xItemDesc"].Value) == null)
                        {
                            bwrongvalue = true;
                            break;
                        }
                    }
                    if (!bwrongvalue)
                    {
                        foreach (DataGridViewRow dr in dgvxcelupload.Rows)
                        {
                            dtItemID = DAL.fnItemID(null, null).Tables[0];
                            if (dtItemID.Rows.Count > 0)
                            {
                                // txtItemCode.Text = string.Concat(txtItemTypeCode.Text, dtItemID.Rows[0][0].ToString());
                                string sItemCode = string.Concat(dr.Cells["xItemType"].Value.ToString().Trim(), "-", dtItemID.Rows[0][0].ToString());
                                string sRemarks = "";
                                string sDrawingNumber = dr.Cells["xDrawingNo"].Value.ToString().Trim();
                                GLobalClass.iSuccess = DAL.fnAddItem(Global.uINSERT, sItemCode.Trim().ToUpper(), (dr.Cells["xItemDesc"].Value.ToString().Trim()), string.Empty,
                                    Convert.ToDouble(dr.Cells["xUnitCost"].Value.ToString()), dr.Cells["xType"].Value.ToString().Trim(), sActive, sRemarks, dr.Cells["xUnits"].Value.ToString(), txtOthers.Text, 0,
                                   dr.Cells["xPurchaseType"].Value.ToString().Trim(), dr.Cells["xItemType"].Value.ToString().Trim(), login.GetUserDetails[2], "", dr.Cells["xHsnCode"].Value.ToString(), sDrawingNumber, null,0);//Add new item to the item master database// String.Format("{0:MM/dd/yyyy}", dtpCreatedDate56.Text)

                            }
                        }
                        if (GLobalClass.iSuccess > 0)
                        {
                            MessageBox.Show("Item Codes created successfully", "Success", 0, MessageBoxIcon.Information);
                            dgvxcelupload.DataSource = null;
                            btnUpload.Enabled = false;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please Select Proper Excel File to create item codes", "Warning", 0, MessageBoxIcon.Warning);
                    }
                }
                else
                {
                    MessageBox.Show("Please Select Excel File to Upload the Items", "Warning", 0, MessageBoxIcon.Warning);
                }
            }
        }

        private void cmbProcess_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtsearchitemdesc_MouseClick(object sender, MouseEventArgs e)
        {
            if (dtItemList.Rows.Count == 0)
            {
                dtItemList = DAL.fnItemMasterLoadList(null).Tables[0];
            }
        }

        private void txtUnitCost_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber(sender, e);
        }
        private void fnOnlynumber(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void fnOnlynumber1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtHSNSACCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber1(sender, e);
        }

        private void txtbrowseaddres_TextChanged(object sender, EventArgs e)
        {

        }

        private void chkUpdateUnitPrice_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void pnMain_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
