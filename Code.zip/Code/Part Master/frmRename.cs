﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Part_Master
{
    public partial class frmRename : Form
    {
        #region Intialization of Local Datatables, Variables Daclaration

        DataAccessLayer DAL = new DataAccessLayer();
        DataTable dtTreeviewProductcheck = new DataTable();
        Global GLobalClass = new Global();
        string sPmainfolder = string.Empty;
        string sMProduct = string.Empty;
        string sOldProductName = string.Empty;
        string sOldProductCode = string.Empty;
        DataTable dtParentAndNodeID = new DataTable();
        bool bProductcheck;
        bool bProductCodeCheck;
        DataTable dtProductCode = new DataTable();

        public frmRename()
        {
            InitializeComponent();
        }
        #endregion

        #region Function to Load Folder or Product Name
        public void fnFolderandProduct(string sProductMainFolder, string sProduct)
        {
            sPmainfolder = string.Empty;
            sMProduct = string.Empty;
            sPmainfolder = sProductMainFolder;
            sMProduct = sProduct;
        }
        #endregion

        #region Code to Load Variables on Rename form Load
        private void frmRename_Load(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(sPmainfolder) && string.IsNullOrEmpty(sMProduct))
            {
                txtproductname.Text = sPmainfolder;
                txtproductcode.Visible = false;
                lblmainfoldername.Visible = false;                
            }
            else
            {
                txtproductcode.Visible = true;
                lblmainfoldername.Visible = true;
               
                dtParentAndNodeID = DAL.fnGetLastNodeId(sPmainfolder).Tables["LastNodeId"];
                if(dtParentAndNodeID.Rows.Count>0)
                {
                    dtParentAndNodeID = DAL.fnGetTreeNode(sMProduct, dtParentAndNodeID.Rows[0]["NodeID"].ToString()).Tables[0];
                    if (dtParentAndNodeID.Rows.Count > 0)
                    {
                        txtproductname.Text = dtParentAndNodeID.Rows[0]["Name"].ToString();
                        txtproductcode.Text = dtParentAndNodeID.Rows[0]["ProductCode"].ToString();

                        sOldProductName = dtParentAndNodeID.Rows[0]["Name"].ToString();
                        sOldProductCode = dtParentAndNodeID.Rows[0]["ProductCode"].ToString();                    
                    }
                }
            }
        }
        #endregion

        #region Code to Save Renamed Product or Folder
        private void btnfoldernameok_Click(object sender, EventArgs e)
        {
            bProductcheck = false;
            bProductCodeCheck = false;
            frmProductMasterForm PorductMaster = new frmProductMasterForm();
            if (!string.IsNullOrEmpty(sPmainfolder) && string.IsNullOrEmpty(sMProduct))
            {
                if (!string.IsNullOrEmpty(txtproductname.Text))
                {
                    dtTreeviewProductcheck = DAL.fnGetTreeName(txtproductname.Text.Trim()).Tables[0];
                    if (dtTreeviewProductcheck.Rows.Count == 0)
                    {
                        DAL.fnRenameProduct(sPmainfolder, txtproductname.Text.Trim(), null, null);
                        //PorductMaster.fnNewName(txtproductname.Text.Trim(),"succcess");
                        PorductMaster.fnRenameFormat = txtproductname.Text.Trim();
                        this.Close();
                    }
                    else
                    {
                        PorductMaster.fnRenameFormat = null;
                        MessageBox.Show("Folder Name '" + txtproductname.Text.Trim() + "' Already created. " + Environment.NewLine + " Add Prefix or Suffix to The Folder Name", "Error", 0, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please Enter a Folder Name", "Error", 0, MessageBoxIcon.Error);
                }
            }
            else
            {
                if (!string.IsNullOrEmpty(txtproductname.Text) && !string.IsNullOrEmpty(txtproductcode.Text))
                {
                    dtTreeviewProductcheck = DAL.fnGetLastNodeId(sPmainfolder.Trim()).Tables["LastNodeId"];

                    dtTreeviewProductcheck = DAL.fnParentId(dtTreeviewProductcheck.Rows[0]["NodeID"].ToString()).Tables[0];

                    foreach (DataRow dr in dtTreeviewProductcheck.Rows)
                    {
                        if (dr["Name"].ToString().ToUpper() == txtproductname.Text.Trim().ToUpper())
                        {
                            bProductcheck = true;
                            break;
                        }
                    }

                    if (sOldProductCode != txtproductcode.Text.Trim())
                    {
                        dtProductCode = DAL.fnProductCode(txtproductcode.Text.Trim()).Tables[0];
                        if (dtProductCode.Rows.Count > 0)
                        {
                            bProductCodeCheck = true;
                        }
                    }
                    if (bProductcheck == false && bProductCodeCheck == false)
                    {
                        DAL.fnRenameProduct(txtproductname.Text, txtproductcode.Text, sOldProductName, sOldProductCode);


                        DAL.fnBOMUserNameProduct(txtproductname.Text, sOldProductName, dtParentAndNodeID.Rows[0]["NodeID"].ToString());

                        DAL.fnProjectRenameProduct(txtproductname.Text, txtproductcode.Text, sOldProductName, sOldProductCode);

                        PorductMaster.fnRenameFormat = txtproductname.Text.Trim();
                        this.Close();
                    }
                    else
                    {
                        PorductMaster.fnRenameFormat = null;
                        if (bProductcheck == true)
                        {
                            MessageBox.Show("Same Prodcuct name '" + txtproductname.Text.Trim() + "' already exist in '" + sPmainfolder + "' folder. " + Environment.NewLine + "Add Prefix or Suffix to The Product Name", "Error", 0, MessageBoxIcon.Error);
                        }
                        if (bProductCodeCheck == true)
                        {
                            MessageBox.Show("ProductCode '" + txtproductcode.Text.Trim() + "' already used for product '" + dtProductCode.Rows[0]["name"].ToString() + "' .", "Error", 0, MessageBoxIcon.Error);
                        }
                    }
 
                }
                else
                {
                    MessageBox.Show("Please Enter a Product Code or Product Name", "Error", 0, MessageBoxIcon.Error);
                }
            }
        }
        #endregion

        #region Function to Get Folder Address
        public void fnName(string FolderAddress)
        {
            lbladdressbar.Text = FolderAddress;
        }
        #endregion

        #region Code to Cancel the Rename Product
        private void btncancel_Click(object sender, EventArgs e)
        {
            frmProductMasterForm PorductMaster = new frmProductMasterForm();
            PorductMaster.fnRenameFormat = null;
            this.Close();
        }
        #endregion
    }
}
