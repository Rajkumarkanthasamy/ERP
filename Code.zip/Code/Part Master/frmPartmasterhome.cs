﻿using System;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Part_Master
{
    public partial class frmPartmasterhome : Form
    {
        frmForm2 frm = new frmForm2();
        Global GLobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        public frmPartmasterhome()
        {
            InitializeComponent();
        }

        private void frmPartmasterhome_Load(object sender, EventArgs e)
        {
            if (login.GetUserDetails[5] != "True")
            {
                btnPartMaster.Enabled = false;
            }
            else
            {
                btnPartMaster.Enabled = true;
            }
            if (login.GetUserDetails[54] == "True")
            {
                btnPartMaster.Enabled = false;
            }

            if (login.GetUserDetails[77] != "True")
            {
                btnStandardCost.Enabled = false;
            }
            else
            {
                btnStandardCost.Enabled = true;
            }
            if (login.GetUserDetails[77] == "True" || login.GetUserDetails[2].ToLower() == "hebbarrk")
            {
                btnTargetCost.Enabled = true;
            }
            else
            {
                btnTargetCost.Enabled = false;
            }
        }

        private void frmPartmasterhome_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            frm.Show();
        }

        #region Function to Show Please wait form & Switch to Selected From
        private void fnFormShow(Form Frm)
        {
            this.Hide();
            pleasewaitform pleaseWait = new pleasewaitform();
            pleaseWait.Show();
            Application.DoEvents();
            Frm.Show();
            pleaseWait.Hide();
        }
        #endregion

        private void btnPartMaster_Click(object sender, EventArgs e)
        {
            frmPartmaster frmPartmaster = new frmPartmaster();
            fnFormShow(frmPartmaster);
        }

        private void btnStandardCost_Click(object sender, EventArgs e)
        {
            Part_Master.frmStandardCost standardCost = new frmStandardCost();
            fnFormShow(standardCost);
        }

        private void btnTargetCost_Click(object sender, EventArgs e)
        {
            Part_Master.FrmTargetCost TargetCost = new FrmTargetCost();
            fnFormShow(TargetCost);
        }
    }
}
