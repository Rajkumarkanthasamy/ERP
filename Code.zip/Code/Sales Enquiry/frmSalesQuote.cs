﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Collections;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.Globalization;
using System.Diagnostics;
using Outlook = Microsoft.Office.Interop.Outlook;
using System.Collections.Specialized;
using DataTable = System.Data.DataTable;

namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    public partial class frmSalesQuote : Form
    {
        public frmSalesQuote()        {
            InitializeComponent();
        }

        DataAccessLayer DAL = new DataAccessLayer();
        Global GLobalClass = new Global();
        frmForm2 form = new frmForm2();
        frmSalesHome SalesHome = new frmSalesHome();
        Login.frmLoginForm LoginForm = new Login.frmLoginForm();
        DataTable dtCustomerList = new System.Data.DataTable();
        Sales_Enquiry.frmQuoteViewItems QVI = new frmQuoteViewItems();
        // Sales_Enquiry.frmQuoteView QuoteView = new frmQuoteView();
        DataRow[] DR;
        DataTable dtTreeFromTable = new DataTable();
        DataTable dtDGDatatable = new DataTable();
        TreeNode tnCurrentParentNode = new TreeNode();
        DataTable dtPegRate = new DataTable();
        private string[] sTableColumns = { "ProductCode", "ProductName", "ProductType", "UOM", "UnitCost", "Quantity", "NodeID" };
        private const int _blinkFrequency = 250;
        private const int _maxNumberOfBlinks = 1000;
        private static double dPegRate = 1;
        DataTable dtProductCategory = new DataTable();

        DataTable dtPrimaryApplication = new DataTable();
        DataTable dtPrimaryMaterial = new DataTable();
        DataTable dtLabType = new DataTable();
        DataTable dtBusinessSector = new DataTable();
        DataTable dtPrimaryIndustries = new DataTable();

           

        private string sEnquiryNumber = "";
        public string fnEnquiryNumber
        {
            get
            {
                return sEnquiryNumber;
            }
            set
            {
                sEnquiryNumber = value;
            }
        }

        public int Quoteform = 0;
        private static string sQuote1No;
        public string fnQuote1no
        {
            get
            {
                return sQuote1No;
            }
            set
            {
                sQuote1No = value;
            }
        }

        private static string sQuote1RevNo;
        public string fnQuote1Revno
        {
            get
            {
                return sQuote1RevNo;
            }
            set
            {
                sQuote1RevNo = value;
            }
        }


        

        private void frmSalesQuote_Load(object sender, EventArgs e)
        {
            dtPrimaryApplication = DAL.fnQuoteOpportunityCodes("Primary Application").Tables[0];
            dtPrimaryMaterial = DAL.fnQuoteOpportunityCodes("Primary Material").Tables[0];
            dtLabType = DAL.fnQuoteOpportunityCodes("Lab Type").Tables[0];
            dtBusinessSector = DAL.fnQuoteOpportunityCodes("Business Sector").Tables[0];
            dtPrimaryIndustries = DAL.fnQuoteOpportunityCodes("Primary Industries").Tables[0];

            dtpEnquireDate.Format = DateTimePickerFormat.Custom;
            dtpEnquireDate.CustomFormat = "dd-MM-yyyy";
            dtpExpectedOrderPlacementdate.Format = DateTimePickerFormat.Custom;
            dtpExpectedOrderPlacementdate.CustomFormat = "dd-MM-yyyy";


            foreach (DataRow DR in dtPrimaryApplication.Rows)
            {
                if (!cmbApplication.Items.Contains(DR[2].ToString()))
                    cmbApplication.Items.Add(DR[2].ToString());
            }

            foreach (DataRow DR in dtPrimaryMaterial.Rows)
            {
                if (!cmbprimarymaterial.Items.Contains(DR[2].ToString()))
                    cmbprimarymaterial.Items.Add(DR[2].ToString());
            }

            foreach (DataRow DR in dtLabType.Rows)
            {
                if (!cmbLabtype.Items.Contains(DR[2].ToString()))
                    cmbLabtype.Items.Add(DR[2].ToString());
            }

            foreach (DataRow DR in dtBusinessSector.Rows)
            {
                if (!cmbBusinessector.Items.Contains(DR[2].ToString()))
                    cmbBusinessector.Items.Add(DR[2].ToString());
            }

            foreach (DataRow DR in dtPrimaryIndustries.Rows)
            {
                if (!cmbprimaryind.Items.Contains(DR[2].ToString()))
                    cmbprimaryind.Items.Add(DR[2].ToString());
            }


            dtPegRate = DAL.DTPegRate("").Tables[0];
            if (dtPegRate.Rows.Count > 0)
            {
                dPegRate = Convert.ToDouble(dtPegRate.Rows[0][1].ToString());
            }
            else
            {
                dPegRate = 1;
            }
            lblPrepareBy.Text = LoginForm.GetUserDetails[2];
            chkAddbyBOM.Checked = true;
            chkaddmainitems.Checked = true;
            chkintrastate.Checked = false;
            dtProductCategory = DAL.fnProdcuctCategoryList(null).Tables[0];
            foreach (DataRow DR in dtProductCategory.Rows)
            {
                if (!cmbProductCategory.Items.Contains(DR[1].ToString()))
                    cmbProductCategory.Items.Add(DR[1].ToString());
            }


            dtCustomerList = DAL.fnCustomerList(5, null).Tables[0];
            foreach (DataRow DR in dtCustomerList.Rows)
            {
                if (!cmbCustomer.Items.Contains(DR["CustomerName"].ToString()))
                    cmbCustomer.Items.Add(DR["CustomerName"].ToString());
            }
            foreach (string str in sTableColumns)
            {
                dtDGDatatable.Columns.Add(str);
            }

            LoadTree();

            dtQuoteTreeTable = DAL.fnGetQuoteProductTreeView().Tables[0]; //get the tree folders and sub-folders from database
            if (dtQuoteTreeTable.Rows.Count > 0)
            {
                tvQuoteProduct.Nodes.AddRange(GLobalClass.fnTreeFromTable(dtQuoteTreeTable, "ParentID", "NodeID", "ProductName", "ImageIndex")); // display the folders in the treeview
                tnCurrentParentNode = null;
                tvQuoteProduct.CollapseAll();
                tvQuoteProduct.Sort();
            }

            chkintrastate.Checked = false;
            cmbBank.SelectedIndex = 1;
            if (!string.IsNullOrEmpty(sEnquiryNumber))
            {
                txtEnquiryNumber.Text = sEnquiryNumber;
                dtEnquiryRegDetails = DAL.fnQuotationNumberLoadData(19, sEnquiryNumber, "").Tables[0];

                if (dtEnquiryRegDetails.Rows.Count > 0)
                {
                    cmbQuotationNumber.Items.Clear();
                    foreach (DataRow DR in dtEnquiryRegDetails.Rows)
                    {
                        if (!cmbQuotationNumber.Items.Contains(DR["QuotationNumber"].ToString()))
                            cmbQuotationNumber.Items.Add(DR["QuotationNumber"].ToString());
                    }


                    bCustomerLoad = true;
                    cmbCustomer.SelectedItem = dtEnquiryRegDetails.Rows[0]["CustomerName"].ToString();
                    txtCustomertype.Text = dtEnquiryRegDetails.Rows[0]["CustomerType"].ToString();
                    txtAddress.Text = dtEnquiryRegDetails.Rows[0]["Adress"].ToString();
                    txtDepartment1.Text = dtEnquiryRegDetails.Rows[0]["Department"].ToString();
                    txtContactPerson1.Text = dtEnquiryRegDetails.Rows[0]["ContactPerson"].ToString();
                    txtContactNumber1.Text = dtEnquiryRegDetails.Rows[0]["ContactNumber"].ToString();
                    txtEmailID1.Text = dtEnquiryRegDetails.Rows[0]["EmailID"].ToString();
                    txtCusCode.Text = dtEnquiryRegDetails.Rows[0]["CustomerCode"].ToString();
                    cmbQuotationfor.SelectedItem = dtEnquiryRegDetails.Rows[0]["QuoteFor"].ToString();
                    cmbLeadGenarated.Text = dtEnquiryRegDetails.Rows[0]["Leadgenarated"].ToString();



                    cmbSelectQuoteType.Items.Add("Revise Quote");
                    cmbSelectQuoteType.Items.Add("Update Quote");
                    cmbSelectQuoteType.SelectedIndex = 0;
                    bCustomerLoad = false;
                }
                else
                {
                    cmbSelectQuoteType.Items.Add("New Quote");
                    cmbSelectQuoteType.Items.Add("Copy Quote");
                    cmbSelectQuoteType.SelectedIndex = 0;
                    dtEnquiryRegDetails = DAL.fnQuotationNumberLoadData(20, sEnquiryNumber, "").Tables[0];
                    if (dtEnquiryRegDetails.Rows.Count > 0)
                    {
                        bCustomerLoad = true;
                        cmbCustomer.SelectedItem = dtEnquiryRegDetails.Rows[0]["CustomerName"].ToString();
                        txtCustomertype.Text = dtEnquiryRegDetails.Rows[0]["CustomerType"].ToString();
                        txtAddress.Text = dtEnquiryRegDetails.Rows[0]["Adress"].ToString();
                        txtDepartment1.Text = dtEnquiryRegDetails.Rows[0]["Department"].ToString();
                        txtContactPerson1.Text = dtEnquiryRegDetails.Rows[0]["ContactPerson"].ToString();
                        txtContactNumber1.Text = dtEnquiryRegDetails.Rows[0]["ContactNumber"].ToString();
                        txtEmailID1.Text = dtEnquiryRegDetails.Rows[0]["EmailID"].ToString();
                        txtCusCode.Text = dtEnquiryRegDetails.Rows[0]["CustomerCode"].ToString();
                        cmbQuotationfor.SelectedItem = dtEnquiryRegDetails.Rows[0]["ProductType"].ToString();
                        cmbLeadGenarated.Text = dtEnquiryRegDetails.Rows[0]["Leadinputfrom"].ToString();

                        if (dtEnquiryRegDetails.Rows[0]["CountryName"].ToString() == "India")
                        {
                            cmbEnquireCurrency.SelectedIndex = 0;
                        }
                        else
                        {
                            cmbEnquireCurrency.SelectedIndex = 1;
                        }

                        if (cmbEnquireCurrency.SelectedIndex == 0)
                        {
                            cmbRegion.SelectedItem = dtEnquiryRegDetails.Rows[0]["RegioninIndia"].ToString();
                        }
                        else
                        {
                            cmbRegion.SelectedItem = dtEnquiryRegDetails.Rows[0]["CountryName"].ToString();
                        }

                        bCustomerLoad = false;
                    }
                }
            }
            else
            {
                cmbSelectQuoteType.Items.Add("Revise Quote");
                cmbSelectQuoteType.Items.Add("Update Quote");
            }
        }
        bool bCustomerLoad = false;
        DataTable dtEnquiryRegDetails = new DataTable();
        private void LoadTree()
        {
            tvProduct.Nodes.Clear();
            dtTreeFromTable = DAL.fnGetSalesProductTreeView().Tables[0]; //get the tree folders and sub-folders from database
            if (dtTreeFromTable.Rows.Count > 0)
            {
                tvProduct.Nodes.AddRange(GLobalClass.fnTreeFromTable(dtTreeFromTable, "ParentID", "NodeID", "ProductName", "ImageIndex")); // display the folders in the treeview
                tnCurrentParentNode = null;
                tvProduct.CollapseAll();
                tvProduct.Sort();
            }

        }

        DataTable dtQuoteTreeTable = new DataTable();

        private void cmbCustomer_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!bCustomerLoad)
            {
                DR = dtCustomerList.Select("CustomerName = '" + cmbCustomer.Text + "'");
                if (DR.Length > 0)
                {
                    txtCustomertype.Text = DR[0]["CustomerType"].ToString();
                    txtAddress.Text = DR[0]["Address1"].ToString() + DR[0]["Address2"].ToString() + DR[0]["Address3"].ToString();
                    txtContactPerson1.Text = DR[0]["ContactPerson"].ToString();
                    txtContactNumber1.Text = DR[0]["MobileNo"].ToString();
                    txtEmailID1.Text = DR[0]["EmailAddress"].ToString();
                    txtCusCode.Text = DR[0]["CusCode"].ToString();
                }
                else
                {
                    txtCustomertype.ResetText();
                    txtAddress.ResetText();
                    txtContactPerson1.ResetText();
                    txtContactNumber1.ResetText();
                    txtEmailID1.ResetText();
                    txtCusCode.ResetText();
                }
            }
        }
        string sQuoteSystem = "";
        string sAutoModel = "";
        string sCapacity = "";
        private void cmbQuotatiofor_SelectedIndexChanged(object sender, EventArgs e)
        {
            sQuoteSystem = cmbQuotationfor.Text;
            switch (cmbQuotationfor.SelectedIndex)
            {
                case 0:
                    cmbModel.Text = "";
                    cmbModel.Items.Clear();
                    cmbModel.Items.Add("Nano");
                    cmbModel.Items.Add("Makron");
                    cmbModel.Items.Add("Median");
                    cmbModel.Items.Add("Magnum");
                    cmbModel.Items.Add("Electra");
                    cmbModel.Items.Add("Axial Torsion");
                    //cmbModel.Items.Add("Elastomer/Hfts");
                    break;

                case 1:
                    cmbModel.Text = "";
                    cmbModel.Items.Clear();
                    cmbModel.Items.Add("Bi-Axial");
                    cmbModel.Items.Add("Structural Actuator");
                    cmbModel.Items.Add("Uniaxial Elastomer Test System");
                    cmbModel.Items.Add("2 Axes Vertical Elastomer Test System 25 kN");
                    cmbModel.Items.Add("2 Axes Horizontal Elastomer Test System 25 kN");
                    cmbModel.Items.Add("3 Axes Horizontal Elastomer Test System 300 kN");
                    cmbModel.Items.Add("4 Axes Horizontal Elastomer Test System");
                    break;

                case 2:
                    cmbModel.Text = "";
                    cmbModel.Items.Clear();
                    cmbModel.Items.Add("Single Station");
                    cmbModel.Items.Add("Dual Station");
                    cmbModel.Items.Add("Tilting Machine");
                    cmbModel.Items.Add("Durability");
                    cmbModel.Items.Add("Single Station Cranking System");
                    cmbModel.Items.Add("Dual Station Cranking System");
                    cmbModel.Items.Add("Suspension Test Rig");
                    break;

                case 3:
                    cmbModel.Text = "";
                    cmbModel.Items.Clear();
                    cmbModel.Items.Add("Single Column");
                    cmbModel.Items.Add("Dual Column");
                    break;

                case 4:
                    cmbModel.Text = "";
                    cmbModel.Items.Clear();
                    cmbModel.Items.Add("LigaGen");
                    cmbModel.Items.Add("LumeGen");
                    cmbModel.Items.Add("CartiGen");
                    cmbModel.Items.Add("DermiGen");
                    cmbModel.Items.Add("OsteoGen");
                    break;

                //case 5:
                //    cmbModel.Text = "";
                //    cmbModel.Items.Clear();
                //    cmbModel.Items.Add("3 Axis");
                //    cmbModel.Items.Add("5 Axis");
                //    cmbModel.Items.Add("6 Axis");
                //    cmbModel.Items.Add("Custom");
                //    break;

                case 5:
                    cmbModel.Text = "";
                    cmbModel.Items.Clear();
                    cmbModel.Items.Add("Uniaxial");
                    // cmbModel.Items.Add("Uniaxial Elastomer Test System");
                    cmbModel.Items.Add("Biaxial");
                    cmbModel.Items.Add("Triaxial");
                    break;

                case 6:
                    cmbModel.Text = "";
                    cmbModel.Items.Clear();
                    cmbModel.Items.Add("Others");
                    break;
            }
        }

        

        private void cmbQuotationType_SelectedIndexChanged(object sender, EventArgs e)
        {
            sAutoModel = sQuoteSystem + cmbModel.Text;
            cmbCapacity.Text = "";
            cmbCapacity.Items.Clear();
            switch (cmbQuotationfor.SelectedIndex)
            {
                case 0:
                    switch (cmbModel.SelectedIndex)
                    {
                        case 0:
                            // cmbCapacity.Items.Add("5 kN");
                            cmbCapacity.Items.Add("10 kN");
                            cmbCapacity.Items.Add("15 kN");
                            cmbCapacity.Items.Add("25 kN");
                            cmbCapacity.Items.Add("Custom");
                            break;
                        case 1:
                            cmbCapacity.Items.Add("25 kN");
                            cmbCapacity.Items.Add("50 kN");
                            cmbCapacity.Items.Add("Custom");
                            break;

                        case 2:
                            // cmbCapacity.Items.Add("50 kN");
                            cmbCapacity.Items.Add("100 kN");
                            cmbCapacity.Items.Add("150 kN");
                            cmbCapacity.Items.Add("250 kN");
                            cmbCapacity.Items.Add("300 kN");
                            cmbCapacity.Items.Add("500 kN");
                            cmbCapacity.Items.Add("600 kN");
                            cmbCapacity.Items.Add("Custom");
                            break;

                        case 3:
                            cmbCapacity.Items.Add("500 kN");
                            cmbCapacity.Items.Add("600 kN");
                            cmbCapacity.Items.Add("1000 kN");
                            cmbCapacity.Items.Add("1500 kN");
                            cmbCapacity.Items.Add("2000 kN");
                            cmbCapacity.Items.Add("3000 kN");
                            cmbCapacity.Items.Add("5000 kN");
                            cmbCapacity.Items.Add("Custom");
                            break;

                        case 4:
                            //cmbCapacity.Items.Add("5 kN");
                            cmbCapacity.Items.Add("10 kN");
                            //cmbCapacity.Items.Add("15 kN");
                            cmbCapacity.Items.Add("25 kN");
                            cmbCapacity.Items.Add("50 kN");
                            cmbCapacity.Items.Add("100 kN");
                            cmbCapacity.Items.Add("200 kN");
                            cmbCapacity.Items.Add("Custom");
                            break;

                        case 5:
                            cmbCapacity.Items.Add("25 kN - 500 Nm");
                            cmbCapacity.Items.Add("50 kN - 1000 Nm");
                            cmbCapacity.Items.Add("100 kN - 2000 Nm");
                            cmbCapacity.Items.Add("500 kN - 2000 Nm");
                            cmbCapacity.Items.Add("Custom");
                            break;

                            //case 6:
                            //    cmbCapacity.Items.Add("5 kN");
                            //    cmbCapacity.Items.Add("10 kN");
                            //    cmbCapacity.Items.Add("15 kN");
                            //    cmbCapacity.Items.Add("25 kN");
                            //    cmbCapacity.Items.Add("50 kN");
                            //    cmbCapacity.Items.Add("100 kN");
                            //    cmbCapacity.Items.Add("Custom");
                            //    break;
                    }
                    break;

                case 1:
                    switch (cmbModel.SelectedIndex)
                    {
                        case 0:

                            cmbCapacity.Items.Add("5 kN");
                            cmbCapacity.Items.Add("10 kN");
                            cmbCapacity.Items.Add("25 kN");
                            cmbCapacity.Items.Add("50 kN");
                            cmbCapacity.Items.Add("100 kN");
                            cmbCapacity.Items.Add("250 kN");
                            cmbCapacity.Items.Add("500 kN");
                            cmbCapacity.Items.Add("Custom");
                            break;

                        case 1:
                            cmbCapacity.Items.Add("1 Actuator");
                            cmbCapacity.Items.Add("2 Actuators");
                            cmbCapacity.Items.Add("4 Actuators");
                            cmbCapacity.Items.Add("8 Actuators");
                            cmbCapacity.Items.Add("Custom");
                            break;
                        case 2:
                            cmbCapacity.Items.Add("10 kN");
                            cmbCapacity.Items.Add("25 kN");
                            cmbCapacity.Items.Add("50 kN");
                            cmbCapacity.Items.Add("Custom");
                            break;

                        //case 3:
                        //    cmbCapacity.Items.Add("10 kN");
                        //    cmbCapacity.Items.Add("25 kN");
                        //    cmbCapacity.Items.Add("50 kN");
                        //    cmbCapacity.Items.Add("Custom");
                        //    break;
                        case 3:
                        case 4:
                            cmbCapacity.Items.Add("500 Nm");
                            cmbCapacity.Items.Add("Custom");
                            break;
                        case 5:
                            cmbCapacity.Items.Add("2 k Nm");
                            break;
                        case 6:
                            cmbCapacity.Items.Add("Custom");
                            break;

                    }
                    break;

                case 2:
                    switch (cmbModel.SelectedIndex)
                    {
                        case 0:
                            cmbCapacity.Items.Add("5 kN");
                            cmbCapacity.Items.Add("10 kN");
                            cmbCapacity.Items.Add("15 kN");
                            cmbCapacity.Items.Add("25 kN");
                            cmbCapacity.Items.Add("50 kN");
                            cmbCapacity.Items.Add("Custom");
                            break;
                        case 1:
                            cmbCapacity.Items.Add("5 kN");
                            cmbCapacity.Items.Add("10 kN");
                            cmbCapacity.Items.Add("15 kN");
                            cmbCapacity.Items.Add("25 kN");
                            cmbCapacity.Items.Add("Custom");
                            break;
                        case 2:
                            cmbCapacity.Items.Add("25 kN");
                            cmbCapacity.Items.Add("50 kN");
                            cmbCapacity.Items.Add("Custom");
                            break;
                        case 3:
                            cmbCapacity.Items.Add("10 kN");
                            cmbCapacity.Items.Add("25 kN");
                            cmbCapacity.Items.Add("50 kN");
                            cmbCapacity.Items.Add("Custom");
                            break;
                        case 4:
                            cmbCapacity.Items.Add("5 kN");
                            cmbCapacity.Items.Add("10 kN");
                            cmbCapacity.Items.Add("15 kN");
                            cmbCapacity.Items.Add("Custom");
                            break;
                        case 5:
                            cmbCapacity.Items.Add("5 kN");
                            cmbCapacity.Items.Add("10 kN");
                            cmbCapacity.Items.Add("15 kN");
                            cmbCapacity.Items.Add("Custom");
                            break;
                        case 6:
                            cmbCapacity.Items.Add("10 kN");
                            cmbCapacity.Items.Add("15 kN");
                            cmbCapacity.Items.Add("25 kN");
                            cmbCapacity.Items.Add("50 kN");
                            cmbCapacity.Items.Add("Custom");
                            break;
                    }
                    break;

                case 3:
                    switch (cmbModel.SelectedIndex)
                    {
                        case 0:
                            cmbCapacity.Items.Add("40 N");
                            cmbCapacity.Items.Add("200 N");
                            cmbCapacity.Items.Add("500 N");
                            cmbCapacity.Items.Add("200 N - 2 Nm");
                            cmbCapacity.Items.Add("400 N - 2 Nm");
                            cmbCapacity.Items.Add("Custom");
                            break;
                        case 1:
                            cmbCapacity.Items.Add("1 kN");
                            cmbCapacity.Items.Add("5 kN");
                            cmbCapacity.Items.Add("10 kN");
                            cmbCapacity.Items.Add("Custom");
                            break;
                    }
                    break;

                case 4:
                    switch (cmbModel.SelectedIndex)
                    {
                        case 0:
                            cmbCapacity.Items.Add("L30 -1C");
                            cmbCapacity.Items.Add("L30 -4C");
                            cmbCapacity.Items.Add("L150 -1C");
                            cmbCapacity.Items.Add("Custom");
                            break;

                        case 1:
                            cmbCapacity.Items.Add("Single Chamber");
                            cmbCapacity.Items.Add("Multi Chamber");
                            cmbCapacity.Items.Add("Custom");
                            break;

                        case 2:
                            cmbCapacity.Items.Add("C10-12");
                            cmbCapacity.Items.Add("C-9x");
                            cmbCapacity.Items.Add("Custom");
                            break;

                        case 3:
                            cmbCapacity.Items.Add("D70-1");
                            cmbCapacity.Items.Add("Custom");
                            break;

                        case 4:
                            cmbCapacity.Items.Add("1 O");
                            cmbCapacity.Items.Add("6 O");
                            cmbCapacity.Items.Add("12 O");
                            cmbCapacity.Items.Add("Custom");
                            break;
                    }
                    break;

                //case 5:
                //    switch (cmbModel.SelectedIndex)
                //    {
                //        case 0:
                //        case 1:
                //        case 2:
                //            cmbCapacity.Items.Add("50kN");
                //            break;
                //        case 3:
                //            cmbCapacity.Items.Add("Others");
                //            break;
                //    }
                //    break;

                case 5:
                    switch (cmbModel.SelectedIndex)
                    {
                        case 0:

                            cmbCapacity.Items.Add("0.5m and 500kg");
                            cmbCapacity.Items.Add("1m x 500kg");
                            cmbCapacity.Items.Add("1m x 1000kg");
                            cmbCapacity.Items.Add("1.5m x 1000kg");
                            cmbCapacity.Items.Add("1.5m x 2000kg");
                            cmbCapacity.Items.Add("2m x 2000kg");
                            cmbCapacity.Items.Add("2m x 3000kg");
                            cmbCapacity.Items.Add("3m x 5000kg");
                            cmbCapacity.Items.Add("3m x 10000kg");
                            cmbCapacity.Items.Add("Custom");
                            break;
                        //case 1:
                        //    cmbCapacity.Items.Add("10 kN");
                        //    cmbCapacity.Items.Add("25 kN");
                        //    cmbCapacity.Items.Add("50 kN");
                        //    cmbCapacity.Items.Add("Custom");
                        //    break;
                        case 1:
                            cmbCapacity.Items.Add("0.5m and 500kg");
                            cmbCapacity.Items.Add("1m x 500kg");
                            cmbCapacity.Items.Add("1m x 1000kg");
                            cmbCapacity.Items.Add("1.5m x 1000kg");
                            cmbCapacity.Items.Add("1.5m x 2000kg");
                            cmbCapacity.Items.Add("2m x 2000kg");
                            cmbCapacity.Items.Add("2m x 3000kg");
                            cmbCapacity.Items.Add("3m x 5000kg");
                            cmbCapacity.Items.Add("3m x 10000kg");
                            cmbCapacity.Items.Add("Custom");
                            break;

                        case 2:
                            cmbCapacity.Items.Add("0.5m and 500kg");
                            cmbCapacity.Items.Add("1m x 500kg");
                            cmbCapacity.Items.Add("1m x 1000kg");
                            cmbCapacity.Items.Add("2m x 2000kg");
                            cmbCapacity.Items.Add("2m x 5000kg");
                            cmbCapacity.Items.Add("Custom");
                            break;

                    }
                    break;


                case 6:
                    switch (cmbModel.SelectedIndex)
                    {
                        case 0:
                            cmbCapacity.Items.Add("Others");
                            break;

                    }
                    break;
            }
        }
        DataTable dtQuote = new DataTable();
        DataTable SalesProductCodeDetails = new DataTable();
        DataTable dtQuoteOptionalItems = new DataTable();
        //  DataTable dtQuoteAdditionalItems = new DataTable();
        DataTable dtQuoteBOMNUmber = new DataTable();
        DataTable dtQuoteId = new DataTable();
        private void btnStartQuote_Click(object sender, EventArgs e)
        {
            if (cmbQuoteCompany.SelectedIndex == -1)
            {
                MessageBox.Show("Select quotation for to start quote ", "Information", 0, MessageBoxIcon.Warning);
                cmbQuoteCompany.DroppedDown = true;
            }
            else if (cmbQuoteType.SelectedIndex == -1)
            {
                MessageBox.Show("Select quotation type to start quote ", "Information", 0, MessageBoxIcon.Warning);
                cmbQuoteType.DroppedDown = true;
            }
            else if (cmbEnquireCurrency.SelectedIndex == -1)
            {
                MessageBox.Show("Select a currency to start quote ", "Information", 0, MessageBoxIcon.Warning);
                cmbEnquireCurrency.DroppedDown = true;
            }
            else if (cmbRegion.SelectedIndex == -1)
            {
                MessageBox.Show("Select a country/region to start quote ", "Information", 0, MessageBoxIcon.Warning);
                cmbRegion.DroppedDown = true;
            }
            else if (cmbLeadGenarated.SelectedIndex == -1)
            {
                MessageBox.Show("Select lead genarated by to start quote ", "Information", 0, MessageBoxIcon.Warning);
                cmbLeadGenarated.DroppedDown = true;
            }
            else if (cmbQuotationfor.SelectedIndex == -1)
            {
                MessageBox.Show("Select quote system to start quote ", "Information", 0, MessageBoxIcon.Warning);
                cmbQuotationfor.DroppedDown = true;
            }
            else if (cmbModel.SelectedIndex == -1)
            {
                MessageBox.Show("Select model to start quote ", "Information", 0, MessageBoxIcon.Warning);
                cmbModel.DroppedDown = true;
            }
            else if (cmbCapacity.SelectedIndex == -1)
            {
                MessageBox.Show("Select capacity to start quote ", "Information", 0, MessageBoxIcon.Information);
                cmbCapacity.DroppedDown = true;
            }
            else if (string.IsNullOrEmpty(txtModelNumber.Text))
            {
                MessageBox.Show("Enter Model number to start quote", "Information", 0, MessageBoxIcon.Information);
                txtModelNumber.Focus();
            }

            else if (cmbCustomer.SelectedIndex == -1)
            {
                MessageBox.Show("Select a customer to start quote ", "Information", 0, MessageBoxIcon.Information);
                cmbCustomer.DroppedDown = true;

            }
            else if (cmbIncoTerms.SelectedIndex == -1)
            {
                MessageBox.Show("Select Inco terms to start quote ", "Information", 0, MessageBoxIcon.Information);
                cmbIncoTerms.DroppedDown = true;
            }
            else if (cmbeightytwenty.SelectedIndex == -1)
            {
                MessageBox.Show("Select 80/20 details to start quote ", "Information", 0, MessageBoxIcon.Information);
                cmbeightytwenty.DroppedDown = true;
            }
            else if (cmblevelofcustomization.SelectedIndex == -1)
            {
                MessageBox.Show("Select level of customization details to start quote ", "Information", 0, MessageBoxIcon.Information);
                cmblevelofcustomization.DroppedDown = true;
            }
            else if (string.IsNullOrEmpty(txtQuoteName.Text))
            {
                MessageBox.Show("Enter Quote Name to start quote ", "Information", 0, MessageBoxIcon.Information);
                txtQuoteName.Focus();
            }
            else
            {
                cmbSelectQuoteType.Enabled = false;
                btnViewQuotes.Enabled = false;
                if (cmbSelectQuoteType.Text == "Update Quote" || cmbSelectQuoteType.Text == "Revise Quote")
                {
                    if (cmbQuotationNumber.SelectedIndex >= 0 && cmbRevisionNumber.SelectedIndex >= 0)
                    {
                        pnQuotationNumber.Visible = true;
                        pnQuotationNumber.Enabled = false;
                        tabControl1.SelectTab(1);
                    }
                    else
                    {
                        if (cmbQuotationNumber.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select Quotation number", "Error", 0, MessageBoxIcon.Error);
                        }
                        else if (cmbRevisionNumber.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select Quotation revision number", "Error", 0, MessageBoxIcon.Error);
                        }
                    }
                }
                else if (cmbSelectQuoteType.Text == "New Quote")
                {
                    tabControl1.SelectTab(1);
                }
                else if (cmbSelectQuoteType.Text == "Copy Quote")
                {
                    if (cmbQuotationNumber.SelectedIndex >= 0 && cmbRevisionNumber.SelectedIndex >= 0)
                    {
                        pnQuotationNumber.Visible = true;
                        pnQuotationNumber.Enabled = false;
                        tabControl1.SelectTab(1);
                    }
                    else
                    {
                        if (cmbQuotationNumber.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select Quotation number", "Error", 0, MessageBoxIcon.Error);
                        }
                        else if (cmbRevisionNumber.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select Quotation revision number", "Error", 0, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }

        private void txtsearchtree_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnsearchtree_Click(sender, e);
            }
        }
        private string LastSearchText;
        private List<TreeNode> CurrentNodeMatches = new List<TreeNode>();
        private int LastNodeIndex = 0;

        private void SearchNodes(string SearchText, TreeNode StartNode)
        {
            while (StartNode != null)
            {
                if (StartNode.Text.ToLower().Contains(SearchText.ToLower()))
                {
                    CurrentNodeMatches.Add(StartNode);
                };
                if (StartNode.Nodes.Count != 0)
                {
                    SearchNodes(SearchText, StartNode.Nodes[0]);//Recursive Search 
                };
                StartNode = StartNode.NextNode;
            };
        }

        private void cleartreeview_Click(object sender, EventArgs e)
        {
            LastSearchText = "";
            txtsearchtree.ResetText();
            if (chkAddbyBOM.Checked == true)
            {
                tvProduct.CollapseAll();
                if ((tvProduct.SelectedNode) != null)
                {
                    TreeNode tn = this.tvProduct.SelectedNode;
                    int x = tn.Bounds.X;
                    int y = tn.Bounds.Y;
                    TreeNodeMouseClickEventArgs treeNodeMouseClickEventArgs = new TreeNodeMouseClickEventArgs(tn, MouseButtons.Left, 1, x, y);
                }
            }
            else if (chkAddbyQuoteMaster.Checked == true)
            {
                tvQuoteProduct.CollapseAll();
                if ((tvQuoteProduct.SelectedNode) != null)
                {
                    TreeNode tn = this.tvQuoteProduct.SelectedNode;
                    int x = tn.Bounds.X;
                    int y = tn.Bounds.Y;
                    TreeNodeMouseClickEventArgs treeNodeMouseClickEventArgs = new TreeNodeMouseClickEventArgs(tn, MouseButtons.Left, 1, x, y);
                }
            }

            LoadTree();
        }
        DataTable dtParentName = new DataTable();
        DataTable dtProductCode = new DataTable();
        DataTable dtParentid = new DataTable();
        DataTable dtCompleteBOM = new DataTable();
        DataTable dtVersion = new DataTable();
        string sNName;
        DataRow DR1;
        private void tvProduct_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            tvProduct.SelectedNode = e.Node;
            tvProduct.LabelEdit = false;
            sNName = e.Node.Name;
            if (cmbProductCategory.SelectedIndex >= 0)
            {
                if (e.Node.Parent != null && e.Node != null && e.Node.Name != "All Product" && (e.Node.StateImageIndex == 2 || e.Node.StateImageIndex == 3 || e.Node.StateImageIndex == 4))
                {
                    sName = tvProduct.SelectedNode.Name.Split(')');

                    fnAddProducttoDataGridview(true);
                }
            }
            else
            {
                if (cmbProductCategory.SelectedIndex < 0)
                {
                    MessageBox.Show("Please select the product category", "Information", 0, MessageBoxIcon.Warning);
                    cmbProductCategory.DroppedDown = true;
                }

            }
        }


        private void fnAddProducttoDataGridview(bool bAddFromProductCheck)
        {
            bItemCheck = false;
            bCategory = false;
            if (chkaddmainitems.Checked == true)
            {
                if (!bMainCategory)
                {
                    dtProductCode = DAL.fnGetSlaesProdcutTreeNode(sName[0].ToString()).Tables[0];
                    if (dtProductCode.Rows.Count > 0)
                    {
                        Productcode = dtProductCode.Rows[0]["ProductCode"].ToString();

                        foreach (DataGridViewRow dr in dgQuoteBOM.Rows)
                        {
                            if (dr.Cells["ProductCod"].Value.ToString() == Productcode && dr.Cells["ProductGroup"].Value.ToString() == (cmbProductCategory.Text))
                            {
                                if (bAddFromProductCheck)
                                {
                                    MessageBox.Show("Selected product already added in the quote item list", "Warning", 0, MessageBoxIcon.Warning);
                                }
                                bItemCheck = true;
                                break;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please recheck product saved correctly Product Master", "Error", 0, MessageBoxIcon.Error);
                        bItemCheck = true;
                    }
                }

                dRowNumber = 0;

                if (!bItemCheck && cmbProductCategory.SelectedIndex >= 0)
                {
                    DR1 = dtQuote.NewRow();

                    if (dgQuoteBOM.Rows.Count == 0)
                    {
                        dRowNumber++;
                    }
                    foreach (DataGridViewRow DGVR in dgQuoteBOM.Rows)
                    {
                        if (DGVR.Cells["ProductGroup"].Value.ToString().Equals(cmbProductCategory.Text))
                        {
                            bCategory = true;
                            dRowNumber = Convert.ToDouble(DGVR.Cells["SLNO"].Value.ToString());
                        }
                        else
                        {
                            bCategory = false;
                        }
                    }

                    if (!bCategory && dRowNumber == 0)
                    {
                        DataTable dtCloned = dtQuote.Clone();
                        dtCloned.Columns[0].DataType = typeof(double);
                        foreach (DataRow row in dtQuote.Rows)
                        {
                            dtCloned.ImportRow(row);
                        }

                        double maxAccountLevel = double.MinValue;
                        foreach (DataRow dr in dtCloned.Rows)
                        {
                            double accountLevel = dr.Field<double>(0);
                            maxAccountLevel = Math.Max(maxAccountLevel, accountLevel);
                        }

                        if (maxAccountLevel == Math.Floor(maxAccountLevel))
                        {
                            DR1["GroupID"] = Math.Ceiling(maxAccountLevel + 1);
                        }
                        else
                        {
                            DR1["GroupID"] = Math.Ceiling(maxAccountLevel);
                        }
                    }
                    else
                    {
                        if (dgQuoteBOM.Rows.Count > 0)
                        {
                            double dCheck = 0;
                            double d = Math.Truncate(dRowNumber);
                            double x = dRowNumber - d;
                            x = Math.Round(x, 2, MidpointRounding.AwayFromZero);

                            foreach (DataGridViewRow dr in dgQuoteBOM.Rows)
                            {
                                if (Convert.ToDouble(dr.Cells["SLNO"].Value.ToString()) > d && Convert.ToDouble(dr.Cells["SLNO"].Value.ToString()) < (d + 1))
                                {
                                    dCheck++;
                                }
                            }

                            if (dCheck >= 9)
                            {
                                double d1 = Math.Truncate(dRowNumber);
                                double dValue = 0;
                                dValue = d1;
                                foreach (DataGridViewRow dr in dgQuoteBOM.Rows)
                                {
                                    if (Convert.ToDouble(dr.Cells["SLNO"].Value.ToString()) > d1 && Convert.ToDouble(dr.Cells["SLNO"].Value.ToString()) < (d1 + 1))
                                    {
                                        dValue += 0.01;
                                        dr.Cells["SLNO"].Value = (dValue).ToString();
                                    }
                                }

                                dRowNumber = dValue;
                                dRowNumber += 0.01;
                                dRowNumber = Math.Round(dRowNumber, 2, MidpointRounding.AwayFromZero);
                                DR1["GroupID"] = dRowNumber;
                            }
                            else
                            {
                                dRowNumber += 0.1;
                                dRowNumber = Math.Round(dRowNumber, 2, MidpointRounding.AwayFromZero);
                                DR1["GroupID"] = dRowNumber;
                            }
                        }
                        else
                        {
                            DR1["GroupID"] = dRowNumber;
                        }
                    }

                    if (bMainCategory)
                    {
                        bMainCategory = false;

                        DR1["ProductGroup"] = cmbProductCategory.Text;
                        DR1["ProductCode"] = "";
                        DR1["ProductName"] = cmbProductCategory.Text;
                        DR1["ProductDescription"] = cmbProductCategory.Text;
                        DR1["SalesCost"] = 0;
                        DR1["UnitPrice"] = 0;
                        DR1["TotalPrice"] = 0;
                        DR1["BreakupTotal"] = 0;
                        DR1["Quantity"] = 0;
                        DR1["ShowPrice"] = "No";
                    }
                    else
                    {
                        dtParentid = DAL.fnGetSlaesProdcutTreeNode(sName[0].ToString()).Tables[0];


                        double dProductCost = 0;
                        if (dtParentid.Rows.Count > 0)
                        {
                            if (dtParentid.Rows[0]["SalesCost"].ToString() != null && !string.IsNullOrEmpty(dtParentid.Rows[0]["SalesCost"].ToString()))
                            {
                                dProductCost = Convert.ToDouble(dtParentid.Rows[0]["SalesCost"].ToString());
                            }
                            else
                            {
                                dProductCost = 0;
                            }

                            DR1["ProductGroup"] = cmbProductCategory.Text;
                            DR1["ProductCode"] = dtParentid.Rows[0]["ProductCode"].ToString();
                            DR1["ProductName"] = dtParentid.Rows[0]["Name"].ToString();
                            DR1["ProductDescription"] = dtParentid.Rows[0]["Name"].ToString() + "\n" + dtParentid.Rows[0]["ProductDescription"].ToString();
                            if (!string.IsNullOrEmpty(dtParentid.Rows[0]["SalesCost"].ToString()))
                            {
                                DR1["SalesCost"] = (dProductCost * dPegRate).ToString();
                                if (LoginForm.GetUserDetails[2].ToLower() == "vijaya")
                                {
                                    DR1["UnitPrice"] = (Convert.ToDouble(dtParentid.Rows[0]["OTCProductCost"].ToString()) * dPegRate).ToString();
                                    DR1["TotalPrice"] = (Convert.ToDouble(dtParentid.Rows[0]["OTCProductCost"].ToString()) * dPegRate).ToString();
                                    DR1["BreakupTotal"] = (Convert.ToDouble(dtParentid.Rows[0]["OTCProductCost"].ToString()) * dPegRate).ToString();
                                }
                                else
                                {
                                    DR1["UnitPrice"] = (Convert.ToDouble(dtParentid.Rows[0]["ProductCost"].ToString()) * dPegRate).ToString();
                                    DR1["TotalPrice"] = (Convert.ToDouble(dtParentid.Rows[0]["ProductCost"].ToString()) * dPegRate).ToString();
                                    DR1["BreakupTotal"] = (Convert.ToDouble(dtParentid.Rows[0]["ProductCost"].ToString()) * dPegRate).ToString();
                                }
                            }
                            else
                            {
                                DR1["SalesCost"] = 0;
                                DR1["UnitPrice"] = 0;
                                DR1["TotalPrice"] = 0;
                                DR1["BreakupTotal"] = 0;
                            }
                        }
                        DR1["Quantity"] = 1;
                        DR1["ShowPrice"] = "No";
                    }
                    dtQuote.Rows.Add(DR1);

                    fnTotalCalucalation();

                }
                else
                {
                    if (cmbProductCategory.SelectedIndex < 0)
                    {
                        MessageBox.Show("Please select the product category", "Information", 0, MessageBoxIcon.Warning);
                        cmbProductCategory.DroppedDown = true;
                    }
                }
            }
            else if (chkOptionalItems.Checked == true)
            {
                if (!bMainCategory)
                {
                    dtProductCode = DAL.fnGetSlaesProdcutTreeNode(sName[0].ToString()).Tables[0];
                    if (dtProductCode.Rows.Count > 0)
                    {
                        Productcode = dtProductCode.Rows[0]["ProductCode"].ToString();
                        foreach (DataGridViewRow dr in dgvOptionalItems.Rows)
                        {
                            if (dr.Cells["OIProductCode"].Value.ToString() == Productcode && dr.Cells["OIProductGroup"].Value.ToString() == cmbProductCategory.Text)
                            {
                                if (bAddFromProductCheck)
                                {
                                    MessageBox.Show("Selected Product already present in the BOM item list", "Warning", 0, MessageBoxIcon.Warning);
                                }
                                bItemCheck = true;
                                break;
                            }
                        }
                    }
                }
                dOIRowCount = 0;
                if (!bItemCheck && cmbProductCategory.SelectedIndex >= 0)
                {
                    DR1 = dtQuoteOptionalItems.NewRow();

                    if (dgvOptionalItems.Rows.Count == 0)
                    {
                        dOIRowCount++;
                    }
                    foreach (DataGridViewRow DGVR in dgvOptionalItems.Rows)
                    {
                        if (DGVR.Cells["OIProductGroup"].Value.ToString().Equals(cmbProductCategory.Text))
                        {
                            bCategory = true;
                            dOIRowCount = Convert.ToDouble(DGVR.Cells["OISLNo"].Value.ToString());
                        }
                        else
                        {
                            bCategory = false;
                        }
                    }
                    if (!bCategory && dOIRowCount == 0)
                    {
                        DataTable dtCloned = dtQuoteOptionalItems.Clone();
                        dtCloned.Columns[0].DataType = typeof(double);
                        foreach (DataRow row in dtQuoteOptionalItems.Rows)
                        {
                            dtCloned.ImportRow(row);
                        }

                        double maxAccountLevel = double.MinValue;
                        foreach (DataRow dr in dtCloned.Rows)
                        {
                            double accountLevel = dr.Field<double>(0);
                            maxAccountLevel = Math.Max(maxAccountLevel, accountLevel);
                        }

                        if (maxAccountLevel == Math.Floor(maxAccountLevel))
                        {
                            DR1["GroupID"] = Math.Ceiling(maxAccountLevel + 1);
                        }
                        else
                        {
                            DR1["GroupID"] = Math.Ceiling(maxAccountLevel);
                        }
                    }
                    else
                    {
                        if (dgvOptionalItems.Rows.Count > 0)
                        {
                            double dCheck = 0;
                            double d = Math.Truncate(dOIRowCount);
                            double x = dRowNumber - d;
                            x = Math.Round(x, 2, MidpointRounding.AwayFromZero);

                            foreach (DataGridViewRow dr in dgvOptionalItems.Rows)
                            {
                                if (Convert.ToDouble(dr.Cells["OISLNo"].Value.ToString()) > d && Convert.ToDouble(dr.Cells["OISLNo"].Value.ToString()) < (d + 1))
                                {
                                    dCheck++;
                                }
                            }

                            if (dCheck >= 9)
                            {
                                double d1 = Math.Truncate(dOIRowCount);
                                double dValue = 0;
                                dValue = d1;
                                foreach (DataGridViewRow dr in dgvOptionalItems.Rows)
                                {
                                    if (Convert.ToDouble(dr.Cells["OISLNo"].Value.ToString()) > d1 && Convert.ToDouble(dr.Cells["OISLNo"].Value.ToString()) < (d1 + 1))
                                    {
                                        dValue += 0.01;
                                        dr.Cells["OISLNo"].Value = (dValue).ToString();
                                    }
                                }

                                dOIRowCount = dValue;
                                dOIRowCount += 0.01;
                                dOIRowCount = Math.Round(dOIRowCount, 2, MidpointRounding.AwayFromZero);
                                DR1["GroupID"] = dOIRowCount;
                            }

                            else
                            {
                                dOIRowCount += 0.1;
                                dOIRowCount = Math.Round(dOIRowCount, 2, MidpointRounding.AwayFromZero);
                                DR1["GroupID"] = dOIRowCount;
                            }
                        }
                        else
                        {
                            DR1["GroupID"] = dOIRowCount;
                        }

                    }
                    if (bMainCategory)
                    {
                        bMainCategory = false;

                        DR1["ProductGroup"] = cmbProductCategory.Text;
                        DR1["ProductCode"] = "";
                        DR1["ProductName"] = cmbProductCategory.Text;
                        DR1["ProductDescription"] = cmbProductCategory.Text;
                        DR1["SalesCost"] = 0;
                        DR1["UnitPrice"] = 0;
                        DR1["TotalPrice"] = 0;
                        DR1["BreakupTotal"] = 0;
                        DR1["Quantity"] = 0;
                        DR1["ShowPrice"] = "No";
                    }
                    else
                    {
                        //dtParentid = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Parent.Name).Tables["LastNodeId"];
                        //if (dtParentid.Rows.Count > 0)
                        //{
                        //    dtParentid = DAL.fnGetTreeNode(sNName, dtParentid.Rows[0]["NodeID"].ToString()).Tables[0];
                        //}
                        dtParentid = DAL.fnGetSlaesProdcutTreeNode(sName[0].ToString()).Tables[0];
                        double dProductCost = 0;

                        if (dtParentid.Rows.Count > 0)
                        {
                            if (dtParentid.Rows[0]["SalesCost"].ToString() != null && !string.IsNullOrEmpty(dtParentid.Rows[0]["SalesCost"].ToString()))
                            {
                                dProductCost = Convert.ToDouble(dtParentid.Rows[0]["SalesCost"].ToString());
                            }
                            else
                            {
                                dProductCost = 0;
                            }


                            DR1["ProductGroup"] = cmbProductCategory.Text;
                            DR1["ProductCode"] = dtParentid.Rows[0]["ProductCode"].ToString();
                            DR1["ProductName"] = dtParentid.Rows[0]["Name"].ToString();
                            DR1["ProductDescription"] = dtParentid.Rows[0]["Name"].ToString() + "\n" + dtParentid.Rows[0]["ProductDescription"].ToString();

                            if (!string.IsNullOrEmpty(dtParentid.Rows[0]["ProductCost"].ToString()))
                            {
                                DR1["UnitPrice"] = (Convert.ToDouble(dtParentid.Rows[0]["ProductCost"].ToString()) * dPegRate).ToString();
                                DR1["TotalPrice"] = (Convert.ToDouble(dtParentid.Rows[0]["ProductCost"].ToString()) * dPegRate).ToString();
                                DR1["BreakupTotal"] = (Convert.ToDouble(dtParentid.Rows[0]["ProductCost"].ToString()) * dPegRate).ToString();
                            }
                            else
                            {
                                DR1["UnitPrice"] = 0;
                                DR1["TotalPrice"] = 0;
                                DR1["BreakupTotal"] = 0;
                            }
                        }
                        DR1["SalesCost"] = dProductCost * dPegRate;
                        DR1["Quantity"] = 1;
                        DR1["ShowPrice"] = "No";
                    }

                    dtQuoteOptionalItems.Rows.Add(DR1);

                    fnOptionalItemTotalCalculation();
                }
                else
                {
                    if (cmbProductCategory.SelectedIndex < 0)
                    {
                        MessageBox.Show("Please select the product category", "Information", 0, MessageBoxIcon.Warning);
                        cmbProductCategory.DroppedDown = true;
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select any one add quote items option to add items", "Information", 0, MessageBoxIcon.Warning);
                chkaddmainitems.Focus();
            }

            //dgWriteUP.AutoGenerateColumns = false;
            //dgOIWriteUP.AutoGenerateColumns = false;
            //dgWriteUP.DataSource = dtQuote;
            //dgOIWriteUP.DataSource = dtQuoteOptionalItems;
        }
        DataTable dtNodeID = new DataTable();
        DataTable dtParentID = new DataTable();
        int iLastNodeID;
        bool bItemCheck = false;
        string Productcode = "";

        string[] sName;
        string[] sProdcutMasterName;
        private void btnSavetoMaster_Click(object sender, EventArgs e)
        {

        }
        DataTable dtWriteUp = new DataTable();
        DataTable dtOIWriteUp = new DataTable();
        DataTable dtAIWriteUp = new DataTable();
        string sQuotationNumber;
        int LastQuoteNumber = 0;
        DataTable dtQuotationNumber = new DataTable();
        double sTotalAmount = 0;
        private void btngotoquote_Click(object sender, EventArgs e)
        {
            if (dgQuoteBOM.Rows.Count > 0)
            {
                chkWUQuoteItems.Checked = true;

                if (chkSavetoQuoteMaster.Checked == true)
                {
                    if (tvQuoteProduct.SelectedNode != null)
                    {
                        if (tvQuoteProduct.SelectedNode.StateImageIndex == 0)
                        {
                            MessageBox.Show("Please select a product to save to quote master", "Information", 0, MessageBoxIcon.Information);
                        }
                        else if (tvQuoteProduct.SelectedNode.StateImageIndex == 2)
                        {
                            fnSaveQuoteMaster();
                            tabControl1.SelectTab(3);
                        }
                        else if (tvQuoteProduct.SelectedNode.StateImageIndex == 1)
                        {
                            MessageBox.Show("quote master exist quote for selected product, products not saved", "Information", 0, MessageBoxIcon.Information);
                            // DialogResult DR = MessageBox.Show("quote master exist quote for selected product.\nDo you want to update quote master ?  ", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                            //  if (DR == DialogResult.Yes)
                            {
                                //  fnSaveQuoteMaster();
                                tabControl1.SelectTab(3);
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select a product to save to quote master", "Information", 0, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    tabControl1.SelectTab(3);
                }
            }
            else
            {
                MessageBox.Show("Please add products from quote master", "Information", 0, MessageBoxIcon.Information);
            }
        }

        private void fnSaveQuoteMaster()
        {
            sName = tvQuoteProduct.SelectedNode.Name.Split(')');

            foreach (DataGridViewRow dr in dgQuoteBOM.Rows)
            {
                GLobalClass.iStatus = DAL.fnAddQuoteBOMMaster(Global.uINSERT, Convert.ToInt32(sName[0]), dr.Cells["ProductCod"].Value.ToString()
                                                              , dr.Cells["ProductName"].Value.ToString(), dr.Cells["Description"].Value.ToString(),
                                                              Convert.ToDouble(dr.Cells["SalesCost"].Value), Convert.ToDouble(dr.Cells["Quantity"].Value),
                                                              Convert.ToDouble(dr.Cells["UnitPrice"].Value), Convert.ToDouble(dr.Cells["TPrice"].Value),
                                                              Convert.ToDouble(dr.Cells["BreakupTotal"].Value), Convert.ToDouble(dr.Cells["SLNO"].Value),
                                                              dr.Cells["ProductGroup"].Value.ToString(), dr.Cells["SP"].Value.ToString());
            }
            GLobalClass.iSuccess = DAL.fnAddQuoteProduct(4, 0, Convert.ToInt32(sName[0]), "", "", 1, "", "");
            tvQuoteProduct.SelectedNode.StateImageIndex = 1;
            tabControl1.SelectTab(2);
        }

        private void txtJackup_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnNumberKeyPressOnly(sender, e);
        }

        private void fnWeekKeyPressOnly(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '-'))
            {
                e.Handled = true;
            }
            else if ((e.KeyChar == '-') && ((sender as TextBox).Text.IndexOf('-') > -1))
            {
                e.Handled = true;
            }
            if (e.KeyChar == 8)
            {
                if (((TextBox)sender).Text == "" || (((TextBox)sender).Text.Length < 1))
                {
                    ((TextBox)sender).Text = "0";
                }
            }
        }

        private void fnNumberKeyPressOnly(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            else if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
            if (e.KeyChar == 8)
            {
                if (((TextBox)sender).Text == "" || (((TextBox)sender).Text.Length < 1))
                {
                    ((TextBox)sender).Text = "0";
                }
            }
        }

        private void fnEmptyTextBox(object sender, EventArgs e)
        {
            if (((TextBox)sender).Text == "")
            {
                ((TextBox)sender).Text = "0";
            }
        }

        private void txtJackup_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtJackup.Text))
            {
                txtBsaicPrice.Text = Math.Round(((Convert.ToDouble(txtTotalPrice.Text) * Convert.ToDouble(txtJackup.Text)) / 100 + (Convert.ToDouble(txtTotalPrice.Text)))).ToString();
                txtQuoteJack.Text = txtBsaicPrice.Text;
                txtBasicDemoPrice.Text = txtBsaicPrice.Text;
                fnBasicPrice();
                fnJackUpCalculation();
            }
        }

        private void txtJackup_Leave(object sender, EventArgs e)
        {
            fnEmptyTextBox(sender, e);
            txtBsaicPrice.Text = Math.Round((Convert.ToDouble(txtTotalPrice.Text) * Convert.ToDouble(txtJackup.Text)) / 100 + (Convert.ToDouble(txtTotalPrice.Text))).ToString();

        }

        private void txtTotalPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!string.IsNullOrEmpty(txtTotalPrice.Text))
            {
                fnNumberKeyPressOnly(sender, e);
            }
        }


        private void txtPackingForwarding_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnNumberKeyPressOnly(sender, e);

        }

        private void txtPackingForwarding_Leave(object sender, EventArgs e)
        {
            fnEmptyTextBox(sender, e);
        }

        private void txtInsurance_KeyPress(object sender, KeyPressEventArgs e)
        {

            fnNumberKeyPressOnly(sender, e);

        }

        private void txtInsurance_Leave(object sender, EventArgs e)
        {
            fnEmptyTextBox(sender, e);
        }

        private void txtFreight_KeyPress(object sender, KeyPressEventArgs e)
        {

            fnNumberKeyPressOnly(sender, e);

        }

        private void txtFreight_Leave(object sender, EventArgs e)
        {
            fnEmptyTextBox(sender, e);
        }

        private void txtPackingForwarding_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtPackingForwarding.Text))
            {
                fnBasicPrice();

            }
        }

        private void fnBasicPrice()
        {
            txtBsaicPrice.Text = Math.Round((Convert.ToDouble(txtTotalPrice.Text) * Convert.ToDouble(txtJackup.Text)) / 100 + (Convert.ToDouble(txtTotalPrice.Text))).ToString();
            fnTotalPrice();
        }

        private void fnTotalPrice()
        {
            //    Double dTotal = 0;

            if (txtIGSTPer.Text == "18" || txtIGSTPer.Text == "5")
            {
                //   dTax = ();

                txtIGSTAmount.Text = Math.Round(((Convert.ToDouble(txtaftrerdisount.Text)
                    + Convert.ToDouble(txtAdditionalwarrantyAmount.Text) +
                    Convert.ToDouble(txtPackingForwarding.Text) +
                    Convert.ToDouble(txtFreight.Text) + Convert.ToDouble(txtInsurance.Text)) * Convert.ToDouble(txtIGSTPer.Text)) / 100).ToString();
                //    txtSGSTAmount.Text = "0";

                txtFinalNetAmount.Text = Math.Round(Convert.ToDouble(txtaftrerdisount.Text)
                    + Convert.ToDouble(txtAdditionalwarrantyAmount.Text) +
                    Convert.ToDouble(txtPackingForwarding.Text) +
                    Convert.ToDouble(txtFreight.Text) + Convert.ToDouble(txtInsurance.Text) + Convert.ToDouble(txtIGSTAmount.Text)
                    +
                    Convert.ToDouble(txtInsatallationCommision.Text) +
                    Convert.ToDouble(txtServiceTaxIGSTAmount.Text) +
                    Convert.ToDouble(txtServiceTaxSGSTAmount.Text)).ToString();


                //+
                //).ToString();

                //  txtFinalNetAmount.Text = Math.Round(Convert.ToDouble(txtaftrerdisount.Text) + Convert.ToDouble(txtInsatallationCommision.Text) + Convert.ToDouble(txtPackingForwarding.Text) + Convert.ToDouble(txtFreight.Text) +
                //    Convert.ToDouble(txtInsurance.Text) + Convert.ToDouble(txtIGSTAmount.Text) + Convert.ToDouble(txtSGSTAmount.Text) + Convert.ToDouble(txtServiceTaxIGSTAmount.Text) + Convert.ToDouble(txtServiceTaxSGSTAmount.Text)).ToString();
            }
            else if (txtIGSTPer.Text == "9" || txtIGSTPer.Text == "2.5")
            {
                // txtIGSTAmount.Text = Math.Round(


                txtIGSTAmount.Text = Math.Round(((Convert.ToDouble(txtaftrerdisount.Text)
                   + Convert.ToDouble(txtAdditionalwarrantyAmount.Text) +
                   Convert.ToDouble(txtPackingForwarding.Text) +
                   Convert.ToDouble(txtFreight.Text) + Convert.ToDouble(txtInsurance.Text)) * Convert.ToDouble(txtIGSTPer.Text)) / 100).ToString();

                txtSGSTAmount.Text = Math.Round(((Convert.ToDouble(txtaftrerdisount.Text)
                   + Convert.ToDouble(txtAdditionalwarrantyAmount.Text) +
                   Convert.ToDouble(txtPackingForwarding.Text) +
                   Convert.ToDouble(txtFreight.Text) + Convert.ToDouble(txtInsurance.Text)) * Convert.ToDouble(txtSgstPer.Text)) / 100).ToString();

                txtFinalNetAmount.Text = Math.Round(Convert.ToDouble(txtaftrerdisount.Text)
                    + Convert.ToDouble(txtAdditionalwarrantyAmount.Text) +
                    Convert.ToDouble(txtPackingForwarding.Text) +
                    Convert.ToDouble(txtFreight.Text) + Convert.ToDouble(txtInsurance.Text)
                    + Convert.ToDouble(txtIGSTAmount.Text) + Convert.ToDouble(txtSGSTAmount.Text)
                    + Convert.ToDouble(txtInsatallationCommision.Text) +
                    Convert.ToDouble(txtServiceTaxIGSTAmount.Text) +
                    Convert.ToDouble(txtServiceTaxSGSTAmount.Text)).ToString();
            }
            else
            {
                txtIGSTAmount.Text = Math.Round(((Convert.ToDouble(txtaftrerdisount.Text)
                 + Convert.ToDouble(txtAdditionalwarrantyAmount.Text) +
                 Convert.ToDouble(txtPackingForwarding.Text) +
                 Convert.ToDouble(txtFreight.Text) + Convert.ToDouble(txtInsurance.Text)) * Convert.ToDouble(txtIGSTPer.Text)) / 100).ToString();

                txtFinalNetAmount.Text = Math.Round(Convert.ToDouble(txtaftrerdisount.Text)
                    + Convert.ToDouble(txtAdditionalwarrantyAmount.Text) +
                    Convert.ToDouble(txtPackingForwarding.Text) +
                    Convert.ToDouble(txtFreight.Text) + Convert.ToDouble(txtInsurance.Text) + Convert.ToDouble(txtIGSTAmount.Text)
                    +
                    Convert.ToDouble(txtInsatallationCommision.Text) +
                    Convert.ToDouble(txtServiceTaxIGSTAmount.Text) +
                    Convert.ToDouble(txtServiceTaxSGSTAmount.Text)).ToString();
            }
        }

        private void txtFreight_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtFreight.Text))
            {
                fnBasicPrice();
            }
        }

        private void txtInsurance_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtInsurance.Text))
            {
                fnBasicPrice();
            }
        }

        private void txtTotalPrice_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtTotalPrice.Text))
            {
                fnBasicPrice();
                txtJackup_TextChanged(sender, e);
            }
        }

        private void txtDiscount_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnNumberKeyPressOnly(sender, e);
        }

        private void txtDiscount_Leave(object sender, EventArgs e)
        {
            fnEmptyTextBox(sender, e);
        }

        private void txtDiscount_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtDiscount.Text))
            {
                txtDiscAmount.Text = ((Convert.ToDouble(txtBsaicPrice.Text) * Convert.ToDouble(txtDiscount.Text)) / 100).ToString();

                //  txtaftrerdisount.Text = Math.Round((Convert.ToDouble(txtAdditionalwarrantyAmount.Text) + Convert.ToDouble(txtBsaicPrice.Text)) - Convert.ToDouble(txtDiscAmount.Text)).ToString();
                txtaftrerdisount.Text = Math.Round(Convert.ToDouble(txtBsaicPrice.Text) - Convert.ToDouble(txtDiscAmount.Text)).ToString();
                
                
                discountedMMValue.Text = (Math.Round((1 - Convert.ToDouble(totalCostLable.Text) / Convert.ToDouble(txtaftrerdisount.Text)) * 100, 0) + "%").ToString();
                //if (chkintrastate.CheckState == CheckState.Checked)
                //{
                //    txtIGSTAmount.Text = Math.Round((Convert.ToDouble(txtaftrerdisount.Text) * Convert.ToDouble(txtIGSTPer.Text)) / 100).ToString();
                //    txtSGSTAmount.Text = Math.Round((Convert.ToDouble(txtaftrerdisount.Text) * Convert.ToDouble(txtSgstPer.Text)) / 100).ToString();
                //}
                //else
                //{
                //    txtIGSTAmount.Text = Math.Round((Convert.ToDouble(txtaftrerdisount.Text) * Convert.ToDouble(txtIGSTPer.Text)) / 100).ToString();
                //    txtSGSTAmount.Text = "0";
                //}
                fnTotalPrice();
            }
        }

        private void frmSalesQuote_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (GLobalClass.fnMessageResult() == Global.sCLOSE_MESSAGE_RESULT_YES)
            {
                dOIRowCount = 0;
                dRowNumber = 0;

                this.Hide();
                form.Show();
            }
            else
            {
                e.Cancel = true;
            }
        }

        private void txtInsatallationCommision_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnNumberKeyPressOnly(sender, e);
        }

        private void txtInsatallationCommision_Leave(object sender, EventArgs e)
        {
            fnEmptyTextBox(sender, e);
        }
        private void txtInsatallationCommision_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtInsatallationCommision.Text))
            {
                if (cmbEnquireCurrency.SelectedIndex == 1)
                {
                    txtServiceTaxIGSTPercent.Text = "0";
                }
                if (chkintrastate.Checked == false)
                {
                    txtServiceTaxIGSTAmount.Text = ((Convert.ToDouble(txtInsatallationCommision.Text) * Convert.ToDouble(txtServiceTaxIGSTPercent.Text)) / 100).ToString();
                }
                else
                {
                    txtServiceTaxIGSTAmount.Text = ((Convert.ToDouble(txtInsatallationCommision.Text) * Convert.ToDouble(txtServiceTaxIGSTPercent.Text)) / 100).ToString();
                    txtServiceTaxSGSTAmount.Text = ((Convert.ToDouble(txtInsatallationCommision.Text) * Convert.ToDouble(txtServiceTaxSGSTPercent.Text)) / 100).ToString();
                }
                fnBasicPrice();
            }
        }

        private void btnQuotePricing_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(4);
            txtadditionalWarPer_TextChanged(sender, e);
        }

        private void btnBack1_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(1);
        }

        private void btnBack2_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(2);
        }

        private void btnBack3_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(3);
        }
        DataTable dtQuoteCountry = new DataTable();
        bool bCurrencyConverted = false;
        private void cmbEnquire_SelectedIndexChanged(object sender, EventArgs e)
        {



            

            // This Below code for provide the access for the BT

            if (LoginForm.GetUserDetails[2].ToLower() == "vivek g" || LoginForm.GetUserDetails[2].ToLower() == "sadat" || LoginForm.GetUserDetails[2].ToLower() == "ankur" || LoginForm.GetUserDetails[2].ToLower() == "rohit" || LoginForm.GetUserDetails[20].ToLower() == "shivakumar_narayanaswamy@instron.com" || LoginForm.GetUserDetails[2].ToLower() == "biss" || LoginForm.GetUserDetails[2] == "Hebbarrk")
            {
                this.OISalesCost.Visible = true;
                this.OImaterialMargin.Visible = true;
                this.SalesCostTemp.Visible = true;
                this.materialMargin.Visible = true;
                this.discountedMMValue.Visible = true;
                this.discountedMMlb.Visible = true;
            }



            switch (cmbEnquireCurrency.SelectedIndex)
            {
                case 0:
                    chkintrastate.Visible = true;
                    pnIncoterm.Enabled = true;
                    pnGst.Enabled = true;
                    cmbRegion.Text = "";
                    cmbRegion.Items.Clear();
                    cmbRegion.Items.Add("East");
                    cmbRegion.Items.Add("North");
                    cmbRegion.Items.Add("South");
                    cmbRegion.Items.Add("West");
                    cmbPaymentTerms.Enabled = true;
                    lblPrice.Text = "All Prices in INR";
                    cmbPaymentTerms.Text = "";
                    cmbPaymentTerms.Items.Clear();
                    cmbPaymentTerms.Items.Add("Advance");
                    cmbPaymentTerms.Items.Add("On Delivery");
                    cmbPaymentTerms.Items.Add("Letter of Credit");
                    cmbPaymentTerms.Items.Add("Others");
                    cmbPaymentTerms.SelectedIndex = 0;
                    lblregion.Text = "Region* :";
                    txtServiceTaxIGSTPercent.Text = "18";
                    txtIGSTPer.Text = "18";
                    lblFinalNetAmount.Text = "                  Total Price :";


                    if (dtQuoteEnquiryDetails.Rows.Count > 0)
                    {
                        dtPegRate = DAL.DTPegRate("").Tables[0];
                        if (dtPegRate.Rows.Count > 0)
                        {
                            dPegRate = Convert.ToDouble(dtPegRate.Rows[0][1].ToString());
                        }

                        if (dtQuoteEnquiryDetails.Rows[0]["Currency"].ToString() == "USD")
                        {
                            bCurrencyConverted = true;
                            dPegRate = 1 / dPegRate;
                            if (dgQuoteBOM.Rows.Count > 0)
                            {
                                if (cmbEnquireCurrency.Text == "INR")
                                {
                                    dtQuoteEnquiryDetails.Rows[0]["Currency"] = "INR";
                                    foreach (DataGridViewRow dr in dgQuoteBOM.Rows)
                                    {

                                        dr.Cells["SalesCost"].Value = Math.Round(Convert.ToDouble(dr.Cells["SalesCost"].Value) * dPegRate).ToString();
                                        dr.Cells["UnitPrice"].Value = Math.Round(Convert.ToDouble(dr.Cells["UnitPrice"].Value) * dPegRate).ToString();
                                        dr.Cells["TPrice"].Value = Math.Round(Convert.ToDouble(dr.Cells["TPrice"].Value) * dPegRate).ToString();
                                        dr.Cells["BreakupTotal"].Value = Math.Round(Convert.ToDouble(dr.Cells["BreakupTotal"].Value) * dPegRate).ToString();
                                        
                                    }
                                    foreach (DataGridViewRow dr in dgvOptionalItems.Rows)
                                    {

                                        dr.Cells["OISalesCost"].Value = Math.Round(Convert.ToDouble(dr.Cells["OISalesCost"].Value) * dPegRate).ToString();
                                        dr.Cells["OIUnitPrice"].Value = Math.Round(Convert.ToDouble(dr.Cells["OIUnitPrice"].Value) * dPegRate).ToString();
                                        dr.Cells["OITotalPrice"].Value = Math.Round(Convert.ToDouble(dr.Cells["OITotalPrice"].Value) * dPegRate).ToString();
                                        dr.Cells["OIBreakupTotal"].Value = Math.Round(Convert.ToDouble(dr.Cells["OIBreakupTotal"].Value) * dPegRate).ToString();
                                        
                                    }
                                    dtQuote.AcceptChanges();
                                    dtQuoteOptionalItems.AcceptChanges();
                                }
                            }
                            else
                            {
                                dtQuote = DAL.fnQuotationNumberLoadCurrencyData(2, cmbQuotationNumber.Text, cmbRevisionNumber.Text, dPegRate).Tables[0];
                                dtQuoteOptionalItems = DAL.fnQuotationNumberLoadCurrencyData(7, cmbQuotationNumber.Text, cmbRevisionNumber.Text, dPegRate).Tables[0];
                            }
                        }
                        else if (dtQuoteEnquiryDetails.Rows[0]["Currency"].ToString() == "INR")
                        {
                            if (dgQuoteBOM.Rows.Count > 0)
                            {
                                if (cmbEnquireCurrency.Text == "USD")
                                {
                                    dtQuoteEnquiryDetails.Rows[0]["Currency"] = "USD";
                                    if (bCurrencyConverted)
                                    {
                                        foreach (DataGridViewRow dr in dgQuoteBOM.Rows)
                                        {

                                            dr.Cells["SalesCost"].Value = Math.Round(Convert.ToDouble(dr.Cells["SalesCost"].Value) / dPegRate).ToString();
                                            dr.Cells["UnitPrice"].Value = Math.Round(Convert.ToDouble(dr.Cells["UnitPrice"].Value) / dPegRate).ToString();
                                            dr.Cells["TPrice"].Value = Math.Round(Convert.ToDouble(dr.Cells["TPrice"].Value) / dPegRate).ToString();
                                            dr.Cells["BreakupTotal"].Value = Math.Round(Convert.ToDouble(dr.Cells["BreakupTotal"].Value) / dPegRate).ToString();
                                            
                                        }
                                        foreach (DataGridViewRow dr in dgvOptionalItems.Rows)
                                        {

                                            dr.Cells["OISalesCost"].Value = Math.Round(Convert.ToDouble(dr.Cells["OISalesCost"].Value) / dPegRate).ToString();
                                            dr.Cells["OIUnitPrice"].Value = Math.Round(Convert.ToDouble(dr.Cells["OIUnitPrice"].Value) / dPegRate).ToString();
                                            dr.Cells["OITotalPrice"].Value = Math.Round(Convert.ToDouble(dr.Cells["OITotalPrice"].Value) / dPegRate).ToString();
                                            dr.Cells["OIBreakupTotal"].Value = Math.Round(Convert.ToDouble(dr.Cells["OIBreakupTotal"].Value) / dPegRate).ToString();
                                            
                                        }
                                        dtQuote.AcceptChanges();
                                        dtQuoteOptionalItems.AcceptChanges();
                                    }
                                }
                            }
                            else
                            {
                                dtQuote = DAL.fnQuotationNumberLoadCurrencyData(2, cmbQuotationNumber.Text, cmbRevisionNumber.Text, 1).Tables[0];
                                dtQuoteOptionalItems = DAL.fnQuotationNumberLoadCurrencyData(7, cmbQuotationNumber.Text, cmbRevisionNumber.Text, 1).Tables[0];
                            }
                            bCurrencyConverted = false;
                        }

                        if (dtQuote.Rows.Count > 0)
                        {
                            LastQuoteNumber = Convert.ToInt32(dtQuote.Rows[0]["QuoteNoList"].ToString());
                            dgQuoteBOM.AutoGenerateColumns = false;

                            //Added new code for the ADDmaterialMargin
                            decimal totalCost = 0;
                            try
                            {
                                if (!dtQuote.Columns.Contains("materialMargin"))
                                {
                                    dtQuote.Columns.Add("materialMargin", typeof(string));
                                }

                                //SalesCostTemp

                                if (!dtQuote.Columns.Contains("SalesCostTemp"))
                                {
                                    dtQuote.Columns.Add("SalesCostTemp", typeof(string));
                                }

                                foreach (DataRow row in dtQuote.Rows)
                                {
                                    SalesProductCodeDetails = DAL.fnSalesProductCodeName(row["ProductCode"].ToString()).Tables[0]; // SalesProductCodeDetails.Rows[0]["SalesCost"]
                                    //MessageBox.Show(row["ProductCode"].ToString(), "ProductCode1");
                                    //MessageBox.Show(SalesProductCodeDetails.Rows[0]["SalesCost"].ToString(), SalesProductCodeDetails.Rows[0]["ProductCode"].ToString());


                                   

                                    if (SalesProductCodeDetails.Rows[0]["SalesCost"] != DBNull.Value && row["UnitPrice"] != DBNull.Value)
                                    {
                                        row["SalesCostTemp"] = SalesProductCodeDetails.Rows[0]["SalesCost"];

                                        decimal salesCost = Convert.ToDecimal(SalesProductCodeDetails.Rows[0]["SalesCost"]);
                                        decimal unitPrice = Convert.ToDecimal(row["UnitPrice"]);
                                        decimal quantity = Convert.ToDecimal(row["Quantity"]);

                                       

                                        totalCost += quantity * salesCost;

                                        if (unitPrice != 0) // Avoid division by zero
                                        {
                                            decimal mmValue = 1 - (salesCost / unitPrice);
                                            // MessageBox.Show(Math.Round(mmValue, 2).ToString(), "materialMargin");
                                            row["materialMargin"] = Math.Round(mmValue * 100, 0) + "%";
                                        }
                                        else
                                        {
                                            row["materialMargin"] = 0; // or set to 0 or some default
                                        }
                                    }
                                    else
                                    {
                                        row["materialMargin"] = 0; // or set to 0 or some default
                                    }
                                }
                                totalCostLable.Text = totalCost.ToString();
                               
                                
                            }
                            catch (Exception error)
                            {
                                MessageBox.Show( error.Message, "materialMargin Error");
                            }


                            
                    
                            dgQuoteBOM.DataSource = dtQuote;
                            dgWriteUP.AutoGenerateColumns = false;
                            dgWriteUP.DataSource = dtQuote;
                            Datagridviewcolor("ProductCod", dgQuoteBOM);
                            fnTotalCalucalation();
                        }
                        if (dtQuoteOptionalItems.Rows.Count > 0)
                        {
                            dgvOptionalItems.AutoGenerateColumns = false;
                            dgvOptionalItems.DataSource = dtQuoteOptionalItems;
                            dgOIWriteUP.AutoGenerateColumns = false;
                            dgOIWriteUP.DataSource = dtQuoteOptionalItems;
                            Datagridviewcolor("OIProductCode", dgvOptionalItems);
                            fnOptionalItemTotalCalculation();
                        }

                    }
                    dPegRate = 1;
                    break;
                case 1:
                    chkintrastate.Visible = false;
                    cmbPaymentTerms.Text = "";
                    cmbPaymentTerms.Items.Clear();
                    cmbPaymentTerms.Items.Add("Letter of Credit");
                    cmbPaymentTerms.Items.Add("Others");
                    lblPrice.Text = "All Prices in USD";
                    cmbPaymentTerms.SelectedIndex = 0;
                    cmbRegion.Text = "";
                    txtServiceTaxIGSTPercent.Text = "0";
                    txtServiceTaxIGSTAmount.Text = "0";
                    cmbRegion.Items.Clear();

                    dtQuoteCountry = DAL.fnQuoteCountry(0).Tables[0];

                    foreach (DataRow DR in dtQuoteCountry.Rows)
                    {
                        if (!cmbRegion.Items.Contains(DR[0].ToString()))
                            cmbRegion.Items.Add(DR[0].ToString());
                    }
                    pnIncoterm.Enabled = false;
                    pnGst.Enabled = false;
                    lblFinalNetAmount.Text = "Total Ex-Factory Price :";
                    lblregion.Text = "Country*:";
                    txtIGSTPer.Text = "0";

                    dtPegRate = DAL.DTPegRate("").Tables[0];
                    if (dtPegRate.Rows.Count > 0)
                    {
                        dPegRate = Convert.ToDouble(dtPegRate.Rows[0][1].ToString());
                    }
                    else
                    {
                        dPegRate = 1;
                    }

                    if (dtQuoteEnquiryDetails.Rows.Count > 0)
                    {
                        if (dtQuoteEnquiryDetails.Rows[0]["Currency"].ToString() == "INR")
                        {

                            // if (!bCurrencyConverted)
                            //{

                            if (dgQuoteBOM.Rows.Count > 0)
                            {
                                if (cmbEnquireCurrency.Text == "USD")
                                {
                                    bCurrencyConverted = true;
                                    dtQuoteEnquiryDetails.Rows[0]["Currency"] = "USD";
                                    foreach (DataGridViewRow dr in dgQuoteBOM.Rows)
                                    {

                                        dr.Cells["SalesCost"].Value = Math.Round(Convert.ToDouble(dr.Cells["SalesCost"].Value) * dPegRate).ToString();
                                        dr.Cells["UnitPrice"].Value = Math.Round(Convert.ToDouble(dr.Cells["UnitPrice"].Value) * dPegRate).ToString();
                                        dr.Cells["TPrice"].Value = Math.Round(Convert.ToDouble(dr.Cells["TPrice"].Value) * dPegRate).ToString();
                                        dr.Cells["BreakupTotal"].Value = Math.Round(Convert.ToDouble(dr.Cells["BreakupTotal"].Value) * dPegRate).ToString();
                                       
                                    }
                                    foreach (DataGridViewRow dr in dgvOptionalItems.Rows)
                                    {

                                        dr.Cells["OSalesCost"].Value = Math.Round(Convert.ToDouble(dr.Cells["OSalesCost"].Value) * dPegRate).ToString();
                                        dr.Cells["OUnitPrice"].Value = Math.Round(Convert.ToDouble(dr.Cells["OUnitPrice"].Value) * dPegRate).ToString();
                                        dr.Cells["OITotalPrice"].Value = Math.Round(Convert.ToDouble(dr.Cells["OITotalPrice"].Value) * dPegRate).ToString();
                                        dr.Cells["OBreakupTotal"].Value = Math.Round(Convert.ToDouble(dr.Cells["OBreakupTotal"].Value) * dPegRate).ToString();
                                      
                                    }
                                    dtQuote.AcceptChanges();
                                    dtQuoteOptionalItems.AcceptChanges();
                                }
                            }
                            else
                            {
                                dtQuote = DAL.fnQuotationNumberLoadCurrencyData(2, cmbQuotationNumber.Text, cmbRevisionNumber.Text, dPegRate).Tables[0];
                                dtQuoteOptionalItems = DAL.fnQuotationNumberLoadCurrencyData(7, cmbQuotationNumber.Text, cmbRevisionNumber.Text, dPegRate).Tables[0];
                            }
                            //  }
                        }
                        else if (dtQuoteEnquiryDetails.Rows[0]["Currency"].ToString() == "USD")
                        {
                            if (dgQuoteBOM.Rows.Count > 0)
                            {
                                if (bCurrencyConverted)
                                {
                                    if (cmbEnquireCurrency.Text == "INR")
                                    {
                                        dtQuoteEnquiryDetails.Rows[0]["Currency"] = "INR";
                                        foreach (DataGridViewRow dr in dgQuoteBOM.Rows)
                                        {

                                            dr.Cells["SalesCost"].Value = Math.Round(Convert.ToDouble(dr.Cells["SalesCost"].Value) / dPegRate).ToString();
                                            dr.Cells["UnitPrice"].Value = Math.Round(Convert.ToDouble(dr.Cells["UnitPrice"].Value) / dPegRate).ToString();
                                            dr.Cells["TPrice"].Value = Math.Round(Convert.ToDouble(dr.Cells["TPrice"].Value) / dPegRate).ToString();
                                            dr.Cells["BreakupTotal"].Value = Math.Round(Convert.ToDouble(dr.Cells["BreakupTotal"].Value) / dPegRate).ToString();
                                            
                                        }
                                        foreach (DataGridViewRow dr in dgvOptionalItems.Rows)
                                        {

                                            dr.Cells["OSalesCost"].Value = Math.Round(Convert.ToDouble(dr.Cells["OSalesCost"].Value) / dPegRate).ToString();
                                            dr.Cells["OUnitPrice"].Value = Math.Round(Convert.ToDouble(dr.Cells["OUnitPrice"].Value) / dPegRate).ToString();
                                            dr.Cells["OITotalPrice"].Value = Math.Round(Convert.ToDouble(dr.Cells["OITotalPrice"].Value) / dPegRate).ToString();
                                            dr.Cells["OBreakupTotal"].Value = Math.Round(Convert.ToDouble(dr.Cells["OBreakupTotal"].Value) / dPegRate).ToString();
                                            
                                        }
                                        dtQuote.AcceptChanges();
                                        dtQuoteOptionalItems.AcceptChanges();
                                    }
                                }
                            }
                            else
                            {
                                dtQuote = DAL.fnQuotationNumberLoadCurrencyData(2, cmbQuotationNumber.Text, cmbRevisionNumber.Text, 1).Tables[0];
                                dtQuoteOptionalItems = DAL.fnQuotationNumberLoadCurrencyData(7, cmbQuotationNumber.Text, cmbRevisionNumber.Text, 1).Tables[0];
                            }
                            bCurrencyConverted = false;
                        }

                        if (dtQuote.Rows.Count > 0)
                        {

                            //Added new code for the ADDmaterialMargin

                            decimal totalCost = 0;
                            try
                            {
                                if (!dtQuote.Columns.Contains("materialMargin"))
                                {
                                    dtQuote.Columns.Add("materialMargin", typeof(string));
                                }

                                //SalesCostTemp

                                if (!dtQuote.Columns.Contains("SalesCostTemp"))
                                {
                                    dtQuote.Columns.Add("SalesCostTemp", typeof(string));
                                }



                                foreach (DataRow row in dtQuote.Rows)
                                {
                                   // MessageBox.Show(row["ProductCode"].ToString(), "ProductCode2");
                                    SalesProductCodeDetails = DAL.fnSalesProductCodeName(row["ProductCode"].ToString()).Tables[0];
                                    
                                    if (SalesProductCodeDetails.Rows[0]["SalesCost"] != DBNull.Value && row["UnitPrice"] != DBNull.Value)
                                    {
                                        row["SalesCostTemp"] = SalesProductCodeDetails.Rows[0]["SalesCost"];
                                        decimal salesCost = Convert.ToDecimal(SalesProductCodeDetails.Rows[0]["SalesCost"]);
                                        decimal unitPrice = Convert.ToDecimal(row["UnitPrice"]);
                                        decimal quantity = Convert.ToDecimal(row["Quantity"]);

                                       

                                        totalCost += quantity * salesCost;

                                        if (unitPrice != 0) // Avoid division by zero
                                        {
                                            decimal mmValue = 1 - (salesCost / unitPrice);
                                            // MessageBox.Show(Math.Round(mmValue, 2).ToString(), "materialMargin");
                                            row["materialMargin"] = Math.Round(mmValue * 100, 0) + "%";
                                        }
                                        else
                                        {
                                            row["materialMargin"] = 0; // or set to 0 or some default
                                        }
                                    }
                                    else
                                    {
                                        row["materialMargin"] = 0; // or set to 0 or some default
                                    }
                                }
                                totalCostLable.Text = totalCost.ToString();
                               

                            }
                            catch (Exception error)
                            {
                                MessageBox.Show(error.Message, "materialMargin Error");
                            }





                            LastQuoteNumber = Convert.ToInt32(dtQuote.Rows[0]["QuoteNoList"].ToString());
                            dgQuoteBOM.AutoGenerateColumns = false;
                            dgQuoteBOM.DataSource = dtQuote;
                            dgWriteUP.AutoGenerateColumns = false;
                            dgWriteUP.DataSource = dtQuote;
                            Datagridviewcolor("ProductCod", dgQuoteBOM);
                            fnTotalCalucalation();
                        }
                        if (dtQuoteOptionalItems.Rows.Count > 0)
                        {
                            dgvOptionalItems.AutoGenerateColumns = false;
                            

                            //Added new code for the ADDmaterialMargin

                            try
                            {
                                if (!dtQuoteOptionalItems.Columns.Contains("OImaterialMargin"))
                                {
                                    dtQuoteOptionalItems.Columns.Add("OImaterialMargin", typeof(string));
                                }

                                //SalesCostTemp

                                if (!dtQuote.Columns.Contains("SalesCostTemp"))
                                {
                                    dtQuote.Columns.Add("SalesCostTemp", typeof(string));
                                }



                                foreach (DataRow row in dtQuoteOptionalItems.Rows)
                                {
                                   // MessageBox.Show(row["ProductCode"].ToString(), "ProductCode3");
                                    SalesProductCodeDetails = DAL.fnSalesProductCodeName(row["ProductCode"].ToString()).Tables[0]; // SalesProductCodeDetails.Rows[0]["SalesCost"]
                                   
                                    if (SalesProductCodeDetails.Rows[0]["SalesCost"] != DBNull.Value && row["UnitPrice"] != DBNull.Value)
                                    {
                                        row["SalesCostTemp"] = SalesProductCodeDetails.Rows[0]["SalesCost"];
                                        decimal salesCost = Convert.ToDecimal(SalesProductCodeDetails.Rows[0]["SalesCost"]);
                                        decimal unitPrice = Convert.ToDecimal(row["UnitPrice"]);
                                        //decimal quantity = Convert.ToDecimal(row["Quantity"]);



                                        //totalCost += quantity * salesCost;

                                        if (unitPrice != 0) // Avoid division by zero
                                        {
                                            decimal mmValue = 1 - (salesCost / unitPrice);
                                            // MessageBox.Show(Math.Round(mmValue, 2).ToString(), "materialMargin");
                                            row["OImaterialMargin"] = Math.Round(mmValue * 100, 0) + "%";
                                        }
                                        else
                                        {
                                            row["OImaterialMargin"] = 0; // or set to 0 or some default
                                        }
                                    }
                                    else
                                    {
                                        row["OImaterialMargin"] = 0; // or set to 0 or some default
                                    }
                                }



                            }
                            catch (Exception error)
                            {
                                MessageBox.Show(error.Message, "OImaterialMargin Error");
                            }

                            dgvOptionalItems.DataSource = dtQuoteOptionalItems;
                            dgOIWriteUP.AutoGenerateColumns = false;
                            dgOIWriteUP.DataSource = dtQuoteOptionalItems;
                            Datagridviewcolor("OIProductCode", dgvOptionalItems);
                            fnOptionalItemTotalCalculation();
                        }
                    }

                    else
                    {

                        dtQuoteEnquiryDetails = DAL.fnQuotationNumberLoadData(1, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];
                        //if (dgQuoteBOM.Rows.Count == 0)
                        //{
                        //    dtQuote = DAL.fnQuotationNumberLoadData(2, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];
                        //}
                        //if (dtQuoteOptionalItems.Rows.Count == 0)
                        //{
                        //    dtQuoteOptionalItems = DAL.fnQuotationNumberLoadData(7, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];
                        //}
                        //QuoteTaxDetails = DAL.fnQuotationNumberLoadData(3, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];
                    }


                    //   fnQuotationNumberLoadCurrencyData
                    break;
            }
        }

        private void cmbPaymentTerms_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbPaymentTerms.SelectedItem.ToString())
            {
                case "Advance":
                    txtAdvance.Text = "40";
                    txtAfterPDI.Text = "50";
                    txtAfterPDI.Visible = true;
                    label26.Visible = true;
                    TxtAfterInstal.Text = "10";
                    break;
                case "On Delivery":
                    txtAdvance.Text = "90";
                    txtAfterPDI.Text = "00";
                    txtAfterPDI.Visible = true;
                    label26.Visible = true;
                    TxtAfterInstal.Text = "10";
                    break;

                case "Letter of Credit":
                    txtAdvance.Text = "90";
                    txtAfterPDI.Visible = false;
                    label26.Visible = false;
                    txtAfterPDI.Text = "00";
                    TxtAfterInstal.Text = "10";
                    break;
                case "Others":
                    txtAdvance.Text = "00";
                    txtAfterPDI.Visible = false;
                    label26.Visible = false;
                    txtAfterPDI.Text = "00";
                    TxtAfterInstal.Text = "00";
                    break;
            }
        }

        double dCurrentcell = 0;
        double dCurrentcell1 = 0;
        string sRow = "";
        private void dgQuoteBOM_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (dgQuoteBOM.CurrentRow != null)
                {
                    dCurrentcell = 0;
                    dCurrentcell1 = 0.1;

                    dCurrentcell = Convert.ToDouble(dgQuoteBOM.CurrentRow.Cells["SLNO"].Value.ToString());
                    sRow = dgQuoteBOM.CurrentRow.Cells["ProductGroup"].Value.ToString();
                    if (dCurrentcell == Math.Floor(dCurrentcell))
                    {
                        DialogResult DR = MessageBox.Show("If you delete this the complete product items will be deleted. \nDo you want to proceed?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                        if (DR == DialogResult.Yes)
                        {
                            if (cmbSelectQuoteType.Text == "Update Quote")
                            {
                                GLobalClass.iStatus = DAL.fnAddQuoteBOMProduct(Global.uDELETE, cmbQuotationNumber.Text, Convert.ToInt32(cmbRevisionNumber.Text), dgQuoteBOM.CurrentRow.Cells["ProductCod"].Value.ToString(), "", "", 0, 0, 0, 0, 0, 0, "", "", "");
                            }

                            for (int v = 0; v < dgQuoteBOM.Rows.Count; v++)
                            {
                                if (dgQuoteBOM[1, v].Value.ToString() == sRow)
                                {
                                    dgQuoteBOM.Rows.RemoveAt(v);
                                    v--;
                                }
                            }
                            foreach (DataGridViewRow dr in dgQuoteBOM.Rows)
                            {
                                if (Convert.ToDouble(dr.Cells["SLNO"].Value.ToString()) > dCurrentcell)
                                {
                                    dr.Cells["SLNO"].Value = (Convert.ToDouble(dr.Cells["SLNO"].Value) - 1).ToString();
                                }
                            }
                            dtQuote.AcceptChanges();

                            fnTotalCalucalation();
                        }
                    }
                    else
                    {
                        if (cmbSelectQuoteType.Text == "Update Quote")
                        {
                            GLobalClass.iStatus = DAL.fnAddQuoteBOMProduct(Global.uDELETE, cmbQuotationNumber.Text, Convert.ToInt32(cmbRevisionNumber.Text), dgQuoteBOM.CurrentRow.Cells["ProductCod"].Value.ToString(), "", "", 0, 0, 0, 0, 0, 0, "", "", "");
                        }
                        dgQuoteBOM.Rows.RemoveAt(dgQuoteBOM.Rows.IndexOf(dgQuoteBOM.CurrentRow));


                        double dCheck = 0;
                        double dCurrentValue = Math.Truncate(dCurrentcell);
                        double dMinusValue;
                        double dCurrentMinusValue;
                        if (dCurrentValue == 0)
                        {
                            dCurrentValue = 1;
                        }
                        foreach (DataGridViewRow dr in dgQuoteBOM.Rows)
                        {
                            if (Convert.ToDouble(dr.Cells["SLNO"].Value.ToString()) > dCurrentValue && Convert.ToDouble(dr.Cells["SLNO"].Value.ToString()) < (dCurrentValue + 1))
                            {
                                dCheck++;
                            }
                        }

                        if (dCheck <= 9)
                        {
                            dMinusValue = 0.1;
                        }
                        else
                        {
                            dMinusValue = 0.01;
                        }
                        dCurrentMinusValue = dCurrentValue;

                        foreach (DataGridViewRow dr in dgQuoteBOM.Rows)
                        {
                            if (Convert.ToDouble(dr.Cells["SLNO"].Value.ToString()) > dCurrentValue && Convert.ToDouble(dr.Cells["SLNO"].Value.ToString()) < (dCurrentValue + 1))
                            {
                                dCurrentMinusValue += dMinusValue;
                                dr.Cells["SLNO"].Value = (dCurrentMinusValue).ToString();
                            }
                        }
                        dtQuote.AcceptChanges();
                        fnTotalCalucalation();
                    }
                }
            }
        }

        private void chkintrastate_CheckedChanged(object sender, EventArgs e)
        {
            if (chkintrastate.CheckState == CheckState.Checked)
            {
                //txtIGSTPer.Text = "9";
                //txtServiceTaxIGSTPercent.Text = "9";
                //lblServiceIgst.Text = "CGST :";
                //lblIgst.Text = "CGST :";
                //label41.Visible = true;
                //lblSGST.Visible = true;
                //pnInstallCommision.Visible = true;
                //txtSgstPer.Visible = true;
                //txtSGSTAmount.Visible = true;
                //txtServiceTaxIGSTAmount.Text = ((Convert.ToDouble(txtInsatallationCommision.Text) * Convert.ToDouble(txtServiceTaxIGSTPercent.Text)) / 100).ToString();
                //txtServiceTaxSGSTAmount.Text = ((Convert.ToDouble(txtInsatallationCommision.Text) * Convert.ToDouble(txtServiceTaxSGSTPercent.Text)) / 100).ToString();
                txtIGSTPer.Text = "18";
                lblIgst.Text = "IGST :";
                txtServiceTaxIGSTPercent.Text = "18";
                lblServiceIgst.Text = "IGST :";
                pnInstallCommision.Visible = false;
                txtSgstPer.Visible = false;
                txtSGSTAmount.Visible = false;
                label41.Visible = false;
                lblSGST.Visible = false;
                txtSGSTAmount.Text = "0";
                txtServiceTaxIGSTAmount.Text = ((Convert.ToDouble(txtInsatallationCommision.Text) * Convert.ToDouble(txtServiceTaxIGSTPercent.Text)) / 100).ToString();
                txtServiceTaxSGSTAmount.Text = "0";
            }
            else
            {
                txtIGSTPer.Text = "18";
                lblIgst.Text = "IGST :";
                txtServiceTaxIGSTPercent.Text = "18";
                lblServiceIgst.Text = "IGST :";
                pnInstallCommision.Visible = false;
                txtSgstPer.Visible = false;
                txtSGSTAmount.Visible = false;
                label41.Visible = false;
                lblSGST.Visible = false;
                txtSGSTAmount.Text = "0";
                txtServiceTaxIGSTAmount.Text = ((Convert.ToDouble(txtInsatallationCommision.Text) * Convert.ToDouble(txtServiceTaxIGSTPercent.Text)) / 100).ToString();
                txtServiceTaxSGSTAmount.Text = "0";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
        DataTable dtAllRevisionNumber = new DataTable();
        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            NewRevisionNumber = 0;
            dtAllRevisionNumber = DAL.fnQuotationNumberLoadData(5, cmbQuotationNumber.Text, "").Tables[0];
            cmbRevisionNumber.Items.Clear();
            cmbRevisionNumber.Text = "";
            if (dtAllRevisionNumber.Rows.Count > 0)
            {
                foreach (DataRow DR in dtAllRevisionNumber.Rows)
                {
                    if (!cmbRevisionNumber.Items.Contains(DR["RevisionNumber"].ToString()))
                        cmbRevisionNumber.Items.Add(DR["RevisionNumber"].ToString());
                }
            }
        }

        private void label38_Click(object sender, EventArgs e)
        {

        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmbIncoTerms_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbIncoTerms.SelectedIndex)
            {
                case 1:
                    pnIncoterm.Enabled = true;
                    break;

                case 0:
                case 2:
                    pnIncoterm.Enabled = false;
                    break;
            }
        }

        private void txtAdvance_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnNumberKeyPressOnly(sender, e);
        }

        private void txtAdvance_Leave(object sender, EventArgs e)
        {
            fnEmptyTextBox(sender, e);
            fnEmptyTextBoxValidate(1);
        }

        private void txtAfterPDI_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnNumberKeyPressOnly(sender, e);
        }

        private void txtAfterPDI_Leave(object sender, EventArgs e)
        {
            fnEmptyTextBox(sender, e);
            fnEmptyTextBoxValidate(2);
        }

        private void TxtAfterInstal_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnNumberKeyPressOnly(sender, e);
        }

        private void TxtAfterInstal_Leave(object sender, EventArgs e)
        {
            fnEmptyTextBox(sender, e);
            fnEmptyTextBoxValidate(3);
        }

        private void fnEmptyTextBoxValidate(int iTextBox)
        {
            switch (cmbPaymentTerms.SelectedItem.ToString())
            {
                case "Advance":
                case "On Delivery":
                    if ((Convert.ToDouble(txtAdvance.Text) + Convert.ToDouble(txtAfterPDI.Text) + Convert.ToDouble(TxtAfterInstal.Text)) > 100)
                    {
                        if (iTextBox == 1)
                        {
                            txtAdvance.Focus();
                            MessageBox.Show("The Combination value is exceeding 100% ", "Eroor", 0, MessageBoxIcon.Error);
                        }
                        else if (iTextBox == 2)
                        {
                            txtAfterPDI.Focus();
                            MessageBox.Show("The Combination value is exceeding 100% ", "Eroor", 0, MessageBoxIcon.Error);
                        }
                        else if (iTextBox == 3)
                        {
                            TxtAfterInstal.Focus();
                            MessageBox.Show("The Combination value is exceeding 100% ", "Eroor", 0, MessageBoxIcon.Error);
                        }
                    }
                    break;

                case "Letter of Credit":
                case "Others":
                    if ((Convert.ToDouble(txtAdvance.Text) + Convert.ToDouble(TxtAfterInstal.Text)) > 100)
                    {
                        if (iTextBox == 1)
                        {
                            txtAdvance.Focus();
                            MessageBox.Show("The Combination value is exceeding 100% ", "Eroor", 0, MessageBoxIcon.Error);
                        }
                        else if (iTextBox == 3)
                        {
                            TxtAfterInstal.Focus();
                            MessageBox.Show("The Combination value is exceeding 100% ", "Eroor", 0, MessageBoxIcon.Error);
                        }
                    }
                    break;
            }
        }

        private void txtBsaicPrice_TextChanged(object sender, EventArgs e)
        {
            //  txtaftrerdisount.Text = (Convert.ToDouble(txtBsaicPrice.Text) - Convert.ToDouble(txtDiscAmount.Text)).ToString();
            fnTotalPrice();
            txtDiscount_TextChanged(sender, e);
        }

        private void chkrevisequote_CheckedChanged(object sender, EventArgs e)
        {

        }
        string sYear;
        string s4DigitNumber;
        DataTable dtNewRevisionNumber = new DataTable();
        private void btnGenarateQuote_Click(object sender, EventArgs e)
        {
            sQuotationNumber = "";
            btnPreview.Enabled = false;
            if (btnGenarateQuote.Text == "Generate Quote")
            {
                //sYear = DateTime.Today.Year.ToString();
                sYear = DateTime.Now.Year.ToString();
                //MessageBox.Show(sYear, "Date...!");
                dtQuotationNumber = DAL.fnQuotationNumber(null, null).Tables[0];

                if (dtQuotationNumber.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtQuotationNumber.Rows[0]["QuoteNoList"].ToString()))
                    {
                        LastQuoteNumber = Convert.ToInt32(dtQuotationNumber.Rows[0]["QuoteNoList"].ToString());
                        LastQuoteNumber++;
                        //int sequence = LastQuoteNumber % 100_000;       // keep only the 5-digit counter
                        sQuotationNumber = "BISQ" + sYear + LastQuoteNumber.ToString().Substring(4);
                        //sQuotationNumber = ("BISQ" + LastQuoteNumber);
                    }
                    else
                    {
                        string value = String.Format("{0:D4}", 1);
                        sQuotationNumber = ("BISQ" + sYear + value);
                       
                        s4DigitNumber = sQuotationNumber.Substring(4, 8);
                        LastQuoteNumber = Convert.ToInt32(s4DigitNumber);
                    }


                    InsertQuote(Global.uINSERT, sQuotationNumber, 0);

                    if (cmbSelectQuoteType.Text == "Copy Quote")
                    {
                        cmbQuotationNumber.Items.Add(sQuotationNumber).ToString();
                        cmbQuotationNumber.SelectedItem = sQuotationNumber;
                        cmbRevisionNumber.Items.Add("0").ToString();
                        cmbRevisionNumber.SelectedItem = "0";
                    }

                    MessageBox.Show("The new quotation '" + sQuotationNumber + "' genarated successfully ", "Success", 0, MessageBoxIcon.Information);
                }
            }

            else if (btnGenarateQuote.Text == "Update Quote")
            {
                DialogResult DR = MessageBox.Show("Do you want to update the selected quote " + cmbQuotationNumber.Text + " and revision number " + cmbRevisionNumber.Text + "", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DR == DialogResult.Yes)
                {
                    GLobalClass.iStatus = DAL.fnAddQuoteBOMProduct(4, cmbQuotationNumber.Text, Convert.ToInt32(cmbRevisionNumber.Text), "", "", "", 0, 0, 0, 0, 0, 0, "", "", "");
                    GLobalClass.iStatus = DAL.fnAddOptionalQuoteBOMProduct(4, cmbQuotationNumber.Text, Convert.ToInt32(cmbRevisionNumber.Text), "", "", "", 0, 0, 0, 0, 0, 0, "", "", "");
                    GLobalClass.iStatus = DAL.fnAddQuoteTaxDetails(Global.uDELETE, cmbQuotationNumber.Text, Convert.ToInt32(cmbRevisionNumber.Text), 0, true, 0, 0, 0, 0, 0, 0, true, 0, 0, 0, 0, 0, 0, 0, 0, 0, "", 0, 0, 0, 0, 0, 0, 0, 0, 0);
                    GLobalClass.iStatus = DAL.fnAddQuoteEnquiryDetails(Global.uDELETE, cmbQuotationNumber.Text, Convert.ToInt32(cmbRevisionNumber.Text), "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", 0, "", "", "", "", "", "", "", "", "", "", "", "", "");
                    GLobalClass.iStatus = DAL.fnAddQuoteOpportunityDetails(Global.uDELETE, cmbQuotationNumber.Text, Convert.ToInt32(cmbRevisionNumber.Text), cmbLabtype.Text, cmbBusinessector.Text, cmbprimaryind.Text, cmbprimarymaterial.Text, cmbprimarymtrldetail.Text, cmbApplication.Text,
                                                                         cmbTestEnvironment.Text, cmbStatus.Text, cmbStage.Text, cmbtypeofcustomer.Text, txtExpectedValueUSD.Text, dtpExpectedOrderPlacementdate.Text, cmbProbabality.Text, txtCompetation.Text, txtSpecifyOthers.Text, cmbWinLose.Text, txtWonReason.Text, txtLostReason.Text);

                    InsertQuote(Global.uINSERT, cmbQuotationNumber.Text, Convert.ToInt32(cmbRevisionNumber.Text));

                    MessageBox.Show("The quotation '" + cmbQuotationNumber.Text + "' updated successfully ", "Success", 0, MessageBoxIcon.Information);
                }
            }

            else if (btnGenarateQuote.Text == "Revise Quote")
            {
                DialogResult DR = MessageBox.Show("Do you want to revise the selected quote '" + cmbQuotationNumber.Text + "'", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DR == DialogResult.Yes)
                {

                    dtNewRevisionNumber = DAL.fnQuotationNumberLoadData(6, cmbQuotationNumber.Text, "").Tables[0];
                    NewRevisionNumber = 0;
                    if (dtNewRevisionNumber.Rows.Count > 0)
                    {
                        NewRevisionNumber = Convert.ToInt32(dtNewRevisionNumber.Rows[0]["RevisionNumber"].ToString());
                        NewRevisionNumber++;
                        cmbRevisionNumber.Items.Add(NewRevisionNumber.ToString()).ToString();
                        cmbRevisionNumber.SelectedItem = NewRevisionNumber.ToString();
                        InsertQuote(Global.uINSERT, cmbQuotationNumber.Text, NewRevisionNumber);
                        MessageBox.Show("The quotation ' " + cmbQuotationNumber.Text + " ' revised to ' " + NewRevisionNumber + " '  successfully ", "Success", 0, MessageBoxIcon.Information);
                    }
                }
            }
            if (cheSetReminder.Checked == true)
            {
                ReminderExample();
            }
            btnTechQuote.Enabled = true;
            btnFinQuote.Enabled = true;
            btnGenarateQuote.Enabled = false;
        }
        int NewRevisionNumber = 0;
        private void InsertQuote(uint InsertorUpdate, string sQuotationNo, int RevisionNumber)
        {
            foreach (DataGridViewRow dr in dgQuoteBOM.Rows)
            {
                GLobalClass.iStatus = DAL.fnAddQuoteBOMProduct(InsertorUpdate, sQuotationNo, RevisionNumber, dr.Cells["ProductCod"].Value.ToString()
                                                                , dr.Cells["ProductName"].Value.ToString(), dr.Cells["Description"].Value.ToString().Trim(),
                                                                Convert.ToDouble(dr.Cells["SalesCost"].Value), Convert.ToDouble(dr.Cells["Quantity"].Value),
                                                                Convert.ToDouble(dr.Cells["UnitPrice"].Value), Convert.ToDouble(dr.Cells["TPrice"].Value),
                                                                Convert.ToDouble(dr.Cells["BreakupTotal"].Value), LastQuoteNumber,
                                                                 dr.Cells["SLNO"].Value.ToString(), dr.Cells["ProductGroup"].Value.ToString(), dr.Cells["SP"].Value.ToString());
            }
            foreach (DataGridViewRow dr in dgWriteUP.Rows)
            {
                GLobalClass.iStatus = DAL.fnAddQuoteBOMProduct(Global.uUPDATE, sQuotationNo, RevisionNumber, dr.Cells["WUProductcode"].Value.ToString()
                     , "", dr.Cells["WUDescription"].Value.ToString(), 0, 0, 0, 0, 0, 0, dr.Cells["WUSlNo"].Value.ToString(), "", "");
            }

            foreach (DataGridViewRow dr in dgvOptionalItems.Rows)
            {
                GLobalClass.iStatus = DAL.fnAddOptionalQuoteBOMProduct(InsertorUpdate, sQuotationNo, RevisionNumber, dr.Cells["OIProductCode"].Value.ToString()
                                                                , dr.Cells["OIProductName"].Value.ToString(), dr.Cells["OIProductDescription"].Value.ToString().Trim(),
                                                                Convert.ToDouble(dr.Cells["OISalesCost"].Value), Convert.ToDouble(dr.Cells["OIQuantity"].Value),
                                                                Convert.ToDouble(dr.Cells["OIUnitPrice"].Value), Convert.ToDouble(dr.Cells["OITotalPrice"].Value),
                                                                Convert.ToDouble(dr.Cells["OIBreakupTotal"].Value), LastQuoteNumber
                                                                , dr.Cells["OISLNo"].Value.ToString(), dr.Cells["OIProductGroup"].Value.ToString(), dr.Cells["SP1"].Value.ToString());
            }

            foreach (DataGridViewRow dr in dgOIWriteUP.Rows)
            {
                GLobalClass.iStatus = DAL.fnAddOptionalQuoteBOMProduct(Global.uUPDATE, sQuotationNo, RevisionNumber, dr.Cells["WUOIProductCode"].Value.ToString()
                     , "", dr.Cells["WUOIProductDescription"].Value.ToString(), 0, 0, 0, 0, Convert.ToDouble(dr.Cells["DGOISlNo"].Value.ToString()), 0, dr.Cells["DGOISlNo"].Value.ToString(), "", "");
            }

            GLobalClass.iStatus = DAL.fnAddQuoteEnquiryDetails(Global.uINSERT, sQuotationNo, RevisionNumber, cmbEnquireCurrency.Text, cmbRegion.Text, cmbLeadGenarated.Text, cmbQuotationfor.Text, cmbModel.Text,
                                                                cmbCapacity.Text, cmbCustomer.Text, txtCusCode.Text, dtpEnquireDate.Text, txtQuoteName.Text, txtTenderNo.Text, txtQuoteValidity.Text,
                                                                txtQuoteWarranty.Text, txtLeadTime.Text, cmbIncoTerms.Text, txtaddNote.Text, lblPrepareBy.Text, dPegRate, cmbQuoteCompany.Text, cmbeightytwenty.Text,
                                                                cmblevelofcustomization.Text, txtModelNumber.Text, cmbQuoteType.Text, txtEnquiryNumber.Text, txtCustomertype.Text, txtContactPerson1.Text,
                                                                txtContactNumber1.Text, txtDepartment1.Text, txtAddress.Text, txtEmailID1.Text, cmbBank.Text);

            GLobalClass.iStatus = DAL.fnAddQuoteTaxDetails(InsertorUpdate, sQuotationNo, RevisionNumber, Convert.ToDouble(txtTotalPrice.Text), Convert.ToBoolean(chkBreakup.Checked), Convert.ToDouble(txtJackup.Text),
                                                            Convert.ToDouble(txtBsaicPrice.Text), Convert.ToDouble(txtPackingForwarding.Text), Convert.ToDouble(txtDiscount.Text), Convert.ToDouble(txtDiscAmount.Text), Convert.ToDouble(txtaftrerdisount.Text),
                                                            Convert.ToBoolean(chkintrastate.Checked), Convert.ToDouble(txtIGSTPer.Text), Convert.ToDouble(txtIGSTAmount.Text), Convert.ToDouble(txtSgstPer.Text), Convert.ToDouble(txtSGSTAmount.Text), Convert.ToDouble(txtInsatallationCommision.Text),
                                                            Convert.ToDouble(txtServiceTaxIGSTPercent.Text), Convert.ToDouble(txtServiceTaxIGSTAmount.Text), Convert.ToDouble(txtServiceTaxSGSTPercent.Text), Convert.ToDouble(txtServiceTaxSGSTAmount.Text), cmbPaymentTerms.Text, Convert.ToDouble(txtAdvance.Text), Convert.ToDouble(txtAfterPDI.Text), Convert.ToDouble(TxtAfterInstal.Text),
                                                            Convert.ToDouble(txtadditionalWarPer.Text), Convert.ToDouble(txtAdditionalwarrantyAmount.Text), Convert.ToDouble(txtFinalNetAmount.Text), Convert.ToDouble(txtAdditionalMonths.Text), Convert.ToDouble(txtFreight.Text), Convert.ToDouble(txtInsurance.Text));


            GLobalClass.iStatus = DAL.fnAddQuoteOpportunityDetails(InsertorUpdate, sQuotationNo, RevisionNumber, cmbLabtype.Text, cmbBusinessector.Text, cmbprimaryind.Text, cmbprimarymaterial.Text, cmbprimarymtrldetail.Text, cmbApplication.Text,
                cmbTestEnvironment.Text, cmbStatus.Text, cmbStage.Text, cmbtypeofcustomer.Text, txtExpectedValueUSD.Text, dtpExpectedOrderPlacementdate.Text, cmbProbabality.Text, txtCompetation.Text, txtSpecifyOthers.Text, cmbWinLose.Text, txtWonReason.Text, txtLostReason.Text);
            //  GLobalClass.iStatus = DAL.fnUpdateCustomerMaster(Global.uUPDATE, txtCusCode.Text, cmbCustomer.Text, txtCustomertype.Text, txtAddress.Text, txtAdditionalDetails.Text, txtContactNumber1.Text, txtContactPerson1.Text, txtDepartment1.Text, txtEmailID1.Text, txtContactPerson2.Text, txtContactNumber2.Text, txtDepartment2.Text, txtEmailID2.Text);
        }

        private void chkBreakup_CheckedChanged(object sender, EventArgs e)
        {
            if (chkBreakup.CheckState == CheckState.Checked)
            {
                dgQuoteBOM.Columns[9].Visible = true;
                fnJackUpCalculation();
                // txtJackup.Text = "00";
            }
            else
            {
                dgQuoteBOM.Columns[9].Visible = false;
            }
        }

        private void txtQuoteJack_TextChanged(object sender, EventArgs e)
        {
            double dVa = Math.Round((Convert.ToDouble(txtQuoteJack.Text) - Convert.ToDouble(txtQuoteBreak.Text)));
            txtQuoteRemain.Text = dVa.ToString();
        }
        double oldvalue;
        private void dgQuoteBOM_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgQuoteBOM.CurrentCell.OwningColumn.Name == "BreakupTPrice" || dgQuoteBOM.CurrentCell.OwningColumn.Name == "Quantity")
            {
                oldvalue = Convert.ToDouble(dgQuoteBOM.CurrentCell.Value);
            }
        }

        private void dgQuoteBOM_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
            }
        }

        private void Control_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (dgQuoteBOM.CurrentCell.OwningColumn.Index == 6 || dgQuoteBOM.CurrentCell.OwningColumn.Index == 9)
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
                {
                    e.Handled = true;
                }
                // only allow one decimal point
                if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
                {
                    e.Handled = true;
                }
            }

        }

        private void Control_KeyPress1(object sender, KeyPressEventArgs e)
        {
            if (dgvOptionalItems.CurrentCell.OwningColumn.Index == 6 || dgvOptionalItems.CurrentCell.OwningColumn.Index == 9)
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
                {
                    e.Handled = true;
                }
                // only allow one decimal point
                if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
                {
                    e.Handled = true;
                }
            }

        }
        double sBrekTotalAmount = 0;
        private void dgQuoteBOM_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (dgQuoteBOM.CurrentCell.OwningColumn.Name == "BreakupTotal")
            {
                if (!string.IsNullOrEmpty(dgQuoteBOM.CurrentCell.Value.ToString()) && (dgQuoteBOM.CurrentCell.Value.ToString() != "."))// != null)
                {
                    //if (Convert.ToDouble(dgQuoteBOM.CurrentCell.Value.ToString()) != 0)
                    {
                        dgQuoteBOM.CurrentRow.Cells["TPrice"].Value = Math.Round(Convert.ToDouble(dgQuoteBOM.CurrentRow.Cells["Quantity"].Value) * Convert.ToDouble(dgQuoteBOM.CurrentRow.Cells["BreakupTotal"].Value)).ToString();
                        fnJackUpCalculation();
                        dtQuote = dgQuoteBOM.DataSource as DataTable;
                        fnTotalCalucalation();
                    }
                    //else
                    //{
                    //    dgQuoteBOM.CurrentCell.Value = oldvalue;
                    //}

                }
            }
            else if (dgQuoteBOM.CurrentCell.OwningColumn.Name == "Quantity")
            {
                if (!string.IsNullOrEmpty(dgQuoteBOM.CurrentCell.Value.ToString()) && (dgQuoteBOM.CurrentCell.Value.ToString() != "."))// != null)
                {
                    if (Convert.ToDouble(dgQuoteBOM.CurrentCell.Value.ToString()) != 0)
                    {
                        dgQuoteBOM.CurrentRow.Cells["TPrice"].Value = Math.Round(Convert.ToDouble(dgQuoteBOM.CurrentRow.Cells["Quantity"].Value) * Convert.ToDouble(dgQuoteBOM.CurrentRow.Cells["BreakupTotal"].Value)).ToString();
                        // dgQuoteBOM.CurrentRow.Cells["BreakupTotal"].Value = dgQuoteBOM.CurrentRow.Cells["TPrice"].Value.ToString();
                        sBrekTotalAmount = 0;
                        sTotalAmount = 0;

                        foreach (DataGridViewRow dgvr in dgQuoteBOM.Rows)
                        {
                            sBrekTotalAmount += Convert.ToDouble(dgvr.Cells["BreakupTotal"].Value);
                            sTotalAmount += Convert.ToDouble(dgvr.Cells["TPrice"].Value);
                        }

                        txtQuoteBreak.Text = Math.Round(sBrekTotalAmount).ToString();
                        txtTotalPrice.Text = Math.Round(sTotalAmount).ToString();

                        dtQuote = dgQuoteBOM.DataSource as DataTable;
                        fnTotalCalucalation();
                    }
                    else
                    {
                        dgQuoteBOM.CurrentCell.Value = oldvalue;
                    }
                }

            }
        }
        CultureInfo india = new CultureInfo("hi-IN");
        CultureInfo Dollar = new CultureInfo("en-US");
        private string fnCurrencyForamt(double dValue, int Index)
        {
            switch (Index)
            {
                case 0:
                    return string.Format(india, "{0:c}", (dValue));
                case 1:
                    return string.Format(Dollar, "{0:c}", (dValue));
                default:
                    return string.Format(india, "{0:c}", (dValue));
            }


        }

        double dQunaitity, dSalesBreakup, dSalesMarginCost = 0;
        private void fnJackUpCalculation()
        {
            //  dQunaitity = 0; 
            //dSalesBreakup = 0; 
            dSalesMarginCost = 0;
            sBrekTotalAmount = 0;
            sTotalAmount = 0;
            foreach (DataGridViewRow dgvr in dgQuoteBOM.Rows)
            {
                sBrekTotalAmount += (Convert.ToDouble(dgvr.Cells["BreakupTotal"].Value) * Convert.ToDouble(dgvr.Cells["Quantity"].Value));
                dSalesMarginCost += (Convert.ToDouble(dgvr.Cells["SalesCost"].Value) * Convert.ToDouble(dgvr.Cells["Quantity"].Value));
            }


           txtSystemMargin.Text = Math.Round((1 - (dSalesMarginCost / sBrekTotalAmount)) * 100).ToString() + " %";
            //adding 5+ to the output 
           // txtSystemMargin.Text = Math.Round(((1 - (dSalesMarginCost / sBrekTotalAmount)) * 100) + 5).ToString() + " %";


            if (LoginForm.GetUserDetails[2].ToLower() == "vivek g" || LoginForm.GetUserDetails[2].ToLower() == "sadat" || LoginForm.GetUserDetails[2].ToLower() == "abhilash")
            {

            }
            else
            {
                if (!string.IsNullOrEmpty(txtSystemMargin.Text))
                {
                    double kCheck = Convert.ToDouble(Math.Round((1 - (dSalesMarginCost / sBrekTotalAmount)) * 100));
                    if (kCheck > 0)
                    {
                        txtSystemMargin.Text = (Math.Round((1 - (dSalesMarginCost / sBrekTotalAmount)) * 100) - 5).ToString() + " %";
                    }
                }
            }

            txtQuoteBreak.Text = Math.Round(sBrekTotalAmount).ToString();

            double dVa = Math.Round((Convert.ToDouble(txtQuoteJack.Text) - Convert.ToDouble(txtQuoteBreak.Text)));
            txtQuoteRemain.Text = dVa.ToString();

            if (Convert.ToDouble(txtQuoteBreak.Text) <= (Convert.ToDouble(txtQuoteJack.Text)))
            {
                txtQuoteBreak.BackColor = Color.GreenYellow;
                txtQuoteRemain.BackColor = Color.White;
            }
            else
            {
                txtQuoteRemain.BackColor = Color.Red;
                txtQuoteBreak.BackColor = Color.White;
            }
        }


        private void fnJackUpCalculation_new()
        {
            dSalesMarginCost = 0;
            sBrekTotalAmount = 0;
            sTotalAmount = 0;

            foreach (DataGridViewRow dgvr in dgQuoteBOM.Rows)
            {
                // Check BreakupTotal
                if (dgvr.Cells["BreakupTotal"].Value == null || dgvr.Cells["BreakupTotal"].Value == DBNull.Value)
                {
                    Console.WriteLine($"Null detected in BreakupTotal for row {dgvr.Index}");
                    continue; // Skip this row or handle default value
                }

                // Check Quantity
                if (dgvr.Cells["Quantity"].Value == null || dgvr.Cells["Quantity"].Value == DBNull.Value)
                {
                    Console.WriteLine($"Null detected in Quantity for row {dgvr.Index}");
                    continue;
                }

                // Check SalesCost
                if (dgvr.Cells["SalesCost"].Value == null || dgvr.Cells["SalesCost"].Value == DBNull.Value)
                {
                    Console.WriteLine($"Null detected in SalesCost for row {dgvr.Index}");
                    continue;
                }

                // Safe conversion
                double breakupTotal = Convert.ToDouble(dgvr.Cells["BreakupTotal"].Value);
                double quantity = Convert.ToDouble(dgvr.Cells["Quantity"].Value);
                double salesCost = Convert.ToDouble(dgvr.Cells["SalesCost"].Value);

                sBrekTotalAmount += (breakupTotal * quantity);
                dSalesMarginCost += (salesCost * quantity);
            }

            // Margin calculation
            if (sBrekTotalAmount > 0)
            {
                txtSystemMargin.Text = Math.Round((1 - (dSalesMarginCost / sBrekTotalAmount)) * 100).ToString() + " %";
            }
            else
            {
                txtSystemMargin.Text = "0 %";
            }

            // Additional logic for user-specific margin adjustment
            if (!(LoginForm.GetUserDetails[2].ToLower() == "vivek g" ||
                  LoginForm.GetUserDetails[2].ToLower() == "sadat" ||
                  LoginForm.GetUserDetails[2].ToLower() == "abhilash"))
            {
            }
            else { 

                if (!string.IsNullOrEmpty(txtSystemMargin.Text))
                {
                    double kCheck = Convert.ToDouble(Math.Round((1 - (dSalesMarginCost / sBrekTotalAmount)) * 100));
                    if (kCheck > 0)
                    {
                        txtSystemMargin.Text = (Math.Round((1 - (dSalesMarginCost / sBrekTotalAmount)) * 100) - 5).ToString() + " %";
                    }
                }
            }

            txtQuoteBreak.Text = Math.Round(sBrekTotalAmount).ToString();

            // Safe conversion for Jack and Break
            double quoteJack = string.IsNullOrEmpty(txtQuoteJack.Text) ? 0 : Convert.ToDouble(txtQuoteJack.Text);
            double quoteBreak = string.IsNullOrEmpty(txtQuoteBreak.Text) ? 0 : Convert.ToDouble(txtQuoteBreak.Text);

            double dVa = Math.Round(quoteJack - quoteBreak);
            txtQuoteRemain.Text = dVa.ToString();

            if (quoteBreak <= quoteJack)
            {
                txtQuoteBreak.BackColor = Color.GreenYellow;
                txtQuoteRemain.BackColor = Color.White;
            }
            else
            {
                txtQuoteRemain.BackColor = Color.Red;
                txtQuoteBreak.BackColor = Color.White;
            }
        }


        private void dgWriteUP_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            //foreach (DataGridViewRow dr in dgWriteUP.Rows)
            //{
            //    GLobalClass.iStatus = DAL.fnAddQuoteBOMProduct(Global.uINSERT, sQuotationNumber, 0, dr.Cells["ProductCode"].Value.ToString()
            //         , dr.Cells["ProductName"].Value.ToString(), dr.Cells["Description"].Value.ToString(), Convert.ToDouble(dr.Cells["ProductCost"].Value), Convert.ToDouble(dr.Cells["Quantity"].Value),
            //         Convert.ToDouble(dr.Cells["UnitPrice"].Value), Convert.ToDouble(dr.Cells["TPrice"].Value), Convert.ToDouble(dr.Cells["BreakupTotal"].Value));
            //}
        }

        DataTable dtQuoteEnquiryDetails = new DataTable();
        DataTable dtAllQuotationNumbers = new DataTable();
        DataTable dtQuoteBOMItems = new DataTable();
        DataTable QuoteTaxDetails = new DataTable();
        DataTable QOpportuintyDetails = new DataTable();

        private void fnClearLoaddata()
        {
            cmbQuoteType.SelectedIndex = -1;
            txtModelNumber.ResetText();
            cmbEnquireCurrency.SelectedIndex = -1;
            cmbQuoteCompany.SelectedIndex = -1;
            cmbRegion.SelectedIndex = -1;
            cmbLeadGenarated.SelectedIndex = -1;
            cmbQuotationfor.SelectedIndex = -1;
            cmbModel.SelectedIndex = -1;
            cmbCapacity.SelectedIndex = -1;
            cmbCustomer.SelectedIndex = -1;
            txtCusCode.ResetText();
            dtpEnquireDate.ResetText();// Convert.ToDateTime(dtQuoteEnquiryDetails.Rows[0]["DateofEnquiry"].ToString());
            txtQuoteName.ResetText();
            txtTenderNo.ResetText();
            //  txtQuoteValidity.ResetText();
            //  txtQuoteWarranty.ResetText();
            // txtLeadTime.ResetText();
            cmbIncoTerms.SelectedIndex = -1;
            txtaddNote.ResetText();

            cmbLabtype.SelectedIndex = -1;
            cmbBusinessector.SelectedIndex = -1;
            cmbprimaryind.SelectedIndex = -1;
            cmbprimarymaterial.SelectedIndex = -1;
            cmbprimarymtrldetail.ResetText();
            cmbApplication.SelectedIndex = -1;
            cmbTestEnvironment.SelectedIndex = -1;
            cmbStatus.SelectedIndex = -1;
            cmbStage.SelectedIndex = -1;
            cmbtypeofcustomer.SelectedIndex = -1;
            txtExpectedValueUSD.ResetText();
            dtpExpectedOrderPlacementdate.ResetText();
            cmbProbabality.SelectedIndex = -1;
            txtCompetation.ResetText();
            txtSpecifyOthers.ResetText();
            cmbWinLose.SelectedIndex = -1;
            txtWonReason.ResetText();
            txtLostReason.ResetText();

            dgQuoteBOM.DataSource = null;
            dgWriteUP.DataSource = null;
            dgvOptionalItems.DataSource = null;
            dgOIWriteUP.DataSource = null;


            //txtTotalPrice.ResetText();
            //chkBreakup.CheckState = CheckState.Unchecked;
            //txtJackup.ResetText();
            //txtPackingForwarding.ResetText();
            //txtDiscount.ResetText();
            //chkintrastate.CheckState = CheckState.Unchecked;
            //txtInsatallationCommision.ResetText();
            //txtServiceTaxIGSTPercent.ResetText();


            //txtServiceTaxSGSTPercent.ResetText();

            //chkConcessionGst.CheckState = CheckState.Unchecked;

            // cmbPaymentTerms.SelectedIndex = -1;
            //txtAdvance.ResetText();
            //txtAfterPDI.ResetText();
            //TxtAfterInstal.ResetText();
            //txtadditionalWarPer.ResetText();
        }
        DateTime date;
        string formattedDate;
        private void cmbRevisionNumber_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (NewRevisionNumber == 0)
            {
                dtQuoteEnquiryDetails = DAL.fnQuotationNumberLoadData(1, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];

                QuoteTaxDetails = DAL.fnQuotationNumberLoadData(3, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];

                QOpportuintyDetails = DAL.fnQuotationNumberLoadData(8, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];
                if (cmbSelectQuoteType.Text != "Copy Quote")
                {
                    fnClearLoaddata();
                    dtQuote = DAL.fnQuotationNumberLoadData(2, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];
                    dtQuoteOptionalItems = DAL.fnQuotationNumberLoadData(7, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];
                }
                if (dtQuoteEnquiryDetails.Rows.Count > 0)
                {
                    if (cmbSelectQuoteType.Text != "Copy Quote")
                    {
                        txtEnquiryNumber.Text = dtQuoteEnquiryDetails.Rows[0]["EnquiryNumber"].ToString();
                        lblQuoteBy.Text = dtQuoteEnquiryDetails.Rows[0]["QuotePreparedBy"].ToString(); ;
                        cmbEnquireCurrency.SelectedItem = dtQuoteEnquiryDetails.Rows[0]["Currency"].ToString();
                        cmbQuoteCompany.SelectedItem = dtQuoteEnquiryDetails.Rows[0]["QuoteCompany"].ToString();
                        cmbQuoteType.SelectedItem = dtQuoteEnquiryDetails.Rows[0]["QuoteType"].ToString();
                        cmbRegion.SelectedItem = dtQuoteEnquiryDetails.Rows[0]["Region"].ToString();
                        cmbLeadGenarated.SelectedItem = dtQuoteEnquiryDetails.Rows[0]["Leadgenarated"].ToString();
                        cmbQuotationfor.SelectedItem = dtQuoteEnquiryDetails.Rows[0]["QuoteFor"].ToString();
                        cmbModel.SelectedItem = dtQuoteEnquiryDetails.Rows[0]["QuoteModel"].ToString();
                        cmbCapacity.SelectedItem = dtQuoteEnquiryDetails.Rows[0]["QuoteCapacity"].ToString();
                        txtModelNumber.Text = dtQuoteEnquiryDetails.Rows[0]["ModelNumber"].ToString();
                        bCustomerLoad = true;
                        cmbCustomer.SelectedItem = dtQuoteEnquiryDetails.Rows[0]["CustomerName"].ToString();
                        txtCusCode.Text = dtQuoteEnquiryDetails.Rows[0]["CustomerCode"].ToString();
                        txtCustomertype.Text = dtQuoteEnquiryDetails.Rows[0]["CustomerType"].ToString();
                        txtAddress.Text = dtQuoteEnquiryDetails.Rows[0]["Adress"].ToString();
                        txtDepartment1.Text = dtQuoteEnquiryDetails.Rows[0]["Department"].ToString();
                        txtContactPerson1.Text = dtQuoteEnquiryDetails.Rows[0]["ContactPerson"].ToString();
                        txtContactNumber1.Text = dtQuoteEnquiryDetails.Rows[0]["ContactNumber"].ToString();
                        txtEmailID1.Text = dtQuoteEnquiryDetails.Rows[0]["EmailID"].ToString();
                        bCustomerLoad = false;
                        txtQuoteName.Text = dtQuoteEnquiryDetails.Rows[0]["QuoteName"].ToString();
                        txtTenderNo.Text = dtQuoteEnquiryDetails.Rows[0]["TenderNumber"].ToString();
                        txtQuoteValidity.Text = dtQuoteEnquiryDetails.Rows[0]["QuoteValidity"].ToString();
                        txtQuoteWarranty.Text = dtQuoteEnquiryDetails.Rows[0]["QuoteWarranty"].ToString();
                        txtLeadTime.Text = dtQuoteEnquiryDetails.Rows[0]["QuoteLeadTime"].ToString();
                        cmbIncoTerms.SelectedItem = dtQuoteEnquiryDetails.Rows[0]["QuoteIncoTerm"].ToString();
                        txtaddNote.Text = dtQuoteEnquiryDetails.Rows[0]["AddNote"].ToString();
                        if (!string.IsNullOrEmpty(dtQuoteEnquiryDetails.Rows[0]["Pegrate"].ToString()))
                        {
                            dPegRate = Convert.ToDouble(dtQuoteEnquiryDetails.Rows[0]["Pegrate"].ToString());
                        }
                        cmbeightytwenty.SelectedItem = dtQuoteEnquiryDetails.Rows[0]["Project8020"].ToString();
                        cmblevelofcustomization.SelectedItem = dtQuoteEnquiryDetails.Rows[0]["LevelofCustomization"].ToString();
                        cmbBank.SelectedItem = dtQuoteEnquiryDetails.Rows[0]["Bank"].ToString();

                 
                    }
                    else
                    {
                        cmbEnquireCurrency.SelectedItem = dtQuoteEnquiryDetails.Rows[0]["Currency"].ToString();
                    }
                }

                if (QOpportuintyDetails.Rows.Count > 0)
                {
                    if (cmbSelectQuoteType.Text != "Copy Quote")
                    {
                        cmbLabtype.SelectedItem = QOpportuintyDetails.Rows[0]["LabType"].ToString();
                        cmbBusinessector.SelectedItem = QOpportuintyDetails.Rows[0]["BusinessSector"].ToString();
                        cmbprimaryind.SelectedItem = QOpportuintyDetails.Rows[0]["PrimaryInd"].ToString();
                        cmbprimarymaterial.SelectedItem = QOpportuintyDetails.Rows[0]["PrimaryMtrl"].ToString();
                        cmbprimarymtrldetail.Text = QOpportuintyDetails.Rows[0]["PrimaryMtrlDetail"].ToString();
                        cmbApplication.SelectedItem = QOpportuintyDetails.Rows[0]["Application"].ToString();
                        cmbTestEnvironment.SelectedItem = QOpportuintyDetails.Rows[0]["TestEnvironment"].ToString();
                        cmbStatus.SelectedItem = QOpportuintyDetails.Rows[0]["Status"].ToString();
                        cmbStage.SelectedItem = QOpportuintyDetails.Rows[0]["Stage"].ToString();
                        cmbtypeofcustomer.SelectedItem = QOpportuintyDetails.Rows[0]["TypeofCustomer"].ToString();
                        txtExpectedValueUSD.Text = QOpportuintyDetails.Rows[0]["ExpectedOrderValueUSD"].ToString();
                   
                        cmbProbabality.SelectedItem = QOpportuintyDetails.Rows[0]["Probability"].ToString();
                        txtCompetation.Text = QOpportuintyDetails.Rows[0]["Competition"].ToString();
                        txtSpecifyOthers.Text = QOpportuintyDetails.Rows[0]["SpecifyOthers"].ToString();
                        cmbWinLose.SelectedItem = QOpportuintyDetails.Rows[0]["WonLost"].ToString();
                        txtWonReason.Text = QOpportuintyDetails.Rows[0]["WonReason"].ToString();
                        txtLostReason.Text = QOpportuintyDetails.Rows[0]["LostReason"].ToString();

                       
                    }
                }

                if (dtQuote.Rows.Count > 0)
                {
                    LastQuoteNumber = Convert.ToInt32(dtQuote.Rows[0]["QuoteNoList"].ToString());
                    dgQuoteBOM.AutoGenerateColumns = false;
                   // MessageBox.Show("this is happing....!");
                    dgQuoteBOM.DataSource = dtQuote;
                    dgWriteUP.AutoGenerateColumns = false;
                    dgWriteUP.DataSource = dtQuote;
                    Datagridviewcolor("ProductCod", dgQuoteBOM);
                }
                if (dtQuoteOptionalItems.Rows.Count > 0)
                {
                    dgvOptionalItems.AutoGenerateColumns = false;
                    

                    //Added new code for the ADDmaterialMargin
                    
                    try
                    {
                        if (!dtQuoteOptionalItems.Columns.Contains("OImaterialMargin"))
                        {
                            dtQuoteOptionalItems.Columns.Add("OImaterialMargin", typeof(string));
                        }

                        //SalesCostTemp

                        if (!dtQuote.Columns.Contains("SalesCostTemp"))
                        {
                            dtQuote.Columns.Add("SalesCostTemp", typeof(string));
                        }



                        foreach (DataRow row in dtQuoteOptionalItems.Rows)
                        {
                           // MessageBox.Show(row["ProductCode"].ToString(), "ProductCode4");
                            SalesProductCodeDetails = DAL.fnSalesProductCodeName(row["ProductCode"].ToString()).Tables[0]; // SalesProductCodeDetails.Rows[0]["SalesCost"]
                          

                            if (SalesProductCodeDetails.Rows[0]["SalesCost"] != DBNull.Value && row["UnitPrice"] != DBNull.Value)
                            {

                                row["SalesCostTemp"] = SalesProductCodeDetails.Rows[0]["SalesCost"];
                                decimal salesCost = Convert.ToDecimal(SalesProductCodeDetails.Rows[0]["SalesCost"]);
                                decimal unitPrice = Convert.ToDecimal(row["UnitPrice"]);
                                //decimal quantity = Convert.ToDecimal(row["Quantity"]);



                                //totalCost += quantity * salesCost;

                                if (unitPrice != 0) // Avoid division by zero
                                {
                                    decimal mmValue = 1 - (salesCost / unitPrice);
                                    // MessageBox.Show(Math.Round(mmValue, 2).ToString(), "materialMargin");
                                    row["OImaterialMargin"] = Math.Round(mmValue * 100, 0) + "%";
                                }
                                else
                                {
                                    row["OImaterialMargin"] = 0; // or set to 0 or some default
                                }
                            }
                            else
                            {
                                row["OImaterialMargin"] = 0; // or set to 0 or some default
                            }
                        }
                       


                    }
                    catch (Exception error)
                    {
                        MessageBox.Show(error.Message, "OImaterialMargin Error");
                    }




                    dgvOptionalItems.DataSource = dtQuoteOptionalItems;
                    dgOIWriteUP.AutoGenerateColumns = false;
                    dgOIWriteUP.DataSource = dtQuoteOptionalItems;
                    Datagridviewcolor("OIProductCode", dgvOptionalItems);
                }

                if (QuoteTaxDetails.Rows.Count > 0)
                {
                    txtTotalPrice.Text = QuoteTaxDetails.Rows[0]["SellingPrice"].ToString();
                    chkBreakup.Checked = Convert.ToBoolean(QuoteTaxDetails.Rows[0]["BreakupPrice"].ToString());
                    txtJackup.Text = QuoteTaxDetails.Rows[0]["NegotiatryCushion"].ToString();
                    txtPackingForwarding.Text = QuoteTaxDetails.Rows[0]["PackingForwarding"].ToString();
                    txtDiscount.Text = QuoteTaxDetails.Rows[0]["DiscountPercent"].ToString();
                    chkintrastate.Checked = Convert.ToBoolean(QuoteTaxDetails.Rows[0]["IntraState"].ToString());
                    txtInsatallationCommision.Text = QuoteTaxDetails.Rows[0]["InstallationCommission"].ToString();
                    txtServiceTaxIGSTPercent.Text = QuoteTaxDetails.Rows[0]["ServiceTaxPercent"].ToString();


                    txtServiceTaxSGSTPercent.Text = QuoteTaxDetails.Rows[0]["ServiceTaxSGSTPercent"].ToString();
                    if (txtServiceTaxIGSTPercent.Text == "2.5" || txtServiceTaxSGSTPercent.Text == "2.5")
                    {
                        chkConcessionGst.CheckState = CheckState.Checked;
                    }
                    else
                    {
                        chkConcessionGst.CheckState = CheckState.Unchecked;
                    }
                    cmbPaymentTerms.SelectedItem = QuoteTaxDetails.Rows[0]["PaymentTerms"].ToString();
                    txtAdvance.Text = QuoteTaxDetails.Rows[0]["Advance"].ToString();
                    txtAfterPDI.Text = QuoteTaxDetails.Rows[0]["AfterPDI"].ToString();
                    TxtAfterInstal.Text = QuoteTaxDetails.Rows[0]["AfterInstall"].ToString();
                    if (string.IsNullOrEmpty(QuoteTaxDetails.Rows[0]["AdditionalWarrantPer"].ToString()))
                    {
                        txtadditionalWarPer.Text = "0";
                    }
                    else
                    {
                        txtadditionalWarPer.Text = QuoteTaxDetails.Rows[0]["AdditionalWarrantPer"].ToString();
                    }
                    if (string.IsNullOrEmpty(QuoteTaxDetails.Rows[0]["AdditionalMonths"].ToString()))
                    {
                        txtAdditionalMonths.Text = "0";
                    }
                    else
                    {
                        txtAdditionalMonths.Text = QuoteTaxDetails.Rows[0]["AdditionalMonths"].ToString();
                    }
                    txtFreight.Text = QuoteTaxDetails.Rows[0]["Freight"].ToString();
                    txtInsurance.Text = QuoteTaxDetails.Rows[0]["Insurance"].ToString();
                }

                btnTechQuote.Enabled = true;
                btnFinQuote.Enabled = true;

                if (dtQuoteEnquiryDetails.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtQuoteEnquiryDetails.Rows[0]["DateofEnquiry"].ToString()))
                    {
                        bool isValidFormat = DateTime.TryParseExact(dtQuoteEnquiryDetails.Rows[0]["DateofEnquiry"].ToString(), new[] { "dd-MM-yyyy", "d/M/yyyy" }, CultureInfo.InvariantCulture, DateTimeStyles.None, out date);
                        if (isValidFormat)
                        {
                            dtpEnquireDate.Value = Convert.ToDateTime(dtQuoteEnquiryDetails.Rows[0]["DateofEnquiry"].ToString());
                        }
                        else
                        {
                            date = DateTime.ParseExact(dtQuoteEnquiryDetails.Rows[0]["DateofEnquiry"].ToString(), "M/d/yyyy", CultureInfo.InvariantCulture);
                            formattedDate = date.ToString("dd-MM-yyyy");
                            dtpEnquireDate.Value = Convert.ToDateTime(formattedDate);
                        }
                    }
                }
                if (QOpportuintyDetails.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(QOpportuintyDetails.Rows[0]["ExpectedOrderPlacementDate"].ToString()))
                    {
                        bool isValidFormat = DateTime.TryParseExact(QOpportuintyDetails.Rows[0]["ExpectedOrderPlacementDate"].ToString(), new[] { "dd-MM-yyyy", "d/M/yyyy" }, CultureInfo.InvariantCulture, DateTimeStyles.None, out date);
                        if (isValidFormat)
                        {
                            dtpExpectedOrderPlacementdate.Value = Convert.ToDateTime(QOpportuintyDetails.Rows[0]["ExpectedOrderPlacementDate"].ToString());
                        }
                        else
                        {
                            date = DateTime.ParseExact(QOpportuintyDetails.Rows[0]["ExpectedOrderPlacementDate"].ToString(), "M/d/yyyy", CultureInfo.InvariantCulture);
                            formattedDate = date.ToString("dd-MM-yyyy");
                            dtpEnquireDate.Value = Convert.ToDateTime(formattedDate);
                        }
                    }
                }
            }
            else
            {

            }
        }

        private void chkUpdateQuote_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void chkNewQuote_CheckedChanged(object sender, EventArgs e)
        {

        }
        
        private void fnFileSavePath()
        {
            if (Properties.Settings.Default.FolderPath == "C:\\Users\\SOFTWARE8\\Documents\\Quotation")
            {
                DialogResult result = folderBrowserDialog1.ShowDialog();
                if (result == DialogResult.OK)
                {
                    Properties.Settings.Default.FolderPath = folderBrowserDialog1.SelectedPath;
                    Properties.Settings.Default.Save();
                                      
                }
            }
        }
        

        DataTable dtQuoteExcelExport = new DataTable();
        DataTable dtQuoteOptionalExcelExport = new DataTable();
        //  DataTable dtQuoteAdditionalExcelExport = new DataTable();
        DataTable dtQuoteProduct = new DataTable();
        DataTable dtQuoteItemDetails = new DataTable();
        DataTable dtQuoteOptionalItemDetails = new DataTable();
        bool bTecnicalQuote = false;
        private void btnTechQuote_Click(object sender, EventArgs e)
        {
            bTecnicalQuote = true;
            Cursor.Current = Cursors.WaitCursor;
            fnFileSavePath();
            if (cmbSelectQuoteType.Text == "New Quote" || cmbSelectQuoteType.Text == "Copy Quote")
            {
                dtQuoteExcelExport = DAL.fnQuotationNumberLoadData(9, sQuotationNumber, "0").Tables[0];
                dtQuoteOptionalExcelExport = DAL.fnQuotationNumberLoadData(22, sQuotationNumber, "0").Tables[0];
                dtQuoteItemDetails = DAL.fnQuotationNumberLoadData(119, sQuotationNumber, "0").Tables[0];
                dtQuoteOptionalItemDetails = DAL.fnQuotationNumberLoadData(111, sQuotationNumber, "0").Tables[0];
                dtQuoteItemsLength = DAL.fnQuotationNumberLoadData(17, sQuotationNumber, "0").Tables[0];
                dtQuoteOIItemsLength = DAL.fnQuotationNumberLoadData(18, sQuotationNumber, "0").Tables[0];
                fnTechnicalQuote(sQuotationNumber, 0);
            }
            else
            {
                dtQuoteExcelExport = DAL.fnQuotationNumberLoadData(9, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];
                dtQuoteOptionalExcelExport = DAL.fnQuotationNumberLoadData(22, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];
                dtQuoteItemDetails = DAL.fnQuotationNumberLoadData(119, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];
                dtQuoteOptionalItemDetails = DAL.fnQuotationNumberLoadData(111, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];
                dtQuoteItemsLength = DAL.fnQuotationNumberLoadData(17, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];
                dtQuoteOIItemsLength = DAL.fnQuotationNumberLoadData(18, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];
                fnTechnicalQuote(cmbQuotationNumber.Text, Convert.ToInt32(cmbRevisionNumber.Text));
            }
            bTecnicalQuote = false;
            Cursor.Current = Cursors.Default;
        }
        // static string sCompanyName = "";
        // static string[] GeneralTermsandConditions;
        //static string[] CustomerResponsibility;
        private void fnGeneralTermsandConditions(string sCompanyName)
        {


            //};

            //string[] 




        }
        string INRorUSD = "";

        static string sCompanyName;
        DataTable dtQuoteDate = new DataTable();
        #region Technical Quote
        private void fnTechnicalQuote(string sQuotationNumber, int RevisionNumber)
        {
            if (string.IsNullOrEmpty(cmbQuoteCompany.Text))
            {
                MessageBox.Show("Please select a company Name.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cmbQuoteCompany.Focus();
            }
            else
            {
            try
            {
                int iRowIndex = 1;
                //string ExcelFolderName;
                string ExcelFolderPath;
                string FileFullPath;
                string FileFul;
                string sQuoteDate = "";
                int title1, title2 = 0;
                dtQuoteDate = DAL.fnQuotationNumberLoadData(23, sQuotationNumber, RevisionNumber.ToString()).Tables[0];

                if (dtQuoteDate.Rows.Count > 0)
                {
                    //sQuoteDate = dtQuoteDate.Rows[0][0].ToString();
                    var date = DateTime.Parse(dtQuoteDate.Rows[0][0].ToString());
                    sQuoteDate = date.ToString("dd-MM-yyyy");
                }
                else
                {
                    sQuoteDate = dtpEnquireDate.Text;
                }
                EXCEL.Workbook NewWorkBook;
                EXCEL.Worksheet NewWorkSheet;
                EXCEL.Application ExcelApp;
                EXCEL.Range CELLS, cell1, cell2;
                {
                    object misValue;

                    // ExcelFolderName = "\\Quotation";
                    string sFileQuotename = "";
                    if (!bTecnicalQuote)
                    {
                        sFileQuotename = "C-" + sQuotationNumber;
                    }
                    else
                    {
                        sFileQuotename = "T-" + sQuotationNumber;
                    }

                    if (cmbQuoteCompany.SelectedIndex == 0)
                    {
                        sCompanyName = "BISS";
                    }
                    else if (cmbQuoteCompany.SelectedIndex == 1)
                    {
                        sCompanyName = cmbQuoteCompany.Text;
                    }


                    ExcelFolderPath = Properties.Settings.Default.FolderPath;   // System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + ExcelFolderName + "\\";
                    FileFullPath = ExcelFolderPath + "\\" + sFileQuotename + ".xlsx"; //"_" + DateTime.Now.ToString("d/M/yyyy HH/mm/ss") +
                    FileFul = ExcelFolderPath + "\\" + sFileQuotename + ".pdf"; //"_" + DateTime.Now.ToString("d/M/yyyy HH/mm/ss") +
                    string[] Text ={"","",
                                "ITW India Private Limited - "+sCompanyName+" Division","497E, 14 Cross, 4th Phase, Peenya Industrial Area,",
                                "Bangalore 560 058, Karnataka,  India. ", "Phone:91(080) 28360184  FAX: (080) 28360047",
                                "Web: http://www.biss.in, Email: sales@biss.in", "", "","","",cmbCustomer.Text,txtAddress.Text, "","","",
                                "Kind Attention : "+txtContactPerson1.Text +"","","Email : "+txtEmailID1.Text+"","",
                                "Contact No : "+txtContactNumber1.Text+"",
                                "","","Offer No.: "+ sQuotationNumber,
                                "Date : "+sQuoteDate+"","Rev : "+RevisionNumber+"",""};
                    string[] Textins ={"","",
                                "ITW India Private Limited - "+sCompanyName+" Division","497E, 14 Cross, 4th Phase, Peenya Industrial Area,",
                                "Bangalore 560 058, Karnataka,  India. ", "Phone:91(080) 28360184  FAX: (080) 28360047",
                                "Web: http://www.instron.com, Email: sales.india@instron.com", "", "","","",cmbCustomer.Text,txtAddress.Text, "","","",
                                "Kind Attention : "+txtContactPerson1.Text +"","","Email : "+txtEmailID1.Text+"","",
                                "Contact No : "+txtContactNumber1.Text+"",
                                "","","Offer No.: "+ sQuotationNumber,
                                "Date : "+sQuoteDate+"","Rev : "+RevisionNumber+"",""};
                    string sBankDetailBiSS = "";
                    string sBankDetailInstron = "";
                    if (cmbBank.SelectedIndex == 0)
                    {
                        sBankDetailBiSS = "4) Payment terms: \n100% LC against submission of shiping documents.\nAll payments to be made against proforma invoice; Bank details are \nAccount Name :  ITW India Pvt. Ltd., BISS Division \nBank Name: Canara Bank \nBranch Address: SME Branch, Peenya, Bangalore 560058 \nBank Account No. 2454201003508 \nRTGS Code (IFSC Code): CNRB0002454 \nSWIFT Code: CNRBINBB";
                    }
                    else if (cmbBank.SelectedIndex == 1)
                    {
                        sBankDetailBiSS = "4) Payment terms: \n100% LC against submission of shiping documents.\nAll payments to be made against proforma invoice; Bank details are \nAccount Name :  ITW India Pvt. Ltd., BISS Division \nBank Name: CITI Bank \nBranch Address: MG Road, Bangalore, 560001 \nBank Account No. 0522113018 \nRTGS Code (IFSC Code): CITI0000004 \nSWIFT Code: CITIINBXBLR";
                    }
                    else
                    {
                        sBankDetailBiSS = "4) Payment terms: \n100% LC against submission of shiping documents.\nAll payments to be made against proforma invoice; Bank details are \nAccount Name :  ITW India Pvt. Ltd., BISS Division \nBank Name: CITI Bank \nBranch Address: MG Road, Bangalore, 560001 \nBank Account No. 0522113018 \nRTGS Code (IFSC Code): CITI0000004 \nSWIFT Code: CITIINBXBLR";
                    }

                    if (cmbBank.SelectedIndex == 0)
                    {
                        sBankDetailInstron = "4) Payment terms: " + txtAdvance.Text + "% Advance with PO, " + txtAfterPDI.Text + "% plus applicable taxes against delivery to stores and balance " + TxtAfterInstal.Text + "% against installation within 15 days from the date of installation report.\nAll payments to be made through Canara Bank, SME Branch, Peenya, Bangalore 560058, against proforma invoice (ITW India Private Limited Canara bank account No.- 2454201003508).\nIn case of failure to pay the invoices despite reminders, the Company shall reserve the right to proceed legally against the client, including availing the services of third party recovery companies and the costs incurred thereon, shall exclusively be borne by the client.\nThe Company shall also reserve the right to withdraw or suspend all or any of its services to the client, till such time that the invoice/s is/are settled.\nIn the event of any cancellation of services the company shall forfeit the initial advance amount paid.\nTaxes – Will be charged as and when applicable at actuals.";
                    }
                    else if (cmbBank.SelectedIndex == 1)
                    {
                        sBankDetailInstron = "4) Payment terms: " + txtAdvance.Text + "% Advance with PO, " + txtAfterPDI.Text + "% plus applicable taxes against delivery to stores and balance " + TxtAfterInstal.Text + "% against installation within 15 days from the date of installation report.\nAll payments to be made through CITI Bank, MG Road Branch, Bangalore 560001, against proforma invoice (ITW India Private Limited CITI bank account No.- 0522113018).\nIn case of failure to pay the invoices despite reminders, the Company shall reserve the right to proceed legally against the client, including availing the services of third party recovery companies and the costs incurred thereon, shall exclusively be borne by the client.\nThe Company shall also reserve the right to withdraw or suspend all or any of its services to the client, till such time that the invoice/s is/are settled.\nIn the event of any cancellation of services the company shall forfeit the initial advance amount paid.\nTaxes – Will be charged as and when applicable at actuals.";
                    }
                    else
                    {
                        sBankDetailInstron = "4) Payment terms: " + txtAdvance.Text + "% Advance with PO, " + txtAfterPDI.Text + "% plus applicable taxes against delivery to stores and balance " + TxtAfterInstal.Text + "% against installation within 15 days from the date of installation report.\nAll payments to be made through CITI Bank, MG Road Branch, Bangalore 560001, against proforma invoice (ITW India Private Limited CITI bank account No.- 0522113018).\nIn case of failure to pay the invoices despite reminders, the Company shall reserve the right to proceed legally against the client, including availing the services of third party recovery companies and the costs incurred thereon, shall exclusively be borne by the client.\nThe Company shall also reserve the right to withdraw or suspend all or any of its services to the client, till such time that the invoice/s is/are settled.\nIn the event of any cancellation of services the company shall forfeit the initial advance amount paid.\nTaxes – Will be charged as and when applicable at actuals.";
                    }
                    string[] Text2 = { "1) Order Placement: Purchase order to be placed in the name of  “ITW India Private Limited“",
                                         "2) Pricing: "+ExFactory+". All applicable taxes and duties as on date of invoice to be paid by the customer",
                                         "3) Validity: "+txtQuoteValidity.Text+" days from the date of offer/from the date of opening of technical bid, whichever is applicable",
                                        sBankDetailInstron,
                                        "5) Warranty: "+txtQuoteWarranty.Text+" months from the date of installation of the system or 15 months from the date of dispatch from "+sCompanyName+" whichever is earlier.",
                                        "6) Duties and taxes: All applicable duties and taxes at the time of invoicing to be borne by customer.\nFor your information, the current rate of taxation IGST is 18%. SGST is 9% and CGST is 9%.\nConcessional IGST is applicable if the exemption certificate is provided by the customer.At present the concessional IGST is 5%. 18% service tax.\nDuty exemption is subject to submission required certificates.",
                                        "7) Delivery: "+txtLeadTime.Text+" weeks from the date of receipt of firm purchase order unless otherwise specified in the techno commercial offer."};
                    string[] Text21 = { "1", "2", "3", "4", "5", "6", "7" };

                    string[] Text3 = { "1) Order Placement: Purchase order to be placed  in the name of  “ITW India Private Limited“",
                                         "2) Pricing: "+ExFactory+". All applicable taxes and duties as on date of invoice to be paid by the customer",
                                         "3) Validity: "+txtQuoteValidity.Text+" days from the date of offer/from the date of opening of technical bid, whichever is applicable",
                                        sBankDetailBiSS,
                                        "5) Warranty: "+txtQuoteWarranty.Text+" months from the date of installation of the system or 15 months from the date of shipment from "+sCompanyName+" whichever is earlier.",
                                        "6) Duties and taxes: All applicable duties and taxes in the country of destination at the time of invoicing to be borne by customer.",
                                        "7) Shipment: "+txtLeadTime.Text+" weeks from the date of receipt of firm purchase order unless otherwise specified in the techno commercial offer." };

                    if (!Directory.Exists(ExcelFolderPath))
                        Directory.CreateDirectory(ExcelFolderPath);

                    ExcelApp = new EXCEL.Application();
                    misValue = System.Reflection.Missing.Value;
                    try
                    {
                        if (ExcelApp == null)
                            MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                        NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                        NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                        if (NewWorkSheet == null)
                            MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                        else
                            NewWorkSheet.Name = "Quote";
                        EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                        if (RANGE == null)
                            MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                        NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        CELLS = NewWorkSheet.Cells;
                        if (cmbQuoteCompany.Text == "INSTRON")
                        {
                            foreach (string str in Textins)
                            {
                                NewWorkSheet.Cells[iRowIndex, 1] = str;
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                iRowIndex++;
                            }
                        }
                        else if (cmbQuoteCompany.Text == "BiSS-ITW")
                        {
                            foreach (string str in Text)
                            {
                                NewWorkSheet.Cells[iRowIndex, 1] = str;
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                iRowIndex++;
                            }
                        }


                        NewWorkSheet.Cells[24, 3] = "GSTIN - 29AAACI4550Q2Z1";
                        CellMerge("Merge", NewWorkSheet, 24, 24, 3, 4);
                        NewWorkSheet.Cells[25, 3] = "HSN - 90241000";
                        CellMerge("Merge", NewWorkSheet, 25, 25, 3, 4);
                        // NewWorkSheet.Rows.AutoFit();
                        NewWorkSheet.get_Range("A2", "T10000").Cells.Font.Size = 13;
                        NewWorkSheet.Range["A3:D3"].Cells.Font.Bold = true;
                        NewWorkSheet.Range["A8:D8"].Cells.Font.Bold = true;
                        NewWorkSheet.Range["A12:D12"].Cells.Font.Bold = true;

                        NewWorkSheet.get_Range("A1", "D9999").Cells.Font.Name = "Arial";
                        NewWorkSheet.get_Range("A1", "D1").Cells.Font.Name = "Arial Black";


                        CellMerge("Merge", NewWorkSheet, 13, 16, 1, 2);
                        NewWorkSheet.Range["A13:A13"].Cells.WrapText = true;
                        //CellMerge("AlignLeft", NewWorkSheet, 9, 9, 1, 3);
                        CellMerge("AlignTop", NewWorkSheet, 13, 13, 1, 2);
                        NewWorkSheet.Range["A17:D32"].Cells.Font.Bold = true;


                        if (cmbQuotationfor.Text == "STS" || cmbQuotationfor.Text == "DTS")
                        {
                            if (File.Exists(Global.sSTSDTSCompanyLogo))
                            {
                                EXCEL.Range oRange1 = (EXCEL.Range)NewWorkSheet.Cells[28, 1];
                                Image oImage1 = Image.FromFile(Global.sSTSDTSCompanyLogo);
                                System.Windows.Forms.Clipboard.SetDataObject(oImage1, true);
                              //  NewWorkSheet.Paste(oRange1, Global.sITWLogo);

                                    System.Threading.Thread.Sleep(500);
                                    NewWorkSheet.Paste(oRange1);
                                }
                        }
                        else
                        {
                            if (cmbQuoteCompany.SelectedIndex == 0)
                            {
                                if (File.Exists(Global.sCompanyLogo))
                                {
                                    EXCEL.Range oRange1 = (EXCEL.Range)NewWorkSheet.Cells[28, 1];
                                    Image oImage1 = Image.FromFile(Global.sCompanyLogo);
                                    System.Windows.Forms.Clipboard.SetDataObject(oImage1, true);
                                   // NewWorkSheet.Paste(oRange1, Global.sITWLogo);
                                        System.Threading.Thread.Sleep(500);
                                        NewWorkSheet.Paste(oRange1);
                                    }
                            }
                            else if (cmbQuoteCompany.SelectedIndex == 1)
                            {
                                if (File.Exists(Global.sInstronCompanyLogo))
                                {
                                    EXCEL.Range oRange1 = (EXCEL.Range)NewWorkSheet.Cells[28, 1];
                                    Image oImage1 = Image.FromFile(Global.sInstronCompanyLogo);
                                    System.Windows.Forms.Clipboard.SetDataObject(oImage1, true);
                                  //  NewWorkSheet.Paste(oRange1, Global.sITWLogo);
                                        System.Threading.Thread.Sleep(500);
                                        NewWorkSheet.Paste(oRange1);
                                    }
                            }

                        }


                        NewWorkSheet.Cells[45, 1] = "Prepared : " + LoginForm.GetUserDetails[2] + "";
                        CellMerge("Merge", NewWorkSheet, 45, 45, 1, 4);
                        CellMerge("AlignLeft", NewWorkSheet, 45, 45, 1, 4);
                        NewWorkSheet.Cells[46, 1] = "Contact : " + LoginForm.GetUserDetails[50] + "  " + sEmailID + "";
                        CellMerge("Merge", NewWorkSheet, 46, 46, 1, 4);
                        CellMerge("AlignLeft", NewWorkSheet, 46, 46, 1, 4);
                        CellMerge("Bold", NewWorkSheet, 45, 46, 1, 4);

                        NewWorkSheet.Cells[47, 1] = "Model numbers of the systems are revised please visit www.biss.in for more details";
                        CellMerge("Merge", NewWorkSheet, 47, 47, 1, 4);
                        CellMerge("AlignLeft", NewWorkSheet, 47, 47, 1, 4);

                        NewWorkSheet.Cells[47, 1].Font.Color = Color.FromArgb(255, 0, 0);
                        NewWorkSheet.Cells[47, 1].Characters(54, 65).Font.Color = Color.FromArgb(0, 0, 255);
                        NewWorkSheet.Cells[47, 1].Characters(66, 100).Font.Color = Color.FromArgb(255, 0, 0);
                        iRowIndex = 48;

                        NewWorkSheet.HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);

                        NewWorkSheet.Cells[iRowIndex, 1] = (txtQuoteName.Text.Trim() + "\nModel No: " + txtModelNumber.Text.Trim()).Trim();
                        NewWorkSheet.Cells[iRowIndex, 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                        NewWorkSheet.Range["A" + iRowIndex + ":D" + iRowIndex + ""].Cells.WrapText = true;
                        NewWorkSheet.Rows[iRowIndex].RowHeight = 45;
                        NewWorkSheet.get_Range("A" + iRowIndex + "", "D" + iRowIndex + "").Cells.Font.Size = 18;
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                        CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                        CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                        NewWorkSheet.Cells[iRowIndex, 1].Font.Color = Color.FromArgb(186, 12, 47);
                        //  NewWorkSheet.Cells[(18), 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                        iRowIndex++;
                        string finalColLetter = string.Empty;
                        //iRowIndex = 32;
                        int boldiRowIndex = (iRowIndex + 1);
                        int j = iRowIndex;



                        CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                        CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                        NewWorkSheet.get_Range("A" + iRowIndex + "", "D" + iRowIndex + "").Cells.Font.Size = 15;
                        if (dtQuoteExcelExport.Rows.Count > 0)
                        {
                            NewWorkSheet.Cells[(iRowIndex), 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                            NewWorkSheet.Cells[(iRowIndex), 2].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                            NewWorkSheet.Cells[(iRowIndex), 3].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                            NewWorkSheet.Cells[(iRowIndex), 4].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                            // NewWorkSheet.Cells[(iRowIndex), 5].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                            object[,] rawData = new object[dtQuoteExcelExport.Rows.Count + 1, dtQuoteExcelExport.Columns.Count];
                            for (int col = 0; col < dtQuoteExcelExport.Columns.Count; col++)
                            {
                                rawData[0, col] = dtQuoteExcelExport.Columns[col].ColumnName;
                            }
                            for (int row = 0; row < dtQuoteExcelExport.Rows.Count; row++)
                            {
                                for (int col = 0; col < dtQuoteExcelExport.Columns.Count; col++)
                                {
                                    rawData[row + 1, col] = dtQuoteExcelExport.Rows[row].ItemArray[col];
                                }
                            }
                            string excelRange = string.Empty;
                            finalColLetter = string.Empty;
                            string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                            int colCharsetLen = colCharset.Length;

                            if (dtQuoteExcelExport.Columns.Count > colCharsetLen)
                            {
                                finalColLetter = colCharset.Substring((dtQuoteExcelExport.Columns.Count - 1) / colCharsetLen - 1, 1);
                            }
                            finalColLetter += colCharset.Substring((dtQuoteExcelExport.Columns.Count - 1) % colCharsetLen, 1);
                            excelRange = string.Format("A" + iRowIndex + ":{0}{1}", finalColLetter, (dtQuoteExcelExport.Rows.Count + iRowIndex));
                            NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;


                            if (dtQuoteItemsLength.Rows.Count > 0)
                            {
                                foreach (DataRow dr in dtQuoteItemsLength.Rows)
                                {
                                    int kLength = dr[0].ToString().Length + 2;
                                    if (kLength == 2)
                                    {
                                        NewWorkSheet.Cells[boldiRowIndex, 1].Font.Color = Color.FromArgb(186, 12, 47);
                                        NewWorkSheet.Cells[boldiRowIndex, 2].Font.Color = Color.FromArgb(186, 12, 47);
                                        NewWorkSheet.Cells[boldiRowIndex, 3].Font.Color = Color.FromArgb(186, 12, 47);
                                        NewWorkSheet.Cells[boldiRowIndex, 4].Font.Color = Color.FromArgb(186, 12, 47);
                                        NewWorkSheet.Cells[boldiRowIndex, 1].Font.FontStyle = "Bold";
                                        NewWorkSheet.get_Range("A" + boldiRowIndex + "", "A" + boldiRowIndex + "").Cells.Font.Size = 15;
                                        // NewWorkSheet.Cells[boldiRowIndex, 1].Font.Size = 13;
                                        kLength = dr[1].ToString().Length;
                                    }
                                    boldiRowIndex++;
                                }
                            }
                            CellMerge("AlignCenter", NewWorkSheet, (iRowIndex), (iRowIndex + dtQuoteExcelExport.Rows.Count), 3, 3);
                            CellMerge("AlignTop", NewWorkSheet, iRowIndex, (iRowIndex + dtQuoteExcelExport.Rows.Count), 1, 4);



                            //if (cmbEnquireCurrency.SelectedIndex == 0)
                            //{
                            Microsoft.Office.Interop.Excel.Range range31 = NewWorkSheet.get_Range("D" + iRowIndex + "", "D" + dtQuoteExcelExport.Rows.Count + iRowIndex + "");
                            //  range31.NumberFormat = "0,000";
                            range31.NumberFormat = "#,###,###";
                            //}
                            //else
                            //{
                            //    Microsoft.Office.Interop.Excel.Range range31 = NewWorkSheet.get_Range("D" + iRowIndex + "", "D" + dtQuoteExcelExport.Rows.Count + iRowIndex + "");
                            //    range31.NumberFormat = "0,000";
                            //}
                        }

                        if (cmbEnquireCurrency.SelectedIndex == 0)
                        {
                            NewWorkSheet.Cells[iRowIndex, 4] = "Price\nINR";
                        }
                        else
                        {
                            NewWorkSheet.Cells[iRowIndex, 4] = "Price\nUSD";
                        }

                        int kFirstRow = 0;
                        int kLastRow = 0;
                        CellMerge("VAlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                        CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 2, 2);
                        iRowIndex = iRowIndex + dtQuoteExcelExport.Rows.Count;
                        double dFORPrice = 0;
                        iRowIndex++;
                        if (!bTecnicalQuote)
                        {
                            if (cmbEnquireCurrency.SelectedIndex == 0)
                            {
                                NewWorkSheet.Cells[iRowIndex, 1] = "Sub Total";
                                NewWorkSheet.Cells[iRowIndex, 4] = txtBsaicPrice.Text;
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 4, 4);
                                iRowIndex++;
                                kFirstRow = iRowIndex;
                                dFORPrice = Convert.ToDouble(txtBsaicPrice.Text);
                                if (Convert.ToDouble(txtDiscount.Text) > 0)
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1] = "One Time special Discount";
                                    NewWorkSheet.Cells[iRowIndex, 3] = txtDiscount.Text + " %";
                                    NewWorkSheet.Cells[iRowIndex, 4] = txtDiscAmount.Text;
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                    iRowIndex++;
                                    NewWorkSheet.Cells[iRowIndex, 1] = "Sub Total after discount";
                                    NewWorkSheet.Cells[iRowIndex, 4] = txtaftrerdisount.Text;
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                    dFORPrice = Convert.ToDouble(txtaftrerdisount.Text);
                                    iRowIndex++;
                                }

                                if (Convert.ToDouble(txtadditionalWarPer.Text) > 0)
                                {
                                    dFORPrice += Convert.ToDouble(txtAdditionalwarrantyAmount.Text);
                                    NewWorkSheet.Cells[iRowIndex, 1] = "Additional Warranty for " + txtAdditionalMonths.Text + " Months";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                    NewWorkSheet.Cells[iRowIndex, 4] = txtAdditionalwarrantyAmount.Text;
                                    iRowIndex++;
                                }

                                //if (cmbIncoTerms.SelectedIndex == 1)
                                //{
                                if (Convert.ToDouble(txtPackingForwarding.Text) > 0)
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1] = "Packing and Forwarding";
                                    NewWorkSheet.Cells[iRowIndex, 4] = Convert.ToDouble(txtPackingForwarding.Text);
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                    iRowIndex++;
                                }
                                if (Convert.ToDouble(txtFreight.Text) > 0 || Convert.ToDouble(txtInsurance.Text) > 0)
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1] = "Freight and Insurance";
                                    NewWorkSheet.Cells[iRowIndex, 4] = Math.Round(Convert.ToDouble(txtFreight.Text) + Convert.ToDouble(txtInsurance.Text)).ToString();
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                    iRowIndex++;
                                }
                                dFORPrice += Convert.ToDouble(txtPackingForwarding.Text) + Convert.ToDouble(txtFreight.Text) + Convert.ToDouble(txtInsurance.Text);
                                //}
                                //else
                                //{
                                //    if (Convert.ToDouble(txtPackingForwarding.Text) > 0)
                                //    {
                                //        NewWorkSheet.Cells[iRowIndex, 1] = "Packing and forwarding";
                                //        NewWorkSheet.Cells[iRowIndex, 4] = txtPackingForwarding.Text;
                                //        dFORPrice += Convert.ToDouble(txtPackingForwarding.Text);
                                //        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                //        iRowIndex++;
                                //    }
                                //}

                                NewWorkSheet.Cells[iRowIndex, 1] = "Sub Total";
                                NewWorkSheet.Cells[iRowIndex, 4] = dFORPrice.ToString();
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                iRowIndex++;

                                if (chkintrastate.Checked == true)
                                {
                                    if (txtIGSTPer.Text == "18")
                                    {
                                        txtIGSTPer.Text = (Convert.ToDouble(txtIGSTPer.Text) / 2).ToString();
                                        txtIGSTAmount.Text = (Convert.ToDouble(txtIGSTAmount.Text) / 2).ToString();
                                        txtSGSTAmount.Text = txtIGSTAmount.Text;
                                    }
                                    NewWorkSheet.Cells[iRowIndex, 1] = "CGST";
                                    NewWorkSheet.Cells[iRowIndex, 3] = txtIGSTPer.Text + " %";
                                    NewWorkSheet.Cells[iRowIndex, 4] = Convert.ToDouble(txtIGSTAmount.Text); //txtIGSTAmount.Text;
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                    iRowIndex++;
                                    NewWorkSheet.Cells[iRowIndex, 1] = "SGST";
                                    NewWorkSheet.Cells[iRowIndex, 3] = txtSgstPer.Text + " %";
                                    NewWorkSheet.Cells[iRowIndex, 4] = Convert.ToDouble(txtSGSTAmount.Text);
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                    dFORPrice += Math.Round(Convert.ToDouble(txtIGSTAmount.Text) + Convert.ToDouble(txtSGSTAmount.Text));
                                    iRowIndex++;

                                    //NewWorkSheet.Cells[iRowIndex, 1] = "IGST";
                                    //NewWorkSheet.Cells[iRowIndex, 3] = txtIGSTPer.Text + " %";
                                    //NewWorkSheet.Cells[iRowIndex, 4] = Math.Round((Convert.ToDouble(txtIGSTPer.Text) * dFORPrice) / 100);
                                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                    //dFORPrice += Math.Round(Convert.ToDouble(txtIGSTAmount.Text));
                                    //iRowIndex++;
                                }
                                else
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1] = "IGST";
                                    NewWorkSheet.Cells[iRowIndex, 3] = txtIGSTPer.Text + " %";
                                    NewWorkSheet.Cells[iRowIndex, 4] = Math.Round((Convert.ToDouble(txtIGSTPer.Text) * dFORPrice) / 100);
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                    dFORPrice += Math.Round(Convert.ToDouble(txtIGSTAmount.Text));
                                    iRowIndex++;

                                }

                                NewWorkSheet.Cells[iRowIndex, 1] = "Sub Total";
                                NewWorkSheet.Cells[iRowIndex, 4] = dFORPrice.ToString();
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                iRowIndex++;

                                if (Convert.ToDouble(txtInsatallationCommision.Text) > 0)
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1] = "Installation and commissioning charges (SAC Code- 998346)";
                                    NewWorkSheet.Cells[iRowIndex, 4] = txtInsatallationCommision.Text;
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                    iRowIndex++;

                                    dFORPrice += Convert.ToDouble(txtInsatallationCommision.Text);

                                    if (chkintrastate.Checked == true)
                                    {
                                        //NewWorkSheet.Cells[iRowIndex, 1] = "CGST";
                                        //NewWorkSheet.Cells[iRowIndex, 3] = txtServiceTaxIGSTPercent.Text + " %";
                                        //NewWorkSheet.Cells[iRowIndex, 4] = txtServiceTaxIGSTAmount.Text;
                                        //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                        //iRowIndex++;
                                        //NewWorkSheet.Cells[iRowIndex, 1] = "SGST";
                                        //NewWorkSheet.Cells[iRowIndex, 3] = txtServiceTaxSGSTPercent.Text + " %";
                                        //NewWorkSheet.Cells[iRowIndex, 4] = txtServiceTaxSGSTAmount.Text;
                                        //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                        //iRowIndex++;

                                        //dFORPrice += Convert.ToDouble(txtServiceTaxIGSTAmount.Text) + Convert.ToDouble(txtServiceTaxSGSTAmount.Text);

                                        NewWorkSheet.Cells[iRowIndex, 1] = "Service Tax";
                                        NewWorkSheet.Cells[iRowIndex, 3] = txtServiceTaxIGSTPercent.Text + " %";
                                        NewWorkSheet.Cells[iRowIndex, 4] = txtServiceTaxIGSTAmount.Text;
                                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                        iRowIndex++;
                                        dFORPrice += Convert.ToDouble(txtServiceTaxIGSTAmount.Text);
                                    }
                                    else
                                    {
                                        NewWorkSheet.Cells[iRowIndex, 1] = "Service Tax";
                                        NewWorkSheet.Cells[iRowIndex, 3] = txtServiceTaxIGSTPercent.Text + " %";
                                        NewWorkSheet.Cells[iRowIndex, 4] = txtServiceTaxIGSTAmount.Text;
                                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                        iRowIndex++;
                                        dFORPrice += Convert.ToDouble(txtServiceTaxIGSTAmount.Text);
                                    }

                                }
                                else
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1] = "Installation and commissioning charges (SAC Code- 998346)";
                                    NewWorkSheet.Cells[iRowIndex, 4] = "-";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                    iRowIndex++;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "Service Tax";
                                    NewWorkSheet.Cells[iRowIndex, 3] = "-";
                                    NewWorkSheet.Cells[iRowIndex, 4] = "-";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                    iRowIndex++;
                                }

                                NewWorkSheet.Cells[iRowIndex, 1] = "Grand Total";
                                NewWorkSheet.Cells[iRowIndex, 4] = txtFinalNetAmount.Text;
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                CellMerge("Bold", NewWorkSheet, (50 + dtQuoteExcelExport.Rows.Count), iRowIndex, 1, 4);
                                CellMerge("AlignRight", NewWorkSheet, (50 + dtQuoteExcelExport.Rows.Count), iRowIndex, 1, 2);
                                kLastRow = iRowIndex;

                                //if (cmbEnquireCurrency.SelectedIndex == 0)
                                //{
                                //    Microsoft.Office.Interop.Excel.Range range3 = NewWorkSheet.get_Range("D" + kFirstRow + "", "D" + kLastRow + "");
                                //    range3.NumberFormat = "#,##";
                                //}
                                //else
                                //{
                                Microsoft.Office.Interop.Excel.Range range3 = NewWorkSheet.get_Range("D" + kFirstRow + "", "D" + kLastRow + "");
                                range3.NumberFormat = "#,###,###";
                                //}

                                Microsoft.Office.Interop.Excel.Range range7 = NewWorkSheet.get_Range("C" + kFirstRow + "", "C" + kLastRow + "");
                                range7.NumberFormat = "0%";
                                iRowIndex++;

                                NewWorkSheet.Cells[iRowIndex, 1] = "Note*: Old model number " + txtOldModelNumber.Text + " ";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                                CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                                NewWorkSheet.Cells[iRowIndex, 1].Font.Color = Color.FromArgb(255, 0, 0);
                                iRowIndex++;
                            }
                            else
                            {
                                NewWorkSheet.Cells[iRowIndex, 1] = "Sub Total";
                                NewWorkSheet.Cells[iRowIndex, 4] = txtBsaicPrice.Text;
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 4, 4);
                                iRowIndex++;
                                kFirstRow = iRowIndex;
                                dFORPrice = Convert.ToDouble(txtBsaicPrice.Text);

                                NewWorkSheet.Cells[iRowIndex, 1] = "Packing and Forwarding";
                                NewWorkSheet.Cells[iRowIndex, 4] = Math.Round(Convert.ToDouble(txtPackingForwarding.Text)).ToString();
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                iRowIndex++;

                                NewWorkSheet.Cells[iRowIndex, 1] = "Freight and Insurance";
                                NewWorkSheet.Cells[iRowIndex, 4] = Math.Round(Convert.ToDouble(txtFreight.Text) + Convert.ToDouble(txtInsurance.Text)).ToString();
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                iRowIndex++;

                                dFORPrice += Convert.ToDouble(txtPackingForwarding.Text) + Convert.ToDouble(txtFreight.Text) + Convert.ToDouble(txtInsurance.Text);

                                NewWorkSheet.Cells[iRowIndex, 1] = "Total Price";
                                NewWorkSheet.Cells[iRowIndex, 4] = Math.Round(dFORPrice).ToString();
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                iRowIndex++;

                                NewWorkSheet.Cells[iRowIndex, 1] = "Installation and commissioning charges";
                                NewWorkSheet.Cells[iRowIndex, 4] = txtInsatallationCommision.Text;
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                iRowIndex++;

                                dFORPrice += Convert.ToDouble(txtInsatallationCommision.Text);

                                NewWorkSheet.Cells[iRowIndex, 1] = "Grand Total";
                                NewWorkSheet.Cells[iRowIndex, 4] = Math.Round(dFORPrice).ToString();
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                CellMerge("Bold", NewWorkSheet, (50 + dtQuoteExcelExport.Rows.Count), iRowIndex, 1, 4);
                                CellMerge("AlignRight", NewWorkSheet, (50 + dtQuoteExcelExport.Rows.Count), iRowIndex, 1, 2);
                                kLastRow = iRowIndex;

                                Microsoft.Office.Interop.Excel.Range range3 = NewWorkSheet.get_Range("D" + kFirstRow + "", "D" + kLastRow + "");
                                range3.NumberFormat = "#,###,###";
                                iRowIndex++;

                                NewWorkSheet.Cells[iRowIndex, 1] = "Note*: Old model number " + txtOldModelNumber.Text + " ";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                                CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                                NewWorkSheet.Cells[iRowIndex, 1].Font.Color = Color.FromArgb(255, 0, 0);
                                iRowIndex++;
                            }
                        }

                        if (dtQuoteOptionalItemDetails.Rows.Count > 0)
                        {
                            NewWorkSheet.HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);
                            NewWorkSheet.Cells[iRowIndex, 1] = "Optional Items";
                            NewWorkSheet.get_Range("A" + iRowIndex + "", "D" + iRowIndex + "").Cells.Font.Size = 18;
                            iRowIndex++;
                            CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                            NewWorkSheet.get_Range("A" + iRowIndex + "", "D" + iRowIndex + "").Cells.Font.Size = 15;
                            boldiRowIndex = iRowIndex;
                            boldiRowIndex++;
                            NewWorkSheet.Cells[(iRowIndex), 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                            NewWorkSheet.Cells[(iRowIndex), 2].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                            NewWorkSheet.Cells[(iRowIndex), 3].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                            NewWorkSheet.Cells[(iRowIndex), 4].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                            object[,] rawData = new object[dtQuoteOptionalItemDetails.Rows.Count + 1, dtQuoteOptionalItemDetails.Columns.Count];
                            for (int col = 0; col < dtQuoteOptionalItemDetails.Columns.Count; col++)
                            {
                                rawData[0, col] = dtQuoteOptionalItemDetails.Columns[col].ColumnName;
                            }
                            for (int row = 0; row < dtQuoteOptionalItemDetails.Rows.Count; row++)
                            {
                                for (int col = 0; col < dtQuoteOptionalItemDetails.Columns.Count; col++)
                                {
                                    rawData[row + 1, col] = dtQuoteOptionalItemDetails.Rows[row].ItemArray[col];
                                }
                            }
                            string excelRange = string.Empty;
                            finalColLetter = string.Empty;
                            string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                            int colCharsetLen = colCharset.Length;

                            if (dtQuoteOptionalItemDetails.Columns.Count > colCharsetLen)
                            {
                                finalColLetter = colCharset.Substring(
                                    (dtQuoteOptionalItemDetails.Columns.Count - 1) / colCharsetLen - 1, 1);
                            }
                            finalColLetter += colCharset.Substring(
                                    (dtQuoteOptionalItemDetails.Columns.Count - 1) % colCharsetLen, 1);
                            excelRange = string.Format("A" + iRowIndex + ":{0}{1}", finalColLetter, (dtQuoteOptionalItemDetails.Rows.Count + iRowIndex));
                            NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;

                            if (dtQuoteOIItemsLength.Rows.Count > 0)
                            {
                                foreach (DataRow dr in dtQuoteOIItemsLength.Rows)
                                {
                                    int kLength = dr[0].ToString().Length + 2;
                                    if (kLength == 2)
                                    {
                                        NewWorkSheet.Cells[boldiRowIndex, 1].Font.Color = Color.FromArgb(186, 12, 47);
                                        NewWorkSheet.Cells[boldiRowIndex, 2].Font.Color = Color.FromArgb(186, 12, 47);
                                        NewWorkSheet.Cells[boldiRowIndex, 3].Font.Color = Color.FromArgb(186, 12, 47);
                                        NewWorkSheet.Cells[boldiRowIndex, 4].Font.Color = Color.FromArgb(186, 12, 47);
                                        NewWorkSheet.Cells[boldiRowIndex, 1].Font.FontStyle = "Bold";
                                        NewWorkSheet.get_Range("A" + boldiRowIndex + "", "A" + boldiRowIndex + "").Cells.Font.Size = 15;
                                        kLength = dr[1].ToString().Length;
                                    }
                                    boldiRowIndex++;
                                }
                            }

                            //if (cmbEnquireCurrency.SelectedIndex == 0)
                            //{
                            Microsoft.Office.Interop.Excel.Range range32 = NewWorkSheet.get_Range("D" + (iRowIndex + 1) + "", "D" + (dtQuoteOptionalExcelExport.Rows.Count + iRowIndex) + "");
                            range32.NumberFormat = "#,###,###";
                            //}
                            //else
                            //{
                            //    Microsoft.Office.Interop.Excel.Range range32 = NewWorkSheet.get_Range("D" + (iRowIndex + 1) + "", "D" + (dtQuoteOptionalExcelExport.Rows.Count + iRowIndex) + "");
                            //    range32.NumberFormat = "0,00";
                            //}

                            if (cmbEnquireCurrency.SelectedIndex == 0)
                            {
                                NewWorkSheet.Cells[iRowIndex, 4] = "Price\nINR";
                            }
                            else
                            {
                                NewWorkSheet.Cells[iRowIndex, 4] = "Price\nUSD";
                            }
                            CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 4, 4);
                            CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex + dtQuoteOptionalExcelExport.Rows.Count, 3, 3);

                            CellMerge("AlignTop", NewWorkSheet, (iRowIndex + 1), (iRowIndex + dtQuoteOptionalItemDetails.Rows.Count), 1, 4);
                            iRowIndex++;
                            iRowIndex += dtQuoteOptionalItemDetails.Rows.Count;
                        }

                        NewWorkSheet.HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);
                        NewWorkSheet.Cells[iRowIndex, 1] = "Item Details";
                        NewWorkSheet.get_Range("A" + iRowIndex + "", "D" + iRowIndex + "").Cells.Font.Size = 18;
                        iRowIndex++;

                        int iTitleRows = iRowIndex;
                        int iStartFormting = iRowIndex;
                        if (dtQuoteItemDetails.Rows.Count > 0)
                        {
                            boldiRowIndex = iRowIndex;
                            boldiRowIndex++;
                            CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                            NewWorkSheet.get_Range("A" + iRowIndex + "", "D" + iRowIndex + "").Cells.Font.Size = 15;
                            NewWorkSheet.Cells[(iRowIndex), 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                            NewWorkSheet.Cells[(iRowIndex), 2].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                            NewWorkSheet.Cells[(iRowIndex), 3].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                            NewWorkSheet.Cells[(iRowIndex), 4].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                            object[,] rawData = new object[dtQuoteItemDetails.Rows.Count + 1, dtQuoteItemDetails.Columns.Count];
                            for (int col = 0; col < dtQuoteItemDetails.Columns.Count; col++)
                            {
                                rawData[0, col] = dtQuoteItemDetails.Columns[col].ColumnName;
                            }
                            for (int row = 0; row < dtQuoteItemDetails.Rows.Count; row++)
                            {
                                for (int col = 0; col < dtQuoteItemDetails.Columns.Count; col++)
                                {
                                    rawData[row + 1, col] = dtQuoteItemDetails.Rows[row].ItemArray[col];
                                }
                            }
                            string excelRange = string.Empty;
                            finalColLetter = string.Empty;
                            string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                            int colCharsetLen = colCharset.Length;

                            if (dtQuoteItemDetails.Columns.Count > colCharsetLen)
                            {
                                finalColLetter = colCharset.Substring((dtQuoteItemDetails.Columns.Count - 1) / colCharsetLen - 1, 1);
                            }
                            finalColLetter += colCharset.Substring((dtQuoteItemDetails.Columns.Count - 1) % colCharsetLen, 1);
                            //excelRange = string.Format("S" + iRowIndex + ":T{0}", (dtQuoteItemDetails.Rows.Count + iRowIndex));
                            //NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;

                            excelRange = string.Format("A" + iRowIndex + ":{0}{1}", finalColLetter, (dtQuoteItemDetails.Rows.Count + iRowIndex));
                            NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;

                            if (dtQuoteItemsLength.Rows.Count > 0)
                            {
                                foreach (DataRow dr in dtQuoteItemsLength.Rows)
                                {
                                    int kLength = dr[0].ToString().Length + 2;
                                    if (kLength == 2)
                                    {
                                        NewWorkSheet.Cells[boldiRowIndex, 1].Font.Color = Color.FromArgb(186, 12, 47);
                                        NewWorkSheet.Cells[boldiRowIndex, 2].Font.Color = Color.FromArgb(186, 12, 47);
                                        NewWorkSheet.Cells[boldiRowIndex, 3].Font.Color = Color.FromArgb(186, 12, 47);
                                        NewWorkSheet.Cells[boldiRowIndex, 4].Font.Color = Color.FromArgb(186, 12, 47);
                                        NewWorkSheet.get_Range("A" + boldiRowIndex + "", "D" + boldiRowIndex + "").Cells.Font.Size = 16;
                                        NewWorkSheet.Cells[boldiRowIndex, 1].Font.FontStyle = "Bold";
                                        //kLength = dr[1].ToString().Length;
                                    }
                                    else
                                    {
                                        //  CellMerge("Merge", NewWorkSheet, boldiRowIndex, boldiRowIndex, 2, 4);
                                        // NewWorkSheet.Cells[iRowIndex, 2] = "=T" + iRowIndex + "";
                                    }
                                    boldiRowIndex++;
                                }
                            }
                            CellMerge("AlignTop", NewWorkSheet, (iRowIndex + 1), (iRowIndex + dtQuoteItemDetails.Rows.Count), 1, 2);

                            CellMerge("AlignTop", NewWorkSheet, (iRowIndex + 1), (iRowIndex + dtQuoteItemDetails.Rows.Count), 20, 20);

                            CellMerge(sTextAlign, NewWorkSheet, iRowIndex, (iRowIndex + dtQuoteItemDetails.Rows.Count), 2, 2);
                            // string sd="D"+iRowIndex;

                            iRowIndex++;
                            iRowIndex += dtQuoteItemDetails.Rows.Count;
                        }

                        //NewWorkSheet.PageSetup.PrintTitleColumns = "$A$" + iTitleRows + ":$A$" + iRowIndex + "";

                        title1 = iRowIndex;
                        if (dtQuoteOptionalExcelExport.Rows.Count > 0)
                        {
                            NewWorkSheet.HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);
                            NewWorkSheet.Cells[iRowIndex, 1] = "Optional Item Details";
                            NewWorkSheet.get_Range("A" + iRowIndex + "", "D" + iRowIndex + "").Cells.Font.Size = 18;
                            NewWorkSheet.Rows[iRowIndex].RowHeight = 26;
                            iRowIndex++;
                            CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                            CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                            CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 2, 2);
                            NewWorkSheet.get_Range("A" + iRowIndex + "", "D" + iRowIndex + "").Cells.Font.Size = 15;
                            NewWorkSheet.Cells[(iRowIndex), 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                            NewWorkSheet.Cells[(iRowIndex), 2].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                            NewWorkSheet.Cells[(iRowIndex), 3].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                            NewWorkSheet.Cells[(iRowIndex), 4].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                            CellMerge("VAlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                            NewWorkSheet.Rows[iRowIndex].RowHeight = 35;
                            boldiRowIndex = (iRowIndex + 1);
                            object[,] rawData = new object[dtQuoteOptionalExcelExport.Rows.Count + 1, dtQuoteOptionalExcelExport.Columns.Count];
                            for (int col = 0; col < dtQuoteOptionalExcelExport.Columns.Count; col++)
                            {
                                rawData[0, col] = dtQuoteOptionalExcelExport.Columns[col].ColumnName;
                            }
                            for (int row = 0; row < dtQuoteOptionalExcelExport.Rows.Count; row++)
                            {
                                for (int col = 0; col < dtQuoteOptionalExcelExport.Columns.Count; col++)
                                {
                                    rawData[row + 1, col] = dtQuoteOptionalExcelExport.Rows[row].ItemArray[col];
                                }
                            }
                            string excelRange = string.Empty;
                            finalColLetter = string.Empty;
                            string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                            int colCharsetLen = colCharset.Length;

                            if (dtQuoteOptionalExcelExport.Columns.Count > colCharsetLen)
                            {
                                finalColLetter = colCharset.Substring(
                                    (dtQuoteOptionalExcelExport.Columns.Count - 1) / colCharsetLen - 1, 1);
                            }
                            finalColLetter += colCharset.Substring(
                                    (dtQuoteOptionalExcelExport.Columns.Count - 1) % colCharsetLen, 1);

                            //excelRange = string.Format("S" + iRowIndex + ":T{0}", (dtQuoteOptionalExcelExport.Rows.Count + iRowIndex));
                            //NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;

                            excelRange = string.Format("A" + iRowIndex + ":{0}{1}", finalColLetter, (dtQuoteOptionalExcelExport.Rows.Count + iRowIndex));
                            NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;

                            if (dtQuoteOIItemsLength.Rows.Count > 0)
                            {
                                foreach (DataRow dr in dtQuoteOIItemsLength.Rows)
                                {
                                    int kLength = dr[0].ToString().Length + 2;
                                    if (kLength == 2)
                                    {
                                        NewWorkSheet.Cells[boldiRowIndex, 1].Font.Color = Color.FromArgb(186, 12, 47);
                                        NewWorkSheet.Cells[boldiRowIndex, 2].Font.Color = Color.FromArgb(186, 12, 47);
                                        NewWorkSheet.Cells[boldiRowIndex, 3].Font.Color = Color.FromArgb(186, 12, 47);
                                        NewWorkSheet.Cells[boldiRowIndex, 4].Font.Color = Color.FromArgb(186, 12, 47);
                                        //NewWorkSheet.Cells[boldiRowIndex, 1].Font.FontStyle = "Bold";
                                        NewWorkSheet.get_Range("A" + boldiRowIndex + "", "B" + boldiRowIndex + "").Cells.Font.Size = 15;

                                        //  kLength = dr[1].ToString().Length;
                                    }
                                    else
                                    {
                                        // CellMerge("Merge", NewWorkSheet, boldiRowIndex, boldiRowIndex, 2, 4);
                                        // NewWorkSheet.Cells[iRowIndex, 2] = "=T" + iRowIndex + "";
                                    }

                                    boldiRowIndex++;
                                }
                            }
                            CellMerge("AlignTop", NewWorkSheet, (iRowIndex + 1), (iRowIndex + dtQuoteOptionalExcelExport.Rows.Count), 1, 2);
                            CellMerge("AlignTop", NewWorkSheet, (iRowIndex + 1), (iRowIndex + dtQuoteItemDetails.Rows.Count), 20, 20);
                            CellMerge(sTextAlign, NewWorkSheet, iRowIndex, (iRowIndex + dtQuoteOptionalExcelExport.Rows.Count), 2, 2);
                            iRowIndex++;
                            iRowIndex += dtQuoteOptionalExcelExport.Rows.Count;
                        }

                        for (int i = iStartFormting; i < iRowIndex; i++)
                        {
                            NewWorkSheet.Rows[i].AutoFit();
                        }

                        iRowIndex++;
                        title2 = iRowIndex;
                        // NewWorkBook.Worksheets[0].HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);
                        NewWorkSheet.HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);
                        NewWorkSheet.Cells[iRowIndex, 1] = "Terms and Conditions";
                        NewWorkSheet.get_Range("A" + iRowIndex + "", "D" + iRowIndex + "").Cells.Font.Size = 18;
                        // CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                        NewWorkSheet.Rows[iRowIndex].RowHeight = 26;
                        NewWorkSheet.Cells[(iRowIndex), 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                        CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex + 1, 1, 4);
                        CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                        iRowIndex++;
                        j = iRowIndex;

                        foreach (string str in Text21)
                        {
                            NewWorkSheet.Cells[j, 1] = str;
                            CellMerge("AlignTop", NewWorkSheet, j, j, 1, 1);
                            CellMerge("AlignCenter", NewWorkSheet, j, j, 1, 1);
                            //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 2, 5);
                            j++;
                        }
                        int kRowHeight = 0;
                        j = iRowIndex;
                        if (cmbEnquireCurrency.SelectedIndex == 0)
                        {
                            foreach (string str in Text2)
                            {
                                kRowHeight++;
                                NewWorkSheet.Cells[iRowIndex, 1] = str;
                                if (kRowHeight < 4)
                                {
                                    if (kRowHeight == 1)
                                    {
                                        NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 19).Font.FontStyle = "Bold";
                                        NewWorkSheet.Cells[iRowIndex, 1].Characters(64, 36).Font.FontStyle = "Bold";
                                    }
                                    if (kRowHeight == 2)
                                    {
                                        NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 11).Font.FontStyle = "Bold";
                                    }
                                    if (kRowHeight == 3)
                                    {
                                        NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 12).Font.FontStyle = "Bold";
                                    }
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 20;
                                }
                                else if (kRowHeight == 4)
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 17).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 165;
                                }
                                else if (kRowHeight == 5)
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 12).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 36;
                                }
                                else if (kRowHeight == 6)
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 20).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 82;
                                }
                                else if (kRowHeight == 7)
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 12).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 36;
                                }
                                NewWorkSheet.Range["A" + iRowIndex + ":A" + iRowIndex + ""].Cells.WrapText = true;
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                                CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                                CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                                iRowIndex++;
                            }
                            // CellMerge("GridLines", NewWorkSheet, (j - 6), iRowIndex, 1, 5);
                            ////  CellMerge("GridLines", NewWorkSheet, (j), iRowIndex, 1, 5);
                        }
                        else
                        {
                            foreach (string str in Text3)
                            {
                                kRowHeight++;
                                NewWorkSheet.Cells[iRowIndex, 1] = str;
                                if (kRowHeight < 4)
                                {
                                    if (kRowHeight == 1)
                                    {
                                        NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 19).Font.FontStyle = "Bold";
                                    }
                                    if (kRowHeight == 2)
                                    {
                                        NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 11).Font.FontStyle = "Bold";
                                    }
                                    if (kRowHeight == 3)
                                    {
                                        NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 12).Font.FontStyle = "Bold";
                                    }
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 20;
                                }
                                else if (kRowHeight == 4)
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 17).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 150;
                                }
                                else if (kRowHeight == 5)
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 12).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 36;
                                }
                                else if (kRowHeight == 6)
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 20).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 36;
                                }
                                else if (kRowHeight == 7)
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 12).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 36;
                                }
                                NewWorkSheet.Range["A" + iRowIndex + ":A" + iRowIndex + ""].Cells.WrapText = true;
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                                CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                                CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                                iRowIndex++;
                            }
                            //  CellMerge("GridLines", NewWorkSheet, (j - 6), iRowIndex, 1, 5);
                            // CellMerge("GridLines", NewWorkSheet, (j), iRowIndex, 1, 5);
                        }

                        //  
                        NewWorkSheet.Cells[iRowIndex, 1] = "* Please refer to ITW India (P) Ltd., - " + sCompanyName + " Division General terms and conditions.";

                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                        CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                        NewWorkSheet.Rows[iRowIndex].RowHeight = 20;
                        iRowIndex++;

                        NewWorkSheet.HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);
                        NewWorkSheet.Cells[iRowIndex, 1] = "General Terms and Conditions";
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                        CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                        NewWorkSheet.get_Range("A" + iRowIndex + "", "D" + iRowIndex + "").Cells.Font.Size = 18;
                        CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                        NewWorkSheet.Rows[iRowIndex].RowHeight = 26;
                        NewWorkSheet.Cells[(iRowIndex), 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                        NewWorkSheet.Cells[(iRowIndex), 2].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                        NewWorkSheet.Cells[(iRowIndex), 3].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                        NewWorkSheet.Cells[(iRowIndex), 4].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                        iRowIndex++;
                        kRowHeight = 0;

                        string[] GeneralTermsandConditions = { "1. Acceptance: The terms and conditions (‘Terms and Conditions’) contained herein are applicable to all sales of ‘Products’ and/or ‘Services’, and all quotations, order acknowledgements, and invoices from ITW India Private Limited – "+sCompanyName+" Division, hereafter referred to as "+sCompanyName+" and to all Purchase Orders (PO) from "+sCompanyName+"’s Buyers (‘Buyers’) and are the only terms and conditions applicable to the sale of "+sCompanyName+"’s Products and/or Services. Buyer’s Purchase Order (PO), if accepted by "+sCompanyName+", is subject to the terms and conditions set forth herein or as negotiated and agreed to in writing between the Parties, subject to Buyer’s credit approval by "+sCompanyName+". "+sCompanyName+" HEREBY REJECTS ANY ADDITIONAL OR DIFFERENT TERMS OR CONDITIONS PROPOSED BY BUYER, WHETHER OR NOT CONTAINED IN ANY OF BUYER’S BUSINESS FORMS OR IN BUYER’S WEBSITE, AND SUCH ADDITIONAL OR DIFFERENT TERMS AND CONDITIONS SHALL BE VOID AND SHALL HAVE NO EFFECT UNLESS SPECIFICALLY AGREED TO IN WRITING BY "+sCompanyName+". Buyer’s acceptance of Products and/or Services called for in PO shall constitute its acceptance of the terms and conditions contained herein. Any changes to these Terms and Conditions must be in writing clearly identifying the change and signed by both Parties.",
                                                "2. Prices: All prices on the order are exclusive of applicable sales, excise, or similar taxes of federal, state, city, or local governments. All such applicable taxes shall be added to the invoice and paid by the Buyer, unless the Buyer presents a tax-exempt certificate. Prices, with applicable taxes, shown on the Acknowledgement are "+sCompanyName+"'s effective prices at the time the Order was accepted.",
                                             "3. Custom Items: Custom items or products shall be defined as non-standard Product sold to Buyers that are typically identified having an item number starting with ‘CP’ or ‘SP’.",
                                             "4. Cancellations: Orders may not be cancelled without "+sCompanyName+"’s consent. For standard product orders, a cancellation fee equal to 10% of the order value will be applied if the order is cancelled prior to the final thirty (30) days of the promised ship date and a 20% charge if cancelled within the final thirty (30) days of the promised ship date. For custom products (including custom items purchased with standard testing system orders), the cancellation fee shall be fifty percent (50%) of the custom product or order value if cancelled prior to thirty (30) days of the promised ship \ndate. If a custom product order is cancelled within the final thirty (30) days of the promised ship date, the cancellation fee shall be the full order value (100%) of the custom product order.",
                                            "5. Product Returns: All returns are subject to the terms and conditions of the original sale. Custom items are not eligible for return, unless factory authorization is obtained. Items being returned require a Return Material Authorization (RMA) Number prior to the return. To obtain the RMA Number, please contact the local "+sCompanyName+" office.The RMA Number must appear on the outside of the package and all pertinent paperwork must be enclosed; otherwise, "+sCompanyName+" will not accept the package and it will be returned at Buyer’s expense. If an order is shipped in error by "+sCompanyName+" or by its supplier, the item must be returned in new and unused condition in the original packaging. Standard items may be returned within 45 days of receipt. If, after inspection, "+sCompanyName+" determines that the items are saleable as new and unused products, then full credit will be issued. Otherwise, "+sCompanyName+" reserves the right to charge a minimum of 20% of the items’ original order value in refurbishment and re-stocking charges and to limit the credit for the return to the fair value of the items being returned. Original Equipment Manufacturer (OEM) computers and printers purchased from "+sCompanyName+" are not eligible for return."
                                                ,"6. Order acceptance: Order exceution is subject mutual acceptance of terms of suuply as concluded in order acknowledgement, Order acceptance is subject to finalisation of predespatch inspection plan and acceptance schedule at site.",
                                             "7. Pre-design review: Pre-design documents (where ever applicable such as non-standard customised designs), nwhen submitted for review are assumed to be accepted by customer if we fail to get a response within seven days.",
                                             "8. Pre-dispatch inspection: Pre-despatch inspection subject to mutual agreement between "+sCompanyName+" and customer during order acceptance.",
                                             "9. Acceptance tests at site: Acceptance of the system/product at site subject to mutual agreement between "+sCompanyName+" and customer during order acceptance.",
                                             "10. Bank guarantee: Submission of bank guarantee will be subject to 3% increase on the basic pricing of the techno-commercial offer submitted",
                                             "11. Shipments: All shipments are made Ex-Works (EXW) in accordance with the definitions established by the International Chamber of Commerce (INCOTERMS), unless mutually agreed to otherwise in writing, and shall be made in the best and the most cost-effective way. ANY CLAIM MADE AGAINST "+sCompanyName+" FOR THE PAYMENT OF LIQUIDATED DAMAGES FOR LATE DELIVERY SHALL IN NO CASE BECOME DUE BEFORE DELIVERY HAS BEEN COMPLETED.",
                                             "12. Terms of Payment: All payments shall be as stated in the quotation, subject to credit approval, unless mutually agreed to otherwise; no discount shall be allowed upon receipt of invoice. Payments on purchases which include the requirements of a Letter of Credit (LC) shall be governed by those purchase contracts’ terms and conditions. Installation delays incurred as a result of the Buyer’s failure to adequately prepare Buyer’s facility does not warrant a delay in payment for the product purchased.",
                                                "13. Late Payment Penalty: The outstanding amount which is over due for more than 30days after the due day will attract an interest of 15% pa.",
                                             "14. Buyer Responsibilities: The Buyer is liable and responsible for certain actions and responsibilities in preparing the facility, laboratory, or room to accept the equipment purchased and to be installed by "+sCompanyName+". These actions and responsibilities include, but are not limited to, air supply, electrical supply and regulation, cooling water, safe handling and moving equipment, structural integrity of building and floor where testing system shall be located, etc. Please refer to "+sCompanyName+"’s Customer Responsibilities document, which shall be considered part of these Terms and Conditions for the Buyer’s purchase herein or as modified, and/or the Pre-Installation Manual for the Equipment for more specific information for all new testing system purchases. "+sCompanyName+" Customer Service may also be contacted at +91 80 28360184 for assistance. For outside the India, please contact the local "+sCompanyName+" office or its local representative; details of such contact can be found on "+sCompanyName+"’s website (www.biss.in). Buyers purchasing retrofits are responsible for their existing testing instruments. In order for a retrofit to be successful, the existing testing instrument must be in full and good operating condition. All safety features on the existing instrument must function correctly and within the manufacturer’s specifications. Should any portion of the Buyer’s existing frame not function properly, safely and/or within the original manufacturer’s specifications, it is the Buyer’s responsibility to correct any and all of these deficiencies to return the existing frame to safe and correct working order before the retrofit installation can proceed."
                                             ,"15. Warranty: "+sCompanyName+" warrants that all new products manufactured and services supplied under this Order shall conform to the specifications, drawings, samples or other descriptions of the product and services being purchased.\n    i. All testing equipment and systems manufactured by "+sCompanyName+" and installed by "+sCompanyName+" Service Personnel or its authorized local representative shall be warranted against defects in material and workmanship for a period of one (1) year from the date of delivery, unless mutually agreed to otherwise in the purchase documents. Physical damages to electrical and electronic components due to faulty ground and over/under voltage. Consumables including ceramic rods, heating elements, high temperature grease, hydraulic oil, filter, seals, coolant, computer media, printer cartridges etc., Physical damage to mechanical components & connectors due to negligent handling or improper machine operation.\n    ii. For retrofit purchases, this warranty is limited to only those components that are installed as part of the retrofit by "+sCompanyName+" Service Personnel or its authorized local representative. No warranty is implied or expressly given for the Buyer’s existing testing instrument upon which the retrofit shall be installed. The performance and accuracy of a retrofitted or upgraded system is dependent upon the condition of the system prior to retrofit or upgrade. There shall be no implied or expressed guarantee or warranty on the performance or accuracy of the combination of new and existing system components. Retrofit or upgrade specifications stated convey only achievable results for existing systems that are in good working condition prior to the retrofit or upgrade. Prices do not include modifications or repairs to system components that may be possible or necessary to improve performance or accuracy. The operation, use, calibration, maintenance, and repairs associated with the Buyer’s existing testing instrument and any existing testing accessories shall remain the responsibility of the Buyer. The Buyer shall be solely responsible for ensuring the existing testing instrument upon which the retrofit is to be installed is in proper and safe working condition and fully operational prior to the retrofit installation visit by "+sCompanyName+" Service Personnel or "+sCompanyName+" authorized representative. Unless otherwise provided herein or in the Buyer’s purchase and order, any repairs to the Buyer’s existing testing instrument shall be the subject of a separate quote, purchase, and/or order. ",
                                             "   iii. All equipment purchased from "+sCompanyName+" but not installed by "+sCompanyName+" Service Personnel or "+sCompanyName+" authorized representative shall be warranted against defects in material and workmanship for a period of one (1) year from the date of delivery.\n   iv. New equipment warranties are NOT transferable, unless approved by "+sCompanyName+". After transfer of title, "+sCompanyName+" shall not be liable for damage to or destruction of equipment that occurs or which persons other than "+sCompanyName+" employees or representatives cause. "+sCompanyName+" shall have no liability for damages of any kind arising from the installation and/or use of equipment and/or for failure to perform proper maintenance by anyone other than "+sCompanyName+" employees. The Buyer, by acceptance of the equipment, assumes all liability for any damages or injuries that may result from its use or misuse by the Buyer, Buyer’s employees, or by others.",
                                                "THERE SHALL BE NO EXPRESS OR IMPLIED WARRANTY, GUARANTEE, OR LIABILITY EXCEPT AS STATED HEREIN. "+sCompanyName+" SHALL NOT BE LIABLE TO BUYER FOR ANY LOSS, DAMAGE, OR INJURY TO PERSONS OR PROPERTY RESULTING FROM THE HANDLING, STORAGE, TRANSPORTATION, RESALE, OR USE OF ITS PRODUCTS IN MANUFACTURING PROCESSES, OR IN COMBINATION WITH OTHER EQUIPMENT, PRODUCTS, MATERIALS, OR SUBSTANCES FROM A THIRD PARTY, OR OTHERWISE. IN NO EVENT SHALL "+sCompanyName+"’S LIABILITY UNDER THESE TERMS AND CONDITIONS OR IN CONNECTION WITH THE SALE OF PRODUCTS BY "+sCompanyName+" EXCEED THE PURCHASE PRICE OF THE SPECIFIC PRODUCTS OR SERVICES FOR WHICH ANY CLAIM IS MADE.",
                                                 "16. Software License Agreement: The Software License Agreement (SLA) that accompanies all software purchases shall pertain and govern the Buyer’s use, rights, software warranty, limitations, and restrictions. By purchasing and using "+sCompanyName+" software, the Buyer hereby agrees to be bound by the terms of the SLA. Any software updates accessed and downloaded electronically shall be bound by the SLA of the original purchase. "+sCompanyName+"’s SLA may be viewed at "+sCompanyName+"’s homepage (www.biss.in) under ‘Our Company’ and ‘About Us’. The transfer of "+sCompanyName+" software is prohibited unless authorized by "+sCompanyName+"."
                                                ,"17. Confidential Information: All information furnished or made available by "+sCompanyName+" to Buyer in connection with the subject matter hereof shall be held in confidence by Buyer. Buyer agrees not to use (directly or indirectly), or disclose to others, such information without "+sCompanyName+"’s prior written consent. The obligations in this section will not apply to any information that: (a) at the time of disclosure was or thereafter becomes generally available to the public by publication or otherwise through no breach by Buyer of any obligation herein; (b) Buyer can show by written records was in Buyer’s possession prior to disclosure by "+sCompanyName+"; or (c) is legally made available to Buyer by or through a third party having no direct or indirect confidentiality obligation to "+sCompanyName+" with respect to such information.",
                                                 "18. Ownership of Intellectual Property: All drawings, know-how, designs, specifications, inventions, devices, developments, processes, copyrights and other information or Intellectual Property disclosed or otherwise provided to Buyer by "+sCompanyName+" and all rights therein (collectively, ‘Intellectual Property’) will remain the property of "+sCompanyName+" and will be kept confidential by Buyer in accordance with these Terms and Conditions. Buyer shall have no claim to, nor ownership interest in, any Intellectual Property and such information, in whatever form and any copies thereof, shall be promptly returned to "+sCompanyName+" upon written request from "+sCompanyName+". Buyer acknowledges that no license or rights of any sort are granted to Buyer hereunder in respect of any Intellectual Property, other than the limited right to use the "+sCompanyName+"’s proprietary Products purchased from "+sCompanyName+".",
                                                 "19. Use of Trademarks and Trade Names: Buyer shall not use, directly or indirectly, in whole or in part, "+sCompanyName+"’s name, or any other trademark or trade name that is now or may hereafter be owned by "+sCompanyName+" (collectively the ‘Trademarks’), as part of Buyer’s corporate or business name, or in any way in connection with Buyer’s business, except in a manner and to the extent authorized herein or otherwise approved by "+sCompanyName+" in writing. Buyer hereby acknowledges "+sCompanyName+"’s ownership of the Trademarks and the goodwill associated therewith. Buyer shall not infringe upon, harm or contest the validity of any Trademarks. Buyer shall be entitled to use the Trademarks only in connection with the promotion or sale of the Products pursuant to the terms of the Agreement. Buyer shall reproduce the Trademarks exactly as specified by "+sCompanyName+". Buyer shall not use the Trademarks in combination with any other trademarks or names. Buyer agrees that it will not register or attempt to register any Trademark or any colorable imitation thereof (including any non-English language variation thereof), or use such Trademarks for any products or for any purposes other than those set forth in the Agreement. Buyer shall not at any time during or after termination of the Agreement use in its business any other trademark that is similar to or in any way resembles the Trademarks so as to be likely to cause deception or confusion with the Trademarks. Buyer shall provide reasonable cooperation to "+sCompanyName+" with respect to any efforts of "+sCompanyName+" to protect, defend, or enforce its rights to the Trademarks. Should Buyer cease being an authorized customer of "+sCompanyName+" for any reason, Buyer shall immediately discontinue any formerly permitted use of "+sCompanyName+"’s name or the Trademarks.",
                                                "20. Indemnification: For services performed on Buyer’s site associated with Products purchased pursuant to these Terms, "+sCompanyName+" agrees to indemnify Buyer for sums Buyer becomes legally obligated to pay as damages for bodily \ninjury or property damage caused by ‘"+sCompanyName+"'s fault.’ ‘"+sCompanyName+"'s fault’ is defined as: (i) a manufacturing defect, design defect (if designed by "+sCompanyName+"), or negligent failure to warn with respect to products designed by "+sCompanyName+" and supplied to Buyer by "+sCompanyName+"; or (ii) the gross negligence or will full misconduct of "+sCompanyName+"'s employees or agents in connection with the installation or service of "+sCompanyName+"'s products or equipment. "+sCompanyName+" further agrees to indemnify Buyer for reasonable legal expenses it incurs defending itself against any suits seeking such damages. "+sCompanyName+" shall have no obligation to indemnify Buyer for any damages caused by Buyer's fault or for any legal expenses incurred by Buyer in defending itself against suits seeking damages caused by Buyer's fault. To the extent any suit involves claims against Buyer based on both "+sCompanyName+"'s fault and Buyer's fault, "+sCompanyName+"'s obligation to indemnify Buyer for both damages and legal expenses shall be an allocated share, determined by agreement of the parties, or if the parties fail to agree, final judicial resolution of the proportion of liability imposed on each party. It is a condition of this indemnity that "+sCompanyName+" be given prompt written notice of any claims and that Buyer fully cooperates in any defense to such claims. "+sCompanyName+" acknowledges to Buyer that it maintains comprehensive general liability insurance, including completed operations, and contractual liability with minimum bodily injury and property damage which will protect and indemnify Buyer against any and all damages as stated above. If requested, "+sCompanyName+" shall provide a certificate of insurance to Buyer with Buyer as certificate holder and providing for 30 days’ notice of cancellation or non-renewal. UNDER NO CIRCUMSTANCES SHALL "+sCompanyName+" BE LIABLE FOR ANY CONSEQUENTIAL, INDIRECT, CONTINGENT, PUNITIVE, OR SPECIAL DAMAGES, INCLUDING, BUT NOT LIMITED TO, LOST PROFITS. The term of this indemnity shall be for one (1) year from the date of delivery or for the term of the warranty of Buyer’s purchase herein which includes services performed by "+sCompanyName+" on Buyer’s site, after which it shall have no further force or effect.",
                                                "21. Export Sales: Subject to the above conditions, special packing and crating will be added to the invoice, if necessary.",
                                                "22. Export Control: The Buyer acknowledges that the Goods, Services, and Technology herein are subject to the export control regulations of the United States, as amended, and agrees, as a condition of acceptance of this quotation/contract and issuance of any subsequent order or contract hereto, that the Goods, Services, and Technology will not be used for purposes associated with any chemical, biological, or nuclear weapons or with any missiles or armament capable of delivering such weapons, or in support of any terrorist activity or any other weapons of mass destruction (WMD) end use. Nor, will they be re-sold or transferred if it is known or suspected that they are intended for such purposes. This agreement is subject to acceptance that the export of Goods, Services and Technology hereunder is contingent upon the export controls of the United States, and, in the event that the requisite governmental authorizations cannot be obtained, "+sCompanyName+" shall not be liable to the Buyer in respect of any bond or guarantee or for any loss, damage, consequences or other resultant financial penalty.",
                                                "23. Force Majeure: Delivery dates indicated on quotations or on Order Acknowledgements are estimated and not guaranteed. "+sCompanyName+" shall not be liable or responsible for failure to perform or delay in performance or delivery of any Products or Services due to (a) fires, floods, strikes or other labour disputes, accidents, sabotage, terrorism, war, riots, acts of precedence or priorities granted at the request or for the benefit, directly or indirectly, of any federal, state or local government or any subdivision or agency thereof, delays in transportation or lack of transportation facilities, restrictions imposed by federal, state or local laws, rules or regulations; or (b) any other cause beyond the control of "+sCompanyName+". In the event of the occurrence of any of the foregoing, the time for performance shall be extended for such time as may be reasonably necessary to enable "+sCompanyName+" to perform the terms of the sale.",
                                                "24. Integration Clause: These Terms and Conditions constitute the terms and conditions to the contract of sale and purchase between Buyer and "+sCompanyName+" with respect to the Products or Services covered by these Terms and Conditions, and supersedes any prior agreements, understandings, representations, and quotations with respect thereto. No modification hereof shall have any force or effect unless in writing and signed by the Party claiming to be bound thereby.",
                                                "25. Waiver: No failure of "+sCompanyName+" to insist upon strict compliance by Buyer with these Terms and Conditions or to exercise any right accruing from any default of Buyer shall impair "+sCompanyName+"’s rights in case Buyer’s default continues or in case of any subsequent default by Buyer. Waiver by "+sCompanyName+" of any breach by Buyer of these Terms and Conditions shall not be construed as a waiver of any other existing or future breach.",
                                                "26. Limitation of Actions/Choice of Law/Litigation Costs: The Parties shall first attempt to settle any dispute, controversy or claim arising out of or in connection with this Agreement or the execution thereof through good faith negotiations. Any All disputes connected with the present contract should be resolved amicably. If that is not possible they shell be referred to Indian court and settled in accordance with Indian law. The arbitration agreement in this section is governed by the law applicable in the place where "+sCompanyName+" initiated the sale of Products and/or Services. The English language shall be used in the arbitration proceedings. Any arbitration award shall be final and binding on the parties with no right of appeal. This section survives termination of this Agreement.",
                                                "27. Material handling: Unloading and moving the equipment to place of installation is customer’s responsibility. Unpacking and relocation of equipment will be customer responsibility.",
                                                "28. Installation commissioning and training: User training will be imparted upon completion of installation of the system. All required specimens for demonstration and training to be provided by the customer. "+sCompanyName+" in no account is responsible for site related delays in equipment installation. For sake of payment closure, the supply including equipment installation commissioning and training are deemed to be complete if the site is not ready at the time of delivery or if the customer is not available for training / acceptance. As soon as site becomes available, installation commissioning and training will be completed at mutually agreed time subject to prior closure of payment."
                                           ,"29. Site requirements: To be finalised before order acceptance. Customer to provide free access to the installation site for "+sCompanyName+" installation engineers, any pre-requisite papers or permissions to be provided by customer.",
                                           "30. Survival: Any provisions in these Terms and Conditions herein which, by their nature, extend beyond the termination or expiration of any sale of Products or Services, will remain in effect until fulfilled." ,
                                           "31. Severability: If any provision herein shall be held to be unlawful or unenforceable, the remaining provisions herein shall remain in full force and effect."};

                        foreach (string str in GeneralTermsandConditions)
                        {
                            kRowHeight++;
                            NewWorkSheet.Cells[iRowIndex, 1] = str;
                            switch (kRowHeight)
                            {
                                case 1:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 15).Font.FontStyle = "Bold";
                                    //  NewWorkSheet.Cells[iRowIndex, 1].Characters(570, 580).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 185;
                                    break;
                                case 2:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 11).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 70;
                                    break;
                                case 3:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 16).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 35;
                                    break;
                                case 4:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 17).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 120;
                                    break;
                                case 5:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 19).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 170;
                                    break;
                                case 6:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 20).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 36;
                                    break;
                                case 7:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 20).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 36;
                                    break;
                                case 8:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 27).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 36;
                                    break;
                                case 9:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 27).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 36;
                                    break;
                                case 10:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 19).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 36;
                                    break;
                                case 11:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 14).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 70;
                                    break;
                                case 12:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 19).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 90;
                                    break;
                                case 13:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 24).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 36;
                                    break;
                                case 14:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 28).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 238;
                                    break;
                                case 15:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 12).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 352;
                                    break;
                                case 16:
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 155;
                                    break;
                                case 17:
                                    NewWorkSheet.Cells[iRowIndex, 1].Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 120;
                                    break;
                                //16
                                case 18:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 32).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 100;
                                    break;
                                case 19:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 29).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 120;
                                    break;
                                case 20:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 40).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 120;
                                    break;
                                case 21:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 39).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 250;
                                    break;
                                case 22:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 20).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 335;
                                    break;
                                case 23:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 16).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 22;
                                    break;
                                case 24:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 20).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 150;
                                    break;
                                case 25:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 19).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 135;
                                    break;
                                case 26:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 22).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 70;
                                    break;
                                case 27:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 12).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 70;
                                    break;
                                case 28:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 57).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 120;
                                    break;
                                case 29:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 22).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 38;
                                    break;
                                case 30:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 45).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 105;
                                    break;
                                case 31:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 22).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 38;
                                    break;
                                case 32:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 13).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 38;
                                    break;
                                case 33:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 17).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 38;
                                    break;
                            }


                            NewWorkSheet.Range["A" + iRowIndex + ":A" + iRowIndex + ""].Cells.WrapText = true;
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                            // CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                            CellMerge(sTextAlign, NewWorkSheet, iRowIndex, iRowIndex, 1, 4);

                            CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                            iRowIndex++;
                        }


                        iRowIndex++;
                        NewWorkSheet.HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);
                        NewWorkSheet.Cells[iRowIndex, 1] = "Customer Responsibility";
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                        CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                        NewWorkSheet.get_Range("A" + iRowIndex + "", "D" + iRowIndex + "").Cells.Font.Size = 18;
                        CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                        NewWorkSheet.Rows[iRowIndex].RowHeight = 26;
                        NewWorkSheet.Cells[(iRowIndex), 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                        NewWorkSheet.Cells[(iRowIndex), 2].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                        NewWorkSheet.Cells[(iRowIndex), 3].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                        NewWorkSheet.Cells[(iRowIndex), 4].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                        iRowIndex++;

                        NewWorkSheet.Cells[iRowIndex, 1] = "*Note: ITW India Private Limited – " + sCompanyName + " Division will be termed as " + sCompanyName + " in this document";
                        NewWorkSheet.Cells[iRowIndex, 1].Font.Italic = true;
                        NewWorkSheet.Cells[iRowIndex, 1].Font.Color = Color.FromArgb(186, 12, 47);
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                        CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                        NewWorkSheet.Rows[iRowIndex].RowHeight = 20;
                        iRowIndex++;
                        //  iRowIndex++;
                        kRowHeight = 0;

                        string[] CustomerResponsibility ={"1. Customer Responsibilities: The Customer is solely responsible for preparing the facility, laboratory, or room for the equipment purchased. The readiness of the Customer’s facility is required for "+sCompanyName+" to begin installation. Preparations may include, but are not limited to, air supply, electrical supply and regulation, cooling water, safe handling and moving equipment, structural integrity of building and floor where testing system shall be located, etc. This document shall be considered part of the Terms and Conditions for the Customer’s purchase. The Pre-Installation Manual for the Equipment should be reviewed for more specific information for all new testing system purchases. Questions or requests for assistance should be directed to the "+sCompanyName+" Service Department or Customer Service in Bangalore at (080) 28360184. For outside the India, the local representative should be contacted. Contact details may be found www.biss.in",
                                          "2. Site Preparation: Proper site preparation is essential for expeditious and trouble-free startup of equipment during installation. The site must be prepared prior to scheduling the installation. This typically consists of the items listed below, but other items may be required depending on the equipment. "+sCompanyName+" Pre-Installation Manual or information will be sent in advance of the system and should be consulted for more detailed information. Please read the quotation carefully to ensure that the facilities in Customer’s building are appropriate for the instruments being placed there.\n    a. Instrument Placement: Heavy duty support tables with sufficient load capacity to support the weight of table model testing instruments or heavy accessories are necessary. Sufficient clearance around the perimeter of the instrument must be considered before final placement, especially for floor models, to allow for adequate access for the addition or removal of certain accessories. Consult the "+sCompanyName+" Pre-Installation Manual or contact "+sCompanyName+" Customer Service for information on an appropriately-sized table.\n     b. Electrical Power: Required by electromechanical load frames, hydraulic power supplies, temperature chambers, furnaces, controllers and computers. Electricity must be ‘clean’ and stable and within ± 10% of the specified voltage, unless other arrangements are made with "+sCompanyName+".",
                                          "    c. Network and Telephone Access: Having a network connection and telephone near the system will facilitate system updates, support, troubleshooting, and data transfer.\n    d. Compressed air: Some testing systems, such as impact testers and pneumatically-operated accessories require pneumatic air supplied at a nominal 90 psi (6 bar or 620 kPa) air with an air regulator, water trap, and filter. Consult "+sCompanyName+"’s equipment manual or "+sCompanyName+" Customer Service for the specific pneumatic pressure requirements for the products being purchased.\n    e. Environment: The necessary environment for "+sCompanyName+" equipment is generally +10 to +38C (+50 to +100F), 10% to 90% humidity (non-condensing). The environment should be draft-free and stable.\n    f. LN2 or CO2: Required for environmental chambers with cooling options. Cryogen gas extraction will also be required.\n    g. Water: Required for most hydraulic power supplies, some specimen grips, and some temperature controls systems. Cooling water should be provided at the specified pressure, flow, and temperature and should be free of hard deposits such as calcium.",
                                          "    h. HVAC: Air-cooled hydraulic power supplies are sometimes supplied and they usually have a significant effect on the heating, ventilation, and air conditioning (HVAC) system. Temperature chambers and furnaces can also have an effect and should be considered as part of Customer’s environmental control plan. Machines should not generally be sited such that HVAC output is directed at any of the transducers or in their proximity.\n    i. Hydraulic Fluid: Where an existing hydraulic power supply is to be utilized, it will be necessary to top-up the hydraulic oil to compensate for the volume of oil required to fill the hydraulic hoses and actuator package of the new system. Supply of top-up oil is the customer's responsibility unless other arrangements are made. Where a supplier other than "+sCompanyName+" is providing the hydraulic oil, the Customer should check very thoroughly and carefully for compatibility of oil brand/type. Mixing of incompatible oil can have severe short or long-term effects on equipment performance. Unless specified otherwise, oil supplied from external sources should pass through a 3-micron filter prior to filling the "+sCompanyName+" system. Contact "+sCompanyName+" for further advice if required.\n    j. Silicon Oil: Some of our products require the use of silicon oils for temperature baths. These must be provided locally by the Customer.",
                                          "3. Equipment Handling and Placement: Unless other arrangements are made, the Customer shall be responsible for the safe unloading, handling, movement, and placement of the equipment upon delivery to the desired location prior to installation and commissioning by a "+sCompanyName+" Service representative. Arrangements can be made to have a "+sCompanyName+" Service representative supervise the off-loading and moving of the equipment to its final location. It is important to follow these instructions to prevent damage to the equipment.\n    a. The receiving dock needs to be large enough to handle shipment. It also needs to be elevated for off-loading of the truck unless prior arrangements for ‘lift-gate service’ have been made with "+sCompanyName+".\n    b. Properly sized handling and moving equipment to transfer the instrument to the desired location. This includes lifting the equipment onto a tabletop or to different floor locations within the Customer’s facility (e.g., elevator availability and specifications able to handle instrument safely).\n    c. Trained moving personnel will be needed for moving potentially large and heavy items.\n    d. Space clearances must be sufficient to allow easy movement and transfer of equipment through hallways, doors, stairs, and/or elevators.\n    e. Ceiling clearance must be sufficient to allow the equipment to be placed and operated without interference. The equipment may require hoisting or lifting from a horizontal shipping position to the vertical upright position. Room heights must be carefully checked to verify appropriate clearances.\n    f. Seismic Mass: Consultation with a civil engineer should be carried out prior to installation of systems capable of producing high impact energies or reactive loads on the building floor or structure.",
                                          "4. Calibration: Calibration may be required after the Customer’s system is installed to comply with various standards, such as ISO 17025, ASTM E 4, ASTM E 83, ISO 7500-1, and ISO 9513. If the Customer needs to address these and/or other standards, then calibration services at installation must be included in Customer’s purchase order.",
                                          "5. Personal Computers (PC’s) for use with "+sCompanyName+" Testing Instruments: Computer Integration is required for all PCs that will be used as a system controller for "+sCompanyName+" testing systems. Most commercial PC’s can be integrated with "+sCompanyName+"’s testing systems. The following explains the procedures required to insure compatibility.\n    a. Customer-supplied, "+sCompanyName+"-approved PC (On-Site or Factory Integration): These are PCs purchased by the customer that meet the minimum performance and software specifications for the "+sCompanyName+" system that they will be used with. In most cases, "+sCompanyName+" can integrate customer-supplied PCs and associated software which conforms to minimum "+sCompanyName+" PC hardware and software requirements with "+sCompanyName+" Test Systems and "+sCompanyName+" developed software. This integration can be provided either on-site by a "+sCompanyName+" Field Service Representative or by our factory technicians. Both of these are fee-based services. "+sCompanyName+" cannot provide hardware support for customer-supplied PCs, but can provide software support for "+sCompanyName+" developed SW as long as the PC hardware and software configuration has been integrated by "+sCompanyName+" and deemed compatible. All service visits related to customer supplied "+sCompanyName+"-approved PCs would be charged at the standard "+sCompanyName+" service rate.\n    b. Customer-supplied, non-approved PC (On-site or Factory Integration): These are PCs that customers purchase that meet "+sCompanyName+"’s minimum performance specification and software configuration for the "+sCompanyName+" system they will be used with, but are NOT specific models with the specific configuration "+sCompanyName+" recommends.",
                                          "6. Retrofits: The Customer shall be solely responsible for ensuring the existing testing instrument upon which the retrofit is to be installed is: (i) in proper and safe working condition and (ii) fully operational prior to the retrofit installation. The Customer is responsible to correct any necessary deficiencies and repairs to the existing testing instrument and shall be the subject of a separate quote, purchase, and/or order. For retrofit purchases, "+sCompanyName+"’s liability and responsibility is limited to only those components that are installed by a "+sCompanyName+" Field Service Representative or its authorized local representative. There shall be no warranty, implied or expressly given by "+sCompanyName+", for the Customer’s existing testing instrument upon which the retrofit shall be installed nor on the performance or accuracy of the combination of new and existing system components. The performance and accuracy of a retrofitted testing instrument or system is dependent upon the condition of the system prior to retrofit or upgrade.",
                                          "7. Miscellaneous: \n   a. Compressed Nitrogen: Transportation regulations sometimes require that hydraulic accumulators used on hydraulic power supplies or hydraulic manifolds be discharged for transportation. The Customer shall be responsible to provide compressed, dry nitrogen at 140 bar (2,000 psi) with pressure regulation and a shut-off valve. Should the Customer chose, "+sCompanyName+" can provide the necessary accumulator charging kit to ensure the accumulators are appropriately charged.\n   b. Materials Disposal: The Customer shall be responsible for the disposal of any waste materials associated with the installation, including packing materials, old electronics not being traded in, and hydraulic fluids and/or any waste contaminated with hydraulic fluid. "+sCompanyName+"’s Field Service Representative will clean up the site disposing of any packing material in Customer’s refuse disposal containers, with Customer’s permission."};

                        foreach (string str in CustomerResponsibility)
                        {
                            kRowHeight++;
                            NewWorkSheet.Cells[iRowIndex, 1] = str;
                            switch (kRowHeight)
                            {
                                case 1:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 29).Font.FontStyle = "Bold";
                                    //  NewWorkSheet.Cells[iRowIndex, 1].Characters(570, 580).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 135;
                                    break;
                                case 2:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 20).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 220;
                                    break;
                                case 3:
                                    // NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 16).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 200;
                                    break;
                                case 4:
                                    //NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 17).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 220;
                                    break;
                                //3
                                case 5:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 36).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 300;
                                    break;
                                case 6:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 16).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 55;
                                    break;
                                case 7:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 67).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 250;
                                    break;
                                case 8:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 14).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 155;
                                    break;
                                case 9:
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 17).Font.FontStyle = "Bold";
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 150;
                                    break;
                            }

                            NewWorkSheet.Range["A" + iRowIndex + ":A" + iRowIndex + ""].Cells.WrapText = true;
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                            // CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                            CellMerge(sTextAlign, NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                            CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                            iRowIndex++;
                        }



                        NewWorkSheet.Rows[1].RowHeight = 6;
                        NewWorkSheet.Rows[2].RowHeight = 48;
                        NewWorkSheet.Rows[7].RowHeight = 18;

                        NewWorkSheet.Columns[1].ColumnWidth = 22;
                        NewWorkSheet.Columns[2].ColumnWidth = 75;
                        NewWorkSheet.Columns[2].WrapText = true;
                        NewWorkSheet.Columns[3].ColumnWidth = 11;
                        NewWorkSheet.Columns[4].ColumnWidth = 21;

                        // NewWorkSheet.Columns[20].ColumnWidth = 107;
                        //NewWorkSheet.get_Range("A" + title1 + "", "D" + title1 + "").Cells.Font.Size = 16;
                        //NewWorkSheet.get_Range("A" + title2 + "", "D" + title2 + "").Cells.Font.Size = 16;
                        NewWorkSheet.PageSetup.PrintArea = "A1:D" + iRowIndex + "";
                        NewWorkSheet.PageSetup.LeftMargin = 0.3;
                        NewWorkSheet.PageSetup.RightMargin = 0.3;
                        NewWorkSheet.PageSetup.CenterHorizontally = true;
                        NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                        NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
                        NewWorkSheet.PageSetup.LeftHeader = "&\"Arial\"&10" + cmbCustomer.Text + "";
                        NewWorkSheet.PageSetup.RightHeader = "&\"Arial\"&10" + sQuotationNumber + " - " + RevisionNumber + "\nDated : " + sQuoteDate + " ";
                        //NewWorkSheet.PageSetup.Margins.Header = 1.3;
                        NewWorkSheet.PageSetup.AlignMarginsHeaderFooter = false;
                        if (cmbEnquireCurrency.SelectedIndex == 0)
                        {
                            NewWorkSheet.PageSetup.CenterFooter = "&\"Arial\"&10 All prices are in INR ";
                        }
                        else
                        {
                            NewWorkSheet.PageSetup.CenterFooter = "&\"Arial\"&10 All prices are in USD ";
                        }



                        NewWorkSheet.PageSetup.RightFooter = "Page &P of &N";
                        NewWorkSheet.PageSetup.Zoom = 74;

                        if (!bPreview)
                        {
                            if (cmbQuoteCompany.SelectedIndex == 0)
                            {
                                if (File.Exists(Global.sLogo))
                                {
                                    EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 3];
                                    Image oImage = Image.FromFile(Global.sLogo);
                                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                                  //  NewWorkSheet.Paste(oRange, Global.sLogo);

                                        System.Threading.Thread.Sleep(500);
                                        NewWorkSheet.Paste(oRange);
                                    }
                            }
                            else if (cmbQuoteCompany.SelectedIndex == 1)
                            {
                                if (File.Exists(Global.sInsronLogo))
                                {
                                    EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 3];
                                    Image oImage = Image.FromFile(Global.sInsronLogo);
                                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                                   // NewWorkSheet.Paste(oRange, Global.sInsronLogo);
                                        System.Threading.Thread.Sleep(500);
                                        NewWorkSheet.Paste(oRange);

                                    }
                            }
                        }
                        if (File.Exists(Global.sITWLogo))
                        {
                            EXCEL.Range oRange1 = (EXCEL.Range)NewWorkSheet.Cells[2, 1];
                            Image oImage1 = Image.FromFile(Global.sITWLogo);
                            System.Windows.Forms.Clipboard.SetDataObject(oImage1, true);
                          //  NewWorkSheet.Paste(oRange1, Global.sITWLogo);
                                System.Threading.Thread.Sleep(500);
                                NewWorkSheet.Paste(oRange1);
                            }
                        if (bPreview)
                        {
                            if (File.Exists(Global.sPreview))
                            {
                                EXCEL.Range oRange1 = (EXCEL.Range)NewWorkSheet.Cells[2, 3];
                                Image oImage1 = Image.FromFile(Global.sPreview);
                                System.Windows.Forms.Clipboard.SetDataObject(oImage1, true);
                              //  NewWorkSheet.Paste(oRange1, Global.sPreview);
                                    System.Threading.Thread.Sleep(500);
                                    NewWorkSheet.Paste(oRange1);
                                }
                        }

                        NewWorkBook.Save();
                        ExcelApp.Visible = true;
                        ExcelApp.ActiveWorkbook.Saved = true;

                        // EXCEL.Worksheet Worksheet = (EXCEL.Worksheet)NewWorkBook.ActiveSheet;
                        // EXCEL.PageSetup PageSetup = Worksheet.PageSetup;
                        // NewWorkSheet.PageSetup.ResolutionX = 600;
                        //NewWorkSheet.PageSetup.ResolutionY = 600;    
                        //((Microsoft.Office.Interop.Excel._Worksheet) NewWorkBook.ActiveSheet).PageSetup.Orientation =Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                        // NewWorkBook.ExportAsFixedFormat(EXCEL.XlFixedFormatType.xlTypePDF, FileFul);
                        NewWorkBook.ExportAsFixedFormat(EXCEL.XlFixedFormatType.xlTypePDF, FileFul, EXCEL.XlFixedFormatQuality.xlQualityStandard, true);

                        //                NewWorkBook.ExportAsFixedFormat(EXCEL.XlFixedFormatType.xlTypePDF, FileFul,
                        //EXCEL.XlFixedFormatQuality.xlQualityStandard, true, true, 1, Type.Missing, true);

                        System.Diagnostics.Process.Start(FileFul);

                        NewWorkBook.Close(true, misValue, misValue);
                        ExcelApp.Quit();
                        releaseObject(NewWorkSheet);
                        releaseObject(NewWorkBook);
                        releaseObject(ExcelApp);
                        // Close workbook and Excel application
                        //shreeshail is addedd code below
                        //NewWorkBook.Close();
                        //ExcelApp.Quit();

                        // Release Excel objects
                        //System.Runtime.InteropServices.Marshal.ReleaseComObject(NewWorkBook);
                        //System.Runtime.InteropServices.Marshal.ReleaseComObject(ExcelApp);
                        //shreeshail is added code above

                        if (File.Exists(FileFullPath))
                        {
                            //shreeshail is added below code
                            // File.Delete(FileFullPath);
                            using (FileStream stream = File.Open(FileFullPath, FileMode.Open, FileAccess.ReadWrite, FileShare.None))
                            {
                                // Perform any operations on the file, if needed
                                // Close the stream to release the file handle without deleting the file
                                stream.Close();
                                //shreeshail is added above code
                            }
                        }

                        // ExportWorkbookToPDF(FileFullPath, FileFul);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                        foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                        {
                            GetProcess.Kill();
                        }
                    }
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("PurchaseOrder_btnReport_Click  " + ex.Message);
            }
        }
    }
        #endregion

        //private bool SaveAsPdf(string saveAsLocation)
        //{
        //    string saveas = (saveAsLocation.Split('.')[0]) + ".pdf";
        //    try
        //    {
        //        Workbook workbook = new Workbook();
        //        workbook.LoadFromFile(saveAsLocation);

        //        //Save the document in PDF format

        //        workbook.SaveToFile(saveas, Spire.Xls.FileFormat.PDF);
        //        return true;
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(ex.Message);
        //        return false;
        //    }
        //}


        #region reusablecode
        private void fnresusedcode()
        {


        }
        #endregion


        //private static void ExportWorkbookToPDF(string workbook, string output)
        //{
        //    if (string.IsNullOrEmpty(workbook) || string.IsNullOrEmpty(output))
        //    {
        //        throw new NullReferenceException("Cannot create PDF copy " +
        //            "from empty workbook.");
        //    }

        //    EXCEL.Application excelApplication = new  EXCEL.Application();
        //    excelApplication.ScreenUpdating = false;
        //    excelApplication.DisplayAlerts = false;
        //    excelApplication.Visible = false;

        //   EXCEL.Workbook excelWorkbook = excelApplication.Workbooks.Open(
        //        Path.GetDirectoryName(workbook));

        //    if (excelWorkbook == null)
        //    {
        //        excelApplication.Quit();
        //        excelApplication = null;
        //        excelWorkbook = null;

        //        throw new NullReferenceException("Cannot create new excel workbook.");
        //    }

        //    try
        //    {
        //        excelWorkbook.ExportAsFixedFormat(EXCEL.XlFixedFormatType.xlTypePDF,
        //            Path.GetDirectoryName(output));
        //    }
        //    catch (Exception e)
        //    {
        //        Console.WriteLine(e.Message);
        //        Console.ReadLine();
        //    }
        //    finally
        //    {
        //        excelWorkbook.Close();
        //        excelApplication.Quit();
        //        excelApplication = null;
        //        excelWorkbook = null;
        //    }
        //}

        //  CultureInfo india = new CultureInfo("hi-IN");

        string sTextAlign = "TextAlign";
        #region CellMerge Funtion
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "GridLines":
                    {
                        CELLS.Borders.Color = System.Drawing.Color.Black;
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignCenter":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                        break;
                    }
                case "AlignRight":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                        break;
                    }
                case "AlignLeft":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignLeft;
                        break;
                    }
                case "TextAlign":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignJustify;
                        break;
                    }
                case "AlignTop":
                    {
                        CELLS.VerticalAlignment = EXCEL.XlVAlign.xlVAlignTop;
                        break;
                    }
                case "VAlignCenter":
                    {
                        CELLS.VerticalAlignment = EXCEL.XlVAlign.xlVAlignCenter;
                        break;
                    }

                case "Bold":
                    {
                        CELLS.Font.Bold = true;
                        break;
                    }

                case "Autofit":
                    {
                        CELLS.Rows.AutoFit();
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

        }
        #endregion

        #region Excel App Release Object Function
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
        #endregion


        CultureInfo culture = new CultureInfo("en-US");
        private void ReminderExample()
        {
            Outlook.Application outlookApp = new Outlook.Application();
            Outlook.AppointmentItem appt = (Outlook.AppointmentItem)outlookApp.CreateItem(Outlook.OlItemType.olAppointmentItem);
            appt.Subject = txtSubject.Text;
            appt.Location = txtLocation.Text;
            appt.Body = txtBody.Text;
            appt.Sensitivity = Outlook.OlSensitivity.olPrivate;
            string CustomFormat = "dd/MM/yyyy hh:mm tt";
            appt.Start = DateTime.ParseExact(dtpFromDate.Text.ToString(), CustomFormat, culture);
            appt.End = DateTime.ParseExact(dtpEndDate.Text.ToString(), CustomFormat, culture);
            appt.ReminderSet = true;
            appt.ReminderMinutesBeforeStart = 15;
            appt.Importance = Outlook.OlImportance.olImportanceHigh; // appointment importance
            appt.BusyStatus = Outlook.OlBusyStatus.olBusy;
            appt.Save();
            MessageBox.Show("The reminder successfully set.", "Success", 0, MessageBoxIcon.Information);
            cheSetReminder.Checked = false;
        }

        private void cheSetReminder_CheckedChanged(object sender, EventArgs e)
        {
            if (cheSetReminder.CheckState == CheckState.Checked)
            {
                dtpFromDate.Value = dtpFromDate.Value.AddDays(15);
                dtpEndDate.Value = dtpEndDate.Value.AddDays(15);
                dtpFromDate.CustomFormat = "dd/MM/yyyy hh:mm tt";
                dtpEndDate.CustomFormat = "dd/MM/yyyy hh:mm tt";
                txtSubject.Text = "Enquiry Reminder for '" + cmbCustomer.Text + "'";
                pnAppointment.Visible = true;
            }
            else
            {
                dtpFromDate.Value = dtpFromDate.Value.AddDays(-15);
                dtpEndDate.Value = dtpEndDate.Value.AddDays(-15);
                pnAppointment.Visible = false;
            }
        }


        private void txtName_Leave(object sender, EventArgs e)
        {
            if (txtName.Text.Length == 0)
            {
                txtName.Text = "Enter Name";
                txtName.ForeColor = SystemColors.GrayText;
            }
        }

        private void txtName_Enter(object sender, EventArgs e)
        {
            if (txtName.Text == "Enter Name")
            {
                txtName.Text = "";
                txtName.ForeColor = SystemColors.WindowText;
            }
        }

        private void btnAddFolder_Click(object sender, EventArgs e)
        {
            txtName.Visible = true;
            txtCode.Visible = false;
            btnQuoteTreeSave.Enabled = true;
            txtName.ForeColor = SystemColors.GrayText;
            txtName.Text = "Enter Name";
            txtName.Leave += new System.EventHandler(txtName_Leave);
            txtName.Enter += new System.EventHandler(txtName_Enter);
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            txtName.Visible = true;
            txtCode.Visible = true;
            btnQuoteTreeSave.Enabled = true;
            txtCode.ForeColor = SystemColors.GrayText;
            txtCode.Text = "Enter Model Number";
            txtCode.Leave += new System.EventHandler(txtCode_Leave);
            txtCode.Enter += new System.EventHandler(txtCode_Enter);

            txtName.ForeColor = SystemColors.GrayText;
            txtName.Text = "Enter Name";
            txtName.Leave += new System.EventHandler(txtName_Leave);
            txtName.Enter += new System.EventHandler(txtName_Enter);
        }

        private void txtCode_Leave(object sender, EventArgs e)
        {
            if (txtCode.Text.Length == 0)
            {
                txtCode.Text = "Enter Model Number";
                txtCode.ForeColor = SystemColors.GrayText;
            }
        }

        private void txtCode_Enter(object sender, EventArgs e)
        {
            if (txtCode.Text == "Enter Model Number")
            {
                txtCode.Text = "";
                txtCode.ForeColor = SystemColors.WindowText;
            }
        }

        private void tvProduct_AfterLabelEdit(object sender, System.Windows.Forms.NodeLabelEditEventArgs e)
        {
            tvProduct.LabelEdit = false;
        }
        DataTable dtProductorFolderCheck = new DataTable();
        bool bchecked = false;
        private void tvQuoteProduct_NodeMouseClick(object sender, System.Windows.Forms.TreeNodeMouseClickEventArgs e)
        {
            if (e.Node.StateImageIndex == 0)
            {
                bchecked = false;
                sName = e.Node.Name.Split(')');

                dtProductorFolderCheck = DAL.fnQuoteProductorFolder(sName[0], "CV").Tables[0];
                if (dtProductorFolderCheck.Rows.Count == 0)
                {
                    btnAddFolder.Enabled = true;
                    btnAddProduct.Enabled = true;
                    bchecked = true;
                }
                else if (dtProductorFolderCheck.Rows.Count > 0)
                {
                    btnAddFolder.Enabled = false;
                    btnAddProduct.Enabled = true;
                    bchecked = true;
                }
                if (!bchecked)
                {
                    dtProductorFolderCheck = DAL.fnQuoteProductorFolder(sName[0], null).Tables[0];
                    if (dtProductorFolderCheck.Rows.Count > 0)
                    {
                        btnAddFolder.Enabled = true;
                        btnAddProduct.Enabled = false;
                    }
                }
            }
        }
        DataTable dtQuoteNodeID = new DataTable();
        private void btnRename_Click(object sender, EventArgs e)
        {
            if (tvQuoteProduct.SelectedNode.StateImageIndex == 0)
            {
                sName = tvQuoteProduct.SelectedNode.Name.Split(')');
                txtName.Text = sName[1].ToString();
                txtName.Visible = true;
                txtName.ForeColor = SystemColors.WindowText;

            }
            else if (tvQuoteProduct.SelectedNode.StateImageIndex == 1 || tvQuoteProduct.SelectedNode.StateImageIndex == 2)
            {
                sName = tvQuoteProduct.SelectedNode.Name.Split(')');
                dtQuoteNodeID = DAL.fnQuoteProductNodeId(sName[0], null).Tables[0];
                if (dtQuoteNodeID.Rows.Count > 0)
                {
                    txtName.Text = sName[1].ToString();
                    txtCode.Text = dtQuoteNodeID.Rows[0]["ProductCode"].ToString();
                    txtName.Visible = true;
                    txtCode.Visible = true;
                    txtCode.ForeColor = SystemColors.WindowText;
                    txtName.ForeColor = SystemColors.WindowText;
                }
            }
            btnQuoteTreeSave.Text = "Update";
            btnQuoteTreeSave.Enabled = true;
        }

        private void chkAddbyBOM_CheckedChanged(object sender, EventArgs e)
        {
            if (chkAddbyBOM.CheckState == CheckState.Checked)
            {
                chkAddbyQuoteMaster.Checked = false;
                pnQuoteMaster.Visible = false;
                tvProduct.Visible = true;
                LastSearchText = "";
            }
        }

        private void chkAddbyQuoteMaster_CheckedChanged(object sender, EventArgs e)
        {
            if (chkAddbyQuoteMaster.CheckState == CheckState.Checked)
            {
                chkAddbyBOM.Checked = false;
                pnQuoteMaster.Visible = true;
                tvProduct.Visible = false;
                LastSearchText = "";
            }
        }

        private void btnQuoteTreeSave_Click(object sender, EventArgs e)
        {
            if (btnQuoteTreeSave.Text == "Save")
            {
                if (txtName.Text != "Enter Name" && !(txtCode.Visible))
                {
                    dtNodeID = DAL.fnGetSalesLastNodeId(null).Tables[0];
                    if (dtNodeID.Rows.Count > 0)
                    {
                        iLastNodeID = Convert.ToInt32(dtNodeID.Rows[0]["NodeID"].ToString());
                        iLastNodeID++;
                    }
                    sName = tvQuoteProduct.SelectedNode.Name.Split(')');
                    GLobalClass.iSuccess = DAL.fnAddQuoteProduct(Global.uINSERT, Convert.ToInt32(sName[0]), iLastNodeID, "", txtName.Text, 0, LoginForm.GetUserDetails[2], LoginForm.GetUserDetails[2]);
                    MessageBox.Show("Folder '" + txtName.Text + "'  Created Successfully.", "Success", 0, MessageBoxIcon.Information);

                    TreeNode TN = new TreeNode();
                    tvQuoteProduct.BeginUpdate();
                    TN.Name = iLastNodeID + ") " + txtName.Text;
                    TN.Text = iLastNodeID + ") " + txtName.Text;
                    TN.ForeColor = Color.Black;
                    TN.StateImageIndex = 0;
                    tvQuoteProduct.SelectedNode.Nodes.Add(TN);
                    tvQuoteProduct.EndUpdate();
                    btnQuoteTreeSave.Enabled = false;
                    txtCode.Visible = false;
                    txtName.Visible = false;
                }
                else if (txtName.Text != "Enter Name" && txtCode.Text != "Enter Model Number")
                {
                    dtNodeID = DAL.fnGetSalesLastNodeId(null).Tables[0];
                    if (dtNodeID.Rows.Count > 0)
                    {
                        iLastNodeID = Convert.ToInt32(dtNodeID.Rows[0]["NodeID"].ToString());
                        iLastNodeID++;
                    }
                    sName = tvQuoteProduct.SelectedNode.Name.Split(')');
                    GLobalClass.iSuccess = DAL.fnAddQuoteProduct(Global.uINSERT, Convert.ToInt32(sName[0]), iLastNodeID, txtCode.Text, txtName.Text, 2, LoginForm.GetUserDetails[2], LoginForm.GetUserDetails[2]);
                    MessageBox.Show("Folder '" + txtName.Text + "'  Created Successfully.", "Success", 0, MessageBoxIcon.Information);

                    TreeNode TN = new TreeNode();
                    tvQuoteProduct.BeginUpdate();
                    TN.Name = iLastNodeID + ") " + txtName.Text;
                    TN.Text = iLastNodeID + ") " + txtName.Text;
                    TN.ForeColor = Color.Black;
                    TN.StateImageIndex = 2;
                    tvQuoteProduct.SelectedNode.Nodes.Add(TN);
                    tvQuoteProduct.EndUpdate();
                    btnQuoteTreeSave.Enabled = false;
                    txtCode.Visible = false;
                    txtName.Visible = false;
                }
            }
            else if (btnQuoteTreeSave.Text == "Update")
            {
                sName = tvQuoteProduct.SelectedNode.Name.Split(')');



                GLobalClass.iSuccess = DAL.fnAddQuoteProduct(Global.uUPDATE, iLastNodeID, Convert.ToInt32(sName[0]), txtCode.Text, txtName.Text, 2, LoginForm.GetUserDetails[2], LoginForm.GetUserDetails[2]);

                tvQuoteProduct.BeginUpdate();
                tvQuoteProduct.SelectedNode.Name = sName[0] + ") " + txtName.Text;
                tvQuoteProduct.SelectedNode.Text = sName[0] + ") " + txtName.Text;
                tvQuoteProduct.EndUpdate();
                btnQuoteTreeSave.Text = "Save";
                btnQuoteTreeSave.Enabled = false;
                txtCode.Visible = false;
                txtName.Visible = false;
            }
        }

        private void chkSavetoQuoteMaster_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSavetoQuoteMaster.CheckState == CheckState.Checked)
            {
                chkAddbyQuoteMaster.Checked = true;
            }
        }

        private void btnsearchtree_Click(object sender, EventArgs e)
        {
            if (chkAddbyBOM.Checked == true)
            {
                string searchText = this.txtsearchtree.Text;
                if (String.IsNullOrEmpty(searchText))
                {
                    return;
                };

                if (LastSearchText != searchText)
                {
                    //It's a new Search
                    CurrentNodeMatches.Clear();
                    if (chkProductCode.CheckState == CheckState.Checked)
                    {
                        DataTable dtProductCodeSearch = DAL.fnSalesProductCodeName(searchText).Tables[0];
                        LastSearchText = searchText;
                        if (dtProductCodeSearch.Rows.Count > 0)
                        {
                            searchText = (dtProductCodeSearch.Rows[0]["ProductCode"].ToString() + ")" + dtProductCodeSearch.Rows[0]["Name"].ToString()).Trim();
                            LastNodeIndex = 0;
                            SearchNodes(searchText, tvProduct.Nodes[0]);
                        }
                    }

                    else
                    {
                        LastSearchText = searchText;
                        LastNodeIndex = 0;
                        SearchNodes(searchText, tvProduct.Nodes[0]);
                    }
                }

                if (LastNodeIndex >= 0 && CurrentNodeMatches.Count > 0 && LastNodeIndex < CurrentNodeMatches.Count)
                {
                    TreeNode selectedNode = CurrentNodeMatches[LastNodeIndex];
                    LastNodeIndex++;
                    tvProduct.SelectedNode = selectedNode;
                    tvProduct.SelectedNode.Expand();
                    tvProduct.Select();
                    TreeNode tn = tvProduct.SelectedNode;
                    int x = tn.Bounds.X;
                    int y = tn.Bounds.Y;
                    TreeNodeMouseClickEventArgs treeNodeMouseClickEventArgs = new TreeNodeMouseClickEventArgs(tn, MouseButtons.Left, 1, x, y);
                    ///tvProduct_NodeMouseDoubleClick(tn, treeNodeMouseClickEventArgs);

                }
            }
            else if (chkAddbyQuoteMaster.Checked == true)
            {
                string searchText = this.txtsearchtree.Text;
                if (String.IsNullOrEmpty(searchText))
                {
                    return;
                };

                if (LastSearchText != searchText)
                {
                    //It's a new Search
                    CurrentNodeMatches.Clear();
                    LastSearchText = searchText;
                    LastNodeIndex = 0;
                    SearchNodes(searchText, tvQuoteProduct.Nodes[0]);
                }

                if (LastNodeIndex >= 0 && CurrentNodeMatches.Count > 0 && LastNodeIndex < CurrentNodeMatches.Count)
                {
                    TreeNode selectedNode = CurrentNodeMatches[LastNodeIndex];
                    LastNodeIndex++;
                    tvQuoteProduct.SelectedNode = selectedNode;
                    tvQuoteProduct.SelectedNode.Expand();
                    tvQuoteProduct.Select();
                    TreeNode tn = tvQuoteProduct.SelectedNode;
                    int x = tn.Bounds.X;
                    int y = tn.Bounds.Y;
                    TreeNodeMouseClickEventArgs treeNodeMouseClickEventArgs = new TreeNodeMouseClickEventArgs(tn, MouseButtons.Left, 1, x, y);
                }
            }
        }

        string ExFactory = "";
        private void cmbIncoTerms_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            switch (cmbIncoTerms.SelectedIndex)
            {
                case 0:
                case 1:
                    //pnIncoterm.Enabled = true;
                    // pnIncoterm.Enabled = false;
                    txtFreight.Enabled = false;
                    txtInsurance.Enabled = false;
                    ExFactory = "Ex-factory, Bangalore";
                    fnTotalPrice();
                    break;
                default:
                    ExFactory = cmbIncoTerms.Text;
                    txtFreight.Enabled = true;
                    txtInsurance.Enabled = true;
                    break;
            }

            pnIncoterm.Enabled = true;
        }

        private void chkaddmainitems_CheckedChanged(object sender, EventArgs e)
        {
            if (chkaddmainitems.CheckState == CheckState.Checked)
            {
                cmbProductCategory.SelectedIndex = -1;
                pnOptionalItems.Visible = false;
                chkOptionalItems.Checked = false;
                dgQuoteBOM.Visible = true;
                dgvOptionalItems.Visible = false;
                //if (dgQuoteBOM.Rows.Count == 0)
                //{
                //    cmbProductCategory.SelectedIndex = -1;
                //}
                Datagridviewcolor("ProductCod", dgQuoteBOM);

            }
            else
            {
                chkOptionalItems.Checked = true;
            }
        }

        private void chkOptionalItems_CheckedChanged(object sender, EventArgs e)
        {
            if (chkOptionalItems.CheckState == CheckState.Checked)
            {
                cmbProductCategory.SelectedIndex = -1;
                pnOptionalItems.Visible = true;
                chkaddmainitems.Checked = false;
                dgQuoteBOM.Visible = false;
                dgvOptionalItems.Visible = true;
                //if (dgvOptionalItems.Rows.Count == 0)
                //{
                //    cmbProductCategory.SelectedIndex = -1;
                //}
                Datagridviewcolor("OIProductCode", dgvOptionalItems);
            }
            else
            {
                chkaddmainitems.Checked = true;
            }

        }

        private void txtAIJackup_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            fnNumberKeyPressOnly(sender, e);
        }

        private void txtOIJackup_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            fnNumberKeyPressOnly(sender, e);
        }

        private void txtOIJackup_Leave(object sender, EventArgs e)
        {
            fnEmptyTextBox(sender, e);
            txtOIBasicDemoPrice.Text = Math.Round((Convert.ToDouble(txtOITotalPrice.Text) * Convert.ToDouble(txtOIJackup.Text)) / 100 + (Convert.ToDouble(txtOITotalPrice.Text))).ToString();
            
        }



        private void txtOIJackup_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtOIJackup.Text))
            {
                txtOIBasicDemoPrice.Text = Math.Round(((Convert.ToDouble(txtOITotalPrice.Text) * Convert.ToDouble(txtOIJackup.Text)) / 100 + (Convert.ToDouble(txtOITotalPrice.Text)))).ToString();
                txtOIQuoteJack.Text = txtOIBasicDemoPrice.Text;
                
                fnOICalculation();
            }
        }

        private void chkOIBreakup_CheckedChanged(object sender, EventArgs e)
        {
            if (chkOIBreakup.CheckState == CheckState.Checked)
            {
                dgvOptionalItems.Columns[9].Visible = true;
                fnOICalculation();
                //  txtOIJackup.Text = "00";
            }
            else
            {
                dgvOptionalItems.Columns[9].Visible = false;
            }
        }

        private void dgvOptionalItems_CellBeginEdit(object sender, System.Windows.Forms.DataGridViewCellCancelEventArgs e)
        {
            if (dgvOptionalItems.CurrentCell.OwningColumn.Name == "OIBreakupTPrice" || dgvOptionalItems.CurrentCell.OwningColumn.Name == "OIQuantity")
            {
                oldvalue = Convert.ToDouble(dgvOptionalItems.CurrentCell.Value);
            }
        }


        private void dgvOptionalItems_EditingControlShowing(object sender, System.Windows.Forms.DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress1);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
            }
        }


        private void fnOICalculation()
        {
            sBrekTotalAmount = 0;
            sTotalAmount = 0;
            foreach (DataGridViewRow dgvr in dgvOptionalItems.Rows)
            {
                sBrekTotalAmount += Convert.ToDouble(dgvr.Cells["OIBreakupTotal"].Value);
                sTotalAmount += Convert.ToDouble(dgvr.Cells["OITotalPrice"].Value);
            }
            txtOIQuoteBreak.Text = Math.Round(sBrekTotalAmount).ToString();
            //   txtOITotalPrice.Text = sTotalAmount.ToString();

            double dOIVa = Math.Round(Convert.ToDouble(txtOIQuoteJack.Text) - Convert.ToDouble(txtOIQuoteBreak.Text));
            txtOIQuoteRemain.Text = dOIVa.ToString();

            if (Convert.ToDouble(txtOIQuoteBreak.Text) <= (Convert.ToDouble(txtOIQuoteJack.Text)))
            {
                txtOIQuoteBreak.BackColor = Color.GreenYellow;
                txtOIQuoteRemain.BackColor = Color.White;
            }
            else
            {
                txtOIQuoteRemain.BackColor = Color.Red;
                txtOIQuoteBreak.BackColor = Color.White;
            }
        }

        private void dgvOptionalItems_CellEndEdit(object sender, System.Windows.Forms.DataGridViewCellEventArgs e)
        {
            if (dgvOptionalItems.CurrentCell.OwningColumn.Name == "OIBreakupTotal")
            {
                if (!string.IsNullOrEmpty(dgvOptionalItems.CurrentCell.Value.ToString()) && (dgvOptionalItems.CurrentCell.Value.ToString() != "."))// != null)
                {
                    //if (Convert.ToDouble(dgvOptionalItems.CurrentCell.Value.ToString()) != 0)
                    {
                        //dgvOptionalItems.CurrentRow.Cells["OIMargin"].Value = Math.Round((((Convert.ToDouble(dgvOptionalItems.CurrentCell.Value) / Convert.ToDouble(dgvOptionalItems.CurrentRow.Cells["OIQuantity"].Value)) - Convert.ToDouble(dgvOptionalItems.CurrentRow.Cells["OIProductCost"].Value)) / (Convert.ToDouble(dgvOptionalItems.CurrentCell.Value) / Convert.ToDouble(dgvOptionalItems.CurrentRow.Cells["OIQuantity"].Value))) * 100);

                        dgvOptionalItems.CurrentRow.Cells["OITotalPrice"].Value = Math.Round((Convert.ToDouble(dgvOptionalItems.CurrentRow.Cells["OIQuantity"].Value) * Convert.ToDouble(dgvOptionalItems.CurrentRow.Cells["OIBreakupTotal"].Value))).ToString();
                        fnOICalculation();
                        dtQuoteOptionalItems = dgvOptionalItems.DataSource as DataTable;
                        fnOptionalItemTotalCalculation();
                        //   dgvOptionalItems.CurrentRow.Cells["OITotalPrice"].Value = Math.Round((Convert.ToDouble(dgvOptionalItems.CurrentRow.Cells["OIQuantity"].Value) * Convert.ToDouble(dgvOptionalItems.CurrentRow.Cells["OIUnitPrice"].Value))).ToString();
                    }
                    //else
                    //{
                    //    dgvOptionalItems.CurrentCell.Value = oldvalue;
                    //}

                }
            }
            else if (dgvOptionalItems.CurrentCell.OwningColumn.Name == "OIQuantity")
            {
                if (!string.IsNullOrEmpty(dgvOptionalItems.CurrentCell.Value.ToString()) && (dgvOptionalItems.CurrentCell.Value.ToString() != "."))// != null)
                {
                    if (Convert.ToDouble(dgvOptionalItems.CurrentCell.Value.ToString()) != 0)
                    {
                        dgvOptionalItems.CurrentRow.Cells["OITotalPrice"].Value = Math.Round((Convert.ToDouble(dgvOptionalItems.CurrentRow.Cells["OIQuantity"].Value) * Convert.ToDouble(dgvOptionalItems.CurrentRow.Cells["OIBreakupTotal"].Value))).ToString();
                        //  dgvOptionalItems.CurrentRow.Cells["OIBreakupTotal"].Value = dgvOptionalItems.CurrentRow.Cells["OITotalPrice"].Value.ToString();
                        sBrekTotalAmount = 0;
                        sTotalAmount = 0;
                        foreach (DataGridViewRow dgvr in dgvOptionalItems.Rows)
                        {
                            sBrekTotalAmount += Convert.ToDouble(dgvr.Cells["OIBreakupTotal"].Value);
                            sTotalAmount += Convert.ToDouble(dgvr.Cells["OITotalPrice"].Value);
                        }
                        txtOIQuoteBreak.Text = Math.Round(sBrekTotalAmount).ToString();
                        // txtOITotalPrice.Text = sTotalAmount.ToString();

                        dtQuoteOptionalItems = dgvOptionalItems.DataSource as DataTable;
                        fnOptionalItemTotalCalculation();
                    }
                    else
                    {
                        dgvOptionalItems.CurrentCell.Value = oldvalue;
                    }
                }
            }
        }

        private void dgvOptionalItems_KeyUp(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (dgvOptionalItems.CurrentRow != null)
                {
                    dCurrentcell = 0;
                    dCurrentcell1 = 0.1;
                    dCurrentcell = Convert.ToDouble(dgvOptionalItems.CurrentRow.Cells["OISLNo"].Value.ToString());
                    sRow = dgvOptionalItems.CurrentRow.Cells["OIProductGroup"].Value.ToString();
                    if (dCurrentcell == Math.Floor(dCurrentcell))
                    {
                        DialogResult DR = MessageBox.Show("If you delete this the complete product items will be deleted. /nDo you want to proceed?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                        if (DR == DialogResult.Yes)
                        {
                            if (cmbSelectQuoteType.Text == "Update Quote")
                            {
                                GLobalClass.iStatus = DAL.fnAddOptionalQuoteBOMProduct(Global.uDELETE, cmbQuotationNumber.Text, Convert.ToInt32(cmbRevisionNumber.Text),
                                                        dgvOptionalItems.CurrentRow.Cells["OIProductCode"].Value.ToString(), "", "", 0, 0, 0, 0, 0, 0, "", "", "");
                            }

                            for (int v = 0; v < dgvOptionalItems.Rows.Count; v++)
                            {
                                if (dgvOptionalItems[1, v].Value.ToString() == sRow)
                                {
                                    dgvOptionalItems.Rows.RemoveAt(v);
                                    v--;
                                }

                            }
                            foreach (DataGridViewRow dr in dgvOptionalItems.Rows)
                            {
                                if (Convert.ToDouble(dr.Cells["OISLNo"].Value.ToString()) > dCurrentcell)
                                {
                                    dr.Cells["OISLNo"].Value = (Convert.ToDouble(dr.Cells["OISLNo"].Value) - 1).ToString();
                                }
                            }
                            //  dtQuoteOptionalItems = dgvOptionalItems.DataSource as DataTable;
                            dtQuoteOptionalItems.AcceptChanges();
                            fnOptionalItemTotalCalculation();
                        }
                    }
                    else
                    {
                        if (cmbSelectQuoteType.Text == "Update Quote")
                        {
                            GLobalClass.iStatus = DAL.fnAddOptionalQuoteBOMProduct(Global.uDELETE, cmbQuotationNumber.Text, Convert.ToInt32(cmbRevisionNumber.Text),
                              dgvOptionalItems.CurrentRow.Cells["OIProductCode"].Value.ToString(), "", "", 0, 0, 0, 0, 0, 0, "", "", "");
                        }
                        dgvOptionalItems.Rows.RemoveAt(dgvOptionalItems.Rows.IndexOf(dgvOptionalItems.CurrentRow));

                        double dCheck = 0;
                        double dCurrentValue = Math.Truncate(dCurrentcell);
                        double dMinusValue;
                        double dCurrentMinusValue;
                        if (dCurrentValue == 0)
                        {
                            dCurrentValue = 1;
                        }
                        foreach (DataGridViewRow dr in dgvOptionalItems.Rows)
                        {
                            if (Convert.ToDouble(dr.Cells["OISLNo"].Value.ToString()) > dCurrentValue && Convert.ToDouble(dr.Cells["OISLNo"].Value.ToString()) < (dCurrentValue + 1))
                            {
                                dCheck++;
                            }
                        }

                        if (dCheck <= 9)
                        {
                            dMinusValue = 0.1;
                        }
                        else
                        {
                            dMinusValue = 0.01;
                        }
                        dCurrentMinusValue = dCurrentValue;

                        foreach (DataGridViewRow dr in dgvOptionalItems.Rows)
                        {
                            if (Convert.ToDouble(dr.Cells["OISLNo"].Value.ToString()) > dCurrentValue && Convert.ToDouble(dr.Cells["OISLNo"].Value.ToString()) < (dCurrentValue + 1))
                            {
                                dCurrentMinusValue += dMinusValue;
                                dr.Cells["OISLNo"].Value = (dCurrentMinusValue).ToString();
                            }
                        }
                        // dtQuoteOptionalItems = dgvOptionalItems.DataSource as DataTable;
                        dtQuoteOptionalItems.AcceptChanges();
                        fnOptionalItemTotalCalculation();
                    }
                }
            }
        }

        private void chkWUQuoteItems_CheckedChanged(object sender, EventArgs e)
        {
            if (chkWUQuoteItems.CheckState == CheckState.Checked)
            {
                chkWUOptionalItems.Checked = false;
                dgWriteUP.Visible = true;
                dgOIWriteUP.Visible = false;
            }
        }

        private void chkWUOptionalItems_CheckedChanged(object sender, EventArgs e)
        {
            if (chkWUOptionalItems.CheckState == CheckState.Checked)
            {
                chkWUQuoteItems.Checked = false;
                dgWriteUP.Visible = false;
                dgOIWriteUP.Visible = true;
            }
        }

        DataTable dtQuoteItemsLength = new DataTable();
        DataTable dtQuoteOIItemsLength = new DataTable();
        private void btnFinQuote_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            bTecnicalQuote = false;
            fnFileSavePath();
            if (cmbSelectQuoteType.Text == "New Quote" || cmbSelectQuoteType.Text == "Copy Quote")
            {
                if (chkBreakup.Checked)
                {
                    dtQuoteExcelExport = DAL.fnQuotationNumberLoadData(21, sQuotationNumber, "0").Tables[0];

                }
                else
                {
                    //  dtQuoteExcelExport = DAL.fnQuotationNumberLoadData(12, sQuotationNumber, "0").Tables[0];
                    //  dtQuoteOptionalExcelExport = DAL.fnQuotationNumberLoadData(13, sQuotationNumber, "0").Tables[0];

                    dtQuoteExcelExport = DAL.fnQuotationNumberLoadData(9, sQuotationNumber, "0").Tables[0];
                    //  dtQuoteOptionalExcelExport = DAL.fnQuotationNumberLoadData(10, sQuotationNumber, "0").Tables[0];
                }
                dtQuoteOptionalExcelExport = DAL.fnQuotationNumberLoadData(22, sQuotationNumber, "0").Tables[0];
                dtQuoteItemDetails = DAL.fnQuotationNumberLoadData(119, sQuotationNumber, "0").Tables[0];
                dtQuoteOptionalItemDetails = DAL.fnQuotationNumberLoadData(110, sQuotationNumber, "0").Tables[0];
                dtQuoteItemsLength = DAL.fnQuotationNumberLoadData(17, sQuotationNumber, "0").Tables[0];
                dtQuoteOIItemsLength = DAL.fnQuotationNumberLoadData(18, sQuotationNumber, "0").Tables[0];
                fnTechnicalQuote(sQuotationNumber, 0);
            }
            else
            {
                if (chkBreakup.Checked)
                {
                    dtQuoteExcelExport = DAL.fnQuotationNumberLoadData(21, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];

                }
                else
                {
                    dtQuoteExcelExport = DAL.fnQuotationNumberLoadData(9, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];
                }
                dtQuoteOptionalItemDetails = DAL.fnQuotationNumberLoadData(110, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];
                dtQuoteOptionalExcelExport = DAL.fnQuotationNumberLoadData(22, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];
                dtQuoteItemDetails = DAL.fnQuotationNumberLoadData(119, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];



                dtQuoteItemsLength = DAL.fnQuotationNumberLoadData(17, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];
                dtQuoteOIItemsLength = DAL.fnQuotationNumberLoadData(18, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];
                fnTechnicalQuote(cmbQuotationNumber.Text, Convert.ToInt32(cmbRevisionNumber.Text));
            }
            Cursor.Current = Cursors.Default;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (GLobalClass.fnMessageResult() == Global.sCLOSE_MESSAGE_RESULT_YES)
            {
                this.Hide();
                form.Show();
            }
        }

        private void txtOITotalPrice_TextChanged(object sender, EventArgs e)
        {
            txtOIJackup_TextChanged(sender, e);
        }

        bool bCategory = false;
        bool bMainCategory = false;


        public DataTable RemoveDuplicateRows(DataTable table, string DistinctColumn)
        {
            try
            {
                ArrayList UniqueRecords = new ArrayList();
                ArrayList DuplicateRecords = new ArrayList();


                foreach (DataRow dRow in table.Rows)
                {
                    if (UniqueRecords.Contains(dRow[DistinctColumn]))
                        DuplicateRecords.Add(dRow);
                    else
                        UniqueRecords.Add(dRow[DistinctColumn]);

                }
                // Remove dupliate rows from DataTable added to DuplicateRecords
                if (DuplicateRecords.Count > 0)
                {
                    foreach (DataRow dRow in DuplicateRecords)
                    {
                        table.Rows.Remove(dRow);
                    }
                }
                // Return the clean DataTable which contains unique records.
                return table;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return null;

            }
        }


        private void Datagridviewcolor(string ColumnName, DataGridView dgDataGridView)
        {
            foreach (DataGridViewRow dgr in dgDataGridView.Rows)
            {
                if ((dgr.Cells[ColumnName].Value.ToString()) == "")
                {
                    dgr.DefaultCellStyle.BackColor = Color.BurlyWood;
                }
            }
        }

        private void fnTotalCalucalation()
        {
            DataView view = dtQuote.DefaultView;
            view.Sort = "GroupID ASC";
            dtQuote = view.ToTable();
            DataTable dtExcelImport = new DataTable();
            dtExcelImport = dtQuote.Copy();
            double sQty;
            if (dtExcelImport.Rows.Count > 0)
            {
                Dictionary<string, double> dicSum = new Dictionary<string, double>();
                foreach (DataRow row in dtExcelImport.Rows)
                {
                    // if (!string.IsNullOrEmpty(row[3].ToString()))
                    {
                        string group = row["ProductGroup"].ToString();
                        double rate = Convert.ToDouble(row["Quantity"]) * Convert.ToDouble(row["BreakupTotal"]);
                        if (dicSum.ContainsKey(group))
                            dicSum[group] += rate;
                        else
                            dicSum.Add(group, rate);
                    }
                }
                DataTable UniqueRecords = RemoveDuplicateRows(dtExcelImport, "ProductGroup");

                foreach (var group in dicSum)
                {
                    foreach (DataRow FinalItems in dtExcelImport.Rows)
                    {
                        if (FinalItems["ProductGroup"].ToString() == group.Key.ToString())
                        {
                            sQty = group.Value;
                            FinalItems["TotalPrice"] = sQty;

                            break;
                        }
                    }
                }
            }

            foreach (DataRow row in dtQuote.Rows)
            {
                if (string.IsNullOrEmpty(row["ProductCode"].ToString()))
                {
                    foreach (DataRow FinalItems in dtExcelImport.Rows)
                    {
                        if (row["ProductGroup"].ToString() == FinalItems["ProductGroup"].ToString())
                        {
                            row["TotalPrice"] = FinalItems["TotalPrice"].ToString();
                            row["BreakupTotal"] = FinalItems["BreakupTotal"].ToString();
                            break;
                        }
                    }
                }
            }

            dgQuoteBOM.AutoGenerateColumns = false;
            dgQuoteBOM.DataSource = dtQuote;

            dgWriteUP.AutoGenerateColumns = false;
            dgWriteUP.DataSource = dtQuote;



            double sTotalAmount = 0;

            Datagridviewcolor("ProductCod", dgQuoteBOM);
            foreach (DataGridViewRow dgvr in dgQuoteBOM.Rows)
            {
                if (Convert.ToDouble(dgvr.Cells["UnitPrice"].Value) == 0)
                {
                    sTotalAmount += (Convert.ToDouble(dgvr.Cells["Quantity"].Value) * Convert.ToDouble(dgvr.Cells["BreakupTotal"].Value));
                }
                else
                {
                    sTotalAmount += (Convert.ToDouble(dgvr.Cells["Quantity"].Value) * Convert.ToDouble(dgvr.Cells["UnitPrice"].Value));
                }
            }

            int nRowIndex = dgQuoteBOM.Rows.Count;
            if (nRowIndex > 0)
                dgQuoteBOM.CurrentCell = dgQuoteBOM.Rows[nRowIndex - 1].Cells[0];

            txtTotalPrice.Text = Math.Round(sTotalAmount).ToString();
        }

        private void fnOptionalItemTotalCalculation()
        {
            DataView view = dtQuoteOptionalItems.DefaultView;
            view.Sort = "GroupID ASC";
            dtQuoteOptionalItems = view.ToTable();
            DataTable dtExcelImport = new DataTable();
            dtExcelImport = dtQuoteOptionalItems.Copy();
            double sQty;
            if (dtExcelImport.Rows.Count > 0)
            {
                Dictionary<string, double> dicSum = new Dictionary<string, double>();
                foreach (DataRow row in dtExcelImport.Rows)
                {
                    // if (!string.IsNullOrEmpty(row["Quantity"].ToString()) && !string.IsNullOrEmpty(row["BreakupTotal"].ToString()))
                    {
                        string group = row["ProductGroup"].ToString();
                        double rate = Convert.ToDouble(row["Quantity"]) * Convert.ToDouble(row["BreakupTotal"]);
                        if (dicSum.ContainsKey(group))
                            dicSum[group] += rate;
                        else
                            dicSum.Add(group, rate);
                    }
                }
                DataTable UniqueRecords = RemoveDuplicateRows(dtExcelImport, "ProductGroup");

                foreach (var group in dicSum)
                {
                    foreach (DataRow FinalItems in dtExcelImport.Rows)
                    {
                        if (FinalItems["ProductGroup"].ToString() == group.Key.ToString())
                        {
                            sQty = group.Value;
                            FinalItems["TotalPrice"] = sQty;

                            break;
                        }
                    }
                }
            }

            foreach (DataRow row in dtQuoteOptionalItems.Rows)
            {
                if (string.IsNullOrEmpty(row["ProductCode"].ToString()))
                {
                    foreach (DataRow FinalItems in dtExcelImport.Rows)
                    {
                        if (row["ProductGroup"].ToString() == FinalItems["ProductGroup"].ToString())
                        {
                            row["TotalPrice"] = FinalItems["TotalPrice"].ToString();
                            row["BreakupTotal"] = FinalItems["BreakupTotal"].ToString();
                            break;
                        }
                    }
                }
            }
            dgvOptionalItems.AutoGenerateColumns = false;
            
            dgvOptionalItems.DataSource = dtQuoteOptionalItems;

            dgOIWriteUP.AutoGenerateColumns = false;
            dgOIWriteUP.DataSource = dtQuoteOptionalItems;

            Datagridviewcolor("OIProductCode", dgvOptionalItems);
            double sTotalAmount = 0;
            foreach (DataGridViewRow dgvr in dgvOptionalItems.Rows)
            {
                // if (Convert.ToDouble(dgvr.Cells["OIBreakupTotal"].Value) == 0)
                if (Convert.ToDouble(dgvr.Cells["OIUnitPrice"].Value) == 0)
                {
                    sTotalAmount += (Convert.ToDouble(dgvr.Cells["OIQuantity"].Value) * Convert.ToDouble(dgvr.Cells["OIBreakupTotal"].Value));
                }
                else
                {
                    sTotalAmount += (Convert.ToDouble(dgvr.Cells["OIQuantity"].Value) * Convert.ToDouble(dgvr.Cells["OIUnitPrice"].Value));
                }
            }
            txtOITotalPrice.Text = Math.Round(sTotalAmount).ToString();


            int nRowIndex = dgvOptionalItems.Rows.Count;
            if (nRowIndex > 0)
                dgvOptionalItems.CurrentCell = dgvOptionalItems.Rows[nRowIndex - 1].Cells[0];
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }
        private static double dRowNumber = 0, dOIRowCount = 0; //

        //private static decimal dRowNumber = 0m;

        bool bAddFromProduct = false;
        private void tvQuoteProduct_NodeMouseDoubleClick(object sender, System.Windows.Forms.TreeNodeMouseClickEventArgs e)
        {
            txtName.Visible = false;
            txtCode.Visible = false;
            tvQuoteProduct.SelectedNode = e.Node;
            btnRename.Enabled = true;
            btnQuoteTreeSave.Enabled = false;
            bAddFromProduct = false;
            btnQuoteTreeSave.Text = "Save";
            bItemCheck = false;
            if (e.Node.StateImageIndex == 1)
            {
                btnAddFolder.Enabled = false;
                btnAddProduct.Enabled = false;
                DataTable QuoteBOMMaster = new DataTable();
                DataTable dtSalesProdcuts = new DataTable();
                sProdcutMasterName = tvQuoteProduct.SelectedNode.Name.Split(')');
                QuoteBOMMaster = DAL.fnQuotationBOMMaster(sProdcutMasterName[0]).Tables[0];

                if (QuoteBOMMaster.Rows.Count > 0)
                {
                    foreach (DataRow DR in QuoteBOMMaster.Rows)
                    {
                        if (!cmbProductCategory.Items.Contains(DR["ProductGroup"].ToString()))
                        {
                            cmbProductCategory.Items.Add(DR["ProductGroup"].ToString());
                        }
                    }
                    foreach (DataRow dr in QuoteBOMMaster.Rows)
                    {
                        if (!string.IsNullOrEmpty(dr["ProductCode"].ToString()))
                        {
                            dtSalesProdcuts = DAL.fnGetSalesTreeProductCode(dr["ProductCode"].ToString()).Tables[0];
                            if (dtSalesProdcuts.Rows.Count > 0)
                            {
                                sName[0] = dr["ProductCode"].ToString();
                                fnAddProducttoDataGridview(false);
                            }
                        }
                        else
                        {
                            bAddFromProduct = true;
                            cmbProductCategory.SelectedItem = dr["ProductGroup"].ToString();
                            bAddFromProduct = false;
                            if (chkaddmainitems.CheckState == CheckState.Checked)
                            {
                                if (dgQuoteBOM.Rows.Count == 0)
                                {
                                    bMainCategory = true;
                                }
                                foreach (DataGridViewRow DGVR in dgQuoteBOM.Rows)
                                {
                                    if (DGVR.Cells["ProductGroup"].Value.ToString().Equals(dr["ProductGroup"].ToString()))
                                    {
                                        bMainCategory = false;
                                        break;
                                    }
                                    else
                                    {
                                        bMainCategory = true;
                                    }
                                }
                                if (bMainCategory)
                                {
                                    fnAddProducttoDataGridview(false);
                                }
                            }
                            else if (chkOptionalItems.CheckState == CheckState.Checked)
                            {
                                if (dgvOptionalItems.Rows.Count == 0)
                                {
                                    bMainCategory = true;
                                }
                                foreach (DataGridViewRow DGVR in dgvOptionalItems.Rows)
                                {
                                    if (DGVR.Cells["OIProductGroup"].Value.ToString().Equals(dr["ProductGroup"].ToString()))
                                    {
                                        bMainCategory = false;
                                        break;
                                    }
                                    else
                                    {
                                        bMainCategory = true;
                                    }
                                }
                                if (bMainCategory)
                                {
                                    fnAddProducttoDataGridview(false);
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                bAddFromProduct = false;
            }
        }
        DataRow newRow;
        private static int iCopy = 99;
        private static int iCopy1 = 99;

        double dOldMainValue;
        double dNewMainValue;
        double dMiddleValue;
        int numbercheck;
        private void dgQuoteBOM_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Delete)   //delete particular row by pressing Delete key
            {
                dCurrentcell = Convert.ToDouble(dgQuoteBOM.CurrentRow.Cells["SLNO"].Value.ToString());
                numbercheck = (int)dCurrentcell;
                if (e.Control && e.KeyCode == Keys.X && iCopy == 99 && dCurrentcell != Math.Floor(dCurrentcell))
                {
                    DataRow SelectedRow = dtQuote.Rows[dgQuoteBOM.SelectedCells[0].OwningRow.Index];
                    newRow = dtQuote.NewRow();
                    newRow.ItemArray = SelectedRow.ItemArray;
                    dtQuote.Rows.Remove(SelectedRow);
                    iCopy = 1;
                }

                else if ((e.Control && e.KeyCode == Keys.X) && iCopy1 == 99 && dCurrentcell == numbercheck)
                {
                    dOldMainValue = Convert.ToDouble(dgQuoteBOM.CurrentRow.Cells["SLNO"].Value.ToString());
                    MessageBox.Show("Product '" + dgQuoteBOM.CurrentRow.Cells[3].Value.ToString() + "' selected to move.\n\nSelect the next product to move the items", "Success", 0, MessageBoxIcon.Information);
                    iCopy1 = 1;
                }
                else if ((e.Control && e.KeyCode == Keys.V) && iCopy1 == 1 && dCurrentcell == numbercheck)
                {
                    dNewMainValue = Convert.ToDouble(dgQuoteBOM.CurrentRow.Cells["SLNO"].Value.ToString());
                    iCopy1 = 99;
                    int icount = 0;
                    double icount1 = 0.1;
                    dMiddleValue = 60;
                    foreach (DataRow dr in dtQuote.Rows)
                    {
                        if (Convert.ToDouble(dr[0].ToString()) >= dOldMainValue && Convert.ToDouble(dr[0].ToString()) < (1 + dOldMainValue))
                        {
                            if (icount == 0)
                            {
                                dr[0] = dMiddleValue;
                            }
                            else
                            {
                                dr[0] = (dMiddleValue + icount1);
                                icount1 += 0.1;
                            }
                            icount++;

                        }
                    }
                    icount = 0;
                    icount1 = 0.1;
                    dtQuote.AcceptChanges();

                    foreach (DataRow dr in dtQuote.Rows)
                    {
                        if (Convert.ToDouble(dr[0].ToString()) >= dNewMainValue && Convert.ToDouble(dr[0].ToString()) < (1 + dNewMainValue))
                        {
                            if (icount == 0)
                            {
                                dr[0] = dOldMainValue;
                            }
                            else
                            {
                                dr[0] = (dOldMainValue + icount1);
                                icount1 += 0.1;
                            }
                            icount++;

                        }
                    }
                    dtQuote.AcceptChanges();

                    icount = 0;
                    icount1 = 0.1;

                    foreach (DataRow dr in dtQuote.Rows)
                    {
                        if (Convert.ToDouble(dr[0].ToString()) >= dMiddleValue && Convert.ToDouble(dr[0].ToString()) < (1 + dMiddleValue))
                        {
                            if (icount == 0)
                            {
                                dr[0] = dNewMainValue;
                            }
                            else
                            {
                                dr[0] = (dNewMainValue + icount1);
                                icount1 += 0.1;
                            }
                            icount++;

                        }
                    }

                    dtQuote.AcceptChanges();
                    fnTotalCalucalation();
                }
                else if (e.Control && e.KeyCode == Keys.V && dCurrentcell != Math.Floor(dCurrentcell))
                {
                    if (iCopy == 1)
                    {
                        dtQuote.Rows.InsertAt(newRow, (dgQuoteBOM.SelectedCells[0].OwningRow.Index));
                        iCopy = 99;

                        double dCheck = 0;
                        double dCurrentValue = Math.Truncate(dCurrentcell);
                        double dMinusValue;
                        double dCurrentMinusValue;
                        if (dCurrentValue == 0)
                        {
                            dCurrentValue = 1;
                        }
                        foreach (DataGridViewRow dr in dgQuoteBOM.Rows)
                        {
                            if (Convert.ToDouble(dr.Cells["SLNO"].Value.ToString()) > dCurrentValue && Convert.ToDouble(dr.Cells["SLNO"].Value.ToString()) < (dCurrentValue + 1))
                            {
                                dCheck++;
                            }
                        }

                        if (dCheck <= 9)
                        {
                            dMinusValue = 0.1;
                        }
                        else
                        {
                            dMinusValue = 0.01;
                        }
                        dCurrentMinusValue = dCurrentValue;

                        foreach (DataGridViewRow dr in dgQuoteBOM.Rows)
                        {
                            if (Convert.ToDouble(dr.Cells["SLNO"].Value.ToString()) > dCurrentValue && Convert.ToDouble(dr.Cells["SLNO"].Value.ToString()) < (dCurrentValue + 1))
                            {
                                dCurrentMinusValue += dMinusValue;
                                dr.Cells["SLNO"].Value = (dCurrentMinusValue).ToString();
                            }
                        }
                        //   dtQuote = dgQuoteBOM.DataSource as DataTable;
                        dtQuote.AcceptChanges();
                    }
                }
                e.Handled = true;
            }
        }

        string sTreeChildName = string.Empty;
        int NodeID;
        int PasteParentID;
        int PasteImageIndex;
        DataTable dtProductName = new DataTable();
        DataTable dtChildProdcut = new DataTable();
        string[] sProducutID = new string[6];
        string[] sFloderProducutID = new string[6];
        private void tvQuoteProduct_KeyUp(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete selected row from the list
            {
                if (Convert.ToBoolean(LoginForm.GetUserDetails[26]))
                {
                    if (tvQuoteProduct.SelectedNode.Name != "All Product" && (tvQuoteProduct.SelectedNode.StateImageIndex >= 1))
                    {
                        DialogResult DR = MessageBox.Show("Do you want to delete the selected product ' " + tvQuoteProduct.SelectedNode.Name + " '", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                        if (DR == DialogResult.Yes)
                        {
                            //string[] sProducutID = new string[6];
                            sProducutID = tvQuoteProduct.SelectedNode.Name.Trim().Split(')');
                            if (sProducutID.Length >= 2)
                            {
                                GLobalClass.iSuccess = DAL.fnAddQuoteProduct(Global.uDELETE, Convert.ToInt32(sProducutID[0]), 0, txtCode.Text, txtName.Text, 2, LoginForm.GetUserDetails[2], LoginForm.GetUserDetails[2]);
                                GLobalClass.iSuccess = DAL.fnAddQuoteProduct(61, Convert.ToInt32(sProducutID[0]), 0, txtCode.Text, txtName.Text, 2, LoginForm.GetUserDetails[2], LoginForm.GetUserDetails[2]);
                            }
                            if (GLobalClass.iSuccess > 0)
                                tvQuoteProduct.SelectedNode.Remove();
                        }
                    }
                    else
                    {
                        MessageBox.Show("You can't delete this folder ", "Warning", 0, MessageBoxIcon.Warning);
                    }
                }
            }

            else if (e.Control && e.KeyCode == Keys.X)
            {
                if (Convert.ToBoolean(LoginForm.GetUserDetails[26]))
                {
                    if (tvQuoteProduct.SelectedNode.Name != "1)All Product")
                    {
                        sProducutID = tvQuoteProduct.SelectedNode.Name.Trim().Split(')');
                        //sFloderProducutID = tvQuoteProduct.SelectedNode.Parent.Name.Trim().Split(')');
                        if (tvQuoteProduct.SelectedNode.StateImageIndex != 0)
                        {
                            sTreeChildName = tvQuoteProduct.SelectedNode.Name;
                            PasteImageIndex = tvQuoteProduct.SelectedNode.StateImageIndex;
                            // dtProductName = DAL.fnGetLastNodeId(tvProduct.SelectedNode.Parent.Name).Tables["LastNodeId"];
                            if (sProducutID.Length > 0)
                            {
                                NodeID = Convert.ToInt32(sProducutID[0]);
                                tvQuoteProduct.SelectedNode.Remove();
                            }
                            else
                            {
                                NodeID = 0;
                            }
                        }
                        else
                        {
                            // sProducutID = tvQuoteProduct.SelectedNode.Parent.Name.Trim().Split(')');
                            sTreeChildName = tvQuoteProduct.SelectedNode.Name;
                            PasteImageIndex = tvQuoteProduct.SelectedNode.StateImageIndex;
                            NodeID = Convert.ToInt32(sProducutID[0]);
                            tvQuoteProduct.SelectedNode.Remove();
                        }
                    }
                }
            }
            else if (e.Control && e.KeyCode == Keys.V)
            {
                if (Convert.ToBoolean(LoginForm.GetUserDetails[26]))
                {
                    if (!string.IsNullOrEmpty(sTreeChildName))
                    {
                        sProducutID = tvQuoteProduct.SelectedNode.Name.Trim().Split(')');

                        if (sProducutID.Length > 0)
                        {
                            // dtProductName = DAL.fnGetPasteProductTreeNode(1, Convert.ToInt32(sProducutID[0])).Tables[0];
                            PasteParentID = Convert.ToInt32(sProducutID[0]);
                            GLobalClass.iSuccess = DAL.fnPasteProduct(Global.uINSERT, PasteParentID, NodeID);
                            TreeNode TN = new TreeNode();
                            tvQuoteProduct.BeginUpdate();
                            TN.Name = sTreeChildName;
                            TN.Text = sTreeChildName;
                            TN.ForeColor = Color.Black;
                            TN.StateImageIndex = PasteImageIndex;
                            tvQuoteProduct.SelectedNode.Nodes.Add(TN);
                            tvQuoteProduct.EndUpdate();
                            sTreeChildName = "";
                        }
                        else
                        {
                            MessageBox.Show("Selected a folder to paste", "Error", 0, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Selected a Product to be copied", "Error", 0, MessageBoxIcon.Error);
                    }
                }
            }
        }
        public DataGridView.HitTestInfo hitTestInfo { get; set; }
        private void dgWriteUP_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                hitTestInfo = dgWriteUP.HitTest(e.X, e.Y);
                if (hitTestInfo.Type == DataGridViewHitTestType.Cell)
                    dgWriteUP.BeginEdit(true);
                else
                    dgWriteUP.EndEdit();
            }
        }

        private void chkConcessionGst_CheckedChanged(object sender, EventArgs e)
        {
            if (chkConcessionGst.CheckState == CheckState.Checked)
            {
                if (chkintrastate.CheckState == CheckState.Checked)
                {
                    txtIGSTPer.Text = "2.5";
                    txtSgstPer.Text = "2.5";
                }
                else
                {
                    txtIGSTPer.Text = "5";
                }
            }
            else
            {
                if (chkintrastate.CheckState == CheckState.Checked)
                {
                    txtSgstPer.Text = "9";
                    txtIGSTPer.Text = "9";
                }
                else
                {
                    txtIGSTPer.Text = "18";
                }
            }
            fnTotalPrice();
            //txtInsatallationCommision_TextChanged(sender, e);
        }

        private void cmbProductCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!bAddFromProduct)
            {
                if (cmbProductCategory.SelectedIndex >= 0)
                {
                    if (chkaddmainitems.Checked == true)
                    {
                        if (dgQuoteBOM.Rows.Count == 0)
                        {
                            bMainCategory = true;
                        }
                        foreach (DataGridViewRow DGVR in dgQuoteBOM.Rows)
                        {
                            if (DGVR.Cells["ProductGroup"].Value.ToString().Equals(cmbProductCategory.Text))
                            {
                                bMainCategory = false;
                                break;
                            }
                            else
                            {
                                bMainCategory = true;
                            }
                        }
                        if (bMainCategory)
                        {
                            fnAddProducttoDataGridview(true);
                        }
                    }
                    else if (chkOptionalItems.Checked == true)
                    {
                        if (dgvOptionalItems.Rows.Count == 0)
                        {
                            bMainCategory = true;
                        }
                        foreach (DataGridViewRow DGVR in dgvOptionalItems.Rows)
                        {
                            if (DGVR.Cells["OIProductGroup"].Value.ToString().Equals(cmbProductCategory.Text))
                            {
                                bMainCategory = false;
                                break;
                            }
                            else
                            {
                                bMainCategory = true;
                            }
                        }
                        if (bMainCategory)
                        {
                            fnAddProducttoDataGridview(true);
                        }
                    }
                }
            }
        }

        private void dgQuoteBOM_CellEnter(object sender, System.Windows.Forms.DataGridViewCellEventArgs e)
        {
            if ((e.ColumnIndex == 9 || e.ColumnIndex == 6 || e.ColumnIndex == 3) && string.IsNullOrEmpty(dgQuoteBOM.CurrentRow.Cells[2].Value.ToString()))
            {
                dgQuoteBOM.Columns[e.ColumnIndex].ReadOnly = true;
            }
            else if ((e.ColumnIndex == 9 || e.ColumnIndex == 6 || e.ColumnIndex == 3) && !string.IsNullOrEmpty(dgQuoteBOM.CurrentRow.Cells[2].Value.ToString()))
            {
                dgQuoteBOM.Columns[e.ColumnIndex].ReadOnly = false;
            }
        }

        private void dgvOptionalItems_CellEnter(object sender, System.Windows.Forms.DataGridViewCellEventArgs e)
        {
            if ((e.ColumnIndex == 9 || e.ColumnIndex == 6 || e.ColumnIndex == 3) && string.IsNullOrEmpty(dgvOptionalItems.CurrentRow.Cells[2].Value.ToString()))
            {
                dgvOptionalItems.Columns[e.ColumnIndex].ReadOnly = true;
            }
            else if ((e.ColumnIndex == 9 || e.ColumnIndex == 6 || e.ColumnIndex == 3) && !string.IsNullOrEmpty(dgvOptionalItems.CurrentRow.Cells[2].Value.ToString()))
            {
                dgvOptionalItems.Columns[e.ColumnIndex].ReadOnly = false;
            }
        }

        private void dgWriteUP_CellEnter(object sender, System.Windows.Forms.DataGridViewCellEventArgs e)
        {
            if ((e.ColumnIndex == 2) && dgWriteUP.CurrentRow.Cells[3].Value.ToString() == "0")
            {
                dgWriteUP.Columns[e.ColumnIndex].ReadOnly = true;
            }
            else if ((e.ColumnIndex == 2) && dgWriteUP.CurrentRow.Cells[3].Value.ToString() != "0")
            {
                dgWriteUP.Columns[e.ColumnIndex].ReadOnly = false;
            }
        }

        private void dgOIWriteUP_CellEnter(object sender, System.Windows.Forms.DataGridViewCellEventArgs e)
        {
            if ((e.ColumnIndex == 2) && dgOIWriteUP.CurrentRow.Cells[3].Value.ToString() == "0")
            {
                dgOIWriteUP.Columns[e.ColumnIndex].ReadOnly = true;
            }
            else if ((e.ColumnIndex == 2) && dgOIWriteUP.CurrentRow.Cells[3].Value.ToString() != "0")
            {
                dgOIWriteUP.Columns[e.ColumnIndex].ReadOnly = false;
            }
        }

        private void txtQuoteValidity_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            fnWeekKeyPressOnly(sender, e);
        }

        private void txtQuoteWarranty_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            fnWeekKeyPressOnly(sender, e);
        }

        private void txtLeadTime_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            fnWeekKeyPressOnly(sender, e);
        }

        private void cmbCompetetion_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbCompetetion.Text == "Others")
            {
                txtSpecifyOthers.Enabled = true;
                txtCompetation.ResetText();
            }
            else
            {
                if (!string.IsNullOrEmpty(txtCompetation.Text))
                {
                    txtCompetation.Text = txtCompetation.Text + ", " + cmbCompetetion.Text;
                }
                else
                {
                    txtCompetation.Text = cmbCompetetion.Text;
                }
                txtSpecifyOthers.Enabled = false;
            }
        }

        private void cmbWinLose_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbWinLose.SelectedIndex == 0)
            {
                txtWonReason.Enabled = true;
                txtLostReason.Enabled = false;
            }
            else if (cmbWinLose.SelectedIndex == 1)
            {
                txtWonReason.Enabled = false;
                txtLostReason.Enabled = true;
            }
        }

        private void txtExpectedValueUSD_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            fnNumberKeyPressOnly(sender, e);
        }

        private void btnGotoAddProducts_Click(object sender, EventArgs e)
        {
            if (bRequiredDate && cmbLabtype.SelectedIndex >= 0 && cmbBusinessector.SelectedIndex >= 0 && cmbprimaryind.SelectedIndex >= 0 &&
                cmbprimarymaterial.SelectedIndex >= 0 && !string.IsNullOrEmpty(cmbprimarymtrldetail.Text) && cmbApplication.SelectedIndex >= 0 &&
                cmbTestEnvironment.SelectedIndex >= 0 && cmbStatus.SelectedIndex >= 0 && cmbStage.SelectedIndex >= 0 && cmbtypeofcustomer.SelectedIndex >= 0
                && !string.IsNullOrEmpty(txtExpectedValueUSD.Text) && cmbProbabality.SelectedIndex >= 0)
            {
                if (cmbSelectQuoteType.Text == "Update Quote" || cmbSelectQuoteType.Text == "Revise Quote" || cmbSelectQuoteType.Text == "Copy Quote")
                {
                    tabControl1.SelectTab(2);
                    Datagridviewcolor("ProductCod", dgQuoteBOM);
                    Datagridviewcolor("OIProductCode", dgvOptionalItems);

                    foreach (DataRow DR in dtQuote.Rows)
                    {
                        if (!cmbProductCategory.Items.Contains(DR["ProductGroup"].ToString()))
                        {
                            cmbProductCategory.Items.Add(DR["ProductGroup"].ToString());
                        }
                    }

                    foreach (DataRow DR in dtQuoteOptionalItems.Rows)
                    {
                        if (!cmbProductCategory.Items.Contains(DR["ProductGroup"].ToString()))
                        {
                            cmbProductCategory.Items.Add(DR["ProductGroup"].ToString());
                        }
                    }
                }
                else
                {
                    tabControl1.SelectTab(2);
                    if (dgQuoteBOM.Rows.Count == 0)
                    {
                        dtQuote = DAL.fnQuoteBOM(0, -1).Tables[0];
                    }
                    if (dgvOptionalItems.Rows.Count == 0)
                    {
                        dtQuoteOptionalItems = DAL.fnQuoteBOM(1, -1).Tables[0];
                    }
                }
            }
            else
            {
                if (cmbLabtype.SelectedIndex < 0)
                {
                    MessageBox.Show("Please select Lab Type", "Error", 0, MessageBoxIcon.Error);
                    cmbLabtype.DroppedDown = true;
                }
                else if (cmbBusinessector.SelectedIndex < 0)
                {
                    MessageBox.Show("Please select Business Sector", "Error", 0, MessageBoxIcon.Error);
                    cmbBusinessector.DroppedDown = true;
                }
                else if (cmbprimaryind.SelectedIndex < 0)
                {
                    MessageBox.Show("Please select Primary Industry", "Error", 0, MessageBoxIcon.Error);
                    cmbprimaryind.DroppedDown = true;
                }
                else if (cmbprimarymaterial.SelectedIndex < 0)
                {
                    MessageBox.Show("Please select Primary Material", "Error", 0, MessageBoxIcon.Error);
                    cmbprimarymaterial.DroppedDown = true;
                }
                else if (string.IsNullOrEmpty(cmbprimarymtrldetail.Text))
                {
                    MessageBox.Show("Enter Primary Material Details", "Error", 0, MessageBoxIcon.Error);
                    cmbprimarymtrldetail.Focus();
                }
                else if (cmbApplication.SelectedIndex < 0)
                {
                    MessageBox.Show("Select Primary Application", "Error", 0, MessageBoxIcon.Error);
                    cmbApplication.DroppedDown = true;
                }
                else if (cmbTestEnvironment.SelectedIndex < 0)
                {
                    MessageBox.Show("Select Test Environment", "Error", 0, MessageBoxIcon.Error);
                    cmbTestEnvironment.DroppedDown = true;
                }
                else if (cmbStatus.SelectedIndex < 0)
                {
                    MessageBox.Show("Select Status", "Error", 0, MessageBoxIcon.Error);
                    cmbStatus.DroppedDown = true;
                }
                else if (cmbStage.SelectedIndex < 0)
                {
                    MessageBox.Show("Select Stage", "Error", 0, MessageBoxIcon.Error);
                    cmbStage.DroppedDown = true;
                }
                else if (cmbtypeofcustomer.SelectedIndex < 0)
                {
                    MessageBox.Show("Select Type of Customer", "Error", 0, MessageBoxIcon.Error);
                    cmbtypeofcustomer.DroppedDown = true;
                }
                else if (string.IsNullOrEmpty(txtExpectedValueUSD.Text))
                {
                    MessageBox.Show("Enter Expected Order Value", "Error", 0, MessageBoxIcon.Error);
                    txtExpectedValueUSD.Focus();
                }
                else if (cmbProbabality.SelectedIndex < 0)
                {
                    MessageBox.Show("Select Probabality", "Error", 0, MessageBoxIcon.Error);
                    cmbProbabality.DroppedDown = true;
                }
                else if (!bRequiredDate)
                {
                    MessageBox.Show("Select Expected Order Placement date", "Error", 0, MessageBoxIcon.Error);
                    dtpExpectedOrderPlacementdate.Focus();
                }
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(0);
        }

        private void cmbLabtype_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbBusinessector_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbprimaryind_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbprimarymaterial_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbApplication_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        bool bPreview = false;

        private void btnPreview_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            fnFileSavePath();
            if (cmbSelectQuoteType.Text == "New Quote")
            {
                if (dtQuote.Rows.Count > 0)
                {
                    dtQuoteExcelExport = dtQuote.Copy();
                    dtQuoteExcelExport.Columns.RemoveAt(0);
                    dtQuoteExcelExport.Columns[0].ColumnName = "Model Number";

                    dtQuoteExcelExport.Columns.RemoveAt(2);
                    dtQuoteExcelExport.Columns[1].ColumnName = "Description";
                    dtQuoteExcelExport.Columns.RemoveAt(2);
                    dtQuoteExcelExport.Columns.RemoveAt(3);
                    dtQuoteExcelExport.Columns.RemoveAt(5);
                    dtQuoteExcelExport.Columns.RemoveAt(4);
                    dtQuoteExcelExport.Columns.RemoveAt(4);
                    dtQuoteExcelExport.Columns[3].ColumnName = "UnitPrice";
                    // dtQuoteExcelExport.Columns["UnitPrice"].SetOrdinal(3);
                    dtQuoteExcelExport.AcceptChanges();
                    if (chkBreakup.Checked)
                    {
                        foreach (DataRow dr in dtQuoteExcelExport.Rows)
                        {
                            if (Convert.ToDouble(dr[2].ToString()) > 0)
                            {
                                dr[3] = DBNull.Value;
                            }
                            else if (Convert.ToDouble(dr[2].ToString()) == 0)
                            {
                                dr[0] = dr[1];
                                dr[1] = DBNull.Value;
                                dr[2] = DBNull.Value;
                                dr[3] = DBNull.Value;
                            }
                        }
                    }
                    else
                    {
                        foreach (DataRow dr in dtQuoteExcelExport.Rows)
                        {
                            if (Convert.ToDouble(dr[2].ToString()) == 0)
                            {
                                dr[0] = dr[1];
                                dr[1] = DBNull.Value;
                                dr[2] = DBNull.Value;
                                dr[3] = DBNull.Value;
                            }
                        }
                    }
                    dtQuoteOptionalExcelExport = dtQuoteOptionalItems.Copy();
                    if (dtQuoteOptionalExcelExport.Rows.Count > 0)
                    {
                        dtQuoteOptionalExcelExport.Columns.RemoveAt(0);
                        dtQuoteOptionalExcelExport.Columns[0].ColumnName = "Model Number";

                        dtQuoteOptionalExcelExport.Columns.RemoveAt(2);
                        dtQuoteOptionalExcelExport.Columns[1].ColumnName = "Description";
                        dtQuoteOptionalExcelExport.Columns.RemoveAt(2);
                        dtQuoteOptionalExcelExport.Columns.RemoveAt(3);
                        dtQuoteOptionalExcelExport.Columns.RemoveAt(4);
                        dtQuoteOptionalExcelExport.Columns.RemoveAt(4);
                        dtQuoteOptionalExcelExport.Columns.RemoveAt(4);
                        // dtQuoteOptionalExcelExport.Columns[2].ColumnName = "Qty";
                        dtQuoteOptionalExcelExport.Columns[3].ColumnName = "UnitPrice";
                        dtQuoteOptionalExcelExport.AcceptChanges();
                        if (chkBreakup.Checked)
                        {
                            foreach (DataRow dr in dtQuoteOptionalExcelExport.Rows)
                            {
                                if (Convert.ToDouble(dr[2].ToString()) > 0)
                                {
                                    dr[3] = DBNull.Value;
                                }
                                else if (Convert.ToDouble(dr[2].ToString()) == 0)
                                {
                                    dr[0] = dr[1];
                                    dr[1] = DBNull.Value;
                                    dr[2] = DBNull.Value;
                                    dr[3] = DBNull.Value;
                                }
                            }
                        }
                        else
                        {
                            foreach (DataRow dr in dtQuoteOptionalExcelExport.Rows)
                            {
                                if (Convert.ToDouble(dr[2].ToString()) == 0)
                                {
                                    dr[0] = dr[1];
                                    dr[1] = DBNull.Value;
                                    dr[2] = DBNull.Value;
                                    dr[3] = DBNull.Value;
                                }
                            }
                        }

                        dtQuoteOptionalItemDetails = dtQuoteOptionalExcelExport.Copy();
                    }

                    dtQuoteItemsLength = dtQuote.Copy();
                    if (dtQuoteItemsLength.Rows.Count > 0)
                    {
                        dtQuoteItemsLength.Columns.RemoveAt(0);
                        dtQuoteItemsLength.Columns.RemoveAt(3);
                        dtQuoteItemsLength.Columns.RemoveAt(3);
                        dtQuoteItemsLength.Columns.RemoveAt(3);
                        dtQuoteItemsLength.Columns.RemoveAt(3);
                        dtQuoteItemsLength.Columns.RemoveAt(3);
                        dtQuoteItemsLength.Columns.RemoveAt(3);
                        dtQuoteItemsLength.Columns.RemoveAt(3);
                        dtQuoteItemsLength.AcceptChanges();
                        dtQuoteItemDetails = dtQuoteItemsLength.Copy();

                        foreach (DataRow dr in dtQuoteItemDetails.Rows)
                        {
                            if ((dr[2].ToString()) == dr[1].ToString())
                            {
                                dr[0] = dr[1];
                                dr[2] = DBNull.Value;
                            }
                        }

                        dtQuoteItemDetails.Columns.RemoveAt(1);
                        dtQuoteItemDetails.AcceptChanges();
                    }
                    dtQuoteOIItemsLength = dtQuoteOptionalItems.Copy();
                    if (dtQuoteOIItemsLength.Rows.Count > 0)
                    {
                        dtQuoteOIItemsLength.Columns.RemoveAt(0);
                        dtQuoteOIItemsLength.Columns.RemoveAt(3);
                        dtQuoteOIItemsLength.Columns.RemoveAt(3);
                        dtQuoteOIItemsLength.Columns.RemoveAt(3);
                        dtQuoteOIItemsLength.Columns.RemoveAt(3);
                        dtQuoteOIItemsLength.Columns.RemoveAt(3);
                        dtQuoteOIItemsLength.Columns.RemoveAt(3);
                        dtQuoteOIItemsLength.Columns.RemoveAt(3);
                        dtQuoteOIItemsLength.AcceptChanges();
                        dtQuoteOptionalExcelExport = dtQuoteOIItemsLength.Copy();
                        foreach (DataRow dr in dtQuoteOptionalExcelExport.Rows)
                        {
                            if ((dr[2].ToString()) == dr[1].ToString())
                            {
                                dr[0] = dr[1];
                                dr[2] = DBNull.Value;
                            }
                        }

                        dtQuoteOptionalExcelExport.Columns.RemoveAt(1);
                        dtQuoteOptionalExcelExport.AcceptChanges();
                    }

                    bPreview = true;
                    fnTechnicalQuote("Preview", 0);
                    bPreview = false;

                    Cursor.Current = Cursors.Default;
                }
                else
                {
                    MessageBox.Show("Select the products to preview the quote ", "Error", 0, MessageBoxIcon.Error);
                }
            }
            else if (cmbSelectQuoteType.Text == "Copy Quote")
            {
                if (dtQuote.Rows.Count > 0)
                {
                    dtQuoteExcelExport = dtQuote.Copy();
                    dtQuoteExcelExport.Columns.RemoveAt(0);
                    dtQuoteExcelExport.Columns[0].ColumnName = "Model Number";
                    dtQuoteExcelExport.Columns.RemoveAt(3);
                    dtQuoteExcelExport.Columns[1].ColumnName = "Description";
                    dtQuoteExcelExport.Columns.RemoveAt(0);
                    dtQuoteExcelExport.Columns.RemoveAt(2);
                    dtQuoteExcelExport.Columns.RemoveAt(3);
                    dtQuoteExcelExport.Columns.RemoveAt(3);
                    dtQuoteExcelExport.Columns[3].ColumnName = "UnitPrice";
                    dtQuoteExcelExport.Columns["UnitPrice"].SetOrdinal(3);
                    dtQuoteExcelExport.Columns.RemoveAt(4);
                    dtQuoteExcelExport.Columns.RemoveAt(4);
                    dtQuoteExcelExport.AcceptChanges();
                    if (chkBreakup.Checked)
                    {
                        foreach (DataRow dr in dtQuoteExcelExport.Rows)
                        {
                            if (Convert.ToDouble(dr[2].ToString()) > 0)
                            {
                                dr[3] = DBNull.Value;
                            }
                            else if (Convert.ToDouble(dr[2].ToString()) == 0)
                            {
                                dr[0] = dr[1];
                                dr[1] = DBNull.Value;
                                dr[2] = DBNull.Value;
                                dr[3] = DBNull.Value;

                            }
                        }
                    }
                    else
                    {
                        foreach (DataRow dr in dtQuoteExcelExport.Rows)
                        {
                            if (Convert.ToDouble(dr[2].ToString()) == 0)
                            {
                                dr[0] = dr[1];
                                dr[1] = DBNull.Value;
                                dr[2] = DBNull.Value;
                                dr[3] = DBNull.Value;
                            }
                        }
                    }
                    dtQuoteOptionalExcelExport = dtQuoteOptionalItems.Copy();

                    if (dtQuoteOptionalExcelExport.Rows.Count > 0)
                    {
                        dtQuoteOptionalExcelExport.Columns.RemoveAt(0);
                        dtQuoteOptionalExcelExport.Columns[0].ColumnName = "Model Number";

                        dtQuoteOptionalExcelExport.Columns.RemoveAt(3);
                        dtQuoteOptionalExcelExport.Columns[1].ColumnName = "Description";
                        dtQuoteOptionalExcelExport.Columns.RemoveAt(0);
                        dtQuoteOptionalExcelExport.Columns.RemoveAt(2);
                        dtQuoteOptionalExcelExport.Columns.RemoveAt(3);
                        dtQuoteOptionalExcelExport.Columns.RemoveAt(3);
                        dtQuoteOptionalExcelExport.Columns[3].ColumnName = "UnitPrice";
                        dtQuoteOptionalExcelExport.Columns["UnitPrice"].SetOrdinal(3);
                        dtQuoteOptionalExcelExport.Columns.RemoveAt(4);
                        dtQuoteOptionalExcelExport.Columns.RemoveAt(4);
                        dtQuoteOptionalExcelExport.AcceptChanges();
                        if (chkBreakup.Checked)
                        {
                            foreach (DataRow dr in dtQuoteOptionalExcelExport.Rows)
                            {
                                if (Convert.ToDouble(dr[2].ToString()) > 0)
                                {
                                    dr[3] = DBNull.Value;
                                }
                                else if (Convert.ToDouble(dr[2].ToString()) == 0)
                                {
                                    dr[0] = dr[1];
                                    dr[1] = DBNull.Value;
                                    dr[2] = DBNull.Value;
                                    dr[3] = DBNull.Value;
                                }
                            }
                        }
                        else
                        {
                            foreach (DataRow dr in dtQuoteOptionalExcelExport.Rows)
                            {
                                if (Convert.ToDouble(dr[2].ToString()) == 0)
                                {
                                    dr[0] = dr[1];
                                    dr[1] = DBNull.Value;
                                    dr[2] = DBNull.Value;
                                    dr[3] = DBNull.Value;
                                }
                            }
                        }

                        dtQuoteOptionalItemDetails = dtQuoteOptionalExcelExport.Copy();
                    }

                    dtQuoteItemsLength = dtQuote.Copy();
                    if (dtQuoteItemsLength.Rows.Count > 0)
                    {
                        dtQuoteItemsLength.Columns.RemoveAt(0);
                        dtQuoteItemsLength.Columns.RemoveAt(0);
                        dtQuoteItemsLength.Columns.RemoveAt(3);
                        dtQuoteItemsLength.Columns.RemoveAt(3);
                        dtQuoteItemsLength.Columns.RemoveAt(3);
                        dtQuoteItemsLength.Columns.RemoveAt(3);
                        dtQuoteItemsLength.Columns.RemoveAt(3);
                        dtQuoteItemsLength.Columns.RemoveAt(3);
                        dtQuoteItemsLength.Columns.RemoveAt(3);
                        dtQuoteItemsLength.AcceptChanges();
                        dtQuoteItemDetails = dtQuoteItemsLength.Copy();

                        foreach (DataRow dr in dtQuoteItemDetails.Rows)
                        {
                            if ((dr[2].ToString()) == dr[1].ToString())
                            {
                                dr[0] = dr[1];
                                dr[2] = DBNull.Value;
                            }
                        }
                        dtQuoteItemDetails.Columns.RemoveAt(1);
                        dtQuoteItemDetails.AcceptChanges();
                    }
                    dtQuoteOIItemsLength = dtQuoteOptionalItems.Copy();

                    if (dtQuoteOIItemsLength.Rows.Count > 0)
                    {
                        dtQuoteOIItemsLength.Columns.RemoveAt(0);
                        dtQuoteOIItemsLength.Columns.RemoveAt(0);
                        dtQuoteOIItemsLength.Columns.RemoveAt(3);
                        dtQuoteOIItemsLength.Columns.RemoveAt(3);
                        dtQuoteOIItemsLength.Columns.RemoveAt(3);
                        dtQuoteOIItemsLength.Columns.RemoveAt(3);
                        dtQuoteOIItemsLength.Columns.RemoveAt(3);
                        dtQuoteOIItemsLength.Columns.RemoveAt(3);
                        dtQuoteOIItemsLength.Columns.RemoveAt(3);
                        dtQuoteOIItemsLength.AcceptChanges();
                        dtQuoteOptionalExcelExport = dtQuoteOIItemsLength.Copy();
                        foreach (DataRow dr in dtQuoteOptionalExcelExport.Rows)
                        {
                            if ((dr[2].ToString()) == dr[1].ToString())
                            {
                                dr[0] = dr[1];
                                dr[2] = DBNull.Value;
                            }
                        }

                        dtQuoteOptionalExcelExport.Columns.RemoveAt(1);
                        dtQuoteOptionalExcelExport.AcceptChanges();
                    }
                    bPreview = true;
                    fnTechnicalQuote("Preview", 0);
                    bPreview = false;

                    Cursor.Current = Cursors.Default;
                }
                else
                {
                    MessageBox.Show("Select the products to preview the quote ", "Error", 0, MessageBoxIcon.Error);
                }
            }
        }

        private void btnViewQuotes_Click(object sender, EventArgs e)
        {
            sQuote1No = "1";
            QVI.fnQuoteform = sQuote1No.ToString();
            QVI.ShowDialog();
            if (fnQuote1no != null)
            {
                cmbQuotationNumber.SelectedItem = sQuote1No;
                cmbRevisionNumber.SelectedItem = sQuote1RevNo;
            }
        }

        private void chkAddProduct_CheckedChanged(object sender, EventArgs e)
        {
            if (chkAddProduct.CheckState == CheckState.Checked)
            {
                pnAddProduct.Visible = true;
            }
            else
            {
                pnAddProduct.Visible = false;
            }
        }

        private void btnAddCategoryProduct_Click(object sender, EventArgs e)
        {
            if (!cmbProductCategory.Items.Contains(txtProductCategory.Text))
            {
                cmbProductCategory.Items.Add(txtProductCategory.Text);
                chkAddProduct.Checked = false;
                //  pnAddProduct.Visible = false;
                MessageBox.Show("Entered product group added", "Success", 0, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Entered product group exist, Enter a uniqe name", "Error", 0, MessageBoxIcon.Error);
            }
        }

        private void chkQuoteSavePath_CheckedChanged(object sender, EventArgs e)
        {
            if (chkQuoteSavePath.CheckState == CheckState.Checked)
            {
                if (MessageBox.Show("The default save location for quotes is '" + Properties.Settings.Default.FolderPath + "'\nClick on Yes to change the quote save location", "Save location", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                {
                    DialogResult result = folderBrowserDialog1.ShowDialog();
                    if (result == DialogResult.OK)
                    {
                        Properties.Settings.Default.FolderPath = folderBrowserDialog1.SelectedPath;
                        Properties.Settings.Default.Save();
                        MessageBox.Show("The default save location for quotes changed to the selected path '" + Properties.Settings.Default.FolderPath + "'", "Success", 0, MessageBoxIcon.Information);
                        chkQuoteSavePath.Checked = false;
                    }
                    else
                    {
                        chkQuoteSavePath.Checked = false;
                    }
                }
                else
                {
                    chkQuoteSavePath.Checked = false;
                }

            }
        }

        private void cmbSelectQuoteType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!bCustomerLoad)
            {
                // fnClearLoaddata();

                cmbQuotationNumber.SelectedIndex = -1;
                cmbRevisionNumber.SelectedIndex = -1;
            }
            btnPreview.Enabled = false;
            tabControl1.Enabled = true;
            lblQuotebyin.Visible = false;
            lblQuoteBy.Visible = false;
            btnViewQuotes.Enabled = false;
            switch (cmbSelectQuoteType.Text)
            {
                case "New Quote":
                    pnQuotationNumber.Visible = false;
                    btnGenarateQuote.Text = "Generate Quote";
                    btnPreview.Enabled = true;
                    break;

                case "Copy Quote":
                    pnQuotationNumber.Visible = true;
                    cmbQuotationNumber.Items.Clear();
                    dtAllQuotationNumbers = DAL.fnQuotationNumberLoadData(4, lblPrepareBy.Text, "").Tables[0];
                    btnViewQuotes.Enabled = true;
                    cmbEnquireCurrency.SelectedIndex = -1;
                    if (dtAllQuotationNumbers.Rows.Count > 0)
                    {
                        foreach (DataRow DR in dtAllQuotationNumbers.Rows)
                        {
                            if (!cmbQuotationNumber.Items.Contains(DR["QuotationNumber"].ToString()))
                                cmbQuotationNumber.Items.Add(DR["QuotationNumber"].ToString());
                        }
                    }

                    btnGenarateQuote.Text = "Generate Quote";
                    btnPreview.Enabled = true;
                    break;

                case "Revise Quote":
                    lblQuotebyin.Visible = true;
                    lblQuoteBy.Visible = true;
                    btnGenarateQuote.Text = "Revise Quote";

                    pnQuotationNumber.Visible = true;
                    if (string.IsNullOrEmpty(txtEnquiryNumber.Text))
                    {
                        cmbQuotationNumber.Items.Clear();
                        dtAllQuotationNumbers = DAL.fnQuotationNumberLoadData(4, lblPrepareBy.Text, "").Tables[0];

                        if (dtAllQuotationNumbers.Rows.Count > 0)
                        {
                            foreach (DataRow DR in dtAllQuotationNumbers.Rows)
                            {
                                if (!cmbQuotationNumber.Items.Contains(DR["QuotationNumber"].ToString()))
                                    cmbQuotationNumber.Items.Add(DR["QuotationNumber"].ToString());
                            }
                        }
                    }
                    break;

                case "Update Quote":
                    lblQuotebyin.Visible = true;
                    lblQuoteBy.Visible = true;
                    btnGenarateQuote.Text = "Update Quote";
                    pnQuotationNumber.Visible = true;
                    if (string.IsNullOrEmpty(txtEnquiryNumber.Text))
                    {
                        cmbQuotationNumber.Items.Clear();
                        dtAllQuotationNumbers = DAL.fnQuotationNumberLoadData(4, lblPrepareBy.Text, "").Tables[0];

                        if (dtAllQuotationNumbers.Rows.Count > 0)
                        {
                            foreach (DataRow DR in dtAllQuotationNumbers.Rows)
                            {
                                if (!cmbQuotationNumber.Items.Contains(DR["QuotationNumber"].ToString()))
                                    cmbQuotationNumber.Items.Add(DR["QuotationNumber"].ToString());
                            }
                        }
                    }
                    break;
            }
        }

        private void txtAdditionalMonths_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            fnNumberKeyPressOnly(sender, e);
        }

        private void txtAdditionalMonths_Leave(object sender, EventArgs e)
        {
            fnEmptyTextBox(sender, e);
        }

        private void txtadditionalWarPer_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtadditionalWarPer.Text))
            {
                txtAdditionalwarrantyAmount.Text = Math.Round((Convert.ToDouble(txtBsaicPrice.Text) * Convert.ToDouble(txtadditionalWarPer.Text)) / 100).ToString();
                fnTotalPrice();
            }
        }

        private void txtadditionalWarPer_Leave(object sender, EventArgs e)
        {
            fnEmptyTextBox(sender, e);
        }

        private void txtadditionalWarPer_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            fnNumberKeyPressOnly(sender, e);
        }

        DataTable dtKevalue = new DataTable();

        StringDictionary ModelNumber = new StringDictionary();

        StringDictionary NewModelNumber = new StringDictionary();

        private void fnAddDictionary()
        {
            //ModelNumber.Add("UTMNano10 kN", "UT-01-0010");
            //ModelNumber.Add("UTMNano15 kN", "UT-01-0015");
            //ModelNumber.Add("UTMNano25 kN", "UT-01-0025");
            //ModelNumber.Add("UTMMakron25 kN", "UT-02-0025");
            //ModelNumber.Add("UTMMakron50 kN", "UT-02-0050");
            //ModelNumber.Add("UTMMedian100 kN", "UT-04-0100");
            //ModelNumber.Add("UTMMedian150 kN", "UT-04-0150");
            //ModelNumber.Add("UTMMedian250 kN", "UT-04-0250");
            //ModelNumber.Add("UTMMedian300 kN", "UT-04-0300");
            //ModelNumber.Add("UTMMedian500 kN", "UT-04-0500");
            //ModelNumber.Add("UTMMedian600 kN", "UT-04-0600");
            //ModelNumber.Add("UTMMagnum500 kN", "UT-05-0500");
            //ModelNumber.Add("UTMMagnum1000 kN", "UT-05-1000");
            //ModelNumber.Add("UTMMagnum1500 kN", "UT-05-1500");
            //ModelNumber.Add("UTMMagnum2000 kN", "UT-05-2000");
            //ModelNumber.Add("UTMMagnum3000 kN", "UT-05-3000");
            //ModelNumber.Add("UTMElectra25 kN", "UT-20-0025");
            //ModelNumber.Add("UTMElectra50 kN", "UT-20-0050");
            //ModelNumber.Add("UTMElectra100 kN", "UT-20-0100");
            //ModelNumber.Add("UTMElectra200 kN", "UT-20-0200");
            //ModelNumber.Add("UTMAxial Torsion25 kN - 500 Nm", "UT-08-0025");
            //ModelNumber.Add("UTMAxial Torsion50 kN - 1000 Nm", "UT-08-0051");
            //ModelNumber.Add("UTMAxial Torsion100 kN - 2000 Nm", "UT-08-0101");
            //ModelNumber.Add("UTMAxial Torsion500 kN - 2000 Nm", "UT-08-0502");
            //ModelNumber.Add("STSBi-axial5 kN", "MC-02-0005");
            //ModelNumber.Add("STSBi-axial10 kN", "MC-02-0010");
            //ModelNumber.Add("STSBi-axial25 kN", "MC-02-0025");
            //ModelNumber.Add("STSBi-axial50 kN", "MC-02-0050");
            //ModelNumber.Add("STSBi-axial100 kN ", "MC-02-0100");
            //ModelNumber.Add("STSBi-axial250 kN", "MC-02-0250");
            //ModelNumber.Add("STSBi-axial500 kN", "MC-02-0500");
            //ModelNumber.Add("STSStructural Actuator1 Actuator", "SP-01-1000");
            //ModelNumber.Add("STSStructural Actuator2 Actuators", "SP-01-2000");
            //ModelNumber.Add("STSStructural Actuator4 Actuators", "SP-01-3000");
            //ModelNumber.Add("STSStructural Actuator8 Actuators", "SP-01-4000");
            //ModelNumber.Add("DTSSingle Station5 kN", " SP-05-0505");
            //ModelNumber.Add("DTSSingle Station10 kN", " SP-05-0510");
            //ModelNumber.Add("DTSSingle Station15 kN", " SP-05-0515");
            //ModelNumber.Add("DTSSingle Station25 kN", " SP-05-0525");
            //ModelNumber.Add("DTSSingle Station50 kN", " SP-05-0550");
            //ModelNumber.Add("DTSDual Station5 kN", " SP-01-0205");
            //ModelNumber.Add("DTSDual Station10 kN", " SP-01-0210");
            //ModelNumber.Add("DTSDual Station15 kN", " SP-01-0215");
            //ModelNumber.Add("DTSTilting Machine25 kN", " SP-01-0625");
            //ModelNumber.Add("DTSTilting Machine50 kN", " SP-01-0650");
            //ModelNumber.Add("DTSDurability10 kN", " SP-01-0410");
            //ModelNumber.Add("DTSDurability25 kN", " SP-01-0425");
            //ModelNumber.Add("DTSDurability50 kN", " SP-01-0450");
            //ModelNumber.Add("DTSCranking System5 kN", " SP-01-3505");
            //ModelNumber.Add("DTSCranking System10 kN", " SP-01-3510");
            //ModelNumber.Add("DTSCranking System15 kN", " SP-01-3515");
            //ModelNumber.Add("DTSSuspension Test Rig10 kN", "SP-02-1010");
            //ModelNumber.Add("DTSSuspension Test Rig15 kN", "SP-02-1015");
            //ModelNumber.Add("DTSSuspension Test Rig25 kN", "SP-02-1025");
            //ModelNumber.Add("DTSSuspension Test Rig50 kN", "SP-02-1050");
            //ModelNumber.Add("LFSSingle Column40 N", "LF-01-0040");
            //ModelNumber.Add("LFSSingle Column200 N", "LF-01-0200");
            //ModelNumber.Add("LFSSingle Column500 N", "LF-01-0500");
            //ModelNumber.Add("LFSSingle Column200 N - 2 Nm", "LF-01-1200");
            //ModelNumber.Add("LFSSingle Column400 N - 2 Nm", "LF-01-1400");
            //ModelNumber.Add("LFSDual Column1 kN", "LF-02-1000");
            //ModelNumber.Add("LFSDual Column5 kN", "LF-02-5000");
            //ModelNumber.Add("LFSDual Column10 kN", "LF-02-1010");
            //ModelNumber.Add("TGTLigaGenL30 -1C", "TGT-01-01C");
            //ModelNumber.Add("TGTLigaGenL30 -4C", "TGT-01-04C");
            //ModelNumber.Add("TGTLigaGenL150 -1C", "TGT-01-150");
            //ModelNumber.Add("TGTLumeGenSingle Chamber", "TGT-03-1V");
            //ModelNumber.Add("TGTLumeGenMulti Chamber", "TGT-03-6V");
            //ModelNumber.Add("TGTCartiGenC10-12", "TGT-02-010");
            //ModelNumber.Add("TGTCartiGenC-9x", "TGT-02-009");
            //ModelNumber.Add("TGTDermiGenD70-1", "TGT-05-070");
            //ModelNumber.Add("TGTOsteoGen1 O", "TGT-04-001");
            //ModelNumber.Add("TGTOsteoGen6 O", "TGT-04-006");
            //ModelNumber.Add("TGTOsteoGen12 O", "TGT-04-012");
            //ModelNumber.Add("FSW3 Axis50kN", "SP-03-3050");
            //ModelNumber.Add("FSW5 Axis50kN", "SP-03-5050");
            //ModelNumber.Add("FSW6 Axis50kN", "SP-03-5050");
            //ModelNumber.Add("ShaketableUniaxial0.5m and 500kg", "SH-01-0505");
            //ModelNumber.Add("ShaketableUniaxial1m x 500kg", "SH-01-1005");
            //ModelNumber.Add("ShaketableUniaxial1m x 1000kg", "SH-01-1010");
            //ModelNumber.Add("ShaketableUniaxial1.5m x 1000kg", "SH-01-1510");
            //ModelNumber.Add("ShaketableUniaxial1.5m x 2000kg", "SH-01-1520");
            //ModelNumber.Add("ShaketableUniaxial2m x 2000kg", "SH-01-2020");
            //ModelNumber.Add("ShaketableUniaxial2m x 3000kg", "SH-01-2030");
            //ModelNumber.Add("ShaketableUniaxial3m x 5000kg", "SH-01-3050");
            //ModelNumber.Add("ShaketableUniaxial3m x 10000kg", "SH-01-3010");
            //ModelNumber.Add("ShaketableBiaxial0.5m and 500kg", "SH-02-0505");
            //ModelNumber.Add("ShaketableBiaxial1m x 500kg", "SH-02-1005");
            //ModelNumber.Add("ShaketableBiaxial1m x 1000kg", "SH-02-1010");
            //ModelNumber.Add("ShaketableBiaxial1.5m x 1000kg", "SH-02-1510");
            //ModelNumber.Add("ShaketableBiaxial1.5m x 2000kg", "SH-02-1520");
            //ModelNumber.Add("ShaketableBiaxial2m x 2000kg", "SH-02-2020");
            //ModelNumber.Add("ShaketableBiaxial2m x 3000kg", "SH-02-2030");
            //ModelNumber.Add("ShaketableBiaxial3m x 5000kg", "SH-02-3050");
            //ModelNumber.Add("ShaketableBiaxial3m x 10000kg", "SH-02-3010");
            //ModelNumber.Add("ShaketableTriaxial0.5m and 500kg", "SH-04-0505");
            //ModelNumber.Add("ShaketableTriaxial1m x 500kg", "SH-04-1005");
            //ModelNumber.Add("ShaketableTriaxial1m x 1000kg", "SH-04-1010");
            //ModelNumber.Add("ShaketableTriaxial2m x 2000kg", "SH-04-2020");
            //ModelNumber.Add("ShaketableTriaxial2m x 5000kg", "SH-04-2050");

            ModelNumber.Add("BI-7001", "UT-01-0010");
            ModelNumber.Add("BI-7002", "UT-01-0015");
            ModelNumber.Add("BI-7003", "UT-01-0025");
            ModelNumber.Add("BI-7011", "UT-02-0025");
            ModelNumber.Add("BI-7012", "UT-02-0050");
            ModelNumber.Add("BI-7021", "UT-04-0100");
            ModelNumber.Add("BI-7022", "UT-04-0150");
            ModelNumber.Add("BI-7023", "UT-04-0250");
            ModelNumber.Add("BI-7024", "UT-04-0300");
            ModelNumber.Add("BI-7025", "UT-04-0500");
            ModelNumber.Add("BI-7026", "UT-04-0600");
            ModelNumber.Add("Bi-7031", "UT-05-0500");
            ModelNumber.Add("BI-7032", "UT-05-0600");
            ModelNumber.Add("BI-7033", "UT-05-1000");
            ModelNumber.Add("BI-7034", "UT-05-1500");
            ModelNumber.Add("BI-7035", "UT-05-2000");
            ModelNumber.Add("BI-7036", "UT-05-3000");
            ModelNumber.Add("BI-7037", "UT-05-5000");
            ModelNumber.Add("BI-7041", "UT-20-0010");
            ModelNumber.Add("BI-7042", "UT-20-0025");
            ModelNumber.Add("BI-7043", "UT-20-0050");
            ModelNumber.Add("BI-7044", "UT-20-0100");
            ModelNumber.Add("BI-7045", "UT-20-0200");
            ModelNumber.Add("BI-7051", "UT-08-0025");
            ModelNumber.Add("BI-7052", "UT-08-0051");
            ModelNumber.Add("BI-7053", "UT-08-0101");
            ModelNumber.Add("BI-7054", "UT-08-0502");
            ModelNumber.Add("BI-7061", "MC-02-0005");
            ModelNumber.Add("BI-7062", "MC-02-0010");
            ModelNumber.Add("BI-7063", "MC-02-0025");
            ModelNumber.Add("BI-7064", "MC-02-0050");
            ModelNumber.Add("BI-7065", "MC-02-0100");
            ModelNumber.Add("BI-7066", "MC-02-0250");
            ModelNumber.Add("BI-7067", "MC-02-0500");
            ModelNumber.Add("BI-7071", "SP-01-1000");
            ModelNumber.Add("BI-7072", "SP-01-2000");
            ModelNumber.Add("BI-7073", "SP-01-3000");
            ModelNumber.Add("BI-7074", "SP-01-4000");
            ModelNumber.Add("BI-7081SS", "SP-05-0505");
            ModelNumber.Add("BI-7082SS", "SP-05-0510");
            ModelNumber.Add("BI-7083SS", "SP-05-0515");
            ModelNumber.Add("BI-7084SS", "SP-05-0525");
            ModelNumber.Add("BI-7085SS", "SP-05-0550");
            ModelNumber.Add("BI-7081DS", "SP-01-0205");
            ModelNumber.Add("BI-7082DS", "SP-01-0210");
            ModelNumber.Add("BI-7083DS", "SP-01-0215");
            ModelNumber.Add("BI-7084DS", "SP-01-0225");
            ModelNumber.Add("BI-7084R", "SP-01-0625");
            ModelNumber.Add("BI-7085R", "SP-01-0650");
            ModelNumber.Add("BI-7087DR", "SP-01-0410");
            ModelNumber.Add("BI-7088DR", "SP-01-0425");
            ModelNumber.Add("BI-7089DR", "SP-01-0450");
            ModelNumber.Add("BI-7090CS", "SP-01-3505");
            ModelNumber.Add("BI-7091CS", "SP-01-3510");
            ModelNumber.Add("BI-7092CS", "SP-01-3515");
            ModelNumber.Add("BI-7101", "SP-02-1010");
            ModelNumber.Add("BI-7102", "SP-02-1015");
            ModelNumber.Add("BI-7103", "SP-02-1025");
            ModelNumber.Add("BI-7104", "SP-02-1050");
            ModelNumber.Add("BI-7201", "LF-01-0040");
            ModelNumber.Add("BI-7202", "LF-01-0200");
            ModelNumber.Add("BI-7203", "LF-01-0500");
            ModelNumber.Add("BI-7204", "LF-01-1200");
            ModelNumber.Add("BI-7205", "LF-01-1400");
            ModelNumber.Add("BI-7206", "LF-02-1000");
            ModelNumber.Add("BI-7207", "LF-02-5000");
            ModelNumber.Add("BI-7208", "LF-02-1010");
            ModelNumber.Add("BI-7209", "TGT-01-01C");
            ModelNumber.Add("BI-7210", "TGT-01-04C");
            ModelNumber.Add("BI-7211", "TGT-01-150");
            ModelNumber.Add("BI-7212", "TGT-03-1V");
            ModelNumber.Add("BI-7213", "TGT-03-6V");
            ModelNumber.Add("BI-7214", "TGT-02-010");
            ModelNumber.Add("BI-7215", "TGT-02-009");
            ModelNumber.Add("BI-7216", "TGT-05-070");
            ModelNumber.Add("BI-7217", "TGT-04-001");
            ModelNumber.Add("BI-7218", "TGT-04-006");
            ModelNumber.Add("BI-7219", "TGT-04-012");
            ModelNumber.Add("BI-7310", "SH-01-0505");
            ModelNumber.Add("BI-7311", "SH-01-1005");
            ModelNumber.Add("BI-7312", "SH-01-1010");
            ModelNumber.Add("BI-7313", "SH-01-1510");
            ModelNumber.Add("BI-7314", "SH-01-1520");
            ModelNumber.Add("BI-7315", "SH-01-2020");
            ModelNumber.Add("BI-7316", "SH-01-2030");
            ModelNumber.Add("BI-7317", "SH-01-3050");
            ModelNumber.Add("BI-7318", "SH-01-3010");
            ModelNumber.Add("BI-7320", "SH-02-0505");
            ModelNumber.Add("BI-7321", "SH-02-1005");
            ModelNumber.Add("BI-7322", "SH-02-1010");
            ModelNumber.Add("BI-7323", "SH-02-1510");
            ModelNumber.Add("BI-7324", "SH-02-1520");
            ModelNumber.Add("BI-7325", "SH-02-2020");
            ModelNumber.Add("BI-7326", "SH-02-2030");
            ModelNumber.Add("BI-7327", "SH-02-3050");
            ModelNumber.Add("BI-7328", "SH-02-3010");
            ModelNumber.Add("BI-7331", "SH-04-0505");
            ModelNumber.Add("BI-7332", "SH-04-1005");
            ModelNumber.Add("BI-7333", "SH-04-1010");
            ModelNumber.Add("BI-7336", "SH-04-2020");
            ModelNumber.Add("BI-7337", "SH-04-2050");

        }
        private void fnNewmodels()
        {
            NewModelNumber.Add("UTMNano10 kN", "BI-7001");
            NewModelNumber.Add("UTMNano15 kN", "BI-7002");
            NewModelNumber.Add("UTMNano25 kN", "BI-7003");
            NewModelNumber.Add("UTMMakron25 kN", "BI-7011");
            NewModelNumber.Add("UTMMakron50 kN", "BI-7012");
            NewModelNumber.Add("UTMMedian100 kN", "BI-7021");
            NewModelNumber.Add("UTMMedian150 kN", "BI-7022");
            NewModelNumber.Add("UTMMedian250 kN", "BI-7023");
            NewModelNumber.Add("UTMMedian300 kN", "BI-7024");
            NewModelNumber.Add("UTMMedian500 kN", "BI-7025");
            NewModelNumber.Add("UTMMedian600 kN", "BI-7026");
            NewModelNumber.Add("UTMMagnum500 kN", "Bi-7031");
            NewModelNumber.Add("UTMMagnum600 kN", "BI-7032");
            NewModelNumber.Add("UTMMagnum1000 kN", "BI-7033");
            NewModelNumber.Add("UTMMagnum1500 kN", "BI-7034");
            NewModelNumber.Add("UTMMagnum2000 kN", "BI-7035");
            NewModelNumber.Add("UTMMagnum3000 kN", "BI-7036");
            NewModelNumber.Add("UTMMagnum5000 kN", "BI-7037");
            NewModelNumber.Add("UTMElectra10 kN", "BI-7041");
            NewModelNumber.Add("UTMElectra25 kN", "BI-7042");
            NewModelNumber.Add("UTMElectra50 kN", "BI-7043");
            NewModelNumber.Add("UTMElectra100 kN", "BI-7044");
            NewModelNumber.Add("UTMElectra200 kN", "BI-7045");
            NewModelNumber.Add("UTMAxial Torsion25 kN - 500 Nm", "BI-7051");
            NewModelNumber.Add("UTMAxial Torsion50 kN - 1000 Nm", "BI-7052");
            NewModelNumber.Add("UTMAxial Torsion100 kN - 2000 Nm", "BI-7053");
            NewModelNumber.Add("UTMAxial Torsion500 kN - 2000 Nm", "BI-7054");
            NewModelNumber.Add("STSBi-axial5 kN", "BI-7061");
            NewModelNumber.Add("STSBi-axial10 kN", "BI-7062");
            NewModelNumber.Add("STSBi-axial25 kN", "BI-7063");
            NewModelNumber.Add("STSBi-axial50 kN", "BI-7064");
            NewModelNumber.Add("STSBi-axial100 kN ", "BI-7065");
            NewModelNumber.Add("STSBi-axial250 kN", "BI-7066");
            NewModelNumber.Add("STSBi-axial500 kN", "BI-7067");
            NewModelNumber.Add("STSStructural Actuator1 Actuator", "BI-7071");
            NewModelNumber.Add("STSStructural Actuator2 Actuators", "BI-7072");
            NewModelNumber.Add("STSStructural Actuator4 Actuators", "BI-7073");
            NewModelNumber.Add("STSStructural Actuator8 Actuators", "BI-7074");
            NewModelNumber.Add("DTSSingle Station5 kN", "BI-7081SS");
            NewModelNumber.Add("DTSSingle Station10 kN", "BI-7082SS");
            NewModelNumber.Add("DTSSingle Station15 kN", "BI-7083SS");
            NewModelNumber.Add("DTSSingle Station25 kN", "BI-7084SS");
            NewModelNumber.Add("DTSSingle Station50 kN", "BI-7085SS");
            NewModelNumber.Add("DTSDual Station5 kN", "BI-7081DS");
            NewModelNumber.Add("DTSDual Station10 kN", "BI-7082DS");
            NewModelNumber.Add("DTSDual Station15 kN", "BI-7083DS");
            NewModelNumber.Add("DTSDual Station25 kN", "BI-7084DS");
            NewModelNumber.Add("DTSTilting Machine25 kN", "BI-7084R");
            NewModelNumber.Add("DTSTilting Machine50 kN", "BI-7085R");
            NewModelNumber.Add("DTSDurability10 kN", "BI-7087DR");
            NewModelNumber.Add("DTSDurability25 kN", "BI-7088DR");
            NewModelNumber.Add("DTSDurability50 kN", "BI-7089DR");
            NewModelNumber.Add("DTSSingle Station Cranking System5 kN", "BI-7090CS");
            NewModelNumber.Add("DTSSingle Station Cranking System10 kN", "BI-7091CS");
            NewModelNumber.Add("DTSSingle Station Cranking System15 kN", "BI-7092CS");
            NewModelNumber.Add("DTSDual Station Cranking System5 kN", "BI-7093CD");
            NewModelNumber.Add("DTSDual Station Cranking System10 kN", "BI-7094CD");
            NewModelNumber.Add("DTSDual Station Cranking System15 kN", "BI-7095CD");
            NewModelNumber.Add("Noise Detection Test System", "BI-7086N");
            NewModelNumber.Add("DTSSuspension Test Rig10 kN", "BI-7101");
            NewModelNumber.Add("DTSSuspension Test Rig15 kN", "BI-7102");
            NewModelNumber.Add("DTSSuspension Test Rig25 kN", "BI-7103");
            NewModelNumber.Add("DTSSuspension Test Rig50 kN", "BI-7104");
            NewModelNumber.Add("LFSSingle Column40 N", "BI-7201");
            NewModelNumber.Add("LFSSingle Column200 N", "BI-7202");
            NewModelNumber.Add("LFSSingle Column500 N", "BI-7203");
            NewModelNumber.Add("LFSSingle Column200 N - 2 Nm", "BI-7204");
            NewModelNumber.Add("LFSSingle Column400 N - 2 Nm", "BI-7205");
            NewModelNumber.Add("LFSDual Column1 kN", "BI-7206");
            NewModelNumber.Add("LFSDual Column5 kN", "BI-7207");
            NewModelNumber.Add("LFSDual Column10 kN", "BI-7208");
            NewModelNumber.Add("TGTLigaGenL30 -1C", "BI-7209");
            NewModelNumber.Add("TGTLigaGenL30 -4C", "BI-7210");
            NewModelNumber.Add("TGTLigaGenL150 -1C", "BI-7211");
            NewModelNumber.Add("TGTLumeGenSingle Chamber", "BI-7212");
            NewModelNumber.Add("TGTLumeGenMulti Chamber", "BI-7213");
            NewModelNumber.Add("TGTCartiGenC10-12", "BI-7214");
            NewModelNumber.Add("TGTCartiGenC-9x", "BI-7215");
            NewModelNumber.Add("TGTDermiGenD70-1", "BI-7216");
            NewModelNumber.Add("TGTOsteoGen1 O", "BI-7217");
            NewModelNumber.Add("TGTOsteoGen6 O", "BI-7218");
            NewModelNumber.Add("TGTOsteoGen12 O", "BI-7219");
            NewModelNumber.Add("ShaketableUniaxial0.5m and 500kg", "BI-7310");
            NewModelNumber.Add("ShaketableUniaxial1m x 500kg", "BI-7311");
            NewModelNumber.Add("ShaketableUniaxial1m x 1000kg", "BI-7312");
            NewModelNumber.Add("ShaketableUniaxial1.5m x 1000kg", "BI-7313");
            NewModelNumber.Add("ShaketableUniaxial1.5m x 2000kg", "BI-7314");
            NewModelNumber.Add("ShaketableUniaxial2m x 2000kg", "BI-7315");
            NewModelNumber.Add("ShaketableUniaxial2m x 3000kg", "BI-7316");
            NewModelNumber.Add("ShaketableUniaxial3m x 5000kg", "BI-7317");
            NewModelNumber.Add("ShaketableUniaxial3m x 10000kg", "BI-7318");
            NewModelNumber.Add("ShaketableBiaxial0.5m and 500kg", "BI-7320");
            NewModelNumber.Add("ShaketableBiaxial1m x 500kg", "BI-7321");
            NewModelNumber.Add("ShaketableBiaxial1m x 1000kg", "BI-7322");
            NewModelNumber.Add("ShaketableBiaxial1.5m x 1000kg", "BI-7323");
            NewModelNumber.Add("ShaketableBiaxial1.5m x 2000kg", "BI-7324");
            NewModelNumber.Add("ShaketableBiaxial2m x 2000kg", "BI-7325");
            NewModelNumber.Add("ShaketableBiaxial2m x 3000kg", "BI-7326");
            NewModelNumber.Add("ShaketableBiaxial3m x 5000kg", "BI-7327");
            NewModelNumber.Add("ShaketableBiaxial3m x 10000kg", "BI-7328");
            NewModelNumber.Add("ShaketableTriaxial0.5m and 500kg", "BI-7331");
            NewModelNumber.Add("ShaketableTriaxial1m x 500kg", "BI-7332");
            NewModelNumber.Add("ShaketableTriaxial1m x 1000kg", "BI-7333");
            NewModelNumber.Add("ShaketableTriaxial2m x 2000kg", "BI-7336");
            NewModelNumber.Add("ShaketableTriaxial2m x 5000kg", "BI-7337");
            NewModelNumber.Add("Shaketable Uniaxial SE 0.5m x 100kg", "BI-7351");
            NewModelNumber.Add("STSUniaxial Elastomer Test System10 kN", "BI-7361");
            NewModelNumber.Add("STSUniaxial Elastomer Test System25 kN", "BI-7362");
            NewModelNumber.Add("STSUniaxial Elastomer Test System50 kN", "BI-7363");
            NewModelNumber.Add("STS2 Axes Vertical Elastomer Test System 25 kN500 Nm", "BI-7371");
            NewModelNumber.Add("STS2 Axes Horizontal Elastomer Test System 25 kN500 Nm", "BI-7381");
            NewModelNumber.Add("STS3 Axes Horizontal Elastomer Test System 300 kN2 k Nm", "Bi-7391");
            NewModelNumber.Add("STS4 Axes Horizontal Elastomer Test System", "BI-7401");
        }
        private void cmbCapacity_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ModelNumber.Values.Count == 0)
            {
                fnAddDictionary();
                fnNewmodels();
            }
            sCapacity = sAutoModel + cmbCapacity.Text;
            //txtOldModelNumber.Text = ModelNumber[sCapacity];

            txtModelNumber.Text = NewModelNumber[sCapacity];

            txtOldModelNumber.Text = ModelNumber[txtModelNumber.Text];
        }
        private void dgQuoteBOM_CellDoubleClick(object sender, System.Windows.Forms.DataGridViewCellEventArgs e)
        {
            //MessageBox.Show(dgQuoteBOM.CurrentCell.ColumnIndex.ToString());
            if (dgQuoteBOM.CurrentCell.ColumnIndex == 8 && !string.IsNullOrEmpty(dgQuoteBOM.CurrentRow.Cells[2].Value.ToString()))
            {
                if (dgQuoteBOM.CurrentCell.Value.ToString() == "No")
                {
                    dgQuoteBOM.CurrentCell.Value = "Yes";
                }
                else if (dgQuoteBOM.CurrentCell.Value.ToString() == "Yes")
                {
                    dgQuoteBOM.CurrentCell.Value = "No";
                }
            }
        }

        private void dgvOptionalItems_CellDoubleClick(object sender, System.Windows.Forms.DataGridViewCellEventArgs e)
        {
            if (dgvOptionalItems.CurrentCell.ColumnIndex == 8 && !string.IsNullOrEmpty(dgvOptionalItems.CurrentRow.Cells[2].Value.ToString()))
            {
                if (dgvOptionalItems.CurrentCell.Value.ToString() == "No")
                {
                    dgvOptionalItems.CurrentCell.Value = "Yes";
                }
                else if (dgvOptionalItems.CurrentCell.Value.ToString() == "Yes")
                {
                    dgvOptionalItems.CurrentCell.Value = "No";
                }
            }
        }

        private void dgvOptionalItems_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Delete)
            {
                dCurrentcell = Convert.ToDouble(dgvOptionalItems.CurrentRow.Cells["OISLNo"].Value.ToString());
                numbercheck = (int)dCurrentcell;
                if (e.Control && e.KeyCode == Keys.X && iCopy == 99 && dCurrentcell != Math.Floor(dCurrentcell))
                {
                    DataRow SelectedRow = dtQuoteOptionalItems.Rows[dgvOptionalItems.SelectedCells[0].OwningRow.Index];
                    newRow = dtQuoteOptionalItems.NewRow();
                    newRow.ItemArray = SelectedRow.ItemArray;
                    dtQuoteOptionalItems.Rows.Remove(SelectedRow);
                    iCopy = 1;
                }
                else if ((e.Control && e.KeyCode == Keys.X) && iCopy1 == 99 && dCurrentcell == numbercheck)
                {
                    dOldMainValue = Convert.ToDouble(dgvOptionalItems.CurrentRow.Cells["OISLNo"].Value.ToString());
                    MessageBox.Show("Product '" + dgvOptionalItems.CurrentRow.Cells[3].Value.ToString() + "' selected to move.\n\nSelect the next product to move the items", "Success", 0, MessageBoxIcon.Information);
                    iCopy1 = 1;
                }
                else if ((e.Control && e.KeyCode == Keys.V) && iCopy1 == 1 && dCurrentcell == numbercheck)
                {
                    dNewMainValue = Convert.ToDouble(dgvOptionalItems.CurrentRow.Cells["OISLNo"].Value.ToString());
                    iCopy1 = 99;
                    int icount = 0;
                    double icount1 = 0.1;
                    dMiddleValue = 60;
                    foreach (DataRow dr in dtQuoteOptionalItems.Rows)
                    {
                        if (Convert.ToDouble(dr[0].ToString()) >= dOldMainValue && Convert.ToDouble(dr[0].ToString()) < (1 + dOldMainValue))
                        {
                            if (icount == 0)
                            {
                                dr[0] = dMiddleValue;
                            }
                            else
                            {
                                dr[0] = (dMiddleValue + icount1);
                                icount1 += 0.1;
                            }
                            icount++;

                        }
                    }
                    icount = 0;
                    icount1 = 0.1;
                    dtQuoteOptionalItems.AcceptChanges();

                    foreach (DataRow dr in dtQuoteOptionalItems.Rows)
                    {
                        if (Convert.ToDouble(dr[0].ToString()) >= dNewMainValue && Convert.ToDouble(dr[0].ToString()) < (1 + dNewMainValue))
                        {
                            if (icount == 0)
                            {
                                dr[0] = dOldMainValue;
                            }
                            else
                            {
                                dr[0] = (dOldMainValue + icount1);
                                icount1 += 0.1;
                            }
                            icount++;

                        }
                    }
                    dtQuoteOptionalItems.AcceptChanges();

                    icount = 0;
                    icount1 = 0.1;

                    foreach (DataRow dr in dtQuoteOptionalItems.Rows)
                    {
                        if (Convert.ToDouble(dr[0].ToString()) >= dMiddleValue && Convert.ToDouble(dr[0].ToString()) < (1 + dMiddleValue))
                        {
                            if (icount == 0)
                            {
                                dr[0] = dNewMainValue;
                            }
                            else
                            {
                                dr[0] = (dNewMainValue + icount1);
                                icount1 += 0.1;
                            }
                            icount++;

                        }
                    }

                    dtQuoteOptionalItems.AcceptChanges();
                    fnOptionalItemTotalCalculation();
                }
                else if (e.Control && e.KeyCode == Keys.V && dCurrentcell != Math.Floor(dCurrentcell))
                {
                    if (iCopy == 1)
                    {
                        dtQuoteOptionalItems.Rows.InsertAt(newRow, (dgvOptionalItems.SelectedCells[0].OwningRow.Index));
                        iCopy = 99;

                        double dCheck = 0;
                        double dCurrentValue = Math.Truncate(dCurrentcell);
                        double dMinusValue;
                        double dCurrentMinusValue;
                        if (dCurrentValue == 0)
                        {
                            dCurrentValue = 1;
                        }
                        foreach (DataGridViewRow dr in dgvOptionalItems.Rows)
                        {
                            if (Convert.ToDouble(dr.Cells["OISLNo"].Value.ToString()) > dCurrentValue && Convert.ToDouble(dr.Cells["OISLNo"].Value.ToString()) < (dCurrentValue + 1))
                            {
                                dCheck++;
                            }
                        }

                        if (dCheck <= 9)
                        {
                            dMinusValue = 0.1;
                        }
                        else
                        {
                            dMinusValue = 0.01;
                        }
                        dCurrentMinusValue = dCurrentValue;

                        foreach (DataGridViewRow dr in dgvOptionalItems.Rows)
                        {
                            if (Convert.ToDouble(dr.Cells["OISLNo"].Value.ToString()) > dCurrentValue && Convert.ToDouble(dr.Cells["OISLNo"].Value.ToString()) < (dCurrentValue + 1))
                            {
                                dCurrentMinusValue += dMinusValue;
                                dr.Cells["OISLNo"].Value = (dCurrentMinusValue).ToString();
                            }
                        }
                        dtQuoteOptionalItems.AcceptChanges();
                        /////  dtQuoteOptionalItems = dgvOptionalItems.DataSource as DataTable;
                        //fnOptionalItemTotalCalculation();
                    }
                }
                e.Handled = true;
            }
        }

        string[] sDisplayName;
        static string sEmailID;
        private void cmbQuoteCompany_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbQuoteCompany.SelectedIndex)
            {
                case 1:
                case 0:
                    sEmailID = LoginForm.GetUserDetails[20];
                    break;
                    //case 1:
                    //    if (LoginForm.GetUserDetails[2].ToLower() == "vivek g")
                    //    {
                    //        sEmailID = "vivek_gunasekaran@instron.com";
                    //    }
                    //    else if (LoginForm.GetUserDetails[2].ToLower() == "sadat")
                    //    {
                    //        sEmailID = "sadat_syed@instron.com";
                    //    }
                    //    else if (LoginForm.GetUserDetails[2].ToLower() == "Abdul Nayeem")
                    //    {
                    //        sEmailID = "AbdulNayeem_Qureshi@instron.com";
                    //    }
                    //    else if (LoginForm.GetUserDetails[2].ToLower() == "ankur")
                    //    {
                    //        sEmailID = "Ankur_Kulkarni@instron.com";
                    //    }
                    //    else if (LoginForm.GetUserDetails[2].ToLower() == "rohit")
                    //    {
                    //        sEmailID = "rohit_dash@instron.com";
                    //    }
                    //    else if (LoginForm.GetUserDetails[2].ToLower() == "jaibarath")
                    //    {
                    //        sEmailID = "Jai_Barath@instron.com";
                    //    }
                    //    break;
            }

        }
        bool bRequiredDate = false;
        private void dtpExpectedOrderPlacementdate_ValueChanged(object sender, EventArgs e)
        {
            bRequiredDate = true;
        }
        DataTable dtUPdatedPrice = new DataTable();
        private void chkUpdateLatestPrice_CheckedChanged(object sender, EventArgs e)
        {
            if (chkUpdateLatestPrice.Checked)
            {
                if (MessageBox.Show("The quotes item prices will be update with the latest prices.\n\nThis cannot be reversed once clicked Yes. If you want to reverse dont save the quote. \n\nClick on Yes to update the quote item prices", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                {
                    //DialogResult result = folderBrowserDialog1.ShowDialog();
                    // if (result == DialogResult.OK)
                    //{

                    //dtUPdatedPrice = DAL.fnQuotationNumberLoadData(2023, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];
                    if (dgQuoteBOM.RowCount > 0)
                    {
                        foreach (DataGridViewRow dr in dgQuoteBOM.Rows)
                        {
                            if (!string.IsNullOrEmpty(dr.Cells["ProductCod"].Value.ToString()))
                            {
                                dtUPdatedPrice = DAL.fnQuotationNumberLoadData(2023, dr.Cells["ProductCod"].Value.ToString(), "").Tables[0];
                                if (dtUPdatedPrice.Rows.Count > 0)
                                {
                                    //if (cmbEnquireCurrency.Text == "USD")
                                    //{
                                    if (!string.IsNullOrEmpty(dtUPdatedPrice.Rows[0]["SalesCost"].ToString()) && !string.IsNullOrEmpty(dtUPdatedPrice.Rows[0]["ProductCost"].ToString()))
                                    {
                                        dr.Cells["SalesCost"].Value = Math.Round(Convert.ToDouble(dtUPdatedPrice.Rows[0]["SalesCost"].ToString()) * dPegRate).ToString();
                                        dr.Cells["UnitPrice"].Value = Math.Round(Convert.ToDouble(dtUPdatedPrice.Rows[0]["ProductCost"].ToString()) * dPegRate).ToString();
                                        dr.Cells["TPrice"].Value = Math.Round(Convert.ToDouble(dr.Cells["Quantity"].Value) * dPegRate * Convert.ToDouble(dtUPdatedPrice.Rows[0]["ProductCost"].ToString())).ToString();
                                        dr.Cells["BreakupTotal"].Value = Math.Round(Convert.ToDouble(dtUPdatedPrice.Rows[0]["ProductCost"].ToString()) * dPegRate).ToString();
                                       
                                    }
                                    // }
                                    //else if (cmbEnquireCurrency.Text == "INR")
                                    //{
                                    //    dr.Cells["SalesCost"].Value = Math.Round(Convert.ToDouble(dtUPdatedPrice.Rows[0]["SalesCost"].ToString()) / dPegRate).ToString();
                                    //    dr.Cells["UnitPrice"].Value = Math.Round(Convert.ToDouble(dtUPdatedPrice.Rows[0]["ProductCost"].ToString()) / dPegRate).ToString();
                                    //    dr.Cells["TPrice"].Value = Math.Round((Convert.ToDouble(dr.Cells["Quantity"].Value) * Convert.ToDouble(dtUPdatedPrice.Rows[0]["ProductCost"].ToString())) / dPegRate).ToString();
                                    //    dr.Cells["BreakupTotal"].Value = Math.Round(Convert.ToDouble(dtUPdatedPrice.Rows[0]["ProductCost"].ToString()) / dPegRate).ToString();
                                    //}

                                }
                            }

                        }
                        fnBasicPrice();
                        fnJackUpCalculation();
                        dtQuote = dgQuoteBOM.DataSource as DataTable;
                        fnTotalCalucalation();
                    }
                        if (dgvOptionalItems.RowCount > 0)
                        {
                            foreach (DataGridViewRow dr in dgvOptionalItems.Rows)
                            {
                                if (!string.IsNullOrEmpty(dr.Cells["OIProductCode"].Value.ToString()))
                                {
                                    dtUPdatedPrice = DAL.fnQuotationNumberLoadData(2023, dr.Cells["OIProductCode"].Value.ToString(), "").Tables[0];
                                    if (dtUPdatedPrice.Rows.Count > 0)
                                    {
                                        //if (cmbEnquireCurrency.Text == "USD")
                                        //  {
                                        if (!string.IsNullOrEmpty(dtUPdatedPrice.Rows[0]["SalesCost"].ToString()) && !string.IsNullOrEmpty(dtUPdatedPrice.Rows[0]["ProductCost"].ToString()))
                                        {
                                            dr.Cells["OISalesCost"].Value = Math.Round(Convert.ToDouble(dtUPdatedPrice.Rows[0]["SalesCost"].ToString()) * dPegRate).ToString();
                                            dr.Cells["OIUnitPrice"].Value = Math.Round(Convert.ToDouble(dtUPdatedPrice.Rows[0]["ProductCost"].ToString()) * dPegRate).ToString();
                                            dr.Cells["OITotalPrice"].Value = Math.Round(Convert.ToDouble(dr.Cells["OIQuantity"].Value) * dPegRate * Convert.ToDouble(dtUPdatedPrice.Rows[0]["ProductCost"].ToString())).ToString();
                                            dr.Cells["OIBreakupTotal"].Value = Math.Round(Convert.ToDouble(dtUPdatedPrice.Rows[0]["ProductCost"].ToString()) * dPegRate).ToString();
                                            
                                    }
                                        // }
                                        //else if (cmbEnquireCurrency.Text == "INR")
                                        //{
                                        //    dr.Cells["OISalesCost"].Value = Math.Round(Convert.ToDouble(dtUPdatedPrice.Rows[0]["SalesCost"].ToString()) / dPegRate).ToString();
                                        //    dr.Cells["OIUnitPrice"].Value = Math.Round(Convert.ToDouble(dtUPdatedPrice.Rows[0]["ProductCost"].ToString()) / dPegRate).ToString();
                                        //    dr.Cells["OITotalPrice"].Value = Math.Round((Convert.ToDouble(dr.Cells["OIQuantity"].Value) * Convert.ToDouble(dtUPdatedPrice.Rows[0]["ProductCost"].ToString())) / dPegRate).ToString();
                                        //    dr.Cells["OIBreakupTotal"].Value = Math.Round(Convert.ToDouble(dtUPdatedPrice.Rows[0]["ProductCost"].ToString()) / dPegRate).ToString();
                                        //}
                                    }
                                }
                            }
                            fnOICalculation();
                            dtQuoteOptionalItems = dgvOptionalItems.DataSource as DataTable;
                            fnOptionalItemTotalCalculation();
                        }

                        

                    //}
                }
            }
        }

        private void txtSystemMargin_TextChanged(object sender, EventArgs e)
        {

        }

        private void totalCostLable_Click(object sender, EventArgs e)
        {

        }

        private void discountedMMlb_Click(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        DataTable dtDisplyProdcutDesc = new DataTable();

        private void tvProduct_NodeMouseClick(object sender, System.Windows.Forms.TreeNodeMouseClickEventArgs e)
        {
            sDisplayName = e.Node.Text.Split(')');
            dtDisplyProdcutDesc = DAL.fnGetSlaesProdcutTreeNode(sDisplayName[0].ToString()).Tables[0];
            if (dtDisplyProdcutDesc.Rows.Count > 0)
            {
                if (!string.IsNullOrEmpty(dtDisplyProdcutDesc.Rows[0]["ProductDescription"].ToString()))
                {
                    toolTip1.Show(e.Node.Text + "\n" + dtDisplyProdcutDesc.Rows[0]["ProductDescription"].ToString(), tvProduct);
                }
                else
                {
                    toolTip1.Show(e.Node.Text + "\n" + "Product description not available.", tvProduct);
                }

                toolTip1.Show(e.Node.Text + "\n" + "Product description not available.", tvProduct);
            }
            else
            {
                toolTip1.Hide(tvProduct);
            }
        }

        private void tabControl1_Click(object sender, EventArgs e)
        {

        }

    }
}
