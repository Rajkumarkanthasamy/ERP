﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    public partial class frmCustomerVisit : Form
    {
        public frmCustomerVisit()
        {
            InitializeComponent();
        }
        frmForm2 form = new frmForm2();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        DataTable dtCustomerList = new DataTable();

        private void frmCustomerVisit_Load(object sender, EventArgs e)
        {
            lblUserName.Text = login.GetUserDetails[2];
            dtCustomerList = DAL.fnCustomerList(0, null).Tables[0];
            foreach (DataRow DR in dtCustomerList.Rows)
            {
                if (!cmbCustomer.Items.Contains(DR["CustomerName"].ToString()))
                    cmbCustomer.Items.Add(DR["CustomerName"].ToString());
            }
        }
        DataTable dtCustomerVisit = new DataTable();
        int iLastVisitID = 0;
        string sVisit;
        bool bContactPerson = true;
        private void btnSave_Click(object sender, EventArgs e)
        {
            bContactPerson = true;
            iLastVisitID = 0;
            if (dgContactPerson.Rows.Count > 0)
            {
                dtCustomerVisit = DAL.fnCustomerVisit(null).Tables[0];
                if (dtCustomerVisit.Rows.Count > 0)
                {
                    sVisit = dtCustomerVisit.Rows[0][1].ToString();

                    sVisit = sVisit.Substring(6, 5);
                    iLastVisitID = Convert.ToInt32(sVisit);
                    iLastVisitID++;
                }
                else
                {
                    iLastVisitID++;
                }
                string value = String.Format("{0:D5}", iLastVisitID);

                sVisit = "VISIT/" + value;

                foreach (DataGridViewRow row in dgContactPerson.Rows)
                {
                    if (row.Cells[0].Value == null)
                    {
                        bContactPerson = false;
                    }
                }

                if (cmbCustomer.SelectedIndex != -1 && cmbCustomerType.SelectedIndex != -1 && cmbProductType.SelectedIndex != -1
                    && cmbOldNewCustomer.SelectedIndex != -1 && cmb8020.SelectedIndex != -1 && cmbLever.SelectedIndex != -1 && cmbLeadInput.SelectedIndex != -1 && bDate && bContactPerson)
                {
                    foreach (DataGridViewRow row in dgContactPerson.Rows)
                    {
                        GlobalClass.iSuccess = DAL.fnAddCustomerVisitEntry(Global.uINSERT, sVisit, cmbCustomer.Text, txtAddress.Text, cmbCustomerType.Text, row.Cells[0].Value.ToString(), row.Cells[1].Value.ToString(), row.Cells[2].Value.ToString(), row.Cells[3].Value.ToString(), txtWebSite.Text, dtpVisitDate.Text,
                            cmbProductType.Text, txtProductRequirement.Text, cmbLever.Text, cmb8020.Text, lblUserName.Text, cmbOldNewCustomer.Text, cmbLeadInput.Text, txtRemarks.Text);
                    }
                }
                else
                {
                    if (cmbCustomer.SelectedIndex == -1)
                    {
                        MessageBox.Show("Please select customer", "Error", 0, MessageBoxIcon.Error);
                        cmbCustomer.Focus();
                    }
                    else if (cmbCustomerType.SelectedIndex == -1)
                    {
                        MessageBox.Show("Please select customer type", "Error", 0, MessageBoxIcon.Error);
                        cmbCustomerType.Focus();
                    }
                    else if (!bContactPerson)
                    {
                        MessageBox.Show("Please add contact person name and  details ", "Error", 0, MessageBoxIcon.Error);
                        dgContactPerson.Focus();
                    }

                    else if (!bDate)
                    {
                        MessageBox.Show("Please select visit date ", "Error", 0, MessageBoxIcon.Error);
                        dtpVisitDate.Focus();
                    }
                    else if (cmbProductType.SelectedIndex == -1)
                    {
                        MessageBox.Show("Please select product type", "Error", 0, MessageBoxIcon.Error);
                        cmbProductType.Focus();
                    }
                    else if (cmbLever.SelectedIndex == -1)
                    {
                        MessageBox.Show("Please select lever ", "Error", 0, MessageBoxIcon.Error);
                        cmbLever.Focus();
                    }
                    else if (cmb8020.SelectedIndex == -1)
                    {
                        MessageBox.Show("Please select 80/20 Customer ", "Error", 0, MessageBoxIcon.Error);
                        cmb8020.Focus();
                    }
                    else if (cmbOldNewCustomer.SelectedIndex == -1)
                    {
                        MessageBox.Show("Please select Old/New Customer", "Error", 0, MessageBoxIcon.Error);
                        cmbOldNewCustomer.Focus();
                    }
                    else if (cmbLeadInput.SelectedIndex == -1)
                    {
                        MessageBox.Show("Please select lead input ", "Error", 0, MessageBoxIcon.Error);
                        cmbLeadInput.Focus();
                    }
                }
            }
            else
            {
                MessageBox.Show("Please add contact person details ", "Error", 0, MessageBoxIcon.Error);
                dgContactPerson.Focus();
            }
        }
        bool bDate = false;
        private void dtpVisitDate_ValueChanged(object sender, EventArgs e)
        {
            bDate = true;
        }
        bool bNoEmptyCells = false;
        private void btnAddContact_Click(object sender, EventArgs e)
        {
            if (dgContactPerson.Rows.Count > 0)
            {
                bNoEmptyCells = false;
                foreach (DataGridViewRow row in dgContactPerson.Rows)
                {
                    if (row.Cells[0].Value != null) // && !string.IsNullOrEmpty(txtprojectduration .Text) 
                    {
                        bNoEmptyCells = true;
                    }
                    else
                    {
                        bNoEmptyCells = false;
                        MessageBox.Show("Please enter contact person Details", "Error", 0, MessageBoxIcon.Error);
                        break;
                    }
                }
                if (bNoEmptyCells)
                {
                    dgContactPerson.Rows.Add();
                }
            }
            else
            {
                dgContactPerson.Rows.Add();
            }
        }

        private void cmbCustomer_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataView dv = new DataView(dtCustomerList);
            dv.RowFilter = "CustomerName like '" + cmbCustomer.Text.Trim() + "%'";
            DataTable dt = new DataTable();
            dt = dv.ToTable();
            if (dt.Rows.Count > 0)
            {
                txtAddress.Text = dt.Rows[0]["Address1"].ToString() + dt.Rows[0]["Address2"].ToString() + dt.Rows[0]["Address3"].ToString();
            }
        }
        public DataGridView.HitTestInfo hitTestInfo { get; set; }
        private void dgContactPerson_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                hitTestInfo = dgContactPerson.HitTest(e.X, e.Y);
                if (hitTestInfo.Type == DataGridViewHitTestType.Cell)
                    dgContactPerson.BeginEdit(true);
                else
                    dgContactPerson.EndEdit();
            }
        }

        private void dgContactPerson_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                if (dgContactPerson.CurrentRow.Cells[0].Value != null)
                {
                    DialogResult DR = MessageBox.Show("Do you want to delete selected Contact person?  " + dgContactPerson.CurrentRow.Cells[0].Value.ToString() + "", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (DR == DialogResult.Yes)
                    {
                        dgContactPerson.Rows.RemoveAt(dgContactPerson.Rows.IndexOf(dgContactPerson.CurrentRow));
                    }
                }
                else
                {
                    dgContactPerson.Rows.RemoveAt(dgContactPerson.Rows.IndexOf(dgContactPerson.CurrentRow));
                }
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmViewCustomerVisit CustomerVisit = new frmViewCustomerVisit();
            CustomerVisit.Show();
        }

        private void frmCustomerVisit_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            form.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            form.Show();
        }

    }
}
