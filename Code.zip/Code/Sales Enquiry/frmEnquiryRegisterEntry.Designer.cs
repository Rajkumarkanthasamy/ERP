﻿namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    partial class frmEnquiryRegisterEntry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEnquiryRegisterEntry));
            this.cmbDealer = new System.Windows.Forms.ComboBox();
            this.cmbCountryName = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtPrepareBy = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbCustomer = new System.Windows.Forms.ComboBox();
            this.lblCustomerName = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtContactPerson = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.cmbProdcutType = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cmbRegion = new System.Windows.Forms.ComboBox();
            this.txtExpectedTime = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.cmbOrderRecievedYear = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.cmbLeadInput = new System.Windows.Forms.ComboBox();
            this.cmbCustomerBase = new System.Windows.Forms.ComboBox();
            this.cmbStandardCustom = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtCustomerType = new System.Windows.Forms.TextBox();
            this.cmbOrderRecievedMonth = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnGenarateQuote = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnClearAll = new System.Windows.Forms.Button();
            this.txtCusCode = new System.Windows.Forms.TextBox();
            this.txtEmailID = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dtpEnquiryDate = new System.Windows.Forms.DateTimePicker();
            this.txtEnquiryNumber = new System.Windows.Forms.TextBox();
            this.lblEnquiryReg = new System.Windows.Forms.Label();
            this.txtDepartment1 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.txtContactNumber1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cmbReferenceRegister = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // cmbDealer
            // 
            this.cmbDealer.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbDealer.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDealer.FormattingEnabled = true;
            this.cmbDealer.Items.AddRange(new object[] {
            "Aimil",
            "GT Instruments",
            "Instron",
            "SNiP"});
            this.cmbDealer.Location = new System.Drawing.Point(784, 259);
            this.cmbDealer.Name = "cmbDealer";
            this.cmbDealer.Size = new System.Drawing.Size(361, 27);
            this.cmbDealer.TabIndex = 133;
            // 
            // cmbCountryName
            // 
            this.cmbCountryName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCountryName.DropDownHeight = 60;
            this.cmbCountryName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCountryName.DropDownWidth = 150;
            this.cmbCountryName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCountryName.FormattingEnabled = true;
            this.cmbCountryName.IntegralHeight = false;
            this.cmbCountryName.ItemHeight = 19;
            this.cmbCountryName.Location = new System.Drawing.Point(784, 76);
            this.cmbCountryName.Name = "cmbCountryName";
            this.cmbCountryName.Size = new System.Drawing.Size(112, 27);
            this.cmbCountryName.TabIndex = 132;
            this.cmbCountryName.SelectedIndexChanged += new System.EventHandler(this.cmbCountryName_SelectedIndexChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label19.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label19.Location = new System.Drawing.Point(706, 79);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(72, 19);
            this.label19.TabIndex = 129;
            this.label19.Text = "Country :";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label20.Location = new System.Drawing.Point(717, 264);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(61, 19);
            this.label20.TabIndex = 128;
            this.label20.Text = "Dealer :";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label22.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label22.Location = new System.Drawing.Point(902, 79);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(119, 19);
            this.label22.TabIndex = 127;
            this.label22.Text = "Region in India :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(677, 457);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 19);
            this.label1.TabIndex = 142;
            this.label1.Text = "Prepared By :";
            // 
            // txtPrepareBy
            // 
            this.txtPrepareBy.Enabled = false;
            this.txtPrepareBy.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrepareBy.Location = new System.Drawing.Point(784, 454);
            this.txtPrepareBy.Name = "txtPrepareBy";
            this.txtPrepareBy.Size = new System.Drawing.Size(361, 27);
            this.txtPrepareBy.TabIndex = 143;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(32, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(130, 19);
            this.label2.TabIndex = 144;
            this.label2.Text = "Lead/input from :";
            // 
            // cmbCustomer
            // 
            this.cmbCustomer.DropDownHeight = 100;
            this.cmbCustomer.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCustomer.FormattingEnabled = true;
            this.cmbCustomer.IntegralHeight = false;
            this.cmbCustomer.ItemHeight = 19;
            this.cmbCustomer.Location = new System.Drawing.Point(168, 122);
            this.cmbCustomer.Name = "cmbCustomer";
            this.cmbCustomer.Size = new System.Drawing.Size(404, 27);
            this.cmbCustomer.TabIndex = 147;
            this.cmbCustomer.SelectedIndexChanged += new System.EventHandler(this.cmbCustomer_SelectedIndexChanged);
            // 
            // lblCustomerName
            // 
            this.lblCustomerName.AutoSize = true;
            this.lblCustomerName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblCustomerName.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblCustomerName.Location = new System.Drawing.Point(36, 125);
            this.lblCustomerName.Name = "lblCustomerName";
            this.lblCustomerName.Size = new System.Drawing.Size(126, 19);
            this.lblCustomerName.TabIndex = 146;
            this.lblCustomerName.Text = "Customer Name :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(43, 172);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(119, 19);
            this.label7.TabIndex = 149;
            this.label7.Text = "Customer Type :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(45, 216);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(117, 19);
            this.label8.TabIndex = 151;
            this.label8.Text = "Customer Base :";
            // 
            // txtContactPerson
            // 
            this.txtContactPerson.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtContactPerson.Location = new System.Drawing.Point(168, 262);
            this.txtContactPerson.Name = "txtContactPerson";
            this.txtContactPerson.Size = new System.Drawing.Size(343, 26);
            this.txtContactPerson.TabIndex = 152;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(41, 269);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(121, 19);
            this.label10.TabIndex = 154;
            this.label10.Text = "Contact Person :";
            // 
            // cmbProdcutType
            // 
            this.cmbProdcutType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProdcutType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProdcutType.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProdcutType.FormattingEnabled = true;
            this.cmbProdcutType.Items.AddRange(new object[] {
            "UTM",
            "STS",
            "DTS",
            "LFS",
            "TGT",
            "FSW",
            "ShakeTable",
            "CustomRigs",
            "Others"});
            this.cmbProdcutType.Location = new System.Drawing.Point(784, 166);
            this.cmbProdcutType.Name = "cmbProdcutType";
            this.cmbProdcutType.Size = new System.Drawing.Size(361, 27);
            this.cmbProdcutType.TabIndex = 157;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label11.Location = new System.Drawing.Point(669, 169);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(109, 19);
            this.label11.TabIndex = 156;
            this.label11.Text = "Product Type :";
            // 
            // cmbRegion
            // 
            this.cmbRegion.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRegion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRegion.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbRegion.FormattingEnabled = true;
            this.cmbRegion.Items.AddRange(new object[] {
            "East",
            "North",
            "South",
            "West"});
            this.cmbRegion.Location = new System.Drawing.Point(1019, 76);
            this.cmbRegion.Name = "cmbRegion";
            this.cmbRegion.Size = new System.Drawing.Size(126, 27);
            this.cmbRegion.TabIndex = 158;
            // 
            // txtExpectedTime
            // 
            this.txtExpectedTime.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtExpectedTime.Location = new System.Drawing.Point(784, 308);
            this.txtExpectedTime.Name = "txtExpectedTime";
            this.txtExpectedTime.Size = new System.Drawing.Size(361, 26);
            this.txtExpectedTime.TabIndex = 165;
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(602, 308);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(176, 45);
            this.label15.TabIndex = 166;
            this.label15.Text = "Expected Time for offer \r\nPreparation :";
            this.label15.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label24.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label24.Location = new System.Drawing.Point(609, 360);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(169, 19);
            this.label24.TabIndex = 175;
            this.label24.Text = "Order received month :";
            // 
            // cmbOrderRecievedYear
            // 
            this.cmbOrderRecievedYear.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbOrderRecievedYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbOrderRecievedYear.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbOrderRecievedYear.FormattingEnabled = true;
            this.cmbOrderRecievedYear.Items.AddRange(new object[] {
            "2015",
            "2016",
            "2017",
            "2018",
            "2019",
            "2020",
            "2021",
            "2022",
            "2023",
            "2024",
            "2025",
            "2026",
            "2027",
            "2028"});
            this.cmbOrderRecievedYear.Location = new System.Drawing.Point(784, 405);
            this.cmbOrderRecievedYear.Name = "cmbOrderRecievedYear";
            this.cmbOrderRecievedYear.Size = new System.Drawing.Size(361, 27);
            this.cmbOrderRecievedYear.TabIndex = 178;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label25.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label25.Location = new System.Drawing.Point(625, 407);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(153, 19);
            this.label25.TabIndex = 177;
            this.label25.Text = "Order received year :";
            // 
            // cmbLeadInput
            // 
            this.cmbLeadInput.DropDownHeight = 100;
            this.cmbLeadInput.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbLeadInput.FormattingEnabled = true;
            this.cmbLeadInput.IntegralHeight = false;
            this.cmbLeadInput.ItemHeight = 19;
            this.cmbLeadInput.Items.AddRange(new object[] {
            "Telephone",
            "E-mail",
            "Tender",
            "Customer Reference",
            "Dealer",
            "Distributor",
            "Direct",
            "Advertisement",
            "linkedin",
            "Conference/Event"});
            this.cmbLeadInput.Location = new System.Drawing.Point(168, 76);
            this.cmbLeadInput.Name = "cmbLeadInput";
            this.cmbLeadInput.Size = new System.Drawing.Size(343, 27);
            this.cmbLeadInput.TabIndex = 181;
            // 
            // cmbCustomerBase
            // 
            this.cmbCustomerBase.DropDownHeight = 100;
            this.cmbCustomerBase.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCustomerBase.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCustomerBase.FormattingEnabled = true;
            this.cmbCustomerBase.IntegralHeight = false;
            this.cmbCustomerBase.ItemHeight = 19;
            this.cmbCustomerBase.Items.AddRange(new object[] {
            "New",
            "Old"});
            this.cmbCustomerBase.Location = new System.Drawing.Point(168, 216);
            this.cmbCustomerBase.Name = "cmbCustomerBase";
            this.cmbCustomerBase.Size = new System.Drawing.Size(343, 27);
            this.cmbCustomerBase.TabIndex = 183;
            // 
            // cmbStandardCustom
            // 
            this.cmbStandardCustom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbStandardCustom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStandardCustom.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbStandardCustom.FormattingEnabled = true;
            this.cmbStandardCustom.Items.AddRange(new object[] {
            "Standard",
            "Custom"});
            this.cmbStandardCustom.Location = new System.Drawing.Point(784, 210);
            this.cmbStandardCustom.Name = "cmbStandardCustom";
            this.cmbStandardCustom.Size = new System.Drawing.Size(361, 27);
            this.cmbStandardCustom.TabIndex = 185;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label23.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label23.Location = new System.Drawing.Point(636, 216);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(142, 19);
            this.label23.TabIndex = 184;
            this.label23.Text = "Standard/ Custom :";
            // 
            // txtCustomerType
            // 
            this.txtCustomerType.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerType.Location = new System.Drawing.Point(168, 169);
            this.txtCustomerType.Name = "txtCustomerType";
            this.txtCustomerType.Size = new System.Drawing.Size(343, 27);
            this.txtCustomerType.TabIndex = 190;
            // 
            // cmbOrderRecievedMonth
            // 
            this.cmbOrderRecievedMonth.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbOrderRecievedMonth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbOrderRecievedMonth.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbOrderRecievedMonth.FormattingEnabled = true;
            this.cmbOrderRecievedMonth.Items.AddRange(new object[] {
            "JAN",
            "FEB",
            "MAR",
            "APR",
            "MAY",
            "JUN",
            "JUL",
            "AUG",
            "SEP",
            "OCT",
            "NOV",
            "DEC"});
            this.cmbOrderRecievedMonth.Location = new System.Drawing.Point(784, 356);
            this.cmbOrderRecievedMonth.Name = "cmbOrderRecievedMonth";
            this.cmbOrderRecievedMonth.Size = new System.Drawing.Size(361, 27);
            this.cmbOrderRecievedMonth.TabIndex = 191;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Blue;
            this.label14.Location = new System.Drawing.Point(480, 9);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(199, 33);
            this.label14.TabIndex = 193;
            this.label14.Text = "Enquiry Register";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnGenarateQuote);
            this.groupBox2.Controls.Add(this.btnExit);
            this.groupBox2.Controls.Add(this.btnSave);
            this.groupBox2.Controls.Add(this.btnSearch);
            this.groupBox2.Controls.Add(this.btnClearAll);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox2.Location = new System.Drawing.Point(98, 570);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1073, 63);
            this.groupBox2.TabIndex = 194;
            this.groupBox2.TabStop = false;
            // 
            // btnGenarateQuote
            // 
            this.btnGenarateQuote.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnGenarateQuote.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnGenarateQuote.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenarateQuote.Location = new System.Drawing.Point(100, 12);
            this.btnGenarateQuote.Name = "btnGenarateQuote";
            this.btnGenarateQuote.Size = new System.Drawing.Size(145, 45);
            this.btnGenarateQuote.TabIndex = 11;
            this.btnGenarateQuote.Text = "Genarate Quote";
            this.btnGenarateQuote.UseVisualStyleBackColor = false;
            this.btnGenarateQuote.Visible = false;
            this.btnGenarateQuote.Click += new System.EventHandler(this.btnGenarateQuote_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(869, 14);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(102, 45);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(325, 14);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(102, 45);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSearch.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(494, 12);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(102, 45);
            this.btnSearch.TabIndex = 8;
            this.btnSearch.Text = "View";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnClearAll
            // 
            this.btnClearAll.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnClearAll.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnClearAll.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearAll.Location = new System.Drawing.Point(686, 14);
            this.btnClearAll.Name = "btnClearAll";
            this.btnClearAll.Size = new System.Drawing.Size(102, 45);
            this.btnClearAll.TabIndex = 7;
            this.btnClearAll.Text = "Clear All";
            this.btnClearAll.UseVisualStyleBackColor = false;
            this.btnClearAll.Click += new System.EventHandler(this.btnClearAll_Click);
            // 
            // txtCusCode
            // 
            this.txtCusCode.Enabled = false;
            this.txtCusCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCusCode.Location = new System.Drawing.Point(578, 125);
            this.txtCusCode.Name = "txtCusCode";
            this.txtCusCode.Size = new System.Drawing.Size(19, 27);
            this.txtCusCode.TabIndex = 197;
            this.txtCusCode.Visible = false;
            // 
            // txtEmailID
            // 
            this.txtEmailID.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtEmailID.Location = new System.Drawing.Point(168, 306);
            this.txtEmailID.Name = "txtEmailID";
            this.txtEmailID.Size = new System.Drawing.Size(343, 26);
            this.txtEmailID.TabIndex = 198;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(88, 308);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 19);
            this.label3.TabIndex = 199;
            this.label3.Text = "Email ID :";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(665, 122);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(113, 22);
            this.label6.TabIndex = 201;
            this.label6.Text = "Enquiry Date :";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // dtpEnquiryDate
            // 
            this.dtpEnquiryDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpEnquiryDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpEnquiryDate.Location = new System.Drawing.Point(784, 114);
            this.dtpEnquiryDate.Name = "dtpEnquiryDate";
            this.dtpEnquiryDate.Size = new System.Drawing.Size(361, 27);
            this.dtpEnquiryDate.TabIndex = 200;
            this.dtpEnquiryDate.ValueChanged += new System.EventHandler(this.dtpEnquiryDate_ValueChanged);
            // 
            // txtEnquiryNumber
            // 
            this.txtEnquiryNumber.Enabled = false;
            this.txtEnquiryNumber.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEnquiryNumber.Location = new System.Drawing.Point(784, 495);
            this.txtEnquiryNumber.Name = "txtEnquiryNumber";
            this.txtEnquiryNumber.Size = new System.Drawing.Size(361, 27);
            this.txtEnquiryNumber.TabIndex = 203;
            this.txtEnquiryNumber.Visible = false;
            // 
            // lblEnquiryReg
            // 
            this.lblEnquiryReg.AutoSize = true;
            this.lblEnquiryReg.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblEnquiryReg.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblEnquiryReg.Location = new System.Drawing.Point(648, 498);
            this.lblEnquiryReg.Name = "lblEnquiryReg";
            this.lblEnquiryReg.Size = new System.Drawing.Size(130, 19);
            this.lblEnquiryReg.TabIndex = 202;
            this.lblEnquiryReg.Text = "Enquiry Number :";
            this.lblEnquiryReg.Visible = false;
            // 
            // txtDepartment1
            // 
            this.txtDepartment1.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtDepartment1.Location = new System.Drawing.Point(168, 400);
            this.txtDepartment1.Name = "txtDepartment1";
            this.txtDepartment1.Size = new System.Drawing.Size(343, 26);
            this.txtDepartment1.TabIndex = 206;
            this.txtDepartment1.Text = "NIL";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label34.ForeColor = System.Drawing.Color.Black;
            this.label34.Location = new System.Drawing.Point(60, 402);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(100, 19);
            this.label34.TabIndex = 209;
            this.label34.Text = "Department :";
            // 
            // txtContactNumber1
            // 
            this.txtContactNumber1.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtContactNumber1.Location = new System.Drawing.Point(168, 353);
            this.txtContactNumber1.Name = "txtContactNumber1";
            this.txtContactNumber1.Size = new System.Drawing.Size(343, 26);
            this.txtContactNumber1.TabIndex = 205;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(30, 355);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(130, 19);
            this.label5.TabIndex = 208;
            this.label5.Text = "Contact Number :";
            // 
            // txtAddress
            // 
            this.txtAddress.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtAddress.Location = new System.Drawing.Point(168, 445);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(343, 77);
            this.txtAddress.TabIndex = 204;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(89, 447);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(71, 19);
            this.label9.TabIndex = 207;
            this.label9.Text = "Address :";
            // 
            // cmbReferenceRegister
            // 
            this.cmbReferenceRegister.DropDownHeight = 100;
            this.cmbReferenceRegister.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbReferenceRegister.FormattingEnabled = true;
            this.cmbReferenceRegister.IntegralHeight = false;
            this.cmbReferenceRegister.ItemHeight = 19;
            this.cmbReferenceRegister.Location = new System.Drawing.Point(1019, 17);
            this.cmbReferenceRegister.Name = "cmbReferenceRegister";
            this.cmbReferenceRegister.Size = new System.Drawing.Size(244, 27);
            this.cmbReferenceRegister.TabIndex = 211;
            this.cmbReferenceRegister.SelectedIndexChanged += new System.EventHandler(this.cmbReferenceRegister_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(780, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(235, 19);
            this.label4.TabIndex = 210;
            this.label4.Text = "Load from Old Enquiry Register  :";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // frmEnquiryRegisterEntry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1338, 643);
            this.Controls.Add(this.cmbReferenceRegister);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtDepartment1);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.txtContactNumber1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtEnquiryNumber);
            this.Controls.Add(this.lblEnquiryReg);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dtpEnquiryDate);
            this.Controls.Add(this.txtEmailID);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtCusCode);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.cmbOrderRecievedMonth);
            this.Controls.Add(this.txtCustomerType);
            this.Controls.Add(this.cmbStandardCustom);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.cmbCustomerBase);
            this.Controls.Add(this.cmbLeadInput);
            this.Controls.Add(this.cmbOrderRecievedYear);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.txtExpectedTime);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.cmbRegion);
            this.Controls.Add(this.cmbProdcutType);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtContactPerson);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cmbCustomer);
            this.Controls.Add(this.lblCustomerName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtPrepareBy);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbDealer);
            this.Controls.Add(this.cmbCountryName);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label22);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmEnquiryRegisterEntry";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Enquiry Register";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmEnquiryRegisterEntry_FormClosing);
            this.Load += new System.EventHandler(this.frmEnquiryRegisterEntry_Load);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbDealer;
        private System.Windows.Forms.ComboBox cmbCountryName;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPrepareBy;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbCustomer;
        private System.Windows.Forms.Label lblCustomerName;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtContactPerson;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cmbProdcutType;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cmbRegion;
        private System.Windows.Forms.TextBox txtExpectedTime;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox cmbOrderRecievedYear;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox cmbLeadInput;
        private System.Windows.Forms.ComboBox cmbCustomerBase;
        private System.Windows.Forms.ComboBox cmbStandardCustom;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtCustomerType;
        private System.Windows.Forms.ComboBox cmbOrderRecievedMonth;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnClearAll;
        private System.Windows.Forms.TextBox txtCusCode;
        private System.Windows.Forms.TextBox txtEmailID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnGenarateQuote;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dtpEnquiryDate;
        private System.Windows.Forms.TextBox txtEnquiryNumber;
        private System.Windows.Forms.Label lblEnquiryReg;
        private System.Windows.Forms.TextBox txtDepartment1;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtContactNumber1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmbReferenceRegister;
        private System.Windows.Forms.Label label4;
    }
}