﻿using System;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using EXCEL = Microsoft.Office.Interop.Excel;

namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    public partial class frmServicequote : Form
    {
        public frmServicequote()
        {
            InitializeComponent();
            PaymentCode.SelectedIndexChanged += new EventHandler(PaymentCode_SelectedIndexChanged);
        }
        frmForm2 form = new frmForm2();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        // frmSalesHome SalesHome = new frmSalesHome();
        DataTable dtProjectList = new DataTable();
        DataTable dtCustomerList = new DataTable();


        DataTable dtOfferItemDeatils = new DataTable();
        DataRow DR1;
        int iSLNo = 0;
        private void btnAddNewRow_Click(object sender, EventArgs e)
        {
            fnRowCheck();
            if (bValidattion == false)
            {
                if (dtOfferItemDeatils.Rows.Count == 0)
                {
                    dtOfferItemDeatils = DAL.fnServiceQuoteNumber(0, "new", "").Tables[0];
                }

                // DR1 = dtOfferItemDeatils.NewRow();

                // dgvQuoteItems.Rows.Add();
                //  iSLNo++;
                //if (dtOfferItemDeatils.Rows.Count == 0)
                //{

                //       DR1[0] = iSLNo;
                //    DR1[1] = "";
                //}
                //else if (dgvNVLAP.Rows.Count == 1)
                //{
                //    DR1[0] = iSLNo;
                //    DR1[1] = "";
                //}

                dtOfferItemDeatils.Rows.Add(dgvNVLAP.Rows.Count + 1, "");
                dgvNVLAP.DataSource = dtOfferItemDeatils;

            }
        }
        bool bValidattion = false;
        private void fnRowCheck()
        {
            bValidattion = false;
            foreach (DataGridViewRow row in dgvNVLAP.Rows)
            {

                // if (row.Cells[1].Value != null)
                {

                    if (string.IsNullOrEmpty(row.Cells[1].Value.ToString().Trim()))
                    {
                        MessageBox.Show("NVLAP Calibrations details not entered in list.", "Error", 0, MessageBoxIcon.Error);
                        bValidattion = true;
                        break;
                    }
                }
                //else
                //{
                //    MessageBox.Show("Specifications not entered in list.", "Error", 0, MessageBoxIcon.Error);
                //    bValidattion = true;
                //    break;
                //}
            }
        }

        bool bContractValidattion = false;
        private void fnContractRowCheck()
        {
            bContractValidattion = false;
            foreach (DataGridViewRow row in dgvContract.Rows)
            {

                if (Convert.ToInt32(row.Cells[0].Value) == 0)
                {

                    // if (string.IsNullOrEmpty(row.Cells[0].Value.ToString().Trim()))
                    {
                        MessageBox.Show("Enter contract value of 1st year", "Error", 0, MessageBoxIcon.Error);
                        bContractValidattion = true;
                        break;
                    }
                }
                //else if (Convert.ToInt32(row.Cells[1].Value) == 0)
                //{

                //    //if (string.IsNullOrEmpty(row.Cells[1].Value.ToString().Trim()))
                //    {
                //        MessageBox.Show("Enter contract value", "Error", 0, MessageBoxIcon.Error);
                //        bContractValidattion = true;
                //        break;
                //    }
                //}
                else if (string.IsNullOrEmpty(row.Cells[5].Value.ToString()))
                {

                    //if (string.IsNullOrEmpty(row.Cells[2].Value.ToString().Trim()))
                    {
                        MessageBox.Show("Enter scope", "Error", 0, MessageBoxIcon.Error);
                        bContractValidattion = true;
                        break;
                    }
                }
                //else
                //{
                //    MessageBox.Show("Specifications not entered in list.", "Error", 0, MessageBoxIcon.Error);
                //    bValidattion = true;
                //    break;
                //}
            }
        }

        DataTable dtServiceQuoteNumber = new DataTable();
        private void cmbSelectQuoteType_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbQuotationNumber.Items.Clear();
            cmbQuotationNumber.SelectedIndex = -1;
            cmbQuotationNumber.Text = "";
            cmbRevisionNumber.Items.Clear();
            cmbRevisionNumber.SelectedIndex = -1;
            if (cmbSelectQuoteType.SelectedIndex < 0)
            {
                pnQuotationNumber.Visible = false;
                //btnPrintRIQuote.Enabled = false;
            }
            if (cmbSelectQuoteType.SelectedIndex == 0)
            {
                pnQuotationNumber.Visible = false;
                btnGenarateQuote.Text = "Generate Quote";
                btnGenRIVQuote.Text = "Generate Quote";
                btnCALGenerateQuote.Text = "Generate Quote";
                btnGeneratePI.Text = "Generate PI";
                btnPrintRIQuote.Enabled = false;
                btnCALPrintQuote.Enabled = false;
                btnFinQuote.Enabled = false;
                btnPrintPI.Enabled = false;
                if (cmbQuotetype.SelectedIndex == 0)
                {
                    tabAMC.Enabled = true;
                }
                else if (cmbQuotetype.SelectedIndex == 1)
                {
                    tabCalibration.Enabled = true;
                }
                else if (cmbQuotetype.SelectedIndex == 2)
                {
                    tabRI.Enabled = true;
                }
                else if (cmbQuotetype.SelectedIndex == 3)
                {
                    tabRI.Enabled = true;
                }
                else if (cmbQuotetype.SelectedIndex == 4)
                {
                    tabPI.Enabled = true;
                }
            }
            else if (cmbSelectQuoteType.SelectedIndex == 1 || cmbSelectQuoteType.SelectedIndex == 2)
            {
                pnQuotationNumber.Visible = true;
                btnCALPrintQuote.Enabled = true;
                btnPrintRIQuote.Enabled = true;
                btnFinQuote.Enabled = true;

                if (cmbSelectQuoteType.SelectedIndex == 1)
                {
                    btnGenarateQuote.Text = "Update Quote";
                    btnGenRIVQuote.Text = "Update Quote";
                    btnCALGenerateQuote.Text = "Update Quote";
                    btnGeneratePI.Text = "Update PI";
                }
                else if (cmbSelectQuoteType.SelectedIndex == 2)
                {
                    btnGenarateQuote.Text = "Revise Quote";
                    btnGenRIVQuote.Text = "Revise Quote";
                    btnCALGenerateQuote.Text = "Revise Quote";
                    btnGeneratePI.Text = "Update PI";
                }

                cmbQuotationNumber.Items.Clear();
                cmbQuotationNumber.Text = "";
                if (cmbQuotetype.SelectedIndex == 0)
                {
                    dtServiceQuoteNumber = DAL.fnServiceQuotationNumberLoadData(1, cmbQuotetype.Text, "").Tables[0];

                    if (dtServiceQuoteNumber.Rows.Count > 0)
                    {
                        foreach (DataRow DR in dtServiceQuoteNumber.Rows)
                        {
                            if (!cmbQuotationNumber.Items.Contains(DR["QuotationNumber"].ToString()))
                                cmbQuotationNumber.Items.Add(DR["QuotationNumber"].ToString());
                        }
                    }
                    tabAMC.Enabled = true;

                }
                else if (cmbQuotetype.SelectedIndex == 1)
                {
                    dtServiceQuoteNumber = DAL.fnServiceQuotationNumberLoadData(1, cmbQuotetype.Text, "").Tables[0];

                    if (dtServiceQuoteNumber.Rows.Count > 0)
                    {
                        foreach (DataRow DR in dtServiceQuoteNumber.Rows)
                        {
                            if (!cmbQuotationNumber.Items.Contains(DR["QuotationNumber"].ToString()))
                                cmbQuotationNumber.Items.Add(DR["QuotationNumber"].ToString());
                        }
                    }

                    tabCalibration.Enabled = true;
                }
                else if (cmbQuotetype.SelectedIndex == 2)
                {
                    dtServiceQuoteNumber = DAL.fnServiceQuotationNumberLoadData(6, cmbQuotetype.Text, "").Tables[0];

                    if (dtServiceQuoteNumber.Rows.Count > 0)
                    {
                        foreach (DataRow DR in dtServiceQuoteNumber.Rows)
                        {
                            if (!cmbQuotationNumber.Items.Contains(DR["QuotationNumber"].ToString()))
                                cmbQuotationNumber.Items.Add(DR["QuotationNumber"].ToString());
                        }
                    }
                    tabRI.Enabled = true;
                }
                else if (cmbQuotetype.SelectedIndex == 3)
                {
                    dtServiceQuoteNumber = DAL.fnServiceQuotationNumberLoadData(6, cmbQuotetype.Text, "").Tables[0];

                    if (dtServiceQuoteNumber.Rows.Count > 0)
                    {
                        foreach (DataRow DR in dtServiceQuoteNumber.Rows)
                        {
                            if (!cmbQuotationNumber.Items.Contains(DR["QuotationNumber"].ToString()))
                                cmbQuotationNumber.Items.Add(DR["QuotationNumber"].ToString());
                        }
                    }
                    tabRI.Enabled = true;
                }

                else if (cmbQuotetype.SelectedIndex == 4)
                {
                    dtServiceQuoteNumber = DAL.fnServiceQuotationNumberLoadData(7, "", "").Tables[0];

                    if (dtServiceQuoteNumber.Rows.Count > 0)
                    {
                        foreach (DataRow DR in dtServiceQuoteNumber.Rows)
                        {
                            if (!cmbQuotationNumber.Items.Contains(DR["PINumber"].ToString()))
                                cmbQuotationNumber.Items.Add(DR["PINumber"].ToString());
                        }
                    }
                    tabPI.Enabled = true;
                }

            }

        }
        DataTable dtOfferContractDeatils = new DataTable();
        DataTable dtNewServiceQuoteContractValue = new DataTable();
        DataTable dtCeastQuoteContractValue = new DataTable();
        // DataTable dtCustomerList = new DataTable();
        private void frmServicequote_Load(object sender, EventArgs e)
        {
            dtCustomerList = DAL.fnPaymentterm(0, null).Tables[0];
            foreach (DataRow DR in dtCustomerList.Rows)
            {
                if (!PaymentCode.Items.Contains(DR["PaymentCode"].ToString()))
                    PaymentCode.Items.Add(DR["PaymentCode"].ToString());
            }
            // oDateTimePicker.Value = oDateTimePicker.Value.AddDays(-365);
            //dtNewServiceQuoteContractValue = DAL.fnServiceQuoteNumber(1, "new", "").Tables[0];
            //Transpose(dtNewServiceQuoteContractValue);

            lblQuoteBy.Text = login.GetUserDetails[2];
            lblCALQuoteby.Text = login.GetUserDetails[2];
            lblRIQuoteBy.Text = login.GetUserDetails[2];
            lblPIBY.Text = login.GetUserDetails[2];
            dtOfferContractDeatils = DAL.fnServiceQuoteNumber(2, "new", "").Tables[0];
            dgvContract.AutoGenerateColumns = false;
            dgvContract.DataSource = dtOfferContractDeatils;

            dtCeastQuoteContractValue = DAL.fnServiceQuoteNumber(4, "new", "").Tables[0];
            dgvCeastContract.AutoGenerateColumns = false;
            dgvCeastContract.DataSource = dtCeastQuoteContractValue;

            dtCustomerList = DAL.fnCustomerList(5, null).Tables[0];
            foreach (DataRow DR in dtCustomerList.Rows)
            {
                if (!cmbCustomer.Items.Contains(DR["CustomerName"].ToString()))
                    cmbCustomer.Items.Add(DR["CustomerName"].ToString());
                if (!cmbRICustomer.Items.Contains(DR["CustomerName"].ToString()))
                    cmbRICustomer.Items.Add(DR["CustomerName"].ToString());
                if (!cmbCALCustomer.Items.Contains(DR["CustomerName"].ToString()))
                    cmbCALCustomer.Items.Add(DR["CustomerName"].ToString());

                if (!cmbPICustomer.Items.Contains(DR["CustomerName"].ToString()))
                    cmbPICustomer.Items.Add(DR["CustomerName"].ToString());
            }
        }
        DataTable dtNewContract = new DataTable();
        private DataTable Transpose(DataTable dt)
        {
            dtNewContract = new DataTable();

            //adding columns    
            for (int i = 0; i <= dt.Rows.Count; i++)
            {
                dtNewContract.Columns.Add(i.ToString());
            }



            //Changing Column Captions: 
            dtNewContract.Columns[0].ColumnName = " ";

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //For dateTime columns use like below
                dtNewContract.Columns[i + 1].ColumnName = dt.Rows[i].ItemArray[0].ToString();
                //Else just assign the ItermArry[0] to the columnName prooperty

            }
            dtNewContract.AcceptChanges();
            //Adding Row Data
            for (int k = 1; k < dt.Columns.Count; k++)
            {
                DataRow r = dtNewContract.NewRow();
                r[0] = dt.Columns[k].ToString();
                for (int j = 1; j <= dt.Rows.Count; j++)
                    r[j] = dt.Rows[j - 1][k];
                dtNewContract.Rows.Add(r);
            }
            dtNewContract.Columns.Add("ContractValue");
            dtNewContract.Columns.Add("Scope");
            dtNewContract.Rows.Clear();
            dtNewContract.AcceptChanges();
            return dtNewContract;
        }

        private void frmServicequote_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (GlobalClass.fnMessageResult() == Global.sCLOSE_MESSAGE_RESULT_YES)
            {
                this.Hide();
                form.Show();
            }
            else
            {
                e.Cancel = true;
            }
        }

        private void oDateTimePicker_CloseUp(object sender, EventArgs e)
        {
        }

        private void oDateTimePicker_TabIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnAddrow_Click(object sender, EventArgs e)
        {
            fnContractRowCheck();
            if (!bContractValidattion)
            {
                dtOfferContractDeatils.Rows.Add(0, 0, 0, 0, 0, "");
                dgvContract.DataSource = dtOfferContractDeatils;
            }
        }
        bool bContractfromDate = false;
        bool bContracttoDate = false;
        private void btnStartQuote_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCusref.Text))
            {
                MessageBox.Show("Enter contract type", "Information", 0, MessageBoxIcon.Warning);
                txtCusref.Focus();
            }

            else if (string.IsNullOrEmpty(txtZone.Text))
            {
                MessageBox.Show("Enter zone number", "Information", 0, MessageBoxIcon.Warning);
                txtZone.Focus();
            }
            else if (string.IsNullOrEmpty(cmbCustomer.Text))
            {
                MessageBox.Show("Enter or select customer name", "Information", 0, MessageBoxIcon.Warning);
                cmbCustomer.Focus();
            }
            else if (string.IsNullOrEmpty(txtAddress.Text))
            {
                MessageBox.Show("Enter customer address", "Information", 0, MessageBoxIcon.Warning);
                txtAddress.Focus();
            }

            else if (string.IsNullOrEmpty(txtContactPerson.Text))
            {
                MessageBox.Show("Enter contact person", "Information", 0, MessageBoxIcon.Warning);
                txtContactPerson.Focus();
            }

            else if (string.IsNullOrEmpty(txtEmailID.Text))
            {
                MessageBox.Show("Enter customer email id", "Information", 0, MessageBoxIcon.Warning);
                txtEmailID.Focus();
            }

            else if (string.IsNullOrEmpty(txtContactNumber.Text))
            {
                MessageBox.Show("Enter contact number", "Information", 0, MessageBoxIcon.Warning);
                txtContactNumber.Focus();
            }

            else if (cmbEnquireCurrency.SelectedIndex == -1)
            {
                MessageBox.Show("Select quote currency to start quote ", "Information", 0, MessageBoxIcon.Warning);
                cmbEnquireCurrency.DroppedDown = true;
            }
            else if (cmbQuotetype.SelectedIndex == -1)
            {
                MessageBox.Show("Select quotation type to start quote ", "Information", 0, MessageBoxIcon.Warning);
                cmbQuotetype.DroppedDown = true;
            }
            else if (cmbQuoteCompany.SelectedIndex == -1)
            {
                MessageBox.Show("Select quotation for to start quote ", "Information", 0, MessageBoxIcon.Warning);
                cmbQuoteCompany.DroppedDown = true;
            }
            else if (string.IsNullOrEmpty(txtQuoteName.Text))
            {
                MessageBox.Show("Enter quote name", "Information", 0, MessageBoxIcon.Warning);
                txtQuoteName.Focus();
            }
            else if (!bContractfromDate)
            {
                MessageBox.Show("Select contract from date", "Information", 0, MessageBoxIcon.Warning);
                dtpContractfrom.Show();
                //dtpContractfrom.ShowUpDown = true;
            }
            else if (!bContracttoDate)
            {
                MessageBox.Show("Select contract to date", "Information", 0, MessageBoxIcon.Warning);
                dtpContractto.Show();
            }

            else if (string.IsNullOrEmpty(txtModelslno.Text))
            {
                MessageBox.Show("Enter model serial number", "Information", 0, MessageBoxIcon.Warning);
                txtQuoteName.Focus();
            }

            else if (cmbCeastAMC.SelectedIndex == -1)
            {
                MessageBox.Show("Select quotation for CEAST", "Information", 0, MessageBoxIcon.Warning);
                cmbCeastAMC.DroppedDown = true;
            }
            else
            {
                tabAMC.SelectTab(1);
            }


        }

        private void dtpContractfrom_ValueChanged(object sender, EventArgs e)
        {
            bContractfromDate = true;
            if (cmbContractYears.SelectedIndex >= 0)
            {
                // Update the "To" date based on the selected years
                dtpContractto.Value = dtpContractfrom.Value.AddYears(Convert.ToInt32(cmbContractYears.Text)).AddDays(-1);
            }
            else
            {
                MessageBox.Show("Select the contract years", "Error", 0, MessageBoxIcon.Error);
            }
        }

        private void dtpContractto_ValueChanged(object sender, EventArgs e)
        {
            bContracttoDate = true;
        }
        public DataGridView.HitTestInfo hitTestInfo { get; set; }
        private void dgvNVLAP_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                hitTestInfo = dgvNVLAP.HitTest(e.X, e.Y);
                if (hitTestInfo.Type == DataGridViewHitTestType.Cell)
                    dgvNVLAP.BeginEdit(true);
                else
                    dgvNVLAP.EndEdit();
            }
        }

        private void dgvContract_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                hitTestInfo = dgvContract.HitTest(e.X, e.Y);
                if (hitTestInfo.Type == DataGridViewHitTestType.Cell)
                    dgvContract.BeginEdit(true);
                else
                    dgvContract.EndEdit();
            }
        }

        private void btnGotoAddProducts_Click(object sender, EventArgs e)
        {
            tabAMC.SelectTab(2);
        }

        DataTable dtQuotationNumber = new DataTable();
        string sYear;
        string s4DigitNumber;
        string sQuotationNumber;
        int LastQuoteNumber = 0;
        private void btnGenarateQuote_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtpaymentterms.Text) && (dgvContract.Rows.Count > 0 || dgvCeastContract.Rows.Count > 0) && !string.IsNullOrEmpty(txtbreakdownvistcharges.Text))
            {
                if (btnGenarateQuote.Text == "Generate Quote")
                {
                    dtQuotationNumber = DAL.fnServiceQuotationNumber(0, cmbQuotetype.Text, null).Tables[0];
                    sYear = DateTime.Today.Year.ToString();
                    if (dtQuotationNumber.Rows.Count > 0)
                    {
                        if (!string.IsNullOrEmpty(dtQuotationNumber.Rows[0]["QuoteSlNo"].ToString()))
                        {
                            LastQuoteNumber = Convert.ToInt32(dtQuotationNumber.Rows[0]["QuoteSlNo"].ToString());
                            LastQuoteNumber++;
                        }
                        string value = String.Format("{0:D3}", LastQuoteNumber);
                        sQuotationNumber = (DateTime.Now.Year + "-SB" + value);


                        InsertQuote(Global.uINSERT, sQuotationNumber, "0");

                        cmbQuotationNumber.Items.Add(sQuotationNumber);
                        cmbRevisionNumber.Items.Add("0");
                        cmbQuotationNumber.SelectedIndex = 0;
                        cmbRevisionNumber.SelectedIndex = 0;
                        btnFinQuote_Click(sender, e);


                        MessageBox.Show("The new quotation '" + sQuotationNumber + "' genarated successfully ", "Success", 0, MessageBoxIcon.Information);
                        btnGenarateQuote.Enabled = false;
                    }
                }
                else if (btnGenarateQuote.Text == "Update Quote")
                {
                    DialogResult DR = MessageBox.Show("Do you want to update the selected quote " + cmbQuotationNumber.Text + " and revision number " + cmbRevisionNumber.Text + "", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (DR == DialogResult.Yes)
                    {
                        InsertQuote(Global.uUPDATE, cmbQuotationNumber.Text, cmbRevisionNumber.Text);
                    }
                    MessageBox.Show("The quotation '" + cmbQuotationNumber.Text + "' and revision number " + cmbRevisionNumber.Text + " updated successfully ", "Success", 0, MessageBoxIcon.Information);
                    btnGenarateQuote.Enabled = false;
                }
                else if (btnGenarateQuote.Text == "Revise Quote")
                {
                    DialogResult DR = MessageBox.Show("Do you want to revise the selected quote '" + cmbQuotationNumber.Text + "'", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (DR == DialogResult.Yes)
                    {
                        dtQuotationNumber = DAL.fnServiceQuotationNumber(3, cmbQuotationNumber.Text, cmbQuotetype.Text).Tables[0];
                        int NewRevisionNumber = 0;
                        if (dtQuotationNumber.Rows.Count > 0)
                        {
                            NewRevisionNumber = Convert.ToInt32(dtQuotationNumber.Rows[0]["RevisionNumber"].ToString());
                            NewRevisionNumber++;

                            InsertQuote(Global.uINSERT, cmbQuotationNumber.Text, NewRevisionNumber.ToString());
                            MessageBox.Show("The quotation ' " + cmbQuotationNumber.Text + " ' revised to ' " + NewRevisionNumber + " '  successfully ", "Success", 0, MessageBoxIcon.Information);
                            cmbRevisionNumber.Items.Add(NewRevisionNumber.ToString()).ToString();
                            cmbRevisionNumber.SelectedItem = NewRevisionNumber.ToString();
                        }
                    }
                }
            }
            else
            {
                if (string.IsNullOrEmpty(txtpaymentterms.Text))
                {
                    MessageBox.Show("Enter payment terms", "Information", 0, MessageBoxIcon.Warning);
                    txtpaymentterms.Focus();
                }
                else if (dgvContract.Rows.Count == 0 && cmbCeastAMC.SelectedIndex == 1)
                {
                    MessageBox.Show("Enter contract details", "Information", 0, MessageBoxIcon.Warning);
                    dgvContract.Focus();
                }
                else if (string.IsNullOrEmpty(txtbreakdownvistcharges.Text))
                {
                    MessageBox.Show("Enter breakdown visit charges", "Information", 0, MessageBoxIcon.Warning);
                    txtbreakdownvistcharges.Focus();
                }
                else if (cmbCeastAMC.SelectedIndex == 0 && dgvCeastContract.Rows.Count == 0)
                {
                    MessageBox.Show("Enter CEAST contract details", "Information", 0, MessageBoxIcon.Warning);
                    dgvContract.Focus();
                }
            }
        }

        private void InsertQuote(uint InsertorUpdate, string sQuotationNo, string RevisionNumber)
        {
            if (InsertorUpdate == Global.uINSERT)
            {
                GlobalClass.iStatus = DAL.fnAddServiceQuoteDetails(InsertorUpdate, sQuotationNo, RevisionNumber, txtCusref.Text, txtZone.Text, cmbCustomer.Text, txtAddress.Text,
                    txtContactPerson.Text, txtEmailID.Text, txtContactNumber.Text, txtTel.Text, txtQuoteName.Text, dtpContractfrom.Text, dtpContractto.Text, txtModelslno.Text,
                    "", comboPVPPM.Text, txtPVCV.Text, txtPVBV.Text, comboSVPPM.Text, txtSVCV.Text, txtSVBV.Text, txtbreakdownvistcharges.Text, txtpaymentterms.Text,
                    lblQuoteBy.Text, dtpQuoteDate.Text, "", "", LastQuoteNumber.ToString(), cmbQuoteCompany.Text, cmbQuotetype.Text, txtDiscount.Text, txtGrandTotal.Text, cmbEnquireCurrency.Text, cmbContractYears.Text, cmbCeastAMC.Text);

                foreach (DataGridViewRow dr in dgvNVLAP.Rows)
                {
                    GlobalClass.iStatus = DAL.fnAddServiceQuoteNVLAP(InsertorUpdate, sQuotationNo, RevisionNumber, dr.Cells["SLNo"].Value.ToString(), dr.Cells["NVLAPCalibrationscovered"].Value.ToString().Trim(), "");
                }
                if (cmbCeastAMC.SelectedIndex == 1)
                {
                    foreach (DataGridViewRow dr in dgvContract.Rows)
                    {
                        GlobalClass.iStatus = DAL.fnAddServiceQuoteContractValue(InsertorUpdate, sQuotationNo, RevisionNumber, dr.Cells["ContractValue1stYear"].Value.ToString(), dr.Cells["ContractValue2ndYear"].Value.ToString()
                            , dr.Cells["ContractValue3rdYear"].Value.ToString(), dr.Cells["ContractValue4thYear"].Value.ToString(), dr.Cells["ContractValue5thYear"].Value.ToString(), dr.Cells["Scope"].Value.ToString().Trim());
                    }
                }
                else if (cmbCeastAMC.SelectedIndex == 0)
                {
                    foreach (DataGridViewRow dr in dgvCeastContract.Rows)
                    {
                        GlobalClass.iStatus = DAL.fnAddCeastServiceQuoteContractValue(InsertorUpdate, sQuotationNo, RevisionNumber, dr.Cells["InstrumentDetails"].Value.ToString(),
                            dr.Cells["UnitPrice"].Value.ToString(), dr.Cells["Quantity"].Value.ToString());
                    }
                }
            }

            else if (InsertorUpdate == Global.uUPDATE)
            {
                GlobalClass.iStatus = DAL.fnAddServiceQuoteDetails(InsertorUpdate, sQuotationNo, RevisionNumber, txtCusref.Text, txtZone.Text, cmbCustomer.Text, txtAddress.Text,
                    txtContactPerson.Text, txtEmailID.Text, txtContactNumber.Text, txtTel.Text, txtQuoteName.Text, dtpContractfrom.Text, dtpContractto.Text, txtModelslno.Text,
                    "", comboPVPPM.Text, txtPVCV.Text, txtPVBV.Text, comboSVPPM.Text, txtSVCV.Text, txtSVBV.Text, txtbreakdownvistcharges.Text, txtpaymentterms.Text,
                    lblQuoteBy.Text, dtpQuoteDate.Text, "", "", LastQuoteNumber.ToString(), cmbQuoteCompany.Text, cmbQuotetype.Text, txtDiscount.Text, txtGrandTotal.Text, cmbEnquireCurrency.Text, cmbContractYears.Text, cmbCeastAMC.Text);

                GlobalClass.iStatus = DAL.fnAddServiceQuoteNVLAP(Global.uDELETE, sQuotationNo, RevisionNumber, "", "", "");
                if (cmbCeastAMC.SelectedIndex == 1)
                {
                    GlobalClass.iStatus = DAL.fnAddServiceQuoteContractValue(Global.uDELETE, sQuotationNo, RevisionNumber, "", "", "", "", "", "");
                }
                else if (cmbCeastAMC.SelectedIndex == 0)
                {
                    GlobalClass.iStatus = DAL.fnAddCeastServiceQuoteContractValue(Global.uDELETE, sQuotationNo, RevisionNumber, "", "", "");
                }

                foreach (DataGridViewRow dr in dgvNVLAP.Rows)
                {
                    GlobalClass.iStatus = DAL.fnAddServiceQuoteNVLAP(InsertorUpdate, sQuotationNo, RevisionNumber, dr.Cells["SLNo"].Value.ToString(), dr.Cells["NVLAPCalibrationscovered"].Value.ToString().Trim(), "");
                }
                if (cmbCeastAMC.SelectedIndex == 1)
                {
                    foreach (DataGridViewRow dr in dgvContract.Rows)
                    {
                        GlobalClass.iStatus = DAL.fnAddServiceQuoteContractValue(InsertorUpdate, sQuotationNo, RevisionNumber, dr.Cells["ContractValue1stYear"].Value.ToString(), dr.Cells["ContractValue2ndYear"].Value.ToString()
                            , dr.Cells["ContractValue3rdYear"].Value.ToString(), dr.Cells["ContractValue4thYear"].Value.ToString(), dr.Cells["ContractValue5thYear"].Value.ToString(), dr.Cells["Scope"].Value.ToString().Trim());
                    }
                }

                else if (cmbCeastAMC.SelectedIndex == 0)
                {
                    foreach (DataGridViewRow dr in dgvCeastContract.Rows)
                    {
                        GlobalClass.iStatus = DAL.fnAddCeastServiceQuoteContractValue(InsertorUpdate, sQuotationNo, RevisionNumber, dr.Cells["InstrumentDetails"].Value.ToString(),
                            dr.Cells["UnitPrice"].Value.ToString(), dr.Cells["Quantity"].Value.ToString());
                    }
                }
            }
        }

        private void InsertCALQuote(uint InsertorUpdate, string sQuotationNo, string RevisionNumber)
        {
            if (InsertorUpdate == Global.uINSERT)
            {
                GlobalClass.iStatus = DAL.fnAddServiceQuoteDetails(InsertorUpdate, sQuotationNo, RevisionNumber, txtCALCusRef.Text, txtCalZone.Text, cmbCALCustomer.Text, txtCALAddress.Text,
                    txtCALContactPerson.Text, txtCALEmailID.Text, txtCALHandy.Text, txtCALTel.Text, txtCalQuotename.Text, dtpCalibrationDate.Text, dtpMutualyAgreedDate.Text, txtCALModelNo.Text,
                    "", "", "", "", "", "", "", "", txtCALPaymentTerms.Text,
                    lblCALQuoteby.Text, dtpCALDateofQuote.Text, "", "", LastQuoteNumber.ToString(), cmbCALQuoteFor.Text, cmbQuotetype.Text, txtCALDiscount.Text, txtCALGrandTotal.Text, CmbCurrency.Text, "", "");

                foreach (DataGridViewRow dr in dgvCALCalibrationDetails.Rows)
                {
                    GlobalClass.iStatus = DAL.fnAddServiceQuoteNVLAP(InsertorUpdate, sQuotationNo, RevisionNumber, dr.Cells["CALSlNO"].Value.ToString(), dr.Cells["CALNVLAPCalibrationscovered"].Value.ToString().Trim(), dr.Cells["Price"].Value.ToString());
                }
            }

            else if (InsertorUpdate == Global.uUPDATE)
            {
                GlobalClass.iStatus = DAL.fnAddServiceQuoteDetails(InsertorUpdate, sQuotationNo, RevisionNumber, txtCALCusRef.Text, txtCalZone.Text, cmbCALCustomer.Text, txtCALAddress.Text,
                    txtCALContactPerson.Text, txtCALEmailID.Text, txtCALHandy.Text, txtCALTel.Text, txtCalQuotename.Text, dtpCalibrationDate.Text, dtpMutualyAgreedDate.Text, txtCALModelNo.Text,
                    "", "", "", "", "", "", "", "", txtCALPaymentTerms.Text,
                    lblCALQuoteby.Text, dtpCALDateofQuote.Text, "", "", LastQuoteNumber.ToString(), cmbCALQuoteFor.Text, cmbQuotetype.Text, txtCALDiscount.Text, txtCALGrandTotal.Text, CmbCurrency.Text, "", "");

                GlobalClass.iStatus = DAL.fnAddServiceQuoteNVLAP(Global.uDELETE, sQuotationNo, RevisionNumber, "", "", "");


                foreach (DataGridViewRow dr in dgvCALCalibrationDetails.Rows)
                {
                    GlobalClass.iStatus = DAL.fnAddServiceQuoteNVLAP(InsertorUpdate, sQuotationNo, RevisionNumber, dr.Cells["CALSlNO"].Value.ToString(), dr.Cells["CALNVLAPCalibrationscovered"].Value.ToString().Trim(), dr.Cells["Price"].Value.ToString());
                }
            }
        }

        private void InsertRIVQuote(uint InsertorUpdate, string sQuotationNo, string RevisionNumber)
        {
            GlobalClass.iStatus = DAL.fnAddServiceQuoteRIVDetails(InsertorUpdate, sQuotationNo, RevisionNumber, txtRICOntractType.Text, txtRIZone.Text, cmbRICustomer.Text, txtRIAddress.Text,
                TxtRIContactPerson.Text, txtRIEmail.Text, txtRIModelNumber.Text, txtRIQuoteName.Text, txtRIAdditionalCharges.Text, txtRIPaymentTerms.Text,
                lblRIQuoteBy.Text, dtpQuoteDate.Text, "", "", LastQuoteNumber.ToString(), cmbRIQuotefor.Text, cmbQuotetype.Text, txtRIContactNumber.Text, txtRIVDiscount.Text, txtRIVGrandTotal.Text, cmbRICurrency.Text);

            if (InsertorUpdate == Global.uUPDATE)
            {
                GlobalClass.iStatus = DAL.fnAddRIQuoteDetails(Global.uDELETE, sQuotationNo, RevisionNumber, "", "", "");
            }

            foreach (DataGridViewRow dr in dgvRIQuoteDetails.Rows)
            {
                GlobalClass.iStatus = DAL.fnAddRIQuoteDetails(InsertorUpdate, sQuotationNo, RevisionNumber, dr.Cells["RISlNo"].Value.ToString(), dr.Cells["RIScopeofwork"].Value.ToString().Trim(), dr.Cells["RIPrice"].Value.ToString());
            }
        }

        private void cmbQuotationNumber_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbQuotetype.SelectedIndex == 0 || cmbQuotetype.SelectedIndex == 1)
            {
                dtServiceQuoteNumber = DAL.fnServiceQuotationNumberLoadData(2, cmbQuotationNumber.Text, "").Tables[0];
                cmbRevisionNumber.Items.Clear();
                cmbRevisionNumber.SelectedIndex = -1;
                if (dtServiceQuoteNumber.Rows.Count > 0)
                {
                    foreach (DataRow DR in dtServiceQuoteNumber.Rows)
                    {
                        if (!cmbRevisionNumber.Items.Contains(DR["RevisionNumber"].ToString()))
                            cmbRevisionNumber.Items.Add(DR["RevisionNumber"].ToString());
                    }
                }
            }
            else if (cmbQuotetype.SelectedIndex == 2 || cmbQuotetype.SelectedIndex == 3)
            {
                dtServiceQuoteNumber = DAL.fnServiceQuotationNumberLoadData(61, cmbQuotationNumber.Text, "").Tables[0];
                cmbRevisionNumber.Items.Clear();
                cmbRevisionNumber.Text = "";
                if (dtServiceQuoteNumber.Rows.Count > 0)
                {
                    foreach (DataRow DR in dtServiceQuoteNumber.Rows)
                    {
                        if (!cmbRevisionNumber.Items.Contains(DR["RevisionNumber"].ToString()))
                            cmbRevisionNumber.Items.Add(DR["RevisionNumber"].ToString());
                    }
                }
            }

            else if (cmbQuotetype.SelectedIndex == 4)
            {

                tabPI.Enabled = true;
                btnGeneratePI.Enabled = true;
                dtServiceQuoteDetail = DAL.fnServiceQuotationNumberLoadData(71, cmbQuotationNumber.Text, "").Tables[0];
                if (dtServiceQuoteDetail.Rows.Count > 0)
                {
                    cmbPICustomer.Text = dtServiceQuoteDetail.Rows[0]["Customer"].ToString();
                    txtPICusCode.Text = dtServiceQuoteDetail.Rows[0]["CusCode"].ToString();
                    txtPIAddress.Text = dtServiceQuoteDetail.Rows[0]["Address"].ToString();
                    txtPICountry.Text = dtServiceQuoteDetail.Rows[0]["Country"].ToString();
                    txtPIGSTIN.Text = dtServiceQuoteDetail.Rows[0]["GSTIN"].ToString();
                    txtPIQuoteRef.Text = dtServiceQuoteDetail.Rows[0]["QuotationRefNo"].ToString();
                    dtpPIQuoterefdate.Text = dtServiceQuoteDetail.Rows[0]["QuotationRefDate"].ToString();
                    txtPIPurchaseOrder.Text = dtServiceQuoteDetail.Rows[0]["PurchaseOrderNo"].ToString();
                    dtpPIPurchaseorderdate.Text = dtServiceQuoteDetail.Rows[0]["PurchaseOrderDate"].ToString();


                    lblPIBY.Text = dtServiceQuoteDetail.Rows[0]["PICreatedBy"].ToString();
                    dtpPIDate.Text = dtServiceQuoteDetail.Rows[0]["DateofPI"].ToString();
                    cmbPICompany.Text = dtServiceQuoteDetail.Rows[0]["PICompany"].ToString();
                    cmbPICurrency.Text = dtServiceQuoteDetail.Rows[0]["Currency"].ToString();
                    txtPIGST.Text = dtServiceQuoteDetail.Rows[0]["GST"].ToString();
                    txtPIGrandTotal.Text = dtServiceQuoteDetail.Rows[0]["GrandTotal"].ToString();

                    txtPIPaymentterms.Text = dtServiceQuoteDetail.Rows[0]["PaymentTerms"].ToString();
                    txtPImchineNo.Text = dtServiceQuoteDetail.Rows[0]["MachineNo"].ToString();
                }


                dtOfferItemDeatils = DAL.fnServiceQuotationNumberLoadData(72, cmbQuotationNumber.Text, "").Tables[0];
                if (dtOfferItemDeatils.Rows.Count > 0)
                {
                    dgvPIDetails.AutoGenerateColumns = false;
                    dgvPIDetails.DataSource = dtOfferItemDeatils;
                }
            }
        }
        DataTable dtServiceQuoteDetail = new DataTable();

        private void cmbRevisionNumber_SelectedIndexChanged(object sender, EventArgs e)
        {
            //int KNumber = cmbRevisionNumber.SelectedIndex;
            if (cmbQuotetype.SelectedIndex == 0)
            {
                tabAMC.Enabled = true;
                btnFinQuote.Enabled = true;
                dtServiceQuoteDetail = DAL.fnServiceQuotationNumberLoadData(3, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];
                if (dtServiceQuoteDetail.Rows.Count > 0)
                {
                    txtCusref.Text = dtServiceQuoteDetail.Rows[0]["CustomerRef"].ToString();
                    txtZone.Text = dtServiceQuoteDetail.Rows[0]["Zone"].ToString();
                    cmbCustomer.Text = dtServiceQuoteDetail.Rows[0]["Customer"].ToString();
                    txtAddress.Text = dtServiceQuoteDetail.Rows[0]["CustomerAddress"].ToString();
                    txtContactPerson.Text = dtServiceQuoteDetail.Rows[0]["ContactPerson"].ToString();
                    txtEmailID.Text = dtServiceQuoteDetail.Rows[0]["EmailId"].ToString();
                    txtContactNumber.Text = dtServiceQuoteDetail.Rows[0]["HandyNumber"].ToString();
                    txtTel.Text = dtServiceQuoteDetail.Rows[0]["PhoneNumber"].ToString();
                    txtQuoteName.Text = dtServiceQuoteDetail.Rows[0]["QuoteName"].ToString();
                    cmbContractYears.Text = dtServiceQuoteDetail.Rows[0]["ContractYears"].ToString();
                    dtpContractfrom.Text = dtServiceQuoteDetail.Rows[0]["ContractPeriodfrom"].ToString();
                    dtpContractto.Text = dtServiceQuoteDetail.Rows[0]["ContractPeriodto"].ToString();
                    txtModelslno.Text = dtServiceQuoteDetail.Rows[0]["ModelandSerialNumber"].ToString();
                    comboPVPPM.Text = dtServiceQuoteDetail.Rows[0]["PVPreventivemaintenance"].ToString();
                    txtPVCV.Text = dtServiceQuoteDetail.Rows[0]["PVCalibrationvisits"].ToString();
                    txtPVBV.Text = dtServiceQuoteDetail.Rows[0]["PVBreakdownvisits"].ToString();
                    comboSVPPM.Text = dtServiceQuoteDetail.Rows[0]["SVPreventivemaintenance"].ToString();
                    txtSVCV.Text = dtServiceQuoteDetail.Rows[0]["SVCalibrationvisits"].ToString();
                    txtSVBV.Text = dtServiceQuoteDetail.Rows[0]["SVBreakdownvisits"].ToString();
                    txtbreakdownvistcharges.Text = dtServiceQuoteDetail.Rows[0]["Breakdowncharges"].ToString();
                    txtpaymentterms.Text = dtServiceQuoteDetail.Rows[0]["Paymentterms"].ToString();
                    lblQuoteBy.Text = dtServiceQuoteDetail.Rows[0]["QuoteCreatedBy"].ToString();
                    cmbQuoteCompany.Text = dtServiceQuoteDetail.Rows[0]["Quotefor"].ToString();
                    txtDiscount.Text = dtServiceQuoteDetail.Rows[0]["Discount"].ToString();
                    txtGrandTotal.Text = dtServiceQuoteDetail.Rows[0]["GrandTotal"].ToString();
                    cmbEnquireCurrency.Text = dtServiceQuoteDetail.Rows[0]["Currency"].ToString();
                    cmbCeastAMC.Text = dtServiceQuoteDetail.Rows[0]["CeastContract"].ToString();
                }


                dtOfferItemDeatils = DAL.fnServiceQuotationNumberLoadData(4, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];
                if (dtOfferItemDeatils.Rows.Count > 0)
                {
                    dgvNVLAP.AutoGenerateColumns = false;
                    dgvNVLAP.DataSource = dtOfferItemDeatils;
                }

                dtOfferContractDeatils = DAL.fnServiceQuotationNumberLoadData(5, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];

                if (dtOfferContractDeatils.Rows.Count > 0)
                {
                    dgvContract.AutoGenerateColumns = false;
                    dgvContract.DataSource = dtOfferContractDeatils;
                }
                if (cmbCeastAMC.SelectedIndex == 0)
                {
                    dtCeastQuoteContractValue = DAL.fnServiceQuotationNumberLoadData(52, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];

                    if (dtCeastQuoteContractValue.Rows.Count > 0)
                    {
                        dgvCeastContract.AutoGenerateColumns = false;
                        dgvCeastContract.DataSource = dtCeastQuoteContractValue;
                    }

                    fnCeastCalculation();
                }
            }

            else if (cmbQuotetype.SelectedIndex == 1)
            {
                //tabControl1.Enabled = true;
                //btnFinQuote.Enabled = true;
                dtServiceQuoteDetail = DAL.fnServiceQuotationNumberLoadData(3, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];
                if (dtServiceQuoteDetail.Rows.Count > 0)
                {
                    txtCALCusRef.Text = dtServiceQuoteDetail.Rows[0]["CustomerRef"].ToString();
                    txtCalZone.Text = dtServiceQuoteDetail.Rows[0]["Zone"].ToString();
                    cmbCALCustomer.Text = dtServiceQuoteDetail.Rows[0]["Customer"].ToString();
                    txtCALAddress.Text = dtServiceQuoteDetail.Rows[0]["CustomerAddress"].ToString();
                    txtCALContactPerson.Text = dtServiceQuoteDetail.Rows[0]["ContactPerson"].ToString();
                    txtCALEmailID.Text = dtServiceQuoteDetail.Rows[0]["EmailId"].ToString();
                    txtCALHandy.Text = dtServiceQuoteDetail.Rows[0]["HandyNumber"].ToString();
                    txtCALTel.Text = dtServiceQuoteDetail.Rows[0]["PhoneNumber"].ToString();
                    txtCalQuotename.Text = dtServiceQuoteDetail.Rows[0]["QuoteName"].ToString();
                    //dtpCalibrationDate.Text = dtServiceQuoteDetail.Rows[0]["ContractPeriodfrom"].ToString();
                    //dtpMutualyAgreedDate.Text = dtServiceQuoteDetail.Rows[0]["ContractPeriodto"].ToString();
                    txtCALModelNo.Text = dtServiceQuoteDetail.Rows[0]["ModelandSerialNumber"].ToString();

                    //txtbreakdownvistcharges.Text = dtServiceQuoteDetail.Rows[0]["Breakdowncharges"].ToString();
                    txtCALPaymentTerms.Text = dtServiceQuoteDetail.Rows[0]["Paymentterms"].ToString();
                    lblCALQuoteby.Text = dtServiceQuoteDetail.Rows[0]["QuoteCreatedBy"].ToString();
                    cmbCALQuoteFor.Text = dtServiceQuoteDetail.Rows[0]["Quotefor"].ToString();
                    txtCALDiscount.Text = dtServiceQuoteDetail.Rows[0]["Discount"].ToString();
                    txtCALGrandTotal.Text = dtServiceQuoteDetail.Rows[0]["GrandTotal"].ToString();
                    CmbCurrency.Text = dtServiceQuoteDetail.Rows[0]["Currency"].ToString();
                }


                dtOfferItemDeatils = DAL.fnServiceQuotationNumberLoadData(4, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];
                if (dtOfferItemDeatils.Rows.Count > 0)
                {
                    dgvCALCalibrationDetails.AutoGenerateColumns = false;
                    dgvCALCalibrationDetails.DataSource = dtOfferItemDeatils;
                }

            }

            else if (cmbQuotetype.SelectedIndex == 2 || cmbQuotetype.SelectedIndex == 3)
            {
                dtServiceQuoteDetail = DAL.fnServiceQuotationNumberLoadData(62, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];
                if (dtServiceQuoteDetail.Rows.Count > 0)
                {
                    txtRICOntractType.Text = dtServiceQuoteDetail.Rows[0]["ContractType"].ToString();
                    txtRIZone.Text = dtServiceQuoteDetail.Rows[0]["Zone"].ToString();
                    cmbRICustomer.Text = dtServiceQuoteDetail.Rows[0]["Customer"].ToString();
                    txtRIAddress.Text = dtServiceQuoteDetail.Rows[0]["CustomerAddress"].ToString();
                    TxtRIContactPerson.Text = dtServiceQuoteDetail.Rows[0]["ContactPerson"].ToString();
                    txtRIEmail.Text = dtServiceQuoteDetail.Rows[0]["EmailId"].ToString();
                    txtRIQuoteName.Text = dtServiceQuoteDetail.Rows[0]["QuoteName"].ToString();
                    txtRIModelNumber.Text = dtServiceQuoteDetail.Rows[0]["ModelNumber"].ToString();
                    txtRIAdditionalCharges.Text = dtServiceQuoteDetail.Rows[0]["AdditionalDayCharges"].ToString();
                    txtRIPaymentTerms.Text = dtServiceQuoteDetail.Rows[0]["Paymentterms"].ToString();
                    lblRIQuoteBy.Text = dtServiceQuoteDetail.Rows[0]["QuoteCreatedBy"].ToString();
                    cmbRIQuotefor.Text = dtServiceQuoteDetail.Rows[0]["Quotefor"].ToString();
                    txtRIVDiscount.Text = dtServiceQuoteDetail.Rows[0]["Discount"].ToString();
                    txtRIVGrandTotal.Text = dtServiceQuoteDetail.Rows[0]["GrandTotal"].ToString();
                    txtRIContactNumber.Text = dtServiceQuoteDetail.Rows[0]["Contactnumber"].ToString();
                    cmbRICurrency.Text = dtServiceQuoteDetail.Rows[0]["Currency"].ToString();
                    btnPrintRIQuote.Enabled = true;
                }
                dtOfferContractDeatils = DAL.fnServiceQuotationNumberLoadData(63, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];
                dgvRIQuoteDetails.AutoGenerateColumns = false;
                dgvRIQuoteDetails.DataSource = dtOfferContractDeatils;
            }
        }

        private void btnBack1_Click(object sender, EventArgs e)
        {
            tabAMC.SelectTab(1);
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            tabAMC.SelectTab(0);
        }
        DataRow[] DR;
        private void cmbCustomer_SelectedIndexChanged(object sender, EventArgs e)
        {
            DR = dtCustomerList.Select("CustomerName = '" + cmbCustomer.Text + "'");
            if (DR.Length > 0)
            {
                txtAddress.Text = DR[0]["Address1"].ToString() + DR[0]["Address2"].ToString() + DR[0]["Address3"].ToString();
                txtContactPerson.Text = DR[0]["ContactPerson"].ToString();
                txtContactNumber.Text = DR[0]["MobileNo"].ToString();
                txtEmailID.Text = DR[0]["EmailAddress"].ToString();
                txtCusCode.Text = DR[0]["CusCode"].ToString();
            }
            else
            {
                txtAddress.ResetText();
                txtContactPerson.ResetText();
                txtContactNumber.ResetText();
                txtEmailID.ResetText();
                txtCusCode.ResetText();
            }
        }
        string ExcelFolderName;
        string ExcelFolderPath;
        string FileFullPath;
        private void fnFileSavePath()
        {
            //ExcelFolderName = "\\Service Quotes";
            //ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + ExcelFolderName + "\\";

            //if (!Directory.Exists(ExcelFolderPath))
            //    Directory.CreateDirectory(ExcelFolderPath);
            /*
            if (Properties.Settings.Default.ServiceQuotePath == "C:\\Users\\SOFTWARE8\\Documents\\Quotation")
            {
                DialogResult result = folderBrowserDialog1.ShowDialog();
                if (result == DialogResult.OK)
                {
                    Properties.Settings.Default.ServiceQuotePath = folderBrowserDialog1.SelectedPath;
                    Properties.Settings.Default.Save();
                }
            }
            */

            string defaultPath = @"C:\Users\SOFTWARE8\Documents\Quotation";

            if (Properties.Settings.Default.ServiceQuotePath == defaultPath)
            {
                using (FolderBrowserDialog folderBrowserDialog1 = new FolderBrowserDialog())
                {
                    DialogResult result = folderBrowserDialog1.ShowDialog();
                    if (result == DialogResult.OK)
                    {
                        Properties.Settings.Default.ServiceQuotePath = folderBrowserDialog1.SelectedPath;
                        Properties.Settings.Default.Save();
                    }
                }
            }

            if (!Directory.Exists(Properties.Settings.Default.ServiceQuotePath))
            {
                Directory.CreateDirectory(Properties.Settings.Default.ServiceQuotePath);
            }
        }
        private void btnFinQuote_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            fnFileSavePath();
            if (cmbSelectQuoteType.Text == "New" || cmbSelectQuoteType.Text == "Update" || cmbSelectQuoteType.Text == "Revise")
            {

                try
                {
                    int iRowIndex = 1;
                    //string ExcelFolderName;
                    string ExcelFolderPath;
                    string FileFullPath;
                    string FileFul;
                    int title1, title2 = 0;

                    EXCEL.Workbook NewWorkBook;
                    EXCEL.Worksheet NewWorkSheet;
                    EXCEL.Application ExcelApp;
                    EXCEL.Range CELLS, cell1, cell2;
                    {
                        object misValue;


                        // ExcelFolderName = "\\Quotation";
                        string sFileQuotename = cmbQuotationNumber.Text;
                        //shreeshail is added below code
                        Regex illegalInFileName = new Regex(@"[\\/:*?""<>|]");
                        string sProjName = sFileQuotename;
                        sFileQuotename = illegalInFileName.Replace(sProjName, " ");
                        //shreeshail is added above code

                        ExcelFolderPath = Properties.Settings.Default.ServiceQuotePath;   // System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) txtModelslno.Text + ExcelFolderName + "\\";
                        //FileFullPath = ExcelFolderPath + "\\" + sFileQuotename + " - R" + cmbRevisionNumber.Text + " - " + cmbCustomer.Text + " - " + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + ".xlsx"; 
                        //FileFul = ExcelFolderPath + "\\" + sFileQuotename + " - R" + cmbRevisionNumber.Text + " - " + cmbCustomer.Text + " - " + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + ".pdf";

                        FileFullPath = ExcelFolderPath + "\\" + sFileQuotename + " - R" + cmbRevisionNumber.Text + " - " + cmbCustomer.Text + " - " + txtModelslno.Text + " - " + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + ".xlsx";
                        FileFul = ExcelFolderPath + "\\" + sFileQuotename + " - R" + cmbRevisionNumber.Text + " - " + cmbCustomer.Text + " - " + txtModelslno.Text + " - " + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + ".pdf";



                        //"Quotation No: " + cmbQuotationNumber.Text + "","", "",
                        //        "Prepared for:","" + cmbCustomer.Text + "",
                        //        txtAddress.Text,
                        //        "", "", "",
                        //        "Kind Attention : " + txtContactPerson.Text + "","Email : " + txtEmailID.Text + "",
                        //        "Handy.: " + txtContactNumber.Text + "",
                        //        "Tel.: " + txtTel.Text + "","","Dear Sir,","",
                        //        "Sub.: " + txtQuoteName.Text + "","",

                        //string[] Text ={"ITW India Private Limited(Instron Division), engaged in the principal business of marketing testing machines / equipment’s undertakes to execute the repair"
                        //    ,"and maintenance work  mentioned below  as a part of its after-sales activity subject to the terms and  conditions specified as under for a contract period.",
                        //"","Contract period starting from",
                        //"Equipment/s Covered Under this Maintenance Contract:",
                        //"Model and Serial Number","",

                        //"NVLAP Calibrations covered under this Maintenance Contract: "};

                        string sNaBL = "";
                        if (cmbQuoteCompany.SelectedIndex == 0)
                        {
                            sNaBL = "NABL";
                        }
                        else if (cmbQuoteCompany.SelectedIndex == 1)
                        {
                            sNaBL = "NVLAP";
                        }

                        string[] Text ={"ITW India Private Limited(Instron Division), engaged in the principal business of marketing testing machines / equipment’s"
                            ,"undertakes to execute the repair and maintenance work mentioned below as a part of its after-sales activity subject to the","terms and conditions specified as under for a contract period.",
                        "","Contract period starting from " + dtpContractfrom.Text + "  to  " + dtpContractto.Text + "","",
                         ""+sNaBL+" Calibrations covered under this Maintenance Contract: "};


                        string[] Text1 = { "Proposed Visit :","Pre-Scheduled Preventive Maintenance Visits (PPM)"
                        ,"Calibration Visits","Breakdown Visits","","Schedule of Visits :"
                        ,"Pre-Scheduled Preventive Maintenance Visits (PPM) ","Calibration due on ","Breakdown Visits","","Contract Value :"};

                        string sCurrency = "";
                        if (cmbEnquireCurrency.SelectedIndex == 0)
                        {
                            sCurrency = "All prices are in INR ";
                        }
                        else
                        {
                            sCurrency = "All prices are in USD ";
                        }

                        string[] Text2 = {"",comboPVPPM.Text ,txtPVCV.Text,txtPVBV.Text,"","",
                        comboSVPPM.Text,txtSVCV.Text,txtSVBV.Text ,"",sCurrency};

                        string[] Text3 = { "TAX : GST - 18 % - Our GSTIN - 29AAACI4550Q2Z1. Our SAC Code - 998346 Our Income Tax Permanent Account Number (PAN) is AAACI4550Q."
                                ,""
                        ,"Kindly provide us your Purchase order in the name of ITW India Private Limited, 497E, 14 Cross, 4th Phase, Peenya Industrial Area, Bangalore 560 058, Karnataka, India.",
                        "Payment Terms:",txtpaymentterms.Text,""};


                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);

                        ExcelApp = new EXCEL.Application();
                        misValue = System.Reflection.Missing.Value;
                        try
                        {
                            if (ExcelApp == null)
                                MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                            NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                            NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                            if (NewWorkSheet == null)
                                MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                            else
                                NewWorkSheet.Name = "Quote";
                            EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                            if (RANGE == null)
                                MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                            NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                            CELLS = NewWorkSheet.Cells;

                            if (cmbQuoteCompany.SelectedIndex == 0)
                            {

                                string[] TextN ={"","",
                                "ITW India Private Limited - "+cmbQuoteCompany.Text+" Division","497E, 14 Cross, 4th Phase, Peenya Industrial Area,",
                                "Bangalore 560 058, Karnataka,  India. ", "Phone:91(080) 28360184  FAX: (080) 28360047",
                                "Web: http://www.biss.in, Email: sales@biss.in", "", "","","",cmbCustomer.Text.Trim(),txtAddress.Text.Trim(), "","","",
                                "Kind Attention : "+txtContactPerson.Text +"","","Email : "+txtEmailID.Text+"","",
                                "Contact No : "+txtContactNumber.Text+"",
                                "","","Offer No.: "+ cmbQuotationNumber.Text,
                                "Date : "+dtpEnquireDate.Text+"","Rev : "+cmbRevisionNumber.Text+"",""};

                                foreach (string str in TextN)
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1] = str;
                                    // CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                    iRowIndex++;
                                }
                            }
                            else if (cmbQuoteCompany.SelectedIndex == 1)
                            {

                                string[] TextN1 ={"","",
                                "ITW India Private Limited - "+cmbQuoteCompany.Text+" Division","497E, 14 Cross, 4th Phase, Peenya Industrial Area,",
                                "Bangalore 560 058, Karnataka, India.","Phone:91(080) 28360184 FAX: (080) 28360047", "",
                                 "", "","","",cmbCustomer.Text,txtAddress.Text, "","","",
                                "Kind Attention : "+txtContactPerson.Text +"","","Email : "+txtEmailID.Text+"","",
                                "Contact No : "+txtContactNumber.Text+"",
                                "","","Offer No.: "+ cmbQuotationNumber.Text,
                                "Date : "+dtpEnquireDate.Text+"","Rev : "+cmbRevisionNumber.Text+"",""};

                                foreach (string str in TextN1)
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1] = str;
                                    // CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                    iRowIndex++;
                                }
                            }


                            NewWorkSheet.get_Range("A1", "H9999").Cells.Font.Name = "Arial";
                            NewWorkSheet.get_Range("A2", "H9999").Cells.Font.Size = 13;

                            // CellMerge("AlignLeft", NewWorkSheet, 6, 8, 1, 3);
                            NewWorkSheet.Range["A13:A13"].Cells.WrapText = true;
                            CellMerge("Merge", NewWorkSheet, 13, 16, 1, 4);
                            CellMerge("AlignTop", NewWorkSheet, 13, 13, 1, 4);
                            // NewWorkSheet.Range["A1:H48"].Cells.Font.Bold = true;
                            CellMerge("Bold", NewWorkSheet, 3, 3, 1, 8);
                            CellMerge("Bold", NewWorkSheet, 12, 12, 1, 8);
                            CellMerge("Bold", NewWorkSheet, 17, 46, 1, 8);

                            NewWorkSheet.Cells[19, 7] = "Contract Type.: " + txtCusref.Text + "";
                            NewWorkSheet.Cells[21, 7] = "Zone.: " + txtZone.Text + "";

                            NewWorkSheet.Cells[24, 7] = "GSTIN - 29AAACI4550Q2Z1";
                            //  CellMerge("Merge", NewWorkSheet, 24, 24, 3, 4);
                            NewWorkSheet.Cells[25, 7] = "HSN - 90241000";
                            // CellMerge("Merge", NewWorkSheet, 25, 25, 3, 4);

                            if (File.Exists(Global.sCompanyLogo))
                            {
                                EXCEL.Range oRange1 = (EXCEL.Range)NewWorkSheet.Cells[28, 1];
                                Image oImage1 = Image.FromFile(Global.sCompanyLogo);
                                System.Windows.Forms.Clipboard.SetDataObject(oImage1, true);
                                //NewWorkSheet.Paste(oRange1, Global.sITWLogo);
                                System.Threading.Thread.Sleep(500);
                                NewWorkSheet.Paste(oRange1);

                            }


                            //NewWorkSheet.Cells[1, 3] = "Date : " + dtpQuoteDate.Text + "";
                            //NewWorkSheet.Cells[1, 5] = "Cutomer Ref.: " + txtCusref.Text + "    " + "Zone.: " + txtZone.Text + "";

                            //NewWorkSheet.Cells[45, 1] = "Prepared : " + login.GetUserDetails[2] + "";
                            //CellMerge("Merge", NewWorkSheet, 45, 45, 1, 8);
                            //CellMerge("AlignLeft", NewWorkSheet, 45, 45, 1, 8);
                            //NewWorkSheet.Cells[46, 1] = "Contact : " + login.GetUserDetails[20] + " | " + login.GetUserDetails[50] + "";
                            //CellMerge("Merge", NewWorkSheet, 46, 46, 1, 8);
                            //CellMerge("AlignLeft", NewWorkSheet, 46, 46, 1, 8);
                            //  CellMerge("Bold", NewWorkSheet, 45, 46, 1, 8);



                            NewWorkSheet.Cells[47, 1].Font.Color = Color.FromArgb(255, 0, 0);
                            NewWorkSheet.Cells[47, 1].Characters(54, 65).Font.Color = Color.FromArgb(0, 0, 255);
                            NewWorkSheet.Cells[47, 1].Characters(66, 100).Font.Color = Color.FromArgb(255, 0, 0);
                            iRowIndex = 48;

                            NewWorkSheet.HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);
                            NewWorkSheet.Cells[iRowIndex, 1] = (txtQuoteName.Text.Trim() + "\nModel No: " + txtModelslno.Text.Trim()).Trim();
                            NewWorkSheet.Cells[iRowIndex, 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                            NewWorkSheet.Range["A" + iRowIndex + ":D" + iRowIndex + ""].Cells.WrapText = true;
                            NewWorkSheet.Rows[iRowIndex].RowHeight = 70;
                            NewWorkSheet.get_Range("A" + iRowIndex + "", "D" + iRowIndex + "").Cells.Font.Size = 18;
                            CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            NewWorkSheet.Cells[iRowIndex, 1].Font.Color = Color.FromArgb(186, 12, 47);
                            iRowIndex++;
                            iRowIndex++;
                            foreach (string str in Text)
                            {
                                NewWorkSheet.Cells[iRowIndex, 1] = str;
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;
                            }
                            CellMerge("Merge", NewWorkSheet, 54, 54, 1, 8);
                            NewWorkSheet.Rows[53].RowHeight = 20;
                            // CellMerge("AlignCenter", NewWorkSheet, 52, 52, 1, 8);
                            //  NewWorkSheet.get_Range("A" + iRowIndex + "", "D" + iRowIndex + "").Cells.Font.Size = 18;
                            NewWorkSheet.get_Range("A54", "H54").Cells.Font.Size = 16;
                            CellMerge("Bold", NewWorkSheet, 54, 56, 1, 8);

                            // NewWorkSheet.HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);
                            //iRowIndex = 49;

                            //NewWorkSheet.Cells[22, 3] = "";
                            //NewWorkSheet.Cells[24, 5] = txtModelslno.Text;

                            //shreeshail is removed bellow code
                            /*
                            iRowIndex++;
                            for (int i = 0; i < dgvNVLAP.Rows.Count; i++)
                            {
                                for (int m = 0; m < dgvNVLAP.Columns.Count; m++)
                                {
                                    NewWorkSheet.Cells[iRowIndex, m + 1] = dgvNVLAP.Rows[i].Cells[m].Value.ToString();

                                    if (dgvNVLAP.Rows[i].Cells[m].Value.ToString().Length > 0 && dgvNVLAP.Rows[i].Cells[m].Value.ToString().Length < 120)
                                    {
                                        NewWorkSheet.Rows[iRowIndex].RowHeight = 18;
                                        NewWorkSheet.Rows[iRowIndex].WrapText = true;
                                    }

                                    else if (dgvNVLAP.Rows[i].Cells[m].Value.ToString().Length > 122 && dgvNVLAP.Rows[i].Cells[m].Value.ToString().Length < 200)
                                    {
                                        NewWorkSheet.Rows[iRowIndex].RowHeight = 36;
                                        NewWorkSheet.Rows[iRowIndex].WrapText = true;
                                    }
                                    else if (dgvNVLAP.Rows[i].Cells[m].Value.ToString().Length > 200 && dgvNVLAP.Rows[i].Cells[m].Value.ToString().Length < 260)
                                    {
                                        NewWorkSheet.Rows[iRowIndex].RowHeight = 54;
                                        NewWorkSheet.Rows[iRowIndex].WrapText = true;
                                    }
                                    else
                                    {
                                        NewWorkSheet.Rows[iRowIndex].RowHeight = 72;
                                        NewWorkSheet.Rows[iRowIndex].WrapText = true;
                                    }
                                }
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 2, 8);
                                CellMerge("VAlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                                CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                                CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 2, 8);
                                iRowIndex++;
                            }
                            */

                            //shreeshail is removed above code
                            //shreeshail is added bellow code
                            iRowIndex++;
                            for (int i = 0; i < dgvNVLAP.Rows.Count; i++)
                            {
                                for (int m = 0; m < dgvNVLAP.Columns.Count; m++)
                                {
                                    // Get cell value
                                    string cellValue = dgvNVLAP.Rows[i].Cells[m].Value?.ToString() ?? string.Empty;

                                    // Set cell value in the worksheet
                                    NewWorkSheet.Cells[iRowIndex, m + 1] = cellValue;

                                    // Apply WrapText for better visibility
                                    var cell = NewWorkSheet.Cells[iRowIndex, m + 1];
                                    cell.WrapText = true;

                                    // Adjust column width dynamically
                                    NewWorkSheet.Columns[m + 1].AutoFit();

                                    // Manually set the row height to ensure all text fits
                                    if (m == dgvNVLAP.Columns.Count - 1) // Only calculate once per row
                                    {
                                        int maxLength = dgvNVLAP.Rows[i].Cells.Cast<DataGridViewCell>()
                                                          .Max(c => c.Value?.ToString()?.Length ?? 0);

                                        if (maxLength <= 50)
                                        {
                                            NewWorkSheet.Rows[iRowIndex].RowHeight = 20; // Small content
                                        }
                                        else if (maxLength <= 100)
                                        {
                                            NewWorkSheet.Rows[iRowIndex].RowHeight = 30; // Medium content
                                        }
                                        else
                                        {
                                            NewWorkSheet.Rows[iRowIndex].RowHeight = 40; // Large content
                                        }
                                    }
                                }

                                // Apply formatting (e.g., merge cells or borders)
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 2, 8); // Merge B to H
                                CellMerge("VAlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 1); // Align column A
                                CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 1, 1); // Border for column A
                                CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 2, 8); // Border for B to H

                                iRowIndex++;
                            }
                            //shreeshail is added above code




                            //for (int i = iRowIndex + 1; i < (dtOfferItemDeatils.Rows.Count + iRowIndex + 1); i++)
                            //{
                            //    CellMerge("ThickBorder", NewWorkSheet, i, i, 1, 1);
                            //    CellMerge("ThickBorder", NewWorkSheet, i, i, 2, 8);
                            //}

                            //   iRowIndex = iRowIndex + dtOfferItemDeatils.Rows.Count;

                            iRowIndex++;

                            NewWorkSheet.Cells[iRowIndex, 1] = "Kindly go through the details of transducers mentioned above and confirm that all transducers that you are in need of calibration are included in the above list. In case you need to add any transducers you might have procured recently, please inform us to revise the quote.";
                            CellMerge("Merge", NewWorkSheet, iRowIndex, (iRowIndex + 2), 1, 8);
                            CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);

                            iRowIndex++;
                            iRowIndex++;
                            iRowIndex++;
                            iRowIndex++;
                            int newirowindex = iRowIndex;
                            int KROWCheck = 1;
                            foreach (string str in Text1)
                            {
                                NewWorkSheet.Cells[iRowIndex, 1] = str;
                                if (str.Length > 36)
                                {
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 36;
                                    NewWorkSheet.Rows[iRowIndex].WrapText = true;
                                }
                                CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                                if (KROWCheck == 1 || KROWCheck == 6 || KROWCheck == 11)
                                {
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                                }
                                else
                                {
                                    CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                                }
                                iRowIndex++;
                                KROWCheck++;
                            }

                            iRowIndex = newirowindex;

                            CellMerge("BorderAround", NewWorkSheet, iRowIndex + 1, iRowIndex + 1, 1, 2);
                            CellMerge("BorderAround", NewWorkSheet, iRowIndex + 2, iRowIndex + 2, 1, 2);
                            CellMerge("BorderAround", NewWorkSheet, iRowIndex + 3, iRowIndex + 3, 1, 2);
                            CellMerge("BorderAround", NewWorkSheet, iRowIndex + 1, iRowIndex + 1, 3, 8);
                            CellMerge("BorderAround", NewWorkSheet, iRowIndex + 2, iRowIndex + 2, 3, 8);
                            CellMerge("BorderAround", NewWorkSheet, iRowIndex + 3, iRowIndex + 3, 3, 8);

                            CellMerge("BorderAround", NewWorkSheet, iRowIndex + 6, iRowIndex + 6, 1, 2);
                            CellMerge("BorderAround", NewWorkSheet, iRowIndex + 7, iRowIndex + 7, 1, 2);
                            CellMerge("BorderAround", NewWorkSheet, iRowIndex + 8, iRowIndex + 8, 1, 2);
                            CellMerge("BorderAround", NewWorkSheet, iRowIndex + 6, iRowIndex + 6, 3, 8);
                            CellMerge("BorderAround", NewWorkSheet, iRowIndex + 7, iRowIndex + 7, 3, 8);
                            CellMerge("BorderAround", NewWorkSheet, iRowIndex + 8, iRowIndex + 8, 3, 8);

                            foreach (string str in Text2)
                            {
                                NewWorkSheet.Cells[iRowIndex, 3] = str;
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 8);

                                if (str.Length > 90)
                                {
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 36;
                                    NewWorkSheet.Rows[iRowIndex].WrapText = true;
                                }
                                CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 3, 3);
                                CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 3, 3);
                                iRowIndex++;
                            }

                            NewWorkSheet.Cells[(iRowIndex - 1), 3].Font.Color = Color.FromArgb(0, 0, 255);

                            string finalColLetter = string.Empty;
                            string excelRange = string.Empty;
                            finalColLetter = string.Empty;
                            string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                            int colCharsetLen = colCharset.Length;

                            finalColLetter = string.Empty;
                            excelRange = string.Empty;
                            finalColLetter = string.Empty;
                            colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                            colCharsetLen = colCharset.Length;

                            double Firststtotal = 0;
                            double Secondttotal = 0;
                            double Thirdtotal = 0;
                            double Fourthtotal = 0;
                            double Fifthtotal = 0;

                            if (cmbCeastAMC.SelectedIndex == 1)
                            {

                                foreach (DataRow row in dtOfferContractDeatils.Rows)
                                {

                                    {
                                        //Add the value of the column to the total
                                        Firststtotal += Convert.ToDouble(row["1st Year"]);
                                        Secondttotal += Convert.ToDouble(row["2nd Year"]);
                                        Thirdtotal += Convert.ToDouble(row["3rd Year"]);
                                        Fourthtotal += Convert.ToDouble(row["4th Year"]);
                                        Fifthtotal += Convert.ToDouble(row["5th Year"]);
                                    }

                                }

                                if (Convert.ToDouble(txtDiscount.Text) > 0)
                                {
                                    dtOfferContractDeatils.Rows.Add(Math.Round(Firststtotal), Math.Round(Secondttotal), Math.Round(Thirdtotal), Math.Round(Fourthtotal), Math.Round(Fifthtotal), "Total amount for each year contract (Without Tax)");
                                    dtOfferContractDeatils.Rows.Add(Math.Round(Firststtotal * (Convert.ToDouble(txtDiscount.Text) / 100)), Math.Round(Secondttotal * (Convert.ToDouble(txtDiscount.Text) / 100)), Math.Round(Thirdtotal * (Convert.ToDouble(txtDiscount.Text) / 100)),
                                        Math.Round(Fourthtotal * (Convert.ToDouble(txtDiscount.Text) / 100)), Math.Round(Fifthtotal * (Convert.ToDouble(txtDiscount.Text) / 100)), "Discount " + txtDiscount.Text + " %");
                                    dtOfferContractDeatils.Rows.Add(Math.Round(Firststtotal - (Firststtotal * (Convert.ToDouble(txtDiscount.Text) / 100))), Math.Round(Secondttotal - (Secondttotal * (Convert.ToDouble(txtDiscount.Text) / 100))), Math.Round(Thirdtotal - (Thirdtotal * (Convert.ToDouble(txtDiscount.Text) / 100))),
                                    Math.Round(Fourthtotal - (Fourthtotal * (Convert.ToDouble(txtDiscount.Text) / 100))), Math.Round(Fifthtotal - (Fifthtotal * (Convert.ToDouble(txtDiscount.Text) / 100))), "Total for each year contract (Without Tax)");
                                }
                                else
                                {
                                    dtOfferContractDeatils.Rows.Add(Math.Round(Firststtotal), Math.Round(Secondttotal), Math.Round(Thirdtotal), Math.Round(Fourthtotal), Math.Round(Fifthtotal), "Total amount for each year contract (Without Tax)");
                                }

                                if (dtOfferContractDeatils.Rows.Count > 0)
                                {
                                    foreach (DataRow row in dtOfferContractDeatils.Rows)
                                    {
                                        if (row["2nd Year"].ToString() == "0")
                                        {
                                            dtOfferContractDeatils.Columns.Remove("2nd Year");
                                        }
                                        if (row["3rd Year"].ToString() == "0")
                                        {
                                            dtOfferContractDeatils.Columns.Remove("3rd Year");
                                        }
                                        if (row["4th Year"].ToString() == "0")
                                        {
                                            dtOfferContractDeatils.Columns.Remove("4th Year");
                                        }
                                        if (row["5th Year"].ToString() == "0")
                                        {
                                            dtOfferContractDeatils.Columns.Remove("5th Year");
                                        }
                                        break;
                                    }
                                }

                                if (dtOfferContractDeatils.Columns.Count == 6)
                                {
                                    finalColLetter = "H";
                                }
                                else if (dtOfferContractDeatils.Columns.Count == 5)
                                {
                                    finalColLetter = "G";
                                }
                                else if (dtOfferContractDeatils.Columns.Count == 4)
                                {
                                    finalColLetter = "F";
                                }
                                else if (dtOfferContractDeatils.Columns.Count == 3)
                                {
                                    finalColLetter = "E";
                                }
                                else if (dtOfferContractDeatils.Columns.Count == 2)
                                {
                                    finalColLetter = "D";
                                }

                                object[,] rawData = new object[dtOfferContractDeatils.Rows.Count + 1, dtOfferContractDeatils.Columns.Count];
                                for (int col = 0; col < dtOfferContractDeatils.Columns.Count; col++)
                                {
                                    rawData[0, col] = dtOfferContractDeatils.Columns[col].ColumnName;
                                }

                                for (int row = 0; row < dtOfferContractDeatils.Rows.Count; row++)
                                {
                                    for (int col = 0; col < dtOfferContractDeatils.Columns.Count; col++)
                                    {
                                        rawData[row + 1, col] = dtOfferContractDeatils.Rows[row].ItemArray[col];
                                    }
                                }

                                excelRange = string.Format("C" + iRowIndex + ":{0}{1}", finalColLetter, (dtOfferContractDeatils.Rows.Count + iRowIndex));
                                NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;

                                CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);

                                NewWorkSheet.Cells[iRowIndex, 1] = "Charges for Agreed Scope of Work ";
                                CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                                NewWorkSheet.Rows[iRowIndex].RowHeight = 18;
                                CellMerge("Merge", NewWorkSheet, iRowIndex, (dtOfferContractDeatils.Rows.Count + iRowIndex + 1), 1, 2);
                                CellMerge("VAlignCenter", NewWorkSheet, iRowIndex, (dtOfferContractDeatils.Rows.Count + 2 + iRowIndex), 1, 2);
                                CellMerge("AlignCenter", NewWorkSheet, iRowIndex, (dtOfferContractDeatils.Rows.Count + 2 + iRowIndex), 1, 2);


                                for (int i = iRowIndex; i < (dtOfferContractDeatils.Rows.Count + iRowIndex + 3); i++)
                                {
                                    CellMerge("GridLines", NewWorkSheet, i, i, 1, 8);
                                }

                                int jYears = 0;
                                int RowCheck = 0;
                                // iRowIndex++;
                                if (dtOfferContractDeatils.Columns.Count == 6)
                                {
                                    finalColLetter = "H";
                                    jYears = 5;
                                    RowCheck = 0;
                                    for (int i = iRowIndex; i < (dtOfferContractDeatils.Rows.Count + iRowIndex); i++)
                                    {
                                        CellMerge("Merge", NewWorkSheet, i, i, 8, 8);

                                        if (dgvContract.Rows[RowCheck].Cells[5].Value.ToString().Length > 35)
                                        {
                                            NewWorkSheet.Rows[i + 1].RowHeight = 36;
                                            NewWorkSheet.Rows[i + 1].WrapText = true;
                                        }
                                        RowCheck++;
                                    }
                                }
                                else if (dtOfferContractDeatils.Columns.Count == 5)
                                {
                                    jYears = 4;
                                    finalColLetter = "G";
                                    RowCheck = 0;
                                    for (int i = iRowIndex; i < (dtOfferContractDeatils.Rows.Count + iRowIndex); i++)
                                    {
                                        CellMerge("Merge", NewWorkSheet, i, i, 7, 8);
                                        if (dgvContract.Rows[RowCheck].Cells[5].Value.ToString().Length > 45)
                                        {
                                            NewWorkSheet.Rows[i + 1].RowHeight = 36;
                                            NewWorkSheet.Rows[i + 1].WrapText = true;
                                        }
                                        RowCheck++;
                                    }
                                }
                                else if (dtOfferContractDeatils.Columns.Count == 4)
                                {
                                    jYears = 3;
                                    finalColLetter = "F";
                                    RowCheck = 0;
                                    for (int i = iRowIndex; i < (dtOfferContractDeatils.Rows.Count + iRowIndex); i++)
                                    {
                                        CellMerge("Merge", NewWorkSheet, i, i, 6, 8);
                                        if (dgvContract.Rows[RowCheck].Cells[5].Value.ToString().Length > 55)
                                        {
                                            NewWorkSheet.Rows[i + 1].RowHeight = 36;
                                            NewWorkSheet.Rows[i + 1].WrapText = true;
                                        }
                                        RowCheck++;
                                    }
                                }
                                else if (dtOfferContractDeatils.Columns.Count == 3)
                                {
                                    jYears = 2;
                                    finalColLetter = "E";
                                    RowCheck = 0;
                                    for (int i = iRowIndex; i < (dtOfferContractDeatils.Rows.Count + iRowIndex); i++)
                                    {
                                        CellMerge("Merge", NewWorkSheet, i, i, 5, 8);
                                        if (dgvContract.Rows[RowCheck].Cells[5].Value.ToString().Length > 65)
                                        {
                                            NewWorkSheet.Rows[i + 1].RowHeight = 36;
                                            NewWorkSheet.Rows[i + 1].WrapText = true;
                                        }
                                        RowCheck++;
                                    }
                                }
                                else if (dtOfferContractDeatils.Columns.Count == 2)
                                {
                                    jYears = 1;
                                    finalColLetter = "D";
                                    RowCheck = 0;
                                    for (int i = iRowIndex; i < (dtOfferContractDeatils.Rows.Count + iRowIndex); i++)
                                    {
                                        CellMerge("Merge", NewWorkSheet, i, i, 4, 8);
                                        if (dgvContract.Rows[RowCheck].Cells[5].Value.ToString().Length > 75)
                                        {
                                            NewWorkSheet.Rows[i + 1].RowHeight = 36;
                                            NewWorkSheet.Rows[i + 1].WrapText = true;
                                        }
                                        RowCheck++;
                                    }
                                }
                                Microsoft.Office.Interop.Excel.Range range2 = NewWorkSheet.get_Range("C" + iRowIndex, finalColLetter + (iRowIndex + 1 + dtOfferContractDeatils.Rows.Count) + "");
                                range2.NumberFormat = "#,###";

                                iRowIndex = iRowIndex + dtOfferContractDeatils.Rows.Count;
                                iRowIndex++;

                                NewWorkSheet.get_Range("C" + iRowIndex + "", "C" + iRowIndex + "").Cells.Font.Size = 16;
                                NewWorkSheet.Cells[iRowIndex, 3] = Math.Round((Firststtotal + Secondttotal + Thirdtotal + Fourthtotal + Fifthtotal) - ((Firststtotal + Secondttotal + Thirdtotal + Fourthtotal + Fifthtotal) * (Convert.ToDouble(txtDiscount.Text) / 100)));// + " /-";  //- sTotalAmount * (Convert.ToDouble(txtDiscount.Text) / 100)).ToString();
                                if (jYears > 1)
                                {
                                    NewWorkSheet.Cells[iRowIndex, 5] = "Contract price for " + jYears + " years (Without Tax)";
                                }
                                else
                                {
                                    NewWorkSheet.Cells[iRowIndex, 5] = "Contract price for " + jYears + " year (Without Tax)";
                                }
                                NewWorkSheet.Cells[iRowIndex, 3].Font.Color = Color.FromArgb(0, 0, 255);
                                NewWorkSheet.Cells[iRowIndex, 5].Font.Color = Color.FromArgb(0, 0, 255);
                                CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 3, 8);
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 5, 8);
                                CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                                CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex, 5, 8);
                                CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                                iRowIndex++;



                                NewWorkSheet.Cells[iRowIndex, 1] = "Breakdown Visit Charges";
                                if (!string.IsNullOrEmpty(txtbreakdownvistcharges.Text) && txtbreakdownvistcharges.Text != "0")
                                {
                                    if (cmbEnquireCurrency.SelectedIndex == 0)
                                    {
                                        NewWorkSheet.Cells[iRowIndex, 3] = "Rs " + txtbreakdownvistcharges.Text + "/- per day * This is a specially discounted per day charge applicable ONLY to AMC Customers and tax will be at extra.";
                                    }
                                    else
                                    {
                                        NewWorkSheet.Cells[iRowIndex, 3] = "USD " + txtbreakdownvistcharges.Text + "/- per day * This is a specially discounted per day charge applicable ONLY to AMC Customers and tax will be at extra.";
                                    }
                                }
                                else
                                {
                                    NewWorkSheet.Cells[iRowIndex, 3] = "Not Applicable";
                                    CellMerge("VAlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 3, 8);
                                    CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 3, 8);
                                }

                                NewWorkSheet.Rows[iRowIndex].RowHeight = 36;
                                NewWorkSheet.Rows[iRowIndex].WrapText = true;

                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 8);
                                CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex, 3, 8);
                                iRowIndex++;
                                iRowIndex++;

                                if (cmbQuoteCompany.SelectedIndex == 1)
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1] = "TAX : GST - 18 % - Our GSTIN - 29AAACI4550Q2Z1. Our SAC Code- 998346 and Our Income Tax Permanent Account Number (PAN) is AAACI4550Q.";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 1, 1, 8);
                                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;
                                    iRowIndex++;
                                    iRowIndex++;
                                    NewWorkSheet.Cells[iRowIndex, 1] = "Kindly provide us your Purchase order in the name of ITW India Private Limited, 497E, 14 Cross, 4th Phase, Peenya Industrial Area, Bangalore 560 058, Karnataka, India.";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 1, 1, 8);
                                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;
                                    iRowIndex++;
                                    iRowIndex++;
                                    NewWorkSheet.Cells[iRowIndex, 1] = "Payment Terms:";
                                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;

                                    NewWorkSheet.Cells[iRowIndex, 1] = txtpaymentterms.Text;
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 4, 1, 8);
                                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex = iRowIndex + 5;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 1, 1, 8);
                                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex = iRowIndex + 3;

                                    int NextPage = iRowIndex;


                                    NewWorkSheet.Cells[iRowIndex, 1] = "Important Note:";
                                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "By accepting this quote the customer agrees with and understands that Instron will employ the “Simple Acceptance” decision rule in the calibrations provided for thedetermination of conformance to a specification or standard. The decision rule uses a shared risk approach in that uncertainty of measurement values are reported but not used in the determination of conformance.";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 8);
                                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex = iRowIndex + 4;

                                    iRowIndex++;
                                    NewWorkSheet.Cells[iRowIndex, 1] = "Please ensure that following information is clearly mentioned on your order.";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;
                                    NewWorkSheet.Cells[iRowIndex, 1] = "1) Name of person to whom should we need to submit our invoice to.";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;
                                    NewWorkSheet.Cells[iRowIndex, 1] = "2) Contact landline number as well as mobile number and email ID of designated person responsible for release of payment.";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;
                                    iRowIndex++;
                                    NewWorkSheet.Cells[iRowIndex, 1] = "If above information is not mentioned in the order, there will be a delay in processing and accepting the order.";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;
                                    iRowIndex++;
                                    NewWorkSheet.Cells[iRowIndex, 1] = "Additional Special Benefits:";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;
                                    NewWorkSheet.Cells[iRowIndex, 1] = "    • Call logging facility on Toll Free Help Line.";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;
                                    NewWorkSheet.Cells[iRowIndex, 1] = "    • Special Discount on Spares purchase.";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;
                                    iRowIndex++;
                                    NewWorkSheet.Cells[iRowIndex, 1] = "Scope of work:";
                                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "General cleaning of the system, adjustments, lubrication of mechanical and moving parts, electrical checks, testing will be done.  All the above work will be carried out as per manufacturer’s procedure by our Staff, between 09.00 am to 05.00 pm, on any of the working days i.e. Monday to Friday. You will have an assured pre-scheduled and prompt break down maintenance support from us for the stated period. This periodic maintenance will ensure 95% uptime of the aforesaid equipment";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 4, 1, 8);
                                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex = iRowIndex + 6;
                                    iRowIndex++;
                                    NewWorkSheet.Cells[iRowIndex, 1] = "Routine Pre-Scheduled Maintenance:";
                                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "All efforts will be made to complete agreed pre-scheduled maintenance visits on a mutually agreed date and within the contract period mentioned above. On occasions when the systems are not made available to us to render our Planned Preventive visits, the visit will elapse and will not be carried forward.";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 8);
                                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex = iRowIndex + 4;
                                    NewWorkSheet.Cells[iRowIndex, 1] = "NVLAP Calibration:";
                                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "Calibration will be carried out as per NVLAP Standards, which are given in the enclosed annexure. We need an advance notice of 60 days for us to plan and depute our Engineer for calibration. Calibration Certificates will be issued only in PDF Format in electronic format together with a copy of traceability certificates. ";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 8);
                                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex = iRowIndex + 4;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "Break-down Maintenance:";
                                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "This is a specially discounted per day charge applicable ONLY to AMC Customers and extra GST will be applicable.";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;
                                    iRowIndex++;
                                    NewWorkSheet.Cells[iRowIndex, 1] = "Services & Spares not covered: ";
                                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "Servicing of PC System, Hardware, Installation of PC Operating System, Servicing of servo valves, testing of Ring main Oil and servicing, cleaning of heat exchanger, wherever applicable is not included. As our maintenance contract is only for labour, any parts identified as faulty during the contract period will have to be purchased and supplied by the customer. Customer may procure the spares either from our stock at Chennai in INR or from overseas Instron Office in Foreign Currency depending on its availability.";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 4, 1, 8);
                                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex = iRowIndex + 6;

                                    NewWorkSheet.HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);


                                    NewWorkSheet.Cells[iRowIndex, 1] = "General Terms and Conditions";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    NewWorkSheet.get_Range("A" + iRowIndex + "", "D" + iRowIndex + "").Cells.Font.Size = 18;
                                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 26;
                                    NewWorkSheet.Cells[(iRowIndex), 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                    NewWorkSheet.Cells[(iRowIndex), 2].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                    NewWorkSheet.Cells[(iRowIndex), 3].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                    NewWorkSheet.Cells[(iRowIndex), 4].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                    NewWorkSheet.Cells[(iRowIndex), 5].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                    NewWorkSheet.Cells[(iRowIndex), 6].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                    NewWorkSheet.Cells[(iRowIndex), 7].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                    NewWorkSheet.Cells[(iRowIndex), 8].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                    iRowIndex++;


                                    NewWorkSheet.Cells[iRowIndex, 1] = "Customer acknowledges that the export of Goods and Technology herein is/maybe subject to the export control regulations of the United Kingdom and / or the United States, as amended. And agrees as a condition of acceptance of this quotation/contract and issuance of any subsequent order or contract hereto, that the Goods and Technology will not be used for purposes associated with any chemical, biological, nuclear weapons or missiles capable of delivering such weapons, or in support of any terrorist activity or any other military end use. Nor will they be re-sold or transferred if it is known or suspected that they are intended to be used for such purposes. In the event that any requisite governmental license, consent or permit or other authorization cannot be obtained in fulfillment of any subsequent order or contract hereto, ITW India Private Limited shall not be liable to Customer  in respect of any bond or guarantee or for any loss, damage, consequences or other resultant financial penalty We shall not be held responsible for such instruments found defective due to misuse, accident, any repairs/calibration by unauthorized personnel, fire, power fluctuations or any other unforeseen causes and we shall charge for repairs to such instruments depending upon the extent of damages. Either party has the right at any time to terminate this agreement either wholly or in part, by giving one-month notice in writing to the other party by a registered letter. Either party shall have no further liability under the terms of this agreement or all obligations under this agreement shall cease after the expiry of said period of notice. This contract is not transferable and not extended beyond the agreed period, Hence it is your responsibility to provide the system for preventive maintenance as per the schedule agreed. Validity of this proposal is 90 days.  Please make sure that our quotation number and date are clearly mentioned in your Purchase Order and your PO is issued to our Chennai Office Address Only.";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 17, 1, 8);
                                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex = iRowIndex + 18;

                                }

                                else if (cmbQuoteCompany.SelectedIndex == 0)
                                {
                                    NewWorkSheet.HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);
                                    NewWorkSheet.Cells[iRowIndex, 1] = "General Terms and Conditions";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    NewWorkSheet.get_Range("A" + iRowIndex + "", "D" + iRowIndex + "").Cells.Font.Size = 18;
                                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 26;
                                    NewWorkSheet.Cells[(iRowIndex), 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                    NewWorkSheet.Cells[(iRowIndex), 2].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                    NewWorkSheet.Cells[(iRowIndex), 3].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                    NewWorkSheet.Cells[(iRowIndex), 4].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                    NewWorkSheet.Cells[(iRowIndex), 5].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                    NewWorkSheet.Cells[(iRowIndex), 6].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                    NewWorkSheet.Cells[(iRowIndex), 7].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                    NewWorkSheet.Cells[(iRowIndex), 8].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                    iRowIndex++;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "The Terms and conditions as specified are applicable to all Interstate/Intrastate Annual Maintenance Contracts (AMC). AMC will cover 3 visits in a year and our representative will spend not more than 1 day at site for every visit.  BiSS expects complete co-operation from the customer during the AMC visits like free access to the test system area and basic accessories to expedite the trouble shooting should be made available.  This service conract will be effective for a period of 12 months from acceptance of service contract from both sides.  This contract is not transferable and not extended beyond the agree period, hence it is customer responsibility to provide the system for preventive maintenance as per the schedule agreed.";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 7, 1, 8);
                                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex = iRowIndex + 9;


                                    NewWorkSheet.Cells[iRowIndex, 1] = "Order Placement: AMC order to be placed in the name of ''ITW India Private Limited''";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 16).Font.FontStyle = "Bold";
                                    iRowIndex++;
                                    iRowIndex++;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "Duties and Taxes: All applicable taxes and duties as on date of invoice to be paid by the customer";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 16).Font.FontStyle = "Bold";
                                    iRowIndex++;
                                    iRowIndex++;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "Offer Validity: 45 days from the date of contract/from the date of opening of technical bid, whichever is earlier.";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 16).Font.FontStyle = "Bold";
                                    iRowIndex++;
                                    iRowIndex++;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "Order Acceptance:";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "All orders are subject to acceptance by ITW BISS Division. We assume acceptance by the customer on terms and conditions as stated in order acknolwedgement, if we fail to receive a reply within seven days. ";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 1, 1, 8);
                                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex = iRowIndex + 3;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "Payment Terms:";
                                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;

                                    NewWorkSheet.Cells[iRowIndex, 1] = txtpaymentterms.Text;
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 8);
                                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex = iRowIndex + 4;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "Visit Details:  Every visit wll be planned after mutual consultation and agreement between ITW - BiSS Division and the customer planned visits cannot be rescheduled.";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 1, 1, 8);
                                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 13).Font.FontStyle = "Bold";
                                    iRowIndex = iRowIndex + 3;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "Note:";
                                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "1. Calibration of transducers will be performed only once in a year.";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "2. Out of 3 AMC visits, Calibration will be performed in anyone of the AMC visit.";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;
                                    iRowIndex++;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "Pre-Scheduled Maintenance:  All efforts will be made to complete agreed pre-scheduled maintenance visits on a mutually agreed date within the contract period mentioned above.  When the systems are not made available to us to render our Planned Preventive visits, the visit will elapse and will not be carried forward and AMC charges are applicable.";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 8);
                                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 26).Font.FontStyle = "Bold";
                                    iRowIndex = iRowIndex + 4;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "Spares:  Before entering in to an AMC, we request the customers to maintain te spares of the relevant system.  The spare list of BiSS supplied systems is readily available and can be made available on request. BiSS will not be responsible if he system has to be left unattended during our visit because of shortage of spares.  The visit will be considered elapsed even f no services are rendered in such cases.";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 8);
                                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 7).Font.FontStyle = "Bold";
                                    iRowIndex = iRowIndex + 5;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "Supplies: The AMC is only a service contract and does not cover charges for any of the parts supplied or used as a replacement or as an addition during servicing/repairing the system covered under AMC.  The cost of the part replaced/added will be billed accordingly to the customer and the customer is liable to pay the charges (within 30 days) for the same with all applicable taxes as on date of invoice.";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 8);
                                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 9).Font.FontStyle = "Bold";
                                    iRowIndex = iRowIndex + 5;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "Not Covered under AMC: Servicing of PC, Monitor, Printer, Plotter, Recorder etc is out of scope of AMC.  However, problems related to application software supplied by BiSS will be part of AMC Contract.  Components that are not originally supplied by BiSS or components those are retrofitted with BiSS controls then servicing or repair of such parts is out of scope of the AMC, however BiSS will offer the similar type of components as replacement in case of failure or breakdown.";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 8);
                                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 22).Font.FontStyle = "Bold";
                                    iRowIndex = iRowIndex + 5;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "Load Calibration:  Calibration in tension and compression mode in accordance with IS 1828 (Part 1) 2015 with NABL Certified mechanical claibration devices.  Calibration Certificates will be issued together with a copy of traceability certificates of calibration device.  Calibration will be carried out from 10 to 100% of loadcell range.";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 8);
                                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 18).Font.FontStyle = "Bold";
                                    iRowIndex = iRowIndex + 4;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "Displacement/Stroke Calibration:  The displacement calibration will be done in accordance with ASTM E2309/E2309M-16 (Set-the-Displacemet Method).  Calibration will be carried out at a minimum of 10 points across the length of actuator stroke range.  Calibration Certificates will be issued together with a copy of traceability certificates of the calibration devices.";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 8);
                                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 32).Font.FontStyle = "Bold";
                                    iRowIndex = iRowIndex + 6;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "Extensometer/COD Calibration: Calibration of extensometers as per ASTM E 83 Latest version with calibration device with valid certification from NABL.  Calibration Certificates will be issued together with a copy of traceability certificates of the calibration devices.";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 8);
                                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 30).Font.FontStyle = "Bold";
                                    iRowIndex = iRowIndex + 4;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "Note: The Calibration is valid only for one year.";
                                    NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 5).Font.FontStyle = "Bold";
                                    iRowIndex++;
                                    iRowIndex++;
                                }

                            }
                            else if (cmbCeastAMC.SelectedIndex == 0)
                            {
                                NewWorkSheet.Cells[iRowIndex, 1] = "Instrument Details";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                                NewWorkSheet.Cells[iRowIndex, 6] = "Unit Price";
                                NewWorkSheet.Cells[iRowIndex, 7] = "Quantity";
                                NewWorkSheet.Cells[iRowIndex, 8] = "Amount";
                                CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);

                                iRowIndex++;

                                for (int i = 0; i < dgvCeastContract.Rows.Count; i++)
                                {
                                    for (int m = 0; m < 1; m++)
                                    {
                                        NewWorkSheet.Cells[iRowIndex, m + 1] = dgvCeastContract.Rows[i].Cells[m].Value.ToString();

                                        // Ensure WrapText is enabled for the cell
                                        NewWorkSheet.Rows[iRowIndex].WrapText = true;
                                    }

                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                                    iRowIndex++;
                                }

                                iRowIndex = iRowIndex - dgvCeastContract.Rows.Count;

                                Microsoft.Office.Interop.Excel.Range range2 = NewWorkSheet.get_Range("F" + iRowIndex, "H" + (iRowIndex + 1 + dgvCeastContract.Rows.Count));
                                range2.NumberFormat = "#,###";

                                for (int i = iRowIndex - 1; i < (dgvCeastContract.Rows.Count + iRowIndex + 4); i++)
                                {
                                    CellMerge("GridLines", NewWorkSheet, i, i, 1, 8);
                                }

                                for (int i = 0; i < dgvCeastContract.Rows.Count; i++)
                                {
                                    for (int m = 1; m < dgvCeastContract.Columns.Count; m++)
                                    {
                                        NewWorkSheet.Cells[iRowIndex, m + 5] = dgvCeastContract.Rows[i].Cells[m].Value.ToString();

                                        // Ensure WrapText is enabled for the cell
                                        NewWorkSheet.Rows[iRowIndex].WrapText = true;
                                    }

                                    iRowIndex++;
                                }

                                // AutoFit the rows to adjust the height based on content
                                NewWorkSheet.Rows.AutoFit();

                                NewWorkSheet.Cells[iRowIndex, 1] = "Total Amount";
                                NewWorkSheet.Cells[iRowIndex, 8] = sTotalAmount;
                                // Apply formatting: merge cells and set font color for discount row
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                                CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                                NewWorkSheet.Cells[iRowIndex, 8].Font.Color = Color.FromArgb(0, 0, 255);
                                CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 8, 8);

                                iRowIndex++;

                                // Calculate and insert discount
                                double grandTotal = 0;
                                if (Convert.ToDouble(txtDiscount.Text) > 0)
                                {
                                    if (double.TryParse(txtGrandTotal.Text, out grandTotal))
                                    {
                                        // Calculate the discount (difference)
                                        double discount = sTotalAmount - grandTotal;

                                        // Insert the Discount row above the "Total AMC cost excluding tax for one year"
                                        NewWorkSheet.Cells[iRowIndex, 1] = "Discount: " + txtDiscount.Text + "%";  // Add the label
                                        NewWorkSheet.Cells[iRowIndex, 8] = discount;  // Insert the discount value

                                        // Apply formatting: merge cells and set font color for discount row
                                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                                        CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                                        NewWorkSheet.Cells[iRowIndex, 8].Font.Color = Color.FromArgb(0, 0, 255);
                                        CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 8, 8);

                                        iRowIndex++;  // Increment to move to the next row for "Total AMC cost excluding tax for one year"
                                    }
                                    else
                                    {
                                        MessageBox.Show("Invalid Grand Total value. Please enter a valid number.");
                                    }
                                }


                                // Insert the Total AMC cost excluding tax for one year row
                                NewWorkSheet.Cells[iRowIndex, 1] = "Total AMC cost excluding tax for one year";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                                CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                                NewWorkSheet.Cells[iRowIndex, 8] = txtGrandTotal.Text;

                                NewWorkSheet.Cells[iRowIndex, 8].Font.Color = Color.FromArgb(0, 0, 255);
                                CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 8, 8);

                                iRowIndex++;  // Increment row index for next entry



                                NewWorkSheet.Cells[iRowIndex, 1] = "Breakdown Visit Charges";
                                CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                                CellMerge("VAlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);

                                if (!string.IsNullOrEmpty(txtbreakdownvistcharges.Text) && txtbreakdownvistcharges.Text != "0")
                                {
                                    if (cmbEnquireCurrency.SelectedIndex == 0)
                                    {
                                        NewWorkSheet.Cells[iRowIndex, 3] = "Rs " + txtbreakdownvistcharges.Text + "/- per day * This is a specially discounted per day charge applicable ONLY to AMC Customers and tax will be at extra.";
                                    }
                                    else
                                    {
                                        NewWorkSheet.Cells[iRowIndex, 3] = "USD " + txtbreakdownvistcharges.Text + "/- per day * This is a specially discounted per day charge applicable ONLY to AMC Customers will be at extra.";
                                    }
                                }
                                else
                                {
                                    NewWorkSheet.Cells[iRowIndex, 3] = "Not Applicable";
                                    CellMerge("VAlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 3, 8);
                                    CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 3, 8);
                                }

                                NewWorkSheet.Rows[iRowIndex].RowHeight = 36;
                                NewWorkSheet.Rows[iRowIndex].WrapText = true;

                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 8);
                                CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex, 3, 8);
                                iRowIndex++;
                                //  iRowIndex++;


                                NewWorkSheet.Cells[iRowIndex, 1] = "TAX : GST - 18 % - Our GSTIN - 29AAACI4550Q2Z1. Our SAC Code - 998346";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 1, 1, 8);
                                CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;
                                iRowIndex++;
                                iRowIndex++;


                                NewWorkSheet.Cells[iRowIndex, 1] = "Kindly provide us your Purchase order in the name of ITW India Private Limited, 497E, 14 Cross, 4th Phase, Peenya Industrial Area, Bangalore 560 058, Karnataka, India.";
                                CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex + 1, 1, 8);
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 1, 1, 8);
                                CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;
                                iRowIndex++;
                                iRowIndex++;

                                NewWorkSheet.Cells[iRowIndex, 1] = "Payment Terms:";
                                CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;

                                NewWorkSheet.Cells[iRowIndex, 1] = txtpaymentterms.Text;
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 8);
                                CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex = iRowIndex + 4;

                                // iRowIndex++;
                                //  iRowIndex++;
                                NewWorkSheet.Cells[iRowIndex, 1] = "Additional Special Benefits:";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;
                                NewWorkSheet.Cells[iRowIndex, 1] = "    • Call logging facility on Toll Free Help Line.";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;
                                NewWorkSheet.Cells[iRowIndex, 1] = "    • Special Discount of 7.5% on Spares purchase.";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;
                                iRowIndex++;

                                NewWorkSheet.Cells[iRowIndex, 1] = "Scope of work:";
                                CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;

                                NewWorkSheet.Cells[iRowIndex, 1] = "Electrical and mechanical operational checks.";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;

                                NewWorkSheet.Cells[iRowIndex, 1] = "Monitoring of mechanical and electrical checkpoints";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;

                                NewWorkSheet.Cells[iRowIndex, 1] = "Adjustment where possible to bring checkpoints parameters to within proper operating range.";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;

                                NewWorkSheet.Cells[iRowIndex, 1] = "recommendations on parts that should be replaced";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;

                                NewWorkSheet.Cells[iRowIndex, 1] = "Online support (Telephone + e-mail) for application problems during working hours.";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;
                                iRowIndex++;

                                NewWorkSheet.Cells[iRowIndex, 1] = "All the above work will be carried out as per manufacturer’s procedure by our Staff, between 09.00 am to 05.00 pm, on any of the working days i.e Monday to Friday. You will have an assured pre-scheduled and prompt break down maintenance support from us for the stated period. This periodic maintenance will ensure 95% uptime of the aforesaid equipment";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 8);
                                CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex = iRowIndex + 3;
                                iRowIndex++;

                                iRowIndex++;
                                NewWorkSheet.Cells[iRowIndex, 1] = "Routine Pre-Scheduled Maintenance:";
                                CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;

                                NewWorkSheet.Cells[iRowIndex, 1] = "All efforts will be made to complete agreed pre-scheduled maintenance visits on a mutually agreed date and within the contract period mentioned above. On occasions when the systems are not made available to us to render our Planned Preventive visits, the visit will elapse and will not be carried forward.";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 8);
                                CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex = iRowIndex + 4;


                                NewWorkSheet.Cells[iRowIndex, 1] = "Break-down Maintenance:";
                                CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;

                                NewWorkSheet.Cells[iRowIndex, 1] = "Any additional breakdown visits shall be charged at a special discounted rate agreed in the contract.";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;
                                iRowIndex++;
                                NewWorkSheet.Cells[iRowIndex, 1] = "Services & Spares not covered: ";
                                CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;

                                NewWorkSheet.Cells[iRowIndex, 1] = "Servicing of PC System, Hardware, Installation of PC Operating System, Repair of accessories, Reinstallation of Instron software is not included. As our maintenance contract is only for labor, any parts identified as faulty during the contract period will have to be purchased and supplied by the customer. Customer may procure the spares either from our stock at Chennai in INR or from overseas Instron- ITW Office in Foreign Currency depending on its availability.";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 8);
                                CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex = iRowIndex + 4;


                                NewWorkSheet.HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);


                                NewWorkSheet.Cells[iRowIndex, 1] = "General Terms and Conditions";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                NewWorkSheet.get_Range("A" + iRowIndex + "", "D" + iRowIndex + "").Cells.Font.Size = 18;
                                CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                NewWorkSheet.Rows[iRowIndex].RowHeight = 26;
                                NewWorkSheet.Cells[(iRowIndex), 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                NewWorkSheet.Cells[(iRowIndex), 2].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                NewWorkSheet.Cells[(iRowIndex), 3].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                NewWorkSheet.Cells[(iRowIndex), 4].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                NewWorkSheet.Cells[(iRowIndex), 5].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                NewWorkSheet.Cells[(iRowIndex), 6].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                NewWorkSheet.Cells[(iRowIndex), 7].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                NewWorkSheet.Cells[(iRowIndex), 8].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                iRowIndex++;


                                NewWorkSheet.Cells[iRowIndex, 1] = "Customer acknowledges that the export of Goods and Technology herein is/maybe subject to the export control regulations of the Italy/ or the United States, as amended. And agrees as a condition of acceptance of this quotation/contract and issuance of any subsequent order or contract hereto, that the Goods and Technology will not be used for purposes associated with any chemical, biological, nuclear weapons or missiles capable of delivering such weapons, or in support of any terrorist activity or any other military end use. Nor will they be re-sold or transferred if it is known or suspected that they are intended to be used for such purposes. In the event that any requisite governmental license, consent or permit or other authorization cannot be obtained in fulfillment of any subsequent order or contract hereto, ITW INDIA PRIVATE LIMITED, shall not be liable to Customer in respect of any bond or guarantee or for any loss, damage, consequences or other resultant financial penalty. We shall not be held responsible for such instruments found defective due to misuse, accident, any repairs / calibration by unauthorized personnel, fire, power fluctuations or any other unforeseen causes and we shall charge for repairs to such instruments depending upon the extent of damages.Either party has the right at any time to terminate this agreement either wholly or in part, by giving one - month notice in writing to the other party by a registered letter.Either party shall have no further liability under the terms of this agreement or all obligations under this agreement shall cease after the expiry of said period of notice.";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 14, 1, 8);
                                CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex = iRowIndex + 15;

                                //  iRowIndex++;

                                NewWorkSheet.Cells[iRowIndex, 1] = "This contract is not transferable and not extended beyond the agreed period, Hence it is your responsibility to provide the system for preventive maintenance as per the schedule agreed. Validity of this proposal is 90 days.  Please make sure that our quotation number and date are clearly mentioned in your Purchase Order and your PO is issued on ITW India Private Limited only.";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 8);
                                CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex = iRowIndex + 5;
                            }

                            NewWorkSheet.Cells[iRowIndex, 1] = "We hope that our quotation is in line with your expectation and look forward to receive your valued order at the earliest.";
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            iRowIndex++;
                            NewWorkSheet.Cells[iRowIndex, 1] = "Thanking you and assuring you of our best services always.";
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            iRowIndex++;
                            iRowIndex = iRowIndex + 4;

                            NewWorkSheet.Cells[iRowIndex, 1] = "Yours truly";
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            iRowIndex++;

                            NewWorkSheet.Cells[iRowIndex, 1] = "For ITW India Private Limited";
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);

                            if (login.GetUserDetails[2] == "Chaithra.K.R" || login.GetUserDetails[2] == "R Nagashree")
                            {
                                EXCEL.Range oRange2 = (EXCEL.Range)NewWorkSheet.Cells[(iRowIndex + 2), 1];
                                Image oImage2 = Image.FromFile("C:\\Databasepath\\ChaitraSign.jpg");
                                System.Windows.Forms.Clipboard.SetDataObject(oImage2, true);
                                //NewWorkSheet.Paste(oRange2, Global.sITWLogo);
                                System.Threading.Thread.Sleep(500);
                                NewWorkSheet.Paste(oRange2);

                            }

                            iRowIndex = iRowIndex + 5;

                            if (login.GetUserDetails[2] == "Chaithra.K.R" || login.GetUserDetails[2] == "R Nagashree")
                            {
                                NewWorkSheet.Cells[iRowIndex, 1] = "Chaithra.K.R";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;
                            }
                            else
                            {
                                NewWorkSheet.Cells[iRowIndex, 1] = lblRIQuoteBy.Text;
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;
                            }
                            NewWorkSheet.Cells[iRowIndex, 1] = "Asst. Manager Service and sales Coordinator,";
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            iRowIndex++;

                            if (login.GetUserDetails[2] == "Chaithra.K.R" || login.GetUserDetails[2] == "R Nagashree")
                            {
                                NewWorkSheet.Cells[iRowIndex, 1] = "Chaithra_KR@instron.com";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;
                            }
                            else
                            {
                                NewWorkSheet.Cells[iRowIndex, 1] = login.GetUserDetails[20].ToString() + "|" + login.GetUserDetails[50];
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;
                            }
                            // NewWorkSheet.Rows.AutoFit();
                            // NewWorkSheet.Columns.AutoFit();

                            NewWorkSheet.Rows[1].RowHeight = 6;
                            NewWorkSheet.Rows[2].RowHeight = 48;
                            NewWorkSheet.Rows[13].RowHeight = 68;
                            NewWorkSheet.Columns[1].ColumnWidth = 2;
                            NewWorkSheet.Columns[2].ColumnWidth = 27;
                            NewWorkSheet.Columns[3].ColumnWidth = 14;
                            NewWorkSheet.Columns[4].ColumnWidth = 14;
                            NewWorkSheet.Columns[5].ColumnWidth = 14;
                            NewWorkSheet.Columns[6].ColumnWidth = 14;
                            NewWorkSheet.Columns[7].ColumnWidth = 14;
                            NewWorkSheet.Columns[8].ColumnWidth = 22;


                            //NewWorkSheet.Columns[1].ColumnWidth = 2;
                            //NewWorkSheet.Columns[2].ColumnWidth = 32;
                            //NewWorkSheet.Columns[3].ColumnWidth = 9;
                            //NewWorkSheet.Columns[4].ColumnWidth = 9;
                            //NewWorkSheet.Columns[5].ColumnWidth = 9;
                            //NewWorkSheet.Columns[6].ColumnWidth = 9;
                            //NewWorkSheet.Columns[7].ColumnWidth = 9;
                            //NewWorkSheet.Columns[8].ColumnWidth = 42;

                            NewWorkSheet.PageSetup.PrintArea = "A1:H" + iRowIndex + "";
                            NewWorkSheet.PageSetup.LeftMargin = 0.3;
                            NewWorkSheet.PageSetup.RightMargin = 0.3;
                            NewWorkSheet.PageSetup.CenterHorizontally = true;
                            NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                            NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                            Image HeaderPicture = Image.FromFile("C:\\Databasepath\\BiSSServiceQuoteHeader.jpg");

                            NewWorkSheet.PageSetup.LeftHeader = "&\"Arial\"&10" + cmbCustomer.Text + " ";
                            //  NewWorkSheet.PageSetup.LeftHeader = "&\"Arial\"&" + customerText;

                            NewWorkSheet.PageSetup.RightHeader = "&\"Arial\"&10 QNo: " + cmbQuotationNumber.Text + " - " + cmbRevisionNumber.Text + "\nDated : " + dtpEnquireDate.Text + " ";

                            //  NewWorkSheet.PageSetup.CenterHeaderPicture = HeaderPicture;

                            NewWorkSheet.PageSetup.CenterHeaderPicture.Filename = "C:\\Databasepath\\BiSSServiceQuoteHeader.jpg";
                            NewWorkSheet.PageSetup.CenterHeader = "&G";

                            //NewWorkSheet.PageSetup.CenterFooterPicture.Filename = "C:\\Databasepath\\BiSSServiceQuoteFooter.jpg";
                            //NewWorkSheet.PageSetup.CenterFooter = "&G";

                            NewWorkSheet.PageSetup.AlignMarginsHeaderFooter = false;
                            //if (cmbEnquireCurrency.SelectedIndex == 0)
                            {
                                //.//NewWorkSheet.PageSetup.CenterFooter = "&\"Arial\"&10 All prices are in INR ";
                            }


                            if (cmbQuoteCompany.SelectedIndex == 0)
                            {
                                if (File.Exists(Global.sLogo))
                                {
                                    EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 7];
                                    Image oImage = Image.FromFile(Global.sLogo);
                                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                                    //  NewWorkSheet.Paste(oRange, Global.sLogo);
                                    System.Threading.Thread.Sleep(500);
                                    NewWorkSheet.Paste(oRange);

                                }
                            }
                            else if (cmbQuoteCompany.SelectedIndex == 1)
                            {
                                if (File.Exists(Global.sInsronLogo))
                                {
                                    EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 7];
                                    Image oImage = Image.FromFile(Global.sInsronLogo);
                                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                                    //  NewWorkSheet.Paste(oRange, Global.sInsronLogo);
                                    System.Threading.Thread.Sleep(500);
                                    NewWorkSheet.Paste(oRange);

                                }
                            }

                            if (File.Exists(Global.sITWLogo))
                            {
                                EXCEL.Range oRange1 = (EXCEL.Range)NewWorkSheet.Cells[2, 1];
                                Image oImage1 = Image.FromFile(Global.sITWLogo);
                                System.Windows.Forms.Clipboard.SetDataObject(oImage1, true);
                                // NewWorkSheet.Paste(oRange1, Global.sITWLogo);
                                System.Threading.Thread.Sleep(500);
                                NewWorkSheet.Paste(oRange1);

                            }


                            NewWorkSheet.PageSetup.RightFooter = "Page &P of &N";
                            NewWorkSheet.PageSetup.Zoom = 74;

                            if (cmbEnquireCurrency.SelectedIndex == 0)
                            {
                                NewWorkSheet.PageSetup.CenterFooter = "&\"Arial\"&10 All prices are in INR ";
                            }
                            else
                            {
                                NewWorkSheet.PageSetup.CenterFooter = "&\"Arial\"&10 All prices are in USD ";
                            }

                            NewWorkBook.Save();
                            ExcelApp.Visible = false;
                            ExcelApp.ActiveWorkbook.Saved = true;

                            // EXCEL.Worksheet Worksheet = (EXCEL.Worksheet)NewWorkBook.ActiveSheet;
                            // EXCEL.PageSetup PageSetup = Worksheet.PageSetup;
                            // NewWorkSheet.PageSetup.ResolutionX = 600;
                            //NewWorkSheet.PageSetup.ResolutionY = 600;    
                            //((Microsoft.Office.Interop.Excel._Worksheet) NewWorkBook.ActiveSheet).PageSetup.Orientation =Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                            // NewWorkBook.ExportAsFixedFormat(EXCEL.XlFixedFormatType.xlTypePDF, FileFul);
                            NewWorkBook.ExportAsFixedFormat(EXCEL.XlFixedFormatType.xlTypePDF, FileFul, EXCEL.XlFixedFormatQuality.xlQualityStandard, true);

                            //                NewWorkBook.ExportAsFixedFormat(EXCEL.XlFixedFormatType.xlTypePDF, FileFul,
                            //EXCEL.XlFixedFormatQuality.xlQualityStandard, true, true, 1, Type.Missing, true);

                            System.Diagnostics.Process.Start(FileFul);

                            NewWorkBook.Close(true, misValue, misValue);
                            ExcelApp.Quit();
                            releaseObject(NewWorkSheet);
                            releaseObject(NewWorkBook);
                            releaseObject(ExcelApp);

                            if (File.Exists(FileFullPath))
                            {
                                // File.Delete(FileFullPath);
                            }

                            dtOfferContractDeatils = DAL.fnServiceQuotationNumberLoadData(5, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];

                            if (dtOfferContractDeatils.Rows.Count > 0)
                            {
                                dgvContract.AutoGenerateColumns = false;
                                dgvContract.DataSource = dtOfferContractDeatils;
                            }

                            // ExportWorkbookToPDF(FileFullPath, FileFul);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                            foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                            {
                                GetProcess.Kill();
                            }
                        }
                    }
                }
                catch (Exception ex)
                { }
            }
        }

        string sTextAlign = "TextAlign";
        #region CellMerge Funtion
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "ThickBorder":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "GridLines":
                    {
                        CELLS.Borders.Color = System.Drawing.Color.Black;
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignCenter":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                        break;
                    }

                case "WrapText":
                    {
                        CELLS.WrapText = true;
                        break;
                    }

                case "AlignRight":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                        break;
                    }
                case "AlignLeft":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignLeft;
                        break;
                    }
                case "TextAlign":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignJustify;
                        break;
                    }
                case "AlignTop":
                    {
                        CELLS.VerticalAlignment = EXCEL.XlVAlign.xlVAlignTop;
                        break;
                    }
                case "VAlignCenter":
                    {
                        CELLS.VerticalAlignment = EXCEL.XlVAlign.xlVAlignCenter;
                        break;
                    }

                case "Bold":
                    {
                        CELLS.Font.Bold = true;
                        break;
                    }

                case "Autofit":
                    {
                        CELLS.Rows.AutoFit();
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

        }
        #endregion

        #region Excel App Release Object Function
        //private void releaseObject(object obj)
        //{
        //    try
        //    {
        //        System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
        //        obj = null;
        //    }
        //    catch (Exception ex)
        //    {
        //        obj = null;
        //        MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
        //    }
        //    finally
        //    {
        //        GC.Collect();
        //    }
        //}
        private void releaseObject(object obj)
        {
            try
            {
                Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch
            {
                obj = null;
            }
            finally
            {
                GC.Collect();
            }
        }


        #endregion


        CultureInfo culture = new CultureInfo("en-US");

        private void cmbQuotetype_SelectedIndexChanged(object sender, EventArgs e)
        {
            tabAMC.Visible = false;
            tabCalibration.Visible = false;
            tabRI.Visible = false;
            tabPI.Visible = false;
            cmbSelectQuoteType.Visible = true;
            lblStartQuote.Visible = true;
            cmbSelectQuoteType.SelectedIndex = -1;

            tabAMC.Enabled = false;
            tabRI.Enabled = false;
            tabCalibration.Enabled = false;
            tabPI.Enabled = false;

            switch (cmbQuotetype.Text)
            {
                case "AMC":
                    tabAMC.Visible = true;
                    tabAMC.Enabled = false;
                    break;
                case "Calibration":
                    tabCalibration.Visible = true;
                    tabCalibration.Enabled = false;
                    break;
                case "Re Installation Visit":
                case "Service Visit":
                    tabRI.Visible = true;
                    tabRI.Enabled = false;
                    break;
                case "Preforma Invoice":
                    tabPI.Visible = true;
                    tabPI.Enabled = false;
                    cmbPICompany.SelectedIndex = 1;
                    break;
            }
        }

        private void cmbRICustomer_SelectedIndexChanged(object sender, EventArgs e)
        {
            DR = dtCustomerList.Select("CustomerName = '" + cmbRICustomer.Text + "'");
            if (DR.Length > 0)
            {
                txtRIAddress.Text = DR[0]["Address1"].ToString() + DR[0]["Address2"].ToString() + DR[0]["Address3"].ToString();
                txtRICusCode.Text = DR[0]["CusCode"].ToString();
                TxtRIContactPerson.Text = DR[0]["ContactPerson"].ToString();
                txtRIContactNumber.Text = DR[0]["MobileNo"].ToString();
                txtRIEmail.Text = DR[0]["EmailAddress"].ToString();
            }
            else
            {
                txtRIAddress.ResetText();
                txtRICusCode.ResetText();
                TxtRIContactPerson.ResetText();
                txtRIContactNumber.ResetText();
                txtRIEmail.ResetText();
            }
        }

        private void btnGenRIVQuote_Click(object sender, EventArgs e)
        {
            if (cmbQuotetype.Text == "Re Installation Visit" || cmbQuotetype.Text == "Service Visit")
            {

                if (btnGenarateQuote.Text == "Generate Quote")
                {
                    dtQuotationNumber = DAL.fnServiceQuotationNumber(2, cmbQuotetype.Text, null).Tables[0];
                    sYear = DateTime.Today.Year.ToString();

                    if (dtQuotationNumber.Rows.Count > 0)
                    {
                        if (!string.IsNullOrEmpty(dtQuotationNumber.Rows[0]["QuoteSlNo"].ToString()))
                        {
                            LastQuoteNumber = Convert.ToInt32(dtQuotationNumber.Rows[0]["QuoteSlNo"].ToString());
                            LastQuoteNumber++;
                        }
                        else
                        {
                            LastQuoteNumber = 1;
                        }
                        string value = String.Format("{0:D3}", LastQuoteNumber);
                        if (cmbQuotetype.Text == "Re Installation Visit")
                        {
                            sQuotationNumber = (DateTime.Now.Year + "-IB" + value);
                        }
                        else if (cmbQuotetype.Text == "Service Visit")
                        {
                            sQuotationNumber = ("SD-" + DateTime.Now.Year + value);
                        }

                        InsertRIVQuote(Global.uINSERT, sQuotationNumber, "0");

                        cmbQuotationNumber.Items.Add(sQuotationNumber);
                        cmbRevisionNumber.Items.Add("0");
                        cmbQuotationNumber.SelectedIndex = 0;
                        cmbRevisionNumber.SelectedIndex = 0;
                        btnPrintRIQuote_Click(sender, e);

                        MessageBox.Show("The new quotation '" + sQuotationNumber + "' genarated successfully ", "Success", 0, MessageBoxIcon.Information);
                        btnGenarateQuote.Enabled = false;

                    }
                }
                else if (btnGenarateQuote.Text == "Update Quote")
                {

                    DialogResult DR = MessageBox.Show("Do you want to update the selected quote " + cmbQuotationNumber.Text + " and revision number " + cmbRevisionNumber.Text + "", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (DR == DialogResult.Yes)
                    {
                        InsertRIVQuote(Global.uUPDATE, cmbQuotationNumber.Text, cmbRevisionNumber.Text);
                    }
                    MessageBox.Show("The quotation '" + cmbQuotationNumber.Text + "' and revision number " + cmbRevisionNumber.Text + " updated successfully ", "Success", 0, MessageBoxIcon.Information);
                    btnGenarateQuote.Enabled = false;

                }
                else if (btnGenarateQuote.Text == "Revise Quote")
                {
                    DialogResult DR = MessageBox.Show("Do you want to revise the selected quote '" + cmbQuotationNumber.Text + "'", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (DR == DialogResult.Yes)
                    {
                        dtQuotationNumber = DAL.fnServiceQuotationNumber(4, cmbQuotationNumber.Text, cmbQuotetype.Text).Tables[0];
                        int NewRevisionNumber = 0;
                        if (dtQuotationNumber.Rows.Count > 0)
                        {
                            NewRevisionNumber = Convert.ToInt32(dtQuotationNumber.Rows[0]["RevisionNumber"].ToString());
                            NewRevisionNumber++;

                            InsertRIVQuote(Global.uINSERT, cmbQuotationNumber.Text, NewRevisionNumber.ToString());
                            MessageBox.Show("The quotation ' " + cmbQuotationNumber.Text + " ' revised to ' " + NewRevisionNumber + " '  successfully ", "Success", 0, MessageBoxIcon.Information);
                            cmbRevisionNumber.Items.Add(NewRevisionNumber.ToString()).ToString();
                            cmbRevisionNumber.SelectedItem = NewRevisionNumber.ToString();
                        }
                    }
                }
            }
            //else if (cmbQuotetype.Text == "Service Visit")
            //{
            //    dtQuotationNumber = DAL.fnServiceQuotationNumber(2, cmbQuotetype.Text, null).Tables[0];
            //    sYear = DateTime.Today.Year.ToString();
            //    if (btnGenarateQuote.Text == "Generate Quote")
            //    {
            //        if (dtQuotationNumber.Rows.Count > 0)
            //        {
            //            if (!string.IsNullOrEmpty(dtQuotationNumber.Rows[0]["QuoteSlNo"].ToString()))
            //            {
            //                LastQuoteNumber = Convert.ToInt32(dtQuotationNumber.Rows[0]["QuoteSlNo"].ToString());
            //                LastQuoteNumber++;
            //            }
            //            else
            //            {
            //                LastQuoteNumber = 1;
            //            }
            //            string value = String.Format("{0:D3}", LastQuoteNumber);
            //            if (cmbQuotetype.Text == "Service Visit")
            //            {
            //                sQuotationNumber = ("2023-BA" + value);
            //            }


            //            InsertRIVQuote(Global.uINSERT, sQuotationNumber, "0");

            //            MessageBox.Show("The new quotation '" + sQuotationNumber + "' genarated successfully ", "Success", 0, MessageBoxIcon.Information);
            //            btnGenarateQuote.Enabled = false;
            //        }
            //    }
            //    else if (btnGenarateQuote.Text == "Update Quote")
            //    {

            //        DialogResult DR = MessageBox.Show("Do you want to update the selected quote " + cmbQuotationNumber.Text + " and revision number " + cmbRevisionNumber.Text + "", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            //        if (DR == DialogResult.Yes)
            //        {
            //            InsertRIVQuote(Global.uUPDATE, cmbQuotationNumber.Text, cmbRevisionNumber.Text);
            //        }
            //        MessageBox.Show("The quotation '" + cmbQuotationNumber.Text + "' and revision number " + cmbRevisionNumber.Text + " updated successfully ", "Success", 0, MessageBoxIcon.Information);
            //        btnGenarateQuote.Enabled = false;

            //    }
            //    else if (btnGenarateQuote.Text == "Revise Quote")
            //    {
            //        DialogResult DR = MessageBox.Show("Do you want to revise the selected quote '" + cmbQuotationNumber.Text + "'", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            //        if (DR == DialogResult.Yes)
            //        {
            //            dtQuotationNumber = DAL.fnServiceQuotationNumber(4, cmbQuotationNumber.Text, null).Tables[0];
            //            int NewRevisionNumber = 0;
            //            if (dtQuotationNumber.Rows.Count > 0)
            //            {
            //                NewRevisionNumber = Convert.ToInt32(dtQuotationNumber.Rows[0]["RevisionNumber"].ToString());
            //                NewRevisionNumber++;

            //                InsertRIVQuote(Global.uINSERT, cmbQuotationNumber.Text, NewRevisionNumber.ToString());
            //                MessageBox.Show("The quotation ' " + cmbQuotationNumber.Text + " ' revised to ' " + NewRevisionNumber + " '  successfully ", "Success", 0, MessageBoxIcon.Information);
            //                cmbRevisionNumber.Items.Add(NewRevisionNumber.ToString()).ToString();
            //                cmbRevisionNumber.SelectedItem = NewRevisionNumber.ToString();
            //            }
            //        }
            //    }
            //}
        }

        DataTable dtRIAddNewItem = new DataTable();
        //private void btnRIAddNewItem_Click(object sender, EventArgs e)
        //{
        //    fnRIRowCheck();
        //    if (bRIValidattion == false)
        //    {
        //        if (dtRIAddNewItem.Rows.Count == 0)
        //        {
        //            dtRIAddNewItem = DAL.fnServiceQuotationNumberLoadData(63, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];
        //        }

        //        dtRIAddNewItem.Rows.Add(dgvRIQuoteDetails.Rows.Count + 1, " ", "0");
        //        dgvRIQuoteDetails.AutoGenerateColumns = false;
        //        dgvRIQuoteDetails.DataSource = dtRIAddNewItem;


        //    }
        //}


        private void btnRIAddNewItem_Click(object sender, EventArgs e)
        {
            fnRIRowCheck();

            if (!bRIValidattion)
            {
                if (dtRIAddNewItem.Rows.Count == 0)
                {
                    if (cmbSelectQuoteType.SelectedItem != null)
                    {
                        string quoteType = cmbSelectQuoteType.SelectedItem.ToString().ToLower();

                        if (quoteType == "update")
                        {
                            dtRIAddNewItem = DAL.fnServiceQuotationNumberLoadData(63, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];
                        }
                        else if (quoteType == "new")
                        {
                            dtRIAddNewItem = DAL.fnServiceQuotationNumberLoadData(100, cmbQuotationNumber.Text, cmbRevisionNumber.Text).Tables[0];

                        }
                    }
                }

                if (dtRIAddNewItem.Rows.Count == 0)
                {
                    dtRIAddNewItem.Rows.Add(dgvRIQuoteDetails.Rows.Count + 1, " ", "0");
                    dgvRIQuoteDetails.AutoGenerateColumns = false;
                    dgvRIQuoteDetails.DataSource = dtRIAddNewItem;
                }
                else if (dtRIAddNewItem.Rows.Count != 0)
                {
                    dtRIAddNewItem.Rows.Add(dgvRIQuoteDetails.Rows.Count + 1, " ", "0");
                    dgvRIQuoteDetails.AutoGenerateColumns = false;
                    dgvRIQuoteDetails.DataSource = dtRIAddNewItem;
                }
            }
        }


        bool bRIValidattion = false;
        private void fnRIRowCheck()
        {
            bRIValidattion = false;
            foreach (DataGridViewRow row in dgvRIQuoteDetails.Rows)
            {
                if (row.Cells[1].Value == null)
                {
                    //if (string.IsNullOrEmpty(row.Cells[1].Value.ToString().Trim()))
                    {
                        MessageBox.Show("Enter scope of work.", "Error", 0, MessageBoxIcon.Error);
                        bRIValidattion = true;
                        break;
                    }
                }
                else if (row.Cells[2].Value.ToString() == "0")
                {
                    //if (string.IsNullOrEmpty(row.Cells[2].Value.ToString().Trim()))
                    {
                        MessageBox.Show("Enter price.", "Error", 0, MessageBoxIcon.Error);
                        bRIValidattion = true;
                        break;
                    }
                }
                //else
                //{
                //    MessageBox.Show("Specifications not entered in list.", "Error", 0, MessageBoxIcon.Error);
                //    bValidattion = true;
                //    break;
                //}
            }
        }

        private void btnPrintRIQuote_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            fnFileSavePath();
            if (cmbQuotetype.Text == "Re Installation Visit")
            {
                if (cmbSelectQuoteType.Text == "New" || cmbSelectQuoteType.Text == "Update" || cmbSelectQuoteType.Text == "Revise")
                {
                    try
                    {
                        int iRowIndex = 1;
                        //string ExcelFolderName;
                        string ExcelFolderPath;
                        string FileFullPath;
                        string FileFul;
                        int title1, title2 = 0;

                        EXCEL.Workbook NewWorkBook;
                        EXCEL.Worksheet NewWorkSheet;
                        EXCEL.Application ExcelApp;
                        EXCEL.Range CELLS, cell1, cell2;
                        {
                            object misValue;

                            // ExcelFolderName = "\\Quotation";
                            string sFileQuotename = cmbQuotationNumber.Text;
                            //shreeshail is added above code
                            Regex illegalInFileName = new Regex(@"[\\/:*?""<>|]");
                            string sProjName = sFileQuotename;
                            sFileQuotename = illegalInFileName.Replace(sProjName, " ");
                            //shreeshail is added above code

                            ExcelFolderPath = Properties.Settings.Default.ServiceQuotePath;   // System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + ExcelFolderName + "\\";
                            //FileFullPath = ExcelFolderPath + "\\" + sFileQuotename + " - R" + cmbRevisionNumber.Text + " - " + cmbRICustomer.Text + " - " + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + ".xlsx"; 
                            //FileFul = ExcelFolderPath + "\\" + sFileQuotename + " - R" + cmbRevisionNumber.Text + " - " + cmbRICustomer.Text + " - " + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + ".pdf";

                            FileFullPath = ExcelFolderPath + "\\" + sFileQuotename + " - R" + cmbRevisionNumber.Text + " - " + cmbRICustomer.Text + " - " + txtRIModelNumber.Text + " - " + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + ".xlsx";
                            FileFul = ExcelFolderPath + "\\" + sFileQuotename + " - R" + cmbRevisionNumber.Text + " - " + cmbRICustomer.Text + " - " + txtRIModelNumber.Text + " - " + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + ".pdf";


                            if (!Directory.Exists(ExcelFolderPath))
                                Directory.CreateDirectory(ExcelFolderPath);

                            ExcelApp = new EXCEL.Application();
                            misValue = System.Reflection.Missing.Value;



                            try
                            {
                                if (ExcelApp == null)
                                    MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                                NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                                NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                                if (NewWorkSheet == null)
                                    MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                                else
                                    NewWorkSheet.Name = "Quote";
                                EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                                if (RANGE == null)
                                    MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                                NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                                CELLS = NewWorkSheet.Cells;


                                if (cmbRIQuotefor.SelectedIndex == 0)
                                {
                                    string[] TextN ={"","",
                                "ITW India Private Limited - "+cmbRIQuotefor.Text+" Division","497E, 14 Cross, 4th Phase, Peenya Industrial Area,",
                                "Bangalore 560 058, Karnataka,  India. ", "Phone:91(080) 28360184  FAX: (080) 28360047",
                                "Web: http://www.biss.in, Email: sales@biss.in", "", "","","",cmbRICustomer.Text,txtRIAddress.Text, "","","",
                                "Kind Attention : "+TxtRIContactPerson.Text +"","","Email : "+txtRIEmail.Text+"","",
                                "Contact No : "+txtRIContactNumber.Text+"",
                                "","","Offer No.: "+ cmbQuotationNumber.Text,
                                "Date : "+dtpRIQuoteDate.Text+"","Rev : "+cmbRevisionNumber.Text+"",""};

                                    foreach (string str in TextN)
                                    {
                                        NewWorkSheet.Cells[iRowIndex, 1] = str;
                                        // CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                        iRowIndex++;
                                    }
                                }
                                else if (cmbRIQuotefor.SelectedIndex == 1)
                                {

                                    string[] TextN1 ={"","",
                                "ITW India Private Limited - "+cmbRIQuotefor.Text+" Division","497E, 14 Cross, 4th Phase, Peenya Industrial Area,",
                                "Bangalore 560 058, Karnataka, India.","Phone:91(080) 28360184 FAX: (080) 28360047", "",
                                "", "","","",cmbRICustomer.Text,txtRIAddress.Text, "","","",
                                "Kind Attention : "+TxtRIContactPerson.Text +"","","Email : "+txtRIEmail.Text+"","",
                                "Contact No : "+txtRIContactNumber.Text+"",
                                "","","Offer No.: "+ cmbQuotationNumber.Text,
                                "Date : "+dtpRIQuoteDate.Text+"","Rev : "+cmbRevisionNumber.Text+"",""};

                                    foreach (string str in TextN1)
                                    {
                                        NewWorkSheet.Cells[iRowIndex, 1] = str;
                                        // CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                        iRowIndex++;
                                    }
                                }

                                NewWorkSheet.get_Range("A1", "H9999").Cells.Font.Name = "Arial";
                                NewWorkSheet.get_Range("A2", "H9999").Cells.Font.Size = 13;
                                CellMerge("Merge", NewWorkSheet, 13, 16, 1, 4);
                                // CellMerge("AlignLeft", NewWorkSheet, 6, 8, 1, 3);
                                NewWorkSheet.Range["A13:A13"].Cells.WrapText = true;
                                CellMerge("AlignTop", NewWorkSheet, 13, 13, 1, 2);
                                // NewWorkSheet.Range["A1:H48"].Cells.Font.Bold = true;
                                CellMerge("Bold", NewWorkSheet, 3, 3, 1, 8);
                                CellMerge("Bold", NewWorkSheet, 12, 12, 1, 8);
                                CellMerge("Bold", NewWorkSheet, 17, 46, 1, 8);

                                NewWorkSheet.Cells[19, 7] = "Contract Type : " + txtRICOntractType.Text + "";
                                NewWorkSheet.Cells[21, 7] = "Zone : " + txtRIZone.Text + "";

                                NewWorkSheet.Cells[24, 7] = "GSTIN - 29AAACI4550Q2Z1";
                                //  CellMerge("Merge", NewWorkSheet, 24, 24, 3, 4);
                                NewWorkSheet.Cells[25, 7] = "HSN - 90241000";
                                // CellMerge("Merge", NewWorkSheet, 25, 25, 3, 4);

                                if (File.Exists(Global.sCompanyLogo))
                                {
                                    EXCEL.Range oRange1 = (EXCEL.Range)NewWorkSheet.Cells[28, 1];
                                    Image oImage1 = Image.FromFile(Global.sCompanyLogo);
                                    System.Windows.Forms.Clipboard.SetDataObject(oImage1, true);
                                    // NewWorkSheet.Paste(oRange1, Global.sITWLogo);
                                    System.Threading.Thread.Sleep(500);
                                    NewWorkSheet.Paste(oRange1);

                                }


                                //NewWorkSheet.Cells[1, 3] = "Date : " + dtpQuoteDate.Text + "";
                                //NewWorkSheet.Cells[1, 5] = "Cutomer Ref.: " + txtCusref.Text + "    " + "Zone.: " + txtZone.Text + "";

                                //NewWorkSheet.Cells[45, 1] = "Prepared : " + login.GetUserDetails[2] + "";
                                //CellMerge("Merge", NewWorkSheet, 45, 45, 1, 8);
                                //CellMerge("AlignLeft", NewWorkSheet, 45, 45, 1, 8);
                                //NewWorkSheet.Cells[46, 1] = "Contact : " + login.GetUserDetails[20] + " | " + login.GetUserDetails[50] + "";
                                //CellMerge("Merge", NewWorkSheet, 46, 46, 1, 8);
                                //CellMerge("AlignLeft", NewWorkSheet, 46, 46, 1, 8);
                                //  CellMerge("Bold", NewWorkSheet, 45, 46, 1, 8);



                                NewWorkSheet.Cells[47, 1].Font.Color = Color.FromArgb(255, 0, 0);
                                NewWorkSheet.Cells[47, 1].Characters(54, 65).Font.Color = Color.FromArgb(0, 0, 255);
                                NewWorkSheet.Cells[47, 1].Characters(66, 100).Font.Color = Color.FromArgb(255, 0, 0);
                                iRowIndex = 48;

                                NewWorkSheet.HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);
                                NewWorkSheet.Cells[iRowIndex, 1] = (txtRIQuoteName.Text.Trim() + "\nModel No: " + txtRIModelNumber.Text.Trim()).Trim();
                                NewWorkSheet.Cells[iRowIndex, 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                NewWorkSheet.Range["A" + iRowIndex + ":D" + iRowIndex + ""].Cells.WrapText = true;
                                NewWorkSheet.Rows[iRowIndex].RowHeight = 70;
                                NewWorkSheet.get_Range("A" + iRowIndex + "", "D" + iRowIndex + "").Cells.Font.Size = 18;
                                CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                NewWorkSheet.Cells[iRowIndex, 1].Font.Color = Color.FromArgb(186, 12, 47);
                                iRowIndex++;
                                iRowIndex++;
                                iRowIndex++;

                                NewWorkSheet.get_Range("A" + iRowIndex + "", "H" + iRowIndex + "").Cells.Font.Size = 16;
                                NewWorkSheet.Cells[iRowIndex, 1] = "Sl No";
                                NewWorkSheet.Cells[iRowIndex, 2] = "Scope";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 2, 7);
                                CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                NewWorkSheet.Cells[iRowIndex, 8] = "Price(INR)";
                                NewWorkSheet.Cells[iRowIndex, 1].Font.Color = Color.FromArgb(186, 12, 47);
                                NewWorkSheet.Cells[iRowIndex, 2].Font.Color = Color.FromArgb(186, 12, 47);
                                NewWorkSheet.Cells[iRowIndex, 8].Font.Color = Color.FromArgb(186, 12, 47);
                                CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                                CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 2, 7);
                                CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 7, 8);

                                CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);

                                Microsoft.Office.Interop.Excel.Range range2 = NewWorkSheet.get_Range("H51", "H" + (55 + dgvRIQuoteDetails.Rows.Count) + "");
                                range2.NumberFormat = "#,###";
                                iRowIndex++;


                                CellMerge("GridLines", NewWorkSheet, (iRowIndex - 1), (iRowIndex + dgvRIQuoteDetails.Rows.Count), 1, 8);

                                for (int i = 0; i < dgvRIQuoteDetails.Rows.Count; i++)
                                {
                                    for (int m = 0; m < dgvRIQuoteDetails.Columns.Count; m++)
                                    {
                                        if (m == 0)
                                        {
                                            CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                                            CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                                            NewWorkSheet.Cells[iRowIndex, m + 1] = dgvRIQuoteDetails.Rows[i].Cells[m].Value.ToString();
                                            CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);

                                        }
                                        else if (m == 1)
                                        {
                                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 2, 7);
                                            NewWorkSheet.Cells[iRowIndex, 2] = dgvRIQuoteDetails.Rows[i].Cells[m].Value.ToString();
                                            CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 2, 2);
                                            CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 2, 2);
                                            CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                        }
                                        else if (m == 2)
                                        {
                                            //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 7, 8);
                                            NewWorkSheet.Cells[iRowIndex, 8] = dgvRIQuoteDetails.Rows[i].Cells[m].Value.ToString();
                                            CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 8, 8);
                                            CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 8, 8);
                                            CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 8, 8);
                                            CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                        }

                                        if (dgvRIQuoteDetails.Rows[i].Cells[m].Value.ToString().Length > 130 && dgvRIQuoteDetails.Rows[i].Cells[m].Value.ToString().Length < 300)
                                        {
                                            NewWorkSheet.Rows[iRowIndex].RowHeight = 320;
                                            NewWorkSheet.Rows[iRowIndex].WrapText = true;
                                        }
                                        else if (dgvRIQuoteDetails.Rows[i].Cells[m].Value.ToString().Length > 300)
                                        {
                                            NewWorkSheet.Rows[iRowIndex].RowHeight = 380;
                                            NewWorkSheet.Rows[iRowIndex].WrapText = true;
                                        }
                                    }
                                    iRowIndex++;
                                }


                                double Firststtotal = 0;

                                foreach (DataRow row in dtOfferContractDeatils.Rows)
                                {
                                    Firststtotal += Convert.ToDouble(row["Price"]);
                                }

                                NewWorkSheet.Cells[iRowIndex, 1] = "Total charges without tax";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                                CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                NewWorkSheet.Cells[iRowIndex, 8] = Math.Round(Firststtotal).ToString();
                                CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                                CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                                CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 7, 8);
                                iRowIndex++;

                                if (Convert.ToDouble(txtRIVDiscount.Text) > 0)
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1] = "Discount " + txtRIVDiscount.Text + "%";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    NewWorkSheet.Cells[iRowIndex, 8] = Math.Round(Firststtotal * (Convert.ToDouble(txtRIVDiscount.Text) / 100)).ToString();
                                    CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                                    CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                                    CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 7, 8);
                                    iRowIndex++;


                                    NewWorkSheet.Cells[iRowIndex, 1] = "Grand Total charges without tax";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    NewWorkSheet.Cells[iRowIndex, 8] = txtRIVGrandTotal.Text;
                                    CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                                    CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                                    CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 7, 8);

                                    iRowIndex++;
                                    iRowIndex++;
                                }
                                else
                                {
                                    iRowIndex++;
                                    iRowIndex++;
                                }
                                NewWorkSheet.Cells[iRowIndex, 1] = "TAX : GST - 18 % - Our GSTIN - 29AAACI4550Q2Z1. Our SAC Code - 998346 and Our Income Tax Permanent Account Number (PAN) is AAACI4550Q.";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;


                                NewWorkSheet.Cells[iRowIndex, 1] = "Kinldy release the order in favor of ITW India Private Limited, 497E, 14 Cross, 4th Phase, Peenya Industrial Area, Bangalore 560 058, Karnataka, India.";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 8);
                                CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex = iRowIndex + 4;



                                NewWorkSheet.Cells[iRowIndex, 1] = "Important Note:";
                                CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;
                                NewWorkSheet.Cells[iRowIndex, 1] = "• If any parts found to be faulty during Installation, those parts identified as faulty is to be procured by you from Instron U.S  for us to install them and make your equipment up and running, if recommended spares are available.  Our charges are purely for labor only and it does not include any spare supply.";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 8);
                                CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex = iRowIndex + 4;

                                NewWorkSheet.Cells[iRowIndex, 1] = "• Any additional days spent will be charged @ Rs. " + txtRIAdditionalCharges.Text + "/- per day*.";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;
                                iRowIndex++;
                                NewWorkSheet.Cells[iRowIndex, 1] = "Payment Terms:";
                                CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;

                                NewWorkSheet.Cells[iRowIndex, 1] = txtRIPaymentTerms.Text;
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 8);
                                CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex = iRowIndex + 3;



                                NewWorkSheet.HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);

                                //NewWorkSheet.Cells[iRowIndex, 1] = "General :";
                                //CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                //iRowIndex++;

                                NewWorkSheet.Cells[iRowIndex, 1] = "General Terms and Conditions";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                NewWorkSheet.get_Range("A" + iRowIndex + "", "D" + iRowIndex + "").Cells.Font.Size = 18;
                                CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                NewWorkSheet.Rows[iRowIndex].RowHeight = 26;
                                NewWorkSheet.Cells[(iRowIndex), 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                NewWorkSheet.Cells[(iRowIndex), 2].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                NewWorkSheet.Cells[(iRowIndex), 3].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                NewWorkSheet.Cells[(iRowIndex), 4].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                NewWorkSheet.Cells[(iRowIndex), 5].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                NewWorkSheet.Cells[(iRowIndex), 6].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                NewWorkSheet.Cells[(iRowIndex), 7].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                NewWorkSheet.Cells[(iRowIndex), 8].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                iRowIndex++;


                                NewWorkSheet.Cells[iRowIndex, 1] = "Customer  acknowledges that the export of Goods and Technology herein is/maybe subject to the export control regulations of the United Kingdom and / or the United States, as amended. And agrees as a condition of acceptance of this quotation/contract and issuance of any subsequent order or contract hereto, that the Goods and Technology will not be used for purposes associated with any chemical, biological, nuclear weapons or missiles capable of delivering such weapons, or in support of any terrorist activity or any other military end use. Nor will they be re-sold or transferred if it is known or suspected that they are intended to be used for such purposes. In the event that any requisite governmental licence, consent or permit or other authorization cannot be obtained in fulfillment of any subsequent order or contract hereto. ITW India Private Limited shall not be liable to Customer in respect of any bond or guarantee or for any loss, damage, consequences or other resultant financial penalty. We require advance notice of at least 3 weeks for us to depute our Engineer from date of receipt of your order and 100% payment in advance.";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 9, 1, 8);
                                CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex = iRowIndex + 11;

                                NewWorkSheet.Cells[iRowIndex, 1] = "Thanking you and assuring you of our best services and attention to all your needs on mutually beneficial terms.";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex = iRowIndex + 4;

                                NewWorkSheet.Cells[iRowIndex, 1] = "Yours truly";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;

                                NewWorkSheet.Cells[iRowIndex, 1] = "For ITW India Private Limited";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);

                                if (login.GetUserDetails[2] == "Chaithra.K.R" || login.GetUserDetails[2] == "R Nagashree")
                                {
                                    EXCEL.Range oRange2 = (EXCEL.Range)NewWorkSheet.Cells[(iRowIndex + 2), 1];
                                    Image oImage2 = Image.FromFile("C:\\Databasepath\\ChaitraSign.jpg");
                                    System.Windows.Forms.Clipboard.SetDataObject(oImage2, true);
                                    // NewWorkSheet.Paste(oRange2, "C:\\Databasepath\\ChaitraSign.jpg");
                                    System.Threading.Thread.Sleep(500);
                                    NewWorkSheet.Paste(oRange2);

                                }
                                iRowIndex = iRowIndex + 5;

                                if (login.GetUserDetails[2] == "Chaithra.K.R" || login.GetUserDetails[2] == "R Nagashree")
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1] = "Chaithra.K.R";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;
                                }
                                else
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1] = lblRIQuoteBy.Text;
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;
                                }
                                NewWorkSheet.Cells[iRowIndex, 1] = "Business Coordinator,";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;

                                if (login.GetUserDetails[2] == "Chaithra.K.R" || login.GetUserDetails[2] == "R Nagashree")
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1] = "Chaithra_KR@instron.com";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;
                                }
                                else
                                {

                                    NewWorkSheet.Cells[iRowIndex, 1] = login.GetUserDetails[20].ToString() + "|" + login.GetUserDetails[50];
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;
                                }


                                iRowIndex++;
                                iRowIndex++;
                                iRowIndex++;
                                int newirowindex = iRowIndex;

                                iRowIndex = newirowindex;


                                NewWorkSheet.Rows[1].RowHeight = 6;
                                NewWorkSheet.Rows[2].RowHeight = 48;
                                NewWorkSheet.Columns[1].ColumnWidth = 7;
                                NewWorkSheet.Columns[2].ColumnWidth = 37;
                                NewWorkSheet.Columns[3].ColumnWidth = 9;
                                NewWorkSheet.Columns[4].ColumnWidth = 9;
                                NewWorkSheet.Columns[5].ColumnWidth = 9;
                                NewWorkSheet.Columns[6].ColumnWidth = 9;
                                NewWorkSheet.Columns[7].ColumnWidth = 25;
                                NewWorkSheet.Columns[8].ColumnWidth = 16;


                                // CellMerge("BorderAround", NewWorkSheet, 1, iRowIndex, 1, 8);
                                //NewWorkSheet.PageSetup.PrintArea = "A1:H" + iRowIndex + "";
                                NewWorkSheet.PageSetup.PrintArea = "A1:H" + iRowIndex.ToString();
                                NewWorkSheet.PageSetup.LeftMargin = ExcelApp.InchesToPoints(0.3);  //0.5;
                                NewWorkSheet.PageSetup.RightMargin = ExcelApp.InchesToPoints(0.3);
                                NewWorkSheet.PageSetup.CenterHorizontally = true;
                                NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                                NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                                Image HeaderPicture = Image.FromFile("C:\\Databasepath\\BiSSServiceQuoteHeader.jpg");

                                //NewWorkSheet.PageSetup.LeftHeader = "&\"Arial\"&10" + cmbRICustomer.Text + " ";
                                //int fontSize = 12;  // Example of dynamic font size
                                //NewWorkSheet.PageSetup.LeftHeader = "&\"Arial\"&" + fontSize.ToString() + " " + cmbRICustomer.Text + " ";

                                // Get the customer text
                                string customerText = cmbRICustomer.Text;

                                // Check if the text length exceeds 20 characters
                                if (customerText.Length > 20)
                                {
                                    // Insert a line break after the 20th character
                                    customerText = customerText.Substring(0, 20) + "\n" + customerText.Substring(20);
                                }
                                // Add three spaces for padding to move text right
                                customerText = "    " + customerText;
                                // Set the LeftHeader with Arial font, dynamic font size, and wrapped text
                                NewWorkSheet.PageSetup.LeftHeader = "&\"Arial\"&" + customerText;
                                //NewWorkSheet.PageSetup.LeftHeader = "&\"Arial\"&" + fontSize.ToString() + " " + cmbRICustomer.Text;
                                NewWorkSheet.PageSetup.RightHeader = "&\"Arial\"&10 QNo: " + cmbQuotationNumber.Text + " - " + cmbRevisionNumber.Text + "\nDated : " + dtpRIQuoteDate.Text + " ";

                                //  NewWorkSheet.PageSetup.CenterHeaderPicture = HeaderPicture;

                                NewWorkSheet.PageSetup.CenterHeaderPicture.Filename = "C:\\Databasepath\\BiSSServiceQuoteHeader.jpg";
                                NewWorkSheet.PageSetup.CenterHeader = "&G";
                                NewWorkSheet.PageSetup.RightFooter = "Page &P of &N";
                                //NewWorkSheet.PageSetup.CenterFooterPicture.Filename = "C:\\Databasepath\\BiSSServiceQuoteFooter.jpg";
                                //NewWorkSheet.PageSetup.CenterFooter = "&G";

                                NewWorkSheet.PageSetup.AlignMarginsHeaderFooter = false;
                                //if (cmbEnquireCurrency.SelectedIndex == 0)
                                {
                                    //.//NewWorkSheet.PageSetup.CenterFooter = "&\"Arial\"&10 All prices are in INR ";
                                }


                                if (cmbRIQuotefor.SelectedIndex == 0)
                                {
                                    if (File.Exists(Global.sLogo))
                                    {
                                        EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 6];
                                        Image oImage = Image.FromFile(Global.sLogo);
                                        System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                                        // NewWorkSheet.Paste(oRange, Global.sLogo);
                                        System.Threading.Thread.Sleep(500);
                                        NewWorkSheet.Paste(oRange);
                                    }
                                }
                                else if (cmbRIQuotefor.SelectedIndex == 1)
                                {
                                    if (File.Exists(Global.sInsronLogo))
                                    {
                                        EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 6];
                                        Image oImage = Image.FromFile(Global.sInsronLogo);
                                        System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                                        //  NewWorkSheet.Paste(oRange, Global.sInsronLogo);
                                        System.Threading.Thread.Sleep(500);
                                        NewWorkSheet.Paste(oRange);
                                    }
                                }

                                if (File.Exists(Global.sITWLogo))
                                {
                                    EXCEL.Range oRange1 = (EXCEL.Range)NewWorkSheet.Cells[2, 1];
                                    Image oImage1 = Image.FromFile(Global.sITWLogo);
                                    System.Windows.Forms.Clipboard.SetDataObject(oImage1, true);
                                    //  NewWorkSheet.Paste(oRange1, Global.sITWLogo);
                                    System.Threading.Thread.Sleep(500);
                                    NewWorkSheet.Paste(oRange1);
                                }
                                NewWorkSheet.PageSetup.AlignMarginsHeaderFooter = false;

                                if (cmbRICurrency.SelectedIndex == 0)
                                {
                                    NewWorkSheet.PageSetup.CenterFooter = "&\"Arial\"&10 All prices are in INR ";
                                }
                                else
                                {
                                    NewWorkSheet.PageSetup.CenterFooter = "&\"Arial\"&10 All prices are in USD ";
                                }





                                // NewWorkSheet.PageSetup.RightFooter = "Page &P of &N";
                                NewWorkSheet.PageSetup.Zoom = 74;
                                NewWorkBook.Save();
                                ExcelApp.Visible = false;
                                ExcelApp.ActiveWorkbook.Saved = true;

                                // EXCEL.Worksheet Worksheet = (EXCEL.Worksheet)NewWorkBook.ActiveSheet;
                                // EXCEL.PageSetup PageSetup = Worksheet.PageSetup;
                                // NewWorkSheet.PageSetup.ResolutionX = 600;
                                //NewWorkSheet.PageSetup.ResolutionY = 600;    
                                //((Microsoft.Office.Interop.Excel._Worksheet) NewWorkBook.ActiveSheet).PageSetup.Orientation =Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                                // NewWorkBook.ExportAsFixedFormat(EXCEL.XlFixedFormatType.xlTypePDF, FileFul);
                                NewWorkBook.ExportAsFixedFormat(EXCEL.XlFixedFormatType.xlTypePDF, FileFul, EXCEL.XlFixedFormatQuality.xlQualityStandard, true);

                                //                NewWorkBook.ExportAsFixedFormat(EXCEL.XlFixedFormatType.xlTypePDF, FileFul,
                                //EXCEL.XlFixedFormatQuality.xlQualityStandard, true, true, 1, Type.Missing, true);

                                System.Diagnostics.Process.Start(FileFul);

                                NewWorkBook.Close(true, misValue, misValue);
                                ExcelApp.Quit();
                                releaseObject(NewWorkSheet);
                                releaseObject(NewWorkBook);
                                releaseObject(ExcelApp);

                                if (File.Exists(FileFullPath))
                                {
                                    // File.Delete(FileFullPath);
                                }

                                // ExportWorkbookToPDF(FileFullPath, FileFul);
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message);
                                foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                                {
                                    GetProcess.Kill();
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    { }
                }
            }
            else if (cmbQuotetype.Text == "Service Visit")
            {
                if (cmbSelectQuoteType.Text == "New" || cmbSelectQuoteType.Text == "Update" || cmbSelectQuoteType.Text == "Revise")

                {

                    try
                    {
                        int iRowIndex = 1;
                        //string ExcelFolderName;
                        string ExcelFolderPath;
                        string FileFullPath;
                        string FileFul;
                        int title1, title2 = 0;

                        EXCEL.Workbook NewWorkBook;
                        EXCEL.Worksheet NewWorkSheet;
                        EXCEL.Application ExcelApp;
                        EXCEL.Range CELLS, cell1, cell2;
                        {
                            object misValue;

                            // ExcelFolderName = "\\Quotation";
                            string sFileQuotename = cmbQuotationNumber.Text;
                            //shreeshail is added above code
                            Regex illegalInFileName = new Regex(@"[\\/:*?""<>|]");
                            string sProjName = sFileQuotename;
                            sFileQuotename = illegalInFileName.Replace(sProjName, " ");
                            //shreeshail is added above code
                            //+ " - " + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") +
                            ExcelFolderPath = Properties.Settings.Default.ServiceQuotePath;   // System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + ExcelFolderName + "\\";
                            //FileFullPath = ExcelFolderPath + "\\" + sFileQuotename + " - R" + cmbRevisionNumber.Text + " - " + cmbRICustomer.Text + ".xlsx";  
                            //FileFul = ExcelFolderPath + "\\" + sFileQuotename + " - R" + cmbRevisionNumber.Text + " - " + cmbRICustomer.Text  + ".pdf";

                            FileFullPath = ExcelFolderPath + "\\" + sFileQuotename + " - R" + cmbRevisionNumber.Text + " - " + cmbRICustomer.Text + " - " + txtRIModelNumber.Text + ".xlsx";
                            FileFul = ExcelFolderPath + "\\" + sFileQuotename + " - R" + cmbRevisionNumber.Text + " - " + cmbRICustomer.Text + " - " + txtRIModelNumber.Text + ".pdf";

                            if (!Directory.Exists(ExcelFolderPath))
                                Directory.CreateDirectory(ExcelFolderPath);

                            ExcelApp = new EXCEL.Application();
                            misValue = System.Reflection.Missing.Value;



                            try
                            {
                                if (ExcelApp == null)
                                    MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                                NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                                NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                                if (NewWorkSheet == null)
                                    MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                                else
                                    NewWorkSheet.Name = "Quote";
                                EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                                if (RANGE == null)
                                    MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                                NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                                CELLS = NewWorkSheet.Cells;



                                if (cmbRIQuotefor.SelectedIndex == 0)
                                {
                                    string[] TextN ={"","",
                                "ITW India Private Limited - "+cmbRIQuotefor.Text+" Division","497E, 14 Cross, 4th Phase, Peenya Industrial Area,",
                                "Bangalore 560 058, Karnataka,  India. ", "Phone:91(080) 28360184  FAX: (080) 28360047",
                                "Web: http://www.biss.in, Email: sales@biss.in", "", "","","",cmbRICustomer.Text,txtRIAddress.Text, "","","",
                                "Kind Attention : "+TxtRIContactPerson.Text +"","","Email : "+txtRIEmail.Text+"","",
                                "Contact No : "+txtRIContactNumber.Text+"",
                                "","","Offer No.: "+ cmbQuotationNumber.Text,
                                "Date : "+dtpRIQuoteDate.Text+"","Rev : "+cmbRevisionNumber.Text+"",""};

                                    foreach (string str in TextN)
                                    {
                                        NewWorkSheet.Cells[iRowIndex, 1] = str;
                                        // CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                        iRowIndex++;
                                    }
                                }
                                else if (cmbRIQuotefor.SelectedIndex == 1)
                                {

                                    string[] TextN1 ={"","",
                                "ITW India Private Limited - "+cmbRIQuotefor.Text+" Division","497E,14 Cross,4th Phase, Peenya Industrial Area,",
                                "Bangalore 560 058, Karnataka, India.", "Phone:91(080) 28360184 FAX: (080) 28360047","",
                                 "", "","","",cmbRICustomer.Text,txtRIAddress.Text, "","","",
                                "Kind Attention : "+TxtRIContactPerson.Text +"","","Email : "+txtRIEmail.Text+"","",
                                "Contact No : "+txtRIContactNumber.Text+"",
                                "","","Offer No.: "+ cmbQuotationNumber.Text,
                                "Date : "+dtpRIQuoteDate.Text+"","Rev : "+cmbRevisionNumber.Text+"",""};


                                    foreach (string str in TextN1)
                                    {
                                        NewWorkSheet.Cells[iRowIndex, 1] = str;
                                        // CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                        iRowIndex++;
                                    }
                                }

                                NewWorkSheet.get_Range("A1", "H9999").Cells.Font.Name = "Arial";
                                NewWorkSheet.get_Range("A2", "H9999").Cells.Font.Size = 13;
                                CellMerge("Merge", NewWorkSheet, 13, 16, 1, 4);
                                // CellMerge("AlignLeft", NewWorkSheet, 6, 8, 1, 3);
                                NewWorkSheet.Range["A13:A13"].Cells.WrapText = true;
                                CellMerge("AlignTop", NewWorkSheet, 13, 13, 1, 2);
                                // NewWorkSheet.Range["A1:H48"].Cells.Font.Bold = true;
                                CellMerge("Bold", NewWorkSheet, 3, 3, 1, 8);
                                CellMerge("Bold", NewWorkSheet, 12, 12, 1, 8);
                                CellMerge("Bold", NewWorkSheet, 17, 46, 1, 8);

                                NewWorkSheet.Cells[19, 7] = "Contract Type : " + txtRICOntractType.Text + "";
                                NewWorkSheet.Cells[21, 7] = "Zone : " + txtRIZone.Text + "";

                                NewWorkSheet.Cells[24, 7] = "GSTIN - 29AAACI4550Q2Z1";
                                //  CellMerge("Merge", NewWorkSheet, 24, 24, 3, 4);
                                NewWorkSheet.Cells[25, 7] = "HSN - 90241000";
                                // CellMerge("Merge", NewWorkSheet, 25, 25, 3, 4);

                                if (File.Exists(Global.sCompanyLogo))
                                {
                                    EXCEL.Range oRange1 = (EXCEL.Range)NewWorkSheet.Cells[28, 1];
                                    Image oImage1 = Image.FromFile(Global.sCompanyLogo);
                                    System.Windows.Forms.Clipboard.SetDataObject(oImage1, true);
                                    //NewWorkSheet.Paste(oRange1, Global.sITWLogo);
                                    System.Threading.Thread.Sleep(500);
                                    NewWorkSheet.Paste(oRange1);

                                }


                                //NewWorkSheet.Cells[1, 3] = "Date : " + dtpQuoteDate.Text + "";
                                //NewWorkSheet.Cells[1, 5] = "Cutomer Ref.: " + txtCusref.Text + "    " + "Zone.: " + txtZone.Text + "";

                                //NewWorkSheet.Cells[45, 1] = "Prepared : " + login.GetUserDetails[2] + "";
                                //CellMerge("Merge", NewWorkSheet, 45, 45, 1, 8);
                                //CellMerge("AlignLeft", NewWorkSheet, 45, 45, 1, 8);
                                //NewWorkSheet.Cells[46, 1] = "Contact : " + login.GetUserDetails[20] + " | " + login.GetUserDetails[50] + "";
                                //CellMerge("Merge", NewWorkSheet, 46, 46, 1, 8);
                                //CellMerge("AlignLeft", NewWorkSheet, 46, 46, 1, 8);
                                ////  CellMerge("Bold", NewWorkSheet, 45, 46, 1, 8);



                                NewWorkSheet.Cells[47, 1].Font.Color = Color.FromArgb(255, 0, 0);
                                NewWorkSheet.Cells[47, 1].Characters(54, 65).Font.Color = Color.FromArgb(0, 0, 255);
                                NewWorkSheet.Cells[47, 1].Characters(66, 100).Font.Color = Color.FromArgb(255, 0, 0);
                                iRowIndex = 48;

                                NewWorkSheet.HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);
                                NewWorkSheet.Cells[iRowIndex, 1] = (txtRIQuoteName.Text.Trim() + "\nModel No: " + txtRIModelNumber.Text.Trim()).Trim();
                                NewWorkSheet.Cells[iRowIndex, 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                NewWorkSheet.Range["A" + iRowIndex + ":D" + iRowIndex + ""].Cells.WrapText = true;
                                NewWorkSheet.Rows[iRowIndex].RowHeight = 70;
                                NewWorkSheet.get_Range("A" + iRowIndex + "", "D" + iRowIndex + "").Cells.Font.Size = 18;
                                CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                NewWorkSheet.Cells[iRowIndex, 1].Font.Color = Color.FromArgb(186, 12, 47);
                                iRowIndex++;
                                iRowIndex++;
                                iRowIndex++;

                                NewWorkSheet.get_Range("A" + iRowIndex + "", "H" + iRowIndex + "").Cells.Font.Size = 16;
                                NewWorkSheet.Cells[iRowIndex, 1] = "Sl No";
                                NewWorkSheet.Cells[iRowIndex, 2] = "Scope";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 2, 7);
                                CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);

                                //MessageBox.Show(cmbRICurrency.Text);
                                NewWorkSheet.Cells[iRowIndex, 8] = "Price("+ cmbRICurrency.Text + ")";
                                NewWorkSheet.Cells[iRowIndex, 1].Font.Color = Color.FromArgb(186, 12, 47);
                                NewWorkSheet.Cells[iRowIndex, 2].Font.Color = Color.FromArgb(186, 12, 47);
                                NewWorkSheet.Cells[iRowIndex, 8].Font.Color = Color.FromArgb(186, 12, 47);
                                CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                                CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 2, 7);
                                CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 7, 8);

                                CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);

                                Microsoft.Office.Interop.Excel.Range range2 = NewWorkSheet.get_Range("H51", "H" + (55 + dgvRIQuoteDetails.Rows.Count) + "");
                                range2.NumberFormat = "#,###";
                                iRowIndex++;

                                CellMerge("GridLines", NewWorkSheet, (iRowIndex - 1), (iRowIndex + dgvRIQuoteDetails.Rows.Count), 1, 8);
                                for (int i = 0; i < dgvRIQuoteDetails.Rows.Count; i++)
                                {
                                    int maxLength = 0;

                                    for (int m = 0; m < dgvRIQuoteDetails.Columns.Count; m++)
                                    {
                                        string cellValue = dgvRIQuoteDetails.Rows[i].Cells[m].Value?.ToString() ?? string.Empty;
                                        maxLength = Math.Max(maxLength, cellValue.Length);

                                        // Apply different formatting based on column index (m)
                                        if (m == 0)
                                        {
                                            // Merging and aligning cells for column 0
                                            CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                                            CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                            CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                                            NewWorkSheet.Cells[iRowIndex, m + 1] = cellValue;
                                        }
                                        else if (m == 1)
                                        {
                                            // Merging and aligning cells for column 1
                                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 2, 7);
                                            NewWorkSheet.Cells[iRowIndex, 2] = cellValue;
                                            CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 2, 2);
                                            CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 2, 2);
                                            CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 2, 2);
                                            CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                        }
                                        else if (m == 2)
                                        {
                                            // Merging and aligning cells for column 2
                                            NewWorkSheet.Cells[iRowIndex, 8] = cellValue;
                                            CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 8, 8);
                                            CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 8, 8);
                                            CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 8, 8);
                                            CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                        }

                                        // Enable wrap text if the text length exceeds a certain limit
                                        if (cellValue.Length > 130)
                                        {
                                            NewWorkSheet.Rows[iRowIndex].WrapText = true;
                                        }
                                    }

                                    // After populating the cells, autofit the columns (if needed)
                                    NewWorkSheet.Columns.AutoFit();  // AutoFit all columns after populating data

                                    // Dynamically adjust row height based on content length (optional scaling)
                                    int calculatedHeight = 35 + (maxLength / 10); // Example scaling factor
                                    if (calculatedHeight < 35) // Ensure minimum height
                                        calculatedHeight = 35;

                                    // Set row height based on content
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = calculatedHeight;

                                    // Wrap text for rows with long content to ensure the text is visible
                                    if (maxLength > 130)
                                    {
                                        NewWorkSheet.Rows[iRowIndex].WrapText = true;
                                    }

                                    iRowIndex++;
                                }



                                double Firststtotal = 0;

                                foreach (DataRow row in dtOfferContractDeatils.Rows)
                                {
                                    Firststtotal += Convert.ToDouble(row["Price"]);
                                }

                                NewWorkSheet.Cells[iRowIndex, 1] = "Total charges without tax";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                                CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                NewWorkSheet.Cells[iRowIndex, 8] = Math.Round(Firststtotal).ToString();
                                CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                                CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                                CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 7, 8);
                                iRowIndex++;

                                if (Convert.ToDouble(txtRIVDiscount.Text) > 0)
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1] = "Discount " + txtRIVDiscount.Text + "%";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    NewWorkSheet.Cells[iRowIndex, 8] = Math.Round(Firststtotal * (Convert.ToDouble(txtRIVDiscount.Text) / 100)).ToString();
                                    CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                                    CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                                    CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 7, 8);
                                    iRowIndex++;


                                    NewWorkSheet.Cells[iRowIndex, 1] = "Grand Total charges without tax";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    NewWorkSheet.Cells[iRowIndex, 8] = txtRIVGrandTotal.Text;
                                    CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                                    CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                                    CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 7, 8);

                                    iRowIndex++;
                                    iRowIndex++;
                                }
                                else
                                {
                                    iRowIndex++;
                                    iRowIndex++;
                                }




                                NewWorkSheet.Cells[iRowIndex, 1] = "";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;
                                NewWorkSheet.Cells[iRowIndex, 1] = "TAX : GST - 18 % - Our GSTIN - 29AAACI4550Q2Z1. Our SAC Code - 998346 and Our Income Tax Permanent Account Number (PAN) is AAACI4550Q.";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 1, 1, 8);
                                CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex = iRowIndex + 3;

                                NewWorkSheet.Cells[iRowIndex, 1] = "We request you to please send us your confirmation/purchase order at the earliest.";

                                iRowIndex++;
                                iRowIndex++;

                                NewWorkSheet.Cells[iRowIndex, 1] = "Payment Terms:";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;

                                NewWorkSheet.Cells[iRowIndex, 1] = txtRIPaymentTerms.Text.Trim();
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 4, 1, 8);
                                CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex = iRowIndex + 5;

                                if (cmbRIQuotefor.SelectedIndex == 0)
                                {

                                    NewWorkSheet.Cells[iRowIndex, 1] = "Kindly release order in favor ITW INDIA PRIVATE LIMITED";
                                    // CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 1, 1, 8);
                                    // CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    // CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;
                                    iRowIndex++;
                                }
                                else if (cmbRIQuotefor.SelectedIndex == 1)
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1] = "Kindly provide us your Purchase order in the name of ITW India Private Limited, 497E, 14 Cross, 4th Phase, Peenya Industrial Area, Bangalore 560 058, Karnataka, India.";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 1, 1, 8);
                                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;
                                    iRowIndex++;
                                    iRowIndex++;
                                }

                                NewWorkSheet.HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);



                                NewWorkSheet.Cells[iRowIndex, 1] = "General Terms and Conditions";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                NewWorkSheet.get_Range("A" + iRowIndex + "", "D" + iRowIndex + "").Cells.Font.Size = 18;
                                CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                NewWorkSheet.Rows[iRowIndex].RowHeight = 26;
                                NewWorkSheet.Cells[(iRowIndex), 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                NewWorkSheet.Cells[(iRowIndex), 2].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                NewWorkSheet.Cells[(iRowIndex), 3].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                NewWorkSheet.Cells[(iRowIndex), 4].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                NewWorkSheet.Cells[(iRowIndex), 5].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                NewWorkSheet.Cells[(iRowIndex), 6].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                NewWorkSheet.Cells[(iRowIndex), 7].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                NewWorkSheet.Cells[(iRowIndex), 8].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                                iRowIndex++;


                                NewWorkSheet.Cells[iRowIndex, 1] = "Customer acknowledges that the export of Goods and Technology herein is/maybe subject to the export control regulations of the United Kingdom and / or the United States, as amended. And agrees as a condition of acceptance of this quotation/contract and issuance of any subsequent order or contract hereto, that the Goods and Technology will not be used for purposes associated with any chemical, biological, nuclear weapons or missiles capable of delivering such weapons, or in support of any terrorist activity or any other military end use. Nor will they be re-sold or transferred if it is known or suspected that they are intended to be used for such purposes. In the event that any requisite governmental license, consent or permit or other authorization cannot be obtained in fulfillment of any subsequent order or contract hereto, ITW India Private Limited shall not be liable to Customer in respect of any bond or guarantee or for any loss, damage, consequences or other resultant financial penalty. We shall not be held responsible for such instruments found defective due to misuse, accident, any repairs/calibration by unauthorized personnel, fire, power fluctuations or any other unforeseen causes and we shall charge for repairs to such instruments depending upon the extent of damages. Either party has the right at any time to terminate this agreement either wholly or in part, by giving one-month notice in writing to the other party by a registered letter. Either party shall have no further liability under the terms of this agreement or all obligations under this agreement shall cease after the expiry of said period of notice.";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 14, 1, 8);
                                CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex = iRowIndex + 15;

                                NewWorkSheet.Cells[iRowIndex, 1] = "Thanking you and assuring you of our best services and attention to all your needs on mutually beneficial terms.";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex = iRowIndex + 4;

                                NewWorkSheet.Cells[iRowIndex, 1] = "Yours truly";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;

                                NewWorkSheet.Cells[iRowIndex, 1] = "For ITW India Private Limited";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);

                                if (login.GetUserDetails[2] == "Chaithra.K.R" || login.GetUserDetails[2] == "R Nagashree")
                                {
                                    EXCEL.Range oRange2 = (EXCEL.Range)NewWorkSheet.Cells[(iRowIndex + 2), 1];
                                    Image oImage2 = Image.FromFile("C:\\Databasepath\\ChaitraSign.jpg");
                                    System.Windows.Forms.Clipboard.SetDataObject(oImage2, true);
                                    // NewWorkSheet.Paste(oRange2, "C:\\Databasepath\\ChaitraSign.jpg");
                                    System.Threading.Thread.Sleep(500);
                                    NewWorkSheet.Paste(oRange2);

                                }
                                else if (login.GetUserDetails[2] == "Jai Barath G")
                                {
                                    EXCEL.Range oRange2 = (EXCEL.Range)NewWorkSheet.Cells[(iRowIndex + 1), 1];
                                    Image oImage2 = Image.FromFile("C:\\Databasepath\\JaibarathSign.jpg");
                                    System.Windows.Forms.Clipboard.SetDataObject(oImage2, true);
                                    //   NewWorkSheet.Paste(oRange2, "C:\\Databasepath\\JaibarathSign.jpg");
                                    System.Threading.Thread.Sleep(500);
                                    NewWorkSheet.Paste(oRange2);

                                }

                                iRowIndex = iRowIndex + 5;

                                if (login.GetUserDetails[2] == "Chaithra.K.R" || login.GetUserDetails[2] == "R Nagashree")
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1] = "Chaithra.K.R";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "Asst. Manager Service and sales Coordinator,";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;
                                }
                                else if (login.GetUserDetails[2] == "Jai Barath G")
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1] = lblRIQuoteBy.Text;
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "Tech Sales Manager,";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;
                                }
                                else
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1] = lblRIQuoteBy.Text;
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;

                                    NewWorkSheet.Cells[iRowIndex, 1] = "Business Coordinator,";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;
                                }

                                if (login.GetUserDetails[2] == "Chaithra.K.R" || login.GetUserDetails[2] == "R Nagashree")
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1] = "Chaithra_KR@instron.com";
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;
                                }
                                else
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1] = login.GetUserDetails[20].ToString() + "|" + login.GetUserDetails[50];
                                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                    iRowIndex++;
                                }
                                iRowIndex++;




                                NewWorkSheet.Rows[1].RowHeight = 6;
                                NewWorkSheet.Rows[2].RowHeight = 48;
                                NewWorkSheet.Rows[13].RowHeight = 100;
                                NewWorkSheet.Columns[1].ColumnWidth = 7;
                                NewWorkSheet.Columns[2].ColumnWidth = 37;
                                NewWorkSheet.Columns[3].ColumnWidth = 9;
                                NewWorkSheet.Columns[4].ColumnWidth = 9;
                                NewWorkSheet.Columns[5].ColumnWidth = 9;
                                NewWorkSheet.Columns[6].ColumnWidth = 9;
                                NewWorkSheet.Columns[7].ColumnWidth = 25;
                                NewWorkSheet.Columns[8].ColumnWidth = 16;


                                // CellMerge("BorderAround", NewWorkSheet, 1, iRowIndex, 1, 8);
                                NewWorkSheet.PageSetup.PrintArea = "A1:H" + iRowIndex + "";
                                NewWorkSheet.PageSetup.LeftMargin = ExcelApp.InchesToPoints(0.3);  //0.5;
                                NewWorkSheet.PageSetup.RightMargin = ExcelApp.InchesToPoints(0.3);
                                NewWorkSheet.PageSetup.CenterHorizontally = true;
                                NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                                NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                                Image HeaderPicture = Image.FromFile("C:\\Databasepath\\BiSSServiceQuoteHeader.jpg");

                                NewWorkSheet.PageSetup.LeftHeader = "&\"Arial\"&10" + cmbRICustomer.Text + "";
                                NewWorkSheet.PageSetup.RightHeader = "&\"Arial\"&10 QNo: " + cmbQuotationNumber.Text + " - " + cmbRevisionNumber.Text + "\nDated : " + dtpRIQuoteDate.Text + " ";

                                //  NewWorkSheet.PageSetup.CenterHeaderPicture = HeaderPicture;

                                NewWorkSheet.PageSetup.CenterHeaderPicture.Filename = "C:\\Databasepath\\BiSSServiceQuoteHeader.jpg";
                                NewWorkSheet.PageSetup.CenterHeader = "&G";
                                NewWorkSheet.PageSetup.RightFooter = "Page &P of &N";
                                //NewWorkSheet.PageSetup.CenterFooterPicture.Filename = "C:\\Databasepath\\BiSSServiceQuoteFooter.jpg";
                                //NewWorkSheet.PageSetup.CenterFooter = "&G";

                                NewWorkSheet.PageSetup.AlignMarginsHeaderFooter = false;
                                if (cmbRICurrency.SelectedIndex == 0)
                                {
                                    NewWorkSheet.PageSetup.CenterFooter = "&\"Arial\"&10 All prices are in INR ";
                                }
                                else
                                {
                                    NewWorkSheet.PageSetup.CenterFooter = "&\"Arial\"&10 All prices are in USD ";
                                }


                                if (cmbRIQuotefor.SelectedIndex == 0)
                                {
                                    if (File.Exists(Global.sLogo))
                                    {
                                        EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 6];
                                        Image oImage = Image.FromFile(Global.sLogo);
                                        System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                                        //  NewWorkSheet.Paste(oRange, Global.sLogo);
                                        System.Threading.Thread.Sleep(500);
                                        NewWorkSheet.Paste(oRange);

                                    }
                                }
                                else if (cmbRIQuotefor.SelectedIndex == 1)
                                {
                                    if (File.Exists(Global.sInsronLogo))
                                    {
                                        EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 6];
                                        Image oImage = Image.FromFile(Global.sInsronLogo);
                                        System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                                        // NewWorkSheet.Paste(oRange, Global.sInsronLogo);
                                        System.Threading.Thread.Sleep(500);
                                        NewWorkSheet.Paste(oRange);

                                    }
                                }

                                if (File.Exists(Global.sITWLogo))
                                {
                                    EXCEL.Range oRange1 = (EXCEL.Range)NewWorkSheet.Cells[2, 1];
                                    Image oImage1 = Image.FromFile(Global.sITWLogo);
                                    System.Windows.Forms.Clipboard.SetDataObject(oImage1, true);
                                    // NewWorkSheet.Paste(oRange1, Global.sITWLogo);
                                    System.Threading.Thread.Sleep(500);
                                    NewWorkSheet.Paste(oRange1);

                                }
                                NewWorkSheet.PageSetup.AlignMarginsHeaderFooter = false;





                                // NewWorkSheet.PageSetup.RightFooter = "Page &P of &N";
                                NewWorkSheet.PageSetup.Zoom = 74;
                                NewWorkBook.Save();
                                ExcelApp.Visible = false;
                                ExcelApp.ActiveWorkbook.Saved = true;

                                // EXCEL.Worksheet Worksheet = (EXCEL.Worksheet)NewWorkBook.ActiveSheet;
                                // EXCEL.PageSetup PageSetup = Worksheet.PageSetup;
                                // NewWorkSheet.PageSetup.ResolutionX = 600;
                                //NewWorkSheet.PageSetup.ResolutionY = 600;    
                                //((Microsoft.Office.Interop.Excel._Worksheet) NewWorkBook.ActiveSheet).PageSetup.Orientation =Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                                // NewWorkBook.ExportAsFixedFormat(EXCEL.XlFixedFormatType.xlTypePDF, FileFul);
                                NewWorkBook.ExportAsFixedFormat(EXCEL.XlFixedFormatType.xlTypePDF, FileFul, EXCEL.XlFixedFormatQuality.xlQualityStandard, true);

                                //                NewWorkBook.ExportAsFixedFormat(EXCEL.XlFixedFormatType.xlTypePDF, FileFul,
                                //EXCEL.XlFixedFormatQuality.xlQualityStandard, true, true, 1, Type.Missing, true);

                                System.Diagnostics.Process.Start(FileFul);

                                NewWorkBook.Close(true, misValue, misValue);
                                ExcelApp.Quit();
                                releaseObject(NewWorkSheet);
                                releaseObject(NewWorkBook);
                                releaseObject(ExcelApp);

                                if (File.Exists(FileFullPath))
                                {
                                    // File.Delete(FileFullPath);
                                    //shreeshail is added
                                    ExcelApp.Quit();
                                }

                                // ExportWorkbookToPDF(FileFullPath, FileFul);
                            }
                            catch (Exception ex)
                            {
                                //MessageBox.Show(ex.Message);

                            }
                            finally
                            {
                                //shreeshail is added
                                ExcelApp.Quit();

                            }
                        }
                    }
                    catch (Exception ex)
                    { }
                }
            }
        }
        double oldvalue = 0;
        private void dgvContract_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvContract.CurrentCell.OwningColumn.Name == "ContractValue1stYear")
            {
                if (!string.IsNullOrEmpty(dgvContract.CurrentCell.Value.ToString()) && (dgvContract.CurrentCell.Value.ToString() != "."))// != null)
                {
                    if (chk3Years.Checked)
                    {
                        dgvContract.CurrentRow.Cells["ContractValue2ndYear"].Value = Math.Round(Convert.ToDouble(dgvContract.CurrentRow.Cells["ContractValue1stYear"].Value) + Convert.ToDouble(dgvContract.CurrentRow.Cells["ContractValue1stYear"].Value) * (Convert.ToDouble(txtContractValue.Text) / 100)).ToString();
                        dgvContract.CurrentRow.Cells["ContractValue3rdYear"].Value = Math.Round(Convert.ToDouble(dgvContract.CurrentRow.Cells["ContractValue2ndYear"].Value) + Convert.ToDouble(dgvContract.CurrentRow.Cells["ContractValue2ndYear"].Value) * (Convert.ToDouble(txtContractValue.Text) / 100)).ToString();
                        dgvContract.CurrentRow.Cells["ContractValue4thYear"].Value = 0;
                        dgvContract.CurrentRow.Cells["ContractValue5thYear"].Value = 0;
                    }
                    if (chk5Years.Checked)
                    {
                        dgvContract.CurrentRow.Cells["ContractValue2ndYear"].Value = Math.Round(Convert.ToDouble(dgvContract.CurrentRow.Cells["ContractValue1stYear"].Value) + Convert.ToDouble(dgvContract.CurrentRow.Cells["ContractValue1stYear"].Value) * (Convert.ToDouble(txtContractValue.Text) / 100)).ToString();
                        dgvContract.CurrentRow.Cells["ContractValue3rdYear"].Value = Math.Round(Convert.ToDouble(dgvContract.CurrentRow.Cells["ContractValue2ndYear"].Value) + Convert.ToDouble(dgvContract.CurrentRow.Cells["ContractValue2ndYear"].Value) * (Convert.ToDouble(txtContractValue.Text) / 100)).ToString();
                        dgvContract.CurrentRow.Cells["ContractValue4thYear"].Value = Math.Round(Convert.ToDouble(dgvContract.CurrentRow.Cells["ContractValue3rdYear"].Value) + Convert.ToDouble(dgvContract.CurrentRow.Cells["ContractValue3rdYear"].Value) * (Convert.ToDouble(txtContractValue.Text) / 100)).ToString();
                        dgvContract.CurrentRow.Cells["ContractValue5thYear"].Value = Math.Round(Convert.ToDouble(dgvContract.CurrentRow.Cells["ContractValue4thYear"].Value) + Convert.ToDouble(dgvContract.CurrentRow.Cells["ContractValue4thYear"].Value) * (Convert.ToDouble(txtContractValue.Text) / 100)).ToString();
                    }

                    txtDiscount_TextChanged(sender, e);
                }

                else
                {
                    dgvContract.CurrentCell.Value = oldvalue;
                }
            }
        }

        private void dgvContract_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgvContract.CurrentCell.OwningColumn.Name == "ContractValue1stYear" || dgvContract.CurrentCell.OwningColumn.Name == "ContractValue2ndYear" || dgvContract.CurrentCell.OwningColumn.Name == "ContractValue3rdYear"
                 || dgvContract.CurrentCell.OwningColumn.Name == "ContractValue4thYear" || dgvContract.CurrentCell.OwningColumn.Name == "ContractValue5thYear")
            {
                oldvalue = Convert.ToDouble(dgvContract.CurrentCell.Value);
            }
        }

        private void dgvContract_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {

            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
            }
        }

        private void Control_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (dgvContract.CurrentCell.OwningColumn.Index == 0 || dgvContract.CurrentCell.OwningColumn.Index == 1 || dgvContract.CurrentCell.OwningColumn.Index == 2
                || dgvContract.CurrentCell.OwningColumn.Index == 3 || dgvContract.CurrentCell.OwningColumn.Index == 4)
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
                {
                    e.Handled = true;
                }
                if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
                {
                    e.Handled = true;
                }
            }

        }

        private void Control_KeyPress2(object sender, KeyPressEventArgs e)
        {
            if (dgvCALCalibrationDetails.CurrentCell.OwningColumn.Index == 2)
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
                {
                    e.Handled = true;
                }
                if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
                {
                    e.Handled = true;
                }
            }

        }

        private void Control_KeyPress3(object sender, KeyPressEventArgs e)
        {
            if (dgvRIQuoteDetails.CurrentCell.OwningColumn.Index == 2)
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
                {
                    e.Handled = true;
                }
                if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
                {
                    e.Handled = true;
                }
            }

        }

        private void fnNumberKeyPressOnly(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            else if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
            if (e.KeyChar == 8)
            {
                if (((TextBox)sender).Text == "" || (((TextBox)sender).Text.Length < 1))
                {
                    ((TextBox)sender).Text = "0";
                }
            }
        }

        private void txtbreakdownvistcharges_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnNumberKeyPressOnly(sender, e);
        }

        private void txtContractValue_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnNumberKeyPressOnly(sender, e);
        }

        private void txtDiscount_TextChanged(object sender, EventArgs e)
        {
            if (txtDiscount.TextLength > 0)
            {
                if (cmbCeastAMC.SelectedIndex == 0)
                {
                    fnCeastCalculation();
                    txtGrandTotal.Text = Math.Round(sTotalAmount - sTotalAmount * (Convert.ToDouble(txtDiscount.Text) / 100)).ToString();
                }
                else
                {
                    fnOICalculation();
                    txtGrandTotal.Text = Math.Round(sTotalAmount - sTotalAmount * (Convert.ToDouble(txtDiscount.Text) / 100)).ToString();
                }
            }
            else
            {
                txtDiscount.Text = "0";

            }
        }
        double sTotalAmount = 0;
        private void fnOICalculation()
        {
            sTotalAmount = 0;
            foreach (DataGridViewRow dgvr in dgvContract.Rows)
            {
                sTotalAmount += Convert.ToDouble(dgvr.Cells["ContractValue1stYear"].Value);
                sTotalAmount += Convert.ToDouble(dgvr.Cells["ContractValue2ndYear"].Value);
                sTotalAmount += Convert.ToDouble(dgvr.Cells["ContractValue3rdYear"].Value);
                sTotalAmount += Convert.ToDouble(dgvr.Cells["ContractValue4thYear"].Value);
                sTotalAmount += Convert.ToDouble(dgvr.Cells["ContractValue5thYear"].Value);
            }

            sTotalAmount = Math.Round(sTotalAmount);
        }

        private void fnCeastCalculation()
        {
            sTotalAmount = 0;
            foreach (DataGridViewRow dgvr in dgvCeastContract.Rows)
            {
                sTotalAmount += Convert.ToDouble(dgvr.Cells["UnitPrice"].Value) * Convert.ToDouble(dgvr.Cells["Quantity"].Value);
            }

            sTotalAmount = Math.Round(sTotalAmount);

            // txtGrandTotal.Text = sTotalAmount.ToString();
        }

        private void txtDiscount_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnNumberKeyPressOnly(sender, e);
        }

        private void txtContractValue_TextChanged(object sender, EventArgs e)
        {
            if (txtContractValue.TextLength > 0)
            {
            }
            else
            {
                txtContractValue.Text = "0";
            }
        }

        private void txtbreakdownvistcharges_TextChanged(object sender, EventArgs e)
        {
            if (txtbreakdownvistcharges.TextLength > 0)
            {
            }
            else
            {
                txtbreakdownvistcharges.Text = "0";
            }
        }

        private void dgvRIQuoteDetails_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (dgvRIQuoteDetails.Rows.Count > 0)
                {
                    DialogResult DR = MessageBox.Show("Do you want to delete selected row", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (DR == DialogResult.Yes)
                    {
                        dgvRIQuoteDetails.Rows.RemoveAt(dgvRIQuoteDetails.Rows.IndexOf(dgvRIQuoteDetails.CurrentRow));

                        if (dgvRIQuoteDetails.Rows.Count > 0)
                        {
                            int i = 1;
                            foreach (DataGridViewRow row in dgvRIQuoteDetails.Rows)
                            {
                                row.Cells[0].Value = i;
                                i++;
                            }
                        }
                    }
                }
            }
        }

        private void dgvContract_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (dgvContract.Rows.Count > 0)
                {
                    DialogResult DR = MessageBox.Show("Do you want to delete selected row", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (DR == DialogResult.Yes)
                    {
                        dgvContract.Rows.RemoveAt(dgvContract.Rows.IndexOf(dgvContract.CurrentRow));
                        txtDiscount_TextChanged(sender, e);
                    }
                }
            }
        }

        private void dgvNVLAP_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (dgvNVLAP.Rows.Count > 0)
                {
                    DialogResult DR = MessageBox.Show("Do you want to delete selected row", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (DR == DialogResult.Yes)
                    {
                        dgvNVLAP.Rows.RemoveAt(dgvNVLAP.Rows.IndexOf(dgvNVLAP.CurrentRow));

                        if (dgvNVLAP.Rows.Count > 0)
                        {
                            int i = 1;
                            foreach (DataGridViewRow row in dgvNVLAP.Rows)
                            {
                                row.Cells[0].Value = i;
                                i++;
                            }
                        }
                    }
                }
            }
        }

        private void btnCalStartQuote_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCALCusRef.Text))
            {
                MessageBox.Show("Enter contract type", "Information", 0, MessageBoxIcon.Warning);
                txtCALCusRef.Focus();
            }

            else if (string.IsNullOrEmpty(txtCalZone.Text))
            {
                MessageBox.Show("Enter zone number", "Information", 0, MessageBoxIcon.Warning);
                txtCalZone.Focus();
            }
            else if (string.IsNullOrEmpty(cmbCALCustomer.Text))
            {
                MessageBox.Show("Enter or select customer name", "Information", 0, MessageBoxIcon.Warning);
                cmbCALCustomer.Focus();
            }
            else if (string.IsNullOrEmpty(txtCALAddress.Text))
            {
                MessageBox.Show("Enter customer address", "Information", 0, MessageBoxIcon.Warning);
                txtCALAddress.Focus();
            }

            else if (string.IsNullOrEmpty(txtCALContactPerson.Text))
            {
                MessageBox.Show("Enter contact person", "Information", 0, MessageBoxIcon.Warning);
                txtCALContactPerson.Focus();
            }

            else if (string.IsNullOrEmpty(txtCALEmailID.Text))
            {
                MessageBox.Show("Enter customer email id", "Information", 0, MessageBoxIcon.Warning);
                txtCALEmailID.Focus();
            }

            else if (string.IsNullOrEmpty(txtCALHandy.Text))
            {
                MessageBox.Show("Enter contact number", "Information", 0, MessageBoxIcon.Warning);
                txtCALHandy.Focus();
            }
            else if (CmbCurrency.SelectedIndex == -1)
            {
                MessageBox.Show("Select quote currency to start quote ", "Information", 0, MessageBoxIcon.Warning);
                CmbCurrency.DroppedDown = true;
            }
            else if (cmbCALQuoteFor.SelectedIndex == -1)
            {
                MessageBox.Show("Select quotation for to start quote ", "Information", 0, MessageBoxIcon.Warning);
                cmbCALQuoteFor.DroppedDown = true;
            }
            else if (string.IsNullOrEmpty(txtCalQuotename.Text))
            {
                MessageBox.Show("Enter quote name", "Information", 0, MessageBoxIcon.Warning);
                txtCalQuotename.Focus();
            }
            /*
            else if (!bCalibrationDate)
            {
                MessageBox.Show("Select calibration due date", "Information", 0, MessageBoxIcon.Warning);
                dtpCalibrationDate.Show();
            }
            else if (!bMutualyAgreedDate)
            {
                MessageBox.Show("Select mutually agreed date", "Information", 0, MessageBoxIcon.Warning);
                dtpMutualyAgreedDate.Show();
            }
            */
            else if (string.IsNullOrEmpty(txtCALModelNo.Text))
            {
                MessageBox.Show("Enter model serial number", "Information", 0, MessageBoxIcon.Warning);
                txtCALModelNo.Focus();
            }
            else
            {
                tabCalibration.SelectTab(1);
            }
        }

        bool bCalibrationDate = false;
        private void dtpCalibrationDate_ValueChanged(object sender, EventArgs e)
        {
            bCalibrationDate = true;
        }
        bool bMutualyAgreedDate = false;
        private void dtpMutualyAgreedDate_ValueChanged(object sender, EventArgs e)
        {
            bMutualyAgreedDate = true;
        }

        bool bCALValidattion = false;
        private void fnCALRowCheck()
        {
            bCALValidattion = false;
            foreach (DataGridViewRow row in dgvCALCalibrationDetails.Rows)
            {
                if (string.IsNullOrEmpty(row.Cells[1].Value.ToString().Trim()))
                {
                    MessageBox.Show("NVLAP Calibrations details not entered in list.", "Error", 0, MessageBoxIcon.Error);
                    bCALValidattion = true;
                    break;
                }

                else if ((row.Cells[2].Value.ToString().Trim()) == "0")
                {
                    MessageBox.Show("NVLAP Calibrations price not entered in list.", "Error", 0, MessageBoxIcon.Error);
                    bCALValidattion = true;
                    break;
                }
            }
        }

        private void btnCALAddItem_Click(object sender, EventArgs e)
        {
            fnCALRowCheck();
            if (bCALValidattion == false)
            {
                if (dtOfferItemDeatils.Rows.Count == 0)
                {
                    dtOfferItemDeatils = DAL.fnServiceQuoteNumber(6, "", "").Tables[0];
                }

                dtOfferItemDeatils.Rows.Add(dgvCALCalibrationDetails.Rows.Count + 1, "", 0);
                dgvCALCalibrationDetails.DataSource = dtOfferItemDeatils;

            }
        }

        private void dgvCALCalibrationDetails_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgvCALCalibrationDetails.CurrentCell.OwningColumn.Name == "Price")
            {
                oldvalue = Convert.ToDouble(dgvCALCalibrationDetails.CurrentCell.Value);
            }
        }

        private void dgvCALCalibrationDetails_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvCALCalibrationDetails.CurrentCell.OwningColumn.Name == "Price")
            {
                if (!string.IsNullOrEmpty(dgvCALCalibrationDetails.CurrentCell.Value.ToString()) && (dgvCALCalibrationDetails.CurrentCell.Value.ToString() != "."))// != null)
                {
                    txtCALDiscount_TextChanged(sender, e);
                }

                else
                {
                    dgvCALCalibrationDetails.CurrentCell.Value = oldvalue;
                }
            }
        }

        private void dgvCALCalibrationDetails_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress2);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
            }
        }
        //BHAVYA
        //private void txtCALDiscount_TextChanged(object sender, EventArgs e)
        //{
        //    if (txtCALDiscount.TextLength > 0)
        //    {
        //        fnCALOICalculation();
        //        txtCALGrandTotal.Text = Math.Round(sTotalAmount - sTotalAmount * (Convert.ToDouble(txtCALDiscount.Text) / 100)).ToString();
        //    }
        //    else
        //    {
        //        txtCALDiscount.Text = "0";
        //    }
        //}BHAVYA


        private void txtCALDiscount_TextChanged(object sender, EventArgs e)
        {
            if (double.TryParse(txtCALDiscount.Text, out double discount))
            {
                fnCALOICalculation();
                txtCALGrandTotal.Text = Math.Round(sTotalAmount - sTotalAmount * (discount / 100)).ToString();
            }
            else
            {
                txtCALDiscount.Text = "0";
            }
        }


        private void txtCALDiscount_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnNumberKeyPressOnly(sender, e);
        }

        private void fnCALOICalculation()
        {
            sTotalAmount = 0;
            foreach (DataGridViewRow dgvr in dgvCALCalibrationDetails.Rows)
            {
                sTotalAmount += Convert.ToDouble(dgvr.Cells["Price"].Value);
            }

            sTotalAmount = Math.Round(sTotalAmount);
        }

        private void cmbCALCustomer_SelectedIndexChanged(object sender, EventArgs e)
        {
            DR = dtCustomerList.Select("CustomerName = '" + cmbCALCustomer.Text + "'");
            if (DR.Length > 0)
            {
                txtCALAddress.Text = DR[0]["Address1"].ToString() + DR[0]["Address2"].ToString() + DR[0]["Address3"].ToString();
                txtCALCusCode.Text = DR[0]["CusCode"].ToString();
                txtCALContactPerson.Text = DR[0]["ContactPerson"].ToString();
                txtCALHandy.Text = DR[0]["MobileNo"].ToString();
                txtCALEmailID.Text = DR[0]["EmailAddress"].ToString();
            }
            else
            {
                txtCALAddress.ResetText();
                txtCALCusCode.ResetText();
                txtCALContactPerson.ResetText();
                txtCALHandy.ResetText();
                txtCALEmailID.ResetText();
            }
        }

        private void dgvCALCalibrationDetails_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (dgvCALCalibrationDetails.Rows.Count > 0)
                {
                    DialogResult DR = MessageBox.Show("Do you want to delete selected row", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (DR == DialogResult.Yes)
                    {
                        dgvCALCalibrationDetails.Rows.RemoveAt(dgvCALCalibrationDetails.Rows.IndexOf(dgvCALCalibrationDetails.CurrentRow));

                        if (dgvCALCalibrationDetails.Rows.Count > 0)
                        {
                            int i = 1;
                            foreach (DataGridViewRow row in dgvCALCalibrationDetails.Rows)
                            {
                                row.Cells[0].Value = i;
                                i++;
                            }
                        }
                    }
                }
            }
        }

        private void btnCALGenerateQuote_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtCALPaymentTerms.Text) && dgvCALCalibrationDetails.Rows.Count > 0)//&& !string.IsNullOrEmpty(txtpaymentterms.Text))
            {
                if (btnGenarateQuote.Text == "Generate Quote")
                {
                    dtQuotationNumber = DAL.fnServiceQuotationNumber(0, cmbQuotetype.Text, null).Tables[0];
                    sYear = DateTime.Today.Year.ToString();
                    if (dtQuotationNumber.Rows.Count > 0)
                    {
                        if (!string.IsNullOrEmpty(dtQuotationNumber.Rows[0]["QuoteSlNo"].ToString()))
                        {
                            LastQuoteNumber = Convert.ToInt32(dtQuotationNumber.Rows[0]["QuoteSlNo"].ToString());
                            LastQuoteNumber++;
                        }
                        else
                        {
                            LastQuoteNumber = 1;
                        }
                        string value = String.Format("{0:D3}", LastQuoteNumber);
                        sQuotationNumber = (DateTime.Now.Year + "-CB" + value);

                        InsertCALQuote(Global.uINSERT, sQuotationNumber, "0");

                        cmbQuotationNumber.Items.Add(sQuotationNumber);
                        cmbRevisionNumber.Items.Add("0");
                        cmbQuotationNumber.SelectedIndex = 0;
                        cmbRevisionNumber.SelectedIndex = 0;
                        btnCALPrintQuote_Click(sender, e);

                        MessageBox.Show("The new quotation '" + sQuotationNumber + "' genarated successfully ", "Success", 0, MessageBoxIcon.Information);
                        btnCALGenerateQuote.Enabled = false;
                    }
                }
                else if (btnGenarateQuote.Text == "Update Quote")
                {
                    DialogResult DR = MessageBox.Show("Do you want to update the selected quote " + cmbQuotationNumber.Text + " and revision number " + cmbRevisionNumber.Text + "", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (DR == DialogResult.Yes)
                    {
                        InsertCALQuote(Global.uUPDATE, cmbQuotationNumber.Text, cmbRevisionNumber.Text);
                    }
                    MessageBox.Show("The quotation '" + cmbQuotationNumber.Text + "' and revision number " + cmbRevisionNumber.Text + " updated successfully ", "Success", 0, MessageBoxIcon.Information);
                    btnCALGenerateQuote.Enabled = false;
                }
                else if (btnGenarateQuote.Text == "Revise Quote")
                {
                    DialogResult DR = MessageBox.Show("Do you want to revise the selected quote '" + cmbQuotationNumber.Text + "'", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (DR == DialogResult.Yes)
                    {
                        dtQuotationNumber = DAL.fnServiceQuotationNumber(3, cmbQuotationNumber.Text, cmbQuotetype.Text).Tables[0];
                        int NewRevisionNumber = 0;
                        if (dtQuotationNumber.Rows.Count > 0)
                        {
                            NewRevisionNumber = Convert.ToInt32(dtQuotationNumber.Rows[0]["RevisionNumber"].ToString());
                            NewRevisionNumber++;

                            InsertCALQuote(Global.uINSERT, cmbQuotationNumber.Text, NewRevisionNumber.ToString());
                            MessageBox.Show("The quotation ' " + cmbQuotationNumber.Text + " ' revised to ' " + NewRevisionNumber + " '  successfully ", "Success", 0, MessageBoxIcon.Information);
                            cmbRevisionNumber.Items.Add(NewRevisionNumber.ToString()).ToString();
                            cmbRevisionNumber.SelectedItem = NewRevisionNumber.ToString();
                            btnCALGenerateQuote.Enabled = false;
                        }
                    }
                }
            }
            else
            {
                if (string.IsNullOrEmpty(txtCALPaymentTerms.Text))
                {
                    MessageBox.Show("Enter payment terms", "Information", 0, MessageBoxIcon.Warning);
                    txtCALPaymentTerms.Focus();
                }
                else if (dgvCALCalibrationDetails.Rows.Count == 0)
                {
                    MessageBox.Show("Enter contract details", "Information", 0, MessageBoxIcon.Warning);
                    dgvCALCalibrationDetails.Focus();
                }
                //else if (string.IsNullOrEmpty(txtbreakdownvistcharges.Text))
                //{
                //    MessageBox.Show("Enter breakdown visit charges", "Information", 0, MessageBoxIcon.Warning);
                //    txtbreakdownvistcharges.Focus();
                //}
            }
        }

        private void btnCALPrintQuote_Click(object sender, EventArgs e)
        {

            Cursor.Current = Cursors.WaitCursor;
            fnFileSavePath();
            if (cmbSelectQuoteType.Text == "New" || cmbSelectQuoteType.Text == "Update" || cmbSelectQuoteType.Text == "Revise")
            {

                try
                {
                    int iRowIndex = 1;
                    //string ExcelFolderName;
                    string ExcelFolderPath;
                    string FileFullPath;
                    string FileFul;
                    int title1, title2 = 0;

                    EXCEL.Workbook NewWorkBook;
                    EXCEL.Worksheet NewWorkSheet;
                    EXCEL.Application ExcelApp;
                    EXCEL.Range CELLS, cell1, cell2;
                    {
                        object misValue;




                        // ExcelFolderName = "\\Quotation";
                        string sFileQuotename = cmbQuotationNumber.Text;
                        //shreeshail is added below 2 line
                        //shreeshail is added above code
                        Regex illegalInFileName = new Regex(@"[\\/:*?""<>|]");
                        string sProjName = sFileQuotename;
                        sFileQuotename = illegalInFileName.Replace(sProjName, " ");
                        //shreeshail is added above line

                        ExcelFolderPath = Properties.Settings.Default.ServiceQuotePath;   // System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + ExcelFolderName + "\\";
                                                                                          //FileFullPath = ExcelFolderPath + "\\" + sFileQuotename + " - R" + cmbRevisionNumber.Text +  " - " + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + ".xlsx"; 
                                                                                          //FileFul = ExcelFolderPath + "\\" + sFileQuotename + " - R" + cmbRevisionNumber.Text + " - "  + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + ".pdf";

                        FileFullPath = ExcelFolderPath + "\\" + sFileQuotename + " - R" + cmbRevisionNumber.Text + " - " + cmbCALCustomer.Text + " - " + txtCALModelNo.Text + " - " + DateTime.Now.ToString("yyyy-MM-dd HH-mm-ss") + ".xlsx"; //("d/M/yyyy hh/mm/ss")+ ".xlsx";
                        FileFul = ExcelFolderPath + "\\" + sFileQuotename + " - R" + cmbRevisionNumber.Text + " - " + cmbCALCustomer.Text + " - " + txtCALModelNo.Text + " - " + DateTime.Now.ToString("yyyy-MM-dd HH-mm-ss") + ".pdf"; //("d/M/yyyy hh/mm/ss") +".pdf";
                        //     FileFul = ExcelFolderPath + "\\" + sFileQuotename + " - " + cmbCustomer.Text + " - " + txtModelslno.Text + ".pdf";

                        //string[] TextN ={"","",
                        //        "ITW India Private Limited - "+cmbCALQuoteFor.Text+" Division","497E, 14 Cross, 4th Phase, Peenya Industrial Area,",
                        //        "Bangalore 560 058, Karnataka,  India. ", "Phone:91(080) 28360184  FAX: (080) 28360047",
                        //        "Web: http://www.biss.in, Email: sales@biss.in", "", "","","",cmbCALCustomer.Text,txtCALAddress.Text, "","","",
                        //        "Kind Attention : "+txtCALContactPerson.Text +"","","Email : "+txtCALEmailID.Text+"","",
                        //        "Contact No : "+txtCALHandy.Text+"",
                        //        "","","Offer No.: "+ cmbQuotationNumber.Text,
                        //        "Date : "+dtpCALDateofQuote.Text+"","Rev : "+cmbRevisionNumber.Text+"",""};

                        //"Quotation No: " + cmbQuotationNumber.Text + "","", "",
                        //        "Prepared for:","" + cmbCustomer.Text + "",
                        //        txtAddress.Text,
                        //        "", "", "",
                        //        "Kind Attention : " + txtContactPerson.Text + "","Email : " + txtEmailID.Text + "",
                        //        "Handy.: " + txtContactNumber.Text + "",
                        //        "Tel.: " + txtTel.Text + "","","Dear Sir,","",
                        //        "Sub.: " + txtQuoteName.Text + "","",

                        //string[] Text ={"ITW India Private Limited(Instron Division), engaged in the principal business of marketing testing machines / equipment’s undertakes to execute the repair"
                        //    ,"and maintenance work  mentioned below  as a part of its after-sales activity subject to the terms and  conditions specified as under for a contract period.",
                        //"","Contract period starting from",
                        //"Equipment/s Covered Under this Maintenance Contract:",
                        //"Model and Serial Number","",
                        //"NVLAP Calibrations covered under this Maintenance Contract: "};

                        //string[] Text ={"ITW India Private Limited(Instron Division), engaged in the principal business of marketing testing machines / equipment’s"
                        //    ,"undertakes to execute the repair and maintenance work mentioned below as a part of its after-sales activity subject to the","terms and conditions specified as under for a contract period.",
                        //"","Calibration due date is on " + dtpCalibrationDate.Text + "   Mutually Agreed date  " + dtpMutualyAgreedDate.Text + "","",
                        // "NVLAP Calibrations covered under this Maintenance Contract: "};




                        //string[] Text3 = { "TAX : GST - 18 % - Our GSTIN - 33AAACI4550Q1ZD. Our SAC Code for AMC - 998717 (Maintenance and repair services of commercial and industrial machinery) and for Calibration - 998349 (Other technical and scientific services n.e.c)"
                        //        ,""
                        //,"Kindly provide us your Purchase order in the name of ITW India Private Limited, First Floor FF2, GCV House, 81 Nungambakkam High Road, Numgambakkam - 600034,Tamil Nadu, India -  There is a change in Office Address",
                        //"Payment Terms:",txtpaymentterms.Text,"Our Service Tax Registration Number is AAACI4550QSD021. Our Income Tax Permanent Account Number (PAN) is AAACI4550Q."};


                        if (!Directory.Exists(ExcelFolderPath))
                            Directory.CreateDirectory(ExcelFolderPath);
                        Clipboard.Clear();
                        ExcelApp = new EXCEL.Application();
                        misValue = System.Reflection.Missing.Value;
                        try
                        {
                            if (ExcelApp == null)
                                MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                            NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                            NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                            if (NewWorkSheet == null)
                                MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                            else
                                NewWorkSheet.Name = "Quote";
                            EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                            if (RANGE == null)
                                MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                            NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                            CELLS = NewWorkSheet.Cells;


                            if (cmbCALQuoteFor.SelectedIndex == 0)
                            {

                                string[] TextN ={"","",
                                "ITW India Private Limited - "+cmbCALQuoteFor.Text+" Division","497E, 14 Cross, 4th Phase, Peenya Industrial Area,",
                                "Bangalore 560 058, Karnataka,  India. ", "Phone:91(080) 28360184  FAX: (080) 28360047",
                                "Web: http://www.biss.in, Email: sales@biss.in","","","","",cmbCALCustomer.Text,txtCALAddress.Text, "","","",
                                "Kind Attention : "+txtCALContactPerson.Text +"","","Email : "+txtCALEmailID.Text+"","",
                                "Contact No : "+txtCALHandy.Text+"",
                                "","","Offer No.: "+ cmbQuotationNumber.Text,
                                "Date : "+dtpCALDateofQuote.Text+"","Rev : "+cmbRevisionNumber.Text+"",""};

                                foreach (string str in TextN)
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1] = str;
                                    // CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                    iRowIndex++;
                                }
                            }
                            else if (cmbCALQuoteFor.SelectedIndex == 1)
                            {
                                //need to add this side
                                string[] TextN1 ={"","",
                                "ITW India Private Limited - "+cmbCALQuoteFor.Text+" Division","497E, 14 Cross, 4th Phase, Peenya Industrial Area,",
                                "Bangalore 560 058, Karnataka, India.", "Phone:91(080) 28360184","FAX: (080) 28360047",
                                 "","","","",cmbCALCustomer.Text,txtCALAddress.Text,"","","","",
                                "Kind Attention : "+txtCALContactPerson.Text +"","","Email : "+txtCALEmailID.Text+"","",
                                "Contact No : "+txtCALHandy.Text+"",
                                "","","Offer No.: "+ cmbQuotationNumber.Text,
                                "Date : "+dtpCALDateofQuote.Text+"","Rev : "+cmbRevisionNumber.Text+"",""};

                                foreach (string str in TextN1)
                                {
                                    NewWorkSheet.Cells[iRowIndex, 1] = str;
                                    // CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                                    iRowIndex++;
                                }
                            }


                            //foreach (string str in TextN)
                            //{
                            //    NewWorkSheet.Cells[iRowIndex, 1] = str;
                            //    // CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                            //    iRowIndex++;
                            //}
                            NewWorkSheet.get_Range("A1", "H9999").Cells.Font.Name = "Arial";
                            NewWorkSheet.get_Range("A2", "H9999").Cells.Font.Size = 13;
                            CellMerge("Merge", NewWorkSheet, 13, 16, 1, 4);
                            // CellMerge("AlignLeft", NewWorkSheet, 6, 8, 1, 3);
                            NewWorkSheet.Range["A13:A13"].Cells.WrapText = true;
                            CellMerge("AlignTop", NewWorkSheet, 13, 13, 1, 2);
                            // NewWorkSheet.Range["A1:H48"].Cells.Font.Bold = true;
                            CellMerge("Bold", NewWorkSheet, 3, 3, 1, 8);
                            CellMerge("Bold", NewWorkSheet, 12, 12, 1, 8);
                            CellMerge("Bold", NewWorkSheet, 17, 46, 1, 8);

                            NewWorkSheet.Cells[19, 6] = "Contract Type.: " + txtCALCusRef.Text + "";
                            NewWorkSheet.Cells[21, 6] = "Zone.: " + txtCalZone.Text + "";

                            NewWorkSheet.Cells[24, 6] = "GSTIN - 29AAACI4550Q2Z1";
                            //  CellMerge("Merge", NewWorkSheet, 24, 24, 3, 4);
                            NewWorkSheet.Cells[25, 6] = "HSN - 90241000";
                            // CellMerge("Merge", NewWorkSheet, 25, 25, 3, 4);

                           // NewWorkSheet.Paste(RANGE);


                            //if (File.Exists(Global.sCompanyLogo))
                            //{
                            //    EXCEL.Range oRange1 = (EXCEL.Range)NewWorkSheet.Cells[28, 1];
                            //    Image oImage1 = Image.FromFile(Global.sCompanyLogo);
                            //    System.Windows.Forms.Clipboard.SetDataObject(oImage1, true);
                            //    NewWorkSheet.Paste(oRange1, Global.sITWLogo);
                            //}


                            //NewWorkSheet.Cells[1, 3] = "Date : " + dtpQuoteDate.Text + "";
                            //NewWorkSheet.Cells[1, 5] = "Cutomer Ref.: " + txtCusref.Text + "    " + "Zone.: " + txtZone.Text + "";

                            //NewWorkSheet.Cells[45, 1] = "Prepared : " + login.GetUserDetails[2] + "";
                            //CellMerge("Merge", NewWorkSheet, 45, 45, 1, 8);
                            //CellMerge("AlignLeft", NewWorkSheet, 45, 45, 1, 8);
                            //NewWorkSheet.Cells[46, 1] = "Contact : " + login.GetUserDetails[20] + " | " + login.GetUserDetails[50] + "";
                            //CellMerge("Merge", NewWorkSheet, 46, 46, 1, 8);
                            //CellMerge("AlignLeft", NewWorkSheet, 46, 46, 1, 8);
                            //  CellMerge("Bold", NewWorkSheet, 45, 46, 1, 8);



                            NewWorkSheet.Cells[47, 1].Font.Color = Color.FromArgb(255, 0, 0);
                            //  NewWorkSheet.Cells[47, 1].Characters(54, 65).Font.Color = Color.FromArgb(0, 0, 255);
                            string cellText = NewWorkSheet.Cells[47, 1].Text.ToString();
                            if (cellText.Length >= 100)
                            {
                                NewWorkSheet.Cells[47, 1].Characters(54, 65).Font.Color = Color.FromArgb(0, 0, 255);
                                NewWorkSheet.Cells[47, 1].Characters(66, 100).Font.Color = Color.FromArgb(255, 0, 0);
                            }

                            NewWorkSheet.Cells[47, 1].Characters(66, 100).Font.Color = Color.FromArgb(255, 0, 0);
                            iRowIndex = 48;

                            NewWorkSheet.HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);
                            NewWorkSheet.Cells[iRowIndex, 1] = (txtCalQuotename.Text.Trim() + "\nModel No: " + txtCALModelNo.Text.Trim()).Trim();
                            NewWorkSheet.Cells[iRowIndex, 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                            NewWorkSheet.Range["A" + iRowIndex + ":D" + iRowIndex + ""].Cells.WrapText = true;
                            NewWorkSheet.Rows[iRowIndex].RowHeight = 45;
                            NewWorkSheet.get_Range("A" + iRowIndex + "", "D" + iRowIndex + "").Cells.Font.Size = 18;
                            CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            NewWorkSheet.Cells[iRowIndex, 1].Font.Color = Color.FromArgb(186, 12, 47);
                            iRowIndex++;

                            //foreach (string str in Text)
                            //{
                            //    NewWorkSheet.Cells[iRowIndex, 1] = str;
                            //    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            //    iRowIndex++;
                            //}


                            //CellMerge("Merge", NewWorkSheet, 52, 52, 1, 8);
                            //NewWorkSheet.Rows[52].RowHeight = 20;
                            //// CellMerge("AlignCenter", NewWorkSheet, 52, 52, 1, 8);
                            ////  NewWorkSheet.get_Range("A" + iRowIndex + "", "D" + iRowIndex + "").Cells.Font.Size = 18;
                            //NewWorkSheet.get_Range("A53", "H53").Cells.Font.Size = 16;
                            //CellMerge("Bold", NewWorkSheet, 53, 55, 1, 8);

                            // NewWorkSheet.HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);
                            //iRowIndex = 49;

                            //NewWorkSheet.Cells[22, 3] = "";
                            //NewWorkSheet.Cells[24, 5] = txtModelslno.Text;

                            iRowIndex++;
                            iRowIndex++;
                            NewWorkSheet.get_Range("A" + iRowIndex + "", "H" + iRowIndex + "").Cells.Font.Size = 16;
                            NewWorkSheet.Cells[iRowIndex, 1] = "Sl No";
                            NewWorkSheet.Cells[iRowIndex, 2] = "Scope";
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 2, 7);
                            CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            if (CmbCurrency.SelectedIndex == 0)
                            {
                                NewWorkSheet.Cells[iRowIndex, 8] = "Price(INR)";
                            }
                            else
                            {
                                NewWorkSheet.Cells[iRowIndex, 8] = "Price(USD)";
                            }
                            NewWorkSheet.Cells[iRowIndex, 1].Font.Color = Color.FromArgb(186, 12, 47);
                            NewWorkSheet.Cells[iRowIndex, 2].Font.Color = Color.FromArgb(186, 12, 47);
                            NewWorkSheet.Cells[iRowIndex, 8].Font.Color = Color.FromArgb(186, 12, 47);
                            CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                            CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 2, 7);
                            CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 7, 8);

                            CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);

                            //Microsoft.Office.Interop.Excel.Range range2 = NewWorkSheet.get_Range("H51", "H" + (55 + dgvCALCalibrationDetails.Rows.Count) + "");
                            //range2.NumberFormat = "#,###";
                            int endRow = 55 + dgvCALCalibrationDetails.Rows.Count;
                            if (endRow < 1048576) // Excel max rows
                            {
                                Microsoft.Office.Interop.Excel.Range range2 = NewWorkSheet.get_Range("H51", "H" + endRow);
                                range2.NumberFormat = "#,###";
                            }



                            iRowIndex++;


                            for (int i = 0; i < dgvCALCalibrationDetails.Rows.Count; i++)
                            {
                                for (int m = 0; m < 2; m++)
                                {
                                    // Set the cell value
                                    //   NewWorkSheet.Cells[iRowIndex, m + 1] = dgvCALCalibrationDetails.Rows[i].Cells[m].Value.ToString();
                                    var cellVal = dgvCALCalibrationDetails.Rows[i].Cells[m].Value;
                                    NewWorkSheet.Cells[iRowIndex, m + 1] = cellVal != null ? cellVal.ToString() : string.Empty;


                                    // Get the cell value as string
                                    string cellValue = dgvCALCalibrationDetails.Rows[i].Cells[m].Value.ToString();

                                    //// Dynamically adjust the row height based on the length of the text
                                    //if (cellValue.Length > 130 && cellValue.Length < 160)
                                    //{
                                    //    NewWorkSheet.Rows[iRowIndex].RowHeight = 36;  // Adjust row height for moderate length text
                                    //    NewWorkSheet.Rows[iRowIndex].WrapText = true; // Wrap the text in the cell
                                    //}
                                    //else
                                    //{
                                    //    NewWorkSheet.Rows[iRowIndex].RowHeight = 54;  // Adjust row height for longer text
                                    //    NewWorkSheet.Rows[iRowIndex].WrapText = true; // Wrap the text in the cell
                                    //}

                                    // Optional: You can calculate the required row height dynamically based on text lines
                                    // If the content is too long, we calculate a better height
                                    int textLineCount = (int)Math.Ceiling((double)cellValue.Length / 50); // Approximate 50 chars per line
                                                                                                          // MessageBox.Show("textLineCount: " + textLineCount.ToString());
                                    NewWorkSheet.Rows[iRowIndex].RowHeight = 18 * (textLineCount); // Adjust the height based on text lines
                                    NewWorkSheet.Rows[iRowIndex].WrapText = true;

                                }

                                // Merge cells for alignment and borders
                                CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 2, 7);
                                CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                                CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 2, 7);

                                iRowIndex++;
                            }

                            iRowIndex = iRowIndex - dgvCALCalibrationDetails.Rows.Count;

                            for (int i = 0; i < dgvCALCalibrationDetails.Rows.Count; i++)
                            {
                                for (int m = 0; m < 1; m++)
                                {
                                    NewWorkSheet.Cells[iRowIndex, 8] = dgvCALCalibrationDetails.Rows[i].Cells[2].Value.ToString();
                                }

                                // Merge cells for the next section
                                CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 7, 8);
                                CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 2, 7);

                                iRowIndex++;
                            }


                            // iRowIndex++;

                            double Firststtotal = 0;

                            foreach (DataRow row in dtOfferItemDeatils.Rows)
                            {
                                Firststtotal += Convert.ToDouble(row["Price"]);
                            }

                            NewWorkSheet.Cells[iRowIndex, 1] = "Total Calibration charges without tax";
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                            CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            NewWorkSheet.Cells[iRowIndex, 8] = Math.Round(Firststtotal).ToString();
                            CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                            CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                            CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 7, 8);
                            iRowIndex++;

                            if (Convert.ToDouble(txtCALDiscount.Text) > 0)
                            {
                                NewWorkSheet.Cells[iRowIndex, 1] = "Discount " + txtCALDiscount.Text + "%";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                                CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                NewWorkSheet.Cells[iRowIndex, 8] = Math.Round(Firststtotal * (Convert.ToDouble(txtCALDiscount.Text) / 100)).ToString();
                                CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                                CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                                CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 7, 8);
                                iRowIndex++;
                            }

                            NewWorkSheet.Cells[iRowIndex, 1] = "Grand Total Calibration charges without tax";
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                            CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            NewWorkSheet.Cells[iRowIndex, 8] = txtCALGrandTotal.Text;
                            CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                            CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                            CellMerge("ThickBorder", NewWorkSheet, iRowIndex, iRowIndex, 7, 8);
                            iRowIndex++;
                            iRowIndex++;

                            // NewWorkSheet.Cells[iRowIndex, 1] = "* Applicable Service Tax + Education Cess + Higher Secondary Education cess will be extra. It is presently charged 14% ST + 0.5% SBC will be applicable as on date of notication";
                            NewWorkSheet.Cells[iRowIndex, 1] = "TAX : GST - 18 % - Our GSTIN - 29AAACI4550Q2Z1. Our SAC Code - 998346 and Our Income Tax Permanent Account Number (PAN) is AAACI4550Q.";
                            CellMerge("Merge", NewWorkSheet, iRowIndex, (iRowIndex + 2), 1, 8);
                            CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            iRowIndex = iRowIndex + 3;
                            iRowIndex++;

                            NewWorkSheet.Cells[iRowIndex, 1] = "Important Note: We need advance notice of 60 days from date of receipt of P.O and payment for deputing an Engineer for calibration. We plan our calibration visit only upon receipt of commercially clean purchase order and payment in advance.";
                            CellMerge("Merge", NewWorkSheet, iRowIndex, (iRowIndex + 2), 1, 8);
                            CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            iRowIndex = iRowIndex + 3;

                            iRowIndex++;

                            //NewWorkSheet.Cells[iRowIndex, 1] = "Calibration due date is on " + dtpCalibrationDate.Text + "   Mutually Agreed date  " + dtpMutualyAgreedDate.Text + "";
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            iRowIndex++;
                            iRowIndex++;

                            NewWorkSheet.Cells[iRowIndex, 1] = "Kindly provide us your Purchase order in the name of ITW India Private Limited, 497E, 14 Cross, 4th Phase, Peenya Industrial Area, Bangalore 560 058, Karnataka, India.";
                            CellMerge("Merge", NewWorkSheet, iRowIndex, (iRowIndex + 2), 1, 8);
                            CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            iRowIndex = iRowIndex + 3;
                            iRowIndex++;
                            int newirowindex = iRowIndex;

                            NewWorkSheet.Cells[iRowIndex, 1] = "Payment Terms:";
                            CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            iRowIndex++;

                            NewWorkSheet.Cells[iRowIndex, 1] = txtCALPaymentTerms.Text;
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 5, 1, 8);
                            CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            iRowIndex = iRowIndex + 6;



                            int NextPage = iRowIndex;
                            NewWorkSheet.HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);

                            //NewWorkSheet.Cells[iRowIndex, 1] = "TERMS AND CONDITIONS";
                            //CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            //CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            //iRowIndex++;

                            NewWorkSheet.Cells[iRowIndex, 1] = "General Terms and Conditions";
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            NewWorkSheet.get_Range("A" + iRowIndex + "", "D" + iRowIndex + "").Cells.Font.Size = 18;
                            CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            NewWorkSheet.Rows[iRowIndex].RowHeight = 26;
                            NewWorkSheet.Cells[(iRowIndex), 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                            NewWorkSheet.Cells[(iRowIndex), 2].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                            NewWorkSheet.Cells[(iRowIndex), 3].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                            NewWorkSheet.Cells[(iRowIndex), 4].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                            NewWorkSheet.Cells[(iRowIndex), 5].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                            NewWorkSheet.Cells[(iRowIndex), 6].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                            NewWorkSheet.Cells[(iRowIndex), 7].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                            NewWorkSheet.Cells[(iRowIndex), 8].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                            iRowIndex++;


                            NewWorkSheet.Cells[iRowIndex, 1] = "The machine and transducers to be calibrated must be handed over in fully working condition preferably after the completion of a maintenance contract visit for performing the calibration. We shall endeavour to depute our personnel on mutually agreed date. However we shall in no way be responsible for any loss, due to attending to your call under circumstances beyond our control. In case we incur any local taxes, levies, Octroi and if any in bringing the calibration kit to your site, the same has to be borne by customer.  Calibration Certificate in PDF format will only be issued and sent to you by email. All applicable statutory levies as of date of our final Invoice will be extra. Please make the payment by demand draft in favour of ITW India Private Limited This quotation is valid for 30 days. Customer acknowledges that the export of Goods and Technology herein is/ maybe subject to the export control regulations of the United Kingdom and / or the United States, as amended.And agrees as a condition of acceptance of this quotation / contract and issuance of any subsequent order or contract hereto, that the Goods and Technology will not be used for purposes associated with any chemical, biological, nuclear weapons or missiles capable of delivering such weapons, or in support of any terrorist activity or any other military end use.Nor will they be re - sold or transferred if it is known or suspected that they are intended to be used for such purposes. In the event that any requisite governmental licence, consent or permit or other authorization cannot be obtained in fulfilment of any subsequent order or contract hereto ITW India Private Limited. shall not be liable to Customer in respect of any bond or guarantee or for any loss, damage, consequences or other resultant financial penalty.We hope that our quotation is in line with your needs and look forward to receive your valued order at the earliest.";
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 16, 1, 8);
                            CellMerge("TextAlign", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);

                            iRowIndex = iRowIndex + 17;

                            iRowIndex++;

                            NewWorkSheet.Cells[iRowIndex, 1] = "Thanking you and assuring you of our best services and attention to all your needs on mutually beneficial terms.";
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            iRowIndex++;

                            iRowIndex = iRowIndex + 4;
                            NewWorkSheet.Cells[iRowIndex, 1] = "Yours truly";
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            iRowIndex++;

                            NewWorkSheet.Cells[iRowIndex, 1] = "For ITW India Private Limited";
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);

                            if (login.GetUserDetails[2] == "Chaithra.K.R" || login.GetUserDetails[2] == "R Nagashree")
                            {
                                EXCEL.Range oRange2 = (EXCEL.Range)NewWorkSheet.Cells[(iRowIndex + 2), 1];
                                Image oImage2 = Image.FromFile("C:\\Databasepath\\ChaitraSign.jpg");
                                System.Windows.Forms.Clipboard.SetDataObject(oImage2, true);
                                // NewWorkSheet.Paste(oRange2, Global.sITWLogo);
                                System.Threading.Thread.Sleep(500);
                                NewWorkSheet.Paste(oRange2);
                            }
                            iRowIndex = iRowIndex + 5;
                            if (login.GetUserDetails[2] == "Chaithra.K.R" || login.GetUserDetails[2] == "R Nagashree")
                            {
                                NewWorkSheet.Cells[iRowIndex, 1] = "Chaithra.K.R";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;
                            }

                            else
                            {
                                NewWorkSheet.Cells[iRowIndex, 1] = lblCALQuoteby.Text;
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;
                            }
                            NewWorkSheet.Cells[iRowIndex, 1] = "Business Coordinator,";
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                            iRowIndex++;
                            if (login.GetUserDetails[2] == "Chaithra.K.R" || login.GetUserDetails[2] == "R Nagashree")
                            {
                                NewWorkSheet.Cells[iRowIndex, 1] = "Chaithra_KR@instron.com";
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;
                            }
                            else
                            {
                                NewWorkSheet.Cells[iRowIndex, 1] = login.GetUserDetails[20].ToString() + "|" + login.GetUserDetails[50];
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 8);
                                iRowIndex++;
                            }


                            //NewWorkSheet.Rows[1].RowHeight = 22;
                            //NewWorkSheet.Rows[21].RowHeight = 1;
                            //NewWorkSheet.Rows[22].RowHeight = 29;
                            //NewWorkSheet.Rows[25].RowHeight = 6;
                            //NewWorkSheet.Rows[25].RowHeight = 6;

                            //CellMerge("VAlignCenter", NewWorkSheet, 22, 22, 1, 8);
                            //CellMerge("Merge", NewWorkSheet, 24, 24, 1, 4);
                            //CellMerge("Merge", NewWorkSheet, 24, 24, 5, 8);
                            //CellMerge("AlignCenter", NewWorkSheet, 24, 24, 1, 4);
                            //CellMerge("AlignCenter", NewWorkSheet, 24, 24, 5, 8);



                            //NewWorkSheet.get_Range("A1", "A1").Cells.Font.Size = 17;
                            //NewWorkSheet.get_Range("A22", "H22").Cells.Font.Size = 14;
                            //NewWorkSheet.Range["A21:H26"].Cells.Font.Bold = true;

                            NewWorkSheet.Range["A1:A1"].Cells.Font.Bold = true;
                            NewWorkSheet.Rows[1].RowHeight = 6;
                            NewWorkSheet.Rows[2].RowHeight = 48;
                            NewWorkSheet.Rows[13].RowHeight = 68;
                            //NewWorkSheet.Rows[2].RowHeight = 48;
                            //NewWorkSheet.Rows[7].RowHeight = 18;
                            NewWorkSheet.Columns[1].ColumnWidth = 7;
                            NewWorkSheet.Columns[2].ColumnWidth = 53;
                            NewWorkSheet.Columns[3].ColumnWidth = 9;
                            //NewWorkSheet.Columns[2].WrapText = true;
                            NewWorkSheet.Columns[4].ColumnWidth = 9;
                            NewWorkSheet.Columns[5].ColumnWidth = 9;
                            NewWorkSheet.Columns[6].ColumnWidth = 9;
                            NewWorkSheet.Columns[7].ColumnWidth = 9;
                            NewWorkSheet.Columns[8].ColumnWidth = 16;


                            // NewWorkSheet.Columns[20].ColumnWidth = 107;
                            //  NewWorkSheet.get_Range("A1", "H" + iRowIndex + "").Cells.Font.Color = Color.DarkBlue;

                            //  CellMerge("BorderAround", NewWorkSheet, NextPage, iRowIndex, 1, 8);
                            NewWorkSheet.PageSetup.PrintArea = "A1:H" + iRowIndex + "";
                            NewWorkSheet.PageSetup.LeftMargin = 0.3;
                            NewWorkSheet.PageSetup.RightMargin = 0.3;
                            NewWorkSheet.PageSetup.CenterHorizontally = true;
                            NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                            NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                            Image HeaderPicture = Image.FromFile("C:\\Databasepath\\BiSSServiceQuoteHeader.jpg");

                            NewWorkSheet.PageSetup.LeftHeader = "&\"Arial\"&10" + cmbCustomer.Text + "";
                            //    NewWorkSheet.PageSetup.RightHeader = "&\"Arial\"&10 QNo: " + cmbQuotationNumber.Text + " - " + cmbRevisionNumber.Text + "\nDated : " + dtpCALDateofQuote.Text + " ";
                            string safeQuoteNo = cmbQuotationNumber.Text.Replace("&", "and");
                            NewWorkSheet.PageSetup.RightHeader = "&\"Arial\"&10 QNo: " + safeQuoteNo;

                            //  NewWorkSheet.PageSetup.CenterHeaderPicture = HeaderPicture;

                            NewWorkSheet.PageSetup.CenterHeaderPicture.Filename = "C:\\Databasepath\\BiSSServiceQuoteHeader.jpg";
                            NewWorkSheet.PageSetup.CenterHeader = "&G";

                            //NewWorkSheet.PageSetup.CenterFooterPicture.Filename = "C:\\Databasepath\\BiSSServiceQuoteFooter.jpg";
                            //NewWorkSheet.PageSetup.CenterFooter = "&G";

                            NewWorkSheet.PageSetup.AlignMarginsHeaderFooter = false;

                            if (CmbCurrency.SelectedIndex == 0)
                            {
                                NewWorkSheet.PageSetup.CenterFooter = "&\"Arial\"&10 All prices are in INR ";
                            }
                            else
                            {
                                NewWorkSheet.PageSetup.CenterFooter = "&\"Arial\"&10 All prices are in USD ";
                            }


                            if (cmbCALQuoteFor.SelectedIndex == 0)
                            {
                                if (File.Exists(Global.sLogo))
                                {
                                    EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 6];
                                    Image oImage = Image.FromFile(Global.sLogo);
                                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                                    // NewWorkSheet.Paste(oRange, Global.sLogo);
                                    System.Threading.Thread.Sleep(500);
                                    NewWorkSheet.Paste(oRange);

                                }
                            }
                            else if (cmbCALQuoteFor.SelectedIndex == 1)
                            {
                                if (File.Exists(Global.sInsronLogo))
                                {
                                    EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 6];
                                    Image oImage = Image.FromFile(Global.sInsronLogo);
                                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                                    //NewWorkSheet.Paste(oRange, Global.sInsronLogo);
                                    System.Threading.Thread.Sleep(500);
                                    NewWorkSheet.Paste(oRange);

                                }
                            }

                            if (File.Exists(Global.sITWLogo))
                            {
                                EXCEL.Range oRange1 = (EXCEL.Range)NewWorkSheet.Cells[2, 1];
                                Image oImage1 = Image.FromFile(Global.sITWLogo);
                                System.Windows.Forms.Clipboard.SetDataObject(oImage1, true);
                                //NewWorkSheet.Paste(oRange1, Global.sITWLogo);
                                System.Threading.Thread.Sleep(500);
                                NewWorkSheet.Paste(oRange1);

                            }


                            NewWorkSheet.PageSetup.RightFooter = "Page &P of &N";
                            NewWorkSheet.PageSetup.Zoom = 74;
                            NewWorkBook.Save();
                            ExcelApp.Visible = false;
                            ExcelApp.ActiveWorkbook.Saved = true;

                            // EXCEL.Worksheet Worksheet = (EXCEL.Worksheet)NewWorkBook.ActiveSheet;
                            // EXCEL.PageSetup PageSetup = Worksheet.PageSetup;
                            // NewWorkSheet.PageSetup.ResolutionX = 600;
                            //NewWorkSheet.PageSetup.ResolutionY = 600;    
                            //((Microsoft.Office.Interop.Excel._Worksheet) NewWorkBook.ActiveSheet).PageSetup.Orientation =Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                            // NewWorkBook.ExportAsFixedFormat(EXCEL.XlFixedFormatType.xlTypePDF, FileFul);
                            NewWorkBook.ExportAsFixedFormat(EXCEL.XlFixedFormatType.xlTypePDF, FileFul, EXCEL.XlFixedFormatQuality.xlQualityStandard, true);

                            //                NewWorkBook.ExportAsFixedFormat(EXCEL.XlFixedFormatType.xlTypePDF, FileFul,
                            //EXCEL.XlFixedFormatQuality.xlQualityStandard, true, true, 1, Type.Missing, true);

                            System.Diagnostics.Process.Start(FileFul);

                            NewWorkBook.Close(true, misValue, misValue);
                            ExcelApp.Quit();
                            releaseObject(NewWorkSheet);
                            releaseObject(NewWorkBook);
                            releaseObject(ExcelApp);

                            if (File.Exists(FileFullPath))
                            {
                                // File.Delete(FileFullPath);
                            }

                            // ExportWorkbookToPDF(FileFullPath, FileFul);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                            foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                            {
                                GetProcess.Kill();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void btnRIStart_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtRICOntractType.Text))
            {
                MessageBox.Show("Enter contract type", "Information", 0, MessageBoxIcon.Warning);
                txtRICOntractType.Focus();
            }

            else if (string.IsNullOrEmpty(txtRIZone.Text))
            {
                MessageBox.Show("Enter zone number", "Information", 0, MessageBoxIcon.Warning);
                txtRIZone.Focus();
            }
            else if (string.IsNullOrEmpty(cmbRICustomer.Text))
            {
                MessageBox.Show("Enter or select customer name", "Information", 0, MessageBoxIcon.Warning);
                cmbRICustomer.Focus();
            }
            else if (string.IsNullOrEmpty(txtRIAddress.Text))
            {
                MessageBox.Show("Enter customer address", "Information", 0, MessageBoxIcon.Warning);
                txtRIAddress.Focus();
            }

            else if (string.IsNullOrEmpty(TxtRIContactPerson.Text))
            {
                MessageBox.Show("Enter contact person", "Information", 0, MessageBoxIcon.Warning);
                TxtRIContactPerson.Focus();
            }

            else if (string.IsNullOrEmpty(txtRIEmail.Text))
            {
                MessageBox.Show("Enter customer email id", "Information", 0, MessageBoxIcon.Warning);
                txtRIEmail.Focus();
            }

            else if (string.IsNullOrEmpty(txtRIContactNumber.Text))
            {
                MessageBox.Show("Enter contact number", "Information", 0, MessageBoxIcon.Warning);
                txtRIContactNumber.Focus();
            }
            else if (cmbRIQuotefor.SelectedIndex == -1)
            {
                MessageBox.Show("Select quotation for to start quote ", "Information", 0, MessageBoxIcon.Warning);
                cmbRIQuotefor.DroppedDown = true;
            }
            else if (cmbRICurrency.SelectedIndex == -1)
            {
                MessageBox.Show("Select quote currency to start quote ", "Information", 0, MessageBoxIcon.Warning);
                cmbRICurrency.DroppedDown = true;
            }

            else if (string.IsNullOrEmpty(txtRIQuoteName.Text))
            {
                MessageBox.Show("Enter quote name", "Information", 0, MessageBoxIcon.Warning);
                txtRIQuoteName.Focus();
            }
            else if (string.IsNullOrEmpty(txtRIModelNumber.Text))
            {
                MessageBox.Show("Enter model serial number", "Information", 0, MessageBoxIcon.Warning);
                txtRIModelNumber.Focus();
            }

            else
            {
                tabRI.SelectTab(1);
            }
        }
        //BHAVYA
        //private void txtRIVDiscount_TextChanged(object sender, EventArgs e)
        //{
        //    if (txtRIVDiscount.TextLength > 0)
        //    {
        //        fnRICalculation();
        //        txtRIVGrandTotal.Text = Math.Round(sTotalAmount - sTotalAmount * (Convert.ToDouble(txtRIVDiscount.Text) / 100)).ToString();
        //    }
        //    else
        //    {
        //        txtRIVDiscount.Text = "0";
        //    }

        //}BHAVYA

        private void txtRIVDiscount_TextChanged(object sender, EventArgs e)
        {
            if (double.TryParse(txtRIVDiscount.Text, out double discount))
            {
                fnRICalculation();
                txtRIVGrandTotal.Text = Math.Round(sTotalAmount - sTotalAmount * (discount / 100)).ToString();
            }
            else
            {
                txtRIVDiscount.Text = "0";
            }
        }

        private void fnRICalculation()
        {
            sTotalAmount = 0;
            foreach (DataGridViewRow dgvr in dgvRIQuoteDetails.Rows)
            {
                sTotalAmount += Convert.ToDouble(dgvr.Cells["RIPrice"].Value);
            }

            sTotalAmount = Math.Round(sTotalAmount);
        }

        private void txtRIVDiscount_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnNumberKeyPressOnly(sender, e);
        }

        private void dgvRIQuoteDetails_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgvRIQuoteDetails.CurrentCell.OwningColumn.Name == "RIPrice")
            {
                oldvalue = Convert.ToDouble(dgvRIQuoteDetails.CurrentCell.Value);
            }
        }

        private void dgvRIQuoteDetails_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvRIQuoteDetails.CurrentCell.OwningColumn.Name == "RIPrice")
            {
                if (!string.IsNullOrEmpty(dgvRIQuoteDetails.CurrentCell.Value.ToString()) && (dgvRIQuoteDetails.CurrentCell.Value.ToString() != "."))// != null)
                {
                    txtRIVDiscount_TextChanged(sender, e);
                }

                else
                {
                    dgvRIQuoteDetails.CurrentCell.Value = oldvalue;
                }
            }
        }

        private void dgvRIQuoteDetails_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress3);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
            }
        }

        private void btnTab3back_Click(object sender, EventArgs e)
        {
            tabRI.SelectTab(0);
            //  tabControl3.SelectedIndex(0);
        }

        private void brnTab2back_Click(object sender, EventArgs e)
        {
            tabCalibration.SelectTab(0);
        }

        private void chkQuoteSavePath_CheckedChanged(object sender, EventArgs e)
        {
            if (chkQuoteSavePath.CheckState == CheckState.Checked)
            {
                if (MessageBox.Show("The default save location for quotes is '" + Properties.Settings.Default.ServiceQuotePath + "'\nClick on Yes to change the quote save location", "Save location", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                {
                    DialogResult result = folderBrowserDialog1.ShowDialog();
                    if (result == DialogResult.OK)
                    {
                        Properties.Settings.Default.ServiceQuotePath = folderBrowserDialog1.SelectedPath;
                        //Properties.Settings.Default.FolderPath = folderBrowserDialog1.SelectedPath;
                        Properties.Settings.Default.Save();
                        MessageBox.Show("The default save location for quotes changed to the selected path '" + Properties.Settings.Default.ServiceQuotePath + "'", "Success", 0, MessageBoxIcon.Information);
                        chkQuoteSavePath.Checked = false;
                    }
                    else
                    {
                        chkQuoteSavePath.Checked = false;
                    }
                }
                else
                {
                    chkQuoteSavePath.Checked = false;
                }
            }
        }

        private void cmbCeastAMC_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbCeastAMC.SelectedIndex == 0)
            {
                pnCeast.Visible = true;
                pnAMC.Visible = false;
            }
            else if (cmbCeastAMC.SelectedIndex == 1)
            {
                pnCeast.Visible = false;
                pnAMC.Visible = true;
            }
        }

        bool bCeastContractValidattion = false;
        private void fnCeastContractRowCheck()
        {
            bCeastContractValidattion = false;
            foreach (DataGridViewRow row in dgvCeastContract.Rows)
            {
                if (string.IsNullOrEmpty(row.Cells[0].Value.ToString()))
                {
                    MessageBox.Show("Enter Instrument details", "Error", 0, MessageBoxIcon.Error);
                    bCeastContractValidattion = true;
                    break;
                }
                else if (Convert.ToInt32(row.Cells[1].Value) == 0)
                {
                    MessageBox.Show("Enter Unit Price", "Error", 0, MessageBoxIcon.Error);
                    bCeastContractValidattion = true;
                    break;
                }
                else if (Convert.ToInt32(row.Cells[2].Value) == 0)
                {

                    MessageBox.Show("Enter Qunatity", "Error", 0, MessageBoxIcon.Error);
                    bCeastContractValidattion = true;
                    break;
                }
            }
        }

        private void btnCeastAdditem_Click(object sender, EventArgs e)
        {
            fnCeastContractRowCheck();
            if (!bCeastContractValidattion)
            {
                dtCeastQuoteContractValue.Rows.Add("", 0, 0, 0);
                dgvCeastContract.DataSource = dtCeastQuoteContractValue;
            }
        }
        double Ceasetoldvalue = 0;
        private void dgvCeastContract_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgvCeastContract.CurrentCell.OwningColumn.Name == "UnitPrice" || dgvCeastContract.CurrentCell.OwningColumn.Name == "Quantity")
            {
                Ceasetoldvalue = Convert.ToDouble(dgvCeastContract.CurrentCell.Value);
            }
        }

        private void dgvCeastContract_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvCeastContract.CurrentCell.OwningColumn.Name == "UnitPrice" || dgvCeastContract.CurrentCell.OwningColumn.Name == "Quantity")
            {
                if (!string.IsNullOrEmpty(dgvCeastContract.CurrentCell.Value.ToString()) && (dgvCeastContract.CurrentCell.Value.ToString() != "."))// != null)
                {
                    dgvCeastContract.CurrentRow.Cells["Amount"].Value = Math.Round(Convert.ToDouble(dgvCeastContract.CurrentRow.Cells["UnitPrice"].Value) * Convert.ToDouble(dgvCeastContract.CurrentRow.Cells["Quantity"].Value)).ToString();

                    fnCeastCalculation();
                    txtDiscount_TextChanged(sender, e);
                }
                else
                {
                    dgvCeastContract.CurrentCell.Value = Ceasetoldvalue;
                }

            }

        }

        private void dgvCeastContract_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress4);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
            }
        }

        private void Control_KeyPress4(object sender, KeyPressEventArgs e)
        {
            if (dgvCeastContract.CurrentCell.OwningColumn.Index == 1 || dgvCeastContract.CurrentCell.OwningColumn.Index == 2)
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
                {
                    e.Handled = true;
                }
                if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
                {
                    e.Handled = true;
                }
            }

        }

        private void dgvCeastContract_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (dgvCeastContract.Rows.Count > 0)
                {
                    DialogResult DR = MessageBox.Show("Do you want to delete selected row", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (DR == DialogResult.Yes)
                    {
                        dgvCeastContract.Rows.RemoveAt(dgvCeastContract.Rows.IndexOf(dgvCeastContract.CurrentRow));
                        fnCeastCalculation();
                    }
                }
            }
        }

        private void cmbPICustomer_SelectedIndexChanged(object sender, EventArgs e)
        {
            DR = dtCustomerList.Select("CustomerName = '" + cmbPICustomer.Text + "'");
            if (DR.Length > 0)
            {
                txtPIAddress.Text = DR[0]["Address1"].ToString() + DR[0]["Address2"].ToString() + DR[0]["Address3"].ToString();
                txtPICountry.Text = DR[0]["Country"].ToString();
                txtPIGSTIN.Text = DR[0]["GSTCode"].ToString();
                txtPICusCode.Text = DR[0]["CusCode"].ToString();
            }
            else
            {
                txtPIAddress.ResetText();
                txtPICountry.ResetText();
                txtPIGSTIN.ResetText();
                txtPICusCode.ResetText();
            }
        }

        private void btnStartPI_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cmbPICustomer.Text))
            {
                MessageBox.Show("Enter or select customer name", "Information", 0, MessageBoxIcon.Warning);
                cmbPICustomer.DroppedDown = true;
            }
            else if (string.IsNullOrEmpty(txtPIAddress.Text))
            {
                MessageBox.Show("Enter customer address", "Information", 0, MessageBoxIcon.Warning);
                txtPIAddress.Focus();
            }
            else if (string.IsNullOrEmpty(txtPIQuoteRef.Text))
            {
                MessageBox.Show("Enter Quote reference number", "Information", 0, MessageBoxIcon.Warning);
                txtPIQuoteRef.Focus();
            }
            else if (!bPIQuoterefdate)
            {
                MessageBox.Show("Select quote reference date", "Information", 0, MessageBoxIcon.Warning);
                dtpPIQuoterefdate.Show();
            }
            else if (string.IsNullOrEmpty(txtPIPurchaseOrder.Text))
            {
                MessageBox.Show("Enter purchase order number", "Information", 0, MessageBoxIcon.Warning);
                txtPIPurchaseOrder.Focus();
            }
            else if (!bPIPurchaseorderdate)
            {
                MessageBox.Show("Select purchase order date", "Information", 0, MessageBoxIcon.Warning);
                dtpPIPurchaseorderdate.Show();
            }
            else if (cmbPICompany.SelectedIndex == -1)
            {
                MessageBox.Show("Select quotation company to start quote ", "Information", 0, MessageBoxIcon.Warning);
                cmbPICompany.DroppedDown = true;
            }
            else if (cmbPICurrency.SelectedIndex == -1)
            {
                MessageBox.Show("Select quotation currency", "Information", 0, MessageBoxIcon.Warning);
                cmbPICurrency.DroppedDown = true;
            }
            else
            {
                tabPI.SelectTab(1);
            }
        }
        bool bPIQuoterefdate = false;
        private void dtpPIQuoterefdate_ValueChanged(object sender, EventArgs e)
        {
            bPIQuoterefdate = true;
        }
        bool bPIPurchaseorderdate = false;
        private void dtpPIPurchaseorderdate_ValueChanged(object sender, EventArgs e)
        {
            bPIPurchaseorderdate = true;
        }
        double POvalue = 0;
        private void dgvPIDetails_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgvPIDetails.CurrentCell.OwningColumn.Name == "PIQty" || dgvPIDetails.CurrentCell.OwningColumn.Name == "PIRate")
            {
                POvalue = Convert.ToDouble(dgvPIDetails.CurrentCell.Value);
            }
        }

        private void dgvPIDetails_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvPIDetails.CurrentCell.OwningColumn.Name == "PIQty" || dgvPIDetails.CurrentCell.OwningColumn.Name == "PIRate")
            {
                if (!string.IsNullOrEmpty(dgvPIDetails.CurrentCell.Value.ToString()) && (dgvPIDetails.CurrentCell.Value.ToString() != "."))// != null)
                {
                    dgvPIDetails.CurrentRow.Cells["PIAmount"].Value = Math.Round(Convert.ToDouble(dgvPIDetails.CurrentRow.Cells["PIQty"].Value) * Convert.ToDouble(dgvPIDetails.CurrentRow.Cells["PIRate"].Value)).ToString();

                    fnPICalculation();
                }
                else
                {
                    dgvPIDetails.CurrentCell.Value = POvalue;
                }

            }
        }

        private void fnPICalculation()
        {
            sTotalAmount = 0;
            foreach (DataGridViewRow dgvr in dgvPIDetails.Rows)
            {
                sTotalAmount += Convert.ToDouble(dgvr.Cells["PIQty"].Value) * Convert.ToDouble(dgvr.Cells["PIRate"].Value);
            }

            sTotalAmount = Math.Round(sTotalAmount);
            txtPIGrandTotal.Text = sTotalAmount.ToString();
        }

        private void dgvPIDetails_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress5);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
            }
        }

        private void Control_KeyPress5(object sender, KeyPressEventArgs e)
        {
            if (dgvPIDetails.CurrentCell.OwningColumn.Index == 2 || dgvPIDetails.CurrentCell.OwningColumn.Index == 3)
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
                {
                    e.Handled = true;
                }
                if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
                {
                    e.Handled = true;
                }
            }

        }

        bool bPIValidattion = false;
        private void fnPIRowCheck()
        {
            if (dtOfferItemDeatils.Rows.Count == 0)
            {
                dtOfferItemDeatils = DAL.fnServiceQuotationNumberLoadData(72, cmbQuotationNumber.Text, "").Tables[0];
            }
            bPIValidattion = false;
            foreach (DataGridViewRow row in dgvPIDetails.Rows)
            {
                if (string.IsNullOrEmpty(row.Cells[1].Value.ToString()))
                {
                    MessageBox.Show("Enter Instrument details", "Error", 0, MessageBoxIcon.Error);
                    bPIValidattion = true;
                    break;
                }
                else if (Convert.ToInt32(row.Cells[2].Value) == 0)
                {
                    MessageBox.Show("Enter Qunatity", "Error", 0, MessageBoxIcon.Error);
                    bPIValidattion = true;
                    break;
                }
                else if (Convert.ToInt32(row.Cells[3].Value) == 0)
                {

                    MessageBox.Show("Enter Unit Price", "Error", 0, MessageBoxIcon.Error);
                    bPIValidattion = true;
                    break;
                }
            }
        }

        private void btnPIAddItem_Click(object sender, EventArgs e)
        {
            fnPIRowCheck();
            if (!bPIValidattion)
            {
                dtOfferItemDeatils.Rows.Add((dgvPIDetails.Rows.Count + 1), "", 0, 0, 0);
                dgvPIDetails.DataSource = dtOfferItemDeatils;
            }
        }

        private void dgvPIDetails_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (dgvPIDetails.Rows.Count > 0)
                {
                    DialogResult DR = MessageBox.Show("Do you want to delete selected row", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (DR == DialogResult.Yes)
                    {
                        dgvPIDetails.Rows.RemoveAt(dgvPIDetails.Rows.IndexOf(dgvPIDetails.CurrentRow));
                        fnPICalculation();
                    }
                }
            }
        }

        private void btnGeneratePI_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtPIPaymentterms.Text) && dgvPIDetails.Rows.Count > 0)
            {
                if (btnGeneratePI.Text == "Generate PI")
                {
                    dtQuotationNumber = DAL.fnServiceQuotationNumber(5, null, null).Tables[0];
                    if (dtQuotationNumber.Rows.Count > 0)
                    {
                        if (!string.IsNullOrEmpty(dtQuotationNumber.Rows[0]["PISlNo"].ToString()))
                        {
                            LastQuoteNumber = Convert.ToInt32(dtQuotationNumber.Rows[0]["PISlNo"].ToString());
                            LastQuoteNumber++;
                        }
                        string value = String.Format("{0:D3}", LastQuoteNumber);
                        sQuotationNumber = ("ITW-25-PI25" + value);
                    }

                    InsertPerfomraInvoice(Global.uINSERT, sQuotationNumber, LastQuoteNumber.ToString());
                    cmbQuotationNumber.Items.Add(sQuotationNumber);
                    cmbQuotationNumber.SelectedIndex = 0;

                    MessageBox.Show("The new Perfroma Invoice '" + sQuotationNumber + "' genarated successfully ", "Success", 0, MessageBoxIcon.Information);
                    btnGeneratePI.Enabled = false;
                    btnPrintPI_Click(sender, e);
                }
                else if (btnGeneratePI.Text == "Update PI")
                {
                    InsertPerfomraInvoice(Global.uUPDATE, cmbQuotationNumber.Text, LastQuoteNumber.ToString());

                    MessageBox.Show("The new Perfroma Invoice '" + cmbQuotationNumber.Text + "' updated successfully ", "Success", 0, MessageBoxIcon.Information);
                    btnGeneratePI.Enabled = false;
                    btnPrintPI_Click(sender, e);
                }
            }
            else
            {
                if (string.IsNullOrEmpty(txtPIPaymentterms.Text))
                {
                    MessageBox.Show("Enter payment terms", "Information", 0, MessageBoxIcon.Warning);
                    txtPIPaymentterms.Focus();
                }
                else if (dgvPIDetails.Rows.Count == 0)
                {
                    MessageBox.Show("Enter PI Item details", "Information", 0, MessageBoxIcon.Warning);
                    dgvPIDetails.Focus();
                }
            }
        }

        private void InsertPerfomraInvoice(uint InsertorUpdate, string sPINo, string sSLNo)
        {
            if (InsertorUpdate == Global.uINSERT)
            {
                GlobalClass.iStatus = DAL.fnAddPIDetails(InsertorUpdate, sPINo, sSLNo, cmbPICustomer.Text, txtPICusCode.Text, txtPIAddress.Text.Trim(),
                    txtPICountry.Text, txtPIGSTIN.Text, txtPIQuoteRef.Text, dtpPIQuoterefdate.Text, txtPIPurchaseOrder.Text, dtpPIPurchaseorderdate.Text, lblPIBY.Text, dtpPIDate.Text
                    , cmbPICompany.Text, cmbPICurrency.Text, txtPIGST.Text, txtPIGrandTotal.Text, txtPIPaymentterms.Text.Trim(), txtPImchineNo.Text);


                foreach (DataGridViewRow dr in dgvPIDetails.Rows)
                {
                    GlobalClass.iStatus = DAL.fnAddPIValue(InsertorUpdate, sPINo, dr.Cells["PISlNo"].Value.ToString(),
                        dr.Cells["PIDescription"].Value.ToString().Trim(), dr.Cells["PIQty"].Value.ToString(), dr.Cells["PIRate"].Value.ToString(), dr.Cells["PIAmount"].Value.ToString());
                }
            }

            else if (InsertorUpdate == Global.uUPDATE)
            {
                GlobalClass.iStatus = DAL.fnAddPIDetails(InsertorUpdate, sPINo, sSLNo, cmbPICustomer.Text, txtPICusCode.Text, txtPIAddress.Text.Trim(),
                     txtPICountry.Text, txtPIGSTIN.Text, txtPIQuoteRef.Text, dtpPIQuoterefdate.Text, txtPIPurchaseOrder.Text, dtpPIPurchaseorderdate.Text, lblPIBY.Text, dtpPIDate.Text
                     , cmbPICompany.Text, cmbPICurrency.Text, txtPIGST.Text, txtPIGrandTotal.Text, txtPIPaymentterms.Text.Trim(), txtPImchineNo.Text);


                GlobalClass.iStatus = DAL.fnAddPIValue(Global.uDELETE, sPINo, "", "", "", "", "");


                foreach (DataGridViewRow dr in dgvPIDetails.Rows)
                {
                    GlobalClass.iStatus = DAL.fnAddPIValue(InsertorUpdate, sPINo, dr.Cells["PISlNo"].Value.ToString(),
                        dr.Cells["PIDescription"].Value.ToString().Trim(), dr.Cells["PIQty"].Value.ToString(), dr.Cells["PIRate"].Value.ToString(), dr.Cells["PIAmount"].Value.ToString());
                }
            }
        }

        private void btnPrintPI_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            fnFileSavePath();
            int iRowIndex = 1;
            string ExcelFolderPath;
            string FileFullPath;
            string FileFul;
            EXCEL.Workbook NewWorkBook;
            EXCEL.Worksheet NewWorkSheet;
            EXCEL.Application ExcelApp;
            EXCEL.Range CELLS, cell1, cell2;
            object misValue;
            if (dgvPIDetails.Rows.Count > 0)
            {
                string sFileQuotename = cmbQuotationNumber.Text;


                //shreeshail is added below 2 line
                Regex illegalInFileName = new Regex(@"[\\/:*?""<>|]");
                string sProjName = sFileQuotename;
                sFileQuotename = illegalInFileName.Replace(sProjName, " ");
                //shreeshail is added above line
                ExcelFolderPath = Properties.Settings.Default.ServiceQuotePath;   // System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + ExcelFolderName + "\\";
                                                                                  //FileFullPath = ExcelFolderPath + "\\" + sFileQuotename + " - " + cmbPICustomer.Text + " - " + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + ".xlsx"; //working code date
                                                                                  //FileFul = ExcelFolderPath + "\\" + sFileQuotename + " - " + cmbPICustomer.Text + " - " + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + ".pdf"; 



                FileFullPath = ExcelFolderPath + "\\" + sFileQuotename + " - " + cmbPICustomer.Text + " - " + txtPImchineNo.Text + " - " + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + ".xlsx"; //working code date
                FileFul = ExcelFolderPath + "\\" + sFileQuotename + " - " + cmbPICustomer.Text + " - " + txtPImchineNo.Text + " - " + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + ".pdf";

                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);
                ExcelApp = new EXCEL.Application();
                misValue = System.Reflection.Missing.Value;


                try
                {
                    if (ExcelApp == null)
                        MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                    NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                    NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                    if (NewWorkSheet == null)
                        MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                    else
                        NewWorkSheet.Name = "Performa Invoice";
                    // Select the Excel cells, in the range c1 to c7 in the worksheet for cell access check.
                    EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                    if (RANGE == null)
                        MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                    //  NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlWorkbookNormal, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    CELLS = NewWorkSheet.Cells;


                    string[] TextN1 ={"","",
                                "ITW India Private Limited - "+cmbPICompany.Text+" Division","497E, 14 Cross, 4th Phase, Peenya Industrial Area,",
                                "Bangalore 560 058, Karnataka, India.","Phone:91(080) 28360184 FAX: (080) 28360047","CIN No : U32301HR1979PTC038643     GSTIN No :29AAACI4550Q2Z1      PAN No : AAACI4550Q"};
                    iRowIndex++;
                    iRowIndex++;
                    foreach (string str in TextN1)
                    {
                        NewWorkSheet.Cells[iRowIndex, 1] = str;
                        // CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                        iRowIndex++;
                    }

                    // iRowIndex++;
                    // iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "Proforma Invoice";
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 5);

                    CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 5);
                    CellMerge("VAlignCenter", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 5);
                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 5);

                    CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 5);
                    //  CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 5, 1, 2);

                    //
                    //iRowIndex++;
                    //NewWorkSheet.Cells[iRowIndex, 3] = "CIN No : U32301HR1979PTC038643";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 5);

                    //iRowIndex++;
                    //NewWorkSheet.Cells[iRowIndex, 3] = "GSTIN No : 33AAACI4550Q1ZD";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 5);

                    //iRowIndex++;
                    //NewWorkSheet.Cells[iRowIndex, 3] = "PAN No : AAACI4550Q";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 5);

                    iRowIndex++;
                    iRowIndex++;
                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = cmbPICustomer.Text;
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                    iRowIndex++;
                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = txtPIAddress.Text + "\n\n" + "Country : " + txtPICountry.Text + "    " + "GSTIN : " + txtPIGSTIN.Text;
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 5, 1, 2);
                    CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 5, 1, 2);
                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);


                    iRowIndex = iRowIndex + 6;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Proforma Invoice No : " + cmbQuotationNumber.Text;
                    NewWorkSheet.Cells[iRowIndex, 4] = "Date : " + dtpPIDate.Text;
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 4, 5);
                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);
                    // NewWorkSheet.Cells[iRowIndex, 6] = dtpPIDate.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);
                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Qtn Ref : " + txtPIQuoteRef.Text;
                    NewWorkSheet.Cells[iRowIndex, 4] = "Date : " + dtpPIQuoterefdate.Text;
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 4, 5);
                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);
                    //   NewWorkSheet.Cells[iRowIndex, 6] = dtpPIQuoterefdate.Text;
                    // CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);
                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Your Ref. Order no : " + txtPIPurchaseOrder.Text;
                    NewWorkSheet.Cells[iRowIndex, 4] = "Date : " + dtpPIPurchaseorderdate.Text;
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 4, 5);
                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);
                    CellMerge("GridLines", NewWorkSheet, 21, iRowIndex, 1, 5); ;
                    iRowIndex++;
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                    // iRowIndex++;
                    // iRowIndex++;
                    //  iRowIndex = iRowIndex + 5;



                    //NewWorkSheet.Cells[iRowIndex, 1] = txtPICountry.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                    /////  CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 6);

                    //iRowIndex++;
                    //NewWorkSheet.Cells[iRowIndex, 1] = txtPIGSTIN.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);

                    iRowIndex++;
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);

                    CellMerge("AlignCenter", NewWorkSheet, iRowIndex + 1, iRowIndex + 1, 1, 5);

                    if (cmbPICurrency.SelectedIndex == 0)
                    {
                        NewWorkSheet.Cells[iRowIndex, 1] = "Note : All prices are in INR";
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                        CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                    }
                    else
                    {
                        NewWorkSheet.Cells[iRowIndex, 1] = "Note : All prices are in USD";
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                        CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                    }
                    iRowIndex++;
                    if (dtOfferItemDeatils.Rows.Count > 0)
                    {
                        object[,] rawData = new object[dtOfferItemDeatils.Rows.Count + 1, dtOfferItemDeatils.Columns.Count];
                        for (int col = 0; col < dtOfferItemDeatils.Columns.Count; col++)
                        {
                            rawData[0, col] = dtOfferItemDeatils.Columns[col].ColumnName;
                        }
                        for (int row = 0; row < dtOfferItemDeatils.Rows.Count; row++)
                        {
                            for (int col = 0; col < dtOfferItemDeatils.Columns.Count; col++)
                            {
                                rawData[row + 1, col] = dtOfferItemDeatils.Rows[row].ItemArray[col];
                            }
                        }
                        string excelRange = string.Empty;
                        string finalColLetter = string.Empty;
                        string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        int colCharsetLen = colCharset.Length;

                        if (dtOfferItemDeatils.Columns.Count > colCharsetLen)
                        {
                            finalColLetter = colCharset.Substring((dtOfferItemDeatils.Columns.Count - 1) / colCharsetLen - 1, 1);
                        }
                        finalColLetter += colCharset.Substring((dtOfferItemDeatils.Columns.Count - 1) % colCharsetLen, 1);
                        excelRange = string.Format("A" + iRowIndex + ":{0}{1}", finalColLetter, (dtOfferItemDeatils.Rows.Count + iRowIndex));
                        NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                    }
                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                    CellMerge("GridLines", NewWorkSheet, iRowIndex, (iRowIndex + dtOfferItemDeatils.Rows.Count + 3), 1, 5);
                    CellMerge("AlignCenter", NewWorkSheet, iRowIndex, (iRowIndex + dtOfferItemDeatils.Rows.Count), 1, 5);
                    CellMerge("VAlignCenter", NewWorkSheet, iRowIndex, (iRowIndex + dtOfferItemDeatils.Rows.Count), 1, 5);

                    Microsoft.Office.Interop.Excel.Range range2 = NewWorkSheet.get_Range("D" + iRowIndex, "F" + (iRowIndex + 3 + dtOfferItemDeatils.Rows.Count) + "");
                    range2.NumberFormat = "#,###";

                    iRowIndex = dtOfferItemDeatils.Rows.Count + iRowIndex;



                    //iRowIndex++;
                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 2] = "Sub Total";
                    NewWorkSheet.Cells[iRowIndex, 5] = txtPIGrandTotal.Text;
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                    CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 4);

                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 2] = "GST (IGST)- " + txtPIGST.Text + "%";
                    double dPIGST = Convert.ToDouble(txtPIGrandTotal.Text) * (Convert.ToDouble(txtPIGST.Text) / 100);
                    NewWorkSheet.Cells[iRowIndex, 5] = dPIGST.ToString();
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);

                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 2] = "Grand Total";
                    NewWorkSheet.Cells[iRowIndex, 5] = Convert.ToDouble(txtPIGrandTotal.Text) + dPIGST;
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                    iRowIndex++;
                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Payment Terms:";
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = txtPIPaymentterms.Text;
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 7, 1, 5);
                    CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 7, 1, 5);
                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex + 7, 1, 5);
                    iRowIndex = iRowIndex + 8;

                    NewWorkSheet.Cells[iRowIndex, 4] = "for ITW India Private Limited,";
                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                    iRowIndex++;

                    // if (login.GetUserDetails[2] == "Chaithra.K.R")
                    {
                        EXCEL.Range oRange2 = (EXCEL.Range)NewWorkSheet.Cells[(iRowIndex), 4];
                        Image oImage2 = Image.FromFile("C:\\Databasepath\\ChaitraSign.jpg");
                        System.Windows.Forms.Clipboard.SetDataObject(oImage2, true);
                        // NewWorkSheet.Paste(oRange2, oImage2);
                        System.Threading.Thread.Sleep(500);
                        NewWorkSheet.Paste(oRange2);
                    }

                    iRowIndex++;
                    iRowIndex++;
                    iRowIndex++;
                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 4] = "Authorised Signatory";
                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 6);
                    iRowIndex++;

                    EXCEL.Range oRange3 = (EXCEL.Range)NewWorkSheet.Cells[(iRowIndex), 4];
                    Image oImage3 = Image.FromFile("C:\\Databasepath\\InstronSeal.jpg");//shreeshail getting error  InstronSeal
                    System.Windows.Forms.Clipboard.SetDataObject(oImage3, true);
                    // NewWorkSheet.Paste(oRange3, oImage3);
                    System.Threading.Thread.Sleep(500);
                    NewWorkSheet.Paste(oRange3);
                    iRowIndex++;
                    iRowIndex++;
                    iRowIndex++;
                    iRowIndex++;
                    //  iRowIndex++;
                    //  iRowIndex++;

                    CellMerge("BorderAround", NewWorkSheet, 1, iRowIndex, 1, 5);
                    NewWorkSheet.Range["A1:E" + (iRowIndex) + ""].Cells.Font.Size = 13;
                    NewWorkSheet.Range["A12:E12"].Cells.Font.Bold = true;
                    NewWorkSheet.Range["A12:E12"].Cells.Font.Size = 16;
                    NewWorkSheet.Range["A9:B9"].Cells.Font.Size = 16;
                    NewWorkSheet.Range["A9:B9"].Cells.Font.Bold = true;
                    NewWorkSheet.Range["A5:B5"].Cells.Font.Size = 16;
                    NewWorkSheet.Range["A5:B5"].Cells.Font.Bold = true;
                    NewWorkSheet.Rows.AutoFit();
                    //NewWorkSheet.Columns.AutoFit();
                    NewWorkSheet.Columns[1].ColumnWidth = 4;
                    NewWorkSheet.Columns[2].ColumnWidth = 55;
                    NewWorkSheet.Columns[2].WrapText = true;
                    NewWorkSheet.Columns[3].ColumnWidth = 16;
                    NewWorkSheet.Columns[4].ColumnWidth = 16;
                    NewWorkSheet.Columns[5].ColumnWidth = 16;



                    NewWorkSheet.PageSetup.PrintArea = "A1:E" + (iRowIndex) + "";
                    //    NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                    NewWorkSheet.PageSetup.PrintNotes = true;
                    NewWorkSheet.PageSetup.CenterHorizontally = true;
                    NewWorkSheet.PageSetup.Zoom = 75;
                    //NewWorkSheet.PageSetup.LeftMargin = 0.3;
                    //NewWorkSheet.PageSetup.RightMargin = 0.3;
                    //NewWorkSheet.PageSetup.TopMargin = 1.8;
                    //NewWorkSheet.PageSetup.BottomMargin = 0.3;
                    NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                    NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
                    // NewWorkSheet.PageSetup.AlignMarginsHeaderFooter = false;
                    // string filename = ("C:\\Databasepath\\Bisslogo.jpg");

                    //  Image HeaderPicture = Image.FromFile("C:\\Databasepath\\BiSSServiceQuoteHeader.jpg");

                    NewWorkSheet.PageSetup.CenterHeaderPicture.Filename = "C:\\Databasepath\\BiSSServiceQuoteHeader.jpg";
                    NewWorkSheet.PageSetup.CenterHeader = "&G";

                    if (File.Exists(Global.sITWLogo))
                    {
                        EXCEL.Range oRange1 = (EXCEL.Range)NewWorkSheet.Cells[2, 2];
                        Image oImage1 = Image.FromFile(Global.sITWLogo);
                        System.Windows.Forms.Clipboard.SetDataObject(oImage1, true);
                        //NewWorkSheet.Paste(oRange1, Global.sITWLogo);
                        System.Threading.Thread.Sleep(500);
                        NewWorkSheet.Paste(oRange1);

                    }

                    if (File.Exists("C:\\Databasepath\\InstronLogo1.jpg"))
                    {
                        EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 4];
                        Image oImage = Image.FromFile("C:\\Databasepath\\InstronLogo.jpg");
                        System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                        //  NewWorkSheet.Paste(oRange, "C:\\Databasepath\\InstronLogo.jpg");
                        System.Threading.Thread.Sleep(500);
                        NewWorkSheet.Paste(oRange);


                    }

                    //NewWorkSheet.PageSetup.LeftHeaderPicture.Filename = "C:\\Databasepath\\BissLogoTP.jpg";
                    //NewWorkSheet.PageSetup.LeftHeader = "&G";
                    //NewWorkSheet.PageSetup.CenterHeader = "Project Description";
                    //NewWorkSheet.PageSetup.RightHeader = "BISS/F/7.5/13";

                    //NewWorkSheet.PageSetup.RightFooter = "Page &P of &N";
                    //NewWorkSheet.PageSetup.LeftFooter = "Issue No: 04";
                    ////string _stLOGO = ("C:\\Databasepath\\Bisslogo.jpg");
                    //EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 7];

                    //Image oImage = Image.FromFile(_stLOGO);
                    //System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    //NewWorkSheet.Paste(oRange, _stLOGO);

                    NewWorkBook.Save();
                    ExcelApp.Visible = false;
                    ExcelApp.ActiveWorkbook.Saved = true;
                    NewWorkBook.ExportAsFixedFormat(EXCEL.XlFixedFormatType.xlTypePDF, FileFul, EXCEL.XlFixedFormatQuality.xlQualityStandard, true);

                    NewWorkBook.Close(true, misValue, misValue);
                    ExcelApp.Quit();
                    releaseObject(NewWorkSheet);
                    releaseObject(NewWorkBook);
                    releaseObject(ExcelApp);
                    System.Diagnostics.Process.Start(FileFul);
                    //ExcelApp.Visible = false;
                    //System.Threading.Thread.Sleep(1000);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    //foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                    //{
                    //    GetProcess.Kill();
                    //}
                }
            }
            else
            {
                MessageBox.Show("No items to save", "Error", 0, MessageBoxIcon.Question);
            }
        }

        private void btnPIBack_Click(object sender, EventArgs e)
        {
            tabPI.SelectTab(0);
        }

        private void txtPIGST_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnNumberKeyPressOnly(sender, e);
        }

        private void txtPIGST_TextChanged(object sender, EventArgs e)
        {
            if (txtPIGST.TextLength > 0)
            {
            }
            else
            {
                txtDiscount.Text = "0";
            }
        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void PaymentCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataSet paymentTermsDataSet = DAL.fnPaymentterm(1, PaymentCode.SelectedItem.ToString());


            if (paymentTermsDataSet != null && paymentTermsDataSet.Tables.Count > 0 && paymentTermsDataSet.Tables[0].Rows.Count > 0)
            {
                string paymentTerms = paymentTermsDataSet.Tables[0].Rows[0]["PaymentTerms"].ToString();

                txtCALPaymentTerms.Text = paymentTerms;
            }

            if (paymentTermsDataSet != null && paymentTermsDataSet.Tables.Count > 0 && paymentTermsDataSet.Tables[0].Rows.Count > 0)
            {
                string paymentTerms = paymentTermsDataSet.Tables[0].Rows[0]["PaymentTerms"].ToString();

                txtpaymentterms.Text = paymentTerms;
            }

            if (paymentTermsDataSet != null && paymentTermsDataSet.Tables.Count > 0 && paymentTermsDataSet.Tables[0].Rows.Count > 0)
            {
                string paymentTerms = paymentTermsDataSet.Tables[0].Rows[0]["PaymentTerms"].ToString();

                txtPIPaymentterms.Text = paymentTerms;
            }
            if (paymentTermsDataSet != null && paymentTermsDataSet.Tables.Count > 0 && paymentTermsDataSet.Tables[0].Rows.Count > 0)
            {
                string paymentTerms = paymentTermsDataSet.Tables[0].Rows[0]["PaymentTerms"].ToString();

                txtRIPaymentTerms.Text = paymentTerms;
            }
        }

        private void tabPage8_Click(object sender, EventArgs e)
        {

        }
    }
}
