﻿namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    partial class frmQuoteView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmQuoteView));
            this.lblFromdate = new System.Windows.Forms.Label();
            this.btnReport = new System.Windows.Forms.Button();
            this.lblToDate = new System.Windows.Forms.Label();
            this.dtpfromdate = new System.Windows.Forms.DateTimePicker();
            this.dtptodate = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvQuoteView = new System.Windows.Forms.DataGridView();
            this.QuotationNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RevisionNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Region = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Leadgenarated = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EnquiryNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DateofEnquiry = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.QuotePreparedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.QuoteCompany = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.QuoteFor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.QuoteModel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.QuoteCapacity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.project8020 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LevelofCustomization = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtSearchText = new System.Windows.Forms.TextBox();
            this.lblItemDescription = new System.Windows.Forms.Label();
            this.btnSearchexactQuote = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuoteView)).BeginInit();
            this.SuspendLayout();
            // 
            // lblFromdate
            // 
            this.lblFromdate.AutoSize = true;
            this.lblFromdate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblFromdate.Location = new System.Drawing.Point(9, 16);
            this.lblFromdate.Name = "lblFromdate";
            this.lblFromdate.Size = new System.Drawing.Size(52, 19);
            this.lblFromdate.TabIndex = 4;
            this.lblFromdate.Text = "From :";
            // 
            // btnReport
            // 
            this.btnReport.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReport.Location = new System.Drawing.Point(334, 9);
            this.btnReport.Name = "btnReport";
            this.btnReport.Size = new System.Drawing.Size(82, 34);
            this.btnReport.TabIndex = 132;
            this.btnReport.Text = "Search";
            this.btnReport.UseVisualStyleBackColor = true;
            this.btnReport.Click += new System.EventHandler(this.btnReport_Click);
            // 
            // lblToDate
            // 
            this.lblToDate.AutoSize = true;
            this.lblToDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblToDate.Location = new System.Drawing.Point(182, 17);
            this.lblToDate.Name = "lblToDate";
            this.lblToDate.Size = new System.Drawing.Size(33, 19);
            this.lblToDate.TabIndex = 6;
            this.lblToDate.Text = "To :";
            // 
            // dtpfromdate
            // 
            this.dtpfromdate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.dtpfromdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpfromdate.Location = new System.Drawing.Point(61, 10);
            this.dtpfromdate.Name = "dtpfromdate";
            this.dtpfromdate.Size = new System.Drawing.Size(115, 27);
            this.dtpfromdate.TabIndex = 9;
            // 
            // dtptodate
            // 
            this.dtptodate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.dtptodate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtptodate.Location = new System.Drawing.Point(217, 12);
            this.dtptodate.Name = "dtptodate";
            this.dtptodate.Size = new System.Drawing.Size(111, 27);
            this.dtptodate.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(428, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 19);
            this.label1.TabIndex = 139;
            this.label1.Text = "Search by :";
            // 
            // dgvQuoteView
            // 
            this.dgvQuoteView.AllowUserToAddRows = false;
            this.dgvQuoteView.AllowUserToDeleteRows = false;
            this.dgvQuoteView.AllowUserToOrderColumns = true;
            this.dgvQuoteView.AllowUserToResizeRows = false;
            this.dgvQuoteView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvQuoteView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvQuoteView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvQuoteView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.QuotationNumber,
            this.RevisionNumber,
            this.Region,
            this.Leadgenarated,
            this.CustomerName,
            this.EnquiryNumber,
            this.DateofEnquiry,
            this.QuotePreparedBy,
            this.QuoteCompany,
            this.QuoteFor,
            this.QuoteModel,
            this.QuoteCapacity,
            this.project8020,
            this.LevelofCustomization});
            this.dgvQuoteView.EnableHeadersVisualStyles = false;
            this.dgvQuoteView.Location = new System.Drawing.Point(3, 51);
            this.dgvQuoteView.Name = "dgvQuoteView";
            this.dgvQuoteView.ReadOnly = true;
            this.dgvQuoteView.RowHeadersVisible = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvQuoteView.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvQuoteView.Size = new System.Drawing.Size(1317, 564);
            this.dgvQuoteView.TabIndex = 137;
            // 
            // QuotationNumber
            // 
            this.QuotationNumber.DataPropertyName = "QuotationNumber";
            this.QuotationNumber.HeaderText = "Quotation Number";
            this.QuotationNumber.Name = "QuotationNumber";
            this.QuotationNumber.ReadOnly = true;
            this.QuotationNumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // RevisionNumber
            // 
            this.RevisionNumber.DataPropertyName = "RevisionNumber";
            this.RevisionNumber.HeaderText = "Revision Number";
            this.RevisionNumber.Name = "RevisionNumber";
            this.RevisionNumber.ReadOnly = true;
            this.RevisionNumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Region
            // 
            this.Region.DataPropertyName = "Region";
            this.Region.HeaderText = "Region";
            this.Region.Name = "Region";
            this.Region.ReadOnly = true;
            this.Region.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Leadgenarated
            // 
            this.Leadgenarated.DataPropertyName = "Leadgenarated";
            this.Leadgenarated.HeaderText = "Lead Genarated";
            this.Leadgenarated.Name = "Leadgenarated";
            this.Leadgenarated.ReadOnly = true;
            this.Leadgenarated.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // CustomerName
            // 
            this.CustomerName.DataPropertyName = "CustomerName";
            this.CustomerName.HeaderText = "Customer";
            this.CustomerName.Name = "CustomerName";
            this.CustomerName.ReadOnly = true;
            this.CustomerName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // EnquiryNumber
            // 
            this.EnquiryNumber.DataPropertyName = "EnquiryNumber";
            this.EnquiryNumber.HeaderText = "Enquiry Number";
            this.EnquiryNumber.Name = "EnquiryNumber";
            this.EnquiryNumber.ReadOnly = true;
            this.EnquiryNumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // DateofEnquiry
            // 
            this.DateofEnquiry.DataPropertyName = "DateofEnquiry";
            this.DateofEnquiry.HeaderText = "Date of Enquiry";
            this.DateofEnquiry.Name = "DateofEnquiry";
            this.DateofEnquiry.ReadOnly = true;
            this.DateofEnquiry.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // QuotePreparedBy
            // 
            this.QuotePreparedBy.DataPropertyName = "QuotePreparedBy";
            this.QuotePreparedBy.HeaderText = "Quote Prepared By";
            this.QuotePreparedBy.Name = "QuotePreparedBy";
            this.QuotePreparedBy.ReadOnly = true;
            this.QuotePreparedBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // QuoteCompany
            // 
            this.QuoteCompany.DataPropertyName = "QuoteCompany";
            this.QuoteCompany.HeaderText = "Quote Company";
            this.QuoteCompany.Name = "QuoteCompany";
            this.QuoteCompany.ReadOnly = true;
            this.QuoteCompany.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // QuoteFor
            // 
            this.QuoteFor.DataPropertyName = "QuoteFor";
            this.QuoteFor.HeaderText = "Quote System";
            this.QuoteFor.Name = "QuoteFor";
            this.QuoteFor.ReadOnly = true;
            this.QuoteFor.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // QuoteModel
            // 
            this.QuoteModel.HeaderText = "Quote Model";
            this.QuoteModel.Name = "QuoteModel";
            this.QuoteModel.ReadOnly = true;
            // 
            // QuoteCapacity
            // 
            this.QuoteCapacity.HeaderText = "Quote Capacity";
            this.QuoteCapacity.Name = "QuoteCapacity";
            this.QuoteCapacity.ReadOnly = true;
            // 
            // project8020
            // 
            this.project8020.HeaderText = "project 80/20";
            this.project8020.Name = "project8020";
            this.project8020.ReadOnly = true;
            // 
            // LevelofCustomization
            // 
            this.LevelofCustomization.HeaderText = "Level of Customization";
            this.LevelofCustomization.Name = "LevelofCustomization";
            this.LevelofCustomization.ReadOnly = true;
            // 
            // txtSearchText
            // 
            this.txtSearchText.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchText.Location = new System.Drawing.Point(518, 15);
            this.txtSearchText.Name = "txtSearchText";
            this.txtSearchText.Size = new System.Drawing.Size(281, 27);
            this.txtSearchText.TabIndex = 141;
            this.txtSearchText.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtSearchText_KeyUp);
            // 
            // lblItemDescription
            // 
            this.lblItemDescription.AutoSize = true;
            this.lblItemDescription.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemDescription.Location = new System.Drawing.Point(864, 4);
            this.lblItemDescription.Name = "lblItemDescription";
            this.lblItemDescription.Size = new System.Drawing.Size(456, 38);
            this.lblItemDescription.TabIndex = 142;
            this.lblItemDescription.Text = "Search results include : QuotationNumber,Region,Leadgenarated,\r\nCustomerName,Quot" +
    "ePreparedBy and QuoteCompany\r\n";
            // 
            // btnSearchexactQuote
            // 
            this.btnSearchexactQuote.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearchexactQuote.Location = new System.Drawing.Point(805, 11);
            this.btnSearchexactQuote.Name = "btnSearchexactQuote";
            this.btnSearchexactQuote.Size = new System.Drawing.Size(60, 34);
            this.btnSearchexactQuote.TabIndex = 143;
            this.btnSearchexactQuote.Text = "Search";
            this.btnSearchexactQuote.UseVisualStyleBackColor = true;
            this.btnSearchexactQuote.Click += new System.EventHandler(this.btnSearchexactQuote_Click);
            // 
            // frmQuoteView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1318, 619);
            this.Controls.Add(this.btnSearchexactQuote);
            this.Controls.Add(this.lblFromdate);
            this.Controls.Add(this.btnReport);
            this.Controls.Add(this.lblItemDescription);
            this.Controls.Add(this.lblToDate);
            this.Controls.Add(this.txtSearchText);
            this.Controls.Add(this.dtpfromdate);
            this.Controls.Add(this.dtptodate);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvQuoteView);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmQuoteView";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quote View";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmQuoteView_FormClosing);
            this.Load += new System.EventHandler(this.frmQuoteView_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuoteView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblFromdate;
        private System.Windows.Forms.Button btnReport;
        private System.Windows.Forms.Label lblToDate;
        private System.Windows.Forms.DateTimePicker dtpfromdate;
        private System.Windows.Forms.DateTimePicker dtptodate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvQuoteView;
        private System.Windows.Forms.TextBox txtSearchText;
        private System.Windows.Forms.Label lblItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn QuotationNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn RevisionNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn Region;
        private System.Windows.Forms.DataGridViewTextBoxColumn Leadgenarated;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerName;
        private System.Windows.Forms.DataGridViewTextBoxColumn EnquiryNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn DateofEnquiry;
        private System.Windows.Forms.DataGridViewTextBoxColumn QuotePreparedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn QuoteCompany;
        private System.Windows.Forms.Button btnSearchexactQuote;
        private System.Windows.Forms.DataGridViewTextBoxColumn QuoteFor;
        private System.Windows.Forms.DataGridViewTextBoxColumn QuoteModel;
        private System.Windows.Forms.DataGridViewTextBoxColumn QuoteCapacity;
        private System.Windows.Forms.DataGridViewTextBoxColumn project8020;
        private System.Windows.Forms.DataGridViewTextBoxColumn LevelofCustomization;
    }
}