﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.Diagnostics;
using System.IO;

namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    public partial class frmQuoteViewItems : Form
    {
        public frmQuoteViewItems()
        {
            InitializeComponent();
        }
        frmForm2 form = new frmForm2();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();

        DataTable dtQuoteList = new DataTable();

        private static string sQuoteNo;

        public string fnQuoteform
        {
            get
            {
                return sQuoteNo;
            }
            set
            {
                sQuoteNo = value;
            }
        }


        private void frmQuoteViewItems_Load(object sender, EventArgs e)
        {
            dtpfromdate.ResetText();
            dtptodate.ResetText();
            fnLoadResults();
        }
        private void fnLoadResults()
        {
            var date = DateTime.Parse(dtpfromdate.Text);
            var date1 = DateTime.Parse(dtptodate.Text);

            dtQuoteList = DAL.fnAllQuoteViewDetails(1, null, date.ToString("yyyy-MM-dd"), date1.ToString("yyyy-MM-dd")).Tables[0];
            if (dtQuoteList.Rows.Count > 0)
            {
                dgvQuoteView.AutoGenerateColumns = false;
                dgvQuoteView.DataSource = dtQuoteList;
            }
            //fnTotalCalucalation();
            //  fnOptionalItemTotalCalculation();
            dtClone = dtQuoteList.Copy();
            bsIteSearch.DataSource = dtClone;
        }

        BindingSource bsIteSearch = new BindingSource();
        DataTable dtClone = new DataTable();

        private void btnSearch_Click(object sender, EventArgs e)
        {
            fnLoadResults();
        }


        private void fnRowFilter(uint uSearchOption, string sRowFilter)    //filter the Item list depends upon the user inpts
        {
            if (dtQuoteList.Rows.Count > 0)
            {
                switch (uSearchOption)
                {
                    case Global.uITEM_CODE_SEARCH:
                        {
                            bsIteSearch.Filter = string.Format("QuotationNumber LIKE '%{0}%' or QuoteModel LIKE '%{0}%'  or QuoteCapacity LIKE '%{0}%' or [QuoteName] LIKE '%{0}%' or CustomerName LIKE '%{0}%' or QuotePreparedBy LIKE '%{0}%' or QuoteCompany LIKE '%{0}%' or  EnquiryNumber LIKE '%{0}%'", sRowFilter);
                            break;
                        }
                }
            }
        }

        private void txtSearchText_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtSearchText.Text.Length > 1)
            {
                fnRowFilter(0, txtSearchText.Text);
                dgvQuoteView.DataSource = bsIteSearch;
            }
            else
            {
                bsIteSearch.RemoveFilter();
            }
        }

        private void Datagridviewcolor(string ColumnName, DataGridView dgDataGridView)
        {
            foreach (DataGridViewRow dgr in dgDataGridView.Rows)
            {
                if ((dgr.Cells[ColumnName].Value.ToString()) == "")
                {
                    dgr.DefaultCellStyle.BackColor = Color.BurlyWood;
                }
            }
        }

        DataTable dtQuote = new DataTable();
        DataTable dtQuoteOptionalItems = new DataTable();
        private void dgvQuoteView_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (!string.IsNullOrEmpty(sQuoteNo))
            {
                Sales_Enquiry.frmSalesQuote SQ = new frmSalesQuote();

                if (sQuoteNo.ToString() == "1" && dgvQuoteView.CurrentRow.Cells[1].Value.ToString() != null)
                {
                    SQ.fnQuote1no = dgvQuoteView.CurrentRow.Cells[1].Value.ToString();
                    SQ.fnQuote1Revno = dgvQuoteView.CurrentRow.Cells[2].Value.ToString();
                    sQuoteNo = "0";
                    this.Close();
                }
            }
        }

        private void rbViewQuote_CheckedChanged(object sender, EventArgs e)
        {
            pnMainItems.Visible = true;
            dgQuoteBOM.Visible = true;
            Datagridviewcolor("ProductCod", dgQuoteBOM);
            dgWriteUP.Visible = false;
            dgvOptionalItems.Visible = false;
            dgOIWriteUP.Visible = false;
        }

        private void rbviewquotewu_CheckedChanged(object sender, EventArgs e)
        {
            dgQuoteBOM.Visible = false;
            dgWriteUP.Visible = true;
            dgvOptionalItems.Visible = false;
            dgOIWriteUP.Visible = false;
        }

        private void rbviewquoteo_CheckedChanged(object sender, EventArgs e)
        {
            pnMainItems.Visible = false;
            dgQuoteBOM.Visible = false;
            dgWriteUP.Visible = false;
            dgvOptionalItems.Visible = true;
            Datagridviewcolor("OIProductCode", dgvOptionalItems);
            dgOIWriteUP.Visible = false;
        }


        private void rbviewquoteowu_CheckedChanged(object sender, EventArgs e)
        {
            dgQuoteBOM.Visible = false;
            dgWriteUP.Visible = false;
            dgvOptionalItems.Visible = false;
            dgOIWriteUP.Visible = true;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            pnQuoteItemsView.Visible = false;
            pnMainItems.Visible = false;
        }

        private void btnExcel_Click(object sender, EventArgs e)
        {
            string ExcelFolderPath;
            string FileFullPath;
            //  dgvQuoteView.DataSource
            Microsoft.Office.Interop.Excel._Application ExcelApp = null;
            Microsoft.Office.Interop.Excel._Workbook NewWorkBook = null;
            Cursor.Current = Cursors.WaitCursor;

            bool IsFirsttime = true;

            if (dtQuoteList.Rows.Count > 0)
            {
                int j = 6;
                ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\BiSS Quote List\\";
                FileFullPath = ExcelFolderPath + "BiSS Quote List" + dtpfromdate.Text + " To " + dtptodate.Text + " " + DateTime.Now.ToString("d/M/yyyy HH/mm/ss") + " ";
                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);

                ExcelApp = new Microsoft.Office.Interop.Excel.Application();
                NewWorkBook = ExcelApp.Workbooks.Add(Type.Missing);
                Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
                worksheet = NewWorkBook.Sheets["Sheet1"];
                worksheet = NewWorkBook.ActiveSheet;
                worksheet.Name = "BiSS Quotation Report";
                object misValue = System.Reflection.Missing.Value;
                worksheet.Cells[1, 1] = "BiSS Quotation Report";
                CellMerge("Merge", NewWorkBook.ActiveSheet, 1, 1, 1, 3);
                //worksheet.Cells[2, 1] = "Item Code :'" + lblRepeatitemcode.Text + "'";// i++;
                //CellMerge("Merge", NewWorkBook.ActiveSheet, 2, 2, 1, 7);
                //worksheet.Cells[3, 1] = "Item Desc : " + lblitemname.Text + "";
                //CellMerge("Merge", NewWorkBook.ActiveSheet, 3, 3, 1, 7);
                worksheet.Cells[4, 1] = "Dated From : " + dtpfromdate.Text + "  To : " + dtptodate.Text + "";// i++; i++;
                CellMerge("Merge", NewWorkBook.ActiveSheet, 4, 4, 1, 5);
                worksheet.Range["A1:C1"].Cells.Font.Size = 16;
                worksheet.Range["A2:C3"].Cells.Font.Size = 14;
                worksheet.Range["A4:C4"].Cells.Font.Size = 12;
                worksheet.Range["A1:C3"].Cells.Font.Bold = true;
                bool bFirsttime = true;

                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Bold = true;
                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Color = Color.Blue;


                object[,] rawData = new object[dtQuoteList.Rows.Count + 1, dtQuoteList.Columns.Count];
                if (bFirsttime)
                {
                    for (int col = 0; col < dtQuoteList.Columns.Count; col++)
                    {
                        rawData[0, col] = dtQuoteList.Columns[col].ColumnName;
                    }
                    bFirsttime = false;
                }
                if (dtQuoteList.Rows.Count > 0)
                {
                    for (int row = 0; row < dtQuoteList.Rows.Count; row++)
                    {
                        for (int col = 0; col < dtQuoteList.Columns.Count; col++)
                        {
                            rawData[row + 1, col] = dtQuoteList.Rows[row].ItemArray[col];
                        }
                    }
                    string finalColLetter = string.Empty;
                    string excelRange = string.Empty;
                    if (IsFirsttime)
                    {
                        finalColLetter = string.Empty;
                        string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        int colCharsetLen = colCharset.Length;

                        if (dtQuoteList.Columns.Count > colCharsetLen)
                        {
                            finalColLetter = colCharset.Substring(
                                (dtQuoteList.Columns.Count - 1) / colCharsetLen - 1, 1);
                        }

                        finalColLetter += colCharset.Substring(
                                (dtQuoteList.Columns.Count - 1) % colCharsetLen, 1);
                        excelRange = string.Format("A6:{0}{1}", finalColLetter, dtQuoteList.Rows.Count + j);
                        IsFirsttime = false;
                    }
                    worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;

                }

                worksheet.Range["A3:C5"].Cells.Font.Size = 14;
                worksheet.Range["A3:C5"].Cells.Font.Bold = 14;
                CellMerge("Merge", NewWorkBook.ActiveSheet, 1, 1, 1, 3);
                worksheet.get_Range("C6", "C99999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                //Microsoft.Office.Interop.Excel.Range Range = worksheet.get_Range("N6", "R99999");
                //Range.EntireColumn.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                worksheet.Rows.RowHeight = "18";
                //Microsoft.Office.Interop.Excel.Range rangea = worksheet.get_Range("J6", "J99999");
                //  rangea.NumberFormat = "dd-MM-yyyy";

                //  if (cmbReportType.SelectedIndex == 0 || cmbReportType.SelectedIndex == 5 || cmbReportType.SelectedIndex == 6)
                {
                    Microsoft.Office.Interop.Excel.Range rangea = worksheet.get_Range("G6", "G99999");
                    rangea.NumberFormat = "dd-MM-yyyy";
                    Microsoft.Office.Interop.Excel.Range rangeDate = worksheet.get_Range("I6", "I9999");
                    rangeDate.NumberFormat = "dd-MM-yyyy";

                    //Microsoft.Office.Interop.Excel.Range rangeDate1 = worksheet.get_Range("N6", "N9999");
                    //rangeDate1.NumberFormat = "0.00";
                }

                worksheet.Columns.AutoFit();
                worksheet.Rows.AutoFit();
                //worksheet.Columns[1].ColumnWidth = 12;
                //worksheet.Columns[1].WrapText = true;
                //worksheet.Columns[12].ColumnWidth = 50;
                // worksheet.Columns[12].WrapText = true;
                //worksheet.Columns[8].ColumnWidth = 50;
                //worksheet.Columns[8].WrapText = true;
                worksheet.Rows.RowHeight = "18";
                worksheet.PageSetup.PrintArea = "A1:J" + (dtQuoteList.Rows.Count + 6) + "";
                worksheet.PageSetup.PrintTitleRows = "$1:$2";
                worksheet.PageSetup.PrintNotes = true;
                worksheet.PageSetup.Zoom = 75;
                worksheet.PageSetup.PrintGridlines = true;
                worksheet.PageSetup.LeftMargin = 0;
                worksheet.PageSetup.RightMargin = 0;
                worksheet.PageSetup.TopMargin = 0.75;
                worksheet.PageSetup.BottomMargin = 0.75;
                worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                NewWorkBook.SaveAs(FileFullPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                NewWorkBook.Save();
                NewWorkBook.Close(true, misValue, misValue);
                ExcelApp.Quit();
                releaseObject(worksheet);
                releaseObject(NewWorkBook);
                releaseObject(ExcelApp);

                if (Directory.Exists(ExcelFolderPath))
                {
                    Process.Start(ExcelFolderPath);
                }
                Cursor.Current = Cursors.Default;
            }
        }

        #region CellMerge Funtion
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlMedium, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "GridLines":
                    {
                        CELLS.Borders.Color = System.Drawing.Color.Black;
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignCenter":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                        break;
                    }
                case "Bold":
                    {
                        CELLS.Font.Bold = true;
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

        }
        #endregion

        #region Excel App Release Object Function
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
        #endregion

        DataTable QuoteTaxDetails = new DataTable();
        private void dgvQuoteView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvQuoteView.CurrentCell.ColumnIndex == 0)
            {
                if (!string.IsNullOrEmpty(dgvQuoteView.CurrentRow.Cells[1].Value.ToString()) && !string.IsNullOrEmpty(dgvQuoteView.CurrentRow.Cells[2].Value.ToString()))
                {
                    lblQuoteNo.Text = dgvQuoteView.CurrentRow.Cells[1].Value.ToString();
                    lblRevision.Text = dgvQuoteView.CurrentRow.Cells[2].Value.ToString();
                    dtQuote = DAL.fnQuotationNumberLoadData(2, dgvQuoteView.CurrentRow.Cells[1].Value.ToString(), dgvQuoteView.CurrentRow.Cells[2].Value.ToString()).Tables[0];
                    dtQuoteOptionalItems = DAL.fnQuotationNumberLoadData(7, dgvQuoteView.CurrentRow.Cells[1].Value.ToString(), dgvQuoteView.CurrentRow.Cells[2].Value.ToString()).Tables[0];
                    if (dtQuote.Rows.Count > 0)
                    {
                        dgQuoteBOM.AutoGenerateColumns = false;
                        dgQuoteBOM.DataSource = dtQuote;
                        dgWriteUP.AutoGenerateColumns = false;
                        dgWriteUP.DataSource = dtQuote;
                        Datagridviewcolor("ProductCod", dgQuoteBOM);
                        pnQuoteItemsView.Visible = true;
                        pnMainItems.Visible = true;
                        rbViewQuote.Checked = true;
                       
                    }
                    if (dtQuoteOptionalItems.Rows.Count > 0)
                    {
                        dgvOptionalItems.AutoGenerateColumns = false;
                        dgvOptionalItems.DataSource = dtQuoteOptionalItems;
                        dgOIWriteUP.AutoGenerateColumns = false;
                        dgOIWriteUP.DataSource = dtQuoteOptionalItems;
                        Datagridviewcolor("OIProductCode", dgvOptionalItems);
                    }

                    QuoteTaxDetails = DAL.fnQuotationNumberLoadData(3, dgvQuoteView.CurrentRow.Cells[1].Value.ToString(), dgvQuoteView.CurrentRow.Cells[2].Value.ToString()).Tables[0];
                    if (QuoteTaxDetails.Rows.Count > 0)
                    {
                        txtTotalPrice.Text = QuoteTaxDetails.Rows[0]["SellingPrice"].ToString();
                        chkBreakup.Checked = Convert.ToBoolean(QuoteTaxDetails.Rows[0]["BreakupPrice"].ToString());
                        txtJackup.Text = QuoteTaxDetails.Rows[0]["NegotiatryCushion"].ToString();
                        fnJackUpCalculation();
                    }
                }
            }
        }

        double dQunaitity, dSalesBreakup, dSalesMarginCost, sBrekTotalAmount, sTotalAmount = 0;

        private void btnSearchQuotenumbe_Click(object sender, EventArgs e)
        {
            dtQuoteList = DAL.fnAllQuoteViewDetails(2, txtSearchText.Text, "", "").Tables[0];
            if (dtQuoteList.Rows.Count > 0)
            {
                dgvQuoteView.AutoGenerateColumns = false;
                dgvQuoteView.DataSource = dtQuoteList;
            }

            dtClone = dtQuoteList.Copy();
            bsIteSearch.DataSource = dtClone;
        }

        private void fnJackUpCalculation()
        {
            dSalesMarginCost = 0;
            sBrekTotalAmount = 0;
            sTotalAmount = 0;
            foreach (DataGridViewRow dgvr in dgQuoteBOM.Rows)
            {
                sBrekTotalAmount += (Convert.ToDouble(dgvr.Cells["BreakupTotal"].Value) * Convert.ToDouble(dgvr.Cells["Quantity"].Value));
                dSalesMarginCost += (Convert.ToDouble(dgvr.Cells["SalesCost"].Value) * Convert.ToDouble(dgvr.Cells["Quantity"].Value));
            }


            txtSystemMargin.Text = Math.Round((1 - (dSalesMarginCost / sBrekTotalAmount)) * 100).ToString() + " %";

            if (login.GetUserDetails[2].ToLower() == "vivek g" || login.GetUserDetails[2].ToLower() == "sadat" || login.GetUserDetails[2].ToLower() == "abhilash")
            {

            }
            else
            {
                if (!string.IsNullOrEmpty(txtSystemMargin.Text))
                {
                    double kCheck = Convert.ToDouble(Math.Round((1 - (dSalesMarginCost / sBrekTotalAmount)) * 100));
                    if (kCheck > 0)
                    {
                        txtSystemMargin.Text = (Math.Round((1 - (dSalesMarginCost / sBrekTotalAmount)) * 100) - 5).ToString() + " %";
                    }
                }
            }

            double dBasic = Math.Round(((Convert.ToDouble(txtTotalPrice.Text) * Convert.ToDouble(txtJackup.Text)) / 100 + (Convert.ToDouble(txtTotalPrice.Text))));
            txtBasicDemoPrice.Text = dBasic.ToString();
            txtQuoteJack.Text = dBasic.ToString();

            txtQuoteBreak.Text = Math.Round(sBrekTotalAmount).ToString();

            double dVa = Math.Round((Convert.ToDouble(txtQuoteJack.Text) - Convert.ToDouble(txtQuoteBreak.Text)));
            txtQuoteRemain.Text = dVa.ToString();

            if (Convert.ToDouble(txtQuoteBreak.Text) <= (Convert.ToDouble(txtQuoteJack.Text)))
            {
                txtQuoteBreak.BackColor = Color.GreenYellow;
                txtQuoteRemain.BackColor = Color.White;
            }
            else
            {
                txtQuoteRemain.BackColor = Color.Red;
                txtQuoteBreak.BackColor = Color.White;
            }

           
        }
    }
}
