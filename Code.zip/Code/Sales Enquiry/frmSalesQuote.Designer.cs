﻿namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    partial class frmSalesQuote
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSalesQuote));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblcustomer = new System.Windows.Forms.Label();
            this.cmbEnquireCurrency = new System.Windows.Forms.ComboBox();
            this.cmbCustomer = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbQuotationfor = new System.Windows.Forms.ComboBox();
            this.cmbRegion = new System.Windows.Forms.ComboBox();
            this.lblregion = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCustomertype = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtContactPerson1 = new System.Windows.Forms.TextBox();
            this.txtContactNumber1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.dtpEnquireDate = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.cmbModel = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.cmbCapacity = new System.Windows.Forms.ComboBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txtOldModelNumber = new System.Windows.Forms.TextBox();
            this.label84 = new System.Windows.Forms.Label();
            this.lblQuoteBy = new System.Windows.Forms.Label();
            this.lblQuotebyin = new System.Windows.Forms.Label();
            this.cmbQuoteType = new System.Windows.Forms.ComboBox();
            this.label80 = new System.Windows.Forms.Label();
            this.cmblevelofcustomization = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.lblPrepareBy = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.cmbeightytwenty = new System.Windows.Forms.ComboBox();
            this.label78 = new System.Windows.Forms.Label();
            this.cmbQuoteCompany = new System.Windows.Forms.ComboBox();
            this.label67 = new System.Windows.Forms.Label();
            this.cmbIncoTerms = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.chkintrastate = new System.Windows.Forms.CheckBox();
            this.txtCusCode = new System.Windows.Forms.TextBox();
            this.txtModelNumber = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.txtEmailID1 = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.txtQuoteName = new System.Windows.Forms.TextBox();
            this.cmbLeadGenarated = new System.Windows.Forms.ComboBox();
            this.txtLeadTime = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.txtQuoteWarranty = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txtQuoteValidity = new System.Windows.Forms.TextBox();
            this.lblDeliveryTerms = new System.Windows.Forms.Label();
            this.txtDepartment1 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.txtTenderNo = new System.Windows.Forms.TextBox();
            this.btnStartQuote = new System.Windows.Forms.Button();
            this.dtpQuoteDate = new System.Windows.Forms.DateTimePicker();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.txtCompetation = new System.Windows.Forms.TextBox();
            this.cmbprimarymtrldetail = new System.Windows.Forms.TextBox();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnGotoAddProducts = new System.Windows.Forms.Button();
            this.txtLostReason = new System.Windows.Forms.TextBox();
            this.txtWonReason = new System.Windows.Forms.TextBox();
            this.txtSpecifyOthers = new System.Windows.Forms.TextBox();
            this.txtExpectedValueUSD = new System.Windows.Forms.TextBox();
            this.dtpExpectedOrderPlacementdate = new System.Windows.Forms.DateTimePicker();
            this.cmbWinLose = new System.Windows.Forms.ComboBox();
            this.cmbCompetetion = new System.Windows.Forms.ComboBox();
            this.cmbProbabality = new System.Windows.Forms.ComboBox();
            this.cmbtypeofcustomer = new System.Windows.Forms.ComboBox();
            this.cmbStatus = new System.Windows.Forms.ComboBox();
            this.cmbStage = new System.Windows.Forms.ComboBox();
            this.cmbTestEnvironment = new System.Windows.Forms.ComboBox();
            this.cmbApplication = new System.Windows.Forms.ComboBox();
            this.cmbprimarymaterial = new System.Windows.Forms.ComboBox();
            this.cmbprimaryind = new System.Windows.Forms.ComboBox();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.cmbLabtype = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbBusinessector = new System.Windows.Forms.ComboBox();
            this.label29 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.chkUpdateLatestPrice = new System.Windows.Forms.CheckBox();
            this.pnAddProduct = new System.Windows.Forms.Panel();
            this.btnAddCategoryProduct = new System.Windows.Forms.Button();
            this.txtProductCategory = new System.Windows.Forms.TextBox();
            this.chkAddProduct = new System.Windows.Forms.CheckBox();
            this.label66 = new System.Windows.Forms.Label();
            this.cmbProductCategory = new System.Windows.Forms.ComboBox();
            this.label64 = new System.Windows.Forms.Label();
            this.txtSystemMargin = new System.Windows.Forms.TextBox();
            this.chkProductCode = new System.Windows.Forms.CheckBox();
            this.pnOptionalItems = new System.Windows.Forms.Panel();
            this.txtOIBasicDemoPrice = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.chkOIBreakup = new System.Windows.Forms.CheckBox();
            this.label57 = new System.Windows.Forms.Label();
            this.txtOITotalPrice = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.txtOIJackup = new System.Windows.Forms.TextBox();
            this.txtOIQuoteRemain = new System.Windows.Forms.TextBox();
            this.txtOIQuoteBreak = new System.Windows.Forms.TextBox();
            this.txtOIQuoteJack = new System.Windows.Forms.TextBox();
            this.chkOptionalItems = new System.Windows.Forms.CheckBox();
            this.chkaddmainitems = new System.Windows.Forms.CheckBox();
            this.txtBasicDemoPrice = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.chkSavetoQuoteMaster = new System.Windows.Forms.CheckBox();
            this.chkAddbyQuoteMaster = new System.Windows.Forms.CheckBox();
            this.chkAddbyBOM = new System.Windows.Forms.CheckBox();
            this.pnQuoteMaster = new System.Windows.Forms.Panel();
            this.btnRename = new System.Windows.Forms.Button();
            this.btnAddProduct = new System.Windows.Forms.Button();
            this.btnAddFolder = new System.Windows.Forms.Button();
            this.btnQuoteTreeSave = new System.Windows.Forms.Button();
            this.txtCode = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.tvQuoteProduct = new System.Windows.Forms.TreeView();
            this.imageList2 = new System.Windows.Forms.ImageList(this.components);
            this.label22 = new System.Windows.Forms.Label();
            this.chkBreakup = new System.Windows.Forms.CheckBox();
            this.label46 = new System.Windows.Forms.Label();
            this.txtTotalPrice = new System.Windows.Forms.TextBox();
            this.lblCST = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.txtJackup = new System.Windows.Forms.TextBox();
            this.txtQuoteRemain = new System.Windows.Forms.TextBox();
            this.txtQuoteBreak = new System.Windows.Forms.TextBox();
            this.txtQuoteJack = new System.Windows.Forms.TextBox();
            this.btnBack1 = new System.Windows.Forms.Button();
            this.btngotoquote = new System.Windows.Forms.Button();
            this.cleartreeview = new System.Windows.Forms.Button();
            this.txtsearchtree = new System.Windows.Forms.TextBox();
            this.btnsearchtree = new System.Windows.Forms.Button();
            this.tvProduct = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.dgQuoteBOM = new System.Windows.Forms.DataGridView();
            this.SLNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductGroup = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductCod = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BreakupTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SalesCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SalesCostTemp = new System.Windows.Forms.DataGridViewTextBoxColumn();//SalesCostTemp
            this.materialMargin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvOptionalItems = new System.Windows.Forms.DataGridView();
            this.OISLNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OIProductGroup = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OIProductCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OIProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OIProductDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OIQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OIUnitPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OITotalPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SP1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OIBreakupTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OISalesCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OImaterialMargin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.chkWUOptionalItems = new System.Windows.Forms.CheckBox();
            this.chkWUQuoteItems = new System.Windows.Forms.CheckBox();
            this.btnBack2 = new System.Windows.Forms.Button();
            this.btnQuotePricing = new System.Windows.Forms.Button();
            this.dgWriteUP = new System.Windows.Forms.DataGridView();
            this.WUSlNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WUProductcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WUDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgOIWriteUP = new System.Windows.Forms.DataGridView();
            this.DGOISlNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WUOIProductCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WUOIProductDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.NoOptionalItems = new System.Windows.Forms.Label();
            this.discountedMMValue = new System.Windows.Forms.Label();
            this.discountedMMlb = new System.Windows.Forms.Label();
            this.totalCostLable = new System.Windows.Forms.Label();
            this.cmbBank = new System.Windows.Forms.ComboBox();
            this.label83 = new System.Windows.Forms.Label();
            this.txtAdditionalMonths = new System.Windows.Forms.TextBox();
            this.chkQuoteSavePath = new System.Windows.Forms.CheckBox();
            this.btnPreview = new System.Windows.Forms.Button();
            this.chkConcessionGst = new System.Windows.Forms.CheckBox();
            this.chkShowPackingForwarding = new System.Windows.Forms.CheckBox();
            this.pnInstallCommision = new System.Windows.Forms.Panel();
            this.txtServiceTaxSGSTAmount = new System.Windows.Forms.TextBox();
            this.lblServiceSgst = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.txtServiceTaxSGSTPercent = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.txtaddNote = new System.Windows.Forms.TextBox();
            this.cheSetReminder = new System.Windows.Forms.CheckBox();
            this.pnAppointment = new System.Windows.Forms.Panel();
            this.txtLocation = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.txtBody = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.txtSubject = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.dtpEndDate = new System.Windows.Forms.DateTimePicker();
            this.label49 = new System.Windows.Forms.Label();
            this.dtpFromDate = new System.Windows.Forms.DateTimePicker();
            this.label48 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.txtadditionalWarPer = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.txtAdditionalwarrantyAmount = new System.Windows.Forms.TextBox();
            this.lblServiceIgst = new System.Windows.Forms.Label();
            this.pnGst = new System.Windows.Forms.Panel();
            this.lblIgst = new System.Windows.Forms.Label();
            this.txtIGSTPer = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.txtIGSTAmount = new System.Windows.Forms.TextBox();
            this.txtSgstPer = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.txtSGSTAmount = new System.Windows.Forms.TextBox();
            this.lblSGST = new System.Windows.Forms.Label();
            this.txtServiceTaxIGSTPercent = new System.Windows.Forms.TextBox();
            this.pnIncoterm = new System.Windows.Forms.Panel();
            this.txtFreight = new System.Windows.Forms.TextBox();
            this.txtInsurance = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.txtServiceTaxIGSTAmount = new System.Windows.Forms.TextBox();
            this.btnGenarateQuote = new System.Windows.Forms.Button();
            this.btnFinQuote = new System.Windows.Forms.Button();
            this.btnTechQuote = new System.Windows.Forms.Button();
            this.label37 = new System.Windows.Forms.Label();
            this.txtaftrerdisount = new System.Windows.Forms.TextBox();
            this.cmbPaymentTerms = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.TxtAfterInstal = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.txtAdvance = new System.Windows.Forms.TextBox();
            this.txtAfterPDI = new System.Windows.Forms.TextBox();
            this.btnBack3 = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.txtBsaicPrice = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtInsatallationCommision = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.lblFinalNetAmount = new System.Windows.Forms.Label();
            this.lblPaymentTerms = new System.Windows.Forms.Label();
            this.txtFinalNetAmount = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.lblPackingAndForwording = new System.Windows.Forms.Label();
            this.txtPackingForwarding = new System.Windows.Forms.TextBox();
            this.txtDiscAmount = new System.Windows.Forms.TextBox();
            this.txtDiscount = new System.Windows.Forms.TextBox();
            this.lblPrice = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.cmbQuotationNumber = new System.Windows.Forms.ComboBox();
            this.label35 = new System.Windows.Forms.Label();
            this.pnQuotationNumber = new System.Windows.Forms.Panel();
            this.cmbRevisionNumber = new System.Windows.Forms.ComboBox();
            this.label36 = new System.Windows.Forms.Label();
            this.btnViewQuotes = new System.Windows.Forms.Button();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.cmbSelectQuoteType = new System.Windows.Forms.ComboBox();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.txtEnquiryNumber = new System.Windows.Forms.TextBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.pnAddProduct.SuspendLayout();
            this.pnOptionalItems.SuspendLayout();
            this.pnQuoteMaster.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgQuoteBOM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOptionalItems)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgWriteUP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgOIWriteUP)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.pnInstallCommision.SuspendLayout();
            this.pnAppointment.SuspendLayout();
            this.pnGst.SuspendLayout();
            this.pnIncoterm.SuspendLayout();
            this.pnQuotationNumber.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblcustomer
            // 
            this.lblcustomer.AutoSize = true;
            this.lblcustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcustomer.ForeColor = System.Drawing.Color.Black;
            this.lblcustomer.Location = new System.Drawing.Point(47, 181);
            this.lblcustomer.Name = "lblcustomer";
            this.lblcustomer.Size = new System.Drawing.Size(77, 18);
            this.lblcustomer.TabIndex = 81;
            this.lblcustomer.Text = "Currency* :";
            // 
            // cmbEnquireCurrency
            // 
            this.cmbEnquireCurrency.DropDownHeight = 60;
            this.cmbEnquireCurrency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEnquireCurrency.DropDownWidth = 150;
            this.cmbEnquireCurrency.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbEnquireCurrency.FormattingEnabled = true;
            this.cmbEnquireCurrency.IntegralHeight = false;
            this.cmbEnquireCurrency.ItemHeight = 18;
            this.cmbEnquireCurrency.Items.AddRange(new object[] {
            "INR",
            "USD"});
            this.cmbEnquireCurrency.Location = new System.Drawing.Point(130, 178);
            this.cmbEnquireCurrency.Name = "cmbEnquireCurrency";
            this.cmbEnquireCurrency.Size = new System.Drawing.Size(222, 26);
            this.cmbEnquireCurrency.TabIndex = 2;
            this.cmbEnquireCurrency.SelectedIndexChanged += new System.EventHandler(this.cmbEnquire_SelectedIndexChanged);
            // 
            // cmbCustomer
            // 
            this.cmbCustomer.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbCustomer.DropDownHeight = 90;
            this.cmbCustomer.DropDownWidth = 150;
            this.cmbCustomer.Enabled = false;
            this.cmbCustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCustomer.FormattingEnabled = true;
            this.cmbCustomer.IntegralHeight = false;
            this.cmbCustomer.Location = new System.Drawing.Point(917, 39);
            this.cmbCustomer.Name = "cmbCustomer";
            this.cmbCustomer.Size = new System.Drawing.Size(343, 26);
            this.cmbCustomer.TabIndex = 15;
            this.cmbCustomer.SelectedIndexChanged += new System.EventHandler(this.cmbCustomer_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(796, 227);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 18);
            this.label4.TabIndex = 84;
            this.label4.Text = "Customer Type* :";
            // 
            // cmbQuotationfor
            // 
            this.cmbQuotationfor.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbQuotationfor.DropDownHeight = 60;
            this.cmbQuotationfor.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbQuotationfor.FormattingEnabled = true;
            this.cmbQuotationfor.IntegralHeight = false;
            this.cmbQuotationfor.Items.AddRange(new object[] {
            "UTM",
            "STS",
            "DTS",
            "LFS",
            "TGT",
            "ShakeTable",
            "CustomRigs"});
            this.cmbQuotationfor.Location = new System.Drawing.Point(130, 316);
            this.cmbQuotationfor.Name = "cmbQuotationfor";
            this.cmbQuotationfor.Size = new System.Drawing.Size(222, 26);
            this.cmbQuotationfor.TabIndex = 5;
            this.cmbQuotationfor.SelectedIndexChanged += new System.EventHandler(this.cmbQuotatiofor_SelectedIndexChanged);
            // 
            // cmbRegion
            // 
            this.cmbRegion.DropDownHeight = 60;
            this.cmbRegion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRegion.DropDownWidth = 150;
            this.cmbRegion.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbRegion.FormattingEnabled = true;
            this.cmbRegion.IntegralHeight = false;
            this.cmbRegion.ItemHeight = 18;
            this.cmbRegion.Location = new System.Drawing.Point(130, 224);
            this.cmbRegion.Name = "cmbRegion";
            this.cmbRegion.Size = new System.Drawing.Size(222, 26);
            this.cmbRegion.Sorted = true;
            this.cmbRegion.TabIndex = 3;
            // 
            // lblregion
            // 
            this.lblregion.AutoSize = true;
            this.lblregion.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblregion.ForeColor = System.Drawing.Color.Black;
            this.lblregion.Location = new System.Drawing.Point(59, 227);
            this.lblregion.Name = "lblregion";
            this.lblregion.Size = new System.Drawing.Size(65, 18);
            this.lblregion.TabIndex = 90;
            this.lblregion.Text = "Region* :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(826, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 18);
            this.label2.TabIndex = 92;
            this.label2.Text = "Customer * :";
            // 
            // txtCustomertype
            // 
            this.txtCustomertype.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtCustomertype.Location = new System.Drawing.Point(917, 224);
            this.txtCustomertype.Name = "txtCustomertype";
            this.txtCustomertype.Size = new System.Drawing.Size(345, 26);
            this.txtCustomertype.TabIndex = 17;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(846, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 18);
            this.label3.TabIndex = 94;
            this.label3.Text = "Address :";
            // 
            // txtAddress
            // 
            this.txtAddress.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtAddress.Location = new System.Drawing.Point(917, 81);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(343, 123);
            this.txtAddress.TabIndex = 16;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(798, 269);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 18);
            this.label5.TabIndex = 96;
            this.label5.Text = "Contact Person* :";
            // 
            // txtContactPerson1
            // 
            this.txtContactPerson1.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtContactPerson1.Location = new System.Drawing.Point(917, 266);
            this.txtContactPerson1.Name = "txtContactPerson1";
            this.txtContactPerson1.Size = new System.Drawing.Size(343, 26);
            this.txtContactPerson1.TabIndex = 18;
            // 
            // txtContactNumber1
            // 
            this.txtContactNumber1.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtContactNumber1.Location = new System.Drawing.Point(917, 308);
            this.txtContactNumber1.Name = "txtContactNumber1";
            this.txtContactNumber1.Size = new System.Drawing.Size(343, 26);
            this.txtContactNumber1.TabIndex = 19;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(795, 311);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(116, 18);
            this.label6.TabIndex = 98;
            this.label6.Text = "Contact Number :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(5, 273);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(120, 18);
            this.label9.TabIndex = 102;
            this.label9.Text = "Lead Genarated* :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(8, 43);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(117, 18);
            this.label10.TabIndex = 104;
            this.label10.Text = "Date of Enquiry* :";
            // 
            // dtpEnquireDate
            // 
            this.dtpEnquireDate.CustomFormat = "";
            this.dtpEnquireDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpEnquireDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpEnquireDate.Location = new System.Drawing.Point(130, 37);
            this.dtpEnquireDate.Name = "dtpEnquireDate";
            this.dtpEnquireDate.Size = new System.Drawing.Size(222, 26);
            this.dtpEnquireDate.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(16, 322);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(109, 18);
            this.label11.TabIndex = 106;
            this.label11.Text = "Quote System* :";
            // 
            // cmbModel
            // 
            this.cmbModel.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbModel.DropDownHeight = 60;
            this.cmbModel.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbModel.FormattingEnabled = true;
            this.cmbModel.IntegralHeight = false;
            this.cmbModel.Location = new System.Drawing.Point(130, 362);
            this.cmbModel.Name = "cmbModel";
            this.cmbModel.Size = new System.Drawing.Size(222, 26);
            this.cmbModel.TabIndex = 6;
            this.cmbModel.SelectedIndexChanged += new System.EventHandler(this.cmbQuotationType_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(62, 365);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 18);
            this.label7.TabIndex = 108;
            this.label7.Text = "Model* :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(51, 411);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(74, 18);
            this.label12.TabIndex = 109;
            this.label12.Text = "Capacity* :";
            // 
            // cmbCapacity
            // 
            this.cmbCapacity.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbCapacity.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCapacity.FormattingEnabled = true;
            this.cmbCapacity.Location = new System.Drawing.Point(130, 408);
            this.cmbCapacity.Name = "cmbCapacity";
            this.cmbCapacity.Size = new System.Drawing.Size(222, 26);
            this.cmbCapacity.TabIndex = 7;
            this.cmbCapacity.SelectedIndexChanged += new System.EventHandler(this.cmbCapacity_SelectedIndexChanged);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Enabled = false;
            this.tabControl1.ItemSize = new System.Drawing.Size(30, 1);
            this.tabControl1.Location = new System.Drawing.Point(7, 55);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1294, 639);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.Click += new System.EventHandler(this.tabControl1_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Silver;
            this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPage1.Controls.Add(this.txtOldModelNumber);
            this.tabPage1.Controls.Add(this.label84);
            this.tabPage1.Controls.Add(this.lblQuoteBy);
            this.tabPage1.Controls.Add(this.lblQuotebyin);
            this.tabPage1.Controls.Add(this.cmbQuoteType);
            this.tabPage1.Controls.Add(this.label80);
            this.tabPage1.Controls.Add(this.cmblevelofcustomization);
            this.tabPage1.Controls.Add(this.label24);
            this.tabPage1.Controls.Add(this.lblPrepareBy);
            this.tabPage1.Controls.Add(this.label79);
            this.tabPage1.Controls.Add(this.cmbeightytwenty);
            this.tabPage1.Controls.Add(this.label78);
            this.tabPage1.Controls.Add(this.cmbQuoteCompany);
            this.tabPage1.Controls.Add(this.label67);
            this.tabPage1.Controls.Add(this.cmbIncoTerms);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.chkintrastate);
            this.tabPage1.Controls.Add(this.txtCusCode);
            this.tabPage1.Controls.Add(this.txtModelNumber);
            this.tabPage1.Controls.Add(this.label47);
            this.tabPage1.Controls.Add(this.txtEmailID1);
            this.tabPage1.Controls.Add(this.label40);
            this.tabPage1.Controls.Add(this.label38);
            this.tabPage1.Controls.Add(this.txtQuoteName);
            this.tabPage1.Controls.Add(this.cmbLeadGenarated);
            this.tabPage1.Controls.Add(this.txtLeadTime);
            this.tabPage1.Controls.Add(this.label30);
            this.tabPage1.Controls.Add(this.txtQuoteWarranty);
            this.tabPage1.Controls.Add(this.label27);
            this.tabPage1.Controls.Add(this.txtQuoteValidity);
            this.tabPage1.Controls.Add(this.lblDeliveryTerms);
            this.tabPage1.Controls.Add(this.txtDepartment1);
            this.tabPage1.Controls.Add(this.label34);
            this.tabPage1.Controls.Add(this.label28);
            this.tabPage1.Controls.Add(this.txtTenderNo);
            this.tabPage1.Controls.Add(this.btnStartQuote);
            this.tabPage1.Controls.Add(this.cmbEnquireCurrency);
            this.tabPage1.Controls.Add(this.cmbCapacity);
            this.tabPage1.Controls.Add(this.lblcustomer);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.cmbQuotationfor);
            this.tabPage1.Controls.Add(this.dtpEnquireDate);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.cmbModel);
            this.tabPage1.Controls.Add(this.lblregion);
            this.tabPage1.Controls.Add(this.txtContactNumber1);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.cmbRegion);
            this.tabPage1.Controls.Add(this.txtContactPerson1);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.txtAddress);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.cmbCustomer);
            this.tabPage1.Controls.Add(this.txtCustomertype);
            this.tabPage1.Controls.Add(this.dtpQuoteDate);
            this.tabPage1.ForeColor = System.Drawing.Color.Black;
            this.tabPage1.Location = new System.Drawing.Point(4, 5);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1286, 630);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // txtOldModelNumber
            // 
            this.txtOldModelNumber.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtOldModelNumber.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtOldModelNumber.Location = new System.Drawing.Point(526, 208);
            this.txtOldModelNumber.Name = "txtOldModelNumber";
            this.txtOldModelNumber.ReadOnly = true;
            this.txtOldModelNumber.Size = new System.Drawing.Size(250, 26);
            this.txtOldModelNumber.TabIndex = 228;
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label84.ForeColor = System.Drawing.Color.Black;
            this.label84.Location = new System.Drawing.Point(382, 211);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(135, 18);
            this.label84.TabIndex = 229;
            this.label84.Text = "Old Model Number :";
            // 
            // lblQuoteBy
            // 
            this.lblQuoteBy.AutoSize = true;
            this.lblQuoteBy.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuoteBy.ForeColor = System.Drawing.Color.Red;
            this.lblQuoteBy.Location = new System.Drawing.Point(126, 457);
            this.lblQuoteBy.Name = "lblQuoteBy";
            this.lblQuoteBy.Size = new System.Drawing.Size(0, 19);
            this.lblQuoteBy.TabIndex = 227;
            // 
            // lblQuotebyin
            // 
            this.lblQuotebyin.AutoSize = true;
            this.lblQuotebyin.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuotebyin.ForeColor = System.Drawing.Color.Black;
            this.lblQuotebyin.Location = new System.Drawing.Point(43, 457);
            this.lblQuotebyin.Name = "lblQuotebyin";
            this.lblQuotebyin.Size = new System.Drawing.Size(81, 19);
            this.lblQuotebyin.TabIndex = 226;
            this.lblQuotebyin.Text = "Quote By :";
            // 
            // cmbQuoteType
            // 
            this.cmbQuoteType.DropDownHeight = 60;
            this.cmbQuoteType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbQuoteType.DropDownWidth = 150;
            this.cmbQuoteType.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbQuoteType.FormattingEnabled = true;
            this.cmbQuoteType.IntegralHeight = false;
            this.cmbQuoteType.ItemHeight = 18;
            this.cmbQuoteType.Items.AddRange(new object[] {
            "Sales",
            "Service",
            "OTC"});
            this.cmbQuoteType.Location = new System.Drawing.Point(130, 132);
            this.cmbQuoteType.Name = "cmbQuoteType";
            this.cmbQuoteType.Size = new System.Drawing.Size(222, 26);
            this.cmbQuoteType.TabIndex = 212;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label80.ForeColor = System.Drawing.Color.Black;
            this.label80.Location = new System.Drawing.Point(31, 135);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(94, 18);
            this.label80.TabIndex = 213;
            this.label80.Text = "Quote Type* :";
            // 
            // cmblevelofcustomization
            // 
            this.cmblevelofcustomization.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmblevelofcustomization.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmblevelofcustomization.DropDownHeight = 70;
            this.cmblevelofcustomization.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmblevelofcustomization.DropDownWidth = 140;
            this.cmblevelofcustomization.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmblevelofcustomization.FormattingEnabled = true;
            this.cmblevelofcustomization.IntegralHeight = false;
            this.cmblevelofcustomization.Items.AddRange(new object[] {
            "1) No design involvement",
            "2) Basic Accessories Modification",
            "3) Advanced Accessories Modification",
            "4) Unique to customer (no repeat order)"});
            this.cmblevelofcustomization.Location = new System.Drawing.Point(919, 450);
            this.cmblevelofcustomization.Name = "cmblevelofcustomization";
            this.cmblevelofcustomization.Size = new System.Drawing.Size(343, 26);
            this.cmblevelofcustomization.TabIndex = 210;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Black;
            this.label24.Location = new System.Drawing.Point(7, 586);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(93, 23);
            this.label24.TabIndex = 205;
            this.label24.Text = "Welcome :";
            // 
            // lblPrepareBy
            // 
            this.lblPrepareBy.AutoSize = true;
            this.lblPrepareBy.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrepareBy.ForeColor = System.Drawing.Color.Black;
            this.lblPrepareBy.Location = new System.Drawing.Point(168, 435);
            this.lblPrepareBy.Name = "lblPrepareBy";
            this.lblPrepareBy.Size = new System.Drawing.Size(18, 23);
            this.lblPrepareBy.TabIndex = 204;
            this.lblPrepareBy.Text = "c";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label79.ForeColor = System.Drawing.Color.Black;
            this.label79.Location = new System.Drawing.Point(750, 453);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(163, 18);
            this.label79.TabIndex = 211;
            this.label79.Text = "Level of Customization *:";
            // 
            // cmbeightytwenty
            // 
            this.cmbeightytwenty.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbeightytwenty.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbeightytwenty.DropDownHeight = 70;
            this.cmbeightytwenty.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbeightytwenty.DropDownWidth = 140;
            this.cmbeightytwenty.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbeightytwenty.FormattingEnabled = true;
            this.cmbeightytwenty.IntegralHeight = false;
            this.cmbeightytwenty.Items.AddRange(new object[] {
            "80",
            "20"});
            this.cmbeightytwenty.Location = new System.Drawing.Point(526, 450);
            this.cmbeightytwenty.Name = "cmbeightytwenty";
            this.cmbeightytwenty.Size = new System.Drawing.Size(187, 26);
            this.cmbeightytwenty.TabIndex = 208;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label78.ForeColor = System.Drawing.Color.Black;
            this.label78.Location = new System.Drawing.Point(465, 453);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(56, 18);
            this.label78.TabIndex = 209;
            this.label78.Text = "80/20 *:";
            // 
            // cmbQuoteCompany
            // 
            this.cmbQuoteCompany.DropDownHeight = 60;
            this.cmbQuoteCompany.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbQuoteCompany.DropDownWidth = 150;
            this.cmbQuoteCompany.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbQuoteCompany.FormattingEnabled = true;
            this.cmbQuoteCompany.IntegralHeight = false;
            this.cmbQuoteCompany.ItemHeight = 18;
            this.cmbQuoteCompany.Items.AddRange(new object[] {
            "BiSS-ITW",
            "INSTRON"});
            this.cmbQuoteCompany.Location = new System.Drawing.Point(130, 81);
            this.cmbQuoteCompany.Name = "cmbQuoteCompany";
            this.cmbQuoteCompany.Size = new System.Drawing.Size(222, 26);
            this.cmbQuoteCompany.TabIndex = 205;
            this.cmbQuoteCompany.SelectedIndexChanged += new System.EventHandler(this.cmbQuoteCompany_SelectedIndexChanged);
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.ForeColor = System.Drawing.Color.Black;
            this.label67.Location = new System.Drawing.Point(40, 84);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(84, 18);
            this.label67.TabIndex = 206;
            this.label67.Text = "Quote For* :";
            // 
            // cmbIncoTerms
            // 
            this.cmbIncoTerms.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbIncoTerms.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbIncoTerms.DropDownHeight = 70;
            this.cmbIncoTerms.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbIncoTerms.DropDownWidth = 140;
            this.cmbIncoTerms.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbIncoTerms.FormattingEnabled = true;
            this.cmbIncoTerms.IntegralHeight = false;
            this.cmbIncoTerms.Items.AddRange(new object[] {
            "Ex Works (EXW)",
            "Free On Board (FOB)",
            "Free Carrier (FCA/FOR)",
            "Carriage Paid To (CPT)",
            "Carriage and Insurance Paid To (CIP)",
            "Cost and Freight (CFR)",
            "Cost Insurance and Freight (CIF)",
            "Delivered at place (DAP)",
            "Delivered at Place Unloaded (DPU)",
            "Delivered Duty Paid (DDP)"});
            this.cmbIncoTerms.Location = new System.Drawing.Point(526, 383);
            this.cmbIncoTerms.Name = "cmbIncoTerms";
            this.cmbIncoTerms.Size = new System.Drawing.Size(250, 26);
            this.cmbIncoTerms.TabIndex = 14;
            this.cmbIncoTerms.SelectedIndexChanged += new System.EventHandler(this.cmbIncoTerms_SelectedIndexChanged_1);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(427, 388);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(94, 18);
            this.label17.TabIndex = 204;
            this.label17.Text = "INCO Terms *:";
            // 
            // chkintrastate
            // 
            this.chkintrastate.AutoSize = true;
            this.chkintrastate.Checked = true;
            this.chkintrastate.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkintrastate.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkintrastate.ForeColor = System.Drawing.Color.Black;
            this.chkintrastate.Location = new System.Drawing.Point(526, 415);
            this.chkintrastate.Name = "chkintrastate";
            this.chkintrastate.Size = new System.Drawing.Size(115, 30);
            this.chkintrastate.TabIndex = 22;
            this.chkintrastate.Text = "Intrastate";
            this.chkintrastate.UseVisualStyleBackColor = true;
            this.chkintrastate.CheckedChanged += new System.EventHandler(this.chkintrastate_CheckedChanged);
            // 
            // txtCusCode
            // 
            this.txtCusCode.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtCusCode.Location = new System.Drawing.Point(1263, 37);
            this.txtCusCode.Name = "txtCusCode";
            this.txtCusCode.Size = new System.Drawing.Size(20, 26);
            this.txtCusCode.TabIndex = 199;
            this.txtCusCode.Visible = false;
            // 
            // txtModelNumber
            // 
            this.txtModelNumber.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtModelNumber.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtModelNumber.Location = new System.Drawing.Point(526, 168);
            this.txtModelNumber.Name = "txtModelNumber";
            this.txtModelNumber.Size = new System.Drawing.Size(250, 26);
            this.txtModelNumber.TabIndex = 10;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label47.ForeColor = System.Drawing.Color.Black;
            this.label47.Location = new System.Drawing.Point(400, 171);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(117, 18);
            this.label47.TabIndex = 197;
            this.label47.Text = "Model Number* :";
            // 
            // txtEmailID1
            // 
            this.txtEmailID1.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtEmailID1.Location = new System.Drawing.Point(917, 392);
            this.txtEmailID1.Name = "txtEmailID1";
            this.txtEmailID1.Size = new System.Drawing.Size(343, 26);
            this.txtEmailID1.TabIndex = 21;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label40.ForeColor = System.Drawing.Color.Black;
            this.label40.Location = new System.Drawing.Point(839, 398);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(72, 18);
            this.label40.TabIndex = 195;
            this.label40.Text = "Email ID* :";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label38.ForeColor = System.Drawing.Color.Black;
            this.label38.Location = new System.Drawing.Point(416, 43);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(101, 18);
            this.label38.TabIndex = 193;
            this.label38.Text = "Quote Name *:";
            this.label38.Click += new System.EventHandler(this.label38_Click);
            // 
            // txtQuoteName
            // 
            this.txtQuoteName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQuoteName.Location = new System.Drawing.Point(526, 39);
            this.txtQuoteName.Multiline = true;
            this.txtQuoteName.Name = "txtQuoteName";
            this.txtQuoteName.Size = new System.Drawing.Size(250, 50);
            this.txtQuoteName.TabIndex = 8;
            this.txtQuoteName.TextChanged += new System.EventHandler(this.textBox11_TextChanged);
            // 
            // cmbLeadGenarated
            // 
            this.cmbLeadGenarated.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbLeadGenarated.DropDownHeight = 60;
            this.cmbLeadGenarated.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbLeadGenarated.FormattingEnabled = true;
            this.cmbLeadGenarated.IntegralHeight = false;
            this.cmbLeadGenarated.Items.AddRange(new object[] {
            "Telephone",
            "E-mail",
            "Tender",
            "Customer Reference",
            "Dealer",
            "Distributor",
            "Direct",
            "Advertisement",
            "linkedin"});
            this.cmbLeadGenarated.Location = new System.Drawing.Point(130, 270);
            this.cmbLeadGenarated.Name = "cmbLeadGenarated";
            this.cmbLeadGenarated.Size = new System.Drawing.Size(222, 26);
            this.cmbLeadGenarated.TabIndex = 4;
            // 
            // txtLeadTime
            // 
            this.txtLeadTime.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtLeadTime.Location = new System.Drawing.Point(526, 339);
            this.txtLeadTime.Name = "txtLeadTime";
            this.txtLeadTime.Size = new System.Drawing.Size(250, 26);
            this.txtLeadTime.TabIndex = 13;
            this.txtLeadTime.Text = "8-10";
            this.txtLeadTime.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLeadTime_KeyPress);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label30.ForeColor = System.Drawing.Color.Black;
            this.label30.Location = new System.Drawing.Point(390, 296);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(130, 18);
            this.label30.TabIndex = 189;
            this.label30.Text = "Warranty (Months):";
            // 
            // txtQuoteWarranty
            // 
            this.txtQuoteWarranty.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtQuoteWarranty.Location = new System.Drawing.Point(526, 293);
            this.txtQuoteWarranty.Name = "txtQuoteWarranty";
            this.txtQuoteWarranty.Size = new System.Drawing.Size(250, 26);
            this.txtQuoteWarranty.TabIndex = 12;
            this.txtQuoteWarranty.Text = "12";
            this.txtQuoteWarranty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQuoteWarranty_KeyPress);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label27.ForeColor = System.Drawing.Color.Black;
            this.label27.Location = new System.Drawing.Point(378, 250);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(143, 18);
            this.label27.TabIndex = 187;
            this.label27.Text = "Quote Validity (Days):";
            // 
            // txtQuoteValidity
            // 
            this.txtQuoteValidity.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtQuoteValidity.Location = new System.Drawing.Point(526, 247);
            this.txtQuoteValidity.Name = "txtQuoteValidity";
            this.txtQuoteValidity.Size = new System.Drawing.Size(250, 26);
            this.txtQuoteValidity.TabIndex = 11;
            this.txtQuoteValidity.Text = "45";
            this.txtQuoteValidity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQuoteValidity_KeyPress);
            // 
            // lblDeliveryTerms
            // 
            this.lblDeliveryTerms.AutoSize = true;
            this.lblDeliveryTerms.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.lblDeliveryTerms.ForeColor = System.Drawing.Color.Black;
            this.lblDeliveryTerms.Location = new System.Drawing.Point(391, 342);
            this.lblDeliveryTerms.Name = "lblDeliveryTerms";
            this.lblDeliveryTerms.Size = new System.Drawing.Size(130, 18);
            this.lblDeliveryTerms.TabIndex = 184;
            this.lblDeliveryTerms.Text = "Lead Time (Weeks):";
            // 
            // txtDepartment1
            // 
            this.txtDepartment1.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtDepartment1.Location = new System.Drawing.Point(917, 350);
            this.txtDepartment1.Name = "txtDepartment1";
            this.txtDepartment1.Size = new System.Drawing.Size(343, 26);
            this.txtDepartment1.TabIndex = 20;
            this.txtDepartment1.Text = "NIL";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label34.ForeColor = System.Drawing.Color.Black;
            this.label34.Location = new System.Drawing.Point(821, 353);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(90, 18);
            this.label34.TabIndex = 127;
            this.label34.Text = "Department :";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label28.ForeColor = System.Drawing.Color.Black;
            this.label28.Location = new System.Drawing.Point(438, 105);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(79, 18);
            this.label28.TabIndex = 117;
            this.label28.Text = "Tender No :";
            // 
            // txtTenderNo
            // 
            this.txtTenderNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenderNo.Location = new System.Drawing.Point(526, 103);
            this.txtTenderNo.Multiline = true;
            this.txtTenderNo.Name = "txtTenderNo";
            this.txtTenderNo.Size = new System.Drawing.Size(250, 50);
            this.txtTenderNo.TabIndex = 9;
            // 
            // btnStartQuote
            // 
            this.btnStartQuote.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnStartQuote.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnStartQuote.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStartQuote.Location = new System.Drawing.Point(1127, 564);
            this.btnStartQuote.Name = "btnStartQuote";
            this.btnStartQuote.Size = new System.Drawing.Size(154, 45);
            this.btnStartQuote.TabIndex = 23;
            this.btnStartQuote.Text = "Start Quote";
            this.btnStartQuote.UseVisualStyleBackColor = false;
            this.btnStartQuote.Click += new System.EventHandler(this.btnStartQuote_Click);
            // 
            // dtpQuoteDate
            // 
            this.dtpQuoteDate.CustomFormat = "";
            this.dtpQuoteDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpQuoteDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpQuoteDate.Location = new System.Drawing.Point(533, 43);
            this.dtpQuoteDate.Name = "dtpQuoteDate";
            this.dtpQuoteDate.Size = new System.Drawing.Size(52, 26);
            this.dtpQuoteDate.TabIndex = 207;
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.Silver;
            this.tabPage5.Controls.Add(this.txtCompetation);
            this.tabPage5.Controls.Add(this.cmbprimarymtrldetail);
            this.tabPage5.Controls.Add(this.btnBack);
            this.tabPage5.Controls.Add(this.btnGotoAddProducts);
            this.tabPage5.Controls.Add(this.txtLostReason);
            this.tabPage5.Controls.Add(this.txtWonReason);
            this.tabPage5.Controls.Add(this.txtSpecifyOthers);
            this.tabPage5.Controls.Add(this.txtExpectedValueUSD);
            this.tabPage5.Controls.Add(this.dtpExpectedOrderPlacementdate);
            this.tabPage5.Controls.Add(this.cmbWinLose);
            this.tabPage5.Controls.Add(this.cmbCompetetion);
            this.tabPage5.Controls.Add(this.cmbProbabality);
            this.tabPage5.Controls.Add(this.cmbtypeofcustomer);
            this.tabPage5.Controls.Add(this.cmbStatus);
            this.tabPage5.Controls.Add(this.cmbStage);
            this.tabPage5.Controls.Add(this.cmbTestEnvironment);
            this.tabPage5.Controls.Add(this.cmbApplication);
            this.tabPage5.Controls.Add(this.cmbprimarymaterial);
            this.tabPage5.Controls.Add(this.cmbprimaryind);
            this.tabPage5.Controls.Add(this.label74);
            this.tabPage5.Controls.Add(this.label75);
            this.tabPage5.Controls.Add(this.label76);
            this.tabPage5.Controls.Add(this.label77);
            this.tabPage5.Controls.Add(this.label68);
            this.tabPage5.Controls.Add(this.label69);
            this.tabPage5.Controls.Add(this.label70);
            this.tabPage5.Controls.Add(this.label71);
            this.tabPage5.Controls.Add(this.label72);
            this.tabPage5.Controls.Add(this.label73);
            this.tabPage5.Controls.Add(this.label54);
            this.tabPage5.Controls.Add(this.label65);
            this.tabPage5.Controls.Add(this.label33);
            this.tabPage5.Controls.Add(this.label53);
            this.tabPage5.Controls.Add(this.label31);
            this.tabPage5.Controls.Add(this.label32);
            this.tabPage5.Controls.Add(this.cmbLabtype);
            this.tabPage5.Controls.Add(this.label1);
            this.tabPage5.Controls.Add(this.cmbBusinessector);
            this.tabPage5.Controls.Add(this.label29);
            this.tabPage5.Location = new System.Drawing.Point(4, 5);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1286, 630);
            this.tabPage5.TabIndex = 4;
            // 
            // txtCompetation
            // 
            this.txtCompetation.Enabled = false;
            this.txtCompetation.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtCompetation.Location = new System.Drawing.Point(887, 188);
            this.txtCompetation.Multiline = true;
            this.txtCompetation.Name = "txtCompetation";
            this.txtCompetation.Size = new System.Drawing.Size(274, 56);
            this.txtCompetation.TabIndex = 251;
            // 
            // cmbprimarymtrldetail
            // 
            this.cmbprimarymtrldetail.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.cmbprimarymtrldetail.Location = new System.Drawing.Point(182, 207);
            this.cmbprimarymtrldetail.Multiline = true;
            this.cmbprimarymtrldetail.Name = "cmbprimarymtrldetail";
            this.cmbprimarymtrldetail.Size = new System.Drawing.Size(354, 53);
            this.cmbprimarymtrldetail.TabIndex = 245;
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnBack.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold);
            this.btnBack.Location = new System.Drawing.Point(1, 569);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(124, 45);
            this.btnBack.TabIndex = 244;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnGotoAddProducts
            // 
            this.btnGotoAddProducts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnGotoAddProducts.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnGotoAddProducts.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGotoAddProducts.Location = new System.Drawing.Point(1088, 569);
            this.btnGotoAddProducts.Name = "btnGotoAddProducts";
            this.btnGotoAddProducts.Size = new System.Drawing.Size(195, 45);
            this.btnGotoAddProducts.TabIndex = 243;
            this.btnGotoAddProducts.Text = "Go to Add Products";
            this.btnGotoAddProducts.UseVisualStyleBackColor = false;
            this.btnGotoAddProducts.Click += new System.EventHandler(this.btnGotoAddProducts_Click);
            // 
            // txtLostReason
            // 
            this.txtLostReason.Enabled = false;
            this.txtLostReason.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLostReason.Location = new System.Drawing.Point(887, 451);
            this.txtLostReason.Multiline = true;
            this.txtLostReason.Name = "txtLostReason";
            this.txtLostReason.Size = new System.Drawing.Size(274, 50);
            this.txtLostReason.TabIndex = 242;
            // 
            // txtWonReason
            // 
            this.txtWonReason.Enabled = false;
            this.txtWonReason.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWonReason.Location = new System.Drawing.Point(887, 369);
            this.txtWonReason.Multiline = true;
            this.txtWonReason.Name = "txtWonReason";
            this.txtWonReason.Size = new System.Drawing.Size(274, 50);
            this.txtWonReason.TabIndex = 241;
            // 
            // txtSpecifyOthers
            // 
            this.txtSpecifyOthers.Enabled = false;
            this.txtSpecifyOthers.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSpecifyOthers.Location = new System.Drawing.Point(887, 250);
            this.txtSpecifyOthers.Multiline = true;
            this.txtSpecifyOthers.Name = "txtSpecifyOthers";
            this.txtSpecifyOthers.Size = new System.Drawing.Size(274, 50);
            this.txtSpecifyOthers.TabIndex = 240;
            // 
            // txtExpectedValueUSD
            // 
            this.txtExpectedValueUSD.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtExpectedValueUSD.Location = new System.Drawing.Point(887, 18);
            this.txtExpectedValueUSD.Name = "txtExpectedValueUSD";
            this.txtExpectedValueUSD.Size = new System.Drawing.Size(274, 26);
            this.txtExpectedValueUSD.TabIndex = 239;
            this.txtExpectedValueUSD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtExpectedValueUSD_KeyPress);
            // 
            // dtpExpectedOrderPlacementdate
            // 
            this.dtpExpectedOrderPlacementdate.CustomFormat = "";
            this.dtpExpectedOrderPlacementdate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpExpectedOrderPlacementdate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpExpectedOrderPlacementdate.Location = new System.Drawing.Point(887, 64);
            this.dtpExpectedOrderPlacementdate.Name = "dtpExpectedOrderPlacementdate";
            this.dtpExpectedOrderPlacementdate.Size = new System.Drawing.Size(274, 26);
            this.dtpExpectedOrderPlacementdate.TabIndex = 238;
            this.dtpExpectedOrderPlacementdate.ValueChanged += new System.EventHandler(this.dtpExpectedOrderPlacementdate_ValueChanged);
            // 
            // cmbWinLose
            // 
            this.cmbWinLose.DropDownHeight = 60;
            this.cmbWinLose.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbWinLose.DropDownWidth = 150;
            this.cmbWinLose.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbWinLose.FormattingEnabled = true;
            this.cmbWinLose.IntegralHeight = false;
            this.cmbWinLose.ItemHeight = 18;
            this.cmbWinLose.Items.AddRange(new object[] {
            "Won",
            "Lost"});
            this.cmbWinLose.Location = new System.Drawing.Point(887, 321);
            this.cmbWinLose.Name = "cmbWinLose";
            this.cmbWinLose.Size = new System.Drawing.Size(274, 26);
            this.cmbWinLose.TabIndex = 237;
            this.cmbWinLose.SelectedIndexChanged += new System.EventHandler(this.cmbWinLose_SelectedIndexChanged);
            // 
            // cmbCompetetion
            // 
            this.cmbCompetetion.DropDownHeight = 60;
            this.cmbCompetetion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCompetetion.DropDownWidth = 150;
            this.cmbCompetetion.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCompetetion.FormattingEnabled = true;
            this.cmbCompetetion.IntegralHeight = false;
            this.cmbCompetetion.ItemHeight = 18;
            this.cmbCompetetion.Items.AddRange(new object[] {
            "MTS",
            "W+B",
            "TO",
            "Heico",
            "Galdabini",
            "Shimadzu",
            "Zwick",
            "Local",
            "Others"});
            this.cmbCompetetion.Location = new System.Drawing.Point(887, 156);
            this.cmbCompetetion.Name = "cmbCompetetion";
            this.cmbCompetetion.Size = new System.Drawing.Size(274, 26);
            this.cmbCompetetion.TabIndex = 236;
            this.cmbCompetetion.SelectedIndexChanged += new System.EventHandler(this.cmbCompetetion_SelectedIndexChanged);
            // 
            // cmbProbabality
            // 
            this.cmbProbabality.DropDownHeight = 60;
            this.cmbProbabality.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProbabality.DropDownWidth = 150;
            this.cmbProbabality.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProbabality.FormattingEnabled = true;
            this.cmbProbabality.IntegralHeight = false;
            this.cmbProbabality.ItemHeight = 18;
            this.cmbProbabality.Items.AddRange(new object[] {
            "Opinion of order to us",
            "Opinion of order to competition",
            "Evidence of order to competition",
            "Evidence of order to us"});
            this.cmbProbabality.Location = new System.Drawing.Point(887, 109);
            this.cmbProbabality.Name = "cmbProbabality";
            this.cmbProbabality.Size = new System.Drawing.Size(274, 26);
            this.cmbProbabality.TabIndex = 235;
            // 
            // cmbtypeofcustomer
            // 
            this.cmbtypeofcustomer.DropDownHeight = 60;
            this.cmbtypeofcustomer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbtypeofcustomer.DropDownWidth = 150;
            this.cmbtypeofcustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbtypeofcustomer.FormattingEnabled = true;
            this.cmbtypeofcustomer.IntegralHeight = false;
            this.cmbtypeofcustomer.ItemHeight = 18;
            this.cmbtypeofcustomer.Items.AddRange(new object[] {
            "Lab with our system",
            "Exclusively competitor system",
            "New to testing"});
            this.cmbtypeofcustomer.Location = new System.Drawing.Point(182, 470);
            this.cmbtypeofcustomer.Name = "cmbtypeofcustomer";
            this.cmbtypeofcustomer.Size = new System.Drawing.Size(354, 26);
            this.cmbtypeofcustomer.TabIndex = 234;
            // 
            // cmbStatus
            // 
            this.cmbStatus.DropDownHeight = 60;
            this.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStatus.DropDownWidth = 150;
            this.cmbStatus.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.IntegralHeight = false;
            this.cmbStatus.ItemHeight = 18;
            this.cmbStatus.Items.AddRange(new object[] {
            "Abandoned",
            "Open"});
            this.cmbStatus.Location = new System.Drawing.Point(182, 374);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(354, 26);
            this.cmbStatus.TabIndex = 233;
            // 
            // cmbStage
            // 
            this.cmbStage.DropDownHeight = 60;
            this.cmbStage.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStage.DropDownWidth = 150;
            this.cmbStage.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbStage.FormattingEnabled = true;
            this.cmbStage.IntegralHeight = false;
            this.cmbStage.ItemHeight = 18;
            this.cmbStage.Items.AddRange(new object[] {
            "Unqualified",
            "Qualified",
            "Budgeting",
            "Quoting",
            "Negotiating",
            "Order placed"});
            this.cmbStage.Location = new System.Drawing.Point(182, 420);
            this.cmbStage.Name = "cmbStage";
            this.cmbStage.Size = new System.Drawing.Size(354, 26);
            this.cmbStage.TabIndex = 232;
            // 
            // cmbTestEnvironment
            // 
            this.cmbTestEnvironment.DropDownHeight = 60;
            this.cmbTestEnvironment.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTestEnvironment.DropDownWidth = 150;
            this.cmbTestEnvironment.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTestEnvironment.FormattingEnabled = true;
            this.cmbTestEnvironment.IntegralHeight = false;
            this.cmbTestEnvironment.ItemHeight = 18;
            this.cmbTestEnvironment.Items.AddRange(new object[] {
            "Ambient",
            "Elevated temperature",
            "High/Low temperature",
            "LN2 purging/High temperature"});
            this.cmbTestEnvironment.Location = new System.Drawing.Point(182, 327);
            this.cmbTestEnvironment.Name = "cmbTestEnvironment";
            this.cmbTestEnvironment.Size = new System.Drawing.Size(354, 26);
            this.cmbTestEnvironment.TabIndex = 231;
            // 
            // cmbApplication
            // 
            this.cmbApplication.DropDownHeight = 60;
            this.cmbApplication.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbApplication.DropDownWidth = 150;
            this.cmbApplication.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbApplication.FormattingEnabled = true;
            this.cmbApplication.IntegralHeight = false;
            this.cmbApplication.ItemHeight = 18;
            this.cmbApplication.Location = new System.Drawing.Point(182, 279);
            this.cmbApplication.Name = "cmbApplication";
            this.cmbApplication.Size = new System.Drawing.Size(354, 26);
            this.cmbApplication.TabIndex = 230;
            this.cmbApplication.SelectedIndexChanged += new System.EventHandler(this.cmbApplication_SelectedIndexChanged);
            // 
            // cmbprimarymaterial
            // 
            this.cmbprimarymaterial.DropDownHeight = 60;
            this.cmbprimarymaterial.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbprimarymaterial.DropDownWidth = 150;
            this.cmbprimarymaterial.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbprimarymaterial.FormattingEnabled = true;
            this.cmbprimarymaterial.IntegralHeight = false;
            this.cmbprimarymaterial.ItemHeight = 18;
            this.cmbprimarymaterial.Location = new System.Drawing.Point(182, 161);
            this.cmbprimarymaterial.Name = "cmbprimarymaterial";
            this.cmbprimarymaterial.Size = new System.Drawing.Size(354, 26);
            this.cmbprimarymaterial.TabIndex = 229;
            this.cmbprimarymaterial.SelectedIndexChanged += new System.EventHandler(this.cmbprimarymaterial_SelectedIndexChanged);
            // 
            // cmbprimaryind
            // 
            this.cmbprimaryind.DropDownHeight = 60;
            this.cmbprimaryind.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbprimaryind.DropDownWidth = 150;
            this.cmbprimaryind.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbprimaryind.FormattingEnabled = true;
            this.cmbprimaryind.IntegralHeight = false;
            this.cmbprimaryind.ItemHeight = 18;
            this.cmbprimaryind.Location = new System.Drawing.Point(182, 114);
            this.cmbprimaryind.Name = "cmbprimaryind";
            this.cmbprimaryind.Size = new System.Drawing.Size(354, 26);
            this.cmbprimaryind.TabIndex = 227;
            this.cmbprimaryind.SelectedIndexChanged += new System.EventHandler(this.cmbprimaryind_SelectedIndexChanged);
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.ForeColor = System.Drawing.Color.Black;
            this.label74.Location = new System.Drawing.Point(786, 462);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(88, 18);
            this.label74.TabIndex = 226;
            this.label74.Text = "Lost Reason :";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.ForeColor = System.Drawing.Color.Black;
            this.label75.Location = new System.Drawing.Point(799, 324);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(75, 18);
            this.label75.TabIndex = 225;
            this.label75.Text = "Won/Lost :";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.ForeColor = System.Drawing.Color.Black;
            this.label76.Location = new System.Drawing.Point(782, 372);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(92, 18);
            this.label76.TabIndex = 224;
            this.label76.Text = "Won Reason :";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.ForeColor = System.Drawing.Color.Black;
            this.label77.Location = new System.Drawing.Point(766, 255);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(105, 18);
            this.label77.TabIndex = 223;
            this.label77.Text = "Specify Others :";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.ForeColor = System.Drawing.Color.Black;
            this.label68.Location = new System.Drawing.Point(781, 159);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(93, 18);
            this.label68.TabIndex = 222;
            this.label68.Text = "Competition :";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.ForeColor = System.Drawing.Color.Black;
            this.label69.Location = new System.Drawing.Point(662, 70);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(212, 18);
            this.label69.TabIndex = 221;
            this.label69.Text = "Expected Order Placement Date :";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.ForeColor = System.Drawing.Color.Black;
            this.label70.Location = new System.Drawing.Point(788, 117);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(83, 18);
            this.label70.TabIndex = 220;
            this.label70.Text = "Probability :";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.ForeColor = System.Drawing.Color.Black;
            this.label71.Location = new System.Drawing.Point(49, 473);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(124, 18);
            this.label71.TabIndex = 219;
            this.label71.Text = "Type of Customer :";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.ForeColor = System.Drawing.Color.Black;
            this.label72.Location = new System.Drawing.Point(725, 21);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(149, 18);
            this.label72.TabIndex = 218;
            this.label72.Text = "Expected Order Value :";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.ForeColor = System.Drawing.Color.Black;
            this.label73.Location = new System.Drawing.Point(124, 423);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(49, 18);
            this.label73.TabIndex = 217;
            this.label73.Text = "Stage :";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.ForeColor = System.Drawing.Color.Black;
            this.label54.Location = new System.Drawing.Point(46, 330);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(123, 18);
            this.label54.TabIndex = 216;
            this.label54.Text = "Test Environment :";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.ForeColor = System.Drawing.Color.Black;
            this.label65.Location = new System.Drawing.Point(120, 377);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(53, 18);
            this.label65.TabIndex = 215;
            this.label65.Text = "Status :";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.Black;
            this.label33.Location = new System.Drawing.Point(14, 213);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(159, 18);
            this.label33.TabIndex = 214;
            this.label33.Text = "Primary Material Detail :";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.ForeColor = System.Drawing.Color.Black;
            this.label53.Location = new System.Drawing.Point(36, 282);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(137, 18);
            this.label53.TabIndex = 213;
            this.label53.Text = "Primary Application :";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.Black;
            this.label31.Location = new System.Drawing.Point(56, 117);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(117, 18);
            this.label31.TabIndex = 212;
            this.label31.Text = "Primary Industry :";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.Black;
            this.label32.Location = new System.Drawing.Point(54, 164);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(119, 18);
            this.label32.TabIndex = 211;
            this.label32.Text = "Primary Material :";
            // 
            // cmbLabtype
            // 
            this.cmbLabtype.DropDownHeight = 60;
            this.cmbLabtype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLabtype.DropDownWidth = 150;
            this.cmbLabtype.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbLabtype.FormattingEnabled = true;
            this.cmbLabtype.IntegralHeight = false;
            this.cmbLabtype.ItemHeight = 18;
            this.cmbLabtype.Location = new System.Drawing.Point(182, 23);
            this.cmbLabtype.Name = "cmbLabtype";
            this.cmbLabtype.Size = new System.Drawing.Size(354, 26);
            this.cmbLabtype.TabIndex = 209;
            this.cmbLabtype.SelectedIndexChanged += new System.EventHandler(this.cmbLabtype_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(104, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 18);
            this.label1.TabIndex = 210;
            this.label1.Text = "Lab Type :";
            // 
            // cmbBusinessector
            // 
            this.cmbBusinessector.DropDownHeight = 60;
            this.cmbBusinessector.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBusinessector.DropDownWidth = 150;
            this.cmbBusinessector.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbBusinessector.FormattingEnabled = true;
            this.cmbBusinessector.IntegralHeight = false;
            this.cmbBusinessector.ItemHeight = 18;
            this.cmbBusinessector.Location = new System.Drawing.Point(182, 69);
            this.cmbBusinessector.Name = "cmbBusinessector";
            this.cmbBusinessector.Size = new System.Drawing.Size(354, 26);
            this.cmbBusinessector.TabIndex = 207;
            this.cmbBusinessector.SelectedIndexChanged += new System.EventHandler(this.cmbBusinessector_SelectedIndexChanged);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.Black;
            this.label29.Location = new System.Drawing.Point(62, 72);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(111, 18);
            this.label29.TabIndex = 208;
            this.label29.Text = "Business Sector :";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Silver;
            this.tabPage2.Controls.Add(this.chkUpdateLatestPrice);
            this.tabPage2.Controls.Add(this.pnAddProduct);
            this.tabPage2.Controls.Add(this.chkAddProduct);
            this.tabPage2.Controls.Add(this.label66);
            this.tabPage2.Controls.Add(this.cmbProductCategory);
            this.tabPage2.Controls.Add(this.label64);
            this.tabPage2.Controls.Add(this.txtSystemMargin);
            this.tabPage2.Controls.Add(this.chkProductCode);
            this.tabPage2.Controls.Add(this.pnOptionalItems);
            this.tabPage2.Controls.Add(this.chkOptionalItems);
            this.tabPage2.Controls.Add(this.chkaddmainitems);
            this.tabPage2.Controls.Add(this.txtBasicDemoPrice);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.chkSavetoQuoteMaster);
            this.tabPage2.Controls.Add(this.chkAddbyQuoteMaster);
            this.tabPage2.Controls.Add(this.chkAddbyBOM);
            this.tabPage2.Controls.Add(this.pnQuoteMaster);
            this.tabPage2.Controls.Add(this.label22);
            this.tabPage2.Controls.Add(this.chkBreakup);
            this.tabPage2.Controls.Add(this.label46);
            this.tabPage2.Controls.Add(this.txtTotalPrice);
            this.tabPage2.Controls.Add(this.lblCST);
            this.tabPage2.Controls.Add(this.label45);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.label44);
            this.tabPage2.Controls.Add(this.txtJackup);
            this.tabPage2.Controls.Add(this.txtQuoteRemain);
            this.tabPage2.Controls.Add(this.txtQuoteBreak);
            this.tabPage2.Controls.Add(this.txtQuoteJack);
            this.tabPage2.Controls.Add(this.btnBack1);
            this.tabPage2.Controls.Add(this.btngotoquote);
            this.tabPage2.Controls.Add(this.cleartreeview);
            this.tabPage2.Controls.Add(this.txtsearchtree);
            this.tabPage2.Controls.Add(this.btnsearchtree);
            this.tabPage2.Controls.Add(this.tvProduct);
            this.tabPage2.Controls.Add(this.dgQuoteBOM);
            this.tabPage2.Controls.Add(this.dgvOptionalItems);
            this.tabPage2.Location = new System.Drawing.Point(4, 5);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1286, 630);
            this.tabPage2.TabIndex = 1;
            // 
            // chkUpdateLatestPrice
            // 
            this.chkUpdateLatestPrice.AutoSize = true;
            this.chkUpdateLatestPrice.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkUpdateLatestPrice.ForeColor = System.Drawing.Color.Black;
            this.chkUpdateLatestPrice.Location = new System.Drawing.Point(1039, 47);
            this.chkUpdateLatestPrice.Name = "chkUpdateLatestPrice";
            this.chkUpdateLatestPrice.Size = new System.Drawing.Size(243, 23);
            this.chkUpdateLatestPrice.TabIndex = 224;
            this.chkUpdateLatestPrice.Text = "Update Quote Latest Item Price";
            this.chkUpdateLatestPrice.UseVisualStyleBackColor = true;
            this.chkUpdateLatestPrice.CheckedChanged += new System.EventHandler(this.chkUpdateLatestPrice_CheckedChanged);
            // 
            // pnAddProduct
            // 
            this.pnAddProduct.Controls.Add(this.btnAddCategoryProduct);
            this.pnAddProduct.Controls.Add(this.txtProductCategory);
            this.pnAddProduct.Location = new System.Drawing.Point(918, 4);
            this.pnAddProduct.Name = "pnAddProduct";
            this.pnAddProduct.Size = new System.Drawing.Size(362, 39);
            this.pnAddProduct.TabIndex = 223;
            this.pnAddProduct.Visible = false;
            // 
            // btnAddCategoryProduct
            // 
            this.btnAddCategoryProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddCategoryProduct.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnAddCategoryProduct.Location = new System.Drawing.Point(310, 6);
            this.btnAddCategoryProduct.Name = "btnAddCategoryProduct";
            this.btnAddCategoryProduct.Size = new System.Drawing.Size(46, 26);
            this.btnAddCategoryProduct.TabIndex = 135;
            this.btnAddCategoryProduct.Text = "Add";
            this.btnAddCategoryProduct.UseVisualStyleBackColor = true;
            this.btnAddCategoryProduct.Click += new System.EventHandler(this.btnAddCategoryProduct_Click);
            // 
            // txtProductCategory
            // 
            this.txtProductCategory.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProductCategory.Location = new System.Drawing.Point(5, 6);
            this.txtProductCategory.Name = "txtProductCategory";
            this.txtProductCategory.Size = new System.Drawing.Size(302, 26);
            this.txtProductCategory.TabIndex = 134;
            // 
            // chkAddProduct
            // 
            this.chkAddProduct.AutoSize = true;
            this.chkAddProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkAddProduct.ForeColor = System.Drawing.Color.Black;
            this.chkAddProduct.Location = new System.Drawing.Point(853, 48);
            this.chkAddProduct.Name = "chkAddProduct";
            this.chkAddProduct.Size = new System.Drawing.Size(180, 23);
            this.chkAddProduct.TabIndex = 222;
            this.chkAddProduct.Text = "Add Product Category";
            this.chkAddProduct.UseVisualStyleBackColor = true;
            this.chkAddProduct.CheckedChanged += new System.EventHandler(this.chkAddProduct_CheckedChanged);
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.ForeColor = System.Drawing.Color.Black;
            this.label66.Location = new System.Drawing.Point(395, 47);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(121, 18);
            this.label66.TabIndex = 220;
            this.label66.Text = "Product Category :";
            // 
            // cmbProductCategory
            // 
            this.cmbProductCategory.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbProductCategory.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProductCategory.DropDownHeight = 180;
            this.cmbProductCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProductCategory.DropDownWidth = 150;
            this.cmbProductCategory.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProductCategory.FormattingEnabled = true;
            this.cmbProductCategory.IntegralHeight = false;
            this.cmbProductCategory.Location = new System.Drawing.Point(518, 44);
            this.cmbProductCategory.Name = "cmbProductCategory";
            this.cmbProductCategory.Size = new System.Drawing.Size(329, 26);
            this.cmbProductCategory.TabIndex = 221;
            this.cmbProductCategory.SelectedIndexChanged += new System.EventHandler(this.cmbProductCategory_SelectedIndexChanged);
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label64.Location = new System.Drawing.Point(135, 579);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(152, 26);
            this.label64.TabIndex = 217;
            this.label64.Text = "System Margin :";
            // 
            // txtSystemMargin
            // 
            this.txtSystemMargin.BackColor = System.Drawing.Color.White;
            this.txtSystemMargin.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSystemMargin.Location = new System.Drawing.Point(286, 577);
            this.txtSystemMargin.Name = "txtSystemMargin";
            this.txtSystemMargin.ReadOnly = true;
            this.txtSystemMargin.Size = new System.Drawing.Size(96, 31);
            this.txtSystemMargin.TabIndex = 218;
            this.txtSystemMargin.Text = "0";
            this.txtSystemMargin.TextChanged += new System.EventHandler(this.txtSystemMargin_TextChanged);
            // 
            // chkProductCode
            // 
            this.chkProductCode.AutoSize = true;
            this.chkProductCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.chkProductCode.Location = new System.Drawing.Point(10, 61);
            this.chkProductCode.Name = "chkProductCode";
            this.chkProductCode.Size = new System.Drawing.Size(121, 23);
            this.chkProductCode.TabIndex = 216;
            this.chkProductCode.Text = "Product Code";
            this.chkProductCode.UseVisualStyleBackColor = true;
            // 
            // pnOptionalItems
            // 
            this.pnOptionalItems.Controls.Add(this.txtOIBasicDemoPrice);
            this.pnOptionalItems.Controls.Add(this.label55);
            this.pnOptionalItems.Controls.Add(this.label56);
            this.pnOptionalItems.Controls.Add(this.chkOIBreakup);
            this.pnOptionalItems.Controls.Add(this.label57);
            this.pnOptionalItems.Controls.Add(this.txtOITotalPrice);
            this.pnOptionalItems.Controls.Add(this.label58);
            this.pnOptionalItems.Controls.Add(this.label59);
            this.pnOptionalItems.Controls.Add(this.label60);
            this.pnOptionalItems.Controls.Add(this.label61);
            this.pnOptionalItems.Controls.Add(this.txtOIJackup);
            this.pnOptionalItems.Controls.Add(this.txtOIQuoteRemain);
            this.pnOptionalItems.Controls.Add(this.txtOIQuoteBreak);
            this.pnOptionalItems.Controls.Add(this.txtOIQuoteJack);
            this.pnOptionalItems.Location = new System.Drawing.Point(392, 530);
            this.pnOptionalItems.Name = "pnOptionalItems";
            this.pnOptionalItems.Size = new System.Drawing.Size(694, 95);
            this.pnOptionalItems.TabIndex = 213;
            // 
            // txtOIBasicDemoPrice
            // 
            this.txtOIBasicDemoPrice.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtOIBasicDemoPrice.Location = new System.Drawing.Point(177, 65);
            this.txtOIBasicDemoPrice.Name = "txtOIBasicDemoPrice";
            this.txtOIBasicDemoPrice.ReadOnly = true;
            this.txtOIBasicDemoPrice.Size = new System.Drawing.Size(178, 26);
            this.txtOIBasicDemoPrice.TabIndex = 220;
            this.txtOIBasicDemoPrice.Text = "0";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.ForeColor = System.Drawing.Color.Black;
            this.label55.Location = new System.Drawing.Point(5, 68);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(170, 18);
            this.label55.TabIndex = 219;
            this.label55.Text = "Basic Price of The System :";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.ForeColor = System.Drawing.Color.Black;
            this.label56.Location = new System.Drawing.Point(19, 8);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(155, 18);
            this.label56.TabIndex = 211;
            this.label56.Text = "Selling Price of System :";
            // 
            // chkOIBreakup
            // 
            this.chkOIBreakup.AutoSize = true;
            this.chkOIBreakup.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkOIBreakup.ForeColor = System.Drawing.Color.DarkBlue;
            this.chkOIBreakup.Location = new System.Drawing.Point(228, 34);
            this.chkOIBreakup.Name = "chkOIBreakup";
            this.chkOIBreakup.Size = new System.Drawing.Size(145, 27);
            this.chkOIBreakup.TabIndex = 215;
            this.chkOIBreakup.Text = "Break Up Price";
            this.chkOIBreakup.UseVisualStyleBackColor = true;
            this.chkOIBreakup.CheckedChanged += new System.EventHandler(this.chkOIBreakup_CheckedChanged);
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label57.ForeColor = System.Drawing.Color.Black;
            this.label57.Location = new System.Drawing.Point(449, 67);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(83, 19);
            this.label57.TabIndex = 218;
            this.label57.Text = "Difference:";
            // 
            // txtOITotalPrice
            // 
            this.txtOITotalPrice.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtOITotalPrice.Location = new System.Drawing.Point(177, 4);
            this.txtOITotalPrice.Name = "txtOITotalPrice";
            this.txtOITotalPrice.ReadOnly = true;
            this.txtOITotalPrice.Size = new System.Drawing.Size(178, 26);
            this.txtOITotalPrice.TabIndex = 208;
            this.txtOITotalPrice.Text = "0";
            this.txtOITotalPrice.TextChanged += new System.EventHandler(this.txtOITotalPrice_TextChanged);
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label58.ForeColor = System.Drawing.Color.Black;
            this.label58.Location = new System.Drawing.Point(28, 39);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(142, 18);
            this.label58.TabIndex = 207;
            this.label58.Text = "Negotiation Cushion :";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label59.ForeColor = System.Drawing.Color.Black;
            this.label59.Location = new System.Drawing.Point(381, 38);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(151, 19);
            this.label59.TabIndex = 217;
            this.label59.Text = "Break Up Total Price:";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.ForeColor = System.Drawing.Color.Black;
            this.label60.Location = new System.Drawing.Point(207, 40);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(22, 18);
            this.label60.TabIndex = 210;
            this.label60.Text = "%";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label61.ForeColor = System.Drawing.Color.Black;
            this.label61.Location = new System.Drawing.Point(392, 6);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(140, 19);
            this.label61.TabIndex = 216;
            this.label61.Text = "Jack Up Total Price:";
            // 
            // txtOIJackup
            // 
            this.txtOIJackup.BackColor = System.Drawing.Color.White;
            this.txtOIJackup.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtOIJackup.Location = new System.Drawing.Point(177, 35);
            this.txtOIJackup.Name = "txtOIJackup";
            this.txtOIJackup.Size = new System.Drawing.Size(30, 26);
            this.txtOIJackup.TabIndex = 209;
            this.txtOIJackup.Text = "0";
            this.txtOIJackup.TextChanged += new System.EventHandler(this.txtOIJackup_TextChanged);
            this.txtOIJackup.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtOIJackup_KeyPress);
            this.txtOIJackup.Leave += new System.EventHandler(this.txtOIJackup_Leave);
            // 
            // txtOIQuoteRemain
            // 
            this.txtOIQuoteRemain.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtOIQuoteRemain.Location = new System.Drawing.Point(534, 65);
            this.txtOIQuoteRemain.Name = "txtOIQuoteRemain";
            this.txtOIQuoteRemain.ReadOnly = true;
            this.txtOIQuoteRemain.Size = new System.Drawing.Size(156, 26);
            this.txtOIQuoteRemain.TabIndex = 214;
            this.txtOIQuoteRemain.Text = "0";
            // 
            // txtOIQuoteBreak
            // 
            this.txtOIQuoteBreak.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtOIQuoteBreak.Location = new System.Drawing.Point(534, 34);
            this.txtOIQuoteBreak.Name = "txtOIQuoteBreak";
            this.txtOIQuoteBreak.ReadOnly = true;
            this.txtOIQuoteBreak.Size = new System.Drawing.Size(156, 26);
            this.txtOIQuoteBreak.TabIndex = 213;
            this.txtOIQuoteBreak.Text = "0";
            // 
            // txtOIQuoteJack
            // 
            this.txtOIQuoteJack.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtOIQuoteJack.Location = new System.Drawing.Point(534, 4);
            this.txtOIQuoteJack.Name = "txtOIQuoteJack";
            this.txtOIQuoteJack.ReadOnly = true;
            this.txtOIQuoteJack.Size = new System.Drawing.Size(156, 26);
            this.txtOIQuoteJack.TabIndex = 212;
            this.txtOIQuoteJack.Text = "0";
            // 
            // chkOptionalItems
            // 
            this.chkOptionalItems.AutoSize = true;
            this.chkOptionalItems.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkOptionalItems.ForeColor = System.Drawing.Color.Black;
            this.chkOptionalItems.Location = new System.Drawing.Point(697, 6);
            this.chkOptionalItems.Name = "chkOptionalItems";
            this.chkOptionalItems.Size = new System.Drawing.Size(207, 23);
            this.chkOptionalItems.TabIndex = 208;
            this.chkOptionalItems.Text = "Add Optional Quote Items";
            this.chkOptionalItems.UseVisualStyleBackColor = true;
            this.chkOptionalItems.CheckedChanged += new System.EventHandler(this.chkOptionalItems_CheckedChanged);
            // 
            // chkaddmainitems
            // 
            this.chkaddmainitems.AutoSize = true;
            this.chkaddmainitems.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkaddmainitems.ForeColor = System.Drawing.Color.Black;
            this.chkaddmainitems.Location = new System.Drawing.Point(508, 6);
            this.chkaddmainitems.Name = "chkaddmainitems";
            this.chkaddmainitems.Size = new System.Drawing.Size(144, 23);
            this.chkaddmainitems.TabIndex = 207;
            this.chkaddmainitems.Text = "Add Quote Items";
            this.chkaddmainitems.UseVisualStyleBackColor = true;
            this.chkaddmainitems.CheckedChanged += new System.EventHandler(this.chkaddmainitems_CheckedChanged);
            // 
            // txtBasicDemoPrice
            // 
            this.txtBasicDemoPrice.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtBasicDemoPrice.Location = new System.Drawing.Point(561, 595);
            this.txtBasicDemoPrice.Name = "txtBasicDemoPrice";
            this.txtBasicDemoPrice.ReadOnly = true;
            this.txtBasicDemoPrice.Size = new System.Drawing.Size(178, 26);
            this.txtBasicDemoPrice.TabIndex = 206;
            this.txtBasicDemoPrice.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(389, 598);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(170, 18);
            this.label8.TabIndex = 205;
            this.label8.Text = "Basic Price of The System :";
            // 
            // chkSavetoQuoteMaster
            // 
            this.chkSavetoQuoteMaster.AutoSize = true;
            this.chkSavetoQuoteMaster.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.chkSavetoQuoteMaster.ForeColor = System.Drawing.Color.DarkBlue;
            this.chkSavetoQuoteMaster.Location = new System.Drawing.Point(1088, 539);
            this.chkSavetoQuoteMaster.Name = "chkSavetoQuoteMaster";
            this.chkSavetoQuoteMaster.Size = new System.Drawing.Size(199, 27);
            this.chkSavetoQuoteMaster.TabIndex = 204;
            this.chkSavetoQuoteMaster.Text = "Save to QuoteMaster";
            this.chkSavetoQuoteMaster.UseVisualStyleBackColor = true;
            this.chkSavetoQuoteMaster.CheckedChanged += new System.EventHandler(this.chkSavetoQuoteMaster_CheckedChanged);
            // 
            // chkAddbyQuoteMaster
            // 
            this.chkAddbyQuoteMaster.AutoSize = true;
            this.chkAddbyQuoteMaster.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkAddbyQuoteMaster.ForeColor = System.Drawing.Color.Black;
            this.chkAddbyQuoteMaster.Location = new System.Drawing.Point(176, 3);
            this.chkAddbyQuoteMaster.Name = "chkAddbyQuoteMaster";
            this.chkAddbyQuoteMaster.Size = new System.Drawing.Size(192, 23);
            this.chkAddbyQuoteMaster.TabIndex = 203;
            this.chkAddbyQuoteMaster.Text = "Add from Quote Master";
            this.chkAddbyQuoteMaster.UseVisualStyleBackColor = true;
            this.chkAddbyQuoteMaster.CheckedChanged += new System.EventHandler(this.chkAddbyQuoteMaster_CheckedChanged);
            // 
            // chkAddbyBOM
            // 
            this.chkAddbyBOM.AutoSize = true;
            this.chkAddbyBOM.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkAddbyBOM.ForeColor = System.Drawing.Color.Black;
            this.chkAddbyBOM.Location = new System.Drawing.Point(16, 3);
            this.chkAddbyBOM.Name = "chkAddbyBOM";
            this.chkAddbyBOM.Size = new System.Drawing.Size(131, 23);
            this.chkAddbyBOM.TabIndex = 202;
            this.chkAddbyBOM.Text = "Add from BOM";
            this.chkAddbyBOM.UseVisualStyleBackColor = true;
            this.chkAddbyBOM.CheckedChanged += new System.EventHandler(this.chkAddbyBOM_CheckedChanged);
            // 
            // pnQuoteMaster
            // 
            this.pnQuoteMaster.Controls.Add(this.btnRename);
            this.pnQuoteMaster.Controls.Add(this.btnAddProduct);
            this.pnQuoteMaster.Controls.Add(this.btnAddFolder);
            this.pnQuoteMaster.Controls.Add(this.btnQuoteTreeSave);
            this.pnQuoteMaster.Controls.Add(this.txtCode);
            this.pnQuoteMaster.Controls.Add(this.txtName);
            this.pnQuoteMaster.Controls.Add(this.tvQuoteProduct);
            this.pnQuoteMaster.Location = new System.Drawing.Point(6, 95);
            this.pnQuoteMaster.Name = "pnQuoteMaster";
            this.pnQuoteMaster.Size = new System.Drawing.Size(380, 445);
            this.pnQuoteMaster.TabIndex = 201;
            // 
            // btnRename
            // 
            this.btnRename.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnRename.Enabled = false;
            this.btnRename.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnRename.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRename.Location = new System.Drawing.Point(259, 314);
            this.btnRename.Name = "btnRename";
            this.btnRename.Size = new System.Drawing.Size(112, 31);
            this.btnRename.TabIndex = 200;
            this.btnRename.Text = "Rename";
            this.btnRename.UseVisualStyleBackColor = false;
            this.btnRename.Click += new System.EventHandler(this.btnRename_Click);
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAddProduct.Enabled = false;
            this.btnAddProduct.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAddProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddProduct.Location = new System.Drawing.Point(136, 314);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(112, 31);
            this.btnAddProduct.TabIndex = 196;
            this.btnAddProduct.Text = "Add Product";
            this.btnAddProduct.UseVisualStyleBackColor = false;
            this.btnAddProduct.Click += new System.EventHandler(this.btnAddProduct_Click);
            // 
            // btnAddFolder
            // 
            this.btnAddFolder.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAddFolder.Enabled = false;
            this.btnAddFolder.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAddFolder.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddFolder.Location = new System.Drawing.Point(10, 314);
            this.btnAddFolder.Name = "btnAddFolder";
            this.btnAddFolder.Size = new System.Drawing.Size(116, 31);
            this.btnAddFolder.TabIndex = 199;
            this.btnAddFolder.Text = "Add Folder";
            this.btnAddFolder.UseVisualStyleBackColor = false;
            this.btnAddFolder.Click += new System.EventHandler(this.btnAddFolder_Click);
            // 
            // btnQuoteTreeSave
            // 
            this.btnQuoteTreeSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnQuoteTreeSave.Enabled = false;
            this.btnQuoteTreeSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnQuoteTreeSave.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuoteTreeSave.Location = new System.Drawing.Point(262, 413);
            this.btnQuoteTreeSave.Name = "btnQuoteTreeSave";
            this.btnQuoteTreeSave.Size = new System.Drawing.Size(109, 30);
            this.btnQuoteTreeSave.TabIndex = 135;
            this.btnQuoteTreeSave.Text = "Save";
            this.btnQuoteTreeSave.UseVisualStyleBackColor = false;
            this.btnQuoteTreeSave.Click += new System.EventHandler(this.btnQuoteTreeSave_Click);
            // 
            // txtCode
            // 
            this.txtCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCode.Location = new System.Drawing.Point(4, 383);
            this.txtCode.Name = "txtCode";
            this.txtCode.Size = new System.Drawing.Size(373, 26);
            this.txtCode.TabIndex = 198;
            this.txtCode.Visible = false;
            this.txtCode.Enter += new System.EventHandler(this.txtCode_Enter);
            this.txtCode.Leave += new System.EventHandler(this.txtCode_Leave);
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(4, 351);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(373, 26);
            this.txtName.TabIndex = 197;
            this.txtName.Visible = false;
            this.txtName.Enter += new System.EventHandler(this.txtName_Enter);
            this.txtName.Leave += new System.EventHandler(this.txtName_Leave);
            // 
            // tvQuoteProduct
            // 
            this.tvQuoteProduct.Cursor = System.Windows.Forms.Cursors.Default;
            this.tvQuoteProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tvQuoteProduct.HideSelection = false;
            this.tvQuoteProduct.Location = new System.Drawing.Point(4, 3);
            this.tvQuoteProduct.Name = "tvQuoteProduct";
            this.tvQuoteProduct.Size = new System.Drawing.Size(373, 308);
            this.tvQuoteProduct.StateImageList = this.imageList2;
            this.tvQuoteProduct.TabIndex = 195;
            this.tvQuoteProduct.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.tvQuoteProduct_NodeMouseClick);
            this.tvQuoteProduct.NodeMouseDoubleClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.tvQuoteProduct_NodeMouseDoubleClick);
            this.tvQuoteProduct.KeyUp += new System.Windows.Forms.KeyEventHandler(this.tvQuoteProduct_KeyUp);
            // 
            // imageList2
            // 
            this.imageList2.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList2.ImageStream")));
            this.imageList2.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList2.Images.SetKeyName(0, "folderopened_yellow.ico");
            this.imageList2.Images.SetKeyName(1, "Dryicons-Aesthetica-2-Process-accept.ico");
            this.imageList2.Images.SetKeyName(2, "Dryicons-Aesthetica-2-Process-remove.ico");
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Black;
            this.label22.Location = new System.Drawing.Point(403, 538);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(155, 18);
            this.label22.TabIndex = 161;
            this.label22.Text = "Selling Price of System :";
            // 
            // chkBreakup
            // 
            this.chkBreakup.AutoSize = true;
            this.chkBreakup.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBreakup.ForeColor = System.Drawing.Color.DarkBlue;
            this.chkBreakup.Location = new System.Drawing.Point(612, 564);
            this.chkBreakup.Name = "chkBreakup";
            this.chkBreakup.Size = new System.Drawing.Size(145, 27);
            this.chkBreakup.TabIndex = 178;
            this.chkBreakup.Text = "Break Up Price";
            this.chkBreakup.UseVisualStyleBackColor = true;
            this.chkBreakup.CheckedChanged += new System.EventHandler(this.chkBreakup_CheckedChanged);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label46.ForeColor = System.Drawing.Color.Black;
            this.label46.Location = new System.Drawing.Point(833, 597);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(83, 19);
            this.label46.TabIndex = 194;
            this.label46.Text = "Difference:";
            // 
            // txtTotalPrice
            // 
            this.txtTotalPrice.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtTotalPrice.Location = new System.Drawing.Point(561, 534);
            this.txtTotalPrice.Name = "txtTotalPrice";
            this.txtTotalPrice.ReadOnly = true;
            this.txtTotalPrice.Size = new System.Drawing.Size(178, 26);
            this.txtTotalPrice.TabIndex = 130;
            this.txtTotalPrice.Text = "0";
            this.txtTotalPrice.TextChanged += new System.EventHandler(this.txtTotalPrice_TextChanged);
            this.txtTotalPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTotalPrice_KeyPress);
            // 
            // lblCST
            // 
            this.lblCST.AutoSize = true;
            this.lblCST.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.lblCST.ForeColor = System.Drawing.Color.Black;
            this.lblCST.Location = new System.Drawing.Point(414, 569);
            this.lblCST.Name = "lblCST";
            this.lblCST.Size = new System.Drawing.Size(142, 18);
            this.lblCST.TabIndex = 127;
            this.lblCST.Text = "Negotiation Cushion :";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label45.ForeColor = System.Drawing.Color.Black;
            this.label45.Location = new System.Drawing.Point(765, 568);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(151, 19);
            this.label45.TabIndex = 193;
            this.label45.Text = "Break Up Total Price:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(591, 570);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(22, 18);
            this.label13.TabIndex = 148;
            this.label13.Text = "%";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label44.ForeColor = System.Drawing.Color.Black;
            this.label44.Location = new System.Drawing.Point(776, 536);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(140, 19);
            this.label44.TabIndex = 192;
            this.label44.Text = "Jack Up Total Price:";
            // 
            // txtJackup
            // 
            this.txtJackup.BackColor = System.Drawing.Color.White;
            this.txtJackup.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtJackup.Location = new System.Drawing.Point(561, 565);
            this.txtJackup.Name = "txtJackup";
            this.txtJackup.Size = new System.Drawing.Size(30, 26);
            this.txtJackup.TabIndex = 136;
            this.txtJackup.Text = "0";
            this.txtJackup.TextChanged += new System.EventHandler(this.txtJackup_TextChanged);
            this.txtJackup.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtJackup_KeyPress);
            this.txtJackup.Leave += new System.EventHandler(this.txtJackup_Leave);
            // 
            // txtQuoteRemain
            // 
            this.txtQuoteRemain.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtQuoteRemain.Location = new System.Drawing.Point(918, 595);
            this.txtQuoteRemain.Name = "txtQuoteRemain";
            this.txtQuoteRemain.ReadOnly = true;
            this.txtQuoteRemain.Size = new System.Drawing.Size(156, 26);
            this.txtQuoteRemain.TabIndex = 171;
            this.txtQuoteRemain.Text = "0";
            // 
            // txtQuoteBreak
            // 
            this.txtQuoteBreak.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtQuoteBreak.Location = new System.Drawing.Point(918, 564);
            this.txtQuoteBreak.Name = "txtQuoteBreak";
            this.txtQuoteBreak.ReadOnly = true;
            this.txtQuoteBreak.Size = new System.Drawing.Size(156, 26);
            this.txtQuoteBreak.TabIndex = 170;
            this.txtQuoteBreak.Text = "0";
            // 
            // txtQuoteJack
            // 
            this.txtQuoteJack.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtQuoteJack.Location = new System.Drawing.Point(918, 534);
            this.txtQuoteJack.Name = "txtQuoteJack";
            this.txtQuoteJack.ReadOnly = true;
            this.txtQuoteJack.Size = new System.Drawing.Size(156, 26);
            this.txtQuoteJack.TabIndex = 169;
            this.txtQuoteJack.Text = "0";
            this.txtQuoteJack.TextChanged += new System.EventHandler(this.txtQuoteJack_TextChanged);
            // 
            // btnBack1
            // 
            this.btnBack1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnBack1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnBack1.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold);
            this.btnBack1.Location = new System.Drawing.Point(6, 569);
            this.btnBack1.Name = "btnBack1";
            this.btnBack1.Size = new System.Drawing.Size(124, 45);
            this.btnBack1.TabIndex = 137;
            this.btnBack1.Text = "Back";
            this.btnBack1.UseVisualStyleBackColor = false;
            this.btnBack1.Click += new System.EventHandler(this.btnBack1_Click);
            // 
            // btngotoquote
            // 
            this.btngotoquote.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btngotoquote.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btngotoquote.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btngotoquote.Location = new System.Drawing.Point(1122, 577);
            this.btngotoquote.Name = "btngotoquote";
            this.btngotoquote.Size = new System.Drawing.Size(158, 45);
            this.btngotoquote.TabIndex = 136;
            this.btngotoquote.Text = "Continue";
            this.btngotoquote.UseVisualStyleBackColor = false;
            this.btngotoquote.Click += new System.EventHandler(this.btngotoquote_Click);
            // 
            // cleartreeview
            // 
            this.cleartreeview.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cleartreeview.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.cleartreeview.Location = new System.Drawing.Point(307, 58);
            this.cleartreeview.Name = "cleartreeview";
            this.cleartreeview.Size = new System.Drawing.Size(61, 26);
            this.cleartreeview.TabIndex = 134;
            this.cleartreeview.Text = "Clear";
            this.cleartreeview.UseVisualStyleBackColor = true;
            this.cleartreeview.Click += new System.EventHandler(this.cleartreeview_Click);
            // 
            // txtsearchtree
            // 
            this.txtsearchtree.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsearchtree.Location = new System.Drawing.Point(10, 29);
            this.txtsearchtree.Name = "txtsearchtree";
            this.txtsearchtree.Size = new System.Drawing.Size(358, 26);
            this.txtsearchtree.TabIndex = 133;
            this.txtsearchtree.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtsearchtree_KeyUp);
            // 
            // btnsearchtree
            // 
            this.btnsearchtree.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearchtree.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnsearchtree.Location = new System.Drawing.Point(229, 58);
            this.btnsearchtree.Name = "btnsearchtree";
            this.btnsearchtree.Size = new System.Drawing.Size(67, 26);
            this.btnsearchtree.TabIndex = 132;
            this.btnsearchtree.Text = "Search";
            this.btnsearchtree.UseVisualStyleBackColor = true;
            this.btnsearchtree.Click += new System.EventHandler(this.btnsearchtree_Click);
            // 
            // tvProduct
            // 
            this.tvProduct.Cursor = System.Windows.Forms.Cursors.Default;
            this.tvProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tvProduct.HideSelection = false;
            this.tvProduct.Location = new System.Drawing.Point(10, 95);
            this.tvProduct.Name = "tvProduct";
            this.tvProduct.Size = new System.Drawing.Size(377, 454);
            this.tvProduct.StateImageList = this.imageList1;
            this.tvProduct.TabIndex = 63;
            this.tvProduct.AfterLabelEdit += new System.Windows.Forms.NodeLabelEditEventHandler(this.tvProduct_AfterLabelEdit);
            this.tvProduct.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.tvProduct_NodeMouseClick);
            this.tvProduct.NodeMouseDoubleClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.tvProduct_NodeMouseDoubleClick);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "folderopened_yellow.ico");
            this.imageList1.Images.SetKeyName(1, "diagram_v2_17.ico");
            this.imageList1.Images.SetKeyName(2, "Dryicons-Aesthetica-2-Process-accept.ico");
            this.imageList1.Images.SetKeyName(3, "Dryicons-Aesthetica-2-Process-remove.ico");
            this.imageList1.Images.SetKeyName(4, "Rafiqul-Hassan-Blogger-Settings.ico");
            // 
            // dgQuoteBOM
            // 
            this.dgQuoteBOM.AllowDrop = true;
            this.dgQuoteBOM.AllowUserToAddRows = false;
            this.dgQuoteBOM.AllowUserToDeleteRows = false;
            this.dgQuoteBOM.AllowUserToResizeRows = false;
            this.dgQuoteBOM.BackgroundColor = System.Drawing.SystemColors.ControlDark;
            this.dgQuoteBOM.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgQuoteBOM.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgQuoteBOM.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgQuoteBOM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgQuoteBOM.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SLNO,
            this.ProductGroup,
            this.ProductCod,
            this.ProductName,
            this.Description,
            this.Quantity,
            this.UnitPrice,
            this.TPrice,
            this.SP,
            this.BreakupTotal,
            this.SalesCost,
            this.SalesCostTemp,
            this.materialMargin});
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgQuoteBOM.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgQuoteBOM.EnableHeadersVisualStyles = false;
            this.dgQuoteBOM.Location = new System.Drawing.Point(389, 74);
            this.dgQuoteBOM.MultiSelect = false;
            this.dgQuoteBOM.Name = "dgQuoteBOM";
            this.dgQuoteBOM.RowHeadersVisible = false;
            this.dgQuoteBOM.RowHeadersWidth = 62;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgQuoteBOM.RowsDefaultCellStyle = dataGridViewCellStyle9;
            this.dgQuoteBOM.Size = new System.Drawing.Size(891, 450);
            this.dgQuoteBOM.TabIndex = 62;
            this.dgQuoteBOM.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgQuoteBOM_CellBeginEdit);
            this.dgQuoteBOM.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgQuoteBOM_CellDoubleClick);
            this.dgQuoteBOM.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgQuoteBOM_CellEndEdit);
            this.dgQuoteBOM.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgQuoteBOM_CellEnter);
            this.dgQuoteBOM.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgQuoteBOM_EditingControlShowing);
            this.dgQuoteBOM.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dgQuoteBOM_KeyDown);
            this.dgQuoteBOM.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgQuoteBOM_KeyUp);
            // 
            // SLNO
            // 
            this.SLNO.DataPropertyName = "GroupID";
            this.SLNO.HeaderText = "SlNo";
            this.SLNO.MinimumWidth = 8;
            this.SLNO.Name = "SLNO";
            this.SLNO.ReadOnly = true;
            this.SLNO.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SLNO.Width = 47;
            // 
            // ProductGroup
            // 
            this.ProductGroup.DataPropertyName = "ProductGroup";
            this.ProductGroup.HeaderText = "ProductGroup";
            this.ProductGroup.MinimumWidth = 8;
            this.ProductGroup.Name = "ProductGroup";
            this.ProductGroup.ReadOnly = true;
            this.ProductGroup.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductGroup.Visible = false;
            this.ProductGroup.Width = 113;
            // 
            // ProductCod
            // 
            this.ProductCod.DataPropertyName = "ProductCode";
            this.ProductCod.HeaderText = "ProductCode";
            this.ProductCod.MinimumWidth = 8;
            this.ProductCod.Name = "ProductCod";
            this.ProductCod.ReadOnly = true;
            this.ProductCod.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductCod.Width = 104;
            // 
            // ProductName
            // 
            this.ProductName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ProductName.DataPropertyName = "ProductName";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ProductName.DefaultCellStyle = dataGridViewCellStyle2;
            this.ProductName.HeaderText = "Product Name";
            this.ProductName.MinimumWidth = 8;
            this.ProductName.Name = "ProductName";
            this.ProductName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Description
            // 
            this.Description.DataPropertyName = "ProductDescription";
            this.Description.HeaderText = "Description";
            this.Description.MinimumWidth = 8;
            this.Description.Name = "Description";
            this.Description.ReadOnly = true;
            this.Description.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Description.Visible = false;
            this.Description.Width = 92;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "Quantity";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Quantity.DefaultCellStyle = dataGridViewCellStyle3;
            this.Quantity.HeaderText = "Qty";
            this.Quantity.MinimumWidth = 8;
            this.Quantity.Name = "Quantity";
            this.Quantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Quantity.Width = 40;
            // 
            // UnitPrice
            // 
            this.UnitPrice.DataPropertyName = "UnitPrice";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.Format = "N0";
            dataGridViewCellStyle4.NullValue = null;
            this.UnitPrice.DefaultCellStyle = dataGridViewCellStyle4;
            this.UnitPrice.HeaderText = "Unit Price";
            this.UnitPrice.MinimumWidth = 8;
            this.UnitPrice.Name = "UnitPrice";
            this.UnitPrice.ReadOnly = true;
            this.UnitPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitPrice.Width = 82;
            // 
            // TPrice
            // 
            this.TPrice.DataPropertyName = "TotalPrice";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.Format = "N0";
            dataGridViewCellStyle5.NullValue = null;
            this.TPrice.DefaultCellStyle = dataGridViewCellStyle5;
            this.TPrice.HeaderText = "Total Price";
            this.TPrice.MinimumWidth = 8;
            this.TPrice.Name = "TPrice";
            this.TPrice.ReadOnly = true;
            this.TPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.TPrice.Width = 87;
            // 
            // SP
            // 
            this.SP.DataPropertyName = "ShowPrice";
            this.SP.HeaderText = "SP";
            this.SP.MinimumWidth = 8;
            this.SP.Name = "SP";
            this.SP.ReadOnly = true;
            this.SP.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SP.Width = 32;
            // 
            // BreakupTotal
            // 
            this.BreakupTotal.DataPropertyName = "BreakupTotal";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle6.Format = "N0";
            dataGridViewCellStyle6.NullValue = null;
            this.BreakupTotal.DefaultCellStyle = dataGridViewCellStyle6;
            this.BreakupTotal.HeaderText = "BreakUp Price";
            this.BreakupTotal.MinimumWidth = 8;
            this.BreakupTotal.Name = "BreakupTotal";
            this.BreakupTotal.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.BreakupTotal.Visible = false;
            this.BreakupTotal.Width = 111;
            // 
            // SalesCost
            // 
            this.SalesCost.DataPropertyName = "SalesCost";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.Format = "N0";
            dataGridViewCellStyle7.NullValue = null;
            this.SalesCost.DefaultCellStyle = dataGridViewCellStyle7;
            this.SalesCost.HeaderText = "Sales Cost";
            this.SalesCost.MinimumWidth = 8;
            this.SalesCost.Name = "SalesCost";
            this.SalesCost.ReadOnly = true;
            this.SalesCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SalesCost.Visible = false;
            this.SalesCost.Width = 82;

            //
            //SalesCostTemp
            //

            this.SalesCostTemp.DataPropertyName = "SalesCostTemp";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.Format = "N0";
            dataGridViewCellStyle7.NullValue = null;
            this.SalesCostTemp.DefaultCellStyle = dataGridViewCellStyle7;
            this.SalesCostTemp.HeaderText = "Sales Cost";
            this.SalesCostTemp.MinimumWidth = 8;
            this.SalesCostTemp.Name = "SalesCostTemp";
            this.SalesCostTemp.ReadOnly = true;
            this.SalesCostTemp.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SalesCostTemp.Visible = false;
            this.SalesCostTemp.Width = 82;

            // 
            // materialMargin
            // 
            this.materialMargin.DataPropertyName = "materialMargin";
            this.materialMargin.HeaderText = "MM";
            this.materialMargin.MinimumWidth = 8;
            this.materialMargin.Name = "materialMargin";
            this.materialMargin.ReadOnly = true;
            this.materialMargin.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.materialMargin.Visible = false;
            this.materialMargin.Width = 70;
            // 
            // dgvOptionalItems
            // 
            this.dgvOptionalItems.AllowUserToAddRows = false;
            this.dgvOptionalItems.AllowUserToDeleteRows = false;
            this.dgvOptionalItems.AllowUserToResizeRows = false;
            this.dgvOptionalItems.BackgroundColor = System.Drawing.SystemColors.ControlDark;
            this.dgvOptionalItems.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvOptionalItems.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvOptionalItems.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dgvOptionalItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOptionalItems.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.OISLNo,
            this.OIProductGroup,
            this.OIProductCode,
            this.OIProductName,
            this.OIProductDescription,
            this.OIQuantity,
            this.OIUnitPrice,
            this.OITotalPrice,
            this.SP1,
            this.OIBreakupTotal,
            this.OISalesCost,
            this.OImaterialMargin});
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvOptionalItems.DefaultCellStyle = dataGridViewCellStyle18;
            this.dgvOptionalItems.EnableHeadersVisualStyles = false;
            this.dgvOptionalItems.Location = new System.Drawing.Point(389, 74);
            this.dgvOptionalItems.MultiSelect = false;
            this.dgvOptionalItems.Name = "dgvOptionalItems";
            this.dgvOptionalItems.RowHeadersVisible = false;
            this.dgvOptionalItems.RowHeadersWidth = 62;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvOptionalItems.RowsDefaultCellStyle = dataGridViewCellStyle19;
            this.dgvOptionalItems.Size = new System.Drawing.Size(894, 450);
            this.dgvOptionalItems.TabIndex = 210;
            this.dgvOptionalItems.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgvOptionalItems_CellBeginEdit);
            this.dgvOptionalItems.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvOptionalItems_CellDoubleClick);
            this.dgvOptionalItems.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvOptionalItems_CellEndEdit);
            this.dgvOptionalItems.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvOptionalItems_CellEnter);
            this.dgvOptionalItems.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvOptionalItems_EditingControlShowing);
            this.dgvOptionalItems.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dgvOptionalItems_KeyDown);
            this.dgvOptionalItems.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvOptionalItems_KeyUp);
            // 
            // OISLNo
            // 
            this.OISLNo.DataPropertyName = "GroupID";
            this.OISLNo.HeaderText = "Slno";
            this.OISLNo.MinimumWidth = 8;
            this.OISLNo.Name = "OISLNo";
            this.OISLNo.ReadOnly = true;
            this.OISLNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OISLNo.Width = 45;
            // 
            // OIProductGroup
            // 
            this.OIProductGroup.DataPropertyName = "ProductGroup";
            this.OIProductGroup.HeaderText = "ProductGroup";
            this.OIProductGroup.MinimumWidth = 8;
            this.OIProductGroup.Name = "OIProductGroup";
            this.OIProductGroup.ReadOnly = true;
            this.OIProductGroup.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OIProductGroup.Visible = false;
            this.OIProductGroup.Width = 113;
            // 
            // OIProductCode
            // 
            this.OIProductCode.DataPropertyName = "ProductCode";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.OIProductCode.DefaultCellStyle = dataGridViewCellStyle11;
            this.OIProductCode.HeaderText = "Product Code";
            this.OIProductCode.MinimumWidth = 8;
            this.OIProductCode.Name = "OIProductCode";
            this.OIProductCode.ReadOnly = true;
            this.OIProductCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OIProductCode.Width = 108;
            // 
            // OIProductName
            // 
            this.OIProductName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.OIProductName.DataPropertyName = "ProductName";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.OIProductName.DefaultCellStyle = dataGridViewCellStyle12;
            this.OIProductName.HeaderText = "Product Name";
            this.OIProductName.MinimumWidth = 8;
            this.OIProductName.Name = "OIProductName";
            this.OIProductName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // OIProductDescription
            // 
            this.OIProductDescription.DataPropertyName = "ProductDescription";
            this.OIProductDescription.HeaderText = "Description";
            this.OIProductDescription.MinimumWidth = 8;
            this.OIProductDescription.Name = "OIProductDescription";
            this.OIProductDescription.ReadOnly = true;
            this.OIProductDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OIProductDescription.Visible = false;
            this.OIProductDescription.Width = 92;
            // 
            // OIQuantity
            // 
            this.OIQuantity.DataPropertyName = "Quantity";
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.OIQuantity.DefaultCellStyle = dataGridViewCellStyle13;
            this.OIQuantity.HeaderText = "Qty";
            this.OIQuantity.MinimumWidth = 8;
            this.OIQuantity.Name = "OIQuantity";
            this.OIQuantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OIQuantity.Width = 40;
            // 
            // OIUnitPrice
            // 
            this.OIUnitPrice.DataPropertyName = "UnitPrice";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle14.Format = "N0";
            dataGridViewCellStyle14.NullValue = null;
            this.OIUnitPrice.DefaultCellStyle = dataGridViewCellStyle14;
            this.OIUnitPrice.HeaderText = "Unit Price";
            this.OIUnitPrice.MinimumWidth = 8;
            this.OIUnitPrice.Name = "OIUnitPrice";
            this.OIUnitPrice.ReadOnly = true;
            this.OIUnitPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OIUnitPrice.Width = 82;
            // 
            // OITotalPrice
            // 
            this.OITotalPrice.DataPropertyName = "TotalPrice";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle15.Format = "N0";
            dataGridViewCellStyle15.NullValue = null;
            this.OITotalPrice.DefaultCellStyle = dataGridViewCellStyle15;
            this.OITotalPrice.HeaderText = "Total Price";
            this.OITotalPrice.MinimumWidth = 8;
            this.OITotalPrice.Name = "OITotalPrice";
            this.OITotalPrice.ReadOnly = true;
            this.OITotalPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OITotalPrice.Width = 87;
            // 
            // SP1
            // 
            this.SP1.DataPropertyName = "ShowPrice";
            this.SP1.HeaderText = "SP";
            this.SP1.MinimumWidth = 8;
            this.SP1.Name = "SP1";
            this.SP1.ReadOnly = true;
            this.SP1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SP1.Width = 32;
            // 
            // OIBreakupTotal
            // 
            this.OIBreakupTotal.DataPropertyName = "BreakupTotal";
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle16.Format = "N0";
            dataGridViewCellStyle16.NullValue = null;
            this.OIBreakupTotal.DefaultCellStyle = dataGridViewCellStyle16;
            this.OIBreakupTotal.HeaderText = "Breakup Price";
            this.OIBreakupTotal.MinimumWidth = 8;
            this.OIBreakupTotal.Name = "OIBreakupTotal";
            this.OIBreakupTotal.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OIBreakupTotal.Visible = false;
            this.OIBreakupTotal.Width = 110;
            // 
            // OISalesCost
            // 
            this.OISalesCost.DataPropertyName = "SalesCost";
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle17.Format = "N0";
            dataGridViewCellStyle17.NullValue = null;
            this.OISalesCost.DefaultCellStyle = dataGridViewCellStyle17;
            this.OISalesCost.HeaderText = "Sales Cost";
            this.OISalesCost.MinimumWidth = 8;
            this.OISalesCost.Name = "OISalesCost";
            this.OISalesCost.ReadOnly = true;
            this.OISalesCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OISalesCost.Visible = false;
            this.OISalesCost.Width = 82;
            // 
            // OImaterialMargin
            // 
            this.OImaterialMargin.DataPropertyName = "OImaterialMargin";
            this.OImaterialMargin.DefaultCellStyle = dataGridViewCellStyle17;
            this.OImaterialMargin.HeaderText = "MM";
            this.OImaterialMargin.MinimumWidth = 8;
            this.OImaterialMargin.Name = "OImaterialMargin";
            this.OImaterialMargin.ReadOnly = true;
            this.OImaterialMargin.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OImaterialMargin.Visible = false;
            this.OImaterialMargin.Width = 70;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Silver;
            this.tabPage3.Controls.Add(this.chkWUOptionalItems);
            this.tabPage3.Controls.Add(this.chkWUQuoteItems);
            this.tabPage3.Controls.Add(this.btnBack2);
            this.tabPage3.Controls.Add(this.btnQuotePricing);
            this.tabPage3.Controls.Add(this.dgWriteUP);
            this.tabPage3.Controls.Add(this.dgOIWriteUP);
            this.tabPage3.Location = new System.Drawing.Point(4, 5);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1286, 630);
            this.tabPage3.TabIndex = 2;
            // 
            // chkWUOptionalItems
            // 
            this.chkWUOptionalItems.AutoSize = true;
            this.chkWUOptionalItems.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkWUOptionalItems.ForeColor = System.Drawing.Color.Black;
            this.chkWUOptionalItems.Location = new System.Drawing.Point(226, 6);
            this.chkWUOptionalItems.Name = "chkWUOptionalItems";
            this.chkWUOptionalItems.Size = new System.Drawing.Size(241, 23);
            this.chkWUOptionalItems.TabIndex = 211;
            this.chkWUOptionalItems.Text = "Write UP Optional Quote Items";
            this.chkWUOptionalItems.UseVisualStyleBackColor = true;
            this.chkWUOptionalItems.CheckedChanged += new System.EventHandler(this.chkWUOptionalItems_CheckedChanged);
            // 
            // chkWUQuoteItems
            // 
            this.chkWUQuoteItems.AutoSize = true;
            this.chkWUQuoteItems.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkWUQuoteItems.ForeColor = System.Drawing.Color.Black;
            this.chkWUQuoteItems.Location = new System.Drawing.Point(6, 6);
            this.chkWUQuoteItems.Name = "chkWUQuoteItems";
            this.chkWUQuoteItems.Size = new System.Drawing.Size(178, 23);
            this.chkWUQuoteItems.TabIndex = 210;
            this.chkWUQuoteItems.Text = "Write UP Quote Items";
            this.chkWUQuoteItems.UseVisualStyleBackColor = true;
            this.chkWUQuoteItems.CheckedChanged += new System.EventHandler(this.chkWUQuoteItems_CheckedChanged);
            // 
            // btnBack2
            // 
            this.btnBack2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBack2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnBack2.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack2.Location = new System.Drawing.Point(6, 570);
            this.btnBack2.Name = "btnBack2";
            this.btnBack2.Size = new System.Drawing.Size(124, 45);
            this.btnBack2.TabIndex = 138;
            this.btnBack2.Text = "Back";
            this.btnBack2.UseVisualStyleBackColor = false;
            this.btnBack2.Click += new System.EventHandler(this.btnBack2_Click);
            // 
            // btnQuotePricing
            // 
            this.btnQuotePricing.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnQuotePricing.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnQuotePricing.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuotePricing.Location = new System.Drawing.Point(1098, 570);
            this.btnQuotePricing.Name = "btnQuotePricing";
            this.btnQuotePricing.Size = new System.Drawing.Size(187, 45);
            this.btnQuotePricing.TabIndex = 137;
            this.btnQuotePricing.Text = "Go to Pricing";
            this.btnQuotePricing.UseVisualStyleBackColor = false;
            this.btnQuotePricing.Click += new System.EventHandler(this.btnQuotePricing_Click);
            // 
            // dgWriteUP
            // 
            this.dgWriteUP.AllowUserToAddRows = false;
            this.dgWriteUP.AllowUserToDeleteRows = false;
            this.dgWriteUP.AllowUserToResizeRows = false;
            this.dgWriteUP.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgWriteUP.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgWriteUP.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgWriteUP.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgWriteUP.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle20;
            this.dgWriteUP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgWriteUP.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.WUSlNo,
            this.WUProductcode,
            this.WUDescription,
            this.dataGridViewTextBoxColumn4});
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgWriteUP.DefaultCellStyle = dataGridViewCellStyle24;
            this.dgWriteUP.EnableHeadersVisualStyles = false;
            this.dgWriteUP.Location = new System.Drawing.Point(3, 28);
            this.dgWriteUP.MultiSelect = false;
            this.dgWriteUP.Name = "dgWriteUP";
            this.dgWriteUP.RowHeadersVisible = false;
            this.dgWriteUP.RowHeadersWidth = 62;
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgWriteUP.RowsDefaultCellStyle = dataGridViewCellStyle25;
            this.dgWriteUP.Size = new System.Drawing.Size(1277, 525);
            this.dgWriteUP.TabIndex = 63;
            this.dgWriteUP.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgWriteUP_CellEndEdit);
            this.dgWriteUP.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgWriteUP_CellEnter);
            this.dgWriteUP.MouseUp += new System.Windows.Forms.MouseEventHandler(this.dgWriteUP_MouseUp);
            // 
            // WUSlNo
            // 
            this.WUSlNo.DataPropertyName = "GroupID";
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle21.NullValue = null;
            this.WUSlNo.DefaultCellStyle = dataGridViewCellStyle21;
            this.WUSlNo.HeaderText = "S.No";
            this.WUSlNo.MinimumWidth = 8;
            this.WUSlNo.Name = "WUSlNo";
            this.WUSlNo.ReadOnly = true;
            this.WUSlNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.WUSlNo.Width = 47;
            // 
            // WUProductcode
            // 
            this.WUProductcode.DataPropertyName = "ProductCode";
            this.WUProductcode.HeaderText = "Product Code";
            this.WUProductcode.MinimumWidth = 8;
            this.WUProductcode.Name = "WUProductcode";
            this.WUProductcode.ReadOnly = true;
            this.WUProductcode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.WUProductcode.Visible = false;
            this.WUProductcode.Width = 108;
            // 
            // WUDescription
            // 
            this.WUDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.WUDescription.DataPropertyName = "ProductDescription";
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.WUDescription.DefaultCellStyle = dataGridViewCellStyle22;
            this.WUDescription.HeaderText = "Description";
            this.WUDescription.MinimumWidth = 8;
            this.WUDescription.Name = "WUDescription";
            this.WUDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Quantity";
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle23;
            this.dataGridViewTextBoxColumn4.HeaderText = "Qty";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn4.Width = 40;
            // 
            // dgOIWriteUP
            // 
            this.dgOIWriteUP.AllowUserToAddRows = false;
            this.dgOIWriteUP.AllowUserToDeleteRows = false;
            this.dgOIWriteUP.AllowUserToResizeRows = false;
            this.dgOIWriteUP.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgOIWriteUP.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgOIWriteUP.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgOIWriteUP.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle26.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle26.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgOIWriteUP.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle26;
            this.dgOIWriteUP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgOIWriteUP.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DGOISlNo,
            this.WUOIProductCode,
            this.WUOIProductDescription,
            this.dataGridViewTextBoxColumn6});
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle30.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle30.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle30.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle30.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle30.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle30.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgOIWriteUP.DefaultCellStyle = dataGridViewCellStyle30;
            this.dgOIWriteUP.EnableHeadersVisualStyles = false;
            this.dgOIWriteUP.Location = new System.Drawing.Point(3, 28);
            this.dgOIWriteUP.MultiSelect = false;
            this.dgOIWriteUP.Name = "dgOIWriteUP";
            this.dgOIWriteUP.RowHeadersVisible = false;
            this.dgOIWriteUP.RowHeadersWidth = 62;
            dataGridViewCellStyle31.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgOIWriteUP.RowsDefaultCellStyle = dataGridViewCellStyle31;
            this.dgOIWriteUP.Size = new System.Drawing.Size(1277, 525);
            this.dgOIWriteUP.TabIndex = 213;
            this.dgOIWriteUP.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgOIWriteUP_CellEnter);
            // 
            // DGOISlNo
            // 
            this.DGOISlNo.DataPropertyName = "GroupID";
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            this.DGOISlNo.DefaultCellStyle = dataGridViewCellStyle27;
            this.DGOISlNo.HeaderText = "S.No";
            this.DGOISlNo.MinimumWidth = 8;
            this.DGOISlNo.Name = "DGOISlNo";
            this.DGOISlNo.ReadOnly = true;
            this.DGOISlNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DGOISlNo.Width = 47;
            // 
            // WUOIProductCode
            // 
            this.WUOIProductCode.DataPropertyName = "ProductCode";
            this.WUOIProductCode.HeaderText = "Product Code";
            this.WUOIProductCode.MinimumWidth = 8;
            this.WUOIProductCode.Name = "WUOIProductCode";
            this.WUOIProductCode.ReadOnly = true;
            this.WUOIProductCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.WUOIProductCode.Visible = false;
            this.WUOIProductCode.Width = 108;
            // 
            // WUOIProductDescription
            // 
            this.WUOIProductDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.WUOIProductDescription.DataPropertyName = "ProductDescription";
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.WUOIProductDescription.DefaultCellStyle = dataGridViewCellStyle28;
            this.WUOIProductDescription.HeaderText = "Description";
            this.WUOIProductDescription.MinimumWidth = 8;
            this.WUOIProductDescription.Name = "WUOIProductDescription";
            this.WUOIProductDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Quantity";
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn6.DefaultCellStyle = dataGridViewCellStyle29;
            this.dataGridViewTextBoxColumn6.HeaderText = "Qty";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn6.Width = 40;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.Silver;
            this.tabPage4.Controls.Add(this.NoOptionalItems);
            this.tabPage4.Controls.Add(this.discountedMMValue);
            this.tabPage4.Controls.Add(this.discountedMMlb);
            this.tabPage4.Controls.Add(this.totalCostLable);
            this.tabPage4.Controls.Add(this.cmbBank);
            this.tabPage4.Controls.Add(this.label83);
            this.tabPage4.Controls.Add(this.txtAdditionalMonths);
            this.tabPage4.Controls.Add(this.chkQuoteSavePath);
            this.tabPage4.Controls.Add(this.btnPreview);
            this.tabPage4.Controls.Add(this.chkConcessionGst);
            this.tabPage4.Controls.Add(this.chkShowPackingForwarding);
            this.tabPage4.Controls.Add(this.pnInstallCommision);
            this.tabPage4.Controls.Add(this.label62);
            this.tabPage4.Controls.Add(this.txtaddNote);
            this.tabPage4.Controls.Add(this.cheSetReminder);
            this.tabPage4.Controls.Add(this.pnAppointment);
            this.tabPage4.Controls.Add(this.label43);
            this.tabPage4.Controls.Add(this.txtadditionalWarPer);
            this.tabPage4.Controls.Add(this.label42);
            this.tabPage4.Controls.Add(this.txtAdditionalwarrantyAmount);
            this.tabPage4.Controls.Add(this.lblServiceIgst);
            this.tabPage4.Controls.Add(this.pnGst);
            this.tabPage4.Controls.Add(this.txtServiceTaxIGSTPercent);
            this.tabPage4.Controls.Add(this.pnIncoterm);
            this.tabPage4.Controls.Add(this.label21);
            this.tabPage4.Controls.Add(this.btnExit);
            this.tabPage4.Controls.Add(this.txtServiceTaxIGSTAmount);
            this.tabPage4.Controls.Add(this.btnGenarateQuote);
            this.tabPage4.Controls.Add(this.btnFinQuote);
            this.tabPage4.Controls.Add(this.btnTechQuote);
            this.tabPage4.Controls.Add(this.label37);
            this.tabPage4.Controls.Add(this.txtaftrerdisount);
            this.tabPage4.Controls.Add(this.cmbPaymentTerms);
            this.tabPage4.Controls.Add(this.label14);
            this.tabPage4.Controls.Add(this.TxtAfterInstal);
            this.tabPage4.Controls.Add(this.label15);
            this.tabPage4.Controls.Add(this.label26);
            this.tabPage4.Controls.Add(this.txtAdvance);
            this.tabPage4.Controls.Add(this.txtAfterPDI);
            this.tabPage4.Controls.Add(this.btnBack3);
            this.tabPage4.Controls.Add(this.label25);
            this.tabPage4.Controls.Add(this.txtBsaicPrice);
            this.tabPage4.Controls.Add(this.label23);
            this.tabPage4.Controls.Add(this.txtInsatallationCommision);
            this.tabPage4.Controls.Add(this.label18);
            this.tabPage4.Controls.Add(this.lblFinalNetAmount);
            this.tabPage4.Controls.Add(this.lblPaymentTerms);
            this.tabPage4.Controls.Add(this.txtFinalNetAmount);
            this.tabPage4.Controls.Add(this.label16);
            this.tabPage4.Controls.Add(this.lblPackingAndForwording);
            this.tabPage4.Controls.Add(this.txtPackingForwarding);
            this.tabPage4.Controls.Add(this.txtDiscAmount);
            this.tabPage4.Controls.Add(this.txtDiscount);
            this.tabPage4.Location = new System.Drawing.Point(4, 5);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1286, 630);
            this.tabPage4.TabIndex = 3;
            // 
            // NoOptionalItems
            // 
            this.NoOptionalItems.AutoSize = true;
            this.NoOptionalItems.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.NoOptionalItems.Location = new System.Drawing.Point(468, 101);
            this.NoOptionalItems.Name = "NoOptionalItems";
            this.NoOptionalItems.Size = new System.Drawing.Size(131, 18);
            this.NoOptionalItems.TabIndex = 222;
            this.NoOptionalItems.Text = "(No Optional Items)";
            // 
            // discountedMMValue
            // 
            this.discountedMMValue.AutoSize = true;
            this.discountedMMValue.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.discountedMMValue.Location = new System.Drawing.Point(591, 83);
            this.discountedMMValue.Name = "discountedMMValue";
            this.discountedMMValue.Size = new System.Drawing.Size(15, 18);
            this.discountedMMValue.TabIndex = 221;
            this.discountedMMValue.Text = "0";
            this.discountedMMValue.Visible = false;
            // 
            // discountedMMlb
            // 
            this.discountedMMlb.AutoSize = true;
            this.discountedMMlb.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.discountedMMlb.Location = new System.Drawing.Point(468, 83);
            this.discountedMMlb.Name = "discountedMMlb";
            this.discountedMMlb.Size = new System.Drawing.Size(114, 18);
            this.discountedMMlb.TabIndex = 220;
            this.discountedMMlb.Text = "Discounted MM :";
            this.discountedMMlb.Visible = false;
            this.discountedMMlb.Click += new System.EventHandler(this.discountedMMlb_Click);
            // 
            // totalCostLable
            // 
            this.totalCostLable.AutoSize = true;
            this.totalCostLable.Location = new System.Drawing.Point(1169, 3);
            this.totalCostLable.Name = "totalCostLable";
            this.totalCostLable.Size = new System.Drawing.Size(13, 13);
            this.totalCostLable.TabIndex = 219;
            this.totalCostLable.Text = "0";
            this.totalCostLable.Visible = false;
            this.totalCostLable.Click += new System.EventHandler(this.totalCostLable_Click);
            // 
            // cmbBank
            // 
            this.cmbBank.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbBank.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbBank.DropDownHeight = 70;
            this.cmbBank.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBank.DropDownWidth = 140;
            this.cmbBank.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbBank.FormattingEnabled = true;
            this.cmbBank.IntegralHeight = false;
            this.cmbBank.Items.AddRange(new object[] {
            "Canara Bank",
            "CITI Bank"});
            this.cmbBank.Location = new System.Drawing.Point(794, 74);
            this.cmbBank.Name = "cmbBank";
            this.cmbBank.Size = new System.Drawing.Size(235, 26);
            this.cmbBank.TabIndex = 217;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label83.ForeColor = System.Drawing.Color.Black;
            this.label83.Location = new System.Drawing.Point(744, 77);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(45, 18);
            this.label83.TabIndex = 218;
            this.label83.Text = "Bank :";
            // 
            // txtAdditionalMonths
            // 
            this.txtAdditionalMonths.BackColor = System.Drawing.Color.White;
            this.txtAdditionalMonths.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtAdditionalMonths.Location = new System.Drawing.Point(257, 221);
            this.txtAdditionalMonths.Name = "txtAdditionalMonths";
            this.txtAdditionalMonths.Size = new System.Drawing.Size(31, 26);
            this.txtAdditionalMonths.TabIndex = 216;
            this.txtAdditionalMonths.Text = "0";
            this.txtAdditionalMonths.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAdditionalMonths_KeyPress);
            this.txtAdditionalMonths.Leave += new System.EventHandler(this.txtAdditionalMonths_Leave);
            // 
            // chkQuoteSavePath
            // 
            this.chkQuoteSavePath.AutoSize = true;
            this.chkQuoteSavePath.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkQuoteSavePath.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.chkQuoteSavePath.Location = new System.Drawing.Point(985, 278);
            this.chkQuoteSavePath.Name = "chkQuoteSavePath";
            this.chkQuoteSavePath.Size = new System.Drawing.Size(213, 27);
            this.chkQuoteSavePath.TabIndex = 214;
            this.chkQuoteSavePath.Text = "Select Quote Save Path";
            this.chkQuoteSavePath.UseVisualStyleBackColor = true;
            this.chkQuoteSavePath.CheckedChanged += new System.EventHandler(this.chkQuoteSavePath_CheckedChanged);
            // 
            // btnPreview
            // 
            this.btnPreview.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnPreview.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPreview.Location = new System.Drawing.Point(198, 570);
            this.btnPreview.Name = "btnPreview";
            this.btnPreview.Size = new System.Drawing.Size(164, 45);
            this.btnPreview.TabIndex = 213;
            this.btnPreview.Text = "Preview Quote";
            this.btnPreview.UseVisualStyleBackColor = false;
            this.btnPreview.Click += new System.EventHandler(this.btnPreview_Click);
            // 
            // chkConcessionGst
            // 
            this.chkConcessionGst.AutoSize = true;
            this.chkConcessionGst.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkConcessionGst.ForeColor = System.Drawing.Color.Black;
            this.chkConcessionGst.Location = new System.Drawing.Point(473, 260);
            this.chkConcessionGst.Name = "chkConcessionGst";
            this.chkConcessionGst.Size = new System.Drawing.Size(133, 23);
            this.chkConcessionGst.TabIndex = 212;
            this.chkConcessionGst.Text = "Concession GST";
            this.chkConcessionGst.UseVisualStyleBackColor = true;
            this.chkConcessionGst.CheckedChanged += new System.EventHandler(this.chkConcessionGst_CheckedChanged);
            // 
            // chkShowPackingForwarding
            // 
            this.chkShowPackingForwarding.AutoSize = true;
            this.chkShowPackingForwarding.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkShowPackingForwarding.ForeColor = System.Drawing.Color.Black;
            this.chkShowPackingForwarding.Location = new System.Drawing.Point(15, 517);
            this.chkShowPackingForwarding.Name = "chkShowPackingForwarding";
            this.chkShowPackingForwarding.Size = new System.Drawing.Size(235, 23);
            this.chkShowPackingForwarding.TabIndex = 211;
            this.chkShowPackingForwarding.Text = "Show Packing and Forwarding";
            this.chkShowPackingForwarding.UseVisualStyleBackColor = true;
            this.chkShowPackingForwarding.Visible = false;
            // 
            // pnInstallCommision
            // 
            this.pnInstallCommision.Controls.Add(this.txtServiceTaxSGSTAmount);
            this.pnInstallCommision.Controls.Add(this.lblServiceSgst);
            this.pnInstallCommision.Controls.Add(this.label63);
            this.pnInstallCommision.Controls.Add(this.txtServiceTaxSGSTPercent);
            this.pnInstallCommision.Location = new System.Drawing.Point(198, 413);
            this.pnInstallCommision.Name = "pnInstallCommision";
            this.pnInstallCommision.Size = new System.Drawing.Size(274, 30);
            this.pnInstallCommision.TabIndex = 210;
            // 
            // txtServiceTaxSGSTAmount
            // 
            this.txtServiceTaxSGSTAmount.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtServiceTaxSGSTAmount.Location = new System.Drawing.Point(114, 1);
            this.txtServiceTaxSGSTAmount.Name = "txtServiceTaxSGSTAmount";
            this.txtServiceTaxSGSTAmount.ReadOnly = true;
            this.txtServiceTaxSGSTAmount.Size = new System.Drawing.Size(152, 26);
            this.txtServiceTaxSGSTAmount.TabIndex = 209;
            this.txtServiceTaxSGSTAmount.Text = "0";
            // 
            // lblServiceSgst
            // 
            this.lblServiceSgst.AutoSize = true;
            this.lblServiceSgst.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.lblServiceSgst.ForeColor = System.Drawing.Color.Black;
            this.lblServiceSgst.Location = new System.Drawing.Point(8, 6);
            this.lblServiceSgst.Name = "lblServiceSgst";
            this.lblServiceSgst.Size = new System.Drawing.Size(46, 18);
            this.lblServiceSgst.TabIndex = 208;
            this.lblServiceSgst.Text = "SGST :";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.ForeColor = System.Drawing.Color.Black;
            this.label63.Location = new System.Drawing.Point(89, 6);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(22, 18);
            this.label63.TabIndex = 207;
            this.label63.Text = "%";
            // 
            // txtServiceTaxSGSTPercent
            // 
            this.txtServiceTaxSGSTPercent.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.txtServiceTaxSGSTPercent.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtServiceTaxSGSTPercent.Location = new System.Drawing.Point(58, 2);
            this.txtServiceTaxSGSTPercent.Name = "txtServiceTaxSGSTPercent";
            this.txtServiceTaxSGSTPercent.ReadOnly = true;
            this.txtServiceTaxSGSTPercent.Size = new System.Drawing.Size(32, 26);
            this.txtServiceTaxSGSTPercent.TabIndex = 206;
            this.txtServiceTaxSGSTPercent.Text = "9";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label62.ForeColor = System.Drawing.Color.Black;
            this.label62.Location = new System.Drawing.Point(715, 114);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(74, 18);
            this.label62.TabIndex = 204;
            this.label62.Text = "Add Note :";
            // 
            // txtaddNote
            // 
            this.txtaddNote.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtaddNote.Location = new System.Drawing.Point(795, 111);
            this.txtaddNote.Multiline = true;
            this.txtaddNote.Name = "txtaddNote";
            this.txtaddNote.Size = new System.Drawing.Size(403, 167);
            this.txtaddNote.TabIndex = 205;
            // 
            // cheSetReminder
            // 
            this.cheSetReminder.AutoSize = true;
            this.cheSetReminder.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cheSetReminder.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.cheSetReminder.Location = new System.Drawing.Point(795, 278);
            this.cheSetReminder.Name = "cheSetReminder";
            this.cheSetReminder.Size = new System.Drawing.Size(137, 27);
            this.cheSetReminder.TabIndex = 203;
            this.cheSetReminder.Text = "Set Reminder";
            this.cheSetReminder.UseVisualStyleBackColor = true;
            this.cheSetReminder.CheckedChanged += new System.EventHandler(this.cheSetReminder_CheckedChanged);
            // 
            // pnAppointment
            // 
            this.pnAppointment.Controls.Add(this.txtLocation);
            this.pnAppointment.Controls.Add(this.label52);
            this.pnAppointment.Controls.Add(this.txtBody);
            this.pnAppointment.Controls.Add(this.label51);
            this.pnAppointment.Controls.Add(this.txtSubject);
            this.pnAppointment.Controls.Add(this.label50);
            this.pnAppointment.Controls.Add(this.dtpEndDate);
            this.pnAppointment.Controls.Add(this.label49);
            this.pnAppointment.Controls.Add(this.dtpFromDate);
            this.pnAppointment.Controls.Add(this.label48);
            this.pnAppointment.Location = new System.Drawing.Point(728, 308);
            this.pnAppointment.Name = "pnAppointment";
            this.pnAppointment.Size = new System.Drawing.Size(502, 210);
            this.pnAppointment.TabIndex = 202;
            this.pnAppointment.Visible = false;
            // 
            // txtLocation
            // 
            this.txtLocation.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtLocation.Location = new System.Drawing.Point(75, 93);
            this.txtLocation.Name = "txtLocation";
            this.txtLocation.Size = new System.Drawing.Size(403, 26);
            this.txtLocation.TabIndex = 203;
            this.txtLocation.WordWrap = false;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label52.ForeColor = System.Drawing.Color.Black;
            this.label52.Location = new System.Drawing.Point(7, 96);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(67, 18);
            this.label52.TabIndex = 202;
            this.label52.Text = "Location :";
            // 
            // txtBody
            // 
            this.txtBody.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtBody.Location = new System.Drawing.Point(75, 132);
            this.txtBody.Multiline = true;
            this.txtBody.Name = "txtBody";
            this.txtBody.Size = new System.Drawing.Size(403, 69);
            this.txtBody.TabIndex = 113;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label51.ForeColor = System.Drawing.Color.Black;
            this.label51.Location = new System.Drawing.Point(28, 135);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(46, 18);
            this.label51.TabIndex = 112;
            this.label51.Text = "Body :";
            // 
            // txtSubject
            // 
            this.txtSubject.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtSubject.Location = new System.Drawing.Point(75, 43);
            this.txtSubject.Multiline = true;
            this.txtSubject.Name = "txtSubject";
            this.txtSubject.Size = new System.Drawing.Size(403, 37);
            this.txtSubject.TabIndex = 111;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label50.ForeColor = System.Drawing.Color.Black;
            this.label50.Location = new System.Drawing.Point(13, 46);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(61, 18);
            this.label50.TabIndex = 110;
            this.label50.Text = "Subject :";
            // 
            // dtpEndDate
            // 
            this.dtpEndDate.CustomFormat = "";
            this.dtpEndDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpEndDate.Location = new System.Drawing.Point(296, 6);
            this.dtpEndDate.MaxDate = new System.DateTime(2028, 12, 31, 0, 0, 0, 0);
            this.dtpEndDate.MinDate = new System.DateTime(2017, 1, 1, 0, 0, 0, 0);
            this.dtpEndDate.Name = "dtpEndDate";
            this.dtpEndDate.Size = new System.Drawing.Size(182, 26);
            this.dtpEndDate.TabIndex = 109;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.ForeColor = System.Drawing.Color.Black;
            this.label49.Location = new System.Drawing.Point(262, 12);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(38, 18);
            this.label49.TabIndex = 108;
            this.label49.Text = "End :";
            // 
            // dtpFromDate
            // 
            this.dtpFromDate.CustomFormat = "";
            this.dtpFromDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFromDate.Location = new System.Drawing.Point(75, 6);
            this.dtpFromDate.MaxDate = new System.DateTime(2028, 12, 31, 0, 0, 0, 0);
            this.dtpFromDate.MinDate = new System.DateTime(2017, 1, 1, 0, 0, 0, 0);
            this.dtpFromDate.Name = "dtpFromDate";
            this.dtpFromDate.Size = new System.Drawing.Size(182, 26);
            this.dtpFromDate.TabIndex = 107;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.ForeColor = System.Drawing.Color.Black;
            this.label48.Location = new System.Drawing.Point(30, 12);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(44, 18);
            this.label48.TabIndex = 106;
            this.label48.Text = "Start :";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.Color.Black;
            this.label43.Location = new System.Drawing.Point(342, 224);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(22, 18);
            this.label43.TabIndex = 200;
            this.label43.Text = "%";
            // 
            // txtadditionalWarPer
            // 
            this.txtadditionalWarPer.BackColor = System.Drawing.Color.White;
            this.txtadditionalWarPer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtadditionalWarPer.Location = new System.Drawing.Point(294, 221);
            this.txtadditionalWarPer.Name = "txtadditionalWarPer";
            this.txtadditionalWarPer.Size = new System.Drawing.Size(47, 26);
            this.txtadditionalWarPer.TabIndex = 199;
            this.txtadditionalWarPer.Text = "0";
            this.txtadditionalWarPer.TextChanged += new System.EventHandler(this.txtadditionalWarPer_TextChanged);
            this.txtadditionalWarPer.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtadditionalWarPer_KeyPress);
            this.txtadditionalWarPer.Leave += new System.EventHandler(this.txtadditionalWarPer_Leave);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.Color.Black;
            this.label42.Location = new System.Drawing.Point(47, 216);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(202, 36);
            this.label42.TabIndex = 198;
            this.label42.Text = "Additional Warranty in Months \r\nand Amount in Percent :";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtAdditionalwarrantyAmount
            // 
            this.txtAdditionalwarrantyAmount.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtAdditionalwarrantyAmount.Location = new System.Drawing.Point(367, 222);
            this.txtAdditionalwarrantyAmount.Name = "txtAdditionalwarrantyAmount";
            this.txtAdditionalwarrantyAmount.ReadOnly = true;
            this.txtAdditionalwarrantyAmount.Size = new System.Drawing.Size(105, 26);
            this.txtAdditionalwarrantyAmount.TabIndex = 197;
            this.txtAdditionalwarrantyAmount.Text = "0";
            // 
            // lblServiceIgst
            // 
            this.lblServiceIgst.AutoSize = true;
            this.lblServiceIgst.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.lblServiceIgst.ForeColor = System.Drawing.Color.Black;
            this.lblServiceIgst.Location = new System.Drawing.Point(206, 375);
            this.lblServiceIgst.Name = "lblServiceIgst";
            this.lblServiceIgst.Size = new System.Drawing.Size(43, 18);
            this.lblServiceIgst.TabIndex = 166;
            this.lblServiceIgst.Text = "IGST :";
            // 
            // pnGst
            // 
            this.pnGst.Controls.Add(this.lblIgst);
            this.pnGst.Controls.Add(this.txtIGSTPer);
            this.pnGst.Controls.Add(this.label39);
            this.pnGst.Controls.Add(this.txtIGSTAmount);
            this.pnGst.Controls.Add(this.txtSgstPer);
            this.pnGst.Controls.Add(this.label41);
            this.pnGst.Controls.Add(this.txtSGSTAmount);
            this.pnGst.Controls.Add(this.lblSGST);
            this.pnGst.Location = new System.Drawing.Point(190, 255);
            this.pnGst.Name = "pnGst";
            this.pnGst.Size = new System.Drawing.Size(277, 70);
            this.pnGst.TabIndex = 196;
            // 
            // lblIgst
            // 
            this.lblIgst.AutoSize = true;
            this.lblIgst.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.lblIgst.ForeColor = System.Drawing.Color.Black;
            this.lblIgst.Location = new System.Drawing.Point(11, 9);
            this.lblIgst.Name = "lblIgst";
            this.lblIgst.Size = new System.Drawing.Size(47, 18);
            this.lblIgst.TabIndex = 184;
            this.lblIgst.Text = "CGST :";
            // 
            // txtIGSTPer
            // 
            this.txtIGSTPer.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.txtIGSTPer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtIGSTPer.Location = new System.Drawing.Point(61, 5);
            this.txtIGSTPer.Name = "txtIGSTPer";
            this.txtIGSTPer.ReadOnly = true;
            this.txtIGSTPer.Size = new System.Drawing.Size(33, 26);
            this.txtIGSTPer.TabIndex = 182;
            this.txtIGSTPer.Text = "9";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.Black;
            this.label39.Location = new System.Drawing.Point(93, 9);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(22, 18);
            this.label39.TabIndex = 183;
            this.label39.Text = "%";
            // 
            // txtIGSTAmount
            // 
            this.txtIGSTAmount.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtIGSTAmount.Location = new System.Drawing.Point(114, 5);
            this.txtIGSTAmount.Name = "txtIGSTAmount";
            this.txtIGSTAmount.ReadOnly = true;
            this.txtIGSTAmount.Size = new System.Drawing.Size(155, 26);
            this.txtIGSTAmount.TabIndex = 185;
            this.txtIGSTAmount.Text = "0";
            // 
            // txtSgstPer
            // 
            this.txtSgstPer.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.txtSgstPer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtSgstPer.Location = new System.Drawing.Point(61, 37);
            this.txtSgstPer.Name = "txtSgstPer";
            this.txtSgstPer.ReadOnly = true;
            this.txtSgstPer.Size = new System.Drawing.Size(33, 26);
            this.txtSgstPer.TabIndex = 186;
            this.txtSgstPer.Text = "9";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.Color.Black;
            this.label41.Location = new System.Drawing.Point(93, 42);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(22, 18);
            this.label41.TabIndex = 187;
            this.label41.Text = "%";
            // 
            // txtSGSTAmount
            // 
            this.txtSGSTAmount.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtSGSTAmount.Location = new System.Drawing.Point(114, 38);
            this.txtSGSTAmount.Name = "txtSGSTAmount";
            this.txtSGSTAmount.ReadOnly = true;
            this.txtSGSTAmount.Size = new System.Drawing.Size(155, 26);
            this.txtSGSTAmount.TabIndex = 189;
            this.txtSGSTAmount.Text = "0";
            // 
            // lblSGST
            // 
            this.lblSGST.AutoSize = true;
            this.lblSGST.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.lblSGST.ForeColor = System.Drawing.Color.Black;
            this.lblSGST.Location = new System.Drawing.Point(12, 40);
            this.lblSGST.Name = "lblSGST";
            this.lblSGST.Size = new System.Drawing.Size(46, 18);
            this.lblSGST.TabIndex = 188;
            this.lblSGST.Text = "SGST :";
            // 
            // txtServiceTaxIGSTPercent
            // 
            this.txtServiceTaxIGSTPercent.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.txtServiceTaxIGSTPercent.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtServiceTaxIGSTPercent.Location = new System.Drawing.Point(256, 375);
            this.txtServiceTaxIGSTPercent.Name = "txtServiceTaxIGSTPercent";
            this.txtServiceTaxIGSTPercent.ReadOnly = true;
            this.txtServiceTaxIGSTPercent.Size = new System.Drawing.Size(32, 26);
            this.txtServiceTaxIGSTPercent.TabIndex = 163;
            this.txtServiceTaxIGSTPercent.Text = "18";
            // 
            // pnIncoterm
            // 
            this.pnIncoterm.Controls.Add(this.txtFreight);
            this.pnIncoterm.Controls.Add(this.txtInsurance);
            this.pnIncoterm.Controls.Add(this.label19);
            this.pnIncoterm.Controls.Add(this.label20);
            this.pnIncoterm.Enabled = false;
            this.pnIncoterm.Location = new System.Drawing.Point(171, 146);
            this.pnIncoterm.Name = "pnIncoterm";
            this.pnIncoterm.Size = new System.Drawing.Size(301, 68);
            this.pnIncoterm.TabIndex = 194;
            // 
            // txtFreight
            // 
            this.txtFreight.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtFreight.Location = new System.Drawing.Point(86, 3);
            this.txtFreight.Name = "txtFreight";
            this.txtFreight.Size = new System.Drawing.Size(207, 26);
            this.txtFreight.TabIndex = 137;
            this.txtFreight.Text = "0";
            this.txtFreight.TextChanged += new System.EventHandler(this.txtFreight_TextChanged);
            this.txtFreight.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFreight_KeyPress);
            this.txtFreight.Leave += new System.EventHandler(this.txtFreight_Leave);
            // 
            // txtInsurance
            // 
            this.txtInsurance.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtInsurance.Location = new System.Drawing.Point(86, 38);
            this.txtInsurance.Name = "txtInsurance";
            this.txtInsurance.Size = new System.Drawing.Size(207, 26);
            this.txtInsurance.TabIndex = 135;
            this.txtInsurance.Text = "0";
            this.txtInsurance.TextChanged += new System.EventHandler(this.txtInsurance_TextChanged);
            this.txtInsurance.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtInsurance_KeyPress);
            this.txtInsurance.Leave += new System.EventHandler(this.txtInsurance_Leave);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(2, 41);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(75, 18);
            this.label19.TabIndex = 158;
            this.label19.Text = "Insurance :";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(19, 6);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(59, 18);
            this.label20.TabIndex = 159;
            this.label20.Text = "Freight :";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(289, 378);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(22, 18);
            this.label21.TabIndex = 165;
            this.label21.Text = "%";
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(1106, 570);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(124, 45);
            this.btnExit.TabIndex = 193;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // txtServiceTaxIGSTAmount
            // 
            this.txtServiceTaxIGSTAmount.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtServiceTaxIGSTAmount.Location = new System.Drawing.Point(312, 375);
            this.txtServiceTaxIGSTAmount.Name = "txtServiceTaxIGSTAmount";
            this.txtServiceTaxIGSTAmount.ReadOnly = true;
            this.txtServiceTaxIGSTAmount.Size = new System.Drawing.Size(152, 26);
            this.txtServiceTaxIGSTAmount.TabIndex = 167;
            this.txtServiceTaxIGSTAmount.Text = "0";
            // 
            // btnGenarateQuote
            // 
            this.btnGenarateQuote.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnGenarateQuote.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenarateQuote.Location = new System.Drawing.Point(422, 570);
            this.btnGenarateQuote.Name = "btnGenarateQuote";
            this.btnGenarateQuote.Size = new System.Drawing.Size(164, 45);
            this.btnGenarateQuote.TabIndex = 192;
            this.btnGenarateQuote.Text = "Generate Quote";
            this.btnGenarateQuote.UseVisualStyleBackColor = false;
            this.btnGenarateQuote.Click += new System.EventHandler(this.btnGenarateQuote_Click);
            // 
            // btnFinQuote
            // 
            this.btnFinQuote.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnFinQuote.Enabled = false;
            this.btnFinQuote.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFinQuote.Location = new System.Drawing.Point(871, 570);
            this.btnFinQuote.Name = "btnFinQuote";
            this.btnFinQuote.Size = new System.Drawing.Size(157, 45);
            this.btnFinQuote.TabIndex = 191;
            this.btnFinQuote.Text = "Financial Quote";
            this.btnFinQuote.UseVisualStyleBackColor = false;
            this.btnFinQuote.Click += new System.EventHandler(this.btnFinQuote_Click);
            // 
            // btnTechQuote
            // 
            this.btnTechQuote.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnTechQuote.Enabled = false;
            this.btnTechQuote.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTechQuote.Location = new System.Drawing.Point(649, 570);
            this.btnTechQuote.Name = "btnTechQuote";
            this.btnTechQuote.Size = new System.Drawing.Size(163, 45);
            this.btnTechQuote.TabIndex = 190;
            this.btnTechQuote.Text = "Technical Quote";
            this.btnTechQuote.UseVisualStyleBackColor = false;
            this.btnTechQuote.Click += new System.EventHandler(this.btnTechQuote_Click);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.Color.Black;
            this.label37.Location = new System.Drawing.Point(95, 83);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(153, 18);
            this.label37.TabIndex = 180;
            this.label37.Text = "Discounted Basic Price :";
            // 
            // txtaftrerdisount
            // 
            this.txtaftrerdisount.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtaftrerdisount.Location = new System.Drawing.Point(257, 80);
            this.txtaftrerdisount.Name = "txtaftrerdisount";
            this.txtaftrerdisount.ReadOnly = true;
            this.txtaftrerdisount.Size = new System.Drawing.Size(207, 26);
            this.txtaftrerdisount.TabIndex = 179;
            this.txtaftrerdisount.Text = "0";
            // 
            // cmbPaymentTerms
            // 
            this.cmbPaymentTerms.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbPaymentTerms.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbPaymentTerms.DropDownHeight = 130;
            this.cmbPaymentTerms.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPaymentTerms.DropDownWidth = 279;
            this.cmbPaymentTerms.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPaymentTerms.FormattingEnabled = true;
            this.cmbPaymentTerms.IntegralHeight = false;
            this.cmbPaymentTerms.Items.AddRange(new object[] {
            "Advance",
            "On Delivery",
            "Letter of Credit",
            "Others"});
            this.cmbPaymentTerms.Location = new System.Drawing.Point(794, 15);
            this.cmbPaymentTerms.Name = "cmbPaymentTerms";
            this.cmbPaymentTerms.Size = new System.Drawing.Size(235, 26);
            this.cmbPaymentTerms.TabIndex = 177;
            this.cmbPaymentTerms.SelectedIndexChanged += new System.EventHandler(this.cmbPaymentTerms_SelectedIndexChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(1009, 48);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(22, 18);
            this.label14.TabIndex = 176;
            this.label14.Text = "%";
            // 
            // TxtAfterInstal
            // 
            this.TxtAfterInstal.BackColor = System.Drawing.Color.White;
            this.TxtAfterInstal.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.TxtAfterInstal.Location = new System.Drawing.Point(960, 43);
            this.TxtAfterInstal.Name = "TxtAfterInstal";
            this.TxtAfterInstal.Size = new System.Drawing.Size(47, 26);
            this.TxtAfterInstal.TabIndex = 175;
            this.TxtAfterInstal.Text = "0";
            this.TxtAfterInstal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtAfterInstal_KeyPress);
            this.TxtAfterInstal.Leave += new System.EventHandler(this.TxtAfterInstal_Leave);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(842, 48);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(22, 18);
            this.label15.TabIndex = 174;
            this.label15.Text = "%";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.Black;
            this.label26.Location = new System.Drawing.Point(927, 48);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(22, 18);
            this.label26.TabIndex = 173;
            this.label26.Text = "%";
            // 
            // txtAdvance
            // 
            this.txtAdvance.BackColor = System.Drawing.Color.White;
            this.txtAdvance.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtAdvance.Location = new System.Drawing.Point(794, 43);
            this.txtAdvance.Name = "txtAdvance";
            this.txtAdvance.Size = new System.Drawing.Size(47, 26);
            this.txtAdvance.TabIndex = 171;
            this.txtAdvance.Text = "0";
            this.txtAdvance.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAdvance_KeyPress);
            this.txtAdvance.Leave += new System.EventHandler(this.txtAdvance_Leave);
            // 
            // txtAfterPDI
            // 
            this.txtAfterPDI.BackColor = System.Drawing.Color.White;
            this.txtAfterPDI.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtAfterPDI.Location = new System.Drawing.Point(879, 42);
            this.txtAfterPDI.Name = "txtAfterPDI";
            this.txtAfterPDI.Size = new System.Drawing.Size(47, 26);
            this.txtAfterPDI.TabIndex = 172;
            this.txtAfterPDI.Text = "0";
            this.txtAfterPDI.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAfterPDI_KeyPress);
            this.txtAfterPDI.Leave += new System.EventHandler(this.txtAfterPDI_Leave);
            // 
            // btnBack3
            // 
            this.btnBack3.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnBack3.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnBack3.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack3.Location = new System.Drawing.Point(6, 570);
            this.btnBack3.Name = "btnBack3";
            this.btnBack3.Size = new System.Drawing.Size(124, 45);
            this.btnBack3.TabIndex = 170;
            this.btnBack3.Text = "Back";
            this.btnBack3.UseVisualStyleBackColor = false;
            this.btnBack3.Click += new System.EventHandler(this.btnBack3_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(78, 15);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(170, 18);
            this.label25.TabIndex = 169;
            this.label25.Text = "Basic Price of The System :";
            // 
            // txtBsaicPrice
            // 
            this.txtBsaicPrice.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtBsaicPrice.Location = new System.Drawing.Point(257, 12);
            this.txtBsaicPrice.Name = "txtBsaicPrice";
            this.txtBsaicPrice.ReadOnly = true;
            this.txtBsaicPrice.Size = new System.Drawing.Size(207, 26);
            this.txtBsaicPrice.TabIndex = 168;
            this.txtBsaicPrice.Text = "0";
            this.txtBsaicPrice.TextChanged += new System.EventHandler(this.txtBsaicPrice_TextChanged);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label23.ForeColor = System.Drawing.Color.Black;
            this.label23.Location = new System.Drawing.Point(41, 341);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(209, 18);
            this.label23.TabIndex = 162;
            this.label23.Text = "Installation and Commissioning :";
            // 
            // txtInsatallationCommision
            // 
            this.txtInsatallationCommision.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtInsatallationCommision.Location = new System.Drawing.Point(256, 339);
            this.txtInsatallationCommision.Name = "txtInsatallationCommision";
            this.txtInsatallationCommision.Size = new System.Drawing.Size(208, 26);
            this.txtInsatallationCommision.TabIndex = 164;
            this.txtInsatallationCommision.Text = "0";
            this.txtInsatallationCommision.TextChanged += new System.EventHandler(this.txtInsatallationCommision_TextChanged);
            this.txtInsatallationCommision.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtInsatallationCommision_KeyPress);
            this.txtInsatallationCommision.Leave += new System.EventHandler(this.txtInsatallationCommision_Leave);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(112, 118);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(139, 18);
            this.label18.TabIndex = 157;
            this.label18.Text = "Packing, Forwarding :";
            // 
            // lblFinalNetAmount
            // 
            this.lblFinalNetAmount.AutoSize = true;
            this.lblFinalNetAmount.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinalNetAmount.ForeColor = System.Drawing.Color.Black;
            this.lblFinalNetAmount.Location = new System.Drawing.Point(59, 476);
            this.lblFinalNetAmount.Name = "lblFinalNetAmount";
            this.lblFinalNetAmount.Size = new System.Drawing.Size(217, 26);
            this.lblFinalNetAmount.TabIndex = 149;
            this.lblFinalNetAmount.Text = "                     Total Price :";
            this.lblFinalNetAmount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblPaymentTerms
            // 
            this.lblPaymentTerms.AutoSize = true;
            this.lblPaymentTerms.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPaymentTerms.ForeColor = System.Drawing.Color.Black;
            this.lblPaymentTerms.Location = new System.Drawing.Point(671, 17);
            this.lblPaymentTerms.Name = "lblPaymentTerms";
            this.lblPaymentTerms.Size = new System.Drawing.Size(118, 19);
            this.lblPaymentTerms.TabIndex = 151;
            this.lblPaymentTerms.Text = "Payment Terms:";
            // 
            // txtFinalNetAmount
            // 
            this.txtFinalNetAmount.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.txtFinalNetAmount.Enabled = false;
            this.txtFinalNetAmount.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold);
            this.txtFinalNetAmount.Location = new System.Drawing.Point(269, 473);
            this.txtFinalNetAmount.Name = "txtFinalNetAmount";
            this.txtFinalNetAmount.Size = new System.Drawing.Size(203, 33);
            this.txtFinalNetAmount.TabIndex = 150;
            this.txtFinalNetAmount.Text = "0";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(289, 51);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(22, 18);
            this.label16.TabIndex = 145;
            this.label16.Text = "%";
            // 
            // lblPackingAndForwording
            // 
            this.lblPackingAndForwording.AutoSize = true;
            this.lblPackingAndForwording.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.lblPackingAndForwording.ForeColor = System.Drawing.Color.Black;
            this.lblPackingAndForwording.Location = new System.Drawing.Point(179, 49);
            this.lblPackingAndForwording.Name = "lblPackingAndForwording";
            this.lblPackingAndForwording.Size = new System.Drawing.Size(69, 18);
            this.lblPackingAndForwording.TabIndex = 123;
            this.lblPackingAndForwording.Text = "Discount :";
            // 
            // txtPackingForwarding
            // 
            this.txtPackingForwarding.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtPackingForwarding.Location = new System.Drawing.Point(257, 115);
            this.txtPackingForwarding.Name = "txtPackingForwarding";
            this.txtPackingForwarding.Size = new System.Drawing.Size(207, 26);
            this.txtPackingForwarding.TabIndex = 132;
            this.txtPackingForwarding.Text = "0";
            this.txtPackingForwarding.WordWrap = false;
            this.txtPackingForwarding.TextChanged += new System.EventHandler(this.txtPackingForwarding_TextChanged);
            this.txtPackingForwarding.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPackingForwarding_KeyPress);
            this.txtPackingForwarding.Leave += new System.EventHandler(this.txtPackingForwarding_Leave);
            // 
            // txtDiscAmount
            // 
            this.txtDiscAmount.Enabled = false;
            this.txtDiscAmount.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtDiscAmount.Location = new System.Drawing.Point(311, 47);
            this.txtDiscAmount.Name = "txtDiscAmount";
            this.txtDiscAmount.Size = new System.Drawing.Size(153, 26);
            this.txtDiscAmount.TabIndex = 142;
            this.txtDiscAmount.Text = "0";
            // 
            // txtDiscount
            // 
            this.txtDiscount.BackColor = System.Drawing.Color.White;
            this.txtDiscount.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtDiscount.Location = new System.Drawing.Point(257, 47);
            this.txtDiscount.Name = "txtDiscount";
            this.txtDiscount.Size = new System.Drawing.Size(32, 26);
            this.txtDiscount.TabIndex = 138;
            this.txtDiscount.Text = "0";
            this.txtDiscount.TextChanged += new System.EventHandler(this.txtDiscount_TextChanged);
            this.txtDiscount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDiscount_KeyPress);
            this.txtDiscount.Leave += new System.EventHandler(this.txtDiscount_Leave);
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblPrice.Location = new System.Drawing.Point(944, 13);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(0, 26);
            this.lblPrice.TabIndex = 195;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // cmbQuotationNumber
            // 
            this.cmbQuotationNumber.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbQuotationNumber.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbQuotationNumber.DropDownHeight = 90;
            this.cmbQuotationNumber.DropDownWidth = 150;
            this.cmbQuotationNumber.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbQuotationNumber.FormattingEnabled = true;
            this.cmbQuotationNumber.IntegralHeight = false;
            this.cmbQuotationNumber.Location = new System.Drawing.Point(135, 8);
            this.cmbQuotationNumber.Name = "cmbQuotationNumber";
            this.cmbQuotationNumber.Size = new System.Drawing.Size(163, 26);
            this.cmbQuotationNumber.TabIndex = 181;
            this.cmbQuotationNumber.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.Black;
            this.label35.Location = new System.Drawing.Point(14, 9);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(116, 19);
            this.label35.TabIndex = 180;
            this.label35.Text = "Quotaton No* :";
            // 
            // pnQuotationNumber
            // 
            this.pnQuotationNumber.BackColor = System.Drawing.Color.Silver;
            this.pnQuotationNumber.Controls.Add(this.cmbRevisionNumber);
            this.pnQuotationNumber.Controls.Add(this.label36);
            this.pnQuotationNumber.Controls.Add(this.label35);
            this.pnQuotationNumber.Controls.Add(this.cmbQuotationNumber);
            this.pnQuotationNumber.Location = new System.Drawing.Point(295, 8);
            this.pnQuotationNumber.Name = "pnQuotationNumber";
            this.pnQuotationNumber.Size = new System.Drawing.Size(467, 46);
            this.pnQuotationNumber.TabIndex = 201;
            this.pnQuotationNumber.Visible = false;
            // 
            // cmbRevisionNumber
            // 
            this.cmbRevisionNumber.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbRevisionNumber.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRevisionNumber.DropDownHeight = 90;
            this.cmbRevisionNumber.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRevisionNumber.DropDownWidth = 70;
            this.cmbRevisionNumber.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbRevisionNumber.FormattingEnabled = true;
            this.cmbRevisionNumber.IntegralHeight = false;
            this.cmbRevisionNumber.Location = new System.Drawing.Point(406, 10);
            this.cmbRevisionNumber.Name = "cmbRevisionNumber";
            this.cmbRevisionNumber.Size = new System.Drawing.Size(52, 26);
            this.cmbRevisionNumber.TabIndex = 192;
            this.cmbRevisionNumber.SelectedIndexChanged += new System.EventHandler(this.cmbRevisionNumber_SelectedIndexChanged);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.label36.ForeColor = System.Drawing.Color.Black;
            this.label36.Location = new System.Drawing.Point(304, 11);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(96, 23);
            this.label36.TabIndex = 191;
            this.label36.Text = "Revision *:";
            // 
            // btnViewQuotes
            // 
            this.btnViewQuotes.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnViewQuotes.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewQuotes.Location = new System.Drawing.Point(1163, 16);
            this.btnViewQuotes.Name = "btnViewQuotes";
            this.btnViewQuotes.Size = new System.Drawing.Size(131, 36);
            this.btnViewQuotes.TabIndex = 206;
            this.btnViewQuotes.Text = "View Quotes";
            this.btnViewQuotes.UseVisualStyleBackColor = false;
            this.btnViewQuotes.Click += new System.EventHandler(this.btnViewQuotes_Click);
            // 
            // cmbSelectQuoteType
            // 
            this.cmbSelectQuoteType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbSelectQuoteType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectQuoteType.DropDownHeight = 90;
            this.cmbSelectQuoteType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSelectQuoteType.DropDownWidth = 150;
            this.cmbSelectQuoteType.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSelectQuoteType.FormattingEnabled = true;
            this.cmbSelectQuoteType.IntegralHeight = false;
            this.cmbSelectQuoteType.Location = new System.Drawing.Point(114, 14);
            this.cmbSelectQuoteType.Name = "cmbSelectQuoteType";
            this.cmbSelectQuoteType.Size = new System.Drawing.Size(175, 26);
            this.cmbSelectQuoteType.TabIndex = 207;
            this.cmbSelectQuoteType.SelectedIndexChanged += new System.EventHandler(this.cmbSelectQuoteType_SelectedIndexChanged);
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.ForeColor = System.Drawing.Color.Black;
            this.label81.Location = new System.Drawing.Point(10, 14);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(98, 19);
            this.label81.TabIndex = 208;
            this.label81.Text = "Start Quote :";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label82.ForeColor = System.Drawing.Color.Black;
            this.label82.Location = new System.Drawing.Point(762, 20);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(102, 19);
            this.label82.TabIndex = 209;
            this.label82.Text = "Enquiry No* :";
            // 
            // txtEnquiryNumber
            // 
            this.txtEnquiryNumber.Enabled = false;
            this.txtEnquiryNumber.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtEnquiryNumber.Location = new System.Drawing.Point(862, 17);
            this.txtEnquiryNumber.Name = "txtEnquiryNumber";
            this.txtEnquiryNumber.Size = new System.Drawing.Size(111, 26);
            this.txtEnquiryNumber.TabIndex = 210;
            // 
            // frmSalesQuote
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1313, 704);
            this.Controls.Add(this.txtEnquiryNumber);
            this.Controls.Add(this.label82);
            this.Controls.Add(this.label81);
            this.Controls.Add(this.cmbSelectQuoteType);
            this.Controls.Add(this.btnViewQuotes);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.pnQuotationNumber);
            this.Controls.Add(this.lblPrice);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmSalesQuote";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quote GEN";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmSalesQuote_FormClosing);
            this.Load += new System.EventHandler(this.frmSalesQuote_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.pnAddProduct.ResumeLayout(false);
            this.pnAddProduct.PerformLayout();
            this.pnOptionalItems.ResumeLayout(false);
            this.pnOptionalItems.PerformLayout();
            this.pnQuoteMaster.ResumeLayout(false);
            this.pnQuoteMaster.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgQuoteBOM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOptionalItems)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgWriteUP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgOIWriteUP)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.pnInstallCommision.ResumeLayout(false);
            this.pnInstallCommision.PerformLayout();
            this.pnAppointment.ResumeLayout(false);
            this.pnAppointment.PerformLayout();
            this.pnGst.ResumeLayout(false);
            this.pnGst.PerformLayout();
            this.pnIncoterm.ResumeLayout(false);
            this.pnIncoterm.PerformLayout();
            this.pnQuotationNumber.ResumeLayout(false);
            this.pnQuotationNumber.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblcustomer;
        private System.Windows.Forms.ComboBox cmbEnquireCurrency;
        private System.Windows.Forms.ComboBox cmbCustomer;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbQuotationfor;
        private System.Windows.Forms.ComboBox cmbRegion;
        private System.Windows.Forms.Label lblregion;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCustomertype;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtContactPerson1;
        private System.Windows.Forms.TextBox txtContactNumber1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker dtpEnquireDate;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cmbModel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cmbCapacity;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dgQuoteBOM;
        private System.Windows.Forms.Button btnStartQuote;
        private System.Windows.Forms.TreeView tvProduct;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button cleartreeview;
        private System.Windows.Forms.TextBox txtsearchtree;
        private System.Windows.Forms.Button btnsearchtree;
        private System.Windows.Forms.Button btnQuoteTreeSave;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btngotoquote;
        private System.Windows.Forms.DataGridView dgWriteUP;
        private System.Windows.Forms.Button btnQuotePricing;
        private System.Windows.Forms.Button btnBack1;
        private System.Windows.Forms.Button btnBack2;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtTenderNo;
        private System.Windows.Forms.TextBox txtDepartment1;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtLeadTime;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtQuoteWarranty;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtQuoteValidity;
        private System.Windows.Forms.Label lblDeliveryTerms;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.ComboBox cmbPaymentTerms;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox TxtAfterInstal;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtAdvance;
        private System.Windows.Forms.TextBox txtAfterPDI;
        private System.Windows.Forms.Button btnBack3;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtBsaicPrice;
        private System.Windows.Forms.TextBox txtServiceTaxIGSTAmount;
        private System.Windows.Forms.Label lblServiceIgst;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtInsatallationCommision;
        private System.Windows.Forms.TextBox txtServiceTaxIGSTPercent;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lblFinalNetAmount;
        private System.Windows.Forms.Label lblPaymentTerms;
        private System.Windows.Forms.TextBox txtFinalNetAmount;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lblPackingAndForwording;
        private System.Windows.Forms.TextBox txtPackingForwarding;
        private System.Windows.Forms.TextBox txtInsurance;
        private System.Windows.Forms.TextBox txtFreight;
        private System.Windows.Forms.TextBox txtDiscAmount;
        private System.Windows.Forms.TextBox txtDiscount;
        private System.Windows.Forms.ComboBox cmbLeadGenarated;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txtaftrerdisount;
        private System.Windows.Forms.TextBox txtSGSTAmount;
        private System.Windows.Forms.Label lblSGST;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox txtSgstPer;
        private System.Windows.Forms.TextBox txtIGSTAmount;
        private System.Windows.Forms.Label lblIgst;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txtIGSTPer;
        private System.Windows.Forms.CheckBox chkintrastate;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnGenarateQuote;
        private System.Windows.Forms.Button btnFinQuote;
        private System.Windows.Forms.Button btnTechQuote;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox txtQuoteName;
        private System.Windows.Forms.TextBox txtEmailID1;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Panel pnIncoterm;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Panel pnGst;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox txtadditionalWarPer;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox txtAdditionalwarrantyAmount;
        private System.Windows.Forms.TextBox txtQuoteRemain;
        private System.Windows.Forms.TextBox txtQuoteBreak;
        private System.Windows.Forms.TextBox txtQuoteJack;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TreeView tvQuoteProduct;
        private System.Windows.Forms.ImageList imageList2;
        private System.Windows.Forms.TextBox txtModelNumber;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox txtCusCode;
        private System.Windows.Forms.Panel pnAppointment;
        private System.Windows.Forms.DateTimePicker dtpFromDate;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.DateTimePicker dtpEndDate;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.CheckBox cheSetReminder;
        private System.Windows.Forms.TextBox txtBody;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox txtSubject;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox txtLocation;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.ComboBox cmbIncoTerms;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button btnAddProduct;
        private System.Windows.Forms.Button btnAddFolder;
        private System.Windows.Forms.TextBox txtCode;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Button btnRename;
        private System.Windows.Forms.Panel pnQuoteMaster;
        private System.Windows.Forms.CheckBox chkAddbyQuoteMaster;
        private System.Windows.Forms.CheckBox chkAddbyBOM;
        private System.Windows.Forms.CheckBox chkSavetoQuoteMaster;
        private System.Windows.Forms.TextBox txtTotalPrice;
        private System.Windows.Forms.TextBox txtJackup;
        private System.Windows.Forms.CheckBox chkBreakup;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblCST;
        private System.Windows.Forms.TextBox txtBasicDemoPrice;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox chkOptionalItems;
        private System.Windows.Forms.CheckBox chkaddmainitems;
        private System.Windows.Forms.DataGridView dgvOptionalItems;
        private System.Windows.Forms.Panel pnOptionalItems;
        private System.Windows.Forms.TextBox txtOIBasicDemoPrice;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.CheckBox chkOIBreakup;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox txtOITotalPrice;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox txtOIJackup;
        private System.Windows.Forms.TextBox txtOIQuoteRemain;
        private System.Windows.Forms.TextBox txtOIQuoteBreak;
        private System.Windows.Forms.TextBox txtOIQuoteJack;
        private System.Windows.Forms.CheckBox chkWUOptionalItems;
        private System.Windows.Forms.CheckBox chkWUQuoteItems;
        private System.Windows.Forms.DataGridView dgOIWriteUP;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.TextBox txtaddNote;
        private System.Windows.Forms.Label lblServiceSgst;
        private System.Windows.Forms.TextBox txtServiceTaxSGSTPercent;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.TextBox txtServiceTaxSGSTAmount;
        private System.Windows.Forms.Panel pnInstallCommision;
        private System.Windows.Forms.CheckBox chkShowPackingForwarding;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label lblPrepareBy;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.CheckBox chkProductCode;
        private System.Windows.Forms.CheckBox chkConcessionGst;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.ComboBox cmbProductCategory;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.TextBox txtSystemMargin;
        private System.Windows.Forms.ComboBox cmbQuoteCompany;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGOISlNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn WUOIProductCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn WUOIProductDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.ComboBox cmbLabtype;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbBusinessector;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox cmbProbabality;
        private System.Windows.Forms.ComboBox cmbtypeofcustomer;
        private System.Windows.Forms.ComboBox cmbStatus;
        private System.Windows.Forms.ComboBox cmbStage;
        private System.Windows.Forms.ComboBox cmbTestEnvironment;
        private System.Windows.Forms.ComboBox cmbApplication;
        private System.Windows.Forms.ComboBox cmbprimarymaterial;
        private System.Windows.Forms.ComboBox cmbprimaryind;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox txtLostReason;
        private System.Windows.Forms.TextBox txtWonReason;
        private System.Windows.Forms.TextBox txtSpecifyOthers;
        private System.Windows.Forms.TextBox txtExpectedValueUSD;
        private System.Windows.Forms.DateTimePicker dtpExpectedOrderPlacementdate;
        private System.Windows.Forms.ComboBox cmbWinLose;
        private System.Windows.Forms.ComboBox cmbCompetetion;
        private System.Windows.Forms.Button btnGotoAddProducts;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.TextBox cmbprimarymtrldetail;
        private System.Windows.Forms.TextBox txtCompetation;
        private System.Windows.Forms.ComboBox cmbQuotationNumber;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Panel pnQuotationNumber;
        private System.Windows.Forms.ComboBox cmbRevisionNumber;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Button btnPreview;
        private System.Windows.Forms.Button btnViewQuotes;
        private System.Windows.Forms.DateTimePicker dtpQuoteDate;
        private System.Windows.Forms.CheckBox chkAddProduct;
        private System.Windows.Forms.Panel pnAddProduct;
        private System.Windows.Forms.Button btnAddCategoryProduct;
        private System.Windows.Forms.TextBox txtProductCategory;
        private System.Windows.Forms.ComboBox cmblevelofcustomization;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.ComboBox cmbeightytwenty;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.ComboBox cmbQuoteType;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.CheckBox chkQuoteSavePath;
        private System.Windows.Forms.ComboBox cmbSelectQuoteType;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.TextBox txtEnquiryNumber;
        private System.Windows.Forms.TextBox txtAdditionalMonths;
        private System.Windows.Forms.ComboBox cmbBank;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.DataGridViewTextBoxColumn WUSlNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn WUProductcode;
        private System.Windows.Forms.DataGridViewTextBoxColumn WUDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label lblQuoteBy;
        private System.Windows.Forms.Label lblQuotebyin;
        private System.Windows.Forms.DataGridViewTextBoxColumn SLNO;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductGroup;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductCod;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Description;
        private System.Windows.Forms.DataGridViewTextBoxColumn SalesCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn SalesCostTemp;
        private System.Windows.Forms.DataGridViewTextBoxColumn materialMargin;//materialMargin
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn TPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn BreakupTotal;
        private System.Windows.Forms.DataGridViewTextBoxColumn SP;
        private System.Windows.Forms.DataGridViewTextBoxColumn OISLNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn OIProductGroup;
        private System.Windows.Forms.DataGridViewTextBoxColumn OIProductCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn OIProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn OIProductDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn OISalesCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn OImaterialMargin;//OImaterialMargin
        private System.Windows.Forms.DataGridViewTextBoxColumn OIQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn OIUnitPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn OITotalPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn OIBreakupTotal;
        private System.Windows.Forms.DataGridViewTextBoxColumn SP1;
        private System.Windows.Forms.TextBox txtOldModelNumber;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.CheckBox chkUpdateLatestPrice;
        private System.Windows.Forms.Label totalCostLable;
        private System.Windows.Forms.Label discountedMMValue;
        private System.Windows.Forms.Label discountedMMlb;
        private System.Windows.Forms.Label NoOptionalItems;
    }
}