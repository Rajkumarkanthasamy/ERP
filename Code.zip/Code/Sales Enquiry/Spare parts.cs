﻿using System;
using System.Windows.Forms;
using System.Drawing;
using System.Data;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;
using System.IO;
//using iTextSharp.text;
using EXCEL = Microsoft.Office.Interop.Excel;





namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    public partial class Spare_parts : Form
    {

        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        DataTable dtCustomerList = new DataTable();
        DataTable dtQuationNoList = new DataTable();

        frmForm2 frm = new frmForm2();
        Timer marqueeTimer = new Timer();
        DataTable SparePartQuationDetails = new DataTable();
        DataTable SparePartQuationDetails1 = new DataTable();
        private FolderBrowserDialog folderBrowserDialog1;

        public Spare_parts()
        {
            InitializeComponent();
           
            InitializeDataGridView();
            folderBrowserDialog1 = new FolderBrowserDialog();


        }
       
        private void InitializeDataGridView()
        {
            dgItemOrProductList.CellBorderStyle = DataGridViewCellBorderStyle.Single;

            // Add Select CheckBox Column
            DataGridViewCheckBoxColumn checkBoxColumn = new DataGridViewCheckBoxColumn
            {
                Name = "Select",
                HeaderText = "Select"
            };
            dgItemOrProductList.Columns.Add(checkBoxColumn);

            // Set Row Template Height
            dgItemOrProductList.RowTemplate.Height = 40;

            // Add Delete Button Column
            DataGridViewButtonColumn deleteColumn = new DataGridViewButtonColumn
            {
                Name = "DeleteColumn",
                HeaderText = "Delete",
                Text = "Delete",
                UseColumnTextForButtonValue = true
            };
            dgItemOrProductList.Columns.Add(deleteColumn);

            // Set DataGridView Column Widths
            SetDataGridViewColumnWidths();

            // Set DataGridView Styles
            dgItemOrProductList.DefaultCellStyle.BackColor = Color.White;
            dgItemOrProductList.DefaultCellStyle.ForeColor = Color.Black;
            dgItemOrProductList.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;

            // Bind Events
            buttAdd.Click += new EventHandler(button1_Click);
            dgItemOrProductList.CellContentClick += new DataGridViewCellEventHandler(DgItemOrProductList_CellContentClick);
            dgItemOrProductList.CellValueChanged += new DataGridViewCellEventHandler(DgItemOrProductList_CellValueChanged);
            dgItemOrProductList.CurrentCellDirtyStateChanged += new EventHandler(dgItemOrProductList_CellContentClick);
           
            dgItemOrProductList.CellValidating += DgItemOrProductList_CellValidating;
        }

        private void SetDataGridViewColumnWidths()
        {

            // Set AutoSizeColumnsMode to AllCellsExceptHeader
            dgItemOrProductList.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCellsExceptHeader;

            // Increase the width of specific cells
            dgItemOrProductList.Columns["PartNumber"].Width = 150; // Set the width of PartNumber column to 150
            dgItemOrProductList.Columns["PartDescription"].Width = 300; // Set the width of PartDescription column to 300
            dgItemOrProductList.Columns["Qty"].Width = 80; // Set the width of Qty column to 80
            dgItemOrProductList.Columns["PartDescription"].DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            // If you want the remaining columns to be auto-sized, you don't need to set their widths here


        }
        private void DgItemOrProductList_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            if (e.ColumnIndex == dgItemOrProductList.Columns["Qty"].Index) // Validate only for "Qty" column
            {
                string input = e.FormattedValue.ToString();

                // Regular expression pattern to match digits (0-9) only
                string digitPattern = @"^\d+$";

                if (!Regex.IsMatch(input, digitPattern))
                {
                    e.Cancel = true;
                    MessageBox.Show("Please enter only digits (0-9) in the Quantity column.");
                }
            }
            
            // Validate for "Colunitprice" column
            else if (e.ColumnIndex == dgItemOrProductList.Columns["Colunitprice"].Index)
            {
                string input = e.FormattedValue.ToString().Trim();

                // Ensure input is not empty
                if (string.IsNullOrEmpty(input))
                {
                    e.Cancel = true;
                    MessageBox.Show("Unit Price cannot be empty.");
                    return;
                }

                // Pattern to match only positive integers or floats
                string numberPattern = @"^[0-9]+(\.[0-9]+)?$";

                // Check if the input matches the pattern
                if (!Regex.IsMatch(input, numberPattern))
                {
                    e.Cancel = true; // Cancel the edit
                    MessageBox.Show("Please enter a valid number (integer or float) in the Unit Price column.");
                }
            }
        }
        private void DgItemOrProductList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dgItemOrProductList.Columns["DeleteColumn"].Index && e.RowIndex >= 0)
            {
                DialogResult result = MessageBox.Show("Are you sure you want to delete this row?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    dgItemOrProductList.Rows.RemoveAt(e.RowIndex);
                }
            }
        }

        private void DgItemOrProductList_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dgItemOrProductList.Columns["Select"].Index && e.RowIndex >= 0)
            {
                DataGridViewCheckBoxCell checkBoxCell = (DataGridViewCheckBoxCell)dgItemOrProductList.Rows[e.RowIndex].Cells["Select"];
                bool isChecked = (bool)checkBoxCell.EditedFormattedValue;
                dgItemOrProductList.Rows[e.RowIndex].Selected = isChecked;
            }

            if (e.ColumnIndex == dgItemOrProductList.Columns["Qty"].Index || e.ColumnIndex == dgItemOrProductList.Columns["Colunitprice"].Index)
            {
                DataGridViewRow row = dgItemOrProductList.Rows[e.RowIndex];
                UpdateTotalAmount(row);
            }
            if (dgItemOrProductList.IsCurrentCellDirty)
            {
                dgItemOrProductList.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
        }
        private void UpdateTotalAmount(DataGridViewRow row)
        {
            if (row.Cells["Qty"].Value != null && row.Cells["Colunitprice"].Value != null)
            {
                if (int.TryParse(row.Cells["Qty"].Value.ToString(), out int qty) &&
                    decimal.TryParse(row.Cells["Colunitprice"].Value.ToString(), out decimal unitPrice))
                {
                    decimal total = qty * unitPrice;
                    row.Cells["Coltotal"].Value = total;
                }
                else
                {
                    row.Cells["Coltotal"].Value = 0; // Set to 0 if invalid input
                }
            }
        }
        private void dgItemOrProductList_CellContentClick(object sender, EventArgs e)
        {
            if (dgItemOrProductList.IsCurrentCellDirty)
            {
                dgItemOrProductList.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
        }

        int rowcount = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            //Console.WriteLine("Button clicked, adding a new row.");
            dgItemOrProductList.Rows.Add(rowcount++, 0, " ", 0, 0, 0);
            //dgItemOrProductList.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
        }

        private bool IsValidEmail(string email)
        {
            // Corrected regular expression pattern for validating email
            string pattern = @"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$";

            Regex regex = new Regex(pattern);
            return regex.IsMatch(email);
        }



        private bool IsValidPhoneNumber(string phoneNumber)
        {
            // Regular expression to validate phone number format
            Regex regex = new Regex(@"^\+?(\d[\d-. ]+)?(\([\d-. ]+\))?[\d-. ]+\d$");

            return regex.IsMatch(phoneNumber);
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            DataTable isDuplicateKeyTableQuateNo = DAL.CheckDuplicateKeyQuateNo(0, textquotationNo.Text).Tables[0];
            if (isDuplicateKeyTableQuateNo.Rows.Count > 0)
            {
                MessageBox.Show("Quotation Number already exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textquotationNo.Focus();
                return;

            }
            // Check if critical information is selected
            if (string.IsNullOrWhiteSpace(txtCALCustomer.Text) && txtCALCustomer.Visible == true)
            {
                MessageBox.Show("Please enter Customer");
                txtCALCustomer.BackColor = System.Drawing.Color.FromArgb(255, 204, 204); // Set background color to red
                txtCALCustomer.Focus();  // Set focus to textBoxPaymentIssue
                return;
            }
            else
            {
                txtCALCustomer.BackColor = System.Drawing.Color.White; // Reset background color if valid
            }
            // Check if textBoxInstallationImpact1 is empty
            if (string.IsNullOrWhiteSpace(txtCALContactPerson.Text) && txtCALContactPerson.Visible == true)
            {
                MessageBox.Show("Please enter Contact Person");
                txtCALContactPerson.BackColor = System.Drawing.Color.FromArgb(255, 204, 204); // Set background color to red
                txtCALContactPerson.Focus();  // Set focus to textBoxPaymentIssue
                return;
            }
            else
            {
                txtCALContactPerson.BackColor = System.Drawing.Color.White; // Reset background color if valid
            }


            string email = txtCALEmailID.Text;
            if (IsValidEmail(email))
            {
                txtCALEmailID.ForeColor = System.Drawing.Color.Green;
            }
            else
            {
                MessageBox.Show("Please enter valid Email Address");
                txtCALEmailID.ForeColor = System.Drawing.Color.Red;
                txtCALEmailID.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtCALEmailID.Text) && txtCALEmailID.Visible == true)
            {

                txtCALEmailID.BackColor = System.Drawing.Color.FromArgb(255, 204, 204); // Set background color to red
                txtCALEmailID.Focus();  // Set focus to textBoxPaymentIssue
                return;
            }
            else
            {
                txtCALEmailID.BackColor = System.Drawing.Color.White; // Reset background color if valid
            }


            if (string.IsNullOrWhiteSpace(textquotationNo.Text) && textquotationNo.Visible == true)
            {

                textquotationNo.BackColor = System.Drawing.Color.FromArgb(255, 204, 204); // Set background color to red
                textquotationNo.Focus();  // Set focus to textBoxPaymentIssue
                return;
            }
            else
            {
                textquotationNo.BackColor = System.Drawing.Color.White; // Reset background color if valid
            }




            if (string.IsNullOrWhiteSpace(txtCALTel.Text) && txtCALTel.Visible == true)
            {
                MessageBox.Show("Please enter Phone Number");
                txtCALTel.BackColor = System.Drawing.Color.FromArgb(255, 204, 204); // Set background color to red
                txtCALTel.Focus();  // Set focus to textBoxPaymentIssue
                return;
            }
            else
            {
                txtCALTel.BackColor = System.Drawing.Color.White; // Reset background color if valid
            }

            if (string.IsNullOrWhiteSpace(txtCALAddress.Text) && txtCALAddress.Visible == true)
            {
                MessageBox.Show("Please enter Address");
                txtCALAddress.BackColor = System.Drawing.Color.FromArgb(255, 204, 204); // Set background color to red
                txtCALAddress.Focus();  // Set focus to textBoxPaymentIssue
                return;
            }
            else
            {
                txtCALAddress.BackColor = System.Drawing.Color.White; // Reset background color if valid
            }
            //----------------------------------------------------------------------

            string phoneNumber = txtCALTel.Text.Trim();

            if (IsValidPhoneNumber(phoneNumber))
            {

            }
            else
            {
                MessageBox.Show("Invalid phone number.");
                txtCALTel.Focus();
                return;
            }
            //---------------------------------------------------------------------


            
            string newQuotationNo = textquotationNo.Text;
            //newQuotationNo = IncrementQuotationNo(quotationNo);



            //labquoteby.Text = login.GetUserDetails[2];
            string message1 = "";
            // Declare variables to store textbox values
            string CustomerName = txtCALCustomer.Text;
            string EmailId = txtCALEmailID.Text;
            string PhoneNumber = txtCALTel.Text;
            string Address = txtCALAddress.Text;
            string ContactPerson = txtCALContactPerson.Text;
            string DeliveryTerm = textDeliveryTerm.Text;
            string DateofQuote = dtpCALDateofQuote.Value.Date.ToString("dd-MM-yyyy");
            string QuotationName = txtCalQuotename.Text;
            string Currency = CmbCurrency.Text;
            string Quotationfor = cmbCALQuoteFor.Text;
            string QuotationSerialNo = txtCALModelNo.Text;

            /*
            message1 += $"ContactPerson: {ContactPerson}\n" +
                        $"Customer: {CustomerName}\n" +
                        $"Email ID: {EmailId}\n" +
                        $"Phone Number: {PhoneNumber}\n" +
                        $"Address: {Address}\n" +
                        $"DeliveryTerm: {DeliveryTerm}\n" +
                        $"Quote name: {QuotationName}\n" +
                        $"Date of Quote: {DateofQuote}\n" +
                        $"Currency: {Currency}\n" +
                        $"Quote For: {Quotationfor}\n" +
                        $"Model No: {QuotationSerialNo}\n\n";
            */
            //MessageBox.Show(message1);
            


            bool isAnyRowSelected = false;
            bool allRowsChecked = true; // Flag to check if all visible rows are checked
            bool dataInserted = false;

            // First pass: Check if at least one row is selected and if all visible rows are checked
            foreach (DataGridViewRow row in dgItemOrProductList.Rows)
            {
                // Ensure the row is not a new row and is visible
                if (!row.IsNewRow && row.Visible)
                {
                    DataGridViewCheckBoxCell chkCell = (DataGridViewCheckBoxCell)row.Cells[6];

                    // Check if the checkbox cell is checked
                    if (chkCell.Value != null && (bool)chkCell.Value)
                    {
                        isAnyRowSelected = true;
                    }
                    else
                    {
                        allRowsChecked = false; // Found a visible row that is not checked
                    }
                }
            }

            // Validation Logic
            if (!isAnyRowSelected)
            {
                MessageBox.Show("Please select at least one row before proceeding.", "Selection Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!allRowsChecked)
            {
                MessageBox.Show("All visible rows must be checked before inserting data.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Proceed with data insertion for selected rows
            foreach (DataGridViewRow row in dgItemOrProductList.Rows)
            {
                // Ensure the row is not a new row and is visible
                if (!row.IsNewRow && row.Visible)
                {
                    DataGridViewCheckBoxCell chkCell = (DataGridViewCheckBoxCell)row.Cells[6];

                    // Check if the checkbox cell is checked
                    if (chkCell.Value != null && (bool)chkCell.Value)
                    {
                        string PartNumber = row.Cells["PartNumber"].Value?.ToString() ?? "";
                        string PartDescription = row.Cells["PartDescription"].Value?.ToString() ?? "";

                        if (int.TryParse(row.Cells["Qty"].Value?.ToString(), out int Qty) &&
                            decimal.TryParse(row.Cells["Colunitprice"].Value?.ToString(), out decimal UnitPrice) &&
                            decimal.TryParse(row.Cells["Coltotal"].Value?.ToString(), out decimal TotalQuantityPrice))
                        {
                            string currentDateString = DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss");
                            try
                            {
                                GlobalClass.iStatus = DAL.SparePartQuationDetails(0,
                                    newQuotationNo,
                                    ContactPerson,
                                    CustomerName,
                                    PhoneNumber,
                                    EmailId,
                                    Address,
                                    QuotationName,
                                    Currency,
                                    Quotationfor,
                                    QuotationSerialNo,
                                    DeliveryTerm,
                                    PartNumber,
                                    PartDescription,
                                    Qty,
                                    UnitPrice,
                                    TotalQuantityPrice,
                                    login.GetUserDetails[2],
                                    currentDateString);

                                dataInserted = true;
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show($"Error saving data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Invalid data in the selected row. Please check the quantity, unit price, and total price.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }
                }
            }

            // Optional: Inform the user about successful insertion
            if (dataInserted)
            {
                MessageBox.Show("Data inserted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


          

            

          



            //MessageBox.Show(message);

            this.Hide();
            Spare_parts Spare_parts = new Spare_parts();
            Spare_parts.Show();
            ResetForm();
        }




        static string IncrementQuotationNo(string quotationNo)
        {
            // Extract numeric part from the string
            string pattern = @"^(.*?)(\d+)$";
            Match match = Regex.Match(quotationNo, pattern);

            if (match.Success)
            {
                // Get the prefix and the numeric part
                string prefix = match.Groups[1].Value;
                string numericPart = match.Groups[2].Value;

                // Convert numeric part to an integer and increment it
                int number = int.Parse(numericPart);
                number++;

                // Combine prefix with the new incremented number
                return $"{prefix}{number}";
            }
            else
            {
                // If there's no numeric part, handle it accordingly
                throw new FormatException("Quotation number format is incorrect.");
            }
        }

        private void ResetForm()
        {
            ResetControls(this.Controls);
        }

        private void ResetControls(Control.ControlCollection controls)
        {
            foreach (Control control in controls)
            {
                if (control is ComboBox comboBox)
                {
                    comboBox.SelectedItem = null;
                }
                else if (control is TextBox textBox)
                {
                    textBox.Clear();
                }
                else if (control.HasChildren)
                {
                    ResetControls(control.Controls);
                }
            }

            ClearSpecificTexts();
        }

        private void ClearSpecificTexts()
        {
            // Implement the logic to clear specific labels or textboxes if needed
        }

        private void RefreshDataGridView()
        {
            dgItemOrProductList.DataSource = null;
        }
        //DataTable dtCustomerList = new DataTable();
        DataRow DR;
        private void cmbCALCustomer_SelectedIndexChanged(object sender, EventArgs e)
        {
            /*
            DataRow[] customerRows = dtCustomerList.Select("CustomerName = '" + txtCALCustomer.Text + "'");
            if (customerRows.Length > 0)
            {
                DataRow customerRow = customerRows[0];
                txtCALAddress.Text = customerRow["Address1"].ToString() + customerRow["Address2"].ToString() + customerRow["Address3"].ToString();
                txtCALContactPerson.Text = customerRow["ContactPerson"].ToString();
                txtCALTel.Text = customerRow["MobileNo"].ToString();
                txtCALEmailID.Text = customerRow["EmailAddress"].ToString();
                txtCustomerCode.Text = customerRow["CusCode"].ToString();
            }
            else
            {
                txtCALAddress.ResetText();
                txtCALContactPerson.ResetText();
                txtCALTel.ResetText();
                txtCALEmailID.ResetText();
                txtCustomerCode.ResetText();
            }
            */
        }

        /*
        private void StartMarquee()
        {
            marqueeTimer.Interval = 100; // Adjust the interval as needed for the scrolling speed
            marqueeTimer.Tick += MarqueeTimer_Tick;
            marqueeTimer.Start();
        }

        private void MarqueeTimer_Tick(object sender, EventArgs e)
        {
            // Move the label horizontally
            // Uncomment and complete the code when titleLabel is properly initialized
            labSpareParts.Location = new System.Drawing.Point(labSpareParts.Location.X - 1, labSpareParts.Location.Y);

            // Reset the label position when it moves out of the form's bounds
            if (labSpareParts.Right < 0)
            {
                labSpareParts.Location = new System.Drawing.Point(this.ClientSize.Width, labSpareParts.Location.Y);
            }
        }
        */
        private void Spare_parts_Load(object sender, EventArgs e)
        {
            /*
            dtCustomerList = DAL.fnCustomerList(5, null).Tables[0];
            foreach (DataRow DR in dtCustomerList.Rows)
            {
                if (!txtCALCustomer.Items.Contains(DR["CustomerName"].ToString()))
                    txtCALCustomer.Items.Add(DR["CustomerName"].ToString());
            }
            */
            //comQuotationNo
            dtQuationNoList = DAL.fnQuationNoList(0).Tables[0];
            foreach (DataRow DR in dtQuationNoList.Rows)
            {
                if (!comQuotationNo.Items.Contains(DR["QuotationNo"].ToString()))
                    comQuotationNo.Items.Add(DR["QuotationNo"].ToString());
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {


            this.Hide();
            frm.Show();
        }


        private void dgItemOrProductList_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                e.PaintBackground(e.ClipBounds, true);

                using (Pen gridPen = new Pen(Color.Black, 1))
                {
                    // Draw top border
                    e.Graphics.DrawLine(gridPen, e.CellBounds.Left, e.CellBounds.Top, e.CellBounds.Right, e.CellBounds.Top);
                    // Draw right border
                    e.Graphics.DrawLine(gridPen, e.CellBounds.Right, e.CellBounds.Top, e.CellBounds.Right, e.CellBounds.Bottom);
                    // Draw bottom border
                    e.Graphics.DrawLine(gridPen, e.CellBounds.Left, e.CellBounds.Bottom, e.CellBounds.Right, e.CellBounds.Bottom);
                    // Draw left border
                    e.Graphics.DrawLine(gridPen, e.CellBounds.Left, e.CellBounds.Top, e.CellBounds.Left, e.CellBounds.Bottom);
                }

                e.PaintContent(e.ClipBounds);
                e.Handled = true;
            }
        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void dgItemOrProductList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void labSpareParts_Click(object sender, EventArgs e)
        {

        }



        private void fnFileSavePath()
        {
            if (Properties.Settings.Default.ServiceQuotePath == "C:\\Users\\SparesQuotation")
            {
                DialogResult result = folderBrowserDialog1.ShowDialog();
                if (result == DialogResult.OK)
                {
                    Properties.Settings.Default.ServiceQuotePath = folderBrowserDialog1.SelectedPath;
                    Properties.Settings.Default.Save();
                }
            }

            if (!Directory.Exists(Properties.Settings.Default.ServiceQuotePath))
            {
                Directory.CreateDirectory(Properties.Settings.Default.ServiceQuotePath);
            }
        }

        private void btnPrintSparePartsdownload_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(comQuotationNo.Text))
            {
                MessageBox.Show("Select Quotation number cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                comQuotationNo.Focus(); // Set focus back to the comQuotationNo TextBox
                return;
            }


            SparePartQuationDetails = DAL.SparePartQuationDetails(0, comQuotationNo.Text).Tables[0];
            SparePartQuationDetails1 = DAL.SparePartQuationDetails(1, comQuotationNo.Text).Tables[0];
            Cursor.Current = Cursors.WaitCursor;
            fnFileSavePath();
            int iRowIndex = 1;
            string ExcelFolderPath;
            string FileFullPath;
            string FileFul;
            EXCEL.Workbook NewWorkBook;
            EXCEL.Worksheet NewWorkSheet;
            EXCEL.Application ExcelApp;
            EXCEL.Range CELLS, cell1, cell2;
            object misValue;
            if (SparePartQuationDetails.Rows.Count > 0)
            {
                string sFileQuotename = SparePartQuationDetails.Rows[0]["QuotationNo"].ToString();
                string CustomerName = SparePartQuationDetails.Rows[0]["CustomerName"].ToString();

                //shreeshail is added below 2 line
                Regex illegalInFileName = new Regex(@"[\\/:*?""<>|]");
                string sProjName = sFileQuotename;
                sFileQuotename = illegalInFileName.Replace(sProjName, " ");
                //shreeshail is added above line
                ExcelFolderPath = Properties.Settings.Default.ServiceQuotePath;   // System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + ExcelFolderName + "\\";
                FileFullPath = ExcelFolderPath + "\\" + CustomerName + "-" + sFileQuotename + "-" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + ".xlsx"; //working code date
                FileFul = ExcelFolderPath + "\\" + CustomerName + "-" + sFileQuotename + "-" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + ".pdf";

                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);
                ExcelApp = new EXCEL.Application();
                misValue = System.Reflection.Missing.Value;

                //            string[] Text2 = {
                //    "Dear Sir,",
                //    "",
                //    "Sub.: Quotation for spares for Instron System - 5965R7210",

                //    "",
                //    "With reference to your above, we are pleased to submit the quotation for your kind consideration.",
                //    ""
                //};



                // Define the base text with a placeholder for the quotation number
                string Text2 = "Dear Sir,\n\n" +
                                  "Sub.: Spare parts Quotation for Instron System - {0}\n\n" +
                                  "With reference to your above, we are pleased to submit the quotation for your kind consideration.\n\n";

                // Retrieve the quotation number from your data source
                string quotationNo = SparePartQuationDetails.Rows[0]["QuotationSerialNo"].ToString();

                // Format the text with the actual quotation number
                string formattedText = string.Format(Text2, quotationNo);
                // Split the formatted text into lines
                string[] lines = formattedText.Split(new[] { "\n" }, StringSplitOptions.None);



                try
                {
                    if (ExcelApp == null)
                        MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                    NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                    NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                    if (NewWorkSheet == null)
                        MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                    else
                        NewWorkSheet.Name = "Spare Parts";

                    // Select the Excel cells, in the range c1 to c7 in the worksheet for cell access check.
                    EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C6");

                    if (RANGE == null)
                        MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");

                    NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    CELLS = NewWorkSheet.Cells;



                    NewWorkSheet.Cells[iRowIndex, 1] = "Quotation No : " + SparePartQuationDetails.Rows[0]["QuotationNo"].ToString();
                    // Check the type of the value and convert accordingly
                    object dateValue = SparePartQuationDetails.Rows[0]["QuotationDate"];
                    DateTime quotationDate;

                    if (dateValue is DateTime)
                    {
                        quotationDate = (DateTime)dateValue;
                    }
                    else if (dateValue is string)
                    {
                        if (DateTime.TryParse((string)dateValue, out quotationDate))
                        {
                            // Successfully parsed the string to DateTime
                        }
                        else
                        {
                            // Handle the case where the string is not a valid date
                            // You might want to set a default date or log an error
                            quotationDate = DateTime.MinValue; // Example default date
                        }
                    }
                    else
                    {
                        // Handle the case where the value is neither DateTime nor string
                        // You might want to set a default date or log an error
                        quotationDate = DateTime.MinValue; // Example default date
                    }

                    NewWorkSheet.Cells[iRowIndex, 5] = "Date : " + quotationDate.ToString("dd-MM-yyyy");
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);

                    iRowIndex++;
                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "Prepared For: " + SparePartQuationDetails.Rows[0]["CustomerName"].ToString();
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);

                    iRowIndex++;
                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = SparePartQuationDetails.Rows[0]["Address"].ToString() + "\n\n";
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 4, 1, 3);
                    CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 4, 1, 3);
                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex + 4, 1, 3);


                    iRowIndex = iRowIndex + 6;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Kind Attn:" + SparePartQuationDetails.Rows[0]["ContactPerson"].ToString();
                    iRowIndex++;
                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Mobile No: " + SparePartQuationDetails.Rows[0]["PhoneNumber"].ToString();
                    iRowIndex++;


                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Email Id: " + SparePartQuationDetails.Rows[0]["EmailId"].ToString();
                    iRowIndex++;
                    iRowIndex++;
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);
                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 1, 6);
                    iRowIndex++;

                    iRowIndex++;

                    foreach (string str in lines)
                    {
                        NewWorkSheet.Cells[iRowIndex, 1] = str;
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 6);
                        iRowIndex++;
                    }


                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);

                    //CellMerge("AlignCenter", NewWorkSheet, iRowIndex + 1, iRowIndex + 1, 1, 5);


                    iRowIndex++;
                    if (SparePartQuationDetails.Rows[0]["Currency"].ToString() == "INR")
                    {
                        if (SparePartQuationDetails1.Rows.Count > 0)
                        {
                            // Define the headers
                            string[] headers = { "Si.No", "Part Number", "Part Description", "Qty", "Unit Price In Rupees", "Amount In Rupees" };

                            // Create an array with one extra row for headers
                            object[,] rawData = new object[SparePartQuationDetails1.Rows.Count + 1, headers.Length];

                            // Add headers to the first row
                            for (int col = 0; col < headers.Length; col++)
                            {
                                rawData[0, col] = headers[col];
                            }

                            // Add data to the array starting from the second row
                            for (int row = 0; row < SparePartQuationDetails1.Rows.Count; row++)
                            {
                                // Add serial number
                                rawData[row + 1, 0] = row + 1;

                                // Add other data
                                for (int col = 1; col < headers.Length - 1; col++)
                                {
                                    rawData[row + 1, col] = SparePartQuationDetails1.Rows[row].ItemArray[col - 1];
                                }

                                // Calculate Total Quantity Price in US$
                                int qty = Convert.ToInt32(SparePartQuationDetails1.Rows[row]["Qty"]);
                                //MessageBox.Show(qty);

                                // Convert and format unit price and total quantity price
                                decimal unitPrice = Convert.ToDecimal(SparePartQuationDetails1.Rows[row]["UnitPrice"]);
                                decimal totalQuantityPrice = Convert.ToDecimal(SparePartQuationDetails1.Rows[row]["TotalQuantityPrice"]);

                                // Store with 2 decimal places
                                rawData[row + 1, 4] = unitPrice; //.ToString("0.00"); // Store formatted unit price
                                rawData[row + 1, 5] = totalQuantityPrice; //.ToString("0.00"); // Store formatted total quantity price

                                //MessageBox.Show(unitPrice.ToString("0.00"));
                                //MessageBox.Show(totalQuantityPrice.ToString("0.00"));
                            }

                            // Calculate grand total
                            decimal grandTotal = 0;
                            for (int row = 0; row < SparePartQuationDetails1.Rows.Count; row++)
                            {
                                grandTotal += Convert.ToDecimal(rawData[row + 1, 5]);
                            }





                            // Determine Excel range
                            string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                            int colCharsetLen = colCharset.Length;
                            string finalColLetter = string.Empty;

                            if (headers.Length > colCharsetLen)
                            {
                                finalColLetter = colCharset.Substring((headers.Length - 1) / colCharsetLen - 1, 1);
                            }
                            finalColLetter += colCharset.Substring((headers.Length - 1) % colCharsetLen, 1);
                            string excelRange = string.Format("A" + iRowIndex + ":{0}{1}", finalColLetter, (SparePartQuationDetails1.Rows.Count + iRowIndex));

                            // Insert data into worksheet
                            var range = NewWorkSheet.get_Range(excelRange, Type.Missing);
                            range.Value2 = rawData;
                            range.WrapText = true; // Wrap text for the entire range
                            // Set font size for the entire range
                            range.Cells.Font.Size = 14;

                            // Format and merge cells
                            CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 6);
                            CellMerge("GridLines", NewWorkSheet, iRowIndex, (iRowIndex + SparePartQuationDetails1.Rows.Count + 3), 1, 6);
                            CellMerge("AlignCenter", NewWorkSheet, iRowIndex, (iRowIndex + SparePartQuationDetails1.Rows.Count), 1, 6);
                            CellMerge("VAlignCenter", NewWorkSheet, iRowIndex, (iRowIndex + SparePartQuationDetails1.Rows.Count), 1, 6);

                            Microsoft.Office.Interop.Excel.Range range2 = NewWorkSheet.get_Range("D" + iRowIndex, "F" + (iRowIndex + 3 + SparePartQuationDetails1.Rows.Count) + "");
                            range2.NumberFormat = "#,##0.00";

                            iRowIndex += SparePartQuationDetails1.Rows.Count + 1;


                            NewWorkSheet.Cells[iRowIndex, 2] = "Total";
                            NewWorkSheet.Cells[iRowIndex, 6] = grandTotal;   //txtPIGrandTotal.Text;
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                            CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 5);
                            CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);
                            // Explicitly set the font size for the "Total" row
                            var totalRange = NewWorkSheet.get_Range("A" + iRowIndex + ":F" + iRowIndex.ToString());
                            totalRange.Cells.Font.Size = 14;


                            //iRowIndex++;
                            iRowIndex++;
                            // Set font size for GST row
                            var gstRange = NewWorkSheet.get_Range("A" + iRowIndex + ":F" + iRowIndex);
                            gstRange.Cells.Font.Size = 14;

                            NewWorkSheet.Cells[iRowIndex, 2] = "GST - 18 % "; //txtPIGST.Text
                            decimal dPIGST1 = grandTotal * 0.18m;

                            //double dPIGST = Convert.ToDouble(txtPIGrandTotal.Text) * (Convert.ToDouble(txtPIGST.Text) / 100);
                            NewWorkSheet.Cells[iRowIndex, 6] = dPIGST1.ToString();
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                            CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);

                            iRowIndex++;

                            // Set font size for Grand Total row
                            var grandTotalRange = NewWorkSheet.get_Range("A" + iRowIndex + ":F" + iRowIndex);
                            grandTotalRange.Cells.Font.Size = 14;

                            NewWorkSheet.Cells[iRowIndex, 2] = "Grand Total";
                            NewWorkSheet.Cells[iRowIndex, 6] = grandTotal + dPIGST1;
                            //NewWorkSheet.Cells[iRowIndex, 5] = Convert.ToDouble(txtPIGrandTotal.Text) + dPIGST;
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                            CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 6);
                            CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);

                        }



                        //CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                        iRowIndex++;
                        iRowIndex++;
                        iRowIndex++;
                        iRowIndex++;
                        //------------------------------------------

                        NewWorkSheet.HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);

                        NewWorkSheet.Cells[iRowIndex, 1] = "Terms and Conditions:";
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 6);
                        CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 6);
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 6);
                        iRowIndex++;
                        // Add border to the first cell before merging
                        NewWorkSheet.Cells[iRowIndex, 1].BorderAround();
                        // Set the cell value for the first cell
                        NewWorkSheet.Cells[iRowIndex, 1] = "Price: ";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 1);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 1);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                        // Add border around the merged cells
                        //CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 5);
                        // Set the cell value for the second cell
                        NewWorkSheet.Cells[iRowIndex, 2] = "Prices are firm, and taxes Extra as indicated above.";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 2, 6);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 2, 2, 6);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 6);
                        // Add border around the merged cells
                        //CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 2, 2, 5);

                        // Increment iRowIndex to move to the next set of rows
                        iRowIndex = iRowIndex + 3;

                        //1---------------------------------------------------
                        //iRowIndex++;
                        // Add border to the first cell before merging
                        NewWorkSheet.Cells[iRowIndex, 1].BorderAround();
                        // Set the cell value for the first cell
                        NewWorkSheet.Cells[iRowIndex, 1] = "Order: ";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 1);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 1);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                        // Add border around the merged cells
                        //CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 5);
                        // Set the cell value for the second cell
                        NewWorkSheet.Cells[iRowIndex, 2] = ": Kindly provide us your Purchase order in the name of ITW India Private Limited  \n  No.497E, 14th Cross, 4th Phase, PIA, Bangalore – 560 058";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 2, 6);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 2, 2, 6);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex + 2, 2, 6);
                        // Add border around the merged cells
                        //CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 3, 2, 5);

                        // Increment iRowIndex to move to the next set of rows
                        iRowIndex = iRowIndex + 3;
                        //end1------------------------------------------------



                        //2---------------------------------------------------
                        //iRowIndex++;
                        // Add border to the first cell before merging
                        NewWorkSheet.Cells[iRowIndex, 1].BorderAround();
                        // Set the cell value for the first cell
                        NewWorkSheet.Cells[iRowIndex, 1] = "Delivery: ";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 1);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 1);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                        // Add border around the merged cells
                        //CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 5);
                        // Set the cell value for the second cell
                        NewWorkSheet.Cells[iRowIndex, 2] = "Orders will be served on first come first basis. In case stock is not available, delivery will be made in 6 to 8 weeks’ time from \n the date of receipt of the confirmed commercially clean order.";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 3, 2, 6);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 3, 2, 6);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 2, 6);
                        // Add border around the merged cells
                        //CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 3, 2, 5);

                        // Increment iRowIndex to move to the next set of rows
                        iRowIndex = iRowIndex + 4;
                        //end2------------------------------------------------
                        //3---------------------------------------------------
                        //iRowIndex++;
                        // Add border to the first cell before merging
                        NewWorkSheet.Cells[iRowIndex, 1].BorderAround();
                        // Set the cell value for the first cell
                        NewWorkSheet.Cells[iRowIndex, 1] = "Payment: ";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 1);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 1);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                        // Add border around the merged cells
                        //CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 5);
                        // Set the cell value for the second cell
                        NewWorkSheet.Cells[iRowIndex, 2] = "100% Advance against Pro-forma Invoice.";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 2, 6);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 2, 2, 6);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 2, 6);
                        // Add border around the merged cells
                        //CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 2, 2, 5);

                        // Increment iRowIndex to move to the next set of rows
                        iRowIndex = iRowIndex + 3;
                        //end3------------------------------------------------

                        //4---------------------------------------------------
                        //iRowIndex++;
                        // Add border to the first cell before merging
                        NewWorkSheet.Cells[iRowIndex, 1].BorderAround();
                        // Set the cell value for the first cell
                        NewWorkSheet.Cells[iRowIndex, 1] = "Validity: ";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 1);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 1);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                        // Add border around the merged cells
                        //CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 5);
                        // Set the cell value for the second cell
                        NewWorkSheet.Cells[iRowIndex, 2] = "90 days. ";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 2, 6);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 1, 2, 6);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 2, 6);
                        // Add border around the merged cells
                        //CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 2, 2, 5);

                        // Increment iRowIndex to move to the next set of rows
                        iRowIndex = iRowIndex + 3;
                        //end4------------------------------------------------
                        //5---------------------------------------------------
                        //iRowIndex++;
                        // Add border to the first cell before merging
                        NewWorkSheet.Cells[iRowIndex, 1].BorderAround();
                        // Set the cell value for the first cell
                        NewWorkSheet.Cells[iRowIndex, 1] = "Warranty: ";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 1);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 1);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                        // Add border around the merged cells
                        //CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 5);
                        // Set the cell value for the second cell
                        NewWorkSheet.Cells[iRowIndex, 2] = "All Spares are guaranteed for 3 months from the date of installation or 5 months from date of shipment whichever is \n earlier.";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 3, 2, 6);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 3, 2, 6);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex + 3, 2, 6);
                        // Add border around the merged cells
                        //CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 2, 2, 5);

                        // Increment iRowIndex to move to the next set of rows
                        iRowIndex = iRowIndex + 4;
                        //end5------------------------------------------------


                        //bhavya---------------------------------------------------
                        //iRowIndex++;
                        // Add border to the first cell before merging
                        NewWorkSheet.Cells[iRowIndex, 1].BorderAround();
                        // Set the cell value for the first cell
                        NewWorkSheet.Cells[iRowIndex, 1] = "Important Note: ";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 1);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 1);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                        // Add border around the merged cells
                        //CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 5);
                        // Set the cell value for the second cell
                        NewWorkSheet.Cells[iRowIndex, 2] = "Above quoted prices are exclusive of installation charges and applicable only for the current\n offer the prices may change for future requirements";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 3, 2, 6);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 3, 2, 6);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex + 3, 2, 6);
                        // Add border around the merged cells
                        //CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 2, 2, 5);

                        // Increment iRowIndex to move to the next set of rows
                        iRowIndex = iRowIndex + 4;


                        //bhavya
                        //6---------------------------------------------------
                        //iRowIndex++;
                        // Add border to the first cell before merging
                        NewWorkSheet.Cells[iRowIndex, 1].BorderAround();
                        // Set the cell value for the first cell
                        NewWorkSheet.Cells[iRowIndex, 1] = "TAX : ";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 1, 1, 1);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 1, 1, 1);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                        // Add border around the merged cells
                        //CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 6, 1, 5);
                        // Set the cell value for the second cell
                        NewWorkSheet.Cells[iRowIndex, 2] = "GST - 18 % - Our GSTIN - 29AAACI4550Q2Z1";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 1, 2, 6);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 1, 2, 6);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 2, 6);
                        // Add border around the merged cells
                        //CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 6, 2, 5);

                        // Increment iRowIndex to move to the next set of rows
                        iRowIndex = iRowIndex + 2;
                        //end6------------------------------------------------

                        iRowIndex++;
                        // NewWorkSheet.HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);
                        // Add border to the first cell before merging
                        NewWorkSheet.Cells[iRowIndex, 1].BorderAround();
                        // Set the cell value for the first cell
                        NewWorkSheet.Cells[iRowIndex, 1] = "General:";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 6);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 6);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 6);
                        // Add border around the merged cells
                        //CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                        // Set the cell value for the second cell
                        iRowIndex++;
                        NewWorkSheet.Cells[iRowIndex, 1] = "The export of Goods and Technology herein is/maybe subject to the export control regulations of the United Kingdom / the United States/ Italy, as amended.And agrees as a condition of acceptance of this quotation / contract and issuance of any subsequent order or contract hereto, that the Goods and Technology will not be used for purposes associated with any chemical, biological, nuclear weapons, or missiles capable of delivering such weapons, or in support of any terrorist activity or any other military end use.Nor will they be re - sold or transferred if it is known or  suspected that they are intended be used for such purposes. If any requisite governmental licence, consent or permit or other authorization cannot be obtained in fulfilment of any subsequent order or contract here to, ITW India Private Limited shall not be liable to Birla Institute of Technology in respect of any bond or guarantee or for any loss, damage, consequences, or other resultant financial penalty. Items are imported hence price quoted in Indian Rupees are based on current rates of customs duty, currency exchange rate, Government policies and are subject to change when there is a change in the same.The rates are exclusive of all statutory levies by Central or State Governments and the same shall be, if applicable will have to be paid in addition at the rate prevalent at the time of delivery";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 19, 1, 6);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 19, 1, 6);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 6);
                        // Add border around the merged cells
                        //CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 19, 1, 5);
                        iRowIndex = iRowIndex + 20;
                        iRowIndex++;
                        //-------------------------------------

                        NewWorkSheet.Cells[iRowIndex, 1] = "Yours truly \n For ITW India Private Limited(Instron Division) ";
                        CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 6);
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 6);


                        iRowIndex = iRowIndex + 3;

                        iRowIndex++;
                        iRowIndex++;
                        NewWorkSheet.Cells[iRowIndex, 1] = "With Regards,\n Nagashree.R";
                        CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 6);
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 6);
                        NewWorkSheet.Cells[iRowIndex, 1].Font.Color = EXCEL.XlRgbColor.rgbRed;
                        iRowIndex = iRowIndex + 3;
                        NewWorkSheet.Cells[iRowIndex, 1] = "Service Business \n Coordinator \n +91961107261";
                        CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 6);
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 6);
                        NewWorkSheet.Cells[iRowIndex, 1].Font.Color = EXCEL.XlRgbColor.rgbBlue;
                        iRowIndex = iRowIndex + 4;

                    }
                    else if (SparePartQuationDetails.Rows[0]["Currency"].ToString() == "USD")
                    {
                        // Define the headers
                        string[] headers = { "SlNo", "Part Number", "Part Description", "Qty", "Unit Price in US$", "Total Quantity Price in US$" };

                        // Create an array with one extra row for headers
                        object[,] rawData = new object[SparePartQuationDetails1.Rows.Count + 1, headers.Length];

                        // Add headers to the first row
                        for (int col = 0; col < headers.Length; col++)
                        {
                            rawData[0, col] = headers[col];
                        }

                        // Add data to the array starting from the second row
                        for (int row = 0; row < SparePartQuationDetails1.Rows.Count; row++)
                        {
                            // Add serial number
                            rawData[row + 1, 0] = row + 1;

                            // Add other data
                            for (int col = 1; col < headers.Length - 1; col++)
                            {
                                rawData[row + 1, col] = SparePartQuationDetails1.Rows[row].ItemArray[col - 1];
                            }
                            /*

                            // Calculate Total Quantity Price in US$
                            int qty = Convert.ToInt32(SparePartQuationDetails1.Rows[row]["Qty"]);
                            float unitPrice = Convert.ToSingle(SparePartQuationDetails1.Rows[row]["UnitPrice"]);
                            float totalQuantityPrice = qty * unitPrice;
                            rawData[row + 1, 5] = totalQuantityPrice; // Corrected index

                            */


                            // Calculate Total Quantity Price in US$
                            int qty = Convert.ToInt32(SparePartQuationDetails1.Rows[row]["Qty"]);
                            //MessageBox.Show(qty);

                            // Convert and format unit price and total quantity price
                            decimal unitPrice = Convert.ToDecimal(SparePartQuationDetails1.Rows[row]["UnitPrice"]);
                            decimal totalQuantityPrice = Convert.ToDecimal(SparePartQuationDetails1.Rows[row]["TotalQuantityPrice"]);

                            // Store with 2 decimal places
                            rawData[row + 1, 4] = unitPrice; // Store formatted unit price
                            rawData[row + 1, 5] = totalQuantityPrice; // Store formatted total quantity price

                        }

                        // Calculate grand total
                        decimal grandTotal = 0;
                        for (int row = 0; row < SparePartQuationDetails1.Rows.Count; row++)
                        {
                            grandTotal += Convert.ToDecimal(rawData[row + 1, 5]);
                        }

                        // Determine Excel range
                        string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        int colCharsetLen = colCharset.Length;
                        string finalColLetter = string.Empty;

                        if (headers.Length > colCharsetLen)
                        {
                            finalColLetter = colCharset.Substring((headers.Length - 1) / colCharsetLen - 1, 1);
                        }
                        finalColLetter += colCharset.Substring((headers.Length - 1) % colCharsetLen, 1);
                        string excelRange = string.Format("A" + iRowIndex + ":{0}{1}", finalColLetter, (SparePartQuationDetails1.Rows.Count + iRowIndex));

                        // Insert data into worksheet
                        var range = NewWorkSheet.get_Range(excelRange, Type.Missing);
                        range.Value2 = rawData;
                        range.WrapText = true; // Wrap text for the entire range
                        // Set font size for the entire range
                        range.Cells.Font.Size = 14;

                        // Format and merge cells
                        CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 6);
                        CellMerge("GridLines", NewWorkSheet, iRowIndex, (iRowIndex + SparePartQuationDetails1.Rows.Count + 3), 1, 6);
                        CellMerge("AlignCenter", NewWorkSheet, iRowIndex, (iRowIndex + SparePartQuationDetails1.Rows.Count), 1, 6);
                        CellMerge("VAlignCenter", NewWorkSheet, iRowIndex, (iRowIndex + SparePartQuationDetails1.Rows.Count), 1, 6);

                        Microsoft.Office.Interop.Excel.Range range2 = NewWorkSheet.get_Range("D" + iRowIndex, "F" + (iRowIndex + 3 + SparePartQuationDetails1.Rows.Count) + "");
                        range2.NumberFormat = "#,##0.00";

                        // Add grand total and other information
                        iRowIndex += SparePartQuationDetails1.Rows.Count + 1; // Move to the next row after data
                        NewWorkSheet.Cells[iRowIndex, 2] = "Ex-Works";
                        NewWorkSheet.Cells[iRowIndex, 6] = grandTotal; // Assuming grand total is displayed in the 6th column
                                                                       // Set font size for "Ex-Works" row
                        var exWorksRange = NewWorkSheet.get_Range("A" + iRowIndex + ":F" + iRowIndex);
                        exWorksRange.Cells.Font.Size = 14;

                        // Merge and align cells
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                        CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 5);
                        // Center align cells
                        CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);

                        iRowIndex++;
                        NewWorkSheet.Cells[iRowIndex, 2] = "Add: Export Packing, Handling";
                        decimal dPIGST1 = 250m; // Fixed value
                        NewWorkSheet.Cells[iRowIndex, 6] = dPIGST1.ToString();
                        // Set font size for "Add: Export Packing, Handling" row
                        var addExportPackingRange = NewWorkSheet.get_Range("A" + iRowIndex + ":F" + iRowIndex);
                        addExportPackingRange.Cells.Font.Size = 14;
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                        CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 5);
                        // Center align cells
                        CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);

                        iRowIndex++;
                        NewWorkSheet.Cells[iRowIndex, 2] = SparePartQuationDetails.Rows[0]["DeliveryTerm"].ToString();
                        decimal dPIGST = 250m; // Fixed value
                        NewWorkSheet.Cells[iRowIndex, 6] = dPIGST.ToString();
                        // Set font size for "DeliveryTerm" row
                        var deliveryTermRange = NewWorkSheet.get_Range("A" + iRowIndex + ":F" + iRowIndex);
                        deliveryTermRange.Cells.Font.Size = 14;
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                        CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 5);
                        CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                        CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);

                        iRowIndex++;
                        NewWorkSheet.Cells[iRowIndex, 2] = "Grand Total";
                        NewWorkSheet.Cells[iRowIndex, 6] = grandTotal + dPIGST + dPIGST1;
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                        CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 6);
                        CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                        CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex, 1, 6);
                        // Center align cells
                        CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 5, 8);
                        // Set font size for Grand Total row
                        var grandTotalRange = NewWorkSheet.get_Range("A" + iRowIndex + ":F" + iRowIndex);
                        grandTotalRange.Cells.Font.Size = 14;

                        iRowIndex++;
                        iRowIndex++;
                        iRowIndex++;
                        iRowIndex++;
                        iRowIndex++;
                        iRowIndex++;
                        iRowIndex++;










                        NewWorkSheet.Cells[iRowIndex, 1] = "Payment Terms:";
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 6);
                        CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 6);
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 6);
                        iRowIndex++;

                        NewWorkSheet.Cells[iRowIndex, 1] = "1. Please release the order in the name of Instron, a Division of Illinois Tool Works Inc. Detailed address is mentioned in clause TC-06 under Terms and Conditions.";
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 6);
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 6);
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 2, 6);

                        CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 6);
                        iRowIndex = iRowIndex + 3;
                        //--------------------------------------------

                        NewWorkSheet.Cells[iRowIndex, 1] = "2. Please email signed order in advance to Nagashree_R@instron.com for quick order processing.";
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 1, 1, 6);
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 1, 1, 6);
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 6);
                        CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 1, 1, 6);
                        iRowIndex = iRowIndex + 2;
                        //-------------------------------------------

                        NewWorkSheet.Cells[iRowIndex, 1] = "3. In case of any queries on any of terms and conditions, please contact the undersigned on +91 9611072610.";
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 1, 1, 6);
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 1, 1, 6);
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 6);
                        CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 1, 1, 6);
                        iRowIndex = iRowIndex + 2;
                        //------------------------------------------
                        NewWorkSheet.HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);

                        iRowIndex++;
                        NewWorkSheet.Cells[iRowIndex, 1] = "Terms and Conditions:";
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 6);
                        CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 6);
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 6);
                        iRowIndex++;
                        // Add border to the first cell before merging
                        NewWorkSheet.Cells[iRowIndex, 1].BorderAround();
                        // Set the cell value for the first cell
                        NewWorkSheet.Cells[iRowIndex, 1] = "24514";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 13, 1, 1);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 13, 1, 1);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                        // Add border around the merged cells
                        CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 13, 1, 6);
                        // Set the cell value for the second cell
                        NewWorkSheet.Cells[iRowIndex, 2] = "EXPORT CONTROL \n The Customer acknowledges that the export of Goods and Technology herein is/ maybe subject to the export control regulations of the United Kingdom and / or the United States, as amended.And agree as a condition of acceptance of this quotation / contract and issuance of any subsequent order or contract hereto, that the Goods and Technology will not be used for purposes associated with any chemical, biological, nuclear weapons, or missiles capable of delivering such weapons, or in support of any terrorist activity or any other WMD end use.Nor will they be re - sold or transferred if it is known or suspected that they are intended to be used for such purposes.If any requisite governmental licence, consent or permit or other authorisation cannot be obtained in fulfilment of any subsequent order or contract hereto, Instron shall not be liable to The Customer in respect of any bond or guarantee or for any loss, damage, consequences, or other resultant financial penalty.";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 13, 2, 6);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 13, 2, 6);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 2, 6);
                        // Add border around the merged cells
                        CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 13, 2, 6);

                        // Increment iRowIndex to move to the next set of rows
                        iRowIndex = iRowIndex + 14;
                        //  NewWorkSheet.HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);
                        //1---------------------------------------------------

                        // Add border to the first cell before merging
                        NewWorkSheet.Cells[iRowIndex, 1].BorderAround();
                        // Set the cell value for the first cell
                        NewWorkSheet.Cells[iRowIndex, 1] = "TC-01";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 1);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 1);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                        // Add border around the merged cells
                        CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 6);
                        // Set the cell value for the second cell
                        NewWorkSheet.Cells[iRowIndex, 2] = "FOR ORDERS LESS THAN US Dollars 20000 Payment against proforma invoice by Advance TT remittance into the following Account.The Northern Trust Company, Chicago, IL, USA Swift No. CNORUS44 ABA No. 071000152 Account No. 51191642";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 3, 2, 6);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 3, 2, 6);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 2, 6);
                        // Add border around the merged cells
                        CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 3, 2, 6);

                        // Increment iRowIndex to move to the next set of rows
                        iRowIndex = iRowIndex + 4;
                        //end1------------------------------------------------



                        //2---------------------------------------------------

                        // Add border to the first cell before merging
                        NewWorkSheet.Cells[iRowIndex, 1].BorderAround();
                        // Set the cell value for the first cell
                        NewWorkSheet.Cells[iRowIndex, 1] = "TC-02";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 5, 1, 1);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 5, 1, 1);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                        // Add border around the merged cells
                        CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 5, 1, 6);
                        // Set the cell value for the second cell
                        NewWorkSheet.Cells[iRowIndex, 2] = "FOR ORDERS MORE THAN US Dollars 20000 \n Payment By Irrevocable Letter of Credit valid for at - least 90 days confirmed through Any major Bank in U.S.OR through RBS Citizens, NA International Trade Services, Mail Stop MMF470, 20 Cabot Road, Medford MA 02155 USA Swift No.CTZIUS33     ABA No. 211070175      Telex No. 211047 CTZINTLUR ";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 5, 2, 6);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 5, 2, 6);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 2, 6);
                        // Add border around the merged cells
                        CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 5, 2, 6);

                        // Increment iRowIndex to move to the next set of rows
                        iRowIndex = iRowIndex + 6;
                        //end2------------------------------------------------
                        //3---------------------------------------------------

                        // Add border to the first cell before merging
                        NewWorkSheet.Cells[iRowIndex, 1].BorderAround();
                        // Set the cell value for the first cell
                        NewWorkSheet.Cells[iRowIndex, 1] = "TC-03";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 4, 1, 1);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 4, 1, 1);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                        // Add border around the merged cells
                        CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 4, 1, 6);
                        // Set the cell value for the second cell
                        NewWorkSheet.Cells[iRowIndex, 2] = "DELIVERY \n 6 weeks on receipt of the order and payment / Opening of LC subject to Export Licence wherever is applicable.This is a standard delivery term and delivery period will be re-confirmed once the order is received and processed.";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 4, 2, 6);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 4, 2, 6);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 2, 6);
                        // Add border around the merged cells
                        CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 4, 2, 6);

                        // Increment iRowIndex to move to the next set of rows
                        iRowIndex = iRowIndex + 5;
                        //end3------------------------------------------------

                        //4---------------------------------------------------

                        // Add border to the first cell before merging
                        NewWorkSheet.Cells[iRowIndex, 1].BorderAround();
                        // Set the cell value for the first cell
                        NewWorkSheet.Cells[iRowIndex, 1] = "TC-04";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 1);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 1);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                        // Add border around the merged cells
                        CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 6);
                        // Set the cell value for the second cell
                        NewWorkSheet.Cells[iRowIndex, 2] = "VALIDITY \n This quotation is valid only up to 90 days from date of issue.In case you are releasing the order beyond this period, please seek for re - issue of quotation for price validation.";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 3, 2, 6);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 3, 2, 6);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 2, 6);
                        // Add border around the merged cells
                        CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 3, 2, 6);

                        // Increment iRowIndex to move to the next set of rows
                        iRowIndex = iRowIndex + 4;
                        //end4------------------------------------------------
                        //5---------------------------------------------------

                        // Add border to the first cell before merging
                        NewWorkSheet.Cells[iRowIndex, 1].BorderAround();
                        // Set the cell value for the first cell
                        NewWorkSheet.Cells[iRowIndex, 1] = "TC-05";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 1);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 1);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                        // Add border around the merged cells
                        CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 6);
                        // Set the cell value for the second cell
                        NewWorkSheet.Cells[iRowIndex, 2] = "INSTALLATION: \n Only one-time Installation of Spare will do in One day.";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 2, 6);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 2, 2, 6);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 2, 6);
                        // Add border around the merged cells
                        CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 2, 2, 6);

                        // Increment iRowIndex to move to the next set of rows
                        iRowIndex = iRowIndex + 3;
                        //end5------------------------------------------------
                        //6---------------------------------------------------

                        // Add border to the first cell before merging
                        NewWorkSheet.Cells[iRowIndex, 1].BorderAround();
                        // Set the cell value for the first cell
                        NewWorkSheet.Cells[iRowIndex, 1] = "TC-06";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 6, 1, 1);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 6, 1, 1);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                        // Add border around the merged cells
                        CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 6, 1, 6);
                        // Set the cell value for the second cell
                        NewWorkSheet.Cells[iRowIndex, 2] = "WARRANTY – SPARES \n All Spares are guaranteed for 3 months from the date of installation or 5 months from date of shipment whichever is earlier.Any parts that found defective during the guarantee period and is covered by warranty clause of our principals, will be replaced free of cost on CIP basis.Such spares are directly sent to you, and you shall arrange for its clearance from the Customs.Any charges payable at the time of Customs Clearance will be borne by you.";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 6, 2, 6);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 6, 2, 6);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 2, 6);
                        // Add border around the merged cells
                        CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 6, 2, 6);

                        // Increment iRowIndex to move to the next set of rows
                        iRowIndex = iRowIndex + 7;
                        //end6------------------------------------------------

                        //7---------------------------------------------------

                        // Add border to the first cell before merging
                        NewWorkSheet.Cells[iRowIndex, 1].BorderAround();
                        // Set the cell value for the first cell
                        NewWorkSheet.Cells[iRowIndex, 1] = "TC-07";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 5, 1, 1);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 5, 1, 1);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                        // Add border around the merged cells
                        CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 5, 1, 6);
                        // Set the cell value for the second cell
                        NewWorkSheet.Cells[iRowIndex, 2] = "NOTE 1 \n Please address your order to INSTRON, a Division of Illinois Tool Works Inc, 825, University Avenue, Norwood, MA 02062 – 2643, USA and forward the same to ITW India Private Limited, ITW India Pvt Ltd No. 497E. 14th Cross, 4th Phase, Peenya Industrial Area, Bangalore – 560 058.India";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 5, 2, 6);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 5, 2, 6);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 2, 5);
                        // Add border around the merged cells
                        CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 5, 2, 6);

                        // Increment iRowIndex to move to the next set of rows
                        iRowIndex = iRowIndex + 6;
                        //end7------------------------------------------------
                        //8---------------------------------------------------

                        // Add border to the first cell before merging
                        NewWorkSheet.Cells[iRowIndex, 1].BorderAround();
                        // Set the cell value for the first cell
                        NewWorkSheet.Cells[iRowIndex, 1] = "TC-08";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 1);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 1);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                        // Add border around the merged cells
                        CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 6);
                        // Set the cell value for the second cell
                        NewWorkSheet.Cells[iRowIndex, 2] = "NOTE 2 \n When ordering, would you please ensure that the machine type and serial number for which the spares are required is mentioned in full on your purchase order";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 3, 2, 6);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 3, 2, 6);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 2, 6);
                        // Add border around the merged cells
                        CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 3, 2, 6);

                        // Increment iRowIndex to move to the next set of rows
                        iRowIndex = iRowIndex + 4;
                        //end8------------------------------------------------

                        //8---------------------------------------------------




                        //bhavya---------------------------------------------------

                        // Add border to the first cell before merging
                        NewWorkSheet.Cells[iRowIndex, 1].BorderAround();
                        // Set the cell value for the first cell
                        NewWorkSheet.Cells[iRowIndex, 1] = "TC-09";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 1);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 1);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 1);
                        // Add border around the merged cells
                        CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 6);
                        // Set the cell value for the second cell
                        NewWorkSheet.Cells[iRowIndex, 2] = "NOTE 3 \n Above quoted prices are exclusive of installation charges and applicable only for the current offer the prices may change for future requirements";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 3, 2, 6);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 3, 2, 6);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 2, 6);
                        // Add border around the merged cells
                        CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 3, 2, 6);

                        // Increment iRowIndex to move to the next set of rows
                        iRowIndex = iRowIndex + 4;
                        //bhavya------------------------------------------------


                        // Add border to the first cell before merging
                        NewWorkSheet.Cells[iRowIndex, 1].BorderAround();
                        // Set the cell value for the first cell
                        NewWorkSheet.Cells[iRowIndex, 1] = "If you need any further details /information, please contact us. We look forward to receiving your valued order and payment at the earliest. Thanking you and assuring you of our best services and attention to all your needs on mutually beneficial terms.";
                        // Merge cells from iRowIndex to iRowIndex + 11 for columns 3 to 5
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 6);
                        // Align the merged cells' content to the top
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex + 3, 1, 6);
                        // Wrap the text within the merged cells
                        CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 6);

                        iRowIndex = iRowIndex + 4;
                        //end8------------------------------------------------

                        //-------------------------------------
                        NewWorkSheet.Cells[iRowIndex, 1] = "Yours truly \n For ITW India Private Limited(Instron Division) ";
                        CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 6);
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 6);

                        iRowIndex = iRowIndex + 3;

                        iRowIndex++;
                        iRowIndex++;
                        NewWorkSheet.Cells[iRowIndex, 1] = "Nagashree. R| Service Business co-ordinator | Nagashree_R@instron.com|+91 9611072610";
                        CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 6);
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 6);
                        iRowIndex++;
                    }

                    //CellMerge("BorderAround", NewWorkSheet, 1, iRowIndex, 1, 5);
                    NewWorkSheet.Range["A1:E" + (iRowIndex) + ""].Cells.Font.Size = 14;
                    //NewWorkSheet.Range["A12:E12"].Cells.Font.Bold = true;
                    NewWorkSheet.Range["A12:E12"].Cells.Font.Size = 16;
                    //NewWorkSheet.Range["A9:B9"].Cells.Font.Size = 18;
                    //NewWorkSheet.Range["A9:B9"].Cells.Font.Bold = true;
                    //NewWorkSheet.Range["A5:B5"].Cells.Font.Size = 16;
                    //NewWorkSheet.Range["A5:B5"].Cells.Font.Bold = true;
                    NewWorkSheet.Rows.AutoFit();

                    NewWorkSheet.Columns[1].ColumnWidth = 12;
                    NewWorkSheet.Columns[2].ColumnWidth = 16;
                    NewWorkSheet.Columns[2].WrapText = true;
                    NewWorkSheet.Columns[3].ColumnWidth = 55;
                    NewWorkSheet.Columns[3].WrapText = true;
                    NewWorkSheet.Columns[4].ColumnWidth = 10;
                    NewWorkSheet.Columns[5].ColumnWidth = 16;
                    NewWorkSheet.Columns[5].WrapText = true;
                    NewWorkSheet.Columns[6].ColumnWidth = 16;



                    NewWorkSheet.PageSetup.PrintArea = "A1:F" + (iRowIndex) + "";

                    NewWorkSheet.PageSetup.PrintNotes = true;
                    NewWorkSheet.PageSetup.CenterHorizontally = true;
                    //NewWorkSheet.PageSetup.Zoom = 75;
                    NewWorkSheet.PageSetup.Zoom = 65;
                    NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                    NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;


                    //if (SparePartQuationDetails.Rows[0]["Currency"].ToString() == "USD")
                    //{
                    //    NewWorkSheet.PageSetup.CenterFooter = "&\"Calibri,Bold\"&12 ITW India Private Limited,\n ITW India Pvt Ltd No. 497E. 14th Cross, 4th Phase, Peenya Industrial Area, Bangalore – 560 058.India";
                    //    NewWorkSheet.PageSetup.CenterHeaderPicture.Filename = "C:\\Databasepath\\InstronLogo3.jpg";
                    //    NewWorkSheet.PageSetup.CenterHeader = "&G";
                    //}
                    if (SparePartQuationDetails.Rows[0]["Currency"].ToString() == "USD")
                    {
                        // Set footer text (this is safe)
                        NewWorkSheet.PageSetup.CenterFooter = "&\"Calibri,Bold\"&12 ITW India Private Limited,\n ITW India Pvt Ltd No. 497E. 14th Cross, 4th Phase, Peenya Industrial Area, Bangalore – 560 058.India";

                        string headerImagePath = "C:\\Databasepath\\InstronLogo3.jpg";

                        if (File.Exists(headerImagePath))
                        {
                            try
                            {
                                // ✅ 1. Insert image in cell F2 for reliability
                                //EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 6]; // F2
                                //Image oImage = Image.FromFile(headerImagePath);
                                //Clipboard.SetDataObject(oImage, true);
                                //System.Threading.Thread.Sleep(500); // Ensure clipboard is ready
                                //NewWorkSheet.Paste(oRange);

                               

                                // ✅ 2. Then try to insert into CenterHeader
                                NewWorkSheet.PageSetup.CenterHeaderPicture.Filename = headerImagePath;
                                NewWorkSheet.PageSetup.CenterHeader = "&G";
                            }
                            catch (COMException comEx)
                            {
                                MessageBox.Show("COM error during header image insert: " + comEx.Message);
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Unexpected error inserting header image: " + ex.Message);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Image file not found at: " + headerImagePath);
                        }
                    }
                    //if (SparePartQuationDetails.Rows[0]["Currency"].ToString() == "USD")
                    //{
                    //    // Set footer text (this is safe)
                    //    NewWorkSheet.PageSetup.CenterFooter = "&\"Calibri,Bold\"&12 ITW India Private Limited,\n ITW India Pvt Ltd No. 497E. 14th Cross, 4th Phase, Peenya Industrial Area, Bangalore – 560 058.India";

                    //    string headerImagePath = "C:\\Databasepath\\InstronLogo3.jpg";

                    //    if (File.Exists(headerImagePath))
                    //    {
                    //        try
                    //        {
                    //            // ✅ 1. Insert image in cell F2 for reliability
                    //            EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 6]; // F2
                    //            Image oImage = Image.FromFile(headerImagePath);
                    //            Clipboard.SetDataObject(oImage, true);
                    //            System.Threading.Thread.Sleep(500); // Ensure clipboard is ready
                    //            NewWorkSheet.Paste(oRange);


                    //            // ✅ 2. Then try to insert into CenterHeader
                    //            NewWorkSheet.PageSetup.CenterHeaderPicture.Filename = headerImagePath;
                    //            NewWorkSheet.PageSetup.CenterHeader = "&G";
                    //        }
                    //        catch (COMException comEx)
                    //        {
                    //            MessageBox.Show("COM error during header image insert: " + comEx.Message);
                    //        }
                    //        catch (Exception ex)
                    //        {
                    //            MessageBox.Show("Unexpected error inserting header image: " + ex.Message);
                    //        }
                    //    }
                    //    else
                    //    {
                    //        MessageBox.Show("Image file not found at: " + headerImagePath);
                    //    }
                    //}


                    //if (SparePartQuationDetails.Rows[0]["Currency"].ToString() == "INR")
                    //{
                    //    /*

                    //    NewWorkSheet.PageSetup.CenterHeaderPicture.Filename = "C:\\Databasepath\\BiSSServiceQuoteHeader.jpg";
                    //    NewWorkSheet.PageSetup.CenterHeader = "&G";

                    //    string picturePath = "C:\\Databasepath\\BiSSServiceQuoteFooter.jpg"; // specify your picture path here

                    //    // Set the footer picture directly without adding it to the body
                    //    NewWorkSheet.PageSetup.CenterFooterPicture.Filename = picturePath;
                    //    NewWorkSheet.PageSetup.CenterFooter = "&G"; // This adds the picture to the footer
                    //    */
                    //    NewWorkSheet.PageSetup.CenterFooter = "&\"Calibri,Bold\"&14 ITW India Private Limited,\n ITW India Pvt Ltd No. 497E. 14th Cross, 4th Phase, Peenya Industrial Area, Bangalore – 560 058.India";
                    //    NewWorkSheet.PageSetup.CenterHeaderPicture.Filename = "C:\\Databasepath\\InstronLogo3.jpg";
                    //    NewWorkSheet.PageSetup.CenterHeader = "&G";
                    //}

                    if (SparePartQuationDetails.Rows[0]["Currency"].ToString() == "INR")
                    {
                        // ✅ Set footer text
                        NewWorkSheet.PageSetup.CenterFooter = "&\"Calibri,Bold\"&14 ITW India Private Limited,\n ITW India Pvt Ltd No. 497E. 14th Cross, 4th Phase, Peenya Industrial Area, Bangalore – 560 058.India";

                        string logoPath = "C:\\Databasepath\\InstronLogo3.jpg";

                        if (File.Exists(logoPath))
                        {
                            try
                            {
                                //// ✅ Paste image in cell F2 to simulate header
                                //EXCEL.Range headerCell = (EXCEL.Range)NewWorkSheet.Cells[2, 6]; // F2
                                //Image logoImage = Image.FromFile(logoPath);
                                //Clipboard.SetImage(logoImage);

                                //System.Threading.Thread.Sleep(500); // Let clipboard settle

                                //NewWorkSheet.Paste(headerCell);

                                // ✅ 2. Then try to insert into CenterHeader
                                NewWorkSheet.PageSetup.CenterHeaderPicture.Filename = logoPath;
                                NewWorkSheet.PageSetup.CenterHeader = "&G"; // adjust for horizontal centering
                            }
                            catch (COMException comEx)
                            {
                                MessageBox.Show("COM error during header image insert: " + comEx.Message);
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Unexpected error inserting header image: " + ex.Message);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Image file not found at: " + logoPath);
                        }
                    }





                    NewWorkBook.Save();
                    ExcelApp.Visible = false;
                    ExcelApp.ActiveWorkbook.Saved = true;
                    NewWorkBook.ExportAsFixedFormat(EXCEL.XlFixedFormatType.xlTypePDF, FileFul, EXCEL.XlFixedFormatQuality.xlQualityStandard, true);

                    NewWorkBook.Close(true, misValue, misValue);
                    ExcelApp.Quit();
                    releaseObject(NewWorkSheet);
                    releaseObject(NewWorkBook);
                    releaseObject(ExcelApp);
                    System.Diagnostics.Process.Start(FileFul);


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    //foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                    //{
                    //    GetProcess.Kill();
                    //}
                }
            }
            else
            {
                MessageBox.Show("No items to save", "Error", 0, MessageBoxIcon.Question);
            }
        }




        #region CellMerge Funtion
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "ThickBorder":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "GridLines":
                    {
                        CELLS.Borders.Color = System.Drawing.Color.Black;
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignCenter":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                        break;
                    }

                case "WrapText":
                    {
                        CELLS.WrapText = true;
                        break;
                    }

                case "AlignRight":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                        break;
                    }
                case "AlignLeft":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignLeft;
                        break;
                    }
                case "TextAlign":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignJustify;
                        break;
                    }
                case "AlignTop":
                    {
                        CELLS.VerticalAlignment = EXCEL.XlVAlign.xlVAlignTop;
                        break;
                    }
                case "VAlignCenter":
                    {
                        CELLS.VerticalAlignment = EXCEL.XlVAlign.xlVAlignCenter;
                        break;
                    }

                case "Bold":
                    {
                        CELLS.Font.Bold = true;
                        break;
                    }

                case "Autofit":
                    {
                        CELLS.Rows.AutoFit();
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

        }
        #endregion

        #region Excel App Release Object Function
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
        #endregion
        DataTable parepartdetail = new DataTable();
        private void comQuotationNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnSave.Enabled = false;
            if (comQuotationNo.SelectedIndex >= 0)
            {
                // Fetch and display data based on the selected quotation number
                DataTable parepartdetail = DAL.fnsparepartdetails(0, comQuotationNo.Text).Tables[0];
                if (parepartdetail.Rows.Count > 0)
                {
                    txtCALCustomer.Text = parepartdetail.Rows[0]["CustomerName"].ToString();
                    textquotationNo.Text = parepartdetail.Rows[0]["QuotationNo"].ToString();
                    txtCALEmailID.Text = parepartdetail.Rows[0]["EmailId"].ToString();
                    txtCALAddress.Text = parepartdetail.Rows[0]["Address"].ToString();
                    txtCALTel.Text = parepartdetail.Rows[0]["PhoneNumber"].ToString();
                    txtCALContactPerson.Text = parepartdetail.Rows[0]["ContactPerson"].ToString();
                    txtCalQuotename.Text = parepartdetail.Rows[0]["QuotationName"].ToString();
                    textDeliveryTerm.Text = parepartdetail.Rows[0]["DeliveryTerm"].ToString();
                    CmbCurrency.Text = parepartdetail.Rows[0]["Currency"].ToString();
                    cmbCALQuoteFor.Text = parepartdetail.Rows[0]["Quotationfor"].ToString();
                    txtCALModelNo.Text = parepartdetail.Rows[0]["QuotationSerialNo"].ToString();

                }


            }
        }


        private void btnGenaratePO_Click(object sender, EventArgs e)
        {
            bool isAnyRowSelected = false;
            string message = "";


            DataTable isDuplicateKeyTableQuateNo = DAL.CheckDuplicateKeyQuateNo(0, textquotationNo.Text).Tables[0];
            if (isDuplicateKeyTableQuateNo.Rows.Count > 0)
            {
                MessageBox.Show("Quotation Number already exists.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textquotationNo.Focus();
                return;

            }

            foreach (DataGridViewRow row in dgItemOrProductList.Rows)
            {
                DataGridViewCheckBoxCell chkCell = (DataGridViewCheckBoxCell)row.Cells[6];

                if (chkCell.Value != null && (bool)chkCell.Value)
                {
                    isAnyRowSelected = true;

                    string PartNumber = row.Cells["PartNumber"].Value?.ToString() ?? "";
                    string PartDescription = row.Cells["PartDescription"].Value?.ToString() ?? "";
                    if (int.TryParse(row.Cells["Qty"].Value?.ToString(), out int Qty) &&
                        decimal.TryParse(row.Cells["Colunitprice"].Value?.ToString(), out decimal UnitPrice) &&
                        decimal.TryParse(row.Cells["Coltotal"].Value?.ToString(), out decimal TotalQuantityPrice))
                    {
                        string currentDateString = DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss");

                        // Attempt to save the spare part data
                        try
                        {
                            GlobalClass.iStatus = DAL.SparePartQuationDetails(0,
                                textquotationNo.Text,
                                txtCALContactPerson.Text,
                                txtCALCustomer.Text,
                                txtCALTel.Text,
                                txtCALEmailID.Text,
                                txtCALAddress.Text,
                                txtCalQuotename.Text,
                                CmbCurrency.Text,
                                cmbCALQuoteFor.Text,
                                txtCALModelNo.Text,
                                textDeliveryTerm.Text,
                                PartNumber,
                                PartDescription,
                                Qty,
                                UnitPrice,
                                TotalQuantityPrice,
                                login.GetUserDetails[2],
                                currentDateString);

                            MessageBox.Show("Spare Part data inserted", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Error saving data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid data in the selected row. Please check the quantity, unit price, and total price.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }
            }

            if (!isAnyRowSelected)
            {
                MessageBox.Show("No rows are selected. Please select at least one item before revising data.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            this.Hide();
            Spare_parts spareParts = new Spare_parts();
            spareParts.Show();
            ResetForm();
        }

        private void chkQuoteSavePath_CheckedChanged(object sender, EventArgs e)
        {
            if (chkQuoteSavePath.CheckState == CheckState.Checked)
            {
                if (MessageBox.Show("The default save location for quotes is '" + Properties.Settings.Default.ServiceQuotePath + "'\nClick on Yes to change the quote save location", "Save location", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                {
                    DialogResult result = folderBrowserDialog1.ShowDialog();
                    if (result == DialogResult.OK)
                    {
                        Properties.Settings.Default.ServiceQuotePath = folderBrowserDialog1.SelectedPath;
                        //Properties.Settings.Default.FolderPath = folderBrowserDialog1.SelectedPath;
                        Properties.Settings.Default.Save();
                        MessageBox.Show("The default save location for quotes changed to the selected path '" + Properties.Settings.Default.ServiceQuotePath + "'", "Success", 0, MessageBoxIcon.Information);
                        chkQuoteSavePath.Checked = false;
                    }
                    else
                    {
                        chkQuoteSavePath.Checked = false;
                    }
                }
                else
                {
                    chkQuoteSavePath.Checked = false;
                }
            }
        }
    }
}
