﻿namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    partial class frmSalesProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSalesProduct));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnAddProduct = new System.Windows.Forms.Button();
            this.btnAddFolder = new System.Windows.Forms.Button();
            this.btnQuoteTreeSave = new System.Windows.Forms.Button();
            this.txtName = new System.Windows.Forms.TextBox();
            this.chkProductCode = new System.Windows.Forms.CheckBox();
            this.cleartreeview = new System.Windows.Forms.Button();
            this.txtsearchtree = new System.Windows.Forms.TextBox();
            this.btnsearchtree = new System.Windows.Forms.Button();
            this.tvProduct = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.lblWelcome = new System.Windows.Forms.Label();
            this.lblbomby = new System.Windows.Forms.Label();
            this.pnProductcode = new System.Windows.Forms.Panel();
            this.btnExit = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSalesCost = new System.Windows.Forms.TextBox();
            this.btnUpdateProduct = new System.Windows.Forms.Button();
            this.txtProductCost = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtProductDesc = new System.Windows.Forms.TextBox();
            this.txtProductCode = new System.Windows.Forms.TextBox();
            this.txtProductName = new System.Windows.Forms.TextBox();
            this.lblpname = new System.Windows.Forms.Label();
            this.lblpcode = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblIndent = new System.Windows.Forms.Label();
            this.chkxcelupload = new System.Windows.Forms.CheckBox();
            this.pnExcelItemCode = new System.Windows.Forms.Panel();
            this.lblCount = new System.Windows.Forms.Label();
            this.pnexcelupload = new System.Windows.Forms.Panel();
            this.btnUpload = new System.Windows.Forms.Button();
            this.btnbrowse = new System.Windows.Forms.Button();
            this.txtbrowseaddres = new System.Windows.Forms.TextBox();
            this.dgvxcelupload = new System.Windows.Forms.DataGridView();
            this.ProductCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SalesCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.chkDownload = new System.Windows.Forms.CheckBox();
            this.chkDownloadFolder = new System.Windows.Forms.CheckBox();
            this.chkUpdateProductCost = new System.Windows.Forms.CheckBox();
            this.pnCostUpdate = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.OTCbtnCostUpdate = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.OTCtxtCostUPdate = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnCostUpdate = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCostUPdate = new System.Windows.Forms.TextBox();
            this.panel3.SuspendLayout();
            this.pnProductcode.SuspendLayout();
            this.panel2.SuspendLayout();
            this.pnExcelItemCode.SuspendLayout();
            this.pnexcelupload.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvxcelupload)).BeginInit();
            this.pnCostUpdate.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.btnAddProduct);
            this.panel3.Controls.Add(this.btnAddFolder);
            this.panel3.Controls.Add(this.btnQuoteTreeSave);
            this.panel3.Controls.Add(this.txtName);
            this.panel3.Controls.Add(this.chkProductCode);
            this.panel3.Controls.Add(this.cleartreeview);
            this.panel3.Controls.Add(this.txtsearchtree);
            this.panel3.Controls.Add(this.btnsearchtree);
            this.panel3.Controls.Add(this.tvProduct);
            this.panel3.Location = new System.Drawing.Point(4, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(379, 673);
            this.panel3.TabIndex = 132;
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAddProduct.Enabled = false;
            this.btnAddProduct.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAddProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddProduct.Location = new System.Drawing.Point(151, 562);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(112, 31);
            this.btnAddProduct.TabIndex = 201;
            this.btnAddProduct.Text = "Add Product";
            this.btnAddProduct.UseVisualStyleBackColor = false;
            this.btnAddProduct.Click += new System.EventHandler(this.btnAddProduct_Click);
            // 
            // btnAddFolder
            // 
            this.btnAddFolder.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAddFolder.Enabled = false;
            this.btnAddFolder.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAddFolder.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddFolder.Location = new System.Drawing.Point(8, 562);
            this.btnAddFolder.Name = "btnAddFolder";
            this.btnAddFolder.Size = new System.Drawing.Size(116, 31);
            this.btnAddFolder.TabIndex = 200;
            this.btnAddFolder.Text = "Add Folder";
            this.btnAddFolder.UseVisualStyleBackColor = false;
            this.btnAddFolder.Click += new System.EventHandler(this.btnAddFolder_Click);
            // 
            // btnQuoteTreeSave
            // 
            this.btnQuoteTreeSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnQuoteTreeSave.Enabled = false;
            this.btnQuoteTreeSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnQuoteTreeSave.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuoteTreeSave.Location = new System.Drawing.Point(260, 631);
            this.btnQuoteTreeSave.Name = "btnQuoteTreeSave";
            this.btnQuoteTreeSave.Size = new System.Drawing.Size(105, 33);
            this.btnQuoteTreeSave.TabIndex = 199;
            this.btnQuoteTreeSave.Text = "Save";
            this.btnQuoteTreeSave.UseVisualStyleBackColor = false;
            this.btnQuoteTreeSave.Click += new System.EventHandler(this.btnQuoteTreeSave_Click);
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(4, 599);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(361, 26);
            this.txtName.TabIndex = 198;
            this.txtName.Visible = false;
            this.txtName.Enter += new System.EventHandler(this.txtName_Enter);
            this.txtName.Leave += new System.EventHandler(this.txtName_Leave);
            // 
            // chkProductCode
            // 
            this.chkProductCode.AutoSize = true;
            this.chkProductCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.chkProductCode.Location = new System.Drawing.Point(8, 39);
            this.chkProductCode.Name = "chkProductCode";
            this.chkProductCode.Size = new System.Drawing.Size(121, 23);
            this.chkProductCode.TabIndex = 134;
            this.chkProductCode.Text = "Product Code";
            this.chkProductCode.UseVisualStyleBackColor = true;
            // 
            // cleartreeview
            // 
            this.cleartreeview.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cleartreeview.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.cleartreeview.Location = new System.Drawing.Point(294, 39);
            this.cleartreeview.Name = "cleartreeview";
            this.cleartreeview.Size = new System.Drawing.Size(61, 29);
            this.cleartreeview.TabIndex = 131;
            this.cleartreeview.Text = "Clear";
            this.cleartreeview.UseVisualStyleBackColor = true;
            this.cleartreeview.Click += new System.EventHandler(this.cleartreeview_Click);
            // 
            // txtsearchtree
            // 
            this.txtsearchtree.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsearchtree.Location = new System.Drawing.Point(8, 6);
            this.txtsearchtree.Name = "txtsearchtree";
            this.txtsearchtree.Size = new System.Drawing.Size(358, 27);
            this.txtsearchtree.TabIndex = 130;
            this.txtsearchtree.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtsearchtree_KeyUp);
            // 
            // btnsearchtree
            // 
            this.btnsearchtree.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearchtree.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnsearchtree.Location = new System.Drawing.Point(212, 39);
            this.btnsearchtree.Name = "btnsearchtree";
            this.btnsearchtree.Size = new System.Drawing.Size(67, 29);
            this.btnsearchtree.TabIndex = 129;
            this.btnsearchtree.Text = "Search";
            this.btnsearchtree.UseVisualStyleBackColor = true;
            this.btnsearchtree.Click += new System.EventHandler(this.btnsearchtree_Click);
            // 
            // tvProduct
            // 
            this.tvProduct.Cursor = System.Windows.Forms.Cursors.Default;
            this.tvProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tvProduct.HideSelection = false;
            this.tvProduct.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.tvProduct.Location = new System.Drawing.Point(6, 74);
            this.tvProduct.Name = "tvProduct";
            this.tvProduct.Size = new System.Drawing.Size(366, 482);
            this.tvProduct.StateImageList = this.imageList1;
            this.tvProduct.TabIndex = 9;
            this.tvProduct.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.tvProduct_NodeMouseClick);
            this.tvProduct.KeyUp += new System.Windows.Forms.KeyEventHandler(this.tvProduct_KeyUp);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "folderopened_yellow.ico");
            this.imageList1.Images.SetKeyName(1, "diagram_v2_17.ico");
            this.imageList1.Images.SetKeyName(2, "Dryicons-Aesthetica-2-Process-accept.ico");
            this.imageList1.Images.SetKeyName(3, "Dryicons-Aesthetica-2-Process-remove.ico");
            this.imageList1.Images.SetKeyName(4, "Rafiqul-Hassan-Blogger-Settings.ico");
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.ForeColor = System.Drawing.Color.Black;
            this.lblWelcome.Location = new System.Drawing.Point(3, 3);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(92, 22);
            this.lblWelcome.TabIndex = 123;
            this.lblWelcome.Text = "Welcome :";
            // 
            // lblbomby
            // 
            this.lblbomby.AutoSize = true;
            this.lblbomby.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbomby.ForeColor = System.Drawing.Color.Black;
            this.lblbomby.Location = new System.Drawing.Point(94, 3);
            this.lblbomby.Name = "lblbomby";
            this.lblbomby.Size = new System.Drawing.Size(0, 22);
            this.lblbomby.TabIndex = 122;
            // 
            // pnProductcode
            // 
            this.pnProductcode.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnProductcode.Controls.Add(this.btnExit);
            this.pnProductcode.Controls.Add(this.label3);
            this.pnProductcode.Controls.Add(this.txtSalesCost);
            this.pnProductcode.Controls.Add(this.btnUpdateProduct);
            this.pnProductcode.Controls.Add(this.txtProductCost);
            this.pnProductcode.Controls.Add(this.label2);
            this.pnProductcode.Controls.Add(this.label1);
            this.pnProductcode.Controls.Add(this.txtProductDesc);
            this.pnProductcode.Controls.Add(this.txtProductCode);
            this.pnProductcode.Controls.Add(this.txtProductName);
            this.pnProductcode.Controls.Add(this.lblpname);
            this.pnProductcode.Controls.Add(this.lblpcode);
            this.pnProductcode.Location = new System.Drawing.Point(389, 104);
            this.pnProductcode.Name = "pnProductcode";
            this.pnProductcode.Size = new System.Drawing.Size(875, 571);
            this.pnProductcode.TabIndex = 130;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(584, 499);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(90, 39);
            this.btnExit.TabIndex = 78;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(407, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 19);
            this.label3.TabIndex = 77;
            this.label3.Text = "Sales Cost:";
            // 
            // txtSalesCost
            // 
            this.txtSalesCost.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalesCost.Location = new System.Drawing.Point(493, 72);
            this.txtSalesCost.MaxLength = 14;
            this.txtSalesCost.Name = "txtSalesCost";
            this.txtSalesCost.Size = new System.Drawing.Size(181, 27);
            this.txtSalesCost.TabIndex = 76;
            this.txtSalesCost.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSalesCost_KeyPress);
            // 
            // btnUpdateProduct
            // 
            this.btnUpdateProduct.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateProduct.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnUpdateProduct.Location = new System.Drawing.Point(441, 499);
            this.btnUpdateProduct.Name = "btnUpdateProduct";
            this.btnUpdateProduct.Size = new System.Drawing.Size(130, 38);
            this.btnUpdateProduct.TabIndex = 75;
            this.btnUpdateProduct.Text = "Update!";
            this.btnUpdateProduct.UseVisualStyleBackColor = true;
            this.btnUpdateProduct.Click += new System.EventHandler(this.btnUpdateProduct_Click);
            // 
            // txtProductCost
            // 
            this.txtProductCost.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProductCost.Location = new System.Drawing.Point(149, 72);
            this.txtProductCost.MaxLength = 14;
            this.txtProductCost.Name = "txtProductCost";
            this.txtProductCost.Size = new System.Drawing.Size(220, 27);
            this.txtProductCost.TabIndex = 74;
            this.txtProductCost.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtProductCost_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(39, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 19);
            this.label2.TabIndex = 73;
            this.label2.Text = "Product Price:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(55, 197);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 19);
            this.label1.TabIndex = 72;
            this.label1.Text = "Description:";
            // 
            // txtProductDesc
            // 
            this.txtProductDesc.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProductDesc.Location = new System.Drawing.Point(149, 193);
            this.txtProductDesc.Multiline = true;
            this.txtProductDesc.Name = "txtProductDesc";
            this.txtProductDesc.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtProductDesc.Size = new System.Drawing.Size(525, 272);
            this.txtProductDesc.TabIndex = 71;
            // 
            // txtProductCode
            // 
            this.txtProductCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProductCode.Location = new System.Drawing.Point(149, 25);
            this.txtProductCode.MaxLength = 25;
            this.txtProductCode.Name = "txtProductCode";
            this.txtProductCode.Size = new System.Drawing.Size(220, 27);
            this.txtProductCode.TabIndex = 70;
            // 
            // txtProductName
            // 
            this.txtProductName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProductName.Location = new System.Drawing.Point(149, 118);
            this.txtProductName.MaxLength = 150;
            this.txtProductName.Multiline = true;
            this.txtProductName.Name = "txtProductName";
            this.txtProductName.Size = new System.Drawing.Size(525, 53);
            this.txtProductName.TabIndex = 69;
            // 
            // lblpname
            // 
            this.lblpname.AutoSize = true;
            this.lblpname.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpname.ForeColor = System.Drawing.Color.Black;
            this.lblpname.Location = new System.Drawing.Point(33, 122);
            this.lblpname.Name = "lblpname";
            this.lblpname.Size = new System.Drawing.Size(112, 19);
            this.lblpname.TabIndex = 64;
            this.lblpname.Text = "Product Name:";
            // 
            // lblpcode
            // 
            this.lblpcode.AutoSize = true;
            this.lblpcode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpcode.ForeColor = System.Drawing.Color.Black;
            this.lblpcode.Location = new System.Drawing.Point(39, 29);
            this.lblpcode.Name = "lblpcode";
            this.lblpcode.Size = new System.Drawing.Size(106, 19);
            this.lblpcode.TabIndex = 65;
            this.lblpcode.Text = "Product Code:";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.lblIndent);
            this.panel2.Controls.Add(this.lblWelcome);
            this.panel2.Controls.Add(this.lblbomby);
            this.panel2.Location = new System.Drawing.Point(389, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(875, 69);
            this.panel2.TabIndex = 131;
            // 
            // lblIndent
            // 
            this.lblIndent.AutoSize = true;
            this.lblIndent.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIndent.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblIndent.Location = new System.Drawing.Point(340, 12);
            this.lblIndent.Name = "lblIndent";
            this.lblIndent.Size = new System.Drawing.Size(253, 33);
            this.lblIndent.TabIndex = 11;
            this.lblIndent.Text = "Sales Product Master";
            // 
            // chkxcelupload
            // 
            this.chkxcelupload.AutoSize = true;
            this.chkxcelupload.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkxcelupload.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.chkxcelupload.Location = new System.Drawing.Point(389, 79);
            this.chkxcelupload.Name = "chkxcelupload";
            this.chkxcelupload.Size = new System.Drawing.Size(143, 23);
            this.chkxcelupload.TabIndex = 133;
            this.chkxcelupload.Text = "Update Products";
            this.chkxcelupload.UseVisualStyleBackColor = true;
            this.chkxcelupload.CheckedChanged += new System.EventHandler(this.chkxcelupload_CheckedChanged);
            // 
            // pnExcelItemCode
            // 
            this.pnExcelItemCode.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnExcelItemCode.Controls.Add(this.lblCount);
            this.pnExcelItemCode.Controls.Add(this.pnexcelupload);
            this.pnExcelItemCode.Controls.Add(this.dgvxcelupload);
            this.pnExcelItemCode.Location = new System.Drawing.Point(398, 103);
            this.pnExcelItemCode.Name = "pnExcelItemCode";
            this.pnExcelItemCode.Size = new System.Drawing.Size(869, 567);
            this.pnExcelItemCode.TabIndex = 222;
            this.pnExcelItemCode.Visible = false;
            // 
            // lblCount
            // 
            this.lblCount.AutoSize = true;
            this.lblCount.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCount.ForeColor = System.Drawing.Color.Black;
            this.lblCount.Location = new System.Drawing.Point(18, 538);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(30, 22);
            this.lblCount.TabIndex = 223;
            this.lblCount.Text = "**";
            // 
            // pnexcelupload
            // 
            this.pnexcelupload.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnexcelupload.Controls.Add(this.btnUpload);
            this.pnexcelupload.Controls.Add(this.btnbrowse);
            this.pnexcelupload.Controls.Add(this.txtbrowseaddres);
            this.pnexcelupload.Location = new System.Drawing.Point(6, 4);
            this.pnexcelupload.Name = "pnexcelupload";
            this.pnexcelupload.Size = new System.Drawing.Size(856, 58);
            this.pnexcelupload.TabIndex = 222;
            // 
            // btnUpload
            // 
            this.btnUpload.BackColor = System.Drawing.Color.PaleGreen;
            this.btnUpload.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnUpload.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpload.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnUpload.Location = new System.Drawing.Point(728, 9);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(96, 34);
            this.btnUpload.TabIndex = 65;
            this.btnUpload.Text = "Upload";
            this.btnUpload.UseVisualStyleBackColor = false;
            this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click);
            // 
            // btnbrowse
            // 
            this.btnbrowse.BackColor = System.Drawing.Color.PaleGreen;
            this.btnbrowse.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnbrowse.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnbrowse.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnbrowse.Location = new System.Drawing.Point(631, 9);
            this.btnbrowse.Name = "btnbrowse";
            this.btnbrowse.Size = new System.Drawing.Size(84, 34);
            this.btnbrowse.TabIndex = 1;
            this.btnbrowse.Text = "Browse";
            this.btnbrowse.UseVisualStyleBackColor = false;
            this.btnbrowse.Click += new System.EventHandler(this.btnbrowse_Click);
            // 
            // txtbrowseaddres
            // 
            this.txtbrowseaddres.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbrowseaddres.Location = new System.Drawing.Point(3, 15);
            this.txtbrowseaddres.Name = "txtbrowseaddres";
            this.txtbrowseaddres.ReadOnly = true;
            this.txtbrowseaddres.Size = new System.Drawing.Size(616, 26);
            this.txtbrowseaddres.TabIndex = 0;
            // 
            // dgvxcelupload
            // 
            this.dgvxcelupload.AllowUserToAddRows = false;
            this.dgvxcelupload.AllowUserToResizeRows = false;
            this.dgvxcelupload.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dgvxcelupload.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvxcelupload.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvxcelupload.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvxcelupload.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProductCode,
            this.Name,
            this.ProductDescription,
            this.SalesCost,
            this.ProductPrice});
            this.dgvxcelupload.EnableHeadersVisualStyles = false;
            this.dgvxcelupload.Location = new System.Drawing.Point(6, 77);
            this.dgvxcelupload.Name = "dgvxcelupload";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvxcelupload.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvxcelupload.RowHeadersVisible = false;
            this.dgvxcelupload.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvxcelupload.Size = new System.Drawing.Size(856, 456);
            this.dgvxcelupload.TabIndex = 220;
            // 
            // ProductCode
            // 
            this.ProductCode.DataPropertyName = "ProductCode";
            this.ProductCode.HeaderText = "ProductCode";
            this.ProductCode.Name = "ProductCode";
            this.ProductCode.ReadOnly = true;
            this.ProductCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductCode.Width = 97;
            // 
            // Name
            // 
            this.Name.DataPropertyName = "Name";
            this.Name.HeaderText = "Product Name";
            this.Name.Name = "Name";
            this.Name.ReadOnly = true;
            this.Name.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Name.Width = 95;
            // 
            // ProductDescription
            // 
            this.ProductDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ProductDescription.DataPropertyName = "ProductDescription";
            this.ProductDescription.HeaderText = "Product Description";
            this.ProductDescription.Name = "ProductDescription";
            this.ProductDescription.ReadOnly = true;
            this.ProductDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductDescription.Width = 99;
            // 
            // SalesCost
            // 
            this.SalesCost.DataPropertyName = "SalesCost";
            this.SalesCost.HeaderText = "Sales Cost";
            this.SalesCost.Name = "SalesCost";
            this.SalesCost.ReadOnly = true;
            this.SalesCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SalesCost.Width = 74;
            // 
            // ProductPrice
            // 
            this.ProductPrice.DataPropertyName = "ProductPrice";
            this.ProductPrice.HeaderText = "Product Price";
            this.ProductPrice.Name = "ProductPrice";
            this.ProductPrice.ReadOnly = true;
            this.ProductPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductPrice.Width = 90;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // chkDownload
            // 
            this.chkDownload.AutoSize = true;
            this.chkDownload.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkDownload.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.chkDownload.Location = new System.Drawing.Point(862, 79);
            this.chkDownload.Name = "chkDownload";
            this.chkDownload.Size = new System.Drawing.Size(163, 23);
            this.chkDownload.TabIndex = 223;
            this.chkDownload.Text = "Download Products";
            this.chkDownload.UseVisualStyleBackColor = true;
            this.chkDownload.CheckedChanged += new System.EventHandler(this.chkDownload_CheckedChanged);
            // 
            // chkDownloadFolder
            // 
            this.chkDownloadFolder.AutoSize = true;
            this.chkDownloadFolder.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkDownloadFolder.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.chkDownloadFolder.Location = new System.Drawing.Point(1049, 77);
            this.chkDownloadFolder.Name = "chkDownloadFolder";
            this.chkDownloadFolder.Size = new System.Drawing.Size(207, 23);
            this.chkDownloadFolder.TabIndex = 224;
            this.chkDownloadFolder.Text = "Download Selected Folder";
            this.chkDownloadFolder.UseVisualStyleBackColor = true;
            this.chkDownloadFolder.CheckedChanged += new System.EventHandler(this.chkDownloadFolder_CheckedChanged);
            // 
            // chkUpdateProductCost
            // 
            this.chkUpdateProductCost.AutoSize = true;
            this.chkUpdateProductCost.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkUpdateProductCost.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.chkUpdateProductCost.Location = new System.Drawing.Point(540, 77);
            this.chkUpdateProductCost.Name = "chkUpdateProductCost";
            this.chkUpdateProductCost.Size = new System.Drawing.Size(296, 23);
            this.chkUpdateProductCost.TabIndex = 225;
            this.chkUpdateProductCost.Text = "Update Product Cost/OTC Product Cost";
            this.chkUpdateProductCost.UseVisualStyleBackColor = true;
            this.chkUpdateProductCost.CheckedChanged += new System.EventHandler(this.chkUpdateProductCost_CheckedChanged);
            // 
            // pnCostUpdate
            // 
            this.pnCostUpdate.Controls.Add(this.label6);
            this.pnCostUpdate.Controls.Add(this.OTCbtnCostUpdate);
            this.pnCostUpdate.Controls.Add(this.label7);
            this.pnCostUpdate.Controls.Add(this.OTCtxtCostUPdate);
            this.pnCostUpdate.Controls.Add(this.label5);
            this.pnCostUpdate.Controls.Add(this.btnCostUpdate);
            this.pnCostUpdate.Controls.Add(this.label4);
            this.pnCostUpdate.Controls.Add(this.txtCostUPdate);
            this.pnCostUpdate.Location = new System.Drawing.Point(403, 121);
            this.pnCostUpdate.Name = "pnCostUpdate";
            this.pnCostUpdate.Size = new System.Drawing.Size(389, 252);
            this.pnCostUpdate.TabIndex = 226;
            this.pnCostUpdate.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(316, 137);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(21, 19);
            this.label6.TabIndex = 85;
            this.label6.Text = "%";
            // 
            // OTCbtnCostUpdate
            // 
            this.OTCbtnCostUpdate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OTCbtnCostUpdate.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.OTCbtnCostUpdate.Location = new System.Drawing.Point(228, 175);
            this.OTCbtnCostUpdate.Name = "OTCbtnCostUpdate";
            this.OTCbtnCostUpdate.Size = new System.Drawing.Size(87, 31);
            this.OTCbtnCostUpdate.TabIndex = 84;
            this.OTCbtnCostUpdate.Text = "Update";
            this.OTCbtnCostUpdate.UseVisualStyleBackColor = true;
            this.OTCbtnCostUpdate.Click += new System.EventHandler(this.OTCbtnCostUpdate_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(4, 137);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(218, 19);
            this.label7.TabIndex = 83;
            this.label7.Text = "OTC Product Cost Variation in :";
            // 
            // OTCtxtCostUPdate
            // 
            this.OTCtxtCostUPdate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OTCtxtCostUPdate.Location = new System.Drawing.Point(228, 134);
            this.OTCtxtCostUPdate.MaxLength = 14;
            this.OTCtxtCostUPdate.Name = "OTCtxtCostUPdate";
            this.OTCtxtCostUPdate.Size = new System.Drawing.Size(82, 27);
            this.OTCtxtCostUPdate.TabIndex = 82;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(314, 49);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(21, 19);
            this.label5.TabIndex = 81;
            this.label5.Text = "%";
            // 
            // btnCostUpdate
            // 
            this.btnCostUpdate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCostUpdate.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnCostUpdate.Location = new System.Drawing.Point(228, 87);
            this.btnCostUpdate.Name = "btnCostUpdate";
            this.btnCostUpdate.Size = new System.Drawing.Size(87, 31);
            this.btnCostUpdate.TabIndex = 80;
            this.btnCostUpdate.Text = "Update";
            this.btnCostUpdate.UseVisualStyleBackColor = true;
            this.btnCostUpdate.Click += new System.EventHandler(this.btnCostUpdate_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(35, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(187, 19);
            this.label4.TabIndex = 79;
            this.label4.Text = "Product Cost Variation in :";
            // 
            // txtCostUPdate
            // 
            this.txtCostUPdate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCostUPdate.Location = new System.Drawing.Point(228, 45);
            this.txtCostUPdate.MaxLength = 14;
            this.txtCostUPdate.Name = "txtCostUPdate";
            this.txtCostUPdate.Size = new System.Drawing.Size(82, 27);
            this.txtCostUPdate.TabIndex = 78;
            this.txtCostUPdate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCostUPdate_KeyPress);
            // 
            // frmSalesProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1268, 682);
            this.Controls.Add(this.pnCostUpdate);
            this.Controls.Add(this.chkUpdateProductCost);
            this.Controls.Add(this.pnProductcode);
            this.Controls.Add(this.chkDownloadFolder);
            this.Controls.Add(this.chkDownload);
            this.Controls.Add(this.chkxcelupload);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pnExcelItemCode);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            //this.Name = "frmSalesProduct";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sales Product Master";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmSalesProduct_FormClosing);
            this.Load += new System.EventHandler(this.frmSalesProduct_Load);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.pnProductcode.ResumeLayout(false);
            this.pnProductcode.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.pnExcelItemCode.ResumeLayout(false);
            this.pnExcelItemCode.PerformLayout();
            this.pnexcelupload.ResumeLayout(false);
            this.pnexcelupload.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvxcelupload)).EndInit();
            this.pnCostUpdate.ResumeLayout(false);
            this.pnCostUpdate.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.CheckBox chkProductCode;
        private System.Windows.Forms.Button cleartreeview;
        private System.Windows.Forms.TextBox txtsearchtree;
        private System.Windows.Forms.Button btnsearchtree;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Label lblbomby;
        private System.Windows.Forms.TreeView tvProduct;
        private System.Windows.Forms.Panel pnProductcode;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSalesCost;
        private System.Windows.Forms.Button btnUpdateProduct;
        private System.Windows.Forms.TextBox txtProductCost;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtProductDesc;
        private System.Windows.Forms.TextBox txtProductCode;
        private System.Windows.Forms.TextBox txtProductName;
        private System.Windows.Forms.Label lblpname;
        private System.Windows.Forms.Label lblpcode;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblIndent;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Button btnQuoteTreeSave;
        private System.Windows.Forms.Button btnAddFolder;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button btnAddProduct;
        private System.Windows.Forms.CheckBox chkxcelupload;
        private System.Windows.Forms.Panel pnExcelItemCode;
        private System.Windows.Forms.Panel pnexcelupload;
        private System.Windows.Forms.Button btnUpload;
        private System.Windows.Forms.Button btnbrowse;
        private System.Windows.Forms.TextBox txtbrowseaddres;
        private System.Windows.Forms.DataGridView dgvxcelupload;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn SalesCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductPrice;
        private System.Windows.Forms.CheckBox chkDownload;
        private System.Windows.Forms.CheckBox chkDownloadFolder;
        private System.Windows.Forms.CheckBox chkUpdateProductCost;
        private System.Windows.Forms.Panel pnCostUpdate;
        private System.Windows.Forms.Button btnCostUpdate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtCostUPdate;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button OTCbtnCostUpdate;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox OTCtxtCostUPdate;
        private System.Windows.Forms.Button btnExit;
    }
}
