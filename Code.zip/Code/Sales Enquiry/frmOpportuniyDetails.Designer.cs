﻿namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    partial class frmOpportuniyDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmOpportuniyDetails));
            this.txtSearchText = new System.Windows.Forms.TextBox();
            this.lblFromdate = new System.Windows.Forms.Label();
            this.btnReport = new System.Windows.Forms.Button();
            this.lblToDate = new System.Windows.Forms.Label();
            this.dtpfromdate = new System.Windows.Forms.DateTimePicker();
            this.dtptodate = new System.Windows.Forms.DateTimePicker();
            this.dgvQuoteView = new System.Windows.Forms.DataGridView();
            this.cmbreporttype = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnExcel = new System.Windows.Forms.Button();
            this.QuotationNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RevisionNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LabType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BusinessSector = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PrimaryInd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PrimaryMtrl = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PrimaryMtrlDetail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Application = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TestEnivironment = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Stage = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TypeofCustomer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OrderValue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Currency = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ExpectedOrderPlacementDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Probability = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Competition = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SpecifyOthers = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WonLost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WonReason = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LostReason = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuoteView)).BeginInit();
            this.SuspendLayout();
            // 
            // txtSearchText
            // 
            this.txtSearchText.Enabled = false;
            this.txtSearchText.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchText.Location = new System.Drawing.Point(847, 14);
            this.txtSearchText.Name = "txtSearchText";
            this.txtSearchText.Size = new System.Drawing.Size(328, 27);
            this.txtSearchText.TabIndex = 145;
            this.txtSearchText.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtSearchText_KeyUp);
            // 
            // lblFromdate
            // 
            this.lblFromdate.AutoSize = true;
            this.lblFromdate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblFromdate.Location = new System.Drawing.Point(4, 20);
            this.lblFromdate.Name = "lblFromdate";
            this.lblFromdate.Size = new System.Drawing.Size(52, 19);
            this.lblFromdate.TabIndex = 4;
            this.lblFromdate.Text = "From :";
            // 
            // btnReport
            // 
            this.btnReport.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReport.Location = new System.Drawing.Point(371, 10);
            this.btnReport.Name = "btnReport";
            this.btnReport.Size = new System.Drawing.Size(85, 34);
            this.btnReport.TabIndex = 132;
            this.btnReport.Text = "Search";
            this.btnReport.UseVisualStyleBackColor = true;
            this.btnReport.Click += new System.EventHandler(this.btnReport_Click);
            // 
            // lblToDate
            // 
            this.lblToDate.AutoSize = true;
            this.lblToDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblToDate.Location = new System.Drawing.Point(196, 20);
            this.lblToDate.Name = "lblToDate";
            this.lblToDate.Size = new System.Drawing.Size(33, 19);
            this.lblToDate.TabIndex = 6;
            this.lblToDate.Text = "To :";
            // 
            // dtpfromdate
            // 
            this.dtpfromdate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.dtpfromdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpfromdate.Location = new System.Drawing.Point(56, 14);
            this.dtpfromdate.Name = "dtpfromdate";
            this.dtpfromdate.Size = new System.Drawing.Size(139, 27);
            this.dtpfromdate.TabIndex = 9;
            // 
            // dtptodate
            // 
            this.dtptodate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.dtptodate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtptodate.Location = new System.Drawing.Point(232, 13);
            this.dtptodate.Name = "dtptodate";
            this.dtptodate.Size = new System.Drawing.Size(133, 27);
            this.dtptodate.TabIndex = 10;
            // 
            // dgvQuoteView
            // 
            this.dgvQuoteView.AllowUserToAddRows = false;
            this.dgvQuoteView.AllowUserToDeleteRows = false;
            this.dgvQuoteView.AllowUserToOrderColumns = true;
            this.dgvQuoteView.AllowUserToResizeRows = false;
            this.dgvQuoteView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvQuoteView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvQuoteView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvQuoteView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.QuotationNumber,
            this.RevisionNumber,
            this.CustomerName,
            this.LabType,
            this.BusinessSector,
            this.PrimaryInd,
            this.PrimaryMtrl,
            this.PrimaryMtrlDetail,
            this.Application,
            this.TestEnivironment,
            this.Status,
            this.Stage,
            this.TypeofCustomer,
            this.OrderValue,
            this.Currency,
            this.ExpectedOrderPlacementDate,
            this.Probability,
            this.Competition,
            this.SpecifyOthers,
            this.WonLost,
            this.WonReason,
            this.LostReason});
            this.dgvQuoteView.EnableHeadersVisualStyles = false;
            this.dgvQuoteView.Location = new System.Drawing.Point(1, 47);
            this.dgvQuoteView.Name = "dgvQuoteView";
            this.dgvQuoteView.ReadOnly = true;
            this.dgvQuoteView.RowHeadersVisible = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvQuoteView.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvQuoteView.Size = new System.Drawing.Size(1328, 618);
            this.dgvQuoteView.TabIndex = 143;
            // 
            // cmbreporttype
            // 
            this.cmbreporttype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbreporttype.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbreporttype.FormattingEnabled = true;
            this.cmbreporttype.Items.AddRange(new object[] {
            "Quotation Number",
            "Customer Name",
            "Lab Type",
            "Business Sector",
            "Primary Industry",
            "Primary Material",
            "Primary Material Detail",
            "Application",
            "Test Environment",
            "Status",
            "Stage",
            "Type of Customer",
            "Probability",
            "Competition",
            "Won Lost"});
            this.cmbreporttype.Location = new System.Drawing.Point(576, 14);
            this.cmbreporttype.Name = "cmbreporttype";
            this.cmbreporttype.Size = new System.Drawing.Size(265, 27);
            this.cmbreporttype.TabIndex = 147;
            this.cmbreporttype.SelectedIndexChanged += new System.EventHandler(this.cmbreporttype_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(486, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 19);
            this.label1.TabIndex = 148;
            this.label1.Text = "Search by :";
            // 
            // btnExcel
            // 
            this.btnExcel.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcel.Location = new System.Drawing.Point(1181, 11);
            this.btnExcel.Name = "btnExcel";
            this.btnExcel.Size = new System.Drawing.Size(139, 34);
            this.btnExcel.TabIndex = 149;
            this.btnExcel.Text = "Export to Excel";
            this.btnExcel.UseVisualStyleBackColor = true;
            this.btnExcel.Click += new System.EventHandler(this.btnExcel_Click);
            // 
            // QuotationNumber
            // 
            this.QuotationNumber.DataPropertyName = "QuotationNumber";
            this.QuotationNumber.HeaderText = "Quotation Number";
            this.QuotationNumber.Name = "QuotationNumber";
            this.QuotationNumber.ReadOnly = true;
            this.QuotationNumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.QuotationNumber.Width = 131;
            // 
            // RevisionNumber
            // 
            this.RevisionNumber.DataPropertyName = "RevisionNumber";
            this.RevisionNumber.HeaderText = "Revision Number";
            this.RevisionNumber.Name = "RevisionNumber";
            this.RevisionNumber.ReadOnly = true;
            this.RevisionNumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RevisionNumber.Width = 119;
            // 
            // CustomerName
            // 
            this.CustomerName.DataPropertyName = "CustomerName";
            this.CustomerName.HeaderText = "Customer";
            this.CustomerName.Name = "CustomerName";
            this.CustomerName.ReadOnly = true;
            this.CustomerName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CustomerName.Width = 80;
            // 
            // LabType
            // 
            this.LabType.DataPropertyName = "LabType";
            this.LabType.HeaderText = "LabType";
            this.LabType.Name = "LabType";
            this.LabType.ReadOnly = true;
            this.LabType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.LabType.Width = 72;
            // 
            // BusinessSector
            // 
            this.BusinessSector.DataPropertyName = "BusinessSector";
            this.BusinessSector.HeaderText = "Business Sector";
            this.BusinessSector.Name = "BusinessSector";
            this.BusinessSector.ReadOnly = true;
            this.BusinessSector.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.BusinessSector.Width = 108;
            // 
            // PrimaryInd
            // 
            this.PrimaryInd.DataPropertyName = "PrimaryInd";
            this.PrimaryInd.HeaderText = "Primary Industry";
            this.PrimaryInd.Name = "PrimaryInd";
            this.PrimaryInd.ReadOnly = true;
            this.PrimaryInd.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PrimaryInd.Width = 117;
            // 
            // PrimaryMtrl
            // 
            this.PrimaryMtrl.DataPropertyName = "PrimaryMtrl";
            this.PrimaryMtrl.HeaderText = "Primary Material";
            this.PrimaryMtrl.Name = "PrimaryMtrl";
            this.PrimaryMtrl.ReadOnly = true;
            this.PrimaryMtrl.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PrimaryMtrl.Width = 118;
            // 
            // PrimaryMtrlDetail
            // 
            this.PrimaryMtrlDetail.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.PrimaryMtrlDetail.DataPropertyName = "PrimaryMtrlDetail";
            this.PrimaryMtrlDetail.HeaderText = "Primary Material Detail";
            this.PrimaryMtrlDetail.Name = "PrimaryMtrlDetail";
            this.PrimaryMtrlDetail.ReadOnly = true;
            this.PrimaryMtrlDetail.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PrimaryMtrlDetail.Width = 105;
            // 
            // Application
            // 
            this.Application.DataPropertyName = "Application";
            this.Application.HeaderText = "Application";
            this.Application.Name = "Application";
            this.Application.ReadOnly = true;
            this.Application.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Application.Width = 93;
            // 
            // TestEnivironment
            // 
            this.TestEnivironment.DataPropertyName = "TestEnivironment";
            this.TestEnivironment.HeaderText = "Test Enivironment";
            this.TestEnivironment.Name = "TestEnivironment";
            this.TestEnivironment.ReadOnly = true;
            this.TestEnivironment.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.TestEnivironment.Width = 125;
            // 
            // Status
            // 
            this.Status.DataPropertyName = "Status";
            this.Status.HeaderText = "Status";
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            this.Status.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Status.Width = 58;
            // 
            // Stage
            // 
            this.Stage.DataPropertyName = "Stage";
            this.Stage.HeaderText = "Stage";
            this.Stage.Name = "Stage";
            this.Stage.ReadOnly = true;
            this.Stage.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Stage.Width = 53;
            // 
            // TypeofCustomer
            // 
            this.TypeofCustomer.DataPropertyName = "TypeofCustomer";
            this.TypeofCustomer.HeaderText = "Type of Customer";
            this.TypeofCustomer.Name = "TypeofCustomer";
            this.TypeofCustomer.ReadOnly = true;
            this.TypeofCustomer.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.TypeofCustomer.Width = 122;
            // 
            // OrderValue
            // 
            this.OrderValue.DataPropertyName = "OrderValue";
            this.OrderValue.HeaderText = "OrderValue";
            this.OrderValue.Name = "OrderValue";
            this.OrderValue.ReadOnly = true;
            this.OrderValue.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OrderValue.Width = 92;
            // 
            // Currency
            // 
            this.Currency.DataPropertyName = "Currency";
            this.Currency.HeaderText = "Currency";
            this.Currency.Name = "Currency";
            this.Currency.ReadOnly = true;
            this.Currency.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Currency.Width = 76;
            // 
            // ExpectedOrderPlacementDate
            // 
            this.ExpectedOrderPlacementDate.DataPropertyName = "ExpectedOrderPlacementDate";
            this.ExpectedOrderPlacementDate.HeaderText = "Expected Order Placement Date";
            this.ExpectedOrderPlacementDate.Name = "ExpectedOrderPlacementDate";
            this.ExpectedOrderPlacementDate.ReadOnly = true;
            this.ExpectedOrderPlacementDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ExpectedOrderPlacementDate.Width = 181;
            // 
            // Probability
            // 
            this.Probability.DataPropertyName = "Probability";
            this.Probability.HeaderText = "Probability";
            this.Probability.Name = "Probability";
            this.Probability.ReadOnly = true;
            this.Probability.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Probability.Width = 91;
            // 
            // Competition
            // 
            this.Competition.DataPropertyName = "Competition";
            this.Competition.HeaderText = "Competition";
            this.Competition.Name = "Competition";
            this.Competition.ReadOnly = true;
            this.Competition.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Competition.Width = 98;
            // 
            // SpecifyOthers
            // 
            this.SpecifyOthers.DataPropertyName = "SpecifyOthers";
            this.SpecifyOthers.HeaderText = "Specify Others";
            this.SpecifyOthers.Name = "SpecifyOthers";
            this.SpecifyOthers.ReadOnly = true;
            this.SpecifyOthers.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SpecifyOthers.Width = 103;
            // 
            // WonLost
            // 
            this.WonLost.DataPropertyName = "WonLost";
            this.WonLost.HeaderText = "Won Lost";
            this.WonLost.Name = "WonLost";
            this.WonLost.ReadOnly = true;
            this.WonLost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.WonLost.Width = 71;
            // 
            // WonReason
            // 
            this.WonReason.DataPropertyName = "WonReason";
            this.WonReason.HeaderText = "Won Reason";
            this.WonReason.Name = "WonReason";
            this.WonReason.ReadOnly = true;
            this.WonReason.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.WonReason.Width = 90;
            // 
            // LostReason
            // 
            this.LostReason.DataPropertyName = "LostReason";
            this.LostReason.HeaderText = "Lost Reason";
            this.LostReason.Name = "LostReason";
            this.LostReason.ReadOnly = true;
            this.LostReason.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.LostReason.Width = 86;
            // 
            // frmOpportuniyDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1332, 667);
            this.Controls.Add(this.lblFromdate);
            this.Controls.Add(this.btnExcel);
            this.Controls.Add(this.btnReport);
            this.Controls.Add(this.lblToDate);
            this.Controls.Add(this.cmbreporttype);
            this.Controls.Add(this.dtpfromdate);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtptodate);
            this.Controls.Add(this.txtSearchText);
            this.Controls.Add(this.dgvQuoteView);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmOpportuniyDetails";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Opportuniy Details";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmOpportuniyDetails_FormClosing);
            this.Load += new System.EventHandler(this.frmOpportuniyDetails_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuoteView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSearchText;
        private System.Windows.Forms.Label lblFromdate;
        private System.Windows.Forms.Button btnReport;
        private System.Windows.Forms.Label lblToDate;
        private System.Windows.Forms.DateTimePicker dtpfromdate;
        private System.Windows.Forms.DateTimePicker dtptodate;
        private System.Windows.Forms.DataGridView dgvQuoteView;
        private System.Windows.Forms.ComboBox cmbreporttype;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnExcel;
        private System.Windows.Forms.DataGridViewTextBoxColumn QuotationNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn RevisionNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerName;
        private System.Windows.Forms.DataGridViewTextBoxColumn LabType;
        private System.Windows.Forms.DataGridViewTextBoxColumn BusinessSector;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrimaryInd;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrimaryMtrl;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrimaryMtrlDetail;
        private System.Windows.Forms.DataGridViewTextBoxColumn Application;
        private System.Windows.Forms.DataGridViewTextBoxColumn TestEnivironment;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn Stage;
        private System.Windows.Forms.DataGridViewTextBoxColumn TypeofCustomer;
        private System.Windows.Forms.DataGridViewTextBoxColumn OrderValue;
        private System.Windows.Forms.DataGridViewTextBoxColumn Currency;
        private System.Windows.Forms.DataGridViewTextBoxColumn ExpectedOrderPlacementDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Probability;
        private System.Windows.Forms.DataGridViewTextBoxColumn Competition;
        private System.Windows.Forms.DataGridViewTextBoxColumn SpecifyOthers;
        private System.Windows.Forms.DataGridViewTextBoxColumn WonLost;
        private System.Windows.Forms.DataGridViewTextBoxColumn WonReason;
        private System.Windows.Forms.DataGridViewTextBoxColumn LostReason;
    }
}