﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Data.OleDb;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Diagnostics;

namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    public partial class frmSalesProduct : Form
    {
        public frmSalesProduct()
        {
            InitializeComponent();
        }
        DataAccessLayer DAL = new DataAccessLayer();
        Global GLobalClass = new Global();
        frmForm2 frm = new frmForm2();
        frmSalesHome SalesHome = new frmSalesHome();
        DataTable dtTreeFromTable = new DataTable();
        DataTable dtProductCodeCheck = new DataTable();
        DataTable dtProductName = new DataTable();
        DataTable dtNewProductCodeCheck = new DataTable();
        TreeNode tnCurrentParentNode = new TreeNode();
        Login.frmLoginForm LoginForm = new Login.frmLoginForm();

        private void frmSalesProduct_Load(object sender, EventArgs e)
        {
            dtTreeFromTable = DAL.fnGetSalesMasterProductTreeView(0).Tables[0]; //get the tree folders and sub-folders from database 
            tvProduct.Nodes.AddRange(GLobalClass.fnTreeFromTable(dtTreeFromTable, "ParentID", "NodeID", "ProductName", "ImageIndex")); // display the folders in the treeview
            tnCurrentParentNode = null;
            tvProduct.Sort();
            lblbomby.Text = LoginForm.GetUserDetails[2];
        }

        private void btnUpdateProduct_Click(object sender, EventArgs e)
        {
            if (btnUpdateProduct.Text == "Save")
            {
                dtNewProductCodeCheck = DAL.fnSalesProductCode(txtProductCode.Text).Tables[0];
                if (dtNewProductCodeCheck.Rows.Count == 0)
                {
                    fnUpadateTreeDetails(Global.uINSERT);
                }
                else
                {
                    MessageBox.Show("Entered new product code alreday used for product '" + dtNewProductCodeCheck.Rows[0]["Name"].ToString() + "'. Please enter a unique product code.", "Information", 0, MessageBoxIcon.Warning);
                }
            }

            else if (btnUpdateProduct.Text == "Update")
            {
                dtProductCodeCheck = DAL.fnGetPasteSlalesProductTreeNode(0, sName[0].ToString()).Tables[0];
                dtNewProductCodeCheck = DAL.fnSalesProductCode(dtProductCodeCheck.Rows[0]["ProductCode"].ToString().Trim()).Tables[0];
                if (dtProductCodeCheck.Rows.Count < 2)
                {
                    if (dtProductCodeCheck.Rows[0]["ProductCode"].ToString().Trim() != txtProductCode.Text.Trim())
                    {
                        dtNewProductCodeCheck = DAL.fnSalesProductCodeCheck(txtProductCode.Text).Tables[0];
                        if (dtNewProductCodeCheck.Rows.Count == 0)
                        {
                            fnUpadateTreeDetails(Global.uUPDATE);
                        }
                        else
                        {
                            MessageBox.Show("Entered new product code alreday used for product '" + dtNewProductCodeCheck.Rows[0]["Name"].ToString() + "'. Please enter a unique product code.", "Information", 0, MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                        fnUpadateTreeDetails(Global.uUPDATE);
                    }
                }
                else
                {
                    MessageBox.Show("Selected Product has duplicate product code. Please contact the admin.", "Information", 0, MessageBoxIcon.Warning);
                }
            }
        }

        private void fnUpadateTreeDetails(uint SaveorUpdate)
        {
            // DAL.fnUpdateProductDetails(dtProductName.Rows[0]["ProductCode"].ToString(), txtProductCode.Text.Trim(), txtProductName.Text.Trim(), txtProductDesc.Text.Trim(), txtProductCost.Text, txtSalesCost.Text);


            if (SaveorUpdate == Global.uINSERT)
            {
                dtParentAndNodeID = DAL.fnGetCopySalesFolderNodeId(null).Tables[0];
                if (dtParentAndNodeID.Rows.Count > 0)
                {
                    iLastNodeID = Convert.ToInt32(dtParentAndNodeID.Rows[0]["NodeID"].ToString());
                    iLastNodeID++;
                }
                if (iLastNodeID != 0)
                {
                    GLobalClass.iSuccess = DAL.fnAddSalesProductName(SaveorUpdate, Convert.ToInt32(sName[0]), iLastNodeID, txtProductName.Text, "2", LoginForm.GetUserDetails[2], LoginForm.GetUserDetails[2], txtProductCode.Text, txtProductDesc.Text, txtProductCost.Text, txtSalesCost.Text);
                }

                MessageBox.Show("Product successfully saved.", "Information", 0, MessageBoxIcon.Information);
                TreeNode TN = new TreeNode();
                tvProduct.BeginUpdate();
                TN.Name = iLastNodeID + ")" + txtProductName.Text.Trim(); ;
                TN.Text = iLastNodeID + ")" + txtProductName.Text.Trim(); ;
                TN.ForeColor = Color.Black;
                TN.StateImageIndex = 2;
                tvProduct.SelectedNode.Nodes.Add(TN);
                tvProduct.EndUpdate();
            }

            else if (SaveorUpdate == Global.uUPDATE)
            {
                GLobalClass.iSuccess = DAL.fnAddSalesProductName(SaveorUpdate, 0, Convert.ToInt32(sName[0]), txtProductName.Text, "1", "", "", txtProductCode.Text, txtProductDesc.Text, txtProductCost.Text, txtSalesCost.Text);
                tvProduct.BeginUpdate();
                tvProduct.SelectedNode.Name = sName[0] + ")" + txtProductName.Text.Trim();
                tvProduct.SelectedNode.Text = sName[0] + ")" + txtProductName.Text.Trim();
                if (tvProduct.SelectedNode.StateImageIndex == 2)
                {
                    tvProduct.SelectedNode.StateImageIndex = 2;
                }
                else
                {
                    tvProduct.SelectedNode.StateImageIndex = 3;
                }
                tvProduct.EndUpdate();
                MessageBox.Show("Product successfully updated.", "Information", 0, MessageBoxIcon.Information);
            }
        }

        private void frmSalesProduct_FormClosing(object sender, System.Windows.Forms.FormClosingEventArgs e)
        {
            if (GLobalClass.fnMessageResult() == Global.sCLOSE_MESSAGE_RESULT_YES)
            {
                this.Hide();
                frm.Show();
            }
            else
            {
                e.Cancel = true;
            }
        }

        string[] sName;
        string[] sParentName;
        bool bchecked = false;
        DataTable dtProductorFolderCheck = new DataTable();

        private void tvProduct_NodeMouseClick(object sender, System.Windows.Forms.TreeNodeMouseClickEventArgs e)
        {
            if (e.Node.StateImageIndex == 0)
            {
                //if (e.Button == MouseButtons.Right && e.Node.Name != "1)All Product")
                //{
                //    contextMenuStrip.Show(tvProduct, new Point(e.X, e.Y));
                //}

                pnProductcode.Enabled = false;
                txtProductName.ResetText();
                txtProductCode.ResetText();
                txtProductName.ResetText();
                txtProductCost.ResetText();
                txtProductDesc.ResetText();
                txtSalesCost.ResetText();
                txtName.Visible = false;
                btnQuoteTreeSave.Visible = false;
                bchecked = false;
                sName = e.Node.Name.Split(')');

                dtProductorFolderCheck = DAL.fnSalesQuoteProductorFolder(sName[0], "CV").Tables[0];
                if (dtProductorFolderCheck.Rows.Count == 0)
                {
                    btnAddFolder.Enabled = true;
                    btnAddProduct.Enabled = true;
                    bchecked = true;
                }
                else if (dtProductorFolderCheck.Rows.Count > 0)
                {
                    btnAddFolder.Enabled = true;
                    btnAddProduct.Enabled = true;
                    bchecked = true;
                }
                if (!bchecked)
                {
                    dtProductorFolderCheck = DAL.fnSalesQuoteProductorFolder(sName[0], null).Tables[0];
                    if (dtProductorFolderCheck.Rows.Count > 0)
                    {
                        btnAddFolder.Enabled = true;
                        btnAddProduct.Enabled = false;
                    }
                }
            }
            else if (e.Node.StateImageIndex == 2 || e.Node.StateImageIndex == 3)
            
            {
                pnProductcode.Enabled = true;
                btnAddFolder.Enabled = false;
                btnAddProduct.Enabled = false;
                tvProduct.SelectedNode = e.Node;
                tvProduct.LabelEdit = false;
                sNName = e.Node.Name;
                if (e.Node.Parent != null && e.Node != null && (e.Node.StateImageIndex == 2 || e.Node.StateImageIndex == 3 ))
                {
                    if (e.Node.StateImageIndex == 2 || e.Node.StateImageIndex == 3)
                    {
                        btnAddProduct.Enabled = true;
                    }
                    else
                    {
                        btnAddFolder.Enabled = false;
                        btnAddProduct.Enabled = false;
                    }
                    sName = tvProduct.SelectedNode.Name.Split(')');
                    if (!string.IsNullOrEmpty(sName[0]))
                    {
                        //  SalesProductMaster = DAL.fnGetSlaesProdcutTreeNode(sName[0]).Tables[0];
                        SalesProductMaster = DAL.fnSalesProductMaster(sName[0]).Tables[0];

                        if (SalesProductMaster.Rows.Count > 0)
                        {
                            if (!string.IsNullOrEmpty(SalesProductMaster.Rows[0]["ProductCode"].ToString()))
                            {
                                txtProductName.Text = SalesProductMaster.Rows[0]["Name"].ToString();
                                txtProductCode.Text = SalesProductMaster.Rows[0]["ProductCode"].ToString();
                                txtProductDesc.Text = SalesProductMaster.Rows[0]["ProductDescription"].ToString();
                                txtProductCost.Text = SalesProductMaster.Rows[0]["ProductCost"].ToString();
                                txtSalesCost.Text = SalesProductMaster.Rows[0]["SalesCost"].ToString();
                                btnUpdateProduct.Text = "Update";
                            }
                            else
                            {
                                txtProductName.ResetText();
                                txtProductCode.ResetText();
                                txtProductName.ResetText();
                                txtProductCost.ResetText();
                                txtProductDesc.ResetText();
                                txtSalesCost.ResetText();
                            }
                        }
                    }
                }
                else
                {
                    txtProductName.ResetText();
                    txtProductCode.ResetText();
                    txtProductName.ResetText();
                    txtProductCost.ResetText();
                    txtSalesCost.ResetText();
                    txtProductDesc.ResetText();
                    btnUpdateProduct.Text = "Save";
                }
            }
        }
        DataTable SalesProductMaster = new DataTable();
        string sNName;

        private void btnAddFolder_Click(object sender, EventArgs e)
        {
            txtName.Visible = true;
            btnQuoteTreeSave.Visible = true;
            btnQuoteTreeSave.Enabled = true;
            txtName.ForeColor = SystemColors.GrayText;
            // txtName.Text = "Enter Name";
            txtName.Leave += new System.EventHandler(txtName_Leave);
            txtName.Enter += new System.EventHandler(txtName_Enter);
        }

        private void txtName_Leave(object sender, EventArgs e)
        {
            if (txtName.Text.Length == 0)
            {
                txtName.Text = "Enter Name";
                txtName.ForeColor = SystemColors.GrayText;
            }
        }

        private void txtName_Enter(object sender, EventArgs e)
        {
            if (txtName.Text == "Enter Name")
            {
                txtName.Text = "";
                txtName.ForeColor = SystemColors.WindowText;
            }
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            txtName.Visible = false;
            btnQuoteTreeSave.Visible = false;
            txtProductName.ResetText();
            txtProductCode.ResetText();
            txtProductName.ResetText();
            txtProductCost.ResetText();
            txtSalesCost.ResetText();
            txtProductDesc.ResetText();
            btnUpdateProduct.Text = "Save";
            pnProductcode.Enabled = true;
        }

        private void txtProductCost_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void txtSalesCost_KeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        DataTable dtNodeID = new DataTable();
        int iLastNodeID;
        private void btnQuoteTreeSave_Click(object sender, EventArgs e)
        {
            if (btnQuoteTreeSave.Text == "Save")
            {
                if (txtName.Text != "Enter Name")
                {
                    dtNodeID = DAL.fnGetSalesProductLastNodeId(null).Tables[0];
                    if (dtNodeID.Rows.Count > 0)
                    {
                        iLastNodeID = Convert.ToInt32(dtNodeID.Rows[0]["NodeID"].ToString());
                        iLastNodeID++;
                    }
                    sName = tvProduct.SelectedNode.Name.Split(')');
                    GLobalClass.iSuccess = DAL.fnAddSalesProductName(Global.uINSERT, Convert.ToInt32(sName[0]), iLastNodeID, txtName.Text, "0", LoginForm.GetUserDetails[2], LoginForm.GetUserDetails[2], "", "", "", "");

                    MessageBox.Show("Folder '" + txtName.Text + "'  Created Successfully.", "Success", 0, MessageBoxIcon.Information);

                    TreeNode TN = new TreeNode();
                    tvProduct.BeginUpdate();
                    TN.Name = iLastNodeID + ") " + txtName.Text;
                    TN.Text = iLastNodeID + ") " + txtName.Text;
                    TN.ForeColor = Color.Black;
                    TN.StateImageIndex = 0;
                    tvProduct.SelectedNode.Nodes.Add(TN);
                    tvProduct.EndUpdate();
                    btnQuoteTreeSave.Enabled = false;
                    txtName.Visible = false;
                }
                else
                {
                    MessageBox.Show("Enter a folder name to save.", "Error", 0, MessageBoxIcon.Error);
                    txtName.Focus();
                }
            }
            else if (btnQuoteTreeSave.Text == "Rename")
            {
                if (txtName.Text != "Enter Name")
                {
                    //dtNodeID = DAL.fnGetSalesProductLastNodeId(null).Tables[0];
                    //if (dtNodeID.Rows.Count > 0)
                    //{
                    //    iLastNodeID = Convert.ToInt32(dtNodeID.Rows[0]["NodeID"].ToString());
                    //    iLastNodeID++;
                    //}
                    //  sName = tvProduct.SelectedNode.Name.Split(')');
                    GLobalClass.iSuccess = DAL.fnAddSalesProductName(7, Convert.ToInt32(sName[0]), iLastNodeID, txtName.Text, "0", LoginForm.GetUserDetails[2], LoginForm.GetUserDetails[2], "", "", "", "");

                    MessageBox.Show("Folder renamed to '" + txtName.Text + "' successfully.", "Success", 0, MessageBoxIcon.Information);

                    tvProduct.BeginUpdate();
                    tvProduct.SelectedNode.Name = sName[0] + ")" + txtName.Text;
                    tvProduct.SelectedNode.Text = sName[0] + ")" + txtName.Text;
                    tvProduct.SelectedNode.StateImageIndex = 0;
                    tvProduct.EndUpdate();

                    //TreeNode TN = new TreeNode();
                    //tvProduct.BeginUpdate();
                    //TN.Name = iLastNodeID + ") " + txtName.Text;
                    //TN.Text = iLastNodeID + ") " + txtName.Text;
                    //TN.ForeColor = Color.Black;
                    //TN.StateImageIndex = 0;
                    //tvProduct.SelectedNode.Nodes.Add(TN);
                    //tvProduct.EndUpdate();
                    btnQuoteTreeSave.Text = "Save";
                    btnQuoteTreeSave.Enabled = false;
                    txtName.Visible = false;
                }
                else
                {
                    MessageBox.Show("Enter a folder name to save.", "Error", 0, MessageBoxIcon.Error);
                    txtName.Focus();
                }
            }
        }

        private void SearchNodes(string SearchText, TreeNode StartNode)
        {
            while (StartNode != null)
            {
                if (StartNode.Text.ToLower().Contains(SearchText.ToLower()))
                {
                    CurrentNodeMatches.Add(StartNode);
                };
                if (StartNode.Nodes.Count != 0)
                {
                    SearchNodes(SearchText, StartNode.Nodes[0]);//Recursive Search 
                };
                StartNode = StartNode.NextNode;
            };
        }

        private List<TreeNode> CurrentNodeMatches = new List<TreeNode>();
        private int LastNodeIndex = 0;
        private string LastSearchText;
        DataTable dtProductCodeSearch = new DataTable();
        private void btnsearchtree_Click(object sender, EventArgs e)
        {
            string searchText = this.txtsearchtree.Text;
            if (String.IsNullOrEmpty(searchText))
            {
                return;
            };

            if (LastSearchText != searchText)
            {
                //It's a new Search
                CurrentNodeMatches.Clear();
                if (chkProductCode.CheckState == CheckState.Checked)
                {
                    dtProductCodeSearch = DAL.fnSalesProductCodeName(searchText).Tables[0];
                    LastSearchText = searchText;
                    if (dtProductCodeSearch.Rows.Count > 0)
                    {
                        searchText = dtProductCodeSearch.Rows[0]["NodeID"].ToString() + ")" + dtProductCodeSearch.Rows[0]["Name"].ToString().Trim();
                        LastNodeIndex = 0;
                        SearchNodes(searchText, tvProduct.Nodes[0]);
                    }
                }
                else
                {
                    LastSearchText = searchText;
                    LastNodeIndex = 0;
                    SearchNodes(searchText, tvProduct.Nodes[0]);
                }

            }

            if (LastNodeIndex >= 0 && CurrentNodeMatches.Count > 0 && LastNodeIndex < CurrentNodeMatches.Count)
            {
                TreeNode selectedNode = CurrentNodeMatches[LastNodeIndex];
                LastNodeIndex++;
                tvProduct.SelectedNode = selectedNode;
                tvProduct.SelectedNode.Expand();
                tvProduct.Select();
                TreeNode tn = this.tvProduct.SelectedNode;
                int x = tn.Bounds.X;
                int y = tn.Bounds.Y;
                TreeNodeMouseClickEventArgs treeNodeMouseClickEventArgs = new TreeNodeMouseClickEventArgs(tn, MouseButtons.Left, 1, x, y);
                tvProduct_NodeMouseClick(tn, treeNodeMouseClickEventArgs);

            }
        }

        private void txtsearchtree_KeyUp(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnsearchtree_Click(sender, e);
            }
        }

        private void cleartreeview_Click(object sender, EventArgs e)
        {
            txtsearchtree.ResetText();
            LastSearchText = "";
            tvProduct.CollapseAll();
            if ((tvProduct.SelectedNode) != null)
            {
                TreeNode tn = this.tvProduct.SelectedNode;
                int x = tn.Bounds.X;
                int y = tn.Bounds.Y;
                TreeNodeMouseClickEventArgs treeNodeMouseClickEventArgs = new TreeNodeMouseClickEventArgs(tn, MouseButtons.Left, 1, x, y);
                this.tvProduct_NodeMouseClick(tn, treeNodeMouseClickEventArgs);
            }
        }
        int NodeID;
        int PasteParentID;
        int PasteImageIndex;
        DataTable dtParentAndNodeID = new DataTable();
        int iCurrentParentID;
        DataTable dtChildProdcut = new DataTable();
        string sTreeParentName = string.Empty;
        string sTreeChildName = string.Empty;
        string sPasteTreeParentName = string.Empty;
        string sPasteTreeChildName = string.Empty;

        private void tvProduct_KeyUp(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete selected row from the list
            {
                if (Convert.ToBoolean(LoginForm.GetUserDetails[26]))
                {
                    if (tvProduct.SelectedNode.Name != "1)All Product" && (tvProduct.SelectedNode.StateImageIndex == 2 || tvProduct.SelectedNode.StateImageIndex == 3))
                    {
                        DialogResult DR = MessageBox.Show("Do you want to delete the selected Product ' " + tvProduct.SelectedNode.Name + " ' from ERP", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                        if (DR == DialogResult.Yes)
                        {
                            GLobalClass.iSuccess = DAL.fnAddSalesProductName(Global.uDELETE, 0, Convert.ToInt32(sName[0]), tvProduct.SelectedNode.Name, "2", "", "", sName[0], "", "", "");
                        }
                        if (GLobalClass.iSuccess > 0)
                            tvProduct.SelectedNode.Remove();
                    }
                    else
                    {
                        MessageBox.Show("You can't delete this folder ", "Warning", 0, MessageBoxIcon.Warning);
                    }
                }
            }
            else if (e.KeyCode == Keys.Enter)
            {
                btnsearchtree_Click(sender, e);
            }
            else if (e.Control && e.KeyCode == Keys.R)
            {
                if (tvProduct.SelectedNode.Name != "1)All Product" && tvProduct.SelectedNode.StateImageIndex == 0)
                {
                    sName = tvProduct.SelectedNode.Name.Split(')');
                    btnQuoteTreeSave.Text = "Rename";
                    txtName.Text = sName[1];
                    btnAddFolder_Click(sender, e);
                }
            }

            else if (e.Control && e.KeyCode == Keys.X)
            {
                if (Convert.ToBoolean(LoginForm.GetUserDetails[26]))
                {
                    if (tvProduct.SelectedNode.Name != "1)All Product")
                    {
                        sName = tvProduct.SelectedNode.Name.Split(')');
                        sParentName = tvProduct.SelectedNode.Parent.Name.Split(')');

                        if (tvProduct.SelectedNode.StateImageIndex != 0)
                        {
                            sTreeChildName = tvProduct.SelectedNode.Name;
                            PasteImageIndex = tvProduct.SelectedNode.StateImageIndex;
                            NodeID = Convert.ToInt32(sName[0]);
                            tvProduct.SelectedNode.Remove();
                        }
                        else
                        {
                            sTreeChildName = tvProduct.SelectedNode.Name;
                            PasteImageIndex = tvProduct.SelectedNode.StateImageIndex;
                            NodeID = Convert.ToInt32(sName[0]);
                            tvProduct.SelectedNode.Remove();
                        }
                    }
                }
            }
            else if (e.Control && e.KeyCode == Keys.V)
            {
                if (Convert.ToBoolean(LoginForm.GetUserDetails[26]))
                {
                    sName = tvProduct.SelectedNode.Name.Split(')');
                    //sParentName = tvProduct.SelectedNode.Parent.Name.Split(')');
                    if (!string.IsNullOrEmpty(sTreeChildName))
                    {
                        PasteParentID = Convert.ToInt32(sName[0]);
                        GLobalClass.iSuccess = DAL.fnPasteProduct(4, PasteParentID, NodeID);
                        TreeNode TN = new TreeNode();
                        tvProduct.BeginUpdate();
                        TN.Name = sTreeChildName;
                        TN.Text = sTreeChildName;
                        TN.ForeColor = Color.Black;
                        TN.StateImageIndex = PasteImageIndex;
                        tvProduct.SelectedNode.Nodes.Add(TN);
                        tvProduct.EndUpdate();
                        sTreeChildName = "";
                    }
                    else
                    {
                        MessageBox.Show("Selected a Product to be copied", "Error", 0, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void chkxcelupload_CheckedChanged(object sender, EventArgs e)
        {
            if (chkxcelupload.CheckState == CheckState.Checked)
            {
                btnUpload.Text = "Upload";
                pnExcelItemCode.Visible = true;
                pnProductcode.Visible = false;
                btnUpload.Enabled = true;
                pnCostUpdate.Visible = false;
            }
            else
            {
                pnProductcode.Visible = true;
                pnExcelItemCode.Visible = false;
            }
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            txtbrowseaddres.Text = openFileDialog1.FileName;

            if (!string.IsNullOrEmpty(txtbrowseaddres.Text))
            {
                try
                {
                    string smessageItemCode = string.Empty;
                    string str = string.Empty;
                    DataTable dtExcelImport = new DataTable();
                    string sheetname = "";
                    string constr = "Provider = Microsoft.Jet.OLEDB.4.0; Data Source=" + txtbrowseaddres.Text + ";Extended Properties= \"Excel 8.0;HDR=YES;\";";
                    OleDbConnection con = new OleDbConnection(constr);
                    con.Open();
                    DataTable Sheets = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

                    foreach (DataRow dr in Sheets.Rows)
                    {
                        sheetname = dr[2].ToString().Replace("'", "");
                        break;
                    }
                    if (!string.IsNullOrEmpty(sheetname))
                    {
                        OleDbDataAdapter sda = new OleDbDataAdapter("select * from [" + sheetname + "]", con);
                        sda.Fill(dtExcelImport);
                    }
                    con.Close();

                    if (dtExcelImport.Rows.Count > 0 && dtExcelImport.Columns.Count == 5 && !string.IsNullOrEmpty(dtExcelImport.Rows[0][0].ToString()))
                    {
                        for (int i = 0; i < dtExcelImport.Columns.Count; i++)
                        {
                            switch (i)
                            {
                                case 0:
                                    str = "ProductCode";
                                    break;
                                case 1:
                                    str = "Name";
                                    break;
                                case 2:
                                    str = "ProductDescription";
                                    break;
                                case 3:
                                    str = "SalesCost";
                                    break;
                                case 4:
                                    str = "ProductPrice";
                                    break;
                            }
                            dtExcelImport.Columns[i].ColumnName = str;
                        }

                        for (int i = dtExcelImport.Rows.Count - 1; i >= 0; i--)
                        {
                            if (dtExcelImport.Rows[i][0] == DBNull.Value)
                                dtExcelImport.Rows[i].Delete();
                        }
                        dtExcelImport.AcceptChanges();

                        if (dtExcelImport.Rows.Count > 0)
                        {
                            dgvxcelupload.AutoGenerateColumns = false;
                            dgvxcelupload.DataSource = dtExcelImport;
                            lblCount.Text = "Imported Products: " + dgvxcelupload.Rows.Count;
                        }
                        else
                        {
                            MessageBox.Show("Uploaded Excel file not contains any valid Itemcode(s) matching with the Item master", "Error", 0, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Uploaded Excel file is not in expected format.\n 1) Excel file should contain 13 columns with Names on the first Row \n 2) Items details to be start from the Second Row ", "Error", 0, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("btnUpload_Click" + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Please Select Excel File to Upload the Items", "Warning", 0, MessageBoxIcon.Warning);
            }
        }

        private void btnbrowse_Click(object sender, EventArgs e)
        {
            txtbrowseaddres.ResetText();
            openFileDialog1.Filter = "Excel Files (*.xls)|*.xls";
            openFileDialog1.InitialDirectory = @"c:\";
            openFileDialog1.FileName = "Select File";
            openFileDialog1.Title = "Select excel file..";
            openFileDialog1.ShowDialog();
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            if (btnUpload.Text == "Upload")
            {
                int success = 0;

                if (dgvxcelupload.Rows.Count > 0)
                {
                    foreach (DataGridViewRow dr in dgvxcelupload.Rows)
                    {
                        GLobalClass.iSuccess = DAL.fnAddSalesProductName(6, 0, 5, dr.Cells[1].Value.ToString().Trim(), "", "", "", dr.Cells[0].Value.ToString().Trim(), dr.Cells[2].Value.ToString().Trim(), dr.Cells[4].Value.ToString().Trim(), dr.Cells[3].Value.ToString().Trim());
                        if (GLobalClass.iSuccess == 1)
                        {
                            success++;
                        }
                    }

                    MessageBox.Show("Succefully updated the " + success + " products.", "Success", 0, MessageBoxIcon.Information);
                    btnUpload.Enabled = false;
                    txtbrowseaddres.ResetText();
                }
                else
                {
                    MessageBox.Show("No items to update. Upload a file to update products", "Error", 0, MessageBoxIcon.Question);
                }
            }
            else if (btnUpload.Text == "Download")
            {
                string excelfilename="";
                DataTable dtEXCELData = new DataTable();
                if (chkDownload.Checked)
                {
                    excelfilename = "SalesProductDetails";
                    dtEXCELData = DAL.fnEXCELProductBOMList(null, null).Tables[0];
                }
                else if (chkDownloadFolder.Checked)
                {
                    if (sName != null)
                    {
                        dtEXCELData = DAL.fnEXCELProductBOMList(null, sName[0]).Tables[0];
                        excelfilename = sName[1];
                    }
                }
                if (dtEXCELData.Rows.Count > 0)
                {
                    int iRowIndex = 1;
                    string ExcelFolderPath;
                    string FileFullPath;
                    EXCEL.Workbook NewWorkBook;
                    EXCEL.Worksheet NewWorkSheet;
                    EXCEL.Application ExcelApp;
                    object misValue;
                  
                    //string Productname = sNodeName;

                    //  string Productname = tvProduct.SelectedNode.Parent.Name;

                    // Productname = RemoveSpecialChars(Productname);
                    //  Productname = Productname.Replace(System.Environment.NewLine, string.Empty);
                    string Productcode = txtProductCode.Text;
                    // Productcode = RemoveSpecialChars(txtProductCode.Text);
                   

                    ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\Sales Product Details\\";
                    FileFullPath = ExcelFolderPath + excelfilename + "-" + DateTime.Now.ToString("dd/MM/yyyy hh/mm/ss") + ".xls";
                    if (!Directory.Exists(ExcelFolderPath))
                        Directory.CreateDirectory(ExcelFolderPath);
                    ExcelApp = new EXCEL.Application();
                    misValue = System.Reflection.Missing.Value;
                    try
                    {
                        if (ExcelApp == null)
                            MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                        NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                        NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                        if (NewWorkSheet == null)
                            MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                        else
                            NewWorkSheet.Name = "SalesProductDetails";
                        EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                        if (RANGE == null)
                            MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                        //Commnet here for Design teams
                        // if (Convert.ToBoolean(LoginForm.GetUserDetails[27]) == false)
                        {
                            NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlWorkbookNormal, misValue, misValue, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, misValue, misValue, misValue, misValue, misValue);
                        }

                        NewWorkSheet.Range["A1:E1"].Cells.Font.Size = 14;
                        NewWorkSheet.Range["A1:E1"].Cells.Font.Bold = true;

                        if (dtEXCELData.Rows.Count > 0)
                        {
                            object[,] rawData = new object[dtEXCELData.Rows.Count + 1, dtEXCELData.Columns.Count];
                            for (int col = 0; col < dtEXCELData.Columns.Count; col++)
                            {
                                rawData[0, col] = dtEXCELData.Columns[col].ColumnName;
                            }
                            for (int row = 0; row < dtEXCELData.Rows.Count; row++)
                            {
                                for (int col = 0; col < dtEXCELData.Columns.Count; col++)
                                {
                                    rawData[row + 1, col] = dtEXCELData.Rows[row].ItemArray[col];
                                }
                            }
                            string excelRange = string.Empty;
                            string finalColLetter = string.Empty;
                            string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                            int colCharsetLen = colCharset.Length;

                            if (dtEXCELData.Columns.Count > colCharsetLen)
                            {
                                finalColLetter = colCharset.Substring(
                                    (dtEXCELData.Columns.Count - 1) / colCharsetLen - 1, 1);
                            }

                            finalColLetter += colCharset.Substring(
                                    (dtEXCELData.Columns.Count - 1) % colCharsetLen, 1);
                            excelRange = string.Format("A1:{0}{1}", finalColLetter, dtEXCELData.Rows.Count + iRowIndex);


                            NewWorkSheet.get_Range(excelRange, misValue).Value2 = rawData;
                        }

                        // NewWorkSheet.get_Range("A6:F999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        //  NewWorkSheet.get_Range("A6", "F999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;

                        NewWorkSheet.Rows.AutoFit();
                        NewWorkSheet.Columns.AutoFit();

                        NewWorkSheet.Columns[2].ColumnWidth = 45;
                        NewWorkSheet.Columns[2].WrapText = true;
                        NewWorkSheet.Columns[3].ColumnWidth = 45;
                        NewWorkSheet.Columns[3].WrapText = true;

                        NewWorkSheet.Rows.RowHeight = "18";
                        NewWorkSheet.PageSetup.PrintArea = "A1:E" + (dtEXCELData.Rows.Count + 1) + "";
                        NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                        NewWorkSheet.PageSetup.PrintNotes = true;
                        NewWorkSheet.PageSetup.Zoom = 100;
                        NewWorkSheet.PageSetup.FitToPagesTall = 1;
                        NewWorkSheet.PageSetup.FitToPagesWide = 1;
                        NewWorkSheet.PageSetup.LeftMargin = 0;
                        NewWorkSheet.PageSetup.RightMargin = 0;
                        NewWorkSheet.PageSetup.TopMargin = 0.75;
                        NewWorkSheet.PageSetup.BottomMargin = 0.75;
                        NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                        NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                        NewWorkBook.Save();
                        //Commnet here for Design teams
                        //  if (Convert.ToBoolean(LoginForm.GetUserDetails[27]) == false)
                        {
                            ExcelApp.Visible = false;
                            NewWorkBook.Close(true, misValue, misValue);
                            ExcelApp.Quit();

                            releaseObject(NewWorkSheet);
                            releaseObject(NewWorkBook);
                            releaseObject(ExcelApp);
                        }
                        //else
                        //{
                        //    ExcelApp.Visible = true;
                        //}
                        if (Directory.Exists(ExcelFolderPath))
                        {
                            Process.Start(ExcelFolderPath);
                        }
                    }
                    catch (Exception ex)
                    {
                        ExcelApp.Quit();
                        MessageBox.Show(ex.Message);

                    }
                }
                else
                    MessageBox.Show("No items to save", "Error", 0, MessageBoxIcon.Question);
            }
        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        private void chkDownload_CheckedChanged(object sender, EventArgs e)
        {
            if (chkDownload.CheckState == CheckState.Checked)
            {
                btnUpload.Text = "Download";
                pnExcelItemCode.Visible = true;
                pnProductcode.Visible = false;
                btnUpload.Enabled = true;
                pnCostUpdate.Visible = false;
            }
            else
            {
                pnProductcode.Visible = true;
                pnExcelItemCode.Visible = false;
                btnUpload.Text = "Upload";
            }
        }

        private void chkDownloadFolder_CheckedChanged(object sender, EventArgs e)
        {
            if (chkDownloadFolder.CheckState == CheckState.Checked)
            {
                btnUpload.Text = "Download";
                pnExcelItemCode.Visible = true;
                pnProductcode.Visible = false;
                btnUpload.Enabled = true;
                pnCostUpdate.Visible = false;
            }
            else
            {
                pnProductcode.Visible = true;
                pnExcelItemCode.Visible = false;
                btnUpload.Text = "Upload";
            }
        }

        private void chkUpdateProductCost_CheckedChanged(object sender, EventArgs e)
        {
            if (chkUpdateProductCost.CheckState == CheckState.Checked)
            {
                pnExcelItemCode.Visible = false;
                pnProductcode.Visible = false;
                pnCostUpdate.Visible = true;
            }
            else
            {
                pnProductcode.Visible = true;
                pnExcelItemCode.Visible = false;
                pnCostUpdate.Visible = false;
            }
        }

        private void txtCostUPdate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.') && (e.KeyChar != '-'))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1) || (e.KeyChar == '-') && ((sender as TextBox).Text.IndexOf('-') > -1))
            {
                e.Handled = true;
            }
        }

        private void btnCostUpdate_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtCostUPdate.Text))
            {
                DialogResult DR = MessageBox.Show("Do you want to update all the products cost", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DR == DialogResult.Yes)
                {
                    double dPercentage = Convert.ToDouble(txtCostUPdate.Text) / 100;
                    GLobalClass.iSuccess = DAL.fnAddSalesProductName(8, 0, 0, txtName.Text, "0", LoginForm.GetUserDetails[2], LoginForm.GetUserDetails[2], "", "", "", "");
                    if (dPercentage >= 0)
                    {
                        GLobalClass.iSuccess = DAL.fnAddSalesProductName(9, 0, 0, dPercentage.ToString(), "0", LoginForm.GetUserDetails[2], LoginForm.GetUserDetails[2], "", "", "", "");
                        MessageBox.Show("All Products cost increased by " + txtCostUPdate.Text + "%", "Success", 0, MessageBoxIcon.Information);
                    }
                    else if (dPercentage < 0)
                    {
                        GLobalClass.iSuccess = DAL.fnAddSalesProductName(10, 0, 0, dPercentage.ToString(), "0", LoginForm.GetUserDetails[2], LoginForm.GetUserDetails[2], "", "", "", "");
                        MessageBox.Show("All Products cost decreased by " + txtCostUPdate.Text + "%", "Success", 0, MessageBoxIcon.Information);
                    }
                }
            }
            else
            {
                MessageBox.Show("Enter value to update the cost", "Error", 0, MessageBoxIcon.Error);
            }
        }

        private void OTCbtnCostUpdate_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(OTCtxtCostUPdate.Text))
            {
                DialogResult DR = MessageBox.Show("Do you want to update all the products cost", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DR == DialogResult.Yes)
                {
                    double dPercentage = Convert.ToDouble(OTCtxtCostUPdate.Text) / 100;
                   // GLobalClass.iSuccess = DAL.fnAddSalesProductName(8, 0, 0, txtName.Text, "0", LoginForm.GetUserDetails[2], LoginForm.GetUserDetails[2], "", "", "", "");
                    if (dPercentage >= 0)
                    {
                        GLobalClass.iSuccess = DAL.fnAddSalesProductName(11, 0, 0, dPercentage.ToString(), "0", LoginForm.GetUserDetails[2], LoginForm.GetUserDetails[2], "", "", "", "");
                        MessageBox.Show("All Products cost increased by " + OTCtxtCostUPdate.Text + "%", "Success", 0, MessageBoxIcon.Information);
                    }
                    else if (dPercentage < 0)
                    {
                        GLobalClass.iSuccess = DAL.fnAddSalesProductName(12, 0, 0, dPercentage.ToString(), "0", LoginForm.GetUserDetails[2], LoginForm.GetUserDetails[2], "", "", "", "");
                        MessageBox.Show("All Products cost decreased by " + OTCtxtCostUPdate.Text + "%", "Success", 0, MessageBoxIcon.Information);
                    }
                }
            }
            else
            {
                MessageBox.Show("Enter value to update the cost", "Error", 0, MessageBoxIcon.Error);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm.Show();
        }
    }
}
