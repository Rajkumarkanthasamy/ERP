﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.Diagnostics;
using System.IO;

namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    public partial class frmOpportuniyDetails : Form
    {
        public frmOpportuniyDetails()
        {
            InitializeComponent();
        }
        frmForm2 form = new frmForm2();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        DataTable dtQuoteList = new DataTable();
        frmSalesHome SalesHome = new frmSalesHome();

        private void btnReport_Click(object sender, EventArgs e)
        {
            fnLoadResults();
        }

        private void frmOpportuniyDetails_Load(object sender, EventArgs e)
        {
            fnLoadResults();
        }

        BindingSource bsIteSearch = new BindingSource();
        DataTable dtClone = new DataTable();
        DataTable dtQuoteGroup = new DataTable();
        DataTable dtAddAll = new DataTable();
        DataTable dtQuoteAmount = new DataTable();
        private void fnLoadResults()
        {
            dtpfromdate.Format = DateTimePickerFormat.Custom;
            dtpfromdate.CustomFormat = "yyyy-MM-dd";
            dtptodate.Format = DateTimePickerFormat.Custom;
            dtptodate.CustomFormat = "yyyy-MM-dd";
            dtAddAll = new DataTable();
            dtQuoteGroup = DAL.fnAllQuoteOpportunityViewDetails(0, null, null, dtpfromdate.Text, dtptodate.Text).Tables[0];

            if (dtQuoteGroup.Rows.Count > 0)
            {
                foreach (DataRow dr in dtQuoteGroup.Rows)
                {
                    dtQuoteList = DAL.fnAllQuoteOpportunityViewDetails(1, dr[0].ToString(), dr[1].ToString(), dtpfromdate.Text, dtptodate.Text).Tables[0];

                    dtQuoteAmount = DAL.fnAllQuoteOpportunityViewDetails(2, dr[0].ToString(), dr[1].ToString(), dtpfromdate.Text, dtptodate.Text).Tables[0];
                    if (dtQuoteAmount.Rows.Count > 0)
                    {
                        if (dtQuoteList.Rows.Count > 0)
                        {
                            dtQuoteList.Rows[0]["OrderValue"] = dtQuoteAmount.Rows[0]["OrderValue"];
                        }
                    }

                    dtAddAll.Merge(dtQuoteList);
                }
            }
            if (dtAddAll.Rows.Count > 0)
            {
                dgvQuoteView.AutoGenerateColumns = false;
                dgvQuoteView.DataSource = dtAddAll;
            }
            dtpfromdate.Format = DateTimePickerFormat.Custom;
            dtpfromdate.CustomFormat = "dd-MM-yyyy";
            dtptodate.Format = DateTimePickerFormat.Custom;
            dtptodate.CustomFormat = "dd-MM-yyyy";

            dtClone = dtAddAll.Copy();
            bsIteSearch.DataSource = dtClone;

        }

        private void frmOpportuniyDetails_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            SalesHome.Show();
        }

        private void cmbreporttype_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbreporttype.SelectedIndex >= 0)
            {
                txtSearchText.Enabled = true;
            }
        }

        private void txtSearchText_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtSearchText.Text.Length > 1)
            {
                fnRowFilter(cmbreporttype.SelectedIndex, txtSearchText.Text);
                dgvQuoteView.DataSource = bsIteSearch;
            }
            else
            {
                bsIteSearch.RemoveFilter();
            }
        }


        //        Quotation Number
        //Customer Name
        //Lab Type
        //Business Sector
        //Primary Industry
        //Primary Material
        //Primary Material Detail
        //Application
        //Test Environment
        //Status
        //Stage
        //Type of Customer
        //Probability
        //Competition
        //Won Lost
        private void fnRowFilter(int uSearchOption, string sRowFilter)    //filter the Item list depends upon the user inpts
        {
            if (dtQuoteList.Rows.Count > 0)
            {
                switch (uSearchOption)
                {
                    case 0:
                        {
                            bsIteSearch.Filter = string.Format("QuotationNumber LIKE '%{0}%'", sRowFilter);
                            break;
                        }
                    case 1:
                        {
                            bsIteSearch.Filter = string.Format("CustomerName LIKE '%{0}%'", sRowFilter);
                            break;
                        }
                    case 2:
                        {
                            bsIteSearch.Filter = string.Format("LabType LIKE '%{0}%'", sRowFilter);
                            break;
                        }
                    case 3:
                        {
                            bsIteSearch.Filter = string.Format("BusinessSector LIKE '%{0}%'", sRowFilter);
                            break;
                        }
                    case 4:
                        {
                            bsIteSearch.Filter = string.Format("PrimaryInd LIKE '%{0}%'", sRowFilter);
                            break;
                        }
                    case 5:
                        {
                            bsIteSearch.Filter = string.Format("PrimaryMtrl LIKE '%{0}%'", sRowFilter);
                            break;
                        }
                    case 6:
                        {
                            bsIteSearch.Filter = string.Format("PrimaryMtrlDetail LIKE '%{0}%'", sRowFilter);
                            break;
                        }
                    case 7:
                        {
                            bsIteSearch.Filter = string.Format("Application LIKE '%{0}%'", sRowFilter);
                            break;
                        }
                    case 8:
                        {
                            bsIteSearch.Filter = string.Format("TestEnvironment LIKE '%{0}%'", sRowFilter);
                            break;
                        }
                    case 9:
                        {
                            bsIteSearch.Filter = string.Format("Status LIKE '%{0}%'", sRowFilter);
                            break;
                        }
                    case 10:
                        {
                            bsIteSearch.Filter = string.Format("Stage LIKE '%{0}%'", sRowFilter);
                            break;
                        }
                    case 11:
                        {
                            bsIteSearch.Filter = string.Format("TypeofCustomer LIKE '%{0}%'", sRowFilter);
                            break;
                        }

                    case 12:
                        {
                            bsIteSearch.Filter = string.Format("Probability LIKE '%{0}%'", sRowFilter);
                            break;
                        }
                    case 13:
                        {
                            bsIteSearch.Filter = string.Format("Competition LIKE '%{0}%' or SpecifyOthers LIKE '%{0}%' ", sRowFilter);
                            break;
                        }
                    case 14:
                        {
                            bsIteSearch.Filter = string.Format("WonLost LIKE '%{0}%'", sRowFilter);
                            break;
                        }
                }
            }
        }

        private void btnExcel_Click(object sender, EventArgs e)
        {
            string ExcelFolderPath;
            string FileFullPath;
            //  dgvQuoteView.DataSource
            Microsoft.Office.Interop.Excel._Application ExcelApp = null;
            Microsoft.Office.Interop.Excel._Workbook NewWorkBook = null;
            Cursor.Current = Cursors.WaitCursor;

            bool IsFirsttime = true;
           // DataTable dataTable = (DataTable)BindingSource.bsIteSearch;
            DataTable dtEnquiryDetails = new DataTable();
            dtEnquiryDetails = (DataTable)dgvQuoteView.DataSource;
          //  dtEnquiryDetails = bsIteSearch.DataSource();
            if (dtEnquiryDetails.Rows.Count > 0)
            {
                int j = 6;
                ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\Opportunity Details\\";
                FileFullPath = ExcelFolderPath + "BiSS Opportunity Details " + dtpfromdate.Text + " To " + dtptodate.Text + " " + DateTime.Now.ToString("d/M/yyyy HH/mm/ss") + " ";
                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);

                ExcelApp = new Microsoft.Office.Interop.Excel.Application();
                NewWorkBook = ExcelApp.Workbooks.Add(Type.Missing);
                Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
                worksheet = NewWorkBook.Sheets["Sheet1"];
                worksheet = NewWorkBook.ActiveSheet;
                worksheet.Name = "BiSS Opportunity Details";
                object misValue = System.Reflection.Missing.Value;
                worksheet.Cells[1, 1] = "BiSS Opportunity Details";
                CellMerge("Merge", NewWorkBook.ActiveSheet, 1, 1, 1, 3);
                //worksheet.Cells[2, 1] = "Item Code :'" + lblRepeatitemcode.Text + "'";// i++;
                //CellMerge("Merge", NewWorkBook.ActiveSheet, 2, 2, 1, 7);
                //worksheet.Cells[3, 1] = "Item Desc : " + lblitemname.Text + "";
                //CellMerge("Merge", NewWorkBook.ActiveSheet, 3, 3, 1, 7);
                worksheet.Cells[4, 1] = "Dated From : " + dtpfromdate.Text + "  To : " + dtptodate.Text + "";// i++; i++;
                CellMerge("Merge", NewWorkBook.ActiveSheet, 4, 4, 1, 5);
                worksheet.Range["A1:C1"].Cells.Font.Size = 16;
                worksheet.Range["A2:C3"].Cells.Font.Size = 14;
                worksheet.Range["A4:C4"].Cells.Font.Size = 12;
                worksheet.Range["A1:C3"].Cells.Font.Bold = true;
                bool bFirsttime = true;

                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Bold = true;
                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Color = Color.Blue;


                object[,] rawData = new object[dtEnquiryDetails.Rows.Count + 1, dtEnquiryDetails.Columns.Count];
                if (bFirsttime)
                {
                    for (int col = 0; col < dtEnquiryDetails.Columns.Count; col++)
                    {
                        rawData[0, col] = dtEnquiryDetails.Columns[col].ColumnName;
                    }
                    bFirsttime = false;
                }
                if (dtEnquiryDetails.Rows.Count > 0)
                {
                    for (int row = 0; row < dtEnquiryDetails.Rows.Count; row++)
                    {
                        for (int col = 0; col < dtEnquiryDetails.Columns.Count; col++)
                        {
                            rawData[row + 1, col] = dtEnquiryDetails.Rows[row].ItemArray[col];
                        }
                    }
                    string finalColLetter = string.Empty;
                    string excelRange = string.Empty;
                    if (IsFirsttime)
                    {
                        finalColLetter = string.Empty;
                        string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        int colCharsetLen = colCharset.Length;

                        if (dtEnquiryDetails.Columns.Count > colCharsetLen)
                        {
                            finalColLetter = colCharset.Substring((dtEnquiryDetails.Columns.Count - 1) / colCharsetLen - 1, 1);
                        }

                        finalColLetter += colCharset.Substring((dtEnquiryDetails.Columns.Count - 1) % colCharsetLen, 1);
                        excelRange = string.Format("A6:{0}{1}", finalColLetter, dtEnquiryDetails.Rows.Count + j);
                        IsFirsttime = false;
                    }
                    worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;

                }

                worksheet.Range["A3:C5"].Cells.Font.Size = 14;
                worksheet.Range["A3:C5"].Cells.Font.Bold = 14;
                CellMerge("Merge", NewWorkBook.ActiveSheet, 1, 1, 1, 3);
                //worksheet.get_Range("C6", "C99999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                //Microsoft.Office.Interop.Excel.Range Range = worksheet.get_Range("N6", "R99999");
                //Range.EntireColumn.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                worksheet.Rows.RowHeight = "18";
                //Microsoft.Office.Interop.Excel.Range rangea = worksheet.get_Range("J6", "J99999");
                //  rangea.NumberFormat = "dd-MM-yyyy";

                //  if (cmbReportType.SelectedIndex == 0 || cmbReportType.SelectedIndex == 5 || cmbReportType.SelectedIndex == 6)
                {
                    Microsoft.Office.Interop.Excel.Range rangea = worksheet.get_Range("O6", "O9999");
                    rangea.NumberFormat = "dd-MM-yyyy";
                    //Microsoft.Office.Interop.Excel.Range rangeDate = worksheet.get_Range("U6", "U9999");
                    //rangeDate.NumberFormat = "dd-MM-yyyy";

                    //Microsoft.Office.Interop.Excel.Range rangeDate1 = worksheet.get_Range("N6", "N9999");
                    //rangeDate1.NumberFormat = "0.00";
                }

                worksheet.Columns.AutoFit();
                worksheet.Rows.AutoFit();
                //worksheet.Columns[1].ColumnWidth = 12;
                //worksheet.Columns[1].WrapText = true;
                //worksheet.Columns[12].ColumnWidth = 50;
                // worksheet.Columns[12].WrapText = true;
                //worksheet.Columns[8].ColumnWidth = 50;
                //worksheet.Columns[8].WrapText = true;
                worksheet.Rows.RowHeight = "18";
                worksheet.PageSetup.PrintArea = "A1:X" + (dtEnquiryDetails.Rows.Count + 6) + "";
                worksheet.PageSetup.PrintTitleRows = "$1:$2";
                worksheet.PageSetup.PrintNotes = true;
                worksheet.PageSetup.Zoom = 75;
                worksheet.PageSetup.PrintGridlines = true;
                worksheet.PageSetup.LeftMargin = 0;
                worksheet.PageSetup.RightMargin = 0;
                worksheet.PageSetup.TopMargin = 0.75;
                worksheet.PageSetup.BottomMargin = 0.75;
                worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                NewWorkBook.SaveAs(FileFullPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                NewWorkBook.Save();
                NewWorkBook.Close(true, misValue, misValue);
                ExcelApp.Quit();
                releaseObject(worksheet);
                releaseObject(NewWorkBook);
                releaseObject(ExcelApp);

                if (Directory.Exists(ExcelFolderPath))
                {
                    Process.Start(ExcelFolderPath);
                }
                Cursor.Current = Cursors.Default;
            }
        }

        #region CellMerge Funtion
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlMedium, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "GridLines":
                    {
                        CELLS.Borders.Color = System.Drawing.Color.Black;
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignCenter":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                        break;
                    }
                case "Bold":
                    {
                        CELLS.Font.Bold = true;
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

        }
        #endregion

        #region Excel App Release Object Function
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
        #endregion
    }
}
