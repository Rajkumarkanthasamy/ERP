﻿namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    partial class TestingQuote
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TestingQuote));
            this.lblsuupliercode = new System.Windows.Forms.Label();
            this.cmbCustomer = new System.Windows.Forms.ComboBox();
            this.cmbcustomertype = new System.Windows.Forms.ComboBox();
            this.lblsaletype = new System.Windows.Forms.Label();
            this.cmbEnquireMonth = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbSubmittedMonth = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dtpporevisiondate = new System.Windows.Forms.DateTimePicker();
            this.lblcontactperson = new System.Windows.Forms.Label();
            this.txtcontactperson = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtphonenumber = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtOffername = new System.Windows.Forms.TextBox();
            this.cmbTypeofIndustry = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.pnSaveQuote = new System.Windows.Forms.Panel();
            this.txtCustomerAddress = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.txtDesignation = new System.Windows.Forms.TextBox();
            this.btnCusSearch = new System.Windows.Forms.Button();
            this.txtComment = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.cmbstandardcustom = new System.Windows.Forms.ComboBox();
            this.txtPONumber = new System.Windows.Forms.TextBox();
            this.txtGstValue = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.cmbregion = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtDepartment = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtEmailID = new System.Windows.Forms.TextBox();
            this.txtCostValue = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.cmbBooked = new System.Windows.Forms.ComboBox();
            this.cmbMaterialType = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cmbApplicationtesttype = new System.Windows.Forms.ComboBox();
            this.cmbBookingEstimation = new System.Windows.Forms.ComboBox();
            this.cmbEightyMonth = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.cmbStatus = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.dgvQuoteItems = new System.Windows.Forms.DataGridView();
            this.DSCSLNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Specifications = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Discount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnAddNewRow = new System.Windows.Forms.Button();
            this.cmbOfferNumber = new System.Windows.Forms.ComboBox();
            this.lblOfferNumber = new System.Windows.Forms.Label();
            this.btnViewQuote = new System.Windows.Forms.Button();
            this.label81 = new System.Windows.Forms.Label();
            this.cmbSelectQuoteType = new System.Windows.Forms.ComboBox();
            this.chkQuoteSavePath = new System.Windows.Forms.CheckBox();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.pnCustomerDetails = new System.Windows.Forms.Panel();
            this.btnClose = new System.Windows.Forms.Button();
            this.txtSearchText = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.dgvQuoteView = new System.Windows.Forms.DataGridView();
            this.Customer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ContactPerson = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PhoneNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmailId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Department = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Designation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StandardCustom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Region = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EightyTwenty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NewOldCustomer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnSaveQuote.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuoteItems)).BeginInit();
            this.pnCustomerDetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuoteView)).BeginInit();
            this.SuspendLayout();
            // 
            // lblsuupliercode
            // 
            this.lblsuupliercode.AutoSize = true;
            this.lblsuupliercode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsuupliercode.ForeColor = System.Drawing.Color.Black;
            this.lblsuupliercode.Location = new System.Drawing.Point(685, 12);
            this.lblsuupliercode.Name = "lblsuupliercode";
            this.lblsuupliercode.Size = new System.Drawing.Size(134, 19);
            this.lblsuupliercode.TabIndex = 113;
            this.lblsuupliercode.Text = "Customer Name *:";
            // 
            // cmbCustomer
            // 
            this.cmbCustomer.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbCustomer.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCustomer.DropDownHeight = 130;
            this.cmbCustomer.DropDownWidth = 237;
            this.cmbCustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCustomer.FormattingEnabled = true;
            this.cmbCustomer.IntegralHeight = false;
            this.cmbCustomer.ItemHeight = 18;
            this.cmbCustomer.Items.AddRange(new object[] {
            "None"});
            this.cmbCustomer.Location = new System.Drawing.Point(822, 10);
            this.cmbCustomer.Name = "cmbCustomer";
            this.cmbCustomer.Size = new System.Drawing.Size(414, 26);
            this.cmbCustomer.TabIndex = 114;
            this.cmbCustomer.SelectedIndexChanged += new System.EventHandler(this.cmbCustomer_SelectedIndexChanged);
            // 
            // cmbcustomertype
            // 
            this.cmbcustomertype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbcustomertype.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbcustomertype.FormattingEnabled = true;
            this.cmbcustomertype.Items.AddRange(new object[] {
            "Old",
            "New"});
            this.cmbcustomertype.Location = new System.Drawing.Point(822, 45);
            this.cmbcustomertype.Name = "cmbcustomertype";
            this.cmbcustomertype.Size = new System.Drawing.Size(197, 26);
            this.cmbcustomertype.TabIndex = 116;
            // 
            // lblsaletype
            // 
            this.lblsaletype.AutoSize = true;
            this.lblsaletype.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsaletype.ForeColor = System.Drawing.Color.Black;
            this.lblsaletype.Location = new System.Drawing.Point(692, 47);
            this.lblsaletype.Name = "lblsaletype";
            this.lblsaletype.Size = new System.Drawing.Size(127, 19);
            this.lblsaletype.TabIndex = 115;
            this.lblsaletype.Text = "Customer Type* :";
            // 
            // cmbEnquireMonth
            // 
            this.cmbEnquireMonth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEnquireMonth.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbEnquireMonth.FormattingEnabled = true;
            this.cmbEnquireMonth.Items.AddRange(new object[] {
            "P1",
            "P2",
            "P3",
            "P4",
            "P5",
            "P6",
            "P7",
            "P8",
            "P9",
            "P10",
            "P11",
            "P12"});
            this.cmbEnquireMonth.Location = new System.Drawing.Point(171, 8);
            this.cmbEnquireMonth.Name = "cmbEnquireMonth";
            this.cmbEnquireMonth.Size = new System.Drawing.Size(78, 26);
            this.cmbEnquireMonth.TabIndex = 118;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(40, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 19);
            this.label1.TabIndex = 117;
            this.label1.Text = "Enquiry Month* :";
            // 
            // cmbSubmittedMonth
            // 
            this.cmbSubmittedMonth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSubmittedMonth.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSubmittedMonth.FormattingEnabled = true;
            this.cmbSubmittedMonth.Items.AddRange(new object[] {
            "P1",
            "P2",
            "P3",
            "P4",
            "P5",
            "P6",
            "P7",
            "P8",
            "P9",
            "P10",
            "P11",
            "P12"});
            this.cmbSubmittedMonth.Location = new System.Drawing.Point(426, 8);
            this.cmbSubmittedMonth.Name = "cmbSubmittedMonth";
            this.cmbSubmittedMonth.Size = new System.Drawing.Size(78, 26);
            this.cmbSubmittedMonth.TabIndex = 120;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(273, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(147, 19);
            this.label2.TabIndex = 119;
            this.label2.Text = "Submitted Month* :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(1124, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 19);
            this.label3.TabIndex = 121;
            this.label3.Text = "Date :";
            // 
            // dtpporevisiondate
            // 
            this.dtpporevisiondate.Enabled = false;
            this.dtpporevisiondate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpporevisiondate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpporevisiondate.Location = new System.Drawing.Point(1179, 4);
            this.dtpporevisiondate.Name = "dtpporevisiondate";
            this.dtpporevisiondate.Size = new System.Drawing.Size(105, 26);
            this.dtpporevisiondate.TabIndex = 122;
            // 
            // lblcontactperson
            // 
            this.lblcontactperson.AutoSize = true;
            this.lblcontactperson.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcontactperson.ForeColor = System.Drawing.Color.Black;
            this.lblcontactperson.Location = new System.Drawing.Point(690, 82);
            this.lblcontactperson.Name = "lblcontactperson";
            this.lblcontactperson.Size = new System.Drawing.Size(129, 19);
            this.lblcontactperson.TabIndex = 123;
            this.lblcontactperson.Text = "Contact Person* :";
            // 
            // txtcontactperson
            // 
            this.txtcontactperson.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcontactperson.Location = new System.Drawing.Point(822, 80);
            this.txtcontactperson.Name = "txtcontactperson";
            this.txtcontactperson.Size = new System.Drawing.Size(197, 26);
            this.txtcontactperson.TabIndex = 124;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(698, 118);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(121, 19);
            this.label4.TabIndex = 125;
            this.label4.Text = "Phone Number :";
            // 
            // txtphonenumber
            // 
            this.txtphonenumber.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtphonenumber.Location = new System.Drawing.Point(822, 116);
            this.txtphonenumber.Name = "txtphonenumber";
            this.txtphonenumber.Size = new System.Drawing.Size(197, 26);
            this.txtphonenumber.TabIndex = 126;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(65, 45);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 19);
            this.label5.TabIndex = 127;
            this.label5.Text = "Offer Name* :";
            // 
            // txtOffername
            // 
            this.txtOffername.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOffername.Location = new System.Drawing.Point(171, 43);
            this.txtOffername.Multiline = true;
            this.txtOffername.Name = "txtOffername";
            this.txtOffername.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtOffername.Size = new System.Drawing.Size(335, 61);
            this.txtOffername.TabIndex = 128;
            // 
            // cmbTypeofIndustry
            // 
            this.cmbTypeofIndustry.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTypeofIndustry.FormattingEnabled = true;
            this.cmbTypeofIndustry.Items.AddRange(new object[] {
            "Automotive",
            "Academic",
            "Aerospace",
            "Building/Construction",
            "Defence",
            "Electronics",
            "Healthcare",
            "Nuclear",
            "Wind Energy"});
            this.cmbTypeofIndustry.Location = new System.Drawing.Point(171, 113);
            this.cmbTypeofIndustry.Name = "cmbTypeofIndustry";
            this.cmbTypeofIndustry.Size = new System.Drawing.Size(335, 26);
            this.cmbTypeofIndustry.TabIndex = 130;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(50, 115);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(119, 19);
            this.label6.TabIndex = 129;
            this.label6.Text = "Industry Type* :";
            // 
            // pnSaveQuote
            // 
            this.pnSaveQuote.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnSaveQuote.Controls.Add(this.txtCustomerAddress);
            this.pnSaveQuote.Controls.Add(this.label22);
            this.pnSaveQuote.Controls.Add(this.label21);
            this.pnSaveQuote.Controls.Add(this.txtDesignation);
            this.pnSaveQuote.Controls.Add(this.btnCusSearch);
            this.pnSaveQuote.Controls.Add(this.txtComment);
            this.pnSaveQuote.Controls.Add(this.label12);
            this.pnSaveQuote.Controls.Add(this.label13);
            this.pnSaveQuote.Controls.Add(this.cmbstandardcustom);
            this.pnSaveQuote.Controls.Add(this.txtPONumber);
            this.pnSaveQuote.Controls.Add(this.txtGstValue);
            this.pnSaveQuote.Controls.Add(this.label20);
            this.pnSaveQuote.Controls.Add(this.cmbregion);
            this.pnSaveQuote.Controls.Add(this.label19);
            this.pnSaveQuote.Controls.Add(this.label11);
            this.pnSaveQuote.Controls.Add(this.label18);
            this.pnSaveQuote.Controls.Add(this.txtDepartment);
            this.pnSaveQuote.Controls.Add(this.label10);
            this.pnSaveQuote.Controls.Add(this.txtEmailID);
            this.pnSaveQuote.Controls.Add(this.txtCostValue);
            this.pnSaveQuote.Controls.Add(this.label17);
            this.pnSaveQuote.Controls.Add(this.cmbBooked);
            this.pnSaveQuote.Controls.Add(this.cmbMaterialType);
            this.pnSaveQuote.Controls.Add(this.label9);
            this.pnSaveQuote.Controls.Add(this.cmbApplicationtesttype);
            this.pnSaveQuote.Controls.Add(this.cmbBookingEstimation);
            this.pnSaveQuote.Controls.Add(this.cmbEightyMonth);
            this.pnSaveQuote.Controls.Add(this.label8);
            this.pnSaveQuote.Controls.Add(this.label16);
            this.pnSaveQuote.Controls.Add(this.cmbStatus);
            this.pnSaveQuote.Controls.Add(this.label15);
            this.pnSaveQuote.Controls.Add(this.label7);
            this.pnSaveQuote.Controls.Add(this.label14);
            this.pnSaveQuote.Controls.Add(this.label1);
            this.pnSaveQuote.Controls.Add(this.cmbTypeofIndustry);
            this.pnSaveQuote.Controls.Add(this.label6);
            this.pnSaveQuote.Controls.Add(this.lblsuupliercode);
            this.pnSaveQuote.Controls.Add(this.cmbCustomer);
            this.pnSaveQuote.Controls.Add(this.txtOffername);
            this.pnSaveQuote.Controls.Add(this.lblsaletype);
            this.pnSaveQuote.Controls.Add(this.label5);
            this.pnSaveQuote.Controls.Add(this.cmbcustomertype);
            this.pnSaveQuote.Controls.Add(this.label4);
            this.pnSaveQuote.Controls.Add(this.cmbEnquireMonth);
            this.pnSaveQuote.Controls.Add(this.txtphonenumber);
            this.pnSaveQuote.Controls.Add(this.label2);
            this.pnSaveQuote.Controls.Add(this.lblcontactperson);
            this.pnSaveQuote.Controls.Add(this.cmbSubmittedMonth);
            this.pnSaveQuote.Controls.Add(this.txtcontactperson);
            this.pnSaveQuote.Enabled = false;
            this.pnSaveQuote.Location = new System.Drawing.Point(3, 36);
            this.pnSaveQuote.Name = "pnSaveQuote";
            this.pnSaveQuote.Size = new System.Drawing.Size(1291, 323);
            this.pnSaveQuote.TabIndex = 131;
            // 
            // txtCustomerAddress
            // 
            this.txtCustomerAddress.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerAddress.Location = new System.Drawing.Point(822, 227);
            this.txtCustomerAddress.Multiline = true;
            this.txtCustomerAddress.Name = "txtCustomerAddress";
            this.txtCustomerAddress.Size = new System.Drawing.Size(462, 86);
            this.txtCustomerAddress.TabIndex = 149;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Black;
            this.label22.Location = new System.Drawing.Point(748, 229);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(71, 19);
            this.label22.TabIndex = 148;
            this.label22.Text = "Address :";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(1026, 82);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(97, 19);
            this.label21.TabIndex = 146;
            this.label21.Text = "Designation :";
            // 
            // txtDesignation
            // 
            this.txtDesignation.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDesignation.Location = new System.Drawing.Point(1123, 80);
            this.txtDesignation.Name = "txtDesignation";
            this.txtDesignation.Size = new System.Drawing.Size(161, 26);
            this.txtDesignation.TabIndex = 147;
            // 
            // btnCusSearch
            // 
            this.btnCusSearch.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnCusSearch.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCusSearch.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCusSearch.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCusSearch.Location = new System.Drawing.Point(1237, 8);
            this.btnCusSearch.Name = "btnCusSearch";
            this.btnCusSearch.Size = new System.Drawing.Size(47, 29);
            this.btnCusSearch.TabIndex = 145;
            this.btnCusSearch.Text = "Search";
            this.btnCusSearch.UseVisualStyleBackColor = false;
            this.btnCusSearch.Click += new System.EventHandler(this.btnCusSearch_Click);
            // 
            // txtComment
            // 
            this.txtComment.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtComment.Location = new System.Drawing.Point(471, 254);
            this.txtComment.Multiline = true;
            this.txtComment.Name = "txtComment";
            this.txtComment.Size = new System.Drawing.Size(247, 64);
            this.txtComment.TabIndex = 142;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(393, 256);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(75, 19);
            this.label12.TabIndex = 141;
            this.label12.Text = "Remarks :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(221, 291);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(21, 19);
            this.label13.TabIndex = 144;
            this.label13.Text = "%";
            // 
            // cmbstandardcustom
            // 
            this.cmbstandardcustom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbstandardcustom.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbstandardcustom.FormattingEnabled = true;
            this.cmbstandardcustom.Items.AddRange(new object[] {
            "Standard",
            "Custom"});
            this.cmbstandardcustom.Location = new System.Drawing.Point(1157, 192);
            this.cmbstandardcustom.Name = "cmbstandardcustom";
            this.cmbstandardcustom.Size = new System.Drawing.Size(126, 26);
            this.cmbstandardcustom.TabIndex = 144;
            // 
            // txtPONumber
            // 
            this.txtPONumber.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPONumber.Location = new System.Drawing.Point(470, 219);
            this.txtPONumber.Name = "txtPONumber";
            this.txtPONumber.Size = new System.Drawing.Size(248, 26);
            this.txtPONumber.TabIndex = 140;
            // 
            // txtGstValue
            // 
            this.txtGstValue.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGstValue.Location = new System.Drawing.Point(171, 289);
            this.txtGstValue.Name = "txtGstValue";
            this.txtGstValue.Size = new System.Drawing.Size(47, 26);
            this.txtGstValue.TabIndex = 143;
            this.txtGstValue.Text = "18";
            this.txtGstValue.TextChanged += new System.EventHandler(this.txtGstValue_TextChanged);
            this.txtGstValue.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGstValue_KeyPress);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(1014, 194);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(138, 19);
            this.label20.TabIndex = 143;
            this.label20.Text = "Standard/Custom :";
            // 
            // cmbregion
            // 
            this.cmbregion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbregion.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbregion.FormattingEnabled = true;
            this.cmbregion.Items.AddRange(new object[] {
            "East",
            "North",
            "South",
            "West",
            "International"});
            this.cmbregion.Location = new System.Drawing.Point(822, 192);
            this.cmbregion.Name = "cmbregion";
            this.cmbregion.Size = new System.Drawing.Size(121, 26);
            this.cmbregion.TabIndex = 142;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(747, 194);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(72, 19);
            this.label19.TabIndex = 141;
            this.label19.Text = "Region* :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(399, 219);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(69, 19);
            this.label11.TabIndex = 139;
            this.label11.Text = "PO No* :";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(1023, 120);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(100, 19);
            this.label18.TabIndex = 139;
            this.label18.Text = "Department :";
            // 
            // txtDepartment
            // 
            this.txtDepartment.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDepartment.Location = new System.Drawing.Point(1123, 116);
            this.txtDepartment.Name = "txtDepartment";
            this.txtDepartment.Size = new System.Drawing.Size(161, 26);
            this.txtDepartment.TabIndex = 140;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(11, 291);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(157, 19);
            this.label10.TabIndex = 137;
            this.label10.Text = "Contract Value, INR* :";
            // 
            // txtEmailID
            // 
            this.txtEmailID.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmailID.Location = new System.Drawing.Point(822, 153);
            this.txtEmailID.Name = "txtEmailID";
            this.txtEmailID.Size = new System.Drawing.Size(462, 26);
            this.txtEmailID.TabIndex = 138;
            // 
            // txtCostValue
            // 
            this.txtCostValue.Enabled = false;
            this.txtCostValue.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCostValue.Location = new System.Drawing.Point(248, 289);
            this.txtCostValue.Name = "txtCostValue";
            this.txtCostValue.Size = new System.Drawing.Size(132, 26);
            this.txtCostValue.TabIndex = 138;
            this.txtCostValue.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCostValue_KeyPress);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(747, 157);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(72, 19);
            this.label17.TabIndex = 137;
            this.label17.Text = "Email ID :";
            // 
            // cmbBooked
            // 
            this.cmbBooked.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBooked.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbBooked.FormattingEnabled = true;
            this.cmbBooked.Items.AddRange(new object[] {
            "P1",
            "P2",
            "P3",
            "P4",
            "P5",
            "P6",
            "P7",
            "P8",
            "P9",
            "P10",
            "P11",
            "P12"});
            this.cmbBooked.Location = new System.Drawing.Point(325, 254);
            this.cmbBooked.Name = "cmbBooked";
            this.cmbBooked.Size = new System.Drawing.Size(55, 26);
            this.cmbBooked.TabIndex = 136;
            // 
            // cmbMaterialType
            // 
            this.cmbMaterialType.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbMaterialType.FormattingEnabled = true;
            this.cmbMaterialType.Items.AddRange(new object[] {
            "Adhesive",
            "CFRP",
            "Component",
            "GFRP",
            "Metal",
            "Plastic",
            "Rubber",
            "Spring"});
            this.cmbMaterialType.Location = new System.Drawing.Point(171, 183);
            this.cmbMaterialType.Name = "cmbMaterialType";
            this.cmbMaterialType.Size = new System.Drawing.Size(335, 26);
            this.cmbMaterialType.TabIndex = 136;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(248, 257);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 19);
            this.label9.TabIndex = 135;
            this.label9.Text = "Booked* :";
            // 
            // cmbApplicationtesttype
            // 
            this.cmbApplicationtesttype.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbApplicationtesttype.FormattingEnabled = true;
            this.cmbApplicationtesttype.Items.AddRange(new object[] {
            "RT Static ",
            "HT Static ",
            "Static Compression Test",
            "RT LCF Test",
            "HT LCF Test",
            "RT HCF Test",
            "HT HCF Test",
            "J1c",
            "K1c",
            "HSR/DIC Test",
            "LCF Test in Corrosion Medium",
            "FCGR Test",
            "CTOD Test",
            "Torsional Fatigue",
            "ILSS",
            "Compression"});
            this.cmbApplicationtesttype.Location = new System.Drawing.Point(171, 148);
            this.cmbApplicationtesttype.Name = "cmbApplicationtesttype";
            this.cmbApplicationtesttype.Size = new System.Drawing.Size(335, 26);
            this.cmbApplicationtesttype.TabIndex = 135;
            // 
            // cmbBookingEstimation
            // 
            this.cmbBookingEstimation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBookingEstimation.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbBookingEstimation.FormattingEnabled = true;
            this.cmbBookingEstimation.Items.AddRange(new object[] {
            "P1",
            "P2",
            "P3",
            "P4",
            "P5",
            "P6",
            "P7",
            "P8",
            "P9",
            "P10",
            "P11",
            "P12"});
            this.cmbBookingEstimation.Location = new System.Drawing.Point(171, 254);
            this.cmbBookingEstimation.Name = "cmbBookingEstimation";
            this.cmbBookingEstimation.Size = new System.Drawing.Size(55, 26);
            this.cmbBookingEstimation.TabIndex = 134;
            // 
            // cmbEightyMonth
            // 
            this.cmbEightyMonth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEightyMonth.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbEightyMonth.FormattingEnabled = true;
            this.cmbEightyMonth.Items.AddRange(new object[] {
            "80",
            "20"});
            this.cmbEightyMonth.Location = new System.Drawing.Point(1123, 45);
            this.cmbEightyMonth.Name = "cmbEightyMonth";
            this.cmbEightyMonth.Size = new System.Drawing.Size(157, 26);
            this.cmbEightyMonth.TabIndex = 134;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(12, 256);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(156, 19);
            this.label8.TabIndex = 133;
            this.label8.Text = "Booking Estimation* :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(1055, 45);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(68, 19);
            this.label16.TabIndex = 133;
            this.label16.Text = "80/20 * :";
            // 
            // cmbStatus
            // 
            this.cmbStatus.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.Items.AddRange(new object[] {
            "Quote Submitted",
            "Low",
            "Med",
            "High"});
            this.cmbStatus.Location = new System.Drawing.Point(171, 217);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(209, 26);
            this.cmbStatus.TabIndex = 132;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(47, 185);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(124, 19);
            this.label15.TabIndex = 132;
            this.label15.Text = "Material Type* : ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(17, 223);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(151, 19);
            this.label7.TabIndex = 131;
            this.label7.Text = "Status/Confidence* :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(-5, 150);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(174, 19);
            this.label14.TabIndex = 131;
            this.label14.Text = "Application/Test Type* :";
            // 
            // dgvQuoteItems
            // 
            this.dgvQuoteItems.AllowUserToAddRows = false;
            this.dgvQuoteItems.AllowUserToOrderColumns = true;
            this.dgvQuoteItems.AllowUserToResizeRows = false;
            this.dgvQuoteItems.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvQuoteItems.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvQuoteItems.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvQuoteItems.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvQuoteItems.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvQuoteItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvQuoteItems.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DSCSLNO,
            this.Specifications,
            this.Quantity,
            this.UnitPrice,
            this.Discount,
            this.Amount,
            this.SP});
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvQuoteItems.DefaultCellStyle = dataGridViewCellStyle7;
            this.dgvQuoteItems.Location = new System.Drawing.Point(4, 362);
            this.dgvQuoteItems.Name = "dgvQuoteItems";
            this.dgvQuoteItems.RowHeadersVisible = false;
            this.dgvQuoteItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvQuoteItems.Size = new System.Drawing.Size(1290, 282);
            this.dgvQuoteItems.TabIndex = 181;
            this.dgvQuoteItems.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgvQuoteItems_CellBeginEdit);
            this.dgvQuoteItems.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvQuoteItems_CellContentClick);
            this.dgvQuoteItems.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvQuoteItems_CellDoubleClick);
            this.dgvQuoteItems.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvQuoteItems_CellEndEdit);
            this.dgvQuoteItems.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvQuoteItems_EditingControlShowing);
            this.dgvQuoteItems.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dgvQuoteItems_KeyDown);
            this.dgvQuoteItems.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvQuoteItems_KeyUp);
            this.dgvQuoteItems.MouseUp += new System.Windows.Forms.MouseEventHandler(this.dgvQuoteItems_MouseUp);
            // 
            // DSCSLNO
            // 
            this.DSCSLNO.DataPropertyName = "SlNo";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.LightGreen;
            this.DSCSLNO.DefaultCellStyle = dataGridViewCellStyle2;
            this.DSCSLNO.FillWeight = 56.85279F;
            this.DSCSLNO.HeaderText = "SlNo";
            this.DSCSLNO.Name = "DSCSLNO";
            this.DSCSLNO.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DSCSLNO.Width = 44;
            // 
            // Specifications
            // 
            this.Specifications.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Specifications.DataPropertyName = "Specifications";
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.LightGreen;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.Specifications.DefaultCellStyle = dataGridViewCellStyle3;
            this.Specifications.FillWeight = 107.1912F;
            this.Specifications.HeaderText = "Specifications";
            this.Specifications.Name = "Specifications";
            this.Specifications.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "Quantity";
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.LightGreen;
            this.Quantity.DefaultCellStyle = dataGridViewCellStyle4;
            this.Quantity.HeaderText = "Quantity";
            this.Quantity.Name = "Quantity";
            this.Quantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Quantity.Width = 71;
            // 
            // UnitPrice
            // 
            this.UnitPrice.DataPropertyName = "UnitCost";
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.LightGreen;
            this.UnitPrice.DefaultCellStyle = dataGridViewCellStyle5;
            this.UnitPrice.HeaderText = "Unit Cost";
            this.UnitPrice.Name = "UnitPrice";
            this.UnitPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitPrice.Width = 75;
            // 
            // Discount
            // 
            this.Discount.DataPropertyName = "Discount";
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.LightGreen;
            this.Discount.DefaultCellStyle = dataGridViewCellStyle6;
            this.Discount.HeaderText = "Discount";
            this.Discount.Name = "Discount";
            this.Discount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Discount.Width = 72;
            // 
            // Amount
            // 
            this.Amount.DataPropertyName = "Amount";
            this.Amount.HeaderText = "Amount";
            this.Amount.Name = "Amount";
            this.Amount.ReadOnly = true;
            this.Amount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Amount.Width = 65;
            // 
            // SP
            // 
            this.SP.DataPropertyName = "SP";
            this.SP.HeaderText = "SP";
            this.SP.Name = "SP";
            this.SP.ReadOnly = true;
            this.SP.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SP.Width = 30;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(1086, 650);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(91, 39);
            this.btnSave.TabIndex = 11;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(1199, 650);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(85, 39);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnAddNewRow
            // 
            this.btnAddNewRow.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAddNewRow.Enabled = false;
            this.btnAddNewRow.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAddNewRow.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNewRow.Location = new System.Drawing.Point(67, 365);
            this.btnAddNewRow.Name = "btnAddNewRow";
            this.btnAddNewRow.Size = new System.Drawing.Size(106, 25);
            this.btnAddNewRow.TabIndex = 186;
            this.btnAddNewRow.Text = "Add Item";
            this.btnAddNewRow.UseVisualStyleBackColor = false;
            this.btnAddNewRow.Click += new System.EventHandler(this.btnAddNewRow_Click);
            // 
            // cmbOfferNumber
            // 
            this.cmbOfferNumber.DropDownHeight = 90;
            this.cmbOfferNumber.DropDownWidth = 150;
            this.cmbOfferNumber.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbOfferNumber.FormattingEnabled = true;
            this.cmbOfferNumber.IntegralHeight = false;
            this.cmbOfferNumber.Location = new System.Drawing.Point(480, 4);
            this.cmbOfferNumber.Name = "cmbOfferNumber";
            this.cmbOfferNumber.Size = new System.Drawing.Size(192, 26);
            this.cmbOfferNumber.TabIndex = 188;
            this.cmbOfferNumber.SelectedIndexChanged += new System.EventHandler(this.cmbOfferNumber_SelectedIndexChanged);
            // 
            // lblOfferNumber
            // 
            this.lblOfferNumber.AutoSize = true;
            this.lblOfferNumber.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOfferNumber.ForeColor = System.Drawing.Color.Black;
            this.lblOfferNumber.Location = new System.Drawing.Point(357, 7);
            this.lblOfferNumber.Name = "lblOfferNumber";
            this.lblOfferNumber.Size = new System.Drawing.Size(120, 19);
            this.lblOfferNumber.TabIndex = 189;
            this.lblOfferNumber.Text = "Offer Number* :";
            // 
            // btnViewQuote
            // 
            this.btnViewQuote.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnViewQuote.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnViewQuote.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewQuote.Location = new System.Drawing.Point(946, 650);
            this.btnViewQuote.Name = "btnViewQuote";
            this.btnViewQuote.Size = new System.Drawing.Size(118, 39);
            this.btnViewQuote.TabIndex = 191;
            this.btnViewQuote.Text = "View Quotes";
            this.btnViewQuote.UseVisualStyleBackColor = false;
            this.btnViewQuote.Click += new System.EventHandler(this.btnViewQuote_Click);
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.ForeColor = System.Drawing.Color.Black;
            this.label81.Location = new System.Drawing.Point(27, 2);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(112, 23);
            this.label81.TabIndex = 210;
            this.label81.Text = "Start Quote :";
            // 
            // cmbSelectQuoteType
            // 
            this.cmbSelectQuoteType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbSelectQuoteType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectQuoteType.DropDownHeight = 90;
            this.cmbSelectQuoteType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSelectQuoteType.DropDownWidth = 150;
            this.cmbSelectQuoteType.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSelectQuoteType.FormattingEnabled = true;
            this.cmbSelectQuoteType.IntegralHeight = false;
            this.cmbSelectQuoteType.Items.AddRange(new object[] {
            "New Quote",
            "Update Quote",
            "Revise Quote",
            "Print Quote"});
            this.cmbSelectQuoteType.Location = new System.Drawing.Point(145, 3);
            this.cmbSelectQuoteType.Name = "cmbSelectQuoteType";
            this.cmbSelectQuoteType.Size = new System.Drawing.Size(180, 26);
            this.cmbSelectQuoteType.TabIndex = 209;
            this.cmbSelectQuoteType.SelectedIndexChanged += new System.EventHandler(this.cmbSelectQuoteType_SelectedIndexChanged);
            // 
            // chkQuoteSavePath
            // 
            this.chkQuoteSavePath.AutoSize = true;
            this.chkQuoteSavePath.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkQuoteSavePath.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.chkQuoteSavePath.Location = new System.Drawing.Point(659, 650);
            this.chkQuoteSavePath.Name = "chkQuoteSavePath";
            this.chkQuoteSavePath.Size = new System.Drawing.Size(213, 27);
            this.chkQuoteSavePath.TabIndex = 215;
            this.chkQuoteSavePath.Text = "Select Quote Save Path";
            this.chkQuoteSavePath.UseVisualStyleBackColor = true;
            this.chkQuoteSavePath.CheckedChanged += new System.EventHandler(this.chkQuoteSavePath_CheckedChanged);
            // 
            // pnCustomerDetails
            // 
            this.pnCustomerDetails.Controls.Add(this.txtSearchText);
            this.pnCustomerDetails.Controls.Add(this.btnClose);
            this.pnCustomerDetails.Controls.Add(this.label23);
            this.pnCustomerDetails.Controls.Add(this.dgvQuoteView);
            this.pnCustomerDetails.Location = new System.Drawing.Point(4, 31);
            this.pnCustomerDetails.Name = "pnCustomerDetails";
            this.pnCustomerDetails.Size = new System.Drawing.Size(1290, 613);
            this.pnCustomerDetails.TabIndex = 150;
            this.pnCustomerDetails.Visible = false;
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.Color.Red;
            this.btnClose.Location = new System.Drawing.Point(1060, 9);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(64, 29);
            this.btnClose.TabIndex = 222;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // txtSearchText
            // 
            this.txtSearchText.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchText.Location = new System.Drawing.Point(82, 5);
            this.txtSearchText.Name = "txtSearchText";
            this.txtSearchText.Size = new System.Drawing.Size(339, 27);
            this.txtSearchText.TabIndex = 153;
            this.txtSearchText.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtSearchText_KeyUp);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Black;
            this.label23.Location = new System.Drawing.Point(17, 8);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(63, 19);
            this.label23.TabIndex = 152;
            this.label23.Text = "Search :";
            // 
            // dgvQuoteView
            // 
            this.dgvQuoteView.AllowUserToAddRows = false;
            this.dgvQuoteView.AllowUserToDeleteRows = false;
            this.dgvQuoteView.AllowUserToOrderColumns = true;
            this.dgvQuoteView.AllowUserToResizeRows = false;
            this.dgvQuoteView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvQuoteView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dgvQuoteView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvQuoteView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Customer,
            this.ContactPerson,
            this.PhoneNumber,
            this.EmailId,
            this.Department,
            this.Designation,
            this.CustomerAddress,
            this.StandardCustom,
            this.Region,
            this.EightyTwenty,
            this.NewOldCustomer});
            this.dgvQuoteView.EnableHeadersVisualStyles = false;
            this.dgvQuoteView.Location = new System.Drawing.Point(8, 41);
            this.dgvQuoteView.Name = "dgvQuoteView";
            this.dgvQuoteView.ReadOnly = true;
            this.dgvQuoteView.RowHeadersVisible = false;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvQuoteView.RowsDefaultCellStyle = dataGridViewCellStyle9;
            this.dgvQuoteView.Size = new System.Drawing.Size(1272, 556);
            this.dgvQuoteView.TabIndex = 151;
            this.dgvQuoteView.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvQuoteView_CellDoubleClick);
            // 
            // Customer
            // 
            this.Customer.DataPropertyName = "Customer";
            this.Customer.HeaderText = "Customer Name";
            this.Customer.Name = "Customer";
            this.Customer.ReadOnly = true;
            this.Customer.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Customer.Width = 112;
            // 
            // ContactPerson
            // 
            this.ContactPerson.DataPropertyName = "ContactPerson";
            this.ContactPerson.HeaderText = "Contact Person";
            this.ContactPerson.Name = "ContactPerson";
            this.ContactPerson.ReadOnly = true;
            this.ContactPerson.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ContactPerson.Width = 107;
            // 
            // PhoneNumber
            // 
            this.PhoneNumber.DataPropertyName = "PhoneNumber";
            this.PhoneNumber.HeaderText = "Phone Number";
            this.PhoneNumber.Name = "PhoneNumber";
            this.PhoneNumber.ReadOnly = true;
            this.PhoneNumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PhoneNumber.Width = 107;
            // 
            // EmailId
            // 
            this.EmailId.DataPropertyName = "EmailId";
            this.EmailId.HeaderText = "EmailId";
            this.EmailId.Name = "EmailId";
            this.EmailId.ReadOnly = true;
            this.EmailId.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.EmailId.Width = 65;
            // 
            // Department
            // 
            this.Department.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Department.DataPropertyName = "Department";
            this.Department.HeaderText = "Department";
            this.Department.Name = "Department";
            this.Department.ReadOnly = true;
            this.Department.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Department.Width = 92;
            // 
            // Designation
            // 
            this.Designation.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Designation.DataPropertyName = "Designation";
            this.Designation.HeaderText = "Designation";
            this.Designation.Name = "Designation";
            this.Designation.ReadOnly = true;
            this.Designation.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Designation.Width = 80;
            // 
            // CustomerAddress
            // 
            this.CustomerAddress.DataPropertyName = "CustomerAddress";
            this.CustomerAddress.HeaderText = "Customer Address";
            this.CustomerAddress.Name = "CustomerAddress";
            this.CustomerAddress.ReadOnly = true;
            this.CustomerAddress.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CustomerAddress.Width = 124;
            // 
            // StandardCustom
            // 
            this.StandardCustom.DataPropertyName = "StandardCustom";
            this.StandardCustom.HeaderText = "StandardCustom";
            this.StandardCustom.Name = "StandardCustom";
            this.StandardCustom.ReadOnly = true;
            this.StandardCustom.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.StandardCustom.Width = 129;
            // 
            // Region
            // 
            this.Region.DataPropertyName = "Region";
            this.Region.HeaderText = "Region";
            this.Region.Name = "Region";
            this.Region.ReadOnly = true;
            this.Region.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Region.Width = 62;
            // 
            // EightyTwenty
            // 
            this.EightyTwenty.DataPropertyName = "8020Customer";
            this.EightyTwenty.HeaderText = "80/20";
            this.EightyTwenty.Name = "EightyTwenty";
            this.EightyTwenty.ReadOnly = true;
            this.EightyTwenty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.EightyTwenty.Width = 54;
            // 
            // NewOldCustomer
            // 
            this.NewOldCustomer.DataPropertyName = "NewOldCustomer";
            this.NewOldCustomer.HeaderText = "NewOldCustomer";
            this.NewOldCustomer.Name = "NewOldCustomer";
            this.NewOldCustomer.ReadOnly = true;
            this.NewOldCustomer.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.NewOldCustomer.Width = 135;
            // 
            // TestingQuote
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1297, 690);
            this.Controls.Add(this.pnCustomerDetails);
            this.Controls.Add(this.btnAddNewRow);
            this.Controls.Add(this.chkQuoteSavePath);
            this.Controls.Add(this.label81);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.cmbSelectQuoteType);
            this.Controls.Add(this.btnViewQuote);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblOfferNumber);
            this.Controls.Add(this.cmbOfferNumber);
            this.Controls.Add(this.pnSaveQuote);
            this.Controls.Add(this.dtpporevisiondate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dgvQuoteItems);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "TestingQuote";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Test Lab Quote";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TestingQuote_FormClosing);
            this.Load += new System.EventHandler(this.TestingQuote_Load);
            this.pnSaveQuote.ResumeLayout(false);
            this.pnSaveQuote.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuoteItems)).EndInit();
            this.pnCustomerDetails.ResumeLayout(false);
            this.pnCustomerDetails.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuoteView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblsuupliercode;
        private System.Windows.Forms.ComboBox cmbCustomer;
        private System.Windows.Forms.ComboBox cmbcustomertype;
        private System.Windows.Forms.Label lblsaletype;
        private System.Windows.Forms.ComboBox cmbEnquireMonth;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbSubmittedMonth;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtpporevisiondate;
        private System.Windows.Forms.Label lblcontactperson;
        private System.Windows.Forms.TextBox txtcontactperson;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtphonenumber;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtOffername;
        private System.Windows.Forms.ComboBox cmbTypeofIndustry;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel pnSaveQuote;
        private System.Windows.Forms.DataGridView dgvQuoteItems;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtComment;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtPONumber;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtCostValue;
        private System.Windows.Forms.ComboBox cmbBooked;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmbBookingEstimation;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbStatus;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnAddNewRow;
        private System.Windows.Forms.ComboBox cmbOfferNumber;
        private System.Windows.Forms.Label lblOfferNumber;
        private System.Windows.Forms.TextBox txtGstValue;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnViewQuote;
        private System.Windows.Forms.TextBox txtEmailID;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox cmbMaterialType;
        private System.Windows.Forms.ComboBox cmbApplicationtesttype;
        private System.Windows.Forms.ComboBox cmbEightyMonth;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtDepartment;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.ComboBox cmbSelectQuoteType;
        private System.Windows.Forms.ComboBox cmbstandardcustom;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox cmbregion;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.CheckBox chkQuoteSavePath;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.TextBox txtCustomerAddress;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtDesignation;
        private System.Windows.Forms.Button btnCusSearch;
        private System.Windows.Forms.Panel pnCustomerDetails;
        private System.Windows.Forms.TextBox txtSearchText;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.DataGridView dgvQuoteView;
        private System.Windows.Forms.DataGridViewTextBoxColumn Customer;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContactPerson;
        private System.Windows.Forms.DataGridViewTextBoxColumn PhoneNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmailId;
        private System.Windows.Forms.DataGridViewTextBoxColumn Department;
        private System.Windows.Forms.DataGridViewTextBoxColumn Designation;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerAddress;
        private System.Windows.Forms.DataGridViewTextBoxColumn StandardCustom;
        private System.Windows.Forms.DataGridViewTextBoxColumn Region;
        private System.Windows.Forms.DataGridViewTextBoxColumn EightyTwenty;
        private System.Windows.Forms.DataGridViewTextBoxColumn NewOldCustomer;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.DataGridViewTextBoxColumn DSCSLNO;
        private System.Windows.Forms.DataGridViewTextBoxColumn Specifications;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn Discount;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn SP;
    }
}