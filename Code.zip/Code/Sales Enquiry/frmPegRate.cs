﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    public partial class frmPegRate : Form
    {
        Global GLobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        frmForm2 frm = new frmForm2();
        public frmPegRate()
        {
            InitializeComponent();
        }

        private void txtPegRate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void fnExit()
        {
            this.Hide();
            frm.Show();
        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm.Show();
        }

        private void frmPegRate_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnExit();
        }
        DataTable dtPegRate = new DataTable();
        private void btnSavePegRate_Click(object sender, EventArgs e)
        {
            dtPegRate = DAL.DTPegRate("").Tables[0];
            
                if (chkPegRate.CheckState == CheckState.Checked)
                {
                    if (dtPegRate.Rows.Count > 0)
                    {
                        GLobalClass.iSuccess = DAL.fnAddPegRate(Global.uUPDATE, Convert.ToDouble(txtPegRate.Text), dtpCreatedDate.Text, Convert.ToDouble(dtPegRate.Rows[0][1].ToString()));
                    MessageBox.Show("PegRate updated successfully.", "Success", 0, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    if (dtPegRate.Rows.Count == 0)
                    {
                        GLobalClass.iSuccess = DAL.fnAddPegRate(Global.uINSERT, Convert.ToDouble(txtPegRate.Text), dtpCreatedDate.Text, 0);
                        MessageBox.Show("PegRate added successfully.", "Success", 0, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("PegRate added already.", "Information", 0, MessageBoxIcon.Error);
                    }
                }
           
        }

        private void chkPegRate_CheckedChanged(object sender, EventArgs e)
        {
            if (chkPegRate.CheckState == CheckState.Checked)
            {
                label1.Visible = true;
                txtOldPegRate.Visible = true;
                dtPegRate = DAL.DTPegRate("").Tables[0];
                if (dtPegRate.Rows.Count > 0)
                {
                    txtPegRate.Text = dtPegRate.Rows[0][1].ToString();
                    txtOldPegRate.Text = dtPegRate.Rows[0][3].ToString();
                }
                else
                {
                    txtPegRate.ResetText();
                }
            }
            else
            {
               
                txtPegRate.ResetText();
                txtOldPegRate.ResetText();
                label1.Visible = false;
                txtOldPegRate.Visible = false;
            }
        }

        private void frmPegRate_Load(object sender, EventArgs e)
        {

        }
    }
}
