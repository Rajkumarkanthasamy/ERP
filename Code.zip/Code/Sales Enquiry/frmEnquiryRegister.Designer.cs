﻿namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    partial class frmEnquiryRegisterView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEnquiryRegisterView));
            this.txtSearchText = new System.Windows.Forms.TextBox();
            this.lblFromdate = new System.Windows.Forms.Label();
            this.btnReport = new System.Windows.Forms.Button();
            this.btnExcelReport = new System.Windows.Forms.Button();
            this.lblToDate = new System.Windows.Forms.Label();
            this.dtpFromDate = new System.Windows.Forms.DateTimePicker();
            this.dtpToDate = new System.Windows.Forms.DateTimePicker();
            this.cmbreporttype = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvEnquiry = new System.Windows.Forms.DataGridView();
            this.EnquiryNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PreparedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EnquiryDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Leadinputfrom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerBase = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ContactPerson = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmailID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StandardCustom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CountryName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RegioninIndia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Dealer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Orderreceivedmonth = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Orderreceivedyear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Expectedmonth = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEnquiry)).BeginInit();
            this.SuspendLayout();
            // 
            // txtSearchText
            // 
            this.txtSearchText.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchText.Location = new System.Drawing.Point(1064, 17);
            this.txtSearchText.Name = "txtSearchText";
            this.txtSearchText.Size = new System.Drawing.Size(96, 27);
            this.txtSearchText.TabIndex = 137;
            this.txtSearchText.Visible = false;
            // 
            // lblFromdate
            // 
            this.lblFromdate.AutoSize = true;
            this.lblFromdate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblFromdate.Location = new System.Drawing.Point(12, 18);
            this.lblFromdate.Name = "lblFromdate";
            this.lblFromdate.Size = new System.Drawing.Size(52, 19);
            this.lblFromdate.TabIndex = 4;
            this.lblFromdate.Text = "From :";
            // 
            // btnReport
            // 
            this.btnReport.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReport.Location = new System.Drawing.Point(426, 14);
            this.btnReport.Name = "btnReport";
            this.btnReport.Size = new System.Drawing.Size(93, 30);
            this.btnReport.TabIndex = 132;
            this.btnReport.Text = "Search";
            this.btnReport.UseVisualStyleBackColor = true;
            this.btnReport.Click += new System.EventHandler(this.btnReport_Click);
            // 
            // btnExcelReport
            // 
            this.btnExcelReport.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcelReport.Location = new System.Drawing.Point(563, 15);
            this.btnExcelReport.Name = "btnExcelReport";
            this.btnExcelReport.Size = new System.Drawing.Size(136, 30);
            this.btnExcelReport.TabIndex = 133;
            this.btnExcelReport.Text = "Export to Excel";
            this.btnExcelReport.UseVisualStyleBackColor = true;
            this.btnExcelReport.Click += new System.EventHandler(this.btnExcelReport_Click);
            // 
            // lblToDate
            // 
            this.lblToDate.AutoSize = true;
            this.lblToDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblToDate.Location = new System.Drawing.Point(228, 18);
            this.lblToDate.Name = "lblToDate";
            this.lblToDate.Size = new System.Drawing.Size(33, 19);
            this.lblToDate.TabIndex = 6;
            this.lblToDate.Text = "To :";
            // 
            // dtpFromDate
            // 
            this.dtpFromDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.dtpFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFromDate.Location = new System.Drawing.Point(66, 17);
            this.dtpFromDate.Name = "dtpFromDate";
            this.dtpFromDate.Size = new System.Drawing.Size(139, 27);
            this.dtpFromDate.TabIndex = 9;
            // 
            // dtpToDate
            // 
            this.dtpToDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.dtpToDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpToDate.Location = new System.Drawing.Point(267, 16);
            this.dtpToDate.Name = "dtpToDate";
            this.dtpToDate.Size = new System.Drawing.Size(133, 27);
            this.dtpToDate.TabIndex = 10;
            // 
            // cmbreporttype
            // 
            this.cmbreporttype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbreporttype.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbreporttype.FormattingEnabled = true;
            this.cmbreporttype.Items.AddRange(new object[] {
            "Customer Name",
            "Customer Type",
            "Contact Person",
            "Product Type",
            "Lever",
            "80/20",
            "Product Manager",
            "Old New Customer",
            "Lead Input"});
            this.cmbreporttype.Location = new System.Drawing.Point(972, 17);
            this.cmbreporttype.Name = "cmbreporttype";
            this.cmbreporttype.Size = new System.Drawing.Size(86, 27);
            this.cmbreporttype.TabIndex = 134;
            this.cmbreporttype.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(882, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 19);
            this.label1.TabIndex = 135;
            this.label1.Text = "Search by :";
            this.label1.Visible = false;
            // 
            // dgvEnquiry
            // 
            this.dgvEnquiry.AllowUserToAddRows = false;
            this.dgvEnquiry.AllowUserToDeleteRows = false;
            this.dgvEnquiry.AllowUserToOrderColumns = true;
            this.dgvEnquiry.AllowUserToResizeRows = false;
            this.dgvEnquiry.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvEnquiry.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvEnquiry.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEnquiry.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EnquiryNumber,
            this.PreparedBy,
            this.EnquiryDate,
            this.Leadinputfrom,
            this.CustomerName,
            this.CustomerType,
            this.CustomerBase,
            this.ContactPerson,
            this.EmailID,
            this.ProductType,
            this.StandardCustom,
            this.CountryName,
            this.RegioninIndia,
            this.Dealer,
            this.Orderreceivedmonth,
            this.Orderreceivedyear,
            this.Expectedmonth});
            this.dgvEnquiry.EnableHeadersVisualStyles = false;
            this.dgvEnquiry.Location = new System.Drawing.Point(12, 61);
            this.dgvEnquiry.Name = "dgvEnquiry";
            this.dgvEnquiry.ReadOnly = true;
            this.dgvEnquiry.RowHeadersVisible = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvEnquiry.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvEnquiry.Size = new System.Drawing.Size(1311, 595);
            this.dgvEnquiry.TabIndex = 133;
            this.dgvEnquiry.DoubleClick += new System.EventHandler(this.dgvEnquiry_DoubleClick);
            // 
            // EnquiryNumber
            // 
            this.EnquiryNumber.DataPropertyName = "EnquiryNumber";
            this.EnquiryNumber.HeaderText = "EnquiryNumber";
            this.EnquiryNumber.Name = "EnquiryNumber";
            this.EnquiryNumber.ReadOnly = true;
            this.EnquiryNumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.EnquiryNumber.Width = 124;
            // 
            // PreparedBy
            // 
            this.PreparedBy.DataPropertyName = "PreparedBy";
            this.PreparedBy.HeaderText = "Prepared By";
            this.PreparedBy.Name = "PreparedBy";
            this.PreparedBy.ReadOnly = true;
            this.PreparedBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PreparedBy.Width = 89;
            // 
            // EnquiryDate
            // 
            this.EnquiryDate.DataPropertyName = "Enquirydate";
            this.EnquiryDate.HeaderText = "Enquiry Date";
            this.EnquiryDate.Name = "EnquiryDate";
            this.EnquiryDate.ReadOnly = true;
            this.EnquiryDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.EnquiryDate.Width = 94;
            // 
            // Leadinputfrom
            // 
            this.Leadinputfrom.DataPropertyName = "Leadinputfrom";
            this.Leadinputfrom.HeaderText = "Lead Input From";
            this.Leadinputfrom.Name = "Leadinputfrom";
            this.Leadinputfrom.ReadOnly = true;
            this.Leadinputfrom.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Leadinputfrom.Width = 114;
            // 
            // CustomerName
            // 
            this.CustomerName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.CustomerName.DataPropertyName = "CustomerName";
            this.CustomerName.HeaderText = "Customer";
            this.CustomerName.Name = "CustomerName";
            this.CustomerName.ReadOnly = true;
            this.CustomerName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CustomerName.Width = 80;
            // 
            // CustomerType
            // 
            this.CustomerType.DataPropertyName = "CustomerType";
            this.CustomerType.HeaderText = "Customer Type";
            this.CustomerType.Name = "CustomerType";
            this.CustomerType.ReadOnly = true;
            this.CustomerType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CustomerType.Width = 105;
            // 
            // CustomerBase
            // 
            this.CustomerBase.DataPropertyName = "CustomerBase";
            this.CustomerBase.HeaderText = "Customer Base";
            this.CustomerBase.Name = "CustomerBase";
            this.CustomerBase.ReadOnly = true;
            this.CustomerBase.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CustomerBase.Width = 104;
            // 
            // ContactPerson
            // 
            this.ContactPerson.DataPropertyName = "ContactPerson";
            this.ContactPerson.HeaderText = "Contact Person";
            this.ContactPerson.Name = "ContactPerson";
            this.ContactPerson.ReadOnly = true;
            this.ContactPerson.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ContactPerson.Width = 107;
            // 
            // EmailID
            // 
            this.EmailID.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.EmailID.DataPropertyName = "EmailID";
            this.EmailID.HeaderText = "Email ID";
            this.EmailID.Name = "EmailID";
            this.EmailID.ReadOnly = true;
            this.EmailID.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.EmailID.Width = 63;
            // 
            // ProductType
            // 
            this.ProductType.DataPropertyName = "ProductType";
            this.ProductType.HeaderText = "Product Type";
            this.ProductType.Name = "ProductType";
            this.ProductType.ReadOnly = true;
            this.ProductType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductType.Width = 96;
            // 
            // StandardCustom
            // 
            this.StandardCustom.DataPropertyName = "StandardCustom";
            this.StandardCustom.HeaderText = "Standard Custom";
            this.StandardCustom.Name = "StandardCustom";
            this.StandardCustom.ReadOnly = true;
            this.StandardCustom.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.StandardCustom.Width = 120;
            // 
            // CountryName
            // 
            this.CountryName.DataPropertyName = "CountryName";
            this.CountryName.HeaderText = "Country";
            this.CountryName.Name = "CountryName";
            this.CountryName.ReadOnly = true;
            this.CountryName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CountryName.Width = 70;
            // 
            // RegioninIndia
            // 
            this.RegioninIndia.DataPropertyName = "RegioninIndia";
            this.RegioninIndia.HeaderText = "RegioninIndia";
            this.RegioninIndia.Name = "RegioninIndia";
            this.RegioninIndia.ReadOnly = true;
            this.RegioninIndia.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RegioninIndia.Width = 109;
            // 
            // Dealer
            // 
            this.Dealer.DataPropertyName = "Dealer";
            this.Dealer.HeaderText = "Dealer";
            this.Dealer.Name = "Dealer";
            this.Dealer.ReadOnly = true;
            this.Dealer.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Dealer.Width = 59;
            // 
            // Orderreceivedmonth
            // 
            this.Orderreceivedmonth.DataPropertyName = "Orderreceivedmonth";
            this.Orderreceivedmonth.HeaderText = "Order Received Month";
            this.Orderreceivedmonth.Name = "Orderreceivedmonth";
            this.Orderreceivedmonth.ReadOnly = true;
            this.Orderreceivedmonth.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Orderreceivedmonth.Width = 154;
            // 
            // Orderreceivedyear
            // 
            this.Orderreceivedyear.DataPropertyName = "Orderreceivedyear";
            this.Orderreceivedyear.HeaderText = "Order Received Year";
            this.Orderreceivedyear.Name = "Orderreceivedyear";
            this.Orderreceivedyear.ReadOnly = true;
            this.Orderreceivedyear.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Orderreceivedyear.Width = 112;
            // 
            // Expectedmonth
            // 
            this.Expectedmonth.DataPropertyName = "Expectedmonth";
            this.Expectedmonth.HeaderText = "Expected Month";
            this.Expectedmonth.Name = "Expectedmonth";
            this.Expectedmonth.ReadOnly = true;
            this.Expectedmonth.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Expectedmonth.Width = 115;
            // 
            // frmEnquiryRegisterView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1328, 668);
            this.Controls.Add(this.lblFromdate);
            this.Controls.Add(this.lblToDate);
            this.Controls.Add(this.txtSearchText);
            this.Controls.Add(this.dtpFromDate);
            this.Controls.Add(this.btnReport);
            this.Controls.Add(this.dtpToDate);
            this.Controls.Add(this.btnExcelReport);
            this.Controls.Add(this.cmbreporttype);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvEnquiry);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmEnquiryRegisterView";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Enquiry Register View";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmEnquiryRegisterView_FormClosing);
            this.Load += new System.EventHandler(this.frmEnquiryRegisterView_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEnquiry)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSearchText;
        private System.Windows.Forms.Label lblFromdate;
        private System.Windows.Forms.Button btnReport;
        private System.Windows.Forms.Button btnExcelReport;
        private System.Windows.Forms.Label lblToDate;
        private System.Windows.Forms.DateTimePicker dtpFromDate;
        private System.Windows.Forms.DateTimePicker dtpToDate;
        private System.Windows.Forms.ComboBox cmbreporttype;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvEnquiry;
        private System.Windows.Forms.DataGridViewTextBoxColumn EnquiryNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn PreparedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn EnquiryDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Leadinputfrom;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerName;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerType;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerBase;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContactPerson;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmailID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductType;
        private System.Windows.Forms.DataGridViewTextBoxColumn StandardCustom;
        private System.Windows.Forms.DataGridViewTextBoxColumn CountryName;
        private System.Windows.Forms.DataGridViewTextBoxColumn RegioninIndia;
        private System.Windows.Forms.DataGridViewTextBoxColumn Dealer;
        private System.Windows.Forms.DataGridViewTextBoxColumn Orderreceivedmonth;
        private System.Windows.Forms.DataGridViewTextBoxColumn Orderreceivedyear;
        private System.Windows.Forms.DataGridViewTextBoxColumn Expectedmonth;
    }
}