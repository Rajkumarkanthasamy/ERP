﻿using System;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    public partial class frmSalesHome : Form
    {
        Login.frmLoginForm login = new Login.frmLoginForm();

        Global GLobalClass = new Global();

       // string sQuoteMessage = "Quotegen v5.01 Date 02-12-2021";

        public const string sQuoteVersion = @"\\192.168.1.82\Documents\IT Software\ERP\ERP Quotes";

        public frmSalesHome()
        {
            InitializeComponent();
        }

        private void btnSalesQuote_Click(object sender, EventArgs e)
        {
            Sales_Enquiry.frmSalesQuote SalesQuote = new Sales_Enquiry.frmSalesQuote();
            fnFormShow(SalesQuote);
        }

        #region Function to Show Please wait form & Switch to Selected From
        private void fnFormShow(Form Frm)
        {
            this.Hide();
            pleasewaitform pleaseWait = new pleasewaitform();
            pleaseWait.Show();
            Application.DoEvents();
            Frm.Show();
            pleaseWait.Hide();
        }
        #endregion

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void btnCustomerVisit_Click(object sender, EventArgs e)
        {
            Sales_Enquiry.frmCustomerVisit CustomerVisit = new frmCustomerVisit();
            fnFormShow(CustomerVisit);
        }


        private void frmSalesHome_Load(object sender, EventArgs e)
        {
            //if (sQuoteMessage != Login.frmLoginForm.sUserDetails[58])
            //{
            //    if (MessageBox.Show("Please update the ERP latest version.\n\nClick on Yes to open the link", "Login restricted", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            //    {
            //        System.Diagnostics.Process.Start(sQuoteVersion);
            //        lblWarning.Visible = true;
            //    }
            //}
            //else
            //{
            //    lblWarning.Visible = false;

                if (Login.frmLoginForm.sUserDetails[41] != "True")
                {
                    btnSalesQuote.Enabled = false;
                }
                else
                {
                    btnSalesQuote.Enabled = true;
                }

                if (Login.frmLoginForm.sUserDetails[42] != "True")
                {
                    btnSalesProduct.Enabled = false;
                }
                else
                {
                    btnSalesProduct.Enabled = true;
                }

                if (Login.frmLoginForm.sUserDetails[43] != "True")
                {
                    btnCustomerVisit.Enabled = false;
                }
                else
                {
                    btnCustomerVisit.Enabled = true;
                }

                if (Login.frmLoginForm.sUserDetails[44] != "True")
                {
                    btnOpportunity.Enabled = false;
                }
                else
                {
                    btnOpportunity.Enabled = true;
                }
                if (Login.frmLoginForm.sUserDetails[45] != "True")
                {
                    btnPegRate.Enabled = false;
                }
                else
                {
                    btnPegRate.Enabled = true;
                    btnPegRate.Visible = true;
                }
                if (Login.frmLoginForm.sUserDetails[46] != "True")
                {
                    btnEnquiryRegister.Enabled = false;
                }
                else
                {
                    btnEnquiryRegister.Enabled = true;
                }

                if (Login.frmLoginForm.sUserDetails[47] != "True")
                {
                    btnTestingQuote.Enabled = false;
                }
                else
                {
                    btnTestingQuote.Enabled = true;
                }

            if (Login.frmLoginForm.sUserDetails[81] != "True")
            {
                btnServiceQuote.Enabled = false;
            }
            else
            {
                btnServiceQuote.Enabled = true;
            }
            //}

        }

        private void frmSalesHome_FormClosing(object sender, FormClosingEventArgs e)
        {
            frmForm2 frmHome = new frmForm2();
            this.Hide();
            frmHome.Show();
        }

        private void btnPegRate_Click(object sender, EventArgs e)
        {
            frmPegRate PegRate = new frmPegRate();
            this.Hide();
            PegRate.Show();
        }

        private void btnEnquiryRegister_Click(object sender, EventArgs e)
        {
            frmEnquiryRegisterEntry Enq = new frmEnquiryRegisterEntry();
            this.Hide();
            Enq.Show();
        }

        private void btnTestingQuote_Click(object sender, EventArgs e)
        {
            Sales_Enquiry.TestingQuote TestQuote = new TestingQuote();
            fnFormShow(TestQuote);
        }

        private void btnSalesProduct_Click(object sender, EventArgs e)
        {
            Sales_Enquiry.frmSalesProduct SalesProduct = new frmSalesProduct();
            fnFormShow(SalesProduct);
        }

        private void btnOpportunity_Click(object sender, EventArgs e)
        {
            Sales_Enquiry.frmOpportuniyDetails Opportunity = new frmOpportuniyDetails();
            fnFormShow(Opportunity);
        }

        private void lblWarning_Click(object sender, EventArgs e)
        {
         //   System.Diagnostics.Process.Start(sQuoteVersion);
        }

        private void btnServiceQuote_Click(object sender, EventArgs e)
        {
            Sales_Enquiry.frmServicequote servicequote = new frmServicequote();
            fnFormShow(servicequote);
        }
    }
}
