﻿
namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    partial class Spare_parts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Spare_parts));
            this.lblCALQuoteby = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comQuotationNo = new System.Windows.Forms.ComboBox();
            this.labSpareParts = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnGenaratePO = new System.Windows.Forms.Button();
            this.btnPrintSparePartsdownload = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttAdd = new System.Windows.Forms.Button();
            this.dgItemOrProductList = new System.Windows.Forms.DataGridView();
            this.SLNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PartNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PartDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Qty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Colunitprice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Coltotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtCALCustomer = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textDeliveryTerm = new System.Windows.Forms.TextBox();
            this.textquotationNo = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.labquoteby = new System.Windows.Forms.Label();
            this.txtCALAddress = new System.Windows.Forms.TextBox();
            this.txtCALTel = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.txtCalQuotename = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.cmbCALQuoteFor = new System.Windows.Forms.ComboBox();
            this.CmbCurrency = new System.Windows.Forms.ComboBox();
            this.txtCALModelNo = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.txtCALEmailID = new System.Windows.Forms.TextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dtpCALDateofQuote = new System.Windows.Forms.DateTimePicker();
            this.label56 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.txtCALContactPerson = new System.Windows.Forms.TextBox();
            this.chkQuoteSavePath = new System.Windows.Forms.CheckBox();
            this.groupBox4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgItemOrProductList)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblCALQuoteby
            // 
            this.lblCALQuoteby.AutoSize = true;
            this.lblCALQuoteby.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCALQuoteby.ForeColor = System.Drawing.Color.Red;
            this.lblCALQuoteby.Location = new System.Drawing.Point(1012, 126);
            this.lblCALQuoteby.Name = "lblCALQuoteby";
            this.lblCALQuoteby.Size = new System.Drawing.Size(0, 19);
            this.lblCALQuoteby.TabIndex = 254;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.groupBox4.BackgroundImage = global::Erp_Project_With_Buttons.Properties.Resources.spare_parts3;
            this.groupBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox4.Controls.Add(this.chkQuoteSavePath);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.comQuotationNo);
            this.groupBox4.Controls.Add(this.labSpareParts);
            this.groupBox4.Controls.Add(this.groupBox2);
            this.groupBox4.Controls.Add(this.groupBox1);
            this.groupBox4.Controls.Add(this.groupBox3);
            this.groupBox4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox4.Location = new System.Drawing.Point(12, 2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1318, 691);
            this.groupBox4.TabIndex = 557;
            this.groupBox4.TabStop = false;
            this.groupBox4.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(748, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 18);
            this.label2.TabIndex = 555;
            this.label2.Text = "Slect  Quotation No:";
            // 
            // comQuotationNo
            // 
            this.comQuotationNo.DropDownHeight = 60;
            this.comQuotationNo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comQuotationNo.DropDownWidth = 150;
            this.comQuotationNo.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comQuotationNo.FormattingEnabled = true;
            this.comQuotationNo.IntegralHeight = false;
            this.comQuotationNo.ItemHeight = 18;
            this.comQuotationNo.Location = new System.Drawing.Point(886, 8);
            this.comQuotationNo.Name = "comQuotationNo";
            this.comQuotationNo.Size = new System.Drawing.Size(173, 26);
            this.comQuotationNo.TabIndex = 555;
            this.comQuotationNo.SelectedIndexChanged += new System.EventHandler(this.comQuotationNo_SelectedIndexChanged);
            // 
            // labSpareParts
            // 
            this.labSpareParts.AutoSize = true;
            this.labSpareParts.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.labSpareParts.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labSpareParts.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.labSpareParts.Location = new System.Drawing.Point(603, 8);
            this.labSpareParts.Name = "labSpareParts";
            this.labSpareParts.Size = new System.Drawing.Size(104, 20);
            this.labSpareParts.TabIndex = 0;
            this.labSpareParts.Text = "Spare Parts";
            this.labSpareParts.Click += new System.EventHandler(this.labSpareParts_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.groupBox2.Controls.Add(this.btnGenaratePO);
            this.groupBox2.Controls.Add(this.btnPrintSparePartsdownload);
            this.groupBox2.Controls.Add(this.btnSave);
            this.groupBox2.Controls.Add(this.btnExit);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox2.Location = new System.Drawing.Point(327, 596);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(641, 54);
            this.groupBox2.TabIndex = 260;
            this.groupBox2.TabStop = false;
            // 
            // btnGenaratePO
            // 
            this.btnGenaratePO.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnGenaratePO.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnGenaratePO.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenaratePO.Location = new System.Drawing.Point(172, 7);
            this.btnGenaratePO.Name = "btnGenaratePO";
            this.btnGenaratePO.Size = new System.Drawing.Size(113, 30);
            this.btnGenaratePO.TabIndex = 96;
            this.btnGenaratePO.Text = "REVISED";
            this.btnGenaratePO.UseVisualStyleBackColor = false;
            this.btnGenaratePO.Click += new System.EventHandler(this.btnGenaratePO_Click);
            // 
            // btnPrintSparePartsdownload
            // 
            this.btnPrintSparePartsdownload.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnPrintSparePartsdownload.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnPrintSparePartsdownload.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrintSparePartsdownload.Location = new System.Drawing.Point(308, 10);
            this.btnPrintSparePartsdownload.Name = "btnPrintSparePartsdownload";
            this.btnPrintSparePartsdownload.Size = new System.Drawing.Size(158, 30);
            this.btnPrintSparePartsdownload.TabIndex = 12;
            this.btnPrintSparePartsdownload.Text = "Print Spare Parts";
            this.btnPrintSparePartsdownload.UseVisualStyleBackColor = false;
            this.btnPrintSparePartsdownload.Click += new System.EventHandler(this.btnPrintSparePartsdownload_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(46, 7);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(90, 30);
            this.btnSave.TabIndex = 11;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(498, 10);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(90, 30);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.groupBox1.Controls.Add(this.buttAdd);
            this.groupBox1.Controls.Add(this.dgItemOrProductList);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox1.Location = new System.Drawing.Point(260, 349);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(879, 241);
            this.groupBox1.TabIndex = 556;
            this.groupBox1.TabStop = false;
            // 
            // buttAdd
            // 
            this.buttAdd.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.buttAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttAdd.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttAdd.Location = new System.Drawing.Point(772, 11);
            this.buttAdd.Name = "buttAdd";
            this.buttAdd.Size = new System.Drawing.Size(75, 43);
            this.buttAdd.TabIndex = 63;
            this.buttAdd.Text = "Add rows";
            this.buttAdd.UseVisualStyleBackColor = false;
            this.buttAdd.Click += new System.EventHandler(this.button1_Click);
            // 
            // dgItemOrProductList
            // 
            this.dgItemOrProductList.AllowUserToAddRows = false;
            this.dgItemOrProductList.AllowUserToResizeRows = false;
            this.dgItemOrProductList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgItemOrProductList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgItemOrProductList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgItemOrProductList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgItemOrProductList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgItemOrProductList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SLNO,
            this.PartNumber,
            this.PartDescription,
            this.Qty,
            this.Colunitprice,
            this.Coltotal});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgItemOrProductList.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgItemOrProductList.EnableHeadersVisualStyles = false;
            this.dgItemOrProductList.Location = new System.Drawing.Point(23, 11);
            this.dgItemOrProductList.MultiSelect = false;
            this.dgItemOrProductList.Name = "dgItemOrProductList";
            this.dgItemOrProductList.RowHeadersVisible = false;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgItemOrProductList.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dgItemOrProductList.Size = new System.Drawing.Size(824, 195);
            this.dgItemOrProductList.TabIndex = 62;
            this.dgItemOrProductList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgItemOrProductList_CellContentClick);
            // 
            // SLNO
            // 
            this.SLNO.DataPropertyName = "Sl. No";
            this.SLNO.HeaderText = "SlNo";
            this.SLNO.Name = "SLNO";
            this.SLNO.ReadOnly = true;
            this.SLNO.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.SLNO.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SLNO.Width = 47;
            // 
            // PartNumber
            // 
            this.PartNumber.HeaderText = "Part Number";
            this.PartNumber.Name = "PartNumber";
            this.PartNumber.Width = 113;
            // 
            // PartDescription
            // 
            this.PartDescription.FillWeight = 300F;
            this.PartDescription.HeaderText = "Part Description";
            this.PartDescription.Name = "PartDescription";
            this.PartDescription.Width = 132;
            // 
            // Qty
            // 
            this.Qty.HeaderText = "Qty";
            this.Qty.Name = "Qty";
            this.Qty.Width = 59;
            // 
            // Colunitprice
            // 
            this.Colunitprice.HeaderText = "Unit Price in US$";
            this.Colunitprice.Name = "Colunitprice";
            this.Colunitprice.Width = 112;
            // 
            // Coltotal
            // 
            this.Coltotal.HeaderText = "Total Quantity Price in US$";
            this.Coltotal.Name = "Coltotal";
            this.Coltotal.ReadOnly = true;
            this.Coltotal.Width = 159;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.groupBox3.Controls.Add(this.txtCALCustomer);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.textDeliveryTerm);
            this.groupBox3.Controls.Add(this.textquotationNo);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.labquoteby);
            this.groupBox3.Controls.Add(this.txtCALAddress);
            this.groupBox3.Controls.Add(this.txtCALTel);
            this.groupBox3.Controls.Add(this.label42);
            this.groupBox3.Controls.Add(this.txtCalQuotename);
            this.groupBox3.Controls.Add(this.label48);
            this.groupBox3.Controls.Add(this.cmbCALQuoteFor);
            this.groupBox3.Controls.Add(this.CmbCurrency);
            this.groupBox3.Controls.Add(this.txtCALModelNo);
            this.groupBox3.Controls.Add(this.label45);
            this.groupBox3.Controls.Add(this.txtCALEmailID);
            this.groupBox3.Controls.Add(this.label61);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.dtpCALDateofQuote);
            this.groupBox3.Controls.Add(this.label56);
            this.groupBox3.Controls.Add(this.label54);
            this.groupBox3.Controls.Add(this.label46);
            this.groupBox3.Controls.Add(this.label58);
            this.groupBox3.Controls.Add(this.label57);
            this.groupBox3.Controls.Add(this.txtCALContactPerson);
            this.groupBox3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox3.Location = new System.Drawing.Point(6, 36);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1306, 307);
            this.groupBox3.TabIndex = 261;
            this.groupBox3.TabStop = false;
            // 
            // txtCALCustomer
            // 
            this.txtCALCustomer.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtCALCustomer.Location = new System.Drawing.Point(133, 16);
            this.txtCALCustomer.Name = "txtCALCustomer";
            this.txtCALCustomer.Size = new System.Drawing.Size(250, 26);
            this.txtCALCustomer.TabIndex = 560;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(523, 157);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 18);
            this.label4.TabIndex = 559;
            this.label4.Text = "Delivery Term:";
            // 
            // textDeliveryTerm
            // 
            this.textDeliveryTerm.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.textDeliveryTerm.Location = new System.Drawing.Point(624, 157);
            this.textDeliveryTerm.Name = "textDeliveryTerm";
            this.textDeliveryTerm.Size = new System.Drawing.Size(250, 26);
            this.textDeliveryTerm.TabIndex = 558;
            // 
            // textquotationNo
            // 
            this.textquotationNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textquotationNo.Location = new System.Drawing.Point(624, 20);
            this.textquotationNo.Multiline = true;
            this.textquotationNo.Name = "textquotationNo";
            this.textquotationNo.Size = new System.Drawing.Size(250, 26);
            this.textquotationNo.TabIndex = 556;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(520, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 18);
            this.label3.TabIndex = 557;
            this.label3.Text = "Quotation No*:";
            // 
            // labquoteby
            // 
            this.labquoteby.AutoSize = true;
            this.labquoteby.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.labquoteby.ForeColor = System.Drawing.Color.Black;
            this.labquoteby.Location = new System.Drawing.Point(1199, 22);
            this.labquoteby.Name = "labquoteby";
            this.labquoteby.Size = new System.Drawing.Size(18, 18);
            this.labquoteby.TabIndex = 555;
            this.labquoteby.Text = "* ";
            // 
            // txtCALAddress
            // 
            this.txtCALAddress.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtCALAddress.Location = new System.Drawing.Point(133, 140);
            this.txtCALAddress.MaxLength = 1000;
            this.txtCALAddress.Multiline = true;
            this.txtCALAddress.Name = "txtCALAddress";
            this.txtCALAddress.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtCALAddress.Size = new System.Drawing.Size(369, 147);
            this.txtCALAddress.TabIndex = 554;
            // 
            // txtCALTel
            // 
            this.txtCALTel.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtCALTel.Location = new System.Drawing.Point(133, 100);
            this.txtCALTel.Name = "txtCALTel";
            this.txtCALTel.Size = new System.Drawing.Size(250, 26);
            this.txtCALTel.TabIndex = 204;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label42.ForeColor = System.Drawing.Color.Black;
            this.label42.Location = new System.Drawing.Point(885, 139);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(104, 36);
            this.label42.TabIndex = 255;
            this.label42.Text = "Model and \r\nSerial Number :";
            // 
            // txtCalQuotename
            // 
            this.txtCalQuotename.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCalQuotename.Location = new System.Drawing.Point(624, 106);
            this.txtCalQuotename.Multiline = true;
            this.txtCalQuotename.Name = "txtCalQuotename";
            this.txtCalQuotename.Size = new System.Drawing.Size(250, 26);
            this.txtCalQuotename.TabIndex = 240;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label48.ForeColor = System.Drawing.Color.Black;
            this.label48.Location = new System.Drawing.Point(517, 106);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(101, 18);
            this.label48.TabIndex = 251;
            this.label48.Text = "Quote Name *:";
            // 
            // cmbCALQuoteFor
            // 
            this.cmbCALQuoteFor.DropDownHeight = 60;
            this.cmbCALQuoteFor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCALQuoteFor.DropDownWidth = 150;
            this.cmbCALQuoteFor.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCALQuoteFor.FormattingEnabled = true;
            this.cmbCALQuoteFor.IntegralHeight = false;
            this.cmbCALQuoteFor.ItemHeight = 18;
            this.cmbCALQuoteFor.Items.AddRange(new object[] {
            "BiSS-ITW",
            "INSTRON"});
            this.cmbCALQuoteFor.Location = new System.Drawing.Point(995, 103);
            this.cmbCALQuoteFor.Name = "cmbCALQuoteFor";
            this.cmbCALQuoteFor.Size = new System.Drawing.Size(222, 26);
            this.cmbCALQuoteFor.TabIndex = 256;
            // 
            // CmbCurrency
            // 
            this.CmbCurrency.DropDownHeight = 60;
            this.CmbCurrency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbCurrency.DropDownWidth = 150;
            this.CmbCurrency.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CmbCurrency.FormattingEnabled = true;
            this.CmbCurrency.IntegralHeight = false;
            this.CmbCurrency.ItemHeight = 18;
            this.CmbCurrency.Items.AddRange(new object[] {
            "INR",
            "USD"});
            this.CmbCurrency.Location = new System.Drawing.Point(995, 60);
            this.CmbCurrency.Name = "CmbCurrency";
            this.CmbCurrency.Size = new System.Drawing.Size(222, 26);
            this.CmbCurrency.TabIndex = 258;
            // 
            // txtCALModelNo
            // 
            this.txtCALModelNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCALModelNo.Location = new System.Drawing.Point(995, 140);
            this.txtCALModelNo.Multiline = true;
            this.txtCALModelNo.Name = "txtCALModelNo";
            this.txtCALModelNo.Size = new System.Drawing.Size(222, 35);
            this.txtCALModelNo.TabIndex = 241;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.Black;
            this.label45.Location = new System.Drawing.Point(1119, 19);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(81, 19);
            this.label45.TabIndex = 253;
            this.label45.Text = "Quote By :";
            // 
            // txtCALEmailID
            // 
            this.txtCALEmailID.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtCALEmailID.Location = new System.Drawing.Point(133, 57);
            this.txtCALEmailID.Name = "txtCALEmailID";
            this.txtCALEmailID.Size = new System.Drawing.Size(250, 26);
            this.txtCALEmailID.TabIndex = 205;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.ForeColor = System.Drawing.Color.Black;
            this.label61.Location = new System.Drawing.Point(912, 65);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(77, 18);
            this.label61.TabIndex = 259;
            this.label61.Text = "Currency* :";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Black;
            this.label24.Location = new System.Drawing.Point(905, 106);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(84, 18);
            this.label24.TabIndex = 257;
            this.label24.Text = "Quote For* :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(46, 103);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 18);
            this.label1.TabIndex = 553;
            this.label1.Text = "Mobile No: ";
            // 
            // dtpCALDateofQuote
            // 
            this.dtpCALDateofQuote.CustomFormat = "";
            this.dtpCALDateofQuote.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpCALDateofQuote.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpCALDateofQuote.Location = new System.Drawing.Point(995, 16);
            this.dtpCALDateofQuote.Name = "dtpCALDateofQuote";
            this.dtpCALDateofQuote.Size = new System.Drawing.Size(118, 26);
            this.dtpCALDateofQuote.TabIndex = 239;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label56.ForeColor = System.Drawing.Color.Black;
            this.label56.Location = new System.Drawing.Point(42, 16);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(85, 18);
            this.label56.TabIndex = 206;
            this.label56.Text = "Customer * :";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label54.ForeColor = System.Drawing.Color.Black;
            this.label54.Location = new System.Drawing.Point(880, 27);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(109, 18);
            this.label54.TabIndex = 248;
            this.label54.Text = "Date of Quote* :";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label46.ForeColor = System.Drawing.Color.Black;
            this.label46.Location = new System.Drawing.Point(55, 57);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(72, 18);
            this.label46.TabIndex = 211;
            this.label46.Text = "Email ID* :";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label58.ForeColor = System.Drawing.Color.Black;
            this.label58.Location = new System.Drawing.Point(62, 140);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(65, 18);
            this.label58.TabIndex = 207;
            this.label58.Text = "Address :";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label57.ForeColor = System.Drawing.Color.Black;
            this.label57.Location = new System.Drawing.Point(506, 60);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(115, 18);
            this.label57.TabIndex = 208;
            this.label57.Text = "Contact Person* :";
            // 
            // txtCALContactPerson
            // 
            this.txtCALContactPerson.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtCALContactPerson.Location = new System.Drawing.Point(624, 57);
            this.txtCALContactPerson.MaxLength = 80;
            this.txtCALContactPerson.Name = "txtCALContactPerson";
            this.txtCALContactPerson.Size = new System.Drawing.Size(250, 26);
            this.txtCALContactPerson.TabIndex = 202;
            // 
            // chkQuoteSavePath
            // 
            this.chkQuoteSavePath.AutoSize = true;
            this.chkQuoteSavePath.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkQuoteSavePath.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.chkQuoteSavePath.Location = new System.Drawing.Point(1079, 7);
            this.chkQuoteSavePath.Name = "chkQuoteSavePath";
            this.chkQuoteSavePath.Size = new System.Drawing.Size(160, 27);
            this.chkQuoteSavePath.TabIndex = 557;
            this.chkQuoteSavePath.Text = "Quote Save Path";
            this.chkQuoteSavePath.UseVisualStyleBackColor = true;
            this.chkQuoteSavePath.CheckedChanged += new System.EventHandler(this.chkQuoteSavePath_CheckedChanged);
            // 
            // Spare_parts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1302, 662);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.lblCALQuoteby);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Spare_parts";
            this.Text = "Spare_parts";
            this.Load += new System.EventHandler(this.Spare_parts_Load);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgItemOrProductList)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox CmbCurrency;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.ComboBox cmbCALQuoteFor;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label lblCALQuoteby;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox txtCalQuotename;
        private System.Windows.Forms.TextBox txtCALModelNo;
        private System.Windows.Forms.DateTimePicker dtpCALDateofQuote;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnGenaratePO;
        private System.Windows.Forms.Button btnPrintSparePartsdownload;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dgItemOrProductList;
        private System.Windows.Forms.Button buttAdd;
        private System.Windows.Forms.TextBox txtCALEmailID;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox txtCALTel;
        private System.Windows.Forms.TextBox txtCALContactPerson;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtCALAddress;
        private System.Windows.Forms.DataGridViewTextBoxColumn SLNO;
        private System.Windows.Forms.DataGridViewTextBoxColumn PartNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn PartDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn Qty;
        private System.Windows.Forms.DataGridViewTextBoxColumn Colunitprice;
        private System.Windows.Forms.DataGridViewTextBoxColumn Coltotal;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label labSpareParts;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comQuotationNo;
        private System.Windows.Forms.Label labquoteby;
        private System.Windows.Forms.TextBox textquotationNo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textDeliveryTerm;
        private System.Windows.Forms.TextBox txtCALCustomer;
        private System.Windows.Forms.CheckBox chkQuoteSavePath;
    }
}