﻿using System;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    public partial class frmQuoteView : Form
    {
        public frmQuoteView()
        {
            InitializeComponent();
        }
        frmForm2 form = new frmForm2();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        frmSalesHome SalesHome = new frmSalesHome();
        DataTable dtQuoteList = new DataTable();

        private void frmQuoteView_Load(object sender, EventArgs e)
        {
            dtpfromdate.ResetText();
            dtptodate.ResetText();
            fnLoadResults();
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            fnLoadResults();
        }

        private void fnLoadResults()
        {  
            var date = DateTime.Parse(dtpfromdate.Text);
            var date1 = DateTime.Parse(dtptodate.Text);

            dtQuoteList = DAL.fnAllQuoteViewDetails(0, null, date.ToString("yyyy-MM-dd"), date1.ToString("yyyy-MM-dd")).Tables[0];


           

            if (dtQuoteList.Rows.Count > 0)
            {
                dgvQuoteView.AutoGenerateColumns = false;
                dgvQuoteView.DataSource = dtQuoteList;
            }

            dtClone = dtQuoteList.Copy();
            bsIteSearch.DataSource = dtClone;

        }

        BindingSource bsIteSearch = new BindingSource();
        DataTable dtClone = new DataTable();

        private void txtSearchText_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtSearchText.Text.Length > 1)
            {
                fnRowFilter(0, txtSearchText.Text);
                dgvQuoteView.DataSource = bsIteSearch;
            }
            else
            {
                bsIteSearch.RemoveFilter();
            }
        }

        private void fnRowFilter(uint uSearchOption, string sRowFilter)    //filter the Item list depends upon the user inpts
        {
           if (dtQuoteList.Rows.Count > 0)
            {
                switch (uSearchOption)
                {
                    case Global.uITEM_CODE_SEARCH:
                        {
                            bsIteSearch.Filter = string.Format("QuotationNumber LIKE '%{0}%' or Region LIKE '%{0}%'  or Leadgenarated LIKE '%{0}%' or CustomerName LIKE '%{0}%' or QuotePreparedBy LIKE '%{0}%' or QuoteCompany LIKE '%{0}%'", sRowFilter);
                            break;
                        }
                }
            }
        }
        
        private void frmQuoteView_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Refresh();
            this.Hide();
          
          //  frmSalesQuote SaleQuote = new frmSalesQuote();
           // SaleQuote.Show();
        }

        private void btnSearchexactQuote_Click(object sender, EventArgs e)
        {
            dtQuoteList = DAL.fnAllQuoteViewDetails(3, txtSearchText.Text, "", "").Tables[0];
            if (dtQuoteList.Rows.Count > 0)
            {
                dgvQuoteView.AutoGenerateColumns = false;
                dgvQuoteView.DataSource = dtQuoteList;
                
            }

            dtClone = dtQuoteList.Copy();
            bsIteSearch.DataSource = dtClone;
        }
    }
}
