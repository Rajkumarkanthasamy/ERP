﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.Diagnostics;
using System.IO;

namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    public partial class frmEnquiryRegisterView : Form
    {
        public frmEnquiryRegisterView()
        {
            InitializeComponent();
        }
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        frmSalesHome SalesHome = new frmSalesHome();
        DataTable dtEnquiryDetails = new DataTable();
        frmSalesQuote Quotation = new frmSalesQuote();
        frmEnquiryRegisterEntry ER = new frmEnquiryRegisterEntry();
        private void frmEnquiryRegisterView_Load(object sender, EventArgs e)
        {
            fnLoadDetails();
        }

        private void frmEnquiryRegisterView_FormClosing(object sender, FormClosingEventArgs e)
        {
            ER.fnEnquiryRegNumber = string.Empty;
            fnExit();
        }
        private void fnExit()
        {
            this.Hide();
            ER.Show();
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            fnLoadDetails();
        }

        private void fnLoadDetails()
        {
            dtpFromDate.Format = DateTimePickerFormat.Custom;
            dtpFromDate.CustomFormat = "yyyy-MM-dd";
            dtpToDate.Format = DateTimePickerFormat.Custom;
            dtpToDate.CustomFormat = "yyyy-MM-dd";
            dtEnquiryDetails = DAL.fnEnquiryCheck(0, dtpFromDate.Text, dtpToDate.Text,"").Tables[0];
            dgvEnquiry.AutoGenerateColumns = false;
            dgvEnquiry.DataSource = dtEnquiryDetails;
            
            dtpFromDate.Format = DateTimePickerFormat.Custom;
            dtpFromDate.CustomFormat = "dd-MM-yyyy";
            dtpToDate.Format = DateTimePickerFormat.Custom;
            dtpToDate.CustomFormat = "dd-MM-yyyy";
        }

        private void dgvEnquiry_DoubleClick(object sender, EventArgs e)
        {
            ER.fnEnquiryRegNumber = string.Empty;
            ER.fnEnquiryRegNumber = dgvEnquiry.CurrentRow.Cells["EnquiryNumber"].Value.ToString();
            fnExit();
        }

        private void btnExcelReport_Click(object sender, EventArgs e)
        {
            string ExcelFolderPath;
            string FileFullPath;
            //  dgvQuoteView.DataSource
            Microsoft.Office.Interop.Excel._Application ExcelApp = null;
            Microsoft.Office.Interop.Excel._Workbook NewWorkBook = null;
            Cursor.Current = Cursors.WaitCursor;

            bool IsFirsttime = true;
            dtEnquiryDetails = (DataTable)dgvEnquiry.DataSource;
            if (dtEnquiryDetails.Rows.Count > 0)
            {
                int j = 6;
                ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\Enquiry Register\\";
                FileFullPath = ExcelFolderPath + "BiSS Enquiry Register " + dtpFromDate.Text + " To " + dtpToDate.Text + " " + DateTime.Now.ToString("d/M/yyyy HH/mm/ss") + " ";
                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);

                ExcelApp = new Microsoft.Office.Interop.Excel.Application();
                NewWorkBook = ExcelApp.Workbooks.Add(Type.Missing);
                Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
                worksheet = NewWorkBook.Sheets["Sheet1"];
                worksheet = NewWorkBook.ActiveSheet;
                worksheet.Name = "BiSS Enquiry Register";
                object misValue = System.Reflection.Missing.Value;
                worksheet.Cells[1, 1] = "BiSS Enquiry Register";
                CellMerge("Merge", NewWorkBook.ActiveSheet, 1, 1, 1, 3);
                //worksheet.Cells[2, 1] = "Item Code :'" + lblRepeatitemcode.Text + "'";// i++;
                //CellMerge("Merge", NewWorkBook.ActiveSheet, 2, 2, 1, 7);
                //worksheet.Cells[3, 1] = "Item Desc : " + lblitemname.Text + "";
                //CellMerge("Merge", NewWorkBook.ActiveSheet, 3, 3, 1, 7);
                worksheet.Cells[4, 1] = "Dated From : " + dtpFromDate.Text + "  To : " + dtpToDate.Text + "";// i++; i++;
                CellMerge("Merge", NewWorkBook.ActiveSheet, 4, 4, 1, 5);
                worksheet.Range["A1:C1"].Cells.Font.Size = 16;
                worksheet.Range["A2:C3"].Cells.Font.Size = 14;
                worksheet.Range["A4:C4"].Cells.Font.Size = 12;
                worksheet.Range["A1:C3"].Cells.Font.Bold = true;
                bool bFirsttime = true;

                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Bold = true;
                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Color = Color.Blue;


                object[,] rawData = new object[dtEnquiryDetails.Rows.Count + 1, dtEnquiryDetails.Columns.Count];
                if (bFirsttime)
                {
                    for (int col = 0; col < dtEnquiryDetails.Columns.Count; col++)
                    {
                        rawData[0, col] = dtEnquiryDetails.Columns[col].ColumnName;
                    }
                    bFirsttime = false;
                }
                if (dtEnquiryDetails.Rows.Count > 0)
                {
                    for (int row = 0; row < dtEnquiryDetails.Rows.Count; row++)
                    {
                        for (int col = 0; col < dtEnquiryDetails.Columns.Count; col++)
                        {
                            rawData[row + 1, col] = dtEnquiryDetails.Rows[row].ItemArray[col];
                        }
                    }
                    string finalColLetter = string.Empty;
                    string excelRange = string.Empty;
                    if (IsFirsttime)
                    {
                        finalColLetter = string.Empty;
                        string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        int colCharsetLen = colCharset.Length;

                        if (dtEnquiryDetails.Columns.Count > colCharsetLen)
                        {
                            finalColLetter = colCharset.Substring((dtEnquiryDetails.Columns.Count - 1) / colCharsetLen - 1, 1);
                        }

                        finalColLetter += colCharset.Substring((dtEnquiryDetails.Columns.Count - 1) % colCharsetLen, 1);
                        excelRange = string.Format("A6:{0}{1}", finalColLetter, dtEnquiryDetails.Rows.Count + j);
                        IsFirsttime = false;
                    }
                    worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;

                }

                worksheet.Range["A3:C5"].Cells.Font.Size = 14;
                worksheet.Range["A3:C5"].Cells.Font.Bold = 14;
                CellMerge("Merge", NewWorkBook.ActiveSheet, 1, 1, 1, 3);
                //worksheet.get_Range("C6", "C99999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                //Microsoft.Office.Interop.Excel.Range Range = worksheet.get_Range("N6", "R99999");
                //Range.EntireColumn.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                worksheet.Rows.RowHeight = "18";
                //Microsoft.Office.Interop.Excel.Range rangea = worksheet.get_Range("J6", "J99999");
                //  rangea.NumberFormat = "dd-MM-yyyy";

                //  if (cmbReportType.SelectedIndex == 0 || cmbReportType.SelectedIndex == 5 || cmbReportType.SelectedIndex == 6)
                {
                    Microsoft.Office.Interop.Excel.Range rangea = worksheet.get_Range("B6", "B9999");
                    rangea.NumberFormat = "dd-MM-yyyy";
                    Microsoft.Office.Interop.Excel.Range rangeDate = worksheet.get_Range("T6", "T9999");
                    rangeDate.NumberFormat = "dd-MM-yyyy";

                    //Microsoft.Office.Interop.Excel.Range rangeDate1 = worksheet.get_Range("N6", "N9999");
                    //rangeDate1.NumberFormat = "0.00";
                }

                worksheet.Columns.AutoFit();
                worksheet.Rows.AutoFit();
                //worksheet.Columns[1].ColumnWidth = 12;
                //worksheet.Columns[1].WrapText = true;
                //worksheet.Columns[12].ColumnWidth = 50;
                // worksheet.Columns[12].WrapText = true;
                //worksheet.Columns[8].ColumnWidth = 50;
                //worksheet.Columns[8].WrapText = true;
                worksheet.Rows.RowHeight = "18";
                worksheet.PageSetup.PrintArea = "A1:X" + (dtEnquiryDetails.Rows.Count + 6) + "";
                worksheet.PageSetup.PrintTitleRows = "$1:$2";
                worksheet.PageSetup.PrintNotes = true;
                worksheet.PageSetup.Zoom = 75;
                worksheet.PageSetup.PrintGridlines = true;
                worksheet.PageSetup.LeftMargin = 0;
                worksheet.PageSetup.RightMargin = 0;
                worksheet.PageSetup.TopMargin = 0.75;
                worksheet.PageSetup.BottomMargin = 0.75;
                worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                NewWorkBook.SaveAs(FileFullPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                NewWorkBook.Save();
                NewWorkBook.Close(true, misValue, misValue);
                ExcelApp.Quit();
                releaseObject(worksheet);
                releaseObject(NewWorkBook);
                releaseObject(ExcelApp);

                if (Directory.Exists(ExcelFolderPath))
                {
                    Process.Start(ExcelFolderPath);
                }
                Cursor.Current = Cursors.Default;
            }
        }

        #region CellMerge Funtion
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlMedium, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "GridLines":
                    {
                        CELLS.Borders.Color = System.Drawing.Color.Black;
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignCenter":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                        break;
                    }
                case "Bold":
                    {
                        CELLS.Font.Bold = true;
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

        }
        #endregion

        #region Excel App Release Object Function
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
        #endregion
    }
}
