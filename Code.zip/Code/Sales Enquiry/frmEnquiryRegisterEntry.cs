﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    public partial class frmEnquiryRegisterEntry : Form
    {
        public frmEnquiryRegisterEntry()
        {
            InitializeComponent();
        }
        frmForm2 form = new frmForm2();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        DataTable dtCustomerList = new DataTable();
        frmSalesQuote Quote = new frmSalesQuote();
        DataTable dtEnquiryRegisterNumber = new DataTable();
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtCustomerType.Text) && !string.IsNullOrEmpty(txtContactPerson.Text) &&
                cmbCustomer.SelectedIndex != -1 && cmbLeadInput.SelectedIndex != -1 && cmbCustomerBase.SelectedIndex != -1
                && cmbProdcutType.SelectedIndex != -1 && cmbCountryName.SelectedIndex != -1 && cmbStandardCustom.SelectedIndex != -1 && 
                !string.IsNullOrEmpty(cmbDealer.Text) && !string.IsNullOrEmpty(txtExpectedTime.Text)
                 && bEnquiryDate)
            {
                //if (cmbCountryName.SelectedIndex == 0 && cmbRegion.SelectedIndex != -1)
                //{
                if (btnSave.Text == "Save")
                {
                    //MessageBox.Show(txtPrepareBy.Text, "Code..");
                    GlobalClass.iSuccess = DAL.fnAddEnquiryRegisterEntry(1, txtPrepareBy.Text,
                        cmbLeadInput.Text,cmbCustomer.Text, txtCusCode.Text, txtCustomerType.Text, cmbCustomerBase.Text, txtContactPerson.Text, txtEmailID.Text, cmbProdcutType.Text, cmbCountryName.Text,
                        cmbRegion.Text, cmbStandardCustom.Text, txtExpectedTime.Text, cmbDealer.Text,
                        cmbOrderRecievedMonth.Text, cmbOrderRecievedYear.Text, dtpEnquiryDate.Text, txtContactNumber1.Text, txtDepartment1.Text, txtAddress.Text);


                    dtEnquiryRegisterNumber = DAL.fnEnquiryLatNumber(0, "", txtPrepareBy.Text).Tables[0];

                    if (dtEnquiryRegisterNumber.Rows.Count > 0)
                    {
                        sEnquiryNumber = dtEnquiryRegisterNumber.Rows[0]["EnquiryNumber"].ToString();
                        MessageBox.Show("Enquiry register '" + sEnquiryNumber + "' added successfully", "Success", 0, MessageBoxIcon.Information);

                        fnVisibility();
                    }
                }
                else if (btnSave.Text == "Update")
                {
                    GlobalClass.iSuccess = DAL.fnAddEnquiryRegisterEntry(2, txtEnquiryNumber.Text,
                                          cmbLeadInput.Text,cmbCustomer.Text, txtCusCode.Text, txtCustomerType.Text, cmbCustomerBase.Text, txtContactPerson.Text, txtEmailID.Text, cmbProdcutType.Text, cmbCountryName.Text,
                                          cmbRegion.Text, cmbStandardCustom.Text, txtExpectedTime.Text, cmbDealer.Text,
                                          cmbOrderRecievedMonth.Text, cmbOrderRecievedYear.Text, dtpEnquiryDate.Text, txtContactNumber1.Text, txtDepartment1.Text, txtAddress.Text);

                    MessageBox.Show("Enquiry register '" + txtEnquiryNumber.Text + "' updated successfully", "Success", 0, MessageBoxIcon.Information);

                    fnVisibility();
                }
                btnSave.Enabled = false;
                //}
                //else
                //{
                //     MessageBox.Show("Please select the region", "Error", 0, MessageBoxIcon.Error);
                //        cmbRegion.DroppedDown = true;
                //}
            }
            else
            {
                if (string.IsNullOrEmpty(txtCustomerType.Text))
                {
                    MessageBox.Show("Please enter the customer type", "Error", 0, MessageBoxIcon.Error);
                    txtCustomerType.Focus();
                }
                else if (string.IsNullOrEmpty(txtContactPerson.Text))
                {
                    MessageBox.Show("Please enter the contact person", "Error", 0, MessageBoxIcon.Error);
                    txtContactPerson.Focus();
                }
                else if (cmbCustomer.SelectedIndex == -1)
                {
                    MessageBox.Show("Please select the customer name", "Error", 0, MessageBoxIcon.Error);
                    cmbCustomer.DroppedDown = true;
                }
                else if (cmbLeadInput.SelectedIndex == -1)
                {
                    MessageBox.Show("Please select the lead input", "Error", 0, MessageBoxIcon.Error);
                    cmbLeadInput.DroppedDown = true;
                }
                
                else if (cmbCustomerBase.SelectedIndex == -1)
                {
                    MessageBox.Show("Please select the customer base", "Error", 0, MessageBoxIcon.Error);
                    cmbCustomerBase.DroppedDown = true;
                }
                else if (cmbProdcutType.SelectedIndex == -1)
                {
                    MessageBox.Show("Please select the product type", "Error", 0, MessageBoxIcon.Error);
                    cmbProdcutType.DroppedDown = true;
                }
                else if (cmbCountryName.SelectedIndex == -1)
                {
                    MessageBox.Show("Please select the country", "Error", 0, MessageBoxIcon.Error);
                    cmbCountryName.DroppedDown = true;
                }
                else if (cmbStandardCustom.SelectedIndex == -1)
                {
                    MessageBox.Show("Please select the standard custom", "Error", 0, MessageBoxIcon.Error);
                    cmbStandardCustom.DroppedDown = true;
                }

                else if (string.IsNullOrEmpty(cmbDealer.Text))
                {
                    MessageBox.Show("Please select the dealer", "Error", 0, MessageBoxIcon.Error);
                    cmbDealer.DroppedDown = true;
                }
                else if (string.IsNullOrEmpty(txtExpectedTime.Text))
                {
                    MessageBox.Show("Please enter the expected time", "Error", 0, MessageBoxIcon.Error);
                    txtExpectedTime.Focus();
                }
                //else if (cmbOrderRecievedMonth.SelectedIndex == -1)
                //{
                //    MessageBox.Show("Please select the order recieved month", "Error", 0, MessageBoxIcon.Error);
                //    cmbOrderRecievedMonth.DroppedDown = true;
                //}
                //else if (cmbOrderRecievedYear.SelectedIndex == -1)
                //{
                //    MessageBox.Show("Please select the order recieved year", "Error", 0, MessageBoxIcon.Error);
                //    cmbOrderRecievedYear.DroppedDown = true;
                //}
                else if (!bEnquiryDate)
                {
                    MessageBox.Show("Please select enquire date ", "Error", 0, MessageBoxIcon.Error);
                }
            }

        }

        private string sEnquiryNumber = "";
        public string fnEnquiryRegNumber
        {
            get
            {
                return sEnquiryNumber;
            }
            set
            {
                sEnquiryNumber = value;
            }
        }
        DataTable dtEnquiryDetails = new DataTable();
        DataTable dtQuoteCountry = new DataTable();
        DataTable dtEnquiryNum = new DataTable();
        bool bCustomerLoad = false;
        private void frmEnquiryRegisterEntry_Load(object sender, EventArgs e)
        {
            txtPrepareBy.Text = login.GetUserDetails[2];
            dtCustomerList = DAL.fnCustomerList(5, null).Tables[0];
            foreach (DataRow DR in dtCustomerList.Rows)
            {
                if (!cmbCustomer.Items.Contains(DR["CustomerName"].ToString()))
                    cmbCustomer.Items.Add(DR["CustomerName"].ToString());
            }
            dtpEnquiryDate.Format = DateTimePickerFormat.Custom;
            dtpEnquiryDate.CustomFormat = "yyyy-MM-dd";
            dtEnquiryNum = DAL.fnEnquiryCheck(2, "2020-01-01", dtpEnquiryDate.Text, "").Tables[0];
            dtpEnquiryDate.Format = DateTimePickerFormat.Custom;
            dtpEnquiryDate.CustomFormat = "dd-MM-yyyy";

            foreach (DataRow DR in dtEnquiryNum.Rows)
            {
                if (!cmbReferenceRegister.Items.Contains(DR["EnquiryNumber"].ToString()))
                    cmbReferenceRegister.Items.Add(DR["EnquiryNumber"].ToString());
            }

            dtQuoteCountry = DAL.fnQuoteCountry(0).Tables[0];

            foreach (DataRow DR in dtQuoteCountry.Rows)
            {
                if (!cmbCountryName.Items.Contains(DR[0].ToString()))
                    cmbCountryName.Items.Add(DR[0].ToString());
            }


            if (!string.IsNullOrEmpty(sEnquiryNumber))
            {
                bCustomerLoad = true;
                fnVisibility();
                btnSave.Text = "Update";
                cmbReferenceRegister.Visible = false;
                label4.Visible = false;
                fnLoadData(sEnquiryNumber);
                
                bCustomerLoad = false;
            }
        }


        private void fnLoadData(string sEnquiryNumber)
        {
            dtEnquiryDetails = DAL.fnQuotationNumberLoadData(20, sEnquiryNumber, "").Tables[0];

            if (dtEnquiryDetails.Rows.Count > 0)
            {
                cmbLeadInput.SelectedItem = dtEnquiryDetails.Rows[0]["Leadinputfrom"].ToString();
                cmbCustomer.SelectedItem = dtEnquiryDetails.Rows[0]["CustomerName"].ToString();
                txtCusCode.Text = dtEnquiryDetails.Rows[0]["CustomerCode"].ToString();
                txtCustomerType.Text = dtEnquiryDetails.Rows[0]["CustomerType"].ToString();
                cmbCustomerBase.SelectedItem = dtEnquiryDetails.Rows[0]["CustomerBase"].ToString();
                txtContactPerson.Text = dtEnquiryDetails.Rows[0]["ContactPerson"].ToString();
                txtEmailID.Text = dtEnquiryDetails.Rows[0]["EmailID"].ToString();
                cmbProdcutType.SelectedItem = dtEnquiryDetails.Rows[0]["ProductType"].ToString();
                cmbCountryName.SelectedItem = dtEnquiryDetails.Rows[0]["CountryName"].ToString();
                cmbRegion.SelectedItem = dtEnquiryDetails.Rows[0]["RegioninIndia"].ToString();
                cmbStandardCustom.SelectedItem = dtEnquiryDetails.Rows[0]["StandardCustom"].ToString();
                txtExpectedTime.Text = dtEnquiryDetails.Rows[0]["ExpectedTime"].ToString();
                cmbDealer.Text = dtEnquiryDetails.Rows[0]["Dealer"].ToString();
                cmbOrderRecievedMonth.SelectedItem = dtEnquiryDetails.Rows[0]["Orderreceivedmonth"].ToString();
                cmbOrderRecievedYear.SelectedItem = dtEnquiryDetails.Rows[0]["Orderreceivedyear"].ToString();
                dtpEnquiryDate.Text = dtEnquiryDetails.Rows[0]["Enquirydate"].ToString();
                txtDepartment1.Text = dtEnquiryDetails.Rows[0]["Department"].ToString();
                txtContactNumber1.Text = dtEnquiryDetails.Rows[0]["ContactNumber"].ToString();
                txtAddress.Text = dtEnquiryDetails.Rows[0]["Adress"].ToString();
            }
        }


        private void fnVisibility()
        {
            lblEnquiryReg.Visible = true;
            txtEnquiryNumber.Visible = true;
            txtEnquiryNumber.Text = sEnquiryNumber;
            btnGenarateQuote.Visible = true;
            cmbReferenceRegister.Visible = true;
            label4.Visible = true;
        }

        private void cmbCustomer_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!bCustomerLoad)
            {
                DataView dv = new DataView(dtCustomerList);
                dv.RowFilter = "CustomerName like '" + cmbCustomer.Text.Trim() + "%'";
                DataTable dt = new DataTable();
                dt = dv.ToTable();
                if (dt.Rows.Count > 0)
                {
                    txtCustomerType.Text = dt.Rows[0]["CustomerType"].ToString();
                    txtContactPerson.Text = dt.Rows[0]["ContactPerson"].ToString();
                    txtCusCode.Text = dt.Rows[0]["CusCode"].ToString();
                    txtContactNumber1.Text = dt.Rows[0]["MobileNo"].ToString();
                    txtAddress.Text = dt.Rows[0]["Address1"].ToString() + dt.Rows[0]["Address2"].ToString() + dt.Rows[0]["Address3"].ToString();
                    txtEmailID.Text = dt.Rows[0]["EmailAddress"].ToString();
                }
            }
        }

        private void frmEnquiryRegisterEntry_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            form.Show();
        }

        private void btnClearAll_Click(object sender, EventArgs e)
        {
            frmEnquiryRegisterEntry frm = new frmEnquiryRegisterEntry();
            this.Hide();
            frm.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            form.Show();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmEnquiryRegisterView Eview = new frmEnquiryRegisterView();
            Eview.ShowDialog();
        }
        bool bEnquiryDate = false;
        private void dtpEnquiryDate_ValueChanged(object sender, EventArgs e)
        {
            bEnquiryDate = true;
        }

        private void btnGenarateQuote_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtEnquiryNumber.Text))
            {
                Quote.fnEnquiryNumber = string.Empty;
                Quote.fnEnquiryNumber = txtEnquiryNumber.Text;
                this.Hide();
                pleasewaitform pleaseWait = new pleasewaitform();
                pleaseWait.Show();
                Application.DoEvents();
                Quote.Show();
                pleaseWait.Hide();

            }
        }

        private void cmbCountryName_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbDealer.SelectedIndex = -1;
            cmbDealer.Items.Clear();
            if (cmbCountryName.SelectedIndex == 0)
            {
                cmbDealer.Items.Add("Direct");
                cmbDealer.Items.Add("SNiP");
                cmbDealer.Items.Add("MIC");
                cmbDealer.Items.Add("Blue Star");
                cmbDealer.Items.Add("ABS Instruments");
            }
            else
            {
                cmbDealer.Items.Add("Afix4U");
                cmbDealer.Items.Add("Aikoh");
                cmbDealer.Items.Add("CMEC");
                cmbDealer.Items.Add("GT");
                cmbDealer.Items.Add("Industar-M");
                cmbDealer.Items.Add("Inteltest");
                cmbDealer.Items.Add("Kurs");
                cmbDealer.Items.Add("Novatest");
                cmbDealer.Items.Add("Ostec");
                cmbDealer.Items.Add("Pentad Taiwan");
                cmbDealer.Items.Add("Precizia");
                cmbDealer.Items.Add("Promtex");
                cmbDealer.Items.Add("Sino-Test");
                cmbDealer.Items.Add("TRI");
            }
        }

        private void cmbReferenceRegister_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbReferenceRegister.SelectedIndex >= 0)
            {
                fnLoadData(cmbReferenceRegister.Text);
                fnVisibilequotebtn();
            }
        }
        private void fnVisibilequotebtn()
        {
            lblEnquiryReg.Visible = true;
            txtEnquiryNumber.Visible = true;
            txtEnquiryNumber.Text = cmbReferenceRegister.Text;
            btnGenarateQuote.Visible = true;
            cmbReferenceRegister.Visible = true;
            label4.Visible = true;
        }
    }
}
