﻿namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    partial class frmSalesHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSalesHome));
            this.lblName = new System.Windows.Forms.Label();
            this.btnServiceQuote = new System.Windows.Forms.Button();
            this.btnOpportunity = new System.Windows.Forms.Button();
            this.btnSalesProduct = new System.Windows.Forms.Button();
            this.btnTestingQuote = new System.Windows.Forms.Button();
            this.btnPegRate = new System.Windows.Forms.Button();
            this.btnEnquiryRegister = new System.Windows.Forms.Button();
            this.btnCustomerVisit = new System.Windows.Forms.Button();
            this.btnSalesQuote = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.Indigo;
            this.lblName.Location = new System.Drawing.Point(342, 9);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(294, 29);
            this.lblName.TabIndex = 40;
            this.lblName.Text = "BiSS Inventory Management";
            // 
            // btnServiceQuote
            // 
            this.btnServiceQuote.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnServiceQuote.FlatAppearance.BorderSize = 0;
            this.btnServiceQuote.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnServiceQuote.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnServiceQuote.ForeColor = System.Drawing.Color.MediumBlue;
            this.btnServiceQuote.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_invoice_481;
            this.btnServiceQuote.Location = new System.Drawing.Point(289, 224);
            this.btnServiceQuote.Name = "btnServiceQuote";
            this.btnServiceQuote.Size = new System.Drawing.Size(156, 85);
            this.btnServiceQuote.TabIndex = 42;
            this.btnServiceQuote.Text = "Service Quote GEN";
            this.btnServiceQuote.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnServiceQuote.UseVisualStyleBackColor = true;
            this.btnServiceQuote.Click += new System.EventHandler(this.btnServiceQuote_Click);
            // 
            // btnOpportunity
            // 
            this.btnOpportunity.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnOpportunity.Enabled = false;
            this.btnOpportunity.FlatAppearance.BorderSize = 0;
            this.btnOpportunity.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOpportunity.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnOpportunity.ForeColor = System.Drawing.Color.MediumBlue;
            this.btnOpportunity.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_timeline_48;
            this.btnOpportunity.Location = new System.Drawing.Point(833, 94);
            this.btnOpportunity.Name = "btnOpportunity";
            this.btnOpportunity.Size = new System.Drawing.Size(156, 85);
            this.btnOpportunity.TabIndex = 39;
            this.btnOpportunity.Text = "Opportunity Details";
            this.btnOpportunity.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnOpportunity.UseVisualStyleBackColor = true;
            this.btnOpportunity.Click += new System.EventHandler(this.btnOpportunity_Click);
            // 
            // btnSalesProduct
            // 
            this.btnSalesProduct.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnSalesProduct.Enabled = false;
            this.btnSalesProduct.FlatAppearance.BorderSize = 0;
            this.btnSalesProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalesProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnSalesProduct.ForeColor = System.Drawing.Color.MediumBlue;
            this.btnSalesProduct.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_hierarchy_48;
            this.btnSalesProduct.Location = new System.Drawing.Point(39, 224);
            this.btnSalesProduct.Name = "btnSalesProduct";
            this.btnSalesProduct.Size = new System.Drawing.Size(164, 85);
            this.btnSalesProduct.TabIndex = 36;
            this.btnSalesProduct.Text = "Sales Product Master";
            this.btnSalesProduct.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSalesProduct.UseVisualStyleBackColor = true;
            this.btnSalesProduct.Click += new System.EventHandler(this.btnSalesProduct_Click);
            // 
            // btnTestingQuote
            // 
            this.btnTestingQuote.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnTestingQuote.Enabled = false;
            this.btnTestingQuote.FlatAppearance.BorderSize = 0;
            this.btnTestingQuote.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTestingQuote.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnTestingQuote.ForeColor = System.Drawing.Color.MediumBlue;
            this.btnTestingQuote.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_bill_48__1_;
            this.btnTestingQuote.Location = new System.Drawing.Point(576, 224);
            this.btnTestingQuote.Name = "btnTestingQuote";
            this.btnTestingQuote.Size = new System.Drawing.Size(156, 85);
            this.btnTestingQuote.TabIndex = 34;
            this.btnTestingQuote.Text = "Testing Quote GEN";
            this.btnTestingQuote.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnTestingQuote.UseVisualStyleBackColor = true;
            this.btnTestingQuote.Click += new System.EventHandler(this.btnTestingQuote_Click);
            // 
            // btnPegRate
            // 
            this.btnPegRate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnPegRate.FlatAppearance.BorderSize = 0;
            this.btnPegRate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPegRate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnPegRate.ForeColor = System.Drawing.Color.MediumBlue;
            this.btnPegRate.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_sales_performance_48;
            this.btnPegRate.Location = new System.Drawing.Point(779, 398);
            this.btnPegRate.Name = "btnPegRate";
            this.btnPegRate.Size = new System.Drawing.Size(126, 76);
            this.btnPegRate.TabIndex = 32;
            this.btnPegRate.Text = "Peg Rate";
            this.btnPegRate.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnPegRate.UseVisualStyleBackColor = true;
            this.btnPegRate.Visible = false;
            this.btnPegRate.Click += new System.EventHandler(this.btnPegRate_Click);
            // 
            // btnEnquiryRegister
            // 
            this.btnEnquiryRegister.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnEnquiryRegister.Enabled = false;
            this.btnEnquiryRegister.FlatAppearance.BorderSize = 0;
            this.btnEnquiryRegister.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEnquiryRegister.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnEnquiryRegister.ForeColor = System.Drawing.Color.MediumBlue;
            this.btnEnquiryRegister.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_task_planning_48__1_;
            this.btnEnquiryRegister.Location = new System.Drawing.Point(289, 103);
            this.btnEnquiryRegister.Name = "btnEnquiryRegister";
            this.btnEnquiryRegister.Size = new System.Drawing.Size(164, 76);
            this.btnEnquiryRegister.TabIndex = 31;
            this.btnEnquiryRegister.Text = "Enquiry Register";
            this.btnEnquiryRegister.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnEnquiryRegister.UseVisualStyleBackColor = true;
            this.btnEnquiryRegister.Click += new System.EventHandler(this.btnEnquiryRegister_Click);
            // 
            // btnCustomerVisit
            // 
            this.btnCustomerVisit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnCustomerVisit.Enabled = false;
            this.btnCustomerVisit.FlatAppearance.BorderSize = 0;
            this.btnCustomerVisit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCustomerVisit.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnCustomerVisit.ForeColor = System.Drawing.Color.MediumBlue;
            this.btnCustomerVisit.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_multichannel_48;
            this.btnCustomerVisit.Location = new System.Drawing.Point(592, 103);
            this.btnCustomerVisit.Name = "btnCustomerVisit";
            this.btnCustomerVisit.Size = new System.Drawing.Size(126, 76);
            this.btnCustomerVisit.TabIndex = 29;
            this.btnCustomerVisit.Text = "Customer Visit";
            this.btnCustomerVisit.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnCustomerVisit.UseVisualStyleBackColor = true;
            this.btnCustomerVisit.Click += new System.EventHandler(this.btnCustomerVisit_Click);
            // 
            // btnSalesQuote
            // 
            this.btnSalesQuote.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnSalesQuote.Enabled = false;
            this.btnSalesQuote.FlatAppearance.BorderSize = 0;
            this.btnSalesQuote.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalesQuote.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnSalesQuote.ForeColor = System.Drawing.Color.MediumBlue;
            this.btnSalesQuote.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_purchase_order_48;
            this.btnSalesQuote.Location = new System.Drawing.Point(39, 103);
            this.btnSalesQuote.Name = "btnSalesQuote";
            this.btnSalesQuote.Size = new System.Drawing.Size(156, 76);
            this.btnSalesQuote.TabIndex = 27;
            this.btnSalesQuote.Text = "Quote GEN";
            this.btnSalesQuote.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSalesQuote.UseVisualStyleBackColor = true;
            this.btnSalesQuote.Click += new System.EventHandler(this.btnSalesQuote_Click);
            // 
            // frmSalesHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1045, 509);
            this.Controls.Add(this.btnServiceQuote);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.btnOpportunity);
            this.Controls.Add(this.btnSalesProduct);
            this.Controls.Add(this.btnTestingQuote);
            this.Controls.Add(this.btnPegRate);
            this.Controls.Add(this.btnEnquiryRegister);
            this.Controls.Add(this.btnCustomerVisit);
            this.Controls.Add(this.btnSalesQuote);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmSalesHome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quote GEN";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmSalesHome_FormClosing);
            this.Load += new System.EventHandler(this.frmSalesHome_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSalesQuote;
        private System.Windows.Forms.Button btnCustomerVisit;
        private System.Windows.Forms.Button btnEnquiryRegister;
        private System.Windows.Forms.Button btnPegRate;
        private System.Windows.Forms.Button btnTestingQuote;
        private System.Windows.Forms.Button btnSalesProduct;
        private System.Windows.Forms.Button btnOpportunity;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Button btnServiceQuote;
    }
}