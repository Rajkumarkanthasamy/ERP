﻿namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    partial class frmQuoteViewItems
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmQuoteViewItems));
            this.lblFromdate = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.lblItemDescription = new System.Windows.Forms.Label();
            this.lblToDate = new System.Windows.Forms.Label();
            this.txtSearchText = new System.Windows.Forms.TextBox();
            this.dtpfromdate = new System.Windows.Forms.DateTimePicker();
            this.dtptodate = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvQuoteView = new System.Windows.Forms.DataGridView();
            this.View = new System.Windows.Forms.DataGridViewButtonColumn();
            this.QuotationNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RevisionNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Region = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Leadgenarated = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.QuoteName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EnquiryNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DateofEnquiry = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.QuotePreparedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.QuoteCreatedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.QuoteCompany = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.QuoteFor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.QuoteModel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.QuoteCapacity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.project8020 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LevelofCustomization = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnQuoteItemsView = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblRevision = new System.Windows.Forms.Label();
            this.lblQuoteNo = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.rbviewquoteowu = new System.Windows.Forms.RadioButton();
            this.rbviewquotewu = new System.Windows.Forms.RadioButton();
            this.rbviewquoteo = new System.Windows.Forms.RadioButton();
            this.rbViewQuote = new System.Windows.Forms.RadioButton();
            this.dgWriteUP = new System.Windows.Forms.DataGridView();
            this.WUSlNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WUProductcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WUDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgOIWriteUP = new System.Windows.Forms.DataGridView();
            this.DGOISlNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WUOIProductCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WUOIProductDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgQuoteBOM = new System.Windows.Forms.DataGridView();
            this.SLNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductGroup = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductCod = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SalesCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BreakupTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvOptionalItems = new System.Windows.Forms.DataGridView();
            this.OISLNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OIProductGroup = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OIProductCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OIProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OIProductDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OISalesCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OIQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OIUnitPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OITotalPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OIBreakupTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SP1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnExcel = new System.Windows.Forms.Button();
            this.txtBasicDemoPrice = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.chkBreakup = new System.Windows.Forms.CheckBox();
            this.label46 = new System.Windows.Forms.Label();
            this.txtTotalPrice = new System.Windows.Forms.TextBox();
            this.lblCST = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.txtJackup = new System.Windows.Forms.TextBox();
            this.txtQuoteRemain = new System.Windows.Forms.TextBox();
            this.txtQuoteBreak = new System.Windows.Forms.TextBox();
            this.txtQuoteJack = new System.Windows.Forms.TextBox();
            this.pnMainItems = new System.Windows.Forms.Panel();
            this.label64 = new System.Windows.Forms.Label();
            this.txtSystemMargin = new System.Windows.Forms.TextBox();
            this.btnSearchQuotenumbe = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuoteView)).BeginInit();
            this.pnQuoteItemsView.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgWriteUP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgOIWriteUP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgQuoteBOM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOptionalItems)).BeginInit();
            this.pnMainItems.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblFromdate
            // 
            this.lblFromdate.AutoSize = true;
            this.lblFromdate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblFromdate.Location = new System.Drawing.Point(4, 13);
            this.lblFromdate.Name = "lblFromdate";
            this.lblFromdate.Size = new System.Drawing.Size(52, 19);
            this.lblFromdate.TabIndex = 143;
            this.lblFromdate.Text = "From :";
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(317, 5);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(61, 34);
            this.btnSearch.TabIndex = 147;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // lblItemDescription
            // 
            this.lblItemDescription.AutoSize = true;
            this.lblItemDescription.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemDescription.Location = new System.Drawing.Point(872, 1);
            this.lblItemDescription.Name = "lblItemDescription";
            this.lblItemDescription.Size = new System.Drawing.Size(538, 38);
            this.lblItemDescription.TabIndex = 151;
            this.lblItemDescription.Text = "Search includes : QuotationNumber,QuoteModel,QuoteCapacity,QuoteName,\r\nCustomerNa" +
    "me,QuotePreparedBy and QuoteCompany\r\n";
            // 
            // lblToDate
            // 
            this.lblToDate.AutoSize = true;
            this.lblToDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblToDate.Location = new System.Drawing.Point(173, 13);
            this.lblToDate.Name = "lblToDate";
            this.lblToDate.Size = new System.Drawing.Size(33, 19);
            this.lblToDate.TabIndex = 144;
            this.lblToDate.Text = "To :";
            // 
            // txtSearchText
            // 
            this.txtSearchText.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchText.Location = new System.Drawing.Point(516, 12);
            this.txtSearchText.Name = "txtSearchText";
            this.txtSearchText.Size = new System.Drawing.Size(299, 27);
            this.txtSearchText.TabIndex = 150;
            this.txtSearchText.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtSearchText_KeyUp);
            // 
            // dtpfromdate
            // 
            this.dtpfromdate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.dtpfromdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpfromdate.Location = new System.Drawing.Point(56, 7);
            this.dtpfromdate.Name = "dtpfromdate";
            this.dtpfromdate.Size = new System.Drawing.Size(111, 27);
            this.dtpfromdate.TabIndex = 145;
            // 
            // dtptodate
            // 
            this.dtptodate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.dtptodate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtptodate.Location = new System.Drawing.Point(206, 9);
            this.dtptodate.Name = "dtptodate";
            this.dtptodate.Size = new System.Drawing.Size(105, 27);
            this.dtptodate.TabIndex = 146;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(451, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 19);
            this.label1.TabIndex = 149;
            this.label1.Text = "Search :";
            // 
            // dgvQuoteView
            // 
            this.dgvQuoteView.AllowUserToAddRows = false;
            this.dgvQuoteView.AllowUserToDeleteRows = false;
            this.dgvQuoteView.AllowUserToOrderColumns = true;
            this.dgvQuoteView.AllowUserToResizeRows = false;
            this.dgvQuoteView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvQuoteView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvQuoteView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvQuoteView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.View,
            this.QuotationNumber,
            this.RevisionNumber,
            this.Region,
            this.Leadgenarated,
            this.QuoteName,
            this.CustomerName,
            this.EnquiryNumber,
            this.DateofEnquiry,
            this.QuotePreparedBy,
            this.QuoteCreatedDate,
            this.QuoteCompany,
            this.QuoteFor,
            this.QuoteModel,
            this.QuoteCapacity,
            this.project8020,
            this.LevelofCustomization});
            this.dgvQuoteView.EnableHeadersVisualStyles = false;
            this.dgvQuoteView.Location = new System.Drawing.Point(12, 48);
            this.dgvQuoteView.Name = "dgvQuoteView";
            this.dgvQuoteView.ReadOnly = true;
            this.dgvQuoteView.RowHeadersVisible = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvQuoteView.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvQuoteView.Size = new System.Drawing.Size(1303, 542);
            this.dgvQuoteView.TabIndex = 148;
            this.dgvQuoteView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvQuoteView_CellClick);
            this.dgvQuoteView.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvQuoteView_CellMouseDoubleClick);
            // 
            // View
            // 
            this.View.HeaderText = "View";
            this.View.Name = "View";
            this.View.ReadOnly = true;
            this.View.Width = 48;
            // 
            // QuotationNumber
            // 
            this.QuotationNumber.DataPropertyName = "QuotationNumber";
            this.QuotationNumber.HeaderText = "Quote No";
            this.QuotationNumber.Name = "QuotationNumber";
            this.QuotationNumber.ReadOnly = true;
            this.QuotationNumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.QuotationNumber.Width = 74;
            // 
            // RevisionNumber
            // 
            this.RevisionNumber.DataPropertyName = "RevisionNumber";
            this.RevisionNumber.HeaderText = "Rev No";
            this.RevisionNumber.Name = "RevisionNumber";
            this.RevisionNumber.ReadOnly = true;
            this.RevisionNumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RevisionNumber.Width = 40;
            // 
            // Region
            // 
            this.Region.DataPropertyName = "QuoteModel";
            this.Region.HeaderText = "Quote Model";
            this.Region.Name = "Region";
            this.Region.ReadOnly = true;
            this.Region.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Region.Width = 95;
            // 
            // Leadgenarated
            // 
            this.Leadgenarated.DataPropertyName = "QuoteCapacity";
            this.Leadgenarated.HeaderText = "Quote Capacity";
            this.Leadgenarated.Name = "Leadgenarated";
            this.Leadgenarated.ReadOnly = true;
            this.Leadgenarated.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Leadgenarated.Width = 108;
            // 
            // QuoteName
            // 
            this.QuoteName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.QuoteName.DataPropertyName = "QuoteName";
            this.QuoteName.HeaderText = "Quote Name";
            this.QuoteName.Name = "QuoteName";
            this.QuoteName.ReadOnly = true;
            this.QuoteName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.QuoteName.Width = 92;
            // 
            // CustomerName
            // 
            this.CustomerName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.CustomerName.DataPropertyName = "CustomerName";
            this.CustomerName.HeaderText = "Customer";
            this.CustomerName.Name = "CustomerName";
            this.CustomerName.ReadOnly = true;
            this.CustomerName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CustomerName.Width = 80;
            // 
            // EnquiryNumber
            // 
            this.EnquiryNumber.DataPropertyName = "EnquiryNumber";
            this.EnquiryNumber.HeaderText = "Enquiry Number";
            this.EnquiryNumber.Name = "EnquiryNumber";
            this.EnquiryNumber.ReadOnly = true;
            this.EnquiryNumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.EnquiryNumber.Width = 115;
            // 
            // DateofEnquiry
            // 
            this.DateofEnquiry.DataPropertyName = "DateofEnquiry";
            this.DateofEnquiry.HeaderText = "Date of Enquiry";
            this.DateofEnquiry.Name = "DateofEnquiry";
            this.DateofEnquiry.ReadOnly = true;
            this.DateofEnquiry.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DateofEnquiry.Width = 110;
            // 
            // QuotePreparedBy
            // 
            this.QuotePreparedBy.DataPropertyName = "QuotePreparedBy";
            this.QuotePreparedBy.HeaderText = "Quote Prepared By";
            this.QuotePreparedBy.Name = "QuotePreparedBy";
            this.QuotePreparedBy.ReadOnly = true;
            this.QuotePreparedBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.QuotePreparedBy.Width = 116;
            // 
            // QuoteCreatedDate
            // 
            this.QuoteCreatedDate.DataPropertyName = "QuoteCreatedDate";
            this.QuoteCreatedDate.HeaderText = "Quote Created Date";
            this.QuoteCreatedDate.Name = "QuoteCreatedDate";
            this.QuoteCreatedDate.ReadOnly = true;
            this.QuoteCreatedDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.QuoteCreatedDate.Width = 107;
            // 
            // QuoteCompany
            // 
            this.QuoteCompany.DataPropertyName = "QuoteCompany";
            this.QuoteCompany.HeaderText = "Quote Company";
            this.QuoteCompany.Name = "QuoteCompany";
            this.QuoteCompany.ReadOnly = true;
            this.QuoteCompany.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.QuoteCompany.Width = 113;
            // 
            // QuoteFor
            // 
            this.QuoteFor.DataPropertyName = "QuoteFor";
            this.QuoteFor.HeaderText = "Quote System";
            this.QuoteFor.Name = "QuoteFor";
            this.QuoteFor.ReadOnly = true;
            this.QuoteFor.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // QuoteModel
            // 
            this.QuoteModel.DataPropertyName = "QuoteModel";
            this.QuoteModel.HeaderText = "Quote Model";
            this.QuoteModel.Name = "QuoteModel";
            this.QuoteModel.ReadOnly = true;
            this.QuoteModel.Width = 114;
            // 
            // QuoteCapacity
            // 
            this.QuoteCapacity.DataPropertyName = "QuoteCapacity";
            this.QuoteCapacity.HeaderText = "Quote Capacity";
            this.QuoteCapacity.Name = "QuoteCapacity";
            this.QuoteCapacity.ReadOnly = true;
            this.QuoteCapacity.Width = 127;
            // 
            // project8020
            // 
            this.project8020.DataPropertyName = "project8020";
            this.project8020.HeaderText = "project 80/20";
            this.project8020.Name = "project8020";
            this.project8020.ReadOnly = true;
            this.project8020.Width = 115;
            // 
            // LevelofCustomization
            // 
            this.LevelofCustomization.DataPropertyName = "LevelofCustomization";
            this.LevelofCustomization.HeaderText = "Level of Customization";
            this.LevelofCustomization.Name = "LevelofCustomization";
            this.LevelofCustomization.ReadOnly = true;
            this.LevelofCustomization.Width = 170;
            // 
            // pnQuoteItemsView
            // 
            this.pnQuoteItemsView.Controls.Add(this.groupBox1);
            this.pnQuoteItemsView.Controls.Add(this.dgWriteUP);
            this.pnQuoteItemsView.Controls.Add(this.dgOIWriteUP);
            this.pnQuoteItemsView.Controls.Add(this.dgQuoteBOM);
            this.pnQuoteItemsView.Controls.Add(this.dgvOptionalItems);
            this.pnQuoteItemsView.Location = new System.Drawing.Point(12, 48);
            this.pnQuoteItemsView.Name = "pnQuoteItemsView";
            this.pnQuoteItemsView.Size = new System.Drawing.Size(1303, 542);
            this.pnQuoteItemsView.TabIndex = 152;
            this.pnQuoteItemsView.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblRevision);
            this.groupBox1.Controls.Add(this.lblQuoteNo);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.btnClose);
            this.groupBox1.Controls.Add(this.rbviewquoteowu);
            this.groupBox1.Controls.Add(this.rbviewquotewu);
            this.groupBox1.Controls.Add(this.rbviewquoteo);
            this.groupBox1.Controls.Add(this.rbViewQuote);
            this.groupBox1.Location = new System.Drawing.Point(10, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1284, 75);
            this.groupBox1.TabIndex = 220;
            this.groupBox1.TabStop = false;
            // 
            // lblRevision
            // 
            this.lblRevision.AutoSize = true;
            this.lblRevision.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRevision.ForeColor = System.Drawing.Color.Red;
            this.lblRevision.Location = new System.Drawing.Point(87, 46);
            this.lblRevision.Name = "lblRevision";
            this.lblRevision.Size = new System.Drawing.Size(20, 19);
            this.lblRevision.TabIndex = 226;
            this.lblRevision.Text = "Q";
            // 
            // lblQuoteNo
            // 
            this.lblQuoteNo.AutoSize = true;
            this.lblQuoteNo.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuoteNo.ForeColor = System.Drawing.Color.Red;
            this.lblQuoteNo.Location = new System.Drawing.Point(87, 17);
            this.lblQuoteNo.Name = "lblQuoteNo";
            this.lblQuoteNo.Size = new System.Drawing.Size(20, 19);
            this.lblQuoteNo.TabIndex = 225;
            this.lblQuoteNo.Text = "Q";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(16, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 19);
            this.label3.TabIndex = 224;
            this.label3.Text = "Revision :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(6, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 19);
            this.label2.TabIndex = 223;
            this.label2.Text = "Quote No :";
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.Color.Red;
            this.btnClose.Location = new System.Drawing.Point(932, 33);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(61, 34);
            this.btnClose.TabIndex = 221;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // rbviewquoteowu
            // 
            this.rbviewquoteowu.AutoSize = true;
            this.rbviewquoteowu.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.rbviewquoteowu.Location = new System.Drawing.Point(481, 44);
            this.rbviewquoteowu.Name = "rbviewquoteowu";
            this.rbviewquoteowu.Size = new System.Drawing.Size(240, 23);
            this.rbviewquoteowu.TabIndex = 222;
            this.rbviewquoteowu.TabStop = true;
            this.rbviewquoteowu.Text = "Write UP Optional Quote Items";
            this.rbviewquoteowu.UseVisualStyleBackColor = true;
            this.rbviewquoteowu.CheckedChanged += new System.EventHandler(this.rbviewquoteowu_CheckedChanged);
            // 
            // rbviewquotewu
            // 
            this.rbviewquotewu.AutoSize = true;
            this.rbviewquotewu.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.rbviewquotewu.Location = new System.Drawing.Point(267, 44);
            this.rbviewquotewu.Name = "rbviewquotewu";
            this.rbviewquotewu.Size = new System.Drawing.Size(177, 23);
            this.rbviewquotewu.TabIndex = 221;
            this.rbviewquotewu.TabStop = true;
            this.rbviewquotewu.Text = "Write UP Quote Items";
            this.rbviewquotewu.UseVisualStyleBackColor = true;
            this.rbviewquotewu.CheckedChanged += new System.EventHandler(this.rbviewquotewu_CheckedChanged);
            // 
            // rbviewquoteo
            // 
            this.rbviewquoteo.AutoSize = true;
            this.rbviewquoteo.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.rbviewquoteo.Location = new System.Drawing.Point(481, 15);
            this.rbviewquoteo.Name = "rbviewquoteo";
            this.rbviewquoteo.Size = new System.Drawing.Size(211, 23);
            this.rbviewquoteo.TabIndex = 220;
            this.rbviewquoteo.TabStop = true;
            this.rbviewquoteo.Text = "View Optional Quote Items";
            this.rbviewquoteo.UseVisualStyleBackColor = true;
            this.rbviewquoteo.CheckedChanged += new System.EventHandler(this.rbviewquoteo_CheckedChanged);
            // 
            // rbViewQuote
            // 
            this.rbViewQuote.AutoSize = true;
            this.rbViewQuote.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.rbViewQuote.Location = new System.Drawing.Point(267, 15);
            this.rbViewQuote.Name = "rbViewQuote";
            this.rbViewQuote.Size = new System.Drawing.Size(148, 23);
            this.rbViewQuote.TabIndex = 219;
            this.rbViewQuote.TabStop = true;
            this.rbViewQuote.Text = "View Quote Items";
            this.rbViewQuote.UseVisualStyleBackColor = true;
            this.rbViewQuote.CheckedChanged += new System.EventHandler(this.rbViewQuote_CheckedChanged);
            // 
            // dgWriteUP
            // 
            this.dgWriteUP.AllowUserToAddRows = false;
            this.dgWriteUP.AllowUserToDeleteRows = false;
            this.dgWriteUP.AllowUserToResizeRows = false;
            this.dgWriteUP.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgWriteUP.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgWriteUP.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgWriteUP.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgWriteUP.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgWriteUP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgWriteUP.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.WUSlNo,
            this.WUProductcode,
            this.WUDescription,
            this.dataGridViewTextBoxColumn4});
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgWriteUP.DefaultCellStyle = dataGridViewCellStyle7;
            this.dgWriteUP.EnableHeadersVisualStyles = false;
            this.dgWriteUP.Location = new System.Drawing.Point(1, 84);
            this.dgWriteUP.MultiSelect = false;
            this.dgWriteUP.Name = "dgWriteUP";
            this.dgWriteUP.RowHeadersVisible = false;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgWriteUP.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.dgWriteUP.Size = new System.Drawing.Size(1296, 448);
            this.dgWriteUP.TabIndex = 215;
            // 
            // WUSlNo
            // 
            this.WUSlNo.DataPropertyName = "GroupID";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle4.NullValue = null;
            this.WUSlNo.DefaultCellStyle = dataGridViewCellStyle4;
            this.WUSlNo.HeaderText = "S.No";
            this.WUSlNo.Name = "WUSlNo";
            this.WUSlNo.ReadOnly = true;
            this.WUSlNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.WUSlNo.Width = 47;
            // 
            // WUProductcode
            // 
            this.WUProductcode.DataPropertyName = "ProductCode";
            this.WUProductcode.HeaderText = "Product Code";
            this.WUProductcode.Name = "WUProductcode";
            this.WUProductcode.ReadOnly = true;
            this.WUProductcode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.WUProductcode.Visible = false;
            this.WUProductcode.Width = 108;
            // 
            // WUDescription
            // 
            this.WUDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.WUDescription.DataPropertyName = "ProductDescription";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.WUDescription.DefaultCellStyle = dataGridViewCellStyle5;
            this.WUDescription.HeaderText = "Description";
            this.WUDescription.Name = "WUDescription";
            this.WUDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Quantity";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridViewTextBoxColumn4.HeaderText = "Qty";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn4.Width = 40;
            // 
            // dgOIWriteUP
            // 
            this.dgOIWriteUP.AllowUserToAddRows = false;
            this.dgOIWriteUP.AllowUserToDeleteRows = false;
            this.dgOIWriteUP.AllowUserToResizeRows = false;
            this.dgOIWriteUP.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgOIWriteUP.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgOIWriteUP.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgOIWriteUP.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgOIWriteUP.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgOIWriteUP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgOIWriteUP.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DGOISlNo,
            this.WUOIProductCode,
            this.WUOIProductDescription,
            this.dataGridViewTextBoxColumn6});
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgOIWriteUP.DefaultCellStyle = dataGridViewCellStyle13;
            this.dgOIWriteUP.EnableHeadersVisualStyles = false;
            this.dgOIWriteUP.Location = new System.Drawing.Point(1, 84);
            this.dgOIWriteUP.MultiSelect = false;
            this.dgOIWriteUP.Name = "dgOIWriteUP";
            this.dgOIWriteUP.RowHeadersVisible = false;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgOIWriteUP.RowsDefaultCellStyle = dataGridViewCellStyle14;
            this.dgOIWriteUP.Size = new System.Drawing.Size(1296, 448);
            this.dgOIWriteUP.TabIndex = 218;
            // 
            // DGOISlNo
            // 
            this.DGOISlNo.DataPropertyName = "GroupID";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            this.DGOISlNo.DefaultCellStyle = dataGridViewCellStyle10;
            this.DGOISlNo.HeaderText = "S.No";
            this.DGOISlNo.Name = "DGOISlNo";
            this.DGOISlNo.ReadOnly = true;
            this.DGOISlNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DGOISlNo.Width = 47;
            // 
            // WUOIProductCode
            // 
            this.WUOIProductCode.DataPropertyName = "ProductCode";
            this.WUOIProductCode.HeaderText = "Product Code";
            this.WUOIProductCode.Name = "WUOIProductCode";
            this.WUOIProductCode.ReadOnly = true;
            this.WUOIProductCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.WUOIProductCode.Visible = false;
            this.WUOIProductCode.Width = 108;
            // 
            // WUOIProductDescription
            // 
            this.WUOIProductDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.WUOIProductDescription.DataPropertyName = "ProductDescription";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.WUOIProductDescription.DefaultCellStyle = dataGridViewCellStyle11;
            this.WUOIProductDescription.HeaderText = "Description";
            this.WUOIProductDescription.Name = "WUOIProductDescription";
            this.WUOIProductDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Quantity";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn6.DefaultCellStyle = dataGridViewCellStyle12;
            this.dataGridViewTextBoxColumn6.HeaderText = "Qty";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn6.Width = 40;
            // 
            // dgQuoteBOM
            // 
            this.dgQuoteBOM.AllowUserToAddRows = false;
            this.dgQuoteBOM.AllowUserToDeleteRows = false;
            this.dgQuoteBOM.AllowUserToResizeRows = false;
            this.dgQuoteBOM.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dgQuoteBOM.BackgroundColor = System.Drawing.SystemColors.ControlDark;
            this.dgQuoteBOM.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgQuoteBOM.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgQuoteBOM.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.dgQuoteBOM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgQuoteBOM.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SLNO,
            this.ProductGroup,
            this.ProductCod,
            this.ProductName,
            this.Description,
            this.SalesCost,
            this.Quantity,
            this.UnitPrice,
            this.TPrice,
            this.BreakupTotal,
            this.SP});
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgQuoteBOM.DefaultCellStyle = dataGridViewCellStyle22;
            this.dgQuoteBOM.EnableHeadersVisualStyles = false;
            this.dgQuoteBOM.Location = new System.Drawing.Point(1, 84);
            this.dgQuoteBOM.MultiSelect = false;
            this.dgQuoteBOM.Name = "dgQuoteBOM";
            this.dgQuoteBOM.RowHeadersVisible = false;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgQuoteBOM.RowsDefaultCellStyle = dataGridViewCellStyle23;
            this.dgQuoteBOM.Size = new System.Drawing.Size(1296, 448);
            this.dgQuoteBOM.TabIndex = 211;
            // 
            // SLNO
            // 
            this.SLNO.DataPropertyName = "GroupID";
            this.SLNO.HeaderText = "SlNo";
            this.SLNO.Name = "SLNO";
            this.SLNO.ReadOnly = true;
            this.SLNO.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SLNO.Width = 47;
            // 
            // ProductGroup
            // 
            this.ProductGroup.DataPropertyName = "ProductGroup";
            this.ProductGroup.HeaderText = "ProductGroup";
            this.ProductGroup.Name = "ProductGroup";
            this.ProductGroup.ReadOnly = true;
            this.ProductGroup.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductGroup.Visible = false;
            this.ProductGroup.Width = 113;
            // 
            // ProductCod
            // 
            this.ProductCod.DataPropertyName = "ProductCode";
            this.ProductCod.HeaderText = "ProductCode";
            this.ProductCod.Name = "ProductCod";
            this.ProductCod.ReadOnly = true;
            this.ProductCod.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductCod.Width = 104;
            // 
            // ProductName
            // 
            this.ProductName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ProductName.DataPropertyName = "ProductName";
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ProductName.DefaultCellStyle = dataGridViewCellStyle16;
            this.ProductName.HeaderText = "Product Name";
            this.ProductName.Name = "ProductName";
            this.ProductName.ReadOnly = true;
            this.ProductName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Description
            // 
            this.Description.DataPropertyName = "ProductDescription";
            this.Description.HeaderText = "Description";
            this.Description.Name = "Description";
            this.Description.ReadOnly = true;
            this.Description.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Description.Visible = false;
            this.Description.Width = 92;
            // 
            // SalesCost
            // 
            this.SalesCost.DataPropertyName = "SalesCost";
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle17.Format = "N0";
            dataGridViewCellStyle17.NullValue = null;
            this.SalesCost.DefaultCellStyle = dataGridViewCellStyle17;
            this.SalesCost.HeaderText = "Sales Cost";
            this.SalesCost.Name = "SalesCost";
            this.SalesCost.ReadOnly = true;
            this.SalesCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SalesCost.Visible = false;
            this.SalesCost.Width = 82;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "Quantity";
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Quantity.DefaultCellStyle = dataGridViewCellStyle18;
            this.Quantity.HeaderText = "Qty";
            this.Quantity.Name = "Quantity";
            this.Quantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Quantity.Width = 40;
            // 
            // UnitPrice
            // 
            this.UnitPrice.DataPropertyName = "UnitPrice";
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle19.Format = "N0";
            dataGridViewCellStyle19.NullValue = null;
            this.UnitPrice.DefaultCellStyle = dataGridViewCellStyle19;
            this.UnitPrice.HeaderText = "Unit Price";
            this.UnitPrice.Name = "UnitPrice";
            this.UnitPrice.ReadOnly = true;
            this.UnitPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitPrice.Width = 82;
            // 
            // TPrice
            // 
            this.TPrice.DataPropertyName = "TotalPrice";
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle20.Format = "N0";
            dataGridViewCellStyle20.NullValue = null;
            this.TPrice.DefaultCellStyle = dataGridViewCellStyle20;
            this.TPrice.HeaderText = "Total Price";
            this.TPrice.Name = "TPrice";
            this.TPrice.ReadOnly = true;
            this.TPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.TPrice.Width = 87;
            // 
            // BreakupTotal
            // 
            this.BreakupTotal.DataPropertyName = "BreakupTotal";
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle21.Format = "N0";
            dataGridViewCellStyle21.NullValue = null;
            this.BreakupTotal.DefaultCellStyle = dataGridViewCellStyle21;
            this.BreakupTotal.HeaderText = "BreakUp Price";
            this.BreakupTotal.Name = "BreakupTotal";
            this.BreakupTotal.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.BreakupTotal.Visible = false;
            this.BreakupTotal.Width = 111;
            // 
            // SP
            // 
            this.SP.DataPropertyName = "ShowPrice";
            this.SP.HeaderText = "SP";
            this.SP.Name = "SP";
            this.SP.ReadOnly = true;
            this.SP.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SP.Width = 32;
            // 
            // dgvOptionalItems
            // 
            this.dgvOptionalItems.AllowUserToAddRows = false;
            this.dgvOptionalItems.AllowUserToDeleteRows = false;
            this.dgvOptionalItems.AllowUserToResizeRows = false;
            this.dgvOptionalItems.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dgvOptionalItems.BackgroundColor = System.Drawing.SystemColors.ControlDark;
            this.dgvOptionalItems.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvOptionalItems.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle24.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvOptionalItems.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle24;
            this.dgvOptionalItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOptionalItems.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.OISLNo,
            this.OIProductGroup,
            this.OIProductCode,
            this.OIProductName,
            this.OIProductDescription,
            this.OISalesCost,
            this.OIQuantity,
            this.OIUnitPrice,
            this.OITotalPrice,
            this.OIBreakupTotal,
            this.SP1});
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle32.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle32.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle32.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle32.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle32.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle32.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvOptionalItems.DefaultCellStyle = dataGridViewCellStyle32;
            this.dgvOptionalItems.EnableHeadersVisualStyles = false;
            this.dgvOptionalItems.Location = new System.Drawing.Point(1, 84);
            this.dgvOptionalItems.MultiSelect = false;
            this.dgvOptionalItems.Name = "dgvOptionalItems";
            this.dgvOptionalItems.RowHeadersVisible = false;
            dataGridViewCellStyle33.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvOptionalItems.RowsDefaultCellStyle = dataGridViewCellStyle33;
            this.dgvOptionalItems.Size = new System.Drawing.Size(1296, 448);
            this.dgvOptionalItems.TabIndex = 214;
            // 
            // OISLNo
            // 
            this.OISLNo.DataPropertyName = "GroupID";
            this.OISLNo.HeaderText = "Slno";
            this.OISLNo.Name = "OISLNo";
            this.OISLNo.ReadOnly = true;
            this.OISLNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OISLNo.Width = 45;
            // 
            // OIProductGroup
            // 
            this.OIProductGroup.DataPropertyName = "ProductGroup";
            this.OIProductGroup.HeaderText = "ProductGroup";
            this.OIProductGroup.Name = "OIProductGroup";
            this.OIProductGroup.ReadOnly = true;
            this.OIProductGroup.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OIProductGroup.Visible = false;
            this.OIProductGroup.Width = 113;
            // 
            // OIProductCode
            // 
            this.OIProductCode.DataPropertyName = "ProductCode";
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.OIProductCode.DefaultCellStyle = dataGridViewCellStyle25;
            this.OIProductCode.HeaderText = "Product Code";
            this.OIProductCode.Name = "OIProductCode";
            this.OIProductCode.ReadOnly = true;
            this.OIProductCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OIProductCode.Width = 108;
            // 
            // OIProductName
            // 
            this.OIProductName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.OIProductName.DataPropertyName = "ProductName";
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.OIProductName.DefaultCellStyle = dataGridViewCellStyle26;
            this.OIProductName.HeaderText = "Product Name";
            this.OIProductName.Name = "OIProductName";
            this.OIProductName.ReadOnly = true;
            this.OIProductName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // OIProductDescription
            // 
            this.OIProductDescription.DataPropertyName = "ProductDescription";
            this.OIProductDescription.HeaderText = "Description";
            this.OIProductDescription.Name = "OIProductDescription";
            this.OIProductDescription.ReadOnly = true;
            this.OIProductDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OIProductDescription.Visible = false;
            this.OIProductDescription.Width = 92;
            // 
            // OISalesCost
            // 
            this.OISalesCost.DataPropertyName = "SalesCost";
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle27.Format = "N0";
            dataGridViewCellStyle27.NullValue = null;
            this.OISalesCost.DefaultCellStyle = dataGridViewCellStyle27;
            this.OISalesCost.HeaderText = "Production Cost";
            this.OISalesCost.Name = "OISalesCost";
            this.OISalesCost.ReadOnly = true;
            this.OISalesCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OISalesCost.Visible = false;
            this.OISalesCost.Width = 124;
            // 
            // OIQuantity
            // 
            this.OIQuantity.DataPropertyName = "Quantity";
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.OIQuantity.DefaultCellStyle = dataGridViewCellStyle28;
            this.OIQuantity.HeaderText = "Qty";
            this.OIQuantity.Name = "OIQuantity";
            this.OIQuantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OIQuantity.Width = 40;
            // 
            // OIUnitPrice
            // 
            this.OIUnitPrice.DataPropertyName = "UnitPrice";
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle29.Format = "N0";
            dataGridViewCellStyle29.NullValue = null;
            this.OIUnitPrice.DefaultCellStyle = dataGridViewCellStyle29;
            this.OIUnitPrice.HeaderText = "Unit Price";
            this.OIUnitPrice.Name = "OIUnitPrice";
            this.OIUnitPrice.ReadOnly = true;
            this.OIUnitPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OIUnitPrice.Width = 82;
            // 
            // OITotalPrice
            // 
            this.OITotalPrice.DataPropertyName = "TotalPrice";
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle30.Format = "N0";
            dataGridViewCellStyle30.NullValue = null;
            this.OITotalPrice.DefaultCellStyle = dataGridViewCellStyle30;
            this.OITotalPrice.HeaderText = "Total Price";
            this.OITotalPrice.Name = "OITotalPrice";
            this.OITotalPrice.ReadOnly = true;
            this.OITotalPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OITotalPrice.Width = 87;
            // 
            // OIBreakupTotal
            // 
            this.OIBreakupTotal.DataPropertyName = "BreakupTotal";
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle31.Format = "N0";
            dataGridViewCellStyle31.NullValue = null;
            this.OIBreakupTotal.DefaultCellStyle = dataGridViewCellStyle31;
            this.OIBreakupTotal.HeaderText = "Breakup Price";
            this.OIBreakupTotal.Name = "OIBreakupTotal";
            this.OIBreakupTotal.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OIBreakupTotal.Visible = false;
            this.OIBreakupTotal.Width = 110;
            // 
            // SP1
            // 
            this.SP1.DataPropertyName = "ShowPrice";
            this.SP1.HeaderText = "SP";
            this.SP1.Name = "SP1";
            this.SP1.ReadOnly = true;
            this.SP1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SP1.Width = 32;
            // 
            // btnExcel
            // 
            this.btnExcel.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcel.Location = new System.Drawing.Point(392, 5);
            this.btnExcel.Name = "btnExcel";
            this.btnExcel.Size = new System.Drawing.Size(61, 34);
            this.btnExcel.TabIndex = 153;
            this.btnExcel.Text = "Excel";
            this.btnExcel.UseVisualStyleBackColor = true;
            this.btnExcel.Click += new System.EventHandler(this.btnExcel_Click);
            // 
            // txtBasicDemoPrice
            // 
            this.txtBasicDemoPrice.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtBasicDemoPrice.Location = new System.Drawing.Point(687, 67);
            this.txtBasicDemoPrice.Name = "txtBasicDemoPrice";
            this.txtBasicDemoPrice.ReadOnly = true;
            this.txtBasicDemoPrice.Size = new System.Drawing.Size(178, 26);
            this.txtBasicDemoPrice.TabIndex = 228;
            this.txtBasicDemoPrice.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(515, 70);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(170, 18);
            this.label8.TabIndex = 227;
            this.label8.Text = "Basic Price of The System :";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Black;
            this.label22.Location = new System.Drawing.Point(529, 10);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(155, 18);
            this.label22.TabIndex = 219;
            this.label22.Text = "Selling Price of System :";
            // 
            // chkBreakup
            // 
            this.chkBreakup.AutoSize = true;
            this.chkBreakup.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBreakup.ForeColor = System.Drawing.Color.DarkBlue;
            this.chkBreakup.Location = new System.Drawing.Point(738, 36);
            this.chkBreakup.Name = "chkBreakup";
            this.chkBreakup.Size = new System.Drawing.Size(145, 27);
            this.chkBreakup.TabIndex = 223;
            this.chkBreakup.Text = "Break Up Price";
            this.chkBreakup.UseVisualStyleBackColor = true;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label46.ForeColor = System.Drawing.Color.Black;
            this.label46.Location = new System.Drawing.Point(959, 69);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(83, 19);
            this.label46.TabIndex = 226;
            this.label46.Text = "Difference:";
            // 
            // txtTotalPrice
            // 
            this.txtTotalPrice.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtTotalPrice.Location = new System.Drawing.Point(687, 6);
            this.txtTotalPrice.Name = "txtTotalPrice";
            this.txtTotalPrice.ReadOnly = true;
            this.txtTotalPrice.Size = new System.Drawing.Size(178, 26);
            this.txtTotalPrice.TabIndex = 216;
            this.txtTotalPrice.Text = "0";
            // 
            // lblCST
            // 
            this.lblCST.AutoSize = true;
            this.lblCST.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.lblCST.ForeColor = System.Drawing.Color.Black;
            this.lblCST.Location = new System.Drawing.Point(540, 41);
            this.lblCST.Name = "lblCST";
            this.lblCST.Size = new System.Drawing.Size(142, 18);
            this.lblCST.TabIndex = 215;
            this.lblCST.Text = "Negotiation Cushion :";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label45.ForeColor = System.Drawing.Color.Black;
            this.label45.Location = new System.Drawing.Point(891, 40);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(151, 19);
            this.label45.TabIndex = 225;
            this.label45.Text = "Break Up Total Price:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(717, 42);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(22, 18);
            this.label13.TabIndex = 218;
            this.label13.Text = "%";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label44.ForeColor = System.Drawing.Color.Black;
            this.label44.Location = new System.Drawing.Point(902, 8);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(140, 19);
            this.label44.TabIndex = 224;
            this.label44.Text = "Jack Up Total Price:";
            // 
            // txtJackup
            // 
            this.txtJackup.BackColor = System.Drawing.Color.White;
            this.txtJackup.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtJackup.Location = new System.Drawing.Point(687, 37);
            this.txtJackup.Name = "txtJackup";
            this.txtJackup.Size = new System.Drawing.Size(30, 26);
            this.txtJackup.TabIndex = 217;
            this.txtJackup.Text = "0";
            // 
            // txtQuoteRemain
            // 
            this.txtQuoteRemain.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtQuoteRemain.Location = new System.Drawing.Point(1044, 67);
            this.txtQuoteRemain.Name = "txtQuoteRemain";
            this.txtQuoteRemain.ReadOnly = true;
            this.txtQuoteRemain.Size = new System.Drawing.Size(156, 26);
            this.txtQuoteRemain.TabIndex = 222;
            this.txtQuoteRemain.Text = "0";
            // 
            // txtQuoteBreak
            // 
            this.txtQuoteBreak.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtQuoteBreak.Location = new System.Drawing.Point(1044, 36);
            this.txtQuoteBreak.Name = "txtQuoteBreak";
            this.txtQuoteBreak.ReadOnly = true;
            this.txtQuoteBreak.Size = new System.Drawing.Size(156, 26);
            this.txtQuoteBreak.TabIndex = 221;
            this.txtQuoteBreak.Text = "0";
            // 
            // txtQuoteJack
            // 
            this.txtQuoteJack.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtQuoteJack.Location = new System.Drawing.Point(1044, 6);
            this.txtQuoteJack.Name = "txtQuoteJack";
            this.txtQuoteJack.ReadOnly = true;
            this.txtQuoteJack.Size = new System.Drawing.Size(156, 26);
            this.txtQuoteJack.TabIndex = 220;
            this.txtQuoteJack.Text = "0";
            // 
            // pnMainItems
            // 
            this.pnMainItems.Controls.Add(this.label64);
            this.pnMainItems.Controls.Add(this.txtSystemMargin);
            this.pnMainItems.Controls.Add(this.txtBasicDemoPrice);
            this.pnMainItems.Controls.Add(this.txtQuoteJack);
            this.pnMainItems.Controls.Add(this.label8);
            this.pnMainItems.Controls.Add(this.txtQuoteBreak);
            this.pnMainItems.Controls.Add(this.label22);
            this.pnMainItems.Controls.Add(this.txtQuoteRemain);
            this.pnMainItems.Controls.Add(this.chkBreakup);
            this.pnMainItems.Controls.Add(this.txtJackup);
            this.pnMainItems.Controls.Add(this.label46);
            this.pnMainItems.Controls.Add(this.label44);
            this.pnMainItems.Controls.Add(this.txtTotalPrice);
            this.pnMainItems.Controls.Add(this.label13);
            this.pnMainItems.Controls.Add(this.lblCST);
            this.pnMainItems.Controls.Add(this.label45);
            this.pnMainItems.Location = new System.Drawing.Point(13, 596);
            this.pnMainItems.Name = "pnMainItems";
            this.pnMainItems.Size = new System.Drawing.Size(1226, 100);
            this.pnMainItems.TabIndex = 221;
            this.pnMainItems.Visible = false;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label64.Location = new System.Drawing.Point(95, 33);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(152, 26);
            this.label64.TabIndex = 229;
            this.label64.Text = "System Margin :";
            // 
            // txtSystemMargin
            // 
            this.txtSystemMargin.BackColor = System.Drawing.Color.White;
            this.txtSystemMargin.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSystemMargin.Location = new System.Drawing.Point(246, 31);
            this.txtSystemMargin.Name = "txtSystemMargin";
            this.txtSystemMargin.ReadOnly = true;
            this.txtSystemMargin.Size = new System.Drawing.Size(96, 31);
            this.txtSystemMargin.TabIndex = 230;
            this.txtSystemMargin.Text = "0";
            // 
            // btnSearchQuotenumbe
            // 
            this.btnSearchQuotenumbe.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearchQuotenumbe.Location = new System.Drawing.Point(817, 13);
            this.btnSearchQuotenumbe.Name = "btnSearchQuotenumbe";
            this.btnSearchQuotenumbe.Size = new System.Drawing.Size(57, 25);
            this.btnSearchQuotenumbe.TabIndex = 222;
            this.btnSearchQuotenumbe.Text = "Search";
            this.btnSearchQuotenumbe.UseVisualStyleBackColor = true;
            this.btnSearchQuotenumbe.Click += new System.EventHandler(this.btnSearchQuotenumbe_Click);
            // 
            // frmQuoteViewItems
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1330, 699);
            this.Controls.Add(this.btnSearchQuotenumbe);
            this.Controls.Add(this.pnMainItems);
            this.Controls.Add(this.btnExcel);
            this.Controls.Add(this.lblFromdate);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.lblItemDescription);
            this.Controls.Add(this.lblToDate);
            this.Controls.Add(this.txtSearchText);
            this.Controls.Add(this.dtpfromdate);
            this.Controls.Add(this.dtptodate);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pnQuoteItemsView);
            this.Controls.Add(this.dgvQuoteView);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmQuoteViewItems";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quote View Items";
            this.Load += new System.EventHandler(this.frmQuoteViewItems_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuoteView)).EndInit();
            this.pnQuoteItemsView.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgWriteUP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgOIWriteUP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgQuoteBOM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOptionalItems)).EndInit();
            this.pnMainItems.ResumeLayout(false);
            this.pnMainItems.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblFromdate;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Label lblItemDescription;
        private System.Windows.Forms.Label lblToDate;
        private System.Windows.Forms.TextBox txtSearchText;
        private System.Windows.Forms.DateTimePicker dtpfromdate;
        private System.Windows.Forms.DateTimePicker dtptodate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvQuoteView;
        private System.Windows.Forms.Panel pnQuoteItemsView;
        private System.Windows.Forms.DataGridView dgQuoteBOM;
        private System.Windows.Forms.DataGridViewTextBoxColumn SLNO;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductGroup;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductCod;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Description;
        private System.Windows.Forms.DataGridViewTextBoxColumn SalesCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn TPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn BreakupTotal;
        private System.Windows.Forms.DataGridViewTextBoxColumn SP;
        private System.Windows.Forms.DataGridView dgvOptionalItems;
        private System.Windows.Forms.DataGridViewTextBoxColumn OISLNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn OIProductGroup;
        private System.Windows.Forms.DataGridViewTextBoxColumn OIProductCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn OIProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn OIProductDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn OISalesCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn OIQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn OIUnitPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn OITotalPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn OIBreakupTotal;
        private System.Windows.Forms.DataGridViewTextBoxColumn SP1;
        private System.Windows.Forms.DataGridView dgWriteUP;
        private System.Windows.Forms.DataGridViewTextBoxColumn WUSlNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn WUProductcode;
        private System.Windows.Forms.DataGridViewTextBoxColumn WUDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridView dgOIWriteUP;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGOISlNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn WUOIProductCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn WUOIProductDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbviewquoteowu;
        private System.Windows.Forms.RadioButton rbviewquotewu;
        private System.Windows.Forms.RadioButton rbviewquoteo;
        private System.Windows.Forms.RadioButton rbViewQuote;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblRevision;
        private System.Windows.Forms.Label lblQuoteNo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnExcel;
        private System.Windows.Forms.Panel pnMainItems;
        private System.Windows.Forms.TextBox txtBasicDemoPrice;
        private System.Windows.Forms.TextBox txtQuoteJack;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtQuoteBreak;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtQuoteRemain;
        private System.Windows.Forms.CheckBox chkBreakup;
        private System.Windows.Forms.TextBox txtJackup;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox txtTotalPrice;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblCST;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.TextBox txtSystemMargin;
        private System.Windows.Forms.DataGridViewButtonColumn View;
        private System.Windows.Forms.DataGridViewTextBoxColumn QuotationNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn RevisionNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn Region;
        private System.Windows.Forms.DataGridViewTextBoxColumn Leadgenarated;
        private System.Windows.Forms.DataGridViewTextBoxColumn QuoteName;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerName;
        private System.Windows.Forms.DataGridViewTextBoxColumn EnquiryNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn DateofEnquiry;
        private System.Windows.Forms.DataGridViewTextBoxColumn QuotePreparedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn QuoteCreatedDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn QuoteCompany;
        private System.Windows.Forms.Button btnSearchQuotenumbe;
        private System.Windows.Forms.DataGridViewTextBoxColumn QuoteFor;
        private System.Windows.Forms.DataGridViewTextBoxColumn QuoteModel;
        private System.Windows.Forms.DataGridViewTextBoxColumn QuoteCapacity;
        private System.Windows.Forms.DataGridViewTextBoxColumn project8020;
        private System.Windows.Forms.DataGridViewTextBoxColumn LevelofCustomization;
    }
}