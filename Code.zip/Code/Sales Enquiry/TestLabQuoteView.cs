﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.Diagnostics;
using System.IO;

namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    public partial class TestLabQuoteView : Form
    {
        public TestLabQuoteView()
        {
            InitializeComponent();
        }
        frmForm2 form = new frmForm2();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        DataTable dtTestQuoteList = new DataTable();

        private void TestLabQuoteView_Load(object sender, EventArgs e)
        {

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            dtpfromdate.Format = DateTimePickerFormat.Custom;
            dtpfromdate.CustomFormat = "yyyy-MM-dd";
            dtptodate.Format = DateTimePickerFormat.Custom;
            dtptodate.CustomFormat = "yyyy-MM-dd";
            dtTestQuoteList = DAL.fnAllTestQuoteDetails(0, null, dtpfromdate.Text, dtptodate.Text).Tables[0];
            if (dtTestQuoteList.Rows.Count > 0)
            {
                dgvTestQuoteReport.AutoGenerateColumns = false;
                dgvTestQuoteReport.DataSource = dtTestQuoteList;
            }
            dtpfromdate.Format = DateTimePickerFormat.Custom;
            dtpfromdate.CustomFormat = "dd-MM-yyyy";
            dtptodate.Format = DateTimePickerFormat.Custom;
            dtptodate.CustomFormat = "dd-MM-yyyy";
        }

        private void TestLabQuoteView_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnExit();
        }
        private void fnExit()
        {
            TestingQuote TQ=new TestingQuote();
            this.Hide();
            TQ.Show();
        }

        private void btnExcel_Click(object sender, EventArgs e)
        {
            string ExcelFolderPath;
            string FileFullPath;

            Microsoft.Office.Interop.Excel._Application ExcelApp = null;
            Microsoft.Office.Interop.Excel._Workbook NewWorkBook = null;
            Cursor.Current = Cursors.WaitCursor;

            bool IsFirsttime = true;

            if (dtTestQuoteList.Rows.Count > 0)
            {
                int j = 6;
                ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\Test Quote List\\";
                FileFullPath = ExcelFolderPath + "Test Quote List" + dtpfromdate.Text + " To " + dtptodate.Text + " " + DateTime.Now.ToString("d/M/yyyy HH/mm/ss") + " ";
                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);

                ExcelApp = new Microsoft.Office.Interop.Excel.Application();
                NewWorkBook = ExcelApp.Workbooks.Add(Type.Missing);
                Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
                worksheet = NewWorkBook.Sheets["Sheet1"];
                worksheet = NewWorkBook.ActiveSheet;
                worksheet.Name = "Test Lab Quotation Report";
                object misValue = System.Reflection.Missing.Value;
                worksheet.Cells[1, 1] =Global.sCompanyName; //i++;       
                CellMerge("Merge", NewWorkBook.ActiveSheet, 1, 1, 1, 3);
                //worksheet.Cells[2, 1] = "Item Code :'" + lblRepeatitemcode.Text + "'";// i++;
                //CellMerge("Merge", NewWorkBook.ActiveSheet, 2, 2, 1, 7);
                //worksheet.Cells[3, 1] = "Item Desc : " + lblitemname.Text + "";
                //CellMerge("Merge", NewWorkBook.ActiveSheet, 3, 3, 1, 7);
                worksheet.Cells[4, 1] = "Dated From : " + dtpfromdate.Text + "  To : " + dtptodate.Text + "";// i++; i++;
                CellMerge("Merge", NewWorkBook.ActiveSheet, 4, 4, 1, 5);
                worksheet.Range["A1:C1"].Cells.Font.Size = 16;
                worksheet.Range["A2:C3"].Cells.Font.Size = 14;
                worksheet.Range["A4:C4"].Cells.Font.Size = 12;
                worksheet.Range["A1:C3"].Cells.Font.Bold = true;
                bool bFirsttime = true;

                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Bold = true;
                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Color = Color.Blue;


                object[,] rawData = new object[dtTestQuoteList.Rows.Count + 1, dtTestQuoteList.Columns.Count];
                if (bFirsttime)
                {
                    for (int col = 0; col < dtTestQuoteList.Columns.Count; col++)
                    {
                        rawData[0, col] = dtTestQuoteList.Columns[col].ColumnName;
                    }
                    bFirsttime = false;
                }
                if (dtTestQuoteList.Rows.Count > 0)
                {
                    for (int row = 0; row < dtTestQuoteList.Rows.Count; row++)
                    {
                        for (int col = 0; col < dtTestQuoteList.Columns.Count; col++)
                        {
                            rawData[row + 1, col] = dtTestQuoteList.Rows[row].ItemArray[col];
                        }
                    }
                    string finalColLetter = string.Empty;
                    string excelRange = string.Empty;
                    if (IsFirsttime)
                    {
                        finalColLetter = string.Empty;
                        string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        int colCharsetLen = colCharset.Length;

                        if (dtTestQuoteList.Columns.Count > colCharsetLen)
                        {
                            finalColLetter = colCharset.Substring(
                                (dtTestQuoteList.Columns.Count - 1) / colCharsetLen - 1, 1);
                        }

                        finalColLetter += colCharset.Substring(
                                (dtTestQuoteList.Columns.Count - 1) % colCharsetLen, 1);
                        excelRange = string.Format("A6:{0}{1}", finalColLetter, dtTestQuoteList.Rows.Count + j);
                        IsFirsttime = false;
                    }
                    worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;

                }

                worksheet.Range["A3:C5"].Cells.Font.Size = 14;
                worksheet.Range["A3:C5"].Cells.Font.Bold = 14;
                CellMerge("Merge", NewWorkBook.ActiveSheet, 1, 1, 1, 3);
                worksheet.get_Range("C6", "C99999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                //Microsoft.Office.Interop.Excel.Range Range = worksheet.get_Range("N6", "R99999");
                //Range.EntireColumn.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                worksheet.Rows.RowHeight = "18";
                //Microsoft.Office.Interop.Excel.Range rangea = worksheet.get_Range("J6", "J99999");
              //  rangea.NumberFormat = "dd-MM-yyyy";

              //  if (cmbReportType.SelectedIndex == 0 || cmbReportType.SelectedIndex == 5 || cmbReportType.SelectedIndex == 6)
                {
                    Microsoft.Office.Interop.Excel.Range rangeDate = worksheet.get_Range("D6", "D9999");
                    rangeDate.NumberFormat = "dd-MM-yyyy";
             
                    Microsoft.Office.Interop.Excel.Range rangeDate1 = worksheet.get_Range("N6", "N9999");
                    rangeDate1.NumberFormat = "0.00";
                }

                worksheet.Columns.AutoFit();
                worksheet.Rows.AutoFit();
                //worksheet.Columns[1].ColumnWidth = 12;
                //worksheet.Columns[1].WrapText = true;
                //worksheet.Columns[12].ColumnWidth = 50;
               // worksheet.Columns[12].WrapText = true;
                //worksheet.Columns[8].ColumnWidth = 50;
                //worksheet.Columns[8].WrapText = true;
                worksheet.Rows.RowHeight = "18";
                worksheet.PageSetup.PrintArea = "A1:Q" + (dtTestQuoteList.Rows.Count + 6) + "";
                worksheet.PageSetup.PrintTitleRows = "$1:$2";
                worksheet.PageSetup.PrintNotes = true;
                worksheet.PageSetup.Zoom = 75;
                worksheet.PageSetup.PrintGridlines = true;
                worksheet.PageSetup.LeftMargin = 0;
                worksheet.PageSetup.RightMargin = 0;
                worksheet.PageSetup.TopMargin = 0.75;
                worksheet.PageSetup.BottomMargin = 0.75;
                worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                NewWorkBook.SaveAs(FileFullPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                NewWorkBook.Save();
                NewWorkBook.Close(true, misValue, misValue);
                ExcelApp.Quit();
                releaseObject(worksheet);
                releaseObject(NewWorkBook);
                releaseObject(ExcelApp);

                if (Directory.Exists(ExcelFolderPath))
                {
                    Process.Start(ExcelFolderPath);
                }
                Cursor.Current = Cursors.Default;
            }

        }

        #region CellMerge Funtion
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlMedium, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "GridLines":
                    {
                        CELLS.Borders.Color = System.Drawing.Color.Black;
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignCenter":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                        break;
                    }
                case "Bold":
                    {
                        CELLS.Font.Bold = true;
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

        }
        #endregion

        #region Excel App Release Object Function
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
        #endregion
    }
}
