﻿namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    partial class frmViewCustomerVisit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmViewCustomerVisit));
            this.dgvSetuptimeReport = new System.Windows.Forms.DataGridView();
            this.CompanyName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CompanyType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ContactPerson = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WorkPhoneNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MobileNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmailAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WebSite = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VisitDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductRequirement = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Lever = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.s8020 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductManager = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OldNewCustomer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LeadInput = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Remarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cmbreporttype = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pnGenaralPanel = new System.Windows.Forms.Panel();
            this.txtSearchText = new System.Windows.Forms.TextBox();
            this.lblFromdate = new System.Windows.Forms.Label();
            this.btnReport = new System.Windows.Forms.Button();
            this.btnExcelReport = new System.Windows.Forms.Button();
            this.lblToDate = new System.Windows.Forms.Label();
            this.dtpFromDate = new System.Windows.Forms.DateTimePicker();
            this.dtpToDate = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSetuptimeReport)).BeginInit();
            this.pnGenaralPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvSetuptimeReport
            // 
            this.dgvSetuptimeReport.AllowUserToAddRows = false;
            this.dgvSetuptimeReport.AllowUserToDeleteRows = false;
            this.dgvSetuptimeReport.AllowUserToOrderColumns = true;
            this.dgvSetuptimeReport.AllowUserToResizeRows = false;
            this.dgvSetuptimeReport.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSetuptimeReport.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvSetuptimeReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSetuptimeReport.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CompanyName,
            this.Address,
            this.CompanyType,
            this.ContactPerson,
            this.WorkPhoneNo,
            this.MobileNo,
            this.EmailAddress,
            this.WebSite,
            this.VisitDate,
            this.ProductType,
            this.ProductRequirement,
            this.Lever,
            this.s8020,
            this.ProductManager,
            this.OldNewCustomer,
            this.LeadInput,
            this.Remarks});
            this.dgvSetuptimeReport.EnableHeadersVisualStyles = false;
            this.dgvSetuptimeReport.Location = new System.Drawing.Point(3, 104);
            this.dgvSetuptimeReport.Name = "dgvSetuptimeReport";
            this.dgvSetuptimeReport.ReadOnly = true;
            this.dgvSetuptimeReport.RowHeadersVisible = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvSetuptimeReport.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvSetuptimeReport.Size = new System.Drawing.Size(1294, 512);
            this.dgvSetuptimeReport.TabIndex = 126;
            // 
            // CompanyName
            // 
            this.CompanyName.DataPropertyName = "Company Name";
            this.CompanyName.HeaderText = "Company Name";
            this.CompanyName.Name = "CompanyName";
            this.CompanyName.ReadOnly = true;
            this.CompanyName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CompanyName.Width = 111;
            // 
            // Address
            // 
            this.Address.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Address.DataPropertyName = "Address";
            this.Address.HeaderText = "Address";
            this.Address.Name = "Address";
            this.Address.ReadOnly = true;
            this.Address.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Address.Width = 57;
            // 
            // CompanyType
            // 
            this.CompanyType.DataPropertyName = "Company Type";
            this.CompanyType.HeaderText = "Company Type";
            this.CompanyType.Name = "CompanyType";
            this.CompanyType.ReadOnly = true;
            this.CompanyType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CompanyType.Width = 104;
            // 
            // ContactPerson
            // 
            this.ContactPerson.DataPropertyName = "ContactPerson";
            this.ContactPerson.HeaderText = "Contact Person";
            this.ContactPerson.Name = "ContactPerson";
            this.ContactPerson.ReadOnly = true;
            this.ContactPerson.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ContactPerson.Width = 107;
            // 
            // WorkPhoneNo
            // 
            this.WorkPhoneNo.DataPropertyName = "WorkPhoneNo";
            this.WorkPhoneNo.HeaderText = "Work Phone No";
            this.WorkPhoneNo.Name = "WorkPhoneNo";
            this.WorkPhoneNo.ReadOnly = true;
            this.WorkPhoneNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.WorkPhoneNo.Width = 94;
            // 
            // MobileNo
            // 
            this.MobileNo.DataPropertyName = "MobileNo";
            this.MobileNo.HeaderText = "Mobile No";
            this.MobileNo.Name = "MobileNo";
            this.MobileNo.ReadOnly = true;
            this.MobileNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.MobileNo.Width = 78;
            // 
            // EmailAddress
            // 
            this.EmailAddress.DataPropertyName = "EmailAddress";
            this.EmailAddress.HeaderText = "Email ID";
            this.EmailAddress.Name = "EmailAddress";
            this.EmailAddress.ReadOnly = true;
            this.EmailAddress.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.EmailAddress.Width = 63;
            // 
            // WebSite
            // 
            this.WebSite.DataPropertyName = "WebSite";
            this.WebSite.HeaderText = "WebSite";
            this.WebSite.Name = "WebSite";
            this.WebSite.ReadOnly = true;
            this.WebSite.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.WebSite.Width = 72;
            // 
            // VisitDate
            // 
            this.VisitDate.DataPropertyName = "VisitDate";
            this.VisitDate.HeaderText = "Visit Date";
            this.VisitDate.Name = "VisitDate";
            this.VisitDate.ReadOnly = true;
            this.VisitDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.VisitDate.Width = 72;
            // 
            // ProductType
            // 
            this.ProductType.DataPropertyName = "ProductType";
            this.ProductType.HeaderText = "Product Type";
            this.ProductType.Name = "ProductType";
            this.ProductType.ReadOnly = true;
            this.ProductType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductType.Width = 96;
            // 
            // ProductRequirement
            // 
            this.ProductRequirement.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ProductRequirement.DataPropertyName = "ProductRequirement";
            this.ProductRequirement.HeaderText = "Product Requirement";
            this.ProductRequirement.Name = "ProductRequirement";
            this.ProductRequirement.ReadOnly = true;
            this.ProductRequirement.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductRequirement.Width = 147;
            // 
            // Lever
            // 
            this.Lever.DataPropertyName = "Lever";
            this.Lever.HeaderText = "Lever";
            this.Lever.Name = "Lever";
            this.Lever.ReadOnly = true;
            this.Lever.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Lever.Width = 52;
            // 
            // s8020
            // 
            this.s8020.DataPropertyName = "80/20";
            this.s8020.HeaderText = "80/20";
            this.s8020.Name = "s8020";
            this.s8020.ReadOnly = true;
            this.s8020.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.s8020.Width = 54;
            // 
            // ProductManager
            // 
            this.ProductManager.DataPropertyName = "ProductManager";
            this.ProductManager.HeaderText = "Product Manager";
            this.ProductManager.Name = "ProductManager";
            this.ProductManager.ReadOnly = true;
            this.ProductManager.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductManager.Width = 122;
            // 
            // OldNewCustomer
            // 
            this.OldNewCustomer.DataPropertyName = "OldNewCustomer";
            this.OldNewCustomer.HeaderText = "Old/New Customer";
            this.OldNewCustomer.Name = "OldNewCustomer";
            this.OldNewCustomer.ReadOnly = true;
            this.OldNewCustomer.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OldNewCustomer.Width = 131;
            // 
            // LeadInput
            // 
            this.LeadInput.DataPropertyName = "LeadInput";
            this.LeadInput.HeaderText = "Lead Input";
            this.LeadInput.Name = "LeadInput";
            this.LeadInput.ReadOnly = true;
            this.LeadInput.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.LeadInput.Width = 79;
            // 
            // Remarks
            // 
            this.Remarks.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Remarks.DataPropertyName = "Remarks";
            this.Remarks.HeaderText = "Remarks";
            this.Remarks.Name = "Remarks";
            this.Remarks.ReadOnly = true;
            this.Remarks.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Remarks.Width = 73;
            // 
            // cmbreporttype
            // 
            this.cmbreporttype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbreporttype.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbreporttype.FormattingEnabled = true;
            this.cmbreporttype.Items.AddRange(new object[] {
            "Customer Name",
            "Customer Type",
            "Contact Person",
            "Product Type",
            "Lever",
            "80/20",
            "Product Manager",
            "Old New Customer",
            "Lead Input"});
            this.cmbreporttype.Location = new System.Drawing.Point(82, 53);
            this.cmbreporttype.Name = "cmbreporttype";
            this.cmbreporttype.Size = new System.Drawing.Size(337, 27);
            this.cmbreporttype.TabIndex = 127;
            this.cmbreporttype.SelectedIndexChanged += new System.EventHandler(this.cmbreporttype_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(1, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 19);
            this.label1.TabIndex = 128;
            this.label1.Text = "Search by :";
            // 
            // pnGenaralPanel
            // 
            this.pnGenaralPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnGenaralPanel.Controls.Add(this.txtSearchText);
            this.pnGenaralPanel.Controls.Add(this.cmbreporttype);
            this.pnGenaralPanel.Controls.Add(this.lblFromdate);
            this.pnGenaralPanel.Controls.Add(this.label1);
            this.pnGenaralPanel.Controls.Add(this.btnReport);
            this.pnGenaralPanel.Controls.Add(this.btnExcelReport);
            this.pnGenaralPanel.Controls.Add(this.lblToDate);
            this.pnGenaralPanel.Controls.Add(this.dtpFromDate);
            this.pnGenaralPanel.Controls.Add(this.dtpToDate);
            this.pnGenaralPanel.Location = new System.Drawing.Point(3, 7);
            this.pnGenaralPanel.Name = "pnGenaralPanel";
            this.pnGenaralPanel.Size = new System.Drawing.Size(1294, 91);
            this.pnGenaralPanel.TabIndex = 131;
            // 
            // txtSearchText
            // 
            this.txtSearchText.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearchText.Location = new System.Drawing.Point(434, 53);
            this.txtSearchText.Name = "txtSearchText";
            this.txtSearchText.Size = new System.Drawing.Size(326, 27);
            this.txtSearchText.TabIndex = 132;
            this.txtSearchText.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtSearchText_KeyUp);
            // 
            // lblFromdate
            // 
            this.lblFromdate.AutoSize = true;
            this.lblFromdate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblFromdate.Location = new System.Drawing.Point(7, 12);
            this.lblFromdate.Name = "lblFromdate";
            this.lblFromdate.Size = new System.Drawing.Size(52, 19);
            this.lblFromdate.TabIndex = 4;
            this.lblFromdate.Text = "From :";
            // 
            // btnReport
            // 
            this.btnReport.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReport.Location = new System.Drawing.Point(434, -2);
            this.btnReport.Name = "btnReport";
            this.btnReport.Size = new System.Drawing.Size(139, 39);
            this.btnReport.TabIndex = 132;
            this.btnReport.Text = "Search";
            this.btnReport.UseVisualStyleBackColor = true;
            this.btnReport.Click += new System.EventHandler(this.btnReport_Click);
            // 
            // btnExcelReport
            // 
            this.btnExcelReport.Enabled = false;
            this.btnExcelReport.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcelReport.Location = new System.Drawing.Point(621, -2);
            this.btnExcelReport.Name = "btnExcelReport";
            this.btnExcelReport.Size = new System.Drawing.Size(139, 39);
            this.btnExcelReport.TabIndex = 133;
            this.btnExcelReport.Text = "Export to Excel";
            this.btnExcelReport.UseVisualStyleBackColor = true;
            // 
            // lblToDate
            // 
            this.lblToDate.AutoSize = true;
            this.lblToDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblToDate.Location = new System.Drawing.Point(224, 12);
            this.lblToDate.Name = "lblToDate";
            this.lblToDate.Size = new System.Drawing.Size(33, 19);
            this.lblToDate.TabIndex = 6;
            this.lblToDate.Text = "To :";
            // 
            // dtpFromDate
            // 
            this.dtpFromDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.dtpFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFromDate.Location = new System.Drawing.Point(59, 6);
            this.dtpFromDate.Name = "dtpFromDate";
            this.dtpFromDate.Size = new System.Drawing.Size(139, 27);
            this.dtpFromDate.TabIndex = 9;
            // 
            // dtpToDate
            // 
            this.dtpToDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.dtpToDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpToDate.Location = new System.Drawing.Point(260, 5);
            this.dtpToDate.Name = "dtpToDate";
            this.dtpToDate.Size = new System.Drawing.Size(133, 27);
            this.dtpToDate.TabIndex = 10;
            // 
            // frmViewCustomerVisit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1299, 628);
            this.Controls.Add(this.pnGenaralPanel);
            this.Controls.Add(this.dgvSetuptimeReport);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmViewCustomerVisit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customer Visit View";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmViewCustomerVisit_FormClosing);
            this.Load += new System.EventHandler(this.frmViewCustomerVisit_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSetuptimeReport)).EndInit();
            this.pnGenaralPanel.ResumeLayout(false);
            this.pnGenaralPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvSetuptimeReport;
        private System.Windows.Forms.ComboBox cmbreporttype;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnGenaralPanel;
        private System.Windows.Forms.Label lblFromdate;
        private System.Windows.Forms.Label lblToDate;
        private System.Windows.Forms.DateTimePicker dtpFromDate;
        private System.Windows.Forms.DateTimePicker dtpToDate;
        private System.Windows.Forms.Button btnExcelReport;
        private System.Windows.Forms.Button btnReport;
        private System.Windows.Forms.TextBox txtSearchText;
        private System.Windows.Forms.DataGridViewTextBoxColumn CompanyName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Address;
        private System.Windows.Forms.DataGridViewTextBoxColumn CompanyType;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContactPerson;
        private System.Windows.Forms.DataGridViewTextBoxColumn WorkPhoneNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn MobileNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmailAddress;
        private System.Windows.Forms.DataGridViewTextBoxColumn WebSite;
        private System.Windows.Forms.DataGridViewTextBoxColumn VisitDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductType;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductRequirement;
        private System.Windows.Forms.DataGridViewTextBoxColumn Lever;
        private System.Windows.Forms.DataGridViewTextBoxColumn s8020;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductManager;
        private System.Windows.Forms.DataGridViewTextBoxColumn OldNewCustomer;
        private System.Windows.Forms.DataGridViewTextBoxColumn LeadInput;
        private System.Windows.Forms.DataGridViewTextBoxColumn Remarks;
    }
}