﻿namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    partial class frmCustomerVisit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCustomerVisit));
            this.pnMain = new System.Windows.Forms.Panel();
            this.btnAddContact = new System.Windows.Forms.Button();
            this.dgContactPerson = new System.Windows.Forms.DataGridView();
            this.contactperson = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workphoneno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mobileno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EMail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label6 = new System.Windows.Forms.Label();
            this.txtWebSite = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbProductType = new System.Windows.Forms.ComboBox();
            this.cmbLeadInput = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbOldNewCustomer = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmb8020 = new System.Windows.Forms.ComboBox();
            this.cmbLever = new System.Windows.Forms.ComboBox();
            this.dtpVisitDate = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.lblUserName = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnClearAll = new System.Windows.Forms.Button();
            this.cmbCustomer = new System.Windows.Forms.ComboBox();
            this.txtProductRequirement = new System.Windows.Forms.TextBox();
            this.lblCustomerType = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.lblCSTNo = new System.Windows.Forms.Label();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.cmbCustomerType = new System.Windows.Forms.ComboBox();
            this.lblCustomerName = new System.Windows.Forms.Label();
            this.pnMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgContactPerson)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnMain
            // 
            this.pnMain.BackColor = System.Drawing.Color.Silver;
            this.pnMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnMain.Controls.Add(this.btnAddContact);
            this.pnMain.Controls.Add(this.dgContactPerson);
            this.pnMain.Controls.Add(this.label6);
            this.pnMain.Controls.Add(this.txtWebSite);
            this.pnMain.Controls.Add(this.label5);
            this.pnMain.Controls.Add(this.cmbProductType);
            this.pnMain.Controls.Add(this.cmbLeadInput);
            this.pnMain.Controls.Add(this.label4);
            this.pnMain.Controls.Add(this.cmbOldNewCustomer);
            this.pnMain.Controls.Add(this.label3);
            this.pnMain.Controls.Add(this.cmb8020);
            this.pnMain.Controls.Add(this.cmbLever);
            this.pnMain.Controls.Add(this.dtpVisitDate);
            this.pnMain.Controls.Add(this.label1);
            this.pnMain.Controls.Add(this.lblWelcome);
            this.pnMain.Controls.Add(this.lblUserName);
            this.pnMain.Controls.Add(this.groupBox2);
            this.pnMain.Controls.Add(this.cmbCustomer);
            this.pnMain.Controls.Add(this.txtProductRequirement);
            this.pnMain.Controls.Add(this.lblCustomerType);
            this.pnMain.Controls.Add(this.label19);
            this.pnMain.Controls.Add(this.label20);
            this.pnMain.Controls.Add(this.label22);
            this.pnMain.Controls.Add(this.label23);
            this.pnMain.Controls.Add(this.txtAddress);
            this.pnMain.Controls.Add(this.lblCSTNo);
            this.pnMain.Controls.Add(this.txtRemarks);
            this.pnMain.Controls.Add(this.label13);
            this.pnMain.Controls.Add(this.cmbCustomerType);
            this.pnMain.Controls.Add(this.lblCustomerName);
            this.pnMain.Location = new System.Drawing.Point(9, 11);
            this.pnMain.Name = "pnMain";
            this.pnMain.Size = new System.Drawing.Size(1294, 674);
            this.pnMain.TabIndex = 16;
            // 
            // btnAddContact
            // 
            this.btnAddContact.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddContact.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAddContact.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddContact.ForeColor = System.Drawing.Color.Black;
            this.btnAddContact.Location = new System.Drawing.Point(577, 262);
            this.btnAddContact.Name = "btnAddContact";
            this.btnAddContact.Size = new System.Drawing.Size(80, 24);
            this.btnAddContact.TabIndex = 173;
            this.btnAddContact.Text = "Add Contact";
            this.btnAddContact.UseVisualStyleBackColor = false;
            this.btnAddContact.Click += new System.EventHandler(this.btnAddContact_Click);
            // 
            // dgContactPerson
            // 
            this.dgContactPerson.AllowUserToAddRows = false;
            this.dgContactPerson.AllowUserToDeleteRows = false;
            this.dgContactPerson.AllowUserToResizeRows = false;
            this.dgContactPerson.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgContactPerson.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgContactPerson.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgContactPerson.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgContactPerson.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgContactPerson.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.contactperson,
            this.workphoneno,
            this.mobileno,
            this.EMail});
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgContactPerson.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgContactPerson.EnableHeadersVisualStyles = false;
            this.dgContactPerson.Location = new System.Drawing.Point(16, 262);
            this.dgContactPerson.MultiSelect = false;
            this.dgContactPerson.Name = "dgContactPerson";
            this.dgContactPerson.RowHeadersVisible = false;
            this.dgContactPerson.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgContactPerson.Size = new System.Drawing.Size(606, 151);
            this.dgContactPerson.TabIndex = 172;
            this.dgContactPerson.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgContactPerson_KeyUp);
            this.dgContactPerson.MouseUp += new System.Windows.Forms.MouseEventHandler(this.dgContactPerson_MouseUp);
            // 
            // contactperson
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.contactperson.DefaultCellStyle = dataGridViewCellStyle2;
            this.contactperson.HeaderText = "Contact Person";
            this.contactperson.Name = "contactperson";
            this.contactperson.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // workphoneno
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.workphoneno.DefaultCellStyle = dataGridViewCellStyle3;
            this.workphoneno.HeaderText = "Work Phone No";
            this.workphoneno.Name = "workphoneno";
            this.workphoneno.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // mobileno
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.mobileno.DefaultCellStyle = dataGridViewCellStyle4;
            this.mobileno.HeaderText = "Mobile No";
            this.mobileno.Name = "mobileno";
            this.mobileno.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // EMail
            // 
            this.EMail.DataPropertyName = "Email";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.EMail.DefaultCellStyle = dataGridViewCellStyle5;
            this.EMail.HeaderText = "E Mail";
            this.EMail.Name = "EMail";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label6.Location = new System.Drawing.Point(767, 88);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 19);
            this.label6.TabIndex = 125;
            this.label6.Text = "Visit Date :";
            // 
            // txtWebSite
            // 
            this.txtWebSite.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWebSite.Location = new System.Drawing.Point(218, 438);
            this.txtWebSite.Name = "txtWebSite";
            this.txtWebSite.Size = new System.Drawing.Size(340, 27);
            this.txtWebSite.TabIndex = 124;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label5.Location = new System.Drawing.Point(138, 441);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 19);
            this.label5.TabIndex = 123;
            this.label5.Text = "WebSite :";
            // 
            // cmbProductType
            // 
            this.cmbProductType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProductType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProductType.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProductType.FormattingEnabled = true;
            this.cmbProductType.Items.AddRange(new object[] {
            "UTM",
            "STS",
            "DTS",
            "LFS",
            "TGT",
            "FSW",
            "ShakeTable",
            "CustomRigs",
            "Others"});
            this.cmbProductType.Location = new System.Drawing.Point(855, 120);
            this.cmbProductType.Name = "cmbProductType";
            this.cmbProductType.Size = new System.Drawing.Size(310, 27);
            this.cmbProductType.TabIndex = 122;
            // 
            // cmbLeadInput
            // 
            this.cmbLeadInput.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbLeadInput.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLeadInput.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbLeadInput.FormattingEnabled = true;
            this.cmbLeadInput.Items.AddRange(new object[] {
            "Direct",
            "Dealer",
            "Exhibiton",
            "Others"});
            this.cmbLeadInput.Location = new System.Drawing.Point(856, 431);
            this.cmbLeadInput.Name = "cmbLeadInput";
            this.cmbLeadInput.Size = new System.Drawing.Size(310, 27);
            this.cmbLeadInput.TabIndex = 120;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(760, 433);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 19);
            this.label4.TabIndex = 119;
            this.label4.Text = "Lead Input :";
            // 
            // cmbOldNewCustomer
            // 
            this.cmbOldNewCustomer.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbOldNewCustomer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbOldNewCustomer.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbOldNewCustomer.FormattingEnabled = true;
            this.cmbOldNewCustomer.Items.AddRange(new object[] {
            "Old",
            "New"});
            this.cmbOldNewCustomer.Location = new System.Drawing.Point(856, 378);
            this.cmbOldNewCustomer.Name = "cmbOldNewCustomer";
            this.cmbOldNewCustomer.Size = new System.Drawing.Size(310, 27);
            this.cmbOldNewCustomer.TabIndex = 116;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label3.Location = new System.Drawing.Point(694, 384);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(156, 19);
            this.label3.TabIndex = 115;
            this.label3.Text = "Old / New Customer :";
            // 
            // cmb8020
            // 
            this.cmb8020.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmb8020.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb8020.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb8020.FormattingEnabled = true;
            this.cmb8020.Items.AddRange(new object[] {
            "80",
            "20"});
            this.cmb8020.Location = new System.Drawing.Point(857, 329);
            this.cmb8020.Name = "cmb8020";
            this.cmb8020.Size = new System.Drawing.Size(310, 27);
            this.cmb8020.TabIndex = 112;
            // 
            // cmbLever
            // 
            this.cmbLever.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbLever.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLever.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbLever.FormattingEnabled = true;
            this.cmbLever.Items.AddRange(new object[] {
            "L1",
            "L2",
            "L3"});
            this.cmbLever.Location = new System.Drawing.Point(857, 277);
            this.cmbLever.Name = "cmbLever";
            this.cmbLever.Size = new System.Drawing.Size(310, 27);
            this.cmbLever.TabIndex = 111;
            // 
            // dtpVisitDate
            // 
            this.dtpVisitDate.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpVisitDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpVisitDate.Location = new System.Drawing.Point(856, 85);
            this.dtpVisitDate.Name = "dtpVisitDate";
            this.dtpVisitDate.Size = new System.Drawing.Size(90, 23);
            this.dtpVisitDate.TabIndex = 110;
            this.dtpVisitDate.ValueChanged += new System.EventHandler(this.dtpVisitDate_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Indigo;
            this.label1.Location = new System.Drawing.Point(540, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(180, 33);
            this.label1.TabIndex = 12;
            this.label1.Text = "Customer Visit";
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.ForeColor = System.Drawing.Color.Black;
            this.lblWelcome.Location = new System.Drawing.Point(11, 4);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(98, 24);
            this.lblWelcome.TabIndex = 22;
            this.lblWelcome.Text = "Welcome :";
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserName.ForeColor = System.Drawing.Color.Black;
            this.lblUserName.Location = new System.Drawing.Point(109, 4);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(0, 24);
            this.lblUserName.TabIndex = 21;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnExit);
            this.groupBox2.Controls.Add(this.btnSave);
            this.groupBox2.Controls.Add(this.btnSearch);
            this.groupBox2.Controls.Add(this.btnClearAll);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox2.Location = new System.Drawing.Point(195, 587);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1073, 76);
            this.groupBox2.TabIndex = 71;
            this.groupBox2.TabStop = false;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(869, 21);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(102, 45);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(325, 21);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(102, 45);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSearch.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(494, 19);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(102, 45);
            this.btnSearch.TabIndex = 8;
            this.btnSearch.Text = "View";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnClearAll
            // 
            this.btnClearAll.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnClearAll.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnClearAll.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearAll.Location = new System.Drawing.Point(686, 21);
            this.btnClearAll.Name = "btnClearAll";
            this.btnClearAll.Size = new System.Drawing.Size(102, 45);
            this.btnClearAll.TabIndex = 7;
            this.btnClearAll.Text = "Clear All";
            this.btnClearAll.UseVisualStyleBackColor = false;
            // 
            // cmbCustomer
            // 
            this.cmbCustomer.DropDownHeight = 100;
            this.cmbCustomer.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCustomer.FormattingEnabled = true;
            this.cmbCustomer.IntegralHeight = false;
            this.cmbCustomer.ItemHeight = 19;
            this.cmbCustomer.Location = new System.Drawing.Point(220, 81);
            this.cmbCustomer.Name = "cmbCustomer";
            this.cmbCustomer.Size = new System.Drawing.Size(340, 27);
            this.cmbCustomer.TabIndex = 12;
            this.cmbCustomer.SelectedIndexChanged += new System.EventHandler(this.cmbCustomer_SelectedIndexChanged);
            // 
            // txtProductRequirement
            // 
            this.txtProductRequirement.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProductRequirement.Location = new System.Drawing.Point(856, 160);
            this.txtProductRequirement.Multiline = true;
            this.txtProductRequirement.Name = "txtProductRequirement";
            this.txtProductRequirement.Size = new System.Drawing.Size(310, 83);
            this.txtProductRequirement.TabIndex = 67;
            // 
            // lblCustomerType
            // 
            this.lblCustomerType.AutoSize = true;
            this.lblCustomerType.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerType.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblCustomerType.Location = new System.Drawing.Point(89, 219);
            this.lblCustomerType.Name = "lblCustomerType";
            this.lblCustomerType.Size = new System.Drawing.Size(122, 19);
            this.lblCustomerType.TabIndex = 79;
            this.lblCustomerType.Text = "Company Type*:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label19.Location = new System.Drawing.Point(797, 280);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(54, 19);
            this.label19.TabIndex = 62;
            this.label19.Text = "Lever :";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label20.Location = new System.Drawing.Point(794, 336);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(56, 19);
            this.label20.TabIndex = 61;
            this.label20.Text = "80/20 :";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label22.Location = new System.Drawing.Point(685, 163);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(165, 19);
            this.label22.TabIndex = 59;
            this.label22.Text = "Product Requirement :";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label23.Location = new System.Drawing.Point(741, 124);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(109, 19);
            this.label23.TabIndex = 58;
            this.label23.Text = "Product Type :";
            // 
            // txtAddress
            // 
            this.txtAddress.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Location = new System.Drawing.Point(219, 124);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(340, 83);
            this.txtAddress.TabIndex = 55;
            // 
            // lblCSTNo
            // 
            this.lblCSTNo.AutoSize = true;
            this.lblCSTNo.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCSTNo.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblCSTNo.Location = new System.Drawing.Point(137, 490);
            this.lblCSTNo.Name = "lblCSTNo";
            this.lblCSTNo.Size = new System.Drawing.Size(75, 19);
            this.lblCSTNo.TabIndex = 75;
            this.lblCSTNo.Text = "Remarks :";
            // 
            // txtRemarks
            // 
            this.txtRemarks.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemarks.Location = new System.Drawing.Point(218, 481);
            this.txtRemarks.Multiline = true;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Size = new System.Drawing.Size(948, 63);
            this.txtRemarks.TabIndex = 76;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label13.Location = new System.Drawing.Point(143, 123);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(71, 19);
            this.label13.TabIndex = 4;
            this.label13.Text = "Address :";
            // 
            // cmbCustomerType
            // 
            this.cmbCustomerType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCustomerType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCustomerType.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCustomerType.FormattingEnabled = true;
            this.cmbCustomerType.Items.AddRange(new object[] {
            "Institution",
            "Government Industry",
            "Private Industry",
            "Research Lab"});
            this.cmbCustomerType.Location = new System.Drawing.Point(219, 223);
            this.cmbCustomerType.Name = "cmbCustomerType";
            this.cmbCustomerType.Size = new System.Drawing.Size(340, 27);
            this.cmbCustomerType.TabIndex = 83;
            // 
            // lblCustomerName
            // 
            this.lblCustomerName.AutoSize = true;
            this.lblCustomerName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerName.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblCustomerName.Location = new System.Drawing.Point(80, 88);
            this.lblCustomerName.Name = "lblCustomerName";
            this.lblCustomerName.Size = new System.Drawing.Size(133, 19);
            this.lblCustomerName.TabIndex = 1;
            this.lblCustomerName.Text = "Company Name *:";
            // 
            // frmCustomerVisit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1329, 686);
            this.Controls.Add(this.pnMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmCustomerVisit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customer Visit";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmCustomerVisit_FormClosing);
            this.Load += new System.EventHandler(this.frmCustomerVisit_Load);
            this.pnMain.ResumeLayout(false);
            this.pnMain.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgContactPerson)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnMain;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnClearAll;
        private System.Windows.Forms.ComboBox cmbCustomer;
        private System.Windows.Forms.TextBox txtProductRequirement;
        private System.Windows.Forms.Label lblCustomerType;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label lblCSTNo;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cmbCustomerType;
        private System.Windows.Forms.Label lblCustomerName;
        private System.Windows.Forms.ComboBox cmbLeadInput;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbOldNewCustomer;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmb8020;
        private System.Windows.Forms.ComboBox cmbLever;
        private System.Windows.Forms.DateTimePicker dtpVisitDate;
        private System.Windows.Forms.ComboBox cmbProductType;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtWebSite;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dgContactPerson;
        private System.Windows.Forms.Button btnAddContact;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactperson;
        private System.Windows.Forms.DataGridViewTextBoxColumn workphoneno;
        private System.Windows.Forms.DataGridViewTextBoxColumn mobileno;
        private System.Windows.Forms.DataGridViewTextBoxColumn EMail;
    }
}