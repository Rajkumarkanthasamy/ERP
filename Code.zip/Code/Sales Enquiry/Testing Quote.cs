﻿using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.Diagnostics;

namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    public partial class TestingQuote : Form
    {
        public TestingQuote()
        {
            InitializeComponent();
        }
        frmForm2 form = new frmForm2();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        DataTable dtProjectList = new DataTable();
        DataTable dtCustomerList = new DataTable();
        DataRow[] DR;
        private void TestingQuote_Load(object sender, EventArgs e)
        {
            dtCustomerList = DAL.fnCustomerList(0, null).Tables[0];

            foreach (DataRow DR in dtCustomerList.Rows)
            {
                if (!cmbCustomer.Items.Contains(DR["CustomerName"].ToString()))
                    cmbCustomer.Items.Add(DR["CustomerName"].ToString());
            }
        }

        private void cmbCustomer_SelectedIndexChanged(object sender, EventArgs e)
        {
            DR = dtCustomerList.Select("CustomerName = '" + cmbCustomer.Text + "'");
            if (DR.Length > 0)
            {
                txtcontactperson.Text = DR[0]["ContactPerson"].ToString();
                txtphonenumber.Text = DR[0]["MobileNo"].ToString();
                txtCustomerAddress.Text = DR[0]["Address1"].ToString()+ DR[0]["Address2"].ToString() +DR[0]["Address3"].ToString() ;
                txtEmailID.Text= DR[0]["EmailAddress"].ToString();
            }
            else
            {
                txtcontactperson.Clear();
                txtphonenumber.Clear();
            }
        }
        DataRow DR1;
        private void btnAddNewRow_Click(object sender, EventArgs e)
        {
            //bool bValidattion = false;
            fnRowCheck();
           
            if (bValidattion == false)
            {           
                if (cmbOfferNumber.SelectedIndex == -1)
                {
                    if (dtOfferItemDeatils.Rows.Count == 0)
                    {
                        dtOfferItemDeatils = DAL.fnTestQuoteNumber(32,"new").Tables[0];
                    }

                    DR1 = dtOfferItemDeatils.NewRow();

                   // dgvQuoteItems.Rows.Add();

                    if (dtOfferItemDeatils.Rows.Count == 0)
                    {
                        DR1[0] = 1.0;
                        DR1[1] = "Test setup charges";
                        DR1[2] = 1;
                        DR1[3] = 10000;
                        DR1[4] = 0;
                        DR1[5] = 0;
                        DR1[6] = "Yes";
                    }
                    else if (dgvQuoteItems.Rows.Count == 1)
                    {
                        DR1[1] = @"a) Test type - 
b) Test standard - 
c) Test temperature - 
d) R-ratio - 
e) Test frequency - 
f) No. of samples - 
g) No. of hours for each sample - 
h) Test result -
Note : Max Load is less than 100kN
Max. cycle considered for each samples is 6lakhs";
                        DR1[2] = 0;
                        DR1[3] = 0;
                        DR1[4] = 0;
                        DR1[5] = 0;
                        DR1[6] = "Yes";
                    }
                    else
                    {
                        DR1[1] = "";
                        DR1[2] = 0;
                        DR1[3] = 0;
                        DR1[4] = 0;
                        DR1[5] = 0;
                        DR1[6] = "Yes";
                    }

                    dtOfferItemDeatils.Rows.Add(DR1);
                    dgvQuoteItems.AutoGenerateColumns = false;
                    dgvQuoteItems.DataSource = dtOfferItemDeatils;
                    //int i = 1;
                    //foreach (DataGridViewRow row in dgvQuoteItems.Rows)
                    //{
                    //    row.Cells[0].Value = i;
                    //    i++;
                    //}
                   // dtOfferItemDeatils = dgvQuoteItems.DataSource as DataTable;
                     
                }
                else
                {
                    dtOfferItemDeatils.Rows.Add(dgvQuoteItems.Rows.Count + 1, "", 0, 0, 0, 0, "Yes");
                    dgvQuoteItems.DataSource = dtOfferItemDeatils;
                }

            }
        }
        double oldvalue;
        private void dgvQuoteItems_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgvQuoteItems.CurrentCell.OwningColumn.Index == 2 || dgvQuoteItems.CurrentCell.OwningColumn.Index == 3 || dgvQuoteItems.CurrentCell.OwningColumn.Index == 4)
            {
                oldvalue = Convert.ToDouble(dgvQuoteItems.CurrentCell.Value);
            }
        }

        #region PO quantity cost validating function
        private void Control_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (dgvQuoteItems.CurrentCell.OwningColumn.Index != 1)
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
                {
                    e.Handled = true;
                }
                if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
                {
                    e.Handled = true;
                }
            }
        }
        #endregion

        private void dgvQuoteItems_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
            }
        }

        private void dgvQuoteItems_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvQuoteItems.CurrentCell.Value != null)
            {
                if (!string.IsNullOrEmpty(dgvQuoteItems.CurrentCell.Value.ToString()) && (dgvQuoteItems.CurrentCell.Value.ToString() != "."))
                {
                    switch (dgvQuoteItems.CurrentCell.OwningColumn.Index)
                    {
                        case 2:
                        case 3:
                            //dgvQuoteItems.CurrentRow.Cells[5].Value = ((Convert.ToDouble(dgvQuoteItems.CurrentRow.Cells[2].Value)) * (Convert.ToDouble(dgvQuoteItems.CurrentRow.Cells[3].Value)));
                            //fnTotalAmount();
                            //break;
                        case 4:
                            dgvQuoteItems.CurrentRow.Cells[5].Value = (((Convert.ToDouble(dgvQuoteItems.CurrentRow.Cells[2].Value)) * (Convert.ToDouble(dgvQuoteItems.CurrentRow.Cells[3].Value))) - (Convert.ToDouble(dgvQuoteItems.CurrentRow.Cells[4].Value) * Convert.ToDouble(dgvQuoteItems.CurrentRow.Cells[2].Value) * Convert.ToDouble(dgvQuoteItems.CurrentRow.Cells[3].Value))/100);
                            fnTotalAmount();
                            break;
                    }
                }
                else
                {
                    dgvQuoteItems.CurrentCell.Value = 0;
                }
            }
        }
        double dTotal = 0;
        private void fnTotalAmount()
        {
            dTotal = 0;
            foreach (DataGridViewRow dr in dgvQuoteItems.Rows)
            {
                dTotal += (Convert.ToDouble(dr.Cells[5].Value));
            }
            txtCostValue.Text = (dTotal + (dTotal * (Convert.ToDouble(txtGstValue.Text))) / 100).ToString();
        }

        private void txtCostValue_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        bool bValidattion = false;
        private void fnRowCheck()
        {
            bValidattion = false;
            foreach (DataGridViewRow row in dgvQuoteItems.Rows)
            {

                if (row.Cells[1].Value != null)
                {

                    if (string.IsNullOrEmpty(row.Cells[1].Value.ToString().Trim()))
                    {
                        MessageBox.Show("Specifications not entered in list.", "Error", 0, MessageBoxIcon.Error);
                        bValidattion = true;
                        break;
                    }
                    //else if (Convert.ToString(row.Cells[2].Value) == "0" || (row.Cells[2].Value) == null)
                    //{
                    //    MessageBox.Show("Qunaity not entered in item list.", "Error", 0, MessageBoxIcon.Error);
                    //    bValidattion = true;
                    //    break;
                    //}
                    //else if (Convert.ToString(row.Cells[3].Value) == "0" || (row.Cells[3].Value) == null)
                    //{
                    //    MessageBox.Show("Unit cost not entered in list.", "Error", 0, MessageBoxIcon.Error);
                    //    bValidattion = true;
                    //    break;
                    //}
                    //else if (Convert.ToString(row.Cells[5].Value) == "0" || (row.Cells[5].Value) == null)
                    //{
                    //    MessageBox.Show("Amount not entered in list.", "Error", 0, MessageBoxIcon.Error);
                    //    bValidattion = true;
                    //    break;
                    //}
                }
                else
                {
                    MessageBox.Show("Specifications not entered in list.", "Error", 0, MessageBoxIcon.Error);
                    bValidattion = true;
                    break;
                }
            }
        }
        string sTestQuoteID;
        int iLastTestQuoteID;
        string sTestQuoteNumber;
        int iQuoteno;
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (btnSave.Text == "Save")
            {
                fnRowCheck();
                if (!bValidattion)
                {
                    if (cmbEnquireMonth.SelectedIndex >= 0 && cmbSubmittedMonth.SelectedIndex >= 0 && !string.IsNullOrEmpty(txtOffername.Text) && !string.IsNullOrEmpty(cmbTypeofIndustry.Text)
                        && cmbcustomertype.SelectedIndex >= 0 && !string.IsNullOrEmpty(cmbCustomer.Text) && !string.IsNullOrEmpty(txtcontactperson.Text)
                         && !string.IsNullOrEmpty(cmbApplicationtesttype.Text) && !string.IsNullOrEmpty(cmbMaterialType.Text) && !string.IsNullOrEmpty(cmbEightyMonth.Text) && dgvQuoteItems.Rows.Count > 0
                         && !string.IsNullOrEmpty(cmbregion.Text) && !string.IsNullOrEmpty(cmbstandardcustom.Text))
                    {

                        DataTable dtTestQuoteNumber = DAL.fnTestQuoteNumber(0, null).Tables[0];
                        if (dtTestQuoteNumber.Rows.Count > 0)
                        {
                            sTestQuoteID = dtTestQuoteNumber.Rows[0]["QuotationNumber"].ToString();
                            iQuoteno = Convert.ToInt32(dtTestQuoteNumber.Rows[0]["QuoteNo"].ToString());
                        }
                        if (!string.IsNullOrEmpty(sTestQuoteID))
                        {
                            sTestQuoteID = sTestQuoteID.Substring(5, 3);
                            iLastTestQuoteID = Convert.ToInt32(sTestQuoteID);
                        }
                        else
                        {
                            iLastTestQuoteID = 200;
                        }
                        iQuoteno++;
                        iLastTestQuoteID++;
                        sTestQuoteNumber = "";
                        string value = String.Format("{0:D3}", iLastTestQuoteID);
                        //sTestQuoteNumber = ("Q2022" + value + "/1");
                        sTestQuoteNumber = "Q" + DateTime.Now.Year.ToString() + value + "/1";

                        GlobalClass.iStatus = DAL.fnAddTestQuote(0, sTestQuoteNumber, cmbEnquireMonth.Text, cmbSubmittedMonth.Text, dtpporevisiondate.Text, cmbcustomertype.Text,
                            cmbCustomer.Text, txtcontactperson.Text, txtphonenumber.Text, txtOffername.Text, cmbTypeofIndustry.Text, cmbStatus.Text,
                            cmbBookingEstimation.Text, cmbBooked.Text, txtCostValue.Text, txtPONumber.Text, txtComment.Text, login.GetUserDetails[2].ToString(), txtGstValue.Text,
                            cmbApplicationtesttype.Text, cmbMaterialType.Text, cmbEightyMonth.Text, txtDepartment.Text, txtEmailID.Text, Convert.ToDateTime(dtpporevisiondate.Text).Year.ToString(),
                            cmbregion.Text, cmbstandardcustom.Text, iQuoteno,txtDesignation.Text,txtCustomerAddress.Text);
                        foreach (DataGridViewRow dr in dgvQuoteItems.Rows)
                        {
                            GlobalClass.iStatus = DAL.fnAddTestQuoteItems(0, sTestQuoteNumber, dr.Cells[0].Value.ToString(), dr.Cells[1].Value.ToString(), dr.Cells[2].Value.ToString(), dr.Cells[3].Value.ToString(), dr.Cells[5].Value.ToString(), dr.Cells[4].Value.ToString(), dr.Cells[6].Value.ToString());
                        }

                        MessageBox.Show("Offer number '" + sTestQuoteNumber + "' saved  successfully.", "Error", 0, MessageBoxIcon.Information);
                        btnSave.Enabled = false;
                    }
                    else
                    {
                        if (cmbEnquireMonth.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the enqyiry month.", "Error", 0, MessageBoxIcon.Error);
                            cmbEnquireMonth.DroppedDown = true;
                        }
                        else if (cmbSubmittedMonth.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the submitted month.", "Error", 0, MessageBoxIcon.Error);
                            cmbSubmittedMonth.DroppedDown = true;
                        }
                        else if (string.IsNullOrEmpty(txtOffername.Text))
                        {
                            MessageBox.Show("Enter the offer name.", "Error", 0, MessageBoxIcon.Error);
                            txtOffername.Focus();
                        }
                        else if (string.IsNullOrEmpty(cmbTypeofIndustry.Text))
                        {
                            MessageBox.Show("Enter or select the type of industry.", "Error", 0, MessageBoxIcon.Error);
                            cmbTypeofIndustry.DroppedDown = true;
                        }
                        else if (cmbcustomertype.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the customer type.", "Error", 0, MessageBoxIcon.Error);
                            cmbcustomertype.DroppedDown = true;
                        }
                        else if (string.IsNullOrEmpty(cmbCustomer.Text))
                        {
                            MessageBox.Show("Enter or select the customer name.", "Error", 0, MessageBoxIcon.Error);
                            cmbCustomer.DroppedDown = true;
                        }
                        else if (string.IsNullOrEmpty(txtcontactperson.Text))
                        {
                            MessageBox.Show("Enter the contact person name.", "Error", 0, MessageBoxIcon.Error);
                            txtcontactperson.Focus();
                        }

                        else if (string.IsNullOrEmpty(cmbEightyMonth.Text))
                        {
                            MessageBox.Show("Select the Customer 80/20.", "Error", 0, MessageBoxIcon.Error);
                            cmbEightyMonth.DroppedDown = true;
                        }
                        else if (string.IsNullOrEmpty(cmbApplicationtesttype.Text))
                        {
                            MessageBox.Show("Select the Applcation/Test Type.", "Error", 0, MessageBoxIcon.Error);
                            cmbApplicationtesttype.DroppedDown = true;
                        }
                        else if (string.IsNullOrEmpty(cmbMaterialType.Text))
                        {
                            MessageBox.Show("Select the material type.", "Error", 0, MessageBoxIcon.Error);
                            cmbMaterialType.DroppedDown = true;
                        }
                        else if (string.IsNullOrEmpty(cmbMaterialType.Text))
                        {
                            MessageBox.Show("Select the material type.", "Error", 0, MessageBoxIcon.Error);
                            cmbMaterialType.DroppedDown = true;
                        }
                        else if (string.IsNullOrEmpty(cmbregion.Text))
                        {
                            MessageBox.Show("Select the region.", "Error", 0, MessageBoxIcon.Error);
                            cmbregion.DroppedDown = true;
                        }

                        else if (string.IsNullOrEmpty(cmbstandardcustom.Text))
                        {
                            MessageBox.Show("Select the standardcustom.", "Error", 0, MessageBoxIcon.Error);
                            cmbstandardcustom.DroppedDown = true;
                        }

                        else if (dgvQuoteItems.Rows.Count == 0)
                        {
                            MessageBox.Show("Enter the quote specifications.", "Error", 0, MessageBoxIcon.Error);
                        }
                    }
                }

            }
            else if (btnSave.Text == "Update")
            {
                fnRowCheck();
                if (!bValidattion)
                {
                    //if (!string.IsNullOrEmpty(cmbStatus.Text) && cmbBookingEstimation.SelectedIndex >= 0 && cmbBooked.SelectedIndex >= 0 &&
                    //    !string.IsNullOrEmpty(txtCostValue.Text) && !string.IsNullOrEmpty(txtPONumber.Text) && dgvQuoteItems.Rows.Count > 0)
                    {

                        GlobalClass.iStatus = DAL.fnAddTestQuote(1, cmbOfferNumber.Text, cmbEnquireMonth.Text, cmbSubmittedMonth.Text, dtpporevisiondate.Text, cmbcustomertype.Text,
                          cmbCustomer.Text, txtcontactperson.Text, txtphonenumber.Text, txtOffername.Text, cmbTypeofIndustry.Text, cmbStatus.Text,
                          cmbBookingEstimation.Text, cmbBooked.Text, txtCostValue.Text, txtPONumber.Text, txtComment.Text, login.GetUserDetails[2].ToString(), txtGstValue.Text
                          , cmbApplicationtesttype.Text, cmbMaterialType.Text, cmbEightyMonth.Text, txtDepartment.Text, txtEmailID.Text, Convert.ToDateTime(dtpporevisiondate.Text).Year.ToString(),
                          cmbregion.Text, cmbstandardcustom.Text, 0, txtDesignation.Text, txtCustomerAddress.Text);

                        GlobalClass.iStatus = DAL.fnAddTestQuoteItems(2, cmbOfferNumber.Text, "", "", "", "","","","");


                        foreach (DataGridViewRow dr in dgvQuoteItems.Rows)
                        {
                            GlobalClass.iStatus = DAL.fnAddTestQuoteItems(0, cmbOfferNumber.Text, dr.Cells[0].Value.ToString(), dr.Cells[1].Value.ToString(), dr.Cells[2].Value.ToString(), dr.Cells[3].Value.ToString(), dr.Cells[5].Value.ToString(), dr.Cells[4].Value.ToString(), dr.Cells[6].Value.ToString());
                        }

                        MessageBox.Show("Offer number '" + cmbOfferNumber.Text + "' updated  successfully.", "Error", 0, MessageBoxIcon.Information);
                        btnSave.Enabled = false;
                    }
                    //else
                    //{
                    //    if (string.IsNullOrEmpty(cmbStatus.Text))
                    //    {
                    //        MessageBox.Show("Enter the status of quote.", "Error", 0, MessageBoxIcon.Error);
                    //        cmbStatus.Focus();
                    //    }
                    //    else if (cmbBookingEstimation.SelectedIndex < 0)
                    //    {
                    //        MessageBox.Show("Select the booking estimation month.", "Error", 0, MessageBoxIcon.Error);
                    //        cmbBookingEstimation.Focus();
                    //    }
                    //    else if (cmbBooked.SelectedIndex < 0)
                    //    {
                    //        MessageBox.Show("Select the booked month.", "Error", 0, MessageBoxIcon.Error);
                    //        cmbBooked.Focus();
                    //    }
                    //    else if (string.IsNullOrEmpty(txtCostValue.Text))
                    //    {
                    //        MessageBox.Show("Enter the total cost value of quote.", "Error", 0, MessageBoxIcon.Error);
                    //        txtCostValue.Focus();
                    //    }
                    //    else if (string.IsNullOrEmpty(txtPONumber.Text))
                    //    {
                    //        MessageBox.Show("Enter the PO number of quote.", "Error", 0, MessageBoxIcon.Error);
                    //        txtPONumber.Focus();
                    //    }
                    //    else if (dgvQuoteItems.Rows.Count == 0)
                    //    {
                    //        MessageBox.Show("Enter the quote specifications.", "Error", 0, MessageBoxIcon.Error);
                    //    }
                    //}
                }
            }
            else if (btnSave.Text == "Revise")
            {
                fnRowCheck();
                if (!bValidattion)
                {
                    if (cmbEnquireMonth.SelectedIndex >= 0 && cmbSubmittedMonth.SelectedIndex >= 0 && !string.IsNullOrEmpty(txtOffername.Text) && !string.IsNullOrEmpty(cmbTypeofIndustry.Text)
                        && cmbcustomertype.SelectedIndex >= 0 && !string.IsNullOrEmpty(cmbCustomer.Text) && !string.IsNullOrEmpty(txtcontactperson.Text)
                         && !string.IsNullOrEmpty(cmbApplicationtesttype.Text) && !string.IsNullOrEmpty(cmbMaterialType.Text) && !string.IsNullOrEmpty(cmbEightyMonth.Text) && dgvQuoteItems.Rows.Count > 0
                         && !string.IsNullOrEmpty(cmbregion.Text) && !string.IsNullOrEmpty(cmbstandardcustom.Text))
                    {                      

                        string[] sQuote;
                        sQuote=cmbOfferNumber.Text.Split('/');
                        DataTable dtTestQuoteNumber = DAL.fnTestQuoteNumber(5, sQuote[0]).Tables[0];

                        sTestQuoteID = dtTestQuoteNumber.Rows[0][1].ToString() ;
                        if (cmbOfferNumber.Text.Length == 10)
                            sTestQuoteID = sTestQuoteID.Substring(9, 1);
                        else if (cmbOfferNumber.Text.Length == 11)
                            sTestQuoteID = sTestQuoteID.Substring(9, 2);
                        else if (cmbOfferNumber.Text.Length == 12)
                            sTestQuoteID = sTestQuoteID.Substring(9, 3);

                        iLastTestQuoteID = Convert.ToInt32(sTestQuoteID);
                        

                        iLastTestQuoteID++;
                        sTestQuoteNumber = "";
                        sTestQuoteNumber = sQuote[0] + "/" + iLastTestQuoteID;

                        string sQuo = sQuote[0].TrimStart('Q');
                        iQuoteno = Convert.ToInt32(sQuo);
                        //string value = String.Format("{0:D3}", iLastTestQuoteID);
                        //sTestQuoteNumber = (sTestQuoteNumber + iLastTestQuoteID);

                        GlobalClass.iStatus = DAL.fnAddTestQuote(0, sTestQuoteNumber, cmbEnquireMonth.Text, cmbSubmittedMonth.Text, dtpporevisiondate.Text, cmbcustomertype.Text,
                            cmbCustomer.Text, txtcontactperson.Text, txtphonenumber.Text, txtOffername.Text, cmbTypeofIndustry.Text, cmbStatus.Text,
                            cmbBookingEstimation.Text, cmbBooked.Text, txtCostValue.Text, txtPONumber.Text, txtComment.Text, login.GetUserDetails[2].ToString(), txtGstValue.Text
                             , cmbApplicationtesttype.Text, cmbMaterialType.Text, cmbEightyMonth.Text, txtDepartment.Text, txtEmailID.Text, Convert.ToDateTime(dtpporevisiondate.Text).Year.ToString(),
                             cmbregion.Text, cmbstandardcustom.Text, iQuoteno, txtDesignation.Text, txtCustomerAddress.Text);
                        foreach (DataGridViewRow dr in dgvQuoteItems.Rows)
                        {
                            GlobalClass.iStatus = DAL.fnAddTestQuoteItems(0, sTestQuoteNumber, dr.Cells[0].Value.ToString(), dr.Cells[1].Value.ToString(), dr.Cells[2].Value.ToString(), dr.Cells[3].Value.ToString(), dr.Cells[5].Value.ToString(), dr.Cells[4].Value.ToString(), dr.Cells[6].Value.ToString());
                        }

                        MessageBox.Show("Offer number '" + sTestQuoteNumber + "' revised successfully.", "Error", 0, MessageBoxIcon.Information);
                        btnSave.Enabled = false;

                    }
                    else
                    {
                        if (cmbEnquireMonth.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the enqyiry month.", "Error", 0, MessageBoxIcon.Error);
                            cmbEnquireMonth.DroppedDown = true;
                        }
                        else if (cmbSubmittedMonth.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the submitted month.", "Error", 0, MessageBoxIcon.Error);
                            cmbSubmittedMonth.DroppedDown = true;
                        }
                        else if (string.IsNullOrEmpty(txtOffername.Text))
                        {
                            MessageBox.Show("Enter the offer name.", "Error", 0, MessageBoxIcon.Error);
                            txtOffername.Focus();
                        }
                        else if (string.IsNullOrEmpty(cmbTypeofIndustry.Text))
                        {
                            MessageBox.Show("Enter or select the type of industry.", "Error", 0, MessageBoxIcon.Error);
                            cmbTypeofIndustry.DroppedDown = true;
                        }
                        else if (cmbcustomertype.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the customer type.", "Error", 0, MessageBoxIcon.Error);
                            cmbcustomertype.DroppedDown = true;
                        }
                        else if (string.IsNullOrEmpty(cmbCustomer.Text))
                        {
                            MessageBox.Show("Enter or select the customer name.", "Error", 0, MessageBoxIcon.Error);
                            cmbCustomer.DroppedDown = true;
                        }
                        else if (string.IsNullOrEmpty(txtcontactperson.Text))
                        {
                            MessageBox.Show("Enter the contact person name.", "Error", 0, MessageBoxIcon.Error);
                            txtcontactperson.Focus();
                        }

                        else if (string.IsNullOrEmpty(cmbEightyMonth.Text))
                        {
                            MessageBox.Show("Select the Customer 80/20.", "Error", 0, MessageBoxIcon.Error);
                            cmbEightyMonth.DroppedDown = true;
                        }
                        else if (string.IsNullOrEmpty(cmbApplicationtesttype.Text))
                        {
                            MessageBox.Show("Select the Applcation/Test Type.", "Error", 0, MessageBoxIcon.Error);
                            cmbApplicationtesttype.DroppedDown = true;
                        }
                        else if (string.IsNullOrEmpty(cmbMaterialType.Text))
                        {
                            MessageBox.Show("Select the material type.", "Error", 0, MessageBoxIcon.Error);
                            cmbMaterialType.DroppedDown = true;
                        }
                        else if (string.IsNullOrEmpty(cmbMaterialType.Text))
                        {
                            MessageBox.Show("Select the material type.", "Error", 0, MessageBoxIcon.Error);
                            cmbMaterialType.DroppedDown = true;
                        }
                        else if (string.IsNullOrEmpty(cmbregion.Text))
                        {
                            MessageBox.Show("Select the region.", "Error", 0, MessageBoxIcon.Error);
                            cmbregion.DroppedDown = true;
                        }

                        else if (string.IsNullOrEmpty(cmbstandardcustom.Text))
                        {
                            MessageBox.Show("Select the standardcustom.", "Error", 0, MessageBoxIcon.Error);
                            cmbstandardcustom.DroppedDown = true;
                        }

                        else if (dgvQuoteItems.Rows.Count == 0)
                        {
                            MessageBox.Show("Enter the quote specifications.", "Error", 0, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            else if (btnSave.Text == "Print")
            {
                fnFileSavePath();
                fnTestingQuote();
            }
        }
        DataTable dtOfferNumbers = new DataTable();
        private void btnNewQuote_Click(object sender, EventArgs e)
        {


        }

        private void fnLoadOffernumber()
        {
            fnTestQuoteClear();
            dtOfferNumbers = DAL.fnTestQuoteNumber(1, null).Tables[0];
            cmbOfferNumber.Items.Clear();
            cmbOfferNumber.SelectedIndex = -1;
            foreach (DataRow DR in dtOfferNumbers.Rows)
            {
                if (!cmbOfferNumber.Items.Contains(DR["QuotationNumber"].ToString()))
                    cmbOfferNumber.Items.Add(DR["QuotationNumber"].ToString());
            }
        }

        private void btnUpdateQuote_Click(object sender, EventArgs e)
        {

        }

        private void btnReviseQuote_Click(object sender, EventArgs e)
        {

        }

        private void dgvQuoteItems_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (dgvQuoteItems.Rows.Count > 0)
                {
                    DialogResult DR = MessageBox.Show("Do you want to delete selected row", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (DR == DialogResult.Yes)
                        dgvQuoteItems.Rows.RemoveAt(dgvQuoteItems.Rows.IndexOf(dgvQuoteItems.CurrentRow));
                    //int i = 1;
                    //foreach (DataGridViewRow row in dgvQuoteItems.Rows)
                    //{
                    //    row.Cells[0].Value = i;
                    //    i++;
                    //}
                }
            }
        }
        DataTable dtOfferDeatils = new DataTable();
        DataTable dtOfferItemDeatils = new DataTable();
        private void cmbOfferNumber_SelectedIndexChanged(object sender, EventArgs e)
        {
            fnTestQuoteClear();
            dtOfferDeatils = DAL.fnTestQuoteNumber(2, cmbOfferNumber.Text).Tables[0];
            dtOfferItemDeatils = DAL.fnTestQuoteNumber(3, cmbOfferNumber.Text).Tables[0];
            if (dtOfferDeatils.Rows.Count > 0)
            {
                cmbEnquireMonth.SelectedItem = dtOfferDeatils.Rows[0][2].ToString();
                cmbSubmittedMonth.SelectedItem = dtOfferDeatils.Rows[0][3].ToString();
                cmbcustomertype.SelectedItem = dtOfferDeatils.Rows[0][5].ToString();
                cmbCustomer.Text = dtOfferDeatils.Rows[0][6].ToString();
                txtcontactperson.Text = dtOfferDeatils.Rows[0][7].ToString();
                txtphonenumber.Text = dtOfferDeatils.Rows[0][8].ToString();
                txtOffername.Text = dtOfferDeatils.Rows[0][9].ToString();
                cmbTypeofIndustry.Text = dtOfferDeatils.Rows[0][10].ToString();
                cmbStatus.Text = dtOfferDeatils.Rows[0][11].ToString();
                cmbBookingEstimation.SelectedItem = dtOfferDeatils.Rows[0][12].ToString();
                cmbBooked.SelectedItem = dtOfferDeatils.Rows[0][13].ToString();
                txtCostValue.Text = dtOfferDeatils.Rows[0][14].ToString();
                txtPONumber.Text = dtOfferDeatils.Rows[0][15].ToString();
                txtComment.Text = dtOfferDeatils.Rows[0][16].ToString();
                txtGstValue.Text = dtOfferDeatils.Rows[0][19].ToString();
                cmbApplicationtesttype.Text = dtOfferDeatils.Rows[0][20].ToString();
                cmbMaterialType.Text = dtOfferDeatils.Rows[0][21].ToString();
                cmbEightyMonth.Text = dtOfferDeatils.Rows[0][22].ToString();
                txtDepartment.Text = dtOfferDeatils.Rows[0][23].ToString();
                txtEmailID.Text = dtOfferDeatils.Rows[0][24].ToString();
                cmbregion.Text = dtOfferDeatils.Rows[0]["Region"].ToString();
                cmbstandardcustom.Text = dtOfferDeatils.Rows[0]["StandardCustom"].ToString();
                txtDesignation.Text = dtOfferDeatils.Rows[0]["Designation"].ToString();
                txtCustomerAddress.Text = dtOfferDeatils.Rows[0]["CustomerAddress"].ToString();
            }
            if (dtOfferItemDeatils.Rows.Count > 0)
            {
                dgvQuoteItems.AutoGenerateColumns = false;
                dgvQuoteItems.DataSource = dtOfferItemDeatils;
            }
        }

        private void fnFileSavePath()
        {
            if (Properties.Settings.Default.TestQuotePath == "C:\\Users\\SOFTWARE8\\Documents\\Quotation")
            {
                DialogResult result = folderBrowserDialog1.ShowDialog();
                if (result == DialogResult.OK)
                {
                    Properties.Settings.Default.TestQuotePath = folderBrowserDialog1.SelectedPath;
                    Properties.Settings.Default.Save();
                }
            }
        }

        #region Testing Quote
        private void fnTestingQuote()
        {
            try
            {
                dtOfferItemDeatils = DAL.fnTestQuoteNumber(31, cmbOfferNumber.Text).Tables[0];

                int iRowIndex = 1;
                string ExcelFolderName;
                string ExcelFolderPath;
                string FileFullPath;
                string FileFul;
                EXCEL.Workbook NewWorkBook;
                EXCEL.Worksheet NewWorkSheet;
                EXCEL.Application ExcelApp;
                EXCEL.Range CELLS, cell1, cell2;
                {
                    object misValue;
                    ExcelFolderPath = Properties.Settings.Default.TestQuotePath; 
                    ExcelFolderName = "\\Quotation";
                    //ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + ExcelFolderName + "\\";
                    FileFullPath = ExcelFolderPath + "\\"  +cmbOfferNumber.Text.Replace("/", "-") + "-BiSS Testing Service Quotation.xlsx"; //" + DateTime.Now.ToString("d/M/yyyy HH/mm/ss") + "
                    FileFul = ExcelFolderPath + "\\"  +cmbOfferNumber.Text.Replace("/", "-") + "-BiSS Testing Service Quotation.pdf"; //" + DateTime.Now.ToString("d/M/yyyy HH/mm/ss") + "
                    string[] Text = { "", "", Global.sCompanyName, "497E, 14 Cross, 4th Phase", "Peenya Industrial Area Bangalore 560 058", 
                                        "Phone: +91 80 28360047", "Web: http://www.biss.in, Email - testing@biss.in", "", "","",""
                                        ,cmbCustomer.Text,txtCustomerAddress.Text, "","","",
                                "Kind Attention : "+txtcontactperson.Text +"","","Email : "+txtEmailID.Text+"","",
                                "Contact No : "+txtphonenumber.Text+"",
                                "","","Offer No.: "+ "BiSS/IND/TS/" + cmbOfferNumber.Text,
                                "Date : "+dtpporevisiondate.Text+"","","" };

                    //string[] Text1 = { "Web: http://www.biss.in Email - testing@biss.in" };

                 //   string[] Text2 = { cmbCustomer.Text, "Kind Attn: Mr. " + txtcontactperson.Text.Trim() + "", "BiSS/IND/TS/" + cmbOfferNumber.Text, "", txtOffername.Text };

                    string[] Text3 = { "Scope of contract:",
                                     "Customer responsibility:", 
                                    "• It is requested that all the specimens as referred in the quotation should be sent at once in ready to test condition.",
                                     "• Splitting a batch into smaller batches of specimens will attract extra set up cost for testing.",
                                     "• At least two spare specimens per batch are to be supplied by the customer.",
                                     "• Freight and logistics is customers responsibility.",
                                     "• Tested specimens should be picked up from BiSS Labs within 7days from the date of completion of the tests. It",
                                     "may please be noted that BiSS is not responsible for the safety of the tested specimens beyond this period.",
                                     "•  Late Payment Penalty: The balance of any amount which remains unpaid more than thirty (30) days after it is due",
                                     "or the applicable payment date, shall accrue daily interest in the amount of the current annual interest rate from",
                                     "the original date said payment was due until the date of payment is received by BiSS.",
                                     "","Term of Contract: ",
                                     "• The hours of testing refer to the minimum chargeable hours.",
                                     "• The chargeable hours are the minimum stipulated hours for each test irrespective of an early failure. Additional",
                                     "amount per hour basis will be charged if the specimen fails beyond the stipulated hours of testing.",
                                     "• Unit cost is applicable only if the number of specimens is equal to or the more than the minimum.",
                                     "• The number of hours will be rounded off to the next higher hour.",
                                     "• Idle charges for the machine will be INR 300 per hour. This will be applicable when there is a delay in the supply ",
                                     "of specimens for testing after the set up ready.",
                                     "• The test fixtures designed or manufactured at BiSS are the property of BiSS.",
                                     "• The charges towards delivery of specimens to BiSS Labs for testing and pick up of specimens from BiSS Labs after ",
                                     "testing are kindly to borne by the customer.",
                                     ""};

                    string[] Text4 = { "Validity: 45 days","",
                                     "Payment:",
                                     "• 100% advance must be paid during the release of PO",
                                     "• Invoice will be raised at the end of the month for the completed tests till the tenure of the total test program,",
                                     "• Late Payment Penalty: The balance of any amount which remains unpaid more than",
                                     "thirty (30) days after it is due or the applicable payment date, shall accrue daily interest in",
                                     "the amount of the current annual interest rate from the original date said payment was",
                                     "due until the date of payment is received by BiSS. ",
                                     "","• GST Number : 29AAACI4550Q2Z1",
                                     "• SAC Code : 998346",
                                     "• PAN No.: AAACI4550Q","",
                                     "All payments to be made through BANK: CITI Bank, BRANCH: Bangalore, ADDRESS: MG Road, Bangalore-560001,",
                                     "Account No.: 0522113018, IFSC Code: CITI0000004, SWIFT CODE: CITIINBXBLR","" };

                    string[] Text5 = { "IPR advisory:",
                                     "Our equipment includes one or more items of novel design that are in the process of being protected by patents.",
                                     "By accepting our supply, customer undertakes to respect IPR by avoiding study, duplication or transfer of any",
                                     "proprietary mechanical, electronic or software device from ITW India Pvt Ltd (BISS Division), as these items are",
                                     "released for immediate usage in the best interest of customer."};

                    if (!Directory.Exists(ExcelFolderPath))
                        Directory.CreateDirectory(ExcelFolderPath);

                    ExcelApp = new EXCEL.Application();
                    misValue = System.Reflection.Missing.Value;
                    try
                    {
                        if (ExcelApp == null)
                            MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                        NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                        NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                        if (NewWorkSheet == null)
                            MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                        else
                            NewWorkSheet.Name = "Quote";
                        EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                        if (RANGE == null)
                            MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                        NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        CELLS = NewWorkSheet.Cells;
                        NewWorkSheet.get_Range("A1", "G9999").Cells.Font.Name = "Arial";
                        NewWorkSheet.Range["A1 :G9999"].Cells.Font.Size = 14;
                        foreach (string str in Text)
                        {
                            NewWorkSheet.Cells[iRowIndex, 1] = str;
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                            iRowIndex++;
                        }

                        NewWorkSheet.get_Range("A2", "G9000").Cells.Font.Size = 13;
                        NewWorkSheet.Range["A3:D3"].Cells.Font.Bold = true;
                        NewWorkSheet.Range["A8:D8"].Cells.Font.Bold = true;
                        NewWorkSheet.Range["A12:D12"].Cells.Font.Bold = true;
                        CellMerge("Merge", NewWorkSheet, 13, 16, 1, 4);
                        NewWorkSheet.Range["A13:A13"].Cells.WrapText = true;
                        CellMerge("AlignTop", NewWorkSheet, 13, 13, 1, 4);
                        NewWorkSheet.Range["A17:D32"].Cells.Font.Bold = true;

                        NewWorkSheet.Cells[24, 5] = "GSTIN - 29AAACI4550Q2Z1";
                        CellMerge("Merge", NewWorkSheet, 24, 24, 5, 7);
                        NewWorkSheet.Cells[25, 5] = "HSN/SAC - 998346";
                        CellMerge("Merge", NewWorkSheet, 25, 25, 5, 7);
                        NewWorkSheet.Range["E24:E25"].Cells.Font.Bold = true;
                        CellMerge("AlignLeft", NewWorkSheet, 1, 25, 1, 6);

                        if (File.Exists(Global.sTQTestLabLogo))
                        {
                            EXCEL.Range oRange1 = (EXCEL.Range)NewWorkSheet.Cells[28, 1];
                            Image oImage1 = Image.FromFile(Global.sTQTestLabLogo);
                            System.Windows.Forms.Clipboard.SetDataObject(oImage1, true);
                          //  NewWorkSheet.Paste(oRange1, Global.sTQTestLabLogo);
                            System.Threading.Thread.Sleep(500);
                            NewWorkSheet.Paste(oRange1);
                        }


                        NewWorkSheet.Cells[44, 1] = "Prepared : " + login.GetUserDetails[2] + "";
                        CellMerge("Merge", NewWorkSheet, 44, 44, 1, 4);
                        CellMerge("AlignLeft", NewWorkSheet, 44, 44, 1, 4);
                        NewWorkSheet.Cells[45, 1] = "Contact : " + login.GetUserDetails[50] + "  " + login.GetUserDetails[20] + "";
                        CellMerge("Merge", NewWorkSheet, 45, 45, 1, 4);
                        CellMerge("AlignLeft", NewWorkSheet, 45, 45, 1, 4);
                        CellMerge("Bold", NewWorkSheet, 44, 45, 1, 4);

                        iRowIndex = 46;

                        NewWorkSheet.HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);
                        NewWorkSheet.Cells[iRowIndex, 1] = txtOffername.Text.Trim();
                        NewWorkSheet.Cells[iRowIndex, 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                        NewWorkSheet.Range["A" + iRowIndex + ":E" + iRowIndex + ""].Cells.WrapText = true;
                        NewWorkSheet.Rows[iRowIndex].RowHeight = 45;
                        NewWorkSheet.get_Range("A" + iRowIndex + "", "E" + iRowIndex + "").Cells.Font.Size = 18;
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                        CellMerge("VAlignCentre", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                        CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                        CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                        NewWorkSheet.Cells[iRowIndex, 1].Font.Color = Color.FromArgb(186, 12, 47);
                      //  NewWorkSheet.Range["A8:D8"].Cells.Font.Size = true;
                     //   iRowIndex++;
                        NewWorkSheet.Rows[iRowIndex+1].RowHeight = 30;
                        string finalColLetter = string.Empty;
                       // iRowIndex++;
                        iRowIndex++;
                        NewWorkSheet.Cells[(iRowIndex), 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                        NewWorkSheet.Cells[(iRowIndex), 2].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                        NewWorkSheet.Cells[(iRowIndex), 3].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                        NewWorkSheet.Cells[(iRowIndex), 4].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                        NewWorkSheet.Cells[(iRowIndex), 5].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                        CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                        if (dtOfferItemDeatils.Rows.Count > 0)
                        {
                            object[,] rawData = new object[dtOfferItemDeatils.Rows.Count + 1, dtOfferItemDeatils.Columns.Count];
                            for (int col = 0; col < dtOfferItemDeatils.Columns.Count; col++)
                            {
                                rawData[0, col] = dtOfferItemDeatils.Columns[col].ColumnName;
                            }
                            for (int row = 0; row < dtOfferItemDeatils.Rows.Count; row++)
                            {
                                for (int col = 0; col < dtOfferItemDeatils.Columns.Count; col++)
                                {
                                    rawData[row + 1, col] = dtOfferItemDeatils.Rows[row].ItemArray[col];
                                }
                            }
                            string excelRange = string.Empty;
                            finalColLetter = string.Empty;
                            string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                            int colCharsetLen = colCharset.Length;

                            if (dtOfferItemDeatils.Columns.Count > colCharsetLen)
                            {
                                finalColLetter = colCharset.Substring((dtOfferItemDeatils.Columns.Count - 1) / colCharsetLen - 1, 1);
                            }
                            finalColLetter += colCharset.Substring((dtOfferItemDeatils.Columns.Count - 1) % colCharsetLen, 1);
                            excelRange = string.Format("A" + iRowIndex + ":{0}{1}", "E", (iRowIndex + dtOfferItemDeatils.Rows.Count));
                            NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        }

                        NewWorkSheet.Cells[iRowIndex, 4] = "Unit price, INR";
                        NewWorkSheet.Cells[iRowIndex, 5] = "Amount, INR";
                      //  CellMerge("AlignCenter", NewWorkSheet, 15, 15, 1, 6);
                     //   CellMerge("VAlignCentre", NewWorkSheet, 15, 15, 1, 6);

                        //CellMerge("AlignTop", NewWorkSheet, (16), (iRowIndex + dtOfferItemDeatils.Rows.Count), 3, 3);
                        CellMerge("AlignCenter", NewWorkSheet, (iRowIndex), (iRowIndex + dtOfferItemDeatils.Rows.Count), 1, 1);
                        CellMerge("AlignCenter", NewWorkSheet, (iRowIndex), (iRowIndex + 1), 2, 2);
                        CellMerge("AlignLeft", NewWorkSheet, (iRowIndex+1), (iRowIndex + dtOfferItemDeatils.Rows.Count), 2, 2);
                        CellMerge("AlignCenter", NewWorkSheet, (iRowIndex), (iRowIndex + dtOfferItemDeatils.Rows.Count), 3, 3);
                        CellMerge("AlignCenter", NewWorkSheet, (iRowIndex), (iRowIndex + dtOfferItemDeatils.Rows.Count), 4, 6);
                        CellMerge("VAlignCentre", NewWorkSheet, (iRowIndex), (iRowIndex + dtOfferItemDeatils.Rows.Count), 1, 2);
                        CellMerge("VAlignCentre", NewWorkSheet, (iRowIndex), (iRowIndex + dtOfferItemDeatils.Rows.Count+3), 3, 6);

                        NewWorkSheet.Cells[(iRowIndex + dtOfferItemDeatils.Rows.Count + 1), 1] = "Base Price";
                        NewWorkSheet.Cells[(iRowIndex + dtOfferItemDeatils.Rows.Count + 2), 1] = "GST, " + txtGstValue.Text + " %";
                        NewWorkSheet.Cells[(iRowIndex + dtOfferItemDeatils.Rows.Count + 3), 1] = "Grand Total";
                        CellMerge("AlignRight", NewWorkSheet, (iRowIndex + dtOfferItemDeatils.Rows.Count + 1), (iRowIndex + dtOfferItemDeatils.Rows.Count + 3), 1, 4);
                        CellMerge("VAlignCentre", NewWorkSheet, (iRowIndex + dtOfferItemDeatils.Rows.Count + 1), (iRowIndex + dtOfferItemDeatils.Rows.Count + 3), 1, 6);
                        CellMerge("AlignCenter", NewWorkSheet, (iRowIndex + dtOfferItemDeatils.Rows.Count + 1), (iRowIndex + dtOfferItemDeatils.Rows.Count + 3), 5, 5);
                        fnTotalAmount();
                        NewWorkSheet.Cells[(iRowIndex + dtOfferItemDeatils.Rows.Count + 1), 5] = dTotal.ToString();
                        NewWorkSheet.Cells[(iRowIndex + dtOfferItemDeatils.Rows.Count + 2), 5] = (Convert.ToDouble(txtCostValue.Text) - Convert.ToDouble(dTotal)).ToString(); ;
                        NewWorkSheet.Cells[(iRowIndex + dtOfferItemDeatils.Rows.Count + 3), 5] = txtCostValue.Text;

                        //NewWorkSheet.Range["A" + (15) + ":E" + (15) + ""].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(217, 217, 217));
                        ////NewWorkSheet.Range["A" + (iRowIndex + dtOfferItemDeatils.Rows.Count + 1) + ":E" + (iRowIndex + dtOfferItemDeatils.Rows.Count + 3) + ""].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(217, 217, 217));

                        CellMerge("Merge", NewWorkSheet, (iRowIndex + dtOfferItemDeatils.Rows.Count + 1), (iRowIndex + dtOfferItemDeatils.Rows.Count + 1), 1, 4);
                        CellMerge("Merge", NewWorkSheet, (iRowIndex + dtOfferItemDeatils.Rows.Count + 2), (iRowIndex + dtOfferItemDeatils.Rows.Count + 2), 1, 4);
                        CellMerge("Merge", NewWorkSheet, (iRowIndex + dtOfferItemDeatils.Rows.Count + 3), (iRowIndex + dtOfferItemDeatils.Rows.Count + 3), 1, 4);
                        NewWorkSheet.Range["A" + (iRowIndex + dtOfferItemDeatils.Rows.Count + 1) + ":E" + (iRowIndex + dtOfferItemDeatils.Rows.Count + 3) + ""].Cells.Font.Bold = true;
                      //  NewWorkSheet.Range["A" + (iRowIndex + dtOfferItemDeatils.Rows.Count + 1) + ":F" + (iRowIndex + dtOfferItemDeatils.Rows.Count + 3) + ""].Cells.Font.Size = 12;

                        CellMerge("GridLines", NewWorkSheet, (iRowIndex-1), ((iRowIndex + 3) + dtOfferItemDeatils.Rows.Count), 1, 5);

                        iRowIndex = (iRowIndex + dtOfferItemDeatils.Rows.Count + 4);
                        NewWorkSheet.Range["B" + iRowIndex + ":B" + (iRowIndex + 1) + ""].Cells.Font.Color = Color.Blue;
                        NewWorkSheet.Range["A" + iRowIndex + ":F" + (iRowIndex + 15) + ""].Cells.Font.Bold = true;

                        NewWorkSheet.HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);

                        foreach (string str in Text4)
                        {
                            NewWorkSheet.Cells[iRowIndex, 1] = str;
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                            iRowIndex++;
                        }

                       

                        NewWorkSheet.Range["A" + iRowIndex + ":F" + (iRowIndex + 1) + ""].Cells.Font.Bold = true;
                        NewWorkSheet.Range["A" + iRowIndex + ":F" + (iRowIndex) + ""].Cells.Font.Color = Color.Blue;
                        NewWorkSheet.Range["A" + (iRowIndex + 12) + ":F" + (iRowIndex + 12) + ""].Cells.Font.Bold = true;
                      
                        foreach (string str in Text3)
                        {
                            NewWorkSheet.Cells[iRowIndex, 1] = str;
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                            iRowIndex++;
                        }
                        
                        NewWorkSheet.Range["A" + iRowIndex + ":F" + (iRowIndex) + ""].Cells.Font.Bold = true;
                        NewWorkSheet.Range["A" + iRowIndex + ":F" + (iRowIndex) + ""].Cells.Font.Color = Color.Blue;
                      //  NewWorkSheet.Range["A" + iRowIndex + ":F" + (iRowIndex + 5) + ""].Cells.Font.Size = 12;
                        foreach (string str in Text5)
                        {
                            NewWorkSheet.Cells[iRowIndex, 1] = str;
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 7);
                            iRowIndex++;
                        }
                       
                        NewWorkSheet.Cells[iRowIndex, 1].Characters(0, 16).Font.FontStyle = "Bold";
                        // CellMerge("BorderAround", NewWorkSheet, 1, iRowIndex, 1, 7);
                        //NewWorkSheet.Range["B" + (41 + dtOfferItemDeatils.Rows.Count) + ":E" + (iRowIndex - 6 + 1) + ""].Cells.Font.Bold = true;
                        Microsoft.Office.Interop.Excel.Range range3 = NewWorkSheet.get_Range("D48", "E" + (51 + dtOfferItemDeatils.Rows.Count) + "");
                        range3.NumberFormat = "0,00";

                        //Microsoft.Office.Interop.Excel.Range range4 = NewWorkSheet.get_Range("F" + 39 + "", "F" + (39 + dtOfferItemDeatils.Rows.Count + 2) + "");
                        //range4.NumberFormat = "0,00";


                      //  NewWorkSheet.Columns[1].ColumnWidth = 5;
                        NewWorkSheet.Columns[1].ColumnWidth = 7;
                        NewWorkSheet.Columns[2].ColumnWidth = 50;
                        NewWorkSheet.Columns[2].WrapText = true;
                        NewWorkSheet.Columns[3].ColumnWidth = 11;
                        NewWorkSheet.Columns[4].ColumnWidth = 18;
                        NewWorkSheet.Columns[5].ColumnWidth = 18;
                        NewWorkSheet.Columns[6].ColumnWidth = 9;
                        NewWorkSheet.Columns[7].ColumnWidth = 5;

                        // NewWorkSheet.get_Range("A1", "E1").Cells.Font.Name = "Arial Black";
                        //NewWorkSheet.get_Range("A" + (42 + dtOfferItemDeatils.Rows.Count) + "", "E" + (47 + dtOfferItemDeatils.Rows.Count) + "").Cells.Font.Size = 10;
                        //NewWorkSheet.get_Range("A" + (47 + dtOfferItemDeatils.Rows.Count) + "", "E" + (51 + dtOfferItemDeatils.Rows.Count) + "").Cells.Font.Size = 12;
                        //NewWorkSheet.get_Range("A" + (52 + dtOfferItemDeatils.Rows.Count) + "", "E" + (63 + dtOfferItemDeatils.Rows.Count) + "").Cells.Font.Size = 10;

                        //NewWorkSheet.get_Range("A" + (59 + dtOfferItemDeatils.Rows.Count) + "", "E" + (59 + dtOfferItemDeatils.Rows.Count) + "").Cells.Font.Color = Color.Blue;

                        NewWorkSheet.Rows[1].RowHeight = 6;
                        NewWorkSheet.Rows[2].RowHeight = 42;
                        //NewWorkSheet.Rows[3].RowHeight = 18;
                        //NewWorkSheet.Rows[4].RowHeight = 18;
                        NewWorkSheet.Rows[13].RowHeight = 70;
                        NewWorkSheet.Rows[14].RowHeight = 2;
                        NewWorkSheet.Rows[15].RowHeight = 2;
                        NewWorkSheet.Rows[16].RowHeight = 2;
                        // NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                        NewWorkSheet.PageSetup.LeftHeader = "&I &10 &\"Arial\"" + cmbCustomer.Text + "";
                        //   NewWorkSheet.PageSetup.LeftHeader = "&I Italic text &I";
                        NewWorkSheet.PageSetup.RightHeader = "&I &10 &\"Arial\"" + "BiSS/IND/TS/" + cmbOfferNumber.Text + "\nDated:" + dtpporevisiondate.Text + "";
                        //NewWorkSheet.PageSetup.RightHeader = "&I Italic text &I";
                        // NewWorkSheet.PageSetup.CenterFooter = "&\"Arial\"&10 All prices are in INR ";

                        //NewWorkSheet.PageSetup.LeftFooterPicture.Filename = "C:\\Databasepath\\image (1).png";

                        //NewWorkSheet.PageSetup.LeftFooter = "&G";
                        //NewWorkSheet.PageSetup.CenterFooter = "&I &10 &\"Arial\" Page &P of &N";
                        // Assuming NewWorkSheet is a valid Excel.Worksheet object
                        string imgPath = @"C:\Databasepath\image (1).png";

                        try
                        {
                            if (File.Exists(imgPath))
                            {
                                // Set the footer image
                                NewWorkSheet.PageSetup.LeftFooterPicture.Filename = imgPath;
                                NewWorkSheet.PageSetup.LeftFooter = "&G"; // &G tells Excel to display the image
                            }
                            else
                            {
                                MessageBox.Show("Footer image not found at: " + imgPath, "Image Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }

                            // Set center footer with font and page numbering
                            NewWorkSheet.PageSetup.CenterFooter = "&I &10 &\"Arial\" Page &P of &N";
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error setting footer image or text:\n" + ex.Message, "Footer Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }

                        //NewWorkSheet.PageSetup.CenterFooter = "&I &10 &\"Arial\" Page &P of &N";
                        // NewWorkSheet.PageSetup.CenterFooter = "&I Italic text &I";
                        // NewWorkSheet.PageSetup.PrintNotes = true;
                        NewWorkSheet.PageSetup.PrintArea = "A1:G" + iRowIndex + "";
                        NewWorkSheet.PageSetup.Zoom = 78;
                       
                        //NewWorkSheet.PageSetup.Zoom = 100;
                        //NewWorkSheet.PageSetup.Zoom = false;
                        //NewWorkSheet.PageSetup.FitToPagesTall = 1;
                        NewWorkSheet.PageSetup.AlignMarginsHeaderFooter = false;
                        // NewWorkSheet.PageSetup.FitToPagesWide = 1;

                        NewWorkSheet.PageSetup.LeftMargin = 0.3;
                        NewWorkSheet.PageSetup.RightMargin = 0.3;
                        NewWorkSheet.PageSetup.CenterHorizontally = true;
                        //NewWorkSheet.PageSetup.LeftMargin = (0.75 * 60);
                        //NewWorkSheet.PageSetup.RightMargin = (0.75 * 30);
                        //NewWorkSheet.PageSetup.TopMargin = (0.75 * 30);
                        //NewWorkSheet.PageSetup.BottomMargin = (0.75 * 30);
                        //NewWorkSheet.PageSetup.HeaderMargin = (0.1 * 72);
                        //NewWorkSheet.PageSetup.FooterMargin = (0.5 * 72);
                        NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                        NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                        //  string _stLOGO = "C:\\Databasepath\\BissQuote.jpg";

                        if (File.Exists(Global.sTQLogo))
                        {
                            EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[1, 1];

                            Image oImage = Image.FromFile(Global.sTQLogo);
                            System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                          //  NewWorkSheet.Paste(oRange, Global.sTQLogo);
                            System.Threading.Thread.Sleep(500);
                            NewWorkSheet.Paste(oRange);
                        }

                        if (File.Exists(Global.sLogo12))
                        {
                            EXCEL.Range oRange1 = (EXCEL.Range)NewWorkSheet.Cells[1, 5];

                            Image oImage = Image.FromFile(Global.sLogo12);
                            System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                           // NewWorkSheet.Paste(oRange1, Global.sLogo);
                            System.Threading.Thread.Sleep(500);
                            NewWorkSheet.Paste(oRange1);

                        }


                        //EXCEL.Range oRange1 = (EXCEL.Range)NewWorkSheet.Cells[1, 1];

                        //Image oImage1 = Image.FromFile(Global.sITWLogo);
                        //System.Windows.Forms.Clipboard.SetDataObject(oImage1, true);
                        //NewWorkSheet.Paste(oRange1, Global.sITWLogo);

                        NewWorkBook.Save();
                        ExcelApp.Visible = true;
                        //System.Threading.Thread.Sleep(1000);

                        NewWorkBook.ExportAsFixedFormat(EXCEL.XlFixedFormatType.xlTypePDF, FileFul, EXCEL.XlFixedFormatQuality.xlQualityStandard, true);
                        System.Diagnostics.Process.Start(FileFul);

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                        foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                        {
                            GetProcess.Kill();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("PurchaseOrder_btnReport_Click  " + ex.Message);
            }
        }
        #endregion
        //  CultureInfo india = new CultureInfo("hi-IN");
        #region CellMerge Funtion
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }

                case "TopBorder":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlDouble, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }

                case "GridLines":
                    {
                        CELLS.Borders.Color = System.Drawing.Color.Black;
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignCenter":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                        break;
                    }
                case "AlignRight":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                        break;
                    }
                case "AlignLeft":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignLeft;
                        break;
                    }
                case "VAlignCentre":
                    {
                        CELLS.VerticalAlignment = EXCEL.XlVAlign.xlVAlignCenter;
                        break;
                    }
                case "AlignTop":
                    {
                        CELLS.VerticalAlignment = EXCEL.XlVAlign.xlVAlignTop;
                        break;
                    }
                case "Bold":
                    {
                        CELLS.Font.Bold = true;
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

        }
        #endregion

        #region Excel App Release Object Function
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
        #endregion

        private void fnTestQuoteClear()
        {
            cmbEnquireMonth.SelectedIndex = -1;
            cmbSubmittedMonth.SelectedIndex = -1;
            cmbcustomertype.SelectedIndex = -1;
            cmbCustomer.Text = "";
            txtcontactperson.ResetText();
            txtphonenumber.ResetText();
            txtOffername.ResetText();
            cmbTypeofIndustry.Text = "";
            cmbStatus.Text = "";
            cmbBookingEstimation.SelectedIndex = -1; 
            cmbBooked.SelectedIndex = -1; 
            txtCostValue.ResetText();
            txtPONumber.ResetText();
            txtComment.ResetText();
            btnSave.Enabled = true;
            btnAddNewRow.Enabled = true;
            dgvQuoteItems.DataSource = null;
            txtDesignation.ResetText();
            txtCustomerAddress.ResetText();
            cmbApplicationtesttype.SelectedIndex = -1;
            cmbMaterialType.SelectedIndex = -1;
            cmbEightyMonth.SelectedIndex = -1;
            txtDepartment.ResetText();
            txtEmailID.ResetText();
            cmbstandardcustom.SelectedIndex = -1;
            cmbregion.SelectedIndex = -1;
        }

        private void btnPrintQuote_Click(object sender, EventArgs e)
        {

        }

        private void TestingQuote_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnExit();
        }
        private void fnExit()
        {
            this.Hide();
            form.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            fnExit();
        }

        private void txtGstValue_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtGstValue_TextChanged(object sender, EventArgs e)
        {
            if (txtGstValue.Text.Length > 0)
            {
                fnTotalAmount();
            }
        }

        private void btnViewQuote_Click(object sender, EventArgs e)
        {
            this.Hide();
            TestLabQuoteView TV = new TestLabQuoteView();
            TV.Show();
        }

        private void cmbSelectQuoteType_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbSelectQuoteType.SelectedIndex)
            {
                case 0:
                    btnSave.Text = "Save";
                    pnSaveQuote.Enabled = true;
                   // pnUpdateQuote.Enabled = false;
                    lblOfferNumber.Visible = false;
                    cmbOfferNumber.Visible = false;
                    btnAddNewRow.Enabled = true;
                    fnTestQuoteClear();
                    break;
                case 1:
                    btnSave.Text = "Update";
                    lblOfferNumber.Visible = true;
                    cmbOfferNumber.Visible = true;
                    pnSaveQuote.Enabled = true;
                   // pnUpdateQuote.Enabled = true;
                    fnLoadOffernumber();
                    break;
                case 2:
                    btnSave.Text = "Revise";
                    lblOfferNumber.Visible = true;
                    cmbOfferNumber.Visible = true;
                    pnSaveQuote.Enabled = true;
                   // pnUpdateQuote.Enabled = true;
                    fnLoadOffernumber();
                    break;
                case 3:
                    btnSave.Text = "Print";
                    lblOfferNumber.Visible = true;
                    cmbOfferNumber.Visible = true;
                    pnSaveQuote.Enabled = true;
                   // pnUpdateQuote.Enabled = true;
                    fnLoadOffernumber();
                    break;
            }
        }
        public DataGridView.HitTestInfo hitTestInfo { get; set; }
        private void dgvQuoteItems_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                hitTestInfo = dgvQuoteItems.HitTest(e.X, e.Y);
                if (hitTestInfo.Type == DataGridViewHitTestType.Cell)
                    dgvQuoteItems.BeginEdit(true);
                else
                    dgvQuoteItems.EndEdit();
            }
        }

        private void chkQuoteSavePath_CheckedChanged(object sender, EventArgs e)
        {
           // 

            if (chkQuoteSavePath.CheckState == CheckState.Checked)
            {
                if (MessageBox.Show("The default save location for quotes is '" + Properties.Settings.Default.TestQuotePath + "'\nClick on Yes to change the quote save location", "Save location", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                {
                    DialogResult result = folderBrowserDialog1.ShowDialog();
                    if (result == DialogResult.OK)
                    {
                        Properties.Settings.Default.TestQuotePath = folderBrowserDialog1.SelectedPath;
                        Properties.Settings.Default.Save();
                        MessageBox.Show("The default save location for quotes changed to the selected path '" + Properties.Settings.Default.TestQuotePath + "'", "Success", 0, MessageBoxIcon.Information);
                        chkQuoteSavePath.Checked = false;
                    }
                    else
                    {
                        chkQuoteSavePath.Checked = false;
                    }
                }
                else
                {
                    chkQuoteSavePath.Checked = false;
                }

            }
        }
        DataTable dtCusSerachDetails = new DataTable();
        BindingSource bsIteSearch = new BindingSource();
        DataTable dtClone = new DataTable();
        private void btnCusSearch_Click(object sender, EventArgs e)
        {
            pnCustomerDetails.Visible = true;
            dtCusSerachDetails = DAL.fnCustomerList(6, "").Tables[0];
            dgvQuoteView.AutoGenerateColumns = false;
            dgvQuoteView.DataSource = dtCusSerachDetails;
            dtClone = dtCusSerachDetails.Copy();
            bsIteSearch.DataSource = dtClone;
        }
        private void fnRowFilter(uint uSearchOption, string sRowFilter)    //filter the Item list depends upon the user inpts
        {
            if (dtCusSerachDetails.Rows.Count > 0)
            {
                switch (uSearchOption)
                {
                    case Global.uITEM_CODE_SEARCH:
                        {
                            bsIteSearch.Filter = string.Format("Customer LIKE '%{0}%'", sRowFilter);
                            break;
                        }
                }
            }
        }
        private void txtSearchText_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtSearchText.Text.Length > 2)
            {
                fnRowFilter(0, txtSearchText.Text);
                dgvQuoteView.DataSource = bsIteSearch;
            }
            else
            {
                bsIteSearch.RemoveFilter();
            }
        }

        private void dgvQuoteView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvQuoteView.Rows.Count > 0)
            {
                cmbCustomer.Text = dgvQuoteView.CurrentRow.Cells[0].Value.ToString();
                txtcontactperson.Text = dgvQuoteView.CurrentRow.Cells[1].Value.ToString();
                txtphonenumber.Text = dgvQuoteView.CurrentRow.Cells[2].Value.ToString();
                txtEmailID.Text = dgvQuoteView.CurrentRow.Cells[3].Value.ToString();
                txtDepartment.Text = dgvQuoteView.CurrentRow.Cells[4].Value.ToString();
                txtDesignation.Text = dgvQuoteView.CurrentRow.Cells[5].Value.ToString();
                txtCustomerAddress.Text = dgvQuoteView.CurrentRow.Cells[6].Value.ToString();
                cmbstandardcustom.SelectedItem = dgvQuoteView.CurrentRow.Cells[7].Value.ToString();
                cmbregion.SelectedItem = dgvQuoteView.CurrentRow.Cells[8].Value.ToString();
                cmbEightyMonth.SelectedItem = dgvQuoteView.CurrentRow.Cells[9].Value.ToString();
                cmbcustomertype.SelectedItem = dgvQuoteView.CurrentRow.Cells[10].Value.ToString();
                pnCustomerDetails.Visible = false;
                txtSearchText.ResetText();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            txtSearchText.ResetText();
            pnCustomerDetails.Visible = false;
        }
        DataRow newRow;
        private static int iCopy = 99;
        private void dgvQuoteItems_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.X && iCopy == 99 )
            {
                DataRow SelectedRow = dtOfferItemDeatils.Rows[dgvQuoteItems.SelectedCells[0].OwningRow.Index];
                newRow = dtOfferItemDeatils.NewRow();
                newRow.ItemArray = SelectedRow.ItemArray;
                dtOfferItemDeatils.Rows.Remove(SelectedRow);
                iCopy = 1;
            }
            else if (e.Control && e.KeyCode == Keys.V && iCopy == 1)
            {
                dtOfferItemDeatils.Rows.InsertAt(newRow, (dgvQuoteItems.SelectedCells[0].OwningRow.Index));
                iCopy = 99;
            }
        }

        private void dgvQuoteItems_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvQuoteItems.CurrentCell.ColumnIndex == 6)
            {
                if (dgvQuoteItems.CurrentCell.Value.ToString() == "No")
                {
                    dgvQuoteItems.CurrentCell.Value = "Yes";
                }
                else if (dgvQuoteItems.CurrentCell.Value.ToString() == "Yes")
                {
                    dgvQuoteItems.CurrentCell.Value = "No";
                }
            }
        }

        private void dgvQuoteItems_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
