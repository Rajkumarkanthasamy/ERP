﻿namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    partial class frmPegRate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPegRate));
            this.txtPegRate = new System.Windows.Forms.TextBox();
            this.lblpcode = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSavePegRate = new System.Windows.Forms.Button();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.chkPegRate = new System.Windows.Forms.CheckBox();
            this.dtpCreatedDate = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.txtOldPegRate = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtPegRate
            // 
            this.txtPegRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPegRate.Location = new System.Drawing.Point(127, 107);
            this.txtPegRate.Name = "txtPegRate";
            this.txtPegRate.Size = new System.Drawing.Size(153, 21);
            this.txtPegRate.TabIndex = 72;
            this.txtPegRate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPegRate_KeyPress);
            // 
            // lblpcode
            // 
            this.lblpcode.AutoSize = true;
            this.lblpcode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpcode.ForeColor = System.Drawing.Color.Black;
            this.lblpcode.Location = new System.Drawing.Point(54, 107);
            this.lblpcode.Name = "lblpcode";
            this.lblpcode.Size = new System.Drawing.Size(77, 19);
            this.lblpcode.TabIndex = 71;
            this.lblpcode.Text = "Peg Rate :";
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnExit.Location = new System.Drawing.Point(246, 222);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(119, 31);
            this.btnExit.TabIndex = 195;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSavePegRate
            // 
            this.btnSavePegRate.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnSavePegRate.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSavePegRate.Location = new System.Drawing.Point(84, 222);
            this.btnSavePegRate.Name = "btnSavePegRate";
            this.btnSavePegRate.Size = new System.Drawing.Size(129, 31);
            this.btnSavePegRate.TabIndex = 194;
            this.btnSavePegRate.Text = "Save Peg Rate";
            this.btnSavePegRate.UseVisualStyleBackColor = false;
            this.btnSavePegRate.Click += new System.EventHandler(this.btnSavePegRate_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel1.LinkColor = System.Drawing.Color.MediumBlue;
            this.linkLabel1.Location = new System.Drawing.Point(213, 9);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(80, 23);
            this.linkLabel1.TabIndex = 196;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Peg Rate";
            // 
            // chkPegRate
            // 
            this.chkPegRate.AutoSize = true;
            this.chkPegRate.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPegRate.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.chkPegRate.Location = new System.Drawing.Point(58, 134);
            this.chkPegRate.Name = "chkPegRate";
            this.chkPegRate.Size = new System.Drawing.Size(177, 30);
            this.chkPegRate.TabIndex = 197;
            this.chkPegRate.Text = "Update Peg Rate";
            this.chkPegRate.UseVisualStyleBackColor = true;
            this.chkPegRate.CheckedChanged += new System.EventHandler(this.chkPegRate_CheckedChanged);
            // 
            // dtpCreatedDate
            // 
            this.dtpCreatedDate.Enabled = false;
            this.dtpCreatedDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpCreatedDate.Location = new System.Drawing.Point(206, 106);
            this.dtpCreatedDate.Name = "dtpCreatedDate";
            this.dtpCreatedDate.Size = new System.Drawing.Size(74, 20);
            this.dtpCreatedDate.TabIndex = 198;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(25, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 19);
            this.label1.TabIndex = 199;
            this.label1.Text = "Old Peg Rate :";
            this.label1.Visible = false;
            // 
            // txtOldPegRate
            // 
            this.txtOldPegRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOldPegRate.Location = new System.Drawing.Point(127, 71);
            this.txtOldPegRate.Name = "txtOldPegRate";
            this.txtOldPegRate.ReadOnly = true;
            this.txtOldPegRate.Size = new System.Drawing.Size(153, 21);
            this.txtOldPegRate.TabIndex = 200;
            this.txtOldPegRate.Visible = false;
            // 
            // frmPegRate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(541, 353);
            this.Controls.Add(this.txtOldPegRate);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.chkPegRate);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnSavePegRate);
            this.Controls.Add(this.txtPegRate);
            this.Controls.Add(this.lblpcode);
            this.Controls.Add(this.dtpCreatedDate);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmPegRate";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Peg Rate";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmPegRate_FormClosing);
            this.Load += new System.EventHandler(this.frmPegRate_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtPegRate;
        private System.Windows.Forms.Label lblpcode;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSavePegRate;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.CheckBox chkPegRate;
        private System.Windows.Forms.DateTimePicker dtpCreatedDate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtOldPegRate;
    }
}