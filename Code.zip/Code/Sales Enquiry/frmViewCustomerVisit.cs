﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    public partial class frmViewCustomerVisit : Form
    {
        public frmViewCustomerVisit()
        {
            InitializeComponent();
        }
        DataTable dtSearchList = new DataTable();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        private void cmbreporttype_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void frmViewCustomerVisit_Load(object sender, EventArgs e)
        {
           // dtCustomerList = DAL.fnCustomerList(null).Tables[0];

        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            dtpFromDate.Format = DateTimePickerFormat.Custom;
            dtpFromDate.CustomFormat = "yyyy-MM-dd";
            dtpToDate.Format = DateTimePickerFormat.Custom;
            dtpToDate.CustomFormat = "yyyy-MM-dd";
        
                    dtSearchList = DAL.fnCustomerSearchList(0, dtpFromDate.Text, dtpToDate.Text).Tables[0];
                    dgvSetuptimeReport.AutoGenerateColumns = false;
                    dgvSetuptimeReport.DataSource = dtSearchList;
            
            dtpFromDate.Format = DateTimePickerFormat.Custom;
            dtpFromDate.CustomFormat = "dd-MM-yyyy";
            dtpToDate.Format = DateTimePickerFormat.Custom;
            dtpToDate.CustomFormat = "dd-MM-yyyy";
        }

        private void fnRowFilter(int uSearchOption, string sRowFilter)    //filter the Item list depends upon the user inpts
        {
            DataView dvPOViewList = new DataView(dtSearchList);
            switch (uSearchOption)
            {
                case 0:
                    {
                        dvPOViewList.RowFilter = "[Company Name] like '" + sRowFilter + "%'";
                        dgvSetuptimeReport.DataSource = dvPOViewList.ToTable();
                        break;
                    }
                case 1:
                    {
                        dvPOViewList.RowFilter = "[Company Type] like '" + sRowFilter + "%'";
                        dgvSetuptimeReport.DataSource = dvPOViewList.ToTable();
                        break;
                    }
                case 2:
                    {
                        dvPOViewList.RowFilter = "ContactPerson like '" + sRowFilter + "%'";
                        dgvSetuptimeReport.DataSource = dvPOViewList.ToTable();
                        break;
                    }
                case 3:
                    {
                        dvPOViewList.RowFilter = "ProductType like '" + sRowFilter + "%'";
                        dgvSetuptimeReport.DataSource = dvPOViewList.ToTable();
                        break;
                    }
                case 4:
                    {
                        dvPOViewList.RowFilter = "Lever like '" + sRowFilter + "%'";
                        dgvSetuptimeReport.DataSource = dvPOViewList.ToTable();
                        break;
                    }
                case 5:
                    {
                        dvPOViewList.RowFilter = "[80/20] like '" + sRowFilter + "%'";
                        dgvSetuptimeReport.DataSource = dvPOViewList.ToTable();
                        break;
                    }

                case 6:
                    {
                        dvPOViewList.RowFilter = "ProductManager like '" + sRowFilter + "%'";
                        dgvSetuptimeReport.DataSource = dvPOViewList.ToTable();
                        break;
                    }
                case 7:
                    {
                        dvPOViewList.RowFilter = "OldNewCustomer like '" + sRowFilter + "%'";
                        dgvSetuptimeReport.DataSource = dvPOViewList.ToTable();
                        break;
                    }
                case 8:
                    {
                        dvPOViewList.RowFilter = "LeadInput like '" + sRowFilter + "%'";
                        dgvSetuptimeReport.DataSource = dvPOViewList.ToTable();
                        break;
                    }
            }
        }


        private void frmViewCustomerVisit_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            frmCustomerVisit Customer = new frmCustomerVisit();
            Customer.Show();
        }

        private void txtSearchText_KeyUp(object sender, KeyEventArgs e)
        {
            if (cmbreporttype.SelectedIndex >= 0 && txtSearchText.TextLength > 0)
            {
                fnRowFilter(cmbreporttype.SelectedIndex, txtSearchText.Text);
            }
            else
            {
                dgvSetuptimeReport.AutoGenerateColumns = false;
                dgvSetuptimeReport.DataSource = dtSearchList;
            }
        }
    }
}
