﻿
namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    partial class frmServicequote
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmServicequote));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblStartQuote = new System.Windows.Forms.Label();
            this.cmbSelectQuoteType = new System.Windows.Forms.ComboBox();
            this.pnQuotationNumber = new System.Windows.Forms.Panel();
            this.cmbRevisionNumber = new System.Windows.Forms.ComboBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.cmbQuotationNumber = new System.Windows.Forms.ComboBox();
            this.tabAMC = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.cmbCeastAMC = new System.Windows.Forms.ComboBox();
            this.label64 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.cmbContractYears = new System.Windows.Forms.ComboBox();
            this.cmbEnquireCurrency = new System.Windows.Forms.ComboBox();
            this.lblcustomer = new System.Windows.Forms.Label();
            this.cmbQuoteCompany = new System.Windows.Forms.ComboBox();
            this.label67 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dtpContractto = new System.Windows.Forms.DateTimePicker();
            this.dtpContractfrom = new System.Windows.Forms.DateTimePicker();
            this.lblQuoteBy = new System.Windows.Forms.Label();
            this.lblQuotebyin = new System.Windows.Forms.Label();
            this.txtCusCode = new System.Windows.Forms.TextBox();
            this.txtEmailID = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.txtQuoteName = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.txtZone = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txtCusref = new System.Windows.Forms.ComboBox();
            this.txtTel = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.txtModelslno = new System.Windows.Forms.TextBox();
            this.btnStartQuote = new System.Windows.Forms.Button();
            this.dtpEnquireDate = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.txtContactNumber = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtContactPerson = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbCustomer = new System.Windows.Forms.ComboBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comboSVPPM = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtSVCV = new System.Windows.Forms.ComboBox();
            this.txtSVBV = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboPVPPM = new System.Windows.Forms.ComboBox();
            this.label31 = new System.Windows.Forms.Label();
            this.txtPVCV = new System.Windows.Forms.ComboBox();
            this.txtPVBV = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.btnAddNewRow = new System.Windows.Forms.Button();
            this.dgvNVLAP = new System.Windows.Forms.DataGridView();
            this.SLNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NVLAPCalibrationscovered = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnGotoAddProducts = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.pnCeast = new System.Windows.Forms.Panel();
            this.btnCeastAdditem = new System.Windows.Forms.Button();
            this.dgvCeastContract = new System.Windows.Forms.DataGridView();
            this.InstrumentDetails = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtGrandTotal = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtDiscount = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.btnGenarateQuote = new System.Windows.Forms.Button();
            this.btnFinQuote = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.txtpaymentterms = new System.Windows.Forms.TextBox();
            this.txtbreakdownvistcharges = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.btnBack1 = new System.Windows.Forms.Button();
            this.pnAMC = new System.Windows.Forms.Panel();
            this.label47 = new System.Windows.Forms.Label();
            this.btnAddrow = new System.Windows.Forms.Button();
            this.txtContractValue = new System.Windows.Forms.TextBox();
            this.chk3Years = new System.Windows.Forms.CheckBox();
            this.chk5Years = new System.Windows.Forms.CheckBox();
            this.dgvContract = new System.Windows.Forms.DataGridView();
            this.ContractValue1stYear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ContractValue2ndYear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ContractValue3rdYear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ContractValue4thYear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ContractValue5thYear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Scope = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cmbQuotetype = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dtpQuoteDate = new System.Windows.Forms.DateTimePicker();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.tabCalibration = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.CmbCurrency = new System.Windows.Forms.ComboBox();
            this.label61 = new System.Windows.Forms.Label();
            this.cmbCALQuoteFor = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.dtpMutualyAgreedDate = new System.Windows.Forms.DateTimePicker();
            this.dtpCalibrationDate = new System.Windows.Forms.DateTimePicker();
            this.lblCALQuoteby = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.txtCALCusCode = new System.Windows.Forms.TextBox();
            this.txtCALEmailID = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.txtCalQuotename = new System.Windows.Forms.ComboBox();
            this.label49 = new System.Windows.Forms.Label();
            this.txtCalZone = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.txtCALCusRef = new System.Windows.Forms.ComboBox();
            this.txtCALTel = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.txtCALModelNo = new System.Windows.Forms.TextBox();
            this.btnCalStartQuote = new System.Windows.Forms.Button();
            this.dtpCALDateofQuote = new System.Windows.Forms.DateTimePicker();
            this.label54 = new System.Windows.Forms.Label();
            this.txtCALHandy = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.txtCALContactPerson = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.txtCALAddress = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.cmbCALCustomer = new System.Windows.Forms.ComboBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.brnTab2back = new System.Windows.Forms.Button();
            this.txtCALGrandTotal = new System.Windows.Forms.TextBox();
            this.label65 = new System.Windows.Forms.Label();
            this.txtCALDiscount = new System.Windows.Forms.TextBox();
            this.label66 = new System.Windows.Forms.Label();
            this.btnCALGenerateQuote = new System.Windows.Forms.Button();
            this.btnCALPrintQuote = new System.Windows.Forms.Button();
            this.label68 = new System.Windows.Forms.Label();
            this.txtCALPaymentTerms = new System.Windows.Forms.TextBox();
            this.btnCALAddItem = new System.Windows.Forms.Button();
            this.dgvCALCalibrationDetails = new System.Windows.Forms.DataGridView();
            this.CALSlNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CALNVLAPCalibrationscovered = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabRI = new System.Windows.Forms.TabControl();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.cmbRICurrency = new System.Windows.Forms.ComboBox();
            this.label62 = new System.Windows.Forms.Label();
            this.txtRIContactNumber = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtRIPaymentTerms = new System.Windows.Forms.TextBox();
            this.TxtRIContactPerson = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtRIEmail = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.cmbRIQuotefor = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.lblRIQuoteBy = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtRICusCode = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtRIQuoteName = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtRIZone = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtRICOntractType = new System.Windows.Forms.TextBox();
            this.dtpRIQuoteDate = new System.Windows.Forms.DateTimePicker();
            this.label25 = new System.Windows.Forms.Label();
            this.txtRIModelNumber = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.txtRIAddress = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.cmbRICustomer = new System.Windows.Forms.ComboBox();
            this.btnRIStart = new System.Windows.Forms.Button();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.btnTab3back = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.txtRIAdditionalCharges = new System.Windows.Forms.TextBox();
            this.btnRIAddNewItem = new System.Windows.Forms.Button();
            this.txtRIVGrandTotal = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.txtRIVDiscount = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.btnGenRIVQuote = new System.Windows.Forms.Button();
            this.btnPrintRIQuote = new System.Windows.Forms.Button();
            this.dgvRIQuoteDetails = new System.Windows.Forms.DataGridView();
            this.RISlNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RIScopeofwork = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RIPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chkQuoteSavePath = new System.Windows.Forms.CheckBox();
            this.tabPI = new System.Windows.Forms.TabControl();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.dtpPIPurchaseorderdate = new System.Windows.Forms.DateTimePicker();
            this.label88 = new System.Windows.Forms.Label();
            this.dtpPIQuoterefdate = new System.Windows.Forms.DateTimePicker();
            this.label87 = new System.Windows.Forms.Label();
            this.cmbPICurrency = new System.Windows.Forms.ComboBox();
            this.label69 = new System.Windows.Forms.Label();
            this.txtPICountry = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.txtPImchineNo = new System.Windows.Forms.TextBox();
            this.label78 = new System.Windows.Forms.Label();
            this.txtPIQuoteRef = new System.Windows.Forms.TextBox();
            this.label72 = new System.Windows.Forms.Label();
            this.txtPIPurchaseOrder = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.cmbPICompany = new System.Windows.Forms.ComboBox();
            this.label74 = new System.Windows.Forms.Label();
            this.lblPIBY = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.txtPIGSTIN = new System.Windows.Forms.TextBox();
            this.dtpPIDate = new System.Windows.Forms.DateTimePicker();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.txtPIAddress = new System.Windows.Forms.TextBox();
            this.label83 = new System.Windows.Forms.Label();
            this.cmbPICustomer = new System.Windows.Forms.ComboBox();
            this.btnStartPI = new System.Windows.Forms.Button();
            this.txtPICusCode = new System.Windows.Forms.TextBox();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.label71 = new System.Windows.Forms.Label();
            this.txtPIPaymentterms = new System.Windows.Forms.TextBox();
            this.btnPIBack = new System.Windows.Forms.Button();
            this.label84 = new System.Windows.Forms.Label();
            this.btnPIAddItem = new System.Windows.Forms.Button();
            this.txtPIGrandTotal = new System.Windows.Forms.TextBox();
            this.label85 = new System.Windows.Forms.Label();
            this.txtPIGST = new System.Windows.Forms.TextBox();
            this.btnGeneratePI = new System.Windows.Forms.Button();
            this.btnPrintPI = new System.Windows.Forms.Button();
            this.dgvPIDetails = new System.Windows.Forms.DataGridView();
            this.PISlNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PIDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PIQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PIRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PIAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PaymentCode = new System.Windows.Forms.ComboBox();
            this.label75 = new System.Windows.Forms.Label();
            this.pnQuotationNumber.SuspendLayout();
            this.tabAMC.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNVLAP)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.pnCeast.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCeastContract)).BeginInit();
            this.pnAMC.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContract)).BeginInit();
            this.tabCalibration.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCALCalibrationDetails)).BeginInit();
            this.tabRI.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRIQuoteDetails)).BeginInit();
            this.tabPI.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.tabPage9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPIDetails)).BeginInit();
            this.SuspendLayout();
            // 
            // lblStartQuote
            // 
            this.lblStartQuote.AutoSize = true;
            this.lblStartQuote.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStartQuote.ForeColor = System.Drawing.Color.Black;
            this.lblStartQuote.Location = new System.Drawing.Point(289, 15);
            this.lblStartQuote.Name = "lblStartQuote";
            this.lblStartQuote.Size = new System.Drawing.Size(125, 23);
            this.lblStartQuote.TabIndex = 211;
            this.lblStartQuote.Text = "Start Quote * :";
            this.lblStartQuote.Visible = false;
            // 
            // cmbSelectQuoteType
            // 
            this.cmbSelectQuoteType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbSelectQuoteType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectQuoteType.DropDownHeight = 90;
            this.cmbSelectQuoteType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSelectQuoteType.DropDownWidth = 150;
            this.cmbSelectQuoteType.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSelectQuoteType.FormattingEnabled = true;
            this.cmbSelectQuoteType.IntegralHeight = false;
            this.cmbSelectQuoteType.Items.AddRange(new object[] {
            "New",
            "Update",
            "Revise"});
            this.cmbSelectQuoteType.Location = new System.Drawing.Point(415, 14);
            this.cmbSelectQuoteType.Name = "cmbSelectQuoteType";
            this.cmbSelectQuoteType.Size = new System.Drawing.Size(167, 26);
            this.cmbSelectQuoteType.TabIndex = 210;
            this.cmbSelectQuoteType.Visible = false;
            this.cmbSelectQuoteType.SelectedIndexChanged += new System.EventHandler(this.cmbSelectQuoteType_SelectedIndexChanged);
            // 
            // pnQuotationNumber
            // 
            this.pnQuotationNumber.BackColor = System.Drawing.Color.Silver;
            this.pnQuotationNumber.Controls.Add(this.cmbRevisionNumber);
            this.pnQuotationNumber.Controls.Add(this.label36);
            this.pnQuotationNumber.Controls.Add(this.label35);
            this.pnQuotationNumber.Controls.Add(this.cmbQuotationNumber);
            this.pnQuotationNumber.Location = new System.Drawing.Point(588, 5);
            this.pnQuotationNumber.Name = "pnQuotationNumber";
            this.pnQuotationNumber.Size = new System.Drawing.Size(503, 46);
            this.pnQuotationNumber.TabIndex = 209;
            this.pnQuotationNumber.Visible = false;
            // 
            // cmbRevisionNumber
            // 
            this.cmbRevisionNumber.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbRevisionNumber.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbRevisionNumber.DropDownHeight = 90;
            this.cmbRevisionNumber.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRevisionNumber.DropDownWidth = 70;
            this.cmbRevisionNumber.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbRevisionNumber.FormattingEnabled = true;
            this.cmbRevisionNumber.IntegralHeight = false;
            this.cmbRevisionNumber.Location = new System.Drawing.Point(391, 7);
            this.cmbRevisionNumber.Name = "cmbRevisionNumber";
            this.cmbRevisionNumber.Size = new System.Drawing.Size(98, 26);
            this.cmbRevisionNumber.TabIndex = 192;
            this.cmbRevisionNumber.SelectedIndexChanged += new System.EventHandler(this.cmbRevisionNumber_SelectedIndexChanged);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.label36.ForeColor = System.Drawing.Color.Black;
            this.label36.Location = new System.Drawing.Point(296, 9);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(96, 23);
            this.label36.TabIndex = 191;
            this.label36.Text = "Revision *:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.label35.ForeColor = System.Drawing.Color.Black;
            this.label35.Location = new System.Drawing.Point(3, 10);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(105, 23);
            this.label35.TabIndex = 180;
            this.label35.Text = "Quote No* :";
            // 
            // cmbQuotationNumber
            // 
            this.cmbQuotationNumber.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbQuotationNumber.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbQuotationNumber.DropDownHeight = 90;
            this.cmbQuotationNumber.DropDownWidth = 150;
            this.cmbQuotationNumber.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbQuotationNumber.FormattingEnabled = true;
            this.cmbQuotationNumber.IntegralHeight = false;
            this.cmbQuotationNumber.Location = new System.Drawing.Point(107, 8);
            this.cmbQuotationNumber.Name = "cmbQuotationNumber";
            this.cmbQuotationNumber.Size = new System.Drawing.Size(180, 26);
            this.cmbQuotationNumber.TabIndex = 181;
            this.cmbQuotationNumber.SelectedIndexChanged += new System.EventHandler(this.cmbQuotationNumber_SelectedIndexChanged);
            // 
            // tabAMC
            // 
            this.tabAMC.Controls.Add(this.tabPage1);
            this.tabAMC.Controls.Add(this.tabPage5);
            this.tabAMC.Controls.Add(this.tabPage2);
            this.tabAMC.ItemSize = new System.Drawing.Size(30, 1);
            this.tabAMC.Location = new System.Drawing.Point(6, 61);
            this.tabAMC.Name = "tabAMC";
            this.tabAMC.SelectedIndex = 0;
            this.tabAMC.Size = new System.Drawing.Size(1294, 591);
            this.tabAMC.TabIndex = 212;
            this.tabAMC.Visible = false;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Silver;
            this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPage1.Controls.Add(this.cmbCeastAMC);
            this.tabPage1.Controls.Add(this.label64);
            this.tabPage1.Controls.Add(this.label63);
            this.tabPage1.Controls.Add(this.cmbContractYears);
            this.tabPage1.Controls.Add(this.cmbEnquireCurrency);
            this.tabPage1.Controls.Add(this.lblcustomer);
            this.tabPage1.Controls.Add(this.cmbQuoteCompany);
            this.tabPage1.Controls.Add(this.label67);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.dtpContractto);
            this.tabPage1.Controls.Add(this.dtpContractfrom);
            this.tabPage1.Controls.Add(this.lblQuoteBy);
            this.tabPage1.Controls.Add(this.lblQuotebyin);
            this.tabPage1.Controls.Add(this.txtCusCode);
            this.tabPage1.Controls.Add(this.txtEmailID);
            this.tabPage1.Controls.Add(this.label40);
            this.tabPage1.Controls.Add(this.label38);
            this.tabPage1.Controls.Add(this.txtQuoteName);
            this.tabPage1.Controls.Add(this.label30);
            this.tabPage1.Controls.Add(this.txtZone);
            this.tabPage1.Controls.Add(this.label27);
            this.tabPage1.Controls.Add(this.txtCusref);
            this.tabPage1.Controls.Add(this.txtTel);
            this.tabPage1.Controls.Add(this.label34);
            this.tabPage1.Controls.Add(this.label28);
            this.tabPage1.Controls.Add(this.txtModelslno);
            this.tabPage1.Controls.Add(this.btnStartQuote);
            this.tabPage1.Controls.Add(this.dtpEnquireDate);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.txtContactNumber);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.txtContactPerson);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.txtAddress);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.cmbCustomer);
            this.tabPage1.ForeColor = System.Drawing.Color.Black;
            this.tabPage1.Location = new System.Drawing.Point(4, 5);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1286, 582);
            this.tabPage1.TabIndex = 0;
            // 
            // cmbCeastAMC
            // 
            this.cmbCeastAMC.DropDownHeight = 60;
            this.cmbCeastAMC.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCeastAMC.DropDownWidth = 150;
            this.cmbCeastAMC.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCeastAMC.FormattingEnabled = true;
            this.cmbCeastAMC.IntegralHeight = false;
            this.cmbCeastAMC.ItemHeight = 18;
            this.cmbCeastAMC.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbCeastAMC.Location = new System.Drawing.Point(788, 406);
            this.cmbCeastAMC.Name = "cmbCeastAMC";
            this.cmbCeastAMC.Size = new System.Drawing.Size(222, 26);
            this.cmbCeastAMC.TabIndex = 239;
            this.cmbCeastAMC.SelectedIndexChanged += new System.EventHandler(this.cmbCeastAMC_SelectedIndexChanged);
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.ForeColor = System.Drawing.Color.Black;
            this.label64.Location = new System.Drawing.Point(684, 409);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(96, 18);
            this.label64.TabIndex = 240;
            this.label64.Text = "CEAST AMC ? :";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label63.ForeColor = System.Drawing.Color.Black;
            this.label63.Location = new System.Drawing.Point(877, 235);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(47, 18);
            this.label63.TabIndex = 238;
            this.label63.Text = "From :";
            // 
            // cmbContractYears
            // 
            this.cmbContractYears.DropDownHeight = 60;
            this.cmbContractYears.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbContractYears.DropDownWidth = 150;
            this.cmbContractYears.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbContractYears.FormattingEnabled = true;
            this.cmbContractYears.IntegralHeight = false;
            this.cmbContractYears.ItemHeight = 18;
            this.cmbContractYears.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.cmbContractYears.Location = new System.Drawing.Point(784, 231);
            this.cmbContractYears.Name = "cmbContractYears";
            this.cmbContractYears.Size = new System.Drawing.Size(61, 26);
            this.cmbContractYears.TabIndex = 237;
            // 
            // cmbEnquireCurrency
            // 
            this.cmbEnquireCurrency.DropDownHeight = 60;
            this.cmbEnquireCurrency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEnquireCurrency.DropDownWidth = 150;
            this.cmbEnquireCurrency.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbEnquireCurrency.FormattingEnabled = true;
            this.cmbEnquireCurrency.IntegralHeight = false;
            this.cmbEnquireCurrency.ItemHeight = 18;
            this.cmbEnquireCurrency.Items.AddRange(new object[] {
            "INR",
            "USD"});
            this.cmbEnquireCurrency.Location = new System.Drawing.Point(787, 19);
            this.cmbEnquireCurrency.Name = "cmbEnquireCurrency";
            this.cmbEnquireCurrency.Size = new System.Drawing.Size(222, 26);
            this.cmbEnquireCurrency.TabIndex = 235;
            // 
            // lblcustomer
            // 
            this.lblcustomer.AutoSize = true;
            this.lblcustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcustomer.ForeColor = System.Drawing.Color.Black;
            this.lblcustomer.Location = new System.Drawing.Point(704, 22);
            this.lblcustomer.Name = "lblcustomer";
            this.lblcustomer.Size = new System.Drawing.Size(77, 18);
            this.lblcustomer.TabIndex = 236;
            this.lblcustomer.Text = "Currency* :";
            // 
            // cmbQuoteCompany
            // 
            this.cmbQuoteCompany.DropDownHeight = 60;
            this.cmbQuoteCompany.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbQuoteCompany.DropDownWidth = 150;
            this.cmbQuoteCompany.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbQuoteCompany.FormattingEnabled = true;
            this.cmbQuoteCompany.IntegralHeight = false;
            this.cmbQuoteCompany.ItemHeight = 18;
            this.cmbQuoteCompany.Items.AddRange(new object[] {
            "BiSS-ITW",
            "INSTRON"});
            this.cmbQuoteCompany.Location = new System.Drawing.Point(787, 56);
            this.cmbQuoteCompany.Name = "cmbQuoteCompany";
            this.cmbQuoteCompany.Size = new System.Drawing.Size(222, 26);
            this.cmbQuoteCompany.TabIndex = 233;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.ForeColor = System.Drawing.Color.Black;
            this.label67.Location = new System.Drawing.Point(697, 59);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(84, 18);
            this.label67.TabIndex = 234;
            this.label67.Text = "Quote For* :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label9.Location = new System.Drawing.Point(689, 284);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(351, 18);
            this.label9.TabIndex = 232;
            this.label9.Text = "Equipment/s Covered Under this Maintenance Contract";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(605, 332);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(174, 18);
            this.label7.TabIndex = 231;
            this.label7.Text = "Model and Serial Number :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(1029, 235);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 18);
            this.label4.TabIndex = 230;
            this.label4.Text = "To :";
            // 
            // dtpContractto
            // 
            this.dtpContractto.CustomFormat = "";
            this.dtpContractto.Enabled = false;
            this.dtpContractto.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpContractto.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpContractto.Location = new System.Drawing.Point(1064, 231);
            this.dtpContractto.Name = "dtpContractto";
            this.dtpContractto.Size = new System.Drawing.Size(104, 26);
            this.dtpContractto.TabIndex = 229;
            this.dtpContractto.ValueChanged += new System.EventHandler(this.dtpContractto_ValueChanged);
            // 
            // dtpContractfrom
            // 
            this.dtpContractfrom.CustomFormat = "";
            this.dtpContractfrom.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpContractfrom.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpContractfrom.Location = new System.Drawing.Point(930, 233);
            this.dtpContractfrom.Name = "dtpContractfrom";
            this.dtpContractfrom.Size = new System.Drawing.Size(93, 26);
            this.dtpContractfrom.TabIndex = 228;
            this.dtpContractfrom.ValueChanged += new System.EventHandler(this.dtpContractfrom_ValueChanged);
            // 
            // lblQuoteBy
            // 
            this.lblQuoteBy.AutoSize = true;
            this.lblQuoteBy.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuoteBy.ForeColor = System.Drawing.Color.Red;
            this.lblQuoteBy.Location = new System.Drawing.Point(1026, 99);
            this.lblQuoteBy.Name = "lblQuoteBy";
            this.lblQuoteBy.Size = new System.Drawing.Size(0, 19);
            this.lblQuoteBy.TabIndex = 227;
            // 
            // lblQuotebyin
            // 
            this.lblQuotebyin.AutoSize = true;
            this.lblQuotebyin.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuotebyin.ForeColor = System.Drawing.Color.Black;
            this.lblQuotebyin.Location = new System.Drawing.Point(943, 99);
            this.lblQuotebyin.Name = "lblQuotebyin";
            this.lblQuotebyin.Size = new System.Drawing.Size(81, 19);
            this.lblQuotebyin.TabIndex = 226;
            this.lblQuotebyin.Text = "Quote By :";
            // 
            // txtCusCode
            // 
            this.txtCusCode.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtCusCode.Location = new System.Drawing.Point(476, 111);
            this.txtCusCode.Name = "txtCusCode";
            this.txtCusCode.Size = new System.Drawing.Size(20, 26);
            this.txtCusCode.TabIndex = 199;
            this.txtCusCode.Visible = false;
            // 
            // txtEmailID
            // 
            this.txtEmailID.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtEmailID.Location = new System.Drawing.Point(127, 348);
            this.txtEmailID.Name = "txtEmailID";
            this.txtEmailID.Size = new System.Drawing.Size(343, 26);
            this.txtEmailID.TabIndex = 21;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label40.ForeColor = System.Drawing.Color.Black;
            this.label40.Location = new System.Drawing.Point(49, 354);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(72, 18);
            this.label40.TabIndex = 195;
            this.label40.Text = "Email ID* :";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label38.ForeColor = System.Drawing.Color.Black;
            this.label38.Location = new System.Drawing.Point(678, 146);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(101, 18);
            this.label38.TabIndex = 193;
            this.label38.Text = "Quote Name *:";
            // 
            // txtQuoteName
            // 
            this.txtQuoteName.DropDownHeight = 60;
            this.txtQuoteName.DropDownWidth = 428;
            this.txtQuoteName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQuoteName.FormattingEnabled = true;
            this.txtQuoteName.IntegralHeight = false;
            this.txtQuoteName.ItemHeight = 16;
            this.txtQuoteName.Items.AddRange(new object[] {
            "Non Comprehensive Annual Maintenance Contract",
            "Non Comprehensive Annual Maintenance Contract and Calibration"});
            this.txtQuoteName.Location = new System.Drawing.Point(788, 145);
            this.txtQuoteName.Name = "txtQuoteName";
            this.txtQuoteName.Size = new System.Drawing.Size(428, 24);
            this.txtQuoteName.TabIndex = 8;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label30.ForeColor = System.Drawing.Color.Black;
            this.label30.Location = new System.Drawing.Point(72, 67);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(49, 18);
            this.label30.TabIndex = 189;
            this.label30.Text = "Zone : ";
            // 
            // txtZone
            // 
            this.txtZone.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtZone.Location = new System.Drawing.Point(127, 64);
            this.txtZone.Name = "txtZone";
            this.txtZone.Size = new System.Drawing.Size(343, 26);
            this.txtZone.TabIndex = 12;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label27.ForeColor = System.Drawing.Color.Black;
            this.label27.Location = new System.Drawing.Point(28, 22);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(100, 18);
            this.label27.TabIndex = 187;
            this.label27.Text = "Contract Type :";
            // 
            // txtCusref
            // 
            this.txtCusref.DropDownHeight = 60;
            this.txtCusref.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtCusref.DropDownWidth = 428;
            this.txtCusref.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCusref.FormattingEnabled = true;
            this.txtCusref.IntegralHeight = false;
            this.txtCusref.ItemHeight = 16;
            this.txtCusref.Items.AddRange(new object[] {
            "AMC",
            "Renewal",
            "Lever 1",
            "Lever 2",
            "Warranty conversion",
            "MYC renewal",
            "New MYC",
            "CAL",
            "CAL renewal",
            "MYC CAL",
            "Missing Contract"});
            this.txtCusref.Location = new System.Drawing.Point(127, 19);
            this.txtCusref.Name = "txtCusref";
            this.txtCusref.Size = new System.Drawing.Size(343, 24);
            this.txtCusref.TabIndex = 11;
            // 
            // txtTel
            // 
            this.txtTel.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtTel.Location = new System.Drawing.Point(127, 431);
            this.txtTel.Name = "txtTel";
            this.txtTel.Size = new System.Drawing.Size(343, 26);
            this.txtTel.TabIndex = 20;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label34.ForeColor = System.Drawing.Color.Black;
            this.label34.Location = new System.Drawing.Point(88, 434);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(33, 18);
            this.label34.TabIndex = 127;
            this.label34.Text = "Tel :";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label28.ForeColor = System.Drawing.Color.Black;
            this.label28.Location = new System.Drawing.Point(631, 235);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(147, 18);
            this.label28.TabIndex = 117;
            this.label28.Text = "Contract period Years :";
            // 
            // txtModelslno
            // 
            this.txtModelslno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtModelslno.Location = new System.Drawing.Point(788, 330);
            this.txtModelslno.Multiline = true;
            this.txtModelslno.Name = "txtModelslno";
            this.txtModelslno.Size = new System.Drawing.Size(428, 60);
            this.txtModelslno.TabIndex = 9;
            // 
            // btnStartQuote
            // 
            this.btnStartQuote.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnStartQuote.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnStartQuote.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStartQuote.Location = new System.Drawing.Point(1062, 492);
            this.btnStartQuote.Name = "btnStartQuote";
            this.btnStartQuote.Size = new System.Drawing.Size(154, 45);
            this.btnStartQuote.TabIndex = 23;
            this.btnStartQuote.Text = "Start Quote";
            this.btnStartQuote.UseVisualStyleBackColor = false;
            this.btnStartQuote.Click += new System.EventHandler(this.btnStartQuote_Click);
            // 
            // dtpEnquireDate
            // 
            this.dtpEnquireDate.CustomFormat = "";
            this.dtpEnquireDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpEnquireDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpEnquireDate.Location = new System.Drawing.Point(788, 99);
            this.dtpEnquireDate.Name = "dtpEnquireDate";
            this.dtpEnquireDate.Size = new System.Drawing.Size(104, 26);
            this.dtpEnquireDate.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(670, 100);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(109, 18);
            this.label10.TabIndex = 104;
            this.label10.Text = "Date of Quote* :";
            // 
            // txtContactNumber
            // 
            this.txtContactNumber.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtContactNumber.Location = new System.Drawing.Point(127, 389);
            this.txtContactNumber.Name = "txtContactNumber";
            this.txtContactNumber.Size = new System.Drawing.Size(343, 26);
            this.txtContactNumber.TabIndex = 19;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(67, 392);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 18);
            this.label6.TabIndex = 98;
            this.label6.Text = "Handy :";
            // 
            // txtContactPerson
            // 
            this.txtContactPerson.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtContactPerson.Location = new System.Drawing.Point(127, 301);
            this.txtContactPerson.MaxLength = 80;
            this.txtContactPerson.Name = "txtContactPerson";
            this.txtContactPerson.Size = new System.Drawing.Size(343, 26);
            this.txtContactPerson.TabIndex = 18;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(36, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 18);
            this.label2.TabIndex = 92;
            this.label2.Text = "Customer * :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(8, 304);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 18);
            this.label5.TabIndex = 96;
            this.label5.Text = "Contact Person* :";
            // 
            // txtAddress
            // 
            this.txtAddress.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtAddress.Location = new System.Drawing.Point(127, 153);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(343, 123);
            this.txtAddress.TabIndex = 16;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(56, 156);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 18);
            this.label3.TabIndex = 94;
            this.label3.Text = "Address :";
            // 
            // cmbCustomer
            // 
            this.cmbCustomer.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbCustomer.DropDownHeight = 90;
            this.cmbCustomer.DropDownWidth = 150;
            this.cmbCustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCustomer.FormattingEnabled = true;
            this.cmbCustomer.IntegralHeight = false;
            this.cmbCustomer.Location = new System.Drawing.Point(127, 111);
            this.cmbCustomer.Name = "cmbCustomer";
            this.cmbCustomer.Size = new System.Drawing.Size(343, 26);
            this.cmbCustomer.TabIndex = 15;
            this.cmbCustomer.SelectedIndexChanged += new System.EventHandler(this.cmbCustomer_SelectedIndexChanged);
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.Silver;
            this.tabPage5.Controls.Add(this.groupBox2);
            this.tabPage5.Controls.Add(this.groupBox1);
            this.tabPage5.Controls.Add(this.btnAddNewRow);
            this.tabPage5.Controls.Add(this.dgvNVLAP);
            this.tabPage5.Controls.Add(this.btnBack);
            this.tabPage5.Controls.Add(this.btnGotoAddProducts);
            this.tabPage5.Location = new System.Drawing.Point(4, 5);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1286, 582);
            this.tabPage5.TabIndex = 4;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.comboSVPPM);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.txtSVCV);
            this.groupBox2.Controls.Add(this.txtSVBV);
            this.groupBox2.Controls.Add(this.label32);
            this.groupBox2.Controls.Add(this.label33);
            this.groupBox2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Red;
            this.groupBox2.Location = new System.Drawing.Point(9, 376);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1271, 156);
            this.groupBox2.TabIndex = 256;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Schedule of Visits :";
            // 
            // comboSVPPM
            // 
            this.comboSVPPM.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboSVPPM.FormattingEnabled = true;
            this.comboSVPPM.Items.AddRange(new object[] {
            "6th and 12th month of the contract period",
            "4th, 6th and 12th month of the contract period",
            "PPM3",
            "PPM4"});
            this.comboSVPPM.Location = new System.Drawing.Point(346, 19);
            this.comboSVPPM.Name = "comboSVPPM";
            this.comboSVPPM.Size = new System.Drawing.Size(919, 24);
            this.comboSVPPM.TabIndex = 248;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(220, 113);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(122, 18);
            this.label12.TabIndex = 254;
            this.label12.Text = "Breakdown Visits :";
            // 
            // txtSVCV
            // 
            this.txtSVCV.DropDownHeight = 60;
            this.txtSVCV.DropDownWidth = 428;
            this.txtSVCV.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSVCV.FormattingEnabled = true;
            this.txtSVCV.IntegralHeight = false;
            this.txtSVCV.ItemHeight = 16;
            this.txtSVCV.Items.AddRange(new object[] {
            "On mutually agreed date with prior notice of 60 days in advance"});
            this.txtSVCV.Location = new System.Drawing.Point(346, 63);
            this.txtSVCV.Name = "txtSVCV";
            this.txtSVCV.Size = new System.Drawing.Size(919, 24);
            this.txtSVCV.TabIndex = 249;
            // 
            // txtSVBV
            // 
            this.txtSVBV.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSVBV.Location = new System.Drawing.Point(346, 111);
            this.txtSVBV.Multiline = true;
            this.txtSVBV.Name = "txtSVBV";
            this.txtSVBV.Size = new System.Drawing.Size(919, 38);
            this.txtSVBV.TabIndex = 253;
            this.txtSVBV.Text = "Will be attended as and when reported by customer on chargeable basis.";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label32.ForeColor = System.Drawing.Color.Black;
            this.label32.Location = new System.Drawing.Point(5, 31);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(341, 18);
            this.label32.TabIndex = 250;
            this.label32.Text = "Pre-Scheduled Preventive Maintenance Visits (PPM) :";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label33.ForeColor = System.Drawing.Color.Black;
            this.label33.Location = new System.Drawing.Point(220, 69);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(120, 18);
            this.label33.TabIndex = 251;
            this.label33.Text = "Calibration Visits :";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.comboPVPPM);
            this.groupBox1.Controls.Add(this.label31);
            this.groupBox1.Controls.Add(this.txtPVCV);
            this.groupBox1.Controls.Add(this.txtPVBV);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Red;
            this.groupBox1.Location = new System.Drawing.Point(9, 218);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1271, 156);
            this.groupBox1.TabIndex = 255;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Proposed Visit :";
            // 
            // comboPVPPM
            // 
            this.comboPVPPM.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboPVPPM.FormattingEnabled = true;
            this.comboPVPPM.Items.AddRange(new object[] {
            "2 Preventive Maintenance Visits",
            "3 Preventive Maintenance Visits",
            "PPM3"});
            this.comboPVPPM.Location = new System.Drawing.Point(346, 19);
            this.comboPVPPM.Name = "comboPVPPM";
            this.comboPVPPM.Size = new System.Drawing.Size(919, 24);
            this.comboPVPPM.TabIndex = 249;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label31.ForeColor = System.Drawing.Color.Black;
            this.label31.Location = new System.Drawing.Point(220, 113);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(122, 18);
            this.label31.TabIndex = 254;
            this.label31.Text = "Breakdown Visits :";
            // 
            // txtPVCV
            // 
            this.txtPVCV.DropDownHeight = 60;
            this.txtPVCV.DropDownWidth = 428;
            this.txtPVCV.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPVCV.FormattingEnabled = true;
            this.txtPVCV.IntegralHeight = false;
            this.txtPVCV.ItemHeight = 16;
            this.txtPVCV.Items.AddRange(new object[] {
            "One time calibration of chosen transducers during the contract period"});
            this.txtPVCV.Location = new System.Drawing.Point(346, 63);
            this.txtPVCV.Name = "txtPVCV";
            this.txtPVCV.Size = new System.Drawing.Size(919, 24);
            this.txtPVCV.TabIndex = 249;
            // 
            // txtPVBV
            // 
            this.txtPVBV.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPVBV.Location = new System.Drawing.Point(346, 111);
            this.txtPVBV.Multiline = true;
            this.txtPVBV.Name = "txtPVBV";
            this.txtPVBV.Size = new System.Drawing.Size(919, 38);
            this.txtPVBV.TabIndex = 253;
            this.txtPVBV.Text = "Will be attended as and when reported by customer on chargeable basis. While maki" +
    "ng a provision, please indicate for how many days you have made provision.";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label29.ForeColor = System.Drawing.Color.Black;
            this.label29.Location = new System.Drawing.Point(5, 31);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(341, 18);
            this.label29.TabIndex = 250;
            this.label29.Text = "Pre-Scheduled Preventive Maintenance Visits (PPM) :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(220, 69);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(120, 18);
            this.label17.TabIndex = 251;
            this.label17.Text = "Calibration Visits :";
            // 
            // btnAddNewRow
            // 
            this.btnAddNewRow.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAddNewRow.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAddNewRow.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNewRow.Location = new System.Drawing.Point(1168, 6);
            this.btnAddNewRow.Name = "btnAddNewRow";
            this.btnAddNewRow.Size = new System.Drawing.Size(106, 28);
            this.btnAddNewRow.TabIndex = 247;
            this.btnAddNewRow.Text = "Add Item";
            this.btnAddNewRow.UseVisualStyleBackColor = false;
            this.btnAddNewRow.Click += new System.EventHandler(this.btnAddNewRow_Click);
            // 
            // dgvNVLAP
            // 
            this.dgvNVLAP.AllowUserToAddRows = false;
            this.dgvNVLAP.AllowUserToOrderColumns = true;
            this.dgvNVLAP.AllowUserToResizeRows = false;
            this.dgvNVLAP.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvNVLAP.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvNVLAP.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvNVLAP.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvNVLAP.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvNVLAP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNVLAP.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SLNo,
            this.NVLAPCalibrationscovered});
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvNVLAP.DefaultCellStyle = dataGridViewCellStyle4;
            this.dgvNVLAP.Location = new System.Drawing.Point(6, 6);
            this.dgvNVLAP.Name = "dgvNVLAP";
            this.dgvNVLAP.RowHeadersVisible = false;
            this.dgvNVLAP.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvNVLAP.Size = new System.Drawing.Size(1274, 206);
            this.dgvNVLAP.TabIndex = 246;
            this.dgvNVLAP.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvNVLAP_KeyUp);
            this.dgvNVLAP.MouseUp += new System.Windows.Forms.MouseEventHandler(this.dgvNVLAP_MouseUp);
            // 
            // SLNo
            // 
            this.SLNo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.SLNo.DataPropertyName = "SLNo";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            this.SLNo.DefaultCellStyle = dataGridViewCellStyle2;
            this.SLNo.HeaderText = "SL No";
            this.SLNo.Name = "SLNo";
            this.SLNo.ReadOnly = true;
            this.SLNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SLNo.Width = 49;
            // 
            // NVLAPCalibrationscovered
            // 
            this.NVLAPCalibrationscovered.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.NVLAPCalibrationscovered.DataPropertyName = "NVLAPCalibrationscovered";
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.NVLAPCalibrationscovered.DefaultCellStyle = dataGridViewCellStyle3;
            this.NVLAPCalibrationscovered.HeaderText = "NVLAP Calibrations covered";
            this.NVLAPCalibrationscovered.Name = "NVLAPCalibrationscovered";
            this.NVLAPCalibrationscovered.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnBack.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold);
            this.btnBack.Location = new System.Drawing.Point(9, 532);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(97, 31);
            this.btnBack.TabIndex = 244;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnGotoAddProducts
            // 
            this.btnGotoAddProducts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnGotoAddProducts.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnGotoAddProducts.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGotoAddProducts.Location = new System.Drawing.Point(1190, 531);
            this.btnGotoAddProducts.Name = "btnGotoAddProducts";
            this.btnGotoAddProducts.Size = new System.Drawing.Size(90, 33);
            this.btnGotoAddProducts.TabIndex = 243;
            this.btnGotoAddProducts.Text = "Next";
            this.btnGotoAddProducts.UseVisualStyleBackColor = false;
            this.btnGotoAddProducts.Click += new System.EventHandler(this.btnGotoAddProducts_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Silver;
            this.tabPage2.Controls.Add(this.pnCeast);
            this.tabPage2.Controls.Add(this.txtGrandTotal);
            this.tabPage2.Controls.Add(this.label23);
            this.tabPage2.Controls.Add(this.txtDiscount);
            this.tabPage2.Controls.Add(this.label19);
            this.tabPage2.Controls.Add(this.btnGenarateQuote);
            this.tabPage2.Controls.Add(this.btnFinQuote);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.txtpaymentterms);
            this.tabPage2.Controls.Add(this.txtbreakdownvistcharges);
            this.tabPage2.Controls.Add(this.label53);
            this.tabPage2.Controls.Add(this.btnBack1);
            this.tabPage2.Controls.Add(this.pnAMC);
            this.tabPage2.Location = new System.Drawing.Point(4, 5);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1286, 582);
            this.tabPage2.TabIndex = 1;
            // 
            // pnCeast
            // 
            this.pnCeast.Controls.Add(this.btnCeastAdditem);
            this.pnCeast.Controls.Add(this.dgvCeastContract);
            this.pnCeast.Location = new System.Drawing.Point(10, 7);
            this.pnCeast.Name = "pnCeast";
            this.pnCeast.Size = new System.Drawing.Size(1257, 285);
            this.pnCeast.TabIndex = 263;
            // 
            // btnCeastAdditem
            // 
            this.btnCeastAdditem.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnCeastAdditem.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCeastAdditem.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCeastAdditem.Location = new System.Drawing.Point(779, 9);
            this.btnCeastAdditem.Name = "btnCeastAdditem";
            this.btnCeastAdditem.Size = new System.Drawing.Size(106, 28);
            this.btnCeastAdditem.TabIndex = 304;
            this.btnCeastAdditem.Text = "Add Item";
            this.btnCeastAdditem.UseVisualStyleBackColor = false;
            this.btnCeastAdditem.Click += new System.EventHandler(this.btnCeastAdditem_Click);
            // 
            // dgvCeastContract
            // 
            this.dgvCeastContract.AllowUserToAddRows = false;
            this.dgvCeastContract.AllowUserToOrderColumns = true;
            this.dgvCeastContract.AllowUserToResizeRows = false;
            this.dgvCeastContract.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvCeastContract.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvCeastContract.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvCeastContract.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCeastContract.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvCeastContract.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCeastContract.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.InstrumentDetails,
            this.UnitPrice,
            this.Quantity,
            this.Amount});
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCeastContract.DefaultCellStyle = dataGridViewCellStyle9;
            this.dgvCeastContract.Location = new System.Drawing.Point(8, 9);
            this.dgvCeastContract.Name = "dgvCeastContract";
            this.dgvCeastContract.RowHeadersVisible = false;
            this.dgvCeastContract.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvCeastContract.Size = new System.Drawing.Size(1225, 261);
            this.dgvCeastContract.TabIndex = 303;
            this.dgvCeastContract.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgvCeastContract_CellBeginEdit);
            this.dgvCeastContract.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCeastContract_CellEndEdit);
            this.dgvCeastContract.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvCeastContract_EditingControlShowing);
            this.dgvCeastContract.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvCeastContract_KeyUp);
            // 
            // InstrumentDetails
            // 
            this.InstrumentDetails.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.InstrumentDetails.DataPropertyName = "Instrument Details";
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.InstrumentDetails.DefaultCellStyle = dataGridViewCellStyle6;
            this.InstrumentDetails.HeaderText = "Instrument Details";
            this.InstrumentDetails.Name = "InstrumentDetails";
            this.InstrumentDetails.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // UnitPrice
            // 
            this.UnitPrice.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.UnitPrice.DataPropertyName = "Unit Price";
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.UnitPrice.DefaultCellStyle = dataGridViewCellStyle7;
            this.UnitPrice.FillWeight = 140F;
            this.UnitPrice.HeaderText = "Unit Price";
            this.UnitPrice.Name = "UnitPrice";
            this.UnitPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitPrice.Width = 140;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "Quantity";
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Quantity.DefaultCellStyle = dataGridViewCellStyle8;
            this.Quantity.HeaderText = "Quantity";
            this.Quantity.Name = "Quantity";
            this.Quantity.Width = 94;
            // 
            // Amount
            // 
            this.Amount.DataPropertyName = "Amount";
            this.Amount.HeaderText = "Amount";
            this.Amount.Name = "Amount";
            this.Amount.ReadOnly = true;
            this.Amount.Width = 90;
            // 
            // txtGrandTotal
            // 
            this.txtGrandTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGrandTotal.Location = new System.Drawing.Point(175, 354);
            this.txtGrandTotal.Name = "txtGrandTotal";
            this.txtGrandTotal.ReadOnly = true;
            this.txtGrandTotal.Size = new System.Drawing.Size(142, 22);
            this.txtGrandTotal.TabIndex = 263;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label23.ForeColor = System.Drawing.Color.Black;
            this.label23.Location = new System.Drawing.Point(83, 356);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(86, 18);
            this.label23.TabIndex = 264;
            this.label23.Text = "Grand Total :";
            // 
            // txtDiscount
            // 
            this.txtDiscount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiscount.Location = new System.Drawing.Point(175, 314);
            this.txtDiscount.Name = "txtDiscount";
            this.txtDiscount.Size = new System.Drawing.Size(93, 22);
            this.txtDiscount.TabIndex = 258;
            this.txtDiscount.Text = "0";
            this.txtDiscount.TextChanged += new System.EventHandler(this.txtDiscount_TextChanged);
            this.txtDiscount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDiscount_KeyPress);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(86, 314);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(83, 18);
            this.label19.TabIndex = 259;
            this.label19.Text = "Discount % :";
            // 
            // btnGenarateQuote
            // 
            this.btnGenarateQuote.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnGenarateQuote.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenarateQuote.Location = new System.Drawing.Point(854, 515);
            this.btnGenarateQuote.Name = "btnGenarateQuote";
            this.btnGenarateQuote.Size = new System.Drawing.Size(164, 37);
            this.btnGenarateQuote.TabIndex = 255;
            this.btnGenarateQuote.Text = "Generate Quote";
            this.btnGenarateQuote.UseVisualStyleBackColor = false;
            this.btnGenarateQuote.Click += new System.EventHandler(this.btnGenarateQuote_Click);
            // 
            // btnFinQuote
            // 
            this.btnFinQuote.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnFinQuote.Enabled = false;
            this.btnFinQuote.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFinQuote.Location = new System.Drawing.Point(1070, 516);
            this.btnFinQuote.Name = "btnFinQuote";
            this.btnFinQuote.Size = new System.Drawing.Size(157, 37);
            this.btnFinQuote.TabIndex = 254;
            this.btnFinQuote.Text = "Print Quote";
            this.btnFinQuote.UseVisualStyleBackColor = false;
            this.btnFinQuote.Click += new System.EventHandler(this.btnFinQuote_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(286, 316);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(110, 18);
            this.label8.TabIndex = 253;
            this.label8.Text = "Payment Terms :";
            // 
            // txtpaymentterms
            // 
            this.txtpaymentterms.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpaymentterms.Location = new System.Drawing.Point(402, 305);
            this.txtpaymentterms.Multiline = true;
            this.txtpaymentterms.Name = "txtpaymentterms";
            this.txtpaymentterms.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtpaymentterms.Size = new System.Drawing.Size(857, 188);
            this.txtpaymentterms.TabIndex = 248;
            // 
            // txtbreakdownvistcharges
            // 
            this.txtbreakdownvistcharges.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbreakdownvistcharges.Location = new System.Drawing.Point(176, 393);
            this.txtbreakdownvistcharges.Name = "txtbreakdownvistcharges";
            this.txtbreakdownvistcharges.Size = new System.Drawing.Size(142, 22);
            this.txtbreakdownvistcharges.TabIndex = 251;
            this.txtbreakdownvistcharges.Text = "0";
            this.txtbreakdownvistcharges.TextChanged += new System.EventHandler(this.txtbreakdownvistcharges_TextChanged);
            this.txtbreakdownvistcharges.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbreakdownvistcharges_KeyPress);
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label53.ForeColor = System.Drawing.Color.Black;
            this.label53.Location = new System.Drawing.Point(1, 393);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(168, 18);
            this.label53.TabIndex = 252;
            this.label53.Text = "Breakdown Visit Charges :";
            // 
            // btnBack1
            // 
            this.btnBack1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnBack1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnBack1.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold);
            this.btnBack1.Location = new System.Drawing.Point(6, 521);
            this.btnBack1.Name = "btnBack1";
            this.btnBack1.Size = new System.Drawing.Size(124, 35);
            this.btnBack1.TabIndex = 137;
            this.btnBack1.Text = "Back";
            this.btnBack1.UseVisualStyleBackColor = false;
            this.btnBack1.Click += new System.EventHandler(this.btnBack1_Click);
            // 
            // pnAMC
            // 
            this.pnAMC.Controls.Add(this.label47);
            this.pnAMC.Controls.Add(this.btnAddrow);
            this.pnAMC.Controls.Add(this.txtContractValue);
            this.pnAMC.Controls.Add(this.chk3Years);
            this.pnAMC.Controls.Add(this.chk5Years);
            this.pnAMC.Controls.Add(this.dgvContract);
            this.pnAMC.Location = new System.Drawing.Point(9, 6);
            this.pnAMC.Name = "pnAMC";
            this.pnAMC.Size = new System.Drawing.Size(1271, 287);
            this.pnAMC.TabIndex = 265;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label47.Location = new System.Drawing.Point(6, 10);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(174, 18);
            this.label47.TabIndex = 248;
            this.label47.Text = "Contract Value increase % :";
            // 
            // btnAddrow
            // 
            this.btnAddrow.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAddrow.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAddrow.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddrow.Location = new System.Drawing.Point(1128, 32);
            this.btnAddrow.Name = "btnAddrow";
            this.btnAddrow.Size = new System.Drawing.Size(106, 28);
            this.btnAddrow.TabIndex = 250;
            this.btnAddrow.Text = "Add Item";
            this.btnAddrow.UseVisualStyleBackColor = false;
            this.btnAddrow.Click += new System.EventHandler(this.btnAddrow_Click);
            // 
            // txtContractValue
            // 
            this.txtContractValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContractValue.Location = new System.Drawing.Point(180, 10);
            this.txtContractValue.Name = "txtContractValue";
            this.txtContractValue.Size = new System.Drawing.Size(37, 22);
            this.txtContractValue.TabIndex = 262;
            this.txtContractValue.Text = "7.5";
            this.txtContractValue.TextChanged += new System.EventHandler(this.txtContractValue_TextChanged);
            this.txtContractValue.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtContractValue_KeyPress);
            // 
            // chk3Years
            // 
            this.chk3Years.AutoSize = true;
            this.chk3Years.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk3Years.ForeColor = System.Drawing.Color.Black;
            this.chk3Years.Location = new System.Drawing.Point(268, 3);
            this.chk3Years.Name = "chk3Years";
            this.chk3Years.Size = new System.Drawing.Size(162, 27);
            this.chk3Years.TabIndex = 260;
            this.chk3Years.Text = "Apply for 3 Years";
            this.chk3Years.UseVisualStyleBackColor = true;
            // 
            // chk5Years
            // 
            this.chk5Years.AutoSize = true;
            this.chk5Years.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk5Years.ForeColor = System.Drawing.Color.Black;
            this.chk5Years.Location = new System.Drawing.Point(485, 3);
            this.chk5Years.Name = "chk5Years";
            this.chk5Years.Size = new System.Drawing.Size(162, 27);
            this.chk5Years.TabIndex = 261;
            this.chk5Years.Text = "Apply for 5 Years";
            this.chk5Years.UseVisualStyleBackColor = true;
            // 
            // dgvContract
            // 
            this.dgvContract.AllowUserToAddRows = false;
            this.dgvContract.AllowUserToOrderColumns = true;
            this.dgvContract.AllowUserToResizeRows = false;
            this.dgvContract.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvContract.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvContract.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvContract.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvContract.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dgvContract.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvContract.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ContractValue1stYear,
            this.ContractValue2ndYear,
            this.ContractValue3rdYear,
            this.ContractValue4thYear,
            this.ContractValue5thYear,
            this.Scope});
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvContract.DefaultCellStyle = dataGridViewCellStyle11;
            this.dgvContract.Location = new System.Drawing.Point(3, 32);
            this.dgvContract.Name = "dgvContract";
            this.dgvContract.RowHeadersVisible = false;
            this.dgvContract.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvContract.Size = new System.Drawing.Size(1255, 249);
            this.dgvContract.TabIndex = 249;
            this.dgvContract.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgvContract_CellBeginEdit);
            this.dgvContract.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvContract_CellEndEdit);
            this.dgvContract.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvContract_EditingControlShowing);
            this.dgvContract.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvContract_KeyUp);
            this.dgvContract.MouseUp += new System.Windows.Forms.MouseEventHandler(this.dgvContract_MouseUp);
            // 
            // ContractValue1stYear
            // 
            this.ContractValue1stYear.DataPropertyName = "1st Year";
            this.ContractValue1stYear.HeaderText = "1st Year";
            this.ContractValue1stYear.Name = "ContractValue1stYear";
            this.ContractValue1stYear.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ContractValue1stYear.Width = 68;
            // 
            // ContractValue2ndYear
            // 
            this.ContractValue2ndYear.DataPropertyName = "2nd Year";
            this.ContractValue2ndYear.HeaderText = "2nd Year";
            this.ContractValue2ndYear.Name = "ContractValue2ndYear";
            this.ContractValue2ndYear.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ContractValue2ndYear.Width = 74;
            // 
            // ContractValue3rdYear
            // 
            this.ContractValue3rdYear.DataPropertyName = "3rd Year";
            this.ContractValue3rdYear.HeaderText = "3rd Year";
            this.ContractValue3rdYear.Name = "ContractValue3rdYear";
            this.ContractValue3rdYear.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ContractValue3rdYear.Width = 71;
            // 
            // ContractValue4thYear
            // 
            this.ContractValue4thYear.DataPropertyName = "4th Year";
            this.ContractValue4thYear.HeaderText = "4th Year";
            this.ContractValue4thYear.Name = "ContractValue4thYear";
            this.ContractValue4thYear.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ContractValue4thYear.Width = 71;
            // 
            // ContractValue5thYear
            // 
            this.ContractValue5thYear.DataPropertyName = "5th Year";
            this.ContractValue5thYear.HeaderText = "5th Year";
            this.ContractValue5thYear.Name = "ContractValue5thYear";
            this.ContractValue5thYear.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ContractValue5thYear.Width = 71;
            // 
            // Scope
            // 
            this.Scope.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Scope.DataPropertyName = "Scope";
            this.Scope.HeaderText = "Scope";
            this.Scope.Name = "Scope";
            this.Scope.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // cmbQuotetype
            // 
            this.cmbQuotetype.DropDownHeight = 80;
            this.cmbQuotetype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbQuotetype.DropDownWidth = 150;
            this.cmbQuotetype.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbQuotetype.FormattingEnabled = true;
            this.cmbQuotetype.IntegralHeight = false;
            this.cmbQuotetype.ItemHeight = 18;
            this.cmbQuotetype.Items.AddRange(new object[] {
            "AMC",
            "Calibration",
            "Re Installation Visit",
            "Service Visit",
            "Preforma Invoice"});
            this.cmbQuotetype.Location = new System.Drawing.Point(114, 12);
            this.cmbQuotetype.Name = "cmbQuotetype";
            this.cmbQuotetype.Size = new System.Drawing.Size(167, 26);
            this.cmbQuotetype.TabIndex = 235;
            this.cmbQuotetype.SelectedIndexChanged += new System.EventHandler(this.cmbQuotetype_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(-2, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 23);
            this.label1.TabIndex = 236;
            this.label1.Text = "Quote Type* :";
            // 
            // dtpQuoteDate
            // 
            this.dtpQuoteDate.CustomFormat = "";
            this.dtpQuoteDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpQuoteDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpQuoteDate.Location = new System.Drawing.Point(1000, 19);
            this.dtpQuoteDate.Name = "dtpQuoteDate";
            this.dtpQuoteDate.Size = new System.Drawing.Size(91, 26);
            this.dtpQuoteDate.TabIndex = 207;
            // 
            // tabCalibration
            // 
            this.tabCalibration.Controls.Add(this.tabPage3);
            this.tabCalibration.Controls.Add(this.tabPage4);
            this.tabCalibration.ItemSize = new System.Drawing.Size(30, 1);
            this.tabCalibration.Location = new System.Drawing.Point(8, 71);
            this.tabCalibration.Name = "tabCalibration";
            this.tabCalibration.SelectedIndex = 0;
            this.tabCalibration.Size = new System.Drawing.Size(1294, 591);
            this.tabCalibration.TabIndex = 238;
            this.tabCalibration.Visible = false;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Silver;
            this.tabPage3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPage3.Controls.Add(this.CmbCurrency);
            this.tabPage3.Controls.Add(this.label61);
            this.tabPage3.Controls.Add(this.cmbCALQuoteFor);
            this.tabPage3.Controls.Add(this.label24);
            this.tabPage3.Controls.Add(this.label26);
            this.tabPage3.Controls.Add(this.label42);
            this.tabPage3.Controls.Add(this.label43);
            this.tabPage3.Controls.Add(this.dtpMutualyAgreedDate);
            this.tabPage3.Controls.Add(this.dtpCalibrationDate);
            this.tabPage3.Controls.Add(this.lblCALQuoteby);
            this.tabPage3.Controls.Add(this.label45);
            this.tabPage3.Controls.Add(this.txtCALCusCode);
            this.tabPage3.Controls.Add(this.txtCALEmailID);
            this.tabPage3.Controls.Add(this.label46);
            this.tabPage3.Controls.Add(this.label48);
            this.tabPage3.Controls.Add(this.txtCalQuotename);
            this.tabPage3.Controls.Add(this.label49);
            this.tabPage3.Controls.Add(this.txtCalZone);
            this.tabPage3.Controls.Add(this.label50);
            this.tabPage3.Controls.Add(this.txtCALCusRef);
            this.tabPage3.Controls.Add(this.txtCALTel);
            this.tabPage3.Controls.Add(this.label51);
            this.tabPage3.Controls.Add(this.label52);
            this.tabPage3.Controls.Add(this.txtCALModelNo);
            this.tabPage3.Controls.Add(this.btnCalStartQuote);
            this.tabPage3.Controls.Add(this.dtpCALDateofQuote);
            this.tabPage3.Controls.Add(this.label54);
            this.tabPage3.Controls.Add(this.txtCALHandy);
            this.tabPage3.Controls.Add(this.label55);
            this.tabPage3.Controls.Add(this.txtCALContactPerson);
            this.tabPage3.Controls.Add(this.label56);
            this.tabPage3.Controls.Add(this.label57);
            this.tabPage3.Controls.Add(this.txtCALAddress);
            this.tabPage3.Controls.Add(this.label58);
            this.tabPage3.Controls.Add(this.cmbCALCustomer);
            this.tabPage3.ForeColor = System.Drawing.Color.Black;
            this.tabPage3.Location = new System.Drawing.Point(4, 5);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1286, 582);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Click += new System.EventHandler(this.tabPage3_Click);
            // 
            // CmbCurrency
            // 
            this.CmbCurrency.DropDownHeight = 60;
            this.CmbCurrency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmbCurrency.DropDownWidth = 150;
            this.CmbCurrency.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CmbCurrency.FormattingEnabled = true;
            this.CmbCurrency.IntegralHeight = false;
            this.CmbCurrency.ItemHeight = 18;
            this.CmbCurrency.Items.AddRange(new object[] {
            "INR",
            "USD"});
            this.CmbCurrency.Location = new System.Drawing.Point(787, 17);
            this.CmbCurrency.Name = "CmbCurrency";
            this.CmbCurrency.Size = new System.Drawing.Size(222, 26);
            this.CmbCurrency.TabIndex = 237;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.ForeColor = System.Drawing.Color.Black;
            this.label61.Location = new System.Drawing.Point(704, 20);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(77, 18);
            this.label61.TabIndex = 238;
            this.label61.Text = "Currency* :";
            // 
            // cmbCALQuoteFor
            // 
            this.cmbCALQuoteFor.DropDownHeight = 60;
            this.cmbCALQuoteFor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCALQuoteFor.DropDownWidth = 150;
            this.cmbCALQuoteFor.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCALQuoteFor.FormattingEnabled = true;
            this.cmbCALQuoteFor.IntegralHeight = false;
            this.cmbCALQuoteFor.ItemHeight = 18;
            this.cmbCALQuoteFor.Items.AddRange(new object[] {
            "BiSS-ITW",
            "INSTRON"});
            this.cmbCALQuoteFor.Location = new System.Drawing.Point(787, 56);
            this.cmbCALQuoteFor.Name = "cmbCALQuoteFor";
            this.cmbCALQuoteFor.Size = new System.Drawing.Size(222, 26);
            this.cmbCALQuoteFor.TabIndex = 233;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Black;
            this.label24.Location = new System.Drawing.Point(697, 59);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(84, 18);
            this.label24.TabIndex = 234;
            this.label24.Text = "Quote For* :";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label26.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label26.Location = new System.Drawing.Point(611, 362);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(351, 18);
            this.label26.TabIndex = 232;
            this.label26.Text = "Equipment/s Covered Under this Maintenance Contract";
            this.label26.Visible = false;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label42.ForeColor = System.Drawing.Color.Black;
            this.label42.Location = new System.Drawing.Point(607, 248);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(174, 18);
            this.label42.TabIndex = 231;
            this.label42.Text = "Model and Serial Number :";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label43.ForeColor = System.Drawing.Color.Black;
            this.label43.Location = new System.Drawing.Point(906, 310);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(150, 18);
            this.label43.TabIndex = 230;
            this.label43.Text = "Mutually Agreed date :";
            this.label43.Visible = false;
            // 
            // dtpMutualyAgreedDate
            // 
            this.dtpMutualyAgreedDate.CustomFormat = "";
            this.dtpMutualyAgreedDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpMutualyAgreedDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpMutualyAgreedDate.Location = new System.Drawing.Point(1062, 302);
            this.dtpMutualyAgreedDate.Name = "dtpMutualyAgreedDate";
            this.dtpMutualyAgreedDate.Size = new System.Drawing.Size(104, 26);
            this.dtpMutualyAgreedDate.TabIndex = 229;
            this.dtpMutualyAgreedDate.Visible = false;
            this.dtpMutualyAgreedDate.ValueChanged += new System.EventHandler(this.dtpMutualyAgreedDate_ValueChanged);
            // 
            // dtpCalibrationDate
            // 
            this.dtpCalibrationDate.CustomFormat = "";
            this.dtpCalibrationDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpCalibrationDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpCalibrationDate.Location = new System.Drawing.Point(790, 304);
            this.dtpCalibrationDate.Name = "dtpCalibrationDate";
            this.dtpCalibrationDate.Size = new System.Drawing.Size(93, 26);
            this.dtpCalibrationDate.TabIndex = 228;
            this.dtpCalibrationDate.Visible = false;
            this.dtpCalibrationDate.ValueChanged += new System.EventHandler(this.dtpCalibrationDate_ValueChanged);
            // 
            // lblCALQuoteby
            // 
            this.lblCALQuoteby.AutoSize = true;
            this.lblCALQuoteby.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCALQuoteby.ForeColor = System.Drawing.Color.Red;
            this.lblCALQuoteby.Location = new System.Drawing.Point(1026, 99);
            this.lblCALQuoteby.Name = "lblCALQuoteby";
            this.lblCALQuoteby.Size = new System.Drawing.Size(0, 19);
            this.lblCALQuoteby.TabIndex = 227;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.Black;
            this.label45.Location = new System.Drawing.Point(943, 99);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(81, 19);
            this.label45.TabIndex = 226;
            this.label45.Text = "Quote By :";
            // 
            // txtCALCusCode
            // 
            this.txtCALCusCode.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtCALCusCode.Location = new System.Drawing.Point(476, 111);
            this.txtCALCusCode.Name = "txtCALCusCode";
            this.txtCALCusCode.Size = new System.Drawing.Size(20, 26);
            this.txtCALCusCode.TabIndex = 199;
            this.txtCALCusCode.Visible = false;
            // 
            // txtCALEmailID
            // 
            this.txtCALEmailID.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtCALEmailID.Location = new System.Drawing.Point(127, 348);
            this.txtCALEmailID.Name = "txtCALEmailID";
            this.txtCALEmailID.Size = new System.Drawing.Size(343, 26);
            this.txtCALEmailID.TabIndex = 21;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label46.ForeColor = System.Drawing.Color.Black;
            this.label46.Location = new System.Drawing.Point(49, 354);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(72, 18);
            this.label46.TabIndex = 195;
            this.label46.Text = "Email ID* :";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label48.ForeColor = System.Drawing.Color.Black;
            this.label48.Location = new System.Drawing.Point(678, 146);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(101, 18);
            this.label48.TabIndex = 193;
            this.label48.Text = "Quote Name *:";
            // 
            // txtCalQuotename
            // 
            this.txtCalQuotename.DropDownHeight = 60;
            this.txtCalQuotename.DropDownWidth = 428;
            this.txtCalQuotename.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCalQuotename.FormattingEnabled = true;
            this.txtCalQuotename.IntegralHeight = false;
            this.txtCalQuotename.ItemHeight = 16;
            this.txtCalQuotename.Items.AddRange(new object[] {
            "Quotation for NVLAP Certified Calibration."});
            this.txtCalQuotename.Location = new System.Drawing.Point(788, 145);
            this.txtCalQuotename.Name = "txtCalQuotename";
            this.txtCalQuotename.Size = new System.Drawing.Size(428, 24);
            this.txtCalQuotename.TabIndex = 8;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label49.ForeColor = System.Drawing.Color.Black;
            this.label49.Location = new System.Drawing.Point(72, 67);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(49, 18);
            this.label49.TabIndex = 189;
            this.label49.Text = "Zone : ";
            // 
            // txtCalZone
            // 
            this.txtCalZone.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtCalZone.Location = new System.Drawing.Point(127, 64);
            this.txtCalZone.Name = "txtCalZone";
            this.txtCalZone.Size = new System.Drawing.Size(343, 26);
            this.txtCalZone.TabIndex = 12;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label50.ForeColor = System.Drawing.Color.Black;
            this.label50.Location = new System.Drawing.Point(28, 22);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(97, 18);
            this.label50.TabIndex = 187;
            this.label50.Text = "Contract Type:";
            // 
            // txtCALCusRef
            // 
            this.txtCALCusRef.DropDownHeight = 60;
            this.txtCALCusRef.DropDownWidth = 428;
            this.txtCALCusRef.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCALCusRef.FormattingEnabled = true;
            this.txtCALCusRef.IntegralHeight = false;
            this.txtCALCusRef.ItemHeight = 16;
            this.txtCALCusRef.Items.AddRange(new object[] {
            "AMC",
            "Renewal",
            "Lever 1",
            "Lever 2",
            "Warranty conversion",
            "MYC renewal",
            "New MYC",
            "CAL",
            "CAL renewal",
            "MYC CAL",
            "Missing Contract"});
            this.txtCALCusRef.Location = new System.Drawing.Point(127, 19);
            this.txtCALCusRef.Name = "txtCALCusRef";
            this.txtCALCusRef.Size = new System.Drawing.Size(343, 24);
            this.txtCALCusRef.TabIndex = 11;
            // 
            // txtCALTel
            // 
            this.txtCALTel.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtCALTel.Location = new System.Drawing.Point(127, 431);
            this.txtCALTel.Name = "txtCALTel";
            this.txtCALTel.Size = new System.Drawing.Size(343, 26);
            this.txtCALTel.TabIndex = 20;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label51.ForeColor = System.Drawing.Color.Black;
            this.label51.Location = new System.Drawing.Point(88, 434);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(33, 18);
            this.label51.TabIndex = 127;
            this.label51.Text = "Tel :";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label52.ForeColor = System.Drawing.Color.Black;
            this.label52.Location = new System.Drawing.Point(611, 310);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(173, 18);
            this.label52.TabIndex = 117;
            this.label52.Text = "Calibration due date is on :";
            this.label52.Visible = false;
            // 
            // txtCALModelNo
            // 
            this.txtCALModelNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCALModelNo.Location = new System.Drawing.Point(790, 221);
            this.txtCALModelNo.Multiline = true;
            this.txtCALModelNo.Name = "txtCALModelNo";
            this.txtCALModelNo.Size = new System.Drawing.Size(428, 60);
            this.txtCALModelNo.TabIndex = 9;
            // 
            // btnCalStartQuote
            // 
            this.btnCalStartQuote.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnCalStartQuote.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCalStartQuote.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalStartQuote.Location = new System.Drawing.Point(1062, 492);
            this.btnCalStartQuote.Name = "btnCalStartQuote";
            this.btnCalStartQuote.Size = new System.Drawing.Size(154, 45);
            this.btnCalStartQuote.TabIndex = 23;
            this.btnCalStartQuote.Text = "Start Quote";
            this.btnCalStartQuote.UseVisualStyleBackColor = false;
            this.btnCalStartQuote.Click += new System.EventHandler(this.btnCalStartQuote_Click);
            // 
            // dtpCALDateofQuote
            // 
            this.dtpCALDateofQuote.CustomFormat = "";
            this.dtpCALDateofQuote.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpCALDateofQuote.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpCALDateofQuote.Location = new System.Drawing.Point(788, 99);
            this.dtpCALDateofQuote.Name = "dtpCALDateofQuote";
            this.dtpCALDateofQuote.Size = new System.Drawing.Size(104, 26);
            this.dtpCALDateofQuote.TabIndex = 1;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label54.ForeColor = System.Drawing.Color.Black;
            this.label54.Location = new System.Drawing.Point(670, 100);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(109, 18);
            this.label54.TabIndex = 104;
            this.label54.Text = "Date of Quote* :";
            // 
            // txtCALHandy
            // 
            this.txtCALHandy.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtCALHandy.Location = new System.Drawing.Point(127, 389);
            this.txtCALHandy.Name = "txtCALHandy";
            this.txtCALHandy.Size = new System.Drawing.Size(343, 26);
            this.txtCALHandy.TabIndex = 19;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label55.ForeColor = System.Drawing.Color.Black;
            this.label55.Location = new System.Drawing.Point(67, 392);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(54, 18);
            this.label55.TabIndex = 98;
            this.label55.Text = "Handy :";
            // 
            // txtCALContactPerson
            // 
            this.txtCALContactPerson.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtCALContactPerson.Location = new System.Drawing.Point(127, 301);
            this.txtCALContactPerson.MaxLength = 80;
            this.txtCALContactPerson.Name = "txtCALContactPerson";
            this.txtCALContactPerson.Size = new System.Drawing.Size(343, 26);
            this.txtCALContactPerson.TabIndex = 18;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label56.ForeColor = System.Drawing.Color.Black;
            this.label56.Location = new System.Drawing.Point(36, 117);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(85, 18);
            this.label56.TabIndex = 92;
            this.label56.Text = "Customer * :";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label57.ForeColor = System.Drawing.Color.Black;
            this.label57.Location = new System.Drawing.Point(8, 304);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(115, 18);
            this.label57.TabIndex = 96;
            this.label57.Text = "Contact Person* :";
            // 
            // txtCALAddress
            // 
            this.txtCALAddress.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtCALAddress.Location = new System.Drawing.Point(127, 153);
            this.txtCALAddress.Multiline = true;
            this.txtCALAddress.Name = "txtCALAddress";
            this.txtCALAddress.Size = new System.Drawing.Size(343, 123);
            this.txtCALAddress.TabIndex = 16;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label58.ForeColor = System.Drawing.Color.Black;
            this.label58.Location = new System.Drawing.Point(56, 156);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(65, 18);
            this.label58.TabIndex = 94;
            this.label58.Text = "Address :";
            // 
            // cmbCALCustomer
            // 
            this.cmbCALCustomer.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbCALCustomer.DropDownHeight = 90;
            this.cmbCALCustomer.DropDownWidth = 150;
            this.cmbCALCustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCALCustomer.FormattingEnabled = true;
            this.cmbCALCustomer.IntegralHeight = false;
            this.cmbCALCustomer.Location = new System.Drawing.Point(127, 111);
            this.cmbCALCustomer.Name = "cmbCALCustomer";
            this.cmbCALCustomer.Size = new System.Drawing.Size(343, 26);
            this.cmbCALCustomer.TabIndex = 15;
            this.cmbCALCustomer.SelectedIndexChanged += new System.EventHandler(this.cmbCALCustomer_SelectedIndexChanged);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.Silver;
            this.tabPage4.Controls.Add(this.brnTab2back);
            this.tabPage4.Controls.Add(this.txtCALGrandTotal);
            this.tabPage4.Controls.Add(this.label65);
            this.tabPage4.Controls.Add(this.txtCALDiscount);
            this.tabPage4.Controls.Add(this.label66);
            this.tabPage4.Controls.Add(this.btnCALGenerateQuote);
            this.tabPage4.Controls.Add(this.btnCALPrintQuote);
            this.tabPage4.Controls.Add(this.label68);
            this.tabPage4.Controls.Add(this.txtCALPaymentTerms);
            this.tabPage4.Controls.Add(this.btnCALAddItem);
            this.tabPage4.Controls.Add(this.dgvCALCalibrationDetails);
            this.tabPage4.Location = new System.Drawing.Point(4, 5);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1286, 582);
            this.tabPage4.TabIndex = 4;
            // 
            // brnTab2back
            // 
            this.brnTab2back.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.brnTab2back.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.brnTab2back.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold);
            this.brnTab2back.Location = new System.Drawing.Point(8, 509);
            this.brnTab2back.Name = "brnTab2back";
            this.brnTab2back.Size = new System.Drawing.Size(124, 35);
            this.brnTab2back.TabIndex = 319;
            this.brnTab2back.Text = "Back";
            this.brnTab2back.UseVisualStyleBackColor = false;
            this.brnTab2back.Click += new System.EventHandler(this.brnTab2back_Click);
            // 
            // txtCALGrandTotal
            // 
            this.txtCALGrandTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCALGrandTotal.Location = new System.Drawing.Point(130, 362);
            this.txtCALGrandTotal.Name = "txtCALGrandTotal";
            this.txtCALGrandTotal.Size = new System.Drawing.Size(142, 22);
            this.txtCALGrandTotal.TabIndex = 274;
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label65.ForeColor = System.Drawing.Color.Black;
            this.label65.Location = new System.Drawing.Point(38, 364);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(86, 18);
            this.label65.TabIndex = 275;
            this.label65.Text = "Grand Total :";
            // 
            // txtCALDiscount
            // 
            this.txtCALDiscount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCALDiscount.Location = new System.Drawing.Point(130, 322);
            this.txtCALDiscount.Name = "txtCALDiscount";
            this.txtCALDiscount.Size = new System.Drawing.Size(93, 22);
            this.txtCALDiscount.TabIndex = 272;
            this.txtCALDiscount.Text = "0";
            this.txtCALDiscount.TextChanged += new System.EventHandler(this.txtCALDiscount_TextChanged);
            this.txtCALDiscount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCALDiscount_KeyPress);
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label66.ForeColor = System.Drawing.Color.Black;
            this.label66.Location = new System.Drawing.Point(41, 322);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(83, 18);
            this.label66.TabIndex = 273;
            this.label66.Text = "Discount % :";
            // 
            // btnCALGenerateQuote
            // 
            this.btnCALGenerateQuote.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnCALGenerateQuote.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCALGenerateQuote.Location = new System.Drawing.Point(826, 509);
            this.btnCALGenerateQuote.Name = "btnCALGenerateQuote";
            this.btnCALGenerateQuote.Size = new System.Drawing.Size(164, 46);
            this.btnCALGenerateQuote.TabIndex = 270;
            this.btnCALGenerateQuote.Text = "Generate Quote";
            this.btnCALGenerateQuote.UseVisualStyleBackColor = false;
            this.btnCALGenerateQuote.Click += new System.EventHandler(this.btnCALGenerateQuote_Click);
            // 
            // btnCALPrintQuote
            // 
            this.btnCALPrintQuote.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnCALPrintQuote.Enabled = false;
            this.btnCALPrintQuote.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCALPrintQuote.Location = new System.Drawing.Point(1069, 509);
            this.btnCALPrintQuote.Name = "btnCALPrintQuote";
            this.btnCALPrintQuote.Size = new System.Drawing.Size(157, 46);
            this.btnCALPrintQuote.TabIndex = 269;
            this.btnCALPrintQuote.Text = "Print Quote";
            this.btnCALPrintQuote.UseVisualStyleBackColor = false;
            this.btnCALPrintQuote.Click += new System.EventHandler(this.btnCALPrintQuote_Click);
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label68.ForeColor = System.Drawing.Color.Black;
            this.label68.Location = new System.Drawing.Point(280, 321);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(110, 18);
            this.label68.TabIndex = 268;
            this.label68.Text = "Payment Terms :";
            // 
            // txtCALPaymentTerms
            // 
            this.txtCALPaymentTerms.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCALPaymentTerms.Location = new System.Drawing.Point(415, 318);
            this.txtCALPaymentTerms.Multiline = true;
            this.txtCALPaymentTerms.Name = "txtCALPaymentTerms";
            this.txtCALPaymentTerms.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtCALPaymentTerms.Size = new System.Drawing.Size(857, 185);
            this.txtCALPaymentTerms.TabIndex = 265;
            // 
            // btnCALAddItem
            // 
            this.btnCALAddItem.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnCALAddItem.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCALAddItem.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCALAddItem.Location = new System.Drawing.Point(1007, 7);
            this.btnCALAddItem.Name = "btnCALAddItem";
            this.btnCALAddItem.Size = new System.Drawing.Size(106, 28);
            this.btnCALAddItem.TabIndex = 247;
            this.btnCALAddItem.Text = "Add Item";
            this.btnCALAddItem.UseVisualStyleBackColor = false;
            this.btnCALAddItem.Click += new System.EventHandler(this.btnCALAddItem_Click);
            // 
            // dgvCALCalibrationDetails
            // 
            this.dgvCALCalibrationDetails.AllowUserToAddRows = false;
            this.dgvCALCalibrationDetails.AllowUserToOrderColumns = true;
            this.dgvCALCalibrationDetails.AllowUserToResizeRows = false;
            this.dgvCALCalibrationDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvCALCalibrationDetails.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvCALCalibrationDetails.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvCALCalibrationDetails.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCALCalibrationDetails.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dgvCALCalibrationDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCALCalibrationDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CALSlNO,
            this.CALNVLAPCalibrationscovered,
            this.Price});
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCALCalibrationDetails.DefaultCellStyle = dataGridViewCellStyle16;
            this.dgvCALCalibrationDetails.Location = new System.Drawing.Point(6, 6);
            this.dgvCALCalibrationDetails.Name = "dgvCALCalibrationDetails";
            this.dgvCALCalibrationDetails.RowHeadersVisible = false;
            this.dgvCALCalibrationDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvCALCalibrationDetails.Size = new System.Drawing.Size(1274, 298);
            this.dgvCALCalibrationDetails.TabIndex = 246;
            this.dgvCALCalibrationDetails.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgvCALCalibrationDetails_CellBeginEdit);
            this.dgvCALCalibrationDetails.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCALCalibrationDetails_CellEndEdit);
            this.dgvCALCalibrationDetails.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvCALCalibrationDetails_EditingControlShowing);
            this.dgvCALCalibrationDetails.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvCALCalibrationDetails_KeyUp);
            // 
            // CALSlNO
            // 
            this.CALSlNO.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.CALSlNO.DataPropertyName = "SLNo";
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.White;
            this.CALSlNO.DefaultCellStyle = dataGridViewCellStyle13;
            this.CALSlNO.HeaderText = "SlNo";
            this.CALSlNO.Name = "CALSlNO";
            this.CALSlNO.ReadOnly = true;
            this.CALSlNO.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CALSlNO.Width = 47;
            // 
            // CALNVLAPCalibrationscovered
            // 
            this.CALNVLAPCalibrationscovered.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.CALNVLAPCalibrationscovered.DataPropertyName = "NVLAPCalibrationscovered";
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.CALNVLAPCalibrationscovered.DefaultCellStyle = dataGridViewCellStyle14;
            this.CALNVLAPCalibrationscovered.HeaderText = "NVLAP Calibrations covered";
            this.CALNVLAPCalibrationscovered.Name = "CALNVLAPCalibrationscovered";
            this.CALNVLAPCalibrationscovered.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Price
            // 
            this.Price.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Price.DataPropertyName = "Price";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Price.DefaultCellStyle = dataGridViewCellStyle15;
            this.Price.FillWeight = 150F;
            this.Price.HeaderText = "Price";
            this.Price.Name = "Price";
            this.Price.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Price.Width = 150;
            // 
            // tabRI
            // 
            this.tabRI.Controls.Add(this.tabPage6);
            this.tabRI.Controls.Add(this.tabPage7);
            this.tabRI.ItemSize = new System.Drawing.Size(30, 1);
            this.tabRI.Location = new System.Drawing.Point(10, 52);
            this.tabRI.Name = "tabRI";
            this.tabRI.SelectedIndex = 0;
            this.tabRI.Size = new System.Drawing.Size(1294, 607);
            this.tabRI.TabIndex = 239;
            this.tabRI.Visible = false;
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.Silver;
            this.tabPage6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPage6.Controls.Add(this.cmbRICurrency);
            this.tabPage6.Controls.Add(this.label62);
            this.tabPage6.Controls.Add(this.txtRIContactNumber);
            this.tabPage6.Controls.Add(this.label60);
            this.tabPage6.Controls.Add(this.label13);
            this.tabPage6.Controls.Add(this.txtRIPaymentTerms);
            this.tabPage6.Controls.Add(this.TxtRIContactPerson);
            this.tabPage6.Controls.Add(this.label16);
            this.tabPage6.Controls.Add(this.txtRIEmail);
            this.tabPage6.Controls.Add(this.label15);
            this.tabPage6.Controls.Add(this.cmbRIQuotefor);
            this.tabPage6.Controls.Add(this.label11);
            this.tabPage6.Controls.Add(this.lblRIQuoteBy);
            this.tabPage6.Controls.Add(this.label18);
            this.tabPage6.Controls.Add(this.txtRICusCode);
            this.tabPage6.Controls.Add(this.label20);
            this.tabPage6.Controls.Add(this.txtRIQuoteName);
            this.tabPage6.Controls.Add(this.label21);
            this.tabPage6.Controls.Add(this.txtRIZone);
            this.tabPage6.Controls.Add(this.label22);
            this.tabPage6.Controls.Add(this.txtRICOntractType);
            this.tabPage6.Controls.Add(this.dtpRIQuoteDate);
            this.tabPage6.Controls.Add(this.label25);
            this.tabPage6.Controls.Add(this.txtRIModelNumber);
            this.tabPage6.Controls.Add(this.label37);
            this.tabPage6.Controls.Add(this.label39);
            this.tabPage6.Controls.Add(this.txtRIAddress);
            this.tabPage6.Controls.Add(this.label41);
            this.tabPage6.Controls.Add(this.cmbRICustomer);
            this.tabPage6.Controls.Add(this.btnRIStart);
            this.tabPage6.ForeColor = System.Drawing.Color.Black;
            this.tabPage6.Location = new System.Drawing.Point(4, 5);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1286, 598);
            this.tabPage6.TabIndex = 0;
            // 
            // cmbRICurrency
            // 
            this.cmbRICurrency.DropDownHeight = 60;
            this.cmbRICurrency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRICurrency.DropDownWidth = 150;
            this.cmbRICurrency.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbRICurrency.FormattingEnabled = true;
            this.cmbRICurrency.IntegralHeight = false;
            this.cmbRICurrency.ItemHeight = 18;
            this.cmbRICurrency.Items.AddRange(new object[] {
            "INR",
            "USD"});
            this.cmbRICurrency.Location = new System.Drawing.Point(1061, 106);
            this.cmbRICurrency.Name = "cmbRICurrency";
            this.cmbRICurrency.Size = new System.Drawing.Size(113, 26);
            this.cmbRICurrency.TabIndex = 319;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.ForeColor = System.Drawing.Color.Black;
            this.label62.Location = new System.Drawing.Point(983, 109);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(77, 18);
            this.label62.TabIndex = 320;
            this.label62.Text = "Currency* :";
            // 
            // txtRIContactNumber
            // 
            this.txtRIContactNumber.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtRIContactNumber.Location = new System.Drawing.Point(164, 303);
            this.txtRIContactNumber.MaxLength = 80;
            this.txtRIContactNumber.Name = "txtRIContactNumber";
            this.txtRIContactNumber.Size = new System.Drawing.Size(434, 26);
            this.txtRIContactNumber.TabIndex = 317;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label60.ForeColor = System.Drawing.Color.Black;
            this.label60.Location = new System.Drawing.Point(35, 303);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(116, 18);
            this.label60.TabIndex = 318;
            this.label60.Text = "Contact Number :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(632, 188);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(109, 18);
            this.label13.TabIndex = 316;
            this.label13.Text = "Payment terms :";
            // 
            // txtRIPaymentTerms
            // 
            this.txtRIPaymentTerms.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRIPaymentTerms.Location = new System.Drawing.Point(747, 186);
            this.txtRIPaymentTerms.Multiline = true;
            this.txtRIPaymentTerms.Name = "txtRIPaymentTerms";
            this.txtRIPaymentTerms.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRIPaymentTerms.Size = new System.Drawing.Size(535, 120);
            this.txtRIPaymentTerms.TabIndex = 315;
            // 
            // TxtRIContactPerson
            // 
            this.TxtRIContactPerson.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.TxtRIContactPerson.Location = new System.Drawing.Point(164, 233);
            this.TxtRIContactPerson.MaxLength = 80;
            this.TxtRIContactPerson.Name = "TxtRIContactPerson";
            this.TxtRIContactPerson.Size = new System.Drawing.Size(434, 26);
            this.TxtRIContactPerson.TabIndex = 308;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(38, 236);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(118, 18);
            this.label16.TabIndex = 309;
            this.label16.Text = "Contact Person * :";
            // 
            // txtRIEmail
            // 
            this.txtRIEmail.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtRIEmail.Location = new System.Drawing.Point(164, 268);
            this.txtRIEmail.MaxLength = 80;
            this.txtRIEmail.Name = "txtRIEmail";
            this.txtRIEmail.Size = new System.Drawing.Size(434, 26);
            this.txtRIEmail.TabIndex = 306;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(102, 271);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(49, 18);
            this.label15.TabIndex = 307;
            this.label15.Text = "Email :";
            // 
            // cmbRIQuotefor
            // 
            this.cmbRIQuotefor.DropDownHeight = 60;
            this.cmbRIQuotefor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRIQuotefor.DropDownWidth = 150;
            this.cmbRIQuotefor.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbRIQuotefor.FormattingEnabled = true;
            this.cmbRIQuotefor.IntegralHeight = false;
            this.cmbRIQuotefor.ItemHeight = 18;
            this.cmbRIQuotefor.Items.AddRange(new object[] {
            "BiSS-ITW",
            "INSTRON"});
            this.cmbRIQuotefor.Location = new System.Drawing.Point(766, 102);
            this.cmbRIQuotefor.Name = "cmbRIQuotefor";
            this.cmbRIQuotefor.Size = new System.Drawing.Size(113, 26);
            this.cmbRIQuotefor.TabIndex = 297;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(676, 106);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(84, 18);
            this.label11.TabIndex = 298;
            this.label11.Text = "Quote For* :";
            // 
            // lblRIQuoteBy
            // 
            this.lblRIQuoteBy.AutoSize = true;
            this.lblRIQuoteBy.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRIQuoteBy.ForeColor = System.Drawing.Color.Red;
            this.lblRIQuoteBy.Location = new System.Drawing.Point(1062, 62);
            this.lblRIQuoteBy.Name = "lblRIQuoteBy";
            this.lblRIQuoteBy.Size = new System.Drawing.Size(0, 19);
            this.lblRIQuoteBy.TabIndex = 295;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(979, 62);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(81, 19);
            this.label18.TabIndex = 294;
            this.label18.Text = "Quote By :";
            // 
            // txtRICusCode
            // 
            this.txtRICusCode.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtRICusCode.Location = new System.Drawing.Point(601, 57);
            this.txtRICusCode.Name = "txtRICusCode";
            this.txtRICusCode.Size = new System.Drawing.Size(20, 26);
            this.txtRICusCode.TabIndex = 293;
            this.txtRICusCode.Visible = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(54, 340);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(101, 18);
            this.label20.TabIndex = 292;
            this.label20.Text = "Quote Name *:";
            // 
            // txtRIQuoteName
            // 
            this.txtRIQuoteName.DropDownHeight = 60;
            this.txtRIQuoteName.DropDownWidth = 428;
            this.txtRIQuoteName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRIQuoteName.FormattingEnabled = true;
            this.txtRIQuoteName.IntegralHeight = false;
            this.txtRIQuoteName.ItemHeight = 16;
            this.txtRIQuoteName.Items.AddRange(new object[] {
            "Dismantling, Installation commissioning and at new site.",
            "Service visit charges for 1 day"});
            this.txtRIQuoteName.Location = new System.Drawing.Point(164, 339);
            this.txtRIQuoteName.Name = "txtRIQuoteName";
            this.txtRIQuoteName.Size = new System.Drawing.Size(434, 24);
            this.txtRIQuoteName.TabIndex = 279;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(463, 17);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(49, 18);
            this.label21.TabIndex = 291;
            this.label21.Text = "Zone : ";
            // 
            // txtRIZone
            // 
            this.txtRIZone.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtRIZone.Location = new System.Drawing.Point(518, 14);
            this.txtRIZone.Name = "txtRIZone";
            this.txtRIZone.Size = new System.Drawing.Size(103, 26);
            this.txtRIZone.TabIndex = 282;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label22.ForeColor = System.Drawing.Color.Black;
            this.label22.Location = new System.Drawing.Point(54, 16);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(100, 18);
            this.label22.TabIndex = 290;
            this.label22.Text = "Contract Type :";
            // 
            // txtRICOntractType
            // 
            this.txtRICOntractType.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtRICOntractType.Location = new System.Drawing.Point(164, 13);
            this.txtRICOntractType.Name = "txtRICOntractType";
            this.txtRICOntractType.Size = new System.Drawing.Size(280, 26);
            this.txtRICOntractType.TabIndex = 281;
            // 
            // dtpRIQuoteDate
            // 
            this.dtpRIQuoteDate.CustomFormat = "";
            this.dtpRIQuoteDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpRIQuoteDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpRIQuoteDate.Location = new System.Drawing.Point(766, 55);
            this.dtpRIQuoteDate.Name = "dtpRIQuoteDate";
            this.dtpRIQuoteDate.Size = new System.Drawing.Size(93, 26);
            this.dtpRIQuoteDate.TabIndex = 278;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(706, 60);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(54, 18);
            this.label25.TabIndex = 289;
            this.label25.Text = "Date * :";
            // 
            // txtRIModelNumber
            // 
            this.txtRIModelNumber.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtRIModelNumber.Location = new System.Drawing.Point(751, 142);
            this.txtRIModelNumber.MaxLength = 80;
            this.txtRIModelNumber.Name = "txtRIModelNumber";
            this.txtRIModelNumber.Size = new System.Drawing.Size(434, 26);
            this.txtRIModelNumber.TabIndex = 285;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label37.ForeColor = System.Drawing.Color.Black;
            this.label37.Location = new System.Drawing.Point(73, 60);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(85, 18);
            this.label37.TabIndex = 286;
            this.label37.Text = "Customer * :";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label39.ForeColor = System.Drawing.Color.Black;
            this.label39.Location = new System.Drawing.Point(624, 145);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(117, 18);
            this.label39.TabIndex = 288;
            this.label39.Text = "Model Number* :";
            // 
            // txtRIAddress
            // 
            this.txtRIAddress.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtRIAddress.Location = new System.Drawing.Point(164, 96);
            this.txtRIAddress.Multiline = true;
            this.txtRIAddress.Name = "txtRIAddress";
            this.txtRIAddress.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRIAddress.Size = new System.Drawing.Size(434, 123);
            this.txtRIAddress.TabIndex = 284;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label41.ForeColor = System.Drawing.Color.Black;
            this.label41.Location = new System.Drawing.Point(93, 99);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(65, 18);
            this.label41.TabIndex = 287;
            this.label41.Text = "Address :";
            // 
            // cmbRICustomer
            // 
            this.cmbRICustomer.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbRICustomer.DropDownHeight = 90;
            this.cmbRICustomer.DropDownWidth = 150;
            this.cmbRICustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbRICustomer.FormattingEnabled = true;
            this.cmbRICustomer.IntegralHeight = false;
            this.cmbRICustomer.Location = new System.Drawing.Point(164, 54);
            this.cmbRICustomer.Name = "cmbRICustomer";
            this.cmbRICustomer.Size = new System.Drawing.Size(431, 26);
            this.cmbRICustomer.TabIndex = 283;
            this.cmbRICustomer.SelectedIndexChanged += new System.EventHandler(this.cmbRICustomer_SelectedIndexChanged);
            // 
            // btnRIStart
            // 
            this.btnRIStart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnRIStart.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnRIStart.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRIStart.Location = new System.Drawing.Point(1086, 518);
            this.btnRIStart.Name = "btnRIStart";
            this.btnRIStart.Size = new System.Drawing.Size(154, 37);
            this.btnRIStart.TabIndex = 23;
            this.btnRIStart.Text = "Start Quote";
            this.btnRIStart.UseVisualStyleBackColor = false;
            this.btnRIStart.Click += new System.EventHandler(this.btnRIStart_Click);
            // 
            // tabPage7
            // 
            this.tabPage7.BackColor = System.Drawing.Color.Silver;
            this.tabPage7.Controls.Add(this.btnTab3back);
            this.tabPage7.Controls.Add(this.label14);
            this.tabPage7.Controls.Add(this.txtRIAdditionalCharges);
            this.tabPage7.Controls.Add(this.btnRIAddNewItem);
            this.tabPage7.Controls.Add(this.txtRIVGrandTotal);
            this.tabPage7.Controls.Add(this.label44);
            this.tabPage7.Controls.Add(this.txtRIVDiscount);
            this.tabPage7.Controls.Add(this.label59);
            this.tabPage7.Controls.Add(this.btnGenRIVQuote);
            this.tabPage7.Controls.Add(this.btnPrintRIQuote);
            this.tabPage7.Controls.Add(this.dgvRIQuoteDetails);
            this.tabPage7.Location = new System.Drawing.Point(4, 5);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(1286, 598);
            this.tabPage7.TabIndex = 4;
            // 
            // btnTab3back
            // 
            this.btnTab3back.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnTab3back.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnTab3back.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold);
            this.btnTab3back.Location = new System.Drawing.Point(14, 537);
            this.btnTab3back.Name = "btnTab3back";
            this.btnTab3back.Size = new System.Drawing.Size(124, 35);
            this.btnTab3back.TabIndex = 318;
            this.btnTab3back.Text = "Back";
            this.btnTab3back.UseVisualStyleBackColor = false;
            this.btnTab3back.Click += new System.EventHandler(this.btnTab3back_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(278, 508);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(163, 18);
            this.label14.TabIndex = 317;
            this.label14.Text = "Additional days Charges :";
            // 
            // txtRIAdditionalCharges
            // 
            this.txtRIAdditionalCharges.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRIAdditionalCharges.Location = new System.Drawing.Point(448, 506);
            this.txtRIAdditionalCharges.Name = "txtRIAdditionalCharges";
            this.txtRIAdditionalCharges.Size = new System.Drawing.Size(85, 22);
            this.txtRIAdditionalCharges.TabIndex = 316;
            // 
            // btnRIAddNewItem
            // 
            this.btnRIAddNewItem.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnRIAddNewItem.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnRIAddNewItem.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRIAddNewItem.Location = new System.Drawing.Point(1001, 3);
            this.btnRIAddNewItem.Name = "btnRIAddNewItem";
            this.btnRIAddNewItem.Size = new System.Drawing.Size(106, 28);
            this.btnRIAddNewItem.TabIndex = 315;
            this.btnRIAddNewItem.Text = "Add Item";
            this.btnRIAddNewItem.UseVisualStyleBackColor = false;
            this.btnRIAddNewItem.Click += new System.EventHandler(this.btnRIAddNewItem_Click);
            // 
            // txtRIVGrandTotal
            // 
            this.txtRIVGrandTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRIVGrandTotal.Location = new System.Drawing.Point(653, 506);
            this.txtRIVGrandTotal.Name = "txtRIVGrandTotal";
            this.txtRIVGrandTotal.Size = new System.Drawing.Size(230, 29);
            this.txtRIVGrandTotal.TabIndex = 311;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label44.ForeColor = System.Drawing.Color.Black;
            this.label44.Location = new System.Drawing.Point(561, 508);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(86, 18);
            this.label44.TabIndex = 312;
            this.label44.Text = "Grand Total :";
            // 
            // txtRIVDiscount
            // 
            this.txtRIVDiscount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRIVDiscount.Location = new System.Drawing.Point(100, 506);
            this.txtRIVDiscount.Name = "txtRIVDiscount";
            this.txtRIVDiscount.Size = new System.Drawing.Size(154, 22);
            this.txtRIVDiscount.TabIndex = 309;
            this.txtRIVDiscount.Text = "0";
            this.txtRIVDiscount.TextChanged += new System.EventHandler(this.txtRIVDiscount_TextChanged);
            this.txtRIVDiscount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRIVDiscount_KeyPress);
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label59.ForeColor = System.Drawing.Color.Black;
            this.label59.Location = new System.Drawing.Point(11, 506);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(83, 18);
            this.label59.TabIndex = 310;
            this.label59.Text = "Discount % :";
            // 
            // btnGenRIVQuote
            // 
            this.btnGenRIVQuote.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnGenRIVQuote.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenRIVQuote.Location = new System.Drawing.Point(958, 532);
            this.btnGenRIVQuote.Name = "btnGenRIVQuote";
            this.btnGenRIVQuote.Size = new System.Drawing.Size(164, 40);
            this.btnGenRIVQuote.TabIndex = 307;
            this.btnGenRIVQuote.Text = "Generate Quote";
            this.btnGenRIVQuote.UseVisualStyleBackColor = false;
            this.btnGenRIVQuote.Click += new System.EventHandler(this.btnGenRIVQuote_Click);
            // 
            // btnPrintRIQuote
            // 
            this.btnPrintRIQuote.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnPrintRIQuote.Enabled = false;
            this.btnPrintRIQuote.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrintRIQuote.Location = new System.Drawing.Point(1144, 532);
            this.btnPrintRIQuote.Name = "btnPrintRIQuote";
            this.btnPrintRIQuote.Size = new System.Drawing.Size(126, 40);
            this.btnPrintRIQuote.TabIndex = 306;
            this.btnPrintRIQuote.Text = "Print Quote";
            this.btnPrintRIQuote.UseVisualStyleBackColor = false;
            this.btnPrintRIQuote.Click += new System.EventHandler(this.btnPrintRIQuote_Click);
            // 
            // dgvRIQuoteDetails
            // 
            this.dgvRIQuoteDetails.AllowUserToAddRows = false;
            this.dgvRIQuoteDetails.AllowUserToOrderColumns = true;
            this.dgvRIQuoteDetails.AllowUserToResizeRows = false;
            this.dgvRIQuoteDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvRIQuoteDetails.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvRIQuoteDetails.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvRIQuoteDetails.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRIQuoteDetails.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.dgvRIQuoteDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRIQuoteDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.RISlNo,
            this.RIScopeofwork,
            this.RIPrice});
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle21.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRIQuoteDetails.DefaultCellStyle = dataGridViewCellStyle21;
            this.dgvRIQuoteDetails.Location = new System.Drawing.Point(12, 3);
            this.dgvRIQuoteDetails.Name = "dgvRIQuoteDetails";
            this.dgvRIQuoteDetails.RowHeadersVisible = false;
            this.dgvRIQuoteDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvRIQuoteDetails.Size = new System.Drawing.Size(1258, 490);
            this.dgvRIQuoteDetails.TabIndex = 302;
            this.dgvRIQuoteDetails.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgvRIQuoteDetails_CellBeginEdit);
            this.dgvRIQuoteDetails.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvRIQuoteDetails_CellEndEdit);
            this.dgvRIQuoteDetails.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvRIQuoteDetails_EditingControlShowing);
            this.dgvRIQuoteDetails.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvRIQuoteDetails_KeyUp);
            // 
            // RISlNo
            // 
            this.RISlNo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.RISlNo.DataPropertyName = "SlNo";
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.RISlNo.DefaultCellStyle = dataGridViewCellStyle18;
            this.RISlNo.HeaderText = "SlNo";
            this.RISlNo.Name = "RISlNo";
            this.RISlNo.ReadOnly = true;
            this.RISlNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RISlNo.Width = 47;
            // 
            // RIScopeofwork
            // 
            this.RIScopeofwork.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.RIScopeofwork.DataPropertyName = "Scope of Work";
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.RIScopeofwork.DefaultCellStyle = dataGridViewCellStyle19;
            this.RIScopeofwork.HeaderText = "Scope of work";
            this.RIScopeofwork.Name = "RIScopeofwork";
            this.RIScopeofwork.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // RIPrice
            // 
            this.RIPrice.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.RIPrice.DataPropertyName = "Price";
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.RIPrice.DefaultCellStyle = dataGridViewCellStyle20;
            this.RIPrice.FillWeight = 140F;
            this.RIPrice.HeaderText = "Price";
            this.RIPrice.Name = "RIPrice";
            this.RIPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RIPrice.Width = 140;
            // 
            // chkQuoteSavePath
            // 
            this.chkQuoteSavePath.AutoSize = true;
            this.chkQuoteSavePath.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkQuoteSavePath.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.chkQuoteSavePath.Location = new System.Drawing.Point(1108, 13);
            this.chkQuoteSavePath.Name = "chkQuoteSavePath";
            this.chkQuoteSavePath.Size = new System.Drawing.Size(160, 27);
            this.chkQuoteSavePath.TabIndex = 240;
            this.chkQuoteSavePath.Text = "Quote Save Path";
            this.chkQuoteSavePath.UseVisualStyleBackColor = true;
            this.chkQuoteSavePath.CheckedChanged += new System.EventHandler(this.chkQuoteSavePath_CheckedChanged);
            // 
            // tabPI
            // 
            this.tabPI.Controls.Add(this.tabPage8);
            this.tabPI.Controls.Add(this.tabPage9);
            this.tabPI.ItemSize = new System.Drawing.Size(30, 1);
            this.tabPI.Location = new System.Drawing.Point(3, 78);
            this.tabPI.Name = "tabPI";
            this.tabPI.SelectedIndex = 0;
            this.tabPI.Size = new System.Drawing.Size(1294, 569);
            this.tabPI.TabIndex = 241;
            this.tabPI.Visible = false;
            // 
            // tabPage8
            // 
            this.tabPage8.BackColor = System.Drawing.Color.Silver;
            this.tabPage8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPage8.Controls.Add(this.dtpPIPurchaseorderdate);
            this.tabPage8.Controls.Add(this.label88);
            this.tabPage8.Controls.Add(this.dtpPIQuoterefdate);
            this.tabPage8.Controls.Add(this.label87);
            this.tabPage8.Controls.Add(this.cmbPICurrency);
            this.tabPage8.Controls.Add(this.label69);
            this.tabPage8.Controls.Add(this.txtPICountry);
            this.tabPage8.Controls.Add(this.label70);
            this.tabPage8.Controls.Add(this.txtPImchineNo);
            this.tabPage8.Controls.Add(this.label78);
            this.tabPage8.Controls.Add(this.txtPIQuoteRef);
            this.tabPage8.Controls.Add(this.label72);
            this.tabPage8.Controls.Add(this.txtPIPurchaseOrder);
            this.tabPage8.Controls.Add(this.label73);
            this.tabPage8.Controls.Add(this.cmbPICompany);
            this.tabPage8.Controls.Add(this.label74);
            this.tabPage8.Controls.Add(this.lblPIBY);
            this.tabPage8.Controls.Add(this.label76);
            this.tabPage8.Controls.Add(this.label77);
            this.tabPage8.Controls.Add(this.txtPIGSTIN);
            this.tabPage8.Controls.Add(this.dtpPIDate);
            this.tabPage8.Controls.Add(this.label80);
            this.tabPage8.Controls.Add(this.label81);
            this.tabPage8.Controls.Add(this.txtPIAddress);
            this.tabPage8.Controls.Add(this.label83);
            this.tabPage8.Controls.Add(this.cmbPICustomer);
            this.tabPage8.Controls.Add(this.btnStartPI);
            this.tabPage8.Controls.Add(this.txtPICusCode);
            this.tabPage8.ForeColor = System.Drawing.Color.Black;
            this.tabPage8.Location = new System.Drawing.Point(4, 5);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(1286, 560);
            this.tabPage8.TabIndex = 0;
            // 
            // dtpPIPurchaseorderdate
            // 
            this.dtpPIPurchaseorderdate.CustomFormat = "";
            this.dtpPIPurchaseorderdate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpPIPurchaseorderdate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpPIPurchaseorderdate.Location = new System.Drawing.Point(547, 323);
            this.dtpPIPurchaseorderdate.Name = "dtpPIPurchaseorderdate";
            this.dtpPIPurchaseorderdate.Size = new System.Drawing.Size(93, 26);
            this.dtpPIPurchaseorderdate.TabIndex = 323;
            this.dtpPIPurchaseorderdate.ValueChanged += new System.EventHandler(this.dtpPIPurchaseorderdate_ValueChanged);
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label88.ForeColor = System.Drawing.Color.Black;
            this.label88.Location = new System.Drawing.Point(487, 330);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(54, 18);
            this.label88.TabIndex = 324;
            this.label88.Text = "Date * :";
            // 
            // dtpPIQuoterefdate
            // 
            this.dtpPIQuoterefdate.CustomFormat = "";
            this.dtpPIQuoterefdate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpPIQuoterefdate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpPIQuoterefdate.Location = new System.Drawing.Point(547, 289);
            this.dtpPIQuoterefdate.Name = "dtpPIQuoterefdate";
            this.dtpPIQuoterefdate.Size = new System.Drawing.Size(93, 26);
            this.dtpPIQuoterefdate.TabIndex = 321;
            this.dtpPIQuoterefdate.ValueChanged += new System.EventHandler(this.dtpPIQuoterefdate_ValueChanged);
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label87.ForeColor = System.Drawing.Color.Black;
            this.label87.Location = new System.Drawing.Point(487, 294);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(54, 18);
            this.label87.TabIndex = 322;
            this.label87.Text = "Date * :";
            // 
            // cmbPICurrency
            // 
            this.cmbPICurrency.DropDownHeight = 60;
            this.cmbPICurrency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPICurrency.DropDownWidth = 150;
            this.cmbPICurrency.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPICurrency.FormattingEnabled = true;
            this.cmbPICurrency.IntegralHeight = false;
            this.cmbPICurrency.ItemHeight = 18;
            this.cmbPICurrency.Items.AddRange(new object[] {
            "INR",
            "USD"});
            this.cmbPICurrency.Location = new System.Drawing.Point(950, 199);
            this.cmbPICurrency.Name = "cmbPICurrency";
            this.cmbPICurrency.Size = new System.Drawing.Size(113, 26);
            this.cmbPICurrency.TabIndex = 319;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.ForeColor = System.Drawing.Color.Black;
            this.label69.Location = new System.Drawing.Point(864, 201);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(80, 18);
            this.label69.TabIndex = 320;
            this.label69.Text = "Currency * :";
            // 
            // txtPICountry
            // 
            this.txtPICountry.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtPICountry.Location = new System.Drawing.Point(164, 237);
            this.txtPICountry.MaxLength = 80;
            this.txtPICountry.Name = "txtPICountry";
            this.txtPICountry.Size = new System.Drawing.Size(151, 26);
            this.txtPICountry.TabIndex = 317;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label70.ForeColor = System.Drawing.Color.Black;
            this.label70.Location = new System.Drawing.Point(94, 240);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(64, 18);
            this.label70.TabIndex = 318;
            this.label70.Text = "Country :";
            // 
            // txtPImchineNo
            // 
            this.txtPImchineNo.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtPImchineNo.Location = new System.Drawing.Point(944, 237);
            this.txtPImchineNo.MaxLength = 80;
            this.txtPImchineNo.Name = "txtPImchineNo";
            this.txtPImchineNo.Size = new System.Drawing.Size(123, 26);
            this.txtPImchineNo.TabIndex = 321;
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label78.ForeColor = System.Drawing.Color.Black;
            this.label78.Location = new System.Drawing.Point(851, 240);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(90, 18);
            this.label78.TabIndex = 320;
            this.label78.Text = "Machine No :";
            // 
            // txtPIQuoteRef
            // 
            this.txtPIQuoteRef.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtPIQuoteRef.Location = new System.Drawing.Point(164, 289);
            this.txtPIQuoteRef.MaxLength = 80;
            this.txtPIQuoteRef.Name = "txtPIQuoteRef";
            this.txtPIQuoteRef.Size = new System.Drawing.Size(317, 26);
            this.txtPIQuoteRef.TabIndex = 308;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label72.ForeColor = System.Drawing.Color.Black;
            this.label72.Location = new System.Drawing.Point(46, 291);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(112, 18);
            this.label72.TabIndex = 309;
            this.label72.Text = "Quotation Ref * :";
            // 
            // txtPIPurchaseOrder
            // 
            this.txtPIPurchaseOrder.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtPIPurchaseOrder.Location = new System.Drawing.Point(164, 324);
            this.txtPIPurchaseOrder.MaxLength = 80;
            this.txtPIPurchaseOrder.Name = "txtPIPurchaseOrder";
            this.txtPIPurchaseOrder.Size = new System.Drawing.Size(317, 26);
            this.txtPIPurchaseOrder.TabIndex = 306;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label73.ForeColor = System.Drawing.Color.Black;
            this.label73.Location = new System.Drawing.Point(29, 327);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(129, 18);
            this.label73.TabIndex = 307;
            this.label73.Text = "Purchase Order no :";
            // 
            // cmbPICompany
            // 
            this.cmbPICompany.DropDownHeight = 60;
            this.cmbPICompany.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPICompany.DropDownWidth = 150;
            this.cmbPICompany.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPICompany.FormattingEnabled = true;
            this.cmbPICompany.IntegralHeight = false;
            this.cmbPICompany.ItemHeight = 18;
            this.cmbPICompany.Items.AddRange(new object[] {
            "BiSS-ITW",
            "INSTRON"});
            this.cmbPICompany.Location = new System.Drawing.Point(950, 144);
            this.cmbPICompany.Name = "cmbPICompany";
            this.cmbPICompany.Size = new System.Drawing.Size(113, 26);
            this.cmbPICompany.TabIndex = 297;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.ForeColor = System.Drawing.Color.Black;
            this.label74.Location = new System.Drawing.Point(815, 147);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(131, 18);
            this.label74.TabIndex = 298;
            this.label74.Text = "Invoice Company * :";
            // 
            // lblPIBY
            // 
            this.lblPIBY.AutoSize = true;
            this.lblPIBY.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPIBY.ForeColor = System.Drawing.Color.Red;
            this.lblPIBY.Location = new System.Drawing.Point(946, 68);
            this.lblPIBY.Name = "lblPIBY";
            this.lblPIBY.Size = new System.Drawing.Size(0, 19);
            this.lblPIBY.TabIndex = 295;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.ForeColor = System.Drawing.Color.Black;
            this.label76.Location = new System.Drawing.Point(863, 68);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(81, 19);
            this.label76.TabIndex = 294;
            this.label76.Text = "Quote By :";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label77.ForeColor = System.Drawing.Color.Black;
            this.label77.Location = new System.Drawing.Point(363, 240);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(53, 18);
            this.label77.TabIndex = 292;
            this.label77.Text = "GSTIN :";
            // 
            // txtPIGSTIN
            // 
            this.txtPIGSTIN.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtPIGSTIN.Location = new System.Drawing.Point(422, 237);
            this.txtPIGSTIN.Name = "txtPIGSTIN";
            this.txtPIGSTIN.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtPIGSTIN.Size = new System.Drawing.Size(221, 26);
            this.txtPIGSTIN.TabIndex = 279;
            // 
            // dtpPIDate
            // 
            this.dtpPIDate.CustomFormat = "";
            this.dtpPIDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpPIDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpPIDate.Location = new System.Drawing.Point(950, 104);
            this.dtpPIDate.Name = "dtpPIDate";
            this.dtpPIDate.Size = new System.Drawing.Size(93, 26);
            this.dtpPIDate.TabIndex = 278;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label80.ForeColor = System.Drawing.Color.Black;
            this.label80.Location = new System.Drawing.Point(848, 109);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(102, 18);
            this.label80.TabIndex = 289;
            this.label80.Text = "Invoice Date * :";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label81.ForeColor = System.Drawing.Color.Black;
            this.label81.Location = new System.Drawing.Point(73, 60);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(85, 18);
            this.label81.TabIndex = 286;
            this.label81.Text = "Customer * :";
            // 
            // txtPIAddress
            // 
            this.txtPIAddress.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtPIAddress.Location = new System.Drawing.Point(164, 96);
            this.txtPIAddress.Multiline = true;
            this.txtPIAddress.Name = "txtPIAddress";
            this.txtPIAddress.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtPIAddress.Size = new System.Drawing.Size(476, 123);
            this.txtPIAddress.TabIndex = 284;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label83.ForeColor = System.Drawing.Color.Black;
            this.label83.Location = new System.Drawing.Point(93, 99);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(65, 18);
            this.label83.TabIndex = 287;
            this.label83.Text = "Address :";
            // 
            // cmbPICustomer
            // 
            this.cmbPICustomer.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbPICustomer.DropDownHeight = 90;
            this.cmbPICustomer.DropDownWidth = 150;
            this.cmbPICustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPICustomer.FormattingEnabled = true;
            this.cmbPICustomer.IntegralHeight = false;
            this.cmbPICustomer.Location = new System.Drawing.Point(164, 54);
            this.cmbPICustomer.Name = "cmbPICustomer";
            this.cmbPICustomer.Size = new System.Drawing.Size(476, 26);
            this.cmbPICustomer.TabIndex = 283;
            this.cmbPICustomer.SelectedIndexChanged += new System.EventHandler(this.cmbPICustomer_SelectedIndexChanged);
            // 
            // btnStartPI
            // 
            this.btnStartPI.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnStartPI.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnStartPI.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStartPI.Location = new System.Drawing.Point(1069, 473);
            this.btnStartPI.Name = "btnStartPI";
            this.btnStartPI.Size = new System.Drawing.Size(154, 37);
            this.btnStartPI.TabIndex = 23;
            this.btnStartPI.Text = "Start PI";
            this.btnStartPI.UseVisualStyleBackColor = false;
            this.btnStartPI.Click += new System.EventHandler(this.btnStartPI_Click);
            // 
            // txtPICusCode
            // 
            this.txtPICusCode.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtPICusCode.Location = new System.Drawing.Point(614, 54);
            this.txtPICusCode.Name = "txtPICusCode";
            this.txtPICusCode.Size = new System.Drawing.Size(20, 26);
            this.txtPICusCode.TabIndex = 293;
            this.txtPICusCode.Visible = false;
            // 
            // tabPage9
            // 
            this.tabPage9.BackColor = System.Drawing.Color.Silver;
            this.tabPage9.Controls.Add(this.label71);
            this.tabPage9.Controls.Add(this.txtPIPaymentterms);
            this.tabPage9.Controls.Add(this.btnPIBack);
            this.tabPage9.Controls.Add(this.label84);
            this.tabPage9.Controls.Add(this.btnPIAddItem);
            this.tabPage9.Controls.Add(this.txtPIGrandTotal);
            this.tabPage9.Controls.Add(this.label85);
            this.tabPage9.Controls.Add(this.txtPIGST);
            this.tabPage9.Controls.Add(this.btnGeneratePI);
            this.tabPage9.Controls.Add(this.btnPrintPI);
            this.tabPage9.Controls.Add(this.dgvPIDetails);
            this.tabPage9.Location = new System.Drawing.Point(4, 5);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(1286, 560);
            this.tabPage9.TabIndex = 4;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label71.ForeColor = System.Drawing.Color.Black;
            this.label71.Location = new System.Drawing.Point(19, 267);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(109, 18);
            this.label71.TabIndex = 320;
            this.label71.Text = "Payment terms :";
            // 
            // txtPIPaymentterms
            // 
            this.txtPIPaymentterms.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPIPaymentterms.Location = new System.Drawing.Point(134, 265);
            this.txtPIPaymentterms.Multiline = true;
            this.txtPIPaymentterms.Name = "txtPIPaymentterms";
            this.txtPIPaymentterms.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtPIPaymentterms.Size = new System.Drawing.Size(535, 120);
            this.txtPIPaymentterms.TabIndex = 319;
            this.txtPIPaymentterms.Text = resources.GetString("txtPIPaymentterms.Text");
            // 
            // btnPIBack
            // 
            this.btnPIBack.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnPIBack.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnPIBack.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold);
            this.btnPIBack.Location = new System.Drawing.Point(7, 505);
            this.btnPIBack.Name = "btnPIBack";
            this.btnPIBack.Size = new System.Drawing.Size(124, 35);
            this.btnPIBack.TabIndex = 318;
            this.btnPIBack.Text = "Back";
            this.btnPIBack.UseVisualStyleBackColor = false;
            this.btnPIBack.Click += new System.EventHandler(this.btnPIBack_Click);
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label84.ForeColor = System.Drawing.Color.Black;
            this.label84.Location = new System.Drawing.Point(75, 421);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(53, 18);
            this.label84.TabIndex = 317;
            this.label84.Text = "GST % :";
            // 
            // btnPIAddItem
            // 
            this.btnPIAddItem.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnPIAddItem.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnPIAddItem.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPIAddItem.Location = new System.Drawing.Point(846, 7);
            this.btnPIAddItem.Name = "btnPIAddItem";
            this.btnPIAddItem.Size = new System.Drawing.Size(106, 23);
            this.btnPIAddItem.TabIndex = 315;
            this.btnPIAddItem.Text = "Add Item";
            this.btnPIAddItem.UseVisualStyleBackColor = false;
            this.btnPIAddItem.Click += new System.EventHandler(this.btnPIAddItem_Click);
            // 
            // txtPIGrandTotal
            // 
            this.txtPIGrandTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPIGrandTotal.Location = new System.Drawing.Point(439, 421);
            this.txtPIGrandTotal.Name = "txtPIGrandTotal";
            this.txtPIGrandTotal.ReadOnly = true;
            this.txtPIGrandTotal.Size = new System.Drawing.Size(230, 29);
            this.txtPIGrandTotal.TabIndex = 311;
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label85.ForeColor = System.Drawing.Color.Black;
            this.label85.Location = new System.Drawing.Point(347, 423);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(86, 18);
            this.label85.TabIndex = 312;
            this.label85.Text = "Grand Total :";
            // 
            // txtPIGST
            // 
            this.txtPIGST.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPIGST.Location = new System.Drawing.Point(134, 417);
            this.txtPIGST.Name = "txtPIGST";
            this.txtPIGST.Size = new System.Drawing.Size(154, 22);
            this.txtPIGST.TabIndex = 309;
            this.txtPIGST.Text = "0";
            this.txtPIGST.TextChanged += new System.EventHandler(this.txtPIGST_TextChanged);
            this.txtPIGST.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPIGST_KeyPress);
            // 
            // btnGeneratePI
            // 
            this.btnGeneratePI.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnGeneratePI.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGeneratePI.Location = new System.Drawing.Point(1003, 500);
            this.btnGeneratePI.Name = "btnGeneratePI";
            this.btnGeneratePI.Size = new System.Drawing.Size(129, 40);
            this.btnGeneratePI.TabIndex = 307;
            this.btnGeneratePI.Text = "Generate PI";
            this.btnGeneratePI.UseVisualStyleBackColor = false;
            this.btnGeneratePI.Click += new System.EventHandler(this.btnGeneratePI_Click);
            // 
            // btnPrintPI
            // 
            this.btnPrintPI.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnPrintPI.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrintPI.Location = new System.Drawing.Point(1154, 500);
            this.btnPrintPI.Name = "btnPrintPI";
            this.btnPrintPI.Size = new System.Drawing.Size(126, 40);
            this.btnPrintPI.TabIndex = 306;
            this.btnPrintPI.Text = "Print PI";
            this.btnPrintPI.UseVisualStyleBackColor = false;
            this.btnPrintPI.Click += new System.EventHandler(this.btnPrintPI_Click);
            // 
            // dgvPIDetails
            // 
            this.dgvPIDetails.AllowUserToAddRows = false;
            this.dgvPIDetails.AllowUserToOrderColumns = true;
            this.dgvPIDetails.AllowUserToResizeRows = false;
            this.dgvPIDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvPIDetails.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvPIDetails.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvPIDetails.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPIDetails.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle22;
            this.dgvPIDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPIDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.PISlNo,
            this.PIDescription,
            this.PIQty,
            this.PIRate,
            this.PIAmount});
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle27.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPIDetails.DefaultCellStyle = dataGridViewCellStyle27;
            this.dgvPIDetails.Location = new System.Drawing.Point(12, 3);
            this.dgvPIDetails.Name = "dgvPIDetails";
            this.dgvPIDetails.RowHeadersVisible = false;
            this.dgvPIDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvPIDetails.Size = new System.Drawing.Size(1258, 248);
            this.dgvPIDetails.TabIndex = 302;
            this.dgvPIDetails.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgvPIDetails_CellBeginEdit);
            this.dgvPIDetails.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPIDetails_CellEndEdit);
            this.dgvPIDetails.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvPIDetails_EditingControlShowing);
            this.dgvPIDetails.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvPIDetails_KeyUp);
            // 
            // PISlNo
            // 
            this.PISlNo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.PISlNo.DataPropertyName = "SlNo";
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.PISlNo.DefaultCellStyle = dataGridViewCellStyle23;
            this.PISlNo.HeaderText = "SlNo";
            this.PISlNo.Name = "PISlNo";
            this.PISlNo.ReadOnly = true;
            this.PISlNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PISlNo.Width = 47;
            // 
            // PIDescription
            // 
            this.PIDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.PIDescription.DataPropertyName = "Description";
            dataGridViewCellStyle24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.PIDescription.DefaultCellStyle = dataGridViewCellStyle24;
            this.PIDescription.HeaderText = "Description";
            this.PIDescription.Name = "PIDescription";
            this.PIDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // PIQty
            // 
            this.PIQty.DataPropertyName = "Quantity";
            dataGridViewCellStyle25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.PIQty.DefaultCellStyle = dataGridViewCellStyle25;
            this.PIQty.HeaderText = "Qty";
            this.PIQty.Name = "PIQty";
            this.PIQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PIQty.Width = 40;
            // 
            // PIRate
            // 
            this.PIRate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.PIRate.DataPropertyName = "Rate";
            dataGridViewCellStyle26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.PIRate.DefaultCellStyle = dataGridViewCellStyle26;
            this.PIRate.FillWeight = 140F;
            this.PIRate.HeaderText = "Rate";
            this.PIRate.Name = "PIRate";
            this.PIRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PIRate.Width = 140;
            // 
            // PIAmount
            // 
            this.PIAmount.DataPropertyName = "Amount";
            this.PIAmount.HeaderText = "Amount";
            this.PIAmount.Name = "PIAmount";
            this.PIAmount.ReadOnly = true;
            this.PIAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PIAmount.Width = 71;
            // 
            // PaymentCode
            // 
            this.PaymentCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.PaymentCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.PaymentCode.DropDownHeight = 90;
            this.PaymentCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PaymentCode.DropDownWidth = 70;
            this.PaymentCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PaymentCode.FormattingEnabled = true;
            this.PaymentCode.IntegralHeight = false;
            this.PaymentCode.Location = new System.Drawing.Point(1204, 29);
            this.PaymentCode.Name = "PaymentCode";
            this.PaymentCode.Size = new System.Drawing.Size(98, 26);
            this.PaymentCode.TabIndex = 193;
            this.PaymentCode.SelectedIndexChanged += new System.EventHandler(this.PaymentCode_SelectedIndexChanged);
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.label75.ForeColor = System.Drawing.Color.Black;
            this.label75.Location = new System.Drawing.Point(1073, 32);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(129, 23);
            this.label75.TabIndex = 193;
            this.label75.Text = "Payment Code:";
            // 
            // frmServicequote
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1303, 663);
            this.Controls.Add(this.label75);
            this.Controls.Add(this.PaymentCode);
            this.Controls.Add(this.chkQuoteSavePath);
            this.Controls.Add(this.cmbQuotetype);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblStartQuote);
            this.Controls.Add(this.cmbSelectQuoteType);
            this.Controls.Add(this.pnQuotationNumber);
            this.Controls.Add(this.dtpQuoteDate);
            this.Controls.Add(this.tabCalibration);
            this.Controls.Add(this.tabPI);
            this.Controls.Add(this.tabAMC);
            this.Controls.Add(this.tabRI);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmServicequote";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Service Quote";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmServicequote_FormClosing);
            this.Load += new System.EventHandler(this.frmServicequote_Load);
            this.pnQuotationNumber.ResumeLayout(false);
            this.pnQuotationNumber.PerformLayout();
            this.tabAMC.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNVLAP)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.pnCeast.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCeastContract)).EndInit();
            this.pnAMC.ResumeLayout(false);
            this.pnAMC.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContract)).EndInit();
            this.tabCalibration.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCALCalibrationDetails)).EndInit();
            this.tabRI.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRIQuoteDetails)).EndInit();
            this.tabPI.ResumeLayout(false);
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            this.tabPage9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPIDetails)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblStartQuote;
        private System.Windows.Forms.ComboBox cmbSelectQuoteType;
        private System.Windows.Forms.Panel pnQuotationNumber;
        private System.Windows.Forms.ComboBox cmbRevisionNumber;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.ComboBox cmbQuotationNumber;
        private System.Windows.Forms.TabControl tabAMC;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label lblQuoteBy;
        private System.Windows.Forms.Label lblQuotebyin;
        private System.Windows.Forms.TextBox txtCusCode;
        private System.Windows.Forms.TextBox txtEmailID;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.ComboBox txtQuoteName;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtZone;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ComboBox txtCusref;
        private System.Windows.Forms.TextBox txtTel;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtModelslno;
        private System.Windows.Forms.Button btnStartQuote;
        private System.Windows.Forms.DateTimePicker dtpEnquireDate;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtContactNumber;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtContactPerson;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbCustomer;
        private System.Windows.Forms.DateTimePicker dtpQuoteDate;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnGotoAddProducts;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnBack1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dtpContractto;
        private System.Windows.Forms.DateTimePicker dtpContractfrom;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox comboSVPPM;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox txtSVCV;
        private System.Windows.Forms.TextBox txtSVBV;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox comboPVPPM;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox txtPVCV;
        private System.Windows.Forms.TextBox txtPVBV;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button btnAddNewRow;
        private System.Windows.Forms.DataGridView dgvNVLAP;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtpaymentterms;
        private System.Windows.Forms.TextBox txtbreakdownvistcharges;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Button btnAddrow;
        private System.Windows.Forms.DataGridView dgvContract;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.ComboBox cmbQuoteCompany;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Button btnGenarateQuote;
        private System.Windows.Forms.Button btnFinQuote;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.ComboBox cmbQuotetype;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDiscount;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtContractValue;
        private System.Windows.Forms.CheckBox chk5Years;
        private System.Windows.Forms.CheckBox chk3Years;
        private System.Windows.Forms.TextBox txtGrandTotal;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContractValue1stYear;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContractValue2ndYear;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContractValue3rdYear;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContractValue4thYear;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContractValue5thYear;
        private System.Windows.Forms.DataGridViewTextBoxColumn Scope;
        private System.Windows.Forms.TabControl tabCalibration;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.ComboBox cmbCALQuoteFor;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label lblCALQuoteby;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox txtCALCusCode;
        private System.Windows.Forms.TextBox txtCALEmailID;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.ComboBox txtCalQuotename;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox txtCalZone;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.ComboBox txtCALCusRef;
        private System.Windows.Forms.TextBox txtCALTel;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox txtCALModelNo;
        private System.Windows.Forms.Button btnCalStartQuote;
        private System.Windows.Forms.DateTimePicker dtpCALDateofQuote;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox txtCALHandy;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox txtCALContactPerson;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox txtCALAddress;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.ComboBox cmbCALCustomer;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button btnCALAddItem;
        private System.Windows.Forms.DataGridView dgvCALCalibrationDetails;
        private System.Windows.Forms.TextBox txtCALGrandTotal;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.TextBox txtCALDiscount;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Button btnCALGenerateQuote;
        private System.Windows.Forms.Button btnCALPrintQuote;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.TextBox txtCALPaymentTerms;
        private System.Windows.Forms.TabControl tabRI;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TextBox TxtRIContactPerson;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtRIEmail;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox cmbRIQuotefor;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblRIQuoteBy;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtRICusCode;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox txtRIQuoteName;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtRIZone;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtRICOntractType;
        private System.Windows.Forms.DateTimePicker dtpRIQuoteDate;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtRIModelNumber;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txtRIAddress;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.ComboBox cmbRICustomer;
        private System.Windows.Forms.Button btnRIStart;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Button btnGenRIVQuote;
        private System.Windows.Forms.Button btnPrintRIQuote;
        private System.Windows.Forms.DataGridView dgvRIQuoteDetails;
        private System.Windows.Forms.Button btnRIAddNewItem;
        private System.Windows.Forms.TextBox txtRIVGrandTotal;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox txtRIVDiscount;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtRIPaymentTerms;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtRIAdditionalCharges;
        private System.Windows.Forms.TextBox txtRIContactNumber;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.DataGridViewTextBoxColumn RISlNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn RIScopeofwork;
        private System.Windows.Forms.DataGridViewTextBoxColumn RIPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn SLNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn NVLAPCalibrationscovered;
        private System.Windows.Forms.DataGridViewTextBoxColumn CALSlNO;
        private System.Windows.Forms.DataGridViewTextBoxColumn CALNVLAPCalibrationscovered;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
        private System.Windows.Forms.Button btnTab3back;
        private System.Windows.Forms.Button brnTab2back;
        private System.Windows.Forms.CheckBox chkQuoteSavePath;
        private System.Windows.Forms.ComboBox cmbEnquireCurrency;
        private System.Windows.Forms.Label lblcustomer;
        private System.Windows.Forms.ComboBox CmbCurrency;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.ComboBox cmbRICurrency;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.ComboBox cmbContractYears;
        private System.Windows.Forms.ComboBox cmbCeastAMC;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Panel pnAMC;
        private System.Windows.Forms.Panel pnCeast;
        private System.Windows.Forms.DataGridView dgvCeastContract;
        private System.Windows.Forms.Button btnCeastAdditem;
        private System.Windows.Forms.DataGridViewTextBoxColumn InstrumentDetails;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
        private System.Windows.Forms.TabControl tabPI;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.DateTimePicker dtpPIPurchaseorderdate;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.DateTimePicker dtpPIQuoterefdate;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.ComboBox cmbPICurrency;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.TextBox txtPICountry;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.TextBox txtPIQuoteRef;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.TextBox txtPIPurchaseOrder;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.ComboBox cmbPICompany;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label lblPIBY;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.TextBox txtPIGSTIN;
        private System.Windows.Forms.DateTimePicker dtpPIDate;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.TextBox txtPIAddress;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.ComboBox cmbPICustomer;
        private System.Windows.Forms.Button btnStartPI;
        private System.Windows.Forms.TextBox txtPICusCode;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.TextBox txtPIPaymentterms;
        private System.Windows.Forms.Button btnPIBack;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Button btnPIAddItem;
        private System.Windows.Forms.TextBox txtPIGrandTotal;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.TextBox txtPIGST;
        private System.Windows.Forms.Button btnGeneratePI;
        private System.Windows.Forms.Button btnPrintPI;
        private System.Windows.Forms.DataGridView dgvPIDetails;
        private System.Windows.Forms.DataGridViewTextBoxColumn PISlNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn PIDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn PIQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn PIRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn PIAmount;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.DateTimePicker dtpMutualyAgreedDate;
        private System.Windows.Forms.DateTimePicker dtpCalibrationDate;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.ComboBox PaymentCode;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.TextBox txtPImchineNo;
    }
}