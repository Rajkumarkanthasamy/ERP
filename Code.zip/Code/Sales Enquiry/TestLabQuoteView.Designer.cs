﻿namespace Erp_Project_With_Buttons.Sales_Enquiry
{
    partial class TestLabQuoteView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TestLabQuoteView));
            this.btnExcel = new System.Windows.Forms.Button();
            this.dgvTestQuoteReport = new System.Windows.Forms.DataGridView();
            this.QuotationNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EnquiryMonth = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.QuotationSubmitedMonth = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NewOldCustomer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Customer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ContactPerson = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PhoneNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Department = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ECustomer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TypeofIndustry = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ApplicationTestType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaterialType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OfferName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.QuoteStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BookingEstimation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Booked = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ContractValue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PONumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Comment = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CreatedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UpdatedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.dtptodate = new System.Windows.Forms.DateTimePicker();
            this.dtpfromdate = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTestQuoteReport)).BeginInit();
            this.SuspendLayout();
            // 
            // btnExcel
            // 
            this.btnExcel.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcel.Location = new System.Drawing.Point(1160, 5);
            this.btnExcel.Name = "btnExcel";
            this.btnExcel.Size = new System.Drawing.Size(100, 35);
            this.btnExcel.TabIndex = 190;
            this.btnExcel.Text = "Excel";
            this.btnExcel.UseVisualStyleBackColor = true;
            this.btnExcel.Click += new System.EventHandler(this.btnExcel_Click);
            // 
            // dgvTestQuoteReport
            // 
            this.dgvTestQuoteReport.AllowUserToAddRows = false;
            this.dgvTestQuoteReport.AllowUserToDeleteRows = false;
            this.dgvTestQuoteReport.AllowUserToOrderColumns = true;
            this.dgvTestQuoteReport.AllowUserToResizeRows = false;
            this.dgvTestQuoteReport.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTestQuoteReport.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvTestQuoteReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTestQuoteReport.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.QuotationNumber,
            this.EnquiryMonth,
            this.QuotationSubmitedMonth,
            this.Date,
            this.NewOldCustomer,
            this.Customer,
            this.ContactPerson,
            this.PhoneNumber,
            this.Column1,
            this.Department,
            this.ECustomer,
            this.TypeofIndustry,
            this.ApplicationTestType,
            this.MaterialType,
            this.OfferName,
            this.QuoteStatus,
            this.BookingEstimation,
            this.Booked,
            this.ContractValue,
            this.PONumber,
            this.Comment,
            this.CreatedBy,
            this.UpdatedBy});
            this.dgvTestQuoteReport.Location = new System.Drawing.Point(5, 53);
            this.dgvTestQuoteReport.Name = "dgvTestQuoteReport";
            this.dgvTestQuoteReport.ReadOnly = true;
            this.dgvTestQuoteReport.RowHeadersVisible = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvTestQuoteReport.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvTestQuoteReport.Size = new System.Drawing.Size(1279, 618);
            this.dgvTestQuoteReport.TabIndex = 189;
            // 
            // QuotationNumber
            // 
            this.QuotationNumber.DataPropertyName = "QuotationNumber";
            this.QuotationNumber.HeaderText = "Quotation Number";
            this.QuotationNumber.Name = "QuotationNumber";
            this.QuotationNumber.ReadOnly = true;
            this.QuotationNumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.QuotationNumber.Width = 102;
            // 
            // EnquiryMonth
            // 
            this.EnquiryMonth.DataPropertyName = "EnquiryMonth";
            this.EnquiryMonth.HeaderText = "Enquiry Month";
            this.EnquiryMonth.Name = "EnquiryMonth";
            this.EnquiryMonth.ReadOnly = true;
            this.EnquiryMonth.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.EnquiryMonth.Width = 82;
            // 
            // QuotationSubmitedMonth
            // 
            this.QuotationSubmitedMonth.DataPropertyName = "QuotationSubmitedMonth";
            this.QuotationSubmitedMonth.HeaderText = "Quotation Submited Month";
            this.QuotationSubmitedMonth.Name = "QuotationSubmitedMonth";
            this.QuotationSubmitedMonth.ReadOnly = true;
            this.QuotationSubmitedMonth.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.QuotationSubmitedMonth.Width = 113;
            // 
            // Date
            // 
            this.Date.DataPropertyName = "Date";
            this.Date.HeaderText = "Date";
            this.Date.Name = "Date";
            this.Date.ReadOnly = true;
            this.Date.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Date.Width = 39;
            // 
            // NewOldCustomer
            // 
            this.NewOldCustomer.DataPropertyName = "NewOldCustomer";
            this.NewOldCustomer.HeaderText = "NewOldCustomer";
            this.NewOldCustomer.Name = "NewOldCustomer";
            this.NewOldCustomer.ReadOnly = true;
            this.NewOldCustomer.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.NewOldCustomer.Width = 107;
            // 
            // Customer
            // 
            this.Customer.DataPropertyName = "Customer";
            this.Customer.HeaderText = "Customer";
            this.Customer.Name = "Customer";
            this.Customer.ReadOnly = true;
            this.Customer.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Customer.Width = 64;
            // 
            // ContactPerson
            // 
            this.ContactPerson.DataPropertyName = "ContactPerson";
            this.ContactPerson.HeaderText = "ContactPerson";
            this.ContactPerson.Name = "ContactPerson";
            this.ContactPerson.ReadOnly = true;
            this.ContactPerson.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ContactPerson.Width = 90;
            // 
            // PhoneNumber
            // 
            this.PhoneNumber.DataPropertyName = "PhoneNumber";
            this.PhoneNumber.HeaderText = "PhoneNumber";
            this.PhoneNumber.Name = "PhoneNumber";
            this.PhoneNumber.ReadOnly = true;
            this.PhoneNumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PhoneNumber.Width = 90;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "EmailId";
            this.Column1.HeaderText = "EmailId";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column1.Width = 55;
            // 
            // Department
            // 
            this.Department.DataPropertyName = "Department";
            this.Department.HeaderText = "Department";
            this.Department.Name = "Department";
            this.Department.ReadOnly = true;
            this.Department.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Department.Width = 78;
            // 
            // ECustomer
            // 
            this.ECustomer.DataPropertyName = "8020Customer";
            this.ECustomer.HeaderText = "8020Customer";
            this.ECustomer.Name = "ECustomer";
            this.ECustomer.ReadOnly = true;
            this.ECustomer.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ECustomer.Width = 88;
            // 
            // TypeofIndustry
            // 
            this.TypeofIndustry.DataPropertyName = "TypeofIndustry";
            this.TypeofIndustry.HeaderText = "Industry Type";
            this.TypeofIndustry.Name = "TypeofIndustry";
            this.TypeofIndustry.ReadOnly = true;
            this.TypeofIndustry.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.TypeofIndustry.Width = 76;
            // 
            // ApplicationTestType
            // 
            this.ApplicationTestType.DataPropertyName = "ApplicationTestType";
            this.ApplicationTestType.HeaderText = "ApplicationTestType";
            this.ApplicationTestType.Name = "ApplicationTestType";
            this.ApplicationTestType.ReadOnly = true;
            this.ApplicationTestType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ApplicationTestType.Width = 121;
            // 
            // MaterialType
            // 
            this.MaterialType.DataPropertyName = "MaterialType";
            this.MaterialType.HeaderText = "MaterialType";
            this.MaterialType.Name = "MaterialType";
            this.MaterialType.ReadOnly = true;
            this.MaterialType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.MaterialType.Width = 84;
            // 
            // OfferName
            // 
            this.OfferName.DataPropertyName = "OfferName";
            this.OfferName.HeaderText = "OfferName";
            this.OfferName.Name = "OfferName";
            this.OfferName.ReadOnly = true;
            this.OfferName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OfferName.Width = 71;
            // 
            // QuoteStatus
            // 
            this.QuoteStatus.DataPropertyName = "QuoteStatus";
            this.QuoteStatus.HeaderText = "QuoteStatus";
            this.QuoteStatus.Name = "QuoteStatus";
            this.QuoteStatus.ReadOnly = true;
            this.QuoteStatus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.QuoteStatus.Width = 80;
            // 
            // BookingEstimation
            // 
            this.BookingEstimation.DataPropertyName = "BookingEstimation";
            this.BookingEstimation.HeaderText = "BookingEstimation";
            this.BookingEstimation.Name = "BookingEstimation";
            this.BookingEstimation.ReadOnly = true;
            this.BookingEstimation.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.BookingEstimation.Width = 114;
            // 
            // Booked
            // 
            this.Booked.DataPropertyName = "Booked";
            this.Booked.HeaderText = "Booked";
            this.Booked.Name = "Booked";
            this.Booked.ReadOnly = true;
            this.Booked.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Booked.Width = 54;
            // 
            // ContractValue
            // 
            this.ContractValue.DataPropertyName = "ContractValue";
            this.ContractValue.HeaderText = "ContractValue";
            this.ContractValue.Name = "ContractValue";
            this.ContractValue.ReadOnly = true;
            this.ContractValue.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ContractValue.Width = 88;
            // 
            // PONumber
            // 
            this.PONumber.DataPropertyName = "PONumber";
            this.PONumber.HeaderText = "PONumber";
            this.PONumber.Name = "PONumber";
            this.PONumber.ReadOnly = true;
            this.PONumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PONumber.Width = 70;
            // 
            // Comment
            // 
            this.Comment.DataPropertyName = "Comment";
            this.Comment.HeaderText = "Comment";
            this.Comment.Name = "Comment";
            this.Comment.ReadOnly = true;
            this.Comment.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Comment.Width = 64;
            // 
            // CreatedBy
            // 
            this.CreatedBy.DataPropertyName = "CreatedBy";
            this.CreatedBy.HeaderText = "CreatedBy";
            this.CreatedBy.Name = "CreatedBy";
            this.CreatedBy.ReadOnly = true;
            this.CreatedBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CreatedBy.Width = 67;
            // 
            // UpdatedBy
            // 
            this.UpdatedBy.DataPropertyName = "UpdatedBy";
            this.UpdatedBy.HeaderText = "UpdatedBy";
            this.UpdatedBy.Name = "UpdatedBy";
            this.UpdatedBy.ReadOnly = true;
            this.UpdatedBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UpdatedBy.Width = 72;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(895, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 15);
            this.label1.TabIndex = 188;
            this.label1.Text = "To :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(752, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 15);
            this.label2.TabIndex = 187;
            this.label2.Text = "From :";
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(1044, 5);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(95, 35);
            this.btnSearch.TabIndex = 186;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // dtptodate
            // 
            this.dtptodate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtptodate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtptodate.Location = new System.Drawing.Point(923, 9);
            this.dtptodate.Name = "dtptodate";
            this.dtptodate.Size = new System.Drawing.Size(88, 26);
            this.dtptodate.TabIndex = 185;
            // 
            // dtpfromdate
            // 
            this.dtpfromdate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpfromdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpfromdate.Location = new System.Drawing.Point(797, 9);
            this.dtpfromdate.Name = "dtpfromdate";
            this.dtpfromdate.Size = new System.Drawing.Size(89, 26);
            this.dtpfromdate.TabIndex = 184;
            // 
            // TestLabQuoteView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1290, 676);
            this.Controls.Add(this.btnExcel);
            this.Controls.Add(this.dgvTestQuoteReport);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.dtptodate);
            this.Controls.Add(this.dtpfromdate);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "TestLabQuoteView";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Test Lab Quote View";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TestLabQuoteView_FormClosing);
            this.Load += new System.EventHandler(this.TestLabQuoteView_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTestQuoteReport)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExcel;
        private System.Windows.Forms.DataGridView dgvTestQuoteReport;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.DateTimePicker dtptodate;
        private System.Windows.Forms.DateTimePicker dtpfromdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn QuotationNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn EnquiryMonth;
        private System.Windows.Forms.DataGridViewTextBoxColumn QuotationSubmitedMonth;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date;
        private System.Windows.Forms.DataGridViewTextBoxColumn NewOldCustomer;
        private System.Windows.Forms.DataGridViewTextBoxColumn Customer;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContactPerson;
        private System.Windows.Forms.DataGridViewTextBoxColumn PhoneNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Department;
        private System.Windows.Forms.DataGridViewTextBoxColumn ECustomer;
        private System.Windows.Forms.DataGridViewTextBoxColumn TypeofIndustry;
        private System.Windows.Forms.DataGridViewTextBoxColumn ApplicationTestType;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaterialType;
        private System.Windows.Forms.DataGridViewTextBoxColumn OfferName;
        private System.Windows.Forms.DataGridViewTextBoxColumn QuoteStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn BookingEstimation;
        private System.Windows.Forms.DataGridViewTextBoxColumn Booked;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContractValue;
        private System.Windows.Forms.DataGridViewTextBoxColumn PONumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn Comment;
        private System.Windows.Forms.DataGridViewTextBoxColumn CreatedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn UpdatedBy;
    }
}