﻿using System.Windows.Forms;

namespace Erp_Project_With_Buttons
{
    public partial class pleasewaitform : Form
    {
        Global GlobalClass = new Global();
        public pleasewaitform()
        {
            InitializeComponent();

        }

     
      

    }
}
