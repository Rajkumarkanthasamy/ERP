﻿using Erp_Project_With_Buttons.Part_Reciept;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using Outlook = Microsoft.Office.Interop.Outlook;


namespace Erp_Project_With_Buttons
{

    public partial class frmForm2 : Form
    {
        #region Intialization of Local Datatables, Variables Daclaration
        Login.frmLoginForm Loginfrm = new Login.frmLoginForm();
        DataAccessLayer DAL = new DataAccessLayer();
        Global GlobalClass = new Global();
        Login.frmLoginForm login = new Login.frmLoginForm();
        public frmForm2()
        {
            InitializeComponent();
        }
        #endregion

        #region Code for Form Closing
        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {

            GlobalClass.sMessageResult = GlobalClass.fnMessageResultquit();
            if (GlobalClass.sMessageResult == "Yes")
            {
                GlobalClass.iSuccess = DAL.ERPActiveLoggin(1, lblReturnedby.Text, false, 0);
                Application.ExitThread();
            }
            else
            {
                e.Cancel = true;
            }
        }
        #endregion

        DataTable dtPOCheck = new DataTable();
        DataTable dtProjectCheck = new DataTable();
        DataTable dtWOCheck = new DataTable();
        DataTable dtCustomerApproval = new DataTable();
        DataTable dtDetails = new DataTable();


        public static bool bPOAlert = false;
        public static bool bWOAlert = false;
        DataTable dtWOUserlist = new DataTable();
        DataTable dtPOUserlist = new DataTable();
        #region Code to Home Form Load & Show Only Allowed Panels

        //public void Loadform(object Form)
        //{
        //    if (this.mainPanel.Controls.Count > 0)
        //    {
        //        DialogResult DR = MessageBox.Show("Do you want exit from the current form", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
        //        if (DR == DialogResult.Yes)
        //        {
        //            this.mainPanel.Controls.RemoveAt(0);
        //            Form f = Form as Form;
        //            f.TopLevel = false;
        //            f.Dock = DockStyle.Fill;
        //            this.mainPanel.Controls.Add(f);
        //            this.mainPanel.Tag = f;
        //            f.Show();
        //        }
        //    }
        //    else
        //    {
        //        Form f = Form as Form;
        //        f.TopLevel = false;
        //        f.Dock = DockStyle.Fill;
        //        this.mainPanel.Controls.Add(f);
        //        this.mainPanel.Tag = f;
        //        f.Show();
        //    }
        //}

        DataTable dtAllProjects = new DataTable();
        DataTable dtAllProjectsCount = new DataTable();
        DataTable dtPolist = new DataTable();
        DataTable dtDeptPolist = new DataTable();
        private void POLateCount()
        {
            int POsLateby6Months = 0, POsLateby3Months = 0, POLateby1months = 0;
            foreach (DataRow row in dtPolist.Rows)
            {
                if (Convert.ToDouble(row[1].ToString()) >= 0 && Convert.ToDouble(row[1].ToString()) <= 31)
                {
                    POLateby1months++;
                }
                else if (Convert.ToDouble(row[1].ToString()) > 31 && Convert.ToDouble(row[1].ToString()) <= 180)
                {
                    POsLateby3Months++;
                }
                else if (Convert.ToDouble(row[1].ToString()) > 180)
                {
                    POsLateby6Months++;
                }
            }

            lbl1MonthLatePOs.Text = POLateby1months.ToString() + " Items from 1 Month";
            lbl3MonthLatePOs.Text = POsLateby3Months.ToString() + " Items from 1 to 3 Months";
            lbl6MonthLatePOs.Text = POsLateby6Months.ToString() + " Items from more than 6 Months";
        }
        //var Today = DateTime.Today;
        private void Form2_Load(object sender, EventArgs e)
        {
            var Today = DateTime.Today;
            var Today1 = DateTime.Now.AddDays(-31);
            var Today22 = DateTime.Now.AddDays(-90);
            // Login.frmLoginForm Loginfrm = new Login.frmLoginForm();
            lblReturnedby.Text = Loginfrm.GetUserDetails[2];

            dtPolist = DAL.fnPOlistforview(3, null, null).Tables[0];
            dtDeptPolist = DAL.fnPOlistforview(4, null, null).Tables[0];
            POLateCount();
            lblLatePos.Text = dtPolist.Rows.Count.ToString();

            dtAllProjects = DAL.fnWIPProjectListCount(0, Today.ToString("yyyy-MM-dd"), Today1.ToString("yyyy-MM-dd")).Tables[0];
            lblProjectCount.Text = dtAllProjects.Rows.Count.ToString();

            dtAllProjects = DAL.fnWIPProjectListCount(1, Today1.ToString("yyyy-MM-dd"), Today.ToString("yyyy-MM-dd")).Tables[0];
            lblLatestWIPCount.Text = dtAllProjects.Rows.Count.ToString() + " New WIP Projects from 1 Month";

            dtAllProjectsCount = DAL.fnWIPProjectListCount(2, Today1.ToString("yyyy-MM-dd"), Today.ToString("yyyy-MM-dd")).Tables[0];
            var sbViewCount = new StringBuilder();
            for (int i = 0; i < dtAllProjectsCount.Rows.Count; i++)
            {
                sbViewCount.Append(dtAllProjectsCount.Rows[i][0].ToString() + " - " + dtAllProjectsCount.Rows[i][1].ToString() + " \n");
            }
            toolTip2.SetToolTip(lblProjectCount, sbViewCount.ToString());
            toolTip2.SetToolTip(label3, sbViewCount.ToString());

            dtAllProjectsCount = DAL.fnWIPProjectListCount(3, Today1.ToString("yyyy-MM-dd"), Today.ToString("yyyy-MM-dd")).Tables[0];
            var sbViewCount1 = new StringBuilder();
            for (int i = 0; i < dtAllProjectsCount.Rows.Count; i++)
            {
                sbViewCount1.Append(dtAllProjectsCount.Rows[i][0].ToString() + " - " + dtAllProjectsCount.Rows[i][1].ToString() + " \n");
            }
            toolTip2.SetToolTip(lblLatestWIPCount, sbViewCount1.ToString());


            dtAllProjectsCount = DAL.fnWIPProjectListCount(4, Today1.ToString("yyyy-MM-dd"), Today.ToString("yyyy-MM-dd")).Tables[0];
            lblShippedCount.Text = dtAllProjectsCount.Rows.Count.ToString() + " Shipped Projects from 1 Month";


            dtAllProjectsCount = DAL.fnWIPProjectListCount(5, Today22.ToString("yyyy-MM-dd"), Today.ToString("yyyy-MM-dd")).Tables[0];
            lblInstallationCompleted.Text = dtAllProjectsCount.Rows.Count.ToString() + " Installation Completed Projects from 3 Months";




            var sbViewCount2 = new StringBuilder();
            for (int i = 0; i < dtDeptPolist.Rows.Count; i++)
            {
                sbViewCount2.Append(dtDeptPolist.Rows[i][0].ToString() + " - " + dtDeptPolist.Rows[i][1].ToString() + " \n");
            }

            toolTip2.SetToolTip(lblLatePos, sbViewCount2.ToString());

            #region Customer Master Login

            if (Loginfrm.GetUserDetails[18] != "True")
            {
                customerMasterToolStripMenuItem.Enabled = false;
            }
            else
            {
                customerMasterToolStripMenuItem.Enabled = true;
            }
            #endregion
            #region machine Passport

            if (Loginfrm.GetUserDetails[84] != "True")
            {
                machinePassportToolStripMenuItem.Enabled = false;
            }
            else
            {
                machinePassportToolStripMenuItem.Enabled = true;
            }
            #endregion

            #region project closure

            if (Loginfrm.GetUserDetails[86] != "True")
            {
                packingListToolStripMenuItem.Enabled = false;
            }
            else
            {
                packingListToolStripMenuItem.Enabled = true;
            }
            #endregion

            #region Inventory Management GIN Items
            if (Loginfrm.GetUserDetails[6] != "True")
            {
                gINToolStripMenuItem.Enabled = false;
                reverseGINToolStripMenuItem.Enabled = false;
                pOWOInspectToolStripMenuItem.Enabled = false;
                updateLedgerToolStripMenuItem.Enabled = false;
                itemReturnToolStripMenuItem.Enabled = false;
                toolStripMenuItemSIN.Enabled = false;
            }
            else
            {
                gINToolStripMenuItem.Enabled = true;
                reverseGINToolStripMenuItem.Enabled = true;
                pOWOInspectToolStripMenuItem.Enabled = true;
                updateLedgerToolStripMenuItem.Enabled = true;
                itemReturnToolStripMenuItem.Enabled = true;
                toolStripMenuItemSIN.Enabled = true;
            }
            #endregion

            #region Item Issue
            if (Loginfrm.GetUserDetails[7] != "True")
            {
                itemIssueToolStripMenuItem1.Enabled = false;
            }
            else
            {
                itemIssueToolStripMenuItem1.Enabled = true;
            }
            #endregion

            #region Fixed Asset Master
            if (Login.frmLoginForm.sUserDetails[76] != "True")
            {
                fixedAssetMasterToolStripMenuItem.Enabled = false;
            }
            else
            {
                fixedAssetMasterToolStripMenuItem.Enabled = true;
            }
            #endregion

            #region WAR Report
            if (Login.frmLoginForm.sUserDetails[87] != "True")
            {
                wARCalculationToolStripMenuItem1.Enabled = false;
            }
            else
            {
                wARCalculationToolStripMenuItem1.Enabled = true;
            }
            #endregion

            #region Procurement 
            if (Loginfrm.GetUserDetails[11] != "True")
            {
                newPurchaseOrderToolStripMenuItem.Enabled = false;
            }
            else
            {
                newPurchaseOrderToolStripMenuItem.Enabled = true;

                if (Convert.ToBoolean(Loginfrm.GetUserDetails[16]) == true || Convert.ToBoolean(Loginfrm.GetUserDetails[30]) == true || Convert.ToBoolean(Loginfrm.GetUserDetails[31]) == true
                    || Convert.ToBoolean(Loginfrm.GetUserDetails[32]) == true || Convert.ToBoolean(Loginfrm.GetUserDetails[82]) == true || Convert.ToBoolean(Loginfrm.GetUserDetails[29]) == true || Loginfrm.GetUserDetails[2].ToLower() == "Lizzy" || Loginfrm.GetUserDetails[2].ToLower() == "vivek g")//shreeshail is added or condition lizzy

                {
                    dtDetails.Clear();
                    Today = DateTime.Today;
                    dtPOUserlist = DAL.fnDashBoardFilter(9, Loginfrm.GetUserDetails[2], Today.ToString("yyyy-MM-dd")).Tables[0];
                    if (Convert.ToBoolean(Loginfrm.GetUserDetails[31]) == true)
                    {
                        foreach (DataRow DT in dtPOUserlist.Rows)
                        {
                            dtPOCheck = DAL.fnDashBoardFilter(1, DT["POUserName"].ToString(), Today.ToString("yyyy-MM-dd")).Tables[0];
                            if (dtPOCheck.Rows.Count > 0)
                            {
                                dtDetails.Merge(dtPOCheck);
                            }
                        }

                        dgvDashBoard.AutoGenerateColumns = true;
                        dgvDashBoard.DataSource = dtDetails;
                        /*
                        foreach (DataRow DT in dtPOUserlist.Rows)
                        {
                            dtPOCheck = DAL.fnDashBoardFilter(6, DT["POUserName"].ToString(), Today.ToString("yyyy-MM-dd")).Tables[0];
                            if (dtPOCheck.Rows.Count > 0)
                            {
                                dtDetails.Merge(dtPOCheck);
                            }
                        }
                        dgvDashBoard.AutoGenerateColumns = true;
                        dgvDashBoard.DataSource = dtDetails;
                        */
                    }
                    else if (Convert.ToBoolean(Loginfrm.GetUserDetails[32]) == true)
                    {
                        
                        foreach (DataRow DT in dtPOUserlist.Rows)
                        {
                            dtPOCheck = DAL.fnDashBoardFilter(5, DT["POUserName"].ToString(), Today.ToString("yyyy-MM-dd")).Tables[0];
                            if (dtPOCheck.Rows.Count > 0)
                            {
                                dtDetails.Merge(dtPOCheck);
                            }
                        }
                        dgvDashBoard.AutoGenerateColumns = true;
                        dgvDashBoard.DataSource = dtDetails;
                    }
                    else if (Convert.ToBoolean(Loginfrm.GetUserDetails[29]) == true)
                    {
                        
                        foreach (DataRow DT in dtPOUserlist.Rows)
                        {
                            dtPOCheck = DAL.fnDashBoardFilter(6, DT["POUserName"].ToString(), Today.ToString("yyyy-MM-dd")).Tables[0];
                            if (dtPOCheck.Rows.Count > 0)
                            {
                                dtDetails.Merge(dtPOCheck);
                            }
                        }
                        dgvDashBoard.AutoGenerateColumns = true;
                        dgvDashBoard.DataSource = dtDetails;
                    }
                    else if (Convert.ToBoolean(Loginfrm.GetUserDetails[30]) == true)
                    {
                        //GM
                        //GM ApprovalForm
                        dtDetails = DAL.fnDashBoardFilter(333, "", Today.ToString("yyyy-MM-dd")).Tables[0];
                        
                        if (dtPOCheck.Rows.Count > 0)
                        {
                            dtDetails.Merge(dtPOCheck);

                        }
                        dgvDashBoard.AutoGenerateColumns = true;
                        dgvDashBoard.DataSource = dtDetails;
                        
                        

                        DataGridViewTextBoxColumn txtColumn = new DataGridViewTextBoxColumn();
                        txtColumn.Name = "txtremarks";
                        txtColumn.HeaderText = "Remarks";
                        txtColumn.DataPropertyName = "txtremarks";  // Bind to your data source property
                        txtColumn.Width = 100;
                        txtColumn.ReadOnly = false;

                        // Add to DataGridView
                        dgvDashBoard.Columns.Add(txtColumn);

                        DataGridViewCheckBoxColumn chk = new DataGridViewCheckBoxColumn();
                        chk.Name = "chkSelect";
                        chk.HeaderText = "Select";
                        chk.Width = 60;
                        chk.TrueValue = true;
                        chk.FalseValue = false;

                        dgvDashBoard.Columns.Add(chk);

                        //rk new added the code 
                        //DataTable TotalAmount = DAL.POALLdetails(3, dtDetails.Rows).Tables[0];
                        DataGridViewButtonColumn btnReject = new DataGridViewButtonColumn();
                        btnReject.Name = "btnReject";
                        btnReject.HeaderText = "Reject";
                        btnReject.Text = "Reject";
                        btnReject.UseColumnTextForButtonValue = true;
                        btnReject.FlatStyle = FlatStyle.Flat;
                        btnReject.DefaultCellStyle.BackColor = Color.FromArgb(244, 67, 54);
                        btnReject.DefaultCellStyle.ForeColor = Color.White;




                        dgvDashBoard.Columns.Add(btnReject);

                        DataGridViewButtonColumn btn = new DataGridViewButtonColumn();
                        btn.Name = "btnAction";
                        btn.HeaderText = "Approve";
                        btn.Text = "Approve";
                        btn.UseColumnTextForButtonValue = true;
                        btn.FlatStyle = FlatStyle.Flat;
                        btn.DefaultCellStyle.BackColor = Color.FromArgb(244, 67, 54);
                        btn.DefaultCellStyle.ForeColor = Color.White;

                        dgvDashBoard.Columns.Add(btn);



                        // btnApproval = CreateActionButton("Approve", Color.FromArgb(76, 175, 80));
                        // btnReject = CreateActionButton("Reject", Color.FromArgb(244, 67, 54));
                        // btnClose = CreateActionButton("Close", Color.Gray);
                        dgvDashBoard.ReadOnly = false;
                       

                    }

                    else if (Convert.ToBoolean(Loginfrm.GetUserDetails[85]) == true && Loginfrm.GetUserDetails[2].ToString() == "Vivek G")
                    {
                        //MessageBox.Show("Vivek G");


                        foreach (DataRow DT in dtPOUserlist.Rows)
                        {
                            dtPOCheck = DAL.fnDashBoardFilter(322, DT["POUserName"].ToString(), Today1.ToString("yyyy-MM-dd")).Tables[0];
                            if (dtPOCheck.Rows.Count > 0)
                            {
                                dtDetails.Merge(dtPOCheck);
                            }
                        }

                        dtProjectCheck = DAL.fnDashBoardFilter(3222, "POUserName", Today1.ToString("yyyy-MM-dd")).Tables[0];

                        dtDetails.Merge(dtProjectCheck);
                        dgvDashBoard.AutoGenerateColumns = true;
                        dgvDashBoard.DataSource = dtDetails;
                    }

                    else if (Convert.ToBoolean(Loginfrm.GetUserDetails[85]) == true)
                    {
                        //MessageBox.Show("Vivek G");


                        foreach (DataRow DT in dtPOUserlist.Rows)
                        {
                            dtPOCheck = DAL.fnDashBoardFilter(32, DT["POUserName"].ToString(), Today.ToString("dd-MM-yyyy")).Tables[0];
                            if (dtPOCheck.Rows.Count > 0)
                            {
                                dtDetails.Merge(dtPOCheck);
                            }
                        }
                        dgvDashBoard.AutoGenerateColumns = true;
                        dgvDashBoard.DataSource = dtDetails;
                    }

                    else if (Convert.ToBoolean(Loginfrm.GetUserDetails[82]) == true)
                    {
                        foreach (DataRow DT in dtPOUserlist.Rows)
                        {
                            dtPOCheck = DAL.fnDashBoardFilter(5, DT["POUserName"].ToString(), Today.ToString("yyyy-MM-dd")).Tables[0];
                            if (dtPOCheck.Rows.Count > 0)
                            {
                                dtDetails.Merge(dtPOCheck);
                            }
                        }
                        dgvDashBoard.AutoGenerateColumns = true;
                        dgvDashBoard.DataSource = dtDetails;
                    }

                    else if (Convert.ToBoolean(Loginfrm.GetUserDetails[16]) == true && (Convert.ToBoolean(Loginfrm.GetUserDetails[30]) != true) && (Convert.ToBoolean(Loginfrm.GetUserDetails[80]) != true))
                    {
                        dtDetails = DAL.fnDashBoardFilter(4, "", Today.ToString("yyyy-MM-dd")).Tables[0];
                        dgvDashBoard.AutoGenerateColumns = true;
                        dgvDashBoard.DataSource = dtDetails;

                    }
                    else if (Loginfrm.GetUserDetails[2].ToLower() == "Lizzy" && (Convert.ToBoolean(Loginfrm.GetUserDetails[30]) != true) && (Convert.ToBoolean(Loginfrm.GetUserDetails[80]) != true))
                    {
                        dtDetails = DAL.fnDashBoardFilter(4, "", Today.ToString("yyyy-MM-dd")).Tables[0];
                        dgvDashBoard.AutoGenerateColumns = true;
                        dgvDashBoard.DataSource = dtDetails;

                    }

                    if (dgvDashBoard.Rows.Count > 0)
                    {
                        dgvDashBoard.ColumnHeadersDefaultCellStyle.Font = new Font("Calibri", 12F, FontStyle.Bold);
                        Datagridviewcolor();
                    }

                    if (Loginfrm.GetUserDetails[2].ToString() == "Vivek G")
                    {
                        dgvDashBoard.AutoGenerateColumns = true;
                        dgvDashBoard.DataSource = dtDetails;
                        dgvDashBoard.ColumnHeadersDefaultCellStyle.Font = new Font("Calibri", 12F, FontStyle.Bold);

                        dgvDashBoard.Sort(dgvDashBoard.Columns["Type"], System.ComponentModel.ListSortDirection.Ascending);

                        if (dgvDashBoard.Rows.Count > 0)
                        {
                            Datagridviewcolor();
                        }

                       // foreach (DataGridViewColumn column in dgvDashBoard.Columns)
                        //{
                            //column.SortMode = DataGridViewColumnSortMode.NotSortable;
                        //}
                        
                        tspProjectCLose.Enabled = true;
                    }
                    else
                    {

                    

                    foreach (DataGridViewColumn column in dgvDashBoard.Columns)
                    {
                        column.SortMode = DataGridViewColumnSortMode.NotSortable;
                    }
                        if (Convert.ToBoolean(Loginfrm.GetUserDetails[30]) == true)
                        {
                            foreach (DataGridViewRow row in dgvDashBoard.Rows)
                            {
                                // Skip new row (if AllowUserToAddRows is true)
                                if (row.IsNewRow) continue;

                                string docType = row.Cells[0].Value?.ToString() ?? "";

                                // Check if it's Purchase Order
                                bool isPurchaseOrder = (docType == "Purchase Order");

                                // Get button cells
                                DataGridViewCell btnApprove = row.Cells["btnAction"];
                                DataGridViewCell btnReject = row.Cells["btnReject"];

                                if (isPurchaseOrder)
                                {
                                    // ENABLE - Normal colors for Purchase Order
                                    btnApprove.Style.BackColor = Color.FromArgb(76, 175, 80);  // Green
                                    btnApprove.Style.ForeColor = Color.White;

                                    btnReject.Style.BackColor = Color.FromArgb(244, 67, 54);   // Red
                                    btnReject.Style.ForeColor = Color.White;

                                    row.Tag = "ENABLED";
                                }
                                else
                                {
                                    // DISABLE - Gray out for all other document types
                                    btnApprove.Style.BackColor = Color.Gray;
                                    btnApprove.Style.ForeColor = Color.DarkGray;
                                    btnApprove.Value = "—";  // Optional: change text to dash

                                    btnReject.Style.BackColor = Color.Gray;
                                    btnReject.Style.ForeColor = Color.DarkGray;
                                    btnReject.Value = "—";

                                    row.Tag = "DISABLED";
                                }
                            }
                        }




                    }

                }
            }

            if (Loginfrm.GetUserDetails[12] != "True")
            {
                newApproveWorkOrderToolStripMenuItem.Enabled = false;
            }
            else
            {
                newApproveWorkOrderToolStripMenuItem.Enabled = true;
            }

            #endregion





            #region Time Sheet
            if (Loginfrm.GetUserDetails[72] != "True")
            {
                addTimeSheetToolStripMenuItem.Enabled = false;
            }
            else
            {
                addTimeSheetToolStripMenuItem.Enabled = true;
            }
            if (Loginfrm.GetUserDetails[73] != "True")
            {
                timeSheetReportToolStripMenuItem.Enabled = false;
            }
            else
            {
                timeSheetReportToolStripMenuItem.Enabled = true;
            }

            if (Loginfrm.GetUserDetails[75] != "True")
            {
                machineUtilizationToolStripMenuItem.Enabled = false;
            }
            else
            {
                machineUtilizationToolStripMenuItem.Enabled = true;
            }
            #endregion

            #region Reports

            if (Loginfrm.GetUserDetails[9] != "True")
            {
                allERPReportsToolStripMenuItem.Enabled = false;
            }
            else
            {
                allERPReportsToolStripMenuItem.Enabled = true;
            }
            #endregion

            #region Security Details
            if (Loginfrm.GetUserDetails[59] != "True")
            {
                securityInwardItemsToolStripMenuItem.Enabled = false;
                outwardItemsToolStripMenuItem.Enabled = false;
                manualInwardToolStripMenuItem.Enabled = false;
                reportsToolStripMenuItem3.Enabled = false;
            }
            else
            {
                securityInwardItemsToolStripMenuItem.Enabled = true;
                outwardItemsToolStripMenuItem.Enabled = true;
                manualInwardToolStripMenuItem.Enabled = true;
                reportsToolStripMenuItem3.Enabled = true;
            }
            #endregion

            #region Item Master
            if (Loginfrm.GetUserDetails[5] != "True")
            {
                addItemToolStripMenuItem.Enabled = false;
            }
            else
            {
                addItemToolStripMenuItem.Enabled = true;
            }
            if (Loginfrm.GetUserDetails[77] != "True")
            {
                standardCostUpdateToolStripMenuItem.Enabled = false;
            }
            else
            {
                standardCostUpdateToolStripMenuItem.Enabled = true;
            }
            if (Loginfrm.GetUserDetails[77] == "True" && Loginfrm.GetUserDetails[2].ToLower() == "hebbarrk")
            {
                targetCostToolStripMenuItem.Enabled = true;
            }
            else
            {
                targetCostToolStripMenuItem.Enabled = false;
            }
            if (Loginfrm.GetUserDetails[22] != "True")
            {
                itemLedgerToolStripMenuItem.Enabled = false;
            }
            else
            {
                itemLedgerToolStripMenuItem.Enabled = true;
            }

            if (Loginfrm.GetUserDetails[17] != "True")
            {
                productMasterBOMToolStripMenuItem.Enabled = false;
            }
            else
            {
                productMasterBOMToolStripMenuItem.Enabled = true;
            }
            #endregion

            #region Indent 
            if (Loginfrm.GetUserDetails[10] != "True")
            {
                indentToolStripMenuItem2.Enabled = false;
            }
            else
            {
                indentToolStripMenuItem2.Enabled = true;
            }
            #endregion

            #region KanbanElectronics

            if (Login.frmLoginForm.sUserDetails[55] != "True")
            {
                itemProductionToolStripMenuItem.Enabled = false;
            }
            else
            {
                itemProductionToolStripMenuItem.Enabled = true;
            }

            if (Login.frmLoginForm.sUserDetails[56] != "True")
            {
                reportsToolStripMenuItem1.Enabled = false;
                reportsToolStripMenuItem.Enabled = false;
            }
            else
            {
                reportsToolStripMenuItem1.Enabled = true;
                reportsToolStripMenuItem.Enabled = true;
            }

            if (Login.frmLoginForm.sUserDetails[57] != "True")
            {
                itemIssueToolStripMenuItem.Enabled = false;
            }
            else
            {
                itemIssueToolStripMenuItem.Enabled = true;
            }

            if (Login.frmLoginForm.sUserDetails[62] != "True")
            {
                productionToolStripMenuItem.Enabled = false;
            }
            else
            {
                productionToolStripMenuItem.Enabled = true;
            }
            if (Login.frmLoginForm.sUserDetails[63] != "True")
            {
                kANBANBOMToolStripMenuItem.Enabled = false;
                kANBANBOMToolStripMenuItem1.Enabled = false;
            }
            else
            {
                kANBANBOMToolStripMenuItem.Enabled = true;
                kANBANBOMToolStripMenuItem1.Enabled = true;
            }
            if (Login.frmLoginForm.sUserDetails[64] != "True")
            {
                issueToolStripMenuItem.Enabled = false;
                bOMToolStripMenuItem.Enabled = false;
            }
            else
            {
                bOMToolStripMenuItem.Enabled = true;
                issueToolStripMenuItem.Enabled = true;
            }
            if (Login.frmLoginForm.sUserDetails[65] != "True")
            {
                itemLedgerToolStripMenuItem1.Enabled = false;
                itemLedgerToolStripMenuItem2.Enabled = false;
            }
            else
            {
                itemLedgerToolStripMenuItem1.Enabled = true;
                itemLedgerToolStripMenuItem2.Enabled = true;
            }
            if (Login.frmLoginForm.sUserDetails[67] != "True")
            {
                itemReturnToolStripMenuItem1.Enabled = false;
            }
            else
            {
                itemReturnToolStripMenuItem1.Enabled = true;
            }
            if (Login.frmLoginForm.sUserDetails[68] != "True")
            {
                itemStockAdjustToolStripMenuItem.Enabled = false;
            }
            else
            {
                itemStockAdjustToolStripMenuItem.Enabled = true;
            }

            if (Login.frmLoginForm.sUserDetails[70] != "True")
            {
                itemReturnToolStripMenuItem2.Enabled = false;
            }
            else
            {
                itemReturnToolStripMenuItem2.Enabled = true;
            }

            if (Login.frmLoginForm.sUserDetails[71] != "True")
            {
                itemStockAdjustToolStripMenuItem1.Enabled = false;
            }
            else
            {
                itemStockAdjustToolStripMenuItem1.Enabled = true;
            }
            #endregion

            #region Project Master

            if (Loginfrm.GetUserDetails[48] != "True")
            {
                createProjectToolStripMenuItem.Enabled = false;
            }
            else
            {
                createProjectToolStripMenuItem.Enabled = true;
            }

            if (Loginfrm.GetUserDetails[33] != "True")
            {
                projectTransferToolStripMenuItem.Enabled = false;
            }
            else
            {
                projectTransferToolStripMenuItem.Enabled = true;
            }
            if (Loginfrm.GetUserDetails[34] != "True")
            {
                projectDocumentsToolStripMenuItem.Enabled = false;
            }
            else
            {
                projectDocumentsToolStripMenuItem.Enabled = true;
            }

            if (Loginfrm.GetUserDetails[13] != "True")
            {
                ProjectBOMtoolStripMenuItem.Enabled = false;
            }
            else
            {
                ProjectBOMtoolStripMenuItem.Enabled = true;
            }

            if (Loginfrm.GetUserDetails[69] != "True")
            {
                capexProjectsUpdateToolStripMenuItem.Enabled = false;
                capexProjectDepartmentAccessPermissionToolStripMenuItem.Enabled = false;
            }
            else
            {
                capexProjectsUpdateToolStripMenuItem.Enabled = true;
                capexProjectDepartmentAccessPermissionToolStripMenuItem.Enabled = true;
            }

            if (Loginfrm.GetUserDetails[37] != "True")
            {
                updateProjectToolStripMenuItem.Enabled = false;
            }
            else
            {
                updateProjectToolStripMenuItem.Enabled = true;
            }

            if (Loginfrm.GetUserDetails[38] != "True")
            {
                capexProjectsUpdateToolStripMenuItem.Enabled = false;
                capexProjectStatusUpdateToolStripMenuItem1.Enabled = false;
            }
            else
            {
                capexProjectsUpdateToolStripMenuItem.Enabled = true;
                capexProjectStatusUpdateToolStripMenuItem1.Enabled = true;
            }

            if (Loginfrm.GetUserDetails[39] != "True")
            {
                projectInstallationStatuoUpdateToolStripMenuItem.Enabled = false;
            }
            else
            {
                projectInstallationStatuoUpdateToolStripMenuItem.Enabled = true;
            }

            if (Loginfrm.GetUserDetails[40] != "True")
            {
                projectTransferRequestToolStripMenuItem.Enabled = false;
            }
            else
            {
                projectTransferRequestToolStripMenuItem.Enabled = true;
            }

            if (Loginfrm.GetUserDetails[49] != "True")
            {
                projectShipmentDateUpdateToolStripMenuItem.Enabled = false;
            }
            else
            {
                projectShipmentDateUpdateToolStripMenuItem.Enabled = true;
            }

            if (Loginfrm.GetUserDetails[69] != "True")
            {
                projectBOMApproveToolStripMenuItem.Enabled = false;
            }
            else
            {
                projectBOMApproveToolStripMenuItem.Enabled = true;
            }

            //if (Login.frmLoginForm.sUserDetails[74] != "True")
            //{
            //    btnGMApprove.Enabled = false;
            //    llbGMApprove.Enabled = false;
            //}
            //else
            //{
            //    btnGMApprove.Enabled = true;
            //    llbGMApprove.Enabled = true;
            //}
            // Thilak Kumar , vishal raina, Vishal, Kumar Ravi, Vivek G, Hebbarrk
            if (Loginfrm.GetUserDetails[2].ToString().ToLower() == "biss" ||
                Loginfrm.GetUserDetails[2].ToString().ToLower() == "thilak kumar" ||
                Loginfrm.GetUserDetails[2].ToString().ToLower() == "vishal raina" ||
                Loginfrm.GetUserDetails[2].ToString().ToLower() == "vishal" ||
                Loginfrm.GetUserDetails[2].ToString().ToLower() == "kumar ravi" ||
                Loginfrm.GetUserDetails[2].ToString().ToLower() == "vivek g" ||
                 Loginfrm.GetUserDetails[2].ToString().ToLower() == "hebbarrk")
            {
                ProjectBOMLockMenuItem.Enabled = true;
                ProjectBOMChangesLogsMenuItem.Enabled = true;
            }
            else
            {
                ProjectBOMLockMenuItem.Enabled = false;
                ProjectBOMChangesLogsMenuItem.Enabled = false;
            }


            if (Loginfrm.GetUserDetails[83] != "True")
            {
                projectQRCodeToolStripMenuItem.Enabled = false;
            }
            else
            {
                projectQRCodeToolStripMenuItem.Enabled = true;
            }


            #endregion

            #region Vendor Management
            tspProjectCLose.Enabled = false;
            serviceCallManagerToolStripMenuItem.Enabled = false;
            serviceOrderEntryToolStripMenuItem.Enabled = false;

            if (Loginfrm.GetUserDetails[21] != "True")
            {
                vendorMasterToolStripMenuItem.Enabled = false;
                tspProjectCLose.Enabled = false;
            }
            else
            {
                if (Loginfrm.GetUserDetails[23] == "Accounts" && Loginfrm.GetUserDetails[2].ToString() != "theertha rao")
                {
                    Today1 = DateTime.Today;
                    dtDetails = DAL.fnVedorNameList(4, Today1.ToString("yyyy-MM-dd")).Tables[0];

                    dgvDashBoard.AutoGenerateColumns = true;
                    dgvDashBoard.DataSource = dtDetails;
                    dgvDashBoard.ColumnHeadersDefaultCellStyle.Font = new Font("Calibri", 12F, FontStyle.Bold);

                    if (dgvDashBoard.Rows.Count > 0)
                    {
                        Datagridviewcolor();
                    }

                    foreach (DataGridViewColumn column in dgvDashBoard.Columns)
                    {
                        column.SortMode = DataGridViewColumnSortMode.NotSortable;
                    }
                    tspProjectCLose.Enabled = true;
                }
                else if (Loginfrm.GetUserDetails[2].ToString() == "theertha rao")
                {
                    Today1 = DateTime.Today;
                    dtDetails = DAL.fnVedorNameList(5, Today1.ToString("yyyy-MM-dd")).Tables[0];

                    dgvDashBoard.AutoGenerateColumns = true;
                    dgvDashBoard.DataSource = dtDetails;
                    dgvDashBoard.ColumnHeadersDefaultCellStyle.Font = new Font("Calibri", 12F, FontStyle.Bold);

                    if (dgvDashBoard.Rows.Count > 0)
                    {
                        Datagridviewcolor();
                    }

                    foreach (DataGridViewColumn column in dgvDashBoard.Columns)
                    {
                        column.SortMode = DataGridViewColumnSortMode.NotSortable;
                    }
                    tspProjectCLose.Enabled = true;
                }
                vendorMasterToolStripMenuItem.Enabled = true;

            }

            if (Loginfrm.GetUserDetails[79] != "True")
            {
                cityMasterToolStripMenuItem.Enabled = false;
            }
            else
            {
                cityMasterToolStripMenuItem.Enabled = true;
            }


            #endregion

            #region User Management
            if (Loginfrm.GetUserDetails[2] != "BiSS")
            {
                addNewUserToolStripMenuItem.Enabled = false;
            }
            else
            {
                addNewUserToolStripMenuItem.Enabled = true;
            }



            #endregion

            #region Sales Quote
            if (Loginfrm.GetUserDetails[41] != "True")
            {
                SalesQuoteGenToolStripMenuItem.Enabled = false;
            }
            else
            {
                SalesQuoteGenToolStripMenuItem.Enabled = true;
            }


            if (Loginfrm.GetUserDetails[42] != "True")
            {
                productMasterToolStripMenuItem.Enabled = false;
            }
            else
            {
                productMasterToolStripMenuItem.Enabled = true;
            }

            if (Loginfrm.GetUserDetails[43] != "True")
            {
                customerVisitToolStripMenuItem.Enabled = false;
            }
            else
            {
                customerVisitToolStripMenuItem.Enabled = true;
            }

            if (Loginfrm.GetUserDetails[44] != "True")
            {
                opportunityDetailsToolStripMenuItem.Enabled = false;
            }
            else
            {
                opportunityDetailsToolStripMenuItem.Enabled = true;
            }
            if (Loginfrm.GetUserDetails[45] != "True")
            {
                pEGRateToolStripMenuItem.Enabled = false;
            }
            else
            {
                pEGRateToolStripMenuItem.Enabled = true;
            }
            if (Loginfrm.GetUserDetails[46] != "True")
            {
                enquiryRegisterToolStripMenuItem.Enabled = false;
            }
            else
            {
                enquiryRegisterToolStripMenuItem.Enabled = true;
            }

            if (Loginfrm.GetUserDetails[47] != "True")
            {
                testLabQuoteGENToolStripMenuItem.Enabled = false;
            }
            else
            {
                testLabQuoteGENToolStripMenuItem.Enabled = true;
            }

            if (Loginfrm.GetUserDetails[81] != "True")
            {
                serviceQuoteGenToolStripMenuItem.Enabled = false;
            }
            else
            {
                serviceQuoteGenToolStripMenuItem.Enabled = true;
            }

            #endregion






            /*
            if (Loginfrm.GetUserDetails[26] != "True")
            {
            }
            else
            {
                if (Loginfrm.GetUserDetails[2].ToLower() == "vivek g")
                {
                    var Today2 = DateTime.Today;
                    dtDetails = DAL.fnDashBoardFilter(31, "", Today2.ToString("yyyy-MM-dd")).Tables[0];

                    //   if (dtPOCheck.Rows.Count > 0)
                    {
                        dtDetails.Merge(dtPOCheck);
                    }
                    dgvDashBoard.AutoGenerateColumns = true;
                    dgvDashBoard.DataSource = dtDetails;
                    dgvDashBoard.ColumnHeadersDefaultCellStyle.Font = new Font("Calibri", 12F, FontStyle.Bold);

                    if (dgvDashBoard.Rows.Count > 0)
                    {
                        Datagridviewcolor();
                    }
                }
            }
            */

            #region Quality Management
            if (Loginfrm.GetUserDetails[60] != "True")
            {
                createNCToolStripMenuItem.Enabled = false;
                addEscalationToolStripMenuItem.Enabled = false;
            }
            else
            {
                createNCToolStripMenuItem.Enabled = true;
                addEscalationToolStripMenuItem.Enabled = true;
            }
            #endregion

            #region Request Support
            if (Loginfrm.GetUserDetails[61] != "True")
            {
                raiseRequestToolStripMenuItem.Enabled = false;
                userFeedbackToolStripMenuItem.Enabled = false;
                requestHistoryToolStripMenuItem.Enabled = false;
            }
            else
            {
                raiseRequestToolStripMenuItem.Enabled = true;
                userFeedbackToolStripMenuItem.Enabled = true;
                requestHistoryToolStripMenuItem.Enabled = true;
            }
            #endregion

        }
        #endregion
        #region Function to Show Please wait form & Switch to Selected From
        private void fnFormShow(Form Frm)
        {
            this.Hide();
            pleasewaitform pleaseWait = new pleasewaitform();
            pleaseWait.Show();
            Application.DoEvents();
            Frm.Show();
            pleaseWait.Hide();
        }
        #endregion
        #region Code to Switch Selected Forms

        private void llSwitchUser_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Login.frmLoginForm frmLogin = new Login.frmLoginForm();
            fnFormShow(frmLogin);
        }


        #endregion

        string lastPurchasecode = "";
        private void Datagridviewcolor()
        {

            foreach (DataGridViewRow row in dgvDashBoard.Rows)
            {
             
                    switch (row.Cells[0].Value.ToString())
                    {
                        case "Purchase Order":
                        row.DefaultCellStyle.BackColor = Color.LightYellow;
                        if (Convert.ToBoolean(Loginfrm.GetUserDetails[30]) == true)
                        {
                            if (lastPurchasecode == row.Cells[1].Value?.ToString())
                            {

                                if (Convert.ToDouble(row.Cells[6]?.Value.ToString()) > Convert.ToDouble(row.Cells[7]?.Value.ToString()))
                                {
                                    row.Cells[6].Style.BackColor = Color.Red;
                                    row.Cells[7].Style.BackColor = Color.Red;
                                    row.Cells[6].Style.ForeColor = Color.White;
                                    row.Cells[7].Style.ForeColor = Color.White;
                                }
                                else
                                {
                                    row.Cells[6].Style.BackColor = Color.LightGreen;
                                    row.Cells[7].Style.BackColor = Color.LightGreen;
                                }

                            }
                            else
                            {
                                //New code(header)
                                row.DefaultCellStyle.BackColor = Color.LightGray;
                                lastPurchasecode = row.Cells[1].Value?.ToString();
                                if (Convert.ToDouble(row.Cells[6]?.Value.ToString()) > Convert.ToDouble(row.Cells[7]?.Value.ToString()))
                                {
                                    row.Cells[6].Style.BackColor = Color.Red;
                                    row.Cells[7].Style.BackColor = Color.Red;
                                    row.Cells[6].Style.ForeColor = Color.White;
                                    row.Cells[7].Style.ForeColor = Color.White;
                                }
                                else
                                {
                                    row.Cells[6].Style.BackColor = Color.LightGreen;
                                    row.Cells[7].Style.BackColor = Color.LightGreen;
                                }
                            }
                        }
                            

                           // MessageBox.Show(row.Cells[1].Value?.ToString());
                        break;
                        case "Work Order":
                            row.DefaultCellStyle.BackColor = Color.LightBlue;
                            break;
                        case "Project Approve":
                            row.DefaultCellStyle.BackColor = Color.LightSkyBlue;
                            break;
                        case "Vendor Approve":
                            row.DefaultCellStyle.BackColor = Color.LightYellow;
                            break;
                        case "Warranty Expired":
                            row.DefaultCellStyle.BackColor = Color.Red;
                            break;
                    }
                
            }
        }



        private void dgvDashBoard_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvDashBoard.Rows.Count > 0)
            {
                switch (dgvDashBoard.CurrentRow.Cells[0].Value.ToString())
                {
                    case "Purchase Order":
                    case "PO Unitcost Update":
                    case "PO Finalize":
                        Purchase_Order.PurchaseOrder frmPurchaseOrder = new Purchase_Order.PurchaseOrder();
                        fnFormShow(frmPurchaseOrder);
                        break;
                    case "Work Order":
                        JobWork.frmJObWork frmWorkorder = new JobWork.frmJObWork();
                        fnFormShow(frmWorkorder);
                        break;
                    case "Project Approve":
                        if (Loginfrm.GetUserDetails[2].ToLower() == "hebbarrk" || Loginfrm.GetUserDetails[2].ToLower() == "vivek g")
                        {
                            //Project_Master.frmProjectApproveGM GMApprove = new Project_Master.frmProjectApproveGM();
                            //fnFormShow(GMApprove);
                            frmProjectmaster frmprojectmaster = new frmProjectmaster();
                            fnFormShow(frmprojectmaster);
                        }
                        else
                        {
                            frmProjectmaster frmprojectmaster = new frmProjectmaster();
                            fnFormShow(frmprojectmaster);
                        }
                        break;
                    case "Vendor Approve":
                        Vendor_Master.frmVendorMaster frmVendorMaster = new Vendor_Master.frmVendorMaster();
                        fnFormShow(frmVendorMaster);
                        break;
                    case "Warranty Expired":
                        Project_Master.frmWarrantyExpire Warranty = new Project_Master.frmWarrantyExpire();
                        fnFormShow(Warranty);
                        break;
                }
            }
        }


        //private void sidebarTimer_Tick(object sender, EventArgs e)
        //{
        //    //timerCount.Start();
        //    if (bSideparExpand)
        //    {
        //        Sidebarpanel.Width -= 10;
        //        if (Sidebarpanel.Width == Sidebarpanel.MinimumSize.Width)
        //        {
        //            bSideparExpand = false;
        //            sidebarTimer.Stop();
        //        }
        //    }
        //    else
        //    {
        //        Sidebarpanel.Width += 10;
        //        if (Sidebarpanel.Width == Sidebarpanel.MaximumSize.Width)
        //        {
        //            bSideparExpand = true;
        //            sidebarTimer.Stop();
        //        }
        //    }

        //}


        private void createProjectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmProjectmaster frmprojectmaster = new frmProjectmaster();
            fnFormShow(frmprojectmaster);
        }

        private void updateProjectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Project_Master.frmProjectUpdate PUpdate = new Project_Master.frmProjectUpdate();
            fnFormShow(PUpdate);
        }

        private void toolStripMenuItem4_Click(object sender, EventArgs e)
        {

        }

        private void indentToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void indentToolStripMenuItem2_Click(object sender, EventArgs e)
        {

        }

        private void indentToolStripMenuItem2_Click_1(object sender, EventArgs e)
        {

        }

        private void reportsToolStripMenuItem2_Click(object sender, EventArgs e)
        {

        }


        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {


        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void projectMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem6_Click(object sender, EventArgs e)
        {

        }

        private void purchaseOrderToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void workOrderToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void timeSheetToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void securityToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void newPurchaseOrderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Purchase_Order.PurchaseOrder frmPurchaseOrder = new Purchase_Order.PurchaseOrder();
            fnFormShow(frmPurchaseOrder);
        }

        //private void addItemToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    frmPartmaster frmPartmaster = new frmPartmaster();
        //    fnFormShow(frmPartmaster);
        //}

        //private void standardCostUpdateToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    Part_Master.frmStandardCost standardCost = new Part_Master.frmStandardCost();
        //    fnFormShow(standardCost);
        //}

        //private void targetCostToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    Part_Master.FrmTargetCost TargetCost = new Part_Master.FrmTargetCost();
        //    fnFormShow(TargetCost);
        //}


        //private void itemLedgerToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    Part_Reports.frmMaterialLedger frmMaterialLedger = new Part_Reports.frmMaterialLedger();
        //    fnFormShow(frmMaterialLedger);
        //}

        private void itemReturnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Item_Return_Adjust_Stock.AdjustStock frmAdjuststock = new Item_Return_Adjust_Stock.AdjustStock();
            fnFormShow(frmAdjuststock);
        }

        private void gINToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReciept frmReciept = new frmReciept();
            fnFormShow(frmReciept);
        }

        private void DCToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Part_Reciept.DC Part_Reciept_DC = new Part_Reciept.DC();
            fnFormShow(Part_Reciept_DC);
        }

        private void poStatusToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Part_Reports.POStatus pOstatus = new Part_Reports.POStatus();
            fnFormShow(pOstatus);
        }

        private void reverseGINToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Part_Reciept.GinReverse GinReverse = new Part_Reciept.GinReverse();
            fnFormShow(GinReverse);
        }

        private void pOWOInspectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Part_Reciept.POInspection POInspect = new Part_Reciept.POInspection();
            fnFormShow(POInspect);
        }

        private void updateLedgerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Part_Reciept.GINPOView ginpo = new Part_Reciept.GINPOView();
            fnFormShow(ginpo);
        }

        // newlly added for inventrory
        private void inventoryLedgerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Part_Reciept.frmInventoryLedger frmInventoryLedgerPage = new Part_Reciept.frmInventoryLedger();
            fnFormShow(frmInventoryLedgerPage);
        }

        // newlly added for InventoryCycleCount

        private void InventoryCycleCountMenuItem_Click(object sender, EventArgs e)
        {
            Part_Reciept.InventoryCycleCount InventoryCycleCountPage = new Part_Reciept.InventoryCycleCount();
            fnFormShow(InventoryCycleCountPage);
        }

        private void InventoryDashBoard_Click(object sender, EventArgs e)
        {
            //Part_Reciept.DashBoard InventoryInventoryDashBoard = new Part_Reciept.DashBoard();
            //fnFormShow(InventoryInventoryDashBoard);
        }


        private void ItemLocationUpdateMenuItem_Click(object sender, EventArgs e)
        {
            Part_Reciept.ItemLocationUpdate ItemLocationUpdate = new Part_Reciept.ItemLocationUpdate();
            fnFormShow(ItemLocationUpdate);
        }



        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            ProjectBOM.frmProjectBOM frmProjectBOM = new ProjectBOM.frmProjectBOM();
            fnFormShow(frmProjectBOM);
        }

        private void ProjectBOMLockMenuItem_Click(object sender, EventArgs e)
        {
            ProjectBOM.LockBOM frmLockBOM = new ProjectBOM.LockBOM();
            fnFormShow(frmLockBOM);
        }

        //ProjectBOMChangesLogsMenuItem

        private void ProjectBOMChangesLogsMenuItem_Click(object sender, EventArgs e)
        {
            ProjectBOM.BOMChangesLogs frmBOMChangesLogs = new ProjectBOM.BOMChangesLogs();
            fnFormShow(frmBOMChangesLogs);
        }

        private void ProjectProgressMenuItem_Click(object sender, EventArgs e)
        {
            Part_Reports.ProjectProgress frmProjectProgress = new Part_Reports.ProjectProgress();
            fnFormShow(frmProjectProgress);
        }

        private void projectBOMApproveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Project_Master.frmProjectApproveGM GM = new Project_Master.frmProjectApproveGM();
            fnFormShow(GM);
        }

        private void projectInstallationStatuoUpdateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Project_Master.frmProjectInstall PInstall = new Project_Master.frmProjectInstall();
            fnFormShow(PInstall);
        }

        private void projectShipmentDateUpdateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Project_Master.frmProjectShipmentStatusUpdate PrSU = new Project_Master.frmProjectShipmentStatusUpdate();
            fnFormShow(PrSU);
        }

        private void projectTransferRequestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Project_Master.frmProjectTransferRequest TRE = new Project_Master.frmProjectTransferRequest();
            fnFormShow(TRE);
        }

        private void projectTransferToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Item_Return_Adjust_Stock.frmTranferForm TransferForm = new Item_Return_Adjust_Stock.frmTranferForm();
            fnFormShow(TransferForm);
        }

        private void projectDocumentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Project_Documents.frmProjectDocs PDC = new Project_Documents.frmProjectDocs();
            fnFormShow(PDC);
        }


        //private void projectTrackerToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    Project_Master.frmProjectTracker frmprotacker = new Project_Master.frmProjectTracker();
        //    fnFormShow(frmprotacker);
        //}

        private void projectQRCodeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Project_Master.frmProjectBarcode frmProjectBarcode = new Project_Master.frmProjectBarcode();
            fnFormShow(frmProjectBarcode);
        }


        private void enquiryRegisterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sales_Enquiry.frmEnquiryRegisterEntry Enq = new Sales_Enquiry.frmEnquiryRegisterEntry();
            fnFormShow(Enq);
        }

        private void SalesQuoteGenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sales_Enquiry.frmSalesQuote SalesQuote = new Sales_Enquiry.frmSalesQuote();
            fnFormShow(SalesQuote);
        }

        private void customerVisitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sales_Enquiry.frmCustomerVisit CustomerVisit = new Sales_Enquiry.frmCustomerVisit();
            fnFormShow(CustomerVisit);
        }

        private void opportunityDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sales_Enquiry.frmOpportuniyDetails Opportunity = new Sales_Enquiry.frmOpportuniyDetails();
            fnFormShow(Opportunity);
        }

        //private void productMasterToolStripMenuItem_Click(object sender, EventArgs e)
        //{

        //}

        private void serviceQuoteGenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sales_Enquiry.frmServicequote servicequote = new Sales_Enquiry.frmServicequote();
            fnFormShow(servicequote);
        }

        private void testLabQuoteGENToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sales_Enquiry.TestingQuote TestQuote = new Sales_Enquiry.TestingQuote();
            fnFormShow(TestQuote);
        }

        private void pEGRateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Sales_Enquiry.frmPegRate PegRate = new Sales_Enquiry.frmPegRate();
            fnFormShow(PegRate);
        }

        //private void productionToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    KanBanProduct.frmElectronicsItems EI = new KanBanProduct.frmElectronicsItems();
        //    fnFormShow(EI);
        //}

        //private void issueToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    KanBanProduct.frmElectronicsissue EIssue = new KanBanProduct.frmElectronicsissue();
        //    fnFormShow(EIssue);
        //}

        //private void itemReturnToolStripMenuItem1_Click(object sender, EventArgs e)
        //{
        //    KanBanProduct.frmKanBanEReturn Return = new KanBanProduct.frmKanBanEReturn();
        //    fnFormShow(Return);
        //}

        //private void itemStockAdjustToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    KanBanProduct.frmElectronicsStockadjust StockAdjust = new KanBanProduct.frmElectronicsStockadjust();
        //    fnFormShow(StockAdjust);
        //}

        //private void bOMToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    KanBanProduct.frmProjectBOM frmProjectBOM = new KanBanProduct.frmProjectBOM();
        //    fnFormShow(frmProjectBOM);
        //}

        //private void reportsToolStripMenuItem1_Click(object sender, EventArgs e)
        //{
        //    KanBanProduct.frmKanBanReports KbReports = new KanBanProduct.frmKanBanReports();
        //    fnFormShow(KbReports);
        //}

        //private void itemIssueToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    KanBanProduct.frmKanbanIssue Kissue = new KanBanProduct.frmKanbanIssue();
        //    fnFormShow(Kissue);
        //}

        //private void itemProductionToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    KanBanProduct.frmKanBanItems KbProduct = new KanBanProduct.frmKanBanItems();
        //    fnFormShow(KbProduct);
        //}

        //private void itemReturnToolStripMenuItem2_Click(object sender, EventArgs e)
        //{
        //    KanBanProduct.frmKanBanTransducerReturn TIR = new KanBanProduct.frmKanBanTransducerReturn();
        //    fnFormShow(TIR);
        //}

        //private void itemStockAdjustToolStripMenuItem1_Click(object sender, EventArgs e)
        //{
        //    KanBanProduct.frmKanBanTransducerStockAdjust TRSAdjust = new KanBanProduct.frmKanBanTransducerStockAdjust();
        //    fnFormShow(TRSAdjust);
        //}

        //private void reportsToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    KanBanProduct.frmKanBanReports KbReports = new KanBanProduct.frmKanBanReports();
        //    fnFormShow(KbReports);
        //}

        private void addTimeSheetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Time_Sheet.frmValidationTimeSheet TimeSheet = new Time_Sheet.frmValidationTimeSheet();
            fnFormShow(TimeSheet);
        }

        private void machineUtilizationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Time_Sheet.frmMachineUtilization MU = new Time_Sheet.frmMachineUtilization();
            fnFormShow(MU);
        }

        private void timeSheetReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Time_Sheet.frmTimesheetView VTS = new Time_Sheet.frmTimesheetView();
            fnFormShow(VTS);
        }

        //private void raiseRequestToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    BISS_Complaints.frmCompalint Complaint = new BISS_Complaints.frmCompalint();
        //    fnFormShow(Complaint);
        //}

        //private void userFeedbackToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    BISS_Complaints.frmComplaintFeedback fb = new BISS_Complaints.frmComplaintFeedback();
        //    fnFormShow(fb);
        //}

        //private void requestHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    BISS_Complaints.frmComplaintHistory CH = new BISS_Complaints.frmComplaintHistory();
        //    fnFormShow(CH);
        //}

        private void securityInwardItemsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SecurityInwardOutward.frmSecurityInwards SInward = new SecurityInwardOutward.frmSecurityInwards();
            fnFormShow(SInward);
        }

        private void outwardItemsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SecurityInwardOutward.SecurityOutward SOutward = new SecurityInwardOutward.SecurityOutward();
            fnFormShow(SOutward);
        }

        private void manualInwardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SecurityInwardOutward.frmManualInward ManInward = new SecurityInwardOutward.frmManualInward();
            fnFormShow(ManInward);
        }

        private void reportsToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            SecurityInwardOutward.frmViewInwardOutward ViewReport = new SecurityInwardOutward.frmViewInwardOutward();
            fnFormShow(ViewReport);
        }

        private void allERPReportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReports reports = new frmReports();
            fnFormShow(reports);
        }

        private void itemIssueToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmIssue frmIssue = new frmIssue();
            fnFormShow(frmIssue);
        }

        private void vendorMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Vendor_Master.frmVendorMaster frmVendorMaster = new Vendor_Master.frmVendorMaster();
            fnFormShow(frmVendorMaster);
        }



        private void cityMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            City_Master.CityMaster cityHOME = new City_Master.CityMaster();
            fnFormShow(cityHOME);
        }

        //private void createNCToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    Biss_NC.frmRaiseNC RaiseNC = new Biss_NC.frmRaiseNC();
        //    fnFormShow(RaiseNC);
        //}

        //private void addEscalationToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    Biss_NC.Escalation escal = new Biss_NC.Escalation();
        //    fnFormShow(escal);
        //}


        private void toolStripMenuItemSIN_Click(object sender, EventArgs e)
        {
            Part_Reciept.frmGINotheritems SIN = new Part_Reciept.frmGINotheritems();
            fnFormShow(SIN);
        }

        private void kANBANBOMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            KanBanProduct.frmElectronicsBOM BOM = new KanBanProduct.frmElectronicsBOM();
            fnFormShow(BOM);
        }

        private void itemLedgerToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            KanBanProduct.frmKANBANLedger Ledger = new KanBanProduct.frmKANBANLedger();
            fnFormShow(Ledger);
        }

        //private void kANBANBOMToolStripMenuItem1_Click(object sender, EventArgs e)
        //{
        //    KanBanProduct.frmElectronicsBOM BOM = new KanBanProduct.frmElectronicsBOM();
        //    fnFormShow(BOM);
        //}

        //private void itemLedgerToolStripMenuItem2_Click(object sender, EventArgs e)
        //{
        //    KanBanProduct.frmKANBANLedger Ledger = new KanBanProduct.frmKANBANLedger();
        //    fnFormShow(Ledger);
        //}

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Login.frmChangePasswordForm frmChangePassword = new Login.frmChangePasswordForm();
            fnFormShow(frmChangePassword);
        }

        private void addNewUserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Login.frmAddUserForm frmAddUser = new Login.frmAddUserForm();
            fnFormShow(frmAddUser);
        }

        private void fixedAssetMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AssetMaster.frmAssetmaster frmAssetmaster = new AssetMaster.frmAssetmaster();
            fnFormShow(frmAssetmaster);
        }

        //private void customerMasterToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    Customer_Master.CustomerMasterForm frmCustomerMaster = new Customer_Master.CustomerMasterForm();
        //    fnFormShow(frmCustomerMaster);
        //}

        //private void productMasterBOMToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    Part_Master.frmProductMasterForm frmProductMaster = new Part_Master.frmProductMasterForm();
        //    fnFormShow(frmProductMaster);
        //}

        private void capexProjectStatusUpdateToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Project_Master.frmProjectStatusUpdate frmProjectStatusUpdate = new Project_Master.frmProjectStatusUpdate();
            fnFormShow(frmProjectStatusUpdate);
        }

        private void capexProjectDepartmentAccessPermissionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Project_Master.frmProjectApprove PApprove = new Project_Master.frmProjectApprove();
            fnFormShow(PApprove);
        }

        private void newApproveWorkOrderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            JobWork.frmJObWork frmWorkorder = new JobWork.frmJObWork();
            fnFormShow(frmWorkorder);
        }

        private void indentToolStripMenuItem2_Click_2(object sender, EventArgs e)
        {
            Indent.frmIndent frmIndent = new Indent.frmIndent();
            fnFormShow(frmIndent);
        }

        private void issueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            KanBanProduct.frmElectronicsissue EIssue = new KanBanProduct.frmElectronicsissue();
            fnFormShow(EIssue);
        }

        private void productionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            KanBanProduct.frmElectronicsItems EI = new KanBanProduct.frmElectronicsItems();
            fnFormShow(EI);
        }

        private void itemReturnToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            KanBanProduct.frmKanBanEReturn Return = new KanBanProduct.frmKanBanEReturn();
            fnFormShow(Return);
        }

        private void itemStockAdjustToolStripMenuItem_Click(object sender, EventArgs e)
        {
            KanBanProduct.frmElectronicsStockadjust StockAdjust = new KanBanProduct.frmElectronicsStockadjust();
            fnFormShow(StockAdjust);
        }

        private void bOMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            KanBanProduct.frmProjectBOM frmProjectBOM = new KanBanProduct.frmProjectBOM();
            fnFormShow(frmProjectBOM);
        }

        private void reportsToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            KanBanProduct.frmKanBanReports KbReports = new KanBanProduct.frmKanBanReports();
            fnFormShow(KbReports);
        }

        private void kANBANBOMToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            KanBanProduct.frmElectronicsBOM BOM = new KanBanProduct.frmElectronicsBOM();
            fnFormShow(BOM);
        }

        private void itemLedgerToolStripMenuItem1_Click_1(object sender, EventArgs e)
        {
            KanBanProduct.frmKANBANLedger Ledger = new KanBanProduct.frmKANBANLedger();
            fnFormShow(Ledger);
        }

        private void itemIssueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            KanBanProduct.frmKanbanIssue Kissue = new KanBanProduct.frmKanbanIssue();
            fnFormShow(Kissue);
        }

        private void itemProductionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            KanBanProduct.frmKanBanItems KbProduct = new KanBanProduct.frmKanBanItems();
            fnFormShow(KbProduct);
        }

        private void itemReturnToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            KanBanProduct.frmKanBanTransducerReturn TIR = new KanBanProduct.frmKanBanTransducerReturn();
            fnFormShow(TIR);
        }

        private void itemStockAdjustToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            KanBanProduct.frmKanBanTransducerStockAdjust TRSAdjust = new KanBanProduct.frmKanBanTransducerStockAdjust();
            fnFormShow(TRSAdjust);
        }

        private void reportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            KanBanProduct.frmKanBanReports KbReports = new KanBanProduct.frmKanBanReports();
            fnFormShow(KbReports);
        }

        private void kANBANBOMToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            KanBanProduct.frmElectronicsBOM BOM = new KanBanProduct.frmElectronicsBOM();
            fnFormShow(BOM);
        }

        private void itemLedgerToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            KanBanProduct.frmKANBANLedger Ledger = new KanBanProduct.frmKANBANLedger();
            fnFormShow(Ledger);
        }

        private void addItemToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            frmPartmaster frmPartmaster = new frmPartmaster();
            fnFormShow(frmPartmaster);
        }

        private void standardCostUpdateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Part_Master.frmStandardCost standardCost = new Part_Master.frmStandardCost();
            fnFormShow(standardCost);
        }

        private void targetCostToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Part_Master.FrmTargetCost TargetCost = new Part_Master.FrmTargetCost();
            fnFormShow(TargetCost);
        }

        private void itemLedgerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Part_Reports.frmMaterialLedger frmMaterialLedger = new Part_Reports.frmMaterialLedger();
            fnFormShow(frmMaterialLedger);
        }

        private void InventoryLedgerToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Part_Reports.frmInventoryLedger frmInventoryLedger = new Part_Reports.frmInventoryLedger();
            fnFormShow(frmInventoryLedger);
        }

        private void createNCToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Biss_NC.frmRaiseNC RaiseNC = new Biss_NC.frmRaiseNC();
            fnFormShow(RaiseNC);
        }

        private void addEscalationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Biss_NC.Escalation escal = new Biss_NC.Escalation();
            fnFormShow(escal);
        }

        private void customerMasterToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Customer_Master.CustomerMasterForm frmCustomerMaster = new Customer_Master.CustomerMasterForm();
            fnFormShow(frmCustomerMaster);
        }

        private void productMasterBOMToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Part_Master.frmProductMasterForm frmProductMaster = new Part_Master.frmProductMasterForm();
            fnFormShow(frmProductMaster);
        }

        private void productMasterToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Sales_Enquiry.frmSalesProduct SalesProduct = new Sales_Enquiry.frmSalesProduct();
            fnFormShow(SalesProduct);
        }

        private void raiseRequestToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            BISS_Complaints.frmCompalint Complaint = new BISS_Complaints.frmCompalint();
            fnFormShow(Complaint);
        }

        private void userFeedbackToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BISS_Complaints.frmComplaintFeedback fb = new BISS_Complaints.frmComplaintFeedback();
            fnFormShow(fb);
        }

        private void requestHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BISS_Complaints.frmComplaintHistory CH = new BISS_Complaints.frmComplaintHistory();
            fnFormShow(CH);
        }

        private void sRFCalibrationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Biss_NC.SRFCalibration sRFCalibration = new Biss_NC.SRFCalibration();
            fnFormShow(sRFCalibration);
        }

        private void serviceOrderEntryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Service_Call_Manager.frmServiceOrder serviceOrder = new Service_Call_Manager.frmServiceOrder();
            fnFormShow(serviceOrder);
        }

        private void tspProjectCLose_Click(object sender, EventArgs e)
        {
            Project_Master.frmWarrantyExpire Warranty = new Project_Master.frmWarrantyExpire();
            fnFormShow(Warranty);
        }

        private void orToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Project_Master.Order_Entry OrderEntry = new Project_Master.Order_Entry();
            //fnFormShow(OrderEntry);
        }

        private void machinePassportToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Project_Master.Machine_Passport Machine_Passport = new Project_Master.Machine_Passport();
            fnFormShow(Machine_Passport);


        }

        private void ProjectPackingListToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Project_Master.ProjectPackingList ProjectPackingList = new Project_Master.ProjectPackingList();
            fnFormShow(ProjectPackingList);


        }

        private void packingListToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Project_Master.Project_Closer ProjectClose = new Project_Master.Project_Closer();
            fnFormShow(ProjectClose);


        }


        private void wARCalculationToolStripMenuItem1_Click(object sender, EventArgs e)
        {

            Part_Master.WARReport WARReport = new Part_Master.WARReport();
            fnFormShow(WARReport);


        }

        private void serviceQuoteSparePartsGENToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Sales_Enquiry.Spare_parts Spare_parts = new Sales_Enquiry.Spare_parts();
            fnFormShow(Spare_parts);

        }

        private void dgvDashBoard_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private Panel ApprovalForm;
        private FlowLayoutPanel ApprovalFormChild;
        private FlowLayoutPanel ActionPanelChild;
        private Panel ApprovalGridViewPanel;
        private DataGridView ApprovalGridView;
        private Panel ActionPanel;
        private TextBox ApprovalRemarks;
        private Button btnApproval;
        private Button btnReject;
        private Button btnClose;

        private void dgvDashBoard_CellClick_old(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || !(dgvDashBoard.Columns[e.ColumnIndex] is DataGridViewButtonColumn))
                return;
            //MessageBox.Show(dgvDashBoard.CurrentRow.Cells["Doc Number"].Value.ToString(), "PONumber");
            //Prepared Date
            ShowScanPanel(dgvDashBoard.CurrentRow.Cells["Doc Number"].Value.ToString(), dgvDashBoard.CurrentRow.Cells["Prepared Date"].Value.ToString());
            //btnAcceptPO_Click(PONumber, poPreparedDate, ApprovalRemarks.Text);
        }

        private void dgvDashBoard_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Validate click
            if (e.RowIndex < 0 || !(dgvDashBoard.Columns[e.ColumnIndex] is DataGridViewButtonColumn))
                return;

            // Get the clicked button column name
            string buttonName = dgvDashBoard.Columns[e.ColumnIndex].Name;
            //MessageBox.Show(buttonName);

            // Get row data
            string poNumber = dgvDashBoard.CurrentRow.Cells["Doc Number"].Value?.ToString();
            string refNumber = dgvDashBoard.CurrentRow.Cells["Ref Code"].Value?.ToString();
            string poPreparedDate = dgvDashBoard.CurrentRow.Cells["Prepared Date"].Value?.ToString();
            string Type = dgvDashBoard.CurrentRow.Cells["Type"].Value?.ToString();

            // Get remarks from the textbox column (handle null)
            string remarks = dgvDashBoard.CurrentRow.Cells["txtremarks"].Value?.ToString() ?? "";

            // Check which button was clicked
            if (buttonName == "btnReject" && Type == "Purchase Order")
            {
                // REJECT BUTTON CLICKED
                if (string.IsNullOrWhiteSpace(remarks))
                {
                    MessageBox.Show("Please enter remarks before rejecting.", "Remarks Required",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    // Optional: Focus the remarks cell for user
                    dgvDashBoard.CurrentCell = dgvDashBoard.Rows[e.RowIndex].Cells["txtremarks"];
                    dgvDashBoard.BeginEdit(true);
                    return;
                }

                // Call reject method (create this if needed)
                btnRejectPO_Click(poNumber, poPreparedDate, remarks, refNumber);
            }
            else if (buttonName == "btnAction" && Type == "Purchase Order")  // Approve button
            {
                // APPROVE BUTTON CLICKED
                if (string.IsNullOrWhiteSpace(remarks))
                {
                    MessageBox.Show("Please enter remarks before approving.", "Remarks Required",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    // Focus the remarks cell
                    dgvDashBoard.CurrentCell = dgvDashBoard.Rows[e.RowIndex].Cells["txtremarks"];
                    dgvDashBoard.BeginEdit(true);
                    return;
                }

                // Call your existing accept method
                btnAcceptPO_Click(poNumber, poPreparedDate, remarks, refNumber);
            }else if(buttonName == "chkSelect" && Type == "Purchase Order")
            {
                MessageBox.Show("line item checked...!");
            }
        }

  
        private Button CreateActionButton(string text, Color color)
        {
            return new Button
            {
                Text = text,
                Size = new Size(110, 34),
                BackColor = color,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold),
                Margin = new Padding(0, 0, 10, 0)
            };
        }

       

        private void ApplyBorderRadius(Control control, int radius)
                {
                    Rectangle bounds = new Rectangle(0, 0, control.Width, control.Height);

                    GraphicsPath path = new GraphicsPath();
                    path.StartFigure();

                    path.AddArc(bounds.X, bounds.Y, radius, radius, 180, 90);
                    path.AddArc(bounds.Right - radius, bounds.Y, radius, radius, 270, 90);
                    path.AddArc(bounds.Right - radius, bounds.Bottom - radius, radius, radius, 0, 90);
                    path.AddArc(bounds.X, bounds.Bottom - radius, radius, radius, 90, 90);

                    path.CloseFigure();
                    control.Region = new Region(path);
                }


        private void ShowScanPanel(string PONumber, string poPreparedDate)
        {
            if (ApprovalForm != null)
            {
                ApprovalForm.Dispose();
                ApprovalForm = null;
            }

            // ================= ROOT PANEL =================
            ApprovalForm = new Panel
            {
                Size = new Size(700, 380),
                BackColor = Color.White,
                
                BorderStyle = BorderStyle.None,
                Location = new Point(
                    (ClientSize.Width - 680) / 2,
                    (ClientSize.Height - 380) / 2
                )
            };


            this.Controls.Add(ApprovalForm);
            ApplyBorderRadius(ApprovalForm, 10); // 15px radius
            ApprovalForm.BringToFront();


            // ================= GRID PANEL =================
            Panel gridPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 255,
                
                Padding = new Padding(5)
            };

            ApprovalGridView = new DataGridView
            {
                Name = "ApprovalGridView",
                Dock = DockStyle.Fill,
                AutoGenerateColumns = false,

                // UI Look & Feel
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal,
                GridColor = Color.LightGray,

                // Header Styling
                EnableHeadersVisualStyles = false,
                ColumnHeadersHeight = 40,
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.FromArgb(33, 150, 243), // Material Blue
                    ForeColor = Color.White,
                    Font = new Font("Segoe UI", 13F, FontStyle.Bold),
                    Alignment = DataGridViewContentAlignment.MiddleCenter
                },

                // Row Styling
                RowTemplate = { Height = 35 },
                RowHeadersVisible = false,
                AlternatingRowsDefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.FromArgb(245, 247, 250)
                },
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    Font = new Font("Segoe UI", 9.5F),
                    ForeColor = Color.Black,
                    SelectionBackColor = Color.FromArgb(219, 234, 254),
                    SelectionForeColor = Color.Black
                },

                // Behavior
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                ReadOnly = true,
                MultiSelect = false,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false
            };

            

            // ✅ Data binding AFTER columns
            DataTable GetERPPurchaseOrderDetails = DAL.fnGetERPPurchaseOrderDetails(PONumber).Tables[0];

            //if (dtPOCheck.Rows.Count > 0)
            // {
            //   dtDetails.Merge(dtPOCheck);

            //}
            ApprovalGridView.AutoGenerateColumns = true;
            ApprovalGridView.DataSource = GetERPPurchaseOrderDetails;
            // ApprovalGridView.DataSource =
            // DAL.fnGetERPPurchaseOrderDetails(PONumber).Tables[0];

            gridPanel.Controls.Add(ApprovalGridView);

            // ================= ACTION PANEL =================
            Panel actionPanel = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 130,
                Padding = new Padding(10),
                BackColor = Color.WhiteSmoke
            };

            ApprovalRemarks = new TextBox
            {
                Multiline = true,
                Dock = DockStyle.Top,
                Height = 60,
                Font = new Font("Segoe UI", 9.5F)
            };

            FlowLayoutPanel buttonPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Bottom,
                Height = 40,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false
            };

            btnApproval = CreateActionButton("Approve", Color.FromArgb(76, 175, 80));
            btnReject = CreateActionButton("Reject", Color.FromArgb(244, 67, 54));
            btnClose = CreateActionButton("Close", Color.Gray);

            btnClose.Click += (s, e) => FormReload();//ApprovalForm.Dispose();
           // btnApproval.Click += (s, e) => btnAcceptPO_Click(PONumber, poPreparedDate, ApprovalRemarks.Text);
            //btnReject.Click += (s, e) => btnRejectPO_Click(PONumber, poPreparedDate, ApprovalRemarks.Text);

            buttonPanel.Controls.AddRange(new Control[]
            {
        btnApproval, btnReject, btnClose
            });

            actionPanel.Controls.Add(ApprovalRemarks);
            actionPanel.Controls.Add(buttonPanel);

            // ================= FINAL ASSEMBLY =================
            ApprovalForm.Controls.Add(actionPanel);
            ApprovalForm.Controls.Add(gridPanel);

            Controls.Add(ApprovalForm);
            ApprovalForm.BringToFront();
        }
        private void btnAcceptPO_Click(string poNumber, string preparedDate, string approvalRemarks, string refNumber)
        {
            DataTable dtEMailID = new DataTable();

            //RAMAKRISHNA
            if (Convert.ToBoolean(login.GetUserDetails[30]) == true)
            {
                //rk - GlobalClass.iSuccess = DAL.purchaseOrderApproval(35, poNumber, preparedDate, login.GetUserDetails[2], approvalRemarks);

                //This below line for approve selected line

                foreach (DataGridViewRow row in dgvDashBoard.Rows)
                {

                    if (row.Cells[1].Value?.ToString() == poNumber &&
                        Convert.ToBoolean(row.Cells[12].Value))

                    {
                        GlobalClass.iSuccess = DAL.purchaseOrderGMOMApproval(35, poNumber, preparedDate, login.GetUserDetails[2], approvalRemarks, row.Cells[2].Value.ToString());
                       // MessageBox.Show($"{poNumber+" / "+row.Cells[2].Value.ToString()} selected...!");
                    }
                   // else
                   // {
                       // MessageBox.Show("Not selected...!");
                   // }
                    //MessageBox.Show(row.Cells[11].Value?.ToString());
                }

                            //GlobalClass.iSuccess = DAL.fnUpdatePoProcess(7, poNumber, login.GetUserDetails[2].ToString(), "", "");

                            //foreach (DataGridViewRow row in dgvPOGeneralTerms.Rows)
                            // {
                            // GlobalClass.iSuccess = DAL.fnUpdatePoProcess(6, poNumber, login.GetUserDetails[2].ToString(), "", row.Cells["POTerms"].Value.ToString().Trim());
                            // }

                            dtEMailID = DAL.PORemarksHistory(5, poNumber).Tables[0];
                        if (dtEMailID.Rows.Count > 0)
                        {
                            for (int i = 0; i < dtEMailID.Rows.Count; i++)
                            {
                                if (!lstusers.Items.Contains(dtEMailID.Rows[i]["emailid"].ToString()))
                                {
                                    lstusers.Items.Add(dtEMailID.Rows[i]["emailid"].ToString());
                                }
                            }

                      fnApprovetMail("Pavana", approvalRemarks, lstusers, null, poNumber);
                    // fnApprovetMail("biss", txtRemarks.Text, lstusers, null);
                }
                      GlobalClass.iSuccess = DAL.fnAddERPLog(0, poNumber, login.GetUserDetails[2], preparedDate, "PO Approved", "PurchaseOrder");
                       MessageBox.Show("'" + poNumber + "' approved", "Success", 0, MessageBoxIcon.Information);
                        FormReload();
                        //sPONumber = null;
                        lstusers.Items.Clear();
                        //FormReload();
            }

            //Vivek G
            else if (Convert.ToBoolean(login.GetUserDetails[85]) == true)
            {

                DataTable POGetALLdetails = DAL.POALLdetails(2, poNumber).Tables[0];
                DataTable currencyData = DAL.Currency_IN_INR(0, POGetALLdetails.Rows[0]["Currency"].ToString()).Tables[0];

                if (currencyData.Rows.Count > 0)
                {
                    // Convert the fetched rate to a double
                    double conversionRate = Convert.ToDouble(currencyData.Rows[0]["TO_INR"]);

                    // Step 2: Convert the total amount from label to double
                    DataTable TotalAmount = DAL.POALLdetails(3, poNumber).Tables[0];

                    double totalAmount = Convert.ToDouble(TotalAmount.Rows[0]["TotalAmount"].ToString());

                    // Step 3: Calculate the converted amount
                    double convertedAmount = totalAmount * conversionRate;
                    if (convertedAmount <= 50000)
                    {
                        GlobalClass.iSuccess = DAL.purchaseOrderApproval(19, poNumber, preparedDate, login.GetUserDetails[2], approvalRemarks);

                        GlobalClass.iSuccess = DAL.fnUpdatePoProcess(7, poNumber, login.GetUserDetails[2].ToString(), "", "");
                        //fnLoadComments();

                       // foreach (DataGridViewRow row in dgvPOGeneralTerms.Rows)
                       // {
                       //     GlobalClass.iSuccess = DAL.fnUpdatePoProcess(6, cmbPONO.Text, login.GetUserDetails[2].ToString(), "", row.Cells["POTerms"].Value.ToString().Trim());
                       // }

                        GlobalClass.iSuccess = DAL.fnAddERPLog(0, poNumber, login.GetUserDetails[2], preparedDate, "PO Approved", "PurchaseOrder");
                        //fnApprovetMail("Veena", txtRemarks.Text, lstusers, null);
                        fnAlertMailPOGenrate("Pavana", approvalRemarks, poNumber);
                        //   fnAlertMailPOGenrate("biss", txtRemarks.Text);
                        //fnApprovetMail("Veena", txtRemarks.Text, lstusers, null);
                        MessageBox.Show("PO " +poNumber+ " is approved & email alert sent to Pavana ", "Success", 0, MessageBoxIcon.Information);
                        //refreshTable();
                    }
                    else if (convertedAmount > 50000 && convertedAmount <= 250000)
                    {
                        GlobalClass.iSuccess = DAL.purchaseOrderApproval(19, poNumber, preparedDate, login.GetUserDetails[2], approvalRemarks);

                        GlobalClass.iSuccess = DAL.fnUpdatePoProcess(7, poNumber, login.GetUserDetails[2].ToString(), "", "");
                        //fnLoadComments();
                       // foreach (DataGridViewRow row in dgvPOGeneralTerms.Rows)
                       // {
                       //     GlobalClass.iSuccess = DAL.fnUpdatePoProcess(6, cmbPONO.Text, login.GetUserDetails[2].ToString(), "", row.Cells["POTerms"].Value.ToString().Trim());
                        //}

                        GlobalClass.iSuccess = DAL.fnAddERPLog(0, poNumber, login.GetUserDetails[2], preparedDate, "PO Approved", "PurchaseOrder");
                        
                       
                         
                        //    fnAlertMailPOGenrate("biss", txtRemarks.Text);
                        fnAlertMailPOGenrate("Pavana", approvalRemarks, poNumber);
                        MessageBox.Show("PO " + poNumber + " is approved & email alert sent to Pavana ", "Success", 0, MessageBoxIcon.Information);

                    }
                    else if (convertedAmount > 250000)
                    {
                        GlobalClass.iSuccess = DAL.purchaseOrderApproval(17, poNumber, preparedDate, login.GetUserDetails[2], approvalRemarks);

                        // fnLoadComments();
                        //  btnprintpo_Click(sender, e);

                        //fnAlertMailOM("shreeshail", txtRemarks.Text);
                        //fnApprovetMail("Hebbarrk", txtRemarks.Text, lstusers, null);
                        //  fnApprovetMail("biss", txtRemarks.Text, lstusers, null);

                        dtEMailID = DAL.PORemarksHistory(5, poNumber).Tables[0];
                        if (dtEMailID.Rows.Count > 0)
                        {

                            for (int i = 0; i < dtEMailID.Rows.Count; i++)
                            {
                                if (!lstusers.Items.Contains(dtEMailID.Rows[i]["emailid"].ToString()))
                                {
                                    lstusers.Items.Add(dtEMailID.Rows[i]["emailid"].ToString());
                                }
                            }
                            //fnApprovetMail("Veena", txtRemarks.Text, lstusers, null);
                            // fnApprovetMail("shreeshail", txtRemarks.Text, lstusers, null);
                        }

                        fnApprovetMail("Hebbarrk", approvalRemarks, lstusers, null, poNumber);
                        GlobalClass.iSuccess = DAL.fnAddERPLog(0, poNumber, login.GetUserDetails[2], preparedDate, "PO Approved", "PurchaseOrder");
                        MessageBox.Show("PO " +poNumber+ " is approved & email alert sent to Hebbarrk ", "Success", 0, MessageBoxIcon.Information);


                    }
                }
                //sPONumber = null;
                lstusers.Items.Clear();
                //FormReload();
            }

            //end



            //Test Lab


            //MuthuRamalingam



        }


        public void fnApprovetMail(string sUser, string sRemarks, ListBox sCC, string attachmentFilename, string PONumber)
        {
            DataTable PONoDetails = DAL.purchaseOrderList3(1, PONumber).Tables[0];


            // bMail = false;
            DataTable dtlogindetails = DAL.fnloginemail(sUser.Trim()).Tables[0];
            if (dtlogindetails.Rows.Count > 0)
            {
                if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
                {
                    Outlook.Application oApp = new Outlook.Application();
                    Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);

                    if (login.GetUserDetails[2] == "Hebbarrk")
                    {
                        oMsg.Subject = "" + PONumber + " approved";
                        oMsg.HTMLBody = " Dear " + sUser.ToUpper() + ", <br /><br /><font color='blue'> Purchase order " + PONumber + " approved </font>. <br /> Remarks : " + sRemarks + " <br /> <br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";
                    }

                    //<font color='red'>" + sSixMonthsMessage + "</font>

                    // else
                    // {
                    //  oMsg.Subject = "" + PONumber + " sent for GM approval";
                    //  oMsg.HTMLBody = " Dear " + sUser.ToUpper() + ", <br /><br /> Purchase order <font color='blue'>" + PONumber + " </font> sent for " + sGM + " approval. <font color='red'> " + sSixMonthsMessage + "<br /></font> Remarks : <br /> <br />";

                    //  oMsg.HTMLBody += GetTableFromDataGridWorkOrder();

                    // oMsg.HTMLBody += "<br /><br /><br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /><br /><br /><br /><br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";
                    //}
                    Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                    oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                    oRecips.ResolveAll();



                    try
                    {
                        if (File.Exists(attachmentFilename))
                        {
                            if (attachmentFilename != null)
                                oMsg.Attachments.Add(attachmentFilename);
                        }

                    }
                    catch (FileNotFoundException ex)
                    {
                        MessageBox.Show($"Attachment file not found: {ex.Message}");
                    }

                    if (sCC.Items.Count > 0)
                    {
                        Outlook.Recipient oRecip;
                        List<string> sCCRecipsList = new List<string>();
                        foreach (string tempTO in sCC.Items)
                        {
                            if (tempTO != null)
                                sCCRecipsList.Add(tempTO);
                        }
                        foreach (string t in sCCRecipsList)
                        {
                            oRecip = (Outlook.Recipient)oRecips.Add(t);
                            oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                            oRecip.Resolve();
                        }
                        oMsg.Send();
                        oRecip = null;
                    }
                    else
                    {
                        oMsg.Send();
                        oRecips = null;
                    }
                   // bMail = true;
                    oMsg = null;
                    oApp = null;
                }
            }
           // sGM = "";
        }

        public void fnAlertMailPOGenrate(string sUser, string sRemarks, string ponumber)
        {
            try
            {
                var bMail = false;
                DataTable dtlogindetails = DAL.fnloginemail(sUser).Tables[0]; ;
                if (dtlogindetails.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
                    {
                        Outlook.Application oApp = new Outlook.Application();
                        Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                        oMsg.Subject = "" + ponumber + " Sent for generating a purchase order.";
                        oMsg.HTMLBody = " Dear " + sUser.ToUpper() + ", <br /><br /> purchase order <font color='blue'>" + ponumber + "</font>  has been sent for processing.<br />  <br /> Remarks : " + sRemarks + " <br /> <br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";
                        // Add a recipient.
                        //<br /><b> <font color='red'>" + sSixMonthsMessage + "</font></b><br />
                        Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                        oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                        oRecips.ResolveAll();
                        // Send.
                        oMsg.Send();
                        bMail = true;
                        // Clean up.
                        oRecips = null;
                        oMsg = null;
                        oApp = null;
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void btnRejectPO_Click(string poNumber, string preparedDate, string approvalRemarks, string itemCode)
        {
            if (!string.IsNullOrEmpty(poNumber))
            {
                if (!string.IsNullOrEmpty(approvalRemarks.Trim()))
                {
                   
                    //--Vivek G
                    if (Convert.ToBoolean(login.GetUserDetails[85]) == true)
                    {
                        //ReviewEmail(PONoDetails.Rows[0]["PMName"].ToString(), txtRemarks.Text);
                        ReviewEmail("Pavana", approvalRemarks,poNumber);
                        GlobalClass.iSuccess = DAL.purchaseOrderGMOMAReject(29, poNumber, approvalRemarks, itemCode);
                       // sPONumber = null;
                        //FormReload();
                    }

                    //RAMAKRISHNA
                    else if (Convert.ToBoolean(login.GetUserDetails[30]) == true)
                    {
                        ReviewEmail("Pavana", approvalRemarks, poNumber);

                       

                        foreach (DataGridViewRow row in dgvDashBoard.Rows)
                        {

                            if (row.Cells[1].Value?.ToString() == poNumber &&
                                Convert.ToBoolean(row.Cells[12].Value))

                            {
                                GlobalClass.iSuccess = DAL.purchaseOrderGMOMAReject(29, poNumber, approvalRemarks, row.Cells[2].Value.ToString());
                               // MessageBox.Show($"{poNumber + " / " + row.Cells[2].Value.ToString()} selected...!");
                            }
                          //  else
                            //{
                            //    MessageBox.Show("Not selected...!");
                            //}
                            //MessageBox.Show(row.Cells[11].Value?.ToString());
                        }

                        FormReload();
                        //sPONumber = null;
                        //FormReload();
                    }

                }
                else
                {
                    MessageBox.Show("Please write review reason to review purachase order", "Error", 0, MessageBoxIcon.Error);
                    //txtRemarks.Focus();
                }
            }
            else
            {
                MessageBox.Show("Select PO Number to review purachase order", "Error", 0, MessageBoxIcon.Error);
            } 
        }

        private void ReviewEmail(string sUser, string sRemarks,string poNumber)
        {
            var bMail = false;
            DataTable dtlogindetails = DAL.fnloginemail(sUser).Tables[0];

            if (dtlogindetails.Rows.Count > 0)
            {
                if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
                {
                    Outlook.Application oApp = null;

                    // FIX: Load Outlook safely for all Office versions
                    try
                    {
                        oApp = Marshal.GetActiveObject("Outlook.Application") as Outlook.Application;
                    }
                    catch
                    {
                        oApp = new Outlook.Application();
                    }

                    Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);

                    oMsg.Subject = $"{poNumber} sent back for review";
                    oMsg.HTMLBody = $" Dear {sUser.ToUpper()}, <br /><br /><font color='red'> " +
                                    $"Purchase order {poNumber} sent back for review.<br/> <br/>" +
                                    $"Review reason : {sRemarks} </font><br /><br />Regards,<br />" +
                                    $"{login.GetUserDetails[2].ToUpper()}<br /><br />" +
                                    "<b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";

                    Outlook.Recipients oRecips = oMsg.Recipients;
                    oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                    oRecips.ResolveAll();

                    oMsg.Send();
                    bMail = true;

                    oRecips = null;
                    oMsg = null;
                    oApp = null;
                }
            }

            if (bMail)
            {
                MessageBox.Show($"Mail alert sent to '{sUser}' successfully!", "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void FormReload()
        {
            this.Hide();
            //Form.for PurchaseOrder = new Purchase_Order.PurchaseOrder();
            frmForm2 frm = new frmForm2();
            frm.Show();
            //PurchaseOrder.Show();
        }

        private void dgvDashBoard_EditingControlShowing(
                 object sender, DataGridViewEditingControlShowingEventArgs e)
                    {
                        if (dgvDashBoard.CurrentCell.OwningColumn.Name == "txtremarks")
                        {
                            TextBox tb = e.Control as TextBox;
                            if (tb != null)
                            {
                                tb.TextChanged -= Remarks_TextChanged; // prevent multiple calls
                                tb.TextChanged += Remarks_TextChanged;
                            }
                        }
                    }
            

        private void Remarks_TextChanged(object sender, EventArgs e)
        {
            TextBox tb = sender as TextBox;
            if (tb == null) return;

            DataGridViewRow row = dgvDashBoard.CurrentRow;
            if (row == null) return;

            string remarks = tb.Text;
            string docNumber = row.Cells["Doc Number"].Value?.ToString();
            bool isChecked = Convert.ToBoolean(row.Cells["chkSelect"].Value);

          //  if (isChecked)
            //{
                // Store remarks in grid cell
             //   row.Cells["txtremarks"].Value = remarks;

                // Example logic
             //    MessageBox.Show($"Doc: {docNumber}\nRemarks: {remarks}");
            //}

            foreach (DataGridViewRow rows in dgvDashBoard.Rows)
            {

                if (rows.Cells[1].Value?.ToString() == docNumber &&
                    Convert.ToBoolean(rows.Cells[12].Value))

                {
                    rows.Cells["txtremarks"].Value = remarks;
                   // MessageBox.Show($"Doc: {docNumber}\nRemarks: {remarks}");
                }
            }
        }







    }
}
