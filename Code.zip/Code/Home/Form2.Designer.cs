﻿namespace Erp_Project_With_Buttons
{
    partial class frmForm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmForm2));
            this.pnDashBoard = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dgvDashBoard = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbl6MonthLatePOs = new System.Windows.Forms.Label();
            this.lbl3MonthLatePOs = new System.Windows.Forms.Label();
            this.lbl1MonthLatePOs = new System.Windows.Forms.Label();
            this.lblLatePos = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblInstallationCompleted = new System.Windows.Forms.Label();
            this.lblShippedCount = new System.Windows.Forms.Label();
            this.lblLatestWIPCount = new System.Windows.Forms.Label();
            this.lblProjectCount = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.llSwitchUser = new System.Windows.Forms.LinkLabel();
            this.lblReturnedby = new System.Windows.Forms.Label();
            this.BottomToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.TopToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.RightToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.LeftToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.ContentPanel = new System.Windows.Forms.ToolStripContentPanel();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.indentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.vendorManagementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cityMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.customerMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.addItemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.standardCostUpdateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.targetCostToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itemLedgerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.InventoryLedgerToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.wARCalculationToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.productMasterBOMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.productMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vendorMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.fixedAssetMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.securityToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.securityInwardItemsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.outwardItemsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manualInwardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.issueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.productionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itemReturnToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.itemStockAdjustToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bOMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.kANBANBOMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itemLedgerToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.itemIssueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itemProductionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itemReturnToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.itemStockAdjustToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kANBANBOMToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.itemLedgerToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.sRFCalibrationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.purchaseOrderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newPurchaseOrderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newApproveWorkOrderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.projectMasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.indentToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.createProjectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateProjectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ProjectBOMtoolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ProjectBOMLockMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ProjectBOMChangesLogsMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ProjectProgressMenuItem = new System.Windows.Forms.ToolStripMenuItem();//ProjectProgressMenuItem
            this.projectBOMApproveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.projectInstallationStatuoUpdateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.projectShipmentDateUpdateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.projectTransferRequestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.projectTransferToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.projectDocumentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.projectQRCodeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tspProjectCLose = new System.Windows.Forms.ToolStripMenuItem();
            this.nCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.createNCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addEscalationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.capexProjectsUpdateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.capexProjectStatusUpdateToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.capexProjectDepartmentAccessPermissionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.orToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.packingListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.machinePassportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ProjectPackingListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.allERPReportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.customerVisitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enquiryRegisterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.opportunityDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pEGRateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SalesQuoteGenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.serviceQuoteGenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.testLabQuoteGENToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.serviceQuoteSparePartsGENToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.serviceCallManagerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.serviceOrderEntryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.gINToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itemIssueToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.itemReturnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pOWOInspectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reverseGINToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItemSIN = new System.Windows.Forms.ToolStripMenuItem();
            this.updateLedgerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.InventoryLedgerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.InventoryCycleCountMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.InventoryDashBoard = new System.Windows.Forms.ToolStripMenuItem();
            this.ItemLocationUpdateMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timeSheetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addTimeSheetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.machineUtilizationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timeSheetReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userManagementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewUserToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changePasswordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.requestSupportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.raiseRequestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userFeedbackToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.requestHistoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.poStatusToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DashboardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.WARCalculationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Sidebarpanel = new System.Windows.Forms.FlowLayoutPanel();
            this.lstusers = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.pnDashBoard.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDashBoard)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.Sidebarpanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnDashBoard
            // 
            this.pnDashBoard.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnDashBoard.BackColor = System.Drawing.Color.LightGray;
            this.pnDashBoard.Controls.Add(this.panel3);
            this.pnDashBoard.Controls.Add(this.panel2);
            this.pnDashBoard.Controls.Add(this.panel1);
            this.pnDashBoard.Controls.Add(this.label1);
            this.pnDashBoard.Location = new System.Drawing.Point(199, 0);
            this.pnDashBoard.Name = "pnDashBoard";
            this.pnDashBoard.Size = new System.Drawing.Size(1139, 599);
            this.pnDashBoard.TabIndex = 33;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.dgvDashBoard);
            this.panel3.Location = new System.Drawing.Point(0, 175);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1139, 421);
            this.panel3.TabIndex = 203;
            // 
            // dgvDashBoard
            // 
            this.dgvDashBoard.AllowUserToAddRows = false;
            this.dgvDashBoard.AllowUserToDeleteRows = false;
            this.dgvDashBoard.AllowUserToOrderColumns = true;
            this.dgvDashBoard.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvDashBoard.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDashBoard.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvDashBoard.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDashBoard.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvDashBoard.Location = new System.Drawing.Point(1, 3);
            this.dgvDashBoard.Name = "dgvDashBoard";
            this.dgvDashBoard.ReadOnly = true;
            this.dgvDashBoard.RowHeadersVisible = false;
            this.dgvDashBoard.RowHeadersWidth = 62;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvDashBoard.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvDashBoard.RowTemplate.Height = 25;
            this.dgvDashBoard.Size = new System.Drawing.Size(1138, 415);
            this.dgvDashBoard.TabIndex = 198;
            this.toolTip1.SetToolTip(this.dgvDashBoard, "Double click to proceed");
            this.dgvDashBoard.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDashBoard_CellClick);
            this.dgvDashBoard.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDashBoard_CellContentClick);
            this.dgvDashBoard.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDashBoard_CellDoubleClick);
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.LightCoral;
            this.panel2.Controls.Add(this.lbl6MonthLatePOs);
            this.panel2.Controls.Add(this.lbl3MonthLatePOs);
            this.panel2.Controls.Add(this.lbl1MonthLatePOs);
            this.panel2.Controls.Add(this.lblLatePos);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Location = new System.Drawing.Point(696, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(440, 129);
            this.panel2.TabIndex = 202;
            // 
            // lbl6MonthLatePOs
            // 
            this.lbl6MonthLatePOs.AutoSize = true;
            this.lbl6MonthLatePOs.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl6MonthLatePOs.ForeColor = System.Drawing.Color.Black;
            this.lbl6MonthLatePOs.Location = new System.Drawing.Point(4, 104);
            this.lbl6MonthLatePOs.Name = "lbl6MonthLatePOs";
            this.lbl6MonthLatePOs.Size = new System.Drawing.Size(40, 23);
            this.lbl6MonthLatePOs.TabIndex = 39;
            this.lbl6MonthLatePOs.Text = "256";
            this.lbl6MonthLatePOs.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lbl3MonthLatePOs
            // 
            this.lbl3MonthLatePOs.AutoSize = true;
            this.lbl3MonthLatePOs.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3MonthLatePOs.ForeColor = System.Drawing.Color.Black;
            this.lbl3MonthLatePOs.Location = new System.Drawing.Point(3, 83);
            this.lbl3MonthLatePOs.Name = "lbl3MonthLatePOs";
            this.lbl3MonthLatePOs.Size = new System.Drawing.Size(40, 23);
            this.lbl3MonthLatePOs.TabIndex = 38;
            this.lbl3MonthLatePOs.Text = "256";
            this.lbl3MonthLatePOs.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lbl1MonthLatePOs
            // 
            this.lbl1MonthLatePOs.AutoSize = true;
            this.lbl1MonthLatePOs.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1MonthLatePOs.ForeColor = System.Drawing.Color.Black;
            this.lbl1MonthLatePOs.Location = new System.Drawing.Point(3, 62);
            this.lbl1MonthLatePOs.Name = "lbl1MonthLatePOs";
            this.lbl1MonthLatePOs.Size = new System.Drawing.Size(40, 23);
            this.lbl1MonthLatePOs.TabIndex = 37;
            this.lbl1MonthLatePOs.Text = "256";
            this.lbl1MonthLatePOs.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblLatePos
            // 
            this.lblLatePos.AutoSize = true;
            this.lblLatePos.Font = new System.Drawing.Font("Calibri", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLatePos.ForeColor = System.Drawing.Color.Black;
            this.lblLatePos.Location = new System.Drawing.Point(-1, 23);
            this.lblLatePos.Name = "lblLatePos";
            this.lblLatePos.Size = new System.Drawing.Size(77, 45);
            this.lblLatePos.TabIndex = 36;
            this.lblLatePos.Text = "256";
            this.lblLatePos.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(5, 4);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(241, 19);
            this.label6.TabIndex = 35;
            this.label6.Text = "Total Pending Purchase Order Items";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(340, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(48, 48);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.PaleGreen;
            this.panel1.Controls.Add(this.lblInstallationCompleted);
            this.panel1.Controls.Add(this.lblShippedCount);
            this.panel1.Controls.Add(this.lblLatestWIPCount);
            this.panel1.Controls.Add(this.lblProjectCount);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(472, 129);
            this.panel1.TabIndex = 201;
            // 
            // lblInstallationCompleted
            // 
            this.lblInstallationCompleted.AutoSize = true;
            this.lblInstallationCompleted.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstallationCompleted.ForeColor = System.Drawing.Color.Black;
            this.lblInstallationCompleted.Location = new System.Drawing.Point(4, 104);
            this.lblInstallationCompleted.Name = "lblInstallationCompleted";
            this.lblInstallationCompleted.Size = new System.Drawing.Size(40, 23);
            this.lblInstallationCompleted.TabIndex = 39;
            this.lblInstallationCompleted.Text = "256";
            this.lblInstallationCompleted.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblShippedCount
            // 
            this.lblShippedCount.AutoSize = true;
            this.lblShippedCount.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShippedCount.ForeColor = System.Drawing.Color.Black;
            this.lblShippedCount.Location = new System.Drawing.Point(4, 82);
            this.lblShippedCount.Name = "lblShippedCount";
            this.lblShippedCount.Size = new System.Drawing.Size(40, 23);
            this.lblShippedCount.TabIndex = 38;
            this.lblShippedCount.Text = "256";
            this.lblShippedCount.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblLatestWIPCount
            // 
            this.lblLatestWIPCount.AutoSize = true;
            this.lblLatestWIPCount.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLatestWIPCount.ForeColor = System.Drawing.Color.Black;
            this.lblLatestWIPCount.Location = new System.Drawing.Point(4, 60);
            this.lblLatestWIPCount.Name = "lblLatestWIPCount";
            this.lblLatestWIPCount.Size = new System.Drawing.Size(40, 23);
            this.lblLatestWIPCount.TabIndex = 37;
            this.lblLatestWIPCount.Text = "256";
            this.lblLatestWIPCount.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblProjectCount
            // 
            this.lblProjectCount.AutoSize = true;
            this.lblProjectCount.Font = new System.Drawing.Font("Calibri", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectCount.ForeColor = System.Drawing.Color.Black;
            this.lblProjectCount.Location = new System.Drawing.Point(1, 21);
            this.lblProjectCount.Name = "lblProjectCount";
            this.lblProjectCount.Size = new System.Drawing.Size(77, 45);
            this.lblProjectCount.TabIndex = 36;
            this.lblProjectCount.Text = "256";
            this.lblProjectCount.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(5, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 19);
            this.label3.TabIndex = 35;
            this.label3.Text = "Total WIP Projects";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(340, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 48);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(-1, 143);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(201, 29);
            this.label1.TabIndex = 200;
            this.label1.Text = "Pending Approvals";
            // 
            // llSwitchUser
            // 
            this.llSwitchUser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.llSwitchUser.AutoSize = true;
            this.llSwitchUser.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llSwitchUser.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.llSwitchUser.LinkColor = System.Drawing.Color.Red;
            this.llSwitchUser.Location = new System.Drawing.Point(1244, 626);
            this.llSwitchUser.Name = "llSwitchUser";
            this.llSwitchUser.Size = new System.Drawing.Size(71, 26);
            this.llSwitchUser.TabIndex = 10;
            this.llSwitchUser.TabStop = true;
            this.llSwitchUser.Text = "Logout";
            this.llSwitchUser.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.toolTip1.SetToolTip(this.llSwitchUser, "Click Here To Change The User");
            this.llSwitchUser.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llSwitchUser_LinkClicked_1);
            // 
            // lblReturnedby
            // 
            this.lblReturnedby.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblReturnedby.AutoSize = true;
            this.lblReturnedby.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturnedby.ForeColor = System.Drawing.Color.Indigo;
            this.lblReturnedby.Location = new System.Drawing.Point(304, 626);
            this.lblReturnedby.Name = "lblReturnedby";
            this.lblReturnedby.Size = new System.Drawing.Size(27, 23);
            this.lblReturnedby.TabIndex = 21;
            this.lblReturnedby.Text = "W";
            this.lblReturnedby.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // BottomToolStripPanel
            // 
            this.BottomToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.BottomToolStripPanel.Name = "BottomToolStripPanel";
            this.BottomToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.BottomToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.BottomToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // TopToolStripPanel
            // 
            this.TopToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.TopToolStripPanel.Name = "TopToolStripPanel";
            this.TopToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.TopToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.TopToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // RightToolStripPanel
            // 
            this.RightToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.RightToolStripPanel.Name = "RightToolStripPanel";
            this.RightToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.RightToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.RightToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // LeftToolStripPanel
            // 
            this.LeftToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.LeftToolStripPanel.Name = "LeftToolStripPanel";
            this.LeftToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.LeftToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.LeftToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // ContentPanel
            // 
            this.ContentPanel.Size = new System.Drawing.Size(150, 175);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.indentToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(109, 26);
            // 
            // indentToolStripMenuItem
            // 
            this.indentToolStripMenuItem.Name = "indentToolStripMenuItem";
            this.indentToolStripMenuItem.Size = new System.Drawing.Size(108, 22);
            this.indentToolStripMenuItem.Text = "Indent";
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuStrip1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.vendorManagementToolStripMenuItem,
            this.toolStripMenuItem3,
            this.securityToolStripMenuItem,
            this.toolStripMenuItem8,
            this.purchaseOrderToolStripMenuItem,
            this.projectMasterToolStripMenuItem,
            this.reportsToolStripMenuItem2,
            this.toolStripMenuItem6,
            this.toolStripMenuItem7,
            this.toolStripMenuItem2,
            this.timeSheetToolStripMenuItem,
            this.userManagementToolStripMenuItem});
            this.menuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(196, 330);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // vendorManagementToolStripMenuItem
            // 
            this.vendorManagementToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cityMasterToolStripMenuItem,
            this.customerMasterToolStripMenuItem,
            this.toolStripMenuItem1,
            this.productMasterBOMToolStripMenuItem,
            this.productMasterToolStripMenuItem,
            this.vendorMasterToolStripMenuItem});
            this.vendorManagementToolStripMenuItem.Name = "vendorManagementToolStripMenuItem";
            this.vendorManagementToolStripMenuItem.Size = new System.Drawing.Size(183, 27);
            this.vendorManagementToolStripMenuItem.Text = "ERP Masters";
            this.vendorManagementToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cityMasterToolStripMenuItem
            // 
            this.cityMasterToolStripMenuItem.Name = "cityMasterToolStripMenuItem";
            this.cityMasterToolStripMenuItem.Size = new System.Drawing.Size(249, 28);
            this.cityMasterToolStripMenuItem.Text = "City Master";
            this.cityMasterToolStripMenuItem.Click += new System.EventHandler(this.cityMasterToolStripMenuItem_Click);
            // 
            // customerMasterToolStripMenuItem
            // 
            this.customerMasterToolStripMenuItem.Name = "customerMasterToolStripMenuItem";
            this.customerMasterToolStripMenuItem.Size = new System.Drawing.Size(249, 28);
            this.customerMasterToolStripMenuItem.Text = "Customer Master";
            this.customerMasterToolStripMenuItem.Click += new System.EventHandler(this.customerMasterToolStripMenuItem_Click_1);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addItemToolStripMenuItem,
            this.standardCostUpdateToolStripMenuItem,
            this.targetCostToolStripMenuItem,
            this.itemLedgerToolStripMenuItem,
            this.InventoryLedgerToolStripMenuItem2,
            this.wARCalculationToolStripMenuItem1});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(249, 28);
            this.toolStripMenuItem1.Text = "Item Master";
            this.toolStripMenuItem1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // addItemToolStripMenuItem
            // 
            this.addItemToolStripMenuItem.Name = "addItemToolStripMenuItem";
            this.addItemToolStripMenuItem.Size = new System.Drawing.Size(227, 28);
            this.addItemToolStripMenuItem.Text = "Add / Update Item";
            this.addItemToolStripMenuItem.Click += new System.EventHandler(this.addItemToolStripMenuItem_Click_1);
            // 
            // standardCostUpdateToolStripMenuItem
            // 
            this.standardCostUpdateToolStripMenuItem.Name = "standardCostUpdateToolStripMenuItem";
            this.standardCostUpdateToolStripMenuItem.Size = new System.Drawing.Size(227, 28);
            this.standardCostUpdateToolStripMenuItem.Text = "Standard Cost";
            this.standardCostUpdateToolStripMenuItem.Click += new System.EventHandler(this.standardCostUpdateToolStripMenuItem_Click);
            // 
            // targetCostToolStripMenuItem
            // 
            this.targetCostToolStripMenuItem.Name = "targetCostToolStripMenuItem";
            this.targetCostToolStripMenuItem.Size = new System.Drawing.Size(227, 28);
            this.targetCostToolStripMenuItem.Text = "Target Cost";
            this.targetCostToolStripMenuItem.Click += new System.EventHandler(this.targetCostToolStripMenuItem_Click);
            // 
            // itemLedgerToolStripMenuItem
            // 
            this.itemLedgerToolStripMenuItem.Name = "itemLedgerToolStripMenuItem";
            this.itemLedgerToolStripMenuItem.Size = new System.Drawing.Size(227, 28);
            this.itemLedgerToolStripMenuItem.Text = "Item Ledger";
            this.itemLedgerToolStripMenuItem.Click += new System.EventHandler(this.itemLedgerToolStripMenuItem_Click);
            // 
            // InventoryLedgerToolStripMenuItem2
            // 
            this.InventoryLedgerToolStripMenuItem2.Name = "InventoryLedgerToolStripMenuItem2";
            this.InventoryLedgerToolStripMenuItem2.Size = new System.Drawing.Size(227, 28);
            this.InventoryLedgerToolStripMenuItem2.Text = "Inventory Ledger";
            this.InventoryLedgerToolStripMenuItem2.Click += new System.EventHandler(this.InventoryLedgerToolStripMenuItem2_Click);
            // 
            // wARCalculationToolStripMenuItem1
            // 
            this.wARCalculationToolStripMenuItem1.Name = "wARCalculationToolStripMenuItem1";
            this.wARCalculationToolStripMenuItem1.Size = new System.Drawing.Size(227, 28);
            this.wARCalculationToolStripMenuItem1.Text = "WAR Report";
            this.wARCalculationToolStripMenuItem1.Click += new System.EventHandler(this.wARCalculationToolStripMenuItem1_Click);
            // 
            // productMasterBOMToolStripMenuItem
            // 
            this.productMasterBOMToolStripMenuItem.Name = "productMasterBOMToolStripMenuItem";
            this.productMasterBOMToolStripMenuItem.Size = new System.Drawing.Size(249, 28);
            this.productMasterBOMToolStripMenuItem.Text = "Product Master BOM";
            this.productMasterBOMToolStripMenuItem.Click += new System.EventHandler(this.productMasterBOMToolStripMenuItem_Click_1);
            // 
            // productMasterToolStripMenuItem
            // 
            this.productMasterToolStripMenuItem.Name = "productMasterToolStripMenuItem";
            this.productMasterToolStripMenuItem.Size = new System.Drawing.Size(249, 28);
            this.productMasterToolStripMenuItem.Text = "Sales Product Master";
            this.productMasterToolStripMenuItem.Click += new System.EventHandler(this.productMasterToolStripMenuItem_Click_1);
            // 
            // vendorMasterToolStripMenuItem
            // 
            this.vendorMasterToolStripMenuItem.Name = "vendorMasterToolStripMenuItem";
            this.vendorMasterToolStripMenuItem.Size = new System.Drawing.Size(249, 28);
            this.vendorMasterToolStripMenuItem.Text = "Vendor Master";
            this.vendorMasterToolStripMenuItem.Click += new System.EventHandler(this.vendorMasterToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fixedAssetMasterToolStripMenuItem});
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(183, 27);
            this.toolStripMenuItem3.Text = "Fixed Assets";
            this.toolStripMenuItem3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // fixedAssetMasterToolStripMenuItem
            // 
            this.fixedAssetMasterToolStripMenuItem.Name = "fixedAssetMasterToolStripMenuItem";
            this.fixedAssetMasterToolStripMenuItem.Size = new System.Drawing.Size(282, 28);
            this.fixedAssetMasterToolStripMenuItem.Text = "Add / Update Fixed Asset";
            this.fixedAssetMasterToolStripMenuItem.Click += new System.EventHandler(this.fixedAssetMasterToolStripMenuItem_Click);
            // 
            // securityToolStripMenuItem
            // 
            this.securityToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.securityInwardItemsToolStripMenuItem,
            this.outwardItemsToolStripMenuItem,
            this.manualInwardToolStripMenuItem,
            this.reportsToolStripMenuItem3});
            this.securityToolStripMenuItem.Name = "securityToolStripMenuItem";
            this.securityToolStripMenuItem.Size = new System.Drawing.Size(183, 27);
            this.securityToolStripMenuItem.Text = "Gate Entry";
            this.securityToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.securityToolStripMenuItem.Click += new System.EventHandler(this.securityToolStripMenuItem_Click);
            // 
            // securityInwardItemsToolStripMenuItem
            // 
            this.securityInwardItemsToolStripMenuItem.Name = "securityInwardItemsToolStripMenuItem";
            this.securityInwardItemsToolStripMenuItem.Size = new System.Drawing.Size(241, 28);
            this.securityInwardItemsToolStripMenuItem.Text = "Gate Inward Items";
            this.securityInwardItemsToolStripMenuItem.Click += new System.EventHandler(this.securityInwardItemsToolStripMenuItem_Click);
            // 
            // outwardItemsToolStripMenuItem
            // 
            this.outwardItemsToolStripMenuItem.Name = "outwardItemsToolStripMenuItem";
            this.outwardItemsToolStripMenuItem.Size = new System.Drawing.Size(241, 28);
            this.outwardItemsToolStripMenuItem.Text = "Gate Outward Items";
            this.outwardItemsToolStripMenuItem.Click += new System.EventHandler(this.outwardItemsToolStripMenuItem_Click);
            // 
            // manualInwardToolStripMenuItem
            // 
            this.manualInwardToolStripMenuItem.Name = "manualInwardToolStripMenuItem";
            this.manualInwardToolStripMenuItem.Size = new System.Drawing.Size(241, 28);
            this.manualInwardToolStripMenuItem.Text = "Gate Manual Inward";
            this.manualInwardToolStripMenuItem.Click += new System.EventHandler(this.manualInwardToolStripMenuItem_Click);
            // 
            // reportsToolStripMenuItem3
            // 
            this.reportsToolStripMenuItem3.Name = "reportsToolStripMenuItem3";
            this.reportsToolStripMenuItem3.Size = new System.Drawing.Size(241, 28);
            this.reportsToolStripMenuItem3.Text = "Reports";
            this.reportsToolStripMenuItem3.Click += new System.EventHandler(this.reportsToolStripMenuItem3_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem4,
            this.toolStripMenuItem5,
            this.sRFCalibrationToolStripMenuItem});
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(183, 27);
            this.toolStripMenuItem8.Text = "Kanban Management";
            this.toolStripMenuItem8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.issueToolStripMenuItem,
            this.productionToolStripMenuItem,
            this.itemReturnToolStripMenuItem1,
            this.itemStockAdjustToolStripMenuItem,
            this.bOMToolStripMenuItem,
            this.reportsToolStripMenuItem1,
            this.kANBANBOMToolStripMenuItem,
            this.itemLedgerToolStripMenuItem1});
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(237, 28);
            this.toolStripMenuItem4.Text = "Kanban Electronics";
            this.toolStripMenuItem4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // issueToolStripMenuItem
            // 
            this.issueToolStripMenuItem.Name = "issueToolStripMenuItem";
            this.issueToolStripMenuItem.Size = new System.Drawing.Size(237, 28);
            this.issueToolStripMenuItem.Text = "Item Issue";
            this.issueToolStripMenuItem.Click += new System.EventHandler(this.issueToolStripMenuItem_Click);
            // 
            // productionToolStripMenuItem
            // 
            this.productionToolStripMenuItem.Name = "productionToolStripMenuItem";
            this.productionToolStripMenuItem.Size = new System.Drawing.Size(237, 28);
            this.productionToolStripMenuItem.Text = "Item Production";
            this.productionToolStripMenuItem.Click += new System.EventHandler(this.productionToolStripMenuItem_Click);
            // 
            // itemReturnToolStripMenuItem1
            // 
            this.itemReturnToolStripMenuItem1.Name = "itemReturnToolStripMenuItem1";
            this.itemReturnToolStripMenuItem1.Size = new System.Drawing.Size(237, 28);
            this.itemReturnToolStripMenuItem1.Text = "Item Return";
            this.itemReturnToolStripMenuItem1.Click += new System.EventHandler(this.itemReturnToolStripMenuItem1_Click);
            // 
            // itemStockAdjustToolStripMenuItem
            // 
            this.itemStockAdjustToolStripMenuItem.Name = "itemStockAdjustToolStripMenuItem";
            this.itemStockAdjustToolStripMenuItem.Size = new System.Drawing.Size(237, 28);
            this.itemStockAdjustToolStripMenuItem.Text = "Item Stock Adjust";
            this.itemStockAdjustToolStripMenuItem.Click += new System.EventHandler(this.itemStockAdjustToolStripMenuItem_Click);
            // 
            // bOMToolStripMenuItem
            // 
            this.bOMToolStripMenuItem.Name = "bOMToolStripMenuItem";
            this.bOMToolStripMenuItem.Size = new System.Drawing.Size(237, 28);
            this.bOMToolStripMenuItem.Text = "Electronics BOM";
            this.bOMToolStripMenuItem.Click += new System.EventHandler(this.bOMToolStripMenuItem_Click);
            // 
            // reportsToolStripMenuItem1
            // 
            this.reportsToolStripMenuItem1.Name = "reportsToolStripMenuItem1";
            this.reportsToolStripMenuItem1.Size = new System.Drawing.Size(237, 28);
            this.reportsToolStripMenuItem1.Text = "Reports";
            this.reportsToolStripMenuItem1.Click += new System.EventHandler(this.reportsToolStripMenuItem1_Click);
            // 
            // kANBANBOMToolStripMenuItem
            // 
            this.kANBANBOMToolStripMenuItem.Name = "kANBANBOMToolStripMenuItem";
            this.kANBANBOMToolStripMenuItem.Size = new System.Drawing.Size(237, 28);
            this.kANBANBOMToolStripMenuItem.Text = "Kanban BOM";
            this.kANBANBOMToolStripMenuItem.Click += new System.EventHandler(this.kANBANBOMToolStripMenuItem_Click_1);
            // 
            // itemLedgerToolStripMenuItem1
            // 
            this.itemLedgerToolStripMenuItem1.Name = "itemLedgerToolStripMenuItem1";
            this.itemLedgerToolStripMenuItem1.Size = new System.Drawing.Size(237, 28);
            this.itemLedgerToolStripMenuItem1.Text = "Kanban Item Ledger";
            this.itemLedgerToolStripMenuItem1.Click += new System.EventHandler(this.itemLedgerToolStripMenuItem1_Click_1);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itemIssueToolStripMenuItem,
            this.itemProductionToolStripMenuItem,
            this.itemReturnToolStripMenuItem2,
            this.itemStockAdjustToolStripMenuItem1,
            this.reportsToolStripMenuItem,
            this.kANBANBOMToolStripMenuItem1,
            this.itemLedgerToolStripMenuItem2});
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(237, 28);
            this.toolStripMenuItem5.Text = "Kanban Transducers";
            this.toolStripMenuItem5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // itemIssueToolStripMenuItem
            // 
            this.itemIssueToolStripMenuItem.Name = "itemIssueToolStripMenuItem";
            this.itemIssueToolStripMenuItem.Size = new System.Drawing.Size(237, 28);
            this.itemIssueToolStripMenuItem.Text = "Item Issue";
            this.itemIssueToolStripMenuItem.Click += new System.EventHandler(this.itemIssueToolStripMenuItem_Click);
            // 
            // itemProductionToolStripMenuItem
            // 
            this.itemProductionToolStripMenuItem.Name = "itemProductionToolStripMenuItem";
            this.itemProductionToolStripMenuItem.Size = new System.Drawing.Size(237, 28);
            this.itemProductionToolStripMenuItem.Text = "Item Production";
            this.itemProductionToolStripMenuItem.Click += new System.EventHandler(this.itemProductionToolStripMenuItem_Click);
            // 
            // itemReturnToolStripMenuItem2
            // 
            this.itemReturnToolStripMenuItem2.Name = "itemReturnToolStripMenuItem2";
            this.itemReturnToolStripMenuItem2.Size = new System.Drawing.Size(237, 28);
            this.itemReturnToolStripMenuItem2.Text = "Item Return";
            this.itemReturnToolStripMenuItem2.Click += new System.EventHandler(this.itemReturnToolStripMenuItem2_Click);
            // 
            // itemStockAdjustToolStripMenuItem1
            // 
            this.itemStockAdjustToolStripMenuItem1.Name = "itemStockAdjustToolStripMenuItem1";
            this.itemStockAdjustToolStripMenuItem1.Size = new System.Drawing.Size(237, 28);
            this.itemStockAdjustToolStripMenuItem1.Text = "Item Stock Adjust";
            this.itemStockAdjustToolStripMenuItem1.Click += new System.EventHandler(this.itemStockAdjustToolStripMenuItem1_Click);
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(237, 28);
            this.reportsToolStripMenuItem.Text = "Reports";
            this.reportsToolStripMenuItem.Click += new System.EventHandler(this.reportsToolStripMenuItem_Click);
            // 
            // kANBANBOMToolStripMenuItem1
            // 
            this.kANBANBOMToolStripMenuItem1.Name = "kANBANBOMToolStripMenuItem1";
            this.kANBANBOMToolStripMenuItem1.Size = new System.Drawing.Size(237, 28);
            this.kANBANBOMToolStripMenuItem1.Text = "Kanban BOM";
            this.kANBANBOMToolStripMenuItem1.Click += new System.EventHandler(this.kANBANBOMToolStripMenuItem1_Click);
            // 
            // itemLedgerToolStripMenuItem2
            // 
            this.itemLedgerToolStripMenuItem2.Name = "itemLedgerToolStripMenuItem2";
            this.itemLedgerToolStripMenuItem2.Size = new System.Drawing.Size(237, 28);
            this.itemLedgerToolStripMenuItem2.Text = "Kanban Item Ledger";
            this.itemLedgerToolStripMenuItem2.Click += new System.EventHandler(this.itemLedgerToolStripMenuItem2_Click);
            // 
            // sRFCalibrationToolStripMenuItem
            // 
            this.sRFCalibrationToolStripMenuItem.Name = "sRFCalibrationToolStripMenuItem";
            this.sRFCalibrationToolStripMenuItem.Size = new System.Drawing.Size(237, 28);
            this.sRFCalibrationToolStripMenuItem.Text = "SRF Calibration";
            this.sRFCalibrationToolStripMenuItem.Click += new System.EventHandler(this.sRFCalibrationToolStripMenuItem_Click);
            // 
            // purchaseOrderToolStripMenuItem
            // 
            this.purchaseOrderToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newPurchaseOrderToolStripMenuItem,
            this.newApproveWorkOrderToolStripMenuItem});
            this.purchaseOrderToolStripMenuItem.Name = "purchaseOrderToolStripMenuItem";
            this.purchaseOrderToolStripMenuItem.Size = new System.Drawing.Size(183, 27);
            this.purchaseOrderToolStripMenuItem.Text = "Procurement";
            this.purchaseOrderToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.purchaseOrderToolStripMenuItem.Click += new System.EventHandler(this.purchaseOrderToolStripMenuItem_Click);
            // 
            // newPurchaseOrderToolStripMenuItem
            // 
            this.newPurchaseOrderToolStripMenuItem.Name = "newPurchaseOrderToolStripMenuItem";
            this.newPurchaseOrderToolStripMenuItem.Size = new System.Drawing.Size(203, 28);
            this.newPurchaseOrderToolStripMenuItem.Text = "Purchase Order";
            this.newPurchaseOrderToolStripMenuItem.Click += new System.EventHandler(this.newPurchaseOrderToolStripMenuItem_Click);
            // 
            // newApproveWorkOrderToolStripMenuItem
            // 
            this.newApproveWorkOrderToolStripMenuItem.Name = "newApproveWorkOrderToolStripMenuItem";
            this.newApproveWorkOrderToolStripMenuItem.Size = new System.Drawing.Size(203, 28);
            this.newApproveWorkOrderToolStripMenuItem.Text = "Work Order";
            this.newApproveWorkOrderToolStripMenuItem.Click += new System.EventHandler(this.newApproveWorkOrderToolStripMenuItem_Click);
            // 
            // projectMasterToolStripMenuItem
            // 
            this.projectMasterToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.indentToolStripMenuItem2,
            this.createProjectToolStripMenuItem,
            this.updateProjectToolStripMenuItem,
            this.ProjectBOMtoolStripMenuItem,
            this.ProjectBOMLockMenuItem,
            this.ProjectBOMChangesLogsMenuItem,
            this.projectBOMApproveToolStripMenuItem,
            this.projectInstallationStatuoUpdateToolStripMenuItem,
            this.projectShipmentDateUpdateToolStripMenuItem,
            this.projectTransferRequestToolStripMenuItem,
            this.projectTransferToolStripMenuItem,
            this.projectDocumentsToolStripMenuItem,
            this.projectQRCodeToolStripMenuItem,
            this.tspProjectCLose,
            this.nCToolStripMenuItem,
            this.capexProjectsUpdateToolStripMenuItem,
            this.orToolStripMenuItem,
            this.packingListToolStripMenuItem,
            this.machinePassportToolStripMenuItem,
            this.ProjectPackingListToolStripMenuItem,
            this.ProjectProgressMenuItem});
            this.projectMasterToolStripMenuItem.Name = "projectMasterToolStripMenuItem";
            this.projectMasterToolStripMenuItem.Size = new System.Drawing.Size(183, 27);
            this.projectMasterToolStripMenuItem.Text = "Project Management";
            this.projectMasterToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.projectMasterToolStripMenuItem.Click += new System.EventHandler(this.projectMasterToolStripMenuItem_Click);
            // 
            // indentToolStripMenuItem2
            // 
            this.indentToolStripMenuItem2.Name = "indentToolStripMenuItem2";
            this.indentToolStripMenuItem2.Size = new System.Drawing.Size(406, 28);
            this.indentToolStripMenuItem2.Text = "Indent";
            this.indentToolStripMenuItem2.Click += new System.EventHandler(this.indentToolStripMenuItem2_Click_2);
            // 
            // createProjectToolStripMenuItem
            // 
            this.createProjectToolStripMenuItem.Name = "createProjectToolStripMenuItem";
            this.createProjectToolStripMenuItem.Size = new System.Drawing.Size(406, 28);
            this.createProjectToolStripMenuItem.Text = "Project Create / Approve";
            this.createProjectToolStripMenuItem.Click += new System.EventHandler(this.createProjectToolStripMenuItem_Click);
            // 
            // updateProjectToolStripMenuItem
            // 
            this.updateProjectToolStripMenuItem.Name = "updateProjectToolStripMenuItem";
            this.updateProjectToolStripMenuItem.Size = new System.Drawing.Size(406, 28);
            this.updateProjectToolStripMenuItem.Text = "Project Create Warranty / Shortshipment";
            this.updateProjectToolStripMenuItem.Click += new System.EventHandler(this.updateProjectToolStripMenuItem_Click);
            // 
            // ProjectBOMtoolStripMenuItem
            // 
            this.ProjectBOMtoolStripMenuItem.Name = "ProjectBOMtoolStripMenuItem";
            this.ProjectBOMtoolStripMenuItem.Size = new System.Drawing.Size(406, 28);
            this.ProjectBOMtoolStripMenuItem.Text = "Project BOM";
            this.ProjectBOMtoolStripMenuItem.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // ProjectBOMLockMenuItem
            // 
            this.ProjectBOMLockMenuItem.Name = "ProjectBOMLockMenuItem";
            this.ProjectBOMLockMenuItem.Size = new System.Drawing.Size(406, 28);
            this.ProjectBOMLockMenuItem.Text = "Project BOM Lock/Unlock";
            this.ProjectBOMLockMenuItem.Click += new System.EventHandler(this.ProjectBOMLockMenuItem_Click);
            // 
            // ProjectBOMChangesLogsMenuItem
            // 
            this.ProjectBOMChangesLogsMenuItem.Name = "ProjectBOMChangesLogsMenuItem";
            this.ProjectBOMChangesLogsMenuItem.Size = new System.Drawing.Size(406, 28);
            this.ProjectBOMChangesLogsMenuItem.Text = "Project BOM Changes Logs";
            this.ProjectBOMChangesLogsMenuItem.Click += new System.EventHandler(this.ProjectBOMChangesLogsMenuItem_Click);

            // 
            // ProjectBOMChangesLogsMenuItem
            // 
            this.ProjectProgressMenuItem.Name = "ProjectProgressMenuItem";
            this.ProjectProgressMenuItem.Size = new System.Drawing.Size(406, 28);
            this.ProjectProgressMenuItem.Text = "Project Progress";
            this.ProjectProgressMenuItem.Click += new System.EventHandler(this.ProjectProgressMenuItem_Click);
            // 
            // projectBOMApproveToolStripMenuItem
            // 
            this.projectBOMApproveToolStripMenuItem.Name = "projectBOMApproveToolStripMenuItem";
            this.projectBOMApproveToolStripMenuItem.Size = new System.Drawing.Size(406, 28);
            this.projectBOMApproveToolStripMenuItem.Text = "Project BOM Approve";
            this.projectBOMApproveToolStripMenuItem.Click += new System.EventHandler(this.projectBOMApproveToolStripMenuItem_Click);
            // 
            // projectInstallationStatuoUpdateToolStripMenuItem
            // 
            this.projectInstallationStatuoUpdateToolStripMenuItem.Name = "projectInstallationStatuoUpdateToolStripMenuItem";
            this.projectInstallationStatuoUpdateToolStripMenuItem.Size = new System.Drawing.Size(406, 28);
            this.projectInstallationStatuoUpdateToolStripMenuItem.Text = "Project Installation Status Update";
            this.projectInstallationStatuoUpdateToolStripMenuItem.Click += new System.EventHandler(this.projectInstallationStatuoUpdateToolStripMenuItem_Click);
            // 
            // projectShipmentDateUpdateToolStripMenuItem
            // 
            this.projectShipmentDateUpdateToolStripMenuItem.Name = "projectShipmentDateUpdateToolStripMenuItem";
            this.projectShipmentDateUpdateToolStripMenuItem.Size = new System.Drawing.Size(406, 28);
            this.projectShipmentDateUpdateToolStripMenuItem.Text = "Project Shipment Date Update";
            this.projectShipmentDateUpdateToolStripMenuItem.Click += new System.EventHandler(this.projectShipmentDateUpdateToolStripMenuItem_Click);
            // 
            // projectTransferRequestToolStripMenuItem
            // 
            this.projectTransferRequestToolStripMenuItem.Name = "projectTransferRequestToolStripMenuItem";
            this.projectTransferRequestToolStripMenuItem.Size = new System.Drawing.Size(406, 28);
            this.projectTransferRequestToolStripMenuItem.Text = "Project Transfer Request";
            this.projectTransferRequestToolStripMenuItem.Click += new System.EventHandler(this.projectTransferRequestToolStripMenuItem_Click);
            // 
            // projectTransferToolStripMenuItem
            // 
            this.projectTransferToolStripMenuItem.Name = "projectTransferToolStripMenuItem";
            this.projectTransferToolStripMenuItem.Size = new System.Drawing.Size(406, 28);
            this.projectTransferToolStripMenuItem.Text = "Project Transfer";
            this.projectTransferToolStripMenuItem.Click += new System.EventHandler(this.projectTransferToolStripMenuItem_Click);
            // 
            // projectDocumentsToolStripMenuItem
            // 
            this.projectDocumentsToolStripMenuItem.Name = "projectDocumentsToolStripMenuItem";
            this.projectDocumentsToolStripMenuItem.Size = new System.Drawing.Size(406, 28);
            this.projectDocumentsToolStripMenuItem.Text = "Project Documents";
            this.projectDocumentsToolStripMenuItem.Click += new System.EventHandler(this.projectDocumentsToolStripMenuItem_Click);
            // 
            // projectQRCodeToolStripMenuItem
            // 
            this.projectQRCodeToolStripMenuItem.Name = "projectQRCodeToolStripMenuItem";
            this.projectQRCodeToolStripMenuItem.Size = new System.Drawing.Size(406, 28);
            this.projectQRCodeToolStripMenuItem.Text = "Project QR Code ";
            this.projectQRCodeToolStripMenuItem.Click += new System.EventHandler(this.projectQRCodeToolStripMenuItem_Click);
            // 
            // tspProjectCLose
            // 
            this.tspProjectCLose.Name = "tspProjectCLose";
            this.tspProjectCLose.Size = new System.Drawing.Size(406, 28);
            this.tspProjectCLose.Text = "Project Warranty Expired Close";
            this.tspProjectCLose.Click += new System.EventHandler(this.tspProjectCLose_Click);
            // 
            // nCToolStripMenuItem
            // 
            this.nCToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.createNCToolStripMenuItem,
            this.addEscalationToolStripMenuItem});
            this.nCToolStripMenuItem.Name = "nCToolStripMenuItem";
            this.nCToolStripMenuItem.Size = new System.Drawing.Size(406, 28);
            this.nCToolStripMenuItem.Text = "Quality Management";
            this.nCToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // createNCToolStripMenuItem
            // 
            this.createNCToolStripMenuItem.Name = "createNCToolStripMenuItem";
            this.createNCToolStripMenuItem.Size = new System.Drawing.Size(243, 28);
            this.createNCToolStripMenuItem.Text = "Add NC/View";
            this.createNCToolStripMenuItem.Click += new System.EventHandler(this.createNCToolStripMenuItem_Click_1);
            // 
            // addEscalationToolStripMenuItem
            // 
            this.addEscalationToolStripMenuItem.Name = "addEscalationToolStripMenuItem";
            this.addEscalationToolStripMenuItem.Size = new System.Drawing.Size(243, 28);
            this.addEscalationToolStripMenuItem.Text = "Add Escalation/View";
            this.addEscalationToolStripMenuItem.Click += new System.EventHandler(this.addEscalationToolStripMenuItem_Click);
            // 
            // capexProjectsUpdateToolStripMenuItem
            // 
            this.capexProjectsUpdateToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.capexProjectStatusUpdateToolStripMenuItem1,
            this.capexProjectDepartmentAccessPermissionToolStripMenuItem});
            this.capexProjectsUpdateToolStripMenuItem.Name = "capexProjectsUpdateToolStripMenuItem";
            this.capexProjectsUpdateToolStripMenuItem.Size = new System.Drawing.Size(406, 28);
            this.capexProjectsUpdateToolStripMenuItem.Text = "Capex Projects Update";
            // 
            // capexProjectStatusUpdateToolStripMenuItem1
            // 
            this.capexProjectStatusUpdateToolStripMenuItem1.Name = "capexProjectStatusUpdateToolStripMenuItem1";
            this.capexProjectStatusUpdateToolStripMenuItem1.Size = new System.Drawing.Size(440, 28);
            this.capexProjectStatusUpdateToolStripMenuItem1.Text = "Capex Project Status Update";
            this.capexProjectStatusUpdateToolStripMenuItem1.Click += new System.EventHandler(this.capexProjectStatusUpdateToolStripMenuItem1_Click);
            // 
            // capexProjectDepartmentAccessPermissionToolStripMenuItem
            // 
            this.capexProjectDepartmentAccessPermissionToolStripMenuItem.Name = "capexProjectDepartmentAccessPermissionToolStripMenuItem";
            this.capexProjectDepartmentAccessPermissionToolStripMenuItem.Size = new System.Drawing.Size(440, 28);
            this.capexProjectDepartmentAccessPermissionToolStripMenuItem.Text = "Capex Project Department Access Permission";
            this.capexProjectDepartmentAccessPermissionToolStripMenuItem.Click += new System.EventHandler(this.capexProjectDepartmentAccessPermissionToolStripMenuItem_Click);
            // 
            // orToolStripMenuItem
            // 
            this.orToolStripMenuItem.Name = "orToolStripMenuItem";
            this.orToolStripMenuItem.Size = new System.Drawing.Size(406, 28);
            this.orToolStripMenuItem.Text = "Order Entry";
            this.orToolStripMenuItem.Click += new System.EventHandler(this.orToolStripMenuItem_Click);
            // 
            // packingListToolStripMenuItem
            // 
            this.packingListToolStripMenuItem.Name = "packingListToolStripMenuItem";
            this.packingListToolStripMenuItem.Size = new System.Drawing.Size(406, 28);
            this.packingListToolStripMenuItem.Text = "Project Closer";
            this.packingListToolStripMenuItem.Click += new System.EventHandler(this.packingListToolStripMenuItem_Click);
            // 
            // machinePassportToolStripMenuItem
            // 
            this.machinePassportToolStripMenuItem.Name = "machinePassportToolStripMenuItem";
            this.machinePassportToolStripMenuItem.Size = new System.Drawing.Size(406, 28);
            this.machinePassportToolStripMenuItem.Text = "Machine Passport";
            this.machinePassportToolStripMenuItem.Click += new System.EventHandler(this.machinePassportToolStripMenuItem_Click);
            // 
            // ProjectPackingListToolStripMenuItem
            // 
            this.ProjectPackingListToolStripMenuItem.Name = "ProjectPackingListToolStripMenuItem";
            this.ProjectPackingListToolStripMenuItem.Size = new System.Drawing.Size(406, 28);
            this.ProjectPackingListToolStripMenuItem.Text = "Project Packing List";
            this.ProjectPackingListToolStripMenuItem.Click += new System.EventHandler(this.ProjectPackingListToolStripMenuItem_Click);
            // 
            // reportsToolStripMenuItem2
            // 
            this.reportsToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.allERPReportsToolStripMenuItem});
            this.reportsToolStripMenuItem2.Name = "reportsToolStripMenuItem2";
            this.reportsToolStripMenuItem2.Size = new System.Drawing.Size(183, 27);
            this.reportsToolStripMenuItem2.Text = "Reports";
            this.reportsToolStripMenuItem2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.reportsToolStripMenuItem2.Click += new System.EventHandler(this.reportsToolStripMenuItem2_Click);
            // 
            // allERPReportsToolStripMenuItem
            // 
            this.allERPReportsToolStripMenuItem.Name = "allERPReportsToolStripMenuItem";
            this.allERPReportsToolStripMenuItem.Size = new System.Drawing.Size(177, 28);
            this.allERPReportsToolStripMenuItem.Text = "ERP Reports";
            this.allERPReportsToolStripMenuItem.Click += new System.EventHandler(this.allERPReportsToolStripMenuItem_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.customerVisitToolStripMenuItem,
            this.enquiryRegisterToolStripMenuItem,
            this.opportunityDetailsToolStripMenuItem,
            this.pEGRateToolStripMenuItem,
            this.SalesQuoteGenToolStripMenuItem,
            this.serviceQuoteGenToolStripMenuItem,
            this.testLabQuoteGENToolStripMenuItem,
            this.serviceQuoteSparePartsGENToolStripMenuItem});
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(183, 27);
            this.toolStripMenuItem6.Text = "Sales Management";
            this.toolStripMenuItem6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.toolStripMenuItem6.Click += new System.EventHandler(this.toolStripMenuItem6_Click);
            // 
            // customerVisitToolStripMenuItem
            // 
            this.customerVisitToolStripMenuItem.Name = "customerVisitToolStripMenuItem";
            this.customerVisitToolStripMenuItem.Size = new System.Drawing.Size(238, 28);
            this.customerVisitToolStripMenuItem.Text = "Customer Visit";
            this.customerVisitToolStripMenuItem.Click += new System.EventHandler(this.customerVisitToolStripMenuItem_Click);
            // 
            // enquiryRegisterToolStripMenuItem
            // 
            this.enquiryRegisterToolStripMenuItem.Name = "enquiryRegisterToolStripMenuItem";
            this.enquiryRegisterToolStripMenuItem.Size = new System.Drawing.Size(238, 28);
            this.enquiryRegisterToolStripMenuItem.Text = "Enquiry Register";
            this.enquiryRegisterToolStripMenuItem.Click += new System.EventHandler(this.enquiryRegisterToolStripMenuItem_Click);
            // 
            // opportunityDetailsToolStripMenuItem
            // 
            this.opportunityDetailsToolStripMenuItem.Name = "opportunityDetailsToolStripMenuItem";
            this.opportunityDetailsToolStripMenuItem.Size = new System.Drawing.Size(238, 28);
            this.opportunityDetailsToolStripMenuItem.Text = "Opportunity Details";
            this.opportunityDetailsToolStripMenuItem.Click += new System.EventHandler(this.opportunityDetailsToolStripMenuItem_Click);
            // 
            // pEGRateToolStripMenuItem
            // 
            this.pEGRateToolStripMenuItem.Name = "pEGRateToolStripMenuItem";
            this.pEGRateToolStripMenuItem.Size = new System.Drawing.Size(238, 28);
            this.pEGRateToolStripMenuItem.Text = "Peg Rate";
            this.pEGRateToolStripMenuItem.Click += new System.EventHandler(this.pEGRateToolStripMenuItem_Click);
            // 
            // SalesQuoteGenToolStripMenuItem
            // 
            this.SalesQuoteGenToolStripMenuItem.Name = "SalesQuoteGenToolStripMenuItem";
            this.SalesQuoteGenToolStripMenuItem.Size = new System.Drawing.Size(238, 28);
            this.SalesQuoteGenToolStripMenuItem.Text = "Sales Quote GEN";
            this.SalesQuoteGenToolStripMenuItem.Click += new System.EventHandler(this.SalesQuoteGenToolStripMenuItem_Click);
            // 
            // serviceQuoteGenToolStripMenuItem
            // 
            this.serviceQuoteGenToolStripMenuItem.Name = "serviceQuoteGenToolStripMenuItem";
            this.serviceQuoteGenToolStripMenuItem.Size = new System.Drawing.Size(238, 28);
            this.serviceQuoteGenToolStripMenuItem.Text = "Service Quote GEN";
            this.serviceQuoteGenToolStripMenuItem.Click += new System.EventHandler(this.serviceQuoteGenToolStripMenuItem_Click);
            // 
            // testLabQuoteGENToolStripMenuItem
            // 
            this.testLabQuoteGENToolStripMenuItem.Name = "testLabQuoteGENToolStripMenuItem";
            this.testLabQuoteGENToolStripMenuItem.Size = new System.Drawing.Size(238, 28);
            this.testLabQuoteGENToolStripMenuItem.Text = "Testlab Quote GEN";
            this.testLabQuoteGENToolStripMenuItem.Click += new System.EventHandler(this.testLabQuoteGENToolStripMenuItem_Click);
            // 
            // serviceQuoteSparePartsGENToolStripMenuItem
            // 
            this.serviceQuoteSparePartsGENToolStripMenuItem.Name = "serviceQuoteSparePartsGENToolStripMenuItem";
            this.serviceQuoteSparePartsGENToolStripMenuItem.Size = new System.Drawing.Size(238, 28);
            this.serviceQuoteSparePartsGENToolStripMenuItem.Text = " Spare parts GEN ";
            this.serviceQuoteSparePartsGENToolStripMenuItem.Click += new System.EventHandler(this.serviceQuoteSparePartsGENToolStripMenuItem_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.serviceCallManagerToolStripMenuItem,
            this.serviceOrderEntryToolStripMenuItem});
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(183, 27);
            this.toolStripMenuItem7.Text = "Service Management";
            // 
            // serviceCallManagerToolStripMenuItem
            // 
            this.serviceCallManagerToolStripMenuItem.Name = "serviceCallManagerToolStripMenuItem";
            this.serviceCallManagerToolStripMenuItem.Size = new System.Drawing.Size(246, 28);
            this.serviceCallManagerToolStripMenuItem.Text = "Service Call Manager";
            // 
            // serviceOrderEntryToolStripMenuItem
            // 
            this.serviceOrderEntryToolStripMenuItem.Name = "serviceOrderEntryToolStripMenuItem";
            this.serviceOrderEntryToolStripMenuItem.Size = new System.Drawing.Size(246, 28);
            this.serviceOrderEntryToolStripMenuItem.Text = "Service Order Entry";
            this.serviceOrderEntryToolStripMenuItem.Click += new System.EventHandler(this.serviceOrderEntryToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gINToolStripMenuItem,
            this.itemIssueToolStripMenuItem1,
            this.itemReturnToolStripMenuItem,
            this.pOWOInspectToolStripMenuItem,
            this.reverseGINToolStripMenuItem,
            this.toolStripMenuItemSIN,
            this.updateLedgerToolStripMenuItem,
            this.InventoryLedgerToolStripMenuItem,
            this.InventoryCycleCountMenuItem,
            this.InventoryDashBoard,
            this.ItemLocationUpdateMenuItem,
            this.CDToolStripMenuItem});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(183, 27);
            this.toolStripMenuItem2.Text = "Stores Management";
            this.toolStripMenuItem2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // gINToolStripMenuItem
            // 
            this.gINToolStripMenuItem.Name = "gINToolStripMenuItem";
            this.gINToolStripMenuItem.Size = new System.Drawing.Size(273, 28);
            this.gINToolStripMenuItem.Text = "GIN";
            this.gINToolStripMenuItem.Click += new System.EventHandler(this.gINToolStripMenuItem_Click);

            //
            //CDToolStripMenuItem
            //
            this.CDToolStripMenuItem.Name = "CDToolStripMenuItem";
            this.CDToolStripMenuItem.Size = new System.Drawing.Size(273, 28);
            this.CDToolStripMenuItem.Text = "DC";
            this.CDToolStripMenuItem.Click += new System.EventHandler(this.DCToolStripMenuItem_Click);

            // 
            // itemIssueToolStripMenuItem1
            // 
            this.itemIssueToolStripMenuItem1.Name = "itemIssueToolStripMenuItem1";
            this.itemIssueToolStripMenuItem1.Size = new System.Drawing.Size(273, 28);
            this.itemIssueToolStripMenuItem1.Text = "Item Issue";
            this.itemIssueToolStripMenuItem1.Click += new System.EventHandler(this.itemIssueToolStripMenuItem1_Click);
            // 
            // itemReturnToolStripMenuItem
            // 
            this.itemReturnToolStripMenuItem.Name = "itemReturnToolStripMenuItem";
            this.itemReturnToolStripMenuItem.Size = new System.Drawing.Size(273, 28);
            this.itemReturnToolStripMenuItem.Text = "Item Return";
            this.itemReturnToolStripMenuItem.Click += new System.EventHandler(this.itemReturnToolStripMenuItem_Click);
            // 
            // pOWOInspectToolStripMenuItem
            // 
            this.pOWOInspectToolStripMenuItem.Name = "pOWOInspectToolStripMenuItem";
            this.pOWOInspectToolStripMenuItem.Size = new System.Drawing.Size(273, 28);
            this.pOWOInspectToolStripMenuItem.Text = "PO/WO Inspect Request";
            this.pOWOInspectToolStripMenuItem.Click += new System.EventHandler(this.pOWOInspectToolStripMenuItem_Click);
            // 
            // reverseGINToolStripMenuItem
            // 
            this.reverseGINToolStripMenuItem.Name = "reverseGINToolStripMenuItem";
            this.reverseGINToolStripMenuItem.Size = new System.Drawing.Size(273, 28);
            this.reverseGINToolStripMenuItem.Text = "Reverse GIN";
            this.reverseGINToolStripMenuItem.Click += new System.EventHandler(this.reverseGINToolStripMenuItem_Click);
            // 
            // toolStripMenuItemSIN
            // 
            this.toolStripMenuItemSIN.Name = "toolStripMenuItemSIN";
            this.toolStripMenuItemSIN.Size = new System.Drawing.Size(273, 28);
            this.toolStripMenuItemSIN.Text = "SIN";
            this.toolStripMenuItemSIN.Click += new System.EventHandler(this.toolStripMenuItemSIN_Click);
            // 
            // updateLedgerToolStripMenuItem
            // 
            this.updateLedgerToolStripMenuItem.Name = "updateLedgerToolStripMenuItem";
            this.updateLedgerToolStripMenuItem.Size = new System.Drawing.Size(273, 28);
            this.updateLedgerToolStripMenuItem.Text = "Update GIN Ledger";
            this.updateLedgerToolStripMenuItem.Click += new System.EventHandler(this.updateLedgerToolStripMenuItem_Click);
            // 
            // InventoryLedgerToolStripMenuItem
            // 
            this.InventoryLedgerToolStripMenuItem.Name = "InventoryLedgerToolStripMenuItem";
            this.InventoryLedgerToolStripMenuItem.Size = new System.Drawing.Size(273, 28);
            this.InventoryLedgerToolStripMenuItem.Text = "Inventory Ledger";
            this.InventoryLedgerToolStripMenuItem.Click += new System.EventHandler(this.inventoryLedgerToolStripMenuItem_Click);
            // 
            // InventoryCycleCountMenuItem
            // 
            this.InventoryCycleCountMenuItem.Name = "InventoryCycleCountMenuItem";
            this.InventoryCycleCountMenuItem.Size = new System.Drawing.Size(273, 28);
            this.InventoryCycleCountMenuItem.Text = "Inventory Cycle Count";
            this.InventoryCycleCountMenuItem.Click += new System.EventHandler(this.InventoryCycleCountMenuItem_Click);
            // 
            // InventoryDashBoard
            // 
            this.InventoryDashBoard.Name = "InventoryDashBoard";
            this.InventoryDashBoard.Size = new System.Drawing.Size(273, 28);
            this.InventoryDashBoard.Text = "Inventory DashBoard";
            this.InventoryDashBoard.Click += new System.EventHandler(this.InventoryDashBoard_Click);
            // 
            // ItemLocationUpdateMenuItem
            // 
            this.ItemLocationUpdateMenuItem.Name = "ItemLocationUpdateMenuItem";
            this.ItemLocationUpdateMenuItem.Size = new System.Drawing.Size(273, 28);
            this.ItemLocationUpdateMenuItem.Text = "Item Location Update";
            this.ItemLocationUpdateMenuItem.Click += new System.EventHandler(this.ItemLocationUpdateMenuItem_Click);
            // 
            // timeSheetToolStripMenuItem
            // 
            this.timeSheetToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addTimeSheetToolStripMenuItem,
            this.machineUtilizationToolStripMenuItem,
            this.timeSheetReportToolStripMenuItem});
            this.timeSheetToolStripMenuItem.Name = "timeSheetToolStripMenuItem";
            this.timeSheetToolStripMenuItem.Size = new System.Drawing.Size(183, 27);
            this.timeSheetToolStripMenuItem.Text = "Time Sheet";
            this.timeSheetToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.timeSheetToolStripMenuItem.Click += new System.EventHandler(this.timeSheetToolStripMenuItem_Click);
            // 
            // addTimeSheetToolStripMenuItem
            // 
            this.addTimeSheetToolStripMenuItem.Name = "addTimeSheetToolStripMenuItem";
            this.addTimeSheetToolStripMenuItem.Size = new System.Drawing.Size(234, 28);
            this.addTimeSheetToolStripMenuItem.Text = "Add Time Sheet";
            this.addTimeSheetToolStripMenuItem.Click += new System.EventHandler(this.addTimeSheetToolStripMenuItem_Click);
            // 
            // machineUtilizationToolStripMenuItem
            // 
            this.machineUtilizationToolStripMenuItem.Name = "machineUtilizationToolStripMenuItem";
            this.machineUtilizationToolStripMenuItem.Size = new System.Drawing.Size(234, 28);
            this.machineUtilizationToolStripMenuItem.Text = "Machine Utilization";
            this.machineUtilizationToolStripMenuItem.Click += new System.EventHandler(this.machineUtilizationToolStripMenuItem_Click);
            // 
            // timeSheetReportToolStripMenuItem
            // 
            this.timeSheetReportToolStripMenuItem.Name = "timeSheetReportToolStripMenuItem";
            this.timeSheetReportToolStripMenuItem.Size = new System.Drawing.Size(234, 28);
            this.timeSheetReportToolStripMenuItem.Text = "Time Sheet Report";
            this.timeSheetReportToolStripMenuItem.Click += new System.EventHandler(this.timeSheetReportToolStripMenuItem_Click);
            // 
            // userManagementToolStripMenuItem
            // 
            this.userManagementToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addNewUserToolStripMenuItem,
            this.changePasswordToolStripMenuItem,
            this.requestSupportToolStripMenuItem});
            this.userManagementToolStripMenuItem.Name = "userManagementToolStripMenuItem";
            this.userManagementToolStripMenuItem.Size = new System.Drawing.Size(183, 27);
            this.userManagementToolStripMenuItem.Text = "User Management";
            this.userManagementToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // addNewUserToolStripMenuItem
            // 
            this.addNewUserToolStripMenuItem.Name = "addNewUserToolStripMenuItem";
            this.addNewUserToolStripMenuItem.Size = new System.Drawing.Size(231, 28);
            this.addNewUserToolStripMenuItem.Text = "Add / Update User ";
            this.addNewUserToolStripMenuItem.Click += new System.EventHandler(this.addNewUserToolStripMenuItem_Click);
            // 
            // changePasswordToolStripMenuItem
            // 
            this.changePasswordToolStripMenuItem.Name = "changePasswordToolStripMenuItem";
            this.changePasswordToolStripMenuItem.Size = new System.Drawing.Size(231, 28);
            this.changePasswordToolStripMenuItem.Text = "Change Password";
            this.changePasswordToolStripMenuItem.Click += new System.EventHandler(this.changePasswordToolStripMenuItem_Click);
            // 
            // requestSupportToolStripMenuItem
            // 
            this.requestSupportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.raiseRequestToolStripMenuItem,
            this.userFeedbackToolStripMenuItem,
            this.requestHistoryToolStripMenuItem});
            this.requestSupportToolStripMenuItem.Name = "requestSupportToolStripMenuItem";
            this.requestSupportToolStripMenuItem.Size = new System.Drawing.Size(231, 28);
            this.requestSupportToolStripMenuItem.Text = "Request Support";
            this.requestSupportToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // raiseRequestToolStripMenuItem
            // 
            this.raiseRequestToolStripMenuItem.Name = "raiseRequestToolStripMenuItem";
            this.raiseRequestToolStripMenuItem.Size = new System.Drawing.Size(208, 28);
            this.raiseRequestToolStripMenuItem.Text = "Raise Request";
            this.raiseRequestToolStripMenuItem.Click += new System.EventHandler(this.raiseRequestToolStripMenuItem_Click_1);
            // 
            // userFeedbackToolStripMenuItem
            // 
            this.userFeedbackToolStripMenuItem.Name = "userFeedbackToolStripMenuItem";
            this.userFeedbackToolStripMenuItem.Size = new System.Drawing.Size(208, 28);
            this.userFeedbackToolStripMenuItem.Text = "User Feedback";
            this.userFeedbackToolStripMenuItem.Click += new System.EventHandler(this.userFeedbackToolStripMenuItem_Click);
            // 
            // requestHistoryToolStripMenuItem
            // 
            this.requestHistoryToolStripMenuItem.Name = "requestHistoryToolStripMenuItem";
            this.requestHistoryToolStripMenuItem.Size = new System.Drawing.Size(208, 28);
            this.requestHistoryToolStripMenuItem.Text = "Request History";
            this.requestHistoryToolStripMenuItem.Click += new System.EventHandler(this.requestHistoryToolStripMenuItem_Click);
            // 
            // poStatusToolStripMenuItem
            // 
            this.poStatusToolStripMenuItem.Name = "poStatusToolStripMenuItem";
            this.poStatusToolStripMenuItem.Size = new System.Drawing.Size(273, 28);
            this.poStatusToolStripMenuItem.Text = "PO Status";
            this.poStatusToolStripMenuItem.Click += new System.EventHandler(this.poStatusToolStripMenuItem_Click);
            // 
            // DashboardToolStripMenuItem
            // 
            this.DashboardToolStripMenuItem.Name = "DashboardToolStripMenuItem";
            this.DashboardToolStripMenuItem.Size = new System.Drawing.Size(273, 28);
            // 
            // WARCalculationToolStripMenuItem
            // 
            this.WARCalculationToolStripMenuItem.Name = "WARCalculationToolStripMenuItem";
            this.WARCalculationToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
            // 
            // Sidebarpanel
            // 
            this.Sidebarpanel.BackColor = System.Drawing.Color.LightGray;
            this.Sidebarpanel.Controls.Add(this.menuStrip1);
            this.Sidebarpanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.Sidebarpanel.Location = new System.Drawing.Point(0, 0);
            this.Sidebarpanel.Name = "Sidebarpanel";
            this.Sidebarpanel.Size = new System.Drawing.Size(199, 661);
            this.Sidebarpanel.TabIndex = 22;
            // 
            // lstusers
            // 
            this.lstusers.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstusers.FormattingEnabled = true;
            this.lstusers.ItemHeight = 19;
            this.lstusers.Location = new System.Drawing.Point(392, 2);
            this.lstusers.Name = "lstusers";
            this.lstusers.ScrollAlwaysVisible = true;
            this.lstusers.Size = new System.Drawing.Size(50, 23);
            this.lstusers.TabIndex = 199;
            this.lstusers.Visible = false;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Indigo;
            this.label2.Location = new System.Drawing.Point(205, 626);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 23);
            this.label2.TabIndex = 34;
            this.label2.Text = "Welcome :";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // frmForm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(1338, 661);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblReturnedby);
            this.Controls.Add(this.llSwitchUser);
            this.Controls.Add(this.Sidebarpanel);
            this.Controls.Add(this.pnDashBoard);
            this.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmForm2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BiSS ERP v7.5";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form2_FormClosing);
            this.Load += new System.EventHandler(this.Form2_Load);
            this.pnDashBoard.ResumeLayout(false);
            this.pnDashBoard.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDashBoard)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.Sidebarpanel.ResumeLayout(false);
            this.Sidebarpanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }




        #endregion
        private System.Windows.Forms.LinkLabel llSwitchUser;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label lblReturnedby;
        private System.Windows.Forms.Panel pnDashBoard;
        private System.Windows.Forms.DataGridView dgvDashBoard;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem indentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem gINToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem CDToolStripMenuItem;//CDToolStripMenuItem
        private System.Windows.Forms.ToolStripMenuItem poStatusToolStripMenuItem;//poStatusToolStripMenuItem
        private System.Windows.Forms.ToolStripMenuItem reverseGINToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateLedgerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem InventoryLedgerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem InventoryCycleCountMenuItem;//
        private System.Windows.Forms.ToolStripMenuItem InventoryDashBoard;//
        private System.Windows.Forms.ToolStripMenuItem ItemLocationUpdateMenuItem;//ItemLocationUpdateMenuItem
        private System.Windows.Forms.ToolStripMenuItem DashboardToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pOWOInspectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itemReturnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem projectMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem createProjectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateProjectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ProjectBOMtoolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ProjectBOMLockMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ProjectBOMChangesLogsMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ProjectProgressMenuItem;//ProjectProgressMenuItem
        private System.Windows.Forms.ToolStripMenuItem projectBOMApproveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem projectInstallationStatuoUpdateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem projectShipmentDateUpdateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem projectTransferRequestToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem projectTransferToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem projectDocumentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem projectQRCodeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem enquiryRegisterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SalesQuoteGenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem customerVisitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem opportunityDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem serviceQuoteGenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem testLabQuoteGENToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pEGRateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem purchaseOrderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newPurchaseOrderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem timeSheetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addTimeSheetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem machineUtilizationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem timeSheetReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem securityToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem securityInwardItemsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem outwardItemsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manualInwardToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem2;
        private System.Windows.Forms.FlowLayoutPanel Sidebarpanel;
        private System.Windows.Forms.ToolStripMenuItem allERPReportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itemIssueToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem vendorManagementToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vendorMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cityMasterToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemSIN;
        private System.Windows.Forms.ToolStripMenuItem userManagementToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changePasswordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewUserToolStripMenuItem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem fixedAssetMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem WARCalculationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem capexProjectsUpdateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem capexProjectStatusUpdateToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem capexProjectDepartmentAccessPermissionToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblLatestWIPCount;
        private System.Windows.Forms.Label lblProjectCount;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.ToolStripMenuItem newApproveWorkOrderToolStripMenuItem;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbl1MonthLatePOs;
        private System.Windows.Forms.Label lblLatePos;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lbl6MonthLatePOs;
        private System.Windows.Forms.Label lbl3MonthLatePOs;
        private System.Windows.Forms.Label lblShippedCount;
        private System.Windows.Forms.Label lblInstallationCompleted;
        private System.Windows.Forms.ToolStripPanel BottomToolStripPanel;
        private System.Windows.Forms.ToolStripPanel TopToolStripPanel;
        private System.Windows.Forms.ToolStripPanel RightToolStripPanel;
        private System.Windows.Forms.ToolStripPanel LeftToolStripPanel;
        private System.Windows.Forms.ToolStripContentPanel ContentPanel;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem itemIssueToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itemProductionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itemReturnToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem itemStockAdjustToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kANBANBOMToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem itemLedgerToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem issueToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem productionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itemReturnToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem itemStockAdjustToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bOMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem kANBANBOMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itemLedgerToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem addItemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem standardCostUpdateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem targetCostToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itemLedgerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem InventoryLedgerToolStripMenuItem2;//InventoryLedgerToolStripMenuItem2
        private System.Windows.Forms.ToolStripMenuItem productMasterBOMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem customerMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem productMasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem indentToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem nCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem createNCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addEscalationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem requestSupportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem raiseRequestToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userFeedbackToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem requestHistoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sRFCalibrationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem serviceCallManagerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem serviceOrderEntryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tspProjectCLose;
        private System.Windows.Forms.ToolStripMenuItem orToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem machinePassportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ProjectPackingListToolStripMenuItem;//ProjectPackingListToolStripMenuItem
        private System.Windows.Forms.ToolStripMenuItem packingListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem serviceQuoteSparePartsGENToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wARCalculationToolStripMenuItem1;
        private System.Windows.Forms.ListBox lstusers;
        private System.Windows.Forms.Panel panel3;
    }
}