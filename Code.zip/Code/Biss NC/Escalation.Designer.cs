﻿
namespace Erp_Project_With_Buttons.Biss_NC
{
    partial class Escalation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Escalation));
            this.panel2 = new System.Windows.Forms.Panel();
            this.RCApanel = new System.Windows.Forms.Panel();
            this.txtclosuredatail = new Erp_Project_With_Buttons.SpellCheck();
            this.textBox9 = new System.Windows.Controls.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.btncancel = new System.Windows.Forms.Button();
            this.btnok = new System.Windows.Forms.Button();
            this.radiono = new System.Windows.Forms.RadioButton();
            this.radioyes = new System.Windows.Forms.RadioButton();
            this.label46 = new System.Windows.Forms.Label();
            this.txtNCReviewComments = new Erp_Project_With_Buttons.SpellCheck();
            this.textBox13 = new System.Windows.Controls.TextBox();
            this.txtDescriptionofNC = new Erp_Project_With_Buttons.SpellCheck();
            this.textBox12 = new System.Windows.Controls.TextBox();
            this.txtObservation = new Erp_Project_With_Buttons.SpellCheck();
            this.textBox11 = new System.Windows.Controls.TextBox();
            this.txtOptionalOE = new Erp_Project_With_Buttons.SpellCheck();
            this.textBox10 = new System.Windows.Controls.TextBox();
            this.btnncclose = new System.Windows.Forms.Button();
            this.remcount = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.Meetingbtn = new System.Windows.Forms.Button();
            this.btnReminder = new System.Windows.Forms.Button();
            this.cmbVendorName = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.pnReassign = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.btnReassign = new System.Windows.Forms.Button();
            this.cmbReassignDept = new System.Windows.Forms.ComboBox();
            this.lstusers = new System.Windows.Forms.ListBox();
            this.cmbReAssign = new System.Windows.Forms.ComboBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.cmbCCUser = new System.Windows.Forms.ComboBox();
            this.chkReAssign = new System.Windows.Forms.CheckBox();
            this.pnSave1 = new System.Windows.Forms.Panel();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.chkEditRootCause = new System.Windows.Forms.CheckBox();
            this.pnRootCause = new System.Windows.Forms.Panel();
            this.txtCorrectiveAction = new Erp_Project_With_Buttons.SpellCheck();
            this.textBox3 = new System.Windows.Controls.TextBox();
            this.txtRootCause = new Erp_Project_With_Buttons.SpellCheck();
            this.textBox2 = new System.Windows.Controls.TextBox();
            this.btnRootCauseSave = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.dtpPDC2 = new System.Windows.Forms.DateTimePicker();
            this.chkCorrectionEdit = new System.Windows.Forms.CheckBox();
            this.pnCorrection = new System.Windows.Forms.Panel();
            this.txtCorrectionRequested = new Erp_Project_With_Buttons.SpellCheck();
            this.hostedComponent1 = new System.Windows.Controls.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.btnCorrectionSave = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.dtpPDC1 = new System.Windows.Forms.DateTimePicker();
            this.label16 = new System.Windows.Forms.Label();
            this.cmbDisposition = new System.Windows.Forms.ComboBox();
            this.lstAddUser = new System.Windows.Forms.ListBox();
            this.label22 = new System.Windows.Forms.Label();
            this.cmbUserCC = new System.Windows.Forms.ComboBox();
            this.txtAssignedtoDept = new System.Windows.Forms.ComboBox();
            this.cmbSubProduct = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.cmbComponentType = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtRequesterName = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbEnvironMent = new System.Windows.Forms.ComboBox();
            this.lblprojname = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbNCType = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblProjectDescription = new System.Windows.Forms.Label();
            this.txtRequesterDept = new System.Windows.Forms.TextBox();
            this.cmbPriority = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbAssignedTo = new System.Windows.Forms.ComboBox();
            this.btnProjectView = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lblCustomer = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbProjectcode = new System.Windows.Forms.ComboBox();
            this.cmbQSR = new System.Windows.Forms.ComboBox();
            this.cmbcoesite = new System.Windows.Forms.ComboBox();
            this.label41 = new System.Windows.Forms.Label();
            this.cmblocation = new System.Windows.Forms.ComboBox();
            this.label42 = new System.Windows.Forms.Label();
            this.cmbproductline = new System.Windows.Forms.ComboBox();
            this.label48 = new System.Windows.Forms.Label();
            this.pnObjectiveEvidence = new System.Windows.Forms.Panel();
            this.txtObjectiveEvidenceFound = new Erp_Project_With_Buttons.SpellCheck();
            this.textBox4 = new System.Windows.Controls.TextBox();
            this.txtManHours = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.btnAcceptnCloseNC = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCostincurred = new System.Windows.Forms.TextBox();
            this.dtpCloseDate = new System.Windows.Forms.DateTimePicker();
            this.reviewmeetpn = new System.Windows.Forms.Panel();
            this.txtreasonlevel = new Erp_Project_With_Buttons.SpellCheck();
            this.textBox8 = new System.Windows.Controls.TextBox();
            this.ReviewTextBox = new Erp_Project_With_Buttons.SpellCheck();
            this.textBox7 = new System.Windows.Controls.TextBox();
            this.ActPlanTextbox = new Erp_Project_With_Buttons.SpellCheck();
            this.textBox6 = new System.Windows.Controls.TextBox();
            this.MOMTextbox = new Erp_Project_With_Buttons.SpellCheck();
            this.textBox5 = new System.Windows.Controls.TextBox();
            this.panelclosedate = new System.Windows.Forms.Panel();
            this.dtpclose = new System.Windows.Forms.DateTimePicker();
            this.label45 = new System.Windows.Forms.Label();
            this.Noradio = new System.Windows.Forms.RadioButton();
            this.yesradio = new System.Windows.Forms.RadioButton();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.btnclose = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.lblreviewmeettext = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.CmbRMLevel = new System.Windows.Forms.ComboBox();
            this.dateofresultiontext = new System.Windows.Forms.DateTimePicker();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.savecalcelbtn = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.dtpCreatedDate = new System.Windows.Forms.DateTimePicker();
            this.viewncbtn = new System.Windows.Forms.Button();
            this.label35 = new System.Windows.Forms.Label();
            this.NCnumcmbbox = new System.Windows.Forms.ComboBox();
            this.dtpexcelfromdate = new System.Windows.Forms.DateTimePicker();
            this.dtpexceltodate = new System.Windows.Forms.DateTimePicker();
            this.label38 = new System.Windows.Forms.Label();
            this.btnconsolexcel = new System.Windows.Forms.Button();
            this.btnViewEscalation = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.RCApanel.SuspendLayout();
            this.pnReassign.SuspendLayout();
            this.pnSave1.SuspendLayout();
            this.pnRootCause.SuspendLayout();
            this.pnCorrection.SuspendLayout();
            this.pnObjectiveEvidence.SuspendLayout();
            this.reviewmeetpn.SuspendLayout();
            this.panelclosedate.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.RCApanel);
            this.panel2.Controls.Add(this.txtNCReviewComments);
            this.panel2.Controls.Add(this.txtDescriptionofNC);
            this.panel2.Controls.Add(this.txtObservation);
            this.panel2.Controls.Add(this.txtOptionalOE);
            this.panel2.Controls.Add(this.btnncclose);
            this.panel2.Controls.Add(this.remcount);
            this.panel2.Controls.Add(this.label40);
            this.panel2.Controls.Add(this.label39);
            this.panel2.Controls.Add(this.Meetingbtn);
            this.panel2.Controls.Add(this.btnReminder);
            this.panel2.Controls.Add(this.cmbVendorName);
            this.panel2.Controls.Add(this.label24);
            this.panel2.Controls.Add(this.pnReassign);
            this.panel2.Controls.Add(this.chkReAssign);
            this.panel2.Controls.Add(this.pnSave1);
            this.panel2.Controls.Add(this.chkEditRootCause);
            this.panel2.Controls.Add(this.pnRootCause);
            this.panel2.Controls.Add(this.chkCorrectionEdit);
            this.panel2.Controls.Add(this.pnCorrection);
            this.panel2.Controls.Add(this.lstAddUser);
            this.panel2.Controls.Add(this.label22);
            this.panel2.Controls.Add(this.cmbUserCC);
            this.panel2.Controls.Add(this.txtAssignedtoDept);
            this.panel2.Controls.Add(this.cmbSubProduct);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.label27);
            this.panel2.Controls.Add(this.label31);
            this.panel2.Controls.Add(this.cmbComponentType);
            this.panel2.Controls.Add(this.label26);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.txtRequesterName);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.cmbEnvironMent);
            this.panel2.Controls.Add(this.lblprojname);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.cmbNCType);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.lblProjectDescription);
            this.panel2.Controls.Add(this.txtRequesterDept);
            this.panel2.Controls.Add(this.cmbPriority);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.cmbAssignedTo);
            this.panel2.Controls.Add(this.btnProjectView);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.lblCustomer);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.cmbProjectcode);
            this.panel2.Controls.Add(this.cmbQSR);
            this.panel2.Controls.Add(this.cmbcoesite);
            this.panel2.Controls.Add(this.label41);
            this.panel2.Controls.Add(this.cmblocation);
            this.panel2.Controls.Add(this.label42);
            this.panel2.Controls.Add(this.cmbproductline);
            this.panel2.Controls.Add(this.label48);
            this.panel2.Controls.Add(this.pnObjectiveEvidence);
            this.panel2.Location = new System.Drawing.Point(-1, 29);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1329, 632);
            this.panel2.TabIndex = 194;
            // 
            // RCApanel
            // 
            this.RCApanel.BackColor = System.Drawing.Color.LightGray;
            this.RCApanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RCApanel.Controls.Add(this.txtclosuredatail);
            this.RCApanel.Controls.Add(this.label47);
            this.RCApanel.Controls.Add(this.btncancel);
            this.RCApanel.Controls.Add(this.btnok);
            this.RCApanel.Controls.Add(this.radiono);
            this.RCApanel.Controls.Add(this.radioyes);
            this.RCApanel.Controls.Add(this.label46);
            this.RCApanel.Location = new System.Drawing.Point(494, 107);
            this.RCApanel.Name = "RCApanel";
            this.RCApanel.Size = new System.Drawing.Size(404, 245);
            this.RCApanel.TabIndex = 21;
            this.RCApanel.Visible = false;
            // 
            // txtclosuredatail
            // 
            this.txtclosuredatail.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtclosuredatail.Location = new System.Drawing.Point(97, 67);
            this.txtclosuredatail.Multiline = true;
            this.txtclosuredatail.Name = "txtclosuredatail";
            this.txtclosuredatail.Size = new System.Drawing.Size(302, 124);
            this.txtclosuredatail.TabIndex = 205;
            this.txtclosuredatail.Child = this.textBox9;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(16, 67);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(75, 38);
            this.label47.TabIndex = 5;
            this.label47.Text = "Closure \r\n Deatails :";
            // 
            // btncancel
            // 
            this.btncancel.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncancel.Location = new System.Drawing.Point(232, 207);
            this.btncancel.Name = "btncancel";
            this.btncancel.Size = new System.Drawing.Size(75, 30);
            this.btncancel.TabIndex = 4;
            this.btncancel.Text = "Close";
            this.btncancel.UseVisualStyleBackColor = true;
            this.btncancel.Click += new System.EventHandler(this.btncancel_Click);
            // 
            // btnok
            // 
            this.btnok.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnok.Location = new System.Drawing.Point(313, 207);
            this.btnok.Name = "btnok";
            this.btnok.Size = new System.Drawing.Size(75, 30);
            this.btnok.TabIndex = 3;
            this.btnok.Text = "Save";
            this.btnok.UseVisualStyleBackColor = true;
            this.btnok.Click += new System.EventHandler(this.btnok_Click);
            // 
            // radiono
            // 
            this.radiono.AutoSize = true;
            this.radiono.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radiono.Location = new System.Drawing.Point(229, 25);
            this.radiono.Name = "radiono";
            this.radiono.Size = new System.Drawing.Size(49, 23);
            this.radiono.TabIndex = 2;
            this.radiono.Text = "NO";
            this.radiono.UseVisualStyleBackColor = true;
            // 
            // radioyes
            // 
            this.radioyes.AutoSize = true;
            this.radioyes.Checked = true;
            this.radioyes.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioyes.Location = new System.Drawing.Point(165, 25);
            this.radioyes.Name = "radioyes";
            this.radioyes.Size = new System.Drawing.Size(51, 23);
            this.radioyes.TabIndex = 1;
            this.radioyes.TabStop = true;
            this.radioyes.Text = "YES";
            this.radioyes.UseVisualStyleBackColor = true;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(25, 29);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(113, 19);
            this.label46.TabIndex = 0;
            this.label46.Text = "RCA Required ?";
            // 
            // txtNCReviewComments
            // 
            this.txtNCReviewComments.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNCReviewComments.Location = new System.Drawing.Point(578, 430);
            this.txtNCReviewComments.Multiline = true;
            this.txtNCReviewComments.Name = "txtNCReviewComments";
            this.txtNCReviewComments.Size = new System.Drawing.Size(316, 72);
            this.txtNCReviewComments.TabIndex = 255;
            this.txtNCReviewComments.Child = this.textBox13;
            // 
            // txtDescriptionofNC
            // 
            this.txtDescriptionofNC.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescriptionofNC.Location = new System.Drawing.Point(578, 181);
            this.txtDescriptionofNC.Multiline = true;
            this.txtDescriptionofNC.Name = "txtDescriptionofNC";
            this.txtDescriptionofNC.Size = new System.Drawing.Size(310, 81);
            this.txtDescriptionofNC.TabIndex = 254;
            this.txtDescriptionofNC.Child = this.textBox12;
            // 
            // txtObservation
            // 
            this.txtObservation.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtObservation.Location = new System.Drawing.Point(582, 274);
            this.txtObservation.Multiline = true;
            this.txtObservation.Name = "txtObservation";
            this.txtObservation.Size = new System.Drawing.Size(310, 73);
            this.txtObservation.TabIndex = 253;
            this.txtObservation.Child = this.textBox11;
            // 
            // txtOptionalOE
            // 
            this.txtOptionalOE.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOptionalOE.Location = new System.Drawing.Point(579, 358);
            this.txtOptionalOE.Multiline = true;
            this.txtOptionalOE.Name = "txtOptionalOE";
            this.txtOptionalOE.Size = new System.Drawing.Size(315, 68);
            this.txtOptionalOE.TabIndex = 252;
            this.txtOptionalOE.Child = this.textBox10;
            // 
            // btnncclose
            // 
            this.btnncclose.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnncclose.Location = new System.Drawing.Point(806, 508);
            this.btnncclose.Name = "btnncclose";
            this.btnncclose.Size = new System.Drawing.Size(93, 38);
            this.btnncclose.TabIndex = 214;
            this.btnncclose.Text = "Close NC";
            this.btnncclose.UseVisualStyleBackColor = true;
            this.btnncclose.Visible = false;
            this.btnncclose.Click += new System.EventHandler(this.btnncclose_Click);
            // 
            // remcount
            // 
            this.remcount.AutoSize = true;
            this.remcount.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.remcount.Location = new System.Drawing.Point(582, 156);
            this.remcount.Name = "remcount";
            this.remcount.Size = new System.Drawing.Size(17, 19);
            this.remcount.TabIndex = 213;
            this.remcount.Text = "0";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(1, 126);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(126, 19);
            this.label40.TabIndex = 208;
            this.label40.Text = "QSR/ESC Owner :";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(17, 404);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(104, 19);
            this.label39.TabIndex = 205;
            this.label39.Text = "Product Line :";
            // 
            // Meetingbtn
            // 
            this.Meetingbtn.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Meetingbtn.Location = new System.Drawing.Point(580, 509);
            this.Meetingbtn.Name = "Meetingbtn";
            this.Meetingbtn.Size = new System.Drawing.Size(108, 37);
            this.Meetingbtn.TabIndex = 204;
            this.Meetingbtn.Text = "Meeting";
            this.Meetingbtn.UseVisualStyleBackColor = true;
            this.Meetingbtn.Visible = false;
            this.Meetingbtn.Click += new System.EventHandler(this.Meetingbtn_Click);
            // 
            // btnReminder
            // 
            this.btnReminder.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReminder.Location = new System.Drawing.Point(692, 509);
            this.btnReminder.Name = "btnReminder";
            this.btnReminder.Size = new System.Drawing.Size(107, 37);
            this.btnReminder.TabIndex = 202;
            this.btnReminder.Text = "Reminder";
            this.btnReminder.UseVisualStyleBackColor = true;
            this.btnReminder.Visible = false;
            this.btnReminder.Click += new System.EventHandler(this.btnReminder_Click);
            // 
            // cmbVendorName
            // 
            this.cmbVendorName.DropDownHeight = 130;
            this.cmbVendorName.Enabled = false;
            this.cmbVendorName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbVendorName.FormattingEnabled = true;
            this.cmbVendorName.IntegralHeight = false;
            this.cmbVendorName.Location = new System.Drawing.Point(129, 303);
            this.cmbVendorName.Name = "cmbVendorName";
            this.cmbVendorName.Size = new System.Drawing.Size(257, 27);
            this.cmbVendorName.TabIndex = 200;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(47, 311);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(74, 19);
            this.label24.TabIndex = 199;
            this.label24.Text = "Supplier :";
            // 
            // pnReassign
            // 
            this.pnReassign.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnReassign.Controls.Add(this.label20);
            this.pnReassign.Controls.Add(this.btnReassign);
            this.pnReassign.Controls.Add(this.cmbReassignDept);
            this.pnReassign.Controls.Add(this.lstusers);
            this.pnReassign.Controls.Add(this.cmbReAssign);
            this.pnReassign.Controls.Add(this.label32);
            this.pnReassign.Controls.Add(this.label30);
            this.pnReassign.Controls.Add(this.cmbCCUser);
            this.pnReassign.Enabled = false;
            this.pnReassign.Location = new System.Drawing.Point(9, 549);
            this.pnReassign.Name = "pnReassign";
            this.pnReassign.Size = new System.Drawing.Size(649, 76);
            this.pnReassign.TabIndex = 191;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(235, 9);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(100, 19);
            this.label20.TabIndex = 194;
            this.label20.Text = "Department :";
            // 
            // btnReassign
            // 
            this.btnReassign.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnReassign.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnReassign.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReassign.Location = new System.Drawing.Point(337, 39);
            this.btnReassign.Name = "btnReassign";
            this.btnReassign.Size = new System.Drawing.Size(90, 30);
            this.btnReassign.TabIndex = 193;
            this.btnReassign.Text = "Re Assign";
            this.btnReassign.UseVisualStyleBackColor = false;
            this.btnReassign.Click += new System.EventHandler(this.btnReassign_Click);
            // 
            // cmbReassignDept
            // 
            this.cmbReassignDept.DropDownHeight = 130;
            this.cmbReassignDept.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbReassignDept.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbReassignDept.FormattingEnabled = true;
            this.cmbReassignDept.IntegralHeight = false;
            this.cmbReassignDept.Items.AddRange(new object[] {
            "Design",
            "Application Development",
            "Electronics Design",
            "Mech Production",
            "Hydraulics Production",
            "Electrical Integration",
            "Controllers",
            "Transducers",
            "System Integration",
            "Purchase",
            "Validation",
            "Sales"});
            this.cmbReassignDept.Location = new System.Drawing.Point(337, 6);
            this.cmbReassignDept.Name = "cmbReassignDept";
            this.cmbReassignDept.Size = new System.Drawing.Size(123, 27);
            this.cmbReassignDept.TabIndex = 191;
            // 
            // lstusers
            // 
            this.lstusers.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstusers.FormattingEnabled = true;
            this.lstusers.ItemHeight = 19;
            this.lstusers.Location = new System.Drawing.Point(466, 6);
            this.lstusers.Name = "lstusers";
            this.lstusers.ScrollAlwaysVisible = true;
            this.lstusers.Size = new System.Drawing.Size(176, 61);
            this.lstusers.TabIndex = 188;
            this.lstusers.KeyUp += new System.Windows.Forms.KeyEventHandler(this.lstusers_KeyUp);
            // 
            // cmbReAssign
            // 
            this.cmbReAssign.DropDownHeight = 130;
            this.cmbReAssign.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbReAssign.FormattingEnabled = true;
            this.cmbReAssign.IntegralHeight = false;
            this.cmbReAssign.Location = new System.Drawing.Point(108, 6);
            this.cmbReAssign.Name = "cmbReAssign";
            this.cmbReAssign.Size = new System.Drawing.Size(127, 27);
            this.cmbReAssign.TabIndex = 185;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(20, 46);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(84, 19);
            this.label32.TabIndex = 189;
            this.label32.Text = "Add CC to :";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(6, 6);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(100, 19);
            this.label30.TabIndex = 184;
            this.label30.Text = "Re Assign to :";
            // 
            // cmbCCUser
            // 
            this.cmbCCUser.DropDownHeight = 130;
            this.cmbCCUser.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCCUser.FormattingEnabled = true;
            this.cmbCCUser.IntegralHeight = false;
            this.cmbCCUser.Location = new System.Drawing.Point(108, 43);
            this.cmbCCUser.Name = "cmbCCUser";
            this.cmbCCUser.Size = new System.Drawing.Size(127, 27);
            this.cmbCCUser.TabIndex = 190;
            this.cmbCCUser.SelectedIndexChanged += new System.EventHandler(this.cmbCCUser_SelectedIndexChanged);
            // 
            // chkReAssign
            // 
            this.chkReAssign.AutoSize = true;
            this.chkReAssign.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkReAssign.Location = new System.Drawing.Point(9, 516);
            this.chkReAssign.Name = "chkReAssign";
            this.chkReAssign.Size = new System.Drawing.Size(92, 23);
            this.chkReAssign.TabIndex = 192;
            this.chkReAssign.Text = "Re Assign";
            this.chkReAssign.UseVisualStyleBackColor = true;
            this.chkReAssign.CheckedChanged += new System.EventHandler(this.chkReAssign_CheckedChanged);
            // 
            // pnSave1
            // 
            this.pnSave1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnSave1.Controls.Add(this.btnSave);
            this.pnSave1.Controls.Add(this.btnExit);
            this.pnSave1.Location = new System.Drawing.Point(676, 548);
            this.pnSave1.Name = "pnSave1";
            this.pnSave1.Size = new System.Drawing.Size(228, 77);
            this.pnSave1.TabIndex = 170;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(19, 22);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(90, 39);
            this.btnSave.TabIndex = 167;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(115, 22);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(90, 39);
            this.btnExit.TabIndex = 166;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // chkEditRootCause
            // 
            this.chkEditRootCause.AutoSize = true;
            this.chkEditRootCause.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkEditRootCause.Location = new System.Drawing.Point(913, 182);
            this.chkEditRootCause.Name = "chkEditRootCause";
            this.chkEditRootCause.Size = new System.Drawing.Size(55, 23);
            this.chkEditRootCause.TabIndex = 197;
            this.chkEditRootCause.Text = "Edit";
            this.chkEditRootCause.UseVisualStyleBackColor = true;
            this.chkEditRootCause.Visible = false;
            this.chkEditRootCause.CheckedChanged += new System.EventHandler(this.chkEditRootCause_CheckedChanged);
            // 
            // pnRootCause
            // 
            this.pnRootCause.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnRootCause.Controls.Add(this.txtCorrectiveAction);
            this.pnRootCause.Controls.Add(this.txtRootCause);
            this.pnRootCause.Controls.Add(this.btnRootCauseSave);
            this.pnRootCause.Controls.Add(this.label13);
            this.pnRootCause.Controls.Add(this.label17);
            this.pnRootCause.Controls.Add(this.label14);
            this.pnRootCause.Controls.Add(this.dtpPDC2);
            this.pnRootCause.Enabled = false;
            this.pnRootCause.Location = new System.Drawing.Point(910, 204);
            this.pnRootCause.Name = "pnRootCause";
            this.pnRootCause.Size = new System.Drawing.Size(413, 234);
            this.pnRootCause.TabIndex = 196;
            // 
            // txtCorrectiveAction
            // 
            this.txtCorrectiveAction.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCorrectiveAction.Location = new System.Drawing.Point(16, 128);
            this.txtCorrectiveAction.Multiline = true;
            this.txtCorrectiveAction.Name = "txtCorrectiveAction";
            this.txtCorrectiveAction.Size = new System.Drawing.Size(390, 76);
            this.txtCorrectiveAction.TabIndex = 206;
            this.txtCorrectiveAction.Child = this.textBox3;
            // 
            // txtRootCause
            // 
            this.txtRootCause.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRootCause.Location = new System.Drawing.Point(16, 26);
            this.txtRootCause.Multiline = true;
            this.txtRootCause.Name = "txtRootCause";
            this.txtRootCause.Size = new System.Drawing.Size(392, 81);
            this.txtRootCause.TabIndex = 205;
            this.txtRootCause.Child = this.textBox2;
            // 
            // btnRootCauseSave
            // 
            this.btnRootCauseSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnRootCauseSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnRootCauseSave.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRootCauseSave.Location = new System.Drawing.Point(338, 207);
            this.btnRootCauseSave.Name = "btnRootCauseSave";
            this.btnRootCauseSave.Size = new System.Drawing.Size(72, 25);
            this.btnRootCauseSave.TabIndex = 193;
            this.btnRootCauseSave.Text = "Save";
            this.btnRootCauseSave.UseVisualStyleBackColor = false;
            this.btnRootCauseSave.Click += new System.EventHandler(this.btnRootCauseSave_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(8, -2);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(93, 19);
            this.label13.TabIndex = 161;
            this.label13.Text = "Root Cause :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(274, 2);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(44, 19);
            this.label17.TabIndex = 191;
            this.label17.Text = "PDC :";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(6, 107);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(134, 19);
            this.label14.TabIndex = 163;
            this.label14.Text = "Corrective Action :";
            // 
            // dtpPDC2
            // 
            this.dtpPDC2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpPDC2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpPDC2.Location = new System.Drawing.Point(322, -1);
            this.dtpPDC2.Name = "dtpPDC2";
            this.dtpPDC2.Size = new System.Drawing.Size(89, 26);
            this.dtpPDC2.TabIndex = 169;
            this.dtpPDC2.ValueChanged += new System.EventHandler(this.dtpPDC2_ValueChanged);
            // 
            // chkCorrectionEdit
            // 
            this.chkCorrectionEdit.AutoSize = true;
            this.chkCorrectionEdit.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkCorrectionEdit.Location = new System.Drawing.Point(910, 1);
            this.chkCorrectionEdit.Name = "chkCorrectionEdit";
            this.chkCorrectionEdit.Size = new System.Drawing.Size(55, 23);
            this.chkCorrectionEdit.TabIndex = 194;
            this.chkCorrectionEdit.Text = "Edit";
            this.chkCorrectionEdit.UseVisualStyleBackColor = true;
            this.chkCorrectionEdit.Visible = false;
            this.chkCorrectionEdit.CheckedChanged += new System.EventHandler(this.chkCorrectionEdit_CheckedChanged);
            // 
            // pnCorrection
            // 
            this.pnCorrection.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnCorrection.Controls.Add(this.txtCorrectionRequested);
            this.pnCorrection.Controls.Add(this.label19);
            this.pnCorrection.Controls.Add(this.btnCorrectionSave);
            this.pnCorrection.Controls.Add(this.label10);
            this.pnCorrection.Controls.Add(this.dtpPDC1);
            this.pnCorrection.Controls.Add(this.label16);
            this.pnCorrection.Controls.Add(this.cmbDisposition);
            this.pnCorrection.Enabled = false;
            this.pnCorrection.Location = new System.Drawing.Point(910, 23);
            this.pnCorrection.Name = "pnCorrection";
            this.pnCorrection.Size = new System.Drawing.Size(417, 158);
            this.pnCorrection.TabIndex = 195;
            // 
            // txtCorrectionRequested
            // 
            this.txtCorrectionRequested.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCorrectionRequested.Location = new System.Drawing.Point(16, 46);
            this.txtCorrectionRequested.Multiline = true;
            this.txtCorrectionRequested.Name = "txtCorrectionRequested";
            this.txtCorrectionRequested.Size = new System.Drawing.Size(395, 81);
            this.txtCorrectionRequested.TabIndex = 204;
            this.txtCorrectionRequested.Child = this.hostedComponent1;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(2, 5);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(92, 19);
            this.label19.TabIndex = 172;
            this.label19.Text = "Disposition :";
            // 
            // btnCorrectionSave
            // 
            this.btnCorrectionSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnCorrectionSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCorrectionSave.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCorrectionSave.Location = new System.Drawing.Point(339, 128);
            this.btnCorrectionSave.Name = "btnCorrectionSave";
            this.btnCorrectionSave.Size = new System.Drawing.Size(72, 25);
            this.btnCorrectionSave.TabIndex = 192;
            this.btnCorrectionSave.Text = "Save";
            this.btnCorrectionSave.UseVisualStyleBackColor = false;
            this.btnCorrectionSave.Click += new System.EventHandler(this.btnCorrectionSave_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(5, 28);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(88, 19);
            this.label10.TabIndex = 151;
            this.label10.Text = "Correction :";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // dtpPDC1
            // 
            this.dtpPDC1.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.dtpPDC1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpPDC1.Location = new System.Drawing.Point(322, 3);
            this.dtpPDC1.Name = "dtpPDC1";
            this.dtpPDC1.Size = new System.Drawing.Size(88, 26);
            this.dtpPDC1.TabIndex = 168;
            this.dtpPDC1.ValueChanged += new System.EventHandler(this.dtpPDC1_ValueChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(275, 7);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(44, 19);
            this.label16.TabIndex = 170;
            this.label16.Text = "PDC :";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cmbDisposition
            // 
            this.cmbDisposition.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDisposition.FormattingEnabled = true;
            this.cmbDisposition.Items.AddRange(new object[] {
            "Use as is",
            "Return to supplier",
            "Repair/Rework",
            "Reject"});
            this.cmbDisposition.Location = new System.Drawing.Point(96, 3);
            this.cmbDisposition.Name = "cmbDisposition";
            this.cmbDisposition.Size = new System.Drawing.Size(165, 27);
            this.cmbDisposition.TabIndex = 173;
            // 
            // lstAddUser
            // 
            this.lstAddUser.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstAddUser.FormattingEnabled = true;
            this.lstAddUser.ItemHeight = 19;
            this.lstAddUser.Location = new System.Drawing.Point(129, 466);
            this.lstAddUser.Name = "lstAddUser";
            this.lstAddUser.ScrollAlwaysVisible = true;
            this.lstAddUser.Size = new System.Drawing.Size(257, 80);
            this.lstAddUser.TabIndex = 193;
            this.lstAddUser.KeyUp += new System.Windows.Forms.KeyEventHandler(this.lstAddUser_KeyUp);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(37, 437);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(84, 19);
            this.label22.TabIndex = 191;
            this.label22.Text = "Add CC to :";
            // 
            // cmbUserCC
            // 
            this.cmbUserCC.DropDownHeight = 130;
            this.cmbUserCC.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbUserCC.FormattingEnabled = true;
            this.cmbUserCC.IntegralHeight = false;
            this.cmbUserCC.Location = new System.Drawing.Point(129, 434);
            this.cmbUserCC.Name = "cmbUserCC";
            this.cmbUserCC.Size = new System.Drawing.Size(257, 27);
            this.cmbUserCC.TabIndex = 192;
            this.cmbUserCC.SelectedIndexChanged += new System.EventHandler(this.cmbUserCC_SelectedIndexChanged);
            // 
            // txtAssignedtoDept
            // 
            this.txtAssignedtoDept.DropDownHeight = 130;
            this.txtAssignedtoDept.Enabled = false;
            this.txtAssignedtoDept.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAssignedtoDept.FormattingEnabled = true;
            this.txtAssignedtoDept.IntegralHeight = false;
            this.txtAssignedtoDept.Location = new System.Drawing.Point(332, 159);
            this.txtAssignedtoDept.Name = "txtAssignedtoDept";
            this.txtAssignedtoDept.Size = new System.Drawing.Size(113, 27);
            this.txtAssignedtoDept.Sorted = true;
            this.txtAssignedtoDept.TabIndex = 183;
            // 
            // cmbSubProduct
            // 
            this.cmbSubProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSubProduct.FormattingEnabled = true;
            this.cmbSubProduct.Location = new System.Drawing.Point(130, 372);
            this.cmbSubProduct.Name = "cmbSubProduct";
            this.cmbSubProduct.Size = new System.Drawing.Size(257, 27);
            this.cmbSubProduct.TabIndex = 182;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(429, 361);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(146, 38);
            this.label21.TabIndex = 174;
            this.label21.Text = "Objective Evidence :\r\n       (Optional)";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(19, 376);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(102, 19);
            this.label27.TabIndex = 181;
            this.label27.Text = "Sub Product :";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(412, 432);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(165, 19);
            this.label31.TabIndex = 187;
            this.label31.Text = "NC Review Comments :";
            // 
            // cmbComponentType
            // 
            this.cmbComponentType.DropDownWidth = 445;
            this.cmbComponentType.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbComponentType.FormattingEnabled = true;
            this.cmbComponentType.Items.AddRange(new object[] {
            "Load Frame",
            "Actuators",
            "Grips & Fixtures",
            "Controllers",
            "Application Software",
            "MTL 32",
            "Electrical",
            "Power Pack",
            "Transducers",
            "Site Related"});
            this.cmbComponentType.Location = new System.Drawing.Point(129, 336);
            this.cmbComponentType.Name = "cmbComponentType";
            this.cmbComponentType.Size = new System.Drawing.Size(257, 27);
            this.cmbComponentType.TabIndex = 180;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(49, 344);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(72, 19);
            this.label26.TabIndex = 179;
            this.label26.Text = "Product :";
            // 
            // label18
            // 
            this.label18.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(444, 267);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(131, 50);
            this.label18.TabIndex = 171;
            this.label18.Text = "Observation /  \r\nConsequence :";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtRequesterName
            // 
            this.txtRequesterName.Enabled = false;
            this.txtRequesterName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRequesterName.Location = new System.Drawing.Point(129, 7);
            this.txtRequesterName.Name = "txtRequesterName";
            this.txtRequesterName.Size = new System.Drawing.Size(217, 27);
            this.txtRequesterName.TabIndex = 142;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(358, 13);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 19);
            this.label8.TabIndex = 139;
            this.label8.Text = "Department :";
            // 
            // cmbEnvironMent
            // 
            this.cmbEnvironMent.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbEnvironMent.FormattingEnabled = true;
            this.cmbEnvironMent.Items.AddRange(new object[] {
            "India"});
            this.cmbEnvironMent.Location = new System.Drawing.Point(129, 197);
            this.cmbEnvironMent.Name = "cmbEnvironMent";
            this.cmbEnvironMent.Size = new System.Drawing.Size(257, 27);
            this.cmbEnvironMent.TabIndex = 155;
            // 
            // lblprojname
            // 
            this.lblprojname.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprojname.ForeColor = System.Drawing.Color.Black;
            this.lblprojname.Location = new System.Drawing.Point(129, 85);
            this.lblprojname.Name = "lblprojname";
            this.lblprojname.Size = new System.Drawing.Size(289, 36);
            this.lblprojname.TabIndex = 157;
            this.lblprojname.Text = "P";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(441, 185);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(135, 19);
            this.label5.TabIndex = 147;
            this.label5.Text = "Description of NC :";
            // 
            // cmbNCType
            // 
            this.cmbNCType.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbNCType.FormattingEnabled = true;
            this.cmbNCType.Items.AddRange(new object[] {
            "Critical",
            "Non-Critical"});
            this.cmbNCType.Location = new System.Drawing.Point(129, 268);
            this.cmbNCType.Name = "cmbNCType";
            this.cmbNCType.Size = new System.Drawing.Size(257, 27);
            this.cmbNCType.TabIndex = 154;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(48, 271);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(73, 19);
            this.label11.TabIndex = 153;
            this.label11.Text = "NC Type :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(6, 203);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(115, 19);
            this.label9.TabIndex = 149;
            this.label9.Text = "Sales Territory :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(493, 45);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(82, 19);
            this.label12.TabIndex = 160;
            this.label12.Text = "Customer :";
            // 
            // lblProjectDescription
            // 
            this.lblProjectDescription.AutoSize = true;
            this.lblProjectDescription.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblProjectDescription.ForeColor = System.Drawing.Color.Black;
            this.lblProjectDescription.Location = new System.Drawing.Point(18, 84);
            this.lblProjectDescription.Name = "lblProjectDescription";
            this.lblProjectDescription.Size = new System.Drawing.Size(110, 19);
            this.lblProjectDescription.TabIndex = 156;
            this.lblProjectDescription.Text = "Project Name :";
            // 
            // txtRequesterDept
            // 
            this.txtRequesterDept.Enabled = false;
            this.txtRequesterDept.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRequesterDept.Location = new System.Drawing.Point(467, 10);
            this.txtRequesterDept.Name = "txtRequesterDept";
            this.txtRequesterDept.Size = new System.Drawing.Size(249, 27);
            this.txtRequesterDept.TabIndex = 140;
            // 
            // cmbPriority
            // 
            this.cmbPriority.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPriority.FormattingEnabled = true;
            this.cmbPriority.Items.AddRange(new object[] {
            "Level 1",
            "Level 2",
            "Level 3",
            "Level 4"});
            this.cmbPriority.Location = new System.Drawing.Point(129, 235);
            this.cmbPriority.Name = "cmbPriority";
            this.cmbPriority.Size = new System.Drawing.Size(257, 27);
            this.cmbPriority.TabIndex = 136;
            this.cmbPriority.SelectedIndexChanged += new System.EventHandler(this.cmbPriority_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(69, 238);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 19);
            this.label6.TabIndex = 135;
            this.label6.Text = "Level :";
            // 
            // cmbAssignedTo
            // 
            this.cmbAssignedTo.DropDownHeight = 130;
            this.cmbAssignedTo.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbAssignedTo.FormattingEnabled = true;
            this.cmbAssignedTo.IntegralHeight = false;
            this.cmbAssignedTo.Location = new System.Drawing.Point(129, 159);
            this.cmbAssignedTo.Name = "cmbAssignedTo";
            this.cmbAssignedTo.Size = new System.Drawing.Size(153, 27);
            this.cmbAssignedTo.TabIndex = 146;
            this.cmbAssignedTo.SelectedIndexChanged += new System.EventHandler(this.cmbAssignedTo_SelectedIndexChanged);
            // 
            // btnProjectView
            // 
            this.btnProjectView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnProjectView.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProjectView.Location = new System.Drawing.Point(394, 48);
            this.btnProjectView.Name = "btnProjectView";
            this.btnProjectView.Size = new System.Drawing.Size(24, 24);
            this.btnProjectView.TabIndex = 159;
            this.btnProjectView.Text = "....";
            this.btnProjectView.UseVisualStyleBackColor = false;
            this.btnProjectView.Click += new System.EventHandler(this.btnProjectView_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(25, 162);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 19);
            this.label3.TabIndex = 145;
            this.label3.Text = "Assigned to :";
            // 
            // lblCustomer
            // 
            this.lblCustomer.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomer.ForeColor = System.Drawing.Color.Black;
            this.lblCustomer.Location = new System.Drawing.Point(580, 45);
            this.lblCustomer.Name = "lblCustomer";
            this.lblCustomer.Size = new System.Drawing.Size(322, 27);
            this.lblCustomer.TabIndex = 158;
            this.lblCustomer.Text = "*";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(283, 162);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 19);
            this.label4.TabIndex = 143;
            this.label4.Text = "Dept :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(-2, 10);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(130, 19);
            this.label7.TabIndex = 141;
            this.label7.Text = "Requester Name :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(22, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 19);
            this.label1.TabIndex = 128;
            this.label1.Text = "Project Code :";
            // 
            // cmbProjectcode
            // 
            this.cmbProjectcode.DropDownHeight = 130;
            this.cmbProjectcode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProjectcode.FormattingEnabled = true;
            this.cmbProjectcode.IntegralHeight = false;
            this.cmbProjectcode.Location = new System.Drawing.Point(129, 45);
            this.cmbProjectcode.Name = "cmbProjectcode";
            this.cmbProjectcode.Size = new System.Drawing.Size(258, 27);
            this.cmbProjectcode.TabIndex = 129;
            this.cmbProjectcode.SelectedIndexChanged += new System.EventHandler(this.cmbProjectcode_SelectedIndexChanged);
            // 
            // cmbQSR
            // 
            this.cmbQSR.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbQSR.FormattingEnabled = true;
            this.cmbQSR.Items.AddRange(new object[] {
            "Girish"});
            this.cmbQSR.Location = new System.Drawing.Point(127, 123);
            this.cmbQSR.Name = "cmbQSR";
            this.cmbQSR.Size = new System.Drawing.Size(257, 27);
            this.cmbQSR.TabIndex = 207;
            // 
            // cmbcoesite
            // 
            this.cmbcoesite.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbcoesite.FormattingEnabled = true;
            this.cmbcoesite.Items.AddRange(new object[] {
            "Bengaluru"});
            this.cmbcoesite.Location = new System.Drawing.Point(579, 85);
            this.cmbcoesite.Name = "cmbcoesite";
            this.cmbcoesite.Size = new System.Drawing.Size(242, 27);
            this.cmbcoesite.TabIndex = 210;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(503, 88);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(74, 19);
            this.label41.TabIndex = 209;
            this.label41.Text = "COE Site :";
            // 
            // cmblocation
            // 
            this.cmblocation.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmblocation.FormattingEnabled = true;
            this.cmblocation.Location = new System.Drawing.Point(579, 123);
            this.cmblocation.Name = "cmblocation";
            this.cmblocation.Size = new System.Drawing.Size(242, 27);
            this.cmblocation.TabIndex = 211;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(502, 123);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(75, 19);
            this.label42.TabIndex = 212;
            this.label42.Text = "Location :";
            // 
            // cmbproductline
            // 
            this.cmbproductline.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbproductline.FormattingEnabled = true;
            this.cmbproductline.Location = new System.Drawing.Point(129, 402);
            this.cmbproductline.Name = "cmbproductline";
            this.cmbproductline.Size = new System.Drawing.Size(257, 27);
            this.cmbproductline.TabIndex = 206;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(493, 156);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(83, 19);
            this.label48.TabIndex = 215;
            this.label48.Text = "Reminder :";
            // 
            // pnObjectiveEvidence
            // 
            this.pnObjectiveEvidence.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnObjectiveEvidence.Controls.Add(this.txtObjectiveEvidenceFound);
            this.pnObjectiveEvidence.Controls.Add(this.txtManHours);
            this.pnObjectiveEvidence.Controls.Add(this.label23);
            this.pnObjectiveEvidence.Controls.Add(this.btnAcceptnCloseNC);
            this.pnObjectiveEvidence.Controls.Add(this.label15);
            this.pnObjectiveEvidence.Controls.Add(this.label2);
            this.pnObjectiveEvidence.Controls.Add(this.txtCostincurred);
            this.pnObjectiveEvidence.Controls.Add(this.dtpCloseDate);
            this.pnObjectiveEvidence.Location = new System.Drawing.Point(910, 441);
            this.pnObjectiveEvidence.Name = "pnObjectiveEvidence";
            this.pnObjectiveEvidence.Size = new System.Drawing.Size(408, 186);
            this.pnObjectiveEvidence.TabIndex = 198;
            this.pnObjectiveEvidence.Visible = false;
            // 
            // txtObjectiveEvidenceFound
            // 
            this.txtObjectiveEvidenceFound.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtObjectiveEvidenceFound.Location = new System.Drawing.Point(12, 31);
            this.txtObjectiveEvidenceFound.Multiline = true;
            this.txtObjectiveEvidenceFound.Name = "txtObjectiveEvidenceFound";
            this.txtObjectiveEvidenceFound.Size = new System.Drawing.Size(389, 81);
            this.txtObjectiveEvidenceFound.TabIndex = 205;
            this.txtObjectiveEvidenceFound.Child = this.textBox4;
            // 
            // txtManHours
            // 
            this.txtManHours.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtManHours.Location = new System.Drawing.Point(159, 152);
            this.txtManHours.Name = "txtManHours";
            this.txtManHours.Size = new System.Drawing.Size(123, 27);
            this.txtManHours.TabIndex = 187;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(14, 152);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(134, 19);
            this.label23.TabIndex = 186;
            this.label23.Text = "Man Hours in hrs :";
            // 
            // btnAcceptnCloseNC
            // 
            this.btnAcceptnCloseNC.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAcceptnCloseNC.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAcceptnCloseNC.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAcceptnCloseNC.Location = new System.Drawing.Point(300, 145);
            this.btnAcceptnCloseNC.Name = "btnAcceptnCloseNC";
            this.btnAcceptnCloseNC.Size = new System.Drawing.Size(101, 34);
            this.btnAcceptnCloseNC.TabIndex = 168;
            this.btnAcceptnCloseNC.Text = "Close NC";
            this.btnAcceptnCloseNC.UseVisualStyleBackColor = false;
            this.btnAcceptnCloseNC.Click += new System.EventHandler(this.btnAcceptnCloseNC_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(7, 4);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(138, 19);
            this.label15.TabIndex = 166;
            this.label15.Text = "Objective Evidence";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(7, 121);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(146, 19);
            this.label2.TabIndex = 183;
            this.label2.Text = "Cost Incurred in RS :";
            // 
            // txtCostincurred
            // 
            this.txtCostincurred.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCostincurred.Location = new System.Drawing.Point(159, 121);
            this.txtCostincurred.Name = "txtCostincurred";
            this.txtCostincurred.Size = new System.Drawing.Size(123, 27);
            this.txtCostincurred.TabIndex = 184;
            // 
            // dtpCloseDate
            // 
            this.dtpCloseDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.dtpCloseDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpCloseDate.Location = new System.Drawing.Point(171, 122);
            this.dtpCloseDate.Name = "dtpCloseDate";
            this.dtpCloseDate.Size = new System.Drawing.Size(25, 27);
            this.dtpCloseDate.TabIndex = 185;
            this.dtpCloseDate.Visible = false;
            // 
            // reviewmeetpn
            // 
            this.reviewmeetpn.BackColor = System.Drawing.Color.LightGray;
            this.reviewmeetpn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.reviewmeetpn.Controls.Add(this.txtreasonlevel);
            this.reviewmeetpn.Controls.Add(this.ReviewTextBox);
            this.reviewmeetpn.Controls.Add(this.ActPlanTextbox);
            this.reviewmeetpn.Controls.Add(this.MOMTextbox);
            this.reviewmeetpn.Controls.Add(this.panelclosedate);
            this.reviewmeetpn.Controls.Add(this.Noradio);
            this.reviewmeetpn.Controls.Add(this.yesradio);
            this.reviewmeetpn.Controls.Add(this.label44);
            this.reviewmeetpn.Controls.Add(this.label43);
            this.reviewmeetpn.Controls.Add(this.btnclose);
            this.reviewmeetpn.Controls.Add(this.dateTimePicker1);
            this.reviewmeetpn.Controls.Add(this.lblreviewmeettext);
            this.reviewmeetpn.Controls.Add(this.label37);
            this.reviewmeetpn.Controls.Add(this.label36);
            this.reviewmeetpn.Controls.Add(this.CmbRMLevel);
            this.reviewmeetpn.Controls.Add(this.dateofresultiontext);
            this.reviewmeetpn.Controls.Add(this.label34);
            this.reviewmeetpn.Controls.Add(this.label33);
            this.reviewmeetpn.Controls.Add(this.label29);
            this.reviewmeetpn.Controls.Add(this.label28);
            this.reviewmeetpn.Controls.Add(this.savecalcelbtn);
            this.reviewmeetpn.Location = new System.Drawing.Point(243, 29);
            this.reviewmeetpn.Name = "reviewmeetpn";
            this.reviewmeetpn.Size = new System.Drawing.Size(657, 477);
            this.reviewmeetpn.TabIndex = 203;
            this.reviewmeetpn.Visible = false;
            // 
            // txtreasonlevel
            // 
            this.txtreasonlevel.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtreasonlevel.Location = new System.Drawing.Point(118, 347);
            this.txtreasonlevel.Multiline = true;
            this.txtreasonlevel.Name = "txtreasonlevel";
            this.txtreasonlevel.Size = new System.Drawing.Size(291, 74);
            this.txtreasonlevel.TabIndex = 208;
            this.txtreasonlevel.Child = this.textBox8;
            // 
            // ReviewTextBox
            // 
            this.ReviewTextBox.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReviewTextBox.Location = new System.Drawing.Point(118, 268);
            this.ReviewTextBox.Multiline = true;
            this.ReviewTextBox.Name = "ReviewTextBox";
            this.ReviewTextBox.Size = new System.Drawing.Size(291, 69);
            this.ReviewTextBox.TabIndex = 207;
            this.ReviewTextBox.Child = this.textBox7;
            // 
            // ActPlanTextbox
            // 
            this.ActPlanTextbox.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ActPlanTextbox.Location = new System.Drawing.Point(118, 155);
            this.ActPlanTextbox.Multiline = true;
            this.ActPlanTextbox.Name = "ActPlanTextbox";
            this.ActPlanTextbox.Size = new System.Drawing.Size(514, 104);
            this.ActPlanTextbox.TabIndex = 206;
            this.ActPlanTextbox.Child = this.textBox6;
            // 
            // MOMTextbox
            // 
            this.MOMTextbox.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MOMTextbox.Location = new System.Drawing.Point(118, 45);
            this.MOMTextbox.Multiline = true;
            this.MOMTextbox.Name = "MOMTextbox";
            this.MOMTextbox.Size = new System.Drawing.Size(514, 103);
            this.MOMTextbox.TabIndex = 205;
            this.MOMTextbox.Child = this.textBox5;
            // 
            // panelclosedate
            // 
            this.panelclosedate.Controls.Add(this.dtpclose);
            this.panelclosedate.Controls.Add(this.label45);
            this.panelclosedate.Location = new System.Drawing.Point(420, 376);
            this.panelclosedate.Name = "panelclosedate";
            this.panelclosedate.Size = new System.Drawing.Size(227, 48);
            this.panelclosedate.TabIndex = 20;
            this.panelclosedate.Visible = false;
            // 
            // dtpclose
            // 
            this.dtpclose.CalendarFont = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpclose.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpclose.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpclose.Location = new System.Drawing.Point(103, 18);
            this.dtpclose.Name = "dtpclose";
            this.dtpclose.Size = new System.Drawing.Size(117, 27);
            this.dtpclose.TabIndex = 1;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(3, 7);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(97, 38);
            this.label45.TabIndex = 0;
            this.label45.Text = "New Closure\r\n            Date :";
            // 
            // Noradio
            // 
            this.Noradio.AutoSize = true;
            this.Noradio.Checked = true;
            this.Noradio.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Noradio.Location = new System.Drawing.Point(328, 426);
            this.Noradio.Name = "Noradio";
            this.Noradio.Size = new System.Drawing.Size(49, 23);
            this.Noradio.TabIndex = 19;
            this.Noradio.TabStop = true;
            this.Noradio.Text = "NO";
            this.Noradio.UseVisualStyleBackColor = true;
            this.Noradio.CheckedChanged += new System.EventHandler(this.Noradio_CheckedChanged);
            // 
            // yesradio
            // 
            this.yesradio.AutoSize = true;
            this.yesradio.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yesradio.Location = new System.Drawing.Point(255, 426);
            this.yesradio.Name = "yesradio";
            this.yesradio.Size = new System.Drawing.Size(55, 23);
            this.yesradio.TabIndex = 18;
            this.yesradio.Text = "YES ";
            this.yesradio.UseVisualStyleBackColor = true;
            this.yesradio.CheckedChanged += new System.EventHandler(this.yesradio_CheckedChanged);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(6, 428);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(236, 19);
            this.label44.TabIndex = 17;
            this.label44.Text = "Any Changes in Resolution Date ?";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(6, 348);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(106, 38);
            this.label43.TabIndex = 15;
            this.label43.Text = "Reason  for\r\nLevel Change :";
            // 
            // btnclose
            // 
            this.btnclose.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnclose.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclose.Location = new System.Drawing.Point(540, 436);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(92, 34);
            this.btnclose.TabIndex = 14;
            this.btnclose.Text = "Close";
            this.btnclose.UseVisualStyleBackColor = true;
            this.btnclose.Click += new System.EventHandler(this.btnclose_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Enabled = false;
            this.dateTimePicker1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(437, 7);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(132, 27);
            this.dateTimePicker1.TabIndex = 13;
            // 
            // lblreviewmeettext
            // 
            this.lblreviewmeettext.AutoSize = true;
            this.lblreviewmeettext.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblreviewmeettext.Location = new System.Drawing.Point(312, 8);
            this.lblreviewmeettext.Name = "lblreviewmeettext";
            this.lblreviewmeettext.Size = new System.Drawing.Size(20, 23);
            this.lblreviewmeettext.TabIndex = 12;
            this.lblreviewmeettext.Text = "0";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(162, 8);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(150, 23);
            this.label37.TabIndex = 11;
            this.label37.Text = "Review Meeting -";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(457, 346);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(52, 19);
            this.label36.TabIndex = 10;
            this.label36.Text = "Level :";
            // 
            // CmbRMLevel
            // 
            this.CmbRMLevel.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CmbRMLevel.FormattingEnabled = true;
            this.CmbRMLevel.Location = new System.Drawing.Point(515, 343);
            this.CmbRMLevel.Name = "CmbRMLevel";
            this.CmbRMLevel.Size = new System.Drawing.Size(117, 27);
            this.CmbRMLevel.TabIndex = 9;
            // 
            // dateofresultiontext
            // 
            this.dateofresultiontext.CalendarFont = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateofresultiontext.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateofresultiontext.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateofresultiontext.Location = new System.Drawing.Point(515, 300);
            this.dateofresultiontext.Name = "dateofresultiontext";
            this.dateofresultiontext.Size = new System.Drawing.Size(117, 27);
            this.dateofresultiontext.TabIndex = 8;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(420, 292);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(89, 38);
            this.label34.TabIndex = 4;
            this.label34.Text = "Date Of \r\nResolution :";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(41, 271);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(61, 38);
            this.label33.TabIndex = 3;
            this.label33.Text = "Review\r\n  Team :";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(17, 160);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(95, 19);
            this.label29.TabIndex = 2;
            this.label29.Text = "Action Plan :";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(19, 45);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(93, 38);
            this.label28.TabIndex = 1;
            this.label28.Text = "Minutes of \r\n    Meeting : ";
            // 
            // savecalcelbtn
            // 
            this.savecalcelbtn.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.savecalcelbtn.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.savecalcelbtn.Location = new System.Drawing.Point(440, 436);
            this.savecalcelbtn.Name = "savecalcelbtn";
            this.savecalcelbtn.Size = new System.Drawing.Size(94, 36);
            this.savecalcelbtn.TabIndex = 0;
            this.savecalcelbtn.Text = "Save";
            this.savecalcelbtn.UseVisualStyleBackColor = true;
            this.savecalcelbtn.Click += new System.EventHandler(this.savecalcelbtn_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(1180, 6);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(49, 19);
            this.label25.TabIndex = 178;
            this.label25.Text = "Date :";
            // 
            // dtpCreatedDate
            // 
            this.dtpCreatedDate.Enabled = false;
            this.dtpCreatedDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpCreatedDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpCreatedDate.Location = new System.Drawing.Point(1235, 0);
            this.dtpCreatedDate.Name = "dtpCreatedDate";
            this.dtpCreatedDate.Size = new System.Drawing.Size(93, 26);
            this.dtpCreatedDate.TabIndex = 177;
            // 
            // viewncbtn
            // 
            this.viewncbtn.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewncbtn.Location = new System.Drawing.Point(840, 1);
            this.viewncbtn.Name = "viewncbtn";
            this.viewncbtn.Size = new System.Drawing.Size(119, 29);
            this.viewncbtn.TabIndex = 195;
            this.viewncbtn.Text = "Export to Excel";
            this.viewncbtn.UseVisualStyleBackColor = true;
            this.viewncbtn.Click += new System.EventHandler(this.viewncbtn_Click);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(484, 7);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(92, 19);
            this.label35.TabIndex = 196;
            this.label35.Text = "NC Number:";
            // 
            // NCnumcmbbox
            // 
            this.NCnumcmbbox.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NCnumcmbbox.FormattingEnabled = true;
            this.NCnumcmbbox.Location = new System.Drawing.Point(580, 1);
            this.NCnumcmbbox.Name = "NCnumcmbbox";
            this.NCnumcmbbox.Size = new System.Drawing.Size(233, 27);
            this.NCnumcmbbox.TabIndex = 197;
            this.NCnumcmbbox.SelectedIndexChanged += new System.EventHandler(this.NCnumcmbbox_SelectedIndexChanged);
            // 
            // dtpexcelfromdate
            // 
            this.dtpexcelfromdate.CalendarFont = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpexcelfromdate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpexcelfromdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpexcelfromdate.Location = new System.Drawing.Point(3, 2);
            this.dtpexcelfromdate.Name = "dtpexcelfromdate";
            this.dtpexcelfromdate.Size = new System.Drawing.Size(93, 26);
            this.dtpexcelfromdate.TabIndex = 198;
            // 
            // dtpexceltodate
            // 
            this.dtpexceltodate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpexceltodate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpexceltodate.Location = new System.Drawing.Point(128, 2);
            this.dtpexceltodate.Name = "dtpexceltodate";
            this.dtpexceltodate.Size = new System.Drawing.Size(93, 26);
            this.dtpexceltodate.TabIndex = 199;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(102, 7);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(22, 18);
            this.label38.TabIndex = 200;
            this.label38.Text = "To";
            // 
            // btnconsolexcel
            // 
            this.btnconsolexcel.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnconsolexcel.Location = new System.Drawing.Point(228, 1);
            this.btnconsolexcel.Name = "btnconsolexcel";
            this.btnconsolexcel.Size = new System.Drawing.Size(159, 28);
            this.btnconsolexcel.TabIndex = 201;
            this.btnconsolexcel.Text = "Consolidated Report";
            this.btnconsolexcel.UseVisualStyleBackColor = true;
            this.btnconsolexcel.Click += new System.EventHandler(this.btnconsolexcel_Click);
            // 
            // btnViewEscalation
            // 
            this.btnViewEscalation.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewEscalation.Location = new System.Drawing.Point(990, 0);
            this.btnViewEscalation.Name = "btnViewEscalation";
            this.btnViewEscalation.Size = new System.Drawing.Size(119, 29);
            this.btnViewEscalation.TabIndex = 204;
            this.btnViewEscalation.Text = "View Escalation";
            this.btnViewEscalation.UseVisualStyleBackColor = true;
            this.btnViewEscalation.Click += new System.EventHandler(this.btnViewEscalation_Click);
            // 
            // Escalation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1331, 665);
            this.Controls.Add(this.btnViewEscalation);
            this.Controls.Add(this.reviewmeetpn);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnconsolexcel);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.dtpexceltodate);
            this.Controls.Add(this.dtpexcelfromdate);
            this.Controls.Add(this.NCnumcmbbox);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.viewncbtn);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.dtpCreatedDate);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Escalation";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Escalation";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmEscalationClosing);
            this.Load += new System.EventHandler(this.Escalation_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.RCApanel.ResumeLayout(false);
            this.RCApanel.PerformLayout();
            this.pnReassign.ResumeLayout(false);
            this.pnReassign.PerformLayout();
            this.pnSave1.ResumeLayout(false);
            this.pnRootCause.ResumeLayout(false);
            this.pnRootCause.PerformLayout();
            this.pnCorrection.ResumeLayout(false);
            this.pnCorrection.PerformLayout();
            this.pnObjectiveEvidence.ResumeLayout(false);
            this.pnObjectiveEvidence.PerformLayout();
            this.reviewmeetpn.ResumeLayout(false);
            this.reviewmeetpn.PerformLayout();
            this.panelclosedate.ResumeLayout(false);
            this.panelclosedate.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel pnObjectiveEvidence;
        private System.Windows.Forms.TextBox txtManHours;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button btnAcceptnCloseNC;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCostincurred;
        private System.Windows.Forms.DateTimePicker dtpCloseDate;
        private System.Windows.Forms.CheckBox chkReAssign;
        private System.Windows.Forms.Panel pnReassign;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button btnReassign;
        private System.Windows.Forms.ComboBox cmbReassignDept;
        private System.Windows.Forms.ListBox lstusers;
        private System.Windows.Forms.ComboBox cmbReAssign;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.ComboBox cmbCCUser;
        private System.Windows.Forms.Panel pnSave1;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.CheckBox chkEditRootCause;
        private System.Windows.Forms.Panel pnRootCause;
        private System.Windows.Forms.Button btnRootCauseSave;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DateTimePicker dtpPDC2;
        private System.Windows.Forms.CheckBox chkCorrectionEdit;
        private System.Windows.Forms.Panel pnCorrection;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btnCorrectionSave;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker dtpPDC1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox cmbDisposition;
        private System.Windows.Forms.ListBox lstAddUser;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox cmbUserCC;
        private System.Windows.Forms.ComboBox txtAssignedtoDept;
        private System.Windows.Forms.ComboBox cmbSubProduct;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox cmbComponentType;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.DateTimePicker dtpCreatedDate;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtRequesterName;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbEnvironMent;
        private System.Windows.Forms.Label lblprojname;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbNCType;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblProjectDescription;
        private System.Windows.Forms.TextBox txtRequesterDept;
        private System.Windows.Forms.ComboBox cmbPriority;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbAssignedTo;
        private System.Windows.Forms.Button btnProjectView;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblCustomer;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbProjectcode;
        private System.Windows.Forms.ComboBox cmbVendorName;
        private System.Windows.Forms.Label label24;
        #endregion

        private System.Windows.Forms.Button btnReminder;
        private System.Windows.Forms.Panel reviewmeetpn;
        private System.Windows.Forms.Button savecalcelbtn;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.DateTimePicker dateofresultiontext;
        private System.Windows.Forms.Button Meetingbtn;
        private System.Windows.Forms.Button viewncbtn;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.ComboBox NCnumcmbbox;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ComboBox CmbRMLevel;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label lblreviewmeettext;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.DateTimePicker dtpexcelfromdate;
        private System.Windows.Forms.DateTimePicker dtpexceltodate;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Button btnconsolexcel;
        private System.Windows.Forms.Button btnclose;
        private System.Windows.Forms.ComboBox cmbproductline;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.ComboBox cmbcoesite;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.ComboBox cmblocation;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.ComboBox cmbQSR;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Panel panelclosedate;
        private System.Windows.Forms.DateTimePicker dtpclose;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.RadioButton Noradio;
        private System.Windows.Forms.RadioButton yesradio;
        private System.Windows.Forms.Label remcount;
        private System.Windows.Forms.Button btnncclose;
        private System.Windows.Forms.Panel RCApanel;
        private System.Windows.Forms.Button btncancel;
        private System.Windows.Forms.Button btnok;
        private System.Windows.Forms.RadioButton radiono;
        private System.Windows.Forms.RadioButton radioyes;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private SpellCheck txtCorrectionRequested;
        private System.Windows.Controls.TextBox hostedComponent1;
        private SpellCheck txtCorrectiveAction;
        private System.Windows.Controls.TextBox textBox3;
        private SpellCheck txtRootCause;
        private System.Windows.Controls.TextBox textBox2;
        private SpellCheck txtObjectiveEvidenceFound;
        private System.Windows.Controls.TextBox textBox4;
        private SpellCheck ActPlanTextbox;
        private System.Windows.Controls.TextBox textBox6;
        private SpellCheck MOMTextbox;
        private System.Windows.Controls.TextBox textBox5;
        private SpellCheck txtreasonlevel;
        private System.Windows.Controls.TextBox textBox8;
        private SpellCheck ReviewTextBox;
        private System.Windows.Controls.TextBox textBox7;
        private SpellCheck txtclosuredatail;
        private System.Windows.Controls.TextBox textBox9;
        private SpellCheck txtOptionalOE;
        private System.Windows.Controls.TextBox textBox10;
        private SpellCheck txtDescriptionofNC;
        private System.Windows.Controls.TextBox textBox12;
        private SpellCheck txtObservation;
        private System.Windows.Controls.TextBox textBox11;
        private SpellCheck txtNCReviewComments;
        private System.Windows.Controls.TextBox textBox13;
        private System.Windows.Forms.Button btnViewEscalation;
    }
}
