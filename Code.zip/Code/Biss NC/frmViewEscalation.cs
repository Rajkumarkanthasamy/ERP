﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Biss_NC
{
    public partial class frmViewEscalation : Form
    {
        Login.frmLoginForm Login = new Login.frmLoginForm();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        DataTable dtUserReport = new DataTable();

        public frmViewEscalation()
        {
            InitializeComponent();
        }


        private void frmViewEscalation_Load(object sender, EventArgs e)
        {
            dtUserReport = DAL.fnNCUserReport(9, Login.GetUserDetails[2].ToLower().ToString()).Tables[0];

            dgvUserDetails.AutoGenerateColumns = true;

            dgvUserDetails.DataSource = dtUserReport;
        }
    }
}
