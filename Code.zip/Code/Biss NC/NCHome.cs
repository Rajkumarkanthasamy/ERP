﻿using System;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Biss_NC
{
    public partial class NCHome : Form
    {
        frmForm2 frm = new frmForm2();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm Login = new Login.frmLoginForm();
        public NCHome()
        {
            InitializeComponent();
        }

        private void btnpogeanarate_Click(object sender, EventArgs e)
        {
            Biss_NC.frmRaiseNC Raise = new Biss_NC.frmRaiseNC();
            Raise.Show();
            this.Hide();
        }

        private void NCHome_Load(object sender, EventArgs e)
        {
            lblusername.Text = Login.GetUserDetails[2];
        }

        private void NCHome_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            frm.Show();
        }

        private void BtnEscalation_Click(object sender, EventArgs e)
        {
            Biss_NC.Escalation escal = new Biss_NC.Escalation();
            escal.Show();
            this.Hide();
        }

        private void btnUserReport_Click(object sender, EventArgs e)
        {

        }

        private void btnSummary_Click(object sender, EventArgs e)
        {

        }
    }
}
