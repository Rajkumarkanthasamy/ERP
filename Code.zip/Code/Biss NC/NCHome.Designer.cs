﻿namespace Erp_Project_With_Buttons.Biss_NC
{
    partial class NCHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NCHome));
            this.lblusername = new System.Windows.Forms.Label();
            this.lblwelcome = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.BtnEscalation = new System.Windows.Forms.Button();
            this.btnSummary = new System.Windows.Forms.Button();
            this.btnUserReport = new System.Windows.Forms.Button();
            this.btnpogeanarate = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblusername
            // 
            this.lblusername.AutoSize = true;
            this.lblusername.Font = new System.Drawing.Font("Times New Roman", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblusername.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblusername.Location = new System.Drawing.Point(91, 384);
            this.lblusername.Name = "lblusername";
            this.lblusername.Size = new System.Drawing.Size(27, 22);
            this.lblusername.TabIndex = 21;
            this.lblusername.Text = "M";
            // 
            // lblwelcome
            // 
            this.lblwelcome.AutoSize = true;
            this.lblwelcome.Font = new System.Drawing.Font("Calibri", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblwelcome.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblwelcome.Location = new System.Drawing.Point(4, 383);
            this.lblwelcome.Name = "lblwelcome";
            this.lblwelcome.Size = new System.Drawing.Size(91, 23);
            this.lblwelcome.TabIndex = 20;
            this.lblwelcome.Text = "Welcome :";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.lblusername);
            this.panel2.Controls.Add(this.BtnEscalation);
            this.panel2.Controls.Add(this.lblwelcome);
            this.panel2.Controls.Add(this.btnSummary);
            this.panel2.Controls.Add(this.btnUserReport);
            this.panel2.Controls.Add(this.btnpogeanarate);
            this.panel2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.Location = new System.Drawing.Point(6, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1085, 425);
            this.panel2.TabIndex = 19;
            // 
            // BtnEscalation
            // 
            this.BtnEscalation.FlatAppearance.BorderSize = 0;
            this.BtnEscalation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnEscalation.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEscalation.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnEscalation.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_transfer_48;
            this.BtnEscalation.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.BtnEscalation.Location = new System.Drawing.Point(222, 34);
            this.BtnEscalation.Name = "BtnEscalation";
            this.BtnEscalation.Size = new System.Drawing.Size(136, 80);
            this.BtnEscalation.TabIndex = 11;
            this.BtnEscalation.Text = "Escalation";
            this.BtnEscalation.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.BtnEscalation.UseVisualStyleBackColor = true;
            this.BtnEscalation.Click += new System.EventHandler(this.BtnEscalation_Click);
            // 
            // btnSummary
            // 
            this.btnSummary.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnSummary.FlatAppearance.BorderSize = 0;
            this.btnSummary.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSummary.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSummary.ForeColor = System.Drawing.Color.Black;
            this.btnSummary.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_microsoft_excel_48;
            this.btnSummary.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnSummary.Location = new System.Drawing.Point(251, 230);
            this.btnSummary.Name = "btnSummary";
            this.btnSummary.Size = new System.Drawing.Size(82, 80);
            this.btnSummary.TabIndex = 10;
            this.btnSummary.Text = "Reports";
            this.btnSummary.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnSummary.UseVisualStyleBackColor = false;
            this.btnSummary.Visible = false;
            this.btnSummary.Click += new System.EventHandler(this.btnSummary_Click);
            // 
            // btnUserReport
            // 
            this.btnUserReport.FlatAppearance.BorderSize = 0;
            this.btnUserReport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUserReport.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUserReport.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnUserReport.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_view_48;
            this.btnUserReport.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnUserReport.Location = new System.Drawing.Point(49, 230);
            this.btnUserReport.Name = "btnUserReport";
            this.btnUserReport.Size = new System.Drawing.Size(120, 83);
            this.btnUserReport.TabIndex = 9;
            this.btnUserReport.Text = "View NC";
            this.btnUserReport.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnUserReport.UseVisualStyleBackColor = true;
            this.btnUserReport.Visible = false;
            this.btnUserReport.Click += new System.EventHandler(this.btnUserReport_Click);
            // 
            // btnpogeanarate
            // 
            this.btnpogeanarate.FlatAppearance.BorderSize = 0;
            this.btnpogeanarate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnpogeanarate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnpogeanarate.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnpogeanarate.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_task_planning_48__1_1;
            this.btnpogeanarate.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnpogeanarate.Location = new System.Drawing.Point(49, 34);
            this.btnpogeanarate.Name = "btnpogeanarate";
            this.btnpogeanarate.Size = new System.Drawing.Size(136, 80);
            this.btnpogeanarate.TabIndex = 0;
            this.btnpogeanarate.Text = "NC";
            this.btnpogeanarate.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnpogeanarate.UseVisualStyleBackColor = true;
            this.btnpogeanarate.Click += new System.EventHandler(this.btnpogeanarate_Click);
            // 
            // NCHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1096, 442);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "NCHome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "NC";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.NCHome_FormClosing);
            this.Load += new System.EventHandler(this.NCHome_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }
        #endregion

        private System.Windows.Forms.Label lblusername;
        private System.Windows.Forms.Label lblwelcome;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnSummary;
        private System.Windows.Forms.Button btnUserReport;
        private System.Windows.Forms.Button btnpogeanarate;
        private System.Windows.Forms.Button BtnEscalation;
    }
}
