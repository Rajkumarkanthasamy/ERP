﻿namespace Erp_Project_With_Buttons.Biss_NC
{
    partial class frmRaiseNC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRaiseNC));
            this.lblNCnumber = new System.Windows.Forms.Label();
            this.txtNCnumber = new System.Windows.Forms.TextBox();
            this.btnViewNC = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.cmbVendorName = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.pnReassign = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.btnReassign = new System.Windows.Forms.Button();
            this.cmbReassignDept = new System.Windows.Forms.ComboBox();
            this.lstusers = new System.Windows.Forms.ListBox();
            this.cmbReAssign = new System.Windows.Forms.ComboBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.cmbCCUser = new System.Windows.Forms.ComboBox();
            this.chkReAssign = new System.Windows.Forms.CheckBox();
            this.pnSave1 = new System.Windows.Forms.Panel();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.pnObjectiveEvidence = new System.Windows.Forms.Panel();
            this.txtManHours = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.btnAcceptnCloseNC = new System.Windows.Forms.Button();
            this.txtObjectiveEvidenceFound = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCostincurred = new System.Windows.Forms.TextBox();
            this.dtpCloseDate = new System.Windows.Forms.DateTimePicker();
            this.chkEditRootCause = new System.Windows.Forms.CheckBox();
            this.pnRootCause = new System.Windows.Forms.Panel();
            this.btnRootCauseSave = new System.Windows.Forms.Button();
            this.txtRootCause = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtCorrectiveAction = new System.Windows.Forms.TextBox();
            this.dtpPDC2 = new System.Windows.Forms.DateTimePicker();
            this.chkCorrectionEdit = new System.Windows.Forms.CheckBox();
            this.pnCorrection = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.btnCorrectionSave = new System.Windows.Forms.Button();
            this.txtCorrectionRequested = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.dtpPDC1 = new System.Windows.Forms.DateTimePicker();
            this.label16 = new System.Windows.Forms.Label();
            this.cmbDisposition = new System.Windows.Forms.ComboBox();
            this.lstAddUser = new System.Windows.Forms.ListBox();
            this.label22 = new System.Windows.Forms.Label();
            this.cmbUserCC = new System.Windows.Forms.ComboBox();
            this.txtAssignedtoDept = new System.Windows.Forms.ComboBox();
            this.txtOptionalOE = new System.Windows.Forms.TextBox();
            this.cmbSubProduct = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.cmbComponentType = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtObservation = new System.Windows.Forms.TextBox();
            this.txtRequesterName = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbEnvironMent = new System.Windows.Forms.ComboBox();
            this.lblprojname = new System.Windows.Forms.Label();
            this.txtDescriptionofNC = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbNCType = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblProjectDescription = new System.Windows.Forms.Label();
            this.txtRequesterDept = new System.Windows.Forms.TextBox();
            this.cmbPriority = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbAssignedTo = new System.Windows.Forms.ComboBox();
            this.btnProjectView = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lblCustomer = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbProjectcode = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.dtpCreatedDate = new System.Windows.Forms.DateTimePicker();
            this.panel2.SuspendLayout();
            this.pnReassign.SuspendLayout();
            this.pnSave1.SuspendLayout();
            this.pnObjectiveEvidence.SuspendLayout();
            this.pnRootCause.SuspendLayout();
            this.pnCorrection.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNCnumber
            // 
            this.lblNCnumber.AutoSize = true;
            this.lblNCnumber.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNCnumber.Location = new System.Drawing.Point(487, 4);
            this.lblNCnumber.Name = "lblNCnumber";
            this.lblNCnumber.Size = new System.Drawing.Size(92, 19);
            this.lblNCnumber.TabIndex = 192;
            this.lblNCnumber.Text = "NC Number:";
            this.lblNCnumber.Visible = false;
            // 
            // txtNCnumber
            // 
            this.txtNCnumber.Enabled = false;
            this.txtNCnumber.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNCnumber.Location = new System.Drawing.Point(580, 1);
            this.txtNCnumber.Name = "txtNCnumber";
            this.txtNCnumber.Size = new System.Drawing.Size(325, 27);
            this.txtNCnumber.TabIndex = 193;
            this.txtNCnumber.Visible = false;
            // 
            // btnViewNC
            // 
            this.btnViewNC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnViewNC.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewNC.Location = new System.Drawing.Point(128, 1);
            this.btnViewNC.Name = "btnViewNC";
            this.btnViewNC.Size = new System.Drawing.Size(120, 25);
            this.btnViewNC.TabIndex = 191;
            this.btnViewNC.Text = "View NC";
            this.btnViewNC.UseVisualStyleBackColor = false;
            this.btnViewNC.Click += new System.EventHandler(this.btnViewNC_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.radioButton1);
            this.panel2.Controls.Add(this.cmbVendorName);
            this.panel2.Controls.Add(this.label24);
            this.panel2.Controls.Add(this.pnReassign);
            this.panel2.Controls.Add(this.chkReAssign);
            this.panel2.Controls.Add(this.pnSave1);
            this.panel2.Controls.Add(this.pnObjectiveEvidence);
            this.panel2.Controls.Add(this.chkEditRootCause);
            this.panel2.Controls.Add(this.pnRootCause);
            this.panel2.Controls.Add(this.chkCorrectionEdit);
            this.panel2.Controls.Add(this.pnCorrection);
            this.panel2.Controls.Add(this.lstAddUser);
            this.panel2.Controls.Add(this.label22);
            this.panel2.Controls.Add(this.cmbUserCC);
            this.panel2.Controls.Add(this.txtAssignedtoDept);
            this.panel2.Controls.Add(this.txtOptionalOE);
            this.panel2.Controls.Add(this.cmbSubProduct);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Controls.Add(this.label27);
            this.panel2.Controls.Add(this.label31);
            this.panel2.Controls.Add(this.cmbComponentType);
            this.panel2.Controls.Add(this.label26);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.txtObservation);
            this.panel2.Controls.Add(this.txtRequesterName);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.cmbEnvironMent);
            this.panel2.Controls.Add(this.lblprojname);
            this.panel2.Controls.Add(this.txtDescriptionofNC);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.cmbNCType);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.lblProjectDescription);
            this.panel2.Controls.Add(this.txtRequesterDept);
            this.panel2.Controls.Add(this.cmbPriority);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.cmbAssignedTo);
            this.panel2.Controls.Add(this.btnProjectView);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.lblCustomer);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.cmbProjectcode);
            this.panel2.Location = new System.Drawing.Point(-1, 29);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1329, 632);
            this.panel2.TabIndex = 194;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton1.Location = new System.Drawing.Point(394, 294);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(75, 23);
            this.radioButton1.TabIndex = 201;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Repeat";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // cmbVendorName
            // 
            this.cmbVendorName.DropDownHeight = 130;
            this.cmbVendorName.Enabled = false;
            this.cmbVendorName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbVendorName.FormattingEnabled = true;
            this.cmbVendorName.IntegralHeight = false;
            this.cmbVendorName.Location = new System.Drawing.Point(127, 325);
            this.cmbVendorName.Name = "cmbVendorName";
            this.cmbVendorName.Size = new System.Drawing.Size(259, 27);
            this.cmbVendorName.TabIndex = 200;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(52, 328);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(74, 19);
            this.label24.TabIndex = 199;
            this.label24.Text = "Supplier :";
            // 
            // pnReassign
            // 
            this.pnReassign.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnReassign.Controls.Add(this.label20);
            this.pnReassign.Controls.Add(this.btnReassign);
            this.pnReassign.Controls.Add(this.cmbReassignDept);
            this.pnReassign.Controls.Add(this.lstusers);
            this.pnReassign.Controls.Add(this.cmbReAssign);
            this.pnReassign.Controls.Add(this.label32);
            this.pnReassign.Controls.Add(this.label30);
            this.pnReassign.Controls.Add(this.cmbCCUser);
            this.pnReassign.Enabled = false;
            this.pnReassign.Location = new System.Drawing.Point(9, 549);
            this.pnReassign.Name = "pnReassign";
            this.pnReassign.Size = new System.Drawing.Size(649, 76);
            this.pnReassign.TabIndex = 191;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(235, 9);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(100, 19);
            this.label20.TabIndex = 194;
            this.label20.Text = "Department :";
            // 
            // btnReassign
            // 
            this.btnReassign.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnReassign.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnReassign.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReassign.Location = new System.Drawing.Point(337, 39);
            this.btnReassign.Name = "btnReassign";
            this.btnReassign.Size = new System.Drawing.Size(90, 30);
            this.btnReassign.TabIndex = 193;
            this.btnReassign.Text = "Re Assign";
            this.btnReassign.UseVisualStyleBackColor = false;
            this.btnReassign.Click += new System.EventHandler(this.btnReassign_Click);
            // 
            // cmbReassignDept
            // 
            this.cmbReassignDept.DropDownHeight = 130;
            this.cmbReassignDept.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbReassignDept.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbReassignDept.FormattingEnabled = true;
            this.cmbReassignDept.IntegralHeight = false;
            this.cmbReassignDept.Items.AddRange(new object[] {
            "Design",
            "Application Development",
            "Electronics Design",
            "Mech Production",
            "Hydraulics Production",
            "Electrical Integration",
            "Controllers",
            "Transducers",
            "System Integration",
            "Purchase",
            "Validation",
            "Sales"});
            this.cmbReassignDept.Location = new System.Drawing.Point(337, 6);
            this.cmbReassignDept.Name = "cmbReassignDept";
            this.cmbReassignDept.Size = new System.Drawing.Size(123, 27);
            this.cmbReassignDept.TabIndex = 191;
            // 
            // lstusers
            // 
            this.lstusers.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstusers.FormattingEnabled = true;
            this.lstusers.ItemHeight = 19;
            this.lstusers.Location = new System.Drawing.Point(466, 6);
            this.lstusers.Name = "lstusers";
            this.lstusers.ScrollAlwaysVisible = true;
            this.lstusers.Size = new System.Drawing.Size(176, 61);
            this.lstusers.TabIndex = 188;
            this.lstusers.KeyUp += new System.Windows.Forms.KeyEventHandler(this.lstusers_KeyUp);
            // 
            // cmbReAssign
            // 
            this.cmbReAssign.DropDownHeight = 130;
            this.cmbReAssign.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbReAssign.FormattingEnabled = true;
            this.cmbReAssign.IntegralHeight = false;
            this.cmbReAssign.Location = new System.Drawing.Point(108, 6);
            this.cmbReAssign.Name = "cmbReAssign";
            this.cmbReAssign.Size = new System.Drawing.Size(127, 27);
            this.cmbReAssign.TabIndex = 185;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(20, 46);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(84, 19);
            this.label32.TabIndex = 189;
            this.label32.Text = "Add CC to :";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(6, 6);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(100, 19);
            this.label30.TabIndex = 184;
            this.label30.Text = "Re Assign to :";
            // 
            // cmbCCUser
            // 
            this.cmbCCUser.DropDownHeight = 130;
            this.cmbCCUser.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCCUser.FormattingEnabled = true;
            this.cmbCCUser.IntegralHeight = false;
            this.cmbCCUser.Location = new System.Drawing.Point(108, 43);
            this.cmbCCUser.Name = "cmbCCUser";
            this.cmbCCUser.Size = new System.Drawing.Size(127, 27);
            this.cmbCCUser.TabIndex = 190;
            this.cmbCCUser.SelectedIndexChanged += new System.EventHandler(this.cmbCCUser_SelectedIndexChanged);
            // 
            // chkReAssign
            // 
            this.chkReAssign.AutoSize = true;
            this.chkReAssign.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkReAssign.Location = new System.Drawing.Point(9, 516);
            this.chkReAssign.Name = "chkReAssign";
            this.chkReAssign.Size = new System.Drawing.Size(92, 23);
            this.chkReAssign.TabIndex = 192;
            this.chkReAssign.Text = "Re Assign";
            this.chkReAssign.UseVisualStyleBackColor = true;
            this.chkReAssign.CheckedChanged += new System.EventHandler(this.chkReAssign_CheckedChanged);
            // 
            // pnSave1
            // 
            this.pnSave1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnSave1.Controls.Add(this.btnSave);
            this.pnSave1.Controls.Add(this.btnExit);
            this.pnSave1.Location = new System.Drawing.Point(676, 548);
            this.pnSave1.Name = "pnSave1";
            this.pnSave1.Size = new System.Drawing.Size(228, 77);
            this.pnSave1.TabIndex = 170;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(19, 22);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(90, 39);
            this.btnSave.TabIndex = 167;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(115, 22);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(90, 39);
            this.btnExit.TabIndex = 166;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // pnObjectiveEvidence
            // 
            this.pnObjectiveEvidence.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnObjectiveEvidence.Controls.Add(this.txtManHours);
            this.pnObjectiveEvidence.Controls.Add(this.label23);
            this.pnObjectiveEvidence.Controls.Add(this.btnAcceptnCloseNC);
            this.pnObjectiveEvidence.Controls.Add(this.txtObjectiveEvidenceFound);
            this.pnObjectiveEvidence.Controls.Add(this.label15);
            this.pnObjectiveEvidence.Controls.Add(this.label2);
            this.pnObjectiveEvidence.Controls.Add(this.txtCostincurred);
            this.pnObjectiveEvidence.Controls.Add(this.dtpCloseDate);
            this.pnObjectiveEvidence.Location = new System.Drawing.Point(910, 441);
            this.pnObjectiveEvidence.Name = "pnObjectiveEvidence";
            this.pnObjectiveEvidence.Size = new System.Drawing.Size(408, 186);
            this.pnObjectiveEvidence.TabIndex = 198;
            this.pnObjectiveEvidence.Visible = false;
            // 
            // txtManHours
            // 
            this.txtManHours.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtManHours.Location = new System.Drawing.Point(159, 152);
            this.txtManHours.Name = "txtManHours";
            this.txtManHours.Size = new System.Drawing.Size(123, 27);
            this.txtManHours.TabIndex = 187;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(14, 152);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(134, 19);
            this.label23.TabIndex = 186;
            this.label23.Text = "Man Hours in hrs :";
            // 
            // btnAcceptnCloseNC
            // 
            this.btnAcceptnCloseNC.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAcceptnCloseNC.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAcceptnCloseNC.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAcceptnCloseNC.Location = new System.Drawing.Point(300, 145);
            this.btnAcceptnCloseNC.Name = "btnAcceptnCloseNC";
            this.btnAcceptnCloseNC.Size = new System.Drawing.Size(101, 34);
            this.btnAcceptnCloseNC.TabIndex = 168;
            this.btnAcceptnCloseNC.Text = "Close NC";
            this.btnAcceptnCloseNC.UseVisualStyleBackColor = false;
            this.btnAcceptnCloseNC.Click += new System.EventHandler(this.btnAcceptnCloseNC_Click);
            // 
            // txtObjectiveEvidenceFound
            // 
            this.txtObjectiveEvidenceFound.Font = new System.Drawing.Font("Calibri", 12F);
            this.txtObjectiveEvidenceFound.Location = new System.Drawing.Point(7, 24);
            this.txtObjectiveEvidenceFound.Multiline = true;
            this.txtObjectiveEvidenceFound.Name = "txtObjectiveEvidenceFound";
            this.txtObjectiveEvidenceFound.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtObjectiveEvidenceFound.Size = new System.Drawing.Size(394, 91);
            this.txtObjectiveEvidenceFound.TabIndex = 167;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(7, 4);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(138, 19);
            this.label15.TabIndex = 166;
            this.label15.Text = "Objective Evidence";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(7, 121);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(146, 19);
            this.label2.TabIndex = 183;
            this.label2.Text = "Cost Incurred in RS :";
            // 
            // txtCostincurred
            // 
            this.txtCostincurred.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCostincurred.Location = new System.Drawing.Point(159, 121);
            this.txtCostincurred.Name = "txtCostincurred";
            this.txtCostincurred.Size = new System.Drawing.Size(123, 27);
            this.txtCostincurred.TabIndex = 184;
            // 
            // dtpCloseDate
            // 
            this.dtpCloseDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.dtpCloseDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpCloseDate.Location = new System.Drawing.Point(171, 122);
            this.dtpCloseDate.Name = "dtpCloseDate";
            this.dtpCloseDate.Size = new System.Drawing.Size(25, 27);
            this.dtpCloseDate.TabIndex = 185;
            this.dtpCloseDate.Visible = false;
            // 
            // chkEditRootCause
            // 
            this.chkEditRootCause.AutoSize = true;
            this.chkEditRootCause.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkEditRootCause.Location = new System.Drawing.Point(913, 182);
            this.chkEditRootCause.Name = "chkEditRootCause";
            this.chkEditRootCause.Size = new System.Drawing.Size(55, 23);
            this.chkEditRootCause.TabIndex = 197;
            this.chkEditRootCause.Text = "Edit";
            this.chkEditRootCause.UseVisualStyleBackColor = true;
            this.chkEditRootCause.Visible = false;
            this.chkEditRootCause.CheckedChanged += new System.EventHandler(this.chkEditRootCause_CheckedChanged);
            // 
            // pnRootCause
            // 
            this.pnRootCause.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnRootCause.Controls.Add(this.btnRootCauseSave);
            this.pnRootCause.Controls.Add(this.txtRootCause);
            this.pnRootCause.Controls.Add(this.label13);
            this.pnRootCause.Controls.Add(this.label17);
            this.pnRootCause.Controls.Add(this.label14);
            this.pnRootCause.Controls.Add(this.txtCorrectiveAction);
            this.pnRootCause.Controls.Add(this.dtpPDC2);
            this.pnRootCause.Enabled = false;
            this.pnRootCause.Location = new System.Drawing.Point(910, 204);
            this.pnRootCause.Name = "pnRootCause";
            this.pnRootCause.Size = new System.Drawing.Size(413, 234);
            this.pnRootCause.TabIndex = 196;
            // 
            // btnRootCauseSave
            // 
            this.btnRootCauseSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnRootCauseSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnRootCauseSave.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRootCauseSave.Location = new System.Drawing.Point(338, 207);
            this.btnRootCauseSave.Name = "btnRootCauseSave";
            this.btnRootCauseSave.Size = new System.Drawing.Size(72, 25);
            this.btnRootCauseSave.TabIndex = 193;
            this.btnRootCauseSave.Text = "Save";
            this.btnRootCauseSave.UseVisualStyleBackColor = false;
            this.btnRootCauseSave.Click += new System.EventHandler(this.btnRootCauseSave_Click);
            // 
            // txtRootCause
            // 
            this.txtRootCause.Font = new System.Drawing.Font("Calibri", 12F);
            this.txtRootCause.Location = new System.Drawing.Point(7, 23);
            this.txtRootCause.Multiline = true;
            this.txtRootCause.Name = "txtRootCause";
            this.txtRootCause.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRootCause.Size = new System.Drawing.Size(403, 82);
            this.txtRootCause.TabIndex = 152;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(8, -2);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(93, 19);
            this.label13.TabIndex = 161;
            this.label13.Text = "Root Cause :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(274, 2);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(44, 19);
            this.label17.TabIndex = 191;
            this.label17.Text = "PDC :";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(6, 107);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(134, 19);
            this.label14.TabIndex = 163;
            this.label14.Text = "Corrective Action :";
            // 
            // txtCorrectiveAction
            // 
            this.txtCorrectiveAction.Font = new System.Drawing.Font("Calibri", 12F);
            this.txtCorrectiveAction.Location = new System.Drawing.Point(8, 125);
            this.txtCorrectiveAction.Multiline = true;
            this.txtCorrectiveAction.Name = "txtCorrectiveAction";
            this.txtCorrectiveAction.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtCorrectiveAction.Size = new System.Drawing.Size(403, 82);
            this.txtCorrectiveAction.TabIndex = 162;
            // 
            // dtpPDC2
            // 
            this.dtpPDC2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpPDC2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpPDC2.Location = new System.Drawing.Point(322, -1);
            this.dtpPDC2.Name = "dtpPDC2";
            this.dtpPDC2.Size = new System.Drawing.Size(89, 26);
            this.dtpPDC2.TabIndex = 169;
            this.dtpPDC2.ValueChanged += new System.EventHandler(this.dtpPDC2_ValueChanged);
            // 
            // chkCorrectionEdit
            // 
            this.chkCorrectionEdit.AutoSize = true;
            this.chkCorrectionEdit.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkCorrectionEdit.Location = new System.Drawing.Point(910, 1);
            this.chkCorrectionEdit.Name = "chkCorrectionEdit";
            this.chkCorrectionEdit.Size = new System.Drawing.Size(55, 23);
            this.chkCorrectionEdit.TabIndex = 194;
            this.chkCorrectionEdit.Text = "Edit";
            this.chkCorrectionEdit.UseVisualStyleBackColor = true;
            this.chkCorrectionEdit.Visible = false;
            this.chkCorrectionEdit.CheckedChanged += new System.EventHandler(this.chkCorrectionEdit_CheckedChanged);
            // 
            // pnCorrection
            // 
            this.pnCorrection.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnCorrection.Controls.Add(this.label19);
            this.pnCorrection.Controls.Add(this.btnCorrectionSave);
            this.pnCorrection.Controls.Add(this.txtCorrectionRequested);
            this.pnCorrection.Controls.Add(this.label10);
            this.pnCorrection.Controls.Add(this.dtpPDC1);
            this.pnCorrection.Controls.Add(this.label16);
            this.pnCorrection.Controls.Add(this.cmbDisposition);
            this.pnCorrection.Enabled = false;
            this.pnCorrection.Location = new System.Drawing.Point(910, 23);
            this.pnCorrection.Name = "pnCorrection";
            this.pnCorrection.Size = new System.Drawing.Size(417, 158);
            this.pnCorrection.TabIndex = 195;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(2, 5);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(92, 19);
            this.label19.TabIndex = 172;
            this.label19.Text = "Disposition :";
            // 
            // btnCorrectionSave
            // 
            this.btnCorrectionSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnCorrectionSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCorrectionSave.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCorrectionSave.Location = new System.Drawing.Point(339, 128);
            this.btnCorrectionSave.Name = "btnCorrectionSave";
            this.btnCorrectionSave.Size = new System.Drawing.Size(72, 25);
            this.btnCorrectionSave.TabIndex = 192;
            this.btnCorrectionSave.Text = "Save";
            this.btnCorrectionSave.UseVisualStyleBackColor = false;
            this.btnCorrectionSave.Click += new System.EventHandler(this.btnCorrectionSave_Click);
            // 
            // txtCorrectionRequested
            // 
            this.txtCorrectionRequested.Font = new System.Drawing.Font("Calibri", 12F);
            this.txtCorrectionRequested.Location = new System.Drawing.Point(5, 46);
            this.txtCorrectionRequested.Multiline = true;
            this.txtCorrectionRequested.Name = "txtCorrectionRequested";
            this.txtCorrectionRequested.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtCorrectionRequested.Size = new System.Drawing.Size(403, 82);
            this.txtCorrectionRequested.TabIndex = 150;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(5, 28);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(88, 19);
            this.label10.TabIndex = 151;
            this.label10.Text = "Correction :";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // dtpPDC1
            // 
            this.dtpPDC1.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.dtpPDC1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpPDC1.Location = new System.Drawing.Point(322, 3);
            this.dtpPDC1.Name = "dtpPDC1";
            this.dtpPDC1.Size = new System.Drawing.Size(88, 26);
            this.dtpPDC1.TabIndex = 168;
            this.dtpPDC1.ValueChanged += new System.EventHandler(this.dtpPDC1_ValueChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(275, 7);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(44, 19);
            this.label16.TabIndex = 170;
            this.label16.Text = "PDC :";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cmbDisposition
            // 
            this.cmbDisposition.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDisposition.FormattingEnabled = true;
            this.cmbDisposition.Items.AddRange(new object[] {
            "Use as is",
            "Return to supplier",
            "Repair/Rework",
            "Reject"});
            this.cmbDisposition.Location = new System.Drawing.Point(96, 3);
            this.cmbDisposition.Name = "cmbDisposition";
            this.cmbDisposition.Size = new System.Drawing.Size(165, 27);
            this.cmbDisposition.TabIndex = 173;
            // 
            // lstAddUser
            // 
            this.lstAddUser.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstAddUser.FormattingEnabled = true;
            this.lstAddUser.ItemHeight = 19;
            this.lstAddUser.Location = new System.Drawing.Point(128, 461);
            this.lstAddUser.Name = "lstAddUser";
            this.lstAddUser.ScrollAlwaysVisible = true;
            this.lstAddUser.Size = new System.Drawing.Size(259, 80);
            this.lstAddUser.TabIndex = 193;
            this.lstAddUser.KeyUp += new System.Windows.Forms.KeyEventHandler(this.lstAddUser_KeyUp);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(42, 431);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(84, 19);
            this.label22.TabIndex = 191;
            this.label22.Text = "Add CC to :";
            // 
            // cmbUserCC
            // 
            this.cmbUserCC.DropDownHeight = 130;
            this.cmbUserCC.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbUserCC.FormattingEnabled = true;
            this.cmbUserCC.IntegralHeight = false;
            this.cmbUserCC.Location = new System.Drawing.Point(127, 428);
            this.cmbUserCC.Name = "cmbUserCC";
            this.cmbUserCC.Size = new System.Drawing.Size(260, 27);
            this.cmbUserCC.TabIndex = 192;
            this.cmbUserCC.SelectedIndexChanged += new System.EventHandler(this.cmbUserCC_SelectedIndexChanged);
            // 
            // txtAssignedtoDept
            // 
            this.txtAssignedtoDept.DropDownHeight = 130;
            this.txtAssignedtoDept.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtAssignedtoDept.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAssignedtoDept.FormattingEnabled = true;
            this.txtAssignedtoDept.IntegralHeight = false;
            this.txtAssignedtoDept.Items.AddRange(new object[] {
            "Application Development",
            "Controllers",
            "Design",
            "Electrical Integration",
            "Electronics Design",
            "Hydraulics Production",
            "Mech Production",
            "MTL 32",
            "Purchase",
            "Sales",
            "System Integration",
            "Transducers",
            "Validation"});
            this.txtAssignedtoDept.Location = new System.Drawing.Point(127, 177);
            this.txtAssignedtoDept.Name = "txtAssignedtoDept";
            this.txtAssignedtoDept.Size = new System.Drawing.Size(260, 27);
            this.txtAssignedtoDept.Sorted = true;
            this.txtAssignedtoDept.TabIndex = 183;
            // 
            // txtOptionalOE
            // 
            this.txtOptionalOE.Font = new System.Drawing.Font("Calibri", 12F);
            this.txtOptionalOE.Location = new System.Drawing.Point(580, 311);
            this.txtOptionalOE.Multiline = true;
            this.txtOptionalOE.Name = "txtOptionalOE";
            this.txtOptionalOE.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtOptionalOE.Size = new System.Drawing.Size(322, 78);
            this.txtOptionalOE.TabIndex = 175;
            // 
            // cmbSubProduct
            // 
            this.cmbSubProduct.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSubProduct.FormattingEnabled = true;
            this.cmbSubProduct.Location = new System.Drawing.Point(128, 394);
            this.cmbSubProduct.Name = "cmbSubProduct";
            this.cmbSubProduct.Size = new System.Drawing.Size(259, 27);
            this.cmbSubProduct.TabIndex = 182;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(431, 318);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(146, 38);
            this.label21.TabIndex = 174;
            this.label21.Text = "Objective Evidence :\r\n       (Optional)";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Calibri", 12F);
            this.textBox1.Location = new System.Drawing.Point(580, 420);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1.Size = new System.Drawing.Size(323, 79);
            this.textBox1.TabIndex = 186;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(24, 397);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(102, 19);
            this.label27.TabIndex = 181;
            this.label27.Text = "Sub Product :";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(414, 420);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(165, 19);
            this.label31.TabIndex = 187;
            this.label31.Text = "NC Review Comments :";
            // 
            // cmbComponentType
            // 
            this.cmbComponentType.DropDownWidth = 445;
            this.cmbComponentType.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbComponentType.FormattingEnabled = true;
            this.cmbComponentType.Items.AddRange(new object[] {
            "Load Frame",
            "Actuators",
            "Grips & Fixtures",
            "Controllers",
            "Application Software",
            "MTL 32",
            "Electrical",
            "Power Pack",
            "Transducers"});
            this.cmbComponentType.Location = new System.Drawing.Point(128, 359);
            this.cmbComponentType.Name = "cmbComponentType";
            this.cmbComponentType.Size = new System.Drawing.Size(259, 27);
            this.cmbComponentType.TabIndex = 180;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(54, 362);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(72, 19);
            this.label26.TabIndex = 179;
            this.label26.Text = "Product :";
            // 
            // label18
            // 
            this.label18.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(446, 200);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(131, 56);
            this.label18.TabIndex = 171;
            this.label18.Text = "Observation /  \r\nConsequence :";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtObservation
            // 
            this.txtObservation.Font = new System.Drawing.Font("Calibri", 12F);
            this.txtObservation.Location = new System.Drawing.Point(580, 205);
            this.txtObservation.Multiline = true;
            this.txtObservation.Name = "txtObservation";
            this.txtObservation.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtObservation.Size = new System.Drawing.Size(322, 76);
            this.txtObservation.TabIndex = 170;
            // 
            // txtRequesterName
            // 
            this.txtRequesterName.Enabled = false;
            this.txtRequesterName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRequesterName.Location = new System.Drawing.Point(129, 7);
            this.txtRequesterName.Name = "txtRequesterName";
            this.txtRequesterName.Size = new System.Drawing.Size(258, 27);
            this.txtRequesterName.TabIndex = 142;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(475, 10);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 19);
            this.label8.TabIndex = 139;
            this.label8.Text = "Department :";
            // 
            // cmbEnvironMent
            // 
            this.cmbEnvironMent.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbEnvironMent.FormattingEnabled = true;
            this.cmbEnvironMent.Items.AddRange(new object[] {
            "In House",
            "On Site",
            "KPI",
            "Internal Audit",
            "External Audit",
            "Supplier NC"});
            this.cmbEnvironMent.Location = new System.Drawing.Point(128, 214);
            this.cmbEnvironMent.Name = "cmbEnvironMent";
            this.cmbEnvironMent.Size = new System.Drawing.Size(259, 27);
            this.cmbEnvironMent.TabIndex = 155;
            // 
            // lblprojname
            // 
            this.lblprojname.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprojname.ForeColor = System.Drawing.Color.Black;
            this.lblprojname.Location = new System.Drawing.Point(129, 93);
            this.lblprojname.Name = "lblprojname";
            this.lblprojname.Size = new System.Drawing.Size(289, 36);
            this.lblprojname.TabIndex = 157;
            this.lblprojname.Text = "P";
            // 
            // txtDescriptionofNC
            // 
            this.txtDescriptionofNC.Font = new System.Drawing.Font("Calibri", 12F);
            this.txtDescriptionofNC.Location = new System.Drawing.Point(580, 99);
            this.txtDescriptionofNC.Multiline = true;
            this.txtDescriptionofNC.Name = "txtDescriptionofNC";
            this.txtDescriptionofNC.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDescriptionofNC.Size = new System.Drawing.Size(322, 76);
            this.txtDescriptionofNC.TabIndex = 148;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(442, 102);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(135, 19);
            this.label5.TabIndex = 147;
            this.label5.Text = "Description of NC :";
            // 
            // cmbNCType
            // 
            this.cmbNCType.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbNCType.FormattingEnabled = true;
            this.cmbNCType.Items.AddRange(new object[] {
            "Major",
            "Minor",
            "OFI"});
            this.cmbNCType.Location = new System.Drawing.Point(128, 289);
            this.cmbNCType.Name = "cmbNCType";
            this.cmbNCType.Size = new System.Drawing.Size(259, 27);
            this.cmbNCType.TabIndex = 154;
            this.cmbNCType.SelectedIndexChanged += new System.EventHandler(this.cmbNCType_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(53, 292);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(73, 19);
            this.label11.TabIndex = 153;
            this.label11.Text = "NC Type :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(29, 217);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(97, 19);
            this.label9.TabIndex = 149;
            this.label9.Text = "Evironment :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(493, 51);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(82, 19);
            this.label12.TabIndex = 160;
            this.label12.Text = "Customer :";
            // 
            // lblProjectDescription
            // 
            this.lblProjectDescription.AutoSize = true;
            this.lblProjectDescription.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblProjectDescription.ForeColor = System.Drawing.Color.Black;
            this.lblProjectDescription.Location = new System.Drawing.Point(18, 92);
            this.lblProjectDescription.Name = "lblProjectDescription";
            this.lblProjectDescription.Size = new System.Drawing.Size(110, 19);
            this.lblProjectDescription.TabIndex = 156;
            this.lblProjectDescription.Text = "Project Name :";
            // 
            // txtRequesterDept
            // 
            this.txtRequesterDept.Enabled = false;
            this.txtRequesterDept.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRequesterDept.Location = new System.Drawing.Point(578, 7);
            this.txtRequesterDept.Name = "txtRequesterDept";
            this.txtRequesterDept.Size = new System.Drawing.Size(249, 27);
            this.txtRequesterDept.TabIndex = 140;
            // 
            // cmbPriority
            // 
            this.cmbPriority.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPriority.FormattingEnabled = true;
            this.cmbPriority.Items.AddRange(new object[] {
            "Low",
            "Medium",
            "High"});
            this.cmbPriority.Location = new System.Drawing.Point(128, 251);
            this.cmbPriority.Name = "cmbPriority";
            this.cmbPriority.Size = new System.Drawing.Size(259, 27);
            this.cmbPriority.TabIndex = 136;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(57, 257);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 19);
            this.label6.TabIndex = 135;
            this.label6.Text = "Priority :";
            // 
            // cmbAssignedTo
            // 
            this.cmbAssignedTo.DropDownHeight = 130;
            this.cmbAssignedTo.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbAssignedTo.FormattingEnabled = true;
            this.cmbAssignedTo.IntegralHeight = false;
            this.cmbAssignedTo.Location = new System.Drawing.Point(127, 139);
            this.cmbAssignedTo.Name = "cmbAssignedTo";
            this.cmbAssignedTo.Size = new System.Drawing.Size(260, 27);
            this.cmbAssignedTo.TabIndex = 146;
            // 
            // btnProjectView
            // 
            this.btnProjectView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnProjectView.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProjectView.Location = new System.Drawing.Point(394, 58);
            this.btnProjectView.Name = "btnProjectView";
            this.btnProjectView.Size = new System.Drawing.Size(24, 24);
            this.btnProjectView.TabIndex = 159;
            this.btnProjectView.Text = "....";
            this.btnProjectView.UseVisualStyleBackColor = false;
            this.btnProjectView.Click += new System.EventHandler(this.btnProjectView_Click_1);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(30, 143);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 19);
            this.label3.TabIndex = 145;
            this.label3.Text = "Assigned to :";
            // 
            // lblCustomer
            // 
            this.lblCustomer.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomer.ForeColor = System.Drawing.Color.Black;
            this.lblCustomer.Location = new System.Drawing.Point(575, 51);
            this.lblCustomer.Name = "lblCustomer";
            this.lblCustomer.Size = new System.Drawing.Size(327, 38);
            this.lblCustomer.TabIndex = 158;
            this.lblCustomer.Text = "*";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(26, 183);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 19);
            this.label4.TabIndex = 143;
            this.label4.Text = "Department :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(-2, 10);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(130, 19);
            this.label7.TabIndex = 141;
            this.label7.Text = "Requester Name :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(22, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 19);
            this.label1.TabIndex = 128;
            this.label1.Text = "Project Code :";
            // 
            // cmbProjectcode
            // 
            this.cmbProjectcode.DropDownHeight = 130;
            this.cmbProjectcode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProjectcode.FormattingEnabled = true;
            this.cmbProjectcode.IntegralHeight = false;
            this.cmbProjectcode.Location = new System.Drawing.Point(129, 55);
            this.cmbProjectcode.Name = "cmbProjectcode";
            this.cmbProjectcode.Size = new System.Drawing.Size(258, 27);
            this.cmbProjectcode.TabIndex = 129;
            this.cmbProjectcode.SelectedIndexChanged += new System.EventHandler(this.cmbProjectcode_SelectedIndexChanged);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(1180, 6);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(49, 19);
            this.label25.TabIndex = 178;
            this.label25.Text = "Date :";
            // 
            // dtpCreatedDate
            // 
            this.dtpCreatedDate.Enabled = false;
            this.dtpCreatedDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpCreatedDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpCreatedDate.Location = new System.Drawing.Point(1235, 0);
            this.dtpCreatedDate.Name = "dtpCreatedDate";
            this.dtpCreatedDate.Size = new System.Drawing.Size(93, 26);
            this.dtpCreatedDate.TabIndex = 177;
            // 
            // frmRaiseNC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1331, 665);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.lblNCnumber);
            this.Controls.Add(this.txtNCnumber);
            this.Controls.Add(this.btnViewNC);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.dtpCreatedDate);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmRaiseNC";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Raise NC";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmRaiseNC_FormClosing);
            this.Load += new System.EventHandler(this.frmRaiseNC_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.pnReassign.ResumeLayout(false);
            this.pnReassign.PerformLayout();
            this.pnSave1.ResumeLayout(false);
            this.pnObjectiveEvidence.ResumeLayout(false);
            this.pnObjectiveEvidence.PerformLayout();
            this.pnRootCause.ResumeLayout(false);
            this.pnRootCause.PerformLayout();
            this.pnCorrection.ResumeLayout(false);
            this.pnCorrection.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNCnumber;
        private System.Windows.Forms.TextBox txtNCnumber;
        private System.Windows.Forms.Button btnViewNC;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel pnObjectiveEvidence;
        private System.Windows.Forms.TextBox txtManHours;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button btnAcceptnCloseNC;
        private System.Windows.Forms.TextBox txtObjectiveEvidenceFound;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCostincurred;
        private System.Windows.Forms.DateTimePicker dtpCloseDate;
        private System.Windows.Forms.CheckBox chkReAssign;
        private System.Windows.Forms.Panel pnReassign;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button btnReassign;
        private System.Windows.Forms.ComboBox cmbReassignDept;
        private System.Windows.Forms.ListBox lstusers;
        private System.Windows.Forms.ComboBox cmbReAssign;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.ComboBox cmbCCUser;
        private System.Windows.Forms.Panel pnSave1;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.CheckBox chkEditRootCause;
        private System.Windows.Forms.Panel pnRootCause;
        private System.Windows.Forms.Button btnRootCauseSave;
        private System.Windows.Forms.TextBox txtRootCause;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtCorrectiveAction;
        private System.Windows.Forms.DateTimePicker dtpPDC2;
        private System.Windows.Forms.CheckBox chkCorrectionEdit;
        private System.Windows.Forms.Panel pnCorrection;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btnCorrectionSave;
        private System.Windows.Forms.TextBox txtCorrectionRequested;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker dtpPDC1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox cmbDisposition;
        private System.Windows.Forms.ListBox lstAddUser;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox cmbUserCC;
        private System.Windows.Forms.ComboBox txtAssignedtoDept;
        private System.Windows.Forms.TextBox txtOptionalOE;
        private System.Windows.Forms.ComboBox cmbSubProduct;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox cmbComponentType;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.DateTimePicker dtpCreatedDate;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtObservation;
        private System.Windows.Forms.TextBox txtRequesterName;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbEnvironMent;
        private System.Windows.Forms.Label lblprojname;
        private System.Windows.Forms.TextBox txtDescriptionofNC;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbNCType;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblProjectDescription;
        private System.Windows.Forms.TextBox txtRequesterDept;
        private System.Windows.Forms.ComboBox cmbPriority;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbAssignedTo;
        private System.Windows.Forms.Button btnProjectView;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblCustomer;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbProjectcode;
        private System.Windows.Forms.ComboBox cmbVendorName;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.RadioButton radioButton1;
    }
}