﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using Outlook = Microsoft.Office.Interop.Outlook;

namespace Erp_Project_With_Buttons.Biss_NC
{
    public partial class frmRaiseNC : Form
    {
        frmForm2 frm = new frmForm2();
        Login.frmLoginForm Login = new Login.frmLoginForm();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        DataTable dtProjectlist = new DataTable();
        DataTable dtUserName = new DataTable();
        DataTable dtProjectBOM = new DataTable();

        public frmRaiseNC()
        {
            InitializeComponent();
        }
        private static string sProjectCode;
        public string fnProjectcode
        {
            get
            {
                return sProjectCode;
            }
            set
            {
                sProjectCode = value;
            }
        }

        private static string sNCNumberfn;
        public string fnNCNumber
        {
            get
            {
                return sNCNumberfn;
            }
            set
            {
                sNCNumberfn = value;
            }
        }
        private void frmRaiseNC_Load(object sender, EventArgs e)
        {
            txtRequesterName.Text = Login.GetUserDetails[2];
            txtRequesterDept.Text = Login.GetUserDetails[23];

            dtProjectlist = DAL.fnAllProjectList(null).Tables[0];
            foreach (DataRow dr in dtProjectlist.Rows)
            {
                if (!cmbProjectcode.Items.Contains(dr["ProjectCode"].ToString()))
                {
                    cmbProjectcode.Items.Add(dr["ProjectCode"].ToString());
                }
            }


            DataTable dtvendorList = DAL.fnVedorList(null).Tables[0];
            foreach (DataRow dr in dtvendorList.Rows)
            {
                if (!cmbVendorName.Items.Contains(dr["VendorName"].ToString()))
                {
                    cmbVendorName.Items.Add(dr["VendorName"].ToString());
                }
            }

            dtUserName = DAL.fnUserList("", 2).Tables[0];
            foreach (DataRow DR in dtUserName.Rows)
            {
                if (!cmbAssignedTo.Items.Contains(DR["UserName"].ToString()))
                    cmbAssignedTo.Items.Add(DR["UserName"].ToString());

                if (!cmbCCUser.Items.Contains(DR["UserName"].ToString()))
                    cmbCCUser.Items.Add(DR["UserName"].ToString());

                if (!cmbReAssign.Items.Contains(DR["UserName"].ToString()))
                    cmbReAssign.Items.Add(DR["UserName"].ToString());

                if (!cmbUserCC.Items.Contains(DR["UserName"].ToString()))
                    cmbUserCC.Items.Add(DR["UserName"].ToString());
            }
        }

        private void cmbProjectcode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbProjectcode.SelectedIndex == -1)
            {
                lblprojname.ResetText();
                lblCustomer.ResetText();
            }
            else
            {
                DataView dvProject = new DataView(dtProjectlist);
                dvProject.RowFilter = "ProjectCode Like'" + cmbProjectcode.Text + "'";
                DataTable dtrow = dvProject.ToTable();
                lblprojname.Text = dtrow.Rows[0]["ProjectDescription"].ToString();
                lblCustomer.Text = dtrow.Rows[0]["Customer"].ToString();
                dtProjectBOM = DAL.fnProjectBOMList(cmbProjectcode.Text).Tables[0];
                cmbComponentType.Items.Clear();
                if (dtProjectBOM.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtProjectBOM.Rows)
                    {
                        if (!cmbComponentType.Items.Contains(dr["ProductName"].ToString() + " - " + dr["ProductType"].ToString()))
                        {
                            cmbComponentType.Items.Add(dr["ProductName"].ToString() + " - " + dr["ProductType"].ToString());
                        }

                    }
                }

                cmbComponentType.Items.Add("Controller");
                cmbComponentType.Items.Add("Transducer");
                cmbComponentType.Items.Add("Software");
            }
            // btnSave.Enabled = true;
        }
        string sRecieverEmailID;
        private void cmbAssignedTo_SelectedIndexChanged(object sender, EventArgs e)
        {
            sRecieverEmailID = "";
            if (cmbAssignedTo.SelectedIndex == -1)
            {
                //  txtAssignedtoDept.ResetText();
            }
            else
            {
                DataView dvUser = new DataView(dtUserName);
                dvUser.RowFilter = "UserName Like'" + cmbAssignedTo.Text + "'";
                DataTable dtrow = dvUser.ToTable();
                //  txtAssignedtoDept.Text = dtrow.Rows[0]["Department"].ToString();
                sRecieverEmailID = dtrow.Rows[0]["emailid"].ToString();
            }
        }

        private void CreateEMail(string sNCNumber, string sTo, ListBox sCC, string sSubject)
        {
            try
            {
                Outlook.Application oApp = new Outlook.Application();
                Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                oMsg.Subject = "NC Number '" + sNCNumber + "'. '" + lblprojname.Text + "'";
                //  oMsg.iHTMLBody = true;
                oMsg.HTMLBody = sSubject;
                // Add a recipient.
                Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                oRecips.Add(sTo);
                oRecips.ResolveAll();
                if (sCC.Items.Count > 0)
                {
                    Outlook.Recipient oRecip;
                    List<string> sCCRecipsList = new List<string>();
                    foreach (string tempTO in sCC.Items)
                    {
                        if (tempTO != null)
                            sCCRecipsList.Add(tempTO);
                    }
                    foreach (string t in sCCRecipsList)
                    {

                        oRecip = (Outlook.Recipient)oRecips.Add(t);
                        oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                        oRecip.Resolve();
                    }
                    oMsg.Send();
                    oRecip = null;
                }
                else
                {
                    // Send.
                    oMsg.Send();
                    // Clean up.
                    oRecips = null;
                }

                oMsg = null;
                oApp = null;
            }
            catch (Exception ex)
            {

            }
        }
        DataTable dtLoginDetails = new DataTable();
        string sNCNumber;
        int iLastNumber = 0;
        DataTable dtNcNumber = new DataTable();

        private void btnSave_Click(object sender, EventArgs e)
        {
            #region Tab1
            // if (tabControl1.SelectedIndex == 0)
            {
                if (cmbProjectcode.SelectedIndex >= 0 && cmbAssignedTo.SelectedIndex >= 0 && cmbEnvironMent.SelectedIndex >= 0
                   && cmbPriority.SelectedIndex >= 0 && cmbNCType.SelectedIndex >= 0 && !string.IsNullOrEmpty(txtDescriptionofNC.Text))
                {
                    if (btnSave.Text == "Save")
                    {
                        string sYear = DateTime.Today.Year.ToString().Substring(2, 2);
                       // sYear += "-" + DateTime.Today.Month.ToString();
                        dtNcNumber = DAL.fnNCNumber(null).Tables[0];
                        if (dtNcNumber.Rows.Count > 0)
                        {
                            iLastNumber = Convert.ToInt32(dtNcNumber.Rows[0][0].ToString());
                            iLastNumber++;
                        }
                        else
                        {
                            iLastNumber++;
                        }
                        string value = String.Format("{0:D4}", iLastNumber);
                        sNCNumber = ("Bi" + sYear + value);
                        txtRequesterName.Text = Login.GetUserDetails[2];
                        txtRequesterDept.Text = Login.GetUserDetails[23];
                        GlobalClass.iSuccess = DAL.fnAddNC(Global.uINSERT, sNCNumber, Login.GetUserDetails[2], Login.GetUserDetails[23],
                            cmbProjectcode.Text, cmbAssignedTo.Text, txtAssignedtoDept.Text, cmbEnvironMent.Text, cmbPriority.Text, cmbNCType.Text,
                            txtDescriptionofNC.Text, dtpCreatedDate.Text, txtOptionalOE.Text, cmbComponentType.Text, cmbSubProduct.Text, txtObservation.Text, cmbVendorName.Text);

                        MessageBox.Show("New NC '" + sNCNumber + "' raised & assigned to '" + cmbAssignedTo.Text + "' successfully", "Success", 0, MessageBoxIcon.Information);
                        btnSave.Enabled = false;
                        string sMessage = "<font face=Calibri> Dear " + cmbAssignedTo.Text.ToUpper() + ", <br />NC has been raised on the following issue. Please take necessary action within 3 days.<br /> <br /> <b> Priority :</b> " + cmbPriority.Text + "  <br /><br /> <b>Description of NC : </b>" + txtDescriptionofNC.Text + " <br/><br /> <b>Product : </b>" + cmbComponentType.Text + " <br /> <b>Sub Product : </b>" + cmbSubProduct.Text + " <br /> <br /> <b> Regards,<br /> " + Login.GetUserDetails[2] + " </b>  <br /><br /> <br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";

                        CreateEMail(sNCNumber, sRecieverEmailID, lstAddUser, sMessage);
                        FormReload();
                    }
                    else if (btnSave.Text == "Update")
                    {
                        if (!string.IsNullOrEmpty(sNCNumberfn))
                        {
                            GlobalClass.iSuccess = DAL.fnAddNC(Global.uUPDATE, sNCNumber, Login.GetUserDetails[2], Login.GetUserDetails[23],
                        cmbProjectcode.Text, cmbAssignedTo.Text, txtAssignedtoDept.Text, cmbEnvironMent.Text, cmbPriority.Text, cmbNCType.Text,
                        txtDescriptionofNC.Text, dtpCreatedDate.Text, txtOptionalOE.Text, cmbComponentType.Text, cmbSubProduct.Text, txtObservation.Text, cmbVendorName.Text);
                            // GlobalClass.iSuccess = DAL.fnAddNC(Global.uUPDATE, sNCNumberfn, txtRequesterName.Text, txtRequesterDept.Text, cmbProjectcode.Text, cmbAssignedTo.Text,
                            //    txtAssignedtoDept.Text, cmbEnvironMent.Text, cmbPriority.Text, cmbNCType.Text, txtDescriptionofNC.Text, dtpCreatedDate.Text, txtObservation.Text, cmbComponentType.Text, cmbSubProduct.Text);

                            MessageBox.Show("NC '" + sNCNumberfn + "' updated & assigned to '" + cmbAssignedTo.Text + "' successfully", "Success", 0, MessageBoxIcon.Information);
                            btnSave.Enabled = false;
                            string sMessage = "<font face=Calibri> Dear " + cmbAssignedTo.Text.ToUpper() + ", <br />NC has been updated on the following issue. Please take necessary action within 3 days.<br /> <br /> <b> Priority :</b> " + cmbPriority.Text + "  <br /><br /> <b>Description of NC : </b>" + txtDescriptionofNC.Text + " <br/><br /> <b>Product : </b>" + cmbComponentType.Text + " <br /> <b>Sub Product : </b>" + cmbSubProduct.Text + " <br /> <br /> <b> Regards,<br /> " + Login.GetUserDetails[2] + " </b>  <br /><br /> <br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
                            //   string sMessage = "<font face=Calibri> Dear " + cmbAssignedTo.Text.ToUpper() + ", <br />Rejected NC has been updated on the following issue. Please take necessary required action.<br /> <br /> <b> Priority : " + cmbPriority.Text + " </b> <br /><br /> <b>Description of NC : </b>" + txtDescriptionofNC.Text + " <br/><br /> <br /> <br /> <br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";

                            CreateEMail(sNCNumber, sRecieverEmailID, null, sMessage);

                        }
                        else
                        {
                            MessageBox.Show("Please select NC Number to update", "Error", 0, MessageBoxIcon.Error);

                        }

                    }
                }
                else
                {
                    if (cmbProjectcode.SelectedIndex < 0)
                    {
                        MessageBox.Show("Please select project code ", "Error", 0, MessageBoxIcon.Error);
                        cmbProjectcode.Focus();
                    }
                    else if (cmbAssignedTo.SelectedIndex < 0)
                    {
                        MessageBox.Show("Please select assigned to name ", "Error", 0, MessageBoxIcon.Error);
                        cmbAssignedTo.Focus();
                    }
                    else if (cmbEnvironMent.SelectedIndex < 0)
                    {
                        MessageBox.Show("Please select environment ", "Error", 0, MessageBoxIcon.Error);
                        cmbEnvironMent.Focus();
                    }
                    else if (cmbPriority.SelectedIndex < 0)
                    {
                        MessageBox.Show("Please select priority ", "Error", 0, MessageBoxIcon.Error);
                        cmbPriority.Focus();
                    }
                    else if (cmbNCType.SelectedIndex < 0)
                    {
                        MessageBox.Show("Please select NC type ", "Error", 0, MessageBoxIcon.Error);
                        cmbNCType.Focus();
                    }
                    else if (string.IsNullOrEmpty(txtDescriptionofNC.Text))
                    {
                        MessageBox.Show("Please write the description of NC", "Error", 0, MessageBoxIcon.Error);
                        cmbNCType.Focus();
                    }
                }
            }
            #endregion
        }

        DataTable dtUserNC = new DataTable();
        DataTable dtUserEmail = new DataTable();
        bool bDateCheck = false;

        private void fnNCNumberRecieved(string sNCNumber)
        {
            dtUserNC = DAL.fnLoadNCNumber(null, sNCNumber, 0).Tables[0];
            if (dtUserNC.Rows.Count > 0)
            {
                btnSave.Text = "Update";

                //  pnSave1.Visible = false;
                txtRequesterName.Text = dtUserNC.Rows[0]["RequestBy"].ToString();
                txtRequesterDept.Text = dtUserNC.Rows[0]["RequestDept"].ToString();
                cmbProjectcode.SelectedItem = dtUserNC.Rows[0]["ProjectCode"].ToString();
                cmbAssignedTo.SelectedItem = dtUserNC.Rows[0]["AssignedTo"].ToString();
                txtAssignedtoDept.SelectedItem = dtUserNC.Rows[0]["AssignedDept"].ToString();
                cmbEnvironMent.SelectedItem = dtUserNC.Rows[0]["Environment"].ToString();
                cmbPriority.SelectedItem = dtUserNC.Rows[0]["Priority"].ToString();
                cmbNCType.SelectedItem = dtUserNC.Rows[0]["NCType"].ToString();
                if (cmbNCType.SelectedIndex > 1)
                {
                    cmbVendorName.SelectedItem = dtUserNC.Rows[0]["SupplierName"].ToString();
                }
                txtDescriptionofNC.Text = dtUserNC.Rows[0]["DescriptionOfNC"].ToString();
                txtObservation.Text = dtUserNC.Rows[0]["Observation"].ToString();
                txtOptionalOE.Text = dtUserNC.Rows[0]["ObjectiveEvidence"].ToString();
                cmbComponentType.SelectedItem = dtUserNC.Rows[0]["Product"].ToString();
                cmbSubProduct.Text = dtUserNC.Rows[0]["SubProduct"].ToString();

                cmbDisposition.SelectedItem = dtUserNC.Rows[0]["Disposition"].ToString();
                txtCorrectionRequested.Text = dtUserNC.Rows[0]["CorrectionRequested"].ToString();
                txtRootCause.Text = dtUserNC.Rows[0]["RootCause"].ToString();
                txtCorrectiveAction.Text = dtUserNC.Rows[0]["CorrectiveAction"].ToString();
                txtCostincurred.Text = dtUserNC.Rows[0]["CostIncurred"].ToString();
                txtManHours.Text = dtUserNC.Rows[0]["ManHours"].ToString();
                txtObjectiveEvidenceFound.Text = dtUserNC.Rows[0]["ObjectiveEvidenceFound"].ToString();

                if (string.IsNullOrEmpty(txtCorrectionRequested.Text))
                {
                    pnSave1.Enabled = true;
                    chkReAssign.Visible = true;
                    pnCorrection.Enabled = true;
                    pnRootCause.Enabled = false;
                    chkCorrectionEdit.Visible = false;
                    chkEditRootCause.Visible = false;
                }
                else
                {
                    chkCorrectionEdit.Visible = true;
                    pnSave1.Enabled = false;
                }
                if (!string.IsNullOrEmpty(dtUserNC.Rows[0]["PDC1"].ToString()))
                {

                    bDateCheck = true;
                    dtpPDC1.Value = Convert.ToDateTime(dtUserNC.Rows[0]["PDC1"]);
                    bDateCheck = false;
                    chkCorrectionEdit.Visible = true;
                    pnSave1.Enabled = false;
                }
                if (string.IsNullOrEmpty(txtRootCause.Text))
                {
                    chkReAssign.Visible = true;
                    //  pnSave1.Enabled = false;
                    pnCorrection.Enabled = false;
                    pnRootCause.Enabled = true;
                    chkEditRootCause.Visible = false;

                }
                else
                {
                    chkEditRootCause.Visible = true;
                }

                if (!string.IsNullOrEmpty(dtUserNC.Rows[0]["PDC2"].ToString()))
                {

                    bDateCheck = true;
                    dtpPDC2.Value = Convert.ToDateTime(dtUserNC.Rows[0]["PDC2"]);
                    bDateCheck = false;

                    txtRootCause.Text = dtUserNC.Rows[0]["RootCause"].ToString();
                    txtCorrectiveAction.Text = dtUserNC.Rows[0]["CorrectiveAction"].ToString();
                    txtCostincurred.Text = dtUserNC.Rows[0]["CostIncurred"].ToString();
                    txtObjectiveEvidenceFound.Text = dtUserNC.Rows[0]["ObjectiveEvidenceFound"].ToString();
                    chkEditRootCause.Visible = true;
                }

                if (!string.IsNullOrEmpty(txtRootCause.Text))
                {
                    pnCorrection.Enabled = false;
                    pnRootCause.Enabled = false;
                    pnObjectiveEvidence.Visible = true;
                    pnObjectiveEvidence.Enabled = true;
                }

                if (!string.IsNullOrEmpty(txtObjectiveEvidenceFound.Text))
                {
                    pnObjectiveEvidence.Enabled = false;
                }

                // Comment this after some validation
                chkEditRootCause.Visible = true;
                chkCorrectionEdit.Visible = true;
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(sNCNumberfn))
            {
                //  tabControl1.SelectedIndex = 1;
                //  btnBack.Visible = true;
            }
            else
            {
                MessageBox.Show("Please select NC Number", "Error", 0, MessageBoxIcon.Error);
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            //tabControl1.SelectedIndex = 0;
            pnSave1.Visible = false;
            //   btnBack.Visible = false;
        }
        bool bPDC1Date = false;
        bool bPDC2Date = false;
        private void dtpPDC1_ValueChanged(object sender, EventArgs e)
        {
            if (!bDateCheck)
            {
                bPDC1Date = true;
                if (dtpPDC1.Value < DateTime.Today.Date)
                {
                    //   bPDC1Date = false;
                    //   MessageBox.Show("Probable date of completion should be greater than today date");
                }
                else if ((dtpPDC1.Value - DateTime.Today.Date).TotalDays > 15)
                {
                    if (cmbNCType.Text == "Major")
                    {
                        if ((dtpPDC1.Value - DateTime.Today.Date).TotalDays > 7)
                        {
                            bPDC2Date = false;
                            MessageBox.Show("Probable date of completion should be within a week");
                        }
                    }
                    else 
                    {
                        if ((dtpPDC1.Value - DateTime.Today.Date).TotalDays > 14)
                        {
                            bPDC2Date = false;
                            MessageBox.Show("Probable date of completion should be within 2 weeks");
                        }
                    }

                }
            }
        }

        private void dtpPDC2_ValueChanged(object sender, EventArgs e)
        {
            if (!bDateCheck)
            {
                bPDC2Date = true;
                if (dtpPDC2.Value < DateTime.Today.Date)
                {
                    // bPDC2Date = false;
                    //  MessageBox.Show("Probable date of completion should be greater than today date");
                }
                else if ((dtpPDC2.Value - DateTime.Today.Date).TotalDays > 15)
                {
                    bPDC2Date = false;
                    MessageBox.Show("Probable date of completion should not be more than 15 days");
                }
            }
        }

        private void btnAcceptnCloseNC_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtObjectiveEvidenceFound.Text) && !string.IsNullOrEmpty(txtCostincurred.Text))
            {
                GlobalClass.iSuccess = DAL.fnAddNCSecondTab(7, sNCNumberfn, "", "", "", "", "", "", 0, "", dtpCloseDate.Text, "");
                GlobalClass.iSuccess = DAL.fnAddNCSecondTab(9, sNCNumberfn, "", "", "", "", "", "", 0, "", dtpCloseDate.Text, "");
                GlobalClass.iSuccess = DAL.fnAddNCSecondTab(1, sNCNumberfn, txtObjectiveEvidenceFound.Text, "", "", "", "", "", Convert.ToDouble(txtCostincurred.Text), txtManHours.Text, dtpCloseDate.Text, "");

                MessageBox.Show("Objective evidence details sent for review", "Success", 0, MessageBoxIcon.Information);
                string sMessage = "<font face=Calibri> Dear " + txtRequesterName.Text.ToUpper() + ", <br /> Corrective action taken & details of objective evidence provided.<br /> NC closed successfully. <br /> <br /> <b>  Regards,<br /> " + Login.GetUserDetails[2] + " </b> <br /> <br /><br /> <br /><br /><br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
                dtUserEmail = DAL.fnUserList(txtRequesterName.Text, 1).Tables[0];
                CreateEMail(sNCNumberfn, dtUserEmail.Rows[0]["emailid"].ToString(), lstAddUser, sMessage);
                FormReload();
            }
            else
            {
                if (string.IsNullOrEmpty(txtObjectiveEvidenceFound.Text))
                {
                    MessageBox.Show("Write objective evidence found to accept and close NC", "Error", 0, MessageBoxIcon.Error);
                }
                else if (string.IsNullOrEmpty(txtCostincurred.Text))
                {
                    MessageBox.Show("Add costing details close NC", "Error", 0, MessageBoxIcon.Error);
                }
            }
        }

        #region Raise NC Form Reload
        private void FormReload()
        {
            this.Hide();
            frmRaiseNC RaiseNC = new frmRaiseNC();
            RaiseNC.Show();
        }
        #endregion

        private void txtCostincurred_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void btnViewNC_Click(object sender, EventArgs e)
        {
            Biss_NC.frmUserNcDetails NCDetails = new Biss_NC.frmUserNcDetails();
            NCDetails.ShowDialog();
            if (!String.IsNullOrEmpty(fnNCNumber))
            {
                fnNCNumberRecieved(sNCNumberfn);
                if (!string.IsNullOrEmpty(sNCNumberfn))
                {
                    lblNCnumber.Visible = true;
                    txtNCnumber.Visible = true;
                    txtNCnumber.Text = sNCNumberfn;
                }
            }
        }
        DataTable dtlogindetails = new DataTable();
        private void cmbCCUser_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtlogindetails = DAL.fnloginemail(cmbCCUser.Text).Tables[0];
            if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()) && !lstusers.Items.Contains(dtlogindetails.Rows[0]["emailid"].ToString()))
            {
                lstusers.Items.Add(dtlogindetails.Rows[0]["emailid"].ToString());
            }
        }

        private void btnReassign_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(sNCNumberfn))
            {
                if (cmbReAssign.SelectedIndex != -1 && cmbReassignDept.SelectedIndex != -1)
                {
                    GlobalClass.iSuccess = DAL.fnAddNCSecondTab(6, sNCNumberfn, cmbReAssign.Text, cmbReassignDept.Text, "", "", "", "", 0, null, null, "");
                    MessageBox.Show("NC '" + sNCNumberfn + "' re assigned &.\n Mail sent to '" + cmbReAssign.Text + "' for review", "Success", 0, MessageBoxIcon.Information);
                    string sMessage = "<font face=Calibri> Dear " + cmbReAssign.Text.ToUpper() + ", <br />NC has been raised on the following issue. Please take necessary action within 3 days.<br /> <br /> <b> Priority :</b> " + cmbPriority.Text + "  <br /><br /> <b>Description of NC : </b>" + txtDescriptionofNC.Text + " <br/><br /> <b>Product : </b>" + cmbComponentType.Text + " <br /> <b>Sub Product : </b>" + cmbSubProduct.Text + " <br /> <br /> <b> Regards,<br /> " + Login.GetUserDetails[2] + " </b>  <br /><br /> <br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
                    dtUserEmail = DAL.fnUserList(cmbReAssign.Text, 1).Tables[0];
                    CreateEMail(sNCNumberfn, dtUserEmail.Rows[0]["emailid"].ToString(), lstusers, sMessage);
                    btnReassign.Enabled = false;
                    FormReload();
                }
                else
                {
                    if (cmbReAssign.SelectedIndex == -1)
                    {
                        MessageBox.Show("Select the re assign user.", "Error", 0, MessageBoxIcon.Error);
                        cmbReAssign.Focus();
                    }
                    else if (cmbReassignDept.SelectedIndex == -1)
                    {
                        MessageBox.Show("Select the re assign user department.", "Error", 0, MessageBoxIcon.Error);
                        cmbReassignDept.Focus();
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select NC Number to update", "Error", 0, MessageBoxIcon.Error);

            }
        }

        private void chkCorrectionEdit_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCorrectionEdit.CheckState == CheckState.Checked)
            {
                pnCorrection.Enabled = true;
                btnCorrectionSave.Enabled = true;
            }
            else
            {
                pnCorrection.Enabled = false;
                btnCorrectionSave.Enabled = false;
            }
        }

        private void chkEditRootCause_CheckedChanged(object sender, EventArgs e)
        {
            if (chkEditRootCause.CheckState == CheckState.Checked)
            {
                pnRootCause.Enabled = true;
                btnRootCauseSave.Enabled = true;
            }
            else
            {
                pnRootCause.Enabled = false;
                btnRootCauseSave.Enabled = false;
            }
        }

        private void cmbUserCC_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtlogindetails = DAL.fnloginemail(cmbUserCC.Text).Tables[0]; ;
            if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()) && !lstAddUser.Items.Contains(dtlogindetails.Rows[0]["emailid"].ToString()))
            {
                lstAddUser.Items.Add(dtlogindetails.Rows[0]["emailid"].ToString());
            }
        }

        private void lstAddUser_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                lstAddUser.Items.Remove(lstAddUser.SelectedItem);
            }
        }

        private void lstusers_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                lstusers.Items.Remove(lstusers.SelectedItem);
            }
        }

        private void chkReAssign_CheckedChanged(object sender, EventArgs e)
        {
            if (chkReAssign.CheckState == CheckState.Checked)
            {
                pnReassign.Enabled = true;
                //  btnNext.Enabled = false;
                btnReassign.Enabled = true;

            }
            else
            {
                pnReassign.Enabled = false;
                //  btnNext.Enabled = true;
                btnReassign.Enabled = false;
            }
        }

        private void btnCorrectionSave_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(sNCNumberfn))
            {
                if (!string.IsNullOrEmpty(txtCorrectionRequested.Text) && cmbDisposition.SelectedIndex >= 0 && bPDC1Date)
                {
                    GlobalClass.iSuccess = DAL.fnAddNCSecondTab(5, sNCNumberfn, cmbDisposition.Text, dtpPDC1.Text, txtCorrectionRequested.Text, txtRootCause.Text, dtpPDC2.Text, txtCorrectiveAction.Text, 00, null, null, "");
                    bPDC1Date = false;
                    bPDC2Date = false;
                    btnSave.Enabled = false;
                    if (chkCorrectionEdit.CheckState == CheckState.Unchecked)
                    {
                        MessageBox.Show("NC '" + sNCNumberfn + "' correction/action required saved.\n Mail sent to '" + txtRequesterName.Text + "' for review", "Success", 0, MessageBoxIcon.Information);

                        string sMessage = "<font face=Calibri> Dear " + txtRequesterName.Text.ToUpper() + ", <br />  Correction has been updated.<br /> Please review the correction. <br /> <br /> <b>  Regards,<br /> " + Login.GetUserDetails[2] + " </b> <br /> <br /><br /> <br /><br /><br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
                        dtUserEmail = DAL.fnUserList(txtRequesterName.Text, 1).Tables[0];
                        CreateEMail(sNCNumberfn, dtUserEmail.Rows[0]["emailid"].ToString(), lstAddUser, sMessage);
                    }
                    else
                    {
                        MessageBox.Show("NC '" + sNCNumberfn + "' correction/action required updated.\n Mail sent to '" + cmbAssignedTo.Text + "' for review", "Success", 0, MessageBoxIcon.Information);

                        string sMessage = "<font face=Calibri> Dear " + txtRequesterName.Text.ToUpper() + ", <br />  Correction has been updated.<br /> Please review the correction. <br /> <br /> <b>  Regards,<br /> " + Login.GetUserDetails[2] + " </b> <br /> <br /><br /> <br /><br /><br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
                        dtUserEmail = DAL.fnUserList(txtRequesterName.Text, 1).Tables[0];
                        CreateEMail(sNCNumberfn, dtUserEmail.Rows[0]["emailid"].ToString(), lstAddUser, sMessage);
                    }
                    btnCorrectionSave.Enabled = false;
                    fnNCNumberRecieved(sNCNumberfn);
                    // FormReload();
                }
                else
                {
                    if (cmbDisposition.SelectedIndex < 0)
                    {
                        MessageBox.Show("Please select disposition.", "Error", 0, MessageBoxIcon.Error);
                        cmbAssignedTo.Focus();
                    }
                    else if (!bPDC1Date)
                    {
                        MessageBox.Show("Please select the probable date of completion.", "Error", 0, MessageBoxIcon.Error);
                        dtpPDC1.Focus();
                    }
                    else if (string.IsNullOrEmpty(txtCorrectionRequested.Text))
                    {
                        MessageBox.Show("Please write the correction/action required.", "Error", 0, MessageBoxIcon.Error);
                        cmbProjectcode.Focus();
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select NC Number to update", "Error", 0, MessageBoxIcon.Error);

            }
        }

        private void btnRootCauseSave_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(sNCNumberfn))
            {
                if (!string.IsNullOrEmpty(txtRootCause.Text) && !string.IsNullOrEmpty(txtCorrectiveAction.Text) && bPDC2Date)
                {
                    GlobalClass.iSuccess = DAL.fnAddNCSecondTab(2, sNCNumberfn, cmbDisposition.Text, dtpPDC1.Text, txtCorrectionRequested.Text, txtRootCause.Text, dtpPDC2.Text, txtCorrectiveAction.Text, 0, null, null, "");
                    bPDC1Date = false;
                    bPDC2Date = false;
                    if (chkEditRootCause.CheckState == CheckState.Unchecked)
                    {
                        MessageBox.Show("NC '" + sNCNumberfn + "' root cause saved.\n Mail sent to '" + txtRequesterName.Text + "' for review", "Success", 0, MessageBoxIcon.Information);

                        //  string sMessage = "<font face=Calibri> Dear " + txtRequesterName.Text.ToUpper() + ", <br />  Correction has been updated.<br /> Please review the correction. <br /> <br /> <b>  Regards,<br /> " + Login.GetUserDetails[2] + " </b> <br /> <br /><br /> <br /><br /><br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
                        string sMessage = "<font face=Calibri> Dear " + txtRequesterName.Text.ToUpper() + ", <br /> Root cause & Corrective action has been updated.<br /> Please review the same. <br /> <br /> <b>  Regards,<br /> " + Login.GetUserDetails[2] + " </b> <br /> <br /><br /> <br /><br /><br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
                        dtUserEmail = DAL.fnUserList(txtRequesterName.Text, 1).Tables[0];
                        CreateEMail(sNCNumberfn, dtUserEmail.Rows[0]["emailid"].ToString(), lstAddUser, sMessage);
                    }
                    else
                    {
                        MessageBox.Show("NC '" + sNCNumberfn + "' root cause updated.\n Mail sent to '" + cmbAssignedTo.Text + "' for review", "Success", 0, MessageBoxIcon.Information);

                        string sMessage = "<font face=Calibri> Dear " + txtRequesterName.Text.ToUpper() + ", <br /> Root cause & Corrective action has been updated.<br /> Please review the same. <br /> <br /> <b>  Regards,<br /> " + Login.GetUserDetails[2] + " </b> <br /> <br /><br /> <br /><br /><br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
                        dtUserEmail = DAL.fnUserList(txtRequesterName.Text, 1).Tables[0];
                        CreateEMail(sNCNumberfn, dtUserEmail.Rows[0]["emailid"].ToString(), lstAddUser, sMessage);
                    }
                    btnRootCauseSave.Enabled = false;
                    fnNCNumberRecieved(sNCNumberfn);
                    //  FormReload();
                }
                else
                {

                    if (string.IsNullOrEmpty(txtRootCause.Text))
                    {
                        MessageBox.Show("Please write the root cause.", "Error", 0, MessageBoxIcon.Error);
                        cmbEnvironMent.Focus();
                    }
                    else if (!bPDC2Date)
                    {
                        MessageBox.Show("Please select the probable date of completion.", "Error", 0, MessageBoxIcon.Error);
                        dtpPDC2.Focus();
                    }

                    else if (string.IsNullOrEmpty(txtCorrectiveAction.Text))
                    {
                        MessageBox.Show("Please write the corrective action.", "Error", 0, MessageBoxIcon.Error);
                        cmbEnvironMent.Focus();
                    }
                    else if (string.IsNullOrEmpty(txtCostincurred.Text))
                    {
                        MessageBox.Show("Please enter the cost incurred.", "Error", 0, MessageBoxIcon.Error);
                        txtCostincurred.Focus();
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select NC Number to update", "Error", 0, MessageBoxIcon.Error);

            }
        }

        private void frmRaiseNC_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            frm.Show();
        }

        private void btnProjectView_Click(object sender, EventArgs e)
        {
            Indent.frmProjectselect projectsearch = new Indent.frmProjectselect();
            projectsearch.fnNCform = "1";
            projectsearch.ShowDialog();
            if (fnProjectcode != null)
            {
                cmbProjectcode.Text = sProjectCode;
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm.Show();
        }

        private void txtManHours_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void btnNext_Click_1(object sender, EventArgs e)
        {

        }

        private void cmbNCType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbNCType.SelectedIndex == 2)
            {
                cmbVendorName.Enabled = true;
            }
            else
            {
                cmbVendorName.Text = "";
                cmbVendorName.Enabled = false;
            }
        }

        private void btnProjectView_Click_1(object sender, EventArgs e)
        {
            Indent.frmProjectselect projectsearch = new Indent.frmProjectselect();
            projectsearch.fnNCform = "1";
            projectsearch.ShowDialog();
            if (fnProjectcode != null)
            {
                cmbProjectcode.Text = sProjectCode;
            }
        }
    }
}
