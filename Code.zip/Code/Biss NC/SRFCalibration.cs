﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Biss_NC
{
    public partial class SRFCalibration : Form
    {
        public SRFCalibration()
        {
            InitializeComponent();
        }
        frmForm2 form = new frmForm2();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        // frmSalesHome SalesHome = new frmSalesHome();
        DataTable dtProjectList = new DataTable();
        DataTable dtCustomerList = new DataTable();
        private void SRFCalibration_Load(object sender, EventArgs e)
        {
            dtCustomerList = DAL.fnCustomerList(5, null).Tables[0];
            foreach (DataRow DR in dtCustomerList.Rows)
            {
                if (!cmbSRFCustomer.Items.Contains(DR["CustomerName"].ToString()))
                    cmbSRFCustomer.Items.Add(DR["CustomerName"].ToString());
            }
        }

        DataRow[] DR;
        private void cmbSRFCustomer_SelectedIndexChanged(object sender, EventArgs e)
        {
            DR = dtCustomerList.Select("CustomerName = '" + cmbSRFCustomer.Text + "'");
            if (DR.Length > 0)
            {
                txtSRFAddress.Text = DR[0]["Address1"].ToString() + DR[0]["Address2"].ToString() + DR[0]["Address3"].ToString();
                txtSRFCusCode.Text = DR[0]["CusCode"].ToString();
                TxtSRFContactPerson.Text = DR[0]["ContactPerson"].ToString();
                txtSRFContactNumber.Text = DR[0]["MobileNo"].ToString();
                txtSRFEmail.Text = DR[0]["EmailAddress"].ToString();
            }
            else
            {
                txtSRFAddress.ResetText();
                txtSRFCusCode.ResetText();
                TxtSRFContactPerson.ResetText();
                txtSRFContactNumber.ResetText();
                txtSRFEmail.ResetText();
            }
        }

        private void btnSRFAddNewItem_Click(object sender, EventArgs e)
        {

        }
    }
}
