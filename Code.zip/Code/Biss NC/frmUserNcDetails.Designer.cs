﻿namespace Erp_Project_With_Buttons.Biss_NC
{
    partial class frmUserNcDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmUserNcDetails));
            this.txtNCReViewReason = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.btnTotal = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pnGenaralPanel = new System.Windows.Forms.Panel();
            this.lblFromdate = new System.Windows.Forms.Label();
            this.lblToDate = new System.Windows.Forms.Label();
            this.dtpFromDate = new System.Windows.Forms.DateTimePicker();
            this.dptToDate = new System.Windows.Forms.DateTimePicker();
            this.lstAddUser = new System.Windows.Forms.ListBox();
            this.btnSummaryEmail = new System.Windows.Forms.Button();
            this.btnNCClosed = new System.Windows.Forms.Button();
            this.btnExcel = new System.Windows.Forms.Button();
            this.btnCANotClosed = new System.Windows.Forms.Button();
            this.cmbDepartment = new System.Windows.Forms.ComboBox();
            this.btnCorrectionClosed = new System.Windows.Forms.Button();
            this.cmbAssignAction = new System.Windows.Forms.ComboBox();
            this.btnCloseCorrection = new System.Windows.Forms.Button();
            this.btnNewNC = new System.Windows.Forms.Button();
            this.pnNCOpen = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dtpClosedate = new System.Windows.Forms.DateTimePicker();
            this.dgvUserDetails = new System.Windows.Forms.DataGridView();
            this.SlNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NCNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DateOpened = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Createdby = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AssignedTo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Priority = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NCType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SupplierName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CloseDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Correction = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PDC1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CorrectionStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CorrectionDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RootCause = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CorrectiveAction = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ObjectiveEvidence = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CACorrectionStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CADate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Disposition = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CostIncurred = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1.SuspendLayout();
            this.pnGenaralPanel.SuspendLayout();
            this.pnNCOpen.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUserDetails)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtNCReViewReason
            // 
            this.txtNCReViewReason.Font = new System.Drawing.Font("Calibri", 12F);
            this.txtNCReViewReason.Location = new System.Drawing.Point(7, 19);
            this.txtNCReViewReason.Multiline = true;
            this.txtNCReViewReason.Name = "txtNCReViewReason";
            this.txtNCReViewReason.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtNCReViewReason.Size = new System.Drawing.Size(292, 55);
            this.txtNCReViewReason.TabIndex = 179;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(3, 1);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(134, 19);
            this.label23.TabIndex = 178;
            this.label23.Text = "Review Comments";
            // 
            // btnTotal
            // 
            this.btnTotal.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btnTotal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTotal.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTotal.ForeColor = System.Drawing.Color.Black;
            this.btnTotal.Location = new System.Drawing.Point(1142, 102);
            this.btnTotal.Name = "btnTotal";
            this.btnTotal.Size = new System.Drawing.Size(47, 26);
            this.btnTotal.TabIndex = 195;
            this.btnTotal.UseVisualStyleBackColor = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(1096, 104);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 19);
            this.label5.TabIndex = 194;
            this.label5.Text = "Total";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.pnGenaralPanel);
            this.panel1.Controls.Add(this.lstAddUser);
            this.panel1.Controls.Add(this.btnTotal);
            this.panel1.Controls.Add(this.btnSummaryEmail);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.btnNCClosed);
            this.panel1.Controls.Add(this.btnExcel);
            this.panel1.Controls.Add(this.btnCANotClosed);
            this.panel1.Controls.Add(this.cmbDepartment);
            this.panel1.Controls.Add(this.btnCorrectionClosed);
            this.panel1.Controls.Add(this.cmbAssignAction);
            this.panel1.Controls.Add(this.btnCloseCorrection);
            this.panel1.Controls.Add(this.btnNewNC);
            this.panel1.Controls.Add(this.pnNCOpen);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.dtpClosedate);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1252, 134);
            this.panel1.TabIndex = 207;
            // 
            // pnGenaralPanel
            // 
            this.pnGenaralPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnGenaralPanel.Controls.Add(this.lblFromdate);
            this.pnGenaralPanel.Controls.Add(this.lblToDate);
            this.pnGenaralPanel.Controls.Add(this.dtpFromDate);
            this.pnGenaralPanel.Controls.Add(this.dptToDate);
            this.pnGenaralPanel.Location = new System.Drawing.Point(296, 7);
            this.pnGenaralPanel.Name = "pnGenaralPanel";
            this.pnGenaralPanel.Size = new System.Drawing.Size(222, 77);
            this.pnGenaralPanel.TabIndex = 210;
            this.pnGenaralPanel.Visible = false;
            // 
            // lblFromdate
            // 
            this.lblFromdate.AutoSize = true;
            this.lblFromdate.Font = new System.Drawing.Font("Times New Roman", 11.25F);
            this.lblFromdate.Location = new System.Drawing.Point(19, 10);
            this.lblFromdate.Name = "lblFromdate";
            this.lblFromdate.Size = new System.Drawing.Size(72, 17);
            this.lblFromdate.TabIndex = 4;
            this.lblFromdate.Text = "From Date";
            // 
            // lblToDate
            // 
            this.lblToDate.Font = new System.Drawing.Font("Times New Roman", 11.25F);
            this.lblToDate.Location = new System.Drawing.Point(3, 41);
            this.lblToDate.Name = "lblToDate";
            this.lblToDate.Size = new System.Drawing.Size(88, 18);
            this.lblToDate.TabIndex = 6;
            this.lblToDate.Text = "To Date";
            this.lblToDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // dtpFromDate
            // 
            this.dtpFromDate.Font = new System.Drawing.Font("Times New Roman", 11.25F);
            this.dtpFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFromDate.Location = new System.Drawing.Point(97, 4);
            this.dtpFromDate.Name = "dtpFromDate";
            this.dtpFromDate.Size = new System.Drawing.Size(109, 25);
            this.dtpFromDate.TabIndex = 9;
            // 
            // dptToDate
            // 
            this.dptToDate.Font = new System.Drawing.Font("Times New Roman", 11.25F);
            this.dptToDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dptToDate.Location = new System.Drawing.Point(97, 41);
            this.dptToDate.Name = "dptToDate";
            this.dptToDate.Size = new System.Drawing.Size(109, 25);
            this.dptToDate.TabIndex = 10;
            this.dptToDate.ValueChanged += new System.EventHandler(this.dptToDate_ValueChanged);
            // 
            // lstAddUser
            // 
            this.lstAddUser.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstAddUser.FormattingEnabled = true;
            this.lstAddUser.ItemHeight = 19;
            this.lstAddUser.Location = new System.Drawing.Point(1102, 57);
            this.lstAddUser.Name = "lstAddUser";
            this.lstAddUser.ScrollAlwaysVisible = true;
            this.lstAddUser.Size = new System.Drawing.Size(151, 23);
            this.lstAddUser.TabIndex = 209;
            this.lstAddUser.Visible = false;
            // 
            // btnSummaryEmail
            // 
            this.btnSummaryEmail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnSummaryEmail.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSummaryEmail.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSummaryEmail.Location = new System.Drawing.Point(976, 23);
            this.btnSummaryEmail.Name = "btnSummaryEmail";
            this.btnSummaryEmail.Size = new System.Drawing.Size(119, 28);
            this.btnSummaryEmail.TabIndex = 208;
            this.btnSummaryEmail.Text = "Summary Email";
            this.btnSummaryEmail.UseVisualStyleBackColor = false;
            this.btnSummaryEmail.Visible = false;
            this.btnSummaryEmail.Click += new System.EventHandler(this.btnSummaryEmail_Click);
            // 
            // btnNCClosed
            // 
            this.btnNCClosed.BackColor = System.Drawing.Color.GreenYellow;
            this.btnNCClosed.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNCClosed.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNCClosed.ForeColor = System.Drawing.Color.Black;
            this.btnNCClosed.Location = new System.Drawing.Point(971, 102);
            this.btnNCClosed.Name = "btnNCClosed";
            this.btnNCClosed.Size = new System.Drawing.Size(47, 26);
            this.btnNCClosed.TabIndex = 193;
            this.btnNCClosed.UseVisualStyleBackColor = false;
            // 
            // btnExcel
            // 
            this.btnExcel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnExcel.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExcel.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExcel.Location = new System.Drawing.Point(1120, 23);
            this.btnExcel.Name = "btnExcel";
            this.btnExcel.Size = new System.Drawing.Size(119, 28);
            this.btnExcel.TabIndex = 206;
            this.btnExcel.Text = "Export to Excel";
            this.btnExcel.UseVisualStyleBackColor = false;
            this.btnExcel.Click += new System.EventHandler(this.btnExcel_Click);
            // 
            // btnCANotClosed
            // 
            this.btnCANotClosed.BackColor = System.Drawing.Color.Khaki;
            this.btnCANotClosed.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCANotClosed.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCANotClosed.ForeColor = System.Drawing.Color.Black;
            this.btnCANotClosed.Location = new System.Drawing.Point(725, 102);
            this.btnCANotClosed.Name = "btnCANotClosed";
            this.btnCANotClosed.Size = new System.Drawing.Size(47, 26);
            this.btnCANotClosed.TabIndex = 192;
            this.btnCANotClosed.UseVisualStyleBackColor = false;
            // 
            // cmbDepartment
            // 
            this.cmbDepartment.DropDownHeight = 130;
            this.cmbDepartment.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDepartment.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDepartment.FormattingEnabled = true;
            this.cmbDepartment.IntegralHeight = false;
            this.cmbDepartment.Location = new System.Drawing.Point(3, 57);
            this.cmbDepartment.Name = "cmbDepartment";
            this.cmbDepartment.Size = new System.Drawing.Size(278, 27);
            this.cmbDepartment.TabIndex = 205;
            this.cmbDepartment.Visible = false;
            this.cmbDepartment.SelectedIndexChanged += new System.EventHandler(this.cmbDepartment_SelectedIndexChanged);
            // 
            // btnCorrectionClosed
            // 
            this.btnCorrectionClosed.BackColor = System.Drawing.Color.Salmon;
            this.btnCorrectionClosed.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCorrectionClosed.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCorrectionClosed.ForeColor = System.Drawing.Color.Black;
            this.btnCorrectionClosed.Location = new System.Drawing.Point(395, 102);
            this.btnCorrectionClosed.Name = "btnCorrectionClosed";
            this.btnCorrectionClosed.Size = new System.Drawing.Size(47, 26);
            this.btnCorrectionClosed.TabIndex = 191;
            this.btnCorrectionClosed.UseVisualStyleBackColor = false;
            // 
            // cmbAssignAction
            // 
            this.cmbAssignAction.DropDownHeight = 130;
            this.cmbAssignAction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAssignAction.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbAssignAction.FormattingEnabled = true;
            this.cmbAssignAction.IntegralHeight = false;
            this.cmbAssignAction.Items.AddRange(new object[] {
            "View NC",
            "Close Correction",
            "Re-Open Correction",
            "Close Corrective Action",
            "Re-Open Corrective Action",
            "Department NC"});
            this.cmbAssignAction.Location = new System.Drawing.Point(3, 14);
            this.cmbAssignAction.Name = "cmbAssignAction";
            this.cmbAssignAction.Size = new System.Drawing.Size(278, 27);
            this.cmbAssignAction.TabIndex = 204;
            this.cmbAssignAction.SelectedIndexChanged += new System.EventHandler(this.cmbAssignAction_SelectedIndexChanged);
            // 
            // btnCloseCorrection
            // 
            this.btnCloseCorrection.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnCloseCorrection.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCloseCorrection.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCloseCorrection.Location = new System.Drawing.Point(837, 18);
            this.btnCloseCorrection.Name = "btnCloseCorrection";
            this.btnCloseCorrection.Size = new System.Drawing.Size(119, 28);
            this.btnCloseCorrection.TabIndex = 202;
            this.btnCloseCorrection.Text = "Close Correction";
            this.btnCloseCorrection.UseVisualStyleBackColor = false;
            this.btnCloseCorrection.Visible = false;
            this.btnCloseCorrection.Click += new System.EventHandler(this.btnCloseCorrection_Click);
            // 
            // btnNewNC
            // 
            this.btnNewNC.BackColor = System.Drawing.Color.White;
            this.btnNewNC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNewNC.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewNC.ForeColor = System.Drawing.Color.Black;
            this.btnNewNC.Location = new System.Drawing.Point(131, 102);
            this.btnNewNC.Name = "btnNewNC";
            this.btnNewNC.Size = new System.Drawing.Size(47, 26);
            this.btnNewNC.TabIndex = 190;
            this.btnNewNC.UseVisualStyleBackColor = false;
            // 
            // pnNCOpen
            // 
            this.pnNCOpen.Controls.Add(this.txtNCReViewReason);
            this.pnNCOpen.Controls.Add(this.label23);
            this.pnNCOpen.Location = new System.Drawing.Point(524, 7);
            this.pnNCOpen.Name = "pnNCOpen";
            this.pnNCOpen.Size = new System.Drawing.Size(307, 89);
            this.pnNCOpen.TabIndex = 203;
            this.pnNCOpen.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(890, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 19);
            this.label4.TabIndex = 182;
            this.label4.Text = "NC closed";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(520, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(199, 19);
            this.label3.TabIndex = 181;
            this.label3.Text = "Corrective action not closed";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(234, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(155, 19);
            this.label2.TabIndex = 180;
            this.label2.Text = "Correction not closed";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(62, 104);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 19);
            this.label1.TabIndex = 179;
            this.label1.Text = "New NC";
            // 
            // dtpClosedate
            // 
            this.dtpClosedate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpClosedate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpClosedate.Location = new System.Drawing.Point(1141, 23);
            this.dtpClosedate.Name = "dtpClosedate";
            this.dtpClosedate.Size = new System.Drawing.Size(68, 26);
            this.dtpClosedate.TabIndex = 201;
            // 
            // dgvUserDetails
            // 
            this.dgvUserDetails.AllowUserToAddRows = false;
            this.dgvUserDetails.AllowUserToDeleteRows = false;
            this.dgvUserDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvUserDetails.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvUserDetails.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvUserDetails.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvUserDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUserDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SlNo,
            this.NCNumber,
            this.ProjectCode,
            this.ProjectName,
            this.DateOpened,
            this.Createdby,
            this.AssignedTo,
            this.Priority,
            this.NCType,
            this.SupplierName,
            this.CloseDate,
            this.Description,
            this.Correction,
            this.PDC1,
            this.CorrectionStatus,
            this.CorrectionDate,
            this.RootCause,
            this.CorrectiveAction,
            this.ObjectiveEvidence,
            this.CACorrectionStatus,
            this.CADate,
            this.Disposition,
            this.CostIncurred});
            this.dgvUserDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvUserDetails.Location = new System.Drawing.Point(3, 143);
            this.dgvUserDetails.Name = "dgvUserDetails";
            this.dgvUserDetails.ReadOnly = true;
            this.dgvUserDetails.RowHeadersVisible = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvUserDetails.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvUserDetails.RowTemplate.Height = 24;
            this.dgvUserDetails.Size = new System.Drawing.Size(1252, 512);
            this.dgvUserDetails.TabIndex = 200;
            this.dgvUserDetails.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvUserDetails_CellClick);
            this.dgvUserDetails.DoubleClick += new System.EventHandler(this.dgvUserDetails_DoubleClick);
            // 
            // SlNo
            // 
            this.SlNo.DataPropertyName = "SlNo";
            this.SlNo.FillWeight = 107.3323F;
            this.SlNo.HeaderText = "SlNo";
            this.SlNo.Name = "SlNo";
            this.SlNo.ReadOnly = true;
            this.SlNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SlNo.Width = 43;
            // 
            // NCNumber
            // 
            this.NCNumber.DataPropertyName = "NCNumber";
            this.NCNumber.FillWeight = 195.6828F;
            this.NCNumber.HeaderText = "NCNumber";
            this.NCNumber.Name = "NCNumber";
            this.NCNumber.ReadOnly = true;
            this.NCNumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.NCNumber.Width = 83;
            // 
            // ProjectCode
            // 
            this.ProjectCode.DataPropertyName = "ProjectCode";
            this.ProjectCode.FillWeight = 187.3186F;
            this.ProjectCode.HeaderText = "ProjectCode";
            this.ProjectCode.Name = "ProjectCode";
            this.ProjectCode.ReadOnly = true;
            this.ProjectCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectCode.Width = 90;
            // 
            // ProjectName
            // 
            this.ProjectName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ProjectName.DataPropertyName = "ProjectDescription";
            this.ProjectName.HeaderText = "Project Name";
            this.ProjectName.Name = "ProjectName";
            this.ProjectName.ReadOnly = true;
            this.ProjectName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // DateOpened
            // 
            this.DateOpened.DataPropertyName = "Date Opened";
            this.DateOpened.FillWeight = 174.5336F;
            this.DateOpened.HeaderText = "Date Opened";
            this.DateOpened.Name = "DateOpened";
            this.DateOpened.ReadOnly = true;
            this.DateOpened.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DateOpened.Width = 96;
            // 
            // Createdby
            // 
            this.Createdby.DataPropertyName = "Created by";
            this.Createdby.FillWeight = 127.5544F;
            this.Createdby.HeaderText = "Created by";
            this.Createdby.Name = "Createdby";
            this.Createdby.ReadOnly = true;
            this.Createdby.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Createdby.Width = 81;
            // 
            // AssignedTo
            // 
            this.AssignedTo.DataPropertyName = "AssignedTo";
            this.AssignedTo.FillWeight = 117.9967F;
            this.AssignedTo.HeaderText = "AssignedTo";
            this.AssignedTo.Name = "AssignedTo";
            this.AssignedTo.ReadOnly = true;
            this.AssignedTo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.AssignedTo.Width = 84;
            // 
            // Priority
            // 
            this.Priority.DataPropertyName = "Priority";
            this.Priority.FillWeight = 74.97663F;
            this.Priority.HeaderText = "Priority";
            this.Priority.Name = "Priority";
            this.Priority.ReadOnly = true;
            this.Priority.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Priority.Width = 60;
            // 
            // NCType
            // 
            this.NCType.DataPropertyName = "NCType";
            this.NCType.FillWeight = 72.01997F;
            this.NCType.HeaderText = "NCType";
            this.NCType.Name = "NCType";
            this.NCType.ReadOnly = true;
            this.NCType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.NCType.Width = 62;
            // 
            // SupplierName
            // 
            this.SupplierName.DataPropertyName = "SupplierName";
            this.SupplierName.HeaderText = "SupplierName";
            this.SupplierName.Name = "SupplierName";
            this.SupplierName.ReadOnly = true;
            this.SupplierName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SupplierName.Width = 103;
            // 
            // CloseDate
            // 
            this.CloseDate.DataPropertyName = "Date Closed";
            this.CloseDate.FillWeight = 83.02346F;
            this.CloseDate.HeaderText = "CloseDate";
            this.CloseDate.Name = "CloseDate";
            this.CloseDate.ReadOnly = true;
            this.CloseDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CloseDate.Width = 77;
            // 
            // Description
            // 
            this.Description.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Description.DataPropertyName = "Description";
            this.Description.HeaderText = "Description";
            this.Description.Name = "Description";
            this.Description.ReadOnly = true;
            this.Description.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Description.Width = 85;
            // 
            // Correction
            // 
            this.Correction.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Correction.DataPropertyName = "Correction";
            this.Correction.HeaderText = "Correction";
            this.Correction.Name = "Correction";
            this.Correction.ReadOnly = true;
            this.Correction.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Correction.Width = 79;
            // 
            // PDC1
            // 
            this.PDC1.DataPropertyName = "PDC1";
            this.PDC1.FillWeight = 38.12933F;
            this.PDC1.HeaderText = "PDC";
            this.PDC1.Name = "PDC1";
            this.PDC1.ReadOnly = true;
            this.PDC1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PDC1.Width = 39;
            // 
            // CorrectionStatus
            // 
            this.CorrectionStatus.DataPropertyName = "CorrectionStatus";
            this.CorrectionStatus.FillWeight = 110.8178F;
            this.CorrectionStatus.HeaderText = "CorrectionStatus";
            this.CorrectionStatus.Name = "CorrectionStatus";
            this.CorrectionStatus.ReadOnly = true;
            this.CorrectionStatus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CorrectionStatus.Width = 117;
            // 
            // CorrectionDate
            // 
            this.CorrectionDate.DataPropertyName = "CorrectionDate";
            this.CorrectionDate.FillWeight = 86.75081F;
            this.CorrectionDate.HeaderText = "CorrectionDate";
            this.CorrectionDate.Name = "CorrectionDate";
            this.CorrectionDate.ReadOnly = true;
            this.CorrectionDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CorrectionDate.Width = 108;
            // 
            // RootCause
            // 
            this.RootCause.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.RootCause.DataPropertyName = "RootCause";
            this.RootCause.HeaderText = "RootCause";
            this.RootCause.Name = "RootCause";
            this.RootCause.ReadOnly = true;
            this.RootCause.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RootCause.Width = 80;
            // 
            // CorrectiveAction
            // 
            this.CorrectiveAction.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.CorrectiveAction.DataPropertyName = "CorrectiveAction";
            this.CorrectiveAction.HeaderText = "CorrectiveAction";
            this.CorrectiveAction.Name = "CorrectiveAction";
            this.CorrectiveAction.ReadOnly = true;
            this.CorrectiveAction.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CorrectiveAction.Width = 118;
            // 
            // ObjectiveEvidence
            // 
            this.ObjectiveEvidence.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ObjectiveEvidence.DataPropertyName = "ObjectiveEvidence";
            this.ObjectiveEvidence.HeaderText = "ObjectiveEvidence";
            this.ObjectiveEvidence.Name = "ObjectiveEvidence";
            this.ObjectiveEvidence.ReadOnly = true;
            this.ObjectiveEvidence.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ObjectiveEvidence.Width = 130;
            // 
            // CACorrectionStatus
            // 
            this.CACorrectionStatus.DataPropertyName = "CACorrectionStatus";
            this.CACorrectionStatus.FillWeight = 93.38215F;
            this.CACorrectionStatus.HeaderText = "CACorrectionStatus";
            this.CACorrectionStatus.Name = "CACorrectionStatus";
            this.CACorrectionStatus.ReadOnly = true;
            this.CACorrectionStatus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CACorrectionStatus.Width = 134;
            // 
            // CADate
            // 
            this.CADate.DataPropertyName = "CADate";
            this.CADate.FillWeight = 34.81019F;
            this.CADate.HeaderText = "CADate";
            this.CADate.Name = "CADate";
            this.CADate.ReadOnly = true;
            this.CADate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CADate.Width = 60;
            // 
            // Disposition
            // 
            this.Disposition.DataPropertyName = "Disposition";
            this.Disposition.FillWeight = 46.60604F;
            this.Disposition.HeaderText = "Disposition";
            this.Disposition.Name = "Disposition";
            this.Disposition.ReadOnly = true;
            this.Disposition.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Disposition.Width = 84;
            // 
            // CostIncurred
            // 
            this.CostIncurred.DataPropertyName = "CostIncurred";
            this.CostIncurred.FillWeight = 49.06517F;
            this.CostIncurred.HeaderText = "Cost Incurred";
            this.CostIncurred.Name = "CostIncurred";
            this.CostIncurred.ReadOnly = true;
            this.CostIncurred.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CostIncurred.Width = 96;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.dgvUserDetails, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 21.2766F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 78.7234F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1258, 658);
            this.tableLayoutPanel1.TabIndex = 208;
            // 
            // frmUserNcDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1258, 658);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmUserNcDetails";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "View NC Details";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmUserNcDetails_FormClosing);
            this.Load += new System.EventHandler(this.frmUserNcDetails_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnGenaralPanel.ResumeLayout(false);
            this.pnGenaralPanel.PerformLayout();
            this.pnNCOpen.ResumeLayout(false);
            this.pnNCOpen.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUserDetails)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtNCReViewReason;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button btnTotal;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnNCClosed;
        private System.Windows.Forms.Button btnCANotClosed;
        private System.Windows.Forms.Button btnCorrectionClosed;
        private System.Windows.Forms.Button btnNewNC;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnExcel;
        private System.Windows.Forms.ComboBox cmbDepartment;
        private System.Windows.Forms.ComboBox cmbAssignAction;
        private System.Windows.Forms.Button btnCloseCorrection;
        private System.Windows.Forms.Panel pnNCOpen;
        private System.Windows.Forms.DateTimePicker dtpClosedate;
        private System.Windows.Forms.DataGridView dgvUserDetails;
        private System.Windows.Forms.Button btnSummaryEmail;
        private System.Windows.Forms.ListBox lstAddUser;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SlNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn NCNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectName;
        private System.Windows.Forms.DataGridViewTextBoxColumn DateOpened;
        private System.Windows.Forms.DataGridViewTextBoxColumn Createdby;
        private System.Windows.Forms.DataGridViewTextBoxColumn AssignedTo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Priority;
        private System.Windows.Forms.DataGridViewTextBoxColumn NCType;
        private System.Windows.Forms.DataGridViewTextBoxColumn SupplierName;
        private System.Windows.Forms.DataGridViewTextBoxColumn CloseDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Description;
        private System.Windows.Forms.DataGridViewTextBoxColumn Correction;
        private System.Windows.Forms.DataGridViewTextBoxColumn PDC1;
        private System.Windows.Forms.DataGridViewTextBoxColumn CorrectionStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn CorrectionDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn RootCause;
        private System.Windows.Forms.DataGridViewTextBoxColumn CorrectiveAction;
        private System.Windows.Forms.DataGridViewTextBoxColumn ObjectiveEvidence;
        private System.Windows.Forms.DataGridViewTextBoxColumn CACorrectionStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn CADate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Disposition;
        private System.Windows.Forms.DataGridViewTextBoxColumn CostIncurred;
        private System.Windows.Forms.Panel pnGenaralPanel;
        private System.Windows.Forms.Label lblFromdate;
        private System.Windows.Forms.Label lblToDate;
        private System.Windows.Forms.DateTimePicker dtpFromDate;
        private System.Windows.Forms.DateTimePicker dptToDate;
    }
}