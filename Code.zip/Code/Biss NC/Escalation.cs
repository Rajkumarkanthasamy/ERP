﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Outlook = Microsoft.Office.Interop.Outlook;
using System.Text.RegularExpressions;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Diagnostics;

namespace Erp_Project_With_Buttons.Biss_NC
{
    public partial class Escalation : Form
    {
        frmForm2 frm = new frmForm2();
        Login.frmLoginForm Login = new Login.frmLoginForm();

        System.Windows.Controls.TextBox textBox;
        public Escalation()
        {
            InitializeComponent();
        }
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        private static string sProjectCode;
        DataTable dtNcNumber = new DataTable();
        DataTable dtLoginDetails = new DataTable();
        DataTable dtProjectlist = new DataTable();
        DataTable dtUserName = new DataTable();
        DataTable dtProjectBOM = new DataTable();
        DataTable dtEscNC = new DataTable();
        DataTable dtmeeting = new DataTable();
        string sNCNumber;
        int iLastNumber = 0;
        int iLastreminder = 0;
        string ExcelFolderPath;
        string FileFullPath;
        DataTable dtnc = new DataTable();

        public string fnProjectcode
        {
            get
            {
                return sProjectCode;
            }
            set
            {
                sProjectCode = value;
            }
        }
        private static string sNCNumberfn;
        public string fnNCNumber
        {
            get
            {
                return sNCNumberfn;
            }
            set
            {
                sNCNumberfn = value;
            }
        }
        private void Escalation_Load(object sender, EventArgs e)
        {

            txtRequesterName.Text = Login.GetUserDetails[2];
            txtRequesterDept.Text = Login.GetUserDetails[23];

            dtProjectlist = DAL.fnAllProjectList(null).Tables[0];
            foreach (DataRow dr in dtProjectlist.Rows)
            {
                if (!cmbProjectcode.Items.Contains(dr["ProjectCode"].ToString()))
                {
                    cmbProjectcode.Items.Add(dr["ProjectCode"].ToString());
                }
            }
            dtEscNC = DAL.fnEscalationNCNumber(6, "", "").Tables[0];
            foreach (DataRow dr in dtEscNC.Rows)
            {
                if (!NCnumcmbbox.Items.Contains(dr["NCNumber"].ToString()))
                {
                    NCnumcmbbox.Items.Add(dr["NCNumber"].ToString());
                }
            }


            DataTable dtvendorList = DAL.fnVedorList(null).Tables[0];

            foreach (DataRow dr in dtvendorList.Rows)
            {
                if (!cmbVendorName.Items.Contains(dr["VendorName"].ToString()))
                {
                    cmbVendorName.Items.Add(dr["VendorName"].ToString());
                }
            }

            dtUserName = DAL.fnUserList("", 2).Tables[0];
            foreach (DataRow DR in dtUserName.Rows)
            {
                if (!cmbAssignedTo.Items.Contains(DR["UserName"].ToString()))
                    cmbAssignedTo.Items.Add(DR["UserName"].ToString());

                if (!cmbCCUser.Items.Contains(DR["UserName"].ToString()))
                    cmbCCUser.Items.Add(DR["UserName"].ToString());

                if (!cmbReAssign.Items.Contains(DR["UserName"].ToString()))
                    cmbReAssign.Items.Add(DR["UserName"].ToString());

                if (!cmbUserCC.Items.Contains(DR["UserName"].ToString()))
                    cmbUserCC.Items.Add(DR["UserName"].ToString());
            }

            cmbUserCC.SelectedItem = "Megha";
            cmbUserCC.SelectedItem = "Girish";
            cmbUserCC.SelectedIndex = -1;

        }
        DataTable dtlocation = new DataTable();
        private void cmbProjectcode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbProjectcode.SelectedIndex == -1)
            {
                lblprojname.ResetText();
                lblCustomer.ResetText();
            }
            else
            {
                DataView dvProject = new DataView(dtProjectlist);
                dvProject.RowFilter = "ProjectCode Like'" + cmbProjectcode.Text + "'";
                DataTable dtrow = dvProject.ToTable();
                lblprojname.Text = dtrow.Rows[0]["ProjectDescription"].ToString();
                lblCustomer.Text = dtrow.Rows[0]["Customer"].ToString();
                dtProjectBOM = DAL.fnProjectBOMList(cmbProjectcode.Text).Tables[0];
                dtlocation = DAL.fnEscalationNCNumber(7, dtrow.Rows[0]["CustomerCode"].ToString(), "").Tables[0];
                if (dtlocation.Rows.Count > 0)
                {
                    cmblocation.Text = dtlocation.Rows[0]["Country"].ToString();
                    cmblocation.Enabled = false;
                }
                else
                {
                    cmblocation.ResetText();
                    cmblocation.Enabled = true;
                }
                cmbComponentType.Items.Clear();
                if (dtProjectBOM.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtProjectBOM.Rows)
                    {
                        if (!cmbComponentType.Items.Contains(dr["ProductName"].ToString() + " - " + dr["ProductType"].ToString()))
                        {
                            cmbComponentType.Items.Add(dr["ProductName"].ToString() + " - " + dr["ProductType"].ToString());
                        }

                    }
                }

                cmbComponentType.Items.Add("Controller");
                cmbComponentType.Items.Add("Transducer");
                cmbComponentType.Items.Add("Software");
            }
            // btnSave.Enabled = true;
        }
        string sRecieverEmailID;
        private void cmbAssignedTo_SelectedIndexChanged(object sender, EventArgs e)
        {
            sRecieverEmailID = "";
            if (cmbAssignedTo.SelectedIndex == -1)
            {
                //  txtAssignedtoDept.ResetText();
            }
            else
            {
                DataView dvUser = new DataView(dtUserName);
                dvUser.RowFilter = "UserName Like'" + cmbAssignedTo.Text + "'";
                DataTable dtrow = dvUser.ToTable();
                //  txtAssignedtoDept.Text = dtrow.Rows[0]["Department"].ToString();
                sRecieverEmailID = dtrow.Rows[0]["emailid"].ToString();
                txtAssignedtoDept.Text = dtrow.Rows[0]["Department"].ToString();
            }
        }

        private void CreateEMail(string sNCNumber, string sTo, ListBox sCC, string sSubject)
        {
            try
            {
                Outlook.Application oApp = new Outlook.Application();
                Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                oMsg.Subject = "NC Number " + sNCNumber + ". Project : " + lblprojname.Text + ". Customer : "+ lblCustomer .Text+ "";
                //  oMsg.iHTMLBody = true;
                oMsg.HTMLBody = sSubject;
                // Add a recipient.
                Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                oRecips.Add(sTo);
                oRecips.ResolveAll();
                if (sCC.Items.Count > 0)
                {
                    Outlook.Recipient oRecip;
                    List<string> sCCRecipsList = new List<string>();
                    foreach (string tempTO in sCC.Items)
                    {
                        if (tempTO != null)
                            sCCRecipsList.Add(tempTO);
                    }
                    foreach (string t in sCCRecipsList)
                    {

                        oRecip = (Outlook.Recipient)oRecips.Add(t);
                        oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                        oRecip.Resolve();
                    }
                    oMsg.Send();
                    oRecip = null;
                }
                else
                {
                    // Send.
                    oMsg.Send();
                    // Clean up.
                    oRecips = null;
                }

                oMsg = null;
                oApp = null;
            }
            catch (Exception ex)
            {

            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            #region Tab1
            {
                if (cmbProjectcode.SelectedIndex >= 0 && cmbAssignedTo.SelectedIndex >= 0 && cmbPriority.SelectedIndex >= 0 && cmbNCType.SelectedIndex >= 0 && !string.IsNullOrEmpty(txtDescriptionofNC.Text))
                {
                    if (btnSave.Text == "Save")
                    {
                        string sYear = DateTime.Today.Year.ToString().Substring(2, 2);
                        dtNcNumber = DAL.fnEscalationNCNumber(0, "", "").Tables[0];
                        if (dtNcNumber.Rows.Count > 0)
                        {
                            iLastNumber = Convert.ToInt32(dtNcNumber.Rows[0][0].ToString());
                            iLastNumber++;
                        }
                        else
                        {
                            iLastNumber++;
                        }
                        string value = String.Format("{0:D4}", iLastNumber);
                        sNCNumber = ("Bi" + sYear + value);
                        txtRequesterName.Text = Login.GetUserDetails[2];
                        txtRequesterDept.Text = Login.GetUserDetails[23];
                        GlobalClass.iSuccess = DAL.fnAddEscalationNC(Global.uINSERT, sNCNumber, Login.GetUserDetails[2], Login.GetUserDetails[23],
                         cmbProjectcode.Text, cmbAssignedTo.Text, txtAssignedtoDept.Text, cmbEnvironMent.Text, cmbPriority.Text, cmbNCType.Text,
                         txtDescriptionofNC.Text, dtpCreatedDate.Text, txtOptionalOE.Text, cmbComponentType.Text, cmbSubProduct.Text, txtObservation.Text, cmbVendorName.Text, cmbQSR.Text, cmbproductline.Text, cmbcoesite.Text, cmblocation.Text, txtNCReviewComments.Text);

                        MessageBox.Show("New NC '" + sNCNumber + "' raised & assigned to '" + cmbAssignedTo.Text + "' successfully", "Success", 0, MessageBoxIcon.Information);
                        btnSave.Enabled = false;
                        string sMessage = "<font face=Calibri> Dear " + cmbAssignedTo.Text.ToUpper() + ", <br />NC has been raised on the following issue. Please take necessary action within 3 days.<br /> <br /> <b> Priority :</b> " + cmbPriority.Text + "  <br /><br /> <b>Description of NC : </b>" + txtDescriptionofNC.Text + " <br/><br /> <b>Product : </b>" + cmbComponentType.Text + " <br /> <b>Sub Product : </b>" + cmbSubProduct.Text + " <br /> <br /> <b> Regards,<br /> " + Login.GetUserDetails[2] + " </b>  <br /><br /> <br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";

                        CreateEMail(sNCNumber, sRecieverEmailID, lstAddUser, sMessage);
                        FormReload();
                    }
                    else if (btnSave.Text == "Update")
                    {
                        if (!string.IsNullOrEmpty(NCnumcmbbox.Text))
                        {
                            GlobalClass.iSuccess = DAL.fnAddEscalationNC(Global.uUPDATE, NCnumcmbbox.Text, Login.GetUserDetails[2], Login.GetUserDetails[23],
                            cmbProjectcode.Text, cmbAssignedTo.Text, txtAssignedtoDept.Text, cmbEnvironMent.Text, cmbPriority.Text, cmbNCType.Text,
                            txtDescriptionofNC.Text, dtpCreatedDate.Text, txtOptionalOE.Text, cmbComponentType.Text, cmbSubProduct.Text, txtObservation.Text, cmbVendorName.Text, cmbQSR.Text, cmbproductline.Text, cmbcoesite.Text, cmblocation.Text, txtNCReviewComments.Text);

                            MessageBox.Show("NC '" + NCnumcmbbox.Text + "' updated & assigned to '" + cmbAssignedTo.Text + "' successfully", "Success", 0, MessageBoxIcon.Information);
                            btnSave.Enabled = false;
                            string sMessage = "<font face=Calibri> Dear " + cmbAssignedTo.Text.ToUpper() + ", <br />NC has been updated on the following issue. Please take necessary action within 3 days.<br /> <br /> <b> Priority :</b> " + cmbPriority.Text + "  <br /><br /> <b>Description of NC : </b>" + txtDescriptionofNC.Text + " <br/><br /> <b>Product : </b>" + cmbComponentType.Text + " <br /> <b>Sub Product : </b>" + cmbSubProduct.Text + " <br /> <br /> <b> Regards,<br /> " + Login.GetUserDetails[2] + " </b>  <br /><br /> <br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
                            //   string sMessage = "<font face=Calibri> Dear " + cmbAssignedTo.Text.ToUpper() + ", <br />Rejected NC has been updated on the following issue. Please take necessary required action.<br /> <br /> <b> Priority : " + cmbPriority.Text + " </b> <br /><br /> <b>Description of NC : </b>" + txtDescriptionofNC.Text + " <br/><br /> <br /> <br /> <br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
                            CreateEMail(NCnumcmbbox.Text, sRecieverEmailID, lstAddUser, sMessage);
                            FormReload();
                        }
                        else
                        {
                            MessageBox.Show("Please select NC Number to update", "Error", 0, MessageBoxIcon.Error);

                        }

                    }
                }
                else
                {
                    if (cmbProjectcode.SelectedIndex < 0)
                    {
                        MessageBox.Show("Please select project code ", "Error", 0, MessageBoxIcon.Error);
                        cmbProjectcode.Focus();
                    }
                    else if (cmbAssignedTo.SelectedIndex < 0)
                    {
                        MessageBox.Show("Please select assigned to name ", "Error", 0, MessageBoxIcon.Error);
                        cmbAssignedTo.Focus();
                    }
                    else if (cmbEnvironMent.SelectedIndex < 0)
                    {
                        MessageBox.Show("Please select environment ", "Error", 0, MessageBoxIcon.Error);
                        cmbEnvironMent.Focus();
                    }
                    else if (cmbPriority.SelectedIndex < 0)
                    {
                        MessageBox.Show("Please select priority ", "Error", 0, MessageBoxIcon.Error);
                        cmbPriority.Focus();
                    }
                    else if (cmbNCType.SelectedIndex < 0)
                    {
                        MessageBox.Show("Please select NC type ", "Error", 0, MessageBoxIcon.Error);
                        cmbNCType.Focus();
                    }
                    else if (string.IsNullOrEmpty(txtDescriptionofNC.Text))
                    {
                        MessageBox.Show("Please write the description of NC", "Error", 0, MessageBoxIcon.Error);
                        cmbNCType.Focus();
                    }
                }
            }
            #endregion
        }
        DataTable dtncreminder = new DataTable();
        DataTable dtreminderlvl = new DataTable();
        private void btnReminder_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(cmbProjectcode.Text) && !string.IsNullOrEmpty(NCnumcmbbox.Text))
            {
                dtncreminder = DAL.fnEscalationNCNumber(1, NCnumcmbbox.Text, cmbPriority.Text).Tables[0];
                if (dtncreminder.Rows.Count > 0)
                {
                    iLastreminder = Convert.ToInt32(dtncreminder.Rows[0][0].ToString());
                    iLastreminder++;
                }
                else
                {
                    iLastreminder++;
                }
                GlobalClass.iSuccess = DAL.fnEscalationReviewMeeting(1, NCnumcmbbox.Text, cmbProjectcode.Text, cmbPriority.Text, "", "", "", "", "", iLastreminder, "", "", "");
                if (GlobalClass.iSuccess > 0)
                {
                    dtncreminder = DAL.fnEscalationNCNumber(1, NCnumcmbbox.Text, cmbPriority.Text).Tables[0];
                    if (dtncreminder.Rows.Count > 0)
                    {
                        if (Convert.ToInt32(dtncreminder.Rows[0][0]) > 3)
                        {
                            remcount.Text = "0";
                        }
                        else
                        {
                            remcount.Text = dtncreminder.Rows[0][0].ToString();
                        }
                    }
                    //remcount.Text= dtncreminder
                    if (iLastreminder > 3)
                    {
                        string lavel = cmbPriority.Text.Split(' ')[1];
                        int remdlavel = Convert.ToInt32(lavel);
                        remdlavel++;
                        if (remdlavel < 5)
                        {
                            cmbPriority.Text = "Level " + remdlavel + "";
                            GlobalClass.iSuccess = DAL.fnEscalationReviewMeeting(2, NCnumcmbbox.Text, cmbProjectcode.Text, cmbPriority.Text, "", "", "", "", "", 0, "", "", "");
                            GlobalClass.iSuccess = DAL.fnEscalationReviewMeeting(3, NCnumcmbbox.Text, cmbPriority.Text, "3 Reminders has been sent ", "", "", "", "", "", 0, "", "", "");

                            MessageBox.Show("Level has Been Changed successfully", "Success", 0, MessageBoxIcon.Information);
                        }
                        iLastreminder = 0;
                    }
                    MessageBox.Show("NC '" + sNCNumberfn + "' Sent Reminder to'" + cmbAssignedTo.Text + "' successfully", "Success", 0, MessageBoxIcon.Information);
                    btnSave.Enabled = false;
                    string sMessage = "<font face=Calibri> Dear " + cmbAssignedTo.Text.ToUpper() + ", <br />Reminder to Close the NC raised.Details are provided below .<br /> <br /> <b>Description of NC : </b>" + txtDescriptionofNC.Text + " <br/><br /> <b> Current Escalation Level :</b> " + cmbPriority.Text + "  <br /><br /> <b>Product : </b>" + cmbComponentType.Text + " <br /> <b>Sub Product : </b>" + cmbSubProduct.Text + " <br /> <br /> <b> Regards,<br /> " + Login.GetUserDetails[2] + " </b>  <br /><br /> <br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
                    CreateEMail(sNCNumberfn, sRecieverEmailID, lstAddUser, sMessage);
                }
            }
        }
        private static readonly Regex sWhitespace = new Regex(@"\s+");
        public static string ReplaceWhitespace(string input, string replacement)
        {
            return sWhitespace.Replace(input, replacement);
        }
        String radio;
        private void savecalcelbtn_Click(object sender, EventArgs e)
        {

            if (!string.IsNullOrEmpty(cmbProjectcode.Text) && !string.IsNullOrEmpty(NCnumcmbbox.Text) && !string.IsNullOrEmpty(MOMTextbox.Text) && !string.IsNullOrEmpty(ActPlanTextbox.Text) && !string.IsNullOrEmpty(ReviewTextBox.Text) && !string.IsNullOrEmpty(dateofresultiontext.Text))
            {
                if (yesradio.Checked == true)
                {
                    radio = "Yes";
                }
                else
                {
                    radio = "No";
                }


                var strmom = ReplaceWhitespace(MOMTextbox.Text, "");
                GlobalClass.iSuccess = DAL.fnEscalationReviewMeeting(0, NCnumcmbbox.Text, cmbProjectcode.Text, lblreviewmeettext.Text, ReviewTextBox.Text, MOMTextbox.Text, ActPlanTextbox.Text, dateofresultiontext.Text, CmbRMLevel.Text, 0, radio, dtpclose.Text, "Open");

                if (GlobalClass.iSuccess > 0)
                {
                    if (cmbPriority.Text != CmbRMLevel.Text)
                    {
                        GlobalClass.iSuccess = DAL.fnEscalationReviewMeeting(3, NCnumcmbbox.Text, CmbRMLevel.Text, txtreasonlevel.Text, "", "", "", "", "", 0, "", "", "");
                    }
                    MessageBox.Show("Minutes of Meeting Saved successfully", "Success", 0, MessageBoxIcon.Information);
                    cmbPriority.Text = CmbRMLevel.Text;
                    GlobalClass.iSuccess = DAL.fnEscalationReviewMeeting(2, NCnumcmbbox.Text, cmbProjectcode.Text, CmbRMLevel.Text, "", "", "", "", "", 0, "", "", "");
                    reviewmeetpn.Visible = false;
                    // MOMTextbox.Clear();
                    // ActPlanTextbox.Clear();
                    // ReviewTextBox.Clear();
                    //txtreasonlevel.Clear();
                }
            }
            else
            {
                if (cmbProjectcode.SelectedIndex < 0)
                {
                    MessageBox.Show("Please select project code ", "Error", 0, MessageBoxIcon.Error);
                    cmbProjectcode.Focus();
                }
                else if (cmbAssignedTo.SelectedIndex < 0)
                {
                    MessageBox.Show("Please select assigned to name ", "Error", 0, MessageBoxIcon.Error);
                    cmbAssignedTo.Focus();
                }
                else if (string.IsNullOrEmpty(MOMTextbox.Text))
                {
                    MessageBox.Show("Please select Minutes of Meeting of NC ", "Error", 0, MessageBoxIcon.Error);
                }
                else if (string.IsNullOrEmpty(ActPlanTextbox.Text))
                {
                    MessageBox.Show("Please write the Action Plan of NC", "Error", 0, MessageBoxIcon.Error);
                }
                else if (string.IsNullOrEmpty(ReviewTextBox.Text))
                {
                    MessageBox.Show("Please write the Review Team of NC", "Error", 0, MessageBoxIcon.Error);
                }
            }
        }

        private void frmEscalationClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            frm.Show();
        }
        DataTable dtreview = new DataTable();

        private void Meetingbtn_Click(object sender, EventArgs e)
        {
            dtreview = DAL.fnEscalationNCNumber(4, NCnumcmbbox.Text, cmbProjectcode.Text).Tables[0];
            if (dtreview.Rows.Count > 0)
            {
                int a = Convert.ToInt32(dtreview.Rows[0][0]);
                a++;
                lblreviewmeettext.Text = a.ToString();
            }
            else
            {
                lblreviewmeettext.Text = "1";
            }
            CmbRMLevel.Text = cmbPriority.Text;

            if (cmbPriority.Text == "Level 1")
            {
                CmbRMLevel.Items.Add("Level 2");
                CmbRMLevel.Items.Add("Level 3");
                CmbRMLevel.Items.Add("Level 4");
            }
            if (cmbPriority.Text == "Level 2")
            {
                CmbRMLevel.Items.Add("Level 3");
                CmbRMLevel.Items.Add("Level 4");
            }
            if (cmbPriority.Text == "Level 3")
            {
                CmbRMLevel.Items.Add("Level 4");
            }
            if (cmbPriority.Text == "Level 4")
            {
                CmbRMLevel.Items.Clear();
            }

            reviewmeetpn.Visible = true;
            RCApanel.Visible = false;
        }

        private void NCnumcmbbox_SelectedIndexChanged(object sender, EventArgs e)
        {
            fnNCNumberRecieved(NCnumcmbbox.Text);
        }
        DataTable dtUserNC = new DataTable();
        DataTable dtUserEmail = new DataTable();
        bool bDateCheck = false;

        private void fnNCNumberRecieved(string sNCNumber)
        {
            sNCNumberfn = NCnumcmbbox.Text;
            dtUserNC = DAL.fnLoadNCNumber(null, sNCNumber, 8).Tables[0];
            if (dtUserNC.Rows.Count > 0)
            {
                Meetingbtn.Visible = true;
                btnReminder.Visible = true;
                btnncclose.Visible = true;
                cmbPriority.Enabled = false;
                btnSave.Text = "Update";

                //  pnSave1.Visible = false;
                var level = dtUserNC.Rows[0]["Priority"].ToString();
                txtRequesterName.Text = dtUserNC.Rows[0]["RequestBy"].ToString();
                txtRequesterDept.Text = dtUserNC.Rows[0]["RequestDept"].ToString();
                cmbProjectcode.SelectedItem = dtUserNC.Rows[0]["ProjectCode"].ToString();
                cmbAssignedTo.SelectedItem = dtUserNC.Rows[0]["AssignedTo"].ToString();
                txtAssignedtoDept.SelectedItem = dtUserNC.Rows[0]["AssignedDept"].ToString();
                cmbEnvironMent.SelectedItem = dtUserNC.Rows[0]["SalesTerritory"].ToString();
                cmbPriority.SelectedItem = dtUserNC.Rows[0]["Priority"].ToString();
                cmbNCType.SelectedItem = dtUserNC.Rows[0]["NCType"].ToString();
                cmbQSR.Text = dtUserNC.Rows[0]["QsrEscOwner"].ToString();
                cmbEnvironMent.Text = dtUserNC.Rows[0]["SalesTerritory"].ToString();
                cmbproductline.Text = dtUserNC.Rows[0]["ProductLine"].ToString();
                cmbcoesite.Text = dtUserNC.Rows[0]["COESite"].ToString();
                cmblocation.Text = dtUserNC.Rows[0]["Location"].ToString();

                if (cmbNCType.SelectedIndex > 1)
                {
                    cmbVendorName.SelectedItem = dtUserNC.Rows[0]["SupplierName"].ToString();
                }
                txtDescriptionofNC.Text = dtUserNC.Rows[0]["DescriptionOfNC"].ToString();
                txtObservation.Text = dtUserNC.Rows[0]["Observation"].ToString();
                txtOptionalOE.Text = dtUserNC.Rows[0]["ObjectiveEvidence"].ToString();
                cmbComponentType.SelectedItem = dtUserNC.Rows[0]["Product"].ToString();
                cmbSubProduct.Text = dtUserNC.Rows[0]["SubProduct"].ToString();
                cmbDisposition.SelectedItem = dtUserNC.Rows[0]["Disposition"].ToString();
                txtCorrectionRequested.Text = dtUserNC.Rows[0]["CorrectionRequested"].ToString();
                txtRootCause.Text = dtUserNC.Rows[0]["RootCause"].ToString();
                txtCorrectiveAction.Text = dtUserNC.Rows[0]["CorrectiveAction"].ToString();
                txtCostincurred.Text = dtUserNC.Rows[0]["CostIncurred"].ToString();
                txtManHours.Text = dtUserNC.Rows[0]["ManHours"].ToString();
                txtObjectiveEvidenceFound.Text = dtUserNC.Rows[0]["ObjectiveEvidenceFound"].ToString();
                txtNCReviewComments.Text = dtUserNC.Rows[0]["NCReviewComments"].ToString();

                if (string.IsNullOrEmpty(txtCorrectionRequested.Text))
                {
                    pnSave1.Enabled = true;
                    chkReAssign.Visible = true;
                    pnCorrection.Enabled = true;
                    pnRootCause.Enabled = false;
                    chkCorrectionEdit.Visible = false;
                    chkEditRootCause.Visible = false;
                }
                else
                {
                    chkCorrectionEdit.Visible = true;
                    pnSave1.Enabled = false;
                }
                if (!string.IsNullOrEmpty(dtUserNC.Rows[0]["PDC1"].ToString()))
                {

                    bDateCheck = true;
                    dtpPDC1.Value = Convert.ToDateTime(dtUserNC.Rows[0]["PDC1"]);
                    bDateCheck = false;
                    chkCorrectionEdit.Visible = true;
                    pnSave1.Enabled = false;
                }
                if (string.IsNullOrEmpty(txtRootCause.Text))
                {
                    chkReAssign.Visible = true;
                    //  pnSave1.Enabled = false;
                    pnCorrection.Enabled = false;
                    pnRootCause.Enabled = true;
                    chkEditRootCause.Visible = false;

                }
                else
                {
                    chkEditRootCause.Visible = true;
                }

                if (!string.IsNullOrEmpty(dtUserNC.Rows[0]["PDC2"].ToString()))
                {
                    bDateCheck = true;
                    dtpPDC2.Value = Convert.ToDateTime(dtUserNC.Rows[0]["PDC2"]);
                    bDateCheck = false;

                    txtRootCause.Text = dtUserNC.Rows[0]["RootCause"].ToString();
                    txtCorrectiveAction.Text = dtUserNC.Rows[0]["CorrectiveAction"].ToString();
                    txtCostincurred.Text = dtUserNC.Rows[0]["CostIncurred"].ToString();
                    txtObjectiveEvidenceFound.Text = dtUserNC.Rows[0]["ObjectiveEvidenceFound"].ToString();
                    chkEditRootCause.Visible = true;
                }

                if (!string.IsNullOrEmpty(txtRootCause.Text))
                {
                    pnCorrection.Enabled = false;
                    pnRootCause.Enabled = false;
                    pnObjectiveEvidence.Visible = true;
                    pnObjectiveEvidence.Enabled = true;
                }

                if (!string.IsNullOrEmpty(txtObjectiveEvidenceFound.Text))
                {
                    pnObjectiveEvidence.Enabled = false;
                }

                // Comment this after some validation
                chkEditRootCause.Visible = true;
                chkCorrectionEdit.Visible = true;
            }
        }
        //-------------------------------------------------------------------------------

        bool bPDC1Date = false;
        bool bPDC2Date = false;
        private void dtpPDC1_ValueChanged(object sender, EventArgs e)
        {
            if (!bDateCheck)
            {
                bPDC1Date = true;
                if (dtpPDC1.Value < DateTime.Today.Date)
                {
                    //   bPDC1Date = false;
                    //   MessageBox.Show("Probable date of completion should be greater than today date");
                }
                else if ((dtpPDC1.Value - DateTime.Today.Date).TotalDays > 15)
                {
                    if (cmbNCType.Text == "Major")
                    {
                        if ((dtpPDC1.Value - DateTime.Today.Date).TotalDays > 7)
                        {
                            bPDC2Date = false;
                            MessageBox.Show("Probable date of completion should be within a week");
                        }
                    }
                    else
                    {
                        if ((dtpPDC1.Value - DateTime.Today.Date).TotalDays > 14)
                        {
                            bPDC2Date = false;
                            MessageBox.Show("Probable date of completion should be within 2 weeks");
                        }
                    }

                }
            }
        }

        private void dtpPDC2_ValueChanged(object sender, EventArgs e)
        {
            if (!bDateCheck)
            {
                bPDC2Date = true;
                if (dtpPDC2.Value < DateTime.Today.Date)
                {
                    // bPDC2Date = false;
                    //  MessageBox.Show("Probable date of completion should be greater than today date");
                }
                else if ((dtpPDC2.Value - DateTime.Today.Date).TotalDays > 15)
                {
                    bPDC2Date = false;
                    MessageBox.Show("Probable date of completion should not be more than 15 days");
                }
            }
        }

        private void btnAcceptnCloseNC_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtObjectiveEvidenceFound.Text) && !string.IsNullOrEmpty(txtCostincurred.Text))
            {
                GlobalClass.iSuccess = DAL.fnAddNCSecondTab(11, sNCNumberfn, "", "", "", "", "", "", 0, "", dtpCloseDate.Text, "");
                GlobalClass.iSuccess = DAL.fnAddNCSecondTab(12, sNCNumberfn, "", "", "", "", "", "", 0, "", dtpCloseDate.Text, "");
                GlobalClass.iSuccess = DAL.fnAddNCSecondTab(13, sNCNumberfn, txtObjectiveEvidenceFound.Text, "", "", "", "", "", Convert.ToDouble(txtCostincurred.Text), txtManHours.Text, dtpCloseDate.Text, "");

                MessageBox.Show("Objective evidence details sent for review", "Success", 0, MessageBoxIcon.Information);
                string sMessage = "<font face=Calibri> Dear " + txtRequesterName.Text.ToUpper() + ", <br /> Corrective action taken & details of objective evidence provided.<br /> NC closed successfully. <br /> <br /> <b>  Regards,<br /> " + Login.GetUserDetails[2] + " </b> <br /> <br /><br /> <br /><br /><br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
                dtUserEmail = DAL.fnUserList(txtRequesterName.Text, 1).Tables[0];
                CreateEMail(sNCNumberfn, dtUserEmail.Rows[0]["emailid"].ToString(), lstAddUser, sMessage);
                FormReload();
            }
            else
            {
                if (string.IsNullOrEmpty(txtObjectiveEvidenceFound.Text))
                {
                    MessageBox.Show("Write objective evidence found to accept and close NC", "Error", 0, MessageBoxIcon.Error);
                }
                else if (string.IsNullOrEmpty(txtCostincurred.Text))
                {
                    MessageBox.Show("Add costing details close NC", "Error", 0, MessageBoxIcon.Error);
                }
            }
        }
        private void FormReload()
        {
            this.Hide();
            Escalation RaiseNC = new Escalation();
            RaiseNC.Show();
        }
        DataTable dtlogindetails = new DataTable();
        private void cmbCCUser_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtlogindetails = DAL.fnloginemail(cmbCCUser.Text).Tables[0];
            if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()) && !lstusers.Items.Contains(dtlogindetails.Rows[0]["emailid"].ToString()))
            {
                lstusers.Items.Add(dtlogindetails.Rows[0]["emailid"].ToString());
            }
        }
        private void btnReassign_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(sNCNumberfn))
            {
                if (cmbReAssign.SelectedIndex != -1 && cmbReassignDept.SelectedIndex != -1)
                {
                    GlobalClass.iSuccess = DAL.fnAddNCSecondTab(14, sNCNumberfn, cmbReAssign.Text, cmbReassignDept.Text, "", "", "", "", 0, null, null, "");
                    MessageBox.Show("NC '" + sNCNumberfn + "' re assigned &.\n Mail sent to '" + cmbReAssign.Text + "' for review", "Success", 0, MessageBoxIcon.Information);
                    string sMessage = "<font face=Calibri> Dear " + cmbReAssign.Text.ToUpper() + ", <br />NC has been raised on the following issue. Please take necessary action within 3 days.<br /> <br /> <b> Priority :</b> " + cmbPriority.Text + "  <br /><br /> <b>Description of NC : </b>" + txtDescriptionofNC.Text + " <br/><br /> <b>Product : </b>" + cmbComponentType.Text + " <br /> <b>Sub Product : </b>" + cmbSubProduct.Text + " <br /> <br /> <b> Regards,<br /> " + Login.GetUserDetails[2] + " </b>  <br /><br /> <br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
                    dtUserEmail = DAL.fnUserList(cmbReAssign.Text, 1).Tables[0];
                    CreateEMail(sNCNumberfn, dtUserEmail.Rows[0]["emailid"].ToString(), lstusers, sMessage);
                    btnReassign.Enabled = false;
                    FormReload();
                }
                else
                {
                    if (cmbReAssign.SelectedIndex == -1)
                    {
                        MessageBox.Show("Select the re assign user.", "Error", 0, MessageBoxIcon.Error);
                        cmbReAssign.Focus();
                    }
                    else if (cmbReassignDept.SelectedIndex == -1)
                    {
                        MessageBox.Show("Select the re assign user department.", "Error", 0, MessageBoxIcon.Error);
                        cmbReassignDept.Focus();
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select NC Number to update", "Error", 0, MessageBoxIcon.Error);

            }
        }
        private void chkCorrectionEdit_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCorrectionEdit.CheckState == CheckState.Checked)
            {
                pnCorrection.Enabled = true;
                btnCorrectionSave.Enabled = true;
            }
            else
            {
                pnCorrection.Enabled = false;
                btnCorrectionSave.Enabled = false;
            }
        }

        private void chkEditRootCause_CheckedChanged(object sender, EventArgs e)
        {
            if (chkEditRootCause.CheckState == CheckState.Checked)
            {
                pnRootCause.Enabled = true;
                btnRootCauseSave.Enabled = true;
            }
            else
            {
                pnRootCause.Enabled = false;
                btnRootCauseSave.Enabled = false;
            }
        }

        private void cmbUserCC_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtlogindetails = DAL.fnloginemail(cmbUserCC.Text).Tables[0];
            if (dtlogindetails.Rows.Count > 0)
            {
                if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()) && !lstAddUser.Items.Contains(dtlogindetails.Rows[0]["emailid"].ToString()))
                {
                    lstAddUser.Items.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                }
            }
        }
        private void chkReAssign_CheckedChanged(object sender, EventArgs e)
        {
            if (chkReAssign.CheckState == CheckState.Checked)
            {
                pnReassign.Enabled = true;
                //  btnNext.Enabled = false;
                btnReassign.Enabled = true;

            }
            else
            {
                pnReassign.Enabled = false;
                //  btnNext.Enabled = true;
                btnReassign.Enabled = false;
            }
        }

        private void btnCorrectionSave_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(sNCNumberfn))
            {
                if (!string.IsNullOrEmpty(txtCorrectionRequested.Text) && cmbDisposition.SelectedIndex >= 0 && bPDC1Date)
                {
                    GlobalClass.iSuccess = DAL.fnAddNCSecondTab(15, sNCNumberfn, cmbDisposition.Text, dtpPDC1.Text, txtCorrectionRequested.Text, txtRootCause.Text, dtpPDC2.Text, txtCorrectiveAction.Text, 00, null, null, "");
                    bPDC1Date = false;
                    bPDC2Date = false;
                    btnSave.Enabled = false;
                    if (chkCorrectionEdit.CheckState == CheckState.Unchecked)
                    {
                        MessageBox.Show("NC '" + sNCNumberfn + "' correction/action required saved.\n Mail sent to '" + txtRequesterName.Text + "' for review", "Success", 0, MessageBoxIcon.Information);

                        string sMessage = "<font face=Calibri> Dear " + txtRequesterName.Text.ToUpper() + ", <br />  Correction has been updated.<br /> Please review the correction. <br /> <br /> <b>  Regards,<br /> " + Login.GetUserDetails[2] + " </b> <br /> <br /><br /> <br /><br /><br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
                        dtUserEmail = DAL.fnUserList(txtRequesterName.Text, 1).Tables[0];
                        CreateEMail(sNCNumberfn, dtUserEmail.Rows[0]["emailid"].ToString(), lstAddUser, sMessage);
                    }
                    else
                    {
                        MessageBox.Show("NC '" + sNCNumberfn + "' correction/action required updated.\n Mail sent to '" + cmbAssignedTo.Text + "' for review", "Success", 0, MessageBoxIcon.Information);

                        string sMessage = "<font face=Calibri> Dear " + txtRequesterName.Text.ToUpper() + ", <br />  Correction has been updated.<br /> Please review the correction. <br /> <br /> <b>  Regards,<br /> " + Login.GetUserDetails[2] + " </b> <br /> <br /><br /> <br /><br /><br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
                        dtUserEmail = DAL.fnUserList(txtRequesterName.Text, 1).Tables[0];
                        CreateEMail(sNCNumberfn, dtUserEmail.Rows[0]["emailid"].ToString(), lstAddUser, sMessage);
                    }
                    btnCorrectionSave.Enabled = false;
                    fnNCNumberRecieved(sNCNumberfn);
                    // FormReload();
                }
                else
                {
                    if (cmbDisposition.SelectedIndex < 0)
                    {
                        MessageBox.Show("Please select disposition.", "Error", 0, MessageBoxIcon.Error);
                        cmbAssignedTo.Focus();
                    }
                    else if (!bPDC1Date)
                    {
                        MessageBox.Show("Please select the probable date of completion.", "Error", 0, MessageBoxIcon.Error);
                        dtpPDC1.Focus();
                    }
                    else if (string.IsNullOrEmpty(txtCorrectionRequested.Text))
                    {
                        MessageBox.Show("Please write the correction/action required.", "Error", 0, MessageBoxIcon.Error);
                        cmbProjectcode.Focus();
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select NC Number to update", "Error", 0, MessageBoxIcon.Error);

            }
        }

        private void btnRootCauseSave_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(sNCNumberfn))
            {
                if (!string.IsNullOrEmpty(txtRootCause.Text) && !string.IsNullOrEmpty(txtCorrectiveAction.Text) && bPDC2Date)
                {
                    GlobalClass.iSuccess = DAL.fnAddNCSecondTab(16, sNCNumberfn, cmbDisposition.Text, dtpPDC1.Text, txtCorrectionRequested.Text, txtRootCause.Text, dtpPDC2.Text, txtCorrectiveAction.Text, 0, null, null, "");
                    bPDC1Date = false;
                    bPDC2Date = false;
                    if (chkEditRootCause.CheckState == CheckState.Unchecked)
                    {
                        MessageBox.Show("NC '" + sNCNumberfn + "' root cause saved.\n Mail sent to '" + txtRequesterName.Text + "' for review", "Success", 0, MessageBoxIcon.Information);

                        //  string sMessage = "<font face=Calibri> Dear " + txtRequesterName.Text.ToUpper() + ", <br />  Correction has been updated.<br /> Please review the correction. <br /> <br /> <b>  Regards,<br /> " + Login.GetUserDetails[2] + " </b> <br /> <br /><br /> <br /><br /><br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
                        string sMessage = "<font face=Calibri> Dear " + txtRequesterName.Text.ToUpper() + ", <br /> Root cause & Corrective action has been updated.<br /> Please review the same. <br /> <br /> <b>  Regards,<br /> " + Login.GetUserDetails[2] + " </b> <br /> <br /><br /> <br /><br /><br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
                        dtUserEmail = DAL.fnUserList(txtRequesterName.Text, 1).Tables[0];
                        CreateEMail(sNCNumberfn, dtUserEmail.Rows[0]["emailid"].ToString(), lstAddUser, sMessage);
                    }
                    else
                    {
                        MessageBox.Show("NC '" + sNCNumberfn + "' root cause updated.\n Mail sent to '" + cmbAssignedTo.Text + "' for review", "Success", 0, MessageBoxIcon.Information);

                        string sMessage = "<font face=Calibri> Dear " + txtRequesterName.Text.ToUpper() + ", <br /> Root cause & Corrective action has been updated.<br /> Please review the same. <br /> <br /> <b>  Regards,<br /> " + Login.GetUserDetails[2] + " </b> <br /> <br /><br /> <br /><br /><br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
                        dtUserEmail = DAL.fnUserList(txtRequesterName.Text, 1).Tables[0];
                        CreateEMail(sNCNumberfn, dtUserEmail.Rows[0]["emailid"].ToString(), lstAddUser, sMessage);
                    }
                    btnRootCauseSave.Enabled = false;
                    fnNCNumberRecieved(sNCNumberfn);
                    //  FormReload();
                }
                else
                {

                    if (string.IsNullOrEmpty(txtRootCause.Text))
                    {
                        MessageBox.Show("Please write the root cause.", "Error", 0, MessageBoxIcon.Error);
                        cmbEnvironMent.Focus();
                    }
                    else if (!bPDC2Date)
                    {
                        MessageBox.Show("Please select the probable date of completion.", "Error", 0, MessageBoxIcon.Error);
                        dtpPDC2.Focus();
                    }

                    else if (string.IsNullOrEmpty(txtCorrectiveAction.Text))
                    {
                        MessageBox.Show("Please write the corrective action.", "Error", 0, MessageBoxIcon.Error);
                        cmbEnvironMent.Focus();
                    }
                    else if (string.IsNullOrEmpty(txtCostincurred.Text))
                    {
                        MessageBox.Show("Please enter the cost incurred.", "Error", 0, MessageBoxIcon.Error);
                        txtCostincurred.Focus();
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select NC Number to update", "Error", 0, MessageBoxIcon.Error);

            }
        }

        // -----------------------------------------------------------
        private void viewncbtn_Click(object sender, EventArgs e)
        {
            //dtmeeting =DAL.fnEscalationNCNumber(5, NCnumcmbbox.Text,"").Tables[0];
            dtmeeting = DAL.fnEscalationNCReport(2, NCnumcmbbox.Text, "").Tables[0];
            dtnc = DAL.fnEscalationNCNumber(3, NCnumcmbbox.Text, "").Tables[0];

            fnPrintNCReport();
        }
        private void btnconsolexcel_Click(object sender, EventArgs e)
        {
            string frmdate = DateTime.ParseExact(dtpexcelfromdate.Text, "dd/MM/yyyy", null).ToString("yyyy-MM-dd");
            string todate = DateTime.ParseExact(dtpexceltodate.Text, "dd/MM/yyyy", null).ToString("yyyy-MM-dd");

            fnprintconsolidatedNCReport(frmdate, todate);
        }
        private void fnPrintNCReport()
        {
            try
            {
                int iRowIndex = 1;
                string ExcelFolderName;
                string ExcelFolderPath;
                string FileFullPath;
                EXCEL.Workbook NewWorkBook;
                EXCEL.Worksheet NewWorkSheet;
                EXCEL.Application ExcelApp;
                EXCEL.Range CELLS, cell1, cell2;
                {
                    object misValue;
                    ExcelFolderName = "\\Escalation Report";
                    ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + ExcelFolderName + "\\";
                    FileFullPath = ExcelFolderPath + NCnumcmbbox.Text + "_" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + ".xlsx";
                    string[] Text ={"",
                                Global.sCompanyName,
                                "NO.497E,4TH PHASE PEENYA INDUSTRIAL AREA ",
                                "BANGALORE-560 058",
                                "Phone:91(080) 28360184. FAX: (080) 28360047.",
                                "Web: http://www.biss.in, Email: sales@biss.in",
                                "Escalation Report"};

                    string[] Text1 = {   "Remarks/Comment:",
                                         "",
                                         "",
                                         "",
                                         "",
                                         "",
                                         "" };
                    if (!Directory.Exists(ExcelFolderPath))
                        Directory.CreateDirectory(ExcelFolderPath);

                    ExcelApp = new EXCEL.Application();
                    misValue = System.Reflection.Missing.Value;
                    try
                    {
                        if (ExcelApp == null)
                            MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                        NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                        NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                        if (NewWorkSheet == null)
                            MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                        else
                            NewWorkSheet.Name = "Escalation Report";
                        EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                        if (RANGE == null)
                            MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                        NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        CELLS = NewWorkSheet.Cells;
                        NewWorkSheet.PageSetup.PrintGridlines = false;
                        NewWorkSheet.Range["B1:I1"].Cells.Font.Size = 16;
                        NewWorkSheet.Range["B1:I1"].Cells.Font.Bold = 16;
                        iRowIndex++;
                        foreach (string str in Text)
                        {
                            NewWorkSheet.Cells[iRowIndex, 2] = str;
                            if (iRowIndex < 8)
                            {
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 2, 9);
                            }
                            iRowIndex++;
                        }
                        CellMerge("Merge", NewWorkSheet, 8, 8, 2, 12);
                        CellMerge("ThinBorder", NewWorkSheet, 2, 7, 2, 12);
                        CellMerge("ThinBorder", NewWorkSheet, 8, 8, 2, 12);
                        CellMerge("ThinBorder", NewWorkSheet, 9, 9, 2, 3);
                        CellMerge("ThinBorder", NewWorkSheet, 10, 10, 2, 3);
                        CellMerge("ThinBorder", NewWorkSheet, 11, 11, 2, 3);
                        CellMerge("ThinBorder", NewWorkSheet, 12, 12, 2, 3);
                        CellMerge("ThinBorder", NewWorkSheet, 13, 13, 2, 3);

                        CellMerge("ThinBorder", NewWorkSheet, 9, 9, 4, 6);
                        CellMerge("ThinBorder", NewWorkSheet, 10, 10, 4, 6);
                        CellMerge("ThinBorder", NewWorkSheet, 11, 11, 4, 6);
                        CellMerge("ThinBorder", NewWorkSheet, 12, 12, 4, 6);
                        CellMerge("ThinBorder", NewWorkSheet, 13, 13, 4, 6);

                        CellMerge("ThinBorder", NewWorkSheet, 9, 9, 7, 9);
                        CellMerge("ThinBorder", NewWorkSheet, 10, 10, 7, 9);
                        CellMerge("ThinBorder", NewWorkSheet, 11, 11, 7, 9);
                        CellMerge("ThinBorder", NewWorkSheet, 12, 12, 7, 9);
                        CellMerge("ThinBorder", NewWorkSheet, 13, 13, 7, 9);

                        CellMerge("ThinBorder", NewWorkSheet, 9, 9, 10, 12);
                        CellMerge("ThinBorder", NewWorkSheet, 10, 10, 10, 12);
                        CellMerge("ThinBorder", NewWorkSheet, 11, 11, 10, 12);
                        CellMerge("ThinBorder", NewWorkSheet, 12, 12, 10, 12);
                        CellMerge("ThinBorder", NewWorkSheet, 13, 13, 10, 12);

                        CellMerge("Merge", NewWorkSheet, 9, 9, 2, 3);
                        CellMerge("Merge", NewWorkSheet, 10, 10, 2, 3);
                        CellMerge("Merge", NewWorkSheet, 11, 11, 2, 3);
                        CellMerge("Merge", NewWorkSheet, 12, 12, 2, 3);
                        CellMerge("Merge", NewWorkSheet, 13, 13, 2, 3);

                        CellMerge("Merge", NewWorkSheet, 9, 9, 4, 6);
                        CellMerge("Merge", NewWorkSheet, 10, 10, 4, 6);
                        CellMerge("Merge", NewWorkSheet, 11, 11, 4, 6);
                        CellMerge("Merge", NewWorkSheet, 12, 12, 4, 6);
                        CellMerge("Merge", NewWorkSheet, 13, 13, 4, 6);

                        CellMerge("Merge", NewWorkSheet, 9, 9, 7, 9);
                        CellMerge("Merge", NewWorkSheet, 10, 10, 7, 9);
                        CellMerge("Merge", NewWorkSheet, 11, 11, 7, 9);
                        CellMerge("Merge", NewWorkSheet, 12, 12, 7, 9);
                        CellMerge("Merge", NewWorkSheet, 13, 13, 7, 9);

                        CellMerge("Merge", NewWorkSheet, 9, 9, 10, 12);
                        CellMerge("Merge", NewWorkSheet, 10, 10, 10, 12);
                        CellMerge("Merge", NewWorkSheet, 11, 11, 10, 12);
                        CellMerge("Merge", NewWorkSheet, 12, 12, 10, 12);
                        CellMerge("Merge", NewWorkSheet, 13, 13, 10, 12);

                        CellMerge("Bold", NewWorkSheet, 9, 13, 2, 3);
                        CellMerge("Bold", NewWorkSheet, 9, 13, 7, 9);
                        CellMerge("Bold", NewWorkSheet, 14, 14, 2, 12);
                        CellMerge("Bold", NewWorkSheet, 15, 15, 2, 3);
                        CellMerge("Bold", NewWorkSheet, 20, 20, 2, 3);
                        CellMerge("Bold", NewWorkSheet, 20, 20, 7, 9);
                        CellMerge("AlignCenter", NewWorkSheet, 14, 14, 2, 12);

                        NewWorkSheet.Cells[9, 2] = "Isse No :";
                        NewWorkSheet.Cells[9, 4] = dtnc.Rows[0]["NCNumber"].ToString();
                        NewWorkSheet.Cells[10, 2] = "Customer Name :";
                        NewWorkSheet.Cells[10, 4] = dtnc.Rows[0]["Customer"].ToString();
                        NewWorkSheet.Cells[11, 2] = "Project Description :";
                        NewWorkSheet.Cells[11, 4] = dtnc.Rows[0]["ProjectDescription"].ToString();
                        NewWorkSheet.Cells[12, 2] = "Project Code :";
                        NewWorkSheet.Cells[12, 4] = dtnc.Rows[0]["ProjectCode"].ToString();
                        NewWorkSheet.Cells[13, 2] = "Product Line :";
                        NewWorkSheet.Cells[13, 4] = dtnc.Rows[0]["ProductLine"].ToString();
                        NewWorkSheet.Cells[9, 7] = "Problem Report During:";
                        NewWorkSheet.Cells[9, 10] = "";
                        NewWorkSheet.Cells[10, 7] = "Site Location :";
                        NewWorkSheet.Cells[10, 10] = dtnc.Rows[0]["Location"].ToString();
                        NewWorkSheet.Cells[11, 7] = "Issue Report Date:";
                        NewWorkSheet.Cells[11, 10] = dtnc.Rows[0]["NCDate"].ToString();
                        NewWorkSheet.Cells[12, 7] = "COE Site:";
                        NewWorkSheet.Cells[12, 10] = dtnc.Rows[0]["COESite"].ToString();
                        NewWorkSheet.Cells[13, 7] = "Sales Territory:";
                        NewWorkSheet.Cells[13, 10] = dtnc.Rows[0]["SalesTerritory"].ToString();

                        NewWorkSheet.Cells[14, 2].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Silver);
                        NewWorkSheet.Cells[14, 2].Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Red);
                        CellMerge("Merge", NewWorkSheet, 14, 14, 2, 12);
                        CellMerge("ThinBorder", NewWorkSheet, 14, 14, 2, 12);
                        ((Microsoft.Office.Interop.Excel.Range)NewWorkSheet.Rows[14, Type.Missing]).Font.Size = 14;
                        NewWorkSheet.Cells[14, 2] = "Summary of Reported Problem";

                        CellMerge("Merge", NewWorkSheet, 15, 15, 2, 3);
                        CellMerge("ThinBorder", NewWorkSheet, 15, 15, 2, 3);
                        NewWorkSheet.Cells[15, 2] = "Product:";
                        CellMerge("Merge", NewWorkSheet, 15, 15, 4, 12);
                        CellMerge("ThinBorder", NewWorkSheet, 15, 15, 4, 12);
                        NewWorkSheet.Cells[15, 4] = dtnc.Rows[0]["Product"].ToString();

                        CellMerge("Merge", NewWorkSheet, 16, 16, 2, 12);
                        CellMerge("ThinBorder", NewWorkSheet, 16, 16, 2, 12);
                        CellMerge("AlignTop", NewWorkSheet, 16, 16, 2, 12);
                        NewWorkSheet.Cells[16, 2] = dtnc.Rows[0]["Description"].ToString();
                        NewWorkSheet.Cells[16, 2].WrapText = true;

                        CellMerge("Merge", NewWorkSheet, 16, 19, 2, 12);
                        CellMerge("GridLines", NewWorkSheet, 16, 19, 2, 12);

                        CellMerge("Merge", NewWorkSheet, 20, 20, 2, 3);
                        CellMerge("ThinBorder", NewWorkSheet, 20, 20, 2, 3);
                        NewWorkSheet.Cells[20, 2] = "Reported By :";

                        CellMerge("Merge", NewWorkSheet, 20, 20, 4, 6);
                        CellMerge("ThinBorder", NewWorkSheet, 20, 20, 4, 6);
                        NewWorkSheet.Cells[20, 4] = dtnc.Rows[0]["RequestBy"].ToString();

                        CellMerge("Merge", NewWorkSheet, 20, 20, 7, 9);
                        CellMerge("ThinBorder", NewWorkSheet, 20, 20, 7, 9);
                        NewWorkSheet.Cells[20, 7] = "Date :";

                        CellMerge("Merge", NewWorkSheet, 20, 20, 10, 12);
                        CellMerge("ThinBorder", NewWorkSheet, 20, 20, 10, 12);
                        NewWorkSheet.Cells[20, 10] = dtnc.Rows[0]["NCDate"].ToString();
                        int i = 1;
                        int iRowIndex2 = 20;

                        for (int r = 0; r < dtmeeting.Rows.Count; r++)
                        {
                            if (r == 0)
                            {
                                NewWorkSheet.Cells[iRowIndex2 + 1, 2].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Silver);
                                NewWorkSheet.Cells[iRowIndex2 + 1, 2].Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Red);
                                CellMerge("Bold", NewWorkSheet, iRowIndex2 + 19, iRowIndex2 + 19, 2, 4);
                                CellMerge("Bold", NewWorkSheet, iRowIndex2 + 2, iRowIndex2 + 6, 2, 4);
                                CellMerge("Bold", NewWorkSheet, iRowIndex2 + 13, iRowIndex2 + 13, 2, 4);
                                CellMerge("Bold", NewWorkSheet, iRowIndex2 + 1, iRowIndex2 + 1, 2, 12);
                                CellMerge("AlignCenter", NewWorkSheet, iRowIndex2 + 1, iRowIndex2 + 1, 2, 12);
                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 1, iRowIndex2 + 1, 2, 12);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 1, iRowIndex2 + 1, 2, 12);
                                ((Microsoft.Office.Interop.Excel.Range)NewWorkSheet.Rows[iRowIndex2 + 1, Type.Missing]).Font.Size = 14;
                                NewWorkSheet.Cells[iRowIndex2 + 1, 2] = "Review Meeting -'" + i + "' ";

                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 2, iRowIndex2 + 2, 2, 4);
                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 2, iRowIndex2 + 2, 5, 12);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 2, iRowIndex2 + 2, 2, 4);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 2, iRowIndex2 + 2, 5, 12);
                                NewWorkSheet.Cells[iRowIndex2 + 2, 2] = "QSR/ESC Owner :";
                                NewWorkSheet.Cells[iRowIndex2 + 2, 5] = dtnc.Rows[0]["QsrEscOwner"].ToString();

                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 3, iRowIndex2 + 3, 2, 4);
                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 3, iRowIndex2 + 3, 5, 12);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 3, iRowIndex2 + 3, 2, 4);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 3, iRowIndex2 + 3, 5, 12);
                                NewWorkSheet.Cells[iRowIndex2 + 3, 2] = "Assigned Esc Level :";
                                NewWorkSheet.Cells[iRowIndex2 + 3, 5] = dtmeeting.Rows[r]["EscalationLavel"].ToString();

                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 4, iRowIndex2 + 4, 2, 4);
                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 4, iRowIndex2 + 4, 5, 12);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 4, iRowIndex2 + 4, 2, 4);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 4, iRowIndex2 + 4, 5, 12);
                                NewWorkSheet.Cells[iRowIndex2 + 4, 2] = "Assigned Problem Owner :";
                                NewWorkSheet.Cells[iRowIndex2 + 4, 5] = dtnc.Rows[0]["AssignedTo"].ToString();

                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 5, iRowIndex2 + 5, 2, 4);
                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 5, iRowIndex2 + 5, 5, 12);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 5, iRowIndex2 + 5, 2, 4);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 5, iRowIndex2 + 5, 5, 12);
                                NewWorkSheet.Cells[iRowIndex2 + 5, 2] = "Review Team :";
                                NewWorkSheet.Cells[iRowIndex2 + 5, 5] = dtmeeting.Rows[r]["ReviewTeam"].ToString();// drrm["ReviewTeam"].ToString();

                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 6, iRowIndex2 + 6, 2, 12);
                                // CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 6, iRowIndex2 + 6, 2, 12);
                                NewWorkSheet.Cells[iRowIndex2 + 6, 2] = "Minutes :";

                                NewWorkSheet.Cells[iRowIndex2 + 7, 2].WrapText = true;
                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 7, iRowIndex2 + 12, 2, 12);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 6, iRowIndex2 + 12, 2, 12);
                                CellMerge("AlignTop", NewWorkSheet, iRowIndex2 + 6, iRowIndex2 + 12, 2, 12);
                                NewWorkSheet.Cells[iRowIndex2 + 7, 2] = dtmeeting.Rows[r]["MOM"].ToString();// drrm["MOM"].ToString();

                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 13, iRowIndex2 + 13, 2, 12);
                                //CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 13, iRowIndex2 + 13, 2, 12);
                                NewWorkSheet.Cells[iRowIndex2 + 13, 2] = "Action Plan :";

                                NewWorkSheet.Cells[iRowIndex2 + 14, 2].WrapText = true;
                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 14, iRowIndex2 + 18, 2, 12);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 13, iRowIndex2 + 18, 2, 12);
                                CellMerge("AlignTop", NewWorkSheet, iRowIndex2 + 13, iRowIndex2 + 18, 2, 12);
                                NewWorkSheet.Cells[iRowIndex2 + 14, 2] = dtmeeting.Rows[r]["ActionPlan"].ToString();//drrm["ActionPlan"].ToString();
                                fnDateFormat(NewWorkSheet, iRowIndex2 + 19, 5);
                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 19, iRowIndex2 + 19, 2, 4);
                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 19, iRowIndex2 + 19, 5, 12);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 19, iRowIndex2 + 19, 2, 4);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 19, iRowIndex2 + 19, 5, 12);
                                NewWorkSheet.Cells[iRowIndex2 + 19, 5].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                                NewWorkSheet.Cells[iRowIndex2 + 19, 2] = "Estimated Date of Resolution : ";
                                NewWorkSheet.Cells[iRowIndex2 + 19, 5] = dtmeeting.Rows[r]["ResolutionDate"].ToString();//drrm["ResolutionDate"].ToString();
                                iRowIndex2 = iRowIndex2 + 19;
                                i++;
                            }
                            else
                            {
                                NewWorkSheet.Cells[iRowIndex2 + 1, 2].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Silver);
                                NewWorkSheet.Cells[iRowIndex2 + 1, 2].Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Red);
                                CellMerge("Bold", NewWorkSheet, iRowIndex2 + 19, iRowIndex2 + 19, 2, 4);
                                CellMerge("Bold", NewWorkSheet, iRowIndex2 + 2, iRowIndex2 + 6, 2, 4);
                                CellMerge("Bold", NewWorkSheet, iRowIndex2 + 13, iRowIndex2 + 13, 2, 4);
                                CellMerge("Bold", NewWorkSheet, iRowIndex2 + 22, iRowIndex2 + 24, 2, 4);
                                CellMerge("Bold", NewWorkSheet, iRowIndex2 + 1, iRowIndex2 + 1, 2, 12);
                                CellMerge("AlignCenter", NewWorkSheet, iRowIndex2 + 1, iRowIndex2 + 1, 2, 12);
                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 1, iRowIndex2 + 1, 2, 12);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 1, iRowIndex2 + 1, 2, 12);
                                ((Microsoft.Office.Interop.Excel.Range)NewWorkSheet.Rows[iRowIndex2 + 1, Type.Missing]).Font.Size = 14;
                                NewWorkSheet.Cells[iRowIndex2 + 1, 2] = "Review Meeting -'" + i + "' ";

                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 2, iRowIndex2 + 2, 2, 4);
                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 2, iRowIndex2 + 2, 5, 12);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 2, iRowIndex2 + 2, 2, 4);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 2, iRowIndex2 + 2, 5, 12);
                                NewWorkSheet.Cells[iRowIndex2 + 2, 2] = "NC Status :";
                                NewWorkSheet.Cells[iRowIndex2 + 2, 5] = "Open";

                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 3, iRowIndex2 + 3, 2, 4);
                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 3, iRowIndex2 + 3, 5, 12);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 3, iRowIndex2 + 3, 2, 4);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 3, iRowIndex2 + 3, 5, 12);
                                NewWorkSheet.Cells[iRowIndex2 + 3, 2] = "Current Escalation Level :";
                                NewWorkSheet.Cells[iRowIndex2 + 3, 5] = dtmeeting.Rows[r]["EscalationLavel"].ToString();


                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 4, iRowIndex2 + 4, 2, 4);
                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 4, iRowIndex2 + 4, 5, 12);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 4, iRowIndex2 + 4, 2, 4);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 4, iRowIndex2 + 4, 5, 12);
                                NewWorkSheet.Cells[iRowIndex2 + 4, 2] = "Escalation Level Change Date :";
                                if (!string.IsNullOrEmpty(dtmeeting.Rows[r]["changeDate"].ToString()))
                                {
                                    NewWorkSheet.Cells[iRowIndex2 + 4, 5] = Convert.ToDateTime(dtmeeting.Rows[r]["changeDate"]).ToString("dd-MM-yyyy");
                                }
                                else
                                {
                                    NewWorkSheet.Cells[iRowIndex2 + 4, 5] = "";

                                }
                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 5, iRowIndex2 + 5, 2, 4);
                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 5, iRowIndex2 + 5, 5, 12);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 5, iRowIndex2 + 5, 2, 4);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 5, iRowIndex2 + 5, 5, 12);
                                NewWorkSheet.Cells[iRowIndex2 + 5, 2] = "Review Team :";
                                NewWorkSheet.Cells[iRowIndex2 + 5, 5] = dtmeeting.Rows[r]["ReviewTeam"].ToString();

                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 6, iRowIndex2 + 6, 2, 12);
                                // CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 6, iRowIndex2 + 6, 2, 12);
                                NewWorkSheet.Cells[iRowIndex2 + 6, 2] = "Minutes :";

                                NewWorkSheet.Cells[iRowIndex2 + 7, 2].WrapText = true;
                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 7, iRowIndex2 + 12, 2, 12);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 6, iRowIndex2 + 12, 2, 12);
                                CellMerge("AlignTop", NewWorkSheet, iRowIndex2 + 6, iRowIndex2 + 12, 2, 12);
                                NewWorkSheet.Cells[iRowIndex2 + 7, 2] = dtmeeting.Rows[r]["MOM"].ToString();//drrm["MOM"].ToString();

                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 13, iRowIndex2 + 13, 2, 12);
                                //CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 13, iRowIndex2 + 13, 2, 12);
                                NewWorkSheet.Cells[iRowIndex2 + 13, 2] = "Action Plan :";

                                NewWorkSheet.Cells[iRowIndex2 + 14, 2].WrapText = true;
                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 14, iRowIndex2 + 18, 2, 12);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 13, iRowIndex2 + 18, 2, 12);
                                CellMerge("AlignTop", NewWorkSheet, iRowIndex2 + 13, iRowIndex2 + 18, 2, 12);
                                NewWorkSheet.Cells[iRowIndex2 + 14, 2] = dtmeeting.Rows[r]["ActionPlan"].ToString();//drrm["ActionPlan"].ToString();

                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 19, iRowIndex2 + 19, 2, 12);
                                NewWorkSheet.Cells[iRowIndex2 + 19, 2] = "Reason For Level Change :";
                                NewWorkSheet.Cells[iRowIndex2 + 20, 2].WrapText = true;
                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 20, iRowIndex2 + 21, 2, 12);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 19, iRowIndex2 + 21, 2, 12);
                                CellMerge("AlignTop", NewWorkSheet, iRowIndex2 + 20, iRowIndex2 + 21, 2, 12);
                                NewWorkSheet.Cells[iRowIndex2 + 20, 2] = dtmeeting.Rows[r]["changereason"].ToString();//drrm["ActionPlan"].ToString();

                                fnDateFormat(NewWorkSheet, iRowIndex2 + 22, 5);
                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 22, iRowIndex2 + 22, 2, 4);
                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 22, iRowIndex2 + 22, 5, 12);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 22, iRowIndex2 + 22, 2, 4);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 22, iRowIndex2 + 22, 5, 12);
                                NewWorkSheet.Cells[iRowIndex2 + 22, 5].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                                NewWorkSheet.Cells[iRowIndex2 + 22, 2] = "Estimated Date of Resolution : ";
                                NewWorkSheet.Cells[iRowIndex2 + 22, 5] = dtmeeting.Rows[r]["ResolutionDate"].ToString();//drrm["ResolutionDate"].ToString();

                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 23, iRowIndex2 + 23, 2, 4);
                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 23, iRowIndex2 + 23, 5, 12);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 23, iRowIndex2 + 23, 2, 4);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 23, iRowIndex2 + 23, 5, 12);
                                NewWorkSheet.Cells[iRowIndex2 + 23, 2] = "Any Change in Closure Date ? ";
                                NewWorkSheet.Cells[iRowIndex2 + 23, 5] = dtmeeting.Rows[r]["closure"].ToString();

                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 24, iRowIndex2 + 24, 2, 4);
                                CellMerge("Merge", NewWorkSheet, iRowIndex2 + 24, iRowIndex2 + 24, 5, 12);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 24, iRowIndex2 + 24, 2, 4);
                                CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 24, iRowIndex2 + 24, 5, 12);
                                NewWorkSheet.Cells[iRowIndex2 + 24, 2] = "New Closure Date ";
                                if (!string.IsNullOrEmpty(dtmeeting.Rows[r]["closureDate"].ToString()))
                                {
                                    NewWorkSheet.Cells[iRowIndex2 + 24, 5] = Convert.ToDateTime(dtmeeting.Rows[r]["closureDate"]).ToString("dd-MM-yyyy");
                                }
                                else
                                {
                                    NewWorkSheet.Cells[iRowIndex2 + 24, 5] = "";

                                }

                                iRowIndex2 = iRowIndex2 + 24;
                                i++;
                            }
                        }
                        NewWorkSheet.Cells[iRowIndex2 + 1, 2].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Silver);
                        NewWorkSheet.Cells[iRowIndex2 + 1, 2].Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Red);
                        CellMerge("Bold", NewWorkSheet, iRowIndex2 + 1, iRowIndex2 + 1, 2, 12);
                        CellMerge("Bold", NewWorkSheet, iRowIndex2 + 2, iRowIndex2 + 5, 2, 4);
                        CellMerge("AlignCenter", NewWorkSheet, iRowIndex2 + 1, iRowIndex2 + 1, 2, 12);
                        CellMerge("Merge", NewWorkSheet, iRowIndex2 + 1, iRowIndex2 + 1, 2, 12);
                        CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 1, iRowIndex2 + 1, 2, 12);
                        ((Microsoft.Office.Interop.Excel.Range)NewWorkSheet.Rows[iRowIndex2 + 1, Type.Missing]).Font.Size = 14;
                        NewWorkSheet.Cells[iRowIndex2 + 1, 2] = "Final Closure Details";
                        CellMerge("Merge", NewWorkSheet, iRowIndex2 + 2, iRowIndex2 + 2, 2, 4);
                        CellMerge("Merge", NewWorkSheet, iRowIndex2 + 2, iRowIndex2 + 2, 5, 12);
                        CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 2, iRowIndex2 + 2, 2, 4);
                        CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 2, iRowIndex2 + 2, 5, 12);
                        NewWorkSheet.Cells[iRowIndex2 + 2, 2] = "Problem Status :";
                        NewWorkSheet.Cells[iRowIndex2 + 2, 5] = dtnc.Rows[0]["NCClose"].ToString();

                        CellMerge("Merge", NewWorkSheet, iRowIndex2 + 3, iRowIndex2 + 3, 2, 4);
                        CellMerge("Merge", NewWorkSheet, iRowIndex2 + 3, iRowIndex2 + 3, 5, 12);
                        CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 3, iRowIndex2 + 3, 2, 4);
                        CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 3, iRowIndex2 + 3, 5, 12);
                        NewWorkSheet.Cells[iRowIndex2 + 3, 2] = "Closure Date :";
                        NewWorkSheet.Cells[iRowIndex2 + 3, 5] = dtnc.Rows[0]["NCCloseDate"].ToString();

                        CellMerge("Merge", NewWorkSheet, iRowIndex2 + 4, iRowIndex2 + 4, 2, 4);
                        CellMerge("Merge", NewWorkSheet, iRowIndex2 + 4, iRowIndex2 + 4, 5, 12);
                        CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 4, iRowIndex2 + 4, 2, 4);
                        CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 4, iRowIndex2 + 4, 5, 12);
                        NewWorkSheet.Cells[iRowIndex2 + 4, 2] = "RCA Analysis Required :";
                        NewWorkSheet.Cells[iRowIndex2 + 4, 5] = dtnc.Rows[0]["RCAReq"].ToString();

                        CellMerge("Merge", NewWorkSheet, iRowIndex2 + 5, iRowIndex2 + 5, 2, 12);
                        NewWorkSheet.Cells[iRowIndex2 + 5, 2] = "Closure Summary :";
                        CellMerge("Merge", NewWorkSheet, iRowIndex2 + 6, iRowIndex2 + 8, 2, 12);
                        CellMerge("ThinBorder", NewWorkSheet, iRowIndex2 + 5, iRowIndex2 + 8, 2, 12);
                        CellMerge("AlignTop", NewWorkSheet, iRowIndex2 + 6, iRowIndex2 + 8, 2, 12);
                        NewWorkSheet.Cells[iRowIndex2 + 6, 2] = dtnc.Rows[0]["ClosureDetails"].ToString();


                        CellMerge("AlignCenter", NewWorkSheet, 8, 8, 2, 12);
                        NewWorkSheet.Range["B2:I2"].Cells.Font.Size = 24;
                        NewWorkSheet.Range["B2:I2"].Cells.Font.Bold = true;
                        NewWorkSheet.Range["B8:L8"].Cells.Font.Size = 18;
                        NewWorkSheet.Range["B8:L8"].Cells.Font.Bold = true;
                        //NewWorkSheet.Range["B16:L19"].Cells.WrapText = true;
                        //NewWorkSheet.Range["B22:L23"].Cells.WrapText = true;
                        // NewWorkSheet.Range["B25:F29"].Cells.WrapText = true;
                        //NewWorkSheet.Range["B16:L19"].Cells.RowHeight = 45;
                        // NewWorkSheet.Range["B22:L23"].Cells.RowHeight = 45;                                        
                        //CellMerge("ThinBorder", NewWorkSheet, 31, 31, 10, 12);
                        NewWorkSheet.Rows.AutoFit();
                        NewWorkSheet.Columns.AutoFit();
                        NewWorkSheet.Columns[2].ColumnWidth = 10;
                        NewWorkSheet.Columns[4].ColumnWidth = 19;
                        NewWorkSheet.Columns[3].ColumnWidth = 10;
                        NewWorkSheet.Columns[5].ColumnWidth = 19;
                        NewWorkSheet.Columns[6].ColumnWidth = 19;
                        NewWorkSheet.Columns[9].ColumnWidth = 7;
                        NewWorkSheet.Columns[12].ColumnWidth = 13;
                        //NewWorkSheet.get_Range("A9", "R9999").Cells.Font.Size = 13;
                        NewWorkSheet.get_Range("A1", "R9999").Cells.Font.Name = "Calibri";
                        NewWorkSheet.get_Range("A1", "R9999").Cells.RowHeight = 18;
                        NewWorkSheet.get_Range("A1", "L1").Cells.RowHeight = 4;
                        NewWorkSheet.get_Range("A2", "L2").Cells.RowHeight = 44;
                        //------------------------------------------------------------------------------------------
                        // NewWorkSheet.get_Range("A22", "L22").Cells.RowHeight = 80;
                        //NewWorkSheet.get_Range("A16", "L16").Cells.RowHeight = 0;
                        //NewWorkSheet.get_Range("A23", "L23").Cells.RowHeight = 0;
                        //-------------------------------------------------------------------------
                        NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                        NewWorkSheet.PageSetup.PrintNotes = true;
                        NewWorkSheet.PageSetup.Zoom = 100;
                        NewWorkSheet.PageSetup.Zoom = false;
                        NewWorkSheet.PageSetup.FitToPagesTall = 1;
                        NewWorkSheet.PageSetup.FitToPagesWide = 1;
                        NewWorkSheet.PageSetup.LeftMargin = 0;
                        NewWorkSheet.PageSetup.RightMargin = 0;
                        NewWorkSheet.PageSetup.TopMargin = 0.75;
                        NewWorkSheet.PageSetup.BottomMargin = 0.75;
                        NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                        NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
                        EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 10];
                        Image oImage = Image.FromFile(Global.sLogo);
                        System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                        NewWorkSheet.Paste(oRange, Global.sLogo);
                        EXCEL.Range oRange1 = (EXCEL.Range)NewWorkSheet.Cells[2, 2];
                        Image oImage1 = Image.FromFile(Global.sITWLogo);
                        System.Windows.Forms.Clipboard.SetDataObject(oImage1, true);
                        NewWorkSheet.Paste(oRange1, Global.sITWLogo);
                        NewWorkBook.Save();
                        ExcelApp.Visible = true;
                        System.Threading.Thread.Sleep(1000);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                        foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                        {
                            GetProcess.Kill();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("PurchaseOrder_btnReport_Click  " + ex.Message);
            }
        }

        private void fnprintconsolidatedNCReport(string dtpexcelfromdate, string dtpexceltodate)
        {

            DataTable ConsolidatedNCReport = new DataTable();
            List<string> listSupplierName = new List<string>();
            ConsolidatedNCReport = DAL.fnEscalationNCReport(0, dtpexcelfromdate, dtpexceltodate).Tables[0];
            if (ConsolidatedNCReport.Rows.Count > 0)
            {
                string ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\Consolidated NC Report\\";
                string FileFullPath = ExcelFolderPath + "Consolidated NC Report " + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);

                DataTable dtSelectedGIN = new DataTable();
                DataTable dtGINPODetails = new DataTable();
                string finalColLetter = string.Empty;
                DataTable dtGINReport = new DataTable();
                dtGINReport = DAL.fnEscalationNCReport(0, dtpexcelfromdate, dtpexceltodate).Tables[0];
                if (dtGINReport.Rows.Count > 0)
                {
                    List<string> listPO = new List<string>();
                    foreach (DataRow dr1 in dtGINReport.Rows)
                    {
                        if (!listPO.Contains(dr1["NCNumber"].ToString()))
                        {
                            listPO.Add(dr1["NCNumber"].ToString());
                        }
                    }
                    if (listPO.Count > 0)
                    {
                        foreach (string dr2 in listPO)
                        {
                            dtGINPODetails = DAL.fnEscalationNCReport(1, dr2.ToString(), "").Tables[0];
                            if (dtGINPODetails.Rows.Count > 0)
                            {
                                DataRow dr1 = dtGINPODetails.Rows[0];
                                DataTable dtPack = new DataTable();
                                dtPack = DAL.fnEscalationNCReport(2, dr2.ToString(), "").Tables[0];
                                var k = dtPack.Rows.Count;
                                if (dtPack.Rows.Count > 0)
                                {
                                    for (k = 0; k < dtPack.Rows.Count; k++)
                                    {
                                        if (!string.IsNullOrEmpty(dtPack.Rows[k]["NCNumber"].ToString()) && k == 0)
                                        {
                                            dr1["ReviewMeeeting-" + (k + 1) + ""] = dtPack.Rows[k]["MOM"].ToString();
                                            dr1["ActionPlan-" + (k + 1) + ""] = dtPack.Rows[k]["ActionPlan"].ToString();
                                            dr1["ReviewTeam-" + (k + 1) + ""] = dtPack.Rows[k]["ReviewTeam"].ToString();
                                            dr1["EscalationLevel-" + (k + 1) + ""] = dtPack.Rows[k]["EscalationLavel"].ToString();
                                            dr1["ResolutionDate-" + (k + 1) + ""] = dtPack.Rows[k]["ResolutionDate"].ToString();
                                        }
                                        if (!string.IsNullOrEmpty(dtPack.Rows[k]["NCNumber"].ToString()) && k != 0 && k < 4)
                                        {
                                            dr1["NC Status-" + (k + 1) + ""] = dtPack.Rows[k]["NCStatus"].ToString();
                                            dr1["ReviewMeetingDate-" + (k + 1) + ""] = (!string.IsNullOrEmpty(dtPack.Rows[k]["UserDate"].ToString())) ? Convert.ToDateTime(dtPack.Rows[k]["UserDate"]).ToString("dd-MM-yyyy") : "";
                                            //dr1["ReviewMeetingDate-"+(k+1)+""]= dtPack.Rows[k]["UserDate"].ToString();
                                            dr1["EscalationChangeReason-" + (k + 1) + ""] = dtPack.Rows[k]["changereason"].ToString();
                                            dr1["EscLevelChangeDate-" + (k + 1) + ""] = (!string.IsNullOrEmpty(dtPack.Rows[k]["changeDate"].ToString())) ? Convert.ToDateTime(dtPack.Rows[k]["changeDate"]).ToString("dd-MM-yyyy") : "";
                                            // dr1["EscLevelChangeDate-" + (k + 1) + ""] = dtPack.Rows[k]["changeDate"].ToString();
                                            dr1["ReviewMeeeting-" + (k + 1) + ""] = dtPack.Rows[k]["MOM"].ToString();
                                            dr1["ActionPlan-" + (k + 1) + ""] = dtPack.Rows[k]["ActionPlan"].ToString();
                                            dr1["ReviewTeam-" + (k + 1) + ""] = dtPack.Rows[k]["ReviewTeam"].ToString();
                                            dr1["EscalationLevel-" + (k + 1) + ""] = dtPack.Rows[k]["EscalationLavel"].ToString();
                                            dr1["ResolutionDate-" + (k + 1) + ""] = dtPack.Rows[k]["ResolutionDate"].ToString();
                                            dr1["Any Change in Closure Date-" + (k + 1) + ""] = dtPack.Rows[k]["closure"].ToString();
                                            dr1["New Closure Date-" + (k + 1) + ""] = (!string.IsNullOrEmpty(dtPack.Rows[k]["closureDate"].ToString())) ? Convert.ToDateTime(dtPack.Rows[k]["closureDate"]).ToString("dd-MM-yyyy") : "";
                                            // dr1["New Closure Date-" + (k + 1) + ""]= dtPack.Rows[k]["closureDate"].ToString();
                                        }

                                    }

                                }
                                dtSelectedGIN.Merge(dtGINPODetails);
                            }
                        }
                    }
                }
                DataSet ds = new DataSet("GIN");
                ds.Tables.Add(dtSelectedGIN);
                ExportToExcel(ds, FileFullPath, "NC");
            }
            else
            {
                MessageBox.Show("Selected date has no records to genarate report!");
            }
        }
        public void ExportToExcel(DataSet dataSet, string outputPath, string tablename)
        {

            EXCEL.Workbook NewWorkBook;
            EXCEL.Worksheet worksheet;
            EXCEL.Application excelApp;

            excelApp = new Microsoft.Office.Interop.Excel.Application();
            NewWorkBook = excelApp.Workbooks.Add(Type.Missing);
            worksheet = NewWorkBook.Sheets["Sheet1"];
            worksheet = NewWorkBook.ActiveSheet;
            worksheet.Name = tablename;
            int StockValue;

            foreach (System.Data.DataTable dt in dataSet.Tables)
            {

                // Copy the DataTable to an object array
                object[,] rawData = new object[dt.Rows.Count + 1, dt.Columns.Count];

                // Copy the column names to the first row of the object array
                for (int col = 0; col < dt.Columns.Count; col++)
                {
                    rawData[0, col] = dt.Columns[col].ColumnName;
                }
                // Copy the values to the object array
                for (int col = 0; col < dt.Columns.Count; col++)
                {
                    for (int row = 0; row < dt.Rows.Count; row++)
                    {
                        rawData[row + 1, col] = dt.Rows[row].ItemArray[col];
                    }
                }

                string finalColLetter = string.Empty;
                string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                int colCharsetLen = colCharset.Length;

                if (dt.Columns.Count > colCharsetLen)
                {
                    finalColLetter = colCharset.Substring((dt.Columns.Count - 1) / colCharsetLen - 1, 1);
                }
                finalColLetter += colCharset.Substring((dt.Columns.Count - 1) % colCharsetLen, 1);
                worksheet.Columns.AutoFit();
                worksheet.Rows.AutoFit();
                worksheet.Cells[1, 1] = Global.sCompanyName;
                worksheet.Range["A1:C1"].Cells.Font.Size = 14;
                worksheet.Range["A1:C1"].Cells.Font.Bold = 14;
                worksheet.get_Range("A1", "B1").Merge(true);
                string excelRange;
                worksheet.Rows.RowHeight = "18";
                switch (tablename)
                {
                    case "NC":
                        worksheet.Cells[2, 2] = "Escalation Report";
                        worksheet.Range["A2:C2"].Cells.Font.Size = 14;
                        worksheet.Range["A2:C2"].Cells.Font.Bold = 14;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[7, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[7, Type.Missing]).Font.Size = 12;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[7, Type.Missing]).Font.Color = Color.Red;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[6, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[6, Type.Missing]).Font.Size = 14;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[6, Type.Missing]).Font.Color = Color.Red;
                        excelRange = string.Format("A7:{0}{1}", finalColLetter, dt.Rows.Count + 7);
                        worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        fnDateFormatstring(worksheet, "W7", "W9999");
                        fnDateFormatstring(worksheet, "T7", "T9999");
                        worksheet.Columns.AutoFit();
                        worksheet.Columns.WrapText = true;
                        worksheet.Rows.AutoFit();
                        // worksheet.get_Range("A6", "R9999").HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        //worksheet.get_Range("D6", "E9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                        worksheet.Columns[2].ColumnWidth = 30;
                        worksheet.Columns[2].WrapText = true;
                        worksheet.Columns[4].ColumnWidth = 30;
                        worksheet.Columns[4].WrapText = true;
                        worksheet.Columns[6].ColumnWidth = 30;
                        worksheet.Columns[6].WrapText = true;
                        worksheet.Columns[17].ColumnWidth = 50;
                        worksheet.Columns[17].WrapText = true;
                        worksheet.Columns[19].ColumnWidth = 50;
                        worksheet.Columns[19].WrapText = true;
                        worksheet.Columns[25].ColumnWidth = 50;
                        worksheet.Columns[25].WrapText = true;
                        worksheet.Columns[28].ColumnWidth = 50;
                        worksheet.Columns[28].WrapText = true;
                        worksheet.Columns[36].ColumnWidth = 50;
                        worksheet.Columns[36].WrapText = true;
                        worksheet.Columns[39].ColumnWidth = 50;
                        worksheet.Columns[39].WrapText = true;
                        worksheet.Columns[47].ColumnWidth = 50;
                        worksheet.Columns[47].WrapText = true;
                        worksheet.Columns[50].ColumnWidth = 50;
                        worksheet.Columns[50].WrapText = true;

                        CellMerge("Merge", worksheet, 6, 6, 14, 20);
                        CellMerge("Merge", worksheet, 6, 6, 21, 31);
                        CellMerge("Merge", worksheet, 6, 6, 32, 42);
                        CellMerge("Merge", worksheet, 6, 6, 43, 53);
                        CellMerge("Merge", worksheet, 6, 6, 54, 57);
                        CellMerge("AlignCenter", worksheet, 6, 6, 14, 20);
                        CellMerge("AlignCenter", worksheet, 6, 6, 21, 31);
                        CellMerge("AlignCenter", worksheet, 6, 6, 32, 42);
                        CellMerge("AlignCenter", worksheet, 6, 6, 43, 53);
                        CellMerge("AlignCenter", worksheet, 6, 6, 54, 57);
                        worksheet.Cells[6, 14] = "Review Meeting-1";
                        worksheet.Cells[6, 21] = "Review Meeting-2";
                        worksheet.Cells[6, 32] = "Review Meeting-3";
                        worksheet.Cells[6, 43] = "Review Meeting-4";
                        worksheet.Cells[6, 54] = "Final Closure Details";
                        worksheet.Cells[6, 14].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightBlue);
                        worksheet.Cells[6, 21].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightGoldenrodYellow);
                        worksheet.Cells[6, 32].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Lavender);
                        worksheet.Cells[6, 43].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightCyan);
                        worksheet.Cells[6, 54].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightGreen);
                        //To add  background color to the cell
                        for (int i = 0; i <= dt.Rows.Count; i++)
                        {
                            for (int J = 14; J <= 20; J++)
                            {
                                worksheet.Cells[i + 7, J].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightBlue);
                            }
                            for (int a = 21; a <= 31; a++)
                            {
                                worksheet.Cells[i + 7, a].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightGoldenrodYellow);
                            }
                            for (int b = 32; b <= 42; b++)
                            {
                                worksheet.Cells[i + 7, b].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Lavender);
                            }
                            for (int c = 43; c <= 53; c++)
                            {
                                worksheet.Cells[i + 7, c].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightCyan);
                            }
                            for (int d = 54; d <= 57; d++)
                            {
                                worksheet.Cells[i + 7, d].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightGreen);
                            }
                        }
                        int L = dt.Rows.Count;
                        worksheet.get_Range("A6", "BE" + (L + 10) + "").Cells.Borders.Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
                        //fnDrawLogo(worksheet, 1, 10);
                        ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\Consolidated NC Report\\";
                        Process.Start(ExcelFolderPath);
                        break;
                }
            }
            NewWorkBook.SaveAs(outputPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                               Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive,
                               Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

            NewWorkBook.Save();
            NewWorkBook.Close(true, Type.Missing, Type.Missing);
            excelApp.Quit();
            releaseObject(worksheet);
            releaseObject(NewWorkBook);
            releaseObject(excelApp);
        }
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        public void fnDrawLogo(EXCEL.Worksheet worksheet, int column1, int column2)
        {
            Microsoft.Office.Interop.Excel.Range oRange = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[column1, column2];
            System.Drawing.Image oImage = System.Drawing.Image.FromFile(Global.sLogo);
            System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
            worksheet.Paste(oRange, Global.sLogo);
        }

        public void fnDateFormat(EXCEL.Worksheet worksheet, int column1, int column2)
        {
            Microsoft.Office.Interop.Excel.Range date = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[column1, column2];
            date.EntireColumn.NumberFormat = "DD/MM/YYYY";
        }
        public void fnDateFormatstring(EXCEL.Worksheet worksheet, string column1, string column2)
        {
            Microsoft.Office.Interop.Excel.Range date = worksheet.get_Range(column1, column2);
            date.EntireColumn.NumberFormat = "DD/MM/YYYY";
        }

        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlMedium, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignTop":
                    {
                        CELLS.VerticalAlignment = EXCEL.XlVAlign.xlVAlignTop;
                        break;
                    }
                case "ThinBorder":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        //   CELLS.Borders.Color.SetColor(Color.Red);  
                        break;
                    }

                case "GridLines":
                    {
                        CELLS.Borders.Color = System.Drawing.Color.Black;
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignCenter":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                        break;
                    }
                case "Bold":
                    {
                        CELLS.Font.Bold = true;
                        break;
                    }
                default:
                    {
                        break;
                    }
            }
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            reviewmeetpn.Visible = false;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm.Show();

        }

        private void btnProjectView_Click(object sender, EventArgs e)
        {
            Indent.frmProjectselect projectsearch = new Indent.frmProjectselect();
            projectsearch.fnEscNC = "1";
            projectsearch.ShowDialog();
            if (fnProjectcode != null)
            {
                cmbProjectcode.Text = sProjectCode;
            }
        }

        private void yesradio_CheckedChanged(object sender, EventArgs e)
        {
            panelclosedate.Visible = true;
        }

        private void Noradio_CheckedChanged(object sender, EventArgs e)
        {
            panelclosedate.Visible = false;
        }

        private void btnncclose_Click(object sender, EventArgs e)
        {

            RCApanel.Visible = true;

        }
        string result;
        private void btnok_Click(object sender, EventArgs e)
        {
            if (radioyes.Checked == true)
            {
                result = "Yes";
            }
            else
            {
                result = "No";
            }
            GlobalClass.iSuccess = DAL.fnAddNCSecondTab(17, sNCNumberfn, result, dtpCreatedDate.Text, txtclosuredatail.Text, " ", "", "", 0, null, null, "");
            if (GlobalClass.iSuccess > 0)
            {
                MessageBox.Show("NC closed Successfully", "Success", 0, MessageBoxIcon.Information);
                RCApanel.Visible = false;
            }

        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            RCApanel.Visible = false;
        }

        private void cmbPriority_SelectedIndexChanged(object sender, EventArgs e)
        {
            remcount.ResetText();
            dtncreminder = DAL.fnEscalationNCNumber(1, NCnumcmbbox.Text, cmbPriority.Text).Tables[0];
            if (dtncreminder.Rows.Count > 0)
            {
                if (Convert.ToInt32(dtncreminder.Rows[0][0]) > 3)
                {
                    remcount.Text = "0";
                }
                else
                {
                    remcount.Text = dtncreminder.Rows[0][0].ToString();
                }
            }
        }

        private void lstAddUser_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                if (lstAddUser.SelectedItem.ToString() != "Megha_V@instron.com" && lstAddUser.SelectedItem.ToString() != "Girish_HP@instron.com")
                {
                    lstAddUser.Items.Remove(lstAddUser.SelectedItem);
                }
            }
        }

        private void lstusers_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                lstusers.Items.Remove(lstusers.SelectedItem);
            }
        }

        private void btnViewEscalation_Click(object sender, EventArgs e)
        {
            Biss_NC.frmViewEscalation viewEscalation = new Biss_NC.frmViewEscalation();
            viewEscalation.ShowDialog();
        }
    }
}
