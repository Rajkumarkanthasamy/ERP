﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Outlook = Microsoft.Office.Interop.Outlook;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Diagnostics;

namespace Erp_Project_With_Buttons.Biss_NC
{
    public partial class frmUserNcDetails : Form
    {
        Login.frmLoginForm Login = new Login.frmLoginForm();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        DataTable dtUserReport = new DataTable();
        Biss_NC.frmRaiseNC NC = new Biss_NC.frmRaiseNC();
        DataTable dtUserEmail = new DataTable();
        public frmUserNcDetails()
        {
            InitializeComponent();
        }

        private void frmUserNcDetails_Load(object sender, EventArgs e)
        {
            dtUserReport = DAL.fnNCUserReport(1, Login.GetUserDetails[2].ToLower().ToString()).Tables[0];
            //fnLoad(dtUserReport);
            cmbAssignAction.SelectedIndex = 0;


        }

        private void fnLoad(DataTable dtDetails)
        {

            dgvUserDetails.DataSource = null;
            if (dtDetails.Rows.Count > 0)
            {
                dgvUserDetails.AutoGenerateColumns = false;

                dgvUserDetails.DataSource = dtDetails;
                Datagridviewcolor();
                //  foreach (DataGridViewColumn column in dgvUserDetails.Columns)
                //  {
                //   column.SortMode = DataGridViewColumnSortMode.NotSortable;
                //  }
            }
        }
        #region PO Item Color
        private void Datagridviewcolor()
        {
            int WhiteNC = 0, RedNC = 0, YellowNC = 0, GreenNC = 0;

            foreach (DataGridViewRow dgr in dgvUserDetails.Rows)
            {
                if (string.IsNullOrEmpty(dgr.Cells["Correction"].Value.ToString()))
                {
                    dgr.DefaultCellStyle.BackColor = Color.White;
                    WhiteNC++;
                }
                else if (!string.IsNullOrEmpty(dgr.Cells["Correction"].Value.ToString()) && dgr.Cells["CorrectionStatus"].Value.ToString() == "Open")
                {
                    dgr.DefaultCellStyle.BackColor = Color.Salmon;
                    RedNC++;
                }
                else if (!string.IsNullOrEmpty(dgr.Cells["Correction"].Value.ToString()) && dgr.Cells["CorrectionStatus"].Value.ToString() == "Closed" && dgr.Cells["CACorrectionStatus"].Value.ToString() == "Open")
                {
                    dgr.DefaultCellStyle.BackColor = Color.Khaki;
                    YellowNC++;
                }
                else if (dgr.Cells["CACorrectionStatus"].Value.ToString() == "Closed")
                {
                    dgr.DefaultCellStyle.BackColor = Color.GreenYellow;
                    GreenNC++;
                }

            }

            btnNewNC.Text = WhiteNC.ToString();
            btnCorrectionClosed.Text = RedNC.ToString();
            btnCANotClosed.Text = YellowNC.ToString();
            btnNCClosed.Text = GreenNC.ToString();
            btnTotal.Text = (WhiteNC + RedNC + YellowNC + GreenNC).ToString();
        }
        #endregion

        private void dgvUserDetails_DoubleClick(object sender, EventArgs e)
        {

            switch (cmbAssignAction.SelectedIndex)
            {
                case 0:
                case 5:
                    if (Login.GetUserDetails[2].ToLower() == "megha")
                    {
                        NC.fnNCNumber = string.Empty;
                        NC.fnNCNumber = dgvUserDetails.CurrentRow.Cells["NCNumber"].Value.ToString();
                        this.Close();
                    }
                    else
                    {
                        if (Login.GetUserDetails[2].ToLower() == dgvUserDetails.CurrentRow.Cells["Createdby"].Value.ToString().ToLower() && String.IsNullOrEmpty(dgvUserDetails.CurrentRow.Cells["Correction"].Value.ToString()))
                        {
                            NC.fnNCNumber = string.Empty;
                            NC.fnNCNumber = dgvUserDetails.CurrentRow.Cells["NCNumber"].Value.ToString();
                            this.Close();
                        }

                        else if (Login.GetUserDetails[2].ToLower() == dgvUserDetails.CurrentRow.Cells["AssignedTo"].Value.ToString().ToLower())
                        {
                            NC.fnNCNumber = string.Empty;
                            NC.fnNCNumber = dgvUserDetails.CurrentRow.Cells["NCNumber"].Value.ToString();
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("NC '" + dgvUserDetails.CurrentRow.Cells["NCNumber"].Value.ToString() + "' assigned to '" + dgvUserDetails.CurrentRow.Cells["AssignedTo"].Value.ToString() + "'. \n Only assigned person can open the NC.", "Warning", 0, MessageBoxIcon.Warning);
                        }
                    }
                    
                    break;
            }
        }

        private void dgvUserDetails_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            switch (cmbAssignAction.SelectedIndex)
            {
                case 1:
                    btnCloseCorrection.Text = "Close";
                    btnCloseCorrection.Visible = true;
                    pnNCOpen.Visible = false;
                    break;
                case 2:
                    btnCloseCorrection.Text = "Open";
                    btnCloseCorrection.Visible = true;
                    pnNCOpen.Visible = true;
                    break;
                case 3:
                    btnCloseCorrection.Text = "Close";
                    btnCloseCorrection.Visible = true;
                    pnNCOpen.Visible = false;
                    break;
                case 4:
                    btnCloseCorrection.Text = "Open";
                    btnCloseCorrection.Visible = true;
                    pnNCOpen.Visible = true;
                    break;
            }
        }

        private void btnCloseCorrection_Click(object sender, EventArgs e)
        {
            DialogResult DR;
            string NCNumber = dgvUserDetails.CurrentRow.Cells["NCNumber"].Value.ToString();
            switch (cmbAssignAction.SelectedIndex)
            {
                case 1:
                    DR = MessageBox.Show("Do you want to close the correction status of '" + NCNumber + "'? ", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (DR == DialogResult.Yes)
                    {
                        //if (!string.IsNullOrEmpty(txtObjectiveEvidenceFound.Text) && !string.IsNullOrEmpty(txtCostincurred.Text))
                        {
                            GlobalClass.iSuccess = DAL.fnAddNCSecondTab(7, NCNumber, "", "", "", "", "", "", 0, "", dtpClosedate.Text, "");

                            string sMessage = "<font face=Calibri> Dear " + dgvUserDetails.CurrentRow.Cells["Createdby"].Value.ToString().ToUpper() + ", <br /> Correction has been closed.<br /><br /> Please review the same.<br /> <br /><br /> <br /><br /><br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
                            dtUserEmail = DAL.fnUserList(dgvUserDetails.CurrentRow.Cells["Createdby"].Value.ToString(), 1).Tables[0];
                            CreateEMail(NCNumber, dtUserEmail.Rows[0]["emailid"].ToString(), "megha@biss.in", sMessage);
                            btnCloseCorrection.Visible = false;
                            MessageBox.Show("Correction status closed", "Success", 0, MessageBoxIcon.Information);
                        }
                    }
                    break;

                case 2:
                    DR = MessageBox.Show("Do you want to open the correction status of '" + NCNumber + "'? ", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (DR == DialogResult.Yes)
                    {
                        //if (!string.IsNullOrEmpty(txtObjectiveEvidenceFound.Text) && !string.IsNullOrEmpty(txtCostincurred.Text))
                        {
                            GlobalClass.iSuccess = DAL.fnAddNCSecondTab(8, NCNumber, "", "", "", "", "", "", 0, "", dtpClosedate.Text, "");

                            string sMessage = "<font face=Calibri> Dear " + dgvUserDetails.CurrentRow.Cells["AssignedTo"].Value.ToString().ToUpper() + ", <br /> Correction status has been re-opened for the following reasons.<br /><br />\"" + txtNCReViewReason.Text + "\".<br /><br /><b> Note: Please take appropriate correction & update the status.</b><br /> <br /><br /><br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
                            dtUserEmail = DAL.fnUserList(dgvUserDetails.CurrentRow.Cells["AssignedTo"].Value.ToString(), 1).Tables[0];
                            CreateEMail(NCNumber, dtUserEmail.Rows[0]["emailid"].ToString(), "megha@biss.in", sMessage);
                            btnCloseCorrection.Visible = false;
                            pnNCOpen.Visible = false;
                            MessageBox.Show("Correction status open", "Success", 0, MessageBoxIcon.Information);
                        }
                    }
                    break;

                case 3:
                    DR = MessageBox.Show("Do you want to close the corrective action status of '" + NCNumber + "'? ", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (DR == DialogResult.Yes)
                    {
                        //if (!string.IsNullOrEmpty(txtObjectiveEvidenceFound.Text) && !string.IsNullOrEmpty(txtCostincurred.Text))
                        {
                            GlobalClass.iSuccess = DAL.fnAddNCSecondTab(9, NCNumber, "", "", "", "", "", "", 0, "", dtpClosedate.Text, "");

                            string sMessage = "<font face=Calibri> Dear " + dgvUserDetails.CurrentRow.Cells["Createdby"].Value.ToString().ToUpper() + ", <br /> Corrective action has been closed.<br /><br /> Please review the same.<br /> <br /><br /> <br /><br /><br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
                            dtUserEmail = DAL.fnUserList(dgvUserDetails.CurrentRow.Cells["Createdby"].Value.ToString(), 1).Tables[0];
                            CreateEMail(NCNumber, dtUserEmail.Rows[0]["emailid"].ToString(), "megha@biss.in", sMessage);
                            btnCloseCorrection.Visible = false;
                            MessageBox.Show("Correction status closed", "Success", 0, MessageBoxIcon.Information);
                        }
                    }
                    break;

                case 4:
                    DR = MessageBox.Show("Do you want to open the corrective action status of '" + NCNumber + "'? ", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (DR == DialogResult.Yes)
                    {
                        //if (!string.IsNullOrEmpty(txtObjectiveEvidenceFound.Text) && !string.IsNullOrEmpty(txtCostincurred.Text))
                        {
                            GlobalClass.iSuccess = DAL.fnAddNCSecondTab(10, NCNumber, "", "", "", "", "", "", 0, "", dtpClosedate.Text, "");


                            string sMessage = "<font face=Calibri> Dear " + dgvUserDetails.CurrentRow.Cells["AssignedTo"].Value.ToString().ToUpper() + ", <br /> Corrective action status has been re-opened for the following reasons.<br /><br />\"" + txtNCReViewReason.Text + "\".<br /><br /><b> Note: Please take appropriate corrective action & update the status.</b><br /> <br /><br /><br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
                            dtUserEmail = DAL.fnUserList(dgvUserDetails.CurrentRow.Cells["AssignedTo"].Value.ToString(), 1).Tables[0];
                            CreateEMail(NCNumber, dtUserEmail.Rows[0]["emailid"].ToString(), "megha@biss.in", sMessage);
                            btnCloseCorrection.Visible = false;
                            pnNCOpen.Visible = false;
                            MessageBox.Show("Correction status open", "Success", 0, MessageBoxIcon.Information);
                        }
                    }
                    break;
            }
            cmbAssignAction_SelectedIndexChanged(sender, e);
        }

        private void CreateEMail(string sNCNumber, string sTo, string sCC, string sSubject)
        {
            try
            {
                Outlook.Application oApp = new Outlook.Application();
                Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                oMsg.Subject = "NC Number '" + sNCNumber + "'.";
                //  oMsg.iHTMLBody = true;
                oMsg.HTMLBody = sSubject;
                //@"<font face=Calibri> Dear Sir/Madam, <br /> I have raised a complaint on the following issue.
                //                 <br /> <br /> Priority : " + cmbEmergency.Text + " <br /> Building : " + cmbBuilding.Text + " <br /> Work location : " + txtWorkLocation.Text + " <br /> Type of work request : " + cmbTypeofRequest.Text + " <br /> Details of the issue : " + txtDetailsofWork.Text + " <br /> <br /> <br /> <br /> *** This is an automatically generated email, please do not reply *** </font>";

                // Add a recipient.
                Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                oRecips.Add(sTo);
                oRecips.ResolveAll();
                // Add cc
                if (!string.IsNullOrEmpty(sCC))
                {
                    Outlook.Recipient oRecip = (Outlook.Recipient)oRecips.Add(sCC);
                    oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                    oRecip.Resolve();
                    oMsg.Send();
                    oRecip = null;
                }
                // Send.
                // oMsg.Send();
                // Clean up.
                oRecips = null;
                oMsg = null;
                oApp = null;
            }
            catch (Exception ex)
            {

            }
        }
        private void fnCustomDate(int SwitchCustom)
        {
            switch (SwitchCustom)
            {
                case 0:
                    Cursor.Current = Cursors.WaitCursor;
                    dtpFromDate.Format = DateTimePickerFormat.Custom;
                    dtpFromDate.CustomFormat = "yyyy-MM-dd";
                    dptToDate.Format = DateTimePickerFormat.Custom;
                    dptToDate.CustomFormat = "yyyy-MM-dd";
                    break;
                case 1:
                    dtpFromDate.Format = DateTimePickerFormat.Custom;
                    dtpFromDate.CustomFormat = "dd-MM-yyyy";
                    dptToDate.Format = DateTimePickerFormat.Custom;
                    dptToDate.CustomFormat = "dd-MM-yyyy";
                    break;
            }
        }
        private void cmbAssignAction_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnNewNC.ResetText();
            btnCorrectionClosed.ResetText();
            btnCANotClosed.ResetText();
            btnNCClosed.ResetText();
            btnTotal.ResetText();
            btnSummaryEmail.Visible = false;
            btnCloseCorrection.Visible = false;
            cmbDepartment.Visible = false;
            pnGenaralPanel.Visible = false;
            switch (cmbAssignAction.SelectedIndex)
            {
                case 0:
                    fnCustomDate(0);
                    pnGenaralPanel.Visible = true;
                    dtUserReport = DAL.fnNCUserReport1(1, Login.GetUserDetails[2].ToLower().ToString(),dtpFromDate.Text, dptToDate.Text).Tables[0];
                    fnLoad(dtUserReport);
                    fnCustomDate(1);
                    break;
                case 1:
                    dtUserReport = DAL.fnNCUserReport(3, Login.GetUserDetails[2].ToLower().ToString()).Tables[0];
                    fnLoad(dtUserReport);
                    break;
                case 2:
                    dtUserReport = DAL.fnNCUserReport(4, Login.GetUserDetails[2].ToLower().ToString()).Tables[0];
                    fnLoad(dtUserReport);
                    break;
                case 3:
                    dtUserReport = DAL.fnNCUserReport(5, Login.GetUserDetails[2].ToLower().ToString()).Tables[0];
                    fnLoad(dtUserReport);
                    break;
                case 4:
                    dtUserReport = DAL.fnNCUserReport(6, Login.GetUserDetails[2].ToLower().ToString()).Tables[0];
                    fnLoad(dtUserReport);
                    break;
                case 5:
                    dtUserReport = DAL.fnNCUserReport(7, Login.GetUserDetails[2].ToLower().ToString()).Tables[0];
                    fnLoad(dtUserReport);
                    cmbDepartment.Visible = true;
                    if (dtUserReport.Rows.Count > 0)
                    {
                        foreach (DataRow dr in dtUserReport.Rows)
                        {
                            if (!cmbDepartment.Items.Contains(dr["AssignedDept"].ToString()))
                            {
                                cmbDepartment.Items.Add(dr["AssignedDept"].ToString());
                            }
                        }
                    }
                    if (Login.GetUserDetails[2].ToLower().ToString() == "megha")
                    {
                        btnSummaryEmail.Visible = true;
                    }

                    break;
                default:
                    break;
            }
        }

        private void cmbDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtUserReport = DAL.fnNCUserReport(8, cmbDepartment.Text).Tables[0];
            fnLoad(dtUserReport);
        }

        private void btnExcel_Click(object sender, EventArgs e)
        {
            int iRowIndex = 1;
            string ExcelFolderPath;
            string FileFullPath;
            EXCEL.Workbook NewWorkBook;
            EXCEL.Worksheet NewWorkSheet;
            EXCEL.Application ExcelApp;
            EXCEL.Range CELLS, cell1, cell2;
            object misValue;
            // dtIndentItems = DAL.fnIndentExcel(cmbIndentNo.Text, null).Tables[0];
            if (dtUserReport.Rows.Count > 0)
            {
                ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\NC Report\\";
                FileFullPath = ExcelFolderPath + "NC Report" + "--" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + ".xls";
                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);
                ExcelApp = new EXCEL.Application();
                misValue = System.Reflection.Missing.Value;
                try
                {
                    if (ExcelApp == null)
                        MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                    NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                    NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                    if (NewWorkSheet == null)
                        MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                    else
                        NewWorkSheet.Name = "NC Report";
                    // Select the Excel cells, in the range c1 to c7 in the worksheet for cell access check.
                    EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                    if (RANGE == null)
                        MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                    NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlWorkbookNormal, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    ExcelApp.Visible = false;
                    CELLS = NewWorkSheet.Cells;

                    NewWorkSheet.Cells[iRowIndex, 4] = "NC Report";
                    NewWorkSheet.Range["A1:D1"].Cells.Font.Size = 16;
                    NewWorkSheet.Range["A1:V5"].Cells.Font.Bold = true;
                    iRowIndex++;
                    iRowIndex++;
                    iRowIndex++;
                    iRowIndex++;
                    iRowIndex++;
                    if (dtUserReport.Rows.Count > 0)
                    {
                        object[,] rawData = new object[dtUserReport.Rows.Count + 1, dtUserReport.Columns.Count];
                        for (int col = 0; col < dtUserReport.Columns.Count; col++)
                        {
                            rawData[0, col] = dtUserReport.Columns[col].ColumnName;
                        }
                        for (int row = 0; row < dtUserReport.Rows.Count; row++)
                        {
                            for (int col = 0; col < dtUserReport.Columns.Count; col++)
                            {
                                rawData[row + 1, col] = dtUserReport.Rows[row].ItemArray[col];
                            }
                        }
                        string excelRange = string.Empty;
                        string finalColLetter = string.Empty;
                        string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        int colCharsetLen = colCharset.Length;

                        if (dtUserReport.Columns.Count > colCharsetLen)
                        {
                            finalColLetter = colCharset.Substring(
                                (dtUserReport.Columns.Count - 1) / colCharsetLen - 1, 1);
                        }

                        finalColLetter += colCharset.Substring(
                                (dtUserReport.Columns.Count - 1) % colCharsetLen, 1);
                        excelRange = string.Format("A5:{0}{1}", finalColLetter, dtUserReport.Rows.Count + iRowIndex - 1);


                        NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                    }

                    fnDateFormatstring(NewWorkSheet, "E1", "E9999");
                    fnDateFormatstring(NewWorkSheet, "K1", "K9999");
                    fnDateFormatstring(NewWorkSheet, "N1", "N9999");
                    fnDateFormatstring(NewWorkSheet, "P1", "P9999");
                    fnDateFormatstring(NewWorkSheet, "U1", "U9999");

                    NewWorkSheet.Rows.AutoFit();

                    NewWorkSheet.Columns.AutoFit();
                    NewWorkSheet.Rows.RowHeight = "18";

                    NewWorkSheet.Columns[4].ColumnWidth = 50;
                    NewWorkSheet.Columns[4].WrapText = true;
                    NewWorkSheet.Columns[12].ColumnWidth = 50;
                    NewWorkSheet.Columns[12].WrapText = true;
                    NewWorkSheet.Columns[13].ColumnWidth = 50;
                    NewWorkSheet.Columns[13].WrapText = true;
                    NewWorkSheet.Columns[17].ColumnWidth = 50;
                    NewWorkSheet.Columns[17].WrapText = true;
                    NewWorkSheet.Columns[18].ColumnWidth = 50;
                    NewWorkSheet.Columns[18].WrapText = true;
                    NewWorkSheet.Columns[19].ColumnWidth = 50;
                    NewWorkSheet.Columns[19].WrapText = true;

                    NewWorkSheet.PageSetup.PrintArea = "A1:Z" + dtUserReport.Rows.Count + iRowIndex + 3 + "";
                    NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                    NewWorkSheet.PageSetup.PrintNotes = true;
                    NewWorkSheet.PageSetup.Zoom = 100;
                    NewWorkSheet.PageSetup.FitToPagesTall = 1;
                    NewWorkSheet.PageSetup.FitToPagesWide = 1;
                    NewWorkSheet.PageSetup.LeftMargin = 0;
                    NewWorkSheet.PageSetup.RightMargin = 0;
                    NewWorkSheet.PageSetup.TopMargin = 0.75;
                    NewWorkSheet.PageSetup.BottomMargin = 0.75;
                    NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                    NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                    string _stLOGO = ("C:\\Databasepath\\Bisslogo.jpg");
                    EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[1, 7];

                    Image oImage = Image.FromFile(_stLOGO);
                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    NewWorkSheet.Paste(oRange, _stLOGO);

                    NewWorkBook.Save();
                    NewWorkBook.Close(true, misValue, misValue);
                    ExcelApp.Quit();


                    releaseObject(NewWorkSheet);
                    releaseObject(NewWorkBook);
                    releaseObject(ExcelApp);
                    if (Directory.Exists(ExcelFolderPath))
                    {
                        Process.Start(ExcelFolderPath);
                    }
                    System.Threading.Thread.Sleep(1000);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                    {
                        GetProcess.Kill();
                    }
                }
            }
            else
                MessageBox.Show("No NC to save", "Error", 0, MessageBoxIcon.Question);
        }

        #region Excel App Release Object Function
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
        #endregion

        public void fnDateFormatstring(EXCEL.Worksheet worksheet, string column1, string column2)
        {
            Microsoft.Office.Interop.Excel.Range date = worksheet.get_Range(column1, column2);
            date.EntireColumn.NumberFormat = "DD/MM/YYYY";
        }

        private void frmUserNcDetails_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (NC.fnNCNumber == null)
            {
                NC.fnNCNumber = string.Empty;
            }
        }

        private void btnSummaryEmail_Click(object sender, EventArgs e)
        {
            if (cmbDepartment.Text.Trim() == "Design")
            {
                lstAddUser.Items.Clear();

                {
                    lstAddUser.Items.Add("somayya@biss.in");
                }
                string sSubject = @"<font face=Calibri> Dear Santhosh, 
                                    <br />Summary of NCs for Design Department as follows. Please take necessary action within 5 days.<br /> <br /> 
                                     <b> New NCs : </b> " + btnNewNC.Text + "  <br /> <b>Correction not closed : </b>" + btnCorrectionClosed.Text + " <br/> <b>Corrective action not closed : </b>" + btnCANotClosed.Text + " <br /> <b>NC closed : </b>" + btnNCClosed.Text + " <br /> <br /> <b> Regards,<br /> " + Login.GetUserDetails[2] + " </b>  <br /><br /> <br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
              
                CreateEMail("", "santhoshdj@biss.in", lstAddUser, sSubject);
            }

            else if (cmbDepartment.Text.Trim() == "Mech Production")
            {
                lstAddUser.Items.Clear();

                {
                    lstAddUser.Items.Add("ravi@biss.in");
                }
                string sSubject = @"<font face=Calibri> Dear Lingam, 
                                    <br />Summary of NCs for Mechanical Production as follows. Please take necessary action within 5 days.<br /> <br /> 
                                      <b> New NCs : </b> " + btnNewNC.Text + "  <br /> <b>Correction not closed : </b>" + btnCorrectionClosed.Text + " <br/> <b>Corrective action not closed : </b>" + btnCANotClosed.Text + " <br /> <b>NC closed : </b>" + btnNCClosed.Text + " <br /> <br /> <b> Regards,<br /> " + Login.GetUserDetails[2] + " </b>  <br /><br /> <br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
              
                CreateEMail("", "lingam@biss.in", lstAddUser, sSubject);
            }

            else if (cmbDepartment.Text.Trim() == "Transducer")
            {
                lstAddUser.Items.Clear();

                {
                    lstAddUser.Items.Add("pavankumar@biss.in");
                    lstAddUser.Items.Add("ravi@biss.in");
                }
                string sSubject = @"<font face=Calibri> Dear Pandian, 
                                    <br />Summary of NCs for Transducer Department as follows. Please take necessary action within 5 days.<br /> <br /> 
                                      <b> New NCs : </b> " + btnNewNC.Text + "  <br /> <b>Correction not closed : </b>" + btnCorrectionClosed.Text + " <br/> <b>Corrective action not closed : </b>" + btnCANotClosed.Text + " <br /> <b>NC closed : </b>" + btnNCClosed.Text + " <br /> <br /> <b> Regards,<br /> " + Login.GetUserDetails[2] + " </b>  <br /><br /> <br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
              
                CreateEMail("", "pandian@biss.in", lstAddUser, sSubject);
            }

            else if (cmbDepartment.Text.Trim() == "Controller")
            {
                lstAddUser.Items.Clear();

                {
                    lstAddUser.Items.Add("ravi@biss.in");
                }
                string sSubject = @"<font face=Calibri> Dear Jebaraj, 
                                    <br />Summary of NCs for Controller Department as follows. Please take necessary action within 5 days.<br /> <br /> 
                                      <b> New NCs : </b> " + btnNewNC.Text + "  <br /> <b>Correction not closed : </b>" + btnCorrectionClosed.Text + " <br/> <b>Corrective action not closed : </b>" + btnCANotClosed.Text + " <br /> <b>NC closed : </b>" + btnNCClosed.Text + " <br /> <br /> <b> Regards,<br /> " + Login.GetUserDetails[2] + " </b>  <br /><br /> <br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
              
                CreateEMail("", "jebaraj@biss.in", lstAddUser, sSubject);
            }

            else if (cmbDepartment.Text.Trim() == "Hydraulics")
            {
                lstAddUser.Items.Clear();

                {
                    lstAddUser.Items.Add("ravi@biss.in");
                }
                string sSubject = @"<font face=Calibri> Dear Jayanna, 
                                    <br />Summary of NCs for Hydraulics Department as follows. Please take necessary action within 5 days.<br /> <br /> 
                                      <b> New NCs : </b> " + btnNewNC.Text + "  <br /> <b>Correction not closed : </b>" + btnCorrectionClosed.Text + " <br/> <b>Corrective action not closed : </b>" + btnCANotClosed.Text + " <br /> <b>NC closed : </b>" + btnNCClosed.Text + " <br /> <br /> <b> Regards,<br /> " + Login.GetUserDetails[2] + " </b>  <br /><br /> <br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
              
                CreateEMail("", "jayanna@biss.in", lstAddUser, sSubject);
            }

            else if (cmbDepartment.Text.Trim() == "Integration")
            {
                lstAddUser.Items.Clear();

                {
                    lstAddUser.Items.Add("henry@biss.in");
                    lstAddUser.Items.Add("ravi@biss.in");
                }
                string sSubject = @"<font face=Calibri> Dear Venkatesh, 
                                    <br />Summary of NCs for Integration Department as follows. Please take necessary action within 5 days.<br /> <br /> 
                                      <b> New NCs : </b> " + btnNewNC.Text + "  <br /> <b>Correction not closed : </b>" + btnCorrectionClosed.Text + " <br/> <b>Corrective action not closed : </b>" + btnCANotClosed.Text + " <br /> <b>NC closed : </b>" + btnNCClosed.Text + " <br /> <br /> <b> Regards,<br /> " + Login.GetUserDetails[2] + " </b>  <br /><br /> <br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
              
                CreateEMail("", "venkatesh@biss.in", lstAddUser, sSubject);
            }

            else if (cmbDepartment.Text.Trim() == "Software")
            {
                lstAddUser.Items.Clear();

                {
                    lstAddUser.Items.Add("somayya@biss.in");
                }
                string sSubject = @"<font face=Calibri> Dear Ramesh, 
                                    <br />Summary of NCs for Software Department as follows. Please take necessary action within 5 days.<br /> <br /> 
                                      <b> New NCs : </b> " + btnNewNC.Text + "  <br /> <b>Correction not closed : </b>" + btnCorrectionClosed.Text + " <br/> <b>Corrective action not closed : </b>" + btnCANotClosed.Text + " <br /> <b>NC closed : </b>" + btnNCClosed.Text + " <br /> <br /> <b> Regards,<br /> " + Login.GetUserDetails[2] + " </b>  <br /><br /> <br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
              
                CreateEMail("", "ramesh@biss.in", lstAddUser, sSubject);
            }
            else if (cmbDepartment.Text.Trim() == "MTL32")
            {
                lstAddUser.Items.Clear();

                {
                    lstAddUser.Items.Add("somayya@biss.in");
                }
                string sSubject = @"<font face=Calibri> Dear Ramesh, 
                                    <br />Summary of NCs for MTL32 as follows. Please take necessary action within 5 days.<br /> <br /> 
                                      <b> New NCs : </b> " + btnNewNC.Text + "  <br /> <b>Correction not closed : </b>" + btnCorrectionClosed.Text + " <br/> <b>Corrective action not closed : </b>" + btnCANotClosed.Text + " <br /> <b>NC closed : </b>" + btnNCClosed.Text + " <br /> <br /> <b> Regards,<br /> " + Login.GetUserDetails[2] + " </b>  <br /><br /> <br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
              
                CreateEMail("", "ramesh@biss.in", lstAddUser, sSubject);
            }

            else if (cmbDepartment.Text.Trim() == "Purchase")
            {
                lstAddUser.Items.Clear();

                {
                    lstAddUser.Items.Add("ravi@biss.in");
                }
                string sSubject = @"<font face=Calibri> Dear Muthuramalingam, 
                                    <br />Summary of NCs for Purchase Department as follows. Please take necessary action within 5 days.<br /> <br /> 
                                      <b> New NCs : </b> " + btnNewNC.Text + "  <br /> <b>Correction not closed : </b>" + btnCorrectionClosed.Text + " <br/> <b>Corrective action not closed : </b>" + btnCANotClosed.Text + " <br /> <b>NC closed : </b>" + btnNCClosed.Text + " <br /> <br /> <b> Regards,<br /> " + Login.GetUserDetails[2] + " </b>  <br /><br /> <br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
              
                CreateEMail("", "muthuramalingam@biss.in", lstAddUser, sSubject);
            }

            else if (cmbDepartment.Text.Trim() == "Sales")
            {
                lstAddUser.Items.Clear();

                {
                   // lstAddUser.Items.Add("ravi@biss.in");
                }
                string sSubject = @"<font face=Calibri> Dear Vivek, 
                                    <br />Summary of NCs for Sales Department as follows. Please take necessary action within 5 days.<br /> <br /> 
                                    <b> New NCs : </b> " + btnNewNC.Text + "  <br /> <b>Correction not closed : </b>" + btnCorrectionClosed.Text + " <br/> <b>Corrective action not closed : </b>" + btnCANotClosed.Text + " <br /> <b>NC closed : </b>" + btnNCClosed.Text + " <br /> <br /> <b> Regards,<br /> " + Login.GetUserDetails[2] + " </b>  <br /><br /> <br /> <b>*** PLEASE DO NOT REPLY TO THIS MAIL. THIS IS AN AUTO GENERATED MAIL ***</b> </font>";
              
                CreateEMail("", "vivekg@biss.in", lstAddUser, sSubject);
            }

        }

        private void CreateEMail(string sNCNumber, string sTo, ListBox sCC, string sSubject)
        {
            try
            {
                Outlook.Application oApp = new Outlook.Application();
                Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                oMsg.Subject = "NC summary report";
                //  oMsg.iHTMLBody = true;
                oMsg.HTMLBody = sSubject;
                // Add a recipient.
                Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                oRecips.Add(sTo);
                oRecips.ResolveAll();
                if (sCC.Items.Count > 0)
                {
                    Outlook.Recipient oRecip;
                    List<string> sCCRecipsList = new List<string>();
                    foreach (string tempTO in sCC.Items)
                    {
                        if (tempTO != null)
                            sCCRecipsList.Add(tempTO);
                    }
                    foreach (string t in sCCRecipsList)
                    {

                        oRecip = (Outlook.Recipient)oRecips.Add(t);
                        oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                        oRecip.Resolve();
                    }
                    oMsg.Send();
                    oRecip = null;
                }
                else
                {
                    // Send.
                    oMsg.Send();
                    // Clean up.
                    oRecips = null;
                }

                oMsg = null;
                oApp = null;
            }
            catch (Exception ex)
            {

            }
        }

        private void dptToDate_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
