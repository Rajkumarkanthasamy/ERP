﻿
namespace Erp_Project_With_Buttons.Biss_NC
{
    partial class SRFCalibration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SRFCalibration));
            this.txtSRFContactNumber = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.TxtSRFContactPerson = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtSRFEmail = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtSRFCusCode = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.txtSRFAddress = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.cmbSRFCustomer = new System.Windows.Forms.ComboBox();
            this.cmbSRFCalibrationAt = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.cmbSRFCertificateIssue = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbSRFArtefactCollection = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSRFAddNewItem = new System.Windows.Forms.Button();
            this.dgvRIQuoteDetails = new System.Windows.Forms.DataGridView();
            this.Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Make = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Decisionrule = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TypeModel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CalibrationmethodProcedure = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RISlNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RIScopeofwork = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RIPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtSRFSpecailInstructions = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbSRFAnyRisks = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbSRFDeliveryFeasibility = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbCustomerSpecificrange = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbSRFReviewvedBy = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbSrfStatus = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtSRFRemarks = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cmbSRFAssignedto = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.cmbSRFCalibratedBy = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.dtpSRFCalibratedOn = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRIQuoteDetails)).BeginInit();
            this.SuspendLayout();
            // 
            // txtSRFContactNumber
            // 
            this.txtSRFContactNumber.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtSRFContactNumber.Location = new System.Drawing.Point(144, 195);
            this.txtSRFContactNumber.MaxLength = 80;
            this.txtSRFContactNumber.Name = "txtSRFContactNumber";
            this.txtSRFContactNumber.Size = new System.Drawing.Size(381, 26);
            this.txtSRFContactNumber.TabIndex = 328;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label60.ForeColor = System.Drawing.Color.Black;
            this.label60.Location = new System.Drawing.Point(24, 198);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(116, 18);
            this.label60.TabIndex = 329;
            this.label60.Text = "Contact Number :";
            // 
            // TxtSRFContactPerson
            // 
            this.TxtSRFContactPerson.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.TxtSRFContactPerson.Location = new System.Drawing.Point(144, 160);
            this.TxtSRFContactPerson.MaxLength = 80;
            this.TxtSRFContactPerson.Name = "TxtSRFContactPerson";
            this.TxtSRFContactPerson.Size = new System.Drawing.Size(381, 26);
            this.TxtSRFContactPerson.TabIndex = 326;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(22, 160);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(118, 18);
            this.label16.TabIndex = 327;
            this.label16.Text = "Contact Person * :";
            // 
            // txtSRFEmail
            // 
            this.txtSRFEmail.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtSRFEmail.Location = new System.Drawing.Point(144, 230);
            this.txtSRFEmail.MaxLength = 80;
            this.txtSRFEmail.Name = "txtSRFEmail";
            this.txtSRFEmail.Size = new System.Drawing.Size(381, 26);
            this.txtSRFEmail.TabIndex = 324;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(91, 233);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(49, 18);
            this.label15.TabIndex = 325;
            this.label15.Text = "Email :";
            // 
            // txtSRFCusCode
            // 
            this.txtSRFCusCode.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtSRFCusCode.Location = new System.Drawing.Point(536, 22);
            this.txtSRFCusCode.Name = "txtSRFCusCode";
            this.txtSRFCusCode.Size = new System.Drawing.Size(20, 26);
            this.txtSRFCusCode.TabIndex = 323;
            this.txtSRFCusCode.Visible = false;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label37.ForeColor = System.Drawing.Color.Black;
            this.label37.Location = new System.Drawing.Point(53, 24);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(85, 18);
            this.label37.TabIndex = 321;
            this.label37.Text = "Customer * :";
            // 
            // txtSRFAddress
            // 
            this.txtSRFAddress.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtSRFAddress.Location = new System.Drawing.Point(144, 56);
            this.txtSRFAddress.Multiline = true;
            this.txtSRFAddress.Name = "txtSRFAddress";
            this.txtSRFAddress.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtSRFAddress.Size = new System.Drawing.Size(381, 95);
            this.txtSRFAddress.TabIndex = 320;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label41.ForeColor = System.Drawing.Color.Black;
            this.label41.Location = new System.Drawing.Point(75, 57);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(65, 18);
            this.label41.TabIndex = 322;
            this.label41.Text = "Address :";
            // 
            // cmbSRFCustomer
            // 
            this.cmbSRFCustomer.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbSRFCustomer.DropDownHeight = 90;
            this.cmbSRFCustomer.DropDownWidth = 150;
            this.cmbSRFCustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSRFCustomer.FormattingEnabled = true;
            this.cmbSRFCustomer.IntegralHeight = false;
            this.cmbSRFCustomer.Location = new System.Drawing.Point(144, 21);
            this.cmbSRFCustomer.Name = "cmbSRFCustomer";
            this.cmbSRFCustomer.Size = new System.Drawing.Size(381, 26);
            this.cmbSRFCustomer.TabIndex = 319;
            this.cmbSRFCustomer.SelectedIndexChanged += new System.EventHandler(this.cmbSRFCustomer_SelectedIndexChanged);
            // 
            // cmbSRFCalibrationAt
            // 
            this.cmbSRFCalibrationAt.DropDownHeight = 60;
            this.cmbSRFCalibrationAt.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSRFCalibrationAt.DropDownWidth = 150;
            this.cmbSRFCalibrationAt.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSRFCalibrationAt.FormattingEnabled = true;
            this.cmbSRFCalibrationAt.IntegralHeight = false;
            this.cmbSRFCalibrationAt.ItemHeight = 18;
            this.cmbSRFCalibrationAt.Items.AddRange(new object[] {
            "In House",
            "Site"});
            this.cmbSRFCalibrationAt.Location = new System.Drawing.Point(886, 22);
            this.cmbSRFCalibrationAt.Name = "cmbSRFCalibrationAt";
            this.cmbSRFCalibrationAt.Size = new System.Drawing.Size(113, 26);
            this.cmbSRFCalibrationAt.TabIndex = 330;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(762, 30);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(108, 18);
            this.label11.TabIndex = 331;
            this.label11.Text = "Calibration at * :";
            // 
            // cmbSRFCertificateIssue
            // 
            this.cmbSRFCertificateIssue.DropDownHeight = 60;
            this.cmbSRFCertificateIssue.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSRFCertificateIssue.DropDownWidth = 150;
            this.cmbSRFCertificateIssue.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSRFCertificateIssue.FormattingEnabled = true;
            this.cmbSRFCertificateIssue.IntegralHeight = false;
            this.cmbSRFCertificateIssue.ItemHeight = 18;
            this.cmbSRFCertificateIssue.Items.AddRange(new object[] {
            "By Hand",
            "Post",
            "Others"});
            this.cmbSRFCertificateIssue.Location = new System.Drawing.Point(886, 64);
            this.cmbSRFCertificateIssue.Name = "cmbSRFCertificateIssue";
            this.cmbSRFCertificateIssue.Size = new System.Drawing.Size(113, 26);
            this.cmbSRFCertificateIssue.TabIndex = 332;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(749, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 18);
            this.label1.TabIndex = 333;
            this.label1.Text = "Certificate Issue* :";
            // 
            // cmbSRFArtefactCollection
            // 
            this.cmbSRFArtefactCollection.DropDownHeight = 60;
            this.cmbSRFArtefactCollection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSRFArtefactCollection.DropDownWidth = 150;
            this.cmbSRFArtefactCollection.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSRFArtefactCollection.FormattingEnabled = true;
            this.cmbSRFArtefactCollection.IntegralHeight = false;
            this.cmbSRFArtefactCollection.ItemHeight = 18;
            this.cmbSRFArtefactCollection.Items.AddRange(new object[] {
            "By Hand",
            "Post",
            "Others"});
            this.cmbSRFArtefactCollection.Location = new System.Drawing.Point(886, 106);
            this.cmbSRFArtefactCollection.Name = "cmbSRFArtefactCollection";
            this.cmbSRFArtefactCollection.Size = new System.Drawing.Size(113, 26);
            this.cmbSRFArtefactCollection.TabIndex = 334;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(732, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(138, 18);
            this.label2.TabIndex = 335;
            this.label2.Text = "Artefact Collection* :";
            // 
            // btnSRFAddNewItem
            // 
            this.btnSRFAddNewItem.BackColor = System.Drawing.Color.SpringGreen;
            this.btnSRFAddNewItem.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSRFAddNewItem.Location = new System.Drawing.Point(8, 227);
            this.btnSRFAddNewItem.Name = "btnSRFAddNewItem";
            this.btnSRFAddNewItem.Size = new System.Drawing.Size(77, 30);
            this.btnSRFAddNewItem.TabIndex = 337;
            this.btnSRFAddNewItem.Text = "Add Item";
            this.btnSRFAddNewItem.UseVisualStyleBackColor = false;
            this.btnSRFAddNewItem.Click += new System.EventHandler(this.btnSRFAddNewItem_Click);
            // 
            // dgvRIQuoteDetails
            // 
            this.dgvRIQuoteDetails.AllowUserToAddRows = false;
            this.dgvRIQuoteDetails.AllowUserToOrderColumns = true;
            this.dgvRIQuoteDetails.AllowUserToResizeRows = false;
            this.dgvRIQuoteDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvRIQuoteDetails.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvRIQuoteDetails.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvRIQuoteDetails.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRIQuoteDetails.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvRIQuoteDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRIQuoteDetails.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Description,
            this.Make,
            this.Decisionrule,
            this.TypeModel,
            this.CalibrationmethodProcedure,
            this.RISlNo,
            this.RIScopeofwork,
            this.RIPrice});
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRIQuoteDetails.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgvRIQuoteDetails.Location = new System.Drawing.Point(12, 263);
            this.dgvRIQuoteDetails.Name = "dgvRIQuoteDetails";
            this.dgvRIQuoteDetails.RowHeadersVisible = false;
            this.dgvRIQuoteDetails.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvRIQuoteDetails.Size = new System.Drawing.Size(1258, 281);
            this.dgvRIQuoteDetails.TabIndex = 336;
            // 
            // Description
            // 
            this.Description.HeaderText = "Description";
            this.Description.Name = "Description";
            this.Description.Width = 111;
            // 
            // Make
            // 
            this.Make.HeaderText = "Make";
            this.Make.Name = "Make";
            this.Make.Width = 72;
            // 
            // Decisionrule
            // 
            this.Decisionrule.HeaderText = "Decision Rule";
            this.Decisionrule.Name = "Decisionrule";
            this.Decisionrule.Width = 114;
            // 
            // TypeModel
            // 
            this.TypeModel.HeaderText = "Type/Model";
            this.TypeModel.Name = "TypeModel";
            this.TypeModel.Width = 118;
            // 
            // CalibrationmethodProcedure
            // 
            this.CalibrationmethodProcedure.HeaderText = "Calibration Method / Procedure";
            this.CalibrationmethodProcedure.Name = "CalibrationmethodProcedure";
            this.CalibrationmethodProcedure.Width = 230;
            // 
            // RISlNo
            // 
            this.RISlNo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.RISlNo.DefaultCellStyle = dataGridViewCellStyle2;
            this.RISlNo.HeaderText = "SlNo";
            this.RISlNo.Name = "RISlNo";
            this.RISlNo.ReadOnly = true;
            this.RISlNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RISlNo.Width = 47;
            // 
            // RIScopeofwork
            // 
            this.RIScopeofwork.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.RIScopeofwork.DefaultCellStyle = dataGridViewCellStyle3;
            this.RIScopeofwork.HeaderText = "Calibration Point";
            this.RIScopeofwork.Name = "RIScopeofwork";
            this.RIScopeofwork.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // RIPrice
            // 
            this.RIPrice.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.RIPrice.DefaultCellStyle = dataGridViewCellStyle4;
            this.RIPrice.FillWeight = 140F;
            this.RIPrice.HeaderText = "Calibration Frequency";
            this.RIPrice.Name = "RIPrice";
            this.RIPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RIPrice.Width = 140;
            // 
            // txtSRFSpecailInstructions
            // 
            this.txtSRFSpecailInstructions.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtSRFSpecailInstructions.Location = new System.Drawing.Point(886, 148);
            this.txtSRFSpecailInstructions.Multiline = true;
            this.txtSRFSpecailInstructions.Name = "txtSRFSpecailInstructions";
            this.txtSRFSpecailInstructions.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtSRFSpecailInstructions.Size = new System.Drawing.Size(384, 106);
            this.txtSRFSpecailInstructions.TabIndex = 338;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(688, 150);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(182, 18);
            this.label3.TabIndex = 339;
            this.label3.Text = "Special Instructions (if any) :";
            // 
            // cmbSRFAnyRisks
            // 
            this.cmbSRFAnyRisks.DropDownHeight = 60;
            this.cmbSRFAnyRisks.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSRFAnyRisks.DropDownWidth = 150;
            this.cmbSRFAnyRisks.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSRFAnyRisks.FormattingEnabled = true;
            this.cmbSRFAnyRisks.IntegralHeight = false;
            this.cmbSRFAnyRisks.ItemHeight = 18;
            this.cmbSRFAnyRisks.Items.AddRange(new object[] {
            "Yes",
            "No",
            "NA"});
            this.cmbSRFAnyRisks.Location = new System.Drawing.Point(278, 619);
            this.cmbSRFAnyRisks.Name = "cmbSRFAnyRisks";
            this.cmbSRFAnyRisks.Size = new System.Drawing.Size(113, 26);
            this.cmbSRFAnyRisks.TabIndex = 344;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(23, 622);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(249, 18);
            this.label4.TabIndex = 345;
            this.label4.Text = "Any Risks (Including Impartiality risks) :";
            // 
            // cmbSRFDeliveryFeasibility
            // 
            this.cmbSRFDeliveryFeasibility.DropDownHeight = 60;
            this.cmbSRFDeliveryFeasibility.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSRFDeliveryFeasibility.DropDownWidth = 150;
            this.cmbSRFDeliveryFeasibility.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSRFDeliveryFeasibility.FormattingEnabled = true;
            this.cmbSRFDeliveryFeasibility.IntegralHeight = false;
            this.cmbSRFDeliveryFeasibility.ItemHeight = 18;
            this.cmbSRFDeliveryFeasibility.Items.AddRange(new object[] {
            "Yes",
            "No",
            "NA"});
            this.cmbSRFDeliveryFeasibility.Location = new System.Drawing.Point(278, 586);
            this.cmbSRFDeliveryFeasibility.Name = "cmbSRFDeliveryFeasibility";
            this.cmbSRFDeliveryFeasibility.Size = new System.Drawing.Size(113, 26);
            this.cmbSRFDeliveryFeasibility.TabIndex = 342;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(138, 589);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(134, 18);
            this.label5.TabIndex = 343;
            this.label5.Text = "Delivery Feasibility :";
            // 
            // cmbCustomerSpecificrange
            // 
            this.cmbCustomerSpecificrange.DropDownHeight = 60;
            this.cmbCustomerSpecificrange.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCustomerSpecificrange.DropDownWidth = 150;
            this.cmbCustomerSpecificrange.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCustomerSpecificrange.FormattingEnabled = true;
            this.cmbCustomerSpecificrange.IntegralHeight = false;
            this.cmbCustomerSpecificrange.ItemHeight = 18;
            this.cmbCustomerSpecificrange.Items.AddRange(new object[] {
            "Yes",
            "No",
            "NA"});
            this.cmbCustomerSpecificrange.Location = new System.Drawing.Point(278, 555);
            this.cmbCustomerSpecificrange.Name = "cmbCustomerSpecificrange";
            this.cmbCustomerSpecificrange.Size = new System.Drawing.Size(113, 26);
            this.cmbCustomerSpecificrange.TabIndex = 340;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(57, 558);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(215, 18);
            this.label6.TabIndex = 341;
            this.label6.Text = "Customer Specific Range (If Any) :";
            // 
            // cmbSRFReviewvedBy
            // 
            this.cmbSRFReviewvedBy.DropDownHeight = 60;
            this.cmbSRFReviewvedBy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSRFReviewvedBy.DropDownWidth = 150;
            this.cmbSRFReviewvedBy.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSRFReviewvedBy.FormattingEnabled = true;
            this.cmbSRFReviewvedBy.IntegralHeight = false;
            this.cmbSRFReviewvedBy.ItemHeight = 18;
            this.cmbSRFReviewvedBy.Items.AddRange(new object[] {
            "Yes",
            "No",
            "NA"});
            this.cmbSRFReviewvedBy.Location = new System.Drawing.Point(536, 555);
            this.cmbSRFReviewvedBy.Name = "cmbSRFReviewvedBy";
            this.cmbSRFReviewvedBy.Size = new System.Drawing.Size(113, 26);
            this.cmbSRFReviewvedBy.TabIndex = 346;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(425, 558);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(95, 18);
            this.label7.TabIndex = 347;
            this.label7.Text = "Reviewed by :";
            // 
            // cmbSrfStatus
            // 
            this.cmbSrfStatus.DropDownHeight = 60;
            this.cmbSrfStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSrfStatus.DropDownWidth = 150;
            this.cmbSrfStatus.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSrfStatus.FormattingEnabled = true;
            this.cmbSrfStatus.IntegralHeight = false;
            this.cmbSrfStatus.ItemHeight = 18;
            this.cmbSrfStatus.Items.AddRange(new object[] {
            "Accepted",
            "Not Accepted"});
            this.cmbSrfStatus.Location = new System.Drawing.Point(536, 586);
            this.cmbSrfStatus.Name = "cmbSrfStatus";
            this.cmbSrfStatus.Size = new System.Drawing.Size(113, 26);
            this.cmbSrfStatus.TabIndex = 348;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(467, 589);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 18);
            this.label8.TabIndex = 349;
            this.label8.Text = "Status :";
            // 
            // txtSRFRemarks
            // 
            this.txtSRFRemarks.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtSRFRemarks.Location = new System.Drawing.Point(971, 555);
            this.txtSRFRemarks.Multiline = true;
            this.txtSRFRemarks.Name = "txtSRFRemarks";
            this.txtSRFRemarks.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtSRFRemarks.Size = new System.Drawing.Size(299, 57);
            this.txtSRFRemarks.TabIndex = 350;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(905, 563);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(68, 18);
            this.label9.TabIndex = 351;
            this.label9.Text = "Remarks :";
            // 
            // cmbSRFAssignedto
            // 
            this.cmbSRFAssignedto.DropDownHeight = 60;
            this.cmbSRFAssignedto.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSRFAssignedto.DropDownWidth = 150;
            this.cmbSRFAssignedto.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSRFAssignedto.FormattingEnabled = true;
            this.cmbSRFAssignedto.IntegralHeight = false;
            this.cmbSRFAssignedto.ItemHeight = 18;
            this.cmbSRFAssignedto.Items.AddRange(new object[] {
            "Yes",
            "No",
            "NA"});
            this.cmbSRFAssignedto.Location = new System.Drawing.Point(536, 616);
            this.cmbSRFAssignedto.Name = "cmbSRFAssignedto";
            this.cmbSRFAssignedto.Size = new System.Drawing.Size(113, 26);
            this.cmbSRFAssignedto.TabIndex = 352;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(433, 619);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(87, 18);
            this.label10.TabIndex = 353;
            this.label10.Text = "Assigned to :";
            // 
            // cmbSRFCalibratedBy
            // 
            this.cmbSRFCalibratedBy.DropDownHeight = 60;
            this.cmbSRFCalibratedBy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSRFCalibratedBy.DropDownWidth = 150;
            this.cmbSRFCalibratedBy.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSRFCalibratedBy.FormattingEnabled = true;
            this.cmbSRFCalibratedBy.IntegralHeight = false;
            this.cmbSRFCalibratedBy.ItemHeight = 18;
            this.cmbSRFCalibratedBy.Items.AddRange(new object[] {
            "Yes",
            "No",
            "NA"});
            this.cmbSRFCalibratedBy.Location = new System.Drawing.Point(786, 555);
            this.cmbSRFCalibratedBy.Name = "cmbSRFCalibratedBy";
            this.cmbSRFCalibratedBy.Size = new System.Drawing.Size(113, 26);
            this.cmbSRFCalibratedBy.TabIndex = 354;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(688, 558);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(97, 18);
            this.label12.TabIndex = 355;
            this.label12.Text = "Calibrated By :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(685, 589);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(100, 18);
            this.label13.TabIndex = 356;
            this.label13.Text = "Calibrated On :";
            // 
            // dtpSRFCalibratedOn
            // 
            this.dtpSRFCalibratedOn.CustomFormat = "";
            this.dtpSRFCalibratedOn.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpSRFCalibratedOn.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpSRFCalibratedOn.Location = new System.Drawing.Point(786, 586);
            this.dtpSRFCalibratedOn.Name = "dtpSRFCalibratedOn";
            this.dtpSRFCalibratedOn.Size = new System.Drawing.Size(113, 26);
            this.dtpSRFCalibratedOn.TabIndex = 357;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "";
            this.dateTimePicker1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(1177, 29);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(93, 26);
            this.dateTimePicker1.TabIndex = 358;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button1.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(1164, 614);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 37);
            this.button1.TabIndex = 359;
            this.button1.Text = "Save";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // SRFCalibration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1308, 650);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.dtpSRFCalibratedOn);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.cmbSRFCalibratedBy);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.cmbSRFAssignedto);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtSRFRemarks);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.cmbSrfStatus);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.cmbSRFReviewvedBy);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cmbSRFAnyRisks);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cmbSRFDeliveryFeasibility);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cmbCustomerSpecificrange);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtSRFSpecailInstructions);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnSRFAddNewItem);
            this.Controls.Add(this.dgvRIQuoteDetails);
            this.Controls.Add(this.cmbSRFArtefactCollection);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cmbSRFCertificateIssue);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbSRFCalibrationAt);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtSRFContactNumber);
            this.Controls.Add(this.label60);
            this.Controls.Add(this.TxtSRFContactPerson);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.txtSRFEmail);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txtSRFCusCode);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.txtSRFAddress);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.cmbSRFCustomer);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "SRFCalibration";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SRF Calibration";
            this.Load += new System.EventHandler(this.SRFCalibration_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRIQuoteDetails)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSRFContactNumber;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox TxtSRFContactPerson;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtSRFEmail;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtSRFCusCode;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txtSRFAddress;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.ComboBox cmbSRFCustomer;
        private System.Windows.Forms.ComboBox cmbSRFCalibrationAt;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cmbSRFCertificateIssue;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbSRFArtefactCollection;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSRFAddNewItem;
        private System.Windows.Forms.DataGridView dgvRIQuoteDetails;
        private System.Windows.Forms.DataGridViewTextBoxColumn Description;
        private System.Windows.Forms.DataGridViewTextBoxColumn Make;
        private System.Windows.Forms.DataGridViewTextBoxColumn Decisionrule;
        private System.Windows.Forms.DataGridViewTextBoxColumn TypeModel;
        private System.Windows.Forms.DataGridViewTextBoxColumn CalibrationmethodProcedure;
        private System.Windows.Forms.DataGridViewTextBoxColumn RISlNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn RIScopeofwork;
        private System.Windows.Forms.DataGridViewTextBoxColumn RIPrice;
        private System.Windows.Forms.TextBox txtSRFSpecailInstructions;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbSRFAnyRisks;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbSRFDeliveryFeasibility;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbCustomerSpecificrange;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbSRFReviewvedBy;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbSrfStatus;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtSRFRemarks;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmbSRFAssignedto;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cmbSRFCalibratedBy;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DateTimePicker dtpSRFCalibratedOn;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button button1;
    }
}