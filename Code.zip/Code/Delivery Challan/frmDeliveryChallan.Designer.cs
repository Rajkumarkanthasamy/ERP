﻿
namespace Erp_Project_With_Buttons.Delivery_Challan
{
    partial class frmDeliveryChallan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDeliveryChallan));
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnLoadPO = new System.Windows.Forms.Button();
            this.cmbDCType = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.cmbDeliverChallan = new System.Windows.Forms.ComboBox();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtDcFor = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txttransportmode = new System.Windows.Forms.ComboBox();
            this.dtpDispachDate = new System.Windows.Forms.DateTimePicker();
            this.dtpdateofchallan = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblnoanddescofpackages = new System.Windows.Forms.Label();
            this.lblmodeofdispatch = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtslnoofchallan = new System.Windows.Forms.TextBox();
            this.lbldatetimeofpreparation = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbltimedateofremoval = new System.Windows.Forms.Label();
            this.lblnameofexcise = new System.Windows.Forms.Label();
            this.txtRefNumber = new System.Windows.Forms.TextBox();
            this.lblesugamnumber = new System.Windows.Forms.Label();
            this.txtapplicabletaxrate = new System.Windows.Forms.TextBox();
            this.txtvhiclenumber = new System.Windows.Forms.TextBox();
            this.txttransportcompany = new System.Windows.Forms.TextBox();
            this.txtplaceofsupply = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnCustomer = new System.Windows.Forms.Button();
            this.btnVendor = new System.Windows.Forms.Button();
            this.cmbCustomerName = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtgstin = new System.Windows.Forms.TextBox();
            this.txtcustomerstate = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtcustomerstatecode = new System.Windows.Forms.TextBox();
            this.txtcustomeraddress = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dtpDaterecieved = new System.Windows.Forms.DateTimePicker();
            this.dgvRecievedItems = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RemainingQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RecievedQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvpoitems = new System.Windows.Forms.DataGridView();
            this.btnaddnewrow = new System.Windows.Forms.Button();
            this.pnDCRecieve = new System.Windows.Forms.Panel();
            this.txtProject = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.txtDepartment = new System.Windows.Forms.TextBox();
            this.txtBillNumber = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txttotal = new System.Windows.Forms.TextBox();
            this.btnCancelDC = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.label81 = new System.Windows.Forms.Label();
            this.cmbSelectQuoteType = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.Slno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DescriptionOfGoods = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HsnSacCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Unit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRecievedItems)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvpoitems)).BeginInit();
            this.pnDCRecieve.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.comboBox2);
            this.panel2.Controls.Add(this.comboBox1);
            this.panel2.Controls.Add(this.label81);
            this.panel2.Controls.Add(this.cmbSelectQuoteType);
            this.panel2.Controls.Add(this.btnLoadPO);
            this.panel2.Controls.Add(this.cmbDCType);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.cmbDeliverChallan);
            this.panel2.Controls.Add(this.txtRemarks);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.txtDcFor);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.txttransportmode);
            this.panel2.Controls.Add(this.dtpDispachDate);
            this.panel2.Controls.Add(this.dtpdateofchallan);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.lblnoanddescofpackages);
            this.panel2.Controls.Add(this.lblmodeofdispatch);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.txtslnoofchallan);
            this.panel2.Controls.Add(this.lbldatetimeofpreparation);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.lbltimedateofremoval);
            this.panel2.Controls.Add(this.lblnameofexcise);
            this.panel2.Controls.Add(this.txtRefNumber);
            this.panel2.Controls.Add(this.lblesugamnumber);
            this.panel2.Controls.Add(this.txtapplicabletaxrate);
            this.panel2.Controls.Add(this.txtvhiclenumber);
            this.panel2.Controls.Add(this.txttransportcompany);
            this.panel2.Controls.Add(this.txtplaceofsupply);
            this.panel2.Location = new System.Drawing.Point(12, 5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1284, 246);
            this.panel2.TabIndex = 76;
            // 
            // btnLoadPO
            // 
            this.btnLoadPO.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnLoadPO.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLoadPO.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadPO.Location = new System.Drawing.Point(572, 142);
            this.btnLoadPO.Name = "btnLoadPO";
            this.btnLoadPO.Size = new System.Drawing.Size(160, 24);
            this.btnLoadPO.TabIndex = 123;
            this.btnLoadPO.Text = "Load PO/WO/Indent";
            this.btnLoadPO.UseVisualStyleBackColor = false;
            // 
            // cmbDCType
            // 
            this.cmbDCType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbDCType.DropDownHeight = 130;
            this.cmbDCType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDCType.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDCType.FormattingEnabled = true;
            this.cmbDCType.IntegralHeight = false;
            this.cmbDCType.Items.AddRange(new object[] {
            "Job Work",
            "Warranty",
            "Free Movement"});
            this.cmbDCType.Location = new System.Drawing.Point(170, 85);
            this.cmbDCType.Name = "cmbDCType";
            this.cmbDCType.Size = new System.Drawing.Size(256, 26);
            this.cmbDCType.TabIndex = 100;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(40, 90);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(127, 15);
            this.label15.TabIndex = 99;
            this.label15.Text = "Delivery Challan Type:";
            // 
            // cmbDeliverChallan
            // 
            this.cmbDeliverChallan.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbDeliverChallan.DropDownHeight = 130;
            this.cmbDeliverChallan.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDeliverChallan.FormattingEnabled = true;
            this.cmbDeliverChallan.IntegralHeight = false;
            this.cmbDeliverChallan.Location = new System.Drawing.Point(169, 47);
            this.cmbDeliverChallan.Name = "cmbDeliverChallan";
            this.cmbDeliverChallan.Size = new System.Drawing.Size(256, 26);
            this.cmbDeliverChallan.TabIndex = 98;
            this.cmbDeliverChallan.Visible = false;
            // 
            // txtRemarks
            // 
            this.txtRemarks.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemarks.Location = new System.Drawing.Point(935, 199);
            this.txtRemarks.Multiline = true;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Size = new System.Drawing.Size(331, 40);
            this.txtRemarks.TabIndex = 96;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(874, 202);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(61, 15);
            this.label14.TabIndex = 95;
            this.label14.Text = "Remarks :";
            // 
            // txtDcFor
            // 
            this.txtDcFor.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDcFor.Location = new System.Drawing.Point(170, 214);
            this.txtDcFor.MaxLength = 150;
            this.txtDcFor.Name = "txtDcFor";
            this.txtDcFor.Size = new System.Drawing.Size(300, 23);
            this.txtDcFor.TabIndex = 94;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(47, 217);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(122, 15);
            this.label13.TabIndex = 93;
            this.label13.Text = "Delivery Challan For :";
            // 
            // txttransportmode
            // 
            this.txttransportmode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.txttransportmode.DropDownHeight = 130;
            this.txttransportmode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttransportmode.FormattingEnabled = true;
            this.txttransportmode.IntegralHeight = false;
            this.txttransportmode.Items.AddRange(new object[] {
            "By Road",
            "By Sea",
            "By Air"});
            this.txttransportmode.Location = new System.Drawing.Point(937, 10);
            this.txttransportmode.Name = "txttransportmode";
            this.txttransportmode.Size = new System.Drawing.Size(331, 26);
            this.txttransportmode.TabIndex = 90;
            // 
            // dtpDispachDate
            // 
            this.dtpDispachDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDispachDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDispachDate.Location = new System.Drawing.Point(1161, 167);
            this.dtpDispachDate.Name = "dtpDispachDate";
            this.dtpDispachDate.Size = new System.Drawing.Size(105, 26);
            this.dtpDispachDate.TabIndex = 89;
            // 
            // dtpdateofchallan
            // 
            this.dtpdateofchallan.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpdateofchallan.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpdateofchallan.Location = new System.Drawing.Point(937, 167);
            this.dtpdateofchallan.Name = "dtpdateofchallan";
            this.dtpdateofchallan.Size = new System.Drawing.Size(89, 26);
            this.dtpdateofchallan.TabIndex = 88;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(47, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Serial no. of Challan :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(839, 173);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Date of Challan :";
            // 
            // lblnoanddescofpackages
            // 
            this.lblnoanddescofpackages.AutoSize = true;
            this.lblnoanddescofpackages.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnoanddescofpackages.ForeColor = System.Drawing.Color.Black;
            this.lblnoanddescofpackages.Location = new System.Drawing.Point(815, 111);
            this.lblnoanddescofpackages.Name = "lblnoanddescofpackages";
            this.lblnoanddescofpackages.Size = new System.Drawing.Size(120, 15);
            this.lblnoanddescofpackages.TabIndex = 45;
            this.lblnoanddescofpackages.Text = "Transport Company :";
            // 
            // lblmodeofdispatch
            // 
            this.lblmodeofdispatch.AutoSize = true;
            this.lblmodeofdispatch.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmodeofdispatch.ForeColor = System.Drawing.Color.Black;
            this.lblmodeofdispatch.Location = new System.Drawing.Point(817, 142);
            this.lblmodeofdispatch.Name = "lblmodeofdispatch";
            this.lblmodeofdispatch.Size = new System.Drawing.Size(118, 15);
            this.lblmodeofdispatch.TabIndex = 46;
            this.lblmodeofdispatch.Text = "Applicable Tax Rate :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(64, 154);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "PO/WO/Indent :";
            // 
            // txtslnoofchallan
            // 
            this.txtslnoofchallan.Enabled = false;
            this.txtslnoofchallan.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtslnoofchallan.Location = new System.Drawing.Point(170, 47);
            this.txtslnoofchallan.Name = "txtslnoofchallan";
            this.txtslnoofchallan.Size = new System.Drawing.Size(256, 23);
            this.txtslnoofchallan.TabIndex = 61;
            // 
            // lbldatetimeofpreparation
            // 
            this.lbldatetimeofpreparation.AutoSize = true;
            this.lbldatetimeofpreparation.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldatetimeofpreparation.ForeColor = System.Drawing.Color.Black;
            this.lbldatetimeofpreparation.Location = new System.Drawing.Point(834, 15);
            this.lbldatetimeofpreparation.Name = "lbldatetimeofpreparation";
            this.lbldatetimeofpreparation.Size = new System.Drawing.Size(101, 15);
            this.lbldatetimeofpreparation.TabIndex = 49;
            this.lbldatetimeofpreparation.Text = "Transport Mode :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(86, 186);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Ref Number :";
            // 
            // lbltimedateofremoval
            // 
            this.lbltimedateofremoval.AutoSize = true;
            this.lbltimedateofremoval.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltimedateofremoval.ForeColor = System.Drawing.Color.Black;
            this.lbltimedateofremoval.Location = new System.Drawing.Point(833, 46);
            this.lbltimedateofremoval.Name = "lbltimedateofremoval";
            this.lbltimedateofremoval.Size = new System.Drawing.Size(102, 15);
            this.lbltimedateofremoval.TabIndex = 50;
            this.lbltimedateofremoval.Text = "Vehicle Number :";
            // 
            // lblnameofexcise
            // 
            this.lblnameofexcise.AutoSize = true;
            this.lblnameofexcise.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnameofexcise.ForeColor = System.Drawing.Color.Black;
            this.lblnameofexcise.Location = new System.Drawing.Point(1066, 173);
            this.lblnameofexcise.Name = "lblnameofexcise";
            this.lblnameofexcise.Size = new System.Drawing.Size(89, 15);
            this.lblnameofexcise.TabIndex = 51;
            this.lblnameofexcise.Text = "Dispatch Date :";
            // 
            // txtRefNumber
            // 
            this.txtRefNumber.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRefNumber.Location = new System.Drawing.Point(170, 183);
            this.txtRefNumber.MaxLength = 150;
            this.txtRefNumber.Name = "txtRefNumber";
            this.txtRefNumber.Size = new System.Drawing.Size(300, 23);
            this.txtRefNumber.TabIndex = 59;
            // 
            // lblesugamnumber
            // 
            this.lblesugamnumber.AutoSize = true;
            this.lblesugamnumber.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblesugamnumber.ForeColor = System.Drawing.Color.Black;
            this.lblesugamnumber.Location = new System.Drawing.Point(838, 78);
            this.lblesugamnumber.Name = "lblesugamnumber";
            this.lblesugamnumber.Size = new System.Drawing.Size(97, 15);
            this.lblesugamnumber.TabIndex = 52;
            this.lblesugamnumber.Text = "Place Of Supply :";
            // 
            // txtapplicabletaxrate
            // 
            this.txtapplicabletaxrate.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtapplicabletaxrate.Location = new System.Drawing.Point(936, 139);
            this.txtapplicabletaxrate.MaxLength = 120;
            this.txtapplicabletaxrate.Name = "txtapplicabletaxrate";
            this.txtapplicabletaxrate.Size = new System.Drawing.Size(331, 23);
            this.txtapplicabletaxrate.TabIndex = 48;
            // 
            // txtvhiclenumber
            // 
            this.txtvhiclenumber.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtvhiclenumber.Location = new System.Drawing.Point(936, 43);
            this.txtvhiclenumber.MaxLength = 60;
            this.txtvhiclenumber.Name = "txtvhiclenumber";
            this.txtvhiclenumber.Size = new System.Drawing.Size(331, 23);
            this.txtvhiclenumber.TabIndex = 54;
            // 
            // txttransportcompany
            // 
            this.txttransportcompany.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttransportcompany.Location = new System.Drawing.Point(936, 108);
            this.txttransportcompany.MaxLength = 150;
            this.txttransportcompany.Name = "txttransportcompany";
            this.txttransportcompany.Size = new System.Drawing.Size(331, 23);
            this.txttransportcompany.TabIndex = 47;
            // 
            // txtplaceofsupply
            // 
            this.txtplaceofsupply.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtplaceofsupply.Location = new System.Drawing.Point(936, 75);
            this.txtplaceofsupply.MaxLength = 150;
            this.txtplaceofsupply.Name = "txtplaceofsupply";
            this.txtplaceofsupply.Size = new System.Drawing.Size(331, 23);
            this.txtplaceofsupply.TabIndex = 53;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.txttotal);
            this.panel1.Controls.Add(this.btnCustomer);
            this.panel1.Controls.Add(this.btnVendor);
            this.panel1.Controls.Add(this.cmbCustomerName);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.txtgstin);
            this.panel1.Controls.Add(this.txtcustomerstate);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.txtcustomerstatecode);
            this.panel1.Controls.Add(this.txtcustomeraddress);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.dtpDaterecieved);
            this.panel1.Location = new System.Drawing.Point(12, 264);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1284, 121);
            this.panel1.TabIndex = 77;
            // 
            // btnCustomer
            // 
            this.btnCustomer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCustomer.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustomer.Location = new System.Drawing.Point(3, 1);
            this.btnCustomer.Name = "btnCustomer";
            this.btnCustomer.Size = new System.Drawing.Size(84, 24);
            this.btnCustomer.TabIndex = 122;
            this.btnCustomer.Text = "Customer";
            this.btnCustomer.UseVisualStyleBackColor = false;
            // 
            // btnVendor
            // 
            this.btnVendor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnVendor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVendor.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVendor.Location = new System.Drawing.Point(3, 30);
            this.btnVendor.Name = "btnVendor";
            this.btnVendor.Size = new System.Drawing.Size(84, 25);
            this.btnVendor.TabIndex = 121;
            this.btnVendor.Text = "Vendor";
            this.btnVendor.UseVisualStyleBackColor = false;
            // 
            // cmbCustomerName
            // 
            this.cmbCustomerName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbCustomerName.DropDownHeight = 130;
            this.cmbCustomerName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCustomerName.FormattingEnabled = true;
            this.cmbCustomerName.IntegralHeight = false;
            this.cmbCustomerName.Location = new System.Drawing.Point(170, 6);
            this.cmbCustomerName.Name = "cmbCustomerName";
            this.cmbCustomerName.Size = new System.Drawing.Size(357, 26);
            this.cmbCustomerName.TabIndex = 74;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(533, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(199, 29);
            this.label5.TabIndex = 63;
            this.label5.Text = "Details of Reciever";
            // 
            // txtgstin
            // 
            this.txtgstin.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtgstin.Location = new System.Drawing.Point(797, 11);
            this.txtgstin.MaxLength = 20;
            this.txtgstin.Name = "txtgstin";
            this.txtgstin.Size = new System.Drawing.Size(212, 23);
            this.txtgstin.TabIndex = 73;
            // 
            // txtcustomerstate
            // 
            this.txtcustomerstate.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcustomerstate.Location = new System.Drawing.Point(797, 45);
            this.txtcustomerstate.MaxLength = 45;
            this.txtcustomerstate.Name = "txtcustomerstate";
            this.txtcustomerstate.Size = new System.Drawing.Size(212, 23);
            this.txtcustomerstate.TabIndex = 70;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(117, 10);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 15);
            this.label8.TabIndex = 64;
            this.label8.Text = "Name :";
            // 
            // txtcustomerstatecode
            // 
            this.txtcustomerstatecode.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcustomerstatecode.Location = new System.Drawing.Point(798, 78);
            this.txtcustomerstatecode.MaxLength = 15;
            this.txtcustomerstatecode.Name = "txtcustomerstatecode";
            this.txtcustomerstatecode.Size = new System.Drawing.Size(212, 23);
            this.txtcustomerstatecode.TabIndex = 69;
            // 
            // txtcustomeraddress
            // 
            this.txtcustomeraddress.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcustomeraddress.Location = new System.Drawing.Point(170, 45);
            this.txtcustomeraddress.Multiline = true;
            this.txtcustomeraddress.Name = "txtcustomeraddress";
            this.txtcustomeraddress.Size = new System.Drawing.Size(357, 66);
            this.txtcustomeraddress.TabIndex = 72;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(720, 81);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 15);
            this.label9.TabIndex = 68;
            this.label9.Text = "State Code :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(106, 45);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 15);
            this.label7.TabIndex = 65;
            this.label7.Text = "Address :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(751, 48);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(43, 15);
            this.label10.TabIndex = 67;
            this.label10.Text = "State :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(750, 14);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 15);
            this.label6.TabIndex = 66;
            this.label6.Text = "GSTIN :";
            // 
            // dtpDaterecieved
            // 
            this.dtpDaterecieved.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDaterecieved.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDaterecieved.Location = new System.Drawing.Point(402, 48);
            this.dtpDaterecieved.Name = "dtpDaterecieved";
            this.dtpDaterecieved.Size = new System.Drawing.Size(89, 26);
            this.dtpDaterecieved.TabIndex = 123;
            // 
            // dgvRecievedItems
            // 
            this.dgvRecievedItems.AllowUserToAddRows = false;
            this.dgvRecievedItems.AllowUserToOrderColumns = true;
            this.dgvRecievedItems.AllowUserToResizeRows = false;
            this.dgvRecievedItems.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvRecievedItems.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvRecievedItems.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvRecievedItems.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRecievedItems.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvRecievedItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRecievedItems.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn5,
            this.rRate,
            this.RemainingQty,
            this.RecievedQuantity});
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRecievedItems.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgvRecievedItems.Location = new System.Drawing.Point(12, 416);
            this.dgvRecievedItems.Name = "dgvRecievedItems";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRecievedItems.RowHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgvRecievedItems.RowHeadersVisible = false;
            this.dgvRecievedItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvRecievedItems.Size = new System.Drawing.Size(1284, 242);
            this.dgvRecievedItems.TabIndex = 127;
            this.dgvRecievedItems.Visible = false;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "SlNo";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewTextBoxColumn1.FillWeight = 56.85279F;
            this.dataGridViewTextBoxColumn1.HeaderText = "Sl No";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Width = 43;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn2.DataPropertyName = "DescriptionOfGoods";
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewTextBoxColumn2.FillWeight = 107.1912F;
            this.dataGridViewTextBoxColumn2.HeaderText = "Description Of Goods";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Quantity";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewTextBoxColumn5.FillWeight = 107.1912F;
            this.dataGridViewTextBoxColumn5.HeaderText = "Quantity";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn5.Width = 71;
            // 
            // rRate
            // 
            this.rRate.DataPropertyName = "Rate";
            this.rRate.HeaderText = "Rate";
            this.rRate.Name = "rRate";
            this.rRate.ReadOnly = true;
            this.rRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.rRate.Width = 45;
            // 
            // RemainingQty
            // 
            this.RemainingQty.DataPropertyName = "RemainigQuantity";
            this.RemainingQty.HeaderText = "Remaining Quantity";
            this.RemainingQty.Name = "RemainingQty";
            this.RemainingQty.ReadOnly = true;
            this.RemainingQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RemainingQty.Width = 130;
            // 
            // RecievedQuantity
            // 
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.LightGreen;
            this.RecievedQuantity.DefaultCellStyle = dataGridViewCellStyle5;
            this.RecievedQuantity.HeaderText = "Recieved Quantity";
            this.RecievedQuantity.Name = "RecievedQuantity";
            this.RecievedQuantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RecievedQuantity.Width = 121;
            // 
            // dgvpoitems
            // 
            this.dgvpoitems.AllowUserToAddRows = false;
            this.dgvpoitems.AllowUserToOrderColumns = true;
            this.dgvpoitems.AllowUserToResizeRows = false;
            this.dgvpoitems.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvpoitems.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvpoitems.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvpoitems.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvpoitems.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dgvpoitems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvpoitems.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Slno,
            this.ItemCode,
            this.DescriptionOfGoods,
            this.HsnSacCode,
            this.Unit,
            this.Quantity,
            this.Rate,
            this.Amount});
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvpoitems.DefaultCellStyle = dataGridViewCellStyle17;
            this.dgvpoitems.Location = new System.Drawing.Point(12, 396);
            this.dgvpoitems.Name = "dgvpoitems";
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvpoitems.RowHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.dgvpoitems.RowHeadersVisible = false;
            this.dgvpoitems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvpoitems.Size = new System.Drawing.Size(1284, 262);
            this.dgvpoitems.TabIndex = 126;
            // 
            // btnaddnewrow
            // 
            this.btnaddnewrow.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaddnewrow.Location = new System.Drawing.Point(134, 396);
            this.btnaddnewrow.Name = "btnaddnewrow";
            this.btnaddnewrow.Size = new System.Drawing.Size(114, 32);
            this.btnaddnewrow.TabIndex = 128;
            this.btnaddnewrow.Text = "Add New Row";
            this.btnaddnewrow.UseVisualStyleBackColor = true;
            // 
            // pnDCRecieve
            // 
            this.pnDCRecieve.Controls.Add(this.txtProject);
            this.pnDCRecieve.Controls.Add(this.label18);
            this.pnDCRecieve.Controls.Add(this.label19);
            this.pnDCRecieve.Controls.Add(this.txtDepartment);
            this.pnDCRecieve.Controls.Add(this.txtBillNumber);
            this.pnDCRecieve.Controls.Add(this.label16);
            this.pnDCRecieve.Location = new System.Drawing.Point(21, 664);
            this.pnDCRecieve.Name = "pnDCRecieve";
            this.pnDCRecieve.Size = new System.Drawing.Size(915, 44);
            this.pnDCRecieve.TabIndex = 129;
            this.pnDCRecieve.Visible = false;
            // 
            // txtProject
            // 
            this.txtProject.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProject.Location = new System.Drawing.Point(389, 9);
            this.txtProject.MaxLength = 150;
            this.txtProject.Name = "txtProject";
            this.txtProject.Size = new System.Drawing.Size(256, 23);
            this.txtProject.TabIndex = 70;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(324, 12);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(59, 15);
            this.label18.TabIndex = 67;
            this.label18.Text = "Project *:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(651, 12);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(82, 15);
            this.label19.TabIndex = 68;
            this.label19.Text = "Department :";
            // 
            // txtDepartment
            // 
            this.txtDepartment.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDepartment.Location = new System.Drawing.Point(739, 9);
            this.txtDepartment.MaxLength = 150;
            this.txtDepartment.Name = "txtDepartment";
            this.txtDepartment.Size = new System.Drawing.Size(167, 23);
            this.txtDepartment.TabIndex = 69;
            // 
            // txtBillNumber
            // 
            this.txtBillNumber.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBillNumber.Location = new System.Drawing.Point(62, 9);
            this.txtBillNumber.MaxLength = 150;
            this.txtBillNumber.Name = "txtBillNumber";
            this.txtBillNumber.Size = new System.Drawing.Size(256, 23);
            this.txtBillNumber.TabIndex = 66;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(1, 12);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(55, 15);
            this.label16.TabIndex = 63;
            this.label16.Text = "Bill No* :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(1022, 40);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(57, 23);
            this.label12.TabIndex = 125;
            this.label12.Text = "Total :";
            // 
            // txttotal
            // 
            this.txttotal.Enabled = false;
            this.txttotal.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttotal.Location = new System.Drawing.Point(1085, 40);
            this.txttotal.Name = "txttotal";
            this.txttotal.Size = new System.Drawing.Size(180, 23);
            this.txttotal.TabIndex = 124;
            // 
            // btnCancelDC
            // 
            this.btnCancelDC.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelDC.Location = new System.Drawing.Point(1065, 664);
            this.btnCancelDC.Name = "btnCancelDC";
            this.btnCancelDC.Size = new System.Drawing.Size(104, 35);
            this.btnCancelDC.TabIndex = 131;
            this.btnCancelDC.Text = "Cancel DC";
            this.btnCancelDC.UseVisualStyleBackColor = true;
            this.btnCancelDC.Visible = false;
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(1184, 664);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(95, 35);
            this.btnSave.TabIndex = 130;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.ForeColor = System.Drawing.Color.Black;
            this.label81.Location = new System.Drawing.Point(79, 9);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(84, 23);
            this.label81.TabIndex = 212;
            this.label81.Text = "Start DC :";
            // 
            // cmbSelectQuoteType
            // 
            this.cmbSelectQuoteType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbSelectQuoteType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectQuoteType.DropDownHeight = 90;
            this.cmbSelectQuoteType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSelectQuoteType.DropDownWidth = 150;
            this.cmbSelectQuoteType.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSelectQuoteType.FormattingEnabled = true;
            this.cmbSelectQuoteType.IntegralHeight = false;
            this.cmbSelectQuoteType.Items.AddRange(new object[] {
            "New DC",
            "Recieve DC",
            "Print DC"});
            this.cmbSelectQuoteType.Location = new System.Drawing.Point(169, 10);
            this.cmbSelectQuoteType.Name = "cmbSelectQuoteType";
            this.cmbSelectQuoteType.Size = new System.Drawing.Size(257, 26);
            this.cmbSelectQuoteType.TabIndex = 211;
            // 
            // comboBox1
            // 
            this.comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox1.DropDownHeight = 130;
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.IntegralHeight = false;
            this.comboBox1.Items.AddRange(new object[] {
            "PO",
            "WO",
            "Indent"});
            this.comboBox1.Location = new System.Drawing.Point(169, 148);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(101, 26);
            this.comboBox1.TabIndex = 213;
            this.comboBox1.Visible = false;
            // 
            // comboBox2
            // 
            this.comboBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox2.DropDownHeight = 130;
            this.comboBox2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.IntegralHeight = false;
            this.comboBox2.Location = new System.Drawing.Point(276, 148);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(194, 26);
            this.comboBox2.TabIndex = 214;
            this.comboBox2.Visible = false;
            // 
            // Slno
            // 
            this.Slno.DataPropertyName = "SlNo";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Slno.DefaultCellStyle = dataGridViewCellStyle9;
            this.Slno.FillWeight = 56.85279F;
            this.Slno.HeaderText = "Sl No";
            this.Slno.Name = "Slno";
            this.Slno.ReadOnly = true;
            this.Slno.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Slno.Width = 48;
            // 
            // ItemCode
            // 
            this.ItemCode.DataPropertyName = "ItemCode";
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.ItemCode.DefaultCellStyle = dataGridViewCellStyle10;
            this.ItemCode.HeaderText = "Item Code";
            this.ItemCode.Name = "ItemCode";
            this.ItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemCode.Width = 81;
            // 
            // DescriptionOfGoods
            // 
            this.DescriptionOfGoods.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.DescriptionOfGoods.DataPropertyName = "DescriptionOfGoods";
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.LightGreen;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DescriptionOfGoods.DefaultCellStyle = dataGridViewCellStyle11;
            this.DescriptionOfGoods.FillWeight = 107.1912F;
            this.DescriptionOfGoods.HeaderText = "Item Name";
            this.DescriptionOfGoods.Name = "DescriptionOfGoods";
            this.DescriptionOfGoods.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // HsnSacCode
            // 
            this.HsnSacCode.DataPropertyName = "HsnCode";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.LightGreen;
            this.HsnSacCode.DefaultCellStyle = dataGridViewCellStyle12;
            this.HsnSacCode.HeaderText = "HSN Code";
            this.HsnSacCode.Name = "HsnSacCode";
            this.HsnSacCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.HsnSacCode.Width = 79;
            // 
            // Unit
            // 
            this.Unit.DataPropertyName = "UOM";
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.LightGreen;
            this.Unit.DefaultCellStyle = dataGridViewCellStyle13;
            this.Unit.HeaderText = "UOM";
            this.Unit.Name = "Unit";
            this.Unit.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Unit.Width = 49;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "Quantity";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.LightGreen;
            this.Quantity.DefaultCellStyle = dataGridViewCellStyle14;
            this.Quantity.FillWeight = 107.1912F;
            this.Quantity.HeaderText = "Quantity";
            this.Quantity.Name = "Quantity";
            this.Quantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Quantity.Width = 71;
            // 
            // Rate
            // 
            this.Rate.DataPropertyName = "Rate";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.LightGreen;
            this.Rate.DefaultCellStyle = dataGridViewCellStyle15;
            this.Rate.FillWeight = 107.1912F;
            this.Rate.HeaderText = "Rate";
            this.Rate.Name = "Rate";
            this.Rate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Rate.Width = 45;
            // 
            // Amount
            // 
            this.Amount.DataPropertyName = "Amount";
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle16.NullValue = "0";
            this.Amount.DefaultCellStyle = dataGridViewCellStyle16;
            this.Amount.HeaderText = "Amount";
            this.Amount.Name = "Amount";
            this.Amount.ReadOnly = true;
            this.Amount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Amount.Width = 65;
            // 
            // frmDeliveryChallan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1308, 709);
            this.Controls.Add(this.btnCancelDC);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.pnDCRecieve);
            this.Controls.Add(this.btnaddnewrow);
            this.Controls.Add(this.dgvRecievedItems);
            this.Controls.Add(this.dgvpoitems);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmDeliveryChallan";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Delivery Challan";
            this.Load += new System.EventHandler(this.frmDeliveryChallan_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRecievedItems)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvpoitems)).EndInit();
            this.pnDCRecieve.ResumeLayout(false);
            this.pnDCRecieve.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnLoadPO;
        private System.Windows.Forms.ComboBox cmbDCType;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox cmbDeliverChallan;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtDcFor;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox txttransportmode;
        private System.Windows.Forms.DateTimePicker dtpDispachDate;
        private System.Windows.Forms.DateTimePicker dtpdateofchallan;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblnoanddescofpackages;
        private System.Windows.Forms.Label lblmodeofdispatch;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtslnoofchallan;
        private System.Windows.Forms.Label lbldatetimeofpreparation;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbltimedateofremoval;
        private System.Windows.Forms.Label lblnameofexcise;
        private System.Windows.Forms.TextBox txtRefNumber;
        private System.Windows.Forms.Label lblesugamnumber;
        private System.Windows.Forms.TextBox txtapplicabletaxrate;
        private System.Windows.Forms.TextBox txtvhiclenumber;
        private System.Windows.Forms.TextBox txttransportcompany;
        private System.Windows.Forms.TextBox txtplaceofsupply;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txttotal;
        private System.Windows.Forms.Button btnCustomer;
        private System.Windows.Forms.Button btnVendor;
        private System.Windows.Forms.ComboBox cmbCustomerName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtgstin;
        private System.Windows.Forms.TextBox txtcustomerstate;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtcustomerstatecode;
        private System.Windows.Forms.TextBox txtcustomeraddress;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dtpDaterecieved;
        private System.Windows.Forms.DataGridView dgvRecievedItems;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn rRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn RemainingQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn RecievedQuantity;
        private System.Windows.Forms.DataGridView dgvpoitems;
        private System.Windows.Forms.Button btnaddnewrow;
        private System.Windows.Forms.Panel pnDCRecieve;
        private System.Windows.Forms.TextBox txtProject;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtDepartment;
        private System.Windows.Forms.TextBox txtBillNumber;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button btnCancelDC;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.ComboBox cmbSelectQuoteType;
        private System.Windows.Forms.DataGridViewTextBoxColumn Slno;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn DescriptionOfGoods;
        private System.Windows.Forms.DataGridViewTextBoxColumn HsnSacCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn Unit;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn Rate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
    }
}