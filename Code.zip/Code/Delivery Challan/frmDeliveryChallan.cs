﻿using System;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Delivery_Challan
{
    public partial class frmDeliveryChallan : Form
    {

        DataAccessLayer DAL = new DataAccessLayer();
        Global GLobalClass = new Global();
        Login.frmLoginForm Login = new Login.frmLoginForm();

        public frmDeliveryChallan()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

        }

        private void frmDeliveryChallan_Load(object sender, EventArgs e)
        {

        }
    }
}
