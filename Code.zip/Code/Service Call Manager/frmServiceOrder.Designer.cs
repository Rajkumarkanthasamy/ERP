﻿
namespace Erp_Project_With_Buttons.Service_Call_Manager
{
    partial class frmServiceOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmServiceOrder));
            this.tabMaintenance = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label13 = new System.Windows.Forms.Label();
            this.txtSiteAddress = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtEmailMobile2 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.dtpDateofServiceOrder = new System.Windows.Forms.DateTimePicker();
            this.txtEnduser2 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtEmaliMobile1 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtEnduser1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtMobileno = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtGST = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtCustomerPhone = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTerracastCode = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTerritotyZonename = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtInvoicedoc = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtInvoiceto = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.lblSOBy = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.txtQuoteRef = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.txtBookingorderNo = new System.Windows.Forms.TextBox();
            this.txtOrderValue = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.txtVendorCode = new System.Windows.Forms.TextBox();
            this.btnStartOrder = new System.Windows.Forms.Button();
            this.txtPaymentterms = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.txtCustomerOrderref = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.txtCustomerAddress = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.cmbCustomerName = new System.Windows.Forms.ComboBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.txtBookingRecognition = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtSystemsCovered = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.cmbServiceProduct = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.dtpWeekMonth = new System.Windows.Forms.DateTimePicker();
            this.label20 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.dtpPeriodTo = new System.Windows.Forms.DateTimePicker();
            this.dtpPeriodFrom = new System.Windows.Forms.DateTimePicker();
            this.dgvSOItems = new System.Windows.Forms.DataGridView();
            this.label46 = new System.Windows.Forms.Label();
            this.btnGenrateServiceOrder = new System.Windows.Forms.Button();
            this.btnPrintOrder = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.cmbServiceOrderNo = new System.Windows.Forms.ComboBox();
            this.lblSONo = new System.Windows.Forms.Label();
            this.lblStartQuote = new System.Windows.Forms.Label();
            this.cmbSelectQuoteType = new System.Windows.Forms.ComboBox();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.chkQuoteSavePath = new System.Windows.Forms.CheckBox();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabMaintenance.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSOItems)).BeginInit();
            this.SuspendLayout();
            // 
            // tabMaintenance
            // 
            this.tabMaintenance.Controls.Add(this.tabPage3);
            this.tabMaintenance.Controls.Add(this.tabPage4);
            this.tabMaintenance.Enabled = false;
            this.tabMaintenance.ItemSize = new System.Drawing.Size(30, 18);
            this.tabMaintenance.Location = new System.Drawing.Point(12, 40);
            this.tabMaintenance.Name = "tabMaintenance";
            this.tabMaintenance.SelectedIndex = 0;
            this.tabMaintenance.Size = new System.Drawing.Size(1294, 591);
            this.tabMaintenance.TabIndex = 242;
            this.tabMaintenance.Visible = false;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Silver;
            this.tabPage3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPage3.Controls.Add(this.label13);
            this.tabPage3.Controls.Add(this.txtSiteAddress);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Controls.Add(this.txtEmailMobile2);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.label39);
            this.tabPage3.Controls.Add(this.dtpDateofServiceOrder);
            this.tabPage3.Controls.Add(this.txtEnduser2);
            this.tabPage3.Controls.Add(this.label8);
            this.tabPage3.Controls.Add(this.txtEmaliMobile1);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.txtEnduser1);
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.txtMobileno);
            this.tabPage3.Controls.Add(this.label7);
            this.tabPage3.Controls.Add(this.txtEmail);
            this.tabPage3.Controls.Add(this.txtGST);
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Controls.Add(this.txtCustomerPhone);
            this.tabPage3.Controls.Add(this.label4);
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Controls.Add(this.txtTerracastCode);
            this.tabPage3.Controls.Add(this.label2);
            this.tabPage3.Controls.Add(this.txtTerritotyZonename);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.txtInvoicedoc);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.txtInvoiceto);
            this.tabPage3.Controls.Add(this.label26);
            this.tabPage3.Controls.Add(this.lblSOBy);
            this.tabPage3.Controls.Add(this.label32);
            this.tabPage3.Controls.Add(this.textBox7);
            this.tabPage3.Controls.Add(this.txtQuoteRef);
            this.tabPage3.Controls.Add(this.label33);
            this.tabPage3.Controls.Add(this.label35);
            this.tabPage3.Controls.Add(this.txtBookingorderNo);
            this.tabPage3.Controls.Add(this.txtOrderValue);
            this.tabPage3.Controls.Add(this.label37);
            this.tabPage3.Controls.Add(this.txtVendorCode);
            this.tabPage3.Controls.Add(this.btnStartOrder);
            this.tabPage3.Controls.Add(this.txtPaymentterms);
            this.tabPage3.Controls.Add(this.label41);
            this.tabPage3.Controls.Add(this.txtCustomerOrderref);
            this.tabPage3.Controls.Add(this.label42);
            this.tabPage3.Controls.Add(this.label43);
            this.tabPage3.Controls.Add(this.txtCustomerAddress);
            this.tabPage3.Controls.Add(this.label44);
            this.tabPage3.Controls.Add(this.cmbCustomerName);
            this.tabPage3.ForeColor = System.Drawing.Color.Black;
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1286, 565);
            this.tabPage3.TabIndex = 0;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(766, 437);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(92, 18);
            this.label13.TabIndex = 274;
            this.label13.Text = "Site Address :";
            // 
            // txtSiteAddress
            // 
            this.txtSiteAddress.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtSiteAddress.Location = new System.Drawing.Point(862, 419);
            this.txtSiteAddress.Multiline = true;
            this.txtSiteAddress.Name = "txtSiteAddress";
            this.txtSiteAddress.Size = new System.Drawing.Size(343, 97);
            this.txtSiteAddress.TabIndex = 273;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(766, 367);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 18);
            this.label9.TabIndex = 272;
            this.label9.Text = "Email / Mob :";
            // 
            // txtEmailMobile2
            // 
            this.txtEmailMobile2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtEmailMobile2.Location = new System.Drawing.Point(862, 364);
            this.txtEmailMobile2.Multiline = true;
            this.txtEmailMobile2.Name = "txtEmailMobile2";
            this.txtEmailMobile2.Size = new System.Drawing.Size(343, 49);
            this.txtEmailMobile2.TabIndex = 271;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(776, 317);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(80, 18);
            this.label11.TabIndex = 270;
            this.label11.Text = "End User 2 :";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label39.ForeColor = System.Drawing.Color.Black;
            this.label39.Location = new System.Drawing.Point(1082, 4);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(54, 18);
            this.label39.TabIndex = 267;
            this.label39.Text = "Date * :";
            // 
            // dtpDateofServiceOrder
            // 
            this.dtpDateofServiceOrder.CustomFormat = "";
            this.dtpDateofServiceOrder.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDateofServiceOrder.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDateofServiceOrder.Location = new System.Drawing.Point(1145, -2);
            this.dtpDateofServiceOrder.Name = "dtpDateofServiceOrder";
            this.dtpDateofServiceOrder.Size = new System.Drawing.Size(104, 26);
            this.dtpDateofServiceOrder.TabIndex = 266;
            // 
            // txtEnduser2
            // 
            this.txtEnduser2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtEnduser2.Location = new System.Drawing.Point(862, 314);
            this.txtEnduser2.Name = "txtEnduser2";
            this.txtEnduser2.Size = new System.Drawing.Size(343, 26);
            this.txtEnduser2.TabIndex = 269;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(766, 252);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 18);
            this.label8.TabIndex = 268;
            this.label8.Text = "Email / Mob :";
            // 
            // txtEmaliMobile1
            // 
            this.txtEmaliMobile1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtEmaliMobile1.Location = new System.Drawing.Point(862, 249);
            this.txtEmaliMobile1.Multiline = true;
            this.txtEmaliMobile1.Name = "txtEmaliMobile1";
            this.txtEmaliMobile1.Size = new System.Drawing.Size(343, 49);
            this.txtEmaliMobile1.TabIndex = 267;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(776, 210);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(80, 18);
            this.label10.TabIndex = 264;
            this.label10.Text = "End User 1 :";
            // 
            // txtEnduser1
            // 
            this.txtEnduser1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtEnduser1.Location = new System.Drawing.Point(862, 207);
            this.txtEnduser1.Name = "txtEnduser1";
            this.txtEnduser1.Size = new System.Drawing.Size(343, 26);
            this.txtEnduser1.TabIndex = 263;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(812, 127);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 18);
            this.label6.TabIndex = 262;
            this.label6.Text = "Mob :";
            // 
            // txtMobileno
            // 
            this.txtMobileno.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtMobileno.Location = new System.Drawing.Point(862, 122);
            this.txtMobileno.Name = "txtMobileno";
            this.txtMobileno.Size = new System.Drawing.Size(343, 26);
            this.txtMobileno.TabIndex = 261;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(807, 172);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 18);
            this.label7.TabIndex = 260;
            this.label7.Text = "Email :";
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtEmail.Location = new System.Drawing.Point(862, 164);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(343, 26);
            this.txtEmail.TabIndex = 259;
            // 
            // txtGST
            // 
            this.txtGST.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtGST.Location = new System.Drawing.Point(229, 322);
            this.txtGST.MaxLength = 80;
            this.txtGST.Name = "txtGST";
            this.txtGST.Size = new System.Drawing.Size(343, 26);
            this.txtGST.TabIndex = 257;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(168, 325);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 18);
            this.label5.TabIndex = 258;
            this.label5.Text = "GST :";
            // 
            // txtCustomerPhone
            // 
            this.txtCustomerPhone.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtCustomerPhone.Location = new System.Drawing.Point(229, 351);
            this.txtCustomerPhone.MaxLength = 80;
            this.txtCustomerPhone.Name = "txtCustomerPhone";
            this.txtCustomerPhone.Size = new System.Drawing.Size(343, 26);
            this.txtCustomerPhone.TabIndex = 255;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(168, 354);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 18);
            this.label4.TabIndex = 256;
            this.label4.Text = "Phone :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(48, 98);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(170, 18);
            this.label3.TabIndex = 254;
            this.label3.Text = "Tesseract Customer Code :";
            // 
            // txtTerracastCode
            // 
            this.txtTerracastCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtTerracastCode.Location = new System.Drawing.Point(229, 95);
            this.txtTerracastCode.Name = "txtTerracastCode";
            this.txtTerracastCode.Size = new System.Drawing.Size(343, 26);
            this.txtTerracastCode.TabIndex = 253;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(67, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(151, 18);
            this.label2.TabIndex = 252;
            this.label2.Text = "Territory / Zone Name :";
            // 
            // txtTerritotyZonename
            // 
            this.txtTerritotyZonename.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtTerritotyZonename.Location = new System.Drawing.Point(229, 58);
            this.txtTerritotyZonename.Name = "txtTerritotyZonename";
            this.txtTerritotyZonename.Size = new System.Drawing.Size(343, 26);
            this.txtTerritotyZonename.TabIndex = 251;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(771, 40);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(85, 18);
            this.label12.TabIndex = 250;
            this.label12.Text = "Invoice doc :";
            // 
            // txtInvoicedoc
            // 
            this.txtInvoicedoc.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtInvoicedoc.Location = new System.Drawing.Point(862, 37);
            this.txtInvoicedoc.Name = "txtInvoicedoc";
            this.txtInvoicedoc.Size = new System.Drawing.Size(343, 26);
            this.txtInvoicedoc.TabIndex = 249;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(782, 83);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(76, 18);
            this.label16.TabIndex = 248;
            this.label16.Text = "Invoice to :";
            // 
            // txtInvoiceto
            // 
            this.txtInvoiceto.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtInvoiceto.Location = new System.Drawing.Point(862, 80);
            this.txtInvoiceto.Name = "txtInvoiceto";
            this.txtInvoiceto.Size = new System.Drawing.Size(343, 26);
            this.txtInvoiceto.TabIndex = 247;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label26.ForeColor = System.Drawing.Color.Black;
            this.label26.Location = new System.Drawing.Point(101, 130);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(95, 18);
            this.label26.TabIndex = 231;
            this.label26.Text = "Vendor Code :";
            // 
            // lblSOBy
            // 
            this.lblSOBy.AutoSize = true;
            this.lblSOBy.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSOBy.ForeColor = System.Drawing.Color.Red;
            this.lblSOBy.Location = new System.Drawing.Point(869, 3);
            this.lblSOBy.Name = "lblSOBy";
            this.lblSOBy.Size = new System.Drawing.Size(0, 19);
            this.lblSOBy.TabIndex = 227;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.Black;
            this.label32.Location = new System.Drawing.Point(725, 5);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(131, 19);
            this.label32.TabIndex = 226;
            this.label32.Text = "Service Order By :";
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.textBox7.Location = new System.Drawing.Point(586, 169);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(20, 26);
            this.textBox7.TabIndex = 199;
            this.textBox7.Visible = false;
            // 
            // txtQuoteRef
            // 
            this.txtQuoteRef.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtQuoteRef.Location = new System.Drawing.Point(229, 422);
            this.txtQuoteRef.Name = "txtQuoteRef";
            this.txtQuoteRef.Size = new System.Drawing.Size(343, 26);
            this.txtQuoteRef.TabIndex = 21;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label33.ForeColor = System.Drawing.Color.Black;
            this.label33.Location = new System.Drawing.Point(73, 425);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(145, 18);
            this.label33.TabIndex = 195;
            this.label33.Text = "Quotation Reference :";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label35.ForeColor = System.Drawing.Color.Black;
            this.label35.Location = new System.Drawing.Point(60, 25);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(158, 18);
            this.label35.TabIndex = 189;
            this.label35.Text = "Booking Order Number :";
            // 
            // txtBookingorderNo
            // 
            this.txtBookingorderNo.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtBookingorderNo.Location = new System.Drawing.Point(229, 22);
            this.txtBookingorderNo.Name = "txtBookingorderNo";
            this.txtBookingorderNo.Size = new System.Drawing.Size(343, 26);
            this.txtBookingorderNo.TabIndex = 12;
            // 
            // txtOrderValue
            // 
            this.txtOrderValue.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtOrderValue.Location = new System.Drawing.Point(229, 529);
            this.txtOrderValue.Name = "txtOrderValue";
            this.txtOrderValue.Size = new System.Drawing.Size(343, 26);
            this.txtOrderValue.TabIndex = 20;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label37.ForeColor = System.Drawing.Color.Black;
            this.label37.Location = new System.Drawing.Point(101, 537);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(122, 18);
            this.label37.TabIndex = 127;
            this.label37.Text = "Total Order Value :";
            // 
            // txtVendorCode
            // 
            this.txtVendorCode.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtVendorCode.Location = new System.Drawing.Point(229, 127);
            this.txtVendorCode.Name = "txtVendorCode";
            this.txtVendorCode.Size = new System.Drawing.Size(343, 26);
            this.txtVendorCode.TabIndex = 9;
            // 
            // btnStartOrder
            // 
            this.btnStartOrder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnStartOrder.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnStartOrder.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStartOrder.Location = new System.Drawing.Point(1140, 522);
            this.btnStartOrder.Name = "btnStartOrder";
            this.btnStartOrder.Size = new System.Drawing.Size(144, 33);
            this.btnStartOrder.TabIndex = 23;
            this.btnStartOrder.Text = "Start Order";
            this.btnStartOrder.UseVisualStyleBackColor = false;
            this.btnStartOrder.Click += new System.EventHandler(this.btnStartOrder_Click);
            // 
            // txtPaymentterms
            // 
            this.txtPaymentterms.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtPaymentterms.Location = new System.Drawing.Point(229, 463);
            this.txtPaymentterms.Multiline = true;
            this.txtPaymentterms.Name = "txtPaymentterms";
            this.txtPaymentterms.Size = new System.Drawing.Size(343, 56);
            this.txtPaymentterms.TabIndex = 19;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label41.ForeColor = System.Drawing.Color.Black;
            this.label41.Location = new System.Drawing.Point(108, 466);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(110, 18);
            this.label41.TabIndex = 98;
            this.label41.Text = "Payment Terms :";
            // 
            // txtCustomerOrderref
            // 
            this.txtCustomerOrderref.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtCustomerOrderref.Location = new System.Drawing.Point(229, 385);
            this.txtCustomerOrderref.MaxLength = 80;
            this.txtCustomerOrderref.Name = "txtCustomerOrderref";
            this.txtCustomerOrderref.Size = new System.Drawing.Size(343, 26);
            this.txtCustomerOrderref.TabIndex = 18;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label42.ForeColor = System.Drawing.Color.Black;
            this.label42.Location = new System.Drawing.Point(138, 172);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(85, 18);
            this.label42.TabIndex = 92;
            this.label42.Text = "Customer * :";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label43.ForeColor = System.Drawing.Color.Black;
            this.label43.Location = new System.Drawing.Point(42, 388);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(181, 18);
            this.label43.TabIndex = 96;
            this.label43.Text = "Customer Order Reference :";
            // 
            // txtCustomerAddress
            // 
            this.txtCustomerAddress.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtCustomerAddress.Location = new System.Drawing.Point(229, 201);
            this.txtCustomerAddress.Multiline = true;
            this.txtCustomerAddress.Name = "txtCustomerAddress";
            this.txtCustomerAddress.Size = new System.Drawing.Size(343, 115);
            this.txtCustomerAddress.TabIndex = 16;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label44.ForeColor = System.Drawing.Color.Black;
            this.label44.Location = new System.Drawing.Point(158, 215);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(65, 18);
            this.label44.TabIndex = 94;
            this.label44.Text = "Address :";
            // 
            // cmbCustomerName
            // 
            this.cmbCustomerName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbCustomerName.DropDownHeight = 90;
            this.cmbCustomerName.DropDownWidth = 150;
            this.cmbCustomerName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCustomerName.FormattingEnabled = true;
            this.cmbCustomerName.IntegralHeight = false;
            this.cmbCustomerName.Location = new System.Drawing.Point(229, 169);
            this.cmbCustomerName.Name = "cmbCustomerName";
            this.cmbCustomerName.Size = new System.Drawing.Size(343, 26);
            this.cmbCustomerName.TabIndex = 15;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.Silver;
            this.tabPage4.Controls.Add(this.dgvSOItems);
            this.tabPage4.Controls.Add(this.txtDescription);
            this.tabPage4.Controls.Add(this.button2);
            this.tabPage4.Controls.Add(this.txtBookingRecognition);
            this.tabPage4.Controls.Add(this.label15);
            this.tabPage4.Controls.Add(this.txtSystemsCovered);
            this.tabPage4.Controls.Add(this.label14);
            this.tabPage4.Controls.Add(this.cmbServiceProduct);
            this.tabPage4.Controls.Add(this.label24);
            this.tabPage4.Controls.Add(this.dtpWeekMonth);
            this.tabPage4.Controls.Add(this.label20);
            this.tabPage4.Controls.Add(this.label22);
            this.tabPage4.Controls.Add(this.label29);
            this.tabPage4.Controls.Add(this.dtpPeriodTo);
            this.tabPage4.Controls.Add(this.dtpPeriodFrom);
            this.tabPage4.Controls.Add(this.label46);
            this.tabPage4.Controls.Add(this.btnGenrateServiceOrder);
            this.tabPage4.Controls.Add(this.btnPrintOrder);
            this.tabPage4.Controls.Add(this.button5);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1286, 565);
            this.tabPage4.TabIndex = 1;
            // 
            // txtDescription
            // 
            this.txtDescription.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtDescription.Location = new System.Drawing.Point(198, 137);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(602, 84);
            this.txtDescription.TabIndex = 305;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(1169, 244);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(106, 28);
            this.button2.TabIndex = 304;
            this.button2.Text = "Add Item";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // txtBookingRecognition
            // 
            this.txtBookingRecognition.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtBookingRecognition.Location = new System.Drawing.Point(198, 85);
            this.txtBookingRecognition.Name = "txtBookingRecognition";
            this.txtBookingRecognition.Size = new System.Drawing.Size(343, 26);
            this.txtBookingRecognition.TabIndex = 284;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(651, 41);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(115, 18);
            this.label15.TabIndex = 283;
            this.label15.Text = "System Covered :";
            // 
            // txtSystemsCovered
            // 
            this.txtSystemsCovered.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtSystemsCovered.Location = new System.Drawing.Point(772, 38);
            this.txtSystemsCovered.Name = "txtSystemsCovered";
            this.txtSystemsCovered.Size = new System.Drawing.Size(343, 26);
            this.txtSystemsCovered.TabIndex = 282;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(106, 137);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(86, 18);
            this.label14.TabIndex = 281;
            this.label14.Text = "Description :";
            // 
            // cmbServiceProduct
            // 
            this.cmbServiceProduct.DropDownHeight = 60;
            this.cmbServiceProduct.DropDownWidth = 150;
            this.cmbServiceProduct.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbServiceProduct.FormattingEnabled = true;
            this.cmbServiceProduct.IntegralHeight = false;
            this.cmbServiceProduct.ItemHeight = 18;
            this.cmbServiceProduct.Items.AddRange(new object[] {
            "INR",
            "USD"});
            this.cmbServiceProduct.Location = new System.Drawing.Point(179, 3);
            this.cmbServiceProduct.Name = "cmbServiceProduct";
            this.cmbServiceProduct.Size = new System.Drawing.Size(222, 26);
            this.cmbServiceProduct.TabIndex = 278;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Black;
            this.label24.Location = new System.Drawing.Point(62, 8);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(111, 18);
            this.label24.TabIndex = 279;
            this.label24.Text = "Service Product :";
            // 
            // dtpWeekMonth
            // 
            this.dtpWeekMonth.CustomFormat = "";
            this.dtpWeekMonth.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpWeekMonth.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpWeekMonth.Location = new System.Drawing.Point(243, 53);
            this.dtpWeekMonth.Name = "dtpWeekMonth";
            this.dtpWeekMonth.Size = new System.Drawing.Size(104, 26);
            this.dtpWeekMonth.TabIndex = 274;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(26, 53);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(205, 18);
            this.label20.TabIndex = 275;
            this.label20.Text = "Week/Month Orider is booked :";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label22.ForeColor = System.Drawing.Color.Black;
            this.label22.Location = new System.Drawing.Point(675, 85);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(91, 18);
            this.label22.TabIndex = 273;
            this.label22.Text = "Period  From:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label29.ForeColor = System.Drawing.Color.Black;
            this.label29.Location = new System.Drawing.Point(879, 84);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(29, 18);
            this.label29.TabIndex = 271;
            this.label29.Text = "To :";
            // 
            // dtpPeriodTo
            // 
            this.dtpPeriodTo.CustomFormat = "";
            this.dtpPeriodTo.Enabled = false;
            this.dtpPeriodTo.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpPeriodTo.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpPeriodTo.Location = new System.Drawing.Point(914, 85);
            this.dtpPeriodTo.Name = "dtpPeriodTo";
            this.dtpPeriodTo.Size = new System.Drawing.Size(93, 26);
            this.dtpPeriodTo.TabIndex = 270;
            // 
            // dtpPeriodFrom
            // 
            this.dtpPeriodFrom.CustomFormat = "";
            this.dtpPeriodFrom.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpPeriodFrom.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpPeriodFrom.Location = new System.Drawing.Point(770, 83);
            this.dtpPeriodFrom.Name = "dtpPeriodFrom";
            this.dtpPeriodFrom.Size = new System.Drawing.Size(93, 26);
            this.dtpPeriodFrom.TabIndex = 269;
            // 
            // dgvSOItems
            // 
            this.dgvSOItems.AllowUserToAddRows = false;
            this.dgvSOItems.AllowUserToOrderColumns = true;
            this.dgvSOItems.AllowUserToResizeRows = false;
            this.dgvSOItems.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvSOItems.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvSOItems.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvSOItems.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSOItems.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvSOItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSOItems.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11});
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSOItems.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgvSOItems.Location = new System.Drawing.Point(21, 278);
            this.dgvSOItems.Name = "dgvSOItems";
            this.dgvSOItems.RowHeadersVisible = false;
            this.dgvSOItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvSOItems.Size = new System.Drawing.Size(1254, 222);
            this.dgvSOItems.TabIndex = 306;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label46.ForeColor = System.Drawing.Color.Black;
            this.label46.Location = new System.Drawing.Point(50, 85);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(142, 18);
            this.label46.TabIndex = 259;
            this.label46.Text = "Booking Recognition :";
            // 
            // btnGenrateServiceOrder
            // 
            this.btnGenrateServiceOrder.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnGenrateServiceOrder.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenrateServiceOrder.Location = new System.Drawing.Point(773, 515);
            this.btnGenrateServiceOrder.Name = "btnGenrateServiceOrder";
            this.btnGenrateServiceOrder.Size = new System.Drawing.Size(245, 37);
            this.btnGenrateServiceOrder.TabIndex = 255;
            this.btnGenrateServiceOrder.Text = "Generate Service Order";
            this.btnGenrateServiceOrder.UseVisualStyleBackColor = false;
            this.btnGenrateServiceOrder.Click += new System.EventHandler(this.btnGenrateServiceOrder_Click);
            // 
            // btnPrintOrder
            // 
            this.btnPrintOrder.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnPrintOrder.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrintOrder.Location = new System.Drawing.Point(1070, 516);
            this.btnPrintOrder.Name = "btnPrintOrder";
            this.btnPrintOrder.Size = new System.Drawing.Size(157, 37);
            this.btnPrintOrder.TabIndex = 254;
            this.btnPrintOrder.Text = "Print Quote";
            this.btnPrintOrder.UseVisualStyleBackColor = false;
            this.btnPrintOrder.Click += new System.EventHandler(this.btnPrintOrder_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button5.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold);
            this.button5.Location = new System.Drawing.Point(6, 521);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(124, 35);
            this.button5.TabIndex = 137;
            this.button5.Text = "Back";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // cmbServiceOrderNo
            // 
            this.cmbServiceOrderNo.DropDownHeight = 80;
            this.cmbServiceOrderNo.DropDownWidth = 150;
            this.cmbServiceOrderNo.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbServiceOrderNo.FormattingEnabled = true;
            this.cmbServiceOrderNo.IntegralHeight = false;
            this.cmbServiceOrderNo.ItemHeight = 18;
            this.cmbServiceOrderNo.Location = new System.Drawing.Point(822, 12);
            this.cmbServiceOrderNo.Name = "cmbServiceOrderNo";
            this.cmbServiceOrderNo.Size = new System.Drawing.Size(167, 26);
            this.cmbServiceOrderNo.TabIndex = 245;
            this.cmbServiceOrderNo.Visible = false;
            this.cmbServiceOrderNo.SelectedIndexChanged += new System.EventHandler(this.cmbServiceOrderNo_SelectedIndexChanged);
            // 
            // lblSONo
            // 
            this.lblSONo.AutoSize = true;
            this.lblSONo.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.lblSONo.ForeColor = System.Drawing.Color.Black;
            this.lblSONo.Location = new System.Drawing.Point(610, 14);
            this.lblSONo.Name = "lblSONo";
            this.lblSONo.Size = new System.Drawing.Size(206, 23);
            this.lblSONo.TabIndex = 246;
            this.lblSONo.Text = "Service Order Number* :";
            this.lblSONo.Visible = false;
            // 
            // lblStartQuote
            // 
            this.lblStartQuote.AutoSize = true;
            this.lblStartQuote.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStartQuote.ForeColor = System.Drawing.Color.Black;
            this.lblStartQuote.Location = new System.Drawing.Point(66, 11);
            this.lblStartQuote.Name = "lblStartQuote";
            this.lblStartQuote.Size = new System.Drawing.Size(184, 23);
            this.lblStartQuote.TabIndex = 244;
            this.lblStartQuote.Text = "Start Service Order * :";
            // 
            // cmbSelectQuoteType
            // 
            this.cmbSelectQuoteType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbSelectQuoteType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectQuoteType.DropDownHeight = 90;
            this.cmbSelectQuoteType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSelectQuoteType.DropDownWidth = 150;
            this.cmbSelectQuoteType.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSelectQuoteType.FormattingEnabled = true;
            this.cmbSelectQuoteType.IntegralHeight = false;
            this.cmbSelectQuoteType.Items.AddRange(new object[] {
            "New",
            "Update"});
            this.cmbSelectQuoteType.Location = new System.Drawing.Point(256, 9);
            this.cmbSelectQuoteType.Name = "cmbSelectQuoteType";
            this.cmbSelectQuoteType.Size = new System.Drawing.Size(167, 26);
            this.cmbSelectQuoteType.TabIndex = 243;
            this.cmbSelectQuoteType.SelectedIndexChanged += new System.EventHandler(this.cmbSelectQuoteType_SelectedIndexChanged);
            // 
            // chkQuoteSavePath
            // 
            this.chkQuoteSavePath.AutoSize = true;
            this.chkQuoteSavePath.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkQuoteSavePath.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.chkQuoteSavePath.Location = new System.Drawing.Point(1048, 14);
            this.chkQuoteSavePath.Name = "chkQuoteSavePath";
            this.chkQuoteSavePath.Size = new System.Drawing.Size(219, 27);
            this.chkQuoteSavePath.TabIndex = 247;
            this.chkQuoteSavePath.Text = "Service Order Save Path";
            this.chkQuoteSavePath.UseVisualStyleBackColor = true;
            this.chkQuoteSavePath.CheckedChanged += new System.EventHandler(this.chkQuoteSavePath_CheckedChanged);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn1.DataPropertyName = "OE No";
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewTextBoxColumn1.HeaderText = "OE No";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Scope of Service";
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewTextBoxColumn2.FillWeight = 140F;
            this.dataGridViewTextBoxColumn2.HeaderText = "Scope of Service";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn2.Width = 140;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Schedule";
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewTextBoxColumn3.HeaderText = "Schedule";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 96;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Call Type";
            this.dataGridViewTextBoxColumn4.HeaderText = "Call Type";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 87;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "No Of Days";
            this.dataGridViewTextBoxColumn5.HeaderText = "No Of Days";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 101;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Points";
            this.dataGridViewTextBoxColumn6.HeaderText = "Points";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 77;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Mode";
            this.dataGridViewTextBoxColumn7.HeaderText = "Mode";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Width = 74;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Transducer";
            this.dataGridViewTextBoxColumn8.HeaderText = "Transducer";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.Width = 109;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Type";
            this.dataGridViewTextBoxColumn9.HeaderText = "Type";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.Width = 67;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Order Value";
            this.dataGridViewTextBoxColumn10.HeaderText = "Order Value";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.Width = 105;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "billable";
            this.dataGridViewTextBoxColumn11.HeaderText = "Billable";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.Width = 84;
            // 
            // frmServiceOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1303, 663);
            this.Controls.Add(this.chkQuoteSavePath);
            this.Controls.Add(this.cmbServiceOrderNo);
            this.Controls.Add(this.lblSONo);
            this.Controls.Add(this.lblStartQuote);
            this.Controls.Add(this.cmbSelectQuoteType);
            this.Controls.Add(this.tabMaintenance);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmServiceOrder";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Service Order";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmServiceOrder_FormClosing);
            this.Load += new System.EventHandler(this.frmServiceOrder_Load);
            this.tabMaintenance.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSOItems)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabMaintenance;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtInvoicedoc;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtInvoiceto;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label lblSOBy;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox txtQuoteRef;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox txtBookingorderNo;
        private System.Windows.Forms.TextBox txtOrderValue;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txtVendorCode;
        private System.Windows.Forms.Button btnStartOrder;
        private System.Windows.Forms.TextBox txtPaymentterms;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox txtCustomerOrderref;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox txtCustomerAddress;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.ComboBox cmbCustomerName;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Button btnGenrateServiceOrder;
        private System.Windows.Forms.Button btnPrintOrder;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtSiteAddress;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtEmailMobile2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtEnduser2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtEmaliMobile1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtEnduser1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtMobileno;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtGST;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtCustomerPhone;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtTerracastCode;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtTerritotyZonename;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txtBookingRecognition;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtSystemsCovered;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox cmbServiceProduct;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.DateTimePicker dtpWeekMonth;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.DateTimePicker dtpPeriodTo;
        private System.Windows.Forms.DateTimePicker dtpPeriodFrom;
        private System.Windows.Forms.DateTimePicker dtpDateofServiceOrder;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.ComboBox cmbServiceOrderNo;
        private System.Windows.Forms.Label lblSONo;
        private System.Windows.Forms.Label lblStartQuote;
        private System.Windows.Forms.ComboBox cmbSelectQuoteType;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.DataGridView dgvSOItems;
        private System.Windows.Forms.CheckBox chkQuoteSavePath;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
    }
}