﻿using System;
using System.Data;
using System.Windows.Forms;
using EXCEL = Microsoft.Office.Interop.Excel;

namespace Erp_Project_With_Buttons.Service_Call_Manager
{
    public partial class frmServiceOrderNew : Form
    {
        public frmServiceOrderNew()
        {
            InitializeComponent();
        }

        frmForm2 form = new frmForm2();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();

        #region CellMerge Funtion
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "ThickBorder":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "GridLines":
                    {
                        CELLS.Borders.Color = System.Drawing.Color.Black;
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignCenter":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                        break;
                    }

                case "WrapText":
                    {
                        CELLS.WrapText = true;
                        break;
                    }

                case "AlignRight":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                        break;
                    }
                case "AlignLeft":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignLeft;
                        break;
                    }
                case "TextAlign":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignJustify;
                        break;
                    }
                case "AlignTop":
                    {
                        CELLS.VerticalAlignment = EXCEL.XlVAlign.xlVAlignTop;
                        break;
                    }
                case "VAlignCenter":
                    {
                        CELLS.VerticalAlignment = EXCEL.XlVAlign.xlVAlignCenter;
                        break;
                    }

                case "Bold":
                    {
                        CELLS.Font.Bold = true;
                        break;
                    }

                case "Autofit":
                    {
                        CELLS.Rows.AutoFit();
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

        }
        #endregion

        #region Excel App Release Object Function
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
        #endregion

        private void btnPrintOrder_Click(object sender, EventArgs e)
        {

        }

        private void frmServiceOrderNew_Load(object sender, EventArgs e)
        {

        }

        private void btnStartOrder_Click(object sender, EventArgs e)
        {
            if (cmbCustomerName.SelectedIndex >= 0)
            {

            }
            else
            {
                if (cmbCustomerName.SelectedIndex < 0)
                {
                    MessageBox.Show("Please select customer", "Error", 0, MessageBoxIcon.Error);
                    cmbCustomerName.DroppedDown = true;
                }
            }
        }

        DataTable dtLoadServiceOrder = new DataTable();
        DataTable dtLoadServiceOrderNo = new DataTable();
        DataTable dtLoadServiceOrderDetails = new DataTable();

        private void cmbSelectQuoteType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbSelectQuoteType.SelectedIndex >= 0)
            {
                tabMaintenance.Enabled = true;
                lblSONo.Visible = false;
                cmbServiceOrderNo.Visible = false;
                tabMaintenance.Visible = true;
            }

            if (cmbSelectQuoteType.SelectedIndex > 0)
            {
                dtLoadServiceOrderNo = DAL.fnServiceOrderData(0, "").Tables[0];
                foreach (DataRow DR in dtLoadServiceOrderNo.Rows)
                {
                    if (!cmbServiceOrderNo.Items.Contains(DR["BookingOrderNumber"].ToString()))
                        cmbServiceOrderNo.Items.Add(DR["BookingOrderNumber"].ToString());
                }
                lblSONo.Visible = true;
                cmbServiceOrderNo.Visible = true;

            }
        }

        private void cmbServiceOrderNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtLoadServiceOrder = DAL.fnServiceOrderData(1, cmbServiceOrderNo.Text).Tables[0];
            if (dtLoadServiceOrder.Rows.Count > 0)
            {
                txtBookingorderNo.Text = dtLoadServiceOrder.Rows[0][0].ToString();
                txtTerritotyZonename.Text = dtLoadServiceOrder.Rows[0][1].ToString();
                txtTerracastCode.Text = dtLoadServiceOrder.Rows[0][2].ToString();
                txtVendorCode.Text = dtLoadServiceOrder.Rows[0][3].ToString();
                cmbCustomerName.Text = dtLoadServiceOrder.Rows[0][4].ToString();
                txtCustomerAddress.Text = dtLoadServiceOrder.Rows[0][5].ToString();
                txtGST.Text = dtLoadServiceOrder.Rows[0][6].ToString();
                txtCustomerPhone.Text = dtLoadServiceOrder.Rows[0][7].ToString();
                txtCustomerOrderref.Text = dtLoadServiceOrder.Rows[0][8].ToString();
                txtQuoteRef.Text = dtLoadServiceOrder.Rows[0][9].ToString();
                txtPaymentterms.Text = dtLoadServiceOrder.Rows[0][10].ToString();
                txtOrderValue.Text = dtLoadServiceOrder.Rows[0][11].ToString();
                txtInvoicedoc.Text = dtLoadServiceOrder.Rows[0][12].ToString();
                txtInvoiceto.Text = dtLoadServiceOrder.Rows[0][13].ToString();
                txtMobileno.Text = dtLoadServiceOrder.Rows[0][14].ToString();
                txtEmail.Text = dtLoadServiceOrder.Rows[0][15].ToString();
                txtEnduser1.Text = dtLoadServiceOrder.Rows[0][16].ToString();
                txtEmaliMobile1.Text = dtLoadServiceOrder.Rows[0][17].ToString();
                txtEnduser2.Text = dtLoadServiceOrder.Rows[0][18].ToString();
                txtEmailMobile2.Text = dtLoadServiceOrder.Rows[0][19].ToString();
                txtSiteAddress.Text = dtLoadServiceOrder.Rows[0][20].ToString();
                cmbServiceProduct.Text = dtLoadServiceOrder.Rows[0][21].ToString();
                //dtpWeekMonth.Text = dtLoadServiceOrder.Rows[0][22].ToString();
                txtBookingRecognition.Text = dtLoadServiceOrder.Rows[0][23].ToString();
                txtDescription.Text = dtLoadServiceOrder.Rows[0][24].ToString();
                txtSystemsCovered.Text = dtLoadServiceOrder.Rows[0][25].ToString();
                //dtpPeriodFrom.Text = dtLoadServiceOrder.Rows[0][26].ToString();
                //dtpPeriodTo.Text = dtLoadServiceOrder.Rows[0][27].ToString();
                lblSOBy.Text = dtLoadServiceOrder.Rows[0][28].ToString();
                //dtpDateofServiceOrder.Text = dtLoadServiceOrder.Rows[0][29].ToString();
            }

            dtLoadServiceOrderDetails = DAL.fnServiceOrderData(2, cmbServiceOrderNo.Text).Tables[0];
            if (dtLoadServiceOrderDetails.Rows.Count > 0)
            {
                //dgvServiceOrderItems.AutoGenerateColumns = false;
                //dgvServiceOrderItems.DataSource = dtLoadServiceOrderDetails;
            }
        }

        private void dgvServiceOrderItems_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {

        }
    }
}
