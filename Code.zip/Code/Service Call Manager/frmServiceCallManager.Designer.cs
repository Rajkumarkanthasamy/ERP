﻿
namespace Erp_Project_With_Buttons.Service_Call_Manager
{
    partial class frmServiceCallManager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmServiceCallManager));
            this.tabCalibration = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.cmbCeastAMC = new System.Windows.Forms.ComboBox();
            this.label64 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.cmbContractYears = new System.Windows.Forms.ComboBox();
            this.cmbEnquireCurrency = new System.Windows.Forms.ComboBox();
            this.lblcustomer = new System.Windows.Forms.Label();
            this.cmbQuoteCompany = new System.Windows.Forms.ComboBox();
            this.label67 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dtpContractto = new System.Windows.Forms.DateTimePicker();
            this.dtpContractfrom = new System.Windows.Forms.DateTimePicker();
            this.lblQuoteBy = new System.Windows.Forms.Label();
            this.lblQuotebyin = new System.Windows.Forms.Label();
            this.txtCusCode = new System.Windows.Forms.TextBox();
            this.txtEmailID = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.txtZone = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txtCusref = new System.Windows.Forms.TextBox();
            this.txtTel = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.txtModelslno = new System.Windows.Forms.TextBox();
            this.btnStartQuote = new System.Windows.Forms.Button();
            this.dtpEnquireDate = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.txtContactNumber = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtContactPerson = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbCustomer = new System.Windows.Forms.ComboBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.pnCeast = new System.Windows.Forms.Panel();
            this.btnCeastAdditem = new System.Windows.Forms.Button();
            this.dgvCeastContract = new System.Windows.Forms.DataGridView();
            this.InstrumentDetails = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtGrandTotal = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtDiscount = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.btnGenarateQuote = new System.Windows.Forms.Button();
            this.btnFinQuote = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.txtpaymentterms = new System.Windows.Forms.TextBox();
            this.txtbreakdownvistcharges = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.btnBack1 = new System.Windows.Forms.Button();
            this.pnAMC = new System.Windows.Forms.Panel();
            this.label47 = new System.Windows.Forms.Label();
            this.btnAddrow = new System.Windows.Forms.Button();
            this.txtContractValue = new System.Windows.Forms.TextBox();
            this.chk3Years = new System.Windows.Forms.CheckBox();
            this.chk5Years = new System.Windows.Forms.CheckBox();
            this.dgvContract = new System.Windows.Forms.DataGridView();
            this.ContractValue1stYear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ContractValue2ndYear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ContractValue3rdYear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ContractValue4thYear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ContractValue5thYear = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Scope = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cmbQuotetype = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblStartQuote = new System.Windows.Forms.Label();
            this.cmbSelectQuoteType = new System.Windows.Forms.ComboBox();
            this.tabMaintenance = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label20 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.label24 = new System.Windows.Forms.Label();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.dateTimePicker5 = new System.Windows.Forms.DateTimePicker();
            this.label39 = new System.Windows.Forms.Label();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.cmbServiceOrderNo = new System.Windows.Forms.ComboBox();
            this.lblSONo = new System.Windows.Forms.Label();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.tabCalibration.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.pnCeast.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCeastContract)).BeginInit();
            this.pnAMC.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContract)).BeginInit();
            this.tabMaintenance.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabCalibration
            // 
            this.tabCalibration.Controls.Add(this.tabPage1);
            this.tabCalibration.Controls.Add(this.tabPage2);
            this.tabCalibration.ItemSize = new System.Drawing.Size(30, 18);
            this.tabCalibration.Location = new System.Drawing.Point(12, 40);
            this.tabCalibration.Name = "tabCalibration";
            this.tabCalibration.SelectedIndex = 0;
            this.tabCalibration.Size = new System.Drawing.Size(1294, 591);
            this.tabCalibration.TabIndex = 213;
            this.tabCalibration.Visible = false;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Silver;
            this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.textBox3);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.textBox2);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Controls.Add(this.comboBox1);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.dateTimePicker1);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.cmbCeastAMC);
            this.tabPage1.Controls.Add(this.label64);
            this.tabPage1.Controls.Add(this.label63);
            this.tabPage1.Controls.Add(this.cmbContractYears);
            this.tabPage1.Controls.Add(this.cmbEnquireCurrency);
            this.tabPage1.Controls.Add(this.lblcustomer);
            this.tabPage1.Controls.Add(this.cmbQuoteCompany);
            this.tabPage1.Controls.Add(this.label67);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.dtpContractto);
            this.tabPage1.Controls.Add(this.dtpContractfrom);
            this.tabPage1.Controls.Add(this.lblQuoteBy);
            this.tabPage1.Controls.Add(this.lblQuotebyin);
            this.tabPage1.Controls.Add(this.txtCusCode);
            this.tabPage1.Controls.Add(this.txtEmailID);
            this.tabPage1.Controls.Add(this.label40);
            this.tabPage1.Controls.Add(this.label30);
            this.tabPage1.Controls.Add(this.txtZone);
            this.tabPage1.Controls.Add(this.label27);
            this.tabPage1.Controls.Add(this.txtCusref);
            this.tabPage1.Controls.Add(this.txtTel);
            this.tabPage1.Controls.Add(this.label34);
            this.tabPage1.Controls.Add(this.label28);
            this.tabPage1.Controls.Add(this.txtModelslno);
            this.tabPage1.Controls.Add(this.btnStartQuote);
            this.tabPage1.Controls.Add(this.dtpEnquireDate);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.txtContactNumber);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.txtContactPerson);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.txtAddress);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.cmbCustomer);
            this.tabPage1.ForeColor = System.Drawing.Color.Black;
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1286, 565);
            this.tabPage1.TabIndex = 0;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(806, 209);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(50, 18);
            this.label15.TabIndex = 250;
            this.label15.Text = "Value :";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.textBox3.Location = new System.Drawing.Point(859, 209);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(133, 26);
            this.textBox3.TabIndex = 249;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(806, 124);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(44, 18);
            this.label14.TabIndex = 248;
            this.label14.Text = "CALL :";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.textBox2.Location = new System.Drawing.Point(859, 124);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(133, 26);
            this.textBox2.TabIndex = 247;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(750, 83);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(100, 18);
            this.label9.TabIndex = 246;
            this.label9.Text = "Certificate No :";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.textBox1.Location = new System.Drawing.Point(859, 80);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(133, 26);
            this.textBox1.TabIndex = 245;
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownHeight = 60;
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.DropDownWidth = 150;
            this.comboBox1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.IntegralHeight = false;
            this.comboBox1.ItemHeight = 18;
            this.comboBox1.Items.AddRange(new object[] {
            "BiSS-ITW",
            "INSTRON"});
            this.comboBox1.Location = new System.Drawing.Point(152, 307);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(222, 26);
            this.comboBox1.TabIndex = 243;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(28, 307);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(116, 18);
            this.label13.TabIndex = 244;
            this.label13.Text = "Equipment Type :";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "";
            this.dateTimePicker1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(127, 63);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(104, 26);
            this.dateTimePicker1.TabIndex = 241;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(9, 64);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(109, 18);
            this.label11.TabIndex = 242;
            this.label11.Text = "SOE Due Date * :";
            // 
            // cmbCeastAMC
            // 
            this.cmbCeastAMC.DropDownHeight = 60;
            this.cmbCeastAMC.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCeastAMC.DropDownWidth = 150;
            this.cmbCeastAMC.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCeastAMC.FormattingEnabled = true;
            this.cmbCeastAMC.IntegralHeight = false;
            this.cmbCeastAMC.ItemHeight = 18;
            this.cmbCeastAMC.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbCeastAMC.Location = new System.Drawing.Point(839, 380);
            this.cmbCeastAMC.Name = "cmbCeastAMC";
            this.cmbCeastAMC.Size = new System.Drawing.Size(222, 26);
            this.cmbCeastAMC.TabIndex = 239;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.ForeColor = System.Drawing.Color.Black;
            this.label64.Location = new System.Drawing.Point(717, 383);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(103, 18);
            this.label64.TabIndex = 240;
            this.label64.Text = "Payment Type :";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label63.ForeColor = System.Drawing.Color.Black;
            this.label63.Location = new System.Drawing.Point(32, 102);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(86, 18);
            this.label63.TabIndex = 238;
            this.label63.Text = "Start Date * :";
            // 
            // cmbContractYears
            // 
            this.cmbContractYears.DropDownHeight = 60;
            this.cmbContractYears.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbContractYears.DropDownWidth = 150;
            this.cmbContractYears.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbContractYears.FormattingEnabled = true;
            this.cmbContractYears.IntegralHeight = false;
            this.cmbContractYears.ItemHeight = 18;
            this.cmbContractYears.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.cmbContractYears.Location = new System.Drawing.Point(313, 102);
            this.cmbContractYears.Name = "cmbContractYears";
            this.cmbContractYears.Size = new System.Drawing.Size(61, 26);
            this.cmbContractYears.TabIndex = 237;
            // 
            // cmbEnquireCurrency
            // 
            this.cmbEnquireCurrency.DropDownHeight = 60;
            this.cmbEnquireCurrency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEnquireCurrency.DropDownWidth = 150;
            this.cmbEnquireCurrency.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbEnquireCurrency.FormattingEnabled = true;
            this.cmbEnquireCurrency.IntegralHeight = false;
            this.cmbEnquireCurrency.ItemHeight = 18;
            this.cmbEnquireCurrency.Items.AddRange(new object[] {
            "INR",
            "USD"});
            this.cmbEnquireCurrency.Location = new System.Drawing.Point(839, 299);
            this.cmbEnquireCurrency.Name = "cmbEnquireCurrency";
            this.cmbEnquireCurrency.Size = new System.Drawing.Size(222, 26);
            this.cmbEnquireCurrency.TabIndex = 235;
            // 
            // lblcustomer
            // 
            this.lblcustomer.AutoSize = true;
            this.lblcustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcustomer.ForeColor = System.Drawing.Color.Black;
            this.lblcustomer.Location = new System.Drawing.Point(756, 302);
            this.lblcustomer.Name = "lblcustomer";
            this.lblcustomer.Size = new System.Drawing.Size(69, 18);
            this.lblcustomer.TabIndex = 236;
            this.lblcustomer.Text = "Billable? :";
            // 
            // cmbQuoteCompany
            // 
            this.cmbQuoteCompany.DropDownHeight = 60;
            this.cmbQuoteCompany.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbQuoteCompany.DropDownWidth = 150;
            this.cmbQuoteCompany.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbQuoteCompany.FormattingEnabled = true;
            this.cmbQuoteCompany.IntegralHeight = false;
            this.cmbQuoteCompany.ItemHeight = 18;
            this.cmbQuoteCompany.Items.AddRange(new object[] {
            "BiSS-ITW",
            "INSTRON"});
            this.cmbQuoteCompany.Location = new System.Drawing.Point(839, 336);
            this.cmbQuoteCompany.Name = "cmbQuoteCompany";
            this.cmbQuoteCompany.Size = new System.Drawing.Size(222, 26);
            this.cmbQuoteCompany.TabIndex = 233;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.ForeColor = System.Drawing.Color.Black;
            this.label67.Location = new System.Drawing.Point(749, 339);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(71, 18);
            this.label67.TabIndex = 234;
            this.label67.Text = "Call Type :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(12, 342);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(110, 18);
            this.label7.TabIndex = 231;
            this.label7.Text = "Model Number :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(380, 107);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 18);
            this.label4.TabIndex = 230;
            this.label4.Text = "END  Date * :";
            // 
            // dtpContractto
            // 
            this.dtpContractto.CustomFormat = "";
            this.dtpContractto.Enabled = false;
            this.dtpContractto.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpContractto.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpContractto.Location = new System.Drawing.Point(467, 102);
            this.dtpContractto.Name = "dtpContractto";
            this.dtpContractto.Size = new System.Drawing.Size(93, 26);
            this.dtpContractto.TabIndex = 229;
            // 
            // dtpContractfrom
            // 
            this.dtpContractfrom.CustomFormat = "";
            this.dtpContractfrom.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpContractfrom.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpContractfrom.Location = new System.Drawing.Point(127, 100);
            this.dtpContractfrom.Name = "dtpContractfrom";
            this.dtpContractfrom.Size = new System.Drawing.Size(93, 26);
            this.dtpContractfrom.TabIndex = 228;
            // 
            // lblQuoteBy
            // 
            this.lblQuoteBy.AutoSize = true;
            this.lblQuoteBy.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuoteBy.ForeColor = System.Drawing.Color.Red;
            this.lblQuoteBy.Location = new System.Drawing.Point(858, 3);
            this.lblQuoteBy.Name = "lblQuoteBy";
            this.lblQuoteBy.Size = new System.Drawing.Size(0, 19);
            this.lblQuoteBy.TabIndex = 227;
            // 
            // lblQuotebyin
            // 
            this.lblQuotebyin.AutoSize = true;
            this.lblQuotebyin.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuotebyin.ForeColor = System.Drawing.Color.Black;
            this.lblQuotebyin.Location = new System.Drawing.Point(775, 3);
            this.lblQuotebyin.Name = "lblQuotebyin";
            this.lblQuotebyin.Size = new System.Drawing.Size(62, 19);
            this.lblQuotebyin.TabIndex = 226;
            this.lblQuotebyin.Text = "Call By :";
            // 
            // txtCusCode
            // 
            this.txtCusCode.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtCusCode.Location = new System.Drawing.Point(467, 155);
            this.txtCusCode.Name = "txtCusCode";
            this.txtCusCode.Size = new System.Drawing.Size(20, 26);
            this.txtCusCode.TabIndex = 199;
            this.txtCusCode.Visible = false;
            // 
            // txtEmailID
            // 
            this.txtEmailID.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtEmailID.Location = new System.Drawing.Point(152, 432);
            this.txtEmailID.Name = "txtEmailID";
            this.txtEmailID.Size = new System.Drawing.Size(343, 26);
            this.txtEmailID.TabIndex = 21;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label40.ForeColor = System.Drawing.Color.Black;
            this.label40.Location = new System.Drawing.Point(74, 438);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(78, 18);
            this.label40.TabIndex = 195;
            this.label40.Text = "CAPACITY  :";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label30.ForeColor = System.Drawing.Color.Black;
            this.label30.Location = new System.Drawing.Point(60, 25);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(61, 18);
            this.label30.TabIndex = 189;
            this.label30.Text = "Region : ";
            // 
            // txtZone
            // 
            this.txtZone.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtZone.Location = new System.Drawing.Point(127, 22);
            this.txtZone.Name = "txtZone";
            this.txtZone.Size = new System.Drawing.Size(343, 26);
            this.txtZone.TabIndex = 12;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label27.ForeColor = System.Drawing.Color.Black;
            this.label27.Location = new System.Drawing.Point(794, 47);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(56, 18);
            this.label27.TabIndex = 187;
            this.label27.Text = "SITE ID :";
            // 
            // txtCusref
            // 
            this.txtCusref.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtCusref.Location = new System.Drawing.Point(859, 44);
            this.txtCusref.Name = "txtCusref";
            this.txtCusref.Size = new System.Drawing.Size(133, 26);
            this.txtCusref.TabIndex = 11;
            // 
            // txtTel
            // 
            this.txtTel.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtTel.Location = new System.Drawing.Point(152, 515);
            this.txtTel.Name = "txtTel";
            this.txtTel.Size = new System.Drawing.Size(343, 26);
            this.txtTel.TabIndex = 20;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label34.ForeColor = System.Drawing.Color.Black;
            this.label34.Location = new System.Drawing.Point(113, 518);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(42, 18);
            this.label34.TabIndex = 127;
            this.label34.Text = "Pots :";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label28.ForeColor = System.Drawing.Color.Black;
            this.label28.Location = new System.Drawing.Point(226, 105);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(81, 18);
            this.label28.TabIndex = 117;
            this.label28.Text = "No Of Year :";
            // 
            // txtModelslno
            // 
            this.txtModelslno.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtModelslno.Location = new System.Drawing.Point(152, 339);
            this.txtModelslno.Name = "txtModelslno";
            this.txtModelslno.Size = new System.Drawing.Size(179, 26);
            this.txtModelslno.TabIndex = 9;
            // 
            // btnStartQuote
            // 
            this.btnStartQuote.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnStartQuote.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnStartQuote.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStartQuote.Location = new System.Drawing.Point(1062, 492);
            this.btnStartQuote.Name = "btnStartQuote";
            this.btnStartQuote.Size = new System.Drawing.Size(154, 45);
            this.btnStartQuote.TabIndex = 23;
            this.btnStartQuote.Text = "Start Quote";
            this.btnStartQuote.UseVisualStyleBackColor = false;
            // 
            // dtpEnquireDate
            // 
            this.dtpEnquireDate.CustomFormat = "";
            this.dtpEnquireDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpEnquireDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpEnquireDate.Location = new System.Drawing.Point(859, 166);
            this.dtpEnquireDate.Name = "dtpEnquireDate";
            this.dtpEnquireDate.Size = new System.Drawing.Size(104, 26);
            this.dtpEnquireDate.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(796, 172);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 18);
            this.label10.TabIndex = 104;
            this.label10.Text = "Date * :";
            // 
            // txtContactNumber
            // 
            this.txtContactNumber.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtContactNumber.Location = new System.Drawing.Point(152, 473);
            this.txtContactNumber.Name = "txtContactNumber";
            this.txtContactNumber.Size = new System.Drawing.Size(343, 26);
            this.txtContactNumber.TabIndex = 19;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(80, 476);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 18);
            this.label6.TabIndex = 98;
            this.label6.Text = "Purpose :";
            // 
            // txtContactPerson
            // 
            this.txtContactPerson.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtContactPerson.Location = new System.Drawing.Point(152, 385);
            this.txtContactPerson.MaxLength = 80;
            this.txtContactPerson.Name = "txtContactPerson";
            this.txtContactPerson.Size = new System.Drawing.Size(343, 26);
            this.txtContactPerson.TabIndex = 18;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(27, 158);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 18);
            this.label2.TabIndex = 92;
            this.label2.Text = "Customer * :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(33, 388);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(135, 18);
            this.label5.TabIndex = 96;
            this.label5.Text = "Transducer CatNum :";
            // 
            // txtAddress
            // 
            this.txtAddress.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtAddress.Location = new System.Drawing.Point(118, 197);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(343, 86);
            this.txtAddress.TabIndex = 16;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(47, 200);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 18);
            this.label3.TabIndex = 94;
            this.label3.Text = "Address :";
            // 
            // cmbCustomer
            // 
            this.cmbCustomer.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbCustomer.DropDownHeight = 90;
            this.cmbCustomer.DropDownWidth = 150;
            this.cmbCustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbCustomer.FormattingEnabled = true;
            this.cmbCustomer.IntegralHeight = false;
            this.cmbCustomer.Location = new System.Drawing.Point(118, 155);
            this.cmbCustomer.Name = "cmbCustomer";
            this.cmbCustomer.Size = new System.Drawing.Size(343, 26);
            this.cmbCustomer.TabIndex = 15;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Silver;
            this.tabPage2.Controls.Add(this.pnCeast);
            this.tabPage2.Controls.Add(this.txtGrandTotal);
            this.tabPage2.Controls.Add(this.label23);
            this.tabPage2.Controls.Add(this.txtDiscount);
            this.tabPage2.Controls.Add(this.label19);
            this.tabPage2.Controls.Add(this.btnGenarateQuote);
            this.tabPage2.Controls.Add(this.btnFinQuote);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.txtpaymentterms);
            this.tabPage2.Controls.Add(this.txtbreakdownvistcharges);
            this.tabPage2.Controls.Add(this.label53);
            this.tabPage2.Controls.Add(this.btnBack1);
            this.tabPage2.Controls.Add(this.pnAMC);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1286, 565);
            this.tabPage2.TabIndex = 1;
            // 
            // pnCeast
            // 
            this.pnCeast.Controls.Add(this.btnCeastAdditem);
            this.pnCeast.Controls.Add(this.dgvCeastContract);
            this.pnCeast.Location = new System.Drawing.Point(10, 7);
            this.pnCeast.Name = "pnCeast";
            this.pnCeast.Size = new System.Drawing.Size(1257, 285);
            this.pnCeast.TabIndex = 263;
            // 
            // btnCeastAdditem
            // 
            this.btnCeastAdditem.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnCeastAdditem.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCeastAdditem.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCeastAdditem.Location = new System.Drawing.Point(779, 9);
            this.btnCeastAdditem.Name = "btnCeastAdditem";
            this.btnCeastAdditem.Size = new System.Drawing.Size(106, 28);
            this.btnCeastAdditem.TabIndex = 304;
            this.btnCeastAdditem.Text = "Add Item";
            this.btnCeastAdditem.UseVisualStyleBackColor = false;
            // 
            // dgvCeastContract
            // 
            this.dgvCeastContract.AllowUserToAddRows = false;
            this.dgvCeastContract.AllowUserToOrderColumns = true;
            this.dgvCeastContract.AllowUserToResizeRows = false;
            this.dgvCeastContract.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvCeastContract.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvCeastContract.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvCeastContract.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCeastContract.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvCeastContract.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCeastContract.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.InstrumentDetails,
            this.UnitPrice,
            this.Quantity,
            this.Amount});
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCeastContract.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgvCeastContract.Location = new System.Drawing.Point(8, 9);
            this.dgvCeastContract.Name = "dgvCeastContract";
            this.dgvCeastContract.RowHeadersVisible = false;
            this.dgvCeastContract.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvCeastContract.Size = new System.Drawing.Size(1225, 261);
            this.dgvCeastContract.TabIndex = 303;
            // 
            // InstrumentDetails
            // 
            this.InstrumentDetails.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.InstrumentDetails.DataPropertyName = "Instrument Details";
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.InstrumentDetails.DefaultCellStyle = dataGridViewCellStyle2;
            this.InstrumentDetails.HeaderText = "Instrument Details";
            this.InstrumentDetails.Name = "InstrumentDetails";
            this.InstrumentDetails.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // UnitPrice
            // 
            this.UnitPrice.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.UnitPrice.DataPropertyName = "Unit Price";
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.UnitPrice.DefaultCellStyle = dataGridViewCellStyle3;
            this.UnitPrice.FillWeight = 140F;
            this.UnitPrice.HeaderText = "Unit Price";
            this.UnitPrice.Name = "UnitPrice";
            this.UnitPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitPrice.Width = 140;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "Quantity";
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Quantity.DefaultCellStyle = dataGridViewCellStyle4;
            this.Quantity.HeaderText = "Quantity";
            this.Quantity.Name = "Quantity";
            this.Quantity.Width = 94;
            // 
            // Amount
            // 
            this.Amount.DataPropertyName = "Amount";
            this.Amount.HeaderText = "Amount";
            this.Amount.Name = "Amount";
            this.Amount.ReadOnly = true;
            this.Amount.Width = 90;
            // 
            // txtGrandTotal
            // 
            this.txtGrandTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGrandTotal.Location = new System.Drawing.Point(175, 354);
            this.txtGrandTotal.Name = "txtGrandTotal";
            this.txtGrandTotal.ReadOnly = true;
            this.txtGrandTotal.Size = new System.Drawing.Size(142, 22);
            this.txtGrandTotal.TabIndex = 263;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label23.ForeColor = System.Drawing.Color.Black;
            this.label23.Location = new System.Drawing.Point(83, 356);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(86, 18);
            this.label23.TabIndex = 264;
            this.label23.Text = "Grand Total :";
            // 
            // txtDiscount
            // 
            this.txtDiscount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiscount.Location = new System.Drawing.Point(175, 314);
            this.txtDiscount.Name = "txtDiscount";
            this.txtDiscount.Size = new System.Drawing.Size(93, 22);
            this.txtDiscount.TabIndex = 258;
            this.txtDiscount.Text = "0";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(86, 314);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(83, 18);
            this.label19.TabIndex = 259;
            this.label19.Text = "Discount % :";
            // 
            // btnGenarateQuote
            // 
            this.btnGenarateQuote.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnGenarateQuote.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenarateQuote.Location = new System.Drawing.Point(854, 515);
            this.btnGenarateQuote.Name = "btnGenarateQuote";
            this.btnGenarateQuote.Size = new System.Drawing.Size(164, 37);
            this.btnGenarateQuote.TabIndex = 255;
            this.btnGenarateQuote.Text = "Generate Quote";
            this.btnGenarateQuote.UseVisualStyleBackColor = false;
            // 
            // btnFinQuote
            // 
            this.btnFinQuote.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.btnFinQuote.Enabled = false;
            this.btnFinQuote.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFinQuote.Location = new System.Drawing.Point(1070, 516);
            this.btnFinQuote.Name = "btnFinQuote";
            this.btnFinQuote.Size = new System.Drawing.Size(157, 37);
            this.btnFinQuote.TabIndex = 254;
            this.btnFinQuote.Text = "Print Quote";
            this.btnFinQuote.UseVisualStyleBackColor = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(286, 316);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(110, 18);
            this.label8.TabIndex = 253;
            this.label8.Text = "Payment Terms :";
            // 
            // txtpaymentterms
            // 
            this.txtpaymentterms.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpaymentterms.Location = new System.Drawing.Point(402, 305);
            this.txtpaymentterms.Multiline = true;
            this.txtpaymentterms.Name = "txtpaymentterms";
            this.txtpaymentterms.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtpaymentterms.Size = new System.Drawing.Size(857, 188);
            this.txtpaymentterms.TabIndex = 248;
            // 
            // txtbreakdownvistcharges
            // 
            this.txtbreakdownvistcharges.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbreakdownvistcharges.Location = new System.Drawing.Point(176, 393);
            this.txtbreakdownvistcharges.Name = "txtbreakdownvistcharges";
            this.txtbreakdownvistcharges.Size = new System.Drawing.Size(142, 22);
            this.txtbreakdownvistcharges.TabIndex = 251;
            this.txtbreakdownvistcharges.Text = "0";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label53.ForeColor = System.Drawing.Color.Black;
            this.label53.Location = new System.Drawing.Point(1, 393);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(168, 18);
            this.label53.TabIndex = 252;
            this.label53.Text = "Breakdown Visit Charges :";
            // 
            // btnBack1
            // 
            this.btnBack1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnBack1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnBack1.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold);
            this.btnBack1.Location = new System.Drawing.Point(6, 521);
            this.btnBack1.Name = "btnBack1";
            this.btnBack1.Size = new System.Drawing.Size(124, 35);
            this.btnBack1.TabIndex = 137;
            this.btnBack1.Text = "Back";
            this.btnBack1.UseVisualStyleBackColor = false;
            // 
            // pnAMC
            // 
            this.pnAMC.Controls.Add(this.label47);
            this.pnAMC.Controls.Add(this.btnAddrow);
            this.pnAMC.Controls.Add(this.txtContractValue);
            this.pnAMC.Controls.Add(this.chk3Years);
            this.pnAMC.Controls.Add(this.chk5Years);
            this.pnAMC.Controls.Add(this.dgvContract);
            this.pnAMC.Location = new System.Drawing.Point(9, 6);
            this.pnAMC.Name = "pnAMC";
            this.pnAMC.Size = new System.Drawing.Size(1271, 287);
            this.pnAMC.TabIndex = 265;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label47.Location = new System.Drawing.Point(6, 10);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(174, 18);
            this.label47.TabIndex = 248;
            this.label47.Text = "Contract Value increase % :";
            // 
            // btnAddrow
            // 
            this.btnAddrow.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAddrow.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAddrow.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddrow.Location = new System.Drawing.Point(1128, 32);
            this.btnAddrow.Name = "btnAddrow";
            this.btnAddrow.Size = new System.Drawing.Size(106, 28);
            this.btnAddrow.TabIndex = 250;
            this.btnAddrow.Text = "Add Item";
            this.btnAddrow.UseVisualStyleBackColor = false;
            // 
            // txtContractValue
            // 
            this.txtContractValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContractValue.Location = new System.Drawing.Point(180, 10);
            this.txtContractValue.Name = "txtContractValue";
            this.txtContractValue.Size = new System.Drawing.Size(37, 22);
            this.txtContractValue.TabIndex = 262;
            this.txtContractValue.Text = "7.5";
            // 
            // chk3Years
            // 
            this.chk3Years.AutoSize = true;
            this.chk3Years.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk3Years.ForeColor = System.Drawing.Color.Black;
            this.chk3Years.Location = new System.Drawing.Point(268, 3);
            this.chk3Years.Name = "chk3Years";
            this.chk3Years.Size = new System.Drawing.Size(162, 27);
            this.chk3Years.TabIndex = 260;
            this.chk3Years.Text = "Apply for 3 Years";
            this.chk3Years.UseVisualStyleBackColor = true;
            // 
            // chk5Years
            // 
            this.chk5Years.AutoSize = true;
            this.chk5Years.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk5Years.ForeColor = System.Drawing.Color.Black;
            this.chk5Years.Location = new System.Drawing.Point(485, 3);
            this.chk5Years.Name = "chk5Years";
            this.chk5Years.Size = new System.Drawing.Size(162, 27);
            this.chk5Years.TabIndex = 261;
            this.chk5Years.Text = "Apply for 5 Years";
            this.chk5Years.UseVisualStyleBackColor = true;
            // 
            // dgvContract
            // 
            this.dgvContract.AllowUserToAddRows = false;
            this.dgvContract.AllowUserToOrderColumns = true;
            this.dgvContract.AllowUserToResizeRows = false;
            this.dgvContract.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvContract.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvContract.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvContract.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvContract.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvContract.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvContract.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ContractValue1stYear,
            this.ContractValue2ndYear,
            this.ContractValue3rdYear,
            this.ContractValue4thYear,
            this.ContractValue5thYear,
            this.Scope});
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvContract.DefaultCellStyle = dataGridViewCellStyle7;
            this.dgvContract.Location = new System.Drawing.Point(3, 32);
            this.dgvContract.Name = "dgvContract";
            this.dgvContract.RowHeadersVisible = false;
            this.dgvContract.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvContract.Size = new System.Drawing.Size(1255, 249);
            this.dgvContract.TabIndex = 249;
            // 
            // ContractValue1stYear
            // 
            this.ContractValue1stYear.DataPropertyName = "1st Year";
            this.ContractValue1stYear.HeaderText = "1st Year";
            this.ContractValue1stYear.Name = "ContractValue1stYear";
            this.ContractValue1stYear.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ContractValue1stYear.Width = 68;
            // 
            // ContractValue2ndYear
            // 
            this.ContractValue2ndYear.DataPropertyName = "2nd Year";
            this.ContractValue2ndYear.HeaderText = "2nd Year";
            this.ContractValue2ndYear.Name = "ContractValue2ndYear";
            this.ContractValue2ndYear.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ContractValue2ndYear.Width = 74;
            // 
            // ContractValue3rdYear
            // 
            this.ContractValue3rdYear.DataPropertyName = "3rd Year";
            this.ContractValue3rdYear.HeaderText = "3rd Year";
            this.ContractValue3rdYear.Name = "ContractValue3rdYear";
            this.ContractValue3rdYear.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ContractValue3rdYear.Width = 71;
            // 
            // ContractValue4thYear
            // 
            this.ContractValue4thYear.DataPropertyName = "4th Year";
            this.ContractValue4thYear.HeaderText = "4th Year";
            this.ContractValue4thYear.Name = "ContractValue4thYear";
            this.ContractValue4thYear.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ContractValue4thYear.Width = 71;
            // 
            // ContractValue5thYear
            // 
            this.ContractValue5thYear.DataPropertyName = "5th Year";
            this.ContractValue5thYear.HeaderText = "5th Year";
            this.ContractValue5thYear.Name = "ContractValue5thYear";
            this.ContractValue5thYear.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ContractValue5thYear.Width = 71;
            // 
            // Scope
            // 
            this.Scope.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Scope.DataPropertyName = "Scope";
            this.Scope.HeaderText = "Scope";
            this.Scope.Name = "Scope";
            this.Scope.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // cmbQuotetype
            // 
            this.cmbQuotetype.DropDownHeight = 80;
            this.cmbQuotetype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbQuotetype.DropDownWidth = 150;
            this.cmbQuotetype.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbQuotetype.FormattingEnabled = true;
            this.cmbQuotetype.IntegralHeight = false;
            this.cmbQuotetype.ItemHeight = 18;
            this.cmbQuotetype.Items.AddRange(new object[] {
            "Calibration",
            "Maintenance"});
            this.cmbQuotetype.Location = new System.Drawing.Point(136, 6);
            this.cmbQuotetype.Name = "cmbQuotetype";
            this.cmbQuotetype.Size = new System.Drawing.Size(167, 26);
            this.cmbQuotetype.TabIndex = 239;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(8, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 23);
            this.label1.TabIndex = 240;
            this.label1.Text = "Service Type* :";
            // 
            // lblStartQuote
            // 
            this.lblStartQuote.AutoSize = true;
            this.lblStartQuote.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStartQuote.ForeColor = System.Drawing.Color.Black;
            this.lblStartQuote.Location = new System.Drawing.Point(326, 8);
            this.lblStartQuote.Name = "lblStartQuote";
            this.lblStartQuote.Size = new System.Drawing.Size(92, 23);
            this.lblStartQuote.TabIndex = 238;
            this.lblStartQuote.Text = "Start as * :";
            this.lblStartQuote.Visible = false;
            // 
            // cmbSelectQuoteType
            // 
            this.cmbSelectQuoteType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbSelectQuoteType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSelectQuoteType.DropDownHeight = 90;
            this.cmbSelectQuoteType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSelectQuoteType.DropDownWidth = 150;
            this.cmbSelectQuoteType.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbSelectQuoteType.FormattingEnabled = true;
            this.cmbSelectQuoteType.IntegralHeight = false;
            this.cmbSelectQuoteType.Items.AddRange(new object[] {
            "New",
            "Update",
            "Revise"});
            this.cmbSelectQuoteType.Location = new System.Drawing.Point(424, 6);
            this.cmbSelectQuoteType.Name = "cmbSelectQuoteType";
            this.cmbSelectQuoteType.Size = new System.Drawing.Size(167, 26);
            this.cmbSelectQuoteType.TabIndex = 237;
            this.cmbSelectQuoteType.Visible = false;
            // 
            // tabMaintenance
            // 
            this.tabMaintenance.Controls.Add(this.tabPage3);
            this.tabMaintenance.ItemSize = new System.Drawing.Size(30, 18);
            this.tabMaintenance.Location = new System.Drawing.Point(16, 62);
            this.tabMaintenance.Name = "tabMaintenance";
            this.tabMaintenance.SelectedIndex = 0;
            this.tabMaintenance.Size = new System.Drawing.Size(1294, 591);
            this.tabMaintenance.TabIndex = 241;
            this.tabMaintenance.Visible = false;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Silver;
            this.tabPage3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.textBox4);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.textBox5);
            this.tabPage3.Controls.Add(this.comboBox2);
            this.tabPage3.Controls.Add(this.label18);
            this.tabPage3.Controls.Add(this.dateTimePicker2);
            this.tabPage3.Controls.Add(this.label20);
            this.tabPage3.Controls.Add(this.comboBox3);
            this.tabPage3.Controls.Add(this.label21);
            this.tabPage3.Controls.Add(this.label22);
            this.tabPage3.Controls.Add(this.comboBox4);
            this.tabPage3.Controls.Add(this.comboBox5);
            this.tabPage3.Controls.Add(this.label24);
            this.tabPage3.Controls.Add(this.comboBox6);
            this.tabPage3.Controls.Add(this.label25);
            this.tabPage3.Controls.Add(this.label26);
            this.tabPage3.Controls.Add(this.label29);
            this.tabPage3.Controls.Add(this.dateTimePicker3);
            this.tabPage3.Controls.Add(this.dateTimePicker4);
            this.tabPage3.Controls.Add(this.label31);
            this.tabPage3.Controls.Add(this.label32);
            this.tabPage3.Controls.Add(this.textBox7);
            this.tabPage3.Controls.Add(this.textBox8);
            this.tabPage3.Controls.Add(this.label33);
            this.tabPage3.Controls.Add(this.label35);
            this.tabPage3.Controls.Add(this.textBox9);
            this.tabPage3.Controls.Add(this.textBox11);
            this.tabPage3.Controls.Add(this.label37);
            this.tabPage3.Controls.Add(this.label38);
            this.tabPage3.Controls.Add(this.textBox12);
            this.tabPage3.Controls.Add(this.button1);
            this.tabPage3.Controls.Add(this.dateTimePicker5);
            this.tabPage3.Controls.Add(this.label39);
            this.tabPage3.Controls.Add(this.textBox13);
            this.tabPage3.Controls.Add(this.label41);
            this.tabPage3.Controls.Add(this.textBox14);
            this.tabPage3.Controls.Add(this.label42);
            this.tabPage3.Controls.Add(this.label43);
            this.tabPage3.Controls.Add(this.textBox15);
            this.tabPage3.Controls.Add(this.label44);
            this.tabPage3.Controls.Add(this.comboBox7);
            this.tabPage3.ForeColor = System.Drawing.Color.Black;
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1286, 565);
            this.tabPage3.TabIndex = 0;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(786, 416);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(50, 18);
            this.label12.TabIndex = 250;
            this.label12.Text = "Value :";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.textBox4.Location = new System.Drawing.Point(839, 416);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(133, 26);
            this.textBox4.TabIndex = 249;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(741, 471);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(92, 18);
            this.label16.TabIndex = 248;
            this.label16.Text = "Call Number :";
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.textBox5.Location = new System.Drawing.Point(839, 468);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(133, 26);
            this.textBox5.TabIndex = 247;
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownHeight = 60;
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.DropDownWidth = 150;
            this.comboBox2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.IntegralHeight = false;
            this.comboBox2.ItemHeight = 18;
            this.comboBox2.Items.AddRange(new object[] {
            "BiSS-ITW",
            "INSTRON"});
            this.comboBox2.Location = new System.Drawing.Point(152, 307);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(222, 26);
            this.comboBox2.TabIndex = 243;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(28, 307);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(116, 18);
            this.label18.TabIndex = 244;
            this.label18.Text = "Equipment Type :";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CustomFormat = "";
            this.dateTimePicker2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker2.Location = new System.Drawing.Point(127, 63);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(104, 26);
            this.dateTimePicker2.TabIndex = 241;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(36, 66);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(82, 18);
            this.label20.TabIndex = 242;
            this.label20.Text = "Due Date * :";
            // 
            // comboBox3
            // 
            this.comboBox3.DropDownHeight = 60;
            this.comboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox3.DropDownWidth = 150;
            this.comboBox3.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.IntegralHeight = false;
            this.comboBox3.ItemHeight = 18;
            this.comboBox3.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.comboBox3.Location = new System.Drawing.Point(839, 380);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(222, 26);
            this.comboBox3.TabIndex = 239;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(717, 383);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(103, 18);
            this.label21.TabIndex = 240;
            this.label21.Text = "Payment Type :";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label22.ForeColor = System.Drawing.Color.Black;
            this.label22.Location = new System.Drawing.Point(32, 102);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(86, 18);
            this.label22.TabIndex = 238;
            this.label22.Text = "Start Date * :";
            // 
            // comboBox4
            // 
            this.comboBox4.DropDownHeight = 60;
            this.comboBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox4.DropDownWidth = 150;
            this.comboBox4.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.IntegralHeight = false;
            this.comboBox4.ItemHeight = 18;
            this.comboBox4.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.comboBox4.Location = new System.Drawing.Point(313, 102);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(61, 26);
            this.comboBox4.TabIndex = 237;
            // 
            // comboBox5
            // 
            this.comboBox5.DropDownHeight = 60;
            this.comboBox5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox5.DropDownWidth = 150;
            this.comboBox5.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.IntegralHeight = false;
            this.comboBox5.ItemHeight = 18;
            this.comboBox5.Items.AddRange(new object[] {
            "INR",
            "USD"});
            this.comboBox5.Location = new System.Drawing.Point(839, 299);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(222, 26);
            this.comboBox5.TabIndex = 235;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Black;
            this.label24.Location = new System.Drawing.Point(756, 302);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(69, 18);
            this.label24.TabIndex = 236;
            this.label24.Text = "Billable? :";
            // 
            // comboBox6
            // 
            this.comboBox6.DropDownHeight = 60;
            this.comboBox6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox6.DropDownWidth = 150;
            this.comboBox6.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.IntegralHeight = false;
            this.comboBox6.ItemHeight = 18;
            this.comboBox6.Items.AddRange(new object[] {
            "BiSS-ITW",
            "INSTRON"});
            this.comboBox6.Location = new System.Drawing.Point(839, 336);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(222, 26);
            this.comboBox6.TabIndex = 233;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(749, 339);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(71, 18);
            this.label25.TabIndex = 234;
            this.label25.Text = "Call Type :";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label26.ForeColor = System.Drawing.Color.Black;
            this.label26.Location = new System.Drawing.Point(24, 342);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(110, 18);
            this.label26.TabIndex = 231;
            this.label26.Text = "Model Number :";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label29.ForeColor = System.Drawing.Color.Black;
            this.label29.Location = new System.Drawing.Point(380, 107);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(86, 18);
            this.label29.TabIndex = 230;
            this.label29.Text = "END  Date * :";
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.CustomFormat = "";
            this.dateTimePicker3.Enabled = false;
            this.dateTimePicker3.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker3.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker3.Location = new System.Drawing.Point(467, 102);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(93, 26);
            this.dateTimePicker3.TabIndex = 229;
            // 
            // dateTimePicker4
            // 
            this.dateTimePicker4.CustomFormat = "";
            this.dateTimePicker4.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker4.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker4.Location = new System.Drawing.Point(127, 100);
            this.dateTimePicker4.Name = "dateTimePicker4";
            this.dateTimePicker4.Size = new System.Drawing.Size(93, 26);
            this.dateTimePicker4.TabIndex = 228;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.Red;
            this.label31.Location = new System.Drawing.Point(858, 3);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(0, 19);
            this.label31.TabIndex = 227;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.Black;
            this.label32.Location = new System.Drawing.Point(775, 3);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(62, 19);
            this.label32.TabIndex = 226;
            this.label32.Text = "Call By :";
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.textBox7.Location = new System.Drawing.Point(467, 155);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(20, 26);
            this.textBox7.TabIndex = 199;
            this.textBox7.Visible = false;
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.textBox8.Location = new System.Drawing.Point(152, 432);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(343, 26);
            this.textBox8.TabIndex = 21;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label33.ForeColor = System.Drawing.Color.Black;
            this.label33.Location = new System.Drawing.Point(44, 434);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(98, 18);
            this.label33.TabIndex = 195;
            this.label33.Text = "Planned Days :";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label35.ForeColor = System.Drawing.Color.Black;
            this.label35.Location = new System.Drawing.Point(60, 25);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(61, 18);
            this.label35.TabIndex = 189;
            this.label35.Text = "Region : ";
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.textBox9.Location = new System.Drawing.Point(127, 22);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(343, 26);
            this.textBox9.TabIndex = 12;
            // 
            // textBox11
            // 
            this.textBox11.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.textBox11.Location = new System.Drawing.Point(152, 515);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(343, 26);
            this.textBox11.TabIndex = 20;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label37.ForeColor = System.Drawing.Color.Black;
            this.label37.Location = new System.Drawing.Point(71, 519);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(75, 18);
            this.label37.TabIndex = 127;
            this.label37.Text = "No Of PM :";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label38.ForeColor = System.Drawing.Color.Black;
            this.label38.Location = new System.Drawing.Point(226, 105);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(81, 18);
            this.label38.TabIndex = 117;
            this.label38.Text = "No Of Year :";
            // 
            // textBox12
            // 
            this.textBox12.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.textBox12.Location = new System.Drawing.Point(152, 339);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(343, 26);
            this.textBox12.TabIndex = 9;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button1.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(1062, 492);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(154, 45);
            this.button1.TabIndex = 23;
            this.button1.Text = "Save";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // dateTimePicker5
            // 
            this.dateTimePicker5.CustomFormat = "";
            this.dateTimePicker5.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker5.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker5.Location = new System.Drawing.Point(859, 166);
            this.dateTimePicker5.Name = "dateTimePicker5";
            this.dateTimePicker5.Size = new System.Drawing.Size(104, 26);
            this.dateTimePicker5.TabIndex = 1;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label39.ForeColor = System.Drawing.Color.Black;
            this.label39.Location = new System.Drawing.Point(796, 172);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(54, 18);
            this.label39.TabIndex = 104;
            this.label39.Text = "Date * :";
            // 
            // textBox13
            // 
            this.textBox13.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.textBox13.Location = new System.Drawing.Point(152, 473);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(343, 26);
            this.textBox13.TabIndex = 19;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label41.ForeColor = System.Drawing.Color.Black;
            this.label41.Location = new System.Drawing.Point(80, 476);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(66, 18);
            this.label41.TabIndex = 98;
            this.label41.Text = "Purpose :";
            // 
            // textBox14
            // 
            this.textBox14.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.textBox14.Location = new System.Drawing.Point(152, 385);
            this.textBox14.MaxLength = 80;
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(343, 26);
            this.textBox14.TabIndex = 18;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label42.ForeColor = System.Drawing.Color.Black;
            this.label42.Location = new System.Drawing.Point(27, 158);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(85, 18);
            this.label42.TabIndex = 92;
            this.label42.Text = "Customer * :";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label43.ForeColor = System.Drawing.Color.Black;
            this.label43.Location = new System.Drawing.Point(41, 388);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(93, 18);
            this.label43.TabIndex = 96;
            this.label43.Text = "Service Type :";
            // 
            // textBox15
            // 
            this.textBox15.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.textBox15.Location = new System.Drawing.Point(118, 197);
            this.textBox15.Multiline = true;
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(343, 86);
            this.textBox15.TabIndex = 16;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.label44.ForeColor = System.Drawing.Color.Black;
            this.label44.Location = new System.Drawing.Point(47, 200);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(65, 18);
            this.label44.TabIndex = 94;
            this.label44.Text = "Address :";
            // 
            // comboBox7
            // 
            this.comboBox7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.comboBox7.DropDownHeight = 90;
            this.comboBox7.DropDownWidth = 150;
            this.comboBox7.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.IntegralHeight = false;
            this.comboBox7.Location = new System.Drawing.Point(118, 155);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(343, 26);
            this.comboBox7.TabIndex = 15;
            // 
            // cmbServiceOrderNo
            // 
            this.cmbServiceOrderNo.DropDownHeight = 80;
            this.cmbServiceOrderNo.DropDownWidth = 150;
            this.cmbServiceOrderNo.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbServiceOrderNo.FormattingEnabled = true;
            this.cmbServiceOrderNo.IntegralHeight = false;
            this.cmbServiceOrderNo.ItemHeight = 18;
            this.cmbServiceOrderNo.Location = new System.Drawing.Point(821, 6);
            this.cmbServiceOrderNo.Name = "cmbServiceOrderNo";
            this.cmbServiceOrderNo.Size = new System.Drawing.Size(167, 26);
            this.cmbServiceOrderNo.TabIndex = 247;
            this.cmbServiceOrderNo.Visible = false;
            // 
            // lblSONo
            // 
            this.lblSONo.AutoSize = true;
            this.lblSONo.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.lblSONo.ForeColor = System.Drawing.Color.Black;
            this.lblSONo.Location = new System.Drawing.Point(609, 8);
            this.lblSONo.Name = "lblSONo";
            this.lblSONo.Size = new System.Drawing.Size(206, 23);
            this.lblSONo.TabIndex = 248;
            this.lblSONo.Text = "Service Order Number* :";
            this.lblSONo.Visible = false;
            // 
            // comboBox8
            // 
            this.comboBox8.DropDownHeight = 80;
            this.comboBox8.DropDownWidth = 150;
            this.comboBox8.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.IntegralHeight = false;
            this.comboBox8.ItemHeight = 18;
            this.comboBox8.Location = new System.Drawing.Point(1119, 9);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(167, 26);
            this.comboBox8.TabIndex = 249;
            this.comboBox8.Visible = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(994, 10);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(119, 23);
            this.label17.TabIndex = 250;
            this.label17.Text = "OE Number* :";
            this.label17.Visible = false;
            // 
            // frmServiceCallManager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1303, 663);
            this.Controls.Add(this.comboBox8);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.cmbServiceOrderNo);
            this.Controls.Add(this.lblSONo);
            this.Controls.Add(this.tabMaintenance);
            this.Controls.Add(this.cmbQuotetype);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblStartQuote);
            this.Controls.Add(this.cmbSelectQuoteType);
            this.Controls.Add(this.tabCalibration);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmServiceCallManager";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Service Call Manager";
            this.tabCalibration.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.pnCeast.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCeastContract)).EndInit();
            this.pnAMC.ResumeLayout(false);
            this.pnAMC.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvContract)).EndInit();
            this.tabMaintenance.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabCalibration;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.ComboBox cmbCeastAMC;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.ComboBox cmbContractYears;
        private System.Windows.Forms.ComboBox cmbEnquireCurrency;
        private System.Windows.Forms.Label lblcustomer;
        private System.Windows.Forms.ComboBox cmbQuoteCompany;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dtpContractto;
        private System.Windows.Forms.DateTimePicker dtpContractfrom;
        private System.Windows.Forms.Label lblQuoteBy;
        private System.Windows.Forms.Label lblQuotebyin;
        private System.Windows.Forms.TextBox txtCusCode;
        private System.Windows.Forms.TextBox txtEmailID;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtZone;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtCusref;
        private System.Windows.Forms.TextBox txtTel;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtModelslno;
        private System.Windows.Forms.Button btnStartQuote;
        private System.Windows.Forms.DateTimePicker dtpEnquireDate;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtContactNumber;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtContactPerson;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbCustomer;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel pnCeast;
        private System.Windows.Forms.Button btnCeastAdditem;
        private System.Windows.Forms.DataGridView dgvCeastContract;
        private System.Windows.Forms.DataGridViewTextBoxColumn InstrumentDetails;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
        private System.Windows.Forms.TextBox txtGrandTotal;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtDiscount;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btnGenarateQuote;
        private System.Windows.Forms.Button btnFinQuote;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtpaymentterms;
        private System.Windows.Forms.TextBox txtbreakdownvistcharges;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Button btnBack1;
        private System.Windows.Forms.Panel pnAMC;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Button btnAddrow;
        private System.Windows.Forms.TextBox txtContractValue;
        private System.Windows.Forms.CheckBox chk3Years;
        private System.Windows.Forms.CheckBox chk5Years;
        private System.Windows.Forms.DataGridView dgvContract;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContractValue1stYear;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContractValue2ndYear;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContractValue3rdYear;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContractValue4thYear;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContractValue5thYear;
        private System.Windows.Forms.DataGridViewTextBoxColumn Scope;
        private System.Windows.Forms.ComboBox cmbQuotetype;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblStartQuote;
        private System.Windows.Forms.ComboBox cmbSelectQuoteType;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TabControl tabMaintenance;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.DateTimePicker dateTimePicker4;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DateTimePicker dateTimePicker5;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.ComboBox cmbServiceOrderNo;
        private System.Windows.Forms.Label lblSONo;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.Label label17;
    }
}