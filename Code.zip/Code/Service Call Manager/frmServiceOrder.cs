﻿using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using EXCEL = Microsoft.Office.Interop.Excel;

namespace Erp_Project_With_Buttons.Service_Call_Manager
{
    public partial class frmServiceOrder : Form
    {
        public frmServiceOrder()
        {
            InitializeComponent();
        }
        frmForm2 form = new frmForm2();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        private void btnStartOrder_Click(object sender, EventArgs e)
        {
            if (cmbCustomerName.Text != "")
            {
                tabMaintenance.SelectTab(1);
            }
            else
            {
                if (cmbCustomerName.Text == "")
                {
                    MessageBox.Show("Please select customer", "Error", 0, MessageBoxIcon.Error);
                    cmbCustomerName.DroppedDown = true;
                }
            }
        }

        private void btnGenrateServiceOrder_Click(object sender, EventArgs e)
        {
            if (dgvSOItems.Rows.Count > 0)
            {
                if (btnGenrateServiceOrder.Text == "Generate Quote")
                {

                }
            }
            else
            {
                if (dgvSOItems.Rows.Count == 0)
                {
                    MessageBox.Show("Please add service order items", "Error", 0, MessageBoxIcon.Error);
                }
            }
        }

        private void InsertCALQuote(uint InsertorUpdate, string sQuotationNo, string RevisionNumber)
        {
            if (InsertorUpdate == Global.uINSERT)
            {
                GlobalClass.iStatus = DAL.fnAddServiceOrderDetails(InsertorUpdate, "", txtBookingorderNo.Text, txtTerritotyZonename.Text, txtTerracastCode.Text, txtVendorCode.Text, cmbCustomerName.Text,
                    txtCustomerAddress.Text, txtGST.Text, txtCustomerPhone.Text, txtCustomerOrderref.Text, txtQuoteRef.Text, txtPaymentterms.Text, txtOrderValue.Text, txtInvoicedoc.Text, txtInvoiceto.Text, txtMobileno.Text,
                    txtEmail.Text, txtEnduser1.Text, txtEmaliMobile1.Text, txtEnduser2.Text, txtEmailMobile2.Text, txtSiteAddress.Text, cmbServiceProduct.Text, dtpWeekMonth.Text, txtBookingRecognition.Text,
                    txtDescription.Text, txtSystemsCovered.Text, dtpPeriodFrom.Text, dtpPeriodTo.Text, lblSOBy.Text, dtpDateofServiceOrder.Text);

                foreach (DataGridViewRow dr in dgvSOItems.Rows)
                {
                    GlobalClass.iStatus = DAL.fnAddServiceOrderItems(InsertorUpdate, txtBookingorderNo.Text, dr.Cells[0].Value.ToString(), dr.Cells[1].Value.ToString(), dr.Cells[2].Value.ToString()
                        , dr.Cells[3].Value.ToString(), dr.Cells[4].Value.ToString(), dr.Cells[5].Value.ToString(), dr.Cells[6].Value.ToString(), dr.Cells[7].Value.ToString(), dr.Cells[8].Value.ToString()
                        , dr.Cells[9].Value.ToString(), dr.Cells[10].Value.ToString());
                }
            }

            else if (InsertorUpdate == Global.uUPDATE)
            {

                GlobalClass.iStatus = DAL.fnAddServiceOrderDetails(InsertorUpdate, "", txtTerritotyZonename.Text, txtTerritotyZonename.Text, txtTerracastCode.Text, txtVendorCode.Text, cmbCustomerName.Text,
                                                                     txtCustomerAddress.Text, txtGST.Text, txtCustomerPhone.Text, txtCustomerOrderref.Text, txtQuoteRef.Text, txtPaymentterms.Text, txtOrderValue.Text, txtInvoicedoc.Text, txtInvoiceto.Text, txtMobileno.Text,
                                                                     txtEmail.Text, txtEnduser1.Text, txtEmaliMobile1.Text, txtEnduser2.Text, txtEmailMobile2.Text, txtSiteAddress.Text, cmbServiceProduct.Text, dtpWeekMonth.Text, txtBookingRecognition.Text,
                                                                     txtDescription.Text, txtSystemsCovered.Text, dtpPeriodFrom.Text, dtpPeriodTo.Text, lblSOBy.Text, dtpDateofServiceOrder.Text);

                GlobalClass.iStatus = DAL.fnAddServiceOrderItems(Global.uDELETE, txtBookingorderNo.Text, "", "", "", "", "", "", "", "", "", "", "");


                foreach (DataGridViewRow dr in dgvSOItems.Rows)
                {
                    GlobalClass.iStatus = DAL.fnAddServiceOrderItems(InsertorUpdate, txtBookingorderNo.Text, dr.Cells[0].Value.ToString(), dr.Cells[1].Value.ToString(), dr.Cells[2].Value.ToString()
                        , dr.Cells[3].Value.ToString(), dr.Cells[4].Value.ToString(), dr.Cells[5].Value.ToString(), dr.Cells[6].Value.ToString(), dr.Cells[7].Value.ToString(), dr.Cells[8].Value.ToString()
                        , dr.Cells[9].Value.ToString(), dr.Cells[10].Value.ToString());
                }
            }
        }
        DataTable dtLoadServiceOrder = new DataTable();
        DataTable dtLoadServiceOrderNo = new DataTable();
        DataTable dtLoadServiceOrderDetails = new DataTable();
        private void cmbSelectQuoteType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbSelectQuoteType.SelectedIndex >= 0)
            {
                tabMaintenance.Enabled = true;
                lblSONo.Visible = false;
                cmbServiceOrderNo.Visible = false;
                tabMaintenance.Visible = true;
            }

            if (cmbSelectQuoteType.SelectedIndex > 0)
            {
                dtLoadServiceOrderNo = DAL.fnServiceOrderData(0, "").Tables[0];
                foreach (DataRow DR in dtLoadServiceOrderNo.Rows)
                {
                    if (!cmbServiceOrderNo.Items.Contains(DR["BookingOrderNumber"].ToString()))
                        cmbServiceOrderNo.Items.Add(DR["BookingOrderNumber"].ToString());
                }
                lblSONo.Visible = true;
                cmbServiceOrderNo.Visible = true;

            }
        }

        private void cmbServiceOrderNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtLoadServiceOrder = DAL.fnServiceOrderData(1, cmbServiceOrderNo.Text).Tables[0];
            if (dtLoadServiceOrder.Rows.Count > 0)
            {
                txtBookingorderNo.Text = dtLoadServiceOrder.Rows[0][0].ToString();
                txtTerritotyZonename.Text = dtLoadServiceOrder.Rows[0][1].ToString();
                txtTerracastCode.Text = dtLoadServiceOrder.Rows[0][2].ToString();
                txtVendorCode.Text = dtLoadServiceOrder.Rows[0][3].ToString();
                cmbCustomerName.Text = dtLoadServiceOrder.Rows[0][4].ToString();
                txtCustomerAddress.Text = dtLoadServiceOrder.Rows[0][5].ToString();
                txtGST.Text = dtLoadServiceOrder.Rows[0][6].ToString();
                txtCustomerPhone.Text = dtLoadServiceOrder.Rows[0][7].ToString();
                txtCustomerOrderref.Text = dtLoadServiceOrder.Rows[0][8].ToString();
                txtQuoteRef.Text = dtLoadServiceOrder.Rows[0][9].ToString();
                txtPaymentterms.Text = dtLoadServiceOrder.Rows[0][10].ToString();
                txtOrderValue.Text = dtLoadServiceOrder.Rows[0][11].ToString();
                txtInvoicedoc.Text = dtLoadServiceOrder.Rows[0][12].ToString();
                txtInvoiceto.Text = dtLoadServiceOrder.Rows[0][13].ToString();
                txtMobileno.Text = dtLoadServiceOrder.Rows[0][14].ToString();
                txtEmail.Text = dtLoadServiceOrder.Rows[0][15].ToString();
                txtEnduser1.Text = dtLoadServiceOrder.Rows[0][16].ToString();
                txtEmaliMobile1.Text = dtLoadServiceOrder.Rows[0][17].ToString();
                txtEnduser2.Text = dtLoadServiceOrder.Rows[0][18].ToString();
                txtEmailMobile2.Text = dtLoadServiceOrder.Rows[0][19].ToString();
                txtSiteAddress.Text = dtLoadServiceOrder.Rows[0][20].ToString();
                cmbServiceProduct.Text = dtLoadServiceOrder.Rows[0][21].ToString();
                //dtpWeekMonth.Text = dtLoadServiceOrder.Rows[0][22].ToString();
                txtBookingRecognition.Text = dtLoadServiceOrder.Rows[0][23].ToString();
                txtDescription.Text = dtLoadServiceOrder.Rows[0][24].ToString();
                txtSystemsCovered.Text = dtLoadServiceOrder.Rows[0][25].ToString();
                //dtpPeriodFrom.Text = dtLoadServiceOrder.Rows[0][26].ToString();
                //dtpPeriodTo.Text = dtLoadServiceOrder.Rows[0][27].ToString();
                lblSOBy.Text = dtLoadServiceOrder.Rows[0][28].ToString();
                //dtpDateofServiceOrder.Text = dtLoadServiceOrder.Rows[0][29].ToString();
            }

            dtLoadServiceOrderDetails = DAL.fnServiceOrderData(2, cmbServiceOrderNo.Text).Tables[0];
            if (dtLoadServiceOrderDetails.Rows.Count > 0)
            {
                dgvSOItems.AutoGenerateColumns = false;
                dgvSOItems.DataSource = dtLoadServiceOrderDetails;
            }
        }

        private void frmServiceOrder_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (GlobalClass.fnMessageResult() == Global.sCLOSE_MESSAGE_RESULT_YES)
            {
                this.Hide();
                form.Show();
            }
            else
            {
                e.Cancel = true;
            }
        }


        private void fnFileSavePath()
        {
            if (Properties.Settings.Default.ServiceQuotePath == "C:\\Users\\SOFTWARE8\\Documents\\Quotation")
            {
                DialogResult result = folderBrowserDialog1.ShowDialog();
                if (result == DialogResult.OK)
                {
                    Properties.Settings.Default.ServiceQuotePath = folderBrowserDialog1.SelectedPath;
                    Properties.Settings.Default.Save();
                }
            }
        }

        #region CellMerge Funtion
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "ThickBorder":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "GridLines":
                    {
                        CELLS.Borders.Color = System.Drawing.Color.Black;
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignCenter":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                        break;
                    }

                case "WrapText":
                    {
                        CELLS.WrapText = true;
                        break;
                    }

                case "AlignRight":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                        break;
                    }
                case "AlignLeft":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignLeft;
                        break;
                    }
                case "TextAlign":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignJustify;
                        break;
                    }
                case "AlignTop":
                    {
                        CELLS.VerticalAlignment = EXCEL.XlVAlign.xlVAlignTop;
                        break;
                    }
                case "VAlignCenter":
                    {
                        CELLS.VerticalAlignment = EXCEL.XlVAlign.xlVAlignCenter;
                        break;
                    }

                case "Bold":
                    {
                        CELLS.Font.Bold = true;
                        break;
                    }

                case "Autofit":
                    {
                        CELLS.Rows.AutoFit();
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

        }
        #endregion

        #region Excel App Release Object Function
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
        #endregion

        private void btnPrintOrder_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            fnFileSavePath();
            int iRowIndex = 1;
            string ExcelFolderPath;
            string FileFullPath;
            string FileFul;
            EXCEL.Workbook NewWorkBook;
            EXCEL.Worksheet NewWorkSheet;
            EXCEL.Application ExcelApp;
            EXCEL.Range CELLS, cell1, cell2;
            object misValue;
            if (dgvSOItems.Rows.Count > 0)
            {
                string sFileQuotename = cmbServiceOrderNo.Text;

                Regex illegalInFileName = new Regex(@"[\\/:*?""<>|]");
                string sProjName = sFileQuotename;
                sFileQuotename = illegalInFileName.Replace(sProjName, " ");

                ExcelFolderPath = Properties.Settings.Default.ServiceQuotePath;   // System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + ExcelFolderName + "\\";
                FileFullPath = ExcelFolderPath + "\\" + sFileQuotename + " - " + cmbCustomerName.Text + ".xlsx"; //"_" + DateTime.Now.ToString("d/M/yyyy HH/mm/ss") +
                FileFul = ExcelFolderPath + "\\" + sFileQuotename + " - " + cmbCustomerName.Text + ".pdf"; // "_" + DateTime.Now.ToString("d/M/yyyy HH/mm/ss") + 

                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);
                ExcelApp = new EXCEL.Application();
                misValue = System.Reflection.Missing.Value;
                try
                {
                    if (ExcelApp == null)
                        MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                    NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                    NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                    if (NewWorkSheet == null)
                        MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                    else
                        NewWorkSheet.Name = "Service Order";
                    // Select the Excel cells, in the range c1 to c7 in the worksheet for cell access check.
                    EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                    if (RANGE == null)
                        MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                    //  NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlWorkbookNormal, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    CELLS = NewWorkSheet.Cells;



                    string[] TextN1 ={"","",
                                "ITW India Private Limited - Instron Division","#81 First Floor, FF2 GCV House, Nungambakkam High Road,",
                                "Nungambakkam - 600034, Tamil Nadu, India.","CIN No : U32301HR1979PTC038643      GSTIN No : 33AAACI4550Q1ZD       PAN No : AAACI4550Q"};
                    iRowIndex++;
                    iRowIndex++;
                    foreach (string str in TextN1)
                    {
                        NewWorkSheet.Cells[iRowIndex, 1] = str;
                        //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);
                        iRowIndex++;
                    }

                    // iRowIndex++;
                    // iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "SERVICE ORDER";
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 11);

                    CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 11);
                    CellMerge("VAlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 11);
                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 11);
                    NewWorkSheet.Cells[iRowIndex, 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                    // CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 5);

                 

                    iRowIndex++;

                    for (int i = 10; i < 26; i++)
                    {
                        CellMerge("VAlignCenter", NewWorkSheet, i, i, 1, 11);
                    }

                 

                    NewWorkSheet.Cells[iRowIndex, 1] = "Booking Order Number :";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    NewWorkSheet.Cells[iRowIndex, 3] = txtBookingorderNo.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 5);
                    //CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 3, 5);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 3, 5);

                    NewWorkSheet.Cells[iRowIndex, 6] = "Invoice doc : ";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 6, 7);
                    //CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 6, 7);
                    NewWorkSheet.Cells[iRowIndex, 8] = txtInvoicedoc.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    //CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);

                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Territory / Zone Name : ";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    NewWorkSheet.Cells[iRowIndex, 3] = txtTerritotyZonename.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    //CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);

                    NewWorkSheet.Cells[iRowIndex, 6] = "Invoice to : ";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);
                    //CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);
                    NewWorkSheet.Cells[iRowIndex, 8] = txtInvoiceto.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    //CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);

                    iRowIndex++;


                    NewWorkSheet.Cells[iRowIndex, 1] = "Tesseract Customer Code : ";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    NewWorkSheet.Cells[iRowIndex, 3] = txtTerracastCode.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    //CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    NewWorkSheet.Cells[iRowIndex, 6] = "Mobile : ";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);
                    //CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);
                    NewWorkSheet.Cells[iRowIndex, 8] = txtMobileno.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    //CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Vendor Code : ";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    NewWorkSheet.Cells[iRowIndex, 3] = txtVendorCode.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    //CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);

                    NewWorkSheet.Cells[iRowIndex, 6] = "Email : ";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);
                    //CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);
                    NewWorkSheet.Cells[iRowIndex, 8] = txtEmail.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    //CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);

                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Customer name : ";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    NewWorkSheet.Cells[iRowIndex, 3] = cmbCustomerName.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    //CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                  //  CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 11);

                    NewWorkSheet.Cells[iRowIndex, 6] = "End User 1 : ";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);
                    //CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);
                    NewWorkSheet.Cells[iRowIndex, 8] = txtEnduser1.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    //CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);

                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Customer Order Reference : ";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    NewWorkSheet.Cells[iRowIndex, 3] = txtCustomerOrderref.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    //CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);

                    NewWorkSheet.Cells[iRowIndex, 6] = "Email / Mobile : ";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);
                    //CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);
                    NewWorkSheet.Cells[iRowIndex, 8] = txtEmaliMobile1.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    //CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);

                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Quotation Reference : ";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    NewWorkSheet.Cells[iRowIndex, 3] = txtQuoteRef.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    //CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);

                    NewWorkSheet.Cells[iRowIndex, 6] = "End User 2 : ";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);
                    //CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);
                    NewWorkSheet.Cells[iRowIndex, 8] = txtEnduser2.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    //CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);

                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Payment Terms : ";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    NewWorkSheet.Cells[iRowIndex, 3] = txtPaymentterms.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    //CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);

                    NewWorkSheet.Cells[iRowIndex, 6] = "Email / Mobile : ";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);
                    //CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);
                    NewWorkSheet.Cells[iRowIndex, 8] = txtEmailMobile2.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    //CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Total Order Value : ";
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);


                    NewWorkSheet.Cells[iRowIndex, 3] = txtOrderValue.Text;
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 11);
                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    NewWorkSheet.Cells[iRowIndex, 3].Font.Color = Color.FromArgb(0, 0, 255);

                    Microsoft.Office.Interop.Excel.Range range2 = NewWorkSheet.get_Range("C18", "C18");
                    range2.NumberFormat = "#,###";

                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Address : ";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    NewWorkSheet.Cells[iRowIndex, 3] = txtCustomerAddress.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    //CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);


                    NewWorkSheet.Cells[iRowIndex, 6] = "Site Address : ";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);
                    //CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);
                    NewWorkSheet.Cells[iRowIndex, 8] = txtSiteAddress.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    //CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 11);


                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Phone : ";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    NewWorkSheet.Cells[iRowIndex, 3] = txtCustomerPhone.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    //CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);

                    NewWorkSheet.Cells[iRowIndex, 6] = "Service Product : ";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);
                    //CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);
                    NewWorkSheet.Cells[iRowIndex, 8] = cmbServiceProduct.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    //CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                  //  CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 11);

                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "GST : ";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    NewWorkSheet.Cells[iRowIndex, 3] = txtGST.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    //CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);

                    NewWorkSheet.Cells[iRowIndex, 6] = "System Covered : ";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);
                    //CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);
                    NewWorkSheet.Cells[iRowIndex, 8] = txtSystemsCovered.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    //CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    //CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 11);
                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex + 1, 7, 11);

                    iRowIndex++;

                    //NewWorkSheet.Cells[iRowIndex, 1] = "Service Product : ";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //NewWorkSheet.Cells[iRowIndex, 3] = cmbServiceProduct.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    //CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    //iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Week/Month Order is booked : ";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    NewWorkSheet.Cells[iRowIndex, 3] = dtpWeekMonth.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    //CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);

                    NewWorkSheet.Cells[iRowIndex, 6] = "Period : ";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);
                    //CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 5, 6);
                    NewWorkSheet.Cells[iRowIndex, 8] = dtpPeriodFrom.Text + " to " + dtpPeriodTo.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    //CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 7, 11);
                    
                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Booking Recognition : ";
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    NewWorkSheet.Cells[iRowIndex, 3] = txtBookingRecognition.Text;
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    //CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    //CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 3, 4);
                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Description : ";
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);
                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 2);

                    NewWorkSheet.Cells[iRowIndex, 3] = txtDescription.Text;
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 11);
                    CellMerge("AlignLeft", NewWorkSheet, iRowIndex, iRowIndex, 3, 11);
                    CellMerge("WrapText", NewWorkSheet, iRowIndex, iRowIndex, 3, 11);
                    CellMerge("AlignTop", NewWorkSheet, iRowIndex, iRowIndex, 1, 11);

                    for (int i = 10; i < 24; i++)
                    {
                        CellMerge("Merge", NewWorkSheet, i, i, 1, 2);
                        CellMerge("AlignRight", NewWorkSheet, i, i, 1, 2);
                        CellMerge("Merge", NewWorkSheet, i, i, 3, 5);
                        CellMerge("AlignLeft", NewWorkSheet, i, i, 3, 5);
                        CellMerge("WrapText", NewWorkSheet, i, i, 3, 5);
                    }

                    for (int i = 10; i < 18; i++)
                    {
                        CellMerge("Merge", NewWorkSheet, i, i, 6, 7);
                        CellMerge("AlignRight", NewWorkSheet, i, i, 6, 7);
                        CellMerge("Merge", NewWorkSheet, i, i, 8, 11);
                        CellMerge("AlignLeft", NewWorkSheet, i, i, 8, 11);
                        CellMerge("WrapText", NewWorkSheet, i, i, 8, 11);
                    }

                    for (int i = 19; i < 23; i++)
                    {
                        CellMerge("Merge", NewWorkSheet, i, i, 6, 7);
                        CellMerge("AlignRight", NewWorkSheet, i, i, 6, 7);
                        CellMerge("Merge", NewWorkSheet, i, i, 8, 11);
                        CellMerge("AlignLeft", NewWorkSheet, i, i, 8, 11);
                        CellMerge("WrapText", NewWorkSheet, i, i, 8, 11);
                    }


                    iRowIndex++;
                    iRowIndex++;
                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1].Font.Color = Color.FromArgb(186, 12, 47);
                    NewWorkSheet.Cells[iRowIndex, 2].Font.Color = Color.FromArgb(186, 12, 47);
                    NewWorkSheet.Cells[iRowIndex, 3].Font.Color = Color.FromArgb(186, 12, 47);
                    NewWorkSheet.Cells[iRowIndex, 4].Font.Color = Color.FromArgb(186, 12, 47);
                    NewWorkSheet.Cells[iRowIndex, 5].Font.Color = Color.FromArgb(186, 12, 47);
                    NewWorkSheet.Cells[iRowIndex, 6].Font.Color = Color.FromArgb(186, 12, 47);
                    NewWorkSheet.Cells[iRowIndex, 7].Font.Color = Color.FromArgb(186, 12, 47);
                    NewWorkSheet.Cells[iRowIndex, 8].Font.Color = Color.FromArgb(186, 12, 47);
                    NewWorkSheet.Cells[iRowIndex, 9].Font.Color = Color.FromArgb(186, 12, 47);
                    NewWorkSheet.Cells[iRowIndex, 10].Font.Color = Color.FromArgb(186, 12, 47);
                    NewWorkSheet.Cells[iRowIndex, 11].Font.Color = Color.FromArgb(186, 12, 47);
                    NewWorkSheet.Cells[iRowIndex, 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                    NewWorkSheet.Cells[iRowIndex, 2].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                    NewWorkSheet.Cells[iRowIndex, 3].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                    NewWorkSheet.Cells[iRowIndex, 4].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                    NewWorkSheet.Cells[iRowIndex, 5].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                    NewWorkSheet.Cells[iRowIndex, 6].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                    NewWorkSheet.Cells[iRowIndex, 7].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                    NewWorkSheet.Cells[iRowIndex, 8].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                    NewWorkSheet.Cells[iRowIndex, 9].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                    NewWorkSheet.Cells[iRowIndex, 10].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));
                    NewWorkSheet.Cells[iRowIndex, 11].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(191, 191, 191));

                    if (dtLoadServiceOrderDetails.Rows.Count > 0)
                    {
                        object[,] rawData = new object[dtLoadServiceOrderDetails.Rows.Count + 1, dtLoadServiceOrderDetails.Columns.Count];
                        for (int col = 0; col < dtLoadServiceOrderDetails.Columns.Count; col++)
                        {
                            rawData[0, col] = dtLoadServiceOrderDetails.Columns[col].ColumnName;
                        }
                        for (int row = 0; row < dtLoadServiceOrderDetails.Rows.Count; row++)
                        {
                            for (int col = 0; col < dtLoadServiceOrderDetails.Columns.Count; col++)
                            {
                                rawData[row + 1, col] = dtLoadServiceOrderDetails.Rows[row].ItemArray[col];
                            }
                        }
                        string excelRange = string.Empty;
                        string finalColLetter = string.Empty;
                        string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        int colCharsetLen = colCharset.Length;

                        if (dtLoadServiceOrderDetails.Columns.Count > colCharsetLen)
                        {
                            finalColLetter = colCharset.Substring((dtLoadServiceOrderDetails.Columns.Count - 1) / colCharsetLen - 1, 1);
                        }
                        finalColLetter += colCharset.Substring((dtLoadServiceOrderDetails.Columns.Count - 1) % colCharsetLen, 1);
                        excelRange = string.Format("A" + iRowIndex + ":{0}{1}", finalColLetter, (dtLoadServiceOrderDetails.Rows.Count + iRowIndex));
                        NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                    }
                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 11);
                    CellMerge("GridLines", NewWorkSheet, iRowIndex, (iRowIndex + dtLoadServiceOrderDetails.Rows.Count), 1, 11);
                    CellMerge("AlignCenter", NewWorkSheet, iRowIndex, (iRowIndex + dtLoadServiceOrderDetails.Rows.Count), 1, 11);
                    CellMerge("VAlignCenter", NewWorkSheet, iRowIndex, (iRowIndex + dtLoadServiceOrderDetails.Rows.Count), 1, 11);

                    //  Microsoft.Office.Interop.Excel.Range range2 = NewWorkSheet.get_Range("D" + iRowIndex, "F" + (iRowIndex + 3 + dtLoadServiceOrderDetails.Rows.Count) + "");
                    //  range2.NumberFormat = "#,###";

                    iRowIndex = dtLoadServiceOrderDetails.Rows.Count + iRowIndex + 2;

                    NewWorkSheet.Cells[iRowIndex, 8] = "for ITW India Private Limited,";
                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                    iRowIndex++;
                    iRowIndex++;



                    // if (login.GetUserDetails[2] == "Chaithra.K.R")
                    {
                        EXCEL.Range oRange2 = (EXCEL.Range)NewWorkSheet.Cells[(iRowIndex), 8];
                        Image oImage2 = Image.FromFile("C:\\Databasepath\\ChaitraSign.jpg");
                        System.Windows.Forms.Clipboard.SetDataObject(oImage2, true);
                        NewWorkSheet.Paste(oRange2, oImage2);
                    }

                    iRowIndex++;
                    iRowIndex++;
                    iRowIndex++;
                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 8] = "Authorised Signatory";
                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                    //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 3, 6);
                    iRowIndex++;

                    //EXCEL.Range oRange3 = (EXCEL.Range)NewWorkSheet.Cells[(iRowIndex), 8];
                    //Image oImage3 = Image.FromFile("C:\\Databasepath\\InstronSeal.jpg");
                    //System.Windows.Forms.Clipboard.SetDataObject(oImage3, true);
                    //NewWorkSheet.Paste(oRange3, oImage3);
                    //iRowIndex++;
                    //iRowIndex++;
                    //iRowIndex++;
                    //iRowIndex++;

                    CellMerge("BorderAround", NewWorkSheet, 1, iRowIndex, 1, 11);

                    CellMerge("BorderAround", NewWorkSheet, 1, 8, 1, 11);
                    CellMerge("BorderAround", NewWorkSheet, 9, 9, 1, 11);

                    for (int i = 10; i < 24; i++)
                    {
                        CellMerge("BorderAround", NewWorkSheet, i, i, 1, 11);
                    }

                    CellMerge("BorderAround", NewWorkSheet, 10, 23, 1, 5);
                    CellMerge("Bold", NewWorkSheet, 10, 23, 1, 2);
                    CellMerge("Bold", NewWorkSheet, 10, 23, 5, 6);
                    //CellMerge("Bold", NewWorkSheet, 26, 26, 1, 2);
                    //    CellMerge("Bold", NewWorkSheet, 26, 26, 5, 6);
                    //  CellMerge("BorderAround", NewWorkSheet, 10, 17, 5, 11);
                    CellMerge("BorderAround", NewWorkSheet, 24, 24, 1, 11);
                    // CellMerge("BorderAround", NewWorkSheet, 19, 21, 5, 11);

                    NewWorkSheet.Range["A1:K" + (iRowIndex) + ""].Cells.Font.Size = 13;
                    //  NewWorkSheet.Range["A12:E12"].Cells.Font.Bold = true;
                    //  NewWorkSheet.Range["A12:E12"].Cells.Font.Size = 16;
                    NewWorkSheet.Range["A9:B9"].Cells.Font.Size = 20;
                    NewWorkSheet.Range["A9:B9"].Cells.Font.Bold = true;
                    NewWorkSheet.Range["C18:C18"].Cells.Font.Size = 16;
                    NewWorkSheet.Range["A5:B5"].Cells.Font.Size = 16;
                    NewWorkSheet.Range["A5:B5"].Cells.Font.Bold = true;

                    NewWorkSheet.Range["H21:H22"].Cells.Font.Size = 16;
                    NewWorkSheet.Range["A27:K27"].Cells.Font.Size = 16;
                    NewWorkSheet.Rows.AutoFit();
                    //NewWorkSheet.Columns.AutoFit();
                    NewWorkSheet.Columns[1].ColumnWidth = 14;
                    NewWorkSheet.Columns[2].ColumnWidth = 18;
                    NewWorkSheet.Columns[2].WrapText = true;
                    NewWorkSheet.Columns[3].ColumnWidth = 12;
                    NewWorkSheet.Columns[3].WrapText = true;
                    NewWorkSheet.Columns[4].ColumnWidth = 16;
                    NewWorkSheet.Columns[4].WrapText = true;
                    NewWorkSheet.Columns[5].ColumnWidth = 9;
                    NewWorkSheet.Columns[5].WrapText = true;
                    NewWorkSheet.Columns[6].ColumnWidth = 9;
                    NewWorkSheet.Columns[6].WrapText = true;
                    NewWorkSheet.Columns[7].ColumnWidth = 8;
                    NewWorkSheet.Columns[7].WrapText = true;
                    NewWorkSheet.Columns[8].ColumnWidth = 13;
                    // NewWorkSheet.Columns[8].WrapText = true;
                    NewWorkSheet.Columns[9].ColumnWidth = 8;
                    NewWorkSheet.Columns[9].WrapText = true;
                    NewWorkSheet.Columns[10].ColumnWidth = 8;
                    NewWorkSheet.Columns[10].WrapText = true;
                    NewWorkSheet.Columns[11].ColumnWidth = 10;
                    NewWorkSheet.Columns[11].WrapText = true;

                   // NewWorkSheet.Rows.RowHeight = 20;
                    for (int i = 4; i < 26; i++)
                    {
                        NewWorkSheet.Rows[i].RowHeight = 22;
                    }
                    NewWorkSheet.Rows[9].RowHeight = 30;
                    NewWorkSheet.Rows[14].RowHeight = 40;
                    NewWorkSheet.Rows[19].RowHeight = 120;
                    NewWorkSheet.Rows[24].RowHeight = 60;
                    NewWorkSheet.Rows[27].RowHeight = 40;


                    NewWorkSheet.PageSetup.PrintArea = "A1:K" + (iRowIndex) + "";
                    //    NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                    NewWorkSheet.PageSetup.PrintNotes = true;
                    NewWorkSheet.PageSetup.CenterHorizontally = true;
                    NewWorkSheet.PageSetup.Zoom = 78;
                    NewWorkSheet.PageSetup.LeftMargin = 0.3;
                    NewWorkSheet.PageSetup.RightMargin = 0.3;
                    NewWorkSheet.PageSetup.TopMargin = 1.8;
                    NewWorkSheet.PageSetup.BottomMargin = 0.3;
                    NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                    NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
                    // NewWorkSheet.PageSetup.AlignMarginsHeaderFooter = false;
                    // string filename = ("C:\\Databasepath\\Bisslogo.jpg");

                    //  Image HeaderPicture = Image.FromFile("C:\\Databasepath\\BiSSServiceQuoteHeader.jpg");

                    //   NewWorkSheet.PageSetup.CenterHeaderPicture.Filename = "C:\\Databasepath\\BiSSServiceQuoteHeader.jpg";
                    //   NewWorkSheet.PageSetup.CenterHeader = "&G";

                    if (File.Exists(Global.sITWLogo))
                    {
                        EXCEL.Range oRange1 = (EXCEL.Range)NewWorkSheet.Cells[2, 2];
                        Image oImage1 = Image.FromFile(Global.sITWLogo);
                        System.Windows.Forms.Clipboard.SetDataObject(oImage1, true);
                        NewWorkSheet.Paste(oRange1, Global.sITWLogo);
                    }

                    if (File.Exists("C:\\Databasepath\\InstronLogo1.jpg"))
                    {
                        EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 9];
                        Image oImage = Image.FromFile("C:\\Databasepath\\InstronLogo1.jpg");
                        System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                        NewWorkSheet.Paste(oRange, "C:\\Databasepath\\InstronLogo1.jpg");
                    }
                    //NewWorkSheet.PageSetup.LeftHeaderPicture.Filename = "C:\\Databasepath\\BissLogoTP.jpg";
                    //NewWorkSheet.PageSetup.LeftHeader = "&G";
                    //NewWorkSheet.PageSetup.CenterHeader = "Project Description";
                    //NewWorkSheet.PageSetup.RightHeader = "BISS/F/7.5/13";

                    //NewWorkSheet.PageSetup.RightFooter = "Page &P of &N";
                    //NewWorkSheet.PageSetup.LeftFooter = "Issue No: 04";
                    ////string _stLOGO = ("C:\\Databasepath\\Bisslogo.jpg");
                    //EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 7];

                    //Image oImage = Image.FromFile(_stLOGO);
                    //System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    //NewWorkSheet.Paste(oRange, _stLOGO);

                    NewWorkBook.Save();
                    ExcelApp.Visible = false;
                    ExcelApp.ActiveWorkbook.Saved = true;
                    NewWorkBook.ExportAsFixedFormat(EXCEL.XlFixedFormatType.xlTypePDF, FileFul, EXCEL.XlFixedFormatQuality.xlQualityStandard, true);

                    NewWorkBook.Close(true, misValue, misValue);
                    ExcelApp.Quit();
                    releaseObject(NewWorkSheet);
                    releaseObject(NewWorkBook);
                    releaseObject(ExcelApp);
                    System.Diagnostics.Process.Start(FileFul);
                    //ExcelApp.Visible = false;
                    //System.Threading.Thread.Sleep(1000);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    //foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                    //{
                    //    GetProcess.Kill();
                    //}
                }
            }
            else
            {
                MessageBox.Show("No items to save", "Error", 0, MessageBoxIcon.Question);
            }

        }



        private void frmServiceOrder_Load(object sender, EventArgs e)
        {

        }

        private void chkQuoteSavePath_CheckedChanged(object sender, EventArgs e)
        {
            if (chkQuoteSavePath.CheckState == CheckState.Checked)
            {
                if (MessageBox.Show("The default save location for quotes is '" + Properties.Settings.Default.ServiceQuotePath + "'\nClick on Yes to change the quote save location", "Save location", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                {
                    DialogResult result = folderBrowserDialog1.ShowDialog();
                    if (result == DialogResult.OK)
                    {
                        Properties.Settings.Default.ServiceQuotePath = folderBrowserDialog1.SelectedPath;
                        //Properties.Settings.Default.FolderPath = folderBrowserDialog1.SelectedPath;
                        Properties.Settings.Default.Save();
                        MessageBox.Show("The default save location for quotes changed to the selected path '" + Properties.Settings.Default.ServiceQuotePath + "'", "Success", 0, MessageBoxIcon.Information);
                        chkQuoteSavePath.Checked = false;
                    }
                    else
                    {
                        chkQuoteSavePath.Checked = false;
                    }
                }
                else
                {
                    chkQuoteSavePath.Checked = false;
                }
            }
        }
    }
}
