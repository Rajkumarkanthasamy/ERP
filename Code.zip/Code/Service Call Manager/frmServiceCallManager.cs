﻿using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Service_Call_Manager
{
    public partial class frmServiceCallManager : Form
    {
        public frmServiceCallManager()
        {
            InitializeComponent();
        }
    }
}
