﻿namespace Erp_Project_With_Buttons.BISS_Complaints
{
    partial class frmComplaintHistory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmComplaintHistory));
            this.label8 = new System.Windows.Forms.Label();
            this.txtDataSearch = new System.Windows.Forms.TextBox();
            this.dgComplaintHistory = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.dtptodate = new System.Windows.Forms.DateTimePicker();
            this.dtpfromdate = new System.Windows.Forms.DateTimePicker();
            this.SlNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ComplaintNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Building = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WorkLocation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TypeOfRequest = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DetailsOfWork = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WorkRequired = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Emergency = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ComplaintDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StatusofComplaint = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ComplaintResolvedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AuthorisedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AuthorisedRemarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CloseRemarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ComplaintClose = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FundResourceRequired = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GMReviewRequired = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgComplaintHistory)).BeginInit();
            this.SuspendLayout();
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(0, 7);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(267, 38);
            this.label8.TabIndex = 141;
            this.label8.Text = "Search By (Building, Type of Request, \r\nComplaint By, Priority, Status)";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtDataSearch
            // 
            this.txtDataSearch.Font = new System.Drawing.Font("Calibri", 12F);
            this.txtDataSearch.Location = new System.Drawing.Point(266, 14);
            this.txtDataSearch.Name = "txtDataSearch";
            this.txtDataSearch.Size = new System.Drawing.Size(356, 27);
            this.txtDataSearch.TabIndex = 140;
            this.txtDataSearch.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtDataSearch_KeyUp);
            // 
            // dgComplaintHistory
            // 
            this.dgComplaintHistory.AllowUserToAddRows = false;
            this.dgComplaintHistory.AllowUserToDeleteRows = false;
            this.dgComplaintHistory.AllowUserToResizeRows = false;
            this.dgComplaintHistory.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgComplaintHistory.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgComplaintHistory.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgComplaintHistory.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgComplaintHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgComplaintHistory.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SlNo,
            this.ComplaintNo,
            this.Building,
            this.WorkLocation,
            this.TypeOfRequest,
            this.DetailsOfWork,
            this.WorkRequired,
            this.Emergency,
            this.ComplaintDate,
            this.StatusofComplaint,
            this.ComplaintResolvedBy,
            this.AuthorisedBy,
            this.AuthorisedRemarks,
            this.CloseRemarks,
            this.ComplaintClose,
            this.FundResourceRequired,
            this.GMReviewRequired});
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgComplaintHistory.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgComplaintHistory.Location = new System.Drawing.Point(4, 48);
            this.dgComplaintHistory.MultiSelect = false;
            this.dgComplaintHistory.Name = "dgComplaintHistory";
            this.dgComplaintHistory.RowHeadersVisible = false;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgComplaintHistory.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dgComplaintHistory.Size = new System.Drawing.Size(1274, 631);
            this.dgComplaintHistory.TabIndex = 139;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(831, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 15);
            this.label1.TabIndex = 200;
            this.label1.Text = "To :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(688, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 15);
            this.label2.TabIndex = 199;
            this.label2.Text = "From :";
            // 
            // btnSearch
            // 
            this.btnSearch.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(953, 12);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(95, 35);
            this.btnSearch.TabIndex = 198;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // dtptodate
            // 
            this.dtptodate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtptodate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtptodate.Location = new System.Drawing.Point(859, 16);
            this.dtptodate.Name = "dtptodate";
            this.dtptodate.Size = new System.Drawing.Size(88, 26);
            this.dtptodate.TabIndex = 197;
            // 
            // dtpfromdate
            // 
            this.dtpfromdate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpfromdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpfromdate.Location = new System.Drawing.Point(733, 16);
            this.dtpfromdate.Name = "dtpfromdate";
            this.dtpfromdate.Size = new System.Drawing.Size(89, 26);
            this.dtpfromdate.TabIndex = 196;
            // 
            // SlNo
            // 
            this.SlNo.DataPropertyName = "SlNo";
            this.SlNo.HeaderText = "Sl No";
            this.SlNo.Name = "SlNo";
            this.SlNo.ReadOnly = true;
            this.SlNo.Width = 70;
            // 
            // ComplaintNo
            // 
            this.ComplaintNo.DataPropertyName = "ComplaintNo";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ComplaintNo.DefaultCellStyle = dataGridViewCellStyle2;
            this.ComplaintNo.HeaderText = "ComplaintNo";
            this.ComplaintNo.Name = "ComplaintNo";
            this.ComplaintNo.ReadOnly = true;
            this.ComplaintNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ComplaintNo.Width = 105;
            // 
            // Building
            // 
            this.Building.DataPropertyName = "Building";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.Building.DefaultCellStyle = dataGridViewCellStyle3;
            this.Building.HeaderText = "Building";
            this.Building.Name = "Building";
            this.Building.ReadOnly = true;
            this.Building.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Building.Width = 71;
            // 
            // WorkLocation
            // 
            this.WorkLocation.DataPropertyName = "WorkLocation";
            this.WorkLocation.HeaderText = "Work Location";
            this.WorkLocation.Name = "WorkLocation";
            this.WorkLocation.ReadOnly = true;
            this.WorkLocation.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.WorkLocation.Width = 114;
            // 
            // TypeOfRequest
            // 
            this.TypeOfRequest.DataPropertyName = "TypeOfRequest";
            this.TypeOfRequest.HeaderText = "Type Of Request";
            this.TypeOfRequest.Name = "TypeOfRequest";
            this.TypeOfRequest.ReadOnly = true;
            this.TypeOfRequest.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.TypeOfRequest.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.TypeOfRequest.Width = 114;
            // 
            // DetailsOfWork
            // 
            this.DetailsOfWork.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.DetailsOfWork.DataPropertyName = "DetailsOfWork";
            this.DetailsOfWork.HeaderText = "Details Of Work";
            this.DetailsOfWork.Name = "DetailsOfWork";
            this.DetailsOfWork.ReadOnly = true;
            this.DetailsOfWork.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DetailsOfWork.Width = 77;
            // 
            // WorkRequired
            // 
            this.WorkRequired.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.WorkRequired.DataPropertyName = "WorkRequired";
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.WorkRequired.DefaultCellStyle = dataGridViewCellStyle4;
            this.WorkRequired.HeaderText = "Suggestion";
            this.WorkRequired.Name = "WorkRequired";
            this.WorkRequired.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.WorkRequired.Width = 89;
            // 
            // Emergency
            // 
            this.Emergency.DataPropertyName = "Emergency";
            this.Emergency.HeaderText = "Priority";
            this.Emergency.Name = "Emergency";
            this.Emergency.ReadOnly = true;
            this.Emergency.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Emergency.Width = 67;
            // 
            // ComplaintDate
            // 
            this.ComplaintDate.DataPropertyName = "ComplaintDate";
            this.ComplaintDate.HeaderText = "Complaint Date";
            this.ComplaintDate.Name = "ComplaintDate";
            this.ComplaintDate.ReadOnly = true;
            this.ComplaintDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ComplaintDate.Width = 109;
            // 
            // StatusofComplaint
            // 
            this.StatusofComplaint.DataPropertyName = "StatusofComplaint";
            this.StatusofComplaint.HeaderText = "Status";
            this.StatusofComplaint.Name = "StatusofComplaint";
            this.StatusofComplaint.ReadOnly = true;
            this.StatusofComplaint.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.StatusofComplaint.Width = 58;
            // 
            // ComplaintResolvedBy
            // 
            this.ComplaintResolvedBy.DataPropertyName = "ComplaintResolvedBy";
            this.ComplaintResolvedBy.HeaderText = "Solved By";
            this.ComplaintResolvedBy.Name = "ComplaintResolvedBy";
            this.ComplaintResolvedBy.ReadOnly = true;
            this.ComplaintResolvedBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ComplaintResolvedBy.Width = 74;
            // 
            // AuthorisedBy
            // 
            this.AuthorisedBy.DataPropertyName = "AuthorisedBy";
            this.AuthorisedBy.HeaderText = "Authorised By";
            this.AuthorisedBy.Name = "AuthorisedBy";
            this.AuthorisedBy.ReadOnly = true;
            this.AuthorisedBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.AuthorisedBy.Width = 101;
            // 
            // AuthorisedRemarks
            // 
            this.AuthorisedRemarks.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.AuthorisedRemarks.DataPropertyName = "AuthorisedRemarks";
            this.AuthorisedRemarks.HeaderText = "Authorised Remarks";
            this.AuthorisedRemarks.Name = "AuthorisedRemarks";
            this.AuthorisedRemarks.ReadOnly = true;
            this.AuthorisedRemarks.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.AuthorisedRemarks.Width = 138;
            // 
            // CloseRemarks
            // 
            this.CloseRemarks.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.CloseRemarks.DataPropertyName = "CloseRemarks";
            this.CloseRemarks.HeaderText = "CloseRemarks";
            this.CloseRemarks.Name = "CloseRemarks";
            this.CloseRemarks.ReadOnly = true;
            this.CloseRemarks.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CloseRemarks.Width = 108;
            // 
            // ComplaintClose
            // 
            this.ComplaintClose.DataPropertyName = "ComplaintClose";
            this.ComplaintClose.HeaderText = "Complaint Closed";
            this.ComplaintClose.Name = "ComplaintClose";
            this.ComplaintClose.ReadOnly = true;
            this.ComplaintClose.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ComplaintClose.Width = 120;
            // 
            // FundResourceRequired
            // 
            this.FundResourceRequired.DataPropertyName = "FundResourceRequired";
            this.FundResourceRequired.HeaderText = "Fund Resource Required";
            this.FundResourceRequired.Name = "FundResourceRequired";
            this.FundResourceRequired.ReadOnly = true;
            this.FundResourceRequired.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.FundResourceRequired.Width = 163;
            // 
            // GMReviewRequired
            // 
            this.GMReviewRequired.DataPropertyName = "GMReviewRequired";
            this.GMReviewRequired.HeaderText = "GM Review Required";
            this.GMReviewRequired.Name = "GMReviewRequired";
            this.GMReviewRequired.ReadOnly = true;
            this.GMReviewRequired.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.GMReviewRequired.Width = 142;
            // 
            // frmComplaintHistory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1290, 684);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.dtptodate);
            this.Controls.Add(this.dtpfromdate);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtDataSearch);
            this.Controls.Add(this.dgComplaintHistory);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmComplaintHistory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Complaint History";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmComplaintHistory_FormClosing);
            this.Load += new System.EventHandler(this.frmComplaintHistory_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgComplaintHistory)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtDataSearch;
        private System.Windows.Forms.DataGridView dgComplaintHistory;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.DateTimePicker dtptodate;
        private System.Windows.Forms.DateTimePicker dtpfromdate;
        private System.Windows.Forms.DataGridViewTextBoxColumn SlNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ComplaintNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Building;
        private System.Windows.Forms.DataGridViewTextBoxColumn WorkLocation;
        private System.Windows.Forms.DataGridViewTextBoxColumn TypeOfRequest;
        private System.Windows.Forms.DataGridViewTextBoxColumn DetailsOfWork;
        private System.Windows.Forms.DataGridViewTextBoxColumn WorkRequired;
        private System.Windows.Forms.DataGridViewTextBoxColumn Emergency;
        private System.Windows.Forms.DataGridViewTextBoxColumn ComplaintDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn StatusofComplaint;
        private System.Windows.Forms.DataGridViewTextBoxColumn ComplaintResolvedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn AuthorisedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn AuthorisedRemarks;
        private System.Windows.Forms.DataGridViewTextBoxColumn CloseRemarks;
        private System.Windows.Forms.DataGridViewTextBoxColumn ComplaintClose;
        private System.Windows.Forms.DataGridViewTextBoxColumn FundResourceRequired;
        private System.Windows.Forms.DataGridViewTextBoxColumn GMReviewRequired;
    }
}