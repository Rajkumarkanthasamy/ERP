﻿using System;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.BISS_Complaints
{
    public partial class ComplaintHome : Form
    {
        public ComplaintHome()
        {
            InitializeComponent();
        }
        frmForm2 ERPHome = new frmForm2();
        private void btnComplaint_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmCompalint Complaint = new frmCompalint();
            Complaint.Show();
        }

        private void ComplaintHome_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            ERPHome.Show();
        }

        private void btnComplaintFeedback_Click(object sender, EventArgs e)
        {
            frmComplaintFeedback fb = new frmComplaintFeedback();
            this.Hide();
            fb.Show();
        }

        private void btnComplaintHistory_Click(object sender, EventArgs e)
        {
            frmComplaintHistory CH = new frmComplaintHistory();
            this.Hide();
            CH.Show();
        }

        private void ComplaintHome_Load(object sender, EventArgs e)
        {

        }
    }
}
