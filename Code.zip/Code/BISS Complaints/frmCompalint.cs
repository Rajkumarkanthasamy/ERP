﻿using System;
using System.Data;
using System.Windows.Forms;
using Outlook = Microsoft.Office.Interop.Outlook;

namespace Erp_Project_With_Buttons.BISS_Complaints
{
    public partial class frmCompalint : Form
    {
        DataAccessLayer DAL = new DataAccessLayer();
        Global GLobalClass = new Global();
        Login.frmLoginForm Login = new Login.frmLoginForm();
        DataTable dtComplaints = new DataTable();
        DataTable dtComplaintNumber = new DataTable();
        string sSalesINvoiceID;
        string sSalesInvoiceNumber;
        int iLastSalesINvoiceID;
        DataTable dtLoginDetails = new DataTable();
        frmForm2 form = new frmForm2();
        public frmCompalint()
        {
            InitializeComponent();
        }

        #region Complaint Form Load
        private void frmCompalint_Load(object sender, EventArgs e)
        {
            txtComplaintBy.Text = Login.GetUserDetails[2];
            txtDepartment.Text = Login.GetUserDetails[23];

            if (Login.GetUserDetails[23] == "IT" || Login.GetUserDetails[2].ToLower() == "cheluvaraj")
            {
                btnSave.Enabled = true;
                pnAdminpanel.Visible = true;
                pnAdmin.Visible = true;
                btnAccept.Enabled = true;
                btnReject.Enabled = true;
                if (Login.GetUserDetails[23] == "IT")
                {
                    dtComplaints = DAL.fnComplaintList(null, 1).Tables[0];
                }
                else if (Login.GetUserDetails[2].ToLower() == "cheluvaraj")
                {

                    label14.Visible = true;
                    dateTimePicker1RequiredTime.Visible = true;
                    comboBox1RemarksRequiredTime.Visible = true;
                    label15.Visible = true;
                   // button1.Visible = true;

                    dtComplaints = DAL.fnComplaintList(null, 11).Tables[0];
                }
                if (dtComplaints.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtComplaints.Rows)
                    {
                        if (!cmbComplaintNo.Items.Contains(dr["ComplaintNo"].ToString()))
                        {
                            cmbComplaintNo.Items.Add(dr["ComplaintNo"].ToString());
                        }
                    }
                }
            }
            else
            {
                btnSave.Enabled = true;
                pnAdmin.Visible = false;
                pnAdminpanel.Visible = false;
            }

            //DataTable dtUserName = DAL.fnUserList("", 2).Tables[0];
            //foreach (DataRow DR in dtUserName.Rows)
            //{
            //    if (!cmbUserCC.Items.Contains(DR["UserName"].ToString()))
            //        cmbUserCC.Items.Add(DR["UserName"].ToString());
            //}

        }
        #endregion

        #region Complaint Save
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtWorkLocation.Text) && !string.IsNullOrEmpty(cmbBuilding.Text) && !string.IsNullOrEmpty(cmbTypeofRequest.Text) && !string.IsNullOrEmpty(cmbEmergency.Text) && !string.IsNullOrEmpty(txtDetailsofWork.Text) && (cmbUser.SelectedIndex >= 0))
            {
                string sYear = DateTime.Today.Year.ToString() + "-" + (Convert.ToInt32(DateTime.Today.Year.ToString().Substring(2, 2)) + 1).ToString() + "/";
                dtComplaintNumber = DAL.fnComplaintNumber(null).Tables[0];
                if (dtComplaintNumber.Rows.Count > 0)
                {
                    sSalesINvoiceID = dtComplaintNumber.Rows[0]["ComplaintNo"].ToString();

                    if (!string.IsNullOrEmpty(sSalesINvoiceID))
                    {
                        sSalesINvoiceID = sSalesINvoiceID.Substring(18, 5);
                        iLastSalesINvoiceID = Convert.ToInt32(sSalesINvoiceID);
                    }
                    else
                    {
                        iLastSalesINvoiceID = 0;
                    }
                    iLastSalesINvoiceID++;
                    sSalesInvoiceNumber = "";
                    string value = String.Format("{0:D5}", iLastSalesINvoiceID);
                    sSalesInvoiceNumber = ("ITW/CMPLT/" + sYear + value);
                    txtComplaintNo.Text = sSalesInvoiceNumber;

                    GLobalClass.iSuccess = DAL.fnAddComplaint(Global.uINSERT, txtComplaintNo.Text, txtComplaintBy.Text, txtDepartment.Text, cmbBuilding.Text, txtWorkLocation.Text,
                                                         txtWorkRequired.Text, cmbTypeofRequest.Text, txtDetailsofWork.Text, cmbEmergency.Text, dtpComplaintDate.Text,
                                                         "", "", "", "", "", "", cmbUser.Text);
                    if (GLobalClass.iSuccess > 0)
                    {
                        CreateMailItem();
                        MessageBox.Show("New complaint no '" + txtComplaintNo.Text + "' raised successfully ", "Success", 0, MessageBoxIcon.Information);
                        FormReload();
                    }
                    else
                    {
                        MessageBox.Show("Complaint not saved. Please try again ", "Error", 0, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Complaint not saved. Please try again ", "Error", 0, MessageBoxIcon.Error);
                }
            }

            else
            {
                if (string.IsNullOrEmpty(cmbBuilding.Text))
                {
                    MessageBox.Show("Building not selected", "Error", 0, MessageBoxIcon.Error);
                    cmbBuilding.Focus();
                }
                else if (string.IsNullOrEmpty(txtWorkLocation.Text))
                {
                    MessageBox.Show("Work location not mentioned", "Error", 0, MessageBoxIcon.Error);
                    txtWorkLocation.Focus();
                }
                else if (string.IsNullOrEmpty(cmbTypeofRequest.Text))
                {
                    MessageBox.Show("Type of work request not selected", "Error", 0, MessageBoxIcon.Error);
                    cmbTypeofRequest.Focus();
                }
                else if (string.IsNullOrEmpty(cmbEmergency.Text))
                {
                    MessageBox.Show("Priority not selected", "Error", 0, MessageBoxIcon.Error);
                    cmbEmergency.Focus();
                }
                else if (string.IsNullOrEmpty(txtDetailsofWork.Text))
                {
                    MessageBox.Show("Work required not mentioned", "Error", 0, MessageBoxIcon.Error);
                    txtDetailsofWork.Focus();
                }
                else if (cmbUser.SelectedIndex < 0)
                {
                    MessageBox.Show("Select send the complaint request to user name", "Error", 0, MessageBoxIcon.Error);
                    cmbUser.Focus();
                }
            }
        }
        #endregion

        #region Code for sending outlook email alert 
        private void CreateMailItem()
        {
            try
            {
                Outlook.Application oApp = new Outlook.Application();
                Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                oMsg.Subject = "Complaint Number '" + txtComplaintNo.Text + "'";
                //  oMsg.iHTMLBody = true;
                oMsg.HTMLBody = @"<font face=Calibri> Hi " + cmbUser.Text + ", <br /> I have raised a request on the following.<br /> <br /> <b>Request By :</b> " + txtComplaintBy.Text + "   <br /><br /> <b>Priority :</b> " + cmbEmergency.Text + " <br /> <b>Building :</b> " + cmbBuilding.Text + "    <b>Work location :</b> " + txtWorkLocation.Text + " <br /><br /> <b>Type of request :</b> " + cmbTypeofRequest.Text + " <br /><br /> <b>Details of the request :</b> " + txtDetailsofWork.Text + " <br /> <br /> <br /> <br /> <b>**** This is an automatically generated email, please do not reply ****</b> </font>";
                //  oMsg.HTMLBody = oMsg.HTMLBody.Replace("Times New Roman", "Calibri"); 
                // Add a recipient.
                Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;


                // foreach (string tempTO in lstAddUser.Items)
                {
                    // if (tempTO != null)
                    oRecips.Add(sEmailID);
                }
                oRecips.ResolveAll();
                // Add cc
                 oRecips.Add("Ramakrishna_Hebbar@instron.com");
                 oRecips.Add("Vivek_Gunasekaran@instron.com");
                 oRecips.Add("Vishal_Raina@instron.com");
                 oRecips.Add("Ravindra_Naiker@instron.com");
                 oRecips.Add("Santhosh_D.J@instron.com");
                 oRecips.Add("Hemanth_Reddy@instron.com");
                 oRecips.Add("Manoj_H@instron.com");
                 oRecips.Add("Raghavendra_K@instron.com");
                 oRecips.Add("Suresh_Kumbar@instron.com");


                Outlook.Recipient oRecip = (Outlook.Recipient)oRecips.Add("Gemini_V@instron.com");//, "Gemini_V@instron.com"
                oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                oRecip.Resolve();
                // Send.
                oMsg.Send();
                // Clean up.
                oRecip = null;
                oRecips = null;
                oMsg = null;
                oApp = null;
            }
            catch (Exception ex)
            {

            }

        }
        #endregion


        #region Code to send Accept mail
        private void CreateAcceptMail()
        {
            dtLoginDetails = DAL.fnloginemail(txtComplaintBy.Text).Tables[0];
            if (dtLoginDetails.Rows.Count > 0 && !string.IsNullOrEmpty(dtLoginDetails.Rows[0]["emailid"].ToString()))
            {
                try
                {
                    Outlook.Application oApp = new Outlook.Application();
                    Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                    oMsg.Subject = "Complaint Number '" + txtComplaintNo.Text.ToUpper() + "'";
                    //  oMsg.iHTMLBody = true;
                    oMsg.HTMLBody = @"<font face=Calibri> Dear " + txtComplaintBy.Text + " ,<br /> <br /> Your request has been accepted by '" + Login.GetUserDetails[2].ToUpper() + "'.<br /> Request will be sloved on or before '" + dtpComplaintSolvedBy.Text + "'.<br /> <br /> <b>Details of the request :</b> " + txtDetailsofWork.Text + " <br /><br /> <b> Remarks:</b> " + txtAuthorisedPersonRemarks.Text + " <br />  <br /> <br /> <br /><b> *** This is an automatically generated email, please do not reply *** </b> </font>";

                    // Add a recipient.
                    Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;


                    oRecips.Add("" + dtLoginDetails.Rows[0]["emailid"].ToString() + "");

                    oRecips.ResolveAll();
                    // Add cc
                    oRecips.Add("Ramakrishna_Hebbar@instron.com");
                    oRecips.Add("Vivek_Gunasekaran@instron.com");
                    oRecips.Add("Vishal_Raina@instron.com");
                    oRecips.Add("Ravindra_Naiker@instron.com");
                    oRecips.Add("Santhosh_D.J@instron.com");
                    oRecips.Add("Hemanth_Reddy@instron.com");
                    oRecips.Add("Manoj_H@instron.com");
                    oRecips.Add("Raghavendra_K@instron.com");
                    oRecips.Add("Suresh_Kumbar@instron.com");
                    Outlook.Recipient oRecip = (Outlook.Recipient)oRecips.Add("Gemini_V@instron.com");//Gemini_V@instron.com
                    oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                    oRecip.Resolve();
                    // Send.
                    oMsg.Send();
                    // Clean up.
                    //   oRecip = null;
                    oRecips = null;
                    oMsg = null;
                    oApp = null;
                }
                catch (Exception ex)
                {

                }
            }
        }

        private void CreateAcceptMailMaitanceTeam()
        {
            dtLoginDetails = DAL.fnloginemail(txtComplaintBy.Text).Tables[0];
            if (dtLoginDetails.Rows.Count > 0 && !string.IsNullOrEmpty(dtLoginDetails.Rows[0]["emailid"].ToString()))
            {
                try
                {
                    Outlook.Application oApp = new Outlook.Application();
                    Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                    oMsg.Subject = "Complaint Number '" + txtComplaintNo.Text.ToUpper() + "'";
                    //  oMsg.iHTMLBody = true;
                    oMsg.HTMLBody = @"<font face=Calibri> Dear " + txtComplaintBy.Text + " ,<br /> <br /> Your request has been accepted by '" + Login.GetUserDetails[2].ToUpper() + "'.<br /> Request will be sloved on or before '" + dateTimePicker1RequiredTime.Text + "'.<br /> <br /> <b>Details of the request :</b> " + txtDetailsofWork.Text + " <br /><br /> <b>Completion Date :</b> " + dateTimePicker1RequiredTime.Text + " <br /><br /> <b>Remarks for Time Required :</b> " + comboBox1RemarksRequiredTime.Text + " <br /><br /> <b> Remarks:</b> " + txtAuthorisedPersonRemarks.Text + " <br />  <br /> <br /> <br /><b> *** This is an automatically generated email, please do not reply *** </b> </font>";

                    // Add a recipient.
                    Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;


                    oRecips.Add("" + dtLoginDetails.Rows[0]["emailid"].ToString() + "");

                    oRecips.ResolveAll();
                    // Add cc
                    //oRecips.Add("rajkumar.k@kmpsdi.com");
                    oRecips.Add("Ramakrishna_Hebbar@instron.com");
                    oRecips.Add("Vivek_Gunasekaran@instron.com");
                    oRecips.Add("Vishal_Raina@instron.com");
                    oRecips.Add("Ravindra_Naiker@instron.com");
                    oRecips.Add("Santhosh_D.J@instron.com");
                    oRecips.Add("Hemanth_Reddy@instron.com");
                    oRecips.Add("Manoj_H@instron.com");
                    oRecips.Add("Raghavendra_K@instron.com");
                    oRecips.Add("Suresh_Kumbar@instron.com");
                    Outlook.Recipient oRecip = (Outlook.Recipient)oRecips.Add("Gemini_V@instron.com");//Gemini_V@instron.com
                    oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                    oRecip.Resolve();
                    // Send.
                    oMsg.Send();
                    // Clean up.
                    //   oRecip = null;
                    oRecips = null;
                    oMsg = null;
                    oApp = null;
                }
                catch (Exception ex)
                {

                }
            }
        }


        private void CreateRequiredMail()
        {
            dtLoginDetails = DAL.fnloginemail(txtComplaintBy.Text).Tables[0];
            if (dtLoginDetails.Rows.Count > 0 && !string.IsNullOrEmpty(dtLoginDetails.Rows[0]["emailid"].ToString()))
            {
                try
                {
                    Outlook.Application oApp = new Outlook.Application();
                    Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                    oMsg.Subject = "Complaint Number '" + txtComplaintNo.Text.ToUpper() + "'";
                    //  oMsg.iHTMLBody = true;
                    oMsg.HTMLBody = @"<font face=Calibri> Dear " + txtComplaintBy.Text + " ,<br /> <br /> Your request has been accepted by '" + Login.GetUserDetails[2].ToUpper() + "'.<br /> Request will be sloved on or before '" + dtpComplaintSolvedBy.Text + "'.<br /> <br /> <b>Details of the request :</b> " + txtDetailsofWork.Text + " <br /><br />  <b> Remarks:</b> " + txtAuthorisedPersonRemarks.Text + " <br />  <br /> <br /> <br /><b> *** This is an automatically generated email, please do not reply *** </b> </font>";

                    // Add a recipient.
                    Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;


                    oRecips.Add("" + dtLoginDetails.Rows[0]["emailid"].ToString() + "");

                    oRecips.ResolveAll();
                    // Add cc
                    oRecips.Add("Ramakrishna_Hebbar@instron.com");
                    oRecips.Add("Vivek_Gunasekaran@instron.com");
                    oRecips.Add("Vishal_Raina@instron.com");
                    oRecips.Add("Ravindra_Naiker@instron.com");
                    oRecips.Add("Santhosh_D.J@instron.com");
                    oRecips.Add("Hemanth_Reddy@instron.com");
                    oRecips.Add("Manoj_H@instron.com");
                    oRecips.Add("Raghavendra_K@instron.com");
                    oRecips.Add("Suresh_Kumbar@instron.com");
                    Outlook.Recipient oRecip = (Outlook.Recipient)oRecips.Add("Gemini_V@instron.com");//Gemini_V@instron.com
                    oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                    oRecip.Resolve();
                    // Send.
                    oMsg.Send();
                    // Clean up.
                    //   oRecip = null;
                    oRecips = null;
                    oMsg = null;
                    oApp = null;
                }
                catch (Exception ex)
                {

                }
            }
        }

        #endregion

        #region Code to send Reject mail
        private void CreateRejectMail()
        {
            dtLoginDetails = DAL.fnloginemail(txtComplaintBy.Text).Tables[0];
            if (dtLoginDetails.Rows.Count > 0 && !string.IsNullOrEmpty(dtLoginDetails.Rows[0]["emailid"].ToString()))
            {
                try
                {
                    Outlook.Application oApp = new Outlook.Application();
                    Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                    oMsg.Subject = "Complaint Number '" + txtComplaintNo.Text.ToUpper() + "'";
                    oMsg.HTMLBody = @"<font face=Calibri> Dear " + txtComplaintBy.Text + " , <br /> Your complaint has been reject by '" + Login.GetUserDetails[2].ToUpper() + "'. <br /> Reason for comaplaint reject : '" + txtAuthorisedPersonRemarks.Text + "'.<br /> <br /> <br /> <br /> *** This is an automatically generated email, please do not reply *** </font>";
                    Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                    oRecips.Add("" + dtLoginDetails.Rows[0]["emailid"].ToString() + "");
                    oRecips.ResolveAll();
                    oRecips.Add("Ramakrishna_Hebbar@instron.com");
                    oRecips.Add("Vivek_Gunasekaran@instron.com");
                    oRecips.Add("Vishal_Raina@instron.com");
                    oRecips.Add("Ravindra_Naiker@instron.com");
                    oRecips.Add("Santhosh_D.J@instron.com");
                    oRecips.Add("Hemanth_Reddy@instron.com");
                    oRecips.Add("Manoj_H@instron.com");
                    oRecips.Add("Raghavendra_K@instron.com");
                    oRecips.Add("Suresh_Kumbar@instron.com");
                    Outlook.Recipient oRecip = (Outlook.Recipient)oRecips.Add("Gemini_V@instron.com");//Gemini_V@instron.com
                    oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                    oRecip.Resolve();
                    oMsg.Send();
                    oRecips = null;
                    oMsg = null;
                    oApp = null;
                }
                catch (Exception ex)
                {

                }
            }
        }

        #endregion

        #region Code to send Complaint Close mail
        private void CreateFinishMail()
        {
            dtLoginDetails = DAL.fnloginemail(txtComplaintBy.Text).Tables[0];
            if (dtLoginDetails.Rows.Count > 0 && !string.IsNullOrEmpty(dtLoginDetails.Rows[0]["emailid"].ToString()))
            {
                try
                {
                    Outlook.Application oApp = new Outlook.Application();
                    Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                    oMsg.Subject = "Complaint Number '" + txtComplaintNo.Text.ToUpper() + "'";
                    oMsg.HTMLBody = @"<font face=Calibri> Dear " + txtComplaintBy.Text + " , <br /> Your request has been closed by '" + Login.GetUserDetails[2].ToUpper() + "'. <br /><br />  <b>Details of the request :</b> " + txtDetailsofWork.Text + " <br /><br />  <b> Remarks:</b> " + txtAuthorisedPersonRemarks.Text + " <br /> <br />You can now rate & write a feedback.<br /> <br /> <br /> <br /> <b>*** This is an automatically generated email, please do not reply *** </b></font>";
                    Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                    oRecips.Add("" + dtLoginDetails.Rows[0]["emailid"].ToString() + "");
                    oRecips.ResolveAll();
                    oRecips.Add("Ramakrishna_Hebbar@instron.com");
                    oRecips.Add("Vivek_Gunasekaran@instron.com");
                    oRecips.Add("Vishal_Raina@instron.com");
                    oRecips.Add("Ravindra_Naiker@instron.com");
                    oRecips.Add("Santhosh_D.J@instron.com");
                    oRecips.Add("Hemanth_Reddy@instron.com");
                    oRecips.Add("Manoj_H@instron.com");
                    oRecips.Add("Raghavendra_K@instron.com");
                    oRecips.Add("Suresh_Kumbar@instron.com");
                    Outlook.Recipient oRecip = (Outlook.Recipient)oRecips.Add("Gemini_V@instron.com");//Gemini_V@instron.com
                    oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                    oRecip.Resolve();
                    oMsg.Send();
                    oRecips = null;
                    oMsg = null;
                    oApp = null;
                }
                catch (Exception ex)
                {

                }
            }
        }
        #endregion'
        private void FormReload()
        {
            this.Hide();
            frmCompalint Complaint = new frmCompalint();
            Complaint.Show();
        }

        #region Code to close coplaint
        private void btnClose_Click(object sender, EventArgs e)
        {
            GLobalClass.iSuccess = DAL.fnAddComplaint(3, cmbComplaintNo.Text, "Closed", dtpAcceptdate.Text, "", "", "", "", "", "", "", "",
                                              "", "", "", "", "", txtAuthorisedPersonRemarks.Text);
            //   if (GLobalClass.iSuccess == 1)
            {
                CreateFinishMail();
                MessageBox.Show("Complaint number " + cmbComplaintNo.Text + "issue is closed", "Inforamation", 0, MessageBoxIcon.Information);
                cmbComplaintNo.SelectedText = "";
                FormReload();
            }
        }

        #endregion

        #region Code to reject complaint
        private void btnReject_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtAuthorisedPersonRemarks.Text))
            {


                GLobalClass.iSuccess = DAL.fnAddComplaint(1, txtComplaintNo.Text, txtComplaintBy.Text, dtpAcceptdate.Text, cmbBuilding.Text, txtWorkLocation.Text,
                                                       txtWorkRequired.Text, cmbTypeofRequest.Text, txtDetailsofWork.Text, cmbEmergency.Text, dtpComplaintDate.Text,
                                                      "", "", "", Login.GetUserDetails[2], txtAuthorisedPersonRemarks.Text, "Reject", "");
                //   if (GLobalClass.iSuccess == 1)
                {
                    CreateRejectMail();
                    MessageBox.Show("Complaint no '" + txtComplaintNo.Text + "' rejected", "Success", 0, MessageBoxIcon.Warning);
                    FormReload();
                }
            }
            else
            {
                MessageBox.Show("Please write the remarks for reviewing the comaplaint", "Error", 0, MessageBoxIcon.Error);
                txtAuthorisedPersonRemarks.Focus();
            }
        }
        #endregion

        #region Code to Accept complaint
        bool bDatechange = false;
        private void btnAccept_Click(object sender, EventArgs e)
        {
            if (bDatechange == true && !string.IsNullOrEmpty(cmbFundResourceRequired.Text) && !string.IsNullOrEmpty(cmbGMReviewRequired.Text))
            {
                bDatechange = false;
                GLobalClass.iSuccess = DAL.fnAddComplaint(1, txtComplaintNo.Text, txtComplaintBy.Text, dtpAcceptdate.Text, cmbBuilding.Text, txtWorkLocation.Text,
                                                        txtWorkRequired.Text, cmbTypeofRequest.Text, txtDetailsofWork.Text, cmbEmergency.Text, dtpComplaintDate.Text,
                                                        cmbFundResourceRequired.Text, cmbGMReviewRequired.Text, dtpComplaintSolvedBy.Text, Login.GetUserDetails[2], txtAuthorisedPersonRemarks.Text, "Accept", "");
                //   if (GLobalClass.iSuccess == 1)
                if(Login.GetUserDetails[2].ToLower() != "cheluvaraj")
                {
                    CreateAcceptMail();
                    MessageBox.Show("Complaint no '" + txtComplaintNo.Text + "' accepted successfully ", "Success", 0, MessageBoxIcon.Information);
                    FormReload();
                }
                else
                {
                    CreateAcceptMailMaitanceTeam();
                   


                    int fnUpdateComplaintStatus = DAL.fnUpdateComplaint(1, txtComplaintNo.Text, dateTimePicker1RequiredTime.Text, comboBox1RemarksRequiredTime.Text);
                    MessageBox.Show("Complaint no '" + txtComplaintNo.Text + "' accepted successfully ", "Success", 0, MessageBoxIcon.Information);
                    FormReload();
                }
               
            }
            else
            {
                if (bDatechange == false)
                {
                    MessageBox.Show("Select complaint resolved by date", "Error", 0, MessageBoxIcon.Error);
                    dtpComplaintSolvedBy.Focus();
                }
                else if (string.IsNullOrEmpty(cmbFundResourceRequired.Text))
                {
                    MessageBox.Show("Fund/resource required not selected", "Error", 0, MessageBoxIcon.Error);
                    cmbFundResourceRequired.Focus();
                }
                else if (string.IsNullOrEmpty(cmbGMReviewRequired.Text))
                {
                    MessageBox.Show("GM review required not selected", "Error", 0, MessageBoxIcon.Error);
                    cmbGMReviewRequired.Focus();
                }
            }
        }
        #endregion

        #region Code to validate date
        private void dtpComplaintSolvedBy_ValueChanged(object sender, EventArgs e)
        {
            bDatechange = true;
        }

        #endregion
        #region Code to load complaint details
        private void cmbComplaintNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtComplaints = DAL.fnComplaintList(cmbComplaintNo.Text, 1).Tables[0];
            if (dtComplaints.Rows.Count > 0)
            {
                txtComplaintNo.Text = dtComplaints.Rows[0]["ComplaintNo"].ToString();
                txtComplaintBy.Text = dtComplaints.Rows[0]["ComaplaintBy"].ToString();
                txtDepartment.Text = dtComplaints.Rows[0]["Department"].ToString();
                cmbBuilding.SelectedItem = dtComplaints.Rows[0]["Building"].ToString();
                txtWorkLocation.Text = dtComplaints.Rows[0]["WorkLocation"].ToString();
                txtWorkRequired.Text = dtComplaints.Rows[0]["WorkRequired"].ToString();
                cmbTypeofRequest.SelectedItem = dtComplaints.Rows[0]["TypeOfRequest"].ToString();
                dtpComplaintDate.Value = Convert.ToDateTime(dtComplaints.Rows[0]["ComplaintDate"]);
                txtDetailsofWork.Text = dtComplaints.Rows[0]["DetailsOfWork"].ToString();
                cmbEmergency.SelectedItem = dtComplaints.Rows[0]["Emergency"].ToString();

                if (chkCloseComplaint.CheckState == CheckState.Checked)
                {
                    cmbFundResourceRequired.SelectedItem = dtComplaints.Rows[0]["FundResourceRequired"].ToString();
                    cmbGMReviewRequired.SelectedItem = dtComplaints.Rows[0]["GMReviewRequired"].ToString();
                    if (!string.IsNullOrEmpty(dtComplaints.Rows[0]["ComplaintResolvedBy"].ToString()))
                    {
                        dtpComplaintSolvedBy.Value = Convert.ToDateTime(dtComplaints.Rows[0]["ComplaintResolvedBy"]);
                        dtpComplaintSolvedBy.Enabled = false;
                    }
                }
                else
                {
                    cmbFundResourceRequired.SelectedIndex = -1;
                    cmbGMReviewRequired.SelectedIndex = -1;
                    dtpComplaintSolvedBy.Value = DateTime.Today;
                    dtpComplaintSolvedBy.Enabled = true;
                }
            }
            else
            {
                txtComplaintNo.ResetText();
                txtComplaintBy.ResetText();
                txtDepartment.ResetText();
                cmbBuilding.SelectedIndex = -1;
                txtWorkLocation.ResetText();
                txtWorkRequired.ResetText();
                cmbTypeofRequest.SelectedIndex = -1;
                dtpComplaintDate.Value = DateTime.Today;
                txtDetailsofWork.ResetText();
                cmbEmergency.SelectedIndex = -1;
            }
        }
        #endregion

        #region Code to load Email ID
        DataTable dtlogindetails = new DataTable();
        string sEmailID;
        private void cmbUserCC_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbUser.SelectedIndex)
            {
                case 0:
                    sEmailID = "Cheluvaraj_V@instron.com";//Cheluvaraj_V@instron.com
                    break;
                case 1:
                    sEmailID = "Sivanaga_Arja@instron.com";//Sivanaga_Arja@instron.com
                    break;
            }
        }
        #endregion

        #region Code to Close Copmalint
        private void chkCloseComplaint_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCloseComplaint.CheckState == CheckState.Checked)
            {
                btnReject.Enabled = false;
                btnAccept.Enabled = false;
                btnClose.Enabled = true;
                cmbComplaintNo.Items.Clear();
                if (Login.GetUserDetails[23] == "IT")
                {
                    dtComplaints = DAL.fnComplaintList(null, 4).Tables[0];
                }
                else if (Login.GetUserDetails[2].ToLower() == "cheluvaraj")
                {
                    dtComplaints = DAL.fnComplaintList(null, 41).Tables[0];
                }

                if (dtComplaints.Rows.Count > 0)
                {
                    foreach (DataRow dr in dtComplaints.Rows)
                    {
                        if (!cmbComplaintNo.Items.Contains(dr["ComplaintNo"].ToString()))
                        {
                            cmbComplaintNo.Items.Add(dr["ComplaintNo"].ToString());
                        }
                    }
                }

                chkCloseComplaint.Visible = true;
                pnAdmin.Visible = true;
                lblAuthorRemarks.Visible = true;
                txtAuthorisedPersonRemarks.Visible = true;
                txtComplaintNo.Visible = false;
                cmbComplaintNo.Visible = true;
                btnAccept.Visible = true;
                btnReject.Visible = true;
                btnSave.Enabled = false;
            }
            else
            {
                frmCompalint Complaint = new frmCompalint();
                this.Hide();
                Complaint.Show();
            }
        }
        #endregion

        #region Code to exit form
        private void frmCompalint_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnExit();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            fnExit();
        }
        private void fnExit()
        {
            this.Hide();
           form.Show();
        }
        #endregion

        private void button1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(comboBox1RemarksRequiredTime.Text))
            {
                int fnUpdateComplaintStatus = DAL.fnUpdateComplaint(1, txtComplaintNo.Text, dateTimePicker1RequiredTime.Text, comboBox1RemarksRequiredTime.Text);
                CreateRequiredMail();
                MessageBox.Show("Time Line Updated...");
            }
            else {
                MessageBox.Show("Please Select the Remarks for Required Time..");
            }

        }
    }
}
