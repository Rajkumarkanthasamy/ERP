﻿namespace Erp_Project_With_Buttons.BISS_Complaints
{
    partial class ComplaintHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ComplaintHome));
            this.lblName = new System.Windows.Forms.Label();
            this.btnComplaintFeedback = new System.Windows.Forms.Button();
            this.btnComplaintHistory = new System.Windows.Forms.Button();
            this.btnComplaint = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblName.Location = new System.Drawing.Point(306, 33);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(271, 29);
            this.lblName.TabIndex = 28;
            this.lblName.Text = "BiSS Facility Maintainance";
            // 
            // btnComplaintFeedback
            // 
            this.btnComplaintFeedback.BackColor = System.Drawing.Color.Silver;
            this.btnComplaintFeedback.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnComplaintFeedback.FlatAppearance.BorderSize = 0;
            this.btnComplaintFeedback.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnComplaintFeedback.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnComplaintFeedback.ForeColor = System.Drawing.Color.MediumBlue;
            this.btnComplaintFeedback.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_edit_row_481;
            this.btnComplaintFeedback.Location = new System.Drawing.Point(415, 136);
            this.btnComplaintFeedback.Name = "btnComplaintFeedback";
            this.btnComplaintFeedback.Size = new System.Drawing.Size(125, 85);
            this.btnComplaintFeedback.TabIndex = 34;
            this.btnComplaintFeedback.Text = "User FeedBack";
            this.btnComplaintFeedback.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnComplaintFeedback.UseVisualStyleBackColor = false;
            this.btnComplaintFeedback.Click += new System.EventHandler(this.btnComplaintFeedback_Click);
            // 
            // btnComplaintHistory
            // 
            this.btnComplaintHistory.BackColor = System.Drawing.Color.Silver;
            this.btnComplaintHistory.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnComplaintHistory.FlatAppearance.BorderSize = 0;
            this.btnComplaintHistory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnComplaintHistory.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnComplaintHistory.ForeColor = System.Drawing.Color.MediumBlue;
            this.btnComplaintHistory.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_task_planning_48__1_;
            this.btnComplaintHistory.Location = new System.Drawing.Point(742, 136);
            this.btnComplaintHistory.Name = "btnComplaintHistory";
            this.btnComplaintHistory.Size = new System.Drawing.Size(143, 85);
            this.btnComplaintHistory.TabIndex = 32;
            this.btnComplaintHistory.Text = "Complaint History";
            this.btnComplaintHistory.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnComplaintHistory.UseVisualStyleBackColor = false;
            this.btnComplaintHistory.Click += new System.EventHandler(this.btnComplaintHistory_Click);
            // 
            // btnComplaint
            // 
            this.btnComplaint.BackColor = System.Drawing.Color.Silver;
            this.btnComplaint.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnComplaint.FlatAppearance.BorderSize = 0;
            this.btnComplaint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnComplaint.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnComplaint.ForeColor = System.Drawing.Color.MediumBlue;
            this.btnComplaint.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_clipboard_48;
            this.btnComplaint.Location = new System.Drawing.Point(87, 136);
            this.btnComplaint.Name = "btnComplaint";
            this.btnComplaint.Size = new System.Drawing.Size(131, 85);
            this.btnComplaint.TabIndex = 30;
            this.btnComplaint.Text = "Complaint Form";
            this.btnComplaint.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnComplaint.UseVisualStyleBackColor = false;
            this.btnComplaint.Click += new System.EventHandler(this.btnComplaint_Click);
            // 
            // ComplaintHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(972, 455);
            this.Controls.Add(this.btnComplaintFeedback);
            this.Controls.Add(this.btnComplaintHistory);
            this.Controls.Add(this.btnComplaint);
            this.Controls.Add(this.lblName);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "ComplaintHome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BiSS Facility Maintainance";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ComplaintHome_FormClosing);
            this.Load += new System.EventHandler(this.ComplaintHome_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnComplaintFeedback;
        private System.Windows.Forms.Button btnComplaintHistory;
        private System.Windows.Forms.Button btnComplaint;
        private System.Windows.Forms.Label lblName;
    }
}