﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.BISS_Complaints
{
    public partial class frmComplaintFeedback : Form
    {
        public frmComplaintFeedback()
        {
            InitializeComponent();
        }
        DataAccessLayer DAL = new DataAccessLayer();
        Global GLobalClass = new Global();
        Login.frmLoginForm Login = new Login.frmLoginForm();
        DataTable dtComplaints = new DataTable();
        frmForm2 form = new frmForm2();
        private void frmComplaintFeedback_Load(object sender, EventArgs e)
        {
            trackBar1.Minimum = 0;
            trackBar1.Maximum = 5;

            dtComplaints = DAL.fnComplaintList(Login.GetUserDetails[2], 3).Tables[0];
            if (dtComplaints.Rows.Count > 0)
            {
                foreach (DataRow dr in dtComplaints.Rows)
                {
                    if (!cmbComplaintNo.Items.Contains(dr["ComplaintNo"].ToString()))
                    {
                        cmbComplaintNo.Items.Add(dr["ComplaintNo"].ToString());
                    }
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(lblTrackRating.Text) >= 1 && !string.IsNullOrEmpty(cmbComplaintNo.Text))
            {
                GLobalClass.iSuccess = DAL.fnAddComplaint(2, cmbComplaintNo.Text, lblTrackRating.Text, txtFeedback.Text, "", "", "", "", "", "", "", "",
                                                     "", "", "", "", "","");
                {
                    MessageBox.Show("Thank you for the feedback", "Information", 0, MessageBoxIcon.Information);
                    cmbComplaintNo.SelectedText = "";
                    FormReload();
                }
            }
            else
            {
                if (Convert.ToInt32(lblTrackRating.Text) < 1)
                {
                    MessageBox.Show("Please rate the complaint solved", "Error", 0, MessageBoxIcon.Error);
                    trackBar1.Focus();
                }
                else if (string.IsNullOrEmpty(cmbComplaintNo.Text))
                {
                    MessageBox.Show("Please select the comaplint number", "Error", 0, MessageBoxIcon.Error);
                    cmbComplaintNo.Focus();
                }
            }
        }

        private void FormReload()
        {
            this.Hide();
            frmComplaintFeedback feedback = new frmComplaintFeedback();
            feedback.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            fnExit();
        }

        private void fnExit()
        {
            this.Hide();
            form.Show();
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            lblTrackRating.Text = trackBar1.Value.ToString();
        }

        private void frmComplaintFeedback_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnExit();
        }
    }
}
