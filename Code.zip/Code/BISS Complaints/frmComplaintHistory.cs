﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.BISS_Complaints
{
    public partial class frmComplaintHistory : Form
    {
        public frmComplaintHistory()
        {
            InitializeComponent();
        }
        Global GLobalClass = new Global();
        frmForm2 form = new frmForm2();
        DataAccessLayer DAL = new DataAccessLayer();
        DataTable dtComplaints = new DataTable();
        Login.frmLoginForm Login = new Login.frmLoginForm();
        List<string> lRowColor = new List<string>();
        private void frmComplaintHistory_Load(object sender, EventArgs e)
        {
            // if (Login.GetUserDetails[2].ToLower() == "gemini" || Login.GetUserDetails[2].ToLower() == "cheluvaraj" || Login.GetUserDetails[2].ToLower() == "nagendra")
            {
                //dtComplaints = DAL.fnComplaintList(null, 5).Tables[0];
                //dgComplaintHistory.AutoGenerateColumns = false;
                //dgComplaintHistory.DataSource = dtComplaints;
                //Datagridviewcolor();
            }
            //else
            //{
            //    dtComplaints = DAL.fnComplaintList(Login.GetUserDetails[2].ToString(), 2).Tables[0];
            //    dgComplaintHistory.AutoGenerateColumns = false;
            //    dgComplaintHistory.DataSource = dtComplaints;
            //    Datagridviewcolor();
            //}
        }

        DataTable dtClone = new DataTable();
        BindingSource bsIteSearch = new BindingSource();


        #region Function to Group Multiple Products By Color
        private void Datagridviewcolor()
        {
            lRowColor.Clear();
            foreach (DataGridViewRow dgr in dgComplaintHistory.Rows)
            {
                if (!lRowColor.Contains(dgr.Cells["StatusofComplaint"].Value.ToString()))
                {
                    lRowColor.Add(dgr.Cells["StatusofComplaint"].Value.ToString());
                }
            }

            lRowColor.Sort();

            for (int i = 0; i <= lRowColor.Count - 1; i++)
            {
                if (i % 2 == 0)
                {
                    {
                        foreach (DataGridViewRow dgr in dgComplaintHistory.Rows)
                        {
                            if (lRowColor[i] == (dgr.Cells["StatusofComplaint"].Value.ToString()))
                            {
                                dgr.DefaultCellStyle.BackColor = Color.White;

                            }
                        }
                    }
                }
                else
                {
                    if (i < lRowColor.Count)
                    {
                        foreach (DataGridViewRow dgr in dgComplaintHistory.Rows)
                        {
                            if (lRowColor[i] == (dgr.Cells["StatusofComplaint"].Value.ToString()))
                            {
                                dgr.DefaultCellStyle.BackColor = Color.Wheat;

                            }
                        }
                    }
                }
            }

            foreach (DataGridViewRow dgr in dgComplaintHistory.Rows)
            {
                if (dgr.Cells["ComplaintClose"].Value.ToString() == "Closed")
                {
                    dgr.DefaultCellStyle.BackColor = Color.LightGreen;
                }
            }
        }
        #endregion

        private void txtDataSearch_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtDataSearch.TextLength > 1)
            {
                dtClone = dtComplaints.Copy();
                bsIteSearch.DataSource = dtClone;
                bsIteSearch.Filter = string.Format("Building LIKE '%{0}%' OR ComaplaintBy LIKE '%{0}%' OR TypeOfRequest LIKE '%{0}%' OR Emergency LIKE '%{0}%' OR StatusofComplaint LIKE '%{0}%'", txtDataSearch.Text);
                dgComplaintHistory.DataSource = bsIteSearch;
                Datagridviewcolor();
            }
            else
            {
                bsIteSearch.RemoveFilter();
                Datagridviewcolor();
            }
        }

        private void frmComplaintHistory_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            form.Show();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            dtpfromdate.Format = DateTimePickerFormat.Custom;
            dtpfromdate.CustomFormat = "yyyy-MM-dd";
            dtptodate.Format = DateTimePickerFormat.Custom;
            dtptodate.CustomFormat = "yyyy-MM-dd";

            dtComplaints = DAL.fnComplaintListView(0, dtpfromdate.Text, dtptodate.Text).Tables[0];
            dgComplaintHistory.AutoGenerateColumns = false;
            dgComplaintHistory.DataSource = dtComplaints;
            Datagridviewcolor();

            dtpfromdate.Format = DateTimePickerFormat.Custom;
            dtpfromdate.CustomFormat = "dd-MM-yyyy";
            dtptodate.Format = DateTimePickerFormat.Custom;
            dtptodate.CustomFormat = "dd-MM-yyyy";
        }
    }
}

