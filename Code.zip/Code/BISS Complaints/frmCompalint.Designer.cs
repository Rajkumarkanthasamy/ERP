﻿namespace Erp_Project_With_Buttons.BISS_Complaints
{
    partial class frmCompalint
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCompalint));
            this.dtpAcceptdate = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.cmbFundResourceRequired = new System.Windows.Forms.ComboBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnReject = new System.Windows.Forms.Button();
            this.dtpComplaintDate = new System.Windows.Forms.DateTimePicker();
            this.chkCloseComplaint = new System.Windows.Forms.CheckBox();
            this.cmbComplaintNo = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.pnAdmin = new System.Windows.Forms.Panel();
            this.cmbGMReviewRequired = new System.Windows.Forms.ComboBox();
            this.dtpComplaintSolvedBy = new System.Windows.Forms.DateTimePicker();
            this.txtAuthorisedPersonRemarks = new System.Windows.Forms.TextBox();
            this.lblAuthorRemarks = new System.Windows.Forms.Label();
            this.txtComplaintNo = new System.Windows.Forms.TextBox();
            this.txtWorkLocation = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.btnAccept = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtDepartment = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtComplaintBy = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbEmergency = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtDetailsofWork = new System.Windows.Forms.TextBox();
            this.txtWorkRequired = new System.Windows.Forms.TextBox();
            this.cmbTypeofRequest = new System.Windows.Forms.ComboBox();
            this.cmbBuilding = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.cmbUser = new System.Windows.Forms.ComboBox();
            this.pnAdminpanel = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.comboBox1RemarksRequiredTime = new System.Windows.Forms.ComboBox();
            this.dateTimePicker1RequiredTime = new System.Windows.Forms.DateTimePicker();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.pnAdmin.SuspendLayout();
            this.panel1.SuspendLayout();
            this.pnAdminpanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // dtpAcceptdate
            // 
            this.dtpAcceptdate.Enabled = false;
            this.dtpAcceptdate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpAcceptdate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpAcceptdate.Location = new System.Drawing.Point(334, 256);
            this.dtpAcceptdate.Name = "dtpAcceptdate";
            this.dtpAcceptdate.Size = new System.Drawing.Size(67, 27);
            this.dtpAcceptdate.TabIndex = 198;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(32, 12);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(194, 19);
            this.label11.TabIndex = 144;
            this.label11.Text = "Fund / Resource Required :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(66, 54);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(160, 19);
            this.label10.TabIndex = 142;
            this.label10.Text = "GM Review Required :";
            // 
            // cmbFundResourceRequired
            // 
            this.cmbFundResourceRequired.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFundResourceRequired.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbFundResourceRequired.FormattingEnabled = true;
            this.cmbFundResourceRequired.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbFundResourceRequired.Location = new System.Drawing.Point(232, 9);
            this.cmbFundResourceRequired.Name = "cmbFundResourceRequired";
            this.cmbFundResourceRequired.Size = new System.Drawing.Size(343, 27);
            this.cmbFundResourceRequired.TabIndex = 145;
            // 
            // btnClose
            // 
            this.btnClose.Enabled = false;
            this.btnClose.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(276, 5);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(114, 42);
            this.btnClose.TabIndex = 142;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(757, 5);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(114, 42);
            this.btnExit.TabIndex = 141;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnReject
            // 
            this.btnReject.Enabled = false;
            this.btnReject.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReject.Location = new System.Drawing.Point(516, 5);
            this.btnReject.Name = "btnReject";
            this.btnReject.Size = new System.Drawing.Size(114, 42);
            this.btnReject.TabIndex = 140;
            this.btnReject.Text = "Review";
            this.btnReject.UseVisualStyleBackColor = true;
            this.btnReject.Click += new System.EventHandler(this.btnReject_Click);
            // 
            // dtpComplaintDate
            // 
            this.dtpComplaintDate.Enabled = false;
            this.dtpComplaintDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpComplaintDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpComplaintDate.Location = new System.Drawing.Point(148, 256);
            this.dtpComplaintDate.Name = "dtpComplaintDate";
            this.dtpComplaintDate.Size = new System.Drawing.Size(253, 27);
            this.dtpComplaintDate.TabIndex = 191;
            // 
            // chkCloseComplaint
            // 
            this.chkCloseComplaint.AutoSize = true;
            this.chkCloseComplaint.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkCloseComplaint.ForeColor = System.Drawing.Color.Red;
            this.chkCloseComplaint.Location = new System.Drawing.Point(525, 6);
            this.chkCloseComplaint.Name = "chkCloseComplaint";
            this.chkCloseComplaint.Size = new System.Drawing.Size(211, 23);
            this.chkCloseComplaint.TabIndex = 197;
            this.chkCloseComplaint.Text = "Close Accepted Complaints";
            this.chkCloseComplaint.UseVisualStyleBackColor = true;
            this.chkCloseComplaint.CheckedChanged += new System.EventHandler(this.chkCloseComplaint_CheckedChanged);
            // 
            // cmbComplaintNo
            // 
            this.cmbComplaintNo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbComplaintNo.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbComplaintNo.FormattingEnabled = true;
            this.cmbComplaintNo.Location = new System.Drawing.Point(146, 2);
            this.cmbComplaintNo.Name = "cmbComplaintNo";
            this.cmbComplaintNo.Size = new System.Drawing.Size(253, 27);
            this.cmbComplaintNo.TabIndex = 188;
            this.cmbComplaintNo.SelectedIndexChanged += new System.EventHandler(this.cmbComplaintNo_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(53, 93);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(173, 19);
            this.label13.TabIndex = 164;
            this.label13.Text = "Complaint Resolved By :";
            // 
            // pnAdmin
            // 
            this.pnAdmin.Controls.Add(this.label11);
            this.pnAdmin.Controls.Add(this.label10);
            this.pnAdmin.Controls.Add(this.cmbGMReviewRequired);
            this.pnAdmin.Controls.Add(this.cmbFundResourceRequired);
            this.pnAdmin.Controls.Add(this.dtpComplaintSolvedBy);
            this.pnAdmin.Controls.Add(this.label13);
            this.pnAdmin.Controls.Add(this.txtAuthorisedPersonRemarks);
            this.pnAdmin.Controls.Add(this.lblAuthorRemarks);
            this.pnAdmin.Location = new System.Drawing.Point(579, 233);
            this.pnAdmin.Name = "pnAdmin";
            this.pnAdmin.Size = new System.Drawing.Size(579, 212);
            this.pnAdmin.TabIndex = 196;
            this.pnAdmin.Visible = false;
            // 
            // cmbGMReviewRequired
            // 
            this.cmbGMReviewRequired.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGMReviewRequired.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbGMReviewRequired.FormattingEnabled = true;
            this.cmbGMReviewRequired.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbGMReviewRequired.Location = new System.Drawing.Point(232, 50);
            this.cmbGMReviewRequired.Name = "cmbGMReviewRequired";
            this.cmbGMReviewRequired.Size = new System.Drawing.Size(343, 27);
            this.cmbGMReviewRequired.TabIndex = 143;
            // 
            // dtpComplaintSolvedBy
            // 
            this.dtpComplaintSolvedBy.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.dtpComplaintSolvedBy.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpComplaintSolvedBy.Location = new System.Drawing.Point(232, 90);
            this.dtpComplaintSolvedBy.Name = "dtpComplaintSolvedBy";
            this.dtpComplaintSolvedBy.Size = new System.Drawing.Size(343, 27);
            this.dtpComplaintSolvedBy.TabIndex = 163;
            this.dtpComplaintSolvedBy.ValueChanged += new System.EventHandler(this.dtpComplaintSolvedBy_ValueChanged);
            // 
            // txtAuthorisedPersonRemarks
            // 
            this.txtAuthorisedPersonRemarks.Font = new System.Drawing.Font("Calibri", 12F);
            this.txtAuthorisedPersonRemarks.Location = new System.Drawing.Point(231, 130);
            this.txtAuthorisedPersonRemarks.Multiline = true;
            this.txtAuthorisedPersonRemarks.Name = "txtAuthorisedPersonRemarks";
            this.txtAuthorisedPersonRemarks.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtAuthorisedPersonRemarks.Size = new System.Drawing.Size(343, 76);
            this.txtAuthorisedPersonRemarks.TabIndex = 193;
            // 
            // lblAuthorRemarks
            // 
            this.lblAuthorRemarks.AutoSize = true;
            this.lblAuthorRemarks.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAuthorRemarks.Location = new System.Drawing.Point(19, 130);
            this.lblAuthorRemarks.Name = "lblAuthorRemarks";
            this.lblAuthorRemarks.Size = new System.Drawing.Size(206, 19);
            this.lblAuthorRemarks.TabIndex = 194;
            this.lblAuthorRemarks.Text = "Authorised Person Remarks :";
            // 
            // txtComplaintNo
            // 
            this.txtComplaintNo.Enabled = false;
            this.txtComplaintNo.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtComplaintNo.Location = new System.Drawing.Point(146, 2);
            this.txtComplaintNo.Name = "txtComplaintNo";
            this.txtComplaintNo.Size = new System.Drawing.Size(249, 27);
            this.txtComplaintNo.TabIndex = 195;
            // 
            // txtWorkLocation
            // 
            this.txtWorkLocation.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWorkLocation.Location = new System.Drawing.Point(148, 187);
            this.txtWorkLocation.Name = "txtWorkLocation";
            this.txtWorkLocation.Size = new System.Drawing.Size(253, 27);
            this.txtWorkLocation.TabIndex = 192;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.btnClose);
            this.panel1.Controls.Add(this.btnExit);
            this.panel1.Controls.Add(this.btnReject);
            this.panel1.Controls.Add(this.btnAccept);
            this.panel1.Controls.Add(this.btnSave);
            this.panel1.Location = new System.Drawing.Point(2, 471);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1156, 54);
            this.panel1.TabIndex = 189;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(112, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(158, 42);
            this.button1.TabIndex = 143;
            this.button1.Text = "Update Time";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnAccept
            // 
            this.btnAccept.Enabled = false;
            this.btnAccept.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAccept.Location = new System.Drawing.Point(396, 5);
            this.btnAccept.Name = "btnAccept";
            this.btnAccept.Size = new System.Drawing.Size(114, 42);
            this.btnAccept.TabIndex = 139;
            this.btnAccept.Text = "Accept";
            this.btnAccept.UseVisualStyleBackColor = true;
            this.btnAccept.Click += new System.EventHandler(this.btnAccept_Click);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(636, 5);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(114, 42);
            this.btnSave.TabIndex = 132;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(5, 262);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(123, 19);
            this.label12.TabIndex = 190;
            this.label12.Text = "Complaint Date :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(3, 7);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(111, 19);
            this.label9.TabIndex = 187;
            this.label9.Text = "Complaint No :";
            // 
            // txtDepartment
            // 
            this.txtDepartment.Enabled = false;
            this.txtDepartment.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDepartment.Location = new System.Drawing.Point(148, 77);
            this.txtDepartment.Name = "txtDepartment";
            this.txtDepartment.Size = new System.Drawing.Size(253, 27);
            this.txtDepartment.TabIndex = 186;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(5, 80);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 19);
            this.label8.TabIndex = 185;
            this.label8.Text = "Department :";
            // 
            // txtComplaintBy
            // 
            this.txtComplaintBy.Enabled = false;
            this.txtComplaintBy.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtComplaintBy.Location = new System.Drawing.Point(148, 44);
            this.txtComplaintBy.Name = "txtComplaintBy";
            this.txtComplaintBy.Size = new System.Drawing.Size(253, 27);
            this.txtComplaintBy.TabIndex = 184;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(5, 47);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(130, 19);
            this.label7.TabIndex = 183;
            this.label7.Text = "Requester Name :";
            // 
            // cmbEmergency
            // 
            this.cmbEmergency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEmergency.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbEmergency.FormattingEnabled = true;
            this.cmbEmergency.Items.AddRange(new object[] {
            "Low",
            "Medium",
            "High"});
            this.cmbEmergency.Location = new System.Drawing.Point(148, 112);
            this.cmbEmergency.Name = "cmbEmergency";
            this.cmbEmergency.Size = new System.Drawing.Size(253, 27);
            this.cmbEmergency.TabIndex = 182;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(5, 115);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 19);
            this.label6.TabIndex = 181;
            this.label6.Text = "Priority :";
            // 
            // txtDetailsofWork
            // 
            this.txtDetailsofWork.Font = new System.Drawing.Font("Calibri", 12F);
            this.txtDetailsofWork.Location = new System.Drawing.Point(814, 41);
            this.txtDetailsofWork.Multiline = true;
            this.txtDetailsofWork.Name = "txtDetailsofWork";
            this.txtDetailsofWork.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDetailsofWork.Size = new System.Drawing.Size(344, 90);
            this.txtDetailsofWork.TabIndex = 180;
            // 
            // txtWorkRequired
            // 
            this.txtWorkRequired.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWorkRequired.Location = new System.Drawing.Point(814, 137);
            this.txtWorkRequired.Multiline = true;
            this.txtWorkRequired.Name = "txtWorkRequired";
            this.txtWorkRequired.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtWorkRequired.Size = new System.Drawing.Size(344, 90);
            this.txtWorkRequired.TabIndex = 179;
            // 
            // cmbTypeofRequest
            // 
            this.cmbTypeofRequest.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTypeofRequest.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTypeofRequest.FormattingEnabled = true;
            this.cmbTypeofRequest.Items.AddRange(new object[] {
            "Breakdown",
            "Cleaning",
            "Engineering",
            "IT - Software",
            "IT - Hardware",
            "IT - Network",
            "Minor Construction",
            "Move support",
            "Others",
            "Repair",
            "Signs",
            "Vehicle for Transport"});
            this.cmbTypeofRequest.Location = new System.Drawing.Point(148, 220);
            this.cmbTypeofRequest.Name = "cmbTypeofRequest";
            this.cmbTypeofRequest.Size = new System.Drawing.Size(253, 27);
            this.cmbTypeofRequest.TabIndex = 178;
            // 
            // cmbBuilding
            // 
            this.cmbBuilding.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBuilding.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbBuilding.FormattingEnabled = true;
            this.cmbBuilding.Items.AddRange(new object[] {
            "Admin Block",
            "Engineer Block",
            "Office Campus",
            "Vendor Place / Outside Office"});
            this.cmbBuilding.Location = new System.Drawing.Point(148, 150);
            this.cmbBuilding.Name = "cmbBuilding";
            this.cmbBuilding.Size = new System.Drawing.Size(253, 27);
            this.cmbBuilding.TabIndex = 177;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(547, 44);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(253, 19);
            this.label5.TabIndex = 176;
            this.label5.Text = "Details of Required Work/Problem :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(5, 223);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(124, 19);
            this.label4.TabIndex = 175;
            this.label4.Text = "Type of request :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(658, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(139, 19);
            this.label3.TabIndex = 174;
            this.label3.Text = "Suggestions if any :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(5, 190);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 19);
            this.label2.TabIndex = 173;
            this.label2.Text = "Work location :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(5, 150);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 19);
            this.label1.TabIndex = 172;
            this.label1.Text = "Building :";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(5, 306);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(212, 19);
            this.label22.TabIndex = 199;
            this.label22.Text = "Send Complaint Request To *:";
            // 
            // cmbUser
            // 
            this.cmbUser.DropDownHeight = 130;
            this.cmbUser.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbUser.FormattingEnabled = true;
            this.cmbUser.IntegralHeight = false;
            this.cmbUser.Items.AddRange(new object[] {
            "Maintenance Support",
            "IT Support"});
            this.cmbUser.Location = new System.Drawing.Point(223, 302);
            this.cmbUser.Name = "cmbUser";
            this.cmbUser.Size = new System.Drawing.Size(253, 27);
            this.cmbUser.TabIndex = 200;
            this.cmbUser.SelectedIndexChanged += new System.EventHandler(this.cmbUserCC_SelectedIndexChanged);
            // 
            // pnAdminpanel
            // 
            this.pnAdminpanel.Controls.Add(this.cmbComplaintNo);
            this.pnAdminpanel.Controls.Add(this.label9);
            this.pnAdminpanel.Controls.Add(this.txtComplaintNo);
            this.pnAdminpanel.Controls.Add(this.chkCloseComplaint);
            this.pnAdminpanel.Location = new System.Drawing.Point(2, 4);
            this.pnAdminpanel.Name = "pnAdminpanel";
            this.pnAdminpanel.Size = new System.Drawing.Size(1156, 34);
            this.pnAdminpanel.TabIndex = 201;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label14.Location = new System.Drawing.Point(5, 345);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(217, 19);
            this.label14.TabIndex = 203;
            this.label14.Text = "Required Time to Completion :";
            this.label14.Visible = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label15.Location = new System.Drawing.Point(5, 385);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(202, 19);
            this.label15.TabIndex = 204;
            this.label15.Text = "Remarks for Time Required :";
            this.label15.Visible = false;
            // 
            // comboBox1RemarksRequiredTime
            // 
            this.comboBox1RemarksRequiredTime.Font = new System.Drawing.Font("Calibri", 12F);
            this.comboBox1RemarksRequiredTime.FormattingEnabled = true;
            this.comboBox1RemarksRequiredTime.Items.AddRange(new object[] {
            "Myself",
            "Need to purchase the required materials",
            "Need to arrange the workers",
            "Temporary labor requirement",
            "Skilled technician required",
            "Contractor support needed"});
            this.comboBox1RemarksRequiredTime.Location = new System.Drawing.Point(223, 382);
            this.comboBox1RemarksRequiredTime.Name = "comboBox1RemarksRequiredTime";
            this.comboBox1RemarksRequiredTime.Size = new System.Drawing.Size(253, 27);
            this.comboBox1RemarksRequiredTime.TabIndex = 205;
            this.comboBox1RemarksRequiredTime.Visible = false;
            // 
            // dateTimePicker1RequiredTime
            // 
            this.dateTimePicker1RequiredTime.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1RequiredTime.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1RequiredTime.Location = new System.Drawing.Point(223, 339);
            this.dateTimePicker1RequiredTime.Name = "dateTimePicker1RequiredTime";
            this.dateTimePicker1RequiredTime.Size = new System.Drawing.Size(253, 27);
            this.dateTimePicker1RequiredTime.TabIndex = 206;
            this.dateTimePicker1RequiredTime.Visible = false;
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 537);
            this.splitter1.TabIndex = 207;
            this.splitter1.TabStop = false;
            // 
            // frmCompalint
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1161, 537);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.dateTimePicker1RequiredTime);
            this.Controls.Add(this.comboBox1RemarksRequiredTime);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.pnAdminpanel);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.cmbUser);
            this.Controls.Add(this.dtpComplaintDate);
            this.Controls.Add(this.pnAdmin);
            this.Controls.Add(this.txtWorkLocation);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtDepartment);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtComplaintBy);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cmbEmergency);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtDetailsofWork);
            this.Controls.Add(this.txtWorkRequired);
            this.Controls.Add(this.cmbTypeofRequest);
            this.Controls.Add(this.cmbBuilding);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtpAcceptdate);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmCompalint";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Compalint Request";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmCompalint_FormClosing);
            this.Load += new System.EventHandler(this.frmCompalint_Load);
            this.pnAdmin.ResumeLayout(false);
            this.pnAdmin.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.pnAdminpanel.ResumeLayout(false);
            this.pnAdminpanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtpAcceptdate;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cmbFundResourceRequired;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnReject;
        private System.Windows.Forms.DateTimePicker dtpComplaintDate;
        private System.Windows.Forms.CheckBox chkCloseComplaint;
        private System.Windows.Forms.ComboBox cmbComplaintNo;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel pnAdmin;
        private System.Windows.Forms.ComboBox cmbGMReviewRequired;
        private System.Windows.Forms.DateTimePicker dtpComplaintSolvedBy;
        private System.Windows.Forms.TextBox txtComplaintNo;
        private System.Windows.Forms.Label lblAuthorRemarks;
        private System.Windows.Forms.TextBox txtAuthorisedPersonRemarks;
        private System.Windows.Forms.TextBox txtWorkLocation;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnAccept;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtDepartment;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtComplaintBy;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbEmergency;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtDetailsofWork;
        private System.Windows.Forms.TextBox txtWorkRequired;
        private System.Windows.Forms.ComboBox cmbTypeofRequest;
        private System.Windows.Forms.ComboBox cmbBuilding;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox cmbUser;
        private System.Windows.Forms.Panel pnAdminpanel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox comboBox1RemarksRequiredTime;
        private System.Windows.Forms.DateTimePicker dateTimePicker1RequiredTime;
        private System.Windows.Forms.Splitter splitter1;
    }
}