﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Data.SqlClient;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Diagnostics;

namespace Erp_Project_With_Buttons.SecurityInwardOutward
{
    public partial class SecurityOutward : Form
    {
        public SecurityOutward()
        {
            InitializeComponent();
        }

        frmForm2 frm = new frmForm2();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm frmLoginForm = new Login.frmLoginForm();
        SecurityInwardOutward.SecurityInwardOutwardHome SHome = new SecurityInwardOutwardHome();

        DataTable dtPurchaseOrder = new DataTable();
        DataTable dtDeliverChallan = new DataTable();
        DataTable dtWorkOrder = new DataTable();
        DataTable dtSalesInvoice = new DataTable();
        DataTable dtServiceInvoice = new DataTable();
        DataTable dtExportInvoice = new DataTable();
        DataTable dtGatePassNumber = new DataTable();
        DataTable dtGatePassNumberData = new DataTable();
        DataTable dtGatePassNumberItems = new DataTable();
        DataTable dtDCDeclarationLetter = new DataTable();

        DataTable dtPurchaseOrderData = new DataTable();
        DataTable dtWorkOrderData = new DataTable();
        DataTable dtDeliveryChallanData = new DataTable();
        DataTable dtInvoiceData = new DataTable();
        DataTable dtDCDeclarationLetterData = new DataTable();
        private SqlCommand SQLCmd = new SqlCommand();
        public string ConnectionPath = "Data Source=inbas07;Initial Catalog=BusinessManagement;User ID=sa;Password=BiSS@ERP!!";
        public string ConnectionPath1 = "Data Source=inbas07;Initial Catalog=EasyReports4.0_Tally;User ID=sa;Password=BiSS@ERP!!"; //EasyReports3.6
        public DataSet SQLDataset = new DataSet();
        public SqlDataAdapter SQLDadpr = new SqlDataAdapter();

        #region   Function to Update Master Details With Customer tax registration numbers From The Order Entry Form to ERP Database
        private DataSet SQLERPCustomerUpdate(int iCase, string sDocNumber)
        {
            SqlConnection myconn = new SqlConnection();
            SQLDataset = new DataSet();
            myconn.ConnectionString = ConnectionPath;
            myconn.Open();
            switch (iCase)
            {
                case 0:
                    SQLCmd = new SqlCommand("Select [DCSerialNumber] from [DeliveryChallanItems] group by [DCSerialNumber] order by [DCSerialNumber] desc", myconn);
                    break;
                case 1:
                    SQLCmd = new SqlCommand(@" Select row_number() over(order by DC.ID) as [SlNo], '' as Itemcode ,DC.DescriptionofGoods as ItemDescription, 0 as RecievedQty,
	                                            DC.Quantity as OrderQty,DC.Quantity as RecQty, DD.DRName as VendorName
	                                            from [DeliveryChallanItems] DC join DeliveryChallanDetails DD on DC.DCSerialNumber=DD.DCSerialNumber where DC.DCSerialNumber='" + sDocNumber + "'", myconn);
                    break;

                case 2:
                    SQLCmd = new SqlCommand("Select [DCDLNumber] from [DCDLDetails] group by [DCDLNumber] order by [DCDLNumber] desc", myconn);
                    break;

                case 3:
                    SQLCmd = new SqlCommand(@" Select row_number() over(order by DC.ID) as [SlNo], '' as Itemcode ,DC.[ItemDescription] as ItemDescription, 0 as RecievedQty,
                                               case when DC.[DCDLQuantity]='' then '0' else  DC.[DCDLQuantity] END  as OrderQty, case when DC.[DCDLQuantity]='' then '0' else  DC.[DCDLQuantity] END  as RecQty, DD.DCDLCustomerName as VendorName
                                                from [DCDLItems] DC join [DCDLDetails] DD on DC.DCDLNumber=DD.DCDLNumber where DC.DCDLNumber='" + sDocNumber + "'", myconn);
                    break;
            }
            SQLCmd.ExecuteNonQuery();
            SQLDadpr = new SqlDataAdapter(SQLCmd);
            SQLDadpr.Fill(SQLDataset);
            myconn.Close();
            return SQLDataset;
        }
        #endregion
        #region   Function to Update Master Details With Customer tax registration numbers From The Order Entry Form to ERP Database
        private DataSet SQLInvoiceData(int iCase, string sDocNumber)
        {
            SqlConnection myconn = new SqlConnection();
            SQLDataset = new DataSet();
            myconn.ConnectionString = ConnectionPath1;
            myconn.Open();
            switch (iCase)
            {
                case 8:
                    SQLCmd = new SqlCommand(@"SELECT TTCL.[VoucherID]
                                              ,TTCL.[AccLineNo]
                                              ,TTCL.[InvLineNo]
                                              ,TTCL.[CostCat]
                                              ,TTCL.[CostCtr]
                                              ,[PrimaryCategory]
                                              ,TTCL.[Amount]
                                              ,TTCL.[EntryDate],
                                             convert(date, TTV.[Date],105) as [Date]
                                              ,TTV.[VoucherTypeName]
                                              ,TTV.[VoucherNo]
                                              ,TTV.[Reference]
                                              ,TTV.[PartyLedgerName]
                                          FROM [TD_Txn_CCtrLine] TTCL join [TD_Txn_VchHdr] TTV on TTCL.VoucherID=TTV.[VoucherID] where  convert(date, TTV.[Date],105)>='11-01-2020' and
                                          (TTV.[VoucherTypeName] ='Sales' or TTV.[VoucherTypeName] ='Sales Export ITW' or  TTV.[VoucherTypeName] ='Sales ITW') order by TTV.VoucherNo desc", myconn);
                    break;
                case 9:
                    SQLCmd = new SqlCommand(@"Select top 15 GSTServiceInvoiceNumber from GSTServiceInvoice order by id desc", myconn);
                    break;
                case 10:
                    SQLCmd = new SqlCommand(@"Select top 6 GSTExportInvoiceNumber from GSTExportInvoice order by id desc", myconn);
                    break;

                case 11:
                    SQLCmd = new SqlCommand(@"Select '1' as [SlNo], TTV.[Reference] as Itemcode,''  as ItemDescription,0 as RecievedQty,
                                              0 as OrderQty,0 as RecQty,TTV.[PartyLedgerName] as VendorName 
                                              FROM [TD_Txn_CCtrLine] TTCL join [TD_Txn_VchHdr] 
                                              TTV on TTCL.VoucherID=TTV.[VoucherID] where TTV.[VoucherNo]='" + sDocNumber + "'", myconn);

                    //P.Itemcode,Im.ItemDescription,0 as RecievedQty,P.RequariedQty as OrderQty,P.RequariedQty as RecQty,V.VendorName
                    break;

                case 12:
                    SQLCmd = new SqlCommand(@"Select TTV.[PartyLedgerName] as VendorName from [TD_Txn_CCtrLine] TTCL join [TD_Txn_VchHdr] 
                                              TTV on TTCL.VoucherID=TTV.[VoucherID] where TTV.[VoucherNo]='" + sDocNumber + "'", myconn);

                    //P.Itemcode,Im.ItemDescription,0 as RecievedQty,P.RequariedQty as OrderQty,P.RequariedQty as RecQty,V.VendorName
                    break;
            }
            SQLCmd.ExecuteNonQuery();
            SQLDadpr = new SqlDataAdapter(SQLCmd);
            SQLDadpr.Fill(SQLDataset);
            myconn.Close();
            return SQLDataset;
        }
        #endregion

        private void SecurityOutward_Load(object sender, EventArgs e)
        {
            dtPurchaseOrder = DAL.fnSecurityInward(0, "").Tables[0];
            dtWorkOrder = DAL.fnSecurityInward(2, "").Tables[0];
            ////   dtSalesInvoice = SQLInvoiceData(8, "").Tables[0];
            //dtServiceInvoice = SQLInvoiceData(9, "").Tables[0];
            //   dtExportInvoice = SQLInvoiceData(10, "").Tables[0];
            dtDeliverChallan = SQLERPCustomerUpdate(0, "").Tables[0];
            dtDCDeclarationLetter = SQLERPCustomerUpdate(2, "").Tables[0];
            txtOutwardBy.Text = frmLoginForm.GetUserDetails[2].ToString();

        }

        private void SecurityOutward_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnExit();
        }

        private void cmbInwardItemType_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbItemDocNo.Text = "";
            cmbItemDocNo.Items.Clear();
            dgvInwardItems.DataSource = null;
            txtVendor.ResetText();
            txtRemarks.ResetText();
            txtVendor.Enabled = false;
            btnAddNewRow.Visible = false;
            cmbItemDocNo.DropDownStyle = ComboBoxStyle.DropDownList;

            if (dgvInwardItems.Rows.Count > 0)
            {
                foreach (DataGridViewRow row in dgvInwardItems.Rows)
                {
                    row.Cells[1].ReadOnly = true;
                    row.Cells[1].Style.BackColor = Color.White;
                    row.Cells[2].ReadOnly = true;
                    row.Cells[2].Style.BackColor = Color.White;
                }
            }

            switch (cmbInwardItemType.SelectedIndex)
            {

                case 0:
                    foreach (DataRow DR in dtPurchaseOrder.Rows)
                    {
                        if (!cmbItemDocNo.Items.Contains(DR[0].ToString()))
                            cmbItemDocNo.Items.Add(DR[0].ToString());
                    }
                    break;
                case 1:
                    foreach (DataRow DR in dtWorkOrder.Rows)
                    {
                        if (!cmbItemDocNo.Items.Contains(DR[0].ToString()))
                            cmbItemDocNo.Items.Add(DR[0].ToString());
                    }
                    break;
                case 2:
                    foreach (DataRow DR in dtDeliverChallan.Rows)
                    {
                        if (!cmbItemDocNo.Items.Contains(DR[0].ToString()))
                            cmbItemDocNo.Items.Add(DR[0].ToString());
                    }
                    break;

                case 3:
                    btnAddNewRow.Visible = true;
                    txtVendor.Enabled = true;
                    cmbItemDocNo.DropDownStyle = ComboBoxStyle.DropDown;
                    foreach (DataRow DR in dtSalesInvoice.Rows)
                    {
                        if (!cmbItemDocNo.Items.Contains(DR[10].ToString()))
                            cmbItemDocNo.Items.Add(DR[10].ToString());
                    }

                    //foreach (DataRow DR in dtServiceInvoice.Rows)
                    //{
                    //    if (!cmbItemDocNo.Items.Contains(DR[0].ToString()))
                    //        cmbItemDocNo.Items.Add(DR[0].ToString());
                    //}

                    //foreach (DataRow DR in dtExportInvoice.Rows)
                    //{
                    //    if (!cmbItemDocNo.Items.Contains(DR[0].ToString()))
                    //        cmbItemDocNo.Items.Add(DR[0].ToString());
                    //}
                    break;

                case 4:
                    foreach (DataRow DR in dtDCDeclarationLetter.Rows)
                    {
                        if (!cmbItemDocNo.Items.Contains(DR[0].ToString()))
                            cmbItemDocNo.Items.Add(DR[0].ToString());
                    }
                    break;
            }
        }
        DataTable dtCustomerName = new DataTable();
        private void cmbItemDocNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            dgvInwardItems.DataSource = null;
            btnOutward.Enabled = true;
            txtVendor.ResetText();
            txtRemarks.ResetText();
            switch (cmbInwardItemType.SelectedIndex)
            {
                case 0:
                    dtPurchaseOrderData = DAL.fnSecurityInward(1, cmbItemDocNo.Text).Tables[0];

                    if (dtPurchaseOrderData.Rows.Count > 0)
                    {
                        dgvInwardItems.AutoGenerateColumns = false;
                        dgvInwardItems.DataSource = dtPurchaseOrderData;
                        txtVendor.Text = dtPurchaseOrderData.Rows[0]["VendorName"].ToString();

                        //dtPreviousRecieved = DAL.fnSecurityInward(6, cmbItemDocNo.Text).Tables[0];

                        //if (dtPreviousRecieved.Rows.Count > 0)
                        //{

                        //    for (int j = 0; j < dtPreviousRecieved.Rows.Count; j++)
                        //    {
                        //        for (int p = 0; p < dtPurchaseOrderData.Rows.Count; p++)
                        //        {
                        //            if (dtPreviousRecieved.Rows[j]["ItemCode"].ToString() == dtPurchaseOrderData.Rows[p]["ItemCode"].ToString())
                        //            {
                        //                {
                        //                    int nIndex = dtPurchaseOrderData.Rows.IndexOf(dtPurchaseOrderData.Rows[p]);
                        //                    DataRow dr1 = dtPurchaseOrderData.Rows[nIndex];
                        //                    dr1["RecievedQty"] = dtPreviousRecieved.Rows[j]["SendingQuantity"].ToString();
                        //                    break;
                        //                }
                        //            }

                        //        }
                        //    }
                        //}
                    }

                    break;
                case 1:
                    dtWorkOrderData = DAL.fnSecurityInward(31, cmbItemDocNo.Text).Tables[0];
                    if (dtWorkOrderData.Rows.Count > 0)
                    {
                        dgvInwardItems.AutoGenerateColumns = false;
                        dgvInwardItems.DataSource = dtWorkOrderData;
                        txtVendor.Text = dtWorkOrderData.Rows[0]["VendorName"].ToString();

                        //dtPreviousRecieved = DAL.fnSecurityInward(6, cmbItemDocNo.Text).Tables[0];

                        //if (dtPreviousRecieved.Rows.Count > 0)
                        //{
                        //    for (int j = 0; j < dtPreviousRecieved.Rows.Count; j++)
                        //    {
                        //        for (int p = 0; p < dtWorkOrderData.Rows.Count; p++)
                        //        {
                        //            if (dtPreviousRecieved.Rows[j]["ItemCode"].ToString() == dtWorkOrderData.Rows[p]["ItemCode"].ToString())
                        //            {
                        //                {
                        //                    int nIndex = dtWorkOrderData.Rows.IndexOf(dtWorkOrderData.Rows[p]);
                        //                    DataRow dr1 = dtWorkOrderData.Rows[nIndex];
                        //                    dr1["RecievedQty"] = dtPreviousRecieved.Rows[j]["SendingQuantity"].ToString();
                        //                    break;
                        //                }
                        //            }
                        //        }
                        //    }
                        //}
                    }
                    break;
                case 2:
                    dtDeliveryChallanData = SQLERPCustomerUpdate(1, cmbItemDocNo.Text).Tables[0];
                    if (dtDeliveryChallanData.Rows.Count > 0)
                    {
                        dgvInwardItems.AutoGenerateColumns = false;
                        dgvInwardItems.DataSource = dtDeliveryChallanData;
                        txtVendor.Text = dtDeliveryChallanData.Rows[0]["VendorName"].ToString();
                    }
                    break;

                case 3:
                    dtDeliveryChallanData = SQLInvoiceData(11, cmbItemDocNo.Text).Tables[0];
                    //  dtCustomerName = SQLInvoiceData(12, (dtDeliveryChallanData.Rows[0]["VendorName"].ToString())).Tables[0];
                    if (dtDeliveryChallanData.Rows.Count > 0)
                    {


                        txtVendor.Text = dtDeliveryChallanData.Rows[0]["VendorName"].ToString();

                        DataTable dtProjectBOMdetails = DAL.fnWIPProjectCode(dtDeliveryChallanData.Rows[0]["ItemCode"].ToString()).Tables[0];
                        if (dtProjectBOMdetails.Rows.Count > 0)
                        {
                            foreach (DataRow dr in dtDeliveryChallanData.Rows) // search whole table
                            {
                                dr[2] = dtProjectBOMdetails.Rows[0][0].ToString();
                            }
                            // dtDeliveryChallanData.Rows[0][""].
                        }

                        dgvInwardItems.AutoGenerateColumns = false;
                        dgvInwardItems.DataSource = dtDeliveryChallanData;

                    }
                    break;

                case 4:
                    dtDCDeclarationLetterData = SQLERPCustomerUpdate(3, cmbItemDocNo.Text).Tables[0];
                    if (dtDCDeclarationLetterData.Rows.Count > 0)
                    {
                        dgvInwardItems.AutoGenerateColumns = false;
                        dgvInwardItems.DataSource = dtDCDeclarationLetterData;
                        txtVendor.Text = dtDCDeclarationLetterData.Rows[0]["VendorName"].ToString();
                    }
                    break;
            }
        }

        DataTable dtSlNo = new DataTable();
        DataTable dtPreviousRecieved = new DataTable();
        int iInwardSlNo;
        double oldvalue;
        private void dgvInwardItems_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgvInwardItems.CurrentCell.OwningColumn.Name == "Quantity")
            {
                if (!string.IsNullOrEmpty(dgvInwardItems.CurrentCell.Value.ToString()))
                {
                    oldvalue = Convert.ToDouble(dgvInwardItems.CurrentCell.Value);
                }
            }
        }

        private void dgvInwardItems_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvInwardItems.CurrentCell.OwningColumn.Name == "Quantity")
            {
                if (dgvInwardItems.CurrentCell.Value != null)
                {
                    if (!string.IsNullOrEmpty(dgvInwardItems.CurrentCell.Value.ToString()) && (dgvInwardItems.CurrentCell.Value.ToString() != "."))
                    {
                        //if (Convert.ToDouble(dgvInwardItems.CurrentCell.Value.ToString()) <= (Convert.ToDouble(dgvInwardItems.CurrentRow.Cells[4].Value) - Convert.ToDouble(dgvInwardItems.CurrentRow.Cells[3].Value)))
                        //{

                        //}
                        //else
                        //{
                        //    MessageBox.Show("Sending quanity is more than order quantity. Check the quantity", "Error", 0, MessageBoxIcon.Error);
                        //    dgvInwardItems.CurrentCell.Value = 0;
                        //}
                    }
                    else
                    {
                        MessageBox.Show("Enter the correct quanity", "Error", 0, MessageBoxIcon.Error);
                        dgvInwardItems.CurrentCell.Value = 0;
                    }
                }
            }
        }

        #region PO quantity cost validating function
        private void Control_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (dgvInwardItems.CurrentCell.OwningColumn.Name == "Quantity")
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
                {
                    e.Handled = true;
                }
                if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
                {
                    e.Handled = true;
                }
            }
            else
            {
            }
        }
        #endregion

        private void dgvInwardItems_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
            }
        }
        private void fnExit()
        {
            this.Hide();
            frm.Show();
        }

        private void btExit_Click(object sender, EventArgs e)
        {
            fnExit();
        }
        bool bValidattion = false;
        private void fnRowCheck()
        {
            bValidattion = false;
            foreach (DataGridViewRow row in dgvInwardItems.Rows)
            {
                if (Convert.ToDouble(row.Cells[3].Value) == 0 || (row.Cells[3].Value) == null)
                {
                    MessageBox.Show("Qunaity not entered in item list.", "Error", 0, MessageBoxIcon.Error);
                    bValidattion = true;
                    break;
                }
                //else if (Convert.ToDouble(dgvInwardItems.CurrentRow.Cells[5].Value) > (Convert.ToDouble(dgvInwardItems.CurrentRow.Cells[4].Value) - Convert.ToDouble(dgvInwardItems.CurrentRow.Cells[3].Value)))
                //{
                //    MessageBox.Show("Sending quanity is more than entered quantity. Check the quantity", "Error", 0, MessageBoxIcon.Error);
                //    bValidattion = true;
                //    break;
                //}
            }
        }
        private void btnOutward_Click(object sender, EventArgs e)
        {
            if (btnOutward.Text == "Save")
            {
                fnRowCheck();
                if (cmbInwardItemType.SelectedIndex >= 0 && !string.IsNullOrEmpty(cmbItemDocNo.Text) && !bValidattion &&!string.IsNullOrEmpty(txtvehicleno.Text) && !string.IsNullOrEmpty(txtlrpodno.Text) && !string.IsNullOrEmpty(txtvehicleno.Text) && bRequiredewbDate && bRequiredlrpodbDate)
                {
                    dtSlNo = DAL.fnSecurityInward(41, "").Tables[0];

                    if (dtSlNo.Rows.Count > 0)
                    {
                        iInwardSlNo = Convert.ToInt32(dtSlNo.Rows[0]["OutwardSlNo"].ToString());
                        iInwardSlNo++;
                    }
                    else
                    {
                        iInwardSlNo = 20200001;
                    }

                    if (dgvInwardItems.Rows.Count == 0)
                    {
                        GlobalClass.iSuccess = DAL.fnAddSecutiryInwardOutward(2, ("SO" + iInwardSlNo), txtOutwardBy.Text, cmbInwardItemType.Text, cmbItemDocNo.Text, "",
                                                                                   "", "0", iInwardSlNo, txtRemarks.Text, txtVendor.Text, txtlrpodno.Text,dtplrpod.Text, txtvehicleno.Text, txtewbno.Text, dtpewbdate.Text);
                    }
                    else
                    {
                        foreach (DataGridViewRow dr in dgvInwardItems.Rows)
                        {
                            GlobalClass.iSuccess = DAL.fnAddSecutiryInwardOutward(2, ("SO" + iInwardSlNo), txtOutwardBy.Text, cmbInwardItemType.Text, cmbItemDocNo.Text, dr.Cells["ItemCode"].Value.ToString(),
                                                                                    dr.Cells["ItemDescription"].Value.ToString(), dr.Cells["Quantity"].Value.ToString(), iInwardSlNo, txtRemarks.Text, txtVendor.Text, txtlrpodno.Text, dtplrpod.Text, txtvehicleno.Text, txtewbno.Text, dtpewbdate.Text);
                        }
                    }
                    if (GlobalClass.iSuccess > 0)
                    {
                        GlobalClass.iSuccess = DAL.fnAddERPLog(0, ("SO" + iInwardSlNo), frmLoginForm.GetUserDetails[2], dtpewbdate.Text, "Item Outward", "SecurityOutward");
                        MessageBox.Show(("SO" + iInwardSlNo) + "\n\nItems outward details saved successfully", "Success", 0, MessageBoxIcon.Information);
                        btnOutward.Enabled = false;
                        fnExcel();
                    }
                }
            }
            else if (btnOutward.Text == "Print")
            {
                fnExcel();
            }
        }

        private void dgvInwardItems_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                if (dgvInwardItems.Rows.Count > 0)
                {
                    DialogResult DR = MessageBox.Show("Do you want to delete selected item ?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (DR == DialogResult.Yes)
                    {
                        dgvInwardItems.Rows.RemoveAt(dgvInwardItems.Rows.IndexOf(dgvInwardItems.CurrentRow));
                    }
                }
            }
        }

        private void fnExcel()
        {
            int iRowIndex = 1;
            string ExcelFolderPath;
            string FileFullPath;
            string ExcelFolderName;
            string FileFul;
            EXCEL.Workbook NewWorkBook;
            EXCEL.Worksheet NewWorkSheet;
            EXCEL.Application ExcelApp;
            EXCEL.Range CELLS, cell1, cell2;
            object misValue;
            ExcelFolderName = "\\GatePass";
            ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + ExcelFolderName + "\\";
            FileFullPath = ExcelFolderPath + (cmbItemDocNo.Text).Replace("/", "_") + "--" + DateTime.Now.ToString("dd/MM/yyyy hh/mm/ss") + ".xls";
            FileFul = ExcelFolderPath + (cmbItemDocNo.Text).Replace("/", "_") + "--" + DateTime.Now.ToString("dd/MM/yyyy hh/mm/ss") + ".pdf";
            if (!Directory.Exists(ExcelFolderPath))
                Directory.CreateDirectory(ExcelFolderPath);
            ExcelApp = new EXCEL.Application();
            misValue = System.Reflection.Missing.Value;
            try
            {
                if (ExcelApp == null)
                    MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                if (NewWorkSheet == null)
                    MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                else
                    NewWorkSheet.Name = "Security gate pass";
                // Select the Excel cells, in the range c1 to c7 in the worksheet for cell access check.
                EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                if (RANGE == null)
                    MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlWorkbookNormal, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                CELLS = NewWorkSheet.Cells;

                // dtIndentItems = DAL.fnIndentExcel(cmbIndentNo.Text, null).Tables[0];
                NewWorkSheet.Cells[iRowIndex, 1] = "Security Gate Pass";

                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);

                string[] Text ={"",Global.sCompanyName,
                                "NO.497E, 14th Cross, 4th Phase, Peenya Industrial Area,",
                                "Bangalore-560058, Karnataka, India.",
                                "Phone:91(080) 28360184. FAX: (080) 28360047."};


                //   CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                NewWorkSheet.Range["A1:B1"].Cells.Font.Size = 16;
                NewWorkSheet.Range["A1:B1"].Cells.Font.Bold = 16;
                iRowIndex++;
                foreach (string str in Text)
                {
                    NewWorkSheet.Cells[iRowIndex, 1] = str;
                    iRowIndex++;
                }

                iRowIndex++;
                iRowIndex++;
                NewWorkSheet.Range["A9:B9"].Cells.Font.Size = 16;
                NewWorkSheet.Range["A9:B9"].Cells.Font.Bold = 16;
                NewWorkSheet.Cells[iRowIndex, 1] = "Gate Pass Number: GP" + iInwardSlNo;
                iRowIndex++;
                iRowIndex++;
                iRowIndex++;
                NewWorkSheet.Cells[iRowIndex, 1] = "Reference Number:" + cmbItemDocNo.Text;

                iRowIndex = 20;
                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 4, 5);
                CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 4, 5);
                NewWorkSheet.Cells[iRowIndex, 4] = "Authorised By";

                CellMerge("BorderAround", NewWorkSheet, 1, 1, 1, 5);
                CellMerge("BorderAround", NewWorkSheet, 2, 9, 1, 5);
                CellMerge("BorderAround", NewWorkSheet, 1, 20, 1, 5);

                NewWorkSheet.Range["A1:C1"].Cells.Font.Size = 16;

                NewWorkSheet.Range["A2:D3"].Cells.Font.Size = 14;
                NewWorkSheet.Range["A4:D6"].Cells.Font.Size = 12;
                NewWorkSheet.Range["A1:D6"].Cells.Font.Bold = true;

                NewWorkSheet.Range["A12:D20"].Cells.Font.Size = 13;

                NewWorkSheet.Rows.AutoFit();

                NewWorkSheet.Columns.AutoFit();
                NewWorkSheet.Rows.RowHeight = "18";
                NewWorkSheet.Rows[2].RowHeight = 4;
                NewWorkSheet.Rows[9].RowHeight = 21;
                NewWorkSheet.Columns[1].ColumnWidth = 25;
                NewWorkSheet.Columns[2].ColumnWidth = 25;
                NewWorkSheet.Columns[3].ColumnWidth = 20;
                NewWorkSheet.Columns[4].ColumnWidth = 20;
                NewWorkSheet.Columns[5].ColumnWidth = 20;
                // NewWorkSheet.Columns[6].ColumnWidth = 20;

                NewWorkSheet.PageSetup.PrintArea = "A1:E20";
                NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                NewWorkSheet.PageSetup.PrintNotes = true;
                NewWorkSheet.PageSetup.Zoom = 78;
                NewWorkSheet.PageSetup.AlignMarginsHeaderFooter = false;
                NewWorkSheet.PageSetup.LeftMargin = 0.3;
                NewWorkSheet.PageSetup.RightMargin = 0.3;
                NewWorkSheet.PageSetup.CenterHorizontally = true;

                NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                string _stLOGO = ("C:\\Databasepath\\Bisslogo.jpg");
                EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[3, 4];

                Image oImage = Image.FromFile(_stLOGO);
                System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                NewWorkSheet.Paste(oRange, _stLOGO);

                NewWorkBook.Save();
                ExcelApp.Visible = false;

                NewWorkBook.ExportAsFixedFormat(EXCEL.XlFixedFormatType.xlTypePDF, FileFul);
                System.Diagnostics.Process.Start(FileFul);

                NewWorkBook.Close(true, misValue, misValue);
                ExcelApp.Quit();
                releaseObject(NewWorkSheet);
                releaseObject(NewWorkBook);
                releaseObject(ExcelApp);

                if (File.Exists(FileFullPath))
                {
                    File.Delete(FileFullPath);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                {
                    GetProcess.Kill();
                }
            }
        }

        #region Excel App Release Object Function
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
        #endregion

        #region Excel Merge Function
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignCenter":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

        }
        #endregion

        private void chkPrintPO_CheckedChanged(object sender, EventArgs e)
        {
            if (chkPrintPO.Checked)
            {
                btnOutward.Text = "Print";
                dtGatePassNumber = DAL.fnSecurityInward(8, "").Tables[0];

                foreach (DataRow DR in dtGatePassNumber.Rows)
                {
                    if (!cmbGatePass.Items.Contains(DR[0].ToString()))
                        cmbGatePass.Items.Add(DR[0].ToString());
                }
            }
            else
            {
                btnOutward.Text = "Save";
            }
        }

        private void cmbGatePass_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtGatePassNumberData = DAL.fnSecurityInward(81, cmbGatePass.Text).Tables[0];
            dtGatePassNumberItems = DAL.fnSecurityInward(82, cmbGatePass.Text).Tables[0];

            if (dtGatePassNumberData.Rows.Count > 0)
            {
                cmbInwardItemType.Text = dtGatePassNumberData.Rows[0]["OutwardItemType"].ToString();
                cmbItemDocNo.Text = dtGatePassNumberData.Rows[0]["OutwardDocumentNo"].ToString();
                txtOutwardBy.Text = dtGatePassNumberData.Rows[0]["OutwardBy"].ToString();
                txtRemarks.Text = dtGatePassNumberData.Rows[0]["Remarks"].ToString();
                iInwardSlNo = Convert.ToInt32(dtGatePassNumberData.Rows[0]["OutwardSlNo"].ToString());
            }
            if (dtGatePassNumberItems.Rows.Count > 0)
            {

            }
        }

        private void btnAddNewRow_Click(object sender, EventArgs e)
        {
            dgvInwardItems.Rows.Add();


            dgvInwardItems.Rows[dgvInwardItems.Rows.Count - 1].Cells[1].Value = "";
            dgvInwardItems.Rows[dgvInwardItems.Rows.Count - 1].Cells[2].Value = "";
            dgvInwardItems.Rows[dgvInwardItems.Rows.Count - 1].Cells[3].Value = 0;

            int i = 1;
            foreach (DataGridViewRow row in dgvInwardItems.Rows)
            {
                row.Cells[0].Value = i;

                row.Cells[1].ReadOnly = false;
                row.Cells[1].Style.BackColor = Color.LightGreen;
                row.Cells[2].ReadOnly = false;
                row.Cells[2].Style.BackColor = Color.LightGreen;

                i++;
            }
        }
        bool bRequiredewbDate = false;
        bool bRequiredlrpodbDate = false;
        private void dtpewbdate_ValueChanged(object sender, EventArgs e)
        {
            bRequiredewbDate = true;
        }

        private void dtplrpod_ValueChanged(object sender, EventArgs e)
        {
            bRequiredlrpodbDate = true;
        }
    }
}
