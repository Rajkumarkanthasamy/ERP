﻿namespace Erp_Project_With_Buttons.SecurityInwardOutward
{
    partial class frmManualInward
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmManualInward));
            this.txtVendor = new System.Windows.Forms.TextBox();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbItemDocNo = new System.Windows.Forms.ComboBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.dgvInwardItems = new System.Windows.Forms.DataGridView();
            this.DSCSLNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnInward = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtInwardBy = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbInwardItemType = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnAddNewRow = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtinvoiveno = new System.Windows.Forms.TextBox();
            this.invoicedtp = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInwardItems)).BeginInit();
            this.SuspendLayout();
            // 
            // txtVendor
            // 
            this.txtVendor.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVendor.Location = new System.Drawing.Point(199, 88);
            this.txtVendor.Multiline = true;
            this.txtVendor.Name = "txtVendor";
            this.txtVendor.Size = new System.Drawing.Size(338, 70);
            this.txtVendor.TabIndex = 253;
            // 
            // txtRemarks
            // 
            this.txtRemarks.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemarks.Location = new System.Drawing.Point(682, 81);
            this.txtRemarks.Multiline = true;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Size = new System.Drawing.Size(515, 77);
            this.txtRemarks.TabIndex = 252;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(601, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 19);
            this.label3.TabIndex = 251;
            this.label3.Text = "Remarks :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(127, 91);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 19);
            this.label1.TabIndex = 250;
            this.label1.Text = "Vendor :";
            // 
            // cmbItemDocNo
            // 
            this.cmbItemDocNo.DropDownHeight = 90;
            this.cmbItemDocNo.DropDownWidth = 150;
            this.cmbItemDocNo.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbItemDocNo.FormattingEnabled = true;
            this.cmbItemDocNo.IntegralHeight = false;
            this.cmbItemDocNo.Location = new System.Drawing.Point(199, 49);
            this.cmbItemDocNo.Name = "cmbItemDocNo";
            this.cmbItemDocNo.Size = new System.Drawing.Size(338, 27);
            this.cmbItemDocNo.TabIndex = 249;
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(1097, 581);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(114, 42);
            this.btnExit.TabIndex = 242;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // dgvInwardItems
            // 
            this.dgvInwardItems.AllowUserToAddRows = false;
            this.dgvInwardItems.AllowUserToOrderColumns = true;
            this.dgvInwardItems.AllowUserToResizeRows = false;
            this.dgvInwardItems.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvInwardItems.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvInwardItems.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvInwardItems.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvInwardItems.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvInwardItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInwardItems.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DSCSLNO,
            this.ItemCode,
            this.ItemDescription,
            this.Quantity});
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvInwardItems.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgvInwardItems.Location = new System.Drawing.Point(14, 177);
            this.dgvInwardItems.Name = "dgvInwardItems";
            this.dgvInwardItems.RowHeadersVisible = false;
            this.dgvInwardItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvInwardItems.Size = new System.Drawing.Size(1226, 398);
            this.dgvInwardItems.TabIndex = 248;
            this.dgvInwardItems.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgvInwardItems_CellBeginEdit);
            this.dgvInwardItems.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvInwardItems_CellEndEdit);
            this.dgvInwardItems.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvInwardItems_EditingControlShowing);
            this.dgvInwardItems.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvInwardItems_KeyUp);
            // 
            // DSCSLNO
            // 
            this.DSCSLNO.DataPropertyName = "SlNo";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            this.DSCSLNO.DefaultCellStyle = dataGridViewCellStyle2;
            this.DSCSLNO.FillWeight = 56.85279F;
            this.DSCSLNO.HeaderText = "SlNo";
            this.DSCSLNO.Name = "DSCSLNO";
            this.DSCSLNO.ReadOnly = true;
            this.DSCSLNO.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DSCSLNO.Width = 47;
            // 
            // ItemCode
            // 
            this.ItemCode.DataPropertyName = "ItemCode";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.LightGreen;
            this.ItemCode.DefaultCellStyle = dataGridViewCellStyle3;
            this.ItemCode.HeaderText = "Item Code";
            this.ItemCode.Name = "ItemCode";
            this.ItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemCode.Width = 76;
            // 
            // ItemDescription
            // 
            this.ItemDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ItemDescription.DataPropertyName = "ItemDescription";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.LightGreen;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ItemDescription.DefaultCellStyle = dataGridViewCellStyle4;
            this.ItemDescription.FillWeight = 107.1912F;
            this.ItemDescription.HeaderText = "Item Description";
            this.ItemDescription.Name = "ItemDescription";
            this.ItemDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "RecQty";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.LightGreen;
            this.Quantity.DefaultCellStyle = dataGridViewCellStyle5;
            this.Quantity.HeaderText = "Recieving Qty";
            this.Quantity.Name = "Quantity";
            this.Quantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Quantity.Width = 98;
            // 
            // btnInward
            // 
            this.btnInward.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInward.Location = new System.Drawing.Point(939, 581);
            this.btnInward.Name = "btnInward";
            this.btnInward.Size = new System.Drawing.Size(114, 42);
            this.btnInward.TabIndex = 241;
            this.btnInward.Text = "Save";
            this.btnInward.UseVisualStyleBackColor = true;
            this.btnInward.Click += new System.EventHandler(this.btnInward_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(10, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(183, 19);
            this.label2.TabIndex = 247;
            this.label2.Text = "Item Document Number :";
            // 
            // txtInwardBy
            // 
            this.txtInwardBy.Enabled = false;
            this.txtInwardBy.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInwardBy.Location = new System.Drawing.Point(682, 48);
            this.txtInwardBy.Name = "txtInwardBy";
            this.txtInwardBy.Size = new System.Drawing.Size(253, 27);
            this.txtInwardBy.TabIndex = 246;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(590, 48);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 19);
            this.label7.TabIndex = 245;
            this.label7.Text = "Inward by :";
            // 
            // cmbInwardItemType
            // 
            this.cmbInwardItemType.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbInwardItemType.FormattingEnabled = true;
            this.cmbInwardItemType.Items.AddRange(new object[] {
            "Purchase Order",
            "Work Order",
            "Deliver Challan"});
            this.cmbInwardItemType.Location = new System.Drawing.Point(199, 7);
            this.cmbInwardItemType.Name = "cmbInwardItemType";
            this.cmbInwardItemType.Size = new System.Drawing.Size(338, 27);
            this.cmbInwardItemType.TabIndex = 244;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(56, 7);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(137, 19);
            this.label6.TabIndex = 243;
            this.label6.Text = "Inward Item Type :";
            // 
            // btnAddNewRow
            // 
            this.btnAddNewRow.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAddNewRow.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAddNewRow.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNewRow.Location = new System.Drawing.Point(217, 177);
            this.btnAddNewRow.Name = "btnAddNewRow";
            this.btnAddNewRow.Size = new System.Drawing.Size(106, 36);
            this.btnAddNewRow.TabIndex = 254;
            this.btnAddNewRow.Text = "Add Item";
            this.btnAddNewRow.UseVisualStyleBackColor = false;
            this.btnAddNewRow.Click += new System.EventHandler(this.btnAddNewRow_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(586, 11);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 19);
            this.label4.TabIndex = 255;
            this.label4.Text = "Invoice No :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(912, 10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 19);
            this.label5.TabIndex = 256;
            this.label5.Text = "Invoice Date :";
            // 
            // txtinvoiveno
            // 
            this.txtinvoiveno.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinvoiveno.Location = new System.Drawing.Point(682, 7);
            this.txtinvoiveno.Name = "txtinvoiveno";
            this.txtinvoiveno.Size = new System.Drawing.Size(175, 27);
            this.txtinvoiveno.TabIndex = 257;
            // 
            // invoicedtp
            // 
            this.invoicedtp.CalendarFont = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.invoicedtp.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.invoicedtp.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.invoicedtp.Location = new System.Drawing.Point(1020, 10);
            this.invoicedtp.Name = "invoicedtp";
            this.invoicedtp.Size = new System.Drawing.Size(124, 27);
            this.invoicedtp.TabIndex = 258;
            // 
            // frmManualInward
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(1242, 630);
            this.Controls.Add(this.invoicedtp);
            this.Controls.Add(this.txtinvoiveno);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnAddNewRow);
            this.Controls.Add(this.txtVendor);
            this.Controls.Add(this.txtRemarks);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbItemDocNo);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.dgvInwardItems);
            this.Controls.Add(this.btnInward);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtInwardBy);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cmbInwardItemType);
            this.Controls.Add(this.label6);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmManualInward";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Security Manual Inwards";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmManualInward_FormClosing);
            this.Load += new System.EventHandler(this.frmManualInward_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvInwardItems)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtVendor;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbItemDocNo;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.DataGridView dgvInwardItems;
        private System.Windows.Forms.Button btnInward;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtInwardBy;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbInwardItemType;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnAddNewRow;
        private System.Windows.Forms.DataGridViewTextBoxColumn DSCSLNO;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtinvoiveno;
        private System.Windows.Forms.DateTimePicker invoicedtp;
    }
}
