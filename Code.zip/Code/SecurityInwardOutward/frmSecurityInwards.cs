﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace Erp_Project_With_Buttons.SecurityInwardOutward
{
    public partial class frmSecurityInwards : Form
    {
        public frmSecurityInwards()
        {
            InitializeComponent();
        }
        frmForm2 frm = new frmForm2();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm frmLoginForm = new Login.frmLoginForm();
        SecurityInwardOutward.SecurityInwardOutwardHome SHome = new SecurityInwardOutwardHome();
        bool bRequiredDate = false;
        DataTable dtPurchaseOrder = new DataTable();
        DataTable dtWorkOrder = new DataTable();
        DataTable dtDeliveryChallan = new DataTable();

        DataTable dtPurchaseOrderData = new DataTable();
        DataTable dtWorkOrderData = new DataTable();
        DataTable dtDeliveryChallanData = new DataTable();

        private SqlCommand SQLCmd = new SqlCommand();
        public string ConnectionPath = "Data Source=inbas07;Initial Catalog=BusinessManagement;User ID=sa;Password=BiSS@ERP!!";
        public DataSet SQLDataset = new DataSet();
        public SqlDataAdapter SQLDadpr = new SqlDataAdapter();

        #region   Function to Update Master Details With Customer tax registration numbers From The Order Entry Form to ERP Database
        private DataSet SQLERPCustomerUpdate(int iCase, string sDocNumber)
        {
            SqlConnection myconn = new SqlConnection();
            SQLDataset = new DataSet();
            myconn.ConnectionString = ConnectionPath;
            myconn.Open();
            switch (iCase)
            {
                case 0:
                    SQLCmd = new SqlCommand("Select [DCSerialNumber] from [DeliveryChallanItems] group by [DCSerialNumber] order by [DCSerialNumber] desc", myconn);
                    break;
                case 1:
                    SQLCmd = new SqlCommand(@" Select row_number() over(order by DC.ID) as [SlNo], '' as Itemcode ,DC.DescriptionofGoods as ItemDescription, 0 as RecievedQty,
	                                            DC.Quantity as OrderQty,DC.Quantity as RecQty, DD.DRName as VendorName
	                                            from [DeliveryChallanItems] DC join DeliveryChallanDetails DD on DC.DCSerialNumber=DD.DCSerialNumber where DC.DCSerialNumber='" + sDocNumber + "'", myconn);
                    break;
            }
            SQLCmd.ExecuteNonQuery();
            SQLDadpr = new SqlDataAdapter(SQLCmd);
            SQLDadpr.Fill(SQLDataset);
            myconn.Close();
            return SQLDataset;
        }
        #endregion

        private void frmSecurityInwards_Load(object sender, EventArgs e)
        {
            dtPurchaseOrder = DAL.fnSecurityInward(0, "").Tables[0];
            dtWorkOrder = DAL.fnSecurityInward(2, "").Tables[0];
            dtDeliveryChallan = SQLERPCustomerUpdate(0, "").Tables[0];
            txtInwardBy.Text = frmLoginForm.GetUserDetails[2].ToString();
        }

        private void frmSecurityInwards_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnExit();
        }

        private void fnExit()
        {
            this.Hide();
            frm.Show();
        }
        private void cmbInwardItemType_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbItemDocNo.Text = "";
            cmbItemDocNo.Items.Clear();
            dgvInwardItems.DataSource = null;
            txtVendor.ResetText();
            txtRemarks.ResetText();
            switch (cmbInwardItemType.SelectedIndex)
            {

                case 0:
                    foreach (DataRow DR in dtPurchaseOrder.Rows)
                    {
                        if (!cmbItemDocNo.Items.Contains(DR[0].ToString()))
                            cmbItemDocNo.Items.Add(DR[0].ToString());
                    }
                    break;
                case 1:
                    foreach (DataRow DR in dtWorkOrder.Rows)
                    {
                        if (!cmbItemDocNo.Items.Contains(DR[0].ToString()))
                            cmbItemDocNo.Items.Add(DR[0].ToString());
                    }
                    break;
                case 2:
                    foreach (DataRow DR in dtDeliveryChallan.Rows)
                    {
                        if (!cmbItemDocNo.Items.Contains(DR[0].ToString()))
                            cmbItemDocNo.Items.Add(DR[0].ToString());
                    }
                    break;
            }
        }

        private void cmbItemDocNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            dgvInwardItems.DataSource = null;
            txtRemarks.ResetText();
            txtVendor.ResetText();
            btnInward.Enabled = true;
            switch (cmbInwardItemType.SelectedIndex)
            {

                case 0:
                    dtPurchaseOrderData = DAL.fnSecurityInward(1, cmbItemDocNo.Text).Tables[0];

                    if (dtPurchaseOrderData.Rows.Count > 0)
                    {
                        dgvInwardItems.AutoGenerateColumns = false;
                        dgvInwardItems.DataSource = dtPurchaseOrderData;
                        txtVendor.Text = dtPurchaseOrderData.Rows[0]["VendorName"].ToString();

                        //dtPreviousRecieved = DAL.fnSecurityInward(5, cmbItemDocNo.Text).Tables[0];

                        //if (dtPreviousRecieved.Rows.Count > 0)
                        //{

                        //    for (int j = 0; j < dtPreviousRecieved.Rows.Count; j++)
                        //    {
                        //        for (int p = 0; p < dtPurchaseOrderData.Rows.Count; p++)
                        //        {
                        //            if (dtPreviousRecieved.Rows[j]["ItemCode"].ToString() == dtPurchaseOrderData.Rows[p]["ItemCode"].ToString())
                        //            {
                        //                {
                        //                    int nIndex = dtPurchaseOrderData.Rows.IndexOf(dtPurchaseOrderData.Rows[p]);
                        //                    DataRow dr1 = dtPurchaseOrderData.Rows[nIndex];
                        //                    dr1["RecievedQty"] = dtPreviousRecieved.Rows[j]["RecievingQuantity"].ToString();
                        //                    break;
                        //                }
                        //            }

                        //        }
                        //    }
                        //}
                    }

                    break;
                case 1:
                    dtWorkOrderData = DAL.fnSecurityInward(3, cmbItemDocNo.Text).Tables[0];
                    if (dtWorkOrderData.Rows.Count > 0)
                    {
                        dgvInwardItems.AutoGenerateColumns = false;
                        dgvInwardItems.DataSource = dtWorkOrderData;
                        txtVendor.Text = dtWorkOrderData.Rows[0]["VendorName"].ToString();

                        //dtPreviousRecieved = DAL.fnSecurityInward(5, cmbItemDocNo.Text).Tables[0];

                        //if (dtPreviousRecieved.Rows.Count > 0)
                        //{
                        //    for (int j = 0; j < dtPreviousRecieved.Rows.Count; j++)
                        //    {
                        //        for (int p = 0; p < dtWorkOrderData.Rows.Count; p++)
                        //        {
                        //            if (dtPreviousRecieved.Rows[j]["ItemCode"].ToString() == dtWorkOrderData.Rows[p]["ItemCode"].ToString())
                        //            {
                        //                {
                        //                    int nIndex = dtWorkOrderData.Rows.IndexOf(dtPurchaseOrderData.Rows[p]);
                        //                    DataRow dr1 = dtWorkOrderData.Rows[nIndex];
                        //                    dr1["RecievedQty"] = dtPreviousRecieved.Rows[j]["RecievingQuantity"].ToString();
                        //                    break;
                        //                }
                        //            }
                        //        }
                        //    }
                        //}
                    }
                    break;
                case 2:
                    dtDeliveryChallanData = SQLERPCustomerUpdate(1, cmbItemDocNo.Text).Tables[0];
                    if (dtDeliveryChallanData.Rows.Count > 0)
                    {
                        dgvInwardItems.AutoGenerateColumns = false;
                        dgvInwardItems.DataSource = dtDeliveryChallanData;
                        txtVendor.Text = dtDeliveryChallanData.Rows[0]["VendorName"].ToString();
                    }
                    break;
            }
        }

        DataTable dtSlNo = new DataTable();
        DataTable dtPreviousRecieved = new DataTable();
        int iInwardSlNo;
        private void btnInward_Click(object sender, EventArgs e)
        {
            fnRowCheck();
            if (cmbInwardItemType.SelectedIndex >= 0 && cmbItemDocNo.SelectedIndex >= 0 && !bValidattion && !string.IsNullOrEmpty(txtinvoiveno.Text) && bRequiredDate)
            {
                dtSlNo = DAL.fnSecurityInward(4, "").Tables[0];

                if (dtSlNo.Rows.Count > 0)
                {
                    iInwardSlNo = Convert.ToInt32(dtSlNo.Rows[0]["InwardSlNo"].ToString());
                    iInwardSlNo++;
                }
                else
                {
                    iInwardSlNo = 20200001;
                }

                if (dgvInwardItems.Rows.Count == 0)
                {
                    GlobalClass.iSuccess = DAL.fnAddSecutiryInwardOutward(1, ("SI" + iInwardSlNo), txtInwardBy.Text, cmbInwardItemType.Text, cmbItemDocNo.Text, "",
                                                                               "", "0", iInwardSlNo, txtRemarks.Text,txtVendor.Text, txtinvoiveno.Text,invoicedtp.Text,"","","");
                }
                else
                {
                    foreach (DataGridViewRow dr in dgvInwardItems.Rows)
                    {
                        GlobalClass.iSuccess = DAL.fnAddSecutiryInwardOutward(1, ("SI" + iInwardSlNo), txtInwardBy.Text, cmbInwardItemType.Text, cmbItemDocNo.Text, dr.Cells["ItemCode"].Value.ToString(),
                                                                              Regex.Replace(dr.Cells["ItemDescription"].Value.ToString(),"'"," "), dr.Cells["Quantity"].Value.ToString(), iInwardSlNo, txtRemarks.Text, txtVendor.Text, txtinvoiveno.Text, invoicedtp.Text,"","","");
                    }
                }
                if (GlobalClass.iSuccess > 0)
                {
                    GlobalClass.iSuccess = DAL.fnAddERPLog(0, ("SI" + iInwardSlNo), frmLoginForm.GetUserDetails[2], invoicedtp.Text, "Item Inward", "SecurityInward");
                    MessageBox.Show(("SI" + iInwardSlNo) + "\n\nItems inward details saved successfully", "Success", 0, MessageBoxIcon.Information);
                    btnInward.Enabled = false;
                }
            }
            else
            {
                if (cmbInwardItemType.SelectedIndex < 0)
                {
                    MessageBox.Show("Select the inward item type.", "Error", 0, MessageBoxIcon.Error);
                    cmbInwardItemType.DroppedDown = true;
                }
                else if (cmbItemDocNo.SelectedIndex < 0)
                {
                    MessageBox.Show("Select the document number", "Error", 0, MessageBoxIcon.Error);
                    cmbItemDocNo.DroppedDown = true;
                }
                else if (!bRequiredDate)
                {
                    invoicedtp.Focus();
                    MessageBox.Show("Select Invoice date", "Error", 0, MessageBoxIcon.Error);
                }
                //else if (dgvInwardItems.Rows.Count == 0)
                //{
                //    MessageBox.Show("No item to inward", "Error", 0, MessageBoxIcon.Error);
                //}
            }
        }
        double oldvalue;
        private void dgvInwardItems_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            oldvalue = Convert.ToDouble(dgvInwardItems.CurrentCell.Value);
        }

        private void dgvInwardItems_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvInwardItems.CurrentCell.Value != null)
            {
                if (!string.IsNullOrEmpty(dgvInwardItems.CurrentCell.Value.ToString()) && (dgvInwardItems.CurrentCell.Value.ToString() != "."))
                {
                    //if (Convert.ToDouble(dgvInwardItems.CurrentCell.Value.ToString()) <= (Convert.ToDouble(dgvInwardItems.CurrentRow.Cells[4].Value) - Convert.ToDouble(dgvInwardItems.CurrentRow.Cells[3].Value)))
                    //{

                    //}
                    //else
                    //{
                    //    MessageBox.Show("Recieving quanity is more than order quantity. Check the quantity", "Error", 0, MessageBoxIcon.Error);
                    //    dgvInwardItems.CurrentCell.Value = 0;
                    //}
                }
                else
                {
                    MessageBox.Show("Enter the correct quanity", "Error", 0, MessageBoxIcon.Error);
                    dgvInwardItems.CurrentCell.Value = 0;
                }
            }
        }

        #region PO quantity cost validating function
        private void Control_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                e.Handled = true;
            }
        }
        #endregion

        private void dgvInwardItems_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
            }
        }

        bool bValidattion = false;
        private void fnRowCheck()
        {
            bValidattion = false;
            foreach (DataGridViewRow row in dgvInwardItems.Rows)
            {
                if (Convert.ToDouble(row.Cells[3].Value) == 0 || (row.Cells[3].Value) == null)
                {
                    MessageBox.Show("Qunaity not entered in item list.", "Error", 0, MessageBoxIcon.Error);
                    bValidattion = true;
                    break;
                }
                //else if (Convert.ToDouble(dgvInwardItems.CurrentRow.Cells[5].Value) > (Convert.ToDouble(dgvInwardItems.CurrentRow.Cells[4].Value) - Convert.ToDouble(dgvInwardItems.CurrentRow.Cells[3].Value)))
                //{
                //    MessageBox.Show("Recieving quanity is more than quantity. Check the quantity", "Error", 0, MessageBoxIcon.Error);
                //    bValidattion = true;
                //    break;
                //}
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            fnExit();
        }

        private void dgvInwardItems_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (dgvInwardItems.Rows.Count > 0)
                {
                    DialogResult DR = MessageBox.Show("Do you want to delete selected item ?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (DR == DialogResult.Yes)
                    {
                        dgvInwardItems.Rows.RemoveAt(dgvInwardItems.Rows.IndexOf(dgvInwardItems.CurrentRow));
                    }
                }
            }
        }

        private void invoicedtp_ValueChanged(object sender, EventArgs e)
        {
            bRequiredDate = true;
        }
    }
}
