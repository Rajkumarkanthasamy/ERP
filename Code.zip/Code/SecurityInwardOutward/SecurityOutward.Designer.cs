﻿namespace Erp_Project_With_Buttons.SecurityInwardOutward
{
    partial class SecurityOutward
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SecurityOutward));
            this.cmbItemDocNo = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnReject = new System.Windows.Forms.Button();
            this.btnAccept = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtOutwardBy = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbInwardItemType = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.dgvInwardItems = new System.Windows.Forms.DataGridView();
            this.DSCSLNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btExit = new System.Windows.Forms.Button();
            this.btnOutward = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.chkPrintPO = new System.Windows.Forms.CheckBox();
            this.cmbGatePass = new System.Windows.Forms.ComboBox();
            this.txtVendor = new System.Windows.Forms.TextBox();
            this.btnAddNewRow = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtewbno = new System.Windows.Forms.TextBox();
            this.txtlrpodno = new System.Windows.Forms.TextBox();
            this.dtpewbdate = new System.Windows.Forms.DateTimePicker();
            this.dtplrpod = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.txtvehicleno = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInwardItems)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbItemDocNo
            // 
            this.cmbItemDocNo.DropDownHeight = 90;
            this.cmbItemDocNo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbItemDocNo.DropDownWidth = 150;
            this.cmbItemDocNo.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbItemDocNo.FormattingEnabled = true;
            this.cmbItemDocNo.IntegralHeight = false;
            this.cmbItemDocNo.Location = new System.Drawing.Point(225, 45);
            this.cmbItemDocNo.Name = "cmbItemDocNo";
            this.cmbItemDocNo.Size = new System.Drawing.Size(253, 27);
            this.cmbItemDocNo.TabIndex = 230;
            this.cmbItemDocNo.SelectedIndexChanged += new System.EventHandler(this.cmbItemDocNo_SelectedIndexChanged);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.btnClose);
            this.panel1.Controls.Add(this.btnExit);
            this.panel1.Controls.Add(this.btnReject);
            this.panel1.Controls.Add(this.btnAccept);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Location = new System.Drawing.Point(204, 511);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(886, 74);
            this.panel1.TabIndex = 228;
            // 
            // btnClose
            // 
            this.btnClose.Enabled = false;
            this.btnClose.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(133, 14);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(114, 42);
            this.btnClose.TabIndex = 142;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(747, 14);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(114, 42);
            this.btnExit.TabIndex = 141;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            // 
            // btnReject
            // 
            this.btnReject.Enabled = false;
            this.btnReject.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReject.Location = new System.Drawing.Point(440, 14);
            this.btnReject.Name = "btnReject";
            this.btnReject.Size = new System.Drawing.Size(114, 42);
            this.btnReject.TabIndex = 140;
            this.btnReject.Text = "Review";
            this.btnReject.UseVisualStyleBackColor = true;
            // 
            // btnAccept
            // 
            this.btnAccept.Enabled = false;
            this.btnAccept.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAccept.Location = new System.Drawing.Point(290, 14);
            this.btnAccept.Name = "btnAccept";
            this.btnAccept.Size = new System.Drawing.Size(114, 42);
            this.btnAccept.TabIndex = 139;
            this.btnAccept.Text = "Accept";
            this.btnAccept.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(594, 14);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(114, 42);
            this.button1.TabIndex = 132;
            this.button1.Text = "Save";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(36, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(183, 19);
            this.label2.TabIndex = 227;
            this.label2.Text = "Item Document Number :";
            // 
            // txtOutwardBy
            // 
            this.txtOutwardBy.Enabled = false;
            this.txtOutwardBy.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOutwardBy.Location = new System.Drawing.Point(225, 78);
            this.txtOutwardBy.Name = "txtOutwardBy";
            this.txtOutwardBy.Size = new System.Drawing.Size(253, 27);
            this.txtOutwardBy.TabIndex = 226;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(122, 81);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(99, 19);
            this.label7.TabIndex = 225;
            this.label7.Text = "Outward by :";
            // 
            // cmbInwardItemType
            // 
            this.cmbInwardItemType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbInwardItemType.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbInwardItemType.FormattingEnabled = true;
            this.cmbInwardItemType.Items.AddRange(new object[] {
            "Purchase Order",
            "Work Order",
            "Deliver Challan",
            "Invoice",
            "DC Declaration Letter"});
            this.cmbInwardItemType.Location = new System.Drawing.Point(227, 10);
            this.cmbInwardItemType.Name = "cmbInwardItemType";
            this.cmbInwardItemType.Size = new System.Drawing.Size(253, 27);
            this.cmbInwardItemType.TabIndex = 224;
            this.cmbInwardItemType.SelectedIndexChanged += new System.EventHandler(this.cmbInwardItemType_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(71, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(150, 19);
            this.label6.TabIndex = 223;
            this.label6.Text = "Outward Item Type :";
            // 
            // dgvInwardItems
            // 
            this.dgvInwardItems.AllowUserToAddRows = false;
            this.dgvInwardItems.AllowUserToOrderColumns = true;
            this.dgvInwardItems.AllowUserToResizeRows = false;
            this.dgvInwardItems.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvInwardItems.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvInwardItems.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvInwardItems.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvInwardItems.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvInwardItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInwardItems.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DSCSLNO,
            this.ItemCode,
            this.ItemDescription,
            this.Quantity});
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvInwardItems.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgvInwardItems.Location = new System.Drawing.Point(12, 184);
            this.dgvInwardItems.Name = "dgvInwardItems";
            this.dgvInwardItems.RowHeadersVisible = false;
            this.dgvInwardItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvInwardItems.Size = new System.Drawing.Size(1197, 401);
            this.dgvInwardItems.TabIndex = 231;
            this.dgvInwardItems.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgvInwardItems_CellBeginEdit);
            this.dgvInwardItems.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvInwardItems_CellEndEdit);
            this.dgvInwardItems.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvInwardItems_EditingControlShowing);
            this.dgvInwardItems.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvInwardItems_KeyUp);
            // 
            // DSCSLNO
            // 
            this.DSCSLNO.DataPropertyName = "SlNo";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            this.DSCSLNO.DefaultCellStyle = dataGridViewCellStyle2;
            this.DSCSLNO.FillWeight = 56.85279F;
            this.DSCSLNO.HeaderText = "SlNo";
            this.DSCSLNO.Name = "DSCSLNO";
            this.DSCSLNO.ReadOnly = true;
            this.DSCSLNO.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DSCSLNO.Width = 47;
            // 
            // ItemCode
            // 
            this.ItemCode.DataPropertyName = "ItemCode";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            this.ItemCode.DefaultCellStyle = dataGridViewCellStyle3;
            this.ItemCode.HeaderText = "Item Code";
            this.ItemCode.Name = "ItemCode";
            this.ItemCode.ReadOnly = true;
            this.ItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemCode.Width = 76;
            // 
            // ItemDescription
            // 
            this.ItemDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ItemDescription.DataPropertyName = "ItemDescription";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ItemDescription.DefaultCellStyle = dataGridViewCellStyle4;
            this.ItemDescription.FillWeight = 107.1912F;
            this.ItemDescription.HeaderText = "Item Description";
            this.ItemDescription.Name = "ItemDescription";
            this.ItemDescription.ReadOnly = true;
            this.ItemDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "RecQty";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.LightGreen;
            this.Quantity.DefaultCellStyle = dataGridViewCellStyle5;
            this.Quantity.HeaderText = "Sending Qty";
            this.Quantity.Name = "Quantity";
            this.Quantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Quantity.Width = 89;
            // 
            // btExit
            // 
            this.btExit.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btExit.Location = new System.Drawing.Point(1103, 588);
            this.btExit.Name = "btExit";
            this.btExit.Size = new System.Drawing.Size(114, 42);
            this.btExit.TabIndex = 233;
            this.btExit.Text = "Exit";
            this.btExit.UseVisualStyleBackColor = true;
            this.btExit.Click += new System.EventHandler(this.btExit_Click);
            // 
            // btnOutward
            // 
            this.btnOutward.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOutward.Location = new System.Drawing.Point(955, 588);
            this.btnOutward.Name = "btnOutward";
            this.btnOutward.Size = new System.Drawing.Size(114, 42);
            this.btnOutward.TabIndex = 232;
            this.btnOutward.Text = "Save";
            this.btnOutward.UseVisualStyleBackColor = true;
            this.btnOutward.Click += new System.EventHandler(this.btnOutward_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(153, 131);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 19);
            this.label1.TabIndex = 234;
            this.label1.Text = "Vendor :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(572, 131);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 19);
            this.label3.TabIndex = 236;
            this.label3.Text = "Remarks :";
            // 
            // txtRemarks
            // 
            this.txtRemarks.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemarks.Location = new System.Drawing.Point(653, 116);
            this.txtRemarks.Multiline = true;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Size = new System.Drawing.Size(554, 62);
            this.txtRemarks.TabIndex = 237;
            // 
            // chkPrintPO
            // 
            this.chkPrintPO.AutoSize = true;
            this.chkPrintPO.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPrintPO.ForeColor = System.Drawing.Color.Black;
            this.chkPrintPO.Location = new System.Drawing.Point(883, 14);
            this.chkPrintPO.Name = "chkPrintPO";
            this.chkPrintPO.Size = new System.Drawing.Size(131, 23);
            this.chkPrintPO.TabIndex = 238;
            this.chkPrintPO.Text = "Gate Pass Print";
            this.chkPrintPO.UseVisualStyleBackColor = true;
            this.chkPrintPO.CheckedChanged += new System.EventHandler(this.chkPrintPO_CheckedChanged);
            // 
            // cmbGatePass
            // 
            this.cmbGatePass.DropDownHeight = 90;
            this.cmbGatePass.DropDownWidth = 150;
            this.cmbGatePass.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbGatePass.FormattingEnabled = true;
            this.cmbGatePass.IntegralHeight = false;
            this.cmbGatePass.Location = new System.Drawing.Point(1020, 10);
            this.cmbGatePass.Name = "cmbGatePass";
            this.cmbGatePass.Size = new System.Drawing.Size(180, 27);
            this.cmbGatePass.TabIndex = 239;
            this.cmbGatePass.SelectedIndexChanged += new System.EventHandler(this.cmbGatePass_SelectedIndexChanged);
            // 
            // txtVendor
            // 
            this.txtVendor.Enabled = false;
            this.txtVendor.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVendor.Location = new System.Drawing.Point(225, 111);
            this.txtVendor.Multiline = true;
            this.txtVendor.Name = "txtVendor";
            this.txtVendor.Size = new System.Drawing.Size(305, 56);
            this.txtVendor.TabIndex = 241;
            // 
            // btnAddNewRow
            // 
            this.btnAddNewRow.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAddNewRow.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAddNewRow.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNewRow.Location = new System.Drawing.Point(227, 184);
            this.btnAddNewRow.Name = "btnAddNewRow";
            this.btnAddNewRow.Size = new System.Drawing.Size(106, 30);
            this.btnAddNewRow.TabIndex = 255;
            this.btnAddNewRow.Text = "Add Item";
            this.btnAddNewRow.UseVisualStyleBackColor = false;
            this.btnAddNewRow.Visible = false;
            this.btnAddNewRow.Click += new System.EventHandler(this.btnAddNewRow_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(574, 45);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 19);
            this.label4.TabIndex = 256;
            this.label4.Text = "EWB No*:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(553, 80);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 19);
            this.label5.TabIndex = 257;
            this.label5.Text = "LR/POD No*:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(912, 53);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 19);
            this.label8.TabIndex = 258;
            this.label8.Text = "EWB Date*:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(891, 85);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(110, 19);
            this.label9.TabIndex = 259;
            this.label9.Text = "LR/POD Date*:";
            // 
            // txtewbno
            // 
            this.txtewbno.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtewbno.Location = new System.Drawing.Point(653, 46);
            this.txtewbno.Name = "txtewbno";
            this.txtewbno.Size = new System.Drawing.Size(207, 27);
            this.txtewbno.TabIndex = 260;
            // 
            // txtlrpodno
            // 
            this.txtlrpodno.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtlrpodno.Location = new System.Drawing.Point(653, 80);
            this.txtlrpodno.Name = "txtlrpodno";
            this.txtlrpodno.Size = new System.Drawing.Size(207, 27);
            this.txtlrpodno.TabIndex = 261;
            // 
            // dtpewbdate
            // 
            this.dtpewbdate.CalendarFont = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpewbdate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpewbdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpewbdate.Location = new System.Drawing.Point(1003, 48);
            this.dtpewbdate.Name = "dtpewbdate";
            this.dtpewbdate.Size = new System.Drawing.Size(125, 27);
            this.dtpewbdate.TabIndex = 262;
            this.dtpewbdate.ValueChanged += new System.EventHandler(this.dtpewbdate_ValueChanged);
            // 
            // dtplrpod
            // 
            this.dtplrpod.CalendarFont = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtplrpod.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtplrpod.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtplrpod.Location = new System.Drawing.Point(1003, 80);
            this.dtplrpod.Name = "dtplrpod";
            this.dtplrpod.Size = new System.Drawing.Size(125, 27);
            this.dtplrpod.TabIndex = 263;
            this.dtplrpod.ValueChanged += new System.EventHandler(this.dtplrpod_ValueChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(558, 14);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(93, 19);
            this.label10.TabIndex = 264;
            this.label10.Text = "Vehicle No*:";
            // 
            // txtvehicleno
            // 
            this.txtvehicleno.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtvehicleno.Location = new System.Drawing.Point(653, 12);
            this.txtvehicleno.Name = "txtvehicleno";
            this.txtvehicleno.Size = new System.Drawing.Size(207, 27);
            this.txtvehicleno.TabIndex = 265;
            // 
            // SecurityOutward
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightCoral;
            this.ClientSize = new System.Drawing.Size(1221, 630);
            this.Controls.Add(this.txtvehicleno);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.dtplrpod);
            this.Controls.Add(this.dtpewbdate);
            this.Controls.Add(this.txtlrpodno);
            this.Controls.Add(this.txtewbno);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnAddNewRow);
            this.Controls.Add(this.txtVendor);
            this.Controls.Add(this.cmbGatePass);
            this.Controls.Add(this.chkPrintPO);
            this.Controls.Add(this.txtRemarks);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btExit);
            this.Controls.Add(this.btnOutward);
            this.Controls.Add(this.dgvInwardItems);
            this.Controls.Add(this.cmbItemDocNo);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtOutwardBy);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cmbInwardItemType);
            this.Controls.Add(this.label6);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "SecurityOutward";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SecurityOutward";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SecurityOutward_FormClosing);
            this.Load += new System.EventHandler(this.SecurityOutward_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvInwardItems)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbItemDocNo;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnReject;
        private System.Windows.Forms.Button btnAccept;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtOutwardBy;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbInwardItemType;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dgvInwardItems;
        private System.Windows.Forms.Button btExit;
        private System.Windows.Forms.Button btnOutward;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.CheckBox chkPrintPO;
        private System.Windows.Forms.ComboBox cmbGatePass;
        private System.Windows.Forms.TextBox txtVendor;
        private System.Windows.Forms.DataGridViewTextBoxColumn DSCSLNO;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.Button btnAddNewRow;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtewbno;
        private System.Windows.Forms.TextBox txtlrpodno;
        private System.Windows.Forms.DateTimePicker dtpewbdate;
        private System.Windows.Forms.DateTimePicker dtplrpod;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtvehicleno;
    }
}
