﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.SecurityInwardOutward
{
    public partial class frmManualInward : Form
    {
        public frmManualInward()
        {
            InitializeComponent();
        }
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm frmLoginForm = new Login.frmLoginForm();
        SecurityInwardOutward.SecurityInwardOutwardHome SHome = new SecurityInwardOutwardHome();
        frmForm2 frm = new frmForm2();
        private void frmManualInward_Load(object sender, EventArgs e)
        {
            txtInwardBy.Text = frmLoginForm.GetUserDetails[2].ToString();
        }

        private void btnAddNewRow_Click(object sender, EventArgs e)
        {
            dgvInwardItems.Rows.Add();


            dgvInwardItems.Rows[dgvInwardItems.Rows.Count - 1].Cells[1].Value = "";
            dgvInwardItems.Rows[dgvInwardItems.Rows.Count - 1].Cells[2].Value = "";
            dgvInwardItems.Rows[dgvInwardItems.Rows.Count - 1].Cells[3].Value = 0;

            int i = 1;
            foreach (DataGridViewRow row in dgvInwardItems.Rows)
            {
                row.Cells[0].Value = i;
                i++;
            }
        }

        private void frmManualInward_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnExit();
        }

        private void fnExit()
        {
            this.Hide();
            frm.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            fnExit();
        }
        double oldvalue;
        private void dgvInwardItems_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgvInwardItems.CurrentCell.OwningColumn.Index == 3)
            {
                oldvalue = Convert.ToDouble(dgvInwardItems.CurrentCell.Value);
            }
        }

        private void dgvInwardItems_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            switch (dgvInwardItems.CurrentCell.OwningColumn.Index)
            {
                case 3:
                    if (dgvInwardItems.CurrentCell.Value != null)
                    {
                        if (!string.IsNullOrEmpty(dgvInwardItems.CurrentCell.Value.ToString()) && (dgvInwardItems.CurrentCell.Value.ToString() != "."))
                        {
                        }
                        else
                        {
                            MessageBox.Show("Enter the correct quanity", "Error", 0, MessageBoxIcon.Error);
                            dgvInwardItems.CurrentCell.Value = 0;
                        }
                    }
                    break;
            }
        }

        bool bValidattion = false;
        private void fnRowCheck()
        {
            bValidattion = false;
            foreach (DataGridViewRow row in dgvInwardItems.Rows)
            {
                if (Convert.ToDouble(row.Cells[3].Value) == 0 || (row.Cells[3].Value) == null)
                {
                    MessageBox.Show("Qunaity not entered in item list.", "Error", 0, MessageBoxIcon.Error);
                    bValidattion = true;
                    break;
                }
                //else if (Convert.ToDouble(dgvInwardItems.CurrentRow.Cells[5].Value) > (Convert.ToDouble(dgvInwardItems.CurrentRow.Cells[4].Value) - Convert.ToDouble(dgvInwardItems.CurrentRow.Cells[3].Value)))
                //{
                //    MessageBox.Show("Recieving quanity is more than quantity. Check the quantity", "Error", 0, MessageBoxIcon.Error);
                //    bValidattion = true;
                //    break;
                //}
            }
        }
        int iInwardSlNo;
        DataTable dtSlNo = new DataTable();
        private void btnInward_Click(object sender, EventArgs e)
        {
            fnRowCheck();

            if (!string.IsNullOrEmpty(cmbInwardItemType.Text) && !string.IsNullOrEmpty(cmbItemDocNo.Text) && !bValidattion)
            {
                dtSlNo = DAL.fnSecurityInward(4, "").Tables[0];

                if (dtSlNo.Rows.Count > 0)
                {
                    iInwardSlNo = Convert.ToInt32(dtSlNo.Rows[0]["InwardSlNo"].ToString());
                    iInwardSlNo++;
                }
                else
                {
                    iInwardSlNo = 20200001;
                }

                if (dgvInwardItems.Rows.Count == 0)
                {
                    GlobalClass.iSuccess = DAL.fnAddSecutiryInwardOutward(1, ("SI" + iInwardSlNo), txtInwardBy.Text, cmbInwardItemType.Text, cmbItemDocNo.Text, "",
                                                                               "", "0", iInwardSlNo, txtRemarks.Text, txtVendor.Text, txtinvoiveno.Text, invoicedtp.Text, "","","");
                }
                else
                {
                    foreach (DataGridViewRow dr in dgvInwardItems.Rows)
                    {
                        GlobalClass.iSuccess = DAL.fnAddSecutiryInwardOutward(1, ("SI" + iInwardSlNo), txtInwardBy.Text, cmbInwardItemType.Text, cmbItemDocNo.Text, dr.Cells["ItemCode"].Value.ToString(),
                                                                                dr.Cells["ItemDescription"].Value.ToString(), dr.Cells["Quantity"].Value.ToString(), iInwardSlNo, txtRemarks.Text, txtVendor.Text, txtinvoiveno.Text, invoicedtp.Text, "","","");
                    }
                }
                if (GlobalClass.iSuccess > 0)
                {
                    GlobalClass.iSuccess = DAL.fnAddERPLog(0, ("SI" + iInwardSlNo), frmLoginForm.GetUserDetails[2], invoicedtp.Text, "Item Inward", "SecurityInward");
                    MessageBox.Show(("SI" + iInwardSlNo) + "\n\nItems inward details saved successfully", "Success", 0, MessageBoxIcon.Information);
                    btnInward.Enabled = false;
                    this.Hide();
                    frmManualInward MI = new frmManualInward();
                    MI.Show();
                }
            }
            else
            {
                if (string.IsNullOrEmpty(cmbInwardItemType.Text))
                {
                    MessageBox.Show("Enter the inward item type.", "Error", 0, MessageBoxIcon.Error);
                }
                else if (string.IsNullOrEmpty(cmbItemDocNo.Text))
                {
                    MessageBox.Show("Enter the document number", "Error", 0, MessageBoxIcon.Error);
                    cmbItemDocNo.DroppedDown = true;
                }
            }
        }

        #region PO quantity cost validating function
        private void Control_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (dgvInwardItems.CurrentCell.OwningColumn.Index == 3)
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
                {
                    e.Handled = true;
                }
                if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
                {
                    e.Handled = true;
                }
            }
        }
        #endregion

        private void dgvInwardItems_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
            }
        }

        private void dgvInwardItems_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (dgvInwardItems.Rows.Count > 0)
                {
                    DialogResult DR = MessageBox.Show("Do you want to delete selected item ?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (DR == DialogResult.Yes)
                    {
                        dgvInwardItems.Rows.RemoveAt(dgvInwardItems.Rows.IndexOf(dgvInwardItems.CurrentRow));
                    }
                }
            }
        }
    }
}
