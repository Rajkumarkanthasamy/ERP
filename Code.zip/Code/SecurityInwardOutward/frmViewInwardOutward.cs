﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Diagnostics;

namespace Erp_Project_With_Buttons.SecurityInwardOutward
{
    public partial class frmViewInwardOutward : Form
    {
        public frmViewInwardOutward()
        {
            InitializeComponent();
        }
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm frmLoginForm = new Login.frmLoginForm();
        SecurityInwardOutward.SecurityInwardOutwardHome SHome = new SecurityInwardOutwardHome();
        frmForm2 frm = new frmForm2();
        DataTable dtReport = new DataTable();
        private void fnExit()
        {
            this.Hide();
            frm.Show();
        }
        private void btnReport_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            dgvSecurityReport.DataSource = null;
            dtpFromDate.Format = DateTimePickerFormat.Custom;
            dtpFromDate.CustomFormat = "yyyy-MM-dd";
            dtpToDate.Format = DateTimePickerFormat.Custom;
            dtpToDate.CustomFormat = "yyyy-MM-dd";
            dtReport =DAL.fnSecurityInwardOutwardReport(0, dtpFromDate.Text, dtpToDate.Text).Tables[0];

            dgvSecurityReport.AutoGenerateColumns = true;
            dgvSecurityReport.DataSource = dtReport;

         

            Datagridviewcolor(dgvSecurityReport);

            foreach (DataGridViewColumn column in dgvSecurityReport.Columns)
            {
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
            }

            dtClone = dtReport.Copy();
            bsIteSearch.DataSource = dtClone;

            dtpFromDate.Format = DateTimePickerFormat.Custom;
            dtpFromDate.CustomFormat = "dd-MM-yyyy";
            dtpToDate.Format = DateTimePickerFormat.Custom;
            dtpToDate.CustomFormat = "dd-MM-yyyy";
            Cursor.Current = Cursors.Default;
        }
        private void Datagridviewcolor(DataGridView dgDataGridView)
        {
            foreach (DataGridViewRow dgr in dgDataGridView.Rows)
            {
                if ((dgr.Cells[0].Value.ToString()) == "Inward")
                {
                    dgr.DefaultCellStyle.BackColor = Color.BurlyWood;
                }
            }
        }
        private void frmViewInwardOutward_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnExit();
        }
        BindingSource bsIteSearch = new BindingSource();
        DataTable dtClone = new DataTable();
        private void txtSearchText_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtSearchText.Text.Length > 1)
            {
                fnRowFilter(0, txtSearchText.Text);
                dgvSecurityReport.DataSource = bsIteSearch;
                Datagridviewcolor(dgvSecurityReport);
            }
            else
            {
                bsIteSearch.RemoveFilter();
                Datagridviewcolor(dgvSecurityReport);
            }
        }


        private void fnRowFilter(int uSearchOption, string sRowFilter)    //filter the Item list depends upon the user inpts
        {
            if (dgvSecurityReport.Rows.Count > 0)
            {
                switch (uSearchOption)
                {
                    case 0:
                        {
                            bsIteSearch.Filter = string.Format("InwardDocumentNo LIKE '%{0}%' or VendorName LIKE '%{0}%'", sRowFilter);
                            break;
                        }
                }
            }
        }

        private void dgvSecurityReport_KeyUp(object sender, KeyEventArgs e)
        {
            //if (e.KeyCode == Keys.Delete)
            //{
            //    if (dgvSecurityReport.Rows.Count > 0)
            //    {
            //        DialogResult DR = MessageBox.Show("Do you want to delete selected " + dgvSecurityReport.CurrentRow.Cells[4].Value.ToString() + " details", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            //        if (DR == DialogResult.Yes)
            //        {
            //            if (dgvSecurityReport.CurrentRow.Cells[0].Value.ToString() == "Inward")
            //            {
            //                GlobalClass.iSuccess = DAL.fnDeleteSecutiryInwardOutward(1, dgvSecurityReport.CurrentRow.Cells[1].Value.ToString());
            //                dgvSecurityReport.Rows.RemoveAt(dgvSecurityReport.Rows.IndexOf(dgvSecurityReport.CurrentRow));
            //            }
            //            else if (dgvSecurityReport.CurrentRow.Cells[0].Value.ToString() == "Outward")
            //            {
            //                GlobalClass.iSuccess = DAL.fnDeleteSecutiryInwardOutward(2, dgvSecurityReport.CurrentRow.Cells[1].Value.ToString());
            //                dgvSecurityReport.Rows.RemoveAt(dgvSecurityReport.Rows.IndexOf(dgvSecurityReport.CurrentRow));
            //            }
            //        }
            //    }
            //}
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            fnExit();
        }

        private void btnExcel_Click(object sender, EventArgs e)
        {
            int iRowIndex = 1;
            string ExcelFolderPath;
            string FileFullPath;
            EXCEL.Workbook NewWorkBook;
            EXCEL.Worksheet NewWorkSheet;
            EXCEL.Application ExcelApp;
            EXCEL.Range CELLS, cell1, cell2;
            object misValue;
            if (dtReport.Rows.Count > 0)
            {
                ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\Security Inward Outward\\";
                FileFullPath = ExcelFolderPath + "Security Inward Outward" + "--" + DateTime.Now.ToString("dd/MM/yyyy hh/mm/ss") + ".xls";
                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);
                ExcelApp = new EXCEL.Application();
                misValue = System.Reflection.Missing.Value;
                try
                {
                    if (ExcelApp == null)
                        MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                    NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                    NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                    if (NewWorkSheet == null)
                        MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                    else
                        NewWorkSheet.Name = "Inward Outward";
                    // Select the Excel cells, in the range c1 to c7 in the worksheet for cell access check.
                    EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                    if (RANGE == null)
                        MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                    NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlWorkbookNormal, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                    CELLS = NewWorkSheet.Cells;

                    // dtIndentItems = DAL.fnIndentExcel(cmbIndentNo.Text, null).Tables[0];

                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);

                    NewWorkSheet.Cells[iRowIndex, 1] = "Security Inward Outward (" +dtpFromDate.Text+ "to" + dtpToDate.Text+")";
                    iRowIndex++;
                    iRowIndex++;
                    iRowIndex++;



                    if (dtReport.Rows.Count > 0)
                    {
                        object[,] rawData = new object[dtReport.Rows.Count + 1, dtReport.Columns.Count];
                        for (int col = 0; col < dtReport.Columns.Count; col++)
                        {
                            rawData[0, col] = dtReport.Columns[col].ColumnName;
                        }
                        for (int row = 0; row < dtReport.Rows.Count; row++)
                        {
                            for (int col = 0; col < dtReport.Columns.Count; col++)
                            {
                                rawData[row + 1, col] = dtReport.Rows[row].ItemArray[col];
                            }
                        }
                        string excelRange = string.Empty;
                        string finalColLetter = string.Empty;
                        string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        int colCharsetLen = colCharset.Length;

                        if (dtReport.Columns.Count > colCharsetLen)
                        {
                            finalColLetter = colCharset.Substring(
                                (dtReport.Columns.Count - 1) / colCharsetLen - 1, 1);
                        }

                        finalColLetter += colCharset.Substring((dtReport.Columns.Count - 1) % colCharsetLen, 1);
                        excelRange = string.Format("A6:{0}{1}", finalColLetter, dtReport.Rows.Count + 6);


                        NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                    }


                    NewWorkSheet.Range["A1:R6"].Cells.Font.Bold = true;
                    NewWorkSheet.Range["A1:R6"].Cells.Font.Size = 14;



                    //NewWorkSheet.get_Range("A6:B999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    // NewWorkSheet.get_Range("A6", "B999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;

                    //  Microsoft.Office.Interop.Excel.Range Range = NewWorkSheet.get_Range("C6", "E399");
                    //  Range.EntireColumn.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;

                    NewWorkSheet.Rows.AutoFit();

                    NewWorkSheet.Columns.AutoFit();
                    NewWorkSheet.Columns[7].ColumnWidth = "50";


                    NewWorkSheet.PageSetup.PrintArea = "A1:R" + (dtReport.Rows.Count + iRowIndex + 6 )+ "";
                    NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                    NewWorkSheet.PageSetup.PrintNotes = true;
                    NewWorkSheet.PageSetup.Zoom = 100;
                    NewWorkSheet.PageSetup.FitToPagesTall = 1;
                    NewWorkSheet.PageSetup.FitToPagesWide = 1;
                    NewWorkSheet.PageSetup.LeftMargin = 0;
                    NewWorkSheet.PageSetup.RightMargin = 0;
                    NewWorkSheet.PageSetup.TopMargin = 0.75;
                    NewWorkSheet.PageSetup.BottomMargin = 0.75;
                    NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                    NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                    //string _stLOGO = ("C:\\Databasepath\\Bisslogo.jpg");
                    //EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 7];

                    //Image oImage = Image.FromFile(_stLOGO);
                    //System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    //NewWorkSheet.Paste(oRange, _stLOGO);

                    NewWorkBook.Save();
                    ExcelApp.Visible = true;
                    System.Threading.Thread.Sleep(1000);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                    {
                        GetProcess.Kill();
                    }
                }
            }
            else
                MessageBox.Show("No items to save", "Error", 0, MessageBoxIcon.Question);
        }

        #region Excel Merge Function
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlMedium, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                default:
                    {
                        break;
                    }
            }
        }
        #endregion
    }
}
