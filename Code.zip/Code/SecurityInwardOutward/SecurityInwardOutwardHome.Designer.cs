﻿namespace Erp_Project_With_Buttons.SecurityInwardOutward
{
    partial class SecurityInwardOutwardHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SecurityInwardOutwardHome));
            this.btnInwardOutward = new System.Windows.Forms.Button();
            this.btnOutwardItems = new System.Windows.Forms.Button();
            this.btnManualInward = new System.Windows.Forms.Button();
            this.btnInwardItems = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnInwardOutward
            // 
            this.btnInwardOutward.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnInwardOutward.FlatAppearance.BorderSize = 0;
            this.btnInwardOutward.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInwardOutward.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnInwardOutward.ForeColor = System.Drawing.Color.Black;
            this.btnInwardOutward.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_checklist_481;
            this.btnInwardOutward.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnInwardOutward.Location = new System.Drawing.Point(570, 316);
            this.btnInwardOutward.Name = "btnInwardOutward";
            this.btnInwardOutward.Size = new System.Drawing.Size(96, 120);
            this.btnInwardOutward.TabIndex = 46;
            this.btnInwardOutward.Text = "Inward\r\nOutward\r\nView";
            this.btnInwardOutward.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnInwardOutward.UseVisualStyleBackColor = false;
            this.btnInwardOutward.Click += new System.EventHandler(this.btnInwardOutward_Click);
            // 
            // btnOutwardItems
            // 
            this.btnOutwardItems.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnOutwardItems.FlatAppearance.BorderSize = 0;
            this.btnOutwardItems.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOutwardItems.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnOutwardItems.ForeColor = System.Drawing.Color.Black;
            this.btnOutwardItems.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_import_48;
            this.btnOutwardItems.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnOutwardItems.Location = new System.Drawing.Point(570, 132);
            this.btnOutwardItems.Name = "btnOutwardItems";
            this.btnOutwardItems.Size = new System.Drawing.Size(96, 93);
            this.btnOutwardItems.TabIndex = 45;
            this.btnOutwardItems.Text = "Outward Items";
            this.btnOutwardItems.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnOutwardItems.UseVisualStyleBackColor = false;
            this.btnOutwardItems.Click += new System.EventHandler(this.btnOutwardItems_Click);
            // 
            // btnManualInward
            // 
            this.btnManualInward.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnManualInward.FlatAppearance.BorderSize = 0;
            this.btnManualInward.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnManualInward.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnManualInward.ForeColor = System.Drawing.Color.Black;
            this.btnManualInward.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_transfer_481;
            this.btnManualInward.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnManualInward.Location = new System.Drawing.Point(151, 316);
            this.btnManualInward.Name = "btnManualInward";
            this.btnManualInward.Size = new System.Drawing.Size(96, 93);
            this.btnManualInward.TabIndex = 44;
            this.btnManualInward.Text = "Manual Inward";
            this.btnManualInward.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnManualInward.UseVisualStyleBackColor = false;
            this.btnManualInward.Click += new System.EventHandler(this.btnManualInward_Click);
            // 
            // btnInwardItems
            // 
            this.btnInwardItems.FlatAppearance.BorderSize = 0;
            this.btnInwardItems.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInwardItems.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInwardItems.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnInwardItems.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_open_document_48;
            this.btnInwardItems.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnInwardItems.Location = new System.Drawing.Point(151, 132);
            this.btnInwardItems.Name = "btnInwardItems";
            this.btnInwardItems.Size = new System.Drawing.Size(96, 93);
            this.btnInwardItems.TabIndex = 43;
            this.btnInwardItems.Text = "Inward Items";
            this.btnInwardItems.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnInwardItems.UseVisualStyleBackColor = true;
            this.btnInwardItems.Click += new System.EventHandler(this.btnInwardItems_Click);
            // 
            // SecurityInwardOutwardHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(957, 486);
            this.Controls.Add(this.btnInwardOutward);
            this.Controls.Add(this.btnOutwardItems);
            this.Controls.Add(this.btnManualInward);
            this.Controls.Add(this.btnInwardItems);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "SecurityInwardOutwardHome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Security Inward Outward";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SecurityInwardOutwardHome_FormClosing);
            this.Load += new System.EventHandler(this.SecurityInwardOutwardHome_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnOutwardItems;
        private System.Windows.Forms.Button btnManualInward;
        private System.Windows.Forms.Button btnInwardItems;
        private System.Windows.Forms.Button btnInwardOutward;
    }
}