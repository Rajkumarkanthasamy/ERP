﻿using System;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.SecurityInwardOutward
{
    public partial class SecurityInwardOutwardHome : Form
    {
        public SecurityInwardOutwardHome()
        {
            InitializeComponent();
        }
        frmForm2 frm = new frmForm2();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm frmLoginForm = new Login.frmLoginForm();

        private void SecurityInwardOutwardHome_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            frm.Show();
        }

        private void SecurityInwardOutwardHome_Load(object sender, EventArgs e)
        {
            //if (Login.frmLoginForm.sUserDetails[55] != "True")
            //{
            //    btnKanBanProduct.Enabled = false;
            //}
            //else
            //{
            //    btnKanBanProduct.Enabled = true;
            //}

            //if (Login.frmLoginForm.sUserDetails[56] != "True")
            //{
            //    btnReport.Enabled = false;
            //}
            //else
            //{
            //    btnReport.Enabled = true;
            //}
        }

        #region Function to Show Please wait form & Switch to Selected From
        private void fnFormShow(Form Frm)
        {
            this.Hide();
            pleasewaitform pleaseWait = new pleasewaitform();
            pleaseWait.Show();
            Application.DoEvents();
            Frm.Show();
            pleaseWait.Hide();
        }
        #endregion

        private void btnInwardItems_Click(object sender, EventArgs e)
        {
            SecurityInwardOutward.frmSecurityInwards SInward = new frmSecurityInwards();
            fnFormShow(SInward);
        }

        private void btnOutwardItems_Click(object sender, EventArgs e)
        {
            SecurityInwardOutward.SecurityOutward SOutward = new SecurityOutward();
            fnFormShow(SOutward);
        }

        private void btnManualInward_Click(object sender, EventArgs e)
        {
            SecurityInwardOutward.frmManualInward ManInward = new frmManualInward();
            fnFormShow(ManInward);
        }

        private void btnInwardOutward_Click(object sender, EventArgs e)
        {
            SecurityInwardOutward.frmViewInwardOutward ViewReport = new frmViewInwardOutward();
            fnFormShow(ViewReport);
        }
    }
}
