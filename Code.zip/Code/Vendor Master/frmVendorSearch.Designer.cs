﻿namespace Erp_Project_With_Buttons.Vendor_Master
{
    partial class frmVendorSearch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmVendorSearch));
            this.gbSearchOptions = new System.Windows.Forms.GroupBox();
            this.checkShowInactive = new System.Windows.Forms.CheckBox();
            this.txtVendorCode = new System.Windows.Forms.TextBox();
            this.lblTIN = new System.Windows.Forms.Label();
            this.txtVendorName = new System.Windows.Forms.TextBox();
            this.lblCompanyName = new System.Windows.Forms.Label();
            this.dgVendorList = new System.Windows.Forms.DataGridView();
            this.VendorCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VendorName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TINNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ContactPerson = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PhoneNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FaxNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmailAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbSearchOptions.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgVendorList)).BeginInit();
            this.SuspendLayout();
            // 
            // gbSearchOptions
            // 
            this.gbSearchOptions.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.gbSearchOptions.Controls.Add(this.checkShowInactive);
            this.gbSearchOptions.Controls.Add(this.txtVendorCode);
            this.gbSearchOptions.Controls.Add(this.lblTIN);
            this.gbSearchOptions.Controls.Add(this.txtVendorName);
            this.gbSearchOptions.Controls.Add(this.lblCompanyName);
            this.gbSearchOptions.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.gbSearchOptions.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbSearchOptions.Location = new System.Drawing.Point(5, 12);
            this.gbSearchOptions.Name = "gbSearchOptions";
            this.gbSearchOptions.Size = new System.Drawing.Size(1294, 80);
            this.gbSearchOptions.TabIndex = 6;
            this.gbSearchOptions.TabStop = false;
            // 
            // checkShowInactive
            // 
            this.checkShowInactive.AutoSize = true;
            this.checkShowInactive.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkShowInactive.Location = new System.Drawing.Point(1122, 31);
            this.checkShowInactive.Name = "checkShowInactive";
            this.checkShowInactive.Size = new System.Drawing.Size(138, 27);
            this.checkShowInactive.TabIndex = 5;
            this.checkShowInactive.Text = "Show Inactive";
            this.checkShowInactive.UseVisualStyleBackColor = true;
            this.checkShowInactive.CheckedChanged += new System.EventHandler(this.checkShowInactive_CheckedChanged);
            // 
            // txtVendorCode
            // 
            this.txtVendorCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVendorCode.Location = new System.Drawing.Point(152, 31);
            this.txtVendorCode.Name = "txtVendorCode";
            this.txtVendorCode.Size = new System.Drawing.Size(231, 27);
            this.txtVendorCode.TabIndex = 3;
            this.txtVendorCode.Enter += new System.EventHandler(this.txtVendorCode_Enter);
            this.txtVendorCode.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtVendorCode_KeyUp);
            // 
            // lblTIN
            // 
            this.lblTIN.AutoSize = true;
            this.lblTIN.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTIN.Location = new System.Drawing.Point(30, 31);
            this.lblTIN.Name = "lblTIN";
            this.lblTIN.Size = new System.Drawing.Size(116, 23);
            this.lblTIN.TabIndex = 2;
            this.lblTIN.Text = "Vendor Code:";
            // 
            // txtVendorName
            // 
            this.txtVendorName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVendorName.Location = new System.Drawing.Point(560, 31);
            this.txtVendorName.Name = "txtVendorName";
            this.txtVendorName.Size = new System.Drawing.Size(481, 27);
            this.txtVendorName.TabIndex = 1;
            this.txtVendorName.Enter += new System.EventHandler(this.txtVendorName_Enter);
            this.txtVendorName.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtVendorName_KeyUp);
            // 
            // lblCompanyName
            // 
            this.lblCompanyName.AutoSize = true;
            this.lblCompanyName.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCompanyName.Location = new System.Drawing.Point(431, 31);
            this.lblCompanyName.Name = "lblCompanyName";
            this.lblCompanyName.Size = new System.Drawing.Size(123, 23);
            this.lblCompanyName.TabIndex = 0;
            this.lblCompanyName.Text = "Vendor Name:";
            // 
            // dgVendorList
            // 
            this.dgVendorList.AllowUserToAddRows = false;
            this.dgVendorList.AllowUserToDeleteRows = false;
            this.dgVendorList.AllowUserToResizeRows = false;
            this.dgVendorList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgVendorList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgVendorList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgVendorList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgVendorList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgVendorList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.VendorCode,
            this.VendorName,
            this.TINNO,
            this.ContactPerson,
            this.PhoneNo,
            this.FaxNo,
            this.EmailAddress});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgVendorList.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgVendorList.EnableHeadersVisualStyles = false;
            this.dgVendorList.Location = new System.Drawing.Point(4, 98);
            this.dgVendorList.MultiSelect = false;
            this.dgVendorList.Name = "dgVendorList";
            this.dgVendorList.ReadOnly = true;
            this.dgVendorList.RowHeadersVisible = false;
            this.dgVendorList.Size = new System.Drawing.Size(1294, 580);
            this.dgVendorList.TabIndex = 7;
            this.dgVendorList.DoubleClick += new System.EventHandler(this.dgVendorList_DoubleClick);
            // 
            // VendorCode
            // 
            this.VendorCode.DataPropertyName = "VendorCode";
            this.VendorCode.HeaderText = "VendorCode";
            this.VendorCode.Name = "VendorCode";
            this.VendorCode.ReadOnly = true;
            this.VendorCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.VendorCode.Width = 98;
            // 
            // VendorName
            // 
            this.VendorName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.VendorName.DataPropertyName = "VendorName";
            this.VendorName.HeaderText = "Vendor Name";
            this.VendorName.Name = "VendorName";
            this.VendorName.ReadOnly = true;
            this.VendorName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.VendorName.Width = 107;
            // 
            // TINNO
            // 
            this.TINNO.DataPropertyName = "TINNO";
            this.TINNO.HeaderText = "TIN";
            this.TINNO.Name = "TINNO";
            this.TINNO.ReadOnly = true;
            this.TINNO.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.TINNO.Width = 38;
            // 
            // ContactPerson
            // 
            this.ContactPerson.DataPropertyName = "ContactPerson";
            this.ContactPerson.HeaderText = "Contact Person";
            this.ContactPerson.Name = "ContactPerson";
            this.ContactPerson.ReadOnly = true;
            this.ContactPerson.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ContactPerson.Width = 119;
            // 
            // PhoneNo
            // 
            this.PhoneNo.DataPropertyName = "PhoneNo";
            this.PhoneNo.HeaderText = "Phone No";
            this.PhoneNo.Name = "PhoneNo";
            this.PhoneNo.ReadOnly = true;
            this.PhoneNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PhoneNo.Width = 83;
            // 
            // FaxNo
            // 
            this.FaxNo.DataPropertyName = "FaxNo";
            this.FaxNo.HeaderText = "Fax No";
            this.FaxNo.Name = "FaxNo";
            this.FaxNo.ReadOnly = true;
            this.FaxNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.FaxNo.Width = 61;
            // 
            // EmailAddress
            // 
            this.EmailAddress.DataPropertyName = "EmailAddress";
            this.EmailAddress.HeaderText = "Email";
            this.EmailAddress.Name = "EmailAddress";
            this.EmailAddress.ReadOnly = true;
            this.EmailAddress.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.EmailAddress.Width = 52;
            // 
            // frmVendorSearch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1304, 682);
            this.Controls.Add(this.dgVendorList);
            this.Controls.Add(this.gbSearchOptions);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmVendorSearch";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Vendor Search";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmVendorSearch_FormClosing);
            this.Load += new System.EventHandler(this.frmVendorSearch_Load);
            this.gbSearchOptions.ResumeLayout(false);
            this.gbSearchOptions.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgVendorList)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbSearchOptions;
        private System.Windows.Forms.CheckBox checkShowInactive;
        private System.Windows.Forms.TextBox txtVendorCode;
        private System.Windows.Forms.Label lblTIN;
        private System.Windows.Forms.TextBox txtVendorName;
        private System.Windows.Forms.Label lblCompanyName;
        private System.Windows.Forms.DataGridView dgVendorList;
        private System.Windows.Forms.DataGridViewTextBoxColumn VendorCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn VendorName;
        private System.Windows.Forms.DataGridViewTextBoxColumn TINNO;
        private System.Windows.Forms.DataGridViewTextBoxColumn ContactPerson;
        private System.Windows.Forms.DataGridViewTextBoxColumn PhoneNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn FaxNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmailAddress;
    }
}