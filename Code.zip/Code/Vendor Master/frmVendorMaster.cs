﻿using System;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Vendor_Master
{
    public partial class frmVendorMaster : Form
    {
        frmForm2 frm = new frmForm2();
        Global GLobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        DataTable dtVendorlist = new DataTable();
        private static string sVendorCode;
        Login.frmLoginForm login = new Login.frmLoginForm();
        public string fnGetVendorCode //Get Vendor code from VendorSearch form
        {
            get
            {
                return sVendorCode;
            }
            set
            {
                sVendorCode = value;
            }
        }

        public frmVendorMaster()
        {
            InitializeComponent();
        }
        DataTable dtApproveList = new DataTable();
        DataTable dtstateList = new DataTable();
        DataTable dtcityList = new DataTable();
        DataTable dtPaymentTerms = new DataTable();
        DataTable CurrencyCode = new DataTable();
        private void frmVendorMaster_Load(object sender, EventArgs e)
        {
            dtpCreatedDate.Format = DateTimePickerFormat.Custom;
            dtpCreatedDate.CustomFormat = "dd-MM-yyyy";
            timer1.Interval = 1000;
            timer1.Enabled = true;

            dtcityList = DAL.getstate(1, null, null).Tables[0];

            dtPaymentTerms = DAL.fnPaymentTermMasterList(null).Tables[0];


            CurrencyCode = DAL.Currency_Code(0).Tables[0];
            cmbcurrency.Items.Clear();

            if (CurrencyCode.Rows.Count > 0)
            {
                foreach (DataRow DR in CurrencyCode.Rows)
                {
                    if (!cmbcurrency.Items.Contains(DR[0].ToString()))
                        cmbcurrency.Items.Add(DR[0].ToString());
                }
            }
            cmbcurrency.SelectedIndex = 20;
            txtFxRate.Text = "1";

            foreach (DataRow dr in dtPaymentTerms.Rows)
            {
                if (!cmbPaymentTerms.Items.Contains(dr["PaymentTerms"].ToString()))
                {
                    cmbPaymentTerms.Items.Add(dr["PaymentTerms"].ToString());
                }
            }

            foreach (DataRow dr in dtcityList.Rows)
            {
                if (!txtDistict.Items.Contains(dr["CityName"].ToString()))
                {
                    txtDistict.Items.Add(dr["CityName"].ToString());
                }
            }
            if (login.GetUserDetails[23] == "Accounts")
            {
                cmbApproveVendor.Visible = true;
                lblProjecttype.Visible = true;
                dtApproveList = DAL.fnVedorNameList(1, null).Tables[0];

                foreach (DataRow dr in dtApproveList.Rows)
                {
                    if (!cmbApproveVendor.Items.Contains(dr["VendorName"].ToString()))
                    {
                        cmbApproveVendor.Items.Add(dr["VendorName"].ToString());
                    }
                }
            }
            else
            {
                cmbApproveVendor.Visible = false;
                lblProjecttype.Visible = false;
            }
            lblReturnedby.Text = login.GetUserDetails[2];
            if (fnGetVendorCode != null)
            {
                fnLoadVendorData(fnGetVendorCode);
            }
        }

        private void fnLoadVendorData(string sVendorCode)
        {
            dtVendorlist = DAL.fnVedorList(sVendorCode).Tables[0];//get Particular vendor details from vendor table
            if (dtVendorlist.Rows.Count > 0)
            {
                txtCreatedBy.Text = dtVendorlist.Rows[0]["CreatedBy"].ToString() + " / " + dtVendorlist.Rows[0]["CreatedDate"].ToString();
                txtCompanyName.Text = dtVendorlist.Rows[0]["VendorName"].ToString();
                txtContactPerson.Text = dtVendorlist.Rows[0]["ContactPerson"].ToString();
                txtAddress1.Text = dtVendorlist.Rows[0]["Address1"].ToString();
                txtAddress2.Text = dtVendorlist.Rows[0]["Address2"].ToString();
                txtCountry.Text = dtVendorlist.Rows[0]["Country"].ToString();
                txtDistict.Text = dtVendorlist.Rows[0]["District"].ToString();
                txtEmail.Text = dtVendorlist.Rows[0]["EmailAddress"].ToString();
                txtFaxNo.Text = dtVendorlist.Rows[0]["FaxNo"].ToString();
                txtMoblieNo.Text = dtVendorlist.Rows[0]["MobileNo"].ToString();
                txtPhoneNo.Text = dtVendorlist.Rows[0]["PhoneNo"].ToString();
                txtState.Text = dtVendorlist.Rows[0]["State"].ToString();
                txtstatecode.Text = dtVendorlist.Rows[0]["StateCode"].ToString();
                txtPINCode.Text = dtVendorlist.Rows[0]["PinCode"].ToString();
                txtShippedCountry.Text = dtVendorlist.Rows[0]["ShippedCountry"].ToString();
                txtShippedStateCode.Text = dtVendorlist.Rows[0]["ShippedStateCode"].ToString();
                txtShippedfromaddress.Text = dtVendorlist.Rows[0]["ShippedAddress"].ToString();
                txtgstcode.Text = dtVendorlist.Rows[0]["GSTCode"].ToString();
                txtShippedGstCode.Text = dtVendorlist.Rows[0]["ShippedGSTCode"].ToString();
                cmbMSMERegistered.SelectedItem = dtVendorlist.Rows[0]["MSMERegistered"].ToString();
                txtAccountNo.Text = dtVendorlist.Rows[0]["AccountNo"].ToString();
                txtBeneficiaryName.Text = dtVendorlist.Rows[0]["BeneficiaryName"].ToString();
                txtIFSCCOde.Text = dtVendorlist.Rows[0]["IFSCCode"].ToString();
                tXTBankBranch.Text = dtVendorlist.Rows[0]["BankBranch"].ToString();
                txtSwiftCode.Text = dtVendorlist.Rows[0]["SwiftCode"].ToString();
                txtcinno.Text = dtVendorlist.Rows[0]["CINNo"].ToString();
                txtPanno.Text = dtVendorlist.Rows[0]["PANNo"].ToString();
                cmbPaymentTerms.SelectedItem = dtVendorlist.Rows[0]["PaymentTerm"].ToString();
                if (dtVendorlist.Rows[0]["Status"].ToString() == "Active")
                    chkActive1.Checked = true;
                else if (dtVendorlist.Rows[0]["Status"].ToString() == "InActive")
                    chkActive1.Checked = false;
                btnAddVendor.Text = Global.sBUTTON_SAVE_TEXT_ISUPDATE;

                cmbcurrency.Text = dtVendorlist.Rows[0]["Currency"].ToString();
                txtFxRate.Text = dtVendorlist.Rows[0]["FX Rate"].ToString();
            }
        }

        private void txtPhoneNo_KeyUp(object sender, KeyEventArgs e)
        {
            //  GLobalClass.fnIsPhoneNumber(txtPhoneNo);
        }

        private void txtMoblieNo_KeyUp(object sender, KeyEventArgs e)
        {
            //    GLobalClass.fnIsPhoneNumber(txtMoblieNo);
        }

        private void txtFaxNo_KeyUp(object sender, KeyEventArgs e)
        {
            //  GLobalClass.fnIsPhoneNumber(txtFaxNo);
        }

        private void txtPINCode_KeyUp(object sender, KeyEventArgs e)
        {
            // GLobalClass.fnIsIntNumber(txtPINCode);
        }
        private string sActive;
        string sVendorCodeno;
        DataTable dtVendorCheck = new DataTable();
        DataTable dtVendorGSTCheck = new DataTable();
        private void btnAddVendor_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtCompanyName.Text != string.Empty && txtContactPerson.Text != string.Empty && txtgstcode.Text != string.Empty && txtAddress1.Text != string.Empty && cmbMSMERegistered.SelectedIndex >= 0 && txtAccountNo.Text != string.Empty && txtBeneficiaryName.Text != string.Empty && txtIFSCCOde.Text != string.Empty && tXTBankBranch.Text != string.Empty && txtSwiftCode.Text != string.Empty && !string.IsNullOrEmpty(txtcinno.Text) && txtcinno.Text.Length == 21 && cmbcurrency.SelectedIndex >= 0)//check all required fields are filled or not
                {
                    if (chkActive1.Checked)
                        sActive = "Active";
                    else
                        sActive = "InActive";

                    if (btnAddVendor.Text == Global.sBUTTON_SAVE_TEXT_ISSAVE)
                    {
                        dtVendorCheck = DAL.fnVedorCheck(0, txtCompanyName.Text).Tables[0];
                        dtVendorGSTCheck = DAL.fnVedorCheck(1, txtgstcode.Text).Tables[0];
                        if (dtVendorCheck.Rows.Count == 0 && dtVendorGSTCheck.Rows.Count == 0)
                        {

                            sVendorCodeno = DAL.fnVedorListAutoGenerate();

                            //iID;
                            sVendorCodeno = sVendorCodeno.Substring(01, 09);
                            int iID = Convert.ToInt32(sVendorCodeno);
                            iID++;
                            sVendorCode = "V" + iID;

                            GLobalClass.iSuccess = DAL.fnAddVendor(Global.uINSERT, sVendorCode, txtCompanyName.Text.Trim(), txtContactPerson.Text, txtAddress1.Text, txtAddress2.Text,
                                txtPhoneNo.Text, txtEmail.Text, txtFaxNo.Text, txtMoblieNo.Text, txtDistict.Text, txtState.Text, txtCountry.Text, txtPINCode.Text, txtstatecode.Text, sActive,
                                txtShippedCountry.Text, txtShippedStateCode.Text, txtShippedfromaddress.Text, txtgstcode.Text, txtShippedGstCode.Text, login.GetUserDetails[2],
                                dtpCreatedDate.Text, cmbMSMERegistered.Text, txtAccountNo.Text, txtBeneficiaryName.Text, txtIFSCCOde.Text, tXTBankBranch.Text,
                                txtSwiftCode.Text, txtcinno.Text, txtPanno.Text, cmbPaymentTerms.Text, cmbcurrency.Text, txtFxRate.Text);
                            if (GLobalClass.iSuccess > 0)
                            {
                                GLobalClass.iSuccess = DAL.fnAddERPLog(0, sVendorCode, login.GetUserDetails[2], dtpCreatedDate.Text, "Vendor Created", "Vendors");
                                MessageBox.Show("New Vendor " + txtCompanyName.Text + " Added Successfully", "Success", 0, MessageBoxIcon.Information);
                                ClearTextBoxes(this.Controls);
                            }
                        }
                        else
                        {
                            if (dtVendorCheck.Rows.Count > 0 )
                            {
                                MessageBox.Show("Same Vendor Name already exists", "Error", 0, MessageBoxIcon.Error);
                            }
                            else if (dtVendorGSTCheck.Rows.Count > 0)
                            {
                                MessageBox.Show("Same GST No already exists for other vendor", "Error", 0, MessageBoxIcon.Error);
                            }
                        }
                    }
                    else
                    {
                        GLobalClass.iSuccess = DAL.fnAddVendor(Global.uUPDATE, sVendorCode, txtCompanyName.Text.Trim(), txtContactPerson.Text, txtAddress1.Text, txtAddress2.Text,
                            txtPhoneNo.Text, txtEmail.Text, txtFaxNo.Text, txtMoblieNo.Text, txtDistict.Text, txtState.Text, txtCountry.Text, txtPINCode.Text, txtstatecode.Text, sActive,
                            txtShippedCountry.Text, txtShippedStateCode.Text, txtShippedfromaddress.Text, txtgstcode.Text, txtShippedGstCode.Text, "", "", cmbMSMERegistered.Text,
                            txtAccountNo.Text, txtBeneficiaryName.Text, txtIFSCCOde.Text, tXTBankBranch.Text, txtSwiftCode.Text, txtcinno.Text, txtPanno.Text, cmbPaymentTerms.Text, cmbcurrency.Text, txtFxRate.Text);


                        if (txtCompanyName.Text != string.Empty && txtContactPerson.Text != string.Empty && txtgstcode.Text != string.Empty && txtAddress1.Text != string.Empty && cmbMSMERegistered.SelectedIndex >= 0 && txtAccountNo.Text != string.Empty && txtBeneficiaryName.Text != string.Empty && txtIFSCCOde.Text != string.Empty && tXTBankBranch.Text != string.Empty && txtSwiftCode.Text != string.Empty && !string.IsNullOrEmpty(txtcinno.Text) && txtcinno.Text.Length == 21 && cmbcurrency.SelectedIndex >= 0)//check all required fields are filled or not

                        {
                            GLobalClass.iSuccess = DAL.fnAddVendor1(Global.uUPDATE, sVendorCode, txtCompanyName.Text.Trim(), txtContactPerson.Text, txtAddress1.Text, txtAddress2.Text,
                       txtPhoneNo.Text, txtEmail.Text, txtFaxNo.Text, txtMoblieNo.Text, txtDistict.Text, txtState.Text, txtCountry.Text, txtPINCode.Text, txtstatecode.Text, sActive,
                       txtShippedCountry.Text, txtShippedStateCode.Text, txtShippedfromaddress.Text, txtgstcode.Text, txtShippedGstCode.Text, "", "", cmbMSMERegistered.Text,
                       txtAccountNo.Text, txtBeneficiaryName.Text, txtIFSCCOde.Text, tXTBankBranch.Text, txtSwiftCode.Text, txtcinno.Text, txtPanno.Text, cmbPaymentTerms.Text, cmbcurrency.Text, txtFxRate.Text);

                        }
                        if (login.GetUserDetails[23] == "Accounts" && login.GetUserDetails[2].ToLower() == "theertha rao")
                        {
                            GLobalClass.iSuccess = DAL.fnAddVendor(6, sVendorCode, login.GetUserDetails[2], dtpCreatedDate.Text, txtAddress1.Text, txtAddress2.Text,
                              txtPhoneNo.Text, txtEmail.Text, txtFaxNo.Text, txtMoblieNo.Text, txtDistict.Text, txtState.Text, txtCountry.Text, txtPINCode.Text, txtstatecode.Text,
                              sActive, txtShippedCountry.Text, txtShippedStateCode.Text, txtShippedfromaddress.Text, txtgstcode.Text, txtShippedGstCode.Text, "", "",
                              cmbMSMERegistered.Text, txtAccountNo.Text, txtBeneficiaryName.Text, txtIFSCCOde.Text, tXTBankBranch.Text, txtSwiftCode.Text, txtcinno.Text,
                              txtPanno.Text, cmbPaymentTerms.Text, cmbcurrency.Text, txtFxRate.Text);
                        }

                        if (GLobalClass.iSuccess > 0)
                        {
                            if (login.GetUserDetails[23] == "Accounts")
                            {
                                GLobalClass.iSuccess = DAL.fnAddERPLog(0, sVendorCode, login.GetUserDetails[2], dtpCreatedDate.Text, "Vendor Approved", "Vendors");
                                MessageBox.Show(" Vendor " + txtCompanyName.Text + " Approved Successfully", "Success", 0, MessageBoxIcon.Information);
                            }
                            else
                            {
                                GLobalClass.iSuccess = DAL.fnAddERPLog(0, sVendorCode, login.GetUserDetails[2], dtpCreatedDate.Text, "Vendor Updated", "Vendors");
                                MessageBox.Show(" Vendor " + txtCompanyName.Text + " Updated Successfully", "Success", 0, MessageBoxIcon.Information);
                            }
                            //cmbApproveVendor.SelectedIndex = -1;
                            ClearTextBoxes(this.Controls);
                            btnAddVendor.Text = Global.sBUTTON_SAVE_TEXT_ISSAVE;
                            txtCompanyName.Enabled = true;
                            fnGetVendorCode = null;
                            if (cmbApproveVendor.SelectedIndex >= 0)
                            {
                                cmbApproveVendor.Items.RemoveAt(cmbApproveVendor.SelectedIndex);
                            }
                        }
                    }
                }
                else
                {

                    GLobalClass.iSuccess = DAL.fnAddVendor1(Global.uUPDATE, sVendorCode, txtCompanyName.Text.Trim(), txtContactPerson.Text, txtAddress1.Text, txtAddress2.Text,
                        txtPhoneNo.Text, txtEmail.Text, txtFaxNo.Text, txtMoblieNo.Text, txtDistict.Text, txtState.Text, txtCountry.Text, txtPINCode.Text, txtstatecode.Text, sActive,
                        txtShippedCountry.Text, txtShippedStateCode.Text, txtShippedfromaddress.Text, txtgstcode.Text, txtShippedGstCode.Text, "", "", cmbMSMERegistered.Text,
                        txtAccountNo.Text, txtBeneficiaryName.Text, txtIFSCCOde.Text, tXTBankBranch.Text, txtSwiftCode.Text, txtcinno.Text, txtPanno.Text, cmbPaymentTerms.Text, cmbcurrency.Text, txtFxRate.Text);


                    if (txtCompanyName.Text == string.Empty)
                    {
                        txtCompanyName.Focus();
                        MessageBox.Show("Enter Vendor Name", "Error", 0, MessageBoxIcon.Error);
                    }

                    else if (txtContactPerson.Text == string.Empty)
                    {
                        txtContactPerson.Focus();
                        MessageBox.Show("Enter Contact person", "Error", 0, MessageBoxIcon.Error);
                    }
                    else if (txtgstcode.Text == string.Empty)
                    {
                        MessageBox.Show("Enter GST code", "Error", 0, MessageBoxIcon.Error);
                        txtgstcode.Focus();
                    }
                    else if (txtAddress1.Text == string.Empty)
                    {
                        MessageBox.Show("Enter Address", "Error", 0, MessageBoxIcon.Error);
                        txtAddress1.Focus();
                    }
                    else if (cmbMSMERegistered.SelectedIndex < 0)
                    {
                        MessageBox.Show("Select Vendor MSME Register details", "Error", 0, MessageBoxIcon.Error);
                        cmbMSMERegistered.DroppedDown = true;
                    }
                    else if (txtAccountNo.Text == string.Empty)
                    {
                        MessageBox.Show("Enter Account No", "Error", 0, MessageBoxIcon.Error);
                        txtAccountNo.Focus();
                    }
                    else if (txtBeneficiaryName.Text == string.Empty)
                    {
                        MessageBox.Show("Enter Beneficiary Name", "Error", 0, MessageBoxIcon.Error);
                        txtBeneficiaryName.Focus();
                    }
                    else if (txtIFSCCOde.Text == string.Empty)
                    {
                        MessageBox.Show("Enter IFSC Code", "Error", 0, MessageBoxIcon.Error);
                        txtIFSCCOde.Focus();
                    }
                    else if (tXTBankBranch.Text == string.Empty)
                    {
                        MessageBox.Show("Enter Bank Branch", "Error", 0, MessageBoxIcon.Error);
                        tXTBankBranch.Focus();
                    }
                    else if (txtSwiftCode.Text == string.Empty)
                    {
                        MessageBox.Show("Enter Swift Code", "Error", 0, MessageBoxIcon.Error);
                        txtSwiftCode.Focus();
                    }
                    else if (string.IsNullOrEmpty(txtcinno.Text))
                    {
                        MessageBox.Show("Enter CIN Number", "Error", 0, MessageBoxIcon.Error);
                        txtcinno.Focus();
                    }
                    else if (txtcinno.Text.Length != 21)
                    {
                        MessageBox.Show("The Length of CIN Number should be 21", "Error", 0, MessageBoxIcon.Error);
                        txtcinno.Focus();
                    }
                    else if (cmbcurrency.SelectedIndex < 0)
                    {
                        MessageBox.Show("Select the currency", "Error", 0, MessageBoxIcon.Error);
                        cmbcurrency.DroppedDown = true;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("frmPartmaster_btnSave1_Click  " + ex.Message);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            fnGetVendorCode = null;
            this.Hide();
            frm.Show();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtCompanyName.Text != string.Empty || txtContactPerson.Text != string.Empty || txtMoblieNo.Text != string.Empty || txtPhoneNo.Text != string.Empty)
            {
                if (GLobalClass.fnClearallMessage() == DialogResult.Yes)    //calling clearall function
                {
                    Vendor_Master.frmVendorSearch VendorSearch = new Vendor_Master.frmVendorSearch();
                    this.Hide();
                    VendorSearch.Show();
                }
            }
            else
            {
                Vendor_Master.frmVendorSearch VendorSearch = new Vendor_Master.frmVendorSearch();
                this.Hide();
                VendorSearch.Show();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lbltime.Text = DateTime.Now.ToString("hh:mm:ss tt");
        }

        private void btnClearAll1_Click(object sender, EventArgs e)
        {
            btnAddVendor.Text = Global.sBUTTON_SAVE_TEXT_ISSAVE;
            ClearTextBoxes(this.Controls);
        }

        private void ClearTextBoxes(Control.ControlCollection ClearAll)
        {
            foreach (Control ctrl in ClearAll)
            {
                TextBox tb = ctrl as TextBox;
                if (tb != null)
                    tb.Text = string.Empty;
                else
                    ClearTextBoxes(ctrl.Controls);
            }
        }

        private void frmVendorMaster_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnGetVendorCode = null;
            this.Hide();
            frm.Show();
        }

        private void cmbApproveVendor_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbApproveVendor.SelectedIndex >= 0)
            {
                DataView dvVendor = new DataView(dtApproveList);
                dvVendor.RowFilter = "VendorName Like'" + cmbApproveVendor.Text + "'";
                DataTable dtrow = dvVendor.ToTable();
                fnGetVendorCode = dtrow.Rows[0]["VendorCode"].ToString();
                if (dtrow.Rows.Count > 0)
                {
                    fnLoadVendorData(dtrow.Rows[0]["VendorCode"].ToString());
                }
                lblVenCode.Visible = true;
                txtVenCode.Visible = true;
                txtVenCode.Text = dtrow.Rows[0]["VendorCode"].ToString();

                btnDelete1.Enabled = true;

                //if (cmbMSMERegistered.Text == "Yes")
                //{
                Regex illegalInFileName = new Regex(@"[\\/:*?""<>|]");
                string sProjName1 = txtCompanyName.Text;
                sProjName1 = illegalInFileName.Replace(sProjName1, " ");

                string newPath1 = @"\\inbas01\Data\ERP\Pub\ERP_Project_Document\VendorMSME\\" + sProjName1;

                llbProjectDocuments.Text = newPath1;
                llbProjectDocuments.Visible = true;
                //}
                //else
                //{
                //    llbProjectDocuments.Visible = false;
                //}
            }
        }

        private void cmbMSMERegistered_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtCompanyName.Text) && string.IsNullOrEmpty(sVendorCode))
            {
                openFileDialog1.InitialDirectory = @"c:\";
                openFileDialog1.Title = "Select File";
                openFileDialog1.ShowDialog();
            }
            else
            {
                if (string.IsNullOrEmpty(txtCompanyName.Text))
                {
                    txtCompanyName.Focus();
                    MessageBox.Show("Enter Vendor Name", "Error", 0, MessageBoxIcon.Error);
                }
            }
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

            Regex illegalInFileName = new Regex(@"[\\/:*?""<>|]");
            string sProjName = txtCompanyName.Text;
            sProjName = illegalInFileName.Replace(sProjName, " ");
           // \\inbas01\Data\ERP\Pub
            string newPath = @"\\inbas01\Data\ERP\Pub\ERP_Project_Document\VendorMSME\\" + sProjName;

            if (!Directory.Exists(newPath))
            {
                System.IO.Directory.CreateDirectory(newPath);
            }
            sProjName = sProjName + "\\";
            string sourcePath = openFileDialog1.FileName;

            string targetPath = @"\\inbas01\Data\ERP\Pub\ERP_Project_Document\VendorMSME\\" + sProjName;


            if (!Directory.Exists(targetPath))
            {
                Directory.CreateDirectory(targetPath);
            }
            File.Copy(sourcePath, targetPath + Path.GetFileName(sourcePath), true);
        }

        private void llbProjectDocuments_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (Directory.Exists(llbProjectDocuments.Text))
            {
                System.Diagnostics.Process.Start(llbProjectDocuments.Text);
            }
        }


        private void txtDistict_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtstateList = DAL.getstate(2, txtDistict.Text, null).Tables[0];
            if (dtstateList.Rows.Count > 0)
            {
                txtState.Text = dtstateList.Rows[0]["StateName"].ToString();
                txtstatecode.Text = dtstateList.Rows[0]["Id"].ToString();
                txtCountry.Text = dtstateList.Rows[0]["CountryName"].ToString();
            }
        }
        DataTable dtcurrcy = new DataTable();
        private void cmbcurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            /*
            switch (cmbcurrency.SelectedIndex)
            {
                case 0:
                    txtFxRate.Text = "1";
                    break;
                case 1:
                    dtcurrcy = DAL.DTPegRate(cmbcurrency.SelectedItem.ToString()).Tables[0];
                    if (dtcurrcy.Rows.Count > 0)
                    {
                        txtFxRate.Text = dtcurrcy.Rows[0][2].ToString();
                    }
                    else
                    {
                        txtFxRate.Text = ".5";
                    }
                    break;

                case 2:
                    dtcurrcy = DAL.DTPegRate(cmbcurrency.SelectedItem.ToString()).Tables[0];
                    if (dtcurrcy.Rows.Count > 0)
                    {
                        txtFxRate.Text = dtcurrcy.Rows[0][2].ToString();
                    }
                    else
                    {
                        txtFxRate.Text = ".5";
                    }
                    break;
            }
            */
            dtcurrcy = DAL.DTPegRate(cmbcurrency.SelectedItem.ToString()).Tables[0];
            if (dtcurrcy.Rows.Count > 0)
            {
                txtFxRate.Text = dtcurrcy.Rows[0][6].ToString();
                //curratetext.Text = dtcurrcy.Rows[0][2].ToString();
            }
        }

        
        DataTable dtVendorTransactionCheck = new DataTable();

        private void btnDelete1_Click(object sender, EventArgs e)
        {

            dtVendorTransactionCheck = DAL.fnVedorCheck(2, sVendorCode).Tables[0];

            if (dtVendorTransactionCheck.Rows.Count == 0)
            {

                DialogResult DR = MessageBox.Show("Do you want to delete the vendor from ERP ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DR == DialogResult.Yes)
                {
                    GLobalClass.iSuccess = DAL.fnAddVendor(Global.uDELETE, sVendorCode, txtCompanyName.Text.Trim(), txtContactPerson.Text, txtAddress1.Text, txtAddress2.Text,
                            txtPhoneNo.Text, txtEmail.Text, txtFaxNo.Text, txtMoblieNo.Text, txtDistict.Text, txtState.Text, txtCountry.Text, txtPINCode.Text, txtstatecode.Text, sActive,
                            txtShippedCountry.Text, txtShippedStateCode.Text, txtShippedfromaddress.Text, txtgstcode.Text, txtShippedGstCode.Text, login.GetUserDetails[2],
                            dtpCreatedDate.Text, cmbMSMERegistered.Text, txtAccountNo.Text, txtBeneficiaryName.Text, txtIFSCCOde.Text, tXTBankBranch.Text,
                            txtSwiftCode.Text, txtcinno.Text, txtPanno.Text, cmbPaymentTerms.Text, cmbcurrency.Text, txtFxRate.Text);

                    MessageBox.Show("Vendor " + txtCompanyName.Text + " deleted successfully.", "Success", 0, MessageBoxIcon.Information);

                    ClearTextBoxes(this.Controls);
                    btnAddVendor.Text = Global.sBUTTON_SAVE_TEXT_ISSAVE;
                    txtCompanyName.Enabled = true;
                    fnGetVendorCode = null;
                    if (cmbApproveVendor.SelectedIndex >= 0)
                    {
                        cmbApproveVendor.Items.RemoveAt(cmbApproveVendor.SelectedIndex);
                    }
                    btnDelete1.Enabled = false;
                }
            }
            else
            {
                MessageBox.Show("Selected Vendor has transactions. Vendor cannot be deleted.", "Error", 0, MessageBoxIcon.Error);
            }
        }
    }
}
