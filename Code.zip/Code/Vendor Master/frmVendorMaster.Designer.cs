﻿namespace Erp_Project_With_Buttons.Vendor_Master
{
    partial class frmVendorMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmVendorMaster));
            this.pnBIM = new System.Windows.Forms.Panel();
            this.lbltime = new System.Windows.Forms.Label();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.lblReturnedby = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.cmbApproveVendor = new System.Windows.Forms.ComboBox();
            this.lblProjecttype = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtCompanyName = new System.Windows.Forms.TextBox();
            this.txtAddress2 = new System.Windows.Forms.TextBox();
            this.txtAddress1 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.txtCountry = new System.Windows.Forms.TextBox();
            this.txtPINCode = new System.Windows.Forms.TextBox();
            this.chkActive1 = new System.Windows.Forms.CheckBox();
            this.lblPANNo = new System.Windows.Forms.Label();
            this.txtShippedCountry = new System.Windows.Forms.TextBox();
            this.lbltServiceTax = new System.Windows.Forms.Label();
            this.txtShippedfromaddress = new System.Windows.Forms.TextBox();
            this.lblExciseNo = new System.Windows.Forms.Label();
            this.txtShippedStateCode = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.llQuit = new System.Windows.Forms.LinkLabel();
            this.btnDelete1 = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnIMExit = new System.Windows.Forms.Button();
            this.btnAddVendor = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnClearAll1 = new System.Windows.Forms.Button();
            this.dtpCreatedDate = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.txtgstcode = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtShippedGstCode = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbMSMERegistered = new System.Windows.Forms.ComboBox();
            this.llbProjectDocuments = new System.Windows.Forms.LinkLabel();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCreatedBy = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtFxRate = new System.Windows.Forms.TextBox();
            this.cmbcurrency = new System.Windows.Forms.ComboBox();
            this.lblcurrency = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.cmbPaymentTerms = new System.Windows.Forms.ComboBox();
            this.txtPanno = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.txtcinno = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtState = new System.Windows.Forms.TextBox();
            this.txtstatecode = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.txtDistict = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtContactPerson = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtFaxNo = new System.Windows.Forms.TextBox();
            this.txtMoblieNo = new System.Windows.Forms.TextBox();
            this.txtPhoneNo = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtSwiftCode = new System.Windows.Forms.TextBox();
            this.tXTBankBranch = new System.Windows.Forms.TextBox();
            this.txtIFSCCOde = new System.Windows.Forms.TextBox();
            this.txtBeneficiaryName = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtAccountNo = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtVenCode = new System.Windows.Forms.TextBox();
            this.lblVenCode = new System.Windows.Forms.Label();
            this.pnBIM.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnBIM
            // 
            this.pnBIM.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnBIM.Controls.Add(this.lbltime);
            this.pnBIM.Controls.Add(this.lblWelcome);
            this.pnBIM.Controls.Add(this.lblReturnedby);
            this.pnBIM.Controls.Add(this.lblName);
            this.pnBIM.Location = new System.Drawing.Point(8, 5);
            this.pnBIM.Name = "pnBIM";
            this.pnBIM.Size = new System.Drawing.Size(1293, 61);
            this.pnBIM.TabIndex = 11;
            // 
            // lbltime
            // 
            this.lbltime.AutoSize = true;
            this.lbltime.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltime.ForeColor = System.Drawing.Color.Black;
            this.lbltime.Location = new System.Drawing.Point(1146, 11);
            this.lbltime.Name = "lbltime";
            this.lbltime.Size = new System.Drawing.Size(0, 23);
            this.lbltime.TabIndex = 26;
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.ForeColor = System.Drawing.Color.Black;
            this.lblWelcome.Location = new System.Drawing.Point(7, 9);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(98, 24);
            this.lblWelcome.TabIndex = 22;
            this.lblWelcome.Text = "Welcome :";
            // 
            // lblReturnedby
            // 
            this.lblReturnedby.AutoSize = true;
            this.lblReturnedby.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReturnedby.ForeColor = System.Drawing.Color.Black;
            this.lblReturnedby.Location = new System.Drawing.Point(103, 9);
            this.lblReturnedby.Name = "lblReturnedby";
            this.lblReturnedby.Size = new System.Drawing.Size(0, 24);
            this.lblReturnedby.TabIndex = 21;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.Indigo;
            this.lblName.Location = new System.Drawing.Point(493, 21);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(294, 29);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "BiSS Inventory Management";
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Add-icon.png");
            this.imageList1.Images.SetKeyName(1, "table-add-icon.png");
            this.imageList1.Images.SetKeyName(2, "order-history-icon.png");
            this.imageList1.Images.SetKeyName(3, "Package-Add-icon.png");
            this.imageList1.Images.SetKeyName(4, "Excel-icon.png");
            this.imageList1.Images.SetKeyName(5, "Actions-address-book-new-icon.png");
            this.imageList1.Images.SetKeyName(6, "invoice-icon.png");
            this.imageList1.Images.SetKeyName(7, "Apps-kspread-icon.png");
            this.imageList1.Images.SetKeyName(8, "Apps-klipper-icon.png");
            this.imageList1.Images.SetKeyName(9, "Upline-icon.png");
            this.imageList1.Images.SetKeyName(10, "reports-icon.png");
            this.imageList1.Images.SetKeyName(11, "Mimetypes-application-vnd-sun-xml-calc-template-icon.png");
            this.imageList1.Images.SetKeyName(12, "catalog-icon.png");
            this.imageList1.Images.SetKeyName(13, "Add-icon.png");
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // cmbApproveVendor
            // 
            this.cmbApproveVendor.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbApproveVendor.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbApproveVendor.DropDownHeight = 90;
            this.cmbApproveVendor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbApproveVendor.DropDownWidth = 400;
            this.cmbApproveVendor.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbApproveVendor.FormattingEnabled = true;
            this.cmbApproveVendor.IntegralHeight = false;
            this.cmbApproveVendor.Location = new System.Drawing.Point(203, 72);
            this.cmbApproveVendor.Name = "cmbApproveVendor";
            this.cmbApproveVendor.Size = new System.Drawing.Size(453, 26);
            this.cmbApproveVendor.TabIndex = 78;
            this.cmbApproveVendor.SelectedIndexChanged += new System.EventHandler(this.cmbApproveVendor_SelectedIndexChanged);
            // 
            // lblProjecttype
            // 
            this.lblProjecttype.AutoSize = true;
            this.lblProjecttype.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjecttype.ForeColor = System.Drawing.Color.Black;
            this.lblProjecttype.Location = new System.Drawing.Point(73, 75);
            this.lblProjecttype.Name = "lblProjecttype";
            this.lblProjecttype.Size = new System.Drawing.Size(129, 19);
            this.lblProjecttype.TabIndex = 79;
            this.lblProjecttype.Text = "Approve Vendor :";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(35, 12);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(69, 38);
            this.label10.TabIndex = 79;
            this.label10.Text = "Vendor \r\n Name *:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(25, 123);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(80, 19);
            this.label12.TabIndex = 81;
            this.label12.Text = "Address-2:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(25, 75);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(80, 19);
            this.label13.TabIndex = 82;
            this.label13.Text = "Address-1:";
            // 
            // txtCompanyName
            // 
            this.txtCompanyName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCompanyName.Location = new System.Drawing.Point(112, 7);
            this.txtCompanyName.Multiline = true;
            this.txtCompanyName.Name = "txtCompanyName";
            this.txtCompanyName.Size = new System.Drawing.Size(327, 50);
            this.txtCompanyName.TabIndex = 87;
            // 
            // txtAddress2
            // 
            this.txtAddress2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress2.Location = new System.Drawing.Point(113, 113);
            this.txtAddress2.Name = "txtAddress2";
            this.txtAddress2.Size = new System.Drawing.Size(327, 26);
            this.txtAddress2.TabIndex = 92;
            // 
            // txtAddress1
            // 
            this.txtAddress1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress1.Location = new System.Drawing.Point(113, 71);
            this.txtAddress1.Name = "txtAddress1";
            this.txtAddress1.Size = new System.Drawing.Size(327, 26);
            this.txtAddress1.TabIndex = 93;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(28, 248);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(75, 19);
            this.label20.TabIndex = 98;
            this.label20.Text = "PIN Code:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(35, 361);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(68, 19);
            this.label19.TabIndex = 99;
            this.label19.Text = "Country:";
            // 
            // txtCountry
            // 
            this.txtCountry.Enabled = false;
            this.txtCountry.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCountry.Location = new System.Drawing.Point(112, 359);
            this.txtCountry.Name = "txtCountry";
            this.txtCountry.Size = new System.Drawing.Size(329, 26);
            this.txtCountry.TabIndex = 101;
            // 
            // txtPINCode
            // 
            this.txtPINCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPINCode.Location = new System.Drawing.Point(113, 241);
            this.txtPINCode.Name = "txtPINCode";
            this.txtPINCode.Size = new System.Drawing.Size(327, 26);
            this.txtPINCode.TabIndex = 102;
            this.txtPINCode.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtPINCode_KeyUp);
            // 
            // chkActive1
            // 
            this.chkActive1.AutoSize = true;
            this.chkActive1.Checked = true;
            this.chkActive1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkActive1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkActive1.ForeColor = System.Drawing.Color.Black;
            this.chkActive1.Location = new System.Drawing.Point(1084, 42);
            this.chkActive1.Name = "chkActive1";
            this.chkActive1.Size = new System.Drawing.Size(66, 22);
            this.chkActive1.TabIndex = 105;
            this.chkActive1.Text = "Active";
            this.chkActive1.UseVisualStyleBackColor = true;
            // 
            // lblPANNo
            // 
            this.lblPANNo.AutoSize = true;
            this.lblPANNo.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPANNo.ForeColor = System.Drawing.Color.Black;
            this.lblPANNo.Location = new System.Drawing.Point(474, 334);
            this.lblPANNo.Name = "lblPANNo";
            this.lblPANNo.Size = new System.Drawing.Size(128, 19);
            this.lblPANNo.TabIndex = 108;
            this.lblPANNo.Text = "Shipped Country:";
            // 
            // txtShippedCountry
            // 
            this.txtShippedCountry.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtShippedCountry.Location = new System.Drawing.Point(611, 331);
            this.txtShippedCountry.Name = "txtShippedCountry";
            this.txtShippedCountry.Size = new System.Drawing.Size(273, 26);
            this.txtShippedCountry.TabIndex = 109;
            // 
            // lbltServiceTax
            // 
            this.lbltServiceTax.AutoSize = true;
            this.lbltServiceTax.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltServiceTax.ForeColor = System.Drawing.Color.Black;
            this.lbltServiceTax.Location = new System.Drawing.Point(499, 232);
            this.lbltServiceTax.Name = "lbltServiceTax";
            this.lbltServiceTax.Size = new System.Drawing.Size(103, 38);
            this.lbltServiceTax.TabIndex = 110;
            this.lbltServiceTax.Text = "Shipped from\r\n       Address*:";
            // 
            // txtShippedfromaddress
            // 
            this.txtShippedfromaddress.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtShippedfromaddress.Location = new System.Drawing.Point(608, 227);
            this.txtShippedfromaddress.Multiline = true;
            this.txtShippedfromaddress.Name = "txtShippedfromaddress";
            this.txtShippedfromaddress.Size = new System.Drawing.Size(273, 55);
            this.txtShippedfromaddress.TabIndex = 111;
            // 
            // lblExciseNo
            // 
            this.lblExciseNo.AutoSize = true;
            this.lblExciseNo.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExciseNo.ForeColor = System.Drawing.Color.Black;
            this.lblExciseNo.Location = new System.Drawing.Point(455, 372);
            this.lblExciseNo.Name = "lblExciseNo";
            this.lblExciseNo.Size = new System.Drawing.Size(150, 19);
            this.lblExciseNo.TabIndex = 106;
            this.lblExciseNo.Text = "Shiiped State Code*:";
            // 
            // txtShippedStateCode
            // 
            this.txtShippedStateCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtShippedStateCode.Location = new System.Drawing.Point(611, 370);
            this.txtShippedStateCode.Name = "txtShippedStateCode";
            this.txtShippedStateCode.Size = new System.Drawing.Size(273, 26);
            this.txtShippedStateCode.TabIndex = 107;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.llQuit);
            this.groupBox2.Controls.Add(this.btnDelete1);
            this.groupBox2.Controls.Add(this.btnExit);
            this.groupBox2.Controls.Add(this.btnIMExit);
            this.groupBox2.Controls.Add(this.btnAddVendor);
            this.groupBox2.Controls.Add(this.btnSearch);
            this.groupBox2.Controls.Add(this.btnClearAll1);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox2.Location = new System.Drawing.Point(46, 470);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1201, 66);
            this.groupBox2.TabIndex = 112;
            this.groupBox2.TabStop = false;
            // 
            // llQuit
            // 
            this.llQuit.AutoSize = true;
            this.llQuit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llQuit.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.llQuit.LinkColor = System.Drawing.Color.Red;
            this.llQuit.Location = new System.Drawing.Point(92, 25);
            this.llQuit.Name = "llQuit";
            this.llQuit.Size = new System.Drawing.Size(45, 23);
            this.llQuit.TabIndex = 76;
            this.llQuit.TabStop = true;
            this.llQuit.Text = "Quit";
            // 
            // btnDelete1
            // 
            this.btnDelete1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnDelete1.Enabled = false;
            this.btnDelete1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnDelete1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete1.Location = new System.Drawing.Point(825, 19);
            this.btnDelete1.Name = "btnDelete1";
            this.btnDelete1.Size = new System.Drawing.Size(98, 41);
            this.btnDelete1.TabIndex = 11;
            this.btnDelete1.Text = "Delete";
            this.btnDelete1.UseVisualStyleBackColor = false;
            this.btnDelete1.Click += new System.EventHandler(this.btnDelete1_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(980, 19);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(98, 41);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnIMExit
            // 
            this.btnIMExit.FlatAppearance.BorderSize = 0;
            this.btnIMExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnIMExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIMExit.Image = global::Erp_Project_With_Buttons.Properties.Resources.glossy_3d_blue_delete_icon__1_;
            this.btnIMExit.Location = new System.Drawing.Point(15, 14);
            this.btnIMExit.Name = "btnIMExit";
            this.btnIMExit.Size = new System.Drawing.Size(53, 48);
            this.btnIMExit.TabIndex = 75;
            this.btnIMExit.UseVisualStyleBackColor = true;
            // 
            // btnAddVendor
            // 
            this.btnAddVendor.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnAddVendor.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAddVendor.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddVendor.Location = new System.Drawing.Point(318, 19);
            this.btnAddVendor.Name = "btnAddVendor";
            this.btnAddVendor.Size = new System.Drawing.Size(98, 41);
            this.btnAddVendor.TabIndex = 9;
            this.btnAddVendor.Text = "Save";
            this.btnAddVendor.UseVisualStyleBackColor = false;
            this.btnAddVendor.Click += new System.EventHandler(this.btnAddVendor_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSearch.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.Location = new System.Drawing.Point(487, 19);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(98, 41);
            this.btnSearch.TabIndex = 8;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnClearAll1
            // 
            this.btnClearAll1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnClearAll1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnClearAll1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearAll1.Location = new System.Drawing.Point(649, 19);
            this.btnClearAll1.Name = "btnClearAll1";
            this.btnClearAll1.Size = new System.Drawing.Size(98, 41);
            this.btnClearAll1.TabIndex = 7;
            this.btnClearAll1.Text = "Clear All";
            this.btnClearAll1.UseVisualStyleBackColor = false;
            this.btnClearAll1.Click += new System.EventHandler(this.btnClearAll1_Click);
            // 
            // dtpCreatedDate
            // 
            this.dtpCreatedDate.CustomFormat = "";
            this.dtpCreatedDate.Enabled = false;
            this.dtpCreatedDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpCreatedDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpCreatedDate.Location = new System.Drawing.Point(1072, 7);
            this.dtpCreatedDate.Name = "dtpCreatedDate";
            this.dtpCreatedDate.Size = new System.Drawing.Size(91, 26);
            this.dtpCreatedDate.TabIndex = 164;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(19, 397);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 19);
            this.label1.TabIndex = 165;
            this.label1.Text = "GST Code*:";
            // 
            // txtgstcode
            // 
            this.txtgstcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtgstcode.Location = new System.Drawing.Point(112, 395);
            this.txtgstcode.MaxLength = 15;
            this.txtgstcode.Name = "txtgstcode";
            this.txtgstcode.Size = new System.Drawing.Size(329, 26);
            this.txtgstcode.TabIndex = 166;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(457, 298);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(145, 19);
            this.label3.TabIndex = 168;
            this.label3.Text = "Shipped GST Code*:";
            // 
            // txtShippedGstCode
            // 
            this.txtShippedGstCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtShippedGstCode.Location = new System.Drawing.Point(608, 293);
            this.txtShippedGstCode.MaxLength = 15;
            this.txtShippedGstCode.Name = "txtShippedGstCode";
            this.txtShippedGstCode.Size = new System.Drawing.Size(273, 26);
            this.txtShippedGstCode.TabIndex = 169;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(471, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 19);
            this.label2.TabIndex = 171;
            this.label2.Text = "MSME Registered :";
            // 
            // cmbMSMERegistered
            // 
            this.cmbMSMERegistered.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbMSMERegistered.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbMSMERegistered.DropDownHeight = 90;
            this.cmbMSMERegistered.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMSMERegistered.DropDownWidth = 300;
            this.cmbMSMERegistered.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbMSMERegistered.FormattingEnabled = true;
            this.cmbMSMERegistered.IntegralHeight = false;
            this.cmbMSMERegistered.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbMSMERegistered.Location = new System.Drawing.Point(608, 12);
            this.cmbMSMERegistered.Name = "cmbMSMERegistered";
            this.cmbMSMERegistered.Size = new System.Drawing.Size(273, 26);
            this.cmbMSMERegistered.TabIndex = 170;
            this.cmbMSMERegistered.SelectedIndexChanged += new System.EventHandler(this.cmbMSMERegistered_SelectedIndexChanged);
            // 
            // llbProjectDocuments
            // 
            this.llbProjectDocuments.AutoSize = true;
            this.llbProjectDocuments.Location = new System.Drawing.Point(622, 46);
            this.llbProjectDocuments.Name = "llbProjectDocuments";
            this.llbProjectDocuments.Size = new System.Drawing.Size(0, 18);
            this.llbProjectDocuments.TabIndex = 172;
            this.llbProjectDocuments.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbProjectDocuments_LinkClicked);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(448, 412);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(157, 19);
            this.label4.TabIndex = 173;
            this.label4.Text = "Created By and Date :";
            // 
            // txtCreatedBy
            // 
            this.txtCreatedBy.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCreatedBy.Location = new System.Drawing.Point(611, 408);
            this.txtCreatedBy.Name = "txtCreatedBy";
            this.txtCreatedBy.ReadOnly = true;
            this.txtCreatedBy.Size = new System.Drawing.Size(273, 26);
            this.txtCreatedBy.TabIndex = 174;
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.txtFxRate);
            this.panel1.Controls.Add(this.cmbcurrency);
            this.panel1.Controls.Add(this.lblcurrency);
            this.panel1.Controls.Add(this.label25);
            this.panel1.Controls.Add(this.cmbPaymentTerms);
            this.panel1.Controls.Add(this.txtPanno);
            this.panel1.Controls.Add(this.label24);
            this.panel1.Controls.Add(this.txtcinno);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.txtState);
            this.panel1.Controls.Add(this.txtstatecode);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.txtDistict);
            this.panel1.Controls.Add(this.label22);
            this.panel1.Controls.Add(this.txtContactPerson);
            this.panel1.Controls.Add(this.txtEmail);
            this.panel1.Controls.Add(this.txtFaxNo);
            this.panel1.Controls.Add(this.txtMoblieNo);
            this.panel1.Controls.Add(this.txtPhoneNo);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.txtSwiftCode);
            this.panel1.Controls.Add(this.tXTBankBranch);
            this.panel1.Controls.Add(this.txtIFSCCOde);
            this.panel1.Controls.Add(this.txtBeneficiaryName);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.txtAccountNo);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.txtCreatedBy);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.llbProjectDocuments);
            this.panel1.Controls.Add(this.cmbMSMERegistered);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtShippedGstCode);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txtgstcode);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.dtpCreatedDate);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.txtShippedStateCode);
            this.panel1.Controls.Add(this.lblExciseNo);
            this.panel1.Controls.Add(this.txtShippedfromaddress);
            this.panel1.Controls.Add(this.lbltServiceTax);
            this.panel1.Controls.Add(this.txtShippedCountry);
            this.panel1.Controls.Add(this.lblPANNo);
            this.panel1.Controls.Add(this.chkActive1);
            this.panel1.Controls.Add(this.txtPINCode);
            this.panel1.Controls.Add(this.txtCountry);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.txtAddress1);
            this.panel1.Controls.Add(this.txtAddress2);
            this.panel1.Controls.Add(this.txtCompanyName);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(8, 104);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1293, 555);
            this.panel1.TabIndex = 13;
            // 
            // txtFxRate
            // 
            this.txtFxRate.Enabled = false;
            this.txtFxRate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFxRate.Location = new System.Drawing.Point(1105, 410);
            this.txtFxRate.Name = "txtFxRate";
            this.txtFxRate.Size = new System.Drawing.Size(58, 26);
            this.txtFxRate.TabIndex = 174;
            // 
            // cmbcurrency
            // 
            this.cmbcurrency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbcurrency.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbcurrency.FormattingEnabled = true;
            this.cmbcurrency.ItemHeight = 18;
            this.cmbcurrency.Location = new System.Drawing.Point(1002, 410);
            this.cmbcurrency.Name = "cmbcurrency";
            this.cmbcurrency.Size = new System.Drawing.Size(88, 26);
            this.cmbcurrency.TabIndex = 173;
            this.cmbcurrency.SelectedIndexChanged += new System.EventHandler(this.cmbcurrency_SelectedIndexChanged);
            // 
            // lblcurrency
            // 
            this.lblcurrency.AutoSize = true;
            this.lblcurrency.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblcurrency.ForeColor = System.Drawing.Color.Black;
            this.lblcurrency.Location = new System.Drawing.Point(922, 412);
            this.lblcurrency.Name = "lblcurrency";
            this.lblcurrency.Size = new System.Drawing.Size(78, 19);
            this.lblcurrency.TabIndex = 172;
            this.lblcurrency.Text = "Currency :";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(885, 373);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(118, 19);
            this.label25.TabIndex = 207;
            this.label25.Text = "Payment Terms:";
            // 
            // cmbPaymentTerms
            // 
            this.cmbPaymentTerms.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbPaymentTerms.DropDownHeight = 130;
            this.cmbPaymentTerms.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPaymentTerms.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPaymentTerms.FormattingEnabled = true;
            this.cmbPaymentTerms.IntegralHeight = false;
            this.cmbPaymentTerms.Location = new System.Drawing.Point(1002, 373);
            this.cmbPaymentTerms.Name = "cmbPaymentTerms";
            this.cmbPaymentTerms.Size = new System.Drawing.Size(280, 23);
            this.cmbPaymentTerms.TabIndex = 208;
            // 
            // txtPanno
            // 
            this.txtPanno.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPanno.Location = new System.Drawing.Point(112, 438);
            this.txtPanno.MaxLength = 15;
            this.txtPanno.Name = "txtPanno";
            this.txtPanno.Size = new System.Drawing.Size(329, 26);
            this.txtPanno.TabIndex = 206;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Black;
            this.label24.Location = new System.Drawing.Point(37, 440);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(66, 19);
            this.label24.TabIndex = 205;
            this.label24.Text = "PAN No:";
            // 
            // txtcinno
            // 
            this.txtcinno.Location = new System.Drawing.Point(611, 442);
            this.txtcinno.MaxLength = 21;
            this.txtcinno.Name = "txtcinno";
            this.txtcinno.Size = new System.Drawing.Size(273, 26);
            this.txtcinno.TabIndex = 204;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(557, 445);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(48, 19);
            this.label18.TabIndex = 203;
            this.label18.Text = "CIN *:";
            // 
            // txtState
            // 
            this.txtState.Enabled = false;
            this.txtState.Location = new System.Drawing.Point(113, 282);
            this.txtState.Name = "txtState";
            this.txtState.Size = new System.Drawing.Size(326, 26);
            this.txtState.TabIndex = 202;
            // 
            // txtstatecode
            // 
            this.txtstatecode.Enabled = false;
            this.txtstatecode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstatecode.Location = new System.Drawing.Point(113, 321);
            this.txtstatecode.Name = "txtstatecode";
            this.txtstatecode.Size = new System.Drawing.Size(327, 26);
            this.txtstatecode.TabIndex = 201;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(9, 325);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(95, 19);
            this.label21.TabIndex = 200;
            this.label21.Text = "State Code*:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Black;
            this.label23.Location = new System.Drawing.Point(46, 282);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(57, 19);
            this.label23.TabIndex = 199;
            this.label23.Text = "State*:";
            // 
            // txtDistict
            // 
            this.txtDistict.DropDownHeight = 130;
            this.txtDistict.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.txtDistict.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDistict.FormattingEnabled = true;
            this.txtDistict.IntegralHeight = false;
            this.txtDistict.Location = new System.Drawing.Point(113, 201);
            this.txtDistict.Name = "txtDistict";
            this.txtDistict.Size = new System.Drawing.Size(328, 27);
            this.txtDistict.TabIndex = 198;
            this.txtDistict.SelectedIndexChanged += new System.EventHandler(this.txtDistict_SelectedIndexChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Black;
            this.label22.Location = new System.Drawing.Point(56, 204);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(47, 19);
            this.label22.TabIndex = 197;
            this.label22.Text = "City*:";
            // 
            // txtContactPerson
            // 
            this.txtContactPerson.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContactPerson.Location = new System.Drawing.Point(608, 113);
            this.txtContactPerson.Name = "txtContactPerson";
            this.txtContactPerson.Size = new System.Drawing.Size(273, 26);
            this.txtContactPerson.TabIndex = 196;
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.Location = new System.Drawing.Point(608, 188);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(273, 26);
            this.txtEmail.TabIndex = 195;
            // 
            // txtFaxNo
            // 
            this.txtFaxNo.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFaxNo.Location = new System.Drawing.Point(608, 150);
            this.txtFaxNo.Name = "txtFaxNo";
            this.txtFaxNo.Size = new System.Drawing.Size(273, 26);
            this.txtFaxNo.TabIndex = 194;
            // 
            // txtMoblieNo
            // 
            this.txtMoblieNo.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMoblieNo.Location = new System.Drawing.Point(608, 76);
            this.txtMoblieNo.Name = "txtMoblieNo";
            this.txtMoblieNo.Size = new System.Drawing.Size(273, 26);
            this.txtMoblieNo.TabIndex = 193;
            // 
            // txtPhoneNo
            // 
            this.txtPhoneNo.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhoneNo.Location = new System.Drawing.Point(113, 159);
            this.txtPhoneNo.Name = "txtPhoneNo";
            this.txtPhoneNo.Size = new System.Drawing.Size(327, 26);
            this.txtPhoneNo.TabIndex = 192;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(509, 78);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(93, 19);
            this.label15.TabIndex = 191;
            this.label15.Text = "Mobile No*:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(541, 152);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(59, 19);
            this.label16.TabIndex = 190;
            this.label16.Text = "Fax No:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(544, 190);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(56, 19);
            this.label17.TabIndex = 189;
            this.label17.Text = "E-Mail:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(477, 115);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(125, 19);
            this.label14.TabIndex = 188;
            this.label14.Text = "Contact Person*:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(11, 161);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(93, 19);
            this.label11.TabIndex = 187;
            this.label11.Text = "Phone No *:";
            // 
            // txtSwiftCode
            // 
            this.txtSwiftCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSwiftCode.Location = new System.Drawing.Point(1002, 322);
            this.txtSwiftCode.Name = "txtSwiftCode";
            this.txtSwiftCode.Size = new System.Drawing.Size(218, 26);
            this.txtSwiftCode.TabIndex = 184;
            // 
            // tXTBankBranch
            // 
            this.tXTBankBranch.Location = new System.Drawing.Point(1002, 248);
            this.tXTBankBranch.Multiline = true;
            this.tXTBankBranch.Name = "tXTBankBranch";
            this.tXTBankBranch.Size = new System.Drawing.Size(218, 59);
            this.tXTBankBranch.TabIndex = 183;
            // 
            // txtIFSCCOde
            // 
            this.txtIFSCCOde.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIFSCCOde.Location = new System.Drawing.Point(1000, 203);
            this.txtIFSCCOde.Name = "txtIFSCCOde";
            this.txtIFSCCOde.Size = new System.Drawing.Size(220, 26);
            this.txtIFSCCOde.TabIndex = 182;
            // 
            // txtBeneficiaryName
            // 
            this.txtBeneficiaryName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBeneficiaryName.Location = new System.Drawing.Point(1000, 135);
            this.txtBeneficiaryName.Multiline = true;
            this.txtBeneficiaryName.Name = "txtBeneficiaryName";
            this.txtBeneficiaryName.Size = new System.Drawing.Size(220, 47);
            this.txtBeneficiaryName.TabIndex = 181;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(911, 324);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(85, 19);
            this.label9.TabIndex = 180;
            this.label9.Text = "Swift Code:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(901, 261);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(99, 19);
            this.label8.TabIndex = 179;
            this.label8.Text = "Bank Branch:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(916, 210);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(78, 19);
            this.label7.TabIndex = 178;
            this.label7.Text = "IFSC Code:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(901, 141);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 38);
            this.label6.TabIndex = 177;
            this.label6.Text = "Beneficiary \r\n        Name :";
            // 
            // txtAccountNo
            // 
            this.txtAccountNo.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAccountNo.Location = new System.Drawing.Point(1000, 89);
            this.txtAccountNo.Name = "txtAccountNo";
            this.txtAccountNo.Size = new System.Drawing.Size(220, 26);
            this.txtAccountNo.TabIndex = 176;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(898, 94);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 19);
            this.label5.TabIndex = 175;
            this.label5.Text = "Account No:";
            // 
            // txtVenCode
            // 
            this.txtVenCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVenCode.Location = new System.Drawing.Point(815, 75);
            this.txtVenCode.Name = "txtVenCode";
            this.txtVenCode.ReadOnly = true;
            this.txtVenCode.Size = new System.Drawing.Size(305, 26);
            this.txtVenCode.TabIndex = 95;
            this.txtVenCode.Visible = false;
            // 
            // lblVenCode
            // 
            this.lblVenCode.AutoSize = true;
            this.lblVenCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVenCode.ForeColor = System.Drawing.Color.Black;
            this.lblVenCode.Location = new System.Drawing.Point(705, 79);
            this.lblVenCode.Name = "lblVenCode";
            this.lblVenCode.Size = new System.Drawing.Size(104, 19);
            this.lblVenCode.TabIndex = 94;
            this.lblVenCode.Text = "Vendor Code :";
            this.lblVenCode.Visible = false;
            // 
            // frmVendorMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1304, 672);
            this.Controls.Add(this.txtVenCode);
            this.Controls.Add(this.lblVenCode);
            this.Controls.Add(this.cmbApproveVendor);
            this.Controls.Add(this.lblProjecttype);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnBIM);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmVendorMaster";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Vendor Master";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmVendorMaster_FormClosing);
            this.Load += new System.EventHandler(this.frmVendorMaster_Load);
            this.pnBIM.ResumeLayout(false);
            this.pnBIM.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnBIM;
        private System.Windows.Forms.Label lbltime;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Label lblReturnedby;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ComboBox cmbApproveVendor;
        private System.Windows.Forms.Label lblProjecttype;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtCompanyName;
        private System.Windows.Forms.TextBox txtAddress2;
        private System.Windows.Forms.TextBox txtAddress1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtCountry;
        private System.Windows.Forms.TextBox txtPINCode;
        private System.Windows.Forms.CheckBox chkActive1;
        private System.Windows.Forms.Label lblPANNo;
        private System.Windows.Forms.TextBox txtShippedCountry;
        private System.Windows.Forms.Label lbltServiceTax;
        private System.Windows.Forms.TextBox txtShippedfromaddress;
        private System.Windows.Forms.Label lblExciseNo;
        private System.Windows.Forms.TextBox txtShippedStateCode;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.LinkLabel llQuit;
        private System.Windows.Forms.Button btnDelete1;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnIMExit;
        private System.Windows.Forms.Button btnAddVendor;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnClearAll1;
        private System.Windows.Forms.DateTimePicker dtpCreatedDate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtgstcode;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtShippedGstCode;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbMSMERegistered;
        private System.Windows.Forms.LinkLabel llbProjectDocuments;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtCreatedBy;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtAccountNo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtSwiftCode;
        private System.Windows.Forms.TextBox tXTBankBranch;
        private System.Windows.Forms.TextBox txtIFSCCOde;
        private System.Windows.Forms.TextBox txtBeneficiaryName;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtstatecode;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox txtDistict;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtContactPerson;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtFaxNo;
        private System.Windows.Forms.TextBox txtMoblieNo;
        private System.Windows.Forms.TextBox txtPhoneNo;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtState;
        private System.Windows.Forms.TextBox txtcinno;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtPanno;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox cmbPaymentTerms;
        private System.Windows.Forms.TextBox txtFxRate;
        private System.Windows.Forms.ComboBox cmbcurrency;
        private System.Windows.Forms.Label lblcurrency;
        private System.Windows.Forms.TextBox txtVenCode;
        private System.Windows.Forms.Label lblVenCode;
    }
}
