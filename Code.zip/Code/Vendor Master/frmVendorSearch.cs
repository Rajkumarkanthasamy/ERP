﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Vendor_Master
{
    public partial class frmVendorSearch : Form
    {
        private const uint uVENDOR_NAME_SEARCH = 0;
        private const uint uVENDOR_TINNO_SEARCH = 1;
        private const uint uVENDOR_STATUS_SEARCH = 2;
        DataTable dtVendorList = new DataTable();
        DataView dvVendorList = new DataView();
        BindingSource bsVendorList = new BindingSource();
        frmVendorMaster VendorMaster = new frmVendorMaster();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        private string sCompanyName;

        private void fnRowFilter(uint uSearchOption, string sRowFilter)
        {
            try
            {
                DataView dvVendorList = new DataView(dtVendorList);
                switch (uSearchOption)
                {
                    case uVENDOR_NAME_SEARCH:
                        {
                            dvVendorList.RowFilter = "VendorName like '" + sRowFilter + "%'";
                            dgVendorList.DataSource = dvVendorList.ToTable();
                            break;
                        }
                    case uVENDOR_TINNO_SEARCH:
                        {
                            dvVendorList.RowFilter = "VendorCode like '" + sRowFilter + "%'";
                            dgVendorList.DataSource = dvVendorList.ToTable();
                            break;
                        }
                    case uVENDOR_STATUS_SEARCH:
                        {
                            dvVendorList.RowFilter = "Status like '" + sRowFilter + "%'";
                            dgVendorList.DataSource = dvVendorList.ToTable();
                            break;
                        }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("SearchVendorForm_fnRowFilter " + ex.Message, "Error", 0, MessageBoxIcon.Error);
            }
        }


        public frmVendorSearch()
        {
            InitializeComponent();
        }

        private void frmVendorSearch_Load(object sender, EventArgs e)
        {
            try
            {
                dtVendorList = DAL.fnVedorList(null).Tables[0]; //get all vendor list from database
                bsVendorList.DataSource = dtVendorList;
                dgVendorList.AutoGenerateColumns = false;
                dgVendorList.DataSource = bsVendorList;
            }
            catch (Exception ex)
            {
                MessageBox.Show("SearchVendorForm_frmSearchVendorForm_Load " + ex.Message, "Error", 0, MessageBoxIcon.Error);
            }
        }

        private void dgVendorList_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                sCompanyName = dgVendorList.CurrentRow.Cells["VendorName"].Value.ToString();
                dvVendorList = new DataView(dtVendorList);
                dvVendorList.RowFilter = "VendorName Like '" + sCompanyName + "'";
                dtVendorList = dvVendorList.ToTable(true, "VendorCode");    // select particular vendpr details from database
                VendorMaster.fnGetVendorCode = dtVendorList.Rows[0]["VendorCode"].ToString();
               
                this.Hide();
                pleasewaitform pleaseWait = new pleasewaitform();
                pleaseWait.Show();
                Application.DoEvents();
                VendorMaster.Show();
                pleaseWait.Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show("SearchVendorForm_dgVendorList_DoubleClick " + ex.Message, "Error", 0, MessageBoxIcon.Error);
            }
        }

        private void txtVendorName_KeyUp(object sender, KeyEventArgs e)
        {
            fnRowFilter(0, txtVendorName.Text);
        }

        private void txtVendorCode_KeyUp(object sender, KeyEventArgs e)
        {
            fnRowFilter(1, txtVendorCode.Text);
        }

        private void checkShowInactive_CheckedChanged(object sender, EventArgs e)
        {
            if (checkShowInactive.Checked)
                fnRowFilter(2, "InActive");
            else
                fnRowFilter(2, "Active");
        }

        private void txtVendorCode_Enter(object sender, EventArgs e)
        {
            txtVendorName.Text = string.Empty;
            dgVendorList.DataSource = bsVendorList;
        }

        private void txtVendorName_Enter(object sender, EventArgs e)
        {
            txtVendorCode.Text = string.Empty;
            dgVendorList.DataSource = bsVendorList;
        }

        private void frmVendorSearch_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            pleasewaitform pleaseWait = new pleasewaitform();
            pleaseWait.Show();
            Application.DoEvents();
            VendorMaster.Show();
            pleaseWait.Hide();
        }
    }
}
