﻿namespace Erp_Project_With_Buttons.Part_Reciept
{
    partial class GinReverse
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GinReverse));
            this.label10 = new System.Windows.Forms.Label();
            this.cmbprintginnumber = new System.Windows.Forms.ComboBox();
            this.dgvGINReturnList = new System.Windows.Forms.DataGridView();
            this.ItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RecieveQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AvailableQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReturnQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblVendor = new System.Windows.Forms.Label();
            this.txtVendorcode = new System.Windows.Forms.Label();
            this.lblinvoicedate = new System.Windows.Forms.Label();
            this.lblSupplierinvoicenumber = new System.Windows.Forms.Label();
            this.lblVendorcode = new System.Windows.Forms.Label();
            this.lblVendorname = new System.Windows.Forms.Label();
            this.lbldate = new System.Windows.Forms.Label();
            this.lblInvDate = new System.Windows.Forms.Label();
            this.lblGINDate = new System.Windows.Forms.Label();
            this.txtinvoiceno = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.dtpRivrseGINDate = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGINReturnList)).BeginInit();
            this.SuspendLayout();
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(159, 13);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(98, 19);
            this.label10.TabIndex = 206;
            this.label10.Text = "GIN Number:";
            // 
            // cmbprintginnumber
            // 
            this.cmbprintginnumber.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbprintginnumber.DropDownHeight = 130;
            this.cmbprintginnumber.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbprintginnumber.FormattingEnabled = true;
            this.cmbprintginnumber.IntegralHeight = false;
            this.cmbprintginnumber.ItemHeight = 15;
            this.cmbprintginnumber.Location = new System.Drawing.Point(263, 12);
            this.cmbprintginnumber.Name = "cmbprintginnumber";
            this.cmbprintginnumber.Size = new System.Drawing.Size(255, 23);
            this.cmbprintginnumber.TabIndex = 205;
            this.cmbprintginnumber.SelectedIndexChanged += new System.EventHandler(this.cmbprintginnumber_SelectedIndexChanged);
            // 
            // dgvGINReturnList
            // 
            this.dgvGINReturnList.AllowUserToAddRows = false;
            this.dgvGINReturnList.AllowUserToDeleteRows = false;
            this.dgvGINReturnList.AllowUserToResizeRows = false;
            this.dgvGINReturnList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.Desktop;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvGINReturnList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvGINReturnList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGINReturnList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ItemCode,
            this.ItemDescription,
            this.RecieveQuantity,
            this.AvailableQty,
            this.ReturnQty,
            this.UnitCost,
            this.Amount,
            this.SGSTRate,
            this.SGSTAmount,
            this.CGSTRate,
            this.CGSTAmount,
            this.IGSTRate,
            this.IGSTAmount});
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvGINReturnList.DefaultCellStyle = dataGridViewCellStyle15;
            this.dgvGINReturnList.EnableHeadersVisualStyles = false;
            this.dgvGINReturnList.Location = new System.Drawing.Point(12, 93);
            this.dgvGINReturnList.MultiSelect = false;
            this.dgvGINReturnList.Name = "dgvGINReturnList";
            this.dgvGINReturnList.RowHeadersVisible = false;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvGINReturnList.RowsDefaultCellStyle = dataGridViewCellStyle16;
            this.dgvGINReturnList.Size = new System.Drawing.Size(1312, 356);
            this.dgvGINReturnList.TabIndex = 207;
            this.dgvGINReturnList.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgvGINReturnList_CellBeginEdit);
            this.dgvGINReturnList.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGINReturnList_CellEndEdit);
            this.dgvGINReturnList.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvGINReturnList_EditingControlShowing);
            this.dgvGINReturnList.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvGINReturnList_KeyUp);
            // 
            // ItemCode
            // 
            this.ItemCode.DataPropertyName = "ItemCode";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ItemCode.DefaultCellStyle = dataGridViewCellStyle2;
            this.ItemCode.HeaderText = "Item Code";
            this.ItemCode.Name = "ItemCode";
            this.ItemCode.ReadOnly = true;
            this.ItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemCode.Width = 76;
            // 
            // ItemDescription
            // 
            this.ItemDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ItemDescription.DataPropertyName = "ItemDescription";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ItemDescription.DefaultCellStyle = dataGridViewCellStyle3;
            this.ItemDescription.HeaderText = "Item Description";
            this.ItemDescription.Name = "ItemDescription";
            this.ItemDescription.ReadOnly = true;
            this.ItemDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemDescription.Width = 341;
            // 
            // RecieveQuantity
            // 
            this.RecieveQuantity.DataPropertyName = "Quantity";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.RecieveQuantity.DefaultCellStyle = dataGridViewCellStyle4;
            this.RecieveQuantity.HeaderText = "Received Qty";
            this.RecieveQuantity.Name = "RecieveQuantity";
            this.RecieveQuantity.ReadOnly = true;
            this.RecieveQuantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RecieveQuantity.Width = 95;
            // 
            // AvailableQty
            // 
            this.AvailableQty.DataPropertyName = "AvailableQty";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.AvailableQty.DefaultCellStyle = dataGridViewCellStyle5;
            this.AvailableQty.HeaderText = "Available Qty";
            this.AvailableQty.Name = "AvailableQty";
            this.AvailableQty.ReadOnly = true;
            this.AvailableQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.AvailableQty.Width = 96;
            // 
            // ReturnQty
            // 
            this.ReturnQty.DataPropertyName = "ReturnQty";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ReturnQty.DefaultCellStyle = dataGridViewCellStyle6;
            this.ReturnQty.HeaderText = "Return Qty";
            this.ReturnQty.Name = "ReturnQty";
            this.ReturnQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ReturnQty.Width = 82;
            // 
            // UnitCost
            // 
            this.UnitCost.DataPropertyName = "UnitCost";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.UnitCost.DefaultCellStyle = dataGridViewCellStyle7;
            this.UnitCost.HeaderText = "Unit Cost";
            this.UnitCost.Name = "UnitCost";
            this.UnitCost.ReadOnly = true;
            this.UnitCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitCost.Width = 69;
            // 
            // Amount
            // 
            this.Amount.DataPropertyName = "Amount";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Amount.DefaultCellStyle = dataGridViewCellStyle8;
            this.Amount.HeaderText = "Amount";
            this.Amount.Name = "Amount";
            this.Amount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Amount.Width = 71;
            // 
            // SGSTRate
            // 
            this.SGSTRate.DataPropertyName = "SGSTRate";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.SGSTRate.DefaultCellStyle = dataGridViewCellStyle9;
            this.SGSTRate.HeaderText = "SGST %";
            this.SGSTRate.Name = "SGSTRate";
            this.SGSTRate.ReadOnly = true;
            this.SGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SGSTRate.Width = 59;
            // 
            // SGSTAmount
            // 
            this.SGSTAmount.DataPropertyName = "SGSTAmount";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.Format = "N2";
            this.SGSTAmount.DefaultCellStyle = dataGridViewCellStyle10;
            this.SGSTAmount.HeaderText = "SGST Amt";
            this.SGSTAmount.Name = "SGSTAmount";
            this.SGSTAmount.ReadOnly = true;
            this.SGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SGSTAmount.Width = 74;
            // 
            // CGSTRate
            // 
            this.CGSTRate.DataPropertyName = "CGSTRate";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.CGSTRate.DefaultCellStyle = dataGridViewCellStyle11;
            this.CGSTRate.HeaderText = "CGST %";
            this.CGSTRate.Name = "CGSTRate";
            this.CGSTRate.ReadOnly = true;
            this.CGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CGSTRate.Width = 59;
            // 
            // CGSTAmount
            // 
            this.CGSTAmount.DataPropertyName = "CGSTAmount";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.Format = "N2";
            this.CGSTAmount.DefaultCellStyle = dataGridViewCellStyle12;
            this.CGSTAmount.HeaderText = "CGST Amt";
            this.CGSTAmount.Name = "CGSTAmount";
            this.CGSTAmount.ReadOnly = true;
            this.CGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CGSTAmount.Width = 74;
            // 
            // IGSTRate
            // 
            this.IGSTRate.DataPropertyName = "IGSTRate";
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.IGSTRate.DefaultCellStyle = dataGridViewCellStyle13;
            this.IGSTRate.HeaderText = "IGST %";
            this.IGSTRate.Name = "IGSTRate";
            this.IGSTRate.ReadOnly = true;
            this.IGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IGSTRate.Width = 55;
            // 
            // IGSTAmount
            // 
            this.IGSTAmount.DataPropertyName = "IGSTAmount";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle14.Format = "N2";
            dataGridViewCellStyle14.NullValue = null;
            this.IGSTAmount.DefaultCellStyle = dataGridViewCellStyle14;
            this.IGSTAmount.HeaderText = "IGST Amt";
            this.IGSTAmount.Name = "IGSTAmount";
            this.IGSTAmount.ReadOnly = true;
            this.IGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IGSTAmount.Width = 70;
            // 
            // lblVendor
            // 
            this.lblVendor.AutoSize = true;
            this.lblVendor.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVendor.ForeColor = System.Drawing.Color.Black;
            this.lblVendor.Location = new System.Drawing.Point(255, 51);
            this.lblVendor.Name = "lblVendor";
            this.lblVendor.Size = new System.Drawing.Size(16, 18);
            this.lblVendor.TabIndex = 223;
            this.lblVendor.Text = "C";
            // 
            // txtVendorcode
            // 
            this.txtVendorcode.AutoSize = true;
            this.txtVendorcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVendorcode.ForeColor = System.Drawing.Color.Black;
            this.txtVendorcode.Location = new System.Drawing.Point(711, 51);
            this.txtVendorcode.Name = "txtVendorcode";
            this.txtVendorcode.Size = new System.Drawing.Size(16, 18);
            this.txtVendorcode.TabIndex = 222;
            this.txtVendorcode.Text = "C";
            // 
            // lblinvoicedate
            // 
            this.lblinvoicedate.AutoSize = true;
            this.lblinvoicedate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinvoicedate.ForeColor = System.Drawing.Color.Black;
            this.lblinvoicedate.Location = new System.Drawing.Point(916, 51);
            this.lblinvoicedate.Name = "lblinvoicedate";
            this.lblinvoicedate.Size = new System.Drawing.Size(92, 18);
            this.lblinvoicedate.TabIndex = 218;
            this.lblinvoicedate.Text = "Invoice Date :";
            // 
            // lblSupplierinvoicenumber
            // 
            this.lblSupplierinvoicenumber.AutoSize = true;
            this.lblSupplierinvoicenumber.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSupplierinvoicenumber.ForeColor = System.Drawing.Color.Black;
            this.lblSupplierinvoicenumber.Location = new System.Drawing.Point(626, 18);
            this.lblSupplierinvoicenumber.Name = "lblSupplierinvoicenumber";
            this.lblSupplierinvoicenumber.Size = new System.Drawing.Size(85, 18);
            this.lblSupplierinvoicenumber.TabIndex = 209;
            this.lblSupplierinvoicenumber.Text = "InvoiceNo* :";
            // 
            // lblVendorcode
            // 
            this.lblVendorcode.AutoSize = true;
            this.lblVendorcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVendorcode.ForeColor = System.Drawing.Color.Black;
            this.lblVendorcode.Location = new System.Drawing.Point(616, 51);
            this.lblVendorcode.Name = "lblVendorcode";
            this.lblVendorcode.Size = new System.Drawing.Size(95, 18);
            this.lblVendorcode.TabIndex = 212;
            this.lblVendorcode.Text = "Vendor Code :";
            // 
            // lblVendorname
            // 
            this.lblVendorname.AutoSize = true;
            this.lblVendorname.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVendorname.ForeColor = System.Drawing.Color.Black;
            this.lblVendorname.Location = new System.Drawing.Point(159, 51);
            this.lblVendorname.Name = "lblVendorname";
            this.lblVendorname.Size = new System.Drawing.Size(100, 18);
            this.lblVendorname.TabIndex = 213;
            this.lblVendorname.Text = "Vendor Name :";
            // 
            // lbldate
            // 
            this.lbldate.AutoSize = true;
            this.lbldate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldate.ForeColor = System.Drawing.Color.Black;
            this.lbldate.Location = new System.Drawing.Point(937, 18);
            this.lbldate.Name = "lbldate";
            this.lbldate.Size = new System.Drawing.Size(71, 18);
            this.lbldate.TabIndex = 208;
            this.lbldate.Text = "GIN Date :";
            // 
            // lblInvDate
            // 
            this.lblInvDate.AutoSize = true;
            this.lblInvDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInvDate.ForeColor = System.Drawing.Color.Black;
            this.lblInvDate.Location = new System.Drawing.Point(1014, 48);
            this.lblInvDate.Name = "lblInvDate";
            this.lblInvDate.Size = new System.Drawing.Size(16, 18);
            this.lblInvDate.TabIndex = 227;
            this.lblInvDate.Text = "C";
            // 
            // lblGINDate
            // 
            this.lblGINDate.AutoSize = true;
            this.lblGINDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGINDate.ForeColor = System.Drawing.Color.Black;
            this.lblGINDate.Location = new System.Drawing.Point(1014, 18);
            this.lblGINDate.Name = "lblGINDate";
            this.lblGINDate.Size = new System.Drawing.Size(16, 18);
            this.lblGINDate.TabIndex = 226;
            this.lblGINDate.Text = "C";
            // 
            // txtinvoiceno
            // 
            this.txtinvoiceno.AutoSize = true;
            this.txtinvoiceno.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinvoiceno.ForeColor = System.Drawing.Color.Black;
            this.txtinvoiceno.Location = new System.Drawing.Point(708, 18);
            this.txtinvoiceno.Name = "txtinvoiceno";
            this.txtinvoiceno.Size = new System.Drawing.Size(16, 18);
            this.txtinvoiceno.TabIndex = 228;
            this.txtinvoiceno.Text = "C";
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(1200, 482);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(90, 39);
            this.btnExit.TabIndex = 230;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(1045, 482);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(105, 39);
            this.btnSave.TabIndex = 229;
            this.btnSave.Text = "Reverse Gin";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click_1);
            // 
            // dtpRivrseGINDate
            // 
            this.dtpRivrseGINDate.Enabled = false;
            this.dtpRivrseGINDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpRivrseGINDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpRivrseGINDate.Location = new System.Drawing.Point(1235, 8);
            this.dtpRivrseGINDate.Name = "dtpRivrseGINDate";
            this.dtpRivrseGINDate.Size = new System.Drawing.Size(89, 26);
            this.dtpRivrseGINDate.TabIndex = 231;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(1113, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 18);
            this.label1.TabIndex = 232;
            this.label1.Text = "Riverse GIN Date :";
            // 
            // GinReverse
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1336, 533);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtpRivrseGINDate);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtinvoiceno);
            this.Controls.Add(this.lblInvDate);
            this.Controls.Add(this.lblGINDate);
            this.Controls.Add(this.lblVendor);
            this.Controls.Add(this.txtVendorcode);
            this.Controls.Add(this.lblinvoicedate);
            this.Controls.Add(this.lblSupplierinvoicenumber);
            this.Controls.Add(this.lblVendorcode);
            this.Controls.Add(this.lblVendorname);
            this.Controls.Add(this.lbldate);
            this.Controls.Add(this.dgvGINReturnList);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.cmbprintginnumber);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "GinReverse";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GIN Reverse";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.GinReverse_FormClosing);
            this.Load += new System.EventHandler(this.GinReverse_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGINReturnList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cmbprintginnumber;
        private System.Windows.Forms.DataGridView dgvGINReturnList;
        private System.Windows.Forms.Label lblVendor;
        private System.Windows.Forms.Label txtVendorcode;
        private System.Windows.Forms.Label lblinvoicedate;
        private System.Windows.Forms.Label lblSupplierinvoicenumber;
        private System.Windows.Forms.Label lblVendorcode;
        private System.Windows.Forms.Label lblVendorname;
        private System.Windows.Forms.Label lbldate;
        private System.Windows.Forms.Label lblInvDate;
        private System.Windows.Forms.Label lblGINDate;
        private System.Windows.Forms.Label txtinvoiceno;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.DateTimePicker dtpRivrseGINDate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn RecieveQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn AvailableQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReturnQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn SGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn SGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn CGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn CGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn IGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn IGSTAmount;
    }
}