﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace Erp_Project_With_Buttons
{
    internal class InventoryService
    {
        DataAccessLayer DAL = new DataAccessLayer();

        private string connectionString = "Data Source=inbas07.instron.com;Initial Catalog=ERP_Database;User ID=ERPService;Password=Instron@ERP84$#";
    // private string connectionString = "Data Source=HUGARBH015W11\\SQLEXPRESS;Initial Catalog=ERP_Database; User ID=sa;Password=Bangalore@560058";


        public List<InventoryTransaction> LoadTransactions(DateTime fromDate, DateTime toDate, string itemCode)
        {
            var transactions = new List<InventoryTransaction>();

            string query = @"
        WITH AllTransactions AS (
	 select
				   IM.UnitCost,
				    IM.AvailableQty as Quantity,
				   DATEADD(MINUTE, 5, CONVERT(DATETIME, IM.CreatedDate, 105)) AS Date,
				   IM.ItemCode,
				   0 AS CDValue, 
                   0 AS TransportationFreight, 
                   0 AS PackingForwarding, 
				   'OpeningStock' as TransactionType
from  ItemMaster IM Where IM.AvailableQty>0 AND IM.ItemCode= @ItemCode AND
CONVERT(DATETIME, IM.CreatedDate, 105) >= DATEADD(MINUTE, 5, @FromDate)
    AND CONVERT(DATETIME, IM.CreatedDate, 105) <= DATEADD(MINUTE, 5,  @ToDate)
UNION ALL
SELECT
 
                    R.UnitCost, 
                    R.Quantity,
                    CONVERT(DATETIME, R.Date, 105) AS Date,
                    R.ItemCode,
                    R.CDValue, 
                    R.TransportationFreight, 
                    R.PackingForwarding, 
                    'PO Receipt' AS TransactionType
                FROM [dbo].[Receipt] R
                WHERE 
				R.ItemCode = @ItemCode
                    AND
					CONVERT(DATETIME, R.Date, 105) >= @FromDate
                    AND CONVERT(DATETIME, R.Date, 105) <= @ToDate
					AND R.Refnumber like 'PO%'
	UNION ALL				
                SELECT 
                    I.UnitPrice AS UnitCost, 
                    I.Quantity,
                    DATEADD(MINUTE, 2, CONVERT(DATETIME, I.Issue_Date, 105)) AS Date,
                    I.Item_Code AS ItemCode, 
                    0 AS CDValue, 
                    0 AS TransportationFreight, 
                    0 AS PackingForwarding, 
                    'IndentIssued' AS TransactionType
                FROM [dbo].[Issued] I
                WHERE I.Item_Code = @ItemCode
                   AND
				   CONVERT(DATETIME, I.Issue_Date, 105) >= DATEADD(MINUTE, 5, @FromDate)
                   AND CONVERT(DATETIME, I.Issue_Date, 105) <= DATEADD(MINUTE, 5, @ToDate)
	UNION ALL
    -- ItemReturned (delay +3 min)
    SELECT
        IM.UnitCost,
        IR.Quantity,
         DATEADD(MINUTE, 3, CONVERT(DATETIME, IR.Date, 105)) AS Date,
        IM.ItemCode,
        0 AS CDValue,
        0 AS TransportationFreight,
        0 AS PackingForwarding,
        'ItemReturned' AS TransactionType
    FROM ItemReturn IR
    JOIN ItemMaster IM ON IR.ItemCode = IM.ItemCode
    WHERE IM.ItemCode = @ItemCode
      AND CONVERT(DATETIME, IR.Date, 105) BETWEEN @FromDate AND @ToDate

         UNION ALL

                SELECT 
                R.UnitCost,
                R.Quantity,
                CONVERT(datetime,R.Date,105) as Date,
                R.ItemCode,
                R.CDValue, 
    R.TransportationFreight, 
    R.PackingForwarding, 
                'WO Reciept' as TransactionType 
       from Receipt R join WorkOrder P on R.RefNumber=P.WoNumber  AND r.ItemCode=p.OPItemCode
           Where            R.ItemCode = @ItemCode AND
            CONVERT(datetime,R.Date,105)>=@FromDate and CONVERT(datetime,R.Date,105)<=@ToDate  and R.Refnumber like 'WO%'

)
SELECT *
FROM AllTransactions
ORDER BY Date, ItemCode;

            ";

            using (SqlConnection conn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@FromDate", fromDate);
                cmd.Parameters.AddWithValue("@ToDate", toDate);
                cmd.Parameters.AddWithValue("@ItemCode", itemCode);

                conn.Open();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        decimal baseUnitCost = Convert.ToDecimal(reader["UnitCost"]);
                        decimal cdValue = reader["CDValue"] != DBNull.Value ? Convert.ToDecimal(reader["CDValue"]) : 0;
                        decimal freight = reader["TransportationFreight"] != DBNull.Value ? Convert.ToDecimal(reader["TransportationFreight"]) : 0;
                        decimal packing = reader["PackingForwarding"] != DBNull.Value ? Convert.ToDecimal(reader["PackingForwarding"]) : 0;
                        decimal quantity = Convert.ToDecimal(reader["Quantity"]);
                        string transactionType = reader["TransactionType"].ToString();

                        if (transactionType == "PO Receipt"|| transactionType == "OpeningStock"|| transactionType == "WO Reciept" || transactionType == "ItemReturned" && quantity > 0)
                        {
                            baseUnitCost += (cdValue + freight + packing) / quantity;
                        }

                        transactions.Add(new InventoryTransaction
                        {
                            Date = Convert.ToDateTime(reader["Date"]),
                            Quantity = quantity,
                            UnitCost = baseUnitCost,
                            ItemCode = reader["ItemCode"].ToString(),
                            TransactionType = transactionType
                        });
                    }
                }
            }

            return transactions;
        }


        public List<WarResult> CalculateWAR(List<InventoryTransaction> transactions)
        {
            var results = new List<WarResult>();
            var skippedItems = new List<string>();
            decimal cumQty = 0;
            decimal cumVal = 0;
            decimal currentWAR = 0;
            decimal lastKnownWAR = 0;

            foreach (var txn in transactions.OrderBy(t => t.Date))
            {
                try
                {
                    if (txn.Quantity == 0)
                    {
                        Console.WriteLine($"⚠️ Skipping transaction with zero quantity for item {txn.ItemCode} on {txn.Date:dd-MM-yyyy}");
                     // Log($"Zero quantity txn skipped: {txn.ItemCode} | {txn.Date}");
                        continue;
                    }

                    decimal usedUnitCost = txn.UnitCost;
                    decimal valueChange = 0;

                    Console.WriteLine($"Processing: {txn.TransactionType} | Date: {txn.Date:dd-MM-yyyy HH:mm} | Qty: {txn.Quantity} | UnitCost: {txn.UnitCost} | cumQty: {cumQty} | cumVal: {cumVal}");
                  //Log($"Processing: {txn.TransactionType} | Date: {txn.Date:dd-MM-yyyy HH:mm} | Qty: {txn.Quantity} | UnitCost: {txn.UnitCost} | cumQty: {cumQty} | cumVal: {cumVal}");

                    if (txn.TransactionType == "PO Receipt" || txn.TransactionType == "OpeningStock" ||
                        txn.TransactionType == "WO Reciept" || txn.TransactionType == "ItemReturned")
                    {
                        valueChange = txn.Quantity * usedUnitCost;
                        cumQty += txn.Quantity;
                        cumVal += valueChange;

                        if (cumQty > 0)
                        {
                            currentWAR = cumVal / cumQty;
                            lastKnownWAR = currentWAR;
                        }
                        else
                        {
                            // Keep the last known WAR even if cumQty is 0
                            Console.WriteLine($"⚠️ cumQty is zero or negative after receipt on {txn.Date:dd-MM-yyyy}");
                          
                        }
                    }
                    else if (txn.TransactionType == "IndentIssued")
                    {
                        if (cumQty <= 0 || (cumQty - txn.Quantity) < 0)
                        {
                            string warningMsg = $"⚠️ Warning: Cannot issue '{txn.ItemCode}' on {txn.Date:dd-MM-yyyy} — no/insufficient stock.";
                            Console.WriteLine(warningMsg);
                          
                            skippedItems.Add(txn.ItemCode);

                            results.Add(new WarResult
                            {
                                Date = txn.Date,
                                Quantity = txn.Quantity,
                                UnitCost = usedUnitCost,
                                TransactionType = txn.TransactionType,
                                CumulativeQty = cumQty,
                                CumulativeValue = cumVal,
                                WeightedAverageRate = currentWAR
                            });

                            continue;
                        }

                        usedUnitCost = lastKnownWAR; // Use last known WAR instead of currentWAR
                        valueChange = txn.Quantity * usedUnitCost;
                        cumQty -= txn.Quantity;
                        cumVal -= valueChange;

                        if (cumQty > 0)
                        {
                            currentWAR = cumVal / cumQty;
                            lastKnownWAR = currentWAR;
                        }
                        else
                        {
                            // Do not reset WAR to zero, just retain last known
                            Console.WriteLine($"⚠️ cumQty became zero after issuing on {txn.Date:dd-MM-yyyy}");
                            
                        }
                    }

                    results.Add(new WarResult
                    {
                        Date = txn.Date,
                        Quantity = txn.Quantity,
                        UnitCost = usedUnitCost,
                        TransactionType = txn.TransactionType,
                        CumulativeQty = cumQty,
                        CumulativeValue = cumVal,
                        WeightedAverageRate = currentWAR
                    });
                }
                catch (DivideByZeroException ex)
                {
                    Console.WriteLine($"⚠️ DivideByZeroException on {txn.ItemCode}: {ex.Message}");
                   
                    continue;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"❌ General error on {txn.ItemCode}: {ex.Message}");
               
                    continue;
                }
            }

            if (skippedItems.Any())
            {
                string skippedMessage = $"⚠️ Skipped ItemCodes due to zero/insufficient stock: {string.Join(", ", skippedItems.Distinct())}";
                Console.WriteLine(skippedMessage);
                
            }

            return results;
        }


        //public List<WarResult> CalculateWAR(List<InventoryTransaction> transactions)
        //{
        //    var results = new List<WarResult>();
        //    var skippedItems = new List<string>();
        //    decimal cumQty = 0;
        //    decimal cumVal = 0;
        //    decimal currentWAR = 0;
        //    decimal lastKnownWAR = 0;

        //    foreach (var txn in transactions.OrderBy(t => t.Date))
        //    {
        //        try
        //        {
        //            if (txn.Quantity == 0)
        //            {
        //                //Console.WriteLine($"⚠️ Skipping transaction with zero quantity for item {txn.ItemCode} on {txn.Date:dd-MM-yyyy}");
        //                //Log($"Zero quantity txn skipped: {txn.ItemCode} | {txn.Date}");
        //                continue;
        //            }

        //            decimal usedUnitCost = txn.UnitCost;
        //            decimal valueChange = 0;

        //         //   Console.WriteLine($"Processing: {txn.TransactionType} | Date: {txn.Date:dd-MM-yyyy HH:mm} | Qty: {txn.Quantity} | UnitCost: {txn.UnitCost} | cumQty: {cumQty} | cumVal: {cumVal}");
        //         //   Log($"Processing: {txn.TransactionType} | Date: {txn.Date:dd-MM-yyyy HH:mm} | Qty: {txn.Quantity} | UnitCost: {txn.UnitCost} | cumQty: {cumQty} | cumVal: {cumVal}");

        //            if (txn.TransactionType == "PO Receipt" || txn.TransactionType == "OpeningStock" ||
        //                txn.TransactionType == "WO Reciept" || txn.TransactionType == "ItemReturned")
        //            {
        //                valueChange = txn.Quantity * usedUnitCost;
        //                cumQty += txn.Quantity;
        //                cumVal += valueChange;

        //                if (cumQty > 0)
        //                {
        //                    currentWAR = cumVal / cumQty;
        //                    lastKnownWAR = currentWAR;
        //                }
        //                else
        //                {
        //                    // Keep the last known WAR even if cumQty is 0
        //                  //  Console.WriteLine($"⚠️ cumQty is zero or negative after receipt on {txn.Date:dd-MM-yyyy}");
        //                    //Log($"⚠️ cumQty is zero or negative after receipt on {txn.Date:dd-MM-yyyy}");
        //                }
        //            }
        //            else if (txn.TransactionType == "IndentIssued")
        //            {
        //                if (cumQty <= 0 || (cumQty - txn.Quantity) < 0)
        //                {
        //                    string warningMsg = $"⚠️ Warning: Cannot issue '{txn.ItemCode}' on {txn.Date:dd-MM-yyyy} — no/insufficient stock.";
        //                   // Console.WriteLine(warningMsg);
        //                  //  Log(warningMsg);
        //                    skippedItems.Add(txn.ItemCode);

        //                    results.Add(new WarResult
        //                    {
        //                        Date = txn.Date,
        //                        Quantity = txn.Quantity,
        //                        UnitCost = usedUnitCost,
        //                        TransactionType = txn.TransactionType,
        //                        CumulativeQty = cumQty,
        //                        CumulativeValue = cumVal,
        //                        WeightedAverageRate = currentWAR
        //                    });

        //                    continue;
        //                }

        //                usedUnitCost = lastKnownWAR; // Use last known WAR instead of currentWAR
        //                valueChange = txn.Quantity * usedUnitCost;
        //                cumQty -= txn.Quantity;
        //                cumVal -= valueChange;

        //                if (cumQty > 0)
        //                {
        //                    currentWAR = cumVal / cumQty;
        //                    lastKnownWAR = currentWAR;
        //                }
        //                else
        //                {
        //                    // Do not reset WAR to zero, just retain last known
        //                  //  Console.WriteLine($"⚠️ cumQty became zero after issuing on {txn.Date:dd-MM-yyyy}");
        //                   // Log($"⚠️ cumQty became zero after issuing on {txn.Date:dd-MM-yyyy}");
        //                }
        //            }

        //            results.Add(new WarResult
        //            {
        //                Date = txn.Date,
        //                Quantity = txn.Quantity,
        //                UnitCost = usedUnitCost,
        //                TransactionType = txn.TransactionType,
        //                CumulativeQty = cumQty,
        //                CumulativeValue = cumVal,
        //                WeightedAverageRate = currentWAR
        //            });
        //        }
        //        catch (DivideByZeroException ex)
        //        {
        //         //   Console.WriteLine($"⚠️ DivideByZeroException on {txn.ItemCode}: {ex.Message}");
        //          //  Log($"❌ DivideByZeroException for '{txn.ItemCode}': {ex.Message}");
        //            continue;
        //        }
        //        catch (Exception ex)
        //        {
        //          //  Console.WriteLine($"❌ General error on {txn.ItemCode}: {ex.Message}");
        //           // Log($"❌ General error for '{txn.ItemCode}': {ex.Message}");
        //            continue;
        //        }
        //    }

        //    if (skippedItems.Any())
        //    {
        //        string skippedMessage = $"⚠️ Skipped ItemCodes due to zero/insufficient stock: {string.Join(", ", skippedItems.Distinct())}";
        //       // Console.WriteLine(skippedMessage);
        //       // Log(skippedMessage);
        //    }

        //    return results;
        //}
    }

    public class WarResult
    {
        public DateTime Date { get; set; }
        public decimal Quantity { get; set; }
        public decimal UnitCost { get; set; }
        public string TransactionType { get; set; }
        public decimal CumulativeQty { get; set; }
        public decimal CumulativeValue { get; set; }
        public decimal WeightedAverageRate { get; set; }
    }

    public class InventoryTransaction
    {
        public DateTime Date { get; set; }
        public decimal Quantity { get; set; }
        public decimal UnitCost { get; set; }
        public string ItemCode { get; set; }
        public string TransactionType { get; set; }
    }
}
