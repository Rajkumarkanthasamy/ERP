﻿namespace Erp_Project_With_Buttons.Part_Reciept
{
    partial class GINWOView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GINWOView));
            this.txtAuthorisedBy = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtPreparedBy = new System.Windows.Forms.TextBox();
            this.lblIteType = new System.Windows.Forms.Label();
            this.txtProjectcode = new System.Windows.Forms.TextBox();
            this.lblItemDescription = new System.Windows.Forms.Label();
            this.lblItemCode = new System.Windows.Forms.Label();
            this.gbSearchOptions = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.txtDBOMNo = new System.Windows.Forms.TextBox();
            this.dgpolist = new System.Windows.Forms.DataGridView();
            this.DBOMNO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IPItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IPOrderQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OPItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OPOrderQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Vendorcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VendorName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TotalCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.JobIssueStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PreparedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AuthorisedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WOgeneratedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WOGeneratedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WOStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IPRemainingOrderQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WorkDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OPRemainingQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DGRefno = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbSearchOptions.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgpolist)).BeginInit();
            this.SuspendLayout();
            // 
            // txtAuthorisedBy
            // 
            this.txtAuthorisedBy.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAuthorisedBy.Location = new System.Drawing.Point(1020, 40);
            this.txtAuthorisedBy.Name = "txtAuthorisedBy";
            this.txtAuthorisedBy.Size = new System.Drawing.Size(153, 26);
            this.txtAuthorisedBy.TabIndex = 6;
            this.txtAuthorisedBy.Visible = false;
            this.txtAuthorisedBy.Enter += new System.EventHandler(this.txtAuthorisedBy_Enter);
            this.txtAuthorisedBy.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtAuthorisedBy_KeyUp);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(908, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 19);
            this.label1.TabIndex = 5;
            this.label1.Text = "Authorised By:";
            this.label1.Visible = false;
            // 
            // txtPreparedBy
            // 
            this.txtPreparedBy.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPreparedBy.Location = new System.Drawing.Point(401, 40);
            this.txtPreparedBy.Name = "txtPreparedBy";
            this.txtPreparedBy.Size = new System.Drawing.Size(229, 26);
            this.txtPreparedBy.TabIndex = 4;
            this.txtPreparedBy.Enter += new System.EventHandler(this.txtPreparedBy_Enter);
            this.txtPreparedBy.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtPreparedBy_KeyUp);
            // 
            // lblIteType
            // 
            this.lblIteType.AutoSize = true;
            this.lblIteType.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIteType.Location = new System.Drawing.Point(291, 43);
            this.lblIteType.Name = "lblIteType";
            this.lblIteType.Size = new System.Drawing.Size(110, 19);
            this.lblIteType.TabIndex = 1;
            this.lblIteType.Text = "Vendor Name :";
            // 
            // txtProjectcode
            // 
            this.txtProjectcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProjectcode.Location = new System.Drawing.Point(700, 40);
            this.txtProjectcode.Name = "txtProjectcode";
            this.txtProjectcode.Size = new System.Drawing.Size(203, 26);
            this.txtProjectcode.TabIndex = 3;
            this.txtProjectcode.Visible = false;
            this.txtProjectcode.Enter += new System.EventHandler(this.txtProjectcode_Enter);
            this.txtProjectcode.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtProjectcode_KeyUp);
            // 
            // lblItemDescription
            // 
            this.lblItemDescription.AutoSize = true;
            this.lblItemDescription.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemDescription.Location = new System.Drawing.Point(652, 43);
            this.lblItemDescription.Name = "lblItemDescription";
            this.lblItemDescription.Size = new System.Drawing.Size(42, 19);
            this.lblItemDescription.TabIndex = 2;
            this.lblItemDescription.Text = "GIN :";
            this.lblItemDescription.Visible = false;
            // 
            // lblItemCode
            // 
            this.lblItemCode.AutoSize = true;
            this.lblItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemCode.Location = new System.Drawing.Point(19, 43);
            this.lblItemCode.Name = "lblItemCode";
            this.lblItemCode.Size = new System.Drawing.Size(63, 19);
            this.lblItemCode.TabIndex = 0;
            this.lblItemCode.Text = "WO No:";
            // 
            // gbSearchOptions
            // 
            this.gbSearchOptions.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.gbSearchOptions.Controls.Add(this.label2);
            this.gbSearchOptions.Controls.Add(this.checkBox1);
            this.gbSearchOptions.Controls.Add(this.txtAuthorisedBy);
            this.gbSearchOptions.Controls.Add(this.label1);
            this.gbSearchOptions.Controls.Add(this.txtPreparedBy);
            this.gbSearchOptions.Controls.Add(this.lblIteType);
            this.gbSearchOptions.Controls.Add(this.txtProjectcode);
            this.gbSearchOptions.Controls.Add(this.lblItemDescription);
            this.gbSearchOptions.Controls.Add(this.txtDBOMNo);
            this.gbSearchOptions.Controls.Add(this.lblItemCode);
            this.gbSearchOptions.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.gbSearchOptions.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbSearchOptions.Location = new System.Drawing.Point(4, 3);
            this.gbSearchOptions.Name = "gbSearchOptions";
            this.gbSearchOptions.Size = new System.Drawing.Size(1294, 102);
            this.gbSearchOptions.TabIndex = 9;
            this.gbSearchOptions.TabStop = false;
            this.gbSearchOptions.Text = "Search Options";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Magenta;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(295, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 19);
            this.label2.TabIndex = 10;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(1192, 40);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(100, 23);
            this.checkBox1.TabIndex = 9;
            this.checkBox1.Text = "Active WO";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // txtDBOMNo
            // 
            this.txtDBOMNo.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDBOMNo.Location = new System.Drawing.Point(84, 40);
            this.txtDBOMNo.Name = "txtDBOMNo";
            this.txtDBOMNo.Size = new System.Drawing.Size(188, 26);
            this.txtDBOMNo.TabIndex = 1;
            this.txtDBOMNo.Enter += new System.EventHandler(this.txtDBOMNo_Enter);
            this.txtDBOMNo.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtDBOMNo_KeyUp);
            // 
            // dgpolist
            // 
            this.dgpolist.AllowUserToAddRows = false;
            this.dgpolist.AllowUserToDeleteRows = false;
            this.dgpolist.AllowUserToResizeRows = false;
            this.dgpolist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgpolist.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgpolist.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgpolist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgpolist.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DBOMNO,
            this.IPItemCode,
            this.IPOrderQty,
            this.OPItemCode,
            this.ItemDescription,
            this.OPOrderQty,
            this.Vendorcode,
            this.VendorName,
            this.UnitCost,
            this.TotalCost,
            this.JobIssueStatus,
            this.PreparedBy,
            this.AuthorisedBy,
            this.WOgeneratedDate,
            this.WOGeneratedBy,
            this.WOStatus,
            this.IPRemainingOrderQty,
            this.WorkDescription,
            this.OPRemainingQty,
            this.DGRefno});
            this.dgpolist.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgpolist.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgpolist.EnableHeadersVisualStyles = false;
            this.dgpolist.Location = new System.Drawing.Point(4, 111);
            this.dgpolist.MultiSelect = false;
            this.dgpolist.Name = "dgpolist";
            this.dgpolist.ReadOnly = true;
            this.dgpolist.RowHeadersVisible = false;
            this.dgpolist.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgpolist.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgpolist.Size = new System.Drawing.Size(1294, 559);
            this.dgpolist.TabIndex = 10;
            // 
            // DBOMNO
            // 
            this.DBOMNO.DataPropertyName = "WONumber";
            this.DBOMNO.HeaderText = "WO No";
            this.DBOMNO.Name = "DBOMNO";
            this.DBOMNO.ReadOnly = true;
            this.DBOMNO.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DBOMNO.Width = 65;
            // 
            // IPItemCode
            // 
            this.IPItemCode.DataPropertyName = "IPItemCode";
            this.IPItemCode.HeaderText = "IPItemCode";
            this.IPItemCode.Name = "IPItemCode";
            this.IPItemCode.ReadOnly = true;
            this.IPItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IPItemCode.Width = 93;
            // 
            // IPOrderQty
            // 
            this.IPOrderQty.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.IPOrderQty.DataPropertyName = "IPOrderQty";
            this.IPOrderQty.HeaderText = "IPOrderQty";
            this.IPOrderQty.Name = "IPOrderQty";
            this.IPOrderQty.ReadOnly = true;
            this.IPOrderQty.Width = 112;
            // 
            // OPItemCode
            // 
            this.OPItemCode.DataPropertyName = "OPItemCode";
            this.OPItemCode.HeaderText = "OPItemCode";
            this.OPItemCode.Name = "OPItemCode";
            this.OPItemCode.ReadOnly = true;
            this.OPItemCode.Width = 119;
            // 
            // ItemDescription
            // 
            this.ItemDescription.DataPropertyName = "ItemDescription";
            this.ItemDescription.HeaderText = "ItemDescription";
            this.ItemDescription.Name = "ItemDescription";
            this.ItemDescription.ReadOnly = true;
            this.ItemDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemDescription.Width = 123;
            // 
            // OPOrderQty
            // 
            this.OPOrderQty.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.OPOrderQty.DataPropertyName = "OPOrderQty";
            this.OPOrderQty.HeaderText = "OPOrderQty";
            this.OPOrderQty.Name = "OPOrderQty";
            this.OPOrderQty.ReadOnly = true;
            this.OPOrderQty.Width = 119;
            // 
            // Vendorcode
            // 
            this.Vendorcode.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.Vendorcode.DataPropertyName = "VendorCode";
            this.Vendorcode.HeaderText = "Vendor Code";
            this.Vendorcode.Name = "Vendorcode";
            this.Vendorcode.ReadOnly = true;
            this.Vendorcode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Vendorcode.Width = 102;
            // 
            // VendorName
            // 
            this.VendorName.DataPropertyName = "VendorName";
            this.VendorName.HeaderText = "Vendor Name";
            this.VendorName.Name = "VendorName";
            this.VendorName.ReadOnly = true;
            this.VendorName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.VendorName.Width = 108;
            // 
            // UnitCost
            // 
            this.UnitCost.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.UnitCost.DataPropertyName = "UnitCost";
            this.UnitCost.HeaderText = "Unit Cost";
            this.UnitCost.Name = "UnitCost";
            this.UnitCost.ReadOnly = true;
            this.UnitCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitCost.Width = 77;
            // 
            // TotalCost
            // 
            this.TotalCost.DataPropertyName = "TotalCost";
            this.TotalCost.HeaderText = "TotalCost";
            this.TotalCost.Name = "TotalCost";
            this.TotalCost.ReadOnly = true;
            this.TotalCost.Width = 97;
            // 
            // JobIssueStatus
            // 
            this.JobIssueStatus.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.JobIssueStatus.DataPropertyName = "JobIssueStatus";
            this.JobIssueStatus.HeaderText = "JobIssueStatus";
            this.JobIssueStatus.Name = "JobIssueStatus";
            this.JobIssueStatus.ReadOnly = true;
            this.JobIssueStatus.Width = 133;
            // 
            // PreparedBy
            // 
            this.PreparedBy.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.PreparedBy.DataPropertyName = "PreparedBy";
            this.PreparedBy.HeaderText = "Prepared By";
            this.PreparedBy.Name = "PreparedBy";
            this.PreparedBy.ReadOnly = true;
            this.PreparedBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PreparedBy.Width = 99;
            // 
            // AuthorisedBy
            // 
            this.AuthorisedBy.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.AuthorisedBy.DataPropertyName = "AuthorisedBy";
            this.AuthorisedBy.HeaderText = "Authorised By";
            this.AuthorisedBy.Name = "AuthorisedBy";
            this.AuthorisedBy.ReadOnly = true;
            this.AuthorisedBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.AuthorisedBy.Width = 112;
            // 
            // WOgeneratedDate
            // 
            this.WOgeneratedDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.WOgeneratedDate.DataPropertyName = "WOgeneratedDate";
            this.WOgeneratedDate.HeaderText = "WOgeneratedDate";
            this.WOgeneratedDate.Name = "WOgeneratedDate";
            this.WOgeneratedDate.ReadOnly = true;
            this.WOgeneratedDate.Width = 162;
            // 
            // WOGeneratedBy
            // 
            this.WOGeneratedBy.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.WOGeneratedBy.DataPropertyName = "WOGeneratedBy";
            this.WOGeneratedBy.HeaderText = "WOGeneratedBy";
            this.WOGeneratedBy.Name = "WOGeneratedBy";
            this.WOGeneratedBy.ReadOnly = true;
            this.WOGeneratedBy.Width = 149;
            // 
            // WOStatus
            // 
            this.WOStatus.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.WOStatus.DataPropertyName = "WOStatus";
            this.WOStatus.HeaderText = "WOStatus";
            this.WOStatus.Name = "WOStatus";
            this.WOStatus.ReadOnly = true;
            this.WOStatus.Width = 103;
            // 
            // IPRemainingOrderQty
            // 
            this.IPRemainingOrderQty.DataPropertyName = "IPRemainingOrderQty";
            this.IPRemainingOrderQty.HeaderText = "IPRemainingOrderQty";
            this.IPRemainingOrderQty.Name = "IPRemainingOrderQty";
            this.IPRemainingOrderQty.ReadOnly = true;
            this.IPRemainingOrderQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IPRemainingOrderQty.Width = 165;
            // 
            // WorkDescription
            // 
            this.WorkDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.WorkDescription.DataPropertyName = "WorkDescription";
            this.WorkDescription.HeaderText = "WorkDescription";
            this.WorkDescription.Name = "WorkDescription";
            this.WorkDescription.ReadOnly = true;
            this.WorkDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.WorkDescription.Width = 129;
            // 
            // OPRemainingQty
            // 
            this.OPRemainingQty.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.OPRemainingQty.DataPropertyName = "OPRemainingQty";
            this.OPRemainingQty.HeaderText = "OPRemainingQty";
            this.OPRemainingQty.Name = "OPRemainingQty";
            this.OPRemainingQty.ReadOnly = true;
            this.OPRemainingQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OPRemainingQty.Width = 132;
            // 
            // DGRefno
            // 
            this.DGRefno.DataPropertyName = "DGRefno";
            this.DGRefno.HeaderText = "DGRefno";
            this.DGRefno.Name = "DGRefno";
            this.DGRefno.ReadOnly = true;
            this.DGRefno.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DGRefno.Width = 75;
            // 
            // GINWOView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1304, 682);
            this.Controls.Add(this.gbSearchOptions);
            this.Controls.Add(this.dgpolist);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "GINWOView";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GIN WO View";
            this.Load += new System.EventHandler(this.GINWOView_Load);
            this.gbSearchOptions.ResumeLayout(false);
            this.gbSearchOptions.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgpolist)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtAuthorisedBy;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtPreparedBy;
        private System.Windows.Forms.Label lblIteType;
        private System.Windows.Forms.TextBox txtProjectcode;
        private System.Windows.Forms.Label lblItemDescription;
        private System.Windows.Forms.Label lblItemCode;
        private System.Windows.Forms.GroupBox gbSearchOptions;
        private System.Windows.Forms.TextBox txtDBOMNo;
        private System.Windows.Forms.DataGridView dgpolist;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.DataGridViewTextBoxColumn DBOMNO;
        private System.Windows.Forms.DataGridViewTextBoxColumn IPItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn IPOrderQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn OPItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn OPOrderQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn Vendorcode;
        private System.Windows.Forms.DataGridViewTextBoxColumn VendorName;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn TotalCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn JobIssueStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn PreparedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn AuthorisedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn WOgeneratedDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn WOGeneratedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn WOStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn IPRemainingOrderQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn WorkDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn OPRemainingQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn DGRefno;
    }
}