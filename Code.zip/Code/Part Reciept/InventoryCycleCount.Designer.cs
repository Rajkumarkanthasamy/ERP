﻿
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Part_Reciept
{
    partial class InventoryCycleCount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InventoryCycleCount));
            this.InventoryCycleCountdataGridView = new System.Windows.Forms.DataGridView();
            this.QRCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BatchCodes = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Locations = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GINQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IssuedQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BalanceQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.exportButton = new System.Windows.Forms.Button();
            this.LocationCheckBox = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.InventoryCycleCountdataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // InventoryCycleCountdataGridView
            // 
            this.InventoryCycleCountdataGridView.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.InventoryCycleCountdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.InventoryCycleCountdataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.QRCode,
            this.BatchCodes,
            this.Locations,
            this.ItemCode,
            this.Description,
            this.GINQty,
            this.IssuedQty,
            this.BalanceQty});
            this.InventoryCycleCountdataGridView.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.InventoryCycleCountdataGridView.Location = new System.Drawing.Point(-2, 90);
            this.InventoryCycleCountdataGridView.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.InventoryCycleCountdataGridView.Name = "InventoryCycleCountdataGridView";
            this.InventoryCycleCountdataGridView.RowHeadersWidth = 100;
            this.InventoryCycleCountdataGridView.RowTemplate.Height = 28;
            this.InventoryCycleCountdataGridView.Size = new System.Drawing.Size(1960, 982);
            this.InventoryCycleCountdataGridView.TabIndex = 219;
            // 
            // QRCode
            // 
            this.QRCode.HeaderText = "QR Code";
            this.QRCode.MinimumWidth = 8;
            this.QRCode.Name = "QRCode";
            this.QRCode.Visible = false;
            this.QRCode.Width = 111;
            // 
            // BatchCodes
            // 
            this.BatchCodes.HeaderText = "Batch Codes";
            this.BatchCodes.MinimumWidth = 8;
            this.BatchCodes.Name = "BatchCodes";
            this.BatchCodes.ReadOnly = true;
            this.BatchCodes.Width = 170;
            // 
            // Locations
            // 
            this.Locations.HeaderText = "Locations";
            this.Locations.MinimumWidth = 8;
            this.Locations.Name = "Locations";
            this.Locations.ReadOnly = true;
            this.Locations.Width = 170;
            // 
            // ItemCode
            // 
            this.ItemCode.HeaderText = "Item Code";
            this.ItemCode.MinimumWidth = 8;
            this.ItemCode.Name = "ItemCode";
            this.ItemCode.ReadOnly = true;
            this.ItemCode.Width = 170;
            // 
            // Description
            // 
            this.Description.HeaderText = "Description";
            this.Description.MinimumWidth = 8;
            this.Description.Name = "Description";
            this.Description.ReadOnly = true;
            this.Description.Width = 170;
            // 
            // GINQty
            // 
            this.GINQty.HeaderText = "GIN Qty";
            this.GINQty.MinimumWidth = 8;
            this.GINQty.Name = "GINQty";
            this.GINQty.ReadOnly = true;
            this.GINQty.Width = 110;
            // 
            // IssuedQty
            // 
            this.IssuedQty.HeaderText = "Issued Qty";
            this.IssuedQty.MinimumWidth = 8;
            this.IssuedQty.Name = "IssuedQty";
            this.IssuedQty.ReadOnly = true;
            this.IssuedQty.Width = 110;
            // 
            // BalanceQty
            // 
            this.BalanceQty.HeaderText = "Balance Qty";
            this.BalanceQty.MinimumWidth = 8;
            this.BalanceQty.Name = "BalanceQty";
            this.BalanceQty.ReadOnly = true;
            this.BalanceQty.Width = 110;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(173, 32);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(359, 26);
            this.textBox1.TabIndex = 220;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(72, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 29);
            this.label1.TabIndex = 221;
            this.label1.Text = "SCAN ";
            // 
            // exportButton
            // 
            this.exportButton.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.exportButton.Location = new System.Drawing.Point(1817, 16);
            this.exportButton.Name = "exportButton";
            this.exportButton.Size = new System.Drawing.Size(141, 52);
            this.exportButton.TabIndex = 222;
            this.exportButton.Text = "Export";
            this.exportButton.UseVisualStyleBackColor = true;
            this.exportButton.Click += new System.EventHandler(this.ExportToCsv);
            // 
            // LocationCheckBox
            // 
            this.LocationCheckBox.AutoSize = true;
            this.LocationCheckBox.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.LocationCheckBox.Location = new System.Drawing.Point(551, 34);
            this.LocationCheckBox.Name = "LocationCheckBox";
            this.LocationCheckBox.Size = new System.Drawing.Size(124, 33);
            this.LocationCheckBox.TabIndex = 223;
            this.LocationCheckBox.Text = "Location";
            this.LocationCheckBox.UseVisualStyleBackColor = true;
            // 
            // InventoryCycleCount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1969, 1084);
            this.Controls.Add(this.LocationCheckBox);
            this.Controls.Add(this.exportButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.InventoryCycleCountdataGridView);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "InventoryCycleCount";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "InventoryCycleCount";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMaterialLedger_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.InventoryCycleCountdataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView InventoryCycleCountdataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn QRCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn BatchCodes;
        private System.Windows.Forms.DataGridViewTextBoxColumn Locations;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn Description;
        private System.Windows.Forms.DataGridViewTextBoxColumn GINQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssuedQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn BalanceQty;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private Button exportButton;
        private CheckBox LocationCheckBox;
    }
}
