﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Part_Reciept
{
    public partial class ItemLocationUpdate : Form
    {
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        public ItemLocationUpdate()
        {
            InitializeComponent();
        }

        private void ItemLocationUpdate_Load(object sender, EventArgs e)
        {
            DataTable ItemCodeList = DAL.fnItemcodeList(1).Tables[0];
            foreach (DataRow dr in ItemCodeList.Rows)
            {
                if (!comboBoxItemCode.Items.Contains(dr["ItemCode"].ToString()))
                    comboBoxItemCode.Items.Add(dr["ItemCode"].ToString());
            }
        }
        private void ItemLocationUpdate_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            frmForm2 frm = new frmForm2();
            frm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string temStoreName = "";
            string temSubStoreName = "";

            if (!string.IsNullOrWhiteSpace(comboBoxSubStore.Text))
            {
                switch (comboBoxSubStore.Text)
                {
                    case "First Floor":
                        temSubStoreName = "F";
                        break;
                    case "Ground Floor":
                        temSubStoreName = "G";
                        break;
                    case "Old Store Area":
                        temSubStoreName = "OS";
                        break;
                    case "Actuator Area":
                        temSubStoreName = "AA";
                        break;
                    case "Control Panel Area":
                        temSubStoreName = "Control Panel Area";
                        break;
                    case "Grip Area":
                        temSubStoreName = "GA";
                        break;
                    case "Load Frame Area":
                        temSubStoreName = "LA";
                        break;
                    case "Manifold Area":
                        temSubStoreName = "MF";
                        break;
                    case "Power Pack Area":
                        temSubStoreName = "Power Pack Area";
                        break;
                }
            }



            if (!string.IsNullOrWhiteSpace(comboBoxStoreName.Text))//Kanban Shop Floor
            {
                switch (comboBoxStoreName.Text)
                {
                    case "Main Store":
                        temStoreName = "MS";
                        break;
                    case "De-Centralised":
                        temStoreName = "DC";
                        break;
                    case "Kanban Shop Floor":
                        temStoreName = "KSF";
                        break;
                }
            }
            DataTable ERPItemLocationTable = DAL.fnERPItemLocation(comboBoxItemCode.Text).Tables[0];
            DataTable ItemCodeDetails = DAL.fnPrintReceiptItemCodeList(comboBoxItemCode.Text, null).Tables[0];
            //MessageBox.Show(ItemCodeDetails.Rows.Count.ToString());
            string ItemDescription = ItemCodeDetails.Rows[0]["ItemDescription"].ToString();
            string oldLocation = ItemCodeDetails.Rows[0]["Location"].ToString();
            if (ERPItemLocationTable.Rows.Count > 0)
            {
                if (!string.IsNullOrWhiteSpace(comboBoxPosition.Text))
                {
                    string fnUpateItemLocationInAllTableStatus = DAL.fnUpateItemLocationInAllTable( $"{temStoreName}-{temSubStoreName}-{comboBoxRackNumber.Text}-{comboBoxLevel.Text}-{comboBoxPosition.Text}", comboBoxItemCode.Text);
                   // MessageBox.Show(fnUpateItemLocationInAllTableStatus);
                    string fnCreateERPItemLocationChangesLogstatus = DAL.fnCreateERPItemLocationChangesLog("NEW", comboBoxItemCode.Text, ItemDescription, oldLocation, $"{temStoreName}-{temSubStoreName}-{comboBoxRackNumber.Text}-{comboBoxLevel.Text}-{comboBoxPosition.Text}", login.GetUserDetails[2].ToString());
                }else if (comboBoxSubStore.Text == "Control Panel Area" || comboBoxSubStore.Text == "Power Pack Area")
                {
                    string fnUpateItemLocationInAllTableStatus = DAL.fnUpateItemLocationInAllTable($"{temStoreName}-{temSubStoreName}", comboBoxItemCode.Text);
                   // MessageBox.Show(fnUpateItemLocationInAllTableStatus);
                    string fnCreateERPItemLocationChangesLogstatus = DAL.fnCreateERPItemLocationChangesLog("NEW", comboBoxItemCode.Text, ItemDescription, oldLocation, $"{temStoreName}-{temSubStoreName}", login.GetUserDetails[2].ToString());
                }
                else if (!string.IsNullOrWhiteSpace(comboBoxLevel.Text))
                {
                    string fnUpateItemLocationInAllTableStatus = DAL.fnUpateItemLocationInAllTable( $"{temStoreName}-{temSubStoreName}-{comboBoxRackNumber.Text}-{comboBoxLevel.Text}", comboBoxItemCode.Text);
                   // MessageBox.Show(fnUpateItemLocationInAllTableStatus);
                    string fnCreateERPItemLocationChangesLogstatus = DAL.fnCreateERPItemLocationChangesLog("NEW", comboBoxItemCode.Text, ItemDescription, oldLocation, $"{temStoreName}-{temSubStoreName}-{comboBoxRackNumber.Text}-{comboBoxLevel.Text}", login.GetUserDetails[2].ToString());


                }
                else if (!string.IsNullOrWhiteSpace(comboBoxRackNumber.Text))
                {
                    string fnUpateItemLocationInAllTableStatus = DAL.fnUpateItemLocationInAllTable($"{temStoreName}-{temSubStoreName}-{comboBoxRackNumber.Text}", comboBoxItemCode.Text);
                    // MessageBox.Show(fnUpateItemLocationInAllTableStatus);
                    string fnCreateERPItemLocationChangesLogstatus = DAL.fnCreateERPItemLocationChangesLog("NEW", comboBoxItemCode.Text, ItemDescription, oldLocation, $"{temStoreName}-{temSubStoreName}-{comboBoxRackNumber.Text}", login.GetUserDetails[2].ToString());


                }
                else if (!string.IsNullOrWhiteSpace(temSubStoreName))
                {
                    string fnUpateItemLocationInAllTableStatus = DAL.fnUpateItemLocationInAllTable($"{temStoreName}-{temSubStoreName}", comboBoxItemCode.Text);
                    // MessageBox.Show(fnUpateItemLocationInAllTableStatus);
                    string fnCreateERPItemLocationChangesLogstatus = DAL.fnCreateERPItemLocationChangesLog("NEW", comboBoxItemCode.Text, ItemDescription, oldLocation, $"{temStoreName}-{temSubStoreName}", login.GetUserDetails[2].ToString());


                }
                else if (!string.IsNullOrWhiteSpace(temStoreName))
                {
                    string fnUpateItemLocationInAllTableStatus = DAL.fnUpateItemLocationInAllTable($"{temStoreName}", comboBoxItemCode.Text);
                    // MessageBox.Show(fnUpateItemLocationInAllTableStatus);
                    string fnCreateERPItemLocationChangesLogstatus = DAL.fnCreateERPItemLocationChangesLog("NEW", comboBoxItemCode.Text, ItemDescription, oldLocation, $"{temStoreName}", login.GetUserDetails[2].ToString());


                }

                comboBoxItemCode.Text = "";
                comboBoxStoreName.Text = "";
                comboBoxSubStore.Text = "";
                comboBoxRackNumber.Text = "";
                comboBoxLevel.Text = "";
                comboBoxPosition.Text = "";

                // MessageBox.Show("Location Create Successfully...", "Successfully");
            }
            else
            {
                MessageBox.Show("Location not presented please check with adimn...", "Location ERROR");
            }

        }

        private void comboBoxStoreName_SelectedIndexChanged(object sender, EventArgs e)
        {
            //MessageBox.Show(comboBoxStoreName.Text);

            if (comboBoxStoreName.Text == "De-Centralised")
            {
                comboBoxSubStore.Items.Clear();
                this.comboBoxSubStore.Items.AddRange(new object[] {
            "Actuator Area",
            "Control Panel Area",
            "Grip Area",
            "Load Frame Area",
            "Manifold Area",
            "Power Pack Area"});
            }
            else
            {
                comboBoxSubStore.Items.Clear();
            this.comboBoxSubStore.Items.AddRange(new object[] {
            "First Floor",
            "Ground Floor",
            "Old Store Area"});
            }
        }

        private void comboBoxSubStore_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBoxSubStore.Text == "Control Panel Area" || comboBoxSubStore.Text == "Power Pack Area")
            {
                comboBoxRackNumber.Enabled = false;
                comboBoxLevel.Enabled = false;
                comboBoxPosition.Enabled = false;
            }
            else
            {
                comboBoxRackNumber.Enabled = true;
                comboBoxLevel.Enabled = true;
                comboBoxPosition.Enabled = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            comboBoxItemCode.Text = "";
            comboBoxStoreName.Text = "";
            comboBoxSubStore.Text = "";
            comboBoxRackNumber.Text = "";
            comboBoxLevel.Text = "";
            comboBoxPosition.Text = "";
        }
    }
}
