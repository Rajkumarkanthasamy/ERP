﻿using Erp_Project_With_Buttons.Purchase_Order;
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Part_Reciept
{
    public partial class GINWOView : Form
    {
        public GINWOView()
        {
            InitializeComponent();
        }
        DataTable dtPolist = new DataTable();
        DataTable dtProjectList = new DataTable();
        DataAccessLayer DAL = new DataAccessLayer();
        DataView dvPOViewList = new DataView();
        BindingSource bsItemList = new BindingSource();
        Login.frmLoginForm login = new Login.frmLoginForm();
        Purchase_Order.PurchaseOrder PurchaseOrderForm = new PurchaseOrder();

        private void fnRowFilter(uint uSearchOption, string sRowFilter)    //filter the Item list depends upon the user inpts
        {
            DataView dvPOViewList = new DataView(dtPolist);
            switch (uSearchOption)
            {
                case Global.uITEM_CODE_SEARCH:
                    {
                        dvPOViewList.RowFilter = "WONumber like '" + sRowFilter + "%'";
                        dgpolist.DataSource = dvPOViewList.ToTable();
                        break;
                    }
                case Global.uITEM_DESCRIPTION_SEARCH:
                    {
                        dvPOViewList.RowFilter = "GINNo like '" + sRowFilter + "%'";
                        dgpolist.DataSource = dvPOViewList.ToTable();
                        break;
                    }
                case Global.uITEM_TYPE_SEARCH:
                    {
                        dvPOViewList.RowFilter = "VendorName like '" + sRowFilter + "%'";
                        dgpolist.DataSource = dvPOViewList.ToTable();
                        break;
                    }
                case Global.uITEM_STATUS_SEARCH:
                    {
                        dvPOViewList.RowFilter = "AuthoriedBy like '" + sRowFilter + "%'";
                        dgpolist.DataSource = dvPOViewList.ToTable();
                        break;
                    }

            }
        }
        private void GINWOView_Load(object sender, EventArgs e)
        {
            dtPolist = DAL.fnGINWOlistforview(null).Tables[0];
            bsItemList.DataSource = dtPolist;
            dgpolist.AutoGenerateColumns = false;
            dgpolist.DataSource = bsItemList;
            label2.Text = "WO Status Closed";
            dgpolist.ForeColor = Color.Black;
            foreach (DataGridViewRow dgvrow in dgpolist.Rows)
            {
                dgpolist.DefaultCellStyle.BackColor = Color.LightGreen;
            }
        }

        private void txtDBOMNo_Enter(object sender, EventArgs e)
        {
            txtDBOMNo.Text = string.Empty;
            dgpolist.DataSource = bsItemList;
        }

        private void txtProjectcode_Enter(object sender, EventArgs e)
        {
            txtProjectcode.Text = string.Empty;
            dgpolist.DataSource = bsItemList;
        }

        private void txtPreparedBy_Enter(object sender, EventArgs e)
        {
            txtPreparedBy.Text = string.Empty;
            dgpolist.DataSource = bsItemList;
        }

        private void txtAuthorisedBy_Enter(object sender, EventArgs e)
        {
            txtAuthorisedBy.Text = string.Empty;
            dgpolist.DataSource = bsItemList;
        }

        private void txtDBOMNo_KeyUp(object sender, KeyEventArgs e)
        {
            fnRowFilter(0, txtDBOMNo.Text); 
        }

        private void txtProjectcode_KeyUp(object sender, KeyEventArgs e)
        {
            fnRowFilter(1, txtProjectcode.Text); 
        }

        private void txtPreparedBy_KeyUp(object sender, KeyEventArgs e)
        {
            fnRowFilter(2, txtPreparedBy.Text);
        }

        private void txtAuthorisedBy_KeyUp(object sender, KeyEventArgs e)
        {
            fnRowFilter(3, txtAuthorisedBy.Text); 
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                string status = "Closed";
                dtPolist = DAL.fnGINWOlistforview(status).Tables[0];

                bsItemList.DataSource = dtPolist;

                dgpolist.AutoGenerateColumns = false;

                dgpolist.DataSource = bsItemList;
                 dgpolist.ForeColor = Color.Black;  
                label2.Text = "WO Status Open";
                foreach (DataGridViewRow dgvrow in dgpolist.Rows)
                {
                    dgpolist.DefaultCellStyle.BackColor = Color.LightPink;
                }
            }
            else
            {
                dtPolist = DAL.fnGINWOlistforview(null).Tables[0];

                bsItemList.DataSource = dtPolist;

                dgpolist.AutoGenerateColumns = false;

                dgpolist.DataSource = bsItemList;
                dgpolist.ForeColor = Color.Black;  
                label2.Text = "WO Status Closed";
                foreach (DataGridViewRow dgvrow in dgpolist.Rows)
                {
                    dgpolist.DefaultCellStyle.BackColor = Color.LightGreen;
                }
            }
        }
    }
}
