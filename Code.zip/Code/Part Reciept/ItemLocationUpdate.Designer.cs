﻿namespace Erp_Project_With_Buttons.Part_Reciept
{
    partial class ItemLocationUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ItemLocationUpdate));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.comboBoxItemCode = new System.Windows.Forms.ComboBox();
            this.comboBoxStoreName = new System.Windows.Forms.ComboBox();
            this.comboBoxSubStore = new System.Windows.Forms.ComboBox();
            this.comboBoxRackNumber = new System.Windows.Forms.ComboBox();
            this.comboBoxLevel = new System.Windows.Forms.ComboBox();
            this.comboBoxPosition = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(22, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(379, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "*Update item location based on the selected Item Code*";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(35, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Item Code";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(35, 132);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Store Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(35, 175);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Sub Store";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(35, 216);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "Rack Number";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(35, 261);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 17);
            this.label6.TabIndex = 5;
            this.label6.Text = "Level";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(35, 305);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 17);
            this.label7.TabIndex = 6;
            this.label7.Text = "Position";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold);
            this.button1.Location = new System.Drawing.Point(38, 359);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(81, 36);
            this.button1.TabIndex = 7;
            this.button1.Text = "Clear";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold);
            this.button2.Location = new System.Drawing.Point(136, 359);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(81, 36);
            this.button2.TabIndex = 8;
            this.button2.Text = "Update";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // comboBoxItemCode
            // 
            this.comboBoxItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.comboBoxItemCode.FormattingEnabled = true;
            this.comboBoxItemCode.IntegralHeight = false;
            this.comboBoxItemCode.Location = new System.Drawing.Point(147, 84);
            this.comboBoxItemCode.Name = "comboBoxItemCode";
            this.comboBoxItemCode.Size = new System.Drawing.Size(219, 27);
            this.comboBoxItemCode.TabIndex = 9;
            // 
            // comboBoxStoreName
            // 
            this.comboBoxStoreName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.comboBoxStoreName.FormattingEnabled = true;
            this.comboBoxStoreName.IntegralHeight = false;
            this.comboBoxStoreName.Items.AddRange(new object[] {
            "Main Store",
            "De-Centralised",
            "Kanban Shop Floor"});
            this.comboBoxStoreName.Location = new System.Drawing.Point(147, 132);
            this.comboBoxStoreName.Name = "comboBoxStoreName";
            this.comboBoxStoreName.Size = new System.Drawing.Size(219, 27);
            this.comboBoxStoreName.TabIndex = 10;
            this.comboBoxStoreName.SelectedIndexChanged += new System.EventHandler(this.comboBoxStoreName_SelectedIndexChanged);
            // 
            // comboBoxSubStore
            // 
            this.comboBoxSubStore.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.comboBoxSubStore.FormattingEnabled = true;
            this.comboBoxSubStore.IntegralHeight = false;
            this.comboBoxSubStore.Items.AddRange(new object[] {
            "First Floor",
            "Ground Floor",
            "Old Store Area"});
            this.comboBoxSubStore.Location = new System.Drawing.Point(147, 175);
            this.comboBoxSubStore.Name = "comboBoxSubStore";
            this.comboBoxSubStore.Size = new System.Drawing.Size(219, 27);
            this.comboBoxSubStore.TabIndex = 11;
            this.comboBoxSubStore.SelectedIndexChanged += new System.EventHandler(this.comboBoxSubStore_SelectedIndexChanged);
            // 
            // comboBoxRackNumber
            // 
            this.comboBoxRackNumber.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.comboBoxRackNumber.FormattingEnabled = true;
            this.comboBoxRackNumber.IntegralHeight = false;
            this.comboBoxRackNumber.Items.AddRange(new object[] {
            "C1 Cupboard",
            "C2 Cupboard",
            "Cantilever",
            "Pallet",
            "CL1",
            "CL2",
            "CH",
            "R1",
            "R2",
            "R3",
            "R4",
            "R5",
            "R6",
            "R7",
            "R8",
            "R9",
            "R10",
            "R11",
            "R12",
            "R13",
            "R14"});
            this.comboBoxRackNumber.Location = new System.Drawing.Point(147, 216);
            this.comboBoxRackNumber.Name = "comboBoxRackNumber";
            this.comboBoxRackNumber.Size = new System.Drawing.Size(219, 27);
            this.comboBoxRackNumber.TabIndex = 12;
            // 
            // comboBoxLevel
            // 
            this.comboBoxLevel.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.comboBoxLevel.FormattingEnabled = true;
            this.comboBoxLevel.IntegralHeight = false;
            this.comboBoxLevel.Items.AddRange(new object[] {
            "L1",
            "L2",
            "L3",
            "L4",
            "Bin"});
            this.comboBoxLevel.Location = new System.Drawing.Point(147, 261);
            this.comboBoxLevel.Name = "comboBoxLevel";
            this.comboBoxLevel.Size = new System.Drawing.Size(219, 27);
            this.comboBoxLevel.TabIndex = 13;
            // 
            // comboBoxPosition
            // 
            this.comboBoxPosition.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.comboBoxPosition.FormattingEnabled = true;
            this.comboBoxPosition.IntegralHeight = false;
            this.comboBoxPosition.Items.AddRange(new object[] {
            "P1",
            "P2"});
            this.comboBoxPosition.Location = new System.Drawing.Point(147, 301);
            this.comboBoxPosition.Name = "comboBoxPosition";
            this.comboBoxPosition.Size = new System.Drawing.Size(219, 27);
            this.comboBoxPosition.TabIndex = 14;
            // 
            // ItemLocationUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1347, 706);
            this.Controls.Add(this.comboBoxPosition);
            this.Controls.Add(this.comboBoxLevel);
            this.Controls.Add(this.comboBoxRackNumber);
            this.Controls.Add(this.comboBoxSubStore);
            this.Controls.Add(this.comboBoxStoreName);
            this.Controls.Add(this.comboBoxItemCode);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "ItemLocationUpdate";
            this.Text = "Location Update";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ItemLocationUpdate_FormClosing);
            this.Load += new System.EventHandler(this.ItemLocationUpdate_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox comboBoxItemCode;
        private System.Windows.Forms.ComboBox comboBoxStoreName;
        private System.Windows.Forms.ComboBox comboBoxSubStore;
        private System.Windows.Forms.ComboBox comboBoxRackNumber;
        private System.Windows.Forms.ComboBox comboBoxLevel;
        private System.Windows.Forms.ComboBox comboBoxPosition;
    }
}