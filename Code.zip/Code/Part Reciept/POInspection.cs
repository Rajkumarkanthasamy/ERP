﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Windows.Forms;
using Outlook = Microsoft.Office.Interop.Outlook;

namespace Erp_Project_With_Buttons.Part_Reciept
{
    public partial class POInspection : Form
    {
        public POInspection()
        {
            InitializeComponent();
        }
        Login.frmLoginForm login = new Login.frmLoginForm();
        DataTable dtlogindetails = new DataTable();
        DataTable dtPurchaseOrderList = new DataTable();
        frmForm2 frm = new frmForm2();
        Global GLobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        DataTable DTPOItemList = new DataTable();
        DataTable dtWOList = new DataTable();
        DataTable DTWOnumber = new DataTable();
        DataTable dtItemList = new DataTable();
        DataTable dtsCCUsers = new DataTable();
        private void chkGINPO_CheckedChanged(object sender, EventArgs e)
        {
            if (chkGINPO.CheckState == CheckState.Checked)
            {
                foreach (Control lbl in this.pnPOWO.Controls)
                {
                    if (lbl.GetType() == typeof(Label) && ((lbl.Name == "lblcustomername") || (lbl.Name == "txtinvoiceno") || (lbl.Name == "lblprojcode") || (lbl.Name == "lblprojectdesc") || (lbl.Name == "txtVendorcode")
                        || (lbl.Name == "lblVendor") || (lbl.Name == "lblGinno") || (lbl.Name == "lblpowoby")))

                        lbl.ResetText();
                }
                lblwonum.Visible = false;
                this.chkGINWO.Checked = false;
                cmbPonumber.Items.Clear();
                cmbPonumber.ResetText();
                dtPurchaseOrderList = DAL.purchaseOrderList(null, "PurchaseOrder").Tables[0];
                DataView dvPO = dtPurchaseOrderList.DefaultView;
                dvPO.Sort = "DBOMNo desc";
                dtPurchaseOrderList = dvPO.ToTable();
                foreach (DataRow dr in dtPurchaseOrderList.Rows)
                {
                    if (!cmbPonumber.Items.Contains(dr["DBOMNo"].ToString()))
                        cmbPonumber.Items.Add(dr["DBOMNo"].ToString());
                }
            }
            else
            {
                chkGINWO.Checked = true;
            }
        }

        private void chkGINWO_CheckedChanged(object sender, EventArgs e)
        {
            if (chkGINWO.CheckState == CheckState.Checked)
            {
                foreach (Control lbl in this.pnPOWO.Controls)
                {
                    if (lbl.GetType() == typeof(Label) && ((lbl.Name == "lblcustomername") || (lbl.Name == "txtinvoiceno") || (lbl.Name == "lblprojcode") || (lbl.Name == "lblprojectdesc") || (lbl.Name == "txtVendorcode")
                        || (lbl.Name == "lblVendor") || (lbl.Name == "lblGinno") || (lbl.Name == "lblpowoby")))

                        lbl.ResetText();
                }
                lblwonum.Visible = true;
                chkGINPO.Checked = false;
                dtWOList = DAL.WoOrderDataset(null).Tables[0];

                cmbPonumber.Items.Clear();
                cmbPonumber.ResetText();

                foreach (DataRow dr in dtWOList.Rows)
                {
                    if (!cmbPonumber.Items.Contains(dr["WONumber"].ToString()))
                        cmbPonumber.Items.Add(dr["WONumber"].ToString());
                }
            }
            else
            {
                chkGINPO.Checked = true;
            }
        }

        string sRemarks = "";
        private void cmbPonumber_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstusers.Items.Clear();
            sRemarks = "";

            if (chkGINPO.CheckState == CheckState.Checked)
            {
                dtsCCUsers = DAL.POWOCCList(1, cmbPonumber.Text).Tables[0];
                dgvCopyEmail.DataSource = null;
                dgvCopyEmail.Visible = true;
                if (dtsCCUsers.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtsCCUsers.Rows[0]["emailid"].ToString()) && !lstusers.Items.Contains(dtsCCUsers.Rows[0]["emailid"].ToString()))
                    {
                        lstusers.Items.Add(dtsCCUsers.Rows[0]["emailid"].ToString());
                    }
                    if (!string.IsNullOrEmpty(dtsCCUsers.Rows[0]["emailid1"].ToString()) && !lstusers.Items.Contains(dtsCCUsers.Rows[0]["emailid1"].ToString()))
                    {
                        lstusers.Items.Add(dtsCCUsers.Rows[0]["emailid1"].ToString());
                    }

                    lstusers.Items.Add("thilak_jaganath@instron.com");
                    //lstusers.Items.Add("Muthuramalingam_R@instron.com");
                   // lstusers.Items.Add("pavan@biss.in");
                }

                DTPOItemList = DAL.purchaseOrderList(cmbPonumber.Text, null).Tables[0];

                if (DTPOItemList.Rows.Count > 0)
                {
                    txtVendorcode.Text = DTPOItemList.Rows[0]["VendorCode"].ToString() +" , "+ DTPOItemList.Rows[0]["GSTCode"].ToString();
                    lblVendor.Text = DTPOItemList.Rows[0]["VendorName"].ToString();
                    lblprojcode.Text = DTPOItemList.Rows[0]["ProjectCode"].ToString();
                    lblprojectdesc.Text = DTPOItemList.Rows[0]["ProjectDescription"].ToString();
                    lblpowoby.Text = DTPOItemList.Rows[0]["PreparedBy"].ToString();
                    lblcustomername.Text = DTPOItemList.Rows[0]["Customer"].ToString();
                  //  lblGSTCode.Text = DTPOItemList.Rows[0]["GSTCode"].ToString();
                    sRemarks = "User Remarks : " + DTPOItemList.Rows[0]["Remarks"].ToString() + "<br />PM/MH Remarks : " + DTPOItemList.Rows[0]["PMMHRemarks"].ToString() + "<br />PC Remarks : " + DTPOItemList.Rows[0]["PCRemarks"].ToString();
                    

                    foreach (DataRow DR in DTPOItemList.Rows)
                    {
                        DTPOItemList.Rows[DTPOItemList.Rows.IndexOf(DR)]["RequariedQty"] = DTPOItemList.Rows[DTPOItemList.Rows.IndexOf(DR)]["RemainingQty"].ToString();
                    }
                  //  foreach(DTPOItemList

                    dgvCopyEmail.AutoGenerateColumns = false;
                    dgvCopyEmail.DataSource = DTPOItemList;
                }
            }
            else if (chkGINWO.CheckState == CheckState.Checked)
            {
                dtsCCUsers = DAL.POWOCCList(2, cmbPonumber.Text).Tables[0];
                dgvCopyEmail.DataSource = null;
                dgvCopyEmail.Visible = true;
                if (dtsCCUsers.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtsCCUsers.Rows[0]["emailid"].ToString()) && !lstusers.Items.Contains(dtsCCUsers.Rows[0]["emailid"].ToString()))
                    {
                        lstusers.Items.Add(dtsCCUsers.Rows[0]["emailid"].ToString());
                    }
                    if (!string.IsNullOrEmpty(dtsCCUsers.Rows[0]["emailid1"].ToString()) && !lstusers.Items.Contains(dtsCCUsers.Rows[0]["emailid1"].ToString()))
                    {
                        lstusers.Items.Add(dtsCCUsers.Rows[0]["emailid1"].ToString());
                    }
                    lstusers.Items.Add("thilak_jaganath@instron.com");
                   //lstusers.Items.Add("Muthuramalingam_R@instron.com");
                    // lstusers.Items.Add("pavan@biss.in");
                }

                DTWOnumber = DAL.WoOrderDataset(cmbPonumber.Text).Tables[0];
                if (DTWOnumber.Rows.Count > 0)
                {
                    lblprojcode.Text = DTWOnumber.Rows[0]["ProjectCode"].ToString();
                    lblprojectdesc.Text = DTWOnumber.Rows[0]["ProjectDescription"].ToString();
                    lblcustomername.Text = DTWOnumber.Rows[0]["Customer"].ToString();
                    txtVendorcode.Text = DTWOnumber.Rows[0]["VendorCode"].ToString()+" , "+ DTWOnumber.Rows[0]["GSTCode"].ToString();
                    lblVendor.Text = DTWOnumber.Rows[0]["VendorName"].ToString();
                    lblpowoby.Text = DTWOnumber.Rows[0]["PreparedBy"].ToString();
                   // lblGSTCode.Text = DTWOnumber.Rows[0]["GSTCode"].ToString();


                    foreach (DataRow DR in DTWOnumber.Rows)
                    {
                        DTWOnumber.Rows[DTWOnumber.Rows.IndexOf(DR)]["RequariedQty"] = DTWOnumber.Rows[DTWOnumber.Rows.IndexOf(DR)]["RemainingQty"].ToString();
                    }

                  //  DTWOnumber.Columns["RecieveQuantity"].ColumnName = "RequariedQty";
                    dgvCopyEmail.AutoGenerateColumns = false;
                    dgvCopyEmail.DataSource = DTWOnumber;
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {        
                try
                {
                    fnAlertMail(lblpowoby.Text, lstusers);

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
        }

        public string GetTableFromDataGridWorkOrder()
        {
            StringBuilder strTable = new StringBuilder();
            try
            {
                strTable.Append("<table border='1' cellpadding='0' cellspacing='0'>");
                strTable.Append("<tr>");
                // dgvPOItemList.Columns[0].Visible = false;
                //Create Header Row for Table
                foreach (DataGridViewColumn col in dgvCopyEmail.Columns)
                {
                    strTable.AppendFormat("<th bgcolor='Gainsboro'>{0}  </th>", col.HeaderText);
                }
                strTable.Append("</tr>");
                //Create Table Rows
                for (int i = 0; i < dgvCopyEmail.Rows.Count; i++)
                {
                    strTable.Append("<tr>");
                    foreach (DataGridViewCell cell in dgvCopyEmail.Rows[i].Cells)
                    {
                        if (cell.Value != null)
                        {
                            strTable.AppendLine("<td align='center' valign='middle' bgcolor='AliceBlue'>" + cell.Value.ToString() + "</td>");
                            // strTable.AppendFormat("<td>{0}</td>", cell.Value.ToString());
                        }

                    }
                    strTable.Append("</tr>");
                }
                strTable.Append("</table>");
                //dgvPOItemList.Columns[0].Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            return strTable.ToString();
        }






        #region Email Alert

        public void fnAlertMail(string sUser, ListBox sCC)
        {
            try
            {
                DataTable dtlogindetails = DAL.fnloginemail(sUser).Tables[0];

                if (dtlogindetails.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
                    {
                        Outlook.Application oApp = new Outlook.Application();
                        Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                        oMsg.Subject = "Inspection of items for PO/WO No : " + cmbPonumber.Text + "";

                        //oMsg.IsBodyHtml = true;
                        oMsg.HTMLBody = " Dear " + lblpowoby.Text.ToUpper() + ",<br /> Please visit the stores at the earliest for inspection of recieved items from vendor '" + lblVendor.Text + "'. <br /> <br /> " + sRemarks + "<br /><br />";
                        oMsg.HTMLBody += GetTableFromDataGridWorkOrder();

                        oMsg.HTMLBody += "<br /><br /><br /><br /> <b>**** This is an auto generated E-mail. Please do not reply. ****</b>";
                        //oMsg.HTMLBody = " Dear " + sUser.ToUpper() + ", <br /><br /> Purchase Order ' " + cmbPONO.Text + " ' sent for approval.<br /> Remarks : " + sRemarks + " <br /> <br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /> ** THIS IS AN AUTO GENARATED EMAIL. PLEASE DO NOT REPLY **";
                        // Add a recipient.
                        Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                        oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                        oRecips.ResolveAll();

                        if (sCC.Items.Count > 0)
                        {
                            Outlook.Recipient oRecip;
                            List<string> sCCRecipsList = new List<string>();
                            foreach (string tempTO in sCC.Items)
                            {
                                if (tempTO != null)
                                    sCCRecipsList.Add(tempTO);
                            }
                            foreach (string t in sCCRecipsList)
                            {

                                oRecip = (Outlook.Recipient)oRecips.Add(t);
                                oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                                oRecip.Resolve();
                            }
                            oMsg.Send();
                            oRecip = null;
                        }
                        else
                        {
                            // Send.
                            oMsg.Send();
                            // Clean up.
                            oRecips = null;
                        }
                        oMsg = null;
                        oApp = null;
                        MessageBox.Show("Mail sent to the user '" + sUser + "' successfully!", "E-mail Sent", 0, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        #endregion

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm.Show();
        }

        private void POInspection_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            frm.Show();
        }

        double oldvalue;
        private void dgvCopyEmail_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgvCopyEmail.CurrentCell.OwningColumn.Name == "RemainingQty")
            {
                oldvalue = Convert.ToDouble(dgvCopyEmail.CurrentCell.Value);
            }
        }

        private void dgvCopyEmail_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
            }
        }
        private void Control_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                e.Handled = true;
            }
        }

        private void dgvCopyEmail_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if ((dgvCopyEmail.CurrentCell.Value) != null)// && 
            {
                if (!string.IsNullOrEmpty(dgvCopyEmail.CurrentCell.Value.ToString()))
                {
                    if (dgvCopyEmail.CurrentCell.Value.ToString() != "." && Convert.ToDouble(dgvCopyEmail.CurrentCell.Value.ToString()) != 0.0)
                    {
                        if (Convert.ToDouble(dgvCopyEmail.CurrentCell.Value) > Convert.ToDouble(dgvCopyEmail.CurrentRow.Cells["POQty"].Value))
                        {
                            MessageBox.Show("Quanity should not be more than PO/WO quantity!", "Error", 0, MessageBoxIcon.Error);
                            dgvCopyEmail.CurrentCell.Value = oldvalue;                           
                        }
                    }
                    else
                    {                       
                        MessageBox.Show("Quanity should not be Zero. Equal or less than PO/WO quantity!", "Error", 0, MessageBoxIcon.Error);
                        dgvCopyEmail.CurrentCell.Value = oldvalue;
                    }
                }
            }
        }

        private void POInspection_Load(object sender, EventArgs e)
        {
            chkGINPO.CheckState = CheckState.Checked;
        }

        private void dgvCopyEmail_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (dgvCopyEmail.Rows.Count > 0)
                {
                    dgvCopyEmail.Rows.RemoveAt(dgvCopyEmail.Rows.IndexOf(dgvCopyEmail.CurrentRow));
                }
            }
        }
    }
}
