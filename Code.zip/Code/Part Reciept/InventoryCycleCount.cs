﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Part_Reciept
{
    public partial class InventoryCycleCount : Form
    {
        #region fields
        private readonly DataAccessLayer DAL = new DataAccessLayer();
        private readonly Global GLobalClass = new Global();   // kept – you may use it later
        private readonly Login.frmLoginForm login = new Login.frmLoginForm();

        private DataTable _gridData;
        private Timer _debounceTimer;

        private enum DuplicatePolicy { Skip, Update, Append }
        private DuplicatePolicy _duplicatePolicy = DuplicatePolicy.Append;
        #endregion

        public InventoryCycleCount()
        {
            InitializeComponent();

            Load += InventoryCycleCount_Load;
            Activated += InventoryCycleCount_Activated;

            textBox1.KeyDown += textBox1_KeyDown;
            textBox1.Leave += textBox1_Leave;
            textBox1.TextChanged += textBox1_TextChanged;

            KeyPreview = true;

            InventoryCycleCountdataGridView.CellValueChanged += InventoryCycleCountdataGridView_CellValueChanged;
        }

        #region form life-cycle
        private void InventoryCycleCount_Load(object sender, EventArgs e)
        {
            InitGrid();
            InitDebounce();
            textBox1.Focus();
        }

        private void InventoryCycleCount_Activated(object sender, EventArgs e)
        {
            textBox1.Focus();
            textBox1.SelectAll();
        }
        #endregion

        #region grid
        private void InitGrid()
        {
            _gridData = new DataTable();
            _gridData.Columns.Add("QRCode", typeof(string));  // <-- MUST be string
            _gridData.Columns.Add("BatchCodes", typeof(string));
            _gridData.Columns.Add("Locations", typeof(string));
            _gridData.Columns.Add("ItemCode", typeof(string));
            _gridData.Columns.Add("Description", typeof(string));
            _gridData.Columns.Add("GINQty", typeof(int));
            _gridData.Columns.Add("IssuedQty", typeof(int));
            _gridData.Columns.Add("BalanceQty", typeof(int));

            InventoryCycleCountdataGridView.AutoGenerateColumns = false;
            InventoryCycleCountdataGridView.DataSource = _gridData;

            // map designer columns
            QRCode.DataPropertyName = "QRCode";
            BatchCodes.DataPropertyName = "BatchCodes";
            Locations.DataPropertyName = "Locations";
            ItemCode.DataPropertyName = "ItemCode";
            Description.DataPropertyName = "Description";
            GINQty.DataPropertyName = "GINQty";
            IssuedQty.DataPropertyName = "IssuedQty";
            BalanceQty.DataPropertyName = "BalanceQty";

            // right-align numbers
            foreach (var col in new[] { GINQty, IssuedQty, BalanceQty })
                col.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
        }
        #endregion

        #region debounce timer (for scanners without terminator)
        private void InitDebounce()
        {
            _debounceTimer = new Timer { Interval = 150 };
            _debounceTimer.Tick += (s, e) =>
            {
                _debounceTimer.Stop();
                string raw = textBox1.Text.Trim();
                if (raw.Length >= 4) CommitScan(raw);
            };
        }
        #endregion

        #region scan input
        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Tab)
            {
                e.SuppressKeyPress = true;
                _debounceTimer.Stop();          // cancel pending debounce
                CommitScan(textBox1.Text.Trim());
            }
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            string raw = textBox1.Text.Trim();
            if (raw.Length >= 4) CommitScan(raw);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            _debounceTimer.Stop();
            _debounceTimer.Start();
        }
        #endregion

        #region scan processing
        private void CommitScan(string raw)
        {
            if (string.IsNullOrWhiteSpace(raw)) return;

            // remove common 12-char suffix emitted by some scanners
          string qr = LocationCheckBox.Checked ? raw :  raw.Substring(0, raw.Length - 8);

            TryAddRowFromScan(qr);

            // user feedback
            new ToolTip().Show(qr, this, Width / 2, Height / 2, 2000);
            System.Media.SystemSounds.Asterisk.Play();

            textBox1.Clear();
            textBox1.Focus();
        }

        private void TryAddRowFromScan(string qrCode)
        {
            try
            {
                DataSet ds = LocationCheckBox.Checked
                           ? DAL.getItemBatchLocationBased(qrCode)
                           : DAL.getItemBatchLocation(qrCode);
                //MessageBox.Show(ds?.Tables.Count.ToString());
                DataTable dt = ds?.Tables.Count > 0 ? ds.Tables[0] : null;
                if (dt == null || dt.Rows.Count == 0) return;

                foreach (DataRow r in dt.Rows)
                {
                    string batch = r["BatchCode"].ToString();
                    string loc = r["ItemLocation"].ToString();
                    string item = r["ItemCode"].ToString();
                    string desc = r["ItemDescription"].ToString();
                    int gin = SafeInt(r["ReceivedQtY"]);
                    int issued = SafeInt(r["IndentQty"]);
                    int rem = SafeInt(r["RemainingQty"]);

                    AddOrUpdateRow(qrCode, batch, loc, item, desc, gin, issued, rem);
                }
            }
            catch (Exception ex)
            {
                System.Media.SystemSounds.Hand.Play();
                MessageBox.Show($"Scan failed for '{qrCode}'.\n{ex.Message}", "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AddOrUpdateRow(string qr, string batch, string loc, string item,
                                    string desc, int gin, int issued, int remQty)
        {
            int balance = remQty;

            var row = _gridData.AsEnumerable().FirstOrDefault(r =>
                        string.Equals(r.Field<string>("QRCode"), qr, StringComparison.OrdinalIgnoreCase) &&
                        string.Equals(r.Field<string>("BatchCodes"), batch, StringComparison.OrdinalIgnoreCase) &&
                        string.Equals(r.Field<string>("Locations"), loc, StringComparison.OrdinalIgnoreCase) &&
                        string.Equals(r.Field<string>("ItemCode"), item, StringComparison.OrdinalIgnoreCase));

            if (row == null)
            {
                _gridData.Rows.Add(qr, batch, loc, item, desc, gin, issued, balance);
                return;
            }

            switch (_duplicatePolicy)
            {
                case DuplicatePolicy.Skip:
                    return;

                case DuplicatePolicy.Update:
                    row["Description"] = desc;
                    row["GINQty"] = gin;
                    row["IssuedQty"] = issued;
                    row["BalanceQty"] = balance;
                    break;

                case DuplicatePolicy.Append:
                    int oldGin = SafeInt(row["GINQty"]);
                    int oldIssued = SafeInt(row["IssuedQty"]);
                    row["GINQty"] = oldGin + gin;
                    row["IssuedQty"] = oldIssued + issued;
                    row["BalanceQty"] = SafeInt(row["GINQty"]) - SafeInt(row["IssuedQty"]);
                    break;
            }
        }

        private static int SafeInt(object value)
        {
            if (value == null || value == DBNull.Value) return 0;
            int.TryParse(value.ToString(), out int ret);
            return ret;
        }
        #endregion

        #region grid editing
        private void InventoryCycleCountdataGridView_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            if (e.ColumnIndex == GINQty.Index || e.ColumnIndex == IssuedQty.Index)
            {
                var row = InventoryCycleCountdataGridView.Rows[e.RowIndex];
                int gin = SafeInt(row.Cells[GINQty.Index].Value);
                int issued = SafeInt(row.Cells[IssuedQty.Index].Value);
                row.Cells[BalanceQty.Index].Value = gin - issued;
            }
        }
        #endregion

        #region export (wire to a button or menu)
        private void ExportToCsv(object sender, EventArgs e)
        {
            using (var sfd = new SaveFileDialog
            {
                Filter = "CSV Files (*.csv)|*.csv",
                FileName = $"InventoryCycleCount_{DateTime.Now:yyyyMMdd_HHmmss}.csv"
            })
            {
                if (sfd.ShowDialog() != DialogResult.OK) return;

                var sb = new StringBuilder();
                sb.AppendLine(string.Join(",", _gridData.Columns.Cast<DataColumn>()
                                                 .Select(c => EscapeCsv(c.ColumnName))));

                foreach (DataRow r in _gridData.Rows)
                    sb.AppendLine(string.Join(",", r.ItemArray.Select(v => EscapeCsv(v?.ToString()))));

                System.IO.File.WriteAllText(sfd.FileName, sb.ToString(), Encoding.UTF8);
                MessageBox.Show("Exported to CSV successfully.", "Export",
                              MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private static string EscapeCsv(string s)
        {
            if (s == null) return "";
            bool mustQuote = s.Contains(",") || s.Contains("\"") || s.Contains("\n") || s.Contains("\r");
            return mustQuote ? $"\"{s.Replace("\"", "\"\"")}\"" : s;
        }
        #endregion

        #region close behaviour (kept as in original)
        private void frmMaterialLedger_FormClosing(object sender, FormClosingEventArgs e)
        {
            Hide();
            new frmForm2().Show();
        }
        #endregion
    }
}