﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using WIA;
using System.Runtime.InteropServices;
using System.IO;
using PdfSharp.Drawing;
using System.Drawing.Imaging;
using iTextSharp.text;
using iTextSharp.text.pdf;
using Image = System.Drawing.Image;

namespace Erp_Project_With_Buttons.Part_Reciept
{
    public partial class DocumentScanning : Form
    {
        DataTable Ginnodt = new DataTable();
        DataAccessLayer DAL = new DataAccessLayer();
        string GINNO;
        private static string sGINnumber;
        public string fnGetGINnumber //get GIN from the receipt form
        {
            get
            {
                return sGINnumber;
            }
            set
            {
                sGINnumber = value;
            }
        }
        public DocumentScanning()
        {
            InitializeComponent();
        }
        DataTable dtvalue = new DataTable();

        private void DocumentScanning_Load(object sender, EventArgs e)
        {
            try
            {
                string sMonth = DateTime.Now.ToString("MM-yyyy");
                labelginnumber.Text = sGINnumber;
                GINNO = sGINnumber;
                if (!string.IsNullOrEmpty(sGINnumber))
                {
                    //String GINNUM = ;
                    //if (sGINnumber.Substring(0, 6) == "ITWSIN")
                    //{
                    //    dtvalue = DAL.fnIndentItemCost(sGINnumber, 4).Tables[0];
                    //}
                    //else
                    //{
                    dtvalue = DAL.fnIndentItemCost(sGINnumber, 3).Tables[0];
                    //}

                }
                if (dtvalue.Rows.Count > 0)
                {
                    labelginnumber.Text = dtvalue.Rows[0]["GINNumber"].ToString();
                    lblbasicvalue.Text = dtvalue.Rows[0]["Basic Value"].ToString();
                    lblsgstamount.Text = dtvalue.Rows[0]["SGSTAmount"].ToString();
                    lblcgstamount.Text = dtvalue.Rows[0]["CGSTAmount"].ToString();
                    lbligstamount.Text = dtvalue.Rows[0]["IGSTAmount"].ToString();
                    lblpackingforward.Text = dtvalue.Rows[0]["Packing & Forwarding, Transportation"].ToString();
                    lblgrossvalue.Text = dtvalue.Rows[0]["GrossValue"].ToString();
                }
                var devicemanager = new DeviceManager();
                for (int i = 1; i <= devicemanager.DeviceInfos.Count; i++)
                {
                    if (devicemanager.DeviceInfos[i].Type != WiaDeviceType.ScannerDeviceType)
                    {
                        continue;
                    }
                    ListOfScanner.Items.Add(devicemanager.DeviceInfos[i].Properties["Name"].get_Value());
                }
            }
            catch (COMException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btnscandoc_Click(object sender, EventArgs e)
        {

            string sMonth = DateTime.Now.ToString("MM-yyyy");
            int j = 0;
            var k = ListOfScanner.SelectedIndex;
            string destination;
            //\\inbas01\Data\ERP\Pub
            destination = @"\\inbas01\Data\ERP\Pub\ERP_Project_Document\GIN\" + sMonth + "\\";

            if (!Directory.Exists(destination))
            {
                Directory.CreateDirectory(destination);
            }

            try
            {
                WIA.CommonDialog dlg = new WIA.CommonDialog();
                var devicemanager = new DeviceManager();
                DeviceInfo availablescanner = null;
                for (int i = 1; i <= devicemanager.DeviceInfos.Count; i++)
                {
                    if (devicemanager.DeviceInfos[i].Type != WiaDeviceType.ScannerDeviceType)
                    {
                        continue;
                    }
                    availablescanner = devicemanager.DeviceInfos[k + 1];
                    break;
                }
                var device = availablescanner.Connect();
                var scannerItem = device.Items[1];
                //var imageFile = (ImageFile)scannerItem.Transfer(FormatID.wiaFormatJPEG);
                object scanResult = dlg.ShowTransfer(scannerItem, WIA.FormatID.wiaFormatJPEG, true);
                var imageFile = (ImageFile)scanResult;
                var path1 = @"C:\Databasepath\GINDocuments\\" + GINNO + ".JPEG";

                imageFile.SaveFile(path1);
                pictureBox1.ImageLocation = path1;
                DialogResult dialog = MessageBox.Show("Do You Want To Save The Image", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (dialog == DialogResult.Yes)
                {
                    //if (sGINnumber.Substring(0, 6) == "ITWSIN")
                    //{
                    //    //string destination = @"\\192.168.1.81\ERP_Project_Document\GINReceipt\" +GINNO + ".PDF";
                    //    destination = @"\\192.168.1.81\ERP_Project_Document\SIN\" + sMonth + "\\" + GINNO + ".PDF";
                    //}
                    //else
                    //{
                    destination = @"\\inbas01\Data\ERP\Pub\ERP_Project_Document\GIN\" + sMonth + "\\" + GINNO + ".PDF";
                    //}


                    string extension = Path.GetExtension(destination);
                    while (File.Exists(destination))      //increasing filename like (1),(2) i.e gin(1),gin(2)
                    {
                        if (j == 0)
                            destination = destination.Replace(extension, "(" + ++j + ")" + extension);
                        else
                            destination = destination.Replace("(" + j + ")" + extension, "(" + ++j + ")" + extension);
                    }

                    using (var document = new PdfSharp.Pdf.PdfDocument())         //converting jpeg image to pfd image 
                    {
                        PdfSharp.Pdf.PdfPage page = document.AddPage();
                        using (XImage img = XImage.FromFile(path1))
                        {
                            XGraphics gfx = XGraphics.FromPdfPage(page);
                            gfx.DrawImage(img, 0, 0);
                        }
                        document.Save(destination);

                    }
                    pictureBox1.Image = null;

                    if (File.Exists(path1))
                    {
                        File.Delete(path1);
                    }
                }
                else if (dialog == DialogResult.No)
                {
                    if (File.Exists(path1))
                    {
                        File.Delete(path1);
                    }
                    pictureBox1.Image = null;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        //internal void SaveImageAsPdf(string imageFileName, string pdfFileName, int width = 600, bool deleteImage = false)
        //{
        //    using (var document = new PdfDocument())
        //    {
        //      PdfPage page = document.AddPage();
        //      using (XImage img = XImage.FromFile(imageFileName))
        //      {
        //        var height = (int)(((double)width / (double)img.PixelWidth) * img.PixelHeight);
        //      // Change PDF Page size to match image
        //         page.Width = width;
        //         page.Height = height;
        //         XGraphics gfx = XGraphics.FromPdfPage(page);
        //         gfx.DrawImage(img, 0, 0, width, height);
        //      }
        //        document.Save(pdfFileName);
        //   }
        //    if (deleteImage)
        //    File.Delete(imageFileName);
        // }


        public static List<string> GetDevices()
        {
            List<string> devices = new List<string>();
            WIA.DeviceManager manager = new WIA.DeviceManager();
            foreach (WIA.DeviceInfo info in manager.DeviceInfos)
            {
                devices.Add(info.DeviceID);
            }
            return devices;
        }
        private void Multiplescanbtn_Click_1(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtpages.Text) && txtpages.Text != "0")
            {
                int numbrPages = Convert.ToInt32(txtpages.Text);
                string sMonth = DateTime.Now.ToString("MM-yyyy");
                try
                {
                    List<string> devices = GetDevices();
                    List<Image> images = null;
                    if (devices.Count == 0)
                    {
                        MessageBox.Show("You do not have any WIA devices.");
                        this.Close();
                    }
                    else
                    {
                        if (devices.Count >= 1)
                        {
                            images = Scan(devices[0], numbrPages);
                        }
                    }
                    List<String> localFiles = new List<String>();
                    foreach (Image image in images)
                    {
                        var path = String.Format(@"D:\Scanning\scan{0}_{1}.jpg", DateTime.Now.ToString("yyyy-MM-dd HHmmss"), Path.GetRandomFileName());
                        localFiles.Add(path.ToString());
                        image.Save(path, ImageFormat.Jpeg);
                    }
                    // var pdfpath = String.Format(@"D:\Scanning\");
                    var pdfpath = String.Format(@"\\inbas01\Data\ERP\Pub\ERP_Project_Document\GIN\" + sMonth + "\\");
                    byte[] document = ConvertIntoSinglePDF(localFiles);
                    File.WriteAllBytes(pdfpath + "" + GINNO + ".pdf", document);
                    foreach (string file in localFiles)
                    {
                        File.Delete(file);
                    }
                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message);
                }
            }
            else
            {
                MessageBox.Show("Enter Number Of pages to Scan", "Error", 0, MessageBoxIcon.Question);
            }
        }

        public static List<Image> Scan(string scannerId, int numbrPages)
        {

            List<Image> images = new List<Image>();
            WIA.DeviceManager manager = new WIA.DeviceManager();
            WIA.Device device = null;
            foreach (WIA.DeviceInfo info in manager.DeviceInfos)
            {
                if (info.DeviceID == scannerId)
                {
                    device = info.Connect();
                    break;
                }
            }
            if (device == null)
            {
                string availableDevices = "";
                foreach (WIA.DeviceInfo info in manager.DeviceInfos)
                {
                    availableDevices += info.DeviceID + "\n";
                }
                throw new Exception("The device with provided ID could not be found. Available Devices:\n" + availableDevices);
            }
            WIA.Item item = null;
            WIA.CommonDialog dialog = new WIA.CommonDialog();
            WIA.Items items = dialog.ShowSelectItems(device);
            if (items == null)
                return images;
            item = items[1];
            bool hasMorePages = true;
            while (hasMorePages)
            {
                try
                {
                    WIA.ICommonDialog wiaCommonDialog = new WIA.CommonDialog();
                    WIA.ImageFile image = (WIA.ImageFile)wiaCommonDialog.ShowTransfer(item, wiaFormatBMP, false);
                    string fileName = Path.GetTempFileName();
                    File.Delete(fileName);
                    image.SaveFile(fileName);
                    try
                    {
                        Marshal.FinalReleaseComObject(image);
                    }
                    finally
                    {
                        image = null;
                    }
                    images.Add(Image.FromFile(fileName));
                }
                finally
                {
                    WIA.Property documentHandlingSelect = null;
                    WIA.Property documentHandlingStatus = null;
                    foreach (WIA.Property prop in device.Properties)
                    {
                        if (prop.PropertyID == WIA_PROPERTIES.WIA_DPS_DOCUMENT_HANDLING_SELECT)
                            documentHandlingSelect = prop;
                        if (prop.PropertyID == WIA_PROPERTIES.WIA_DPS_DOCUMENT_HANDLING_STATUS)
                            documentHandlingStatus = prop;
                    }
                    hasMorePages = false;
                    if (documentHandlingSelect != null)
                    {
                        if ((Convert.ToUInt32(documentHandlingSelect.get_Value()) & WIA_DPS_DOCUMENT_HANDLING_SELECT.FEEDER) != 0)
                        {
                            hasMorePages = ((Convert.ToUInt32(documentHandlingStatus.get_Value()) & WIA_DPS_DOCUMENT_HANDLING_STATUS.FEED_READY) != 0);
                        }
                    }
                }
                numbrPages -= 1;
                if (numbrPages > 0)
                    hasMorePages = true;
                else
                    hasMorePages = false;
            }
            return images;
        }
        public static byte[] ConvertIntoSinglePDF(List<string> filePaths)
        {
            Document doc = new Document();
            doc.SetPageSize(PageSize.A4);
            var ms = new System.IO.MemoryStream();
            {
                PdfCopy pdf = new PdfCopy(doc, ms);
                doc.Open();
                foreach (string path in filePaths)
                {
                    byte[] data = File.ReadAllBytes(path);
                    doc.NewPage();
                    Document imageDocument = null;
                    PdfWriter imageDocumentWriter = null;
                    switch (Path.GetExtension(path).ToLower().Trim('.'))
                    {
                        case "bmp":
                        case "gif":
                        case "jpg":
                        case "png":
                            imageDocument = new Document();
                            using (var imageMS = new MemoryStream())
                            {
                                imageDocumentWriter = PdfWriter.GetInstance(imageDocument, imageMS);
                                imageDocument.Open();
                                if (imageDocument.NewPage())
                                {
                                    var image = iTextSharp.text.Image.GetInstance(data);
                                    image.Alignment = Element.ALIGN_CENTER;
                                    image.ScaleToFit(doc.PageSize.Width - 10, doc.PageSize.Height - 10);
                                    if (!imageDocument.Add(image))
                                    {
                                        throw new Exception("Unable to add image to page!");
                                    }
                                    imageDocument.Close();
                                    imageDocumentWriter.Close();
                                    PdfReader imageDocumentReader = new PdfReader(imageMS.ToArray());
                                    var page = pdf.GetImportedPage(imageDocumentReader, 1);
                                    pdf.AddPage(page);
                                    imageDocumentReader.Close();
                                }
                            }
                            break;
                        case "pdf":
                            var reader = new PdfReader(data);
                            for (int i = 0; i < reader.NumberOfPages; i++)
                            {
                                pdf.AddPage(pdf.GetImportedPage(reader, i + 1));
                            }
                            pdf.FreeReader(reader);
                            reader.Close();
                            break;
                        default:
                            break;
                    }
                }
                if (doc.IsOpen()) doc.Close();
                return ms.ToArray();
            }
        }
        const string wiaFormatBMP = "{B96B3CAB-0728-11D3-9D7B-0000F81EF32E}";
        class WIA_DPS_DOCUMENT_HANDLING_SELECT
        {
            public const uint FEEDER = 0x00000001;
            public const uint FLATBED = 0x00000002;
        }
        class WIA_DPS_DOCUMENT_HANDLING_STATUS
        {
            public const uint FEED_READY = 0x00000001;
        }
        class WIA_PROPERTIES
        {
            public const uint WIA_RESERVED_FOR_NEW_PROPS = 1024;
            public const uint WIA_DIP_FIRST = 2;
            public const uint WIA_DPA_FIRST = WIA_DIP_FIRST + WIA_RESERVED_FOR_NEW_PROPS;
            public const uint WIA_DPC_FIRST = WIA_DPA_FIRST + WIA_RESERVED_FOR_NEW_PROPS;
            public const uint WIA_DPS_FIRST = WIA_DPC_FIRST + WIA_RESERVED_FOR_NEW_PROPS;
            public const uint WIA_DPS_DOCUMENT_HANDLING_STATUS = WIA_DPS_FIRST + 13;
            public const uint WIA_DPS_DOCUMENT_HANDLING_SELECT = WIA_DPS_FIRST + 14;
        }

        private void frmScanning_FormClosing(object sender, FormClosingEventArgs e)
        {
            frmReciept frm = new frmReciept();
            this.Hide();
            frm.Show();
        }
        private void txtpages_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber1(sender, e);
        }
        private void fnOnlynumber1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            openFileDialog1.InitialDirectory = @"c:\";
            openFileDialog1.FileName = "Select File";
            openFileDialog1.Title = "Select files..";
            openFileDialog1.ShowDialog();
        }

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            string sMonth = DateTime.Now.ToString("MM-yyyy");
            string destination;
            string sourcePath = openFileDialog1.FileName;
            destination = @"\\inbas01\Data\ERP\Pub\ERP_Project_Document\GIN\" + sMonth + "\\";

            if (!Directory.Exists(destination))
            {
                Directory.CreateDirectory(destination);
            }

            File.Copy(sourcePath, destination + Path.GetFileName(sourcePath), true);
            MessageBox.Show("GIN document saved.", "success", 0, MessageBoxIcon.Information);
        }
    }
}
