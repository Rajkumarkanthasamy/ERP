﻿namespace Erp_Project_With_Buttons
{
    partial class frmReciept
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmReciept));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle46 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lbltime = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lblpartreciept = new System.Windows.Forms.Label();
            this.pnPOWO = new System.Windows.Forms.Panel();
            this.lblCountry = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.combocurrency = new System.Windows.Forms.TextBox();
            this.textBRate = new System.Windows.Forms.TextBox();
            this.lblGSTCode = new System.Windows.Forms.Label();
            this.chkOtherItems = new System.Windows.Forms.CheckBox();
            this.cmbLedger = new System.Windows.Forms.ComboBox();
            this.lblpowoby = new System.Windows.Forms.Label();
            this.lblVendor = new System.Windows.Forms.Label();
            this.txtVendorcode = new System.Windows.Forms.Label();
            this.lblprojcode = new System.Windows.Forms.Label();
            this.lblprojectdesc = new System.Windows.Forms.Label();
            this.lblcustomername = new System.Windows.Forms.Label();
            this.lblCustomer = new System.Windows.Forms.Label();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.lblUser = new System.Windows.Forms.Label();
            this.chkGINWO = new System.Windows.Forms.CheckBox();
            this.chkGINPO = new System.Windows.Forms.CheckBox();
            this.lblinvoicedate = new System.Windows.Forms.Label();
            this.lblGinnumber = new System.Windows.Forms.Label();
            this.dtpInvoiceDate = new System.Windows.Forms.DateTimePicker();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblSupplierinvoicenumber = new System.Windows.Forms.Label();
            this.lblGinno = new System.Windows.Forms.TextBox();
            this.txtinvoiceno = new System.Windows.Forms.TextBox();
            this.lblpogenaratedby = new System.Windows.Forms.Label();
            this.lblVendorcode = new System.Windows.Forms.Label();
            this.lblprojectcode = new System.Windows.Forms.Label();
            this.lblprojectname = new System.Windows.Forms.Label();
            this.lblVendorname = new System.Windows.Forms.Label();
            this.cmbJobstatus = new System.Windows.Forms.ComboBox();
            this.lbldate = new System.Windows.Forms.Label();
            this.lblJobstatus = new System.Windows.Forms.Label();
            this.dtpGINDate = new System.Windows.Forms.DateTimePicker();
            this.cmbPonumber = new System.Windows.Forms.ComboBox();
            this.lblwonum = new System.Windows.Forms.Label();
            this.lblWonumber = new System.Windows.Forms.Label();
            this.dgvPOItemList = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnscan = new System.Windows.Forms.Button();
            this.lstusers = new System.Windows.Forms.ListBox();
            this.dgvCopyEmail = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClearAll = new System.Windows.Forms.Button();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.dgPackingTaxes = new System.Windows.Forms.DataGridView();
            this.TaxDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxamount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxIGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxIGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxSGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxSGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxCGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxCGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblFinalNetAmount = new System.Windows.Forms.Label();
            this.txtFinalNetAmount = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbltotalIGST = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.lbltotalCGST = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.lbltotalSGST = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.lbltotaldiscount = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lblTotalAmount = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.btnAddTransport = new System.Windows.Forms.Button();
            this.btnPackingAmount = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.txtTCSAmount = new System.Windows.Forms.TextBox();
            this.Select = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.SlNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HsnSacCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OrderedQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalOrderedQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalRemainingQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RecieveQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.temRecieveQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiscRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TotalAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TotalPOAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SGSTTotalAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CGSTTotalAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IGSTTotalAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.batchCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemLocation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiscAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.POAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Freight = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomsDuty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomsDutyAmt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cess = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CessAmt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CDIGST = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CDIGSTAmt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RemainingQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel5.SuspendLayout();
            this.pnPOWO.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPOItemList)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCopyEmail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgPackingTaxes)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbltime
            // 
            this.lbltime.AutoSize = true;
            this.lbltime.Font = new System.Drawing.Font("Calibri Light", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltime.ForeColor = System.Drawing.Color.Black;
            this.lbltime.Location = new System.Drawing.Point(53, 59);
            this.lbltime.Name = "lbltime";
            this.lbltime.Size = new System.Drawing.Size(22, 26);
            this.lbltime.TabIndex = 182;
            this.lbltime.Text = "*";
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel5.Controls.Add(this.lblpartreciept);
            this.panel5.Location = new System.Drawing.Point(3, 6);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(180, 39);
            this.panel5.TabIndex = 181;
            // 
            // lblpartreciept
            // 
            this.lblpartreciept.AutoSize = true;
            this.lblpartreciept.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpartreciept.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblpartreciept.Location = new System.Drawing.Point(34, 0);
            this.lblpartreciept.Name = "lblpartreciept";
            this.lblpartreciept.Size = new System.Drawing.Size(99, 33);
            this.lblpartreciept.TabIndex = 71;
            this.lblpartreciept.Text = "Reciept";
            // 
            // pnPOWO
            // 
            this.pnPOWO.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnPOWO.Controls.Add(this.lblCountry);
            this.pnPOWO.Controls.Add(this.panel2);
            this.pnPOWO.Controls.Add(this.lblGSTCode);
            this.pnPOWO.Controls.Add(this.chkOtherItems);
            this.pnPOWO.Controls.Add(this.cmbLedger);
            this.pnPOWO.Controls.Add(this.lbltime);
            this.pnPOWO.Controls.Add(this.panel5);
            this.pnPOWO.Controls.Add(this.lblpowoby);
            this.pnPOWO.Controls.Add(this.lblVendor);
            this.pnPOWO.Controls.Add(this.txtVendorcode);
            this.pnPOWO.Controls.Add(this.lblprojcode);
            this.pnPOWO.Controls.Add(this.lblprojectdesc);
            this.pnPOWO.Controls.Add(this.lblcustomername);
            this.pnPOWO.Controls.Add(this.lblCustomer);
            this.pnPOWO.Controls.Add(this.lblWelcome);
            this.pnPOWO.Controls.Add(this.lblUser);
            this.pnPOWO.Controls.Add(this.chkGINWO);
            this.pnPOWO.Controls.Add(this.chkGINPO);
            this.pnPOWO.Controls.Add(this.lblinvoicedate);
            this.pnPOWO.Controls.Add(this.lblGinnumber);
            this.pnPOWO.Controls.Add(this.dtpInvoiceDate);
            this.pnPOWO.Controls.Add(this.textBox1);
            this.pnPOWO.Controls.Add(this.lblSupplierinvoicenumber);
            this.pnPOWO.Controls.Add(this.lblGinno);
            this.pnPOWO.Controls.Add(this.txtinvoiceno);
            this.pnPOWO.Controls.Add(this.lblpogenaratedby);
            this.pnPOWO.Controls.Add(this.lblVendorcode);
            this.pnPOWO.Controls.Add(this.lblprojectcode);
            this.pnPOWO.Controls.Add(this.lblprojectname);
            this.pnPOWO.Controls.Add(this.lblVendorname);
            this.pnPOWO.Controls.Add(this.cmbJobstatus);
            this.pnPOWO.Controls.Add(this.lbldate);
            this.pnPOWO.Controls.Add(this.lblJobstatus);
            this.pnPOWO.Controls.Add(this.dtpGINDate);
            this.pnPOWO.Controls.Add(this.cmbPonumber);
            this.pnPOWO.Controls.Add(this.lblwonum);
            this.pnPOWO.Controls.Add(this.lblWonumber);
            this.pnPOWO.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.pnPOWO.Location = new System.Drawing.Point(2, 1);
            this.pnPOWO.Name = "pnPOWO";
            this.pnPOWO.Size = new System.Drawing.Size(1329, 169);
            this.pnPOWO.TabIndex = 180;
            // 
            // lblCountry
            // 
            this.lblCountry.AutoSize = true;
            this.lblCountry.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCountry.ForeColor = System.Drawing.Color.Black;
            this.lblCountry.Location = new System.Drawing.Point(120, 84);
            this.lblCountry.Name = "lblCountry";
            this.lblCountry.Size = new System.Drawing.Size(16, 18);
            this.lblCountry.TabIndex = 192;
            this.lblCountry.Text = "C";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.combocurrency);
            this.panel2.Controls.Add(this.textBRate);
            this.panel2.Location = new System.Drawing.Point(685, 124);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(256, 38);
            this.panel2.TabIndex = 191;
            this.panel2.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 18);
            this.label2.TabIndex = 188;
            this.label2.Text = "Currency :";
            // 
            // combocurrency
            // 
            this.combocurrency.Enabled = false;
            this.combocurrency.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combocurrency.Location = new System.Drawing.Point(79, 9);
            this.combocurrency.Name = "combocurrency";
            this.combocurrency.Size = new System.Drawing.Size(100, 23);
            this.combocurrency.TabIndex = 190;
            // 
            // textBRate
            // 
            this.textBRate.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBRate.Location = new System.Drawing.Point(188, 9);
            this.textBRate.Name = "textBRate";
            this.textBRate.Size = new System.Drawing.Size(62, 23);
            this.textBRate.TabIndex = 189;
            this.textBRate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBRate_KeyDown);
            this.textBRate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBRate_KeyPress);
            // 
            // lblGSTCode
            // 
            this.lblGSTCode.AutoSize = true;
            this.lblGSTCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGSTCode.ForeColor = System.Drawing.Color.Black;
            this.lblGSTCode.Location = new System.Drawing.Point(548, 76);
            this.lblGSTCode.Name = "lblGSTCode";
            this.lblGSTCode.Size = new System.Drawing.Size(16, 18);
            this.lblGSTCode.TabIndex = 187;
            this.lblGSTCode.Text = "C";
            // 
            // chkOtherItems
            // 
            this.chkOtherItems.AutoSize = true;
            this.chkOtherItems.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkOtherItems.ForeColor = System.Drawing.Color.Black;
            this.chkOtherItems.Location = new System.Drawing.Point(523, 6);
            this.chkOtherItems.Name = "chkOtherItems";
            this.chkOtherItems.Size = new System.Drawing.Size(136, 23);
            this.chkOtherItems.TabIndex = 186;
            this.chkOtherItems.Text = "GIN other items";
            this.chkOtherItems.UseVisualStyleBackColor = true;
            this.chkOtherItems.Visible = false;
            this.chkOtherItems.CheckedChanged += new System.EventHandler(this.chkOtherItems_CheckedChanged);
            // 
            // cmbLedger
            // 
            this.cmbLedger.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbLedger.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbLedger.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLedger.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbLedger.FormattingEnabled = true;
            this.cmbLedger.ItemHeight = 18;
            this.cmbLedger.Location = new System.Drawing.Point(1218, 133);
            this.cmbLedger.Name = "cmbLedger";
            this.cmbLedger.Size = new System.Drawing.Size(45, 26);
            this.cmbLedger.TabIndex = 185;
            this.toolTip1.SetToolTip(this.cmbLedger, "Select A Reciept Type");
            this.cmbLedger.Visible = false;
            // 
            // lblpowoby
            // 
            this.lblpowoby.AutoSize = true;
            this.lblpowoby.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpowoby.ForeColor = System.Drawing.Color.Black;
            this.lblpowoby.Location = new System.Drawing.Point(1109, 46);
            this.lblpowoby.Name = "lblpowoby";
            this.lblpowoby.Size = new System.Drawing.Size(16, 18);
            this.lblpowoby.TabIndex = 183;
            this.lblpowoby.Text = "C";
            // 
            // lblVendor
            // 
            this.lblVendor.AutoSize = true;
            this.lblVendor.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVendor.ForeColor = System.Drawing.Color.Black;
            this.lblVendor.Location = new System.Drawing.Point(787, 76);
            this.lblVendor.Name = "lblVendor";
            this.lblVendor.Size = new System.Drawing.Size(16, 18);
            this.lblVendor.TabIndex = 183;
            this.lblVendor.Text = "C";
            // 
            // txtVendorcode
            // 
            this.txtVendorcode.AutoSize = true;
            this.txtVendorcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVendorcode.ForeColor = System.Drawing.Color.Black;
            this.txtVendorcode.Location = new System.Drawing.Point(408, 76);
            this.txtVendorcode.Name = "txtVendorcode";
            this.txtVendorcode.Size = new System.Drawing.Size(16, 18);
            this.txtVendorcode.TabIndex = 183;
            this.txtVendorcode.Text = "C";
            // 
            // lblprojcode
            // 
            this.lblprojcode.AutoSize = true;
            this.lblprojcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprojcode.ForeColor = System.Drawing.Color.Black;
            this.lblprojcode.Location = new System.Drawing.Point(408, 106);
            this.lblprojcode.Name = "lblprojcode";
            this.lblprojcode.Size = new System.Drawing.Size(16, 18);
            this.lblprojcode.TabIndex = 183;
            this.lblprojcode.Text = "C";
            // 
            // lblprojectdesc
            // 
            this.lblprojectdesc.AutoSize = true;
            this.lblprojectdesc.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprojectdesc.ForeColor = System.Drawing.Color.Black;
            this.lblprojectdesc.Location = new System.Drawing.Point(787, 106);
            this.lblprojectdesc.Name = "lblprojectdesc";
            this.lblprojectdesc.Size = new System.Drawing.Size(16, 18);
            this.lblprojectdesc.TabIndex = 183;
            this.lblprojectdesc.Text = "C";
            // 
            // lblcustomername
            // 
            this.lblcustomername.AutoSize = true;
            this.lblcustomername.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcustomername.ForeColor = System.Drawing.Color.Black;
            this.lblcustomername.Location = new System.Drawing.Point(408, 137);
            this.lblcustomername.Name = "lblcustomername";
            this.lblcustomername.Size = new System.Drawing.Size(16, 18);
            this.lblcustomername.TabIndex = 183;
            this.lblcustomername.Text = "C";
            // 
            // lblCustomer
            // 
            this.lblCustomer.AutoSize = true;
            this.lblCustomer.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomer.ForeColor = System.Drawing.Color.Black;
            this.lblCustomer.Location = new System.Drawing.Point(336, 137);
            this.lblCustomer.Name = "lblCustomer";
            this.lblCustomer.Size = new System.Drawing.Size(75, 18);
            this.lblCustomer.TabIndex = 183;
            this.lblCustomer.Text = "Customer :";
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.ForeColor = System.Drawing.Color.Black;
            this.lblWelcome.Location = new System.Drawing.Point(3, 139);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(93, 24);
            this.lblWelcome.TabIndex = 22;
            this.lblWelcome.Text = "Welcome:";
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUser.ForeColor = System.Drawing.Color.Black;
            this.lblUser.Location = new System.Drawing.Point(94, 139);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(0, 24);
            this.lblUser.TabIndex = 21;
            // 
            // chkGINWO
            // 
            this.chkGINWO.AutoSize = true;
            this.chkGINWO.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkGINWO.ForeColor = System.Drawing.Color.Black;
            this.chkGINWO.Location = new System.Drawing.Point(373, 7);
            this.chkGINWO.Name = "chkGINWO";
            this.chkGINWO.Size = new System.Drawing.Size(138, 23);
            this.chkGINWO.TabIndex = 181;
            this.chkGINWO.Text = "GIN Work Order";
            this.chkGINWO.UseVisualStyleBackColor = true;
            this.chkGINWO.CheckedChanged += new System.EventHandler(this.chkGINWO_CheckedChanged);
            // 
            // chkGINPO
            // 
            this.chkGINPO.AutoSize = true;
            this.chkGINPO.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkGINPO.ForeColor = System.Drawing.Color.Black;
            this.chkGINPO.Location = new System.Drawing.Point(200, 6);
            this.chkGINPO.Name = "chkGINPO";
            this.chkGINPO.Size = new System.Drawing.Size(163, 23);
            this.chkGINPO.TabIndex = 180;
            this.chkGINPO.Text = "GIN Purchase Order";
            this.chkGINPO.UseVisualStyleBackColor = true;
            this.chkGINPO.CheckedChanged += new System.EventHandler(this.chkGINPO_CheckedChanged);
            // 
            // lblinvoicedate
            // 
            this.lblinvoicedate.AutoSize = true;
            this.lblinvoicedate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinvoicedate.ForeColor = System.Drawing.Color.Black;
            this.lblinvoicedate.Location = new System.Drawing.Point(1098, 9);
            this.lblinvoicedate.Name = "lblinvoicedate";
            this.lblinvoicedate.Size = new System.Drawing.Size(99, 18);
            this.lblinvoicedate.TabIndex = 179;
            this.lblinvoicedate.Text = "Invoice Date* :";
            // 
            // lblGinnumber
            // 
            this.lblGinnumber.AutoSize = true;
            this.lblGinnumber.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGinnumber.ForeColor = System.Drawing.Color.Black;
            this.lblGinnumber.Location = new System.Drawing.Point(693, 9);
            this.lblGinnumber.Name = "lblGinnumber";
            this.lblGinnumber.Size = new System.Drawing.Size(60, 18);
            this.lblGinnumber.TabIndex = 153;
            this.lblGinnumber.Text = "GIN No :";
            // 
            // dtpInvoiceDate
            // 
            this.dtpInvoiceDate.CustomFormat = "";
            this.dtpInvoiceDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpInvoiceDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpInvoiceDate.Location = new System.Drawing.Point(1198, 6);
            this.dtpInvoiceDate.Name = "dtpInvoiceDate";
            this.dtpInvoiceDate.Size = new System.Drawing.Size(90, 26);
            this.dtpInvoiceDate.TabIndex = 162;
            this.dtpInvoiceDate.ValueChanged += new System.EventHandler(this.dtpInvoiceDate_ValueChanged);
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(1261, -63);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(86, 21);
            this.textBox1.TabIndex = 154;
            // 
            // lblSupplierinvoicenumber
            // 
            this.lblSupplierinvoicenumber.AutoSize = true;
            this.lblSupplierinvoicenumber.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSupplierinvoicenumber.ForeColor = System.Drawing.Color.Black;
            this.lblSupplierinvoicenumber.Location = new System.Drawing.Point(691, 46);
            this.lblSupplierinvoicenumber.Name = "lblSupplierinvoicenumber";
            this.lblSupplierinvoicenumber.Size = new System.Drawing.Size(85, 18);
            this.lblSupplierinvoicenumber.TabIndex = 156;
            this.lblSupplierinvoicenumber.Text = "InvoiceNo* :";
            // 
            // lblGinno
            // 
            this.lblGinno.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold);
            this.lblGinno.Location = new System.Drawing.Point(759, 7);
            this.lblGinno.Name = "lblGinno";
            this.lblGinno.ReadOnly = true;
            this.lblGinno.Size = new System.Drawing.Size(165, 23);
            this.lblGinno.TabIndex = 157;
            this.lblGinno.TextChanged += new System.EventHandler(this.lblGinno_TextChanged);
            // 
            // txtinvoiceno
            // 
            this.txtinvoiceno.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinvoiceno.Location = new System.Drawing.Point(776, 45);
            this.txtinvoiceno.Name = "txtinvoiceno";
            this.txtinvoiceno.Size = new System.Drawing.Size(165, 23);
            this.txtinvoiceno.TabIndex = 157;
            // 
            // lblpogenaratedby
            // 
            this.lblpogenaratedby.AutoSize = true;
            this.lblpogenaratedby.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpogenaratedby.ForeColor = System.Drawing.Color.Black;
            this.lblpogenaratedby.Location = new System.Drawing.Point(1025, 46);
            this.lblpogenaratedby.Name = "lblpogenaratedby";
            this.lblpogenaratedby.Size = new System.Drawing.Size(87, 18);
            this.lblpogenaratedby.TabIndex = 176;
            this.lblpogenaratedby.Text = "Prepared By:";
            // 
            // lblVendorcode
            // 
            this.lblVendorcode.AutoSize = true;
            this.lblVendorcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVendorcode.ForeColor = System.Drawing.Color.Black;
            this.lblVendorcode.Location = new System.Drawing.Point(282, 76);
            this.lblVendorcode.Name = "lblVendorcode";
            this.lblVendorcode.Size = new System.Drawing.Size(126, 18);
            this.lblVendorcode.TabIndex = 164;
            this.lblVendorcode.Text = "Vendor Code, GST :";
            // 
            // lblprojectcode
            // 
            this.lblprojectcode.AutoSize = true;
            this.lblprojectcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprojectcode.ForeColor = System.Drawing.Color.Black;
            this.lblprojectcode.Location = new System.Drawing.Point(317, 106);
            this.lblprojectcode.Name = "lblprojectcode";
            this.lblprojectcode.Size = new System.Drawing.Size(94, 18);
            this.lblprojectcode.TabIndex = 173;
            this.lblprojectcode.Text = "Project Code :";
            // 
            // lblprojectname
            // 
            this.lblprojectname.AutoSize = true;
            this.lblprojectname.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprojectname.ForeColor = System.Drawing.Color.Black;
            this.lblprojectname.Location = new System.Drawing.Point(691, 106);
            this.lblprojectname.Name = "lblprojectname";
            this.lblprojectname.Size = new System.Drawing.Size(99, 18);
            this.lblprojectname.TabIndex = 172;
            this.lblprojectname.Text = "Project Name :";
            // 
            // lblVendorname
            // 
            this.lblVendorname.AutoSize = true;
            this.lblVendorname.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVendorname.ForeColor = System.Drawing.Color.Black;
            this.lblVendorname.Location = new System.Drawing.Point(691, 76);
            this.lblVendorname.Name = "lblVendorname";
            this.lblVendorname.Size = new System.Drawing.Size(100, 18);
            this.lblVendorname.TabIndex = 166;
            this.lblVendorname.Text = "Vendor Name :";
            // 
            // cmbJobstatus
            // 
            this.cmbJobstatus.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbJobstatus.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbJobstatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbJobstatus.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbJobstatus.FormattingEnabled = true;
            this.cmbJobstatus.ItemHeight = 18;
            this.cmbJobstatus.Items.AddRange(new object[] {
            "Open ",
            "Close"});
            this.cmbJobstatus.Location = new System.Drawing.Point(1229, 76);
            this.cmbJobstatus.Name = "cmbJobstatus";
            this.cmbJobstatus.Size = new System.Drawing.Size(61, 26);
            this.cmbJobstatus.TabIndex = 171;
            this.toolTip1.SetToolTip(this.cmbJobstatus, "Select A Reciept Type");
            this.cmbJobstatus.Visible = false;
            // 
            // lbldate
            // 
            this.lbldate.AutoSize = true;
            this.lbldate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldate.ForeColor = System.Drawing.Color.Black;
            this.lbldate.Location = new System.Drawing.Point(930, 8);
            this.lbldate.Name = "lbldate";
            this.lbldate.Size = new System.Drawing.Size(71, 18);
            this.lbldate.TabIndex = 155;
            this.lbldate.Text = "GIN Date :";
            // 
            // lblJobstatus
            // 
            this.lblJobstatus.AutoSize = true;
            this.lblJobstatus.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJobstatus.ForeColor = System.Drawing.Color.Black;
            this.lblJobstatus.Location = new System.Drawing.Point(1159, 80);
            this.lblJobstatus.Name = "lblJobstatus";
            this.lblJobstatus.Size = new System.Drawing.Size(70, 18);
            this.lblJobstatus.TabIndex = 170;
            this.lblJobstatus.Text = "Job Status";
            this.lblJobstatus.Visible = false;
            // 
            // dtpGINDate
            // 
            this.dtpGINDate.Enabled = false;
            this.dtpGINDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpGINDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpGINDate.Location = new System.Drawing.Point(1002, 4);
            this.dtpGINDate.Name = "dtpGINDate";
            this.dtpGINDate.Size = new System.Drawing.Size(90, 26);
            this.dtpGINDate.TabIndex = 167;
            // 
            // cmbPonumber
            // 
            this.cmbPonumber.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbPonumber.DropDownHeight = 130;
            this.cmbPonumber.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPonumber.FormattingEnabled = true;
            this.cmbPonumber.IntegralHeight = false;
            this.cmbPonumber.ItemHeight = 15;
            this.cmbPonumber.Location = new System.Drawing.Point(413, 41);
            this.cmbPonumber.Name = "cmbPonumber";
            this.cmbPonumber.Size = new System.Drawing.Size(184, 23);
            this.cmbPonumber.TabIndex = 168;
            this.cmbPonumber.SelectedIndexChanged += new System.EventHandler(this.cmbPonumber_SelectedIndexChanged);
            // 
            // lblwonum
            // 
            this.lblwonum.AutoSize = true;
            this.lblwonum.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblwonum.ForeColor = System.Drawing.Color.Black;
            this.lblwonum.Location = new System.Drawing.Point(318, 41);
            this.lblwonum.Name = "lblwonum";
            this.lblwonum.Size = new System.Drawing.Size(93, 18);
            this.lblwonum.TabIndex = 182;
            this.lblwonum.Text = "WO Number :";
            this.lblwonum.Click += new System.EventHandler(this.lblwonum_Click);
            // 
            // lblWonumber
            // 
            this.lblWonumber.AutoSize = true;
            this.lblWonumber.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWonumber.ForeColor = System.Drawing.Color.Black;
            this.lblWonumber.Location = new System.Drawing.Point(321, 44);
            this.lblWonumber.Name = "lblWonumber";
            this.lblWonumber.Size = new System.Drawing.Size(87, 18);
            this.lblWonumber.TabIndex = 158;
            this.lblWonumber.Text = "PO Number :";
            // 
            // dgvPOItemList
            // 
            this.dgvPOItemList.AllowUserToAddRows = false;
            this.dgvPOItemList.AllowUserToDeleteRows = false;
            this.dgvPOItemList.AllowUserToResizeRows = false;
            this.dgvPOItemList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.Desktop;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPOItemList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvPOItemList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPOItemList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Select,
            this.SlNo,
            this.ItemCode,
            this.ProjectCode,
            this.ProductNo,
            this.ItemDescription,
            this.HsnSacCode,
            this.OrderedQty,
            this.totalOrderedQty,
            this.totalRemainingQty,
            this.RecieveQuantity,
            this.temRecieveQuantity,
            this.UnitCost,
            this.DiscRate,
            this.TotalAmount,
            this.TotalPOAmount,
            this.SGSTTotalAmount,
            this.CGSTTotalAmount,
            this.IGSTTotalAmount,
            this.batchCode,
            this.itemLocation,
            this.DiscAmount,
            this.Amount,
            this.POAmount,
            this.SGSTRate,
            this.SGSTAmount,
            this.CGSTRate,
            this.CGSTAmount,
            this.IGSTRate,
            this.IGSTAmount,
            this.Freight,
            this.CustomsDuty,
            this.CustomsDutyAmt,
            this.Cess,
            this.CessAmt,
            this.CDIGST,
            this.CDIGSTAmt,
            this.RemainingQty});
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle32.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle32.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle32.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle32.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle32.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle32.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPOItemList.DefaultCellStyle = dataGridViewCellStyle32;
            this.dgvPOItemList.EnableHeadersVisualStyles = false;
            this.dgvPOItemList.Location = new System.Drawing.Point(1, 174);
            this.dgvPOItemList.MultiSelect = false;
            this.dgvPOItemList.Name = "dgvPOItemList";
            this.dgvPOItemList.RowHeadersVisible = false;
            this.dgvPOItemList.RowHeadersWidth = 62;
            dataGridViewCellStyle33.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvPOItemList.RowsDefaultCellStyle = dataGridViewCellStyle33;
            this.dgvPOItemList.Size = new System.Drawing.Size(1330, 295);
            this.dgvPOItemList.TabIndex = 169;
            this.dgvPOItemList.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgvPOItemList_CellBeginEdit);
            this.dgvPOItemList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPOItemList_CellContentClick);
            this.dgvPOItemList.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPOItemList_CellEndEdit);
            this.dgvPOItemList.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgvPOItemList_DataError);
            this.dgvPOItemList.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvPOItemList_EditingControlShowing);
            this.dgvPOItemList.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvPOItemList_KeyUp);
            this.dgvPOItemList.DataBindingComplete += dgvPOItemList_DataBindingComplete;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnscan);
            this.groupBox2.Controls.Add(this.lstusers);
            this.groupBox2.Controls.Add(this.dgvCopyEmail);
            this.groupBox2.Controls.Add(this.btnExit);
            this.groupBox2.Controls.Add(this.btnSave);
            this.groupBox2.Controls.Add(this.btnClearAll);
            this.groupBox2.Location = new System.Drawing.Point(202, 627);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1065, 55);
            this.groupBox2.TabIndex = 159;
            this.groupBox2.TabStop = false;
            // 
            // btnscan
            // 
            this.btnscan.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnscan.Location = new System.Drawing.Point(624, 15);
            this.btnscan.Name = "btnscan";
            this.btnscan.Size = new System.Drawing.Size(95, 32);
            this.btnscan.TabIndex = 198;
            this.btnscan.Text = "SCAN";
            this.btnscan.UseVisualStyleBackColor = true;
            this.btnscan.Click += new System.EventHandler(this.btnscan_Click);
            // 
            // lstusers
            // 
            this.lstusers.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstusers.FormattingEnabled = true;
            this.lstusers.ItemHeight = 19;
            this.lstusers.Location = new System.Drawing.Point(482, 19);
            this.lstusers.Name = "lstusers";
            this.lstusers.ScrollAlwaysVisible = true;
            this.lstusers.Size = new System.Drawing.Size(110, 23);
            this.lstusers.TabIndex = 197;
            this.lstusers.Visible = false;
            // 
            // dgvCopyEmail
            // 
            this.dgvCopyEmail.AllowUserToAddRows = false;
            this.dgvCopyEmail.AllowUserToDeleteRows = false;
            this.dgvCopyEmail.AllowUserToResizeRows = false;
            this.dgvCopyEmail.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle34.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle34.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle34.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.SystemColors.Desktop;
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvCopyEmail.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle34;
            this.dgvCopyEmail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCopyEmail.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn7});
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle39.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle39.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle39.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle39.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle39.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle39.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvCopyEmail.DefaultCellStyle = dataGridViewCellStyle39;
            this.dgvCopyEmail.EnableHeadersVisualStyles = false;
            this.dgvCopyEmail.Location = new System.Drawing.Point(175, 0);
            this.dgvCopyEmail.MultiSelect = false;
            this.dgvCopyEmail.Name = "dgvCopyEmail";
            this.dgvCopyEmail.RowHeadersVisible = false;
            this.dgvCopyEmail.RowHeadersWidth = 62;
            dataGridViewCellStyle40.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvCopyEmail.RowsDefaultCellStyle = dataGridViewCellStyle40;
            this.dgvCopyEmail.Size = new System.Drawing.Size(243, 55);
            this.dgvCopyEmail.TabIndex = 186;
            this.dgvCopyEmail.Visible = false;
            this.dgvCopyEmail.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCopyEmail_CellContentClick);
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "ItemCode";
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle35;
            this.dataGridViewTextBoxColumn2.HeaderText = "Item Code";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn3.DataPropertyName = "ItemDescription";
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle36;
            this.dataGridViewTextBoxColumn3.HeaderText = "Item Description";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn3.Width = 132;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Quantity";
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle37;
            this.dataGridViewTextBoxColumn5.HeaderText = "GIN Quantity";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "DeliveryMonitor";
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.dataGridViewTextBoxColumn7.DefaultCellStyle = dataGridViewCellStyle38;
            this.dataGridViewTextBoxColumn7.HeaderText = "Delivery Monitor";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(941, 12);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(90, 39);
            this.btnExit.TabIndex = 15;
            this.btnExit.Text = "Exit";
            this.toolTip1.SetToolTip(this.btnExit, "Click Here To Exit This Tab");
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click_2);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(735, 12);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(90, 39);
            this.btnSave.TabIndex = 14;
            this.btnSave.Text = "Recieve";
            this.toolTip1.SetToolTip(this.btnSave, "Click Here To Recieve Items");
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClearAll
            // 
            this.btnClearAll.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnClearAll.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnClearAll.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearAll.Location = new System.Drawing.Point(837, 12);
            this.btnClearAll.Name = "btnClearAll";
            this.btnClearAll.Size = new System.Drawing.Size(90, 39);
            this.btnClearAll.TabIndex = 12;
            this.btnClearAll.Text = "Clear All";
            this.toolTip1.SetToolTip(this.btnClearAll, "Click Here To Clear All The Fields");
            this.btnClearAll.UseVisualStyleBackColor = false;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Add-icon.png");
            this.imageList1.Images.SetKeyName(1, "table-add-icon.png");
            this.imageList1.Images.SetKeyName(2, "order-history-icon.png");
            this.imageList1.Images.SetKeyName(3, "Package-Add-icon.png");
            this.imageList1.Images.SetKeyName(4, "Excel-icon.png");
            this.imageList1.Images.SetKeyName(5, "Actions-address-book-new-icon.png");
            this.imageList1.Images.SetKeyName(6, "invoice-icon.png");
            this.imageList1.Images.SetKeyName(7, "Apps-kspread-icon.png");
            this.imageList1.Images.SetKeyName(8, "Apps-klipper-icon.png");
            this.imageList1.Images.SetKeyName(9, "Upline-icon.png");
            this.imageList1.Images.SetKeyName(10, "reports-icon.png");
            this.imageList1.Images.SetKeyName(11, "Mimetypes-application-vnd-sun-xml-calc-template-icon.png");
            this.imageList1.Images.SetKeyName(12, "catalog-icon.png");
            this.imageList1.Images.SetKeyName(13, "Add-icon.png");
            // 
            // dgPackingTaxes
            // 
            this.dgPackingTaxes.AllowUserToAddRows = false;
            this.dgPackingTaxes.AllowUserToDeleteRows = false;
            this.dgPackingTaxes.AllowUserToResizeRows = false;
            this.dgPackingTaxes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgPackingTaxes.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgPackingTaxes.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle41.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle41.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle41.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle41.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle41.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle41.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle41.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgPackingTaxes.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle41;
            this.dgPackingTaxes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgPackingTaxes.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TaxDesc,
            this.taxamount,
            this.taxIGSTRate,
            this.taxIGSTAmount,
            this.taxSGSTRate,
            this.taxSGSTAmount,
            this.taxCGSTRate,
            this.taxCGSTAmount});
            dataGridViewCellStyle46.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle46.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle46.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle46.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle46.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle46.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle46.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgPackingTaxes.DefaultCellStyle = dataGridViewCellStyle46;
            this.dgPackingTaxes.EnableHeadersVisualStyles = false;
            this.dgPackingTaxes.Location = new System.Drawing.Point(7, 507);
            this.dgPackingTaxes.MultiSelect = false;
            this.dgPackingTaxes.Name = "dgPackingTaxes";
            this.dgPackingTaxes.RowHeadersVisible = false;
            this.dgPackingTaxes.RowHeadersWidth = 62;
            this.dgPackingTaxes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgPackingTaxes.Size = new System.Drawing.Size(1057, 84);
            this.dgPackingTaxes.TabIndex = 181;
            this.dgPackingTaxes.Visible = false;
            this.dgPackingTaxes.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgPackingTaxes_CellBeginEdit);
            this.dgPackingTaxes.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgPackingTaxes_CellContentClick);
            this.dgPackingTaxes.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgPackingTaxes_CellEndEdit);
            this.dgPackingTaxes.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgPackingTaxes_EditingControlShowing);
            this.dgPackingTaxes.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgPackingTaxes_KeyUp);
            // 
            // TaxDesc
            // 
            this.TaxDesc.DataPropertyName = "TaxDescription";
            this.TaxDesc.HeaderText = "Tax Name";
            this.TaxDesc.MinimumWidth = 8;
            this.TaxDesc.Name = "TaxDesc";
            this.TaxDesc.ReadOnly = true;
            this.TaxDesc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxamount
            // 
            this.taxamount.DataPropertyName = "Amount";
            dataGridViewCellStyle42.BackColor = System.Drawing.Color.LightGreen;
            this.taxamount.DefaultCellStyle = dataGridViewCellStyle42;
            this.taxamount.HeaderText = "Amount";
            this.taxamount.MinimumWidth = 8;
            this.taxamount.Name = "taxamount";
            this.taxamount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxIGSTRate
            // 
            this.taxIGSTRate.DataPropertyName = "IGSTRate";
            dataGridViewCellStyle43.BackColor = System.Drawing.Color.LightGreen;
            this.taxIGSTRate.DefaultCellStyle = dataGridViewCellStyle43;
            this.taxIGSTRate.HeaderText = "IGST %";
            this.taxIGSTRate.MinimumWidth = 8;
            this.taxIGSTRate.Name = "taxIGSTRate";
            this.taxIGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxIGSTAmount
            // 
            this.taxIGSTAmount.DataPropertyName = "IGSTAmount";
            this.taxIGSTAmount.HeaderText = "IGST Amount";
            this.taxIGSTAmount.MinimumWidth = 8;
            this.taxIGSTAmount.Name = "taxIGSTAmount";
            this.taxIGSTAmount.ReadOnly = true;
            this.taxIGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxSGSTRate
            // 
            this.taxSGSTRate.DataPropertyName = "SGSTRate";
            dataGridViewCellStyle44.BackColor = System.Drawing.Color.LightGreen;
            this.taxSGSTRate.DefaultCellStyle = dataGridViewCellStyle44;
            this.taxSGSTRate.HeaderText = "SGST %";
            this.taxSGSTRate.MinimumWidth = 8;
            this.taxSGSTRate.Name = "taxSGSTRate";
            this.taxSGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxSGSTAmount
            // 
            this.taxSGSTAmount.DataPropertyName = "SGSTAmount";
            this.taxSGSTAmount.HeaderText = "SGST Amount";
            this.taxSGSTAmount.MinimumWidth = 8;
            this.taxSGSTAmount.Name = "taxSGSTAmount";
            this.taxSGSTAmount.ReadOnly = true;
            this.taxSGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxCGSTRate
            // 
            this.taxCGSTRate.DataPropertyName = "CGSTRate";
            dataGridViewCellStyle45.BackColor = System.Drawing.Color.LightGreen;
            this.taxCGSTRate.DefaultCellStyle = dataGridViewCellStyle45;
            this.taxCGSTRate.HeaderText = "CGST %";
            this.taxCGSTRate.MinimumWidth = 8;
            this.taxCGSTRate.Name = "taxCGSTRate";
            this.taxCGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxCGSTAmount
            // 
            this.taxCGSTAmount.DataPropertyName = "CGSTAmount";
            this.taxCGSTAmount.HeaderText = "CGST Amount";
            this.taxCGSTAmount.MinimumWidth = 8;
            this.taxCGSTAmount.Name = "taxCGSTAmount";
            this.taxCGSTAmount.ReadOnly = true;
            this.taxCGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // lblFinalNetAmount
            // 
            this.lblFinalNetAmount.AutoSize = true;
            this.lblFinalNetAmount.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinalNetAmount.ForeColor = System.Drawing.Color.Black;
            this.lblFinalNetAmount.Location = new System.Drawing.Point(995, 602);
            this.lblFinalNetAmount.Name = "lblFinalNetAmount";
            this.lblFinalNetAmount.Size = new System.Drawing.Size(121, 23);
            this.lblFinalNetAmount.TabIndex = 182;
            this.lblFinalNetAmount.Text = "Final Amount:";
            // 
            // txtFinalNetAmount
            // 
            this.txtFinalNetAmount.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtFinalNetAmount.Enabled = false;
            this.txtFinalNetAmount.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFinalNetAmount.Location = new System.Drawing.Point(1122, 602);
            this.txtFinalNetAmount.Name = "txtFinalNetAmount";
            this.txtFinalNetAmount.ReadOnly = true;
            this.txtFinalNetAmount.Size = new System.Drawing.Size(163, 27);
            this.txtFinalNetAmount.TabIndex = 183;
            this.txtFinalNetAmount.Text = "0.0";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lbltotalIGST);
            this.panel1.Controls.Add(this.label25);
            this.panel1.Controls.Add(this.lbltotalCGST);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.lbltotalSGST);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.lbltotaldiscount);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.lblTotalAmount);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Location = new System.Drawing.Point(6, 472);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1293, 36);
            this.panel1.TabIndex = 184;
            // 
            // lbltotalIGST
            // 
            this.lbltotalIGST.AutoSize = true;
            this.lbltotalIGST.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotalIGST.ForeColor = System.Drawing.Color.Black;
            this.lbltotalIGST.Location = new System.Drawing.Point(1145, 1);
            this.lbltotalIGST.Name = "lbltotalIGST";
            this.lbltotalIGST.Size = new System.Drawing.Size(23, 26);
            this.lbltotalIGST.TabIndex = 128;
            this.lbltotalIGST.Text = "0";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(1059, 4);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(91, 23);
            this.label25.TabIndex = 127;
            this.label25.Text = "Total IGST:";
            // 
            // lbltotalCGST
            // 
            this.lbltotalCGST.AutoSize = true;
            this.lbltotalCGST.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotalCGST.ForeColor = System.Drawing.Color.Black;
            this.lbltotalCGST.Location = new System.Drawing.Point(907, 4);
            this.lbltotalCGST.Name = "lbltotalCGST";
            this.lbltotalCGST.Size = new System.Drawing.Size(23, 26);
            this.lbltotalCGST.TabIndex = 126;
            this.lbltotalCGST.Text = "0";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(815, 6);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(96, 23);
            this.label21.TabIndex = 125;
            this.label21.Text = "Total CGST:";
            // 
            // lbltotalSGST
            // 
            this.lbltotalSGST.AutoSize = true;
            this.lbltotalSGST.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotalSGST.ForeColor = System.Drawing.Color.Black;
            this.lbltotalSGST.Location = new System.Drawing.Point(687, 3);
            this.lbltotalSGST.Name = "lbltotalSGST";
            this.lbltotalSGST.Size = new System.Drawing.Size(23, 26);
            this.lbltotalSGST.TabIndex = 124;
            this.lbltotalSGST.Text = "0";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Black;
            this.label23.Location = new System.Drawing.Point(591, 6);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(100, 23);
            this.label23.TabIndex = 123;
            this.label23.Text = "Total SGST :";
            // 
            // lbltotaldiscount
            // 
            this.lbltotaldiscount.AutoSize = true;
            this.lbltotaldiscount.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotaldiscount.ForeColor = System.Drawing.Color.Black;
            this.lbltotaldiscount.Location = new System.Drawing.Point(416, 4);
            this.lbltotaldiscount.Name = "lbltotaldiscount";
            this.lbltotaldiscount.Size = new System.Drawing.Size(23, 26);
            this.lbltotaldiscount.TabIndex = 122;
            this.lbltotaldiscount.Text = "0";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(293, 6);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(127, 23);
            this.label18.TabIndex = 121;
            this.label18.Text = "Total Discount:";
            // 
            // lblTotalAmount
            // 
            this.lblTotalAmount.AutoSize = true;
            this.lblTotalAmount.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalAmount.ForeColor = System.Drawing.Color.Black;
            this.lblTotalAmount.Location = new System.Drawing.Point(132, 3);
            this.lblTotalAmount.Name = "lblTotalAmount";
            this.lblTotalAmount.Size = new System.Drawing.Size(23, 26);
            this.lblTotalAmount.TabIndex = 120;
            this.lblTotalAmount.Text = "0";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(9, 3);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(125, 23);
            this.label19.TabIndex = 119;
            this.label19.Text = "Total Amount :";
            // 
            // btnAddTransport
            // 
            this.btnAddTransport.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddTransport.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold);
            this.btnAddTransport.ForeColor = System.Drawing.Color.Black;
            this.btnAddTransport.Location = new System.Drawing.Point(1105, 552);
            this.btnAddTransport.Name = "btnAddTransport";
            this.btnAddTransport.Size = new System.Drawing.Size(166, 25);
            this.btnAddTransport.TabIndex = 195;
            this.btnAddTransport.Text = "Add Transportation/Freight";
            this.btnAddTransport.UseVisualStyleBackColor = false;
            this.btnAddTransport.Visible = false;
            this.btnAddTransport.Click += new System.EventHandler(this.btnAddTransport_Click);
            // 
            // btnPackingAmount
            // 
            this.btnPackingAmount.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnPackingAmount.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPackingAmount.ForeColor = System.Drawing.Color.Black;
            this.btnPackingAmount.Location = new System.Drawing.Point(1105, 514);
            this.btnPackingAmount.Name = "btnPackingAmount";
            this.btnPackingAmount.Size = new System.Drawing.Size(166, 26);
            this.btnPackingAmount.TabIndex = 194;
            this.btnPackingAmount.Text = "Add Packing Forwarding";
            this.btnPackingAmount.UseVisualStyleBackColor = false;
            this.btnPackingAmount.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(645, 602);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(115, 23);
            this.label7.TabIndex = 199;
            this.label7.Text = "TCS Amount :";
            // 
            // txtTCSAmount
            // 
            this.txtTCSAmount.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtTCSAmount.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTCSAmount.Location = new System.Drawing.Point(758, 602);
            this.txtTCSAmount.Name = "txtTCSAmount";
            this.txtTCSAmount.Size = new System.Drawing.Size(163, 27);
            this.txtTCSAmount.TabIndex = 200;
            this.txtTCSAmount.Text = "0";
            this.txtTCSAmount.TextChanged += new System.EventHandler(this.txtTCSAmount_TextChanged);
            this.txtTCSAmount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTCSAmount_KeyPress);
            this.txtTCSAmount.Leave += new System.EventHandler(this.txtTCSAmount_Leave);
            // 
            // Select
            // 
            this.Select.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Select.Frozen = true;
            this.Select.HeaderText = "Sel";
            this.Select.MinimumWidth = 8;
            this.Select.Name = "Select";
            this.Select.Width = 51;
            // 
            // SlNo
            // 
            this.SlNo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.SlNo.DefaultCellStyle = dataGridViewCellStyle2;
            this.SlNo.Frozen = true;
            this.SlNo.HeaderText = "Sl No";
            this.SlNo.MinimumWidth = 8;
            this.SlNo.Name = "SlNo";
            this.SlNo.ReadOnly = true;
            this.SlNo.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.SlNo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SlNo.Width = 50;
            // 
            // ItemCode
            // 
            this.ItemCode.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ItemCode.DataPropertyName = "ItemCode";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ItemCode.DefaultCellStyle = dataGridViewCellStyle3;
            this.ItemCode.Frozen = true;
            this.ItemCode.HeaderText = "Item Code";
            this.ItemCode.MinimumWidth = 8;
            this.ItemCode.Name = "ItemCode";
            this.ItemCode.ReadOnly = true;
            this.ItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemCode.Width = 51;
            // 
            // ProjectCode
            // 
            this.ProjectCode.DataPropertyName = "BOMProjectCode";
            this.ProjectCode.Frozen = true;
            this.ProjectCode.HeaderText = "BOMProjectCodes";
            this.ProjectCode.MinimumWidth = 8;
            this.ProjectCode.Name = "ProjectCode";
            this.ProjectCode.Visible = false;
            this.ProjectCode.Width = 157;
            // 
            // ProductNo
            // 
            this.ProductNo.DataPropertyName = "ProductNo";
            this.ProductNo.Frozen = true;
            this.ProductNo.HeaderText = "ProductNo";
            this.ProductNo.MinimumWidth = 8;
            this.ProductNo.Name = "ProductNo";
            this.ProductNo.Visible = false;
            this.ProductNo.Width = 109;
            // 
            // ItemDescription
            // 
            this.ItemDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ItemDescription.DataPropertyName = "ItemDescription";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ItemDescription.DefaultCellStyle = dataGridViewCellStyle4;
            this.ItemDescription.Frozen = true;
            this.ItemDescription.HeaderText = "Item Description";
            this.ItemDescription.MinimumWidth = 8;
            this.ItemDescription.Name = "ItemDescription";
            this.ItemDescription.ReadOnly = true;
            this.ItemDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemDescription.Width = 132;
            // 
            // HsnSacCode
            // 
            this.HsnSacCode.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.HsnSacCode.DataPropertyName = "HsnSacCode";
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.HsnSacCode.DefaultCellStyle = dataGridViewCellStyle5;
            this.HsnSacCode.Frozen = true;
            this.HsnSacCode.HeaderText = "Hsn / Sac";
            this.HsnSacCode.MinimumWidth = 8;
            this.HsnSacCode.Name = "HsnSacCode";
            this.HsnSacCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.HsnSacCode.Width = 51;
            // 
            // OrderedQty
            // 
            this.OrderedQty.DataPropertyName = "RequariedQty";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.OrderedQty.DefaultCellStyle = dataGridViewCellStyle6;
            this.OrderedQty.HeaderText = "PO Qty";
            this.OrderedQty.MinimumWidth = 8;
            this.OrderedQty.Name = "OrderedQty";
            this.OrderedQty.ReadOnly = true;
            this.OrderedQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OrderedQty.Visible = false;
            this.OrderedQty.Width = 58;
            // 
            // totalOrderedQty
            // 
            this.totalOrderedQty.DataPropertyName = "TotalRequariedQty";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.totalOrderedQty.DefaultCellStyle = dataGridViewCellStyle7;
            this.totalOrderedQty.HeaderText = "PO Qty";
            this.totalOrderedQty.MinimumWidth = 8;
            this.totalOrderedQty.Name = "totalOrderedQty";
            this.totalOrderedQty.ReadOnly = true;
            this.totalOrderedQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.totalOrderedQty.Width = 58;
            // 
            // totalRemainingQty
            // 
            this.totalRemainingQty.DataPropertyName = "totalRemainingQty";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.totalRemainingQty.DefaultCellStyle = dataGridViewCellStyle8;
            this.totalRemainingQty.HeaderText = "Rem Qty";
            this.totalRemainingQty.MinimumWidth = 8;
            this.totalRemainingQty.Name = "totalRemainingQty";
            this.totalRemainingQty.ReadOnly = true;
            this.totalRemainingQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.totalRemainingQty.Width = 67;
            // 
            // RecieveQuantity
            // 
            this.RecieveQuantity.DataPropertyName = "Quantity";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.Yellow;
            this.RecieveQuantity.DefaultCellStyle = dataGridViewCellStyle9;
            this.RecieveQuantity.HeaderText = "Rec Qty";
            this.RecieveQuantity.MinimumWidth = 8;
            this.RecieveQuantity.Name = "RecieveQuantity";
            this.RecieveQuantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RecieveQuantity.Visible = false;
            this.RecieveQuantity.Width = 61;
            // 
            // temRecieveQuantity
            // 
            this.temRecieveQuantity.DataPropertyName = "Quantity";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.Yellow;
            this.temRecieveQuantity.DefaultCellStyle = dataGridViewCellStyle10;
            this.temRecieveQuantity.HeaderText = "Rec Qty";
            this.temRecieveQuantity.MinimumWidth = 8;
            this.temRecieveQuantity.Name = "temRecieveQuantity";
            this.temRecieveQuantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.temRecieveQuantity.Width = 61;
            // 
            // UnitCost
            // 
            this.UnitCost.DataPropertyName = "UnitPrice";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.UnitCost.DefaultCellStyle = dataGridViewCellStyle11;
            this.UnitCost.HeaderText = "Unit Cost";
            this.UnitCost.MinimumWidth = 8;
            this.UnitCost.Name = "UnitCost";
            this.UnitCost.ReadOnly = true;
            this.UnitCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitCost.Width = 69;
            // 
            // DiscRate
            // 
            this.DiscRate.DataPropertyName = "DiscRate";
            this.DiscRate.HeaderText = "Disc %";
            this.DiscRate.MinimumWidth = 8;
            this.DiscRate.Name = "DiscRate";
            this.DiscRate.ReadOnly = true;
            this.DiscRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DiscRate.Width = 52;
            // 
            // TotalAmount
            // 
            this.TotalAmount.DataPropertyName = "TotalAmount";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.TotalAmount.DefaultCellStyle = dataGridViewCellStyle12;
            this.TotalAmount.HeaderText = "Amount";
            this.TotalAmount.MinimumWidth = 8;
            this.TotalAmount.Name = "TotalAmount";
            this.TotalAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.TotalAmount.Width = 71;
            // 
            // TotalPOAmount
            // 
            this.TotalPOAmount.DataPropertyName = "TotalPOAmount";
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.TotalPOAmount.DefaultCellStyle = dataGridViewCellStyle13;
            this.TotalPOAmount.HeaderText = "POAmount";
            this.TotalPOAmount.MinimumWidth = 8;
            this.TotalPOAmount.Name = "TotalPOAmount";
            this.TotalPOAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.TotalPOAmount.Width = 91;
            // 
            // SGSTTotalAmount
            // 
            this.SGSTTotalAmount.DataPropertyName = "SGSTTotalAmount";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle14.Format = "N2";
            dataGridViewCellStyle14.NullValue = null;
            this.SGSTTotalAmount.DefaultCellStyle = dataGridViewCellStyle14;
            this.SGSTTotalAmount.HeaderText = "SGST Amt";
            this.SGSTTotalAmount.MinimumWidth = 8;
            this.SGSTTotalAmount.Name = "SGSTTotalAmount";
            this.SGSTTotalAmount.ReadOnly = true;
            this.SGSTTotalAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SGSTTotalAmount.Width = 74;
            // 
            // CGSTTotalAmount
            // 
            this.CGSTTotalAmount.DataPropertyName = "CGSTTotalAmount";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle15.Format = "N2";
            dataGridViewCellStyle15.NullValue = null;
            this.CGSTTotalAmount.DefaultCellStyle = dataGridViewCellStyle15;
            this.CGSTTotalAmount.HeaderText = "CGST Amt";
            this.CGSTTotalAmount.MinimumWidth = 8;
            this.CGSTTotalAmount.Name = "CGSTTotalAmount";
            this.CGSTTotalAmount.ReadOnly = true;
            this.CGSTTotalAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CGSTTotalAmount.Width = 74;
            // 
            // IGSTTotalAmount
            // 
            this.IGSTTotalAmount.DataPropertyName = "IGSTTotalAmount";
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle16.Format = "N2";
            dataGridViewCellStyle16.NullValue = null;
            this.IGSTTotalAmount.DefaultCellStyle = dataGridViewCellStyle16;
            this.IGSTTotalAmount.HeaderText = "IGST Amt";
            this.IGSTTotalAmount.MinimumWidth = 8;
            this.IGSTTotalAmount.Name = "IGSTTotalAmount";
            this.IGSTTotalAmount.ReadOnly = true;
            this.IGSTTotalAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IGSTTotalAmount.Width = 70;
            // 
            // batchCode
            // 
            this.batchCode.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.batchCode.DataPropertyName = "batchCode";
            this.batchCode.HeaderText = "Batch Code";
            this.batchCode.MinimumWidth = 8;
            this.batchCode.Name = "batchCode";
            this.batchCode.ReadOnly = true;
            this.batchCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.batchCode.Width = 140;
            // 
            // itemLocation
            // 
            this.itemLocation.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.itemLocation.DataPropertyName = "itemLocation";
            this.itemLocation.HeaderText = "Location";
            this.itemLocation.MinimumWidth = 8;
            this.itemLocation.Name = "itemLocation";
            this.itemLocation.ReadOnly = true;
            this.itemLocation.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.itemLocation.Width = 180;
            // 
            // DiscAmount
            // 
            this.DiscAmount.DataPropertyName = "DiscAmount";
            this.DiscAmount.HeaderText = "Disc Amt";
            this.DiscAmount.MinimumWidth = 8;
            this.DiscAmount.Name = "DiscAmount";
            this.DiscAmount.ReadOnly = true;
            this.DiscAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DiscAmount.Width = 68;
            // 
            // Amount
            // 
            this.Amount.DataPropertyName = "Amount";
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Amount.DefaultCellStyle = dataGridViewCellStyle17;
            this.Amount.HeaderText = "Amount";
            this.Amount.MinimumWidth = 8;
            this.Amount.Name = "Amount";
            this.Amount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Amount.Visible = false;
            this.Amount.Width = 71;
            // 
            // POAmount
            // 
            this.POAmount.DataPropertyName = "POAmount";
            this.POAmount.HeaderText = "POAmount";
            this.POAmount.MinimumWidth = 8;
            this.POAmount.Name = "POAmount";
            this.POAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.POAmount.Visible = false;
            this.POAmount.Width = 91;
            // 
            // SGSTRate
            // 
            this.SGSTRate.DataPropertyName = "SGSTRate";
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.SGSTRate.DefaultCellStyle = dataGridViewCellStyle18;
            this.SGSTRate.HeaderText = "SGST %";
            this.SGSTRate.MinimumWidth = 8;
            this.SGSTRate.Name = "SGSTRate";
            this.SGSTRate.ReadOnly = true;
            this.SGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SGSTRate.Width = 59;
            // 
            // SGSTAmount
            // 
            this.SGSTAmount.DataPropertyName = "SGSTAmount";
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle19.Format = "N2";
            this.SGSTAmount.DefaultCellStyle = dataGridViewCellStyle19;
            this.SGSTAmount.HeaderText = "SGST Amt";
            this.SGSTAmount.MinimumWidth = 8;
            this.SGSTAmount.Name = "SGSTAmount";
            this.SGSTAmount.ReadOnly = true;
            this.SGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SGSTAmount.Visible = false;
            this.SGSTAmount.Width = 74;
            // 
            // CGSTRate
            // 
            this.CGSTRate.DataPropertyName = "CGSTRate";
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.CGSTRate.DefaultCellStyle = dataGridViewCellStyle20;
            this.CGSTRate.HeaderText = "CGST %";
            this.CGSTRate.MinimumWidth = 8;
            this.CGSTRate.Name = "CGSTRate";
            this.CGSTRate.ReadOnly = true;
            this.CGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CGSTRate.Width = 59;
            // 
            // CGSTAmount
            // 
            this.CGSTAmount.DataPropertyName = "CGSTAmount";
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle21.Format = "N2";
            this.CGSTAmount.DefaultCellStyle = dataGridViewCellStyle21;
            this.CGSTAmount.HeaderText = "CGST Amt";
            this.CGSTAmount.MinimumWidth = 8;
            this.CGSTAmount.Name = "CGSTAmount";
            this.CGSTAmount.ReadOnly = true;
            this.CGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CGSTAmount.Visible = false;
            this.CGSTAmount.Width = 74;
            // 
            // IGSTRate
            // 
            this.IGSTRate.DataPropertyName = "IGSTRate";
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.IGSTRate.DefaultCellStyle = dataGridViewCellStyle22;
            this.IGSTRate.HeaderText = "IGST %";
            this.IGSTRate.MinimumWidth = 8;
            this.IGSTRate.Name = "IGSTRate";
            this.IGSTRate.ReadOnly = true;
            this.IGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IGSTRate.Width = 55;
            // 
            // IGSTAmount
            // 
            this.IGSTAmount.DataPropertyName = "IGSTAmount";
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle23.Format = "N2";
            dataGridViewCellStyle23.NullValue = null;
            this.IGSTAmount.DefaultCellStyle = dataGridViewCellStyle23;
            this.IGSTAmount.HeaderText = "IGST Amt";
            this.IGSTAmount.MinimumWidth = 8;
            this.IGSTAmount.Name = "IGSTAmount";
            this.IGSTAmount.ReadOnly = true;
            this.IGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IGSTAmount.Visible = false;
            this.IGSTAmount.Width = 70;
            // 
            // Freight
            // 
            this.Freight.DataPropertyName = "Freight";
            dataGridViewCellStyle24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Freight.DefaultCellStyle = dataGridViewCellStyle24;
            this.Freight.HeaderText = "Import Freight";
            this.Freight.MinimumWidth = 8;
            this.Freight.Name = "Freight";
            this.Freight.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Freight.Width = 103;
            // 
            // CustomsDuty
            // 
            this.CustomsDuty.DataPropertyName = "CustomsDuty";
            dataGridViewCellStyle25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.CustomsDuty.DefaultCellStyle = dataGridViewCellStyle25;
            this.CustomsDuty.HeaderText = "Customs Duty %";
            this.CustomsDuty.MinimumWidth = 8;
            this.CustomsDuty.Name = "CustomsDuty";
            this.CustomsDuty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CustomsDuty.Width = 102;
            // 
            // CustomsDutyAmt
            // 
            this.CustomsDutyAmt.DataPropertyName = "CustomsDutyAmt";
            dataGridViewCellStyle26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.CustomsDutyAmt.DefaultCellStyle = dataGridViewCellStyle26;
            this.CustomsDutyAmt.HeaderText = "Customs Duty Amt";
            this.CustomsDutyAmt.MinimumWidth = 8;
            this.CustomsDutyAmt.Name = "CustomsDutyAmt";
            this.CustomsDutyAmt.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CustomsDutyAmt.Width = 102;
            // 
            // Cess
            // 
            this.Cess.DataPropertyName = "Cess";
            dataGridViewCellStyle27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Cess.DefaultCellStyle = dataGridViewCellStyle27;
            this.Cess.HeaderText = "Cess %";
            this.Cess.MinimumWidth = 8;
            this.Cess.Name = "Cess";
            this.Cess.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Cess.Width = 53;
            // 
            // CessAmt
            // 
            this.CessAmt.DataPropertyName = "CessAmt";
            dataGridViewCellStyle28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.CessAmt.DefaultCellStyle = dataGridViewCellStyle28;
            this.CessAmt.HeaderText = "Cess Amt";
            this.CessAmt.MinimumWidth = 8;
            this.CessAmt.Name = "CessAmt";
            this.CessAmt.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CessAmt.Width = 68;
            // 
            // CDIGST
            // 
            this.CDIGST.DataPropertyName = "CDIGST";
            dataGridViewCellStyle29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.CDIGST.DefaultCellStyle = dataGridViewCellStyle29;
            this.CDIGST.HeaderText = "CDIGST %";
            this.CDIGST.MinimumWidth = 8;
            this.CDIGST.Name = "CDIGST";
            this.CDIGST.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CDIGST.Width = 71;
            // 
            // CDIGSTAmt
            // 
            this.CDIGSTAmt.DataPropertyName = "CDIGSTAmt";
            dataGridViewCellStyle30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.CDIGSTAmt.DefaultCellStyle = dataGridViewCellStyle30;
            this.CDIGSTAmt.HeaderText = "CDIGST Amt";
            this.CDIGSTAmt.MinimumWidth = 8;
            this.CDIGSTAmt.Name = "CDIGSTAmt";
            this.CDIGSTAmt.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CDIGSTAmt.Width = 86;
            // 
            // RemainingQty
            // 
            this.RemainingQty.DataPropertyName = "RemainingQty";
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.RemainingQty.DefaultCellStyle = dataGridViewCellStyle31;
            this.RemainingQty.HeaderText = "old Rem Qty";
            this.RemainingQty.MinimumWidth = 8;
            this.RemainingQty.Name = "RemainingQty";
            this.RemainingQty.ReadOnly = true;
            this.RemainingQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RemainingQty.Visible = false;
            this.RemainingQty.Width = 90;
            // 
            // frmReciept
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1343, 702);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtTCSAmount);
            this.Controls.Add(this.btnAddTransport);
            this.Controls.Add(this.btnPackingAmount);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblFinalNetAmount);
            this.Controls.Add(this.txtFinalNetAmount);
            this.Controls.Add(this.dgPackingTaxes);
            this.Controls.Add(this.pnPOWO);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.dgvPOItemList);
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmReciept";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GIN Reciept";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmReciept_FormClosing);
            this.Load += new System.EventHandler(this.frmReciept_Load);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.pnPOWO.ResumeLayout(false);
            this.pnPOWO.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPOItemList)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCopyEmail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgPackingTaxes)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.DataGridView dgvPOItemList;
        private System.Windows.Forms.ComboBox cmbPonumber;
        private System.Windows.Forms.DateTimePicker dtpInvoiceDate;
        private System.Windows.Forms.DateTimePicker dtpGINDate;
        private System.Windows.Forms.Label lbldate;
        private System.Windows.Forms.Label lblVendorname;
        private System.Windows.Forms.Label lblVendorcode;
        private System.Windows.Forms.Label lblWonumber;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClearAll;
        private System.Windows.Forms.TextBox txtinvoiceno;
        private System.Windows.Forms.Label lblSupplierinvoicenumber;
        private System.Windows.Forms.Label lblGinnumber;
        private System.Windows.Forms.ComboBox cmbJobstatus;
        private System.Windows.Forms.Label lblJobstatus;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Label lblpogenaratedby;
        private System.Windows.Forms.Label lblprojectcode;
        private System.Windows.Forms.Label lblprojectname;
        private System.Windows.Forms.Label lblinvoicedate;
        private System.Windows.Forms.Panel pnPOWO;
        private System.Windows.Forms.Label lblwonum;
        private System.Windows.Forms.CheckBox chkGINWO;
        private System.Windows.Forms.CheckBox chkGINPO;
        private System.Windows.Forms.Label lblCustomer;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lblpartreciept;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.Label lbltime;
        private System.Windows.Forms.Label lblcustomername;
        private System.Windows.Forms.Label lblprojectdesc;
        private System.Windows.Forms.Label lblVendor;
        private System.Windows.Forms.Label lblprojcode;
        private System.Windows.Forms.Label txtVendorcode;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblpowoby;
        private System.Windows.Forms.TextBox lblGinno;
        private System.Windows.Forms.DataGridView dgPackingTaxes;
        private System.Windows.Forms.Label lblFinalNetAmount;
        private System.Windows.Forms.TextBox txtFinalNetAmount;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbltotalIGST;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label lbltotalCGST;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lbltotalSGST;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label lbltotaldiscount;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lblTotalAmount;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox cmbLedger;
        private System.Windows.Forms.DataGridView dgvCopyEmail;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.CheckBox chkOtherItems;
        private System.Windows.Forms.Button btnAddTransport;
        private System.Windows.Forms.Button btnPackingAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn TaxDesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxamount;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxIGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxIGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxSGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxSGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxCGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxCGSTAmount;
        private System.Windows.Forms.Label lblGSTCode;
        private System.Windows.Forms.ListBox lstusers;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtTCSAmount;
        private System.Windows.Forms.Button btnscan;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBRate;
        private System.Windows.Forms.TextBox combocurrency;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblCountry;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Select;
        private System.Windows.Forms.DataGridViewTextBoxColumn SlNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn HsnSacCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn OrderedQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalOrderedQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalRemainingQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn RecieveQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn temRecieveQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiscRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn TotalAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn TotalPOAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn SGSTTotalAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn CGSTTotalAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn IGSTTotalAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn batchCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemLocation;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiscAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn POAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn SGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn SGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn CGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn CGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn IGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn IGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn Freight;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomsDuty;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomsDutyAmt;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cess;
        private System.Windows.Forms.DataGridViewTextBoxColumn CessAmt;
        private System.Windows.Forms.DataGridViewTextBoxColumn CDIGST;
        private System.Windows.Forms.DataGridViewTextBoxColumn CDIGSTAmt;
        private System.Windows.Forms.DataGridViewTextBoxColumn RemainingQty;
        //DataGridViewComboBoxColumn
    }
}
