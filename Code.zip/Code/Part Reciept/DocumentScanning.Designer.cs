﻿
namespace Erp_Project_With_Buttons.Part_Reciept
{
    partial class DocumentScanning
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DocumentScanning));
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtpages = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Multiplescanbtn = new System.Windows.Forms.Button();
            this.scannerlbl = new System.Windows.Forms.Label();
            this.Btnscandoc = new System.Windows.Forms.Button();
            this.ListOfScanner = new System.Windows.Forms.ListBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblgintext = new System.Windows.Forms.Label();
            this.labelginnumber = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblbasicvalue = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblsgstamount = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lbligstamount = new System.Windows.Forms.Label();
            this.lblcgstamount = new System.Windows.Forms.Label();
            this.lblpackingforward = new System.Windows.Forms.Label();
            this.lblgrossvalue = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.btnUpload = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightGray;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.btnUpload);
            this.panel1.Controls.Add(this.txtpages);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.Multiplescanbtn);
            this.panel1.Controls.Add(this.scannerlbl);
            this.panel1.Controls.Add(this.Btnscandoc);
            this.panel1.Controls.Add(this.ListOfScanner);
            this.panel1.Location = new System.Drawing.Point(32, 26);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(353, 290);
            this.panel1.TabIndex = 0;
            // 
            // txtpages
            // 
            this.txtpages.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpages.Location = new System.Drawing.Point(116, 184);
            this.txtpages.Name = "txtpages";
            this.txtpages.Size = new System.Drawing.Size(91, 26);
            this.txtpages.TabIndex = 5;
            this.txtpages.Visible = false;
            this.txtpages.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtpages_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(20, 187);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 18);
            this.label2.TabIndex = 4;
            this.label2.Text = "No Of Pages :";
            this.label2.Visible = false;
            // 
            // Multiplescanbtn
            // 
            this.Multiplescanbtn.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Multiplescanbtn.Location = new System.Drawing.Point(242, 176);
            this.Multiplescanbtn.Name = "Multiplescanbtn";
            this.Multiplescanbtn.Size = new System.Drawing.Size(60, 35);
            this.Multiplescanbtn.TabIndex = 3;
            this.Multiplescanbtn.Text = "Scan Multiple Doc";
            this.Multiplescanbtn.UseVisualStyleBackColor = true;
            this.Multiplescanbtn.Visible = false;
            this.Multiplescanbtn.Click += new System.EventHandler(this.Multiplescanbtn_Click_1);
            // 
            // scannerlbl
            // 
            this.scannerlbl.AutoSize = true;
            this.scannerlbl.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scannerlbl.Location = new System.Drawing.Point(20, 15);
            this.scannerlbl.Name = "scannerlbl";
            this.scannerlbl.Size = new System.Drawing.Size(145, 23);
            this.scannerlbl.TabIndex = 2;
            this.scannerlbl.Text = "List Of Scanners :";
            this.scannerlbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Btnscandoc
            // 
            this.Btnscandoc.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btnscandoc.Location = new System.Drawing.Point(224, 239);
            this.Btnscandoc.Name = "Btnscandoc";
            this.Btnscandoc.Size = new System.Drawing.Size(112, 35);
            this.Btnscandoc.TabIndex = 2;
            this.Btnscandoc.Text = "Scan";
            this.Btnscandoc.UseVisualStyleBackColor = true;
            this.Btnscandoc.Click += new System.EventHandler(this.Btnscandoc_Click);
            // 
            // ListOfScanner
            // 
            this.ListOfScanner.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ListOfScanner.FormattingEnabled = true;
            this.ListOfScanner.ItemHeight = 18;
            this.ListOfScanner.Location = new System.Drawing.Point(23, 58);
            this.ListOfScanner.Name = "ListOfScanner";
            this.ListOfScanner.Size = new System.Drawing.Size(279, 112);
            this.ListOfScanner.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Location = new System.Drawing.Point(402, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(838, 634);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // lblgintext
            // 
            this.lblgintext.AutoSize = true;
            this.lblgintext.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgintext.Location = new System.Drawing.Point(97, 431);
            this.lblgintext.Name = "lblgintext";
            this.lblgintext.Size = new System.Drawing.Size(68, 19);
            this.lblgintext.TabIndex = 2;
            this.lblgintext.Text = "GIN NO :";
            this.lblgintext.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelginnumber
            // 
            this.labelginnumber.AutoSize = true;
            this.labelginnumber.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelginnumber.Location = new System.Drawing.Point(174, 432);
            this.labelginnumber.Name = "labelginnumber";
            this.labelginnumber.Size = new System.Drawing.Size(15, 18);
            this.labelginnumber.TabIndex = 3;
            this.labelginnumber.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(76, 460);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 19);
            this.label1.TabIndex = 4;
            this.label1.Text = "Basic Value :";
            // 
            // lblbasicvalue
            // 
            this.lblbasicvalue.AutoSize = true;
            this.lblbasicvalue.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbasicvalue.Location = new System.Drawing.Point(174, 464);
            this.lblbasicvalue.Name = "lblbasicvalue";
            this.lblbasicvalue.Size = new System.Drawing.Size(15, 18);
            this.lblbasicvalue.TabIndex = 5;
            this.lblbasicvalue.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(57, 491);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 19);
            this.label3.TabIndex = 6;
            this.label3.Text = "SGST Amount :";
            // 
            // lblsgstamount
            // 
            this.lblsgstamount.AutoSize = true;
            this.lblsgstamount.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsgstamount.Location = new System.Drawing.Point(174, 497);
            this.lblsgstamount.Name = "lblsgstamount";
            this.lblsgstamount.Size = new System.Drawing.Size(15, 18);
            this.lblsgstamount.TabIndex = 7;
            this.lblsgstamount.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 581);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(156, 19);
            this.label5.TabIndex = 11;
            this.label5.Text = "Packing & Forwarding :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(61, 550);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(107, 19);
            this.label6.TabIndex = 10;
            this.label6.Text = "IGST Amount :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(73, 610);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(95, 19);
            this.label7.TabIndex = 9;
            this.label7.Text = "Gross Value :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(57, 520);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(111, 19);
            this.label8.TabIndex = 8;
            this.label8.Text = "CGST Amount :";
            // 
            // lbligstamount
            // 
            this.lbligstamount.AutoSize = true;
            this.lbligstamount.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbligstamount.Location = new System.Drawing.Point(174, 556);
            this.lbligstamount.Name = "lbligstamount";
            this.lbligstamount.Size = new System.Drawing.Size(15, 18);
            this.lbligstamount.TabIndex = 12;
            this.lbligstamount.Text = "0";
            // 
            // lblcgstamount
            // 
            this.lblcgstamount.AutoSize = true;
            this.lblcgstamount.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcgstamount.Location = new System.Drawing.Point(174, 526);
            this.lblcgstamount.Name = "lblcgstamount";
            this.lblcgstamount.Size = new System.Drawing.Size(15, 18);
            this.lblcgstamount.TabIndex = 13;
            this.lblcgstamount.Text = "0";
            // 
            // lblpackingforward
            // 
            this.lblpackingforward.AutoSize = true;
            this.lblpackingforward.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpackingforward.Location = new System.Drawing.Point(174, 587);
            this.lblpackingforward.Name = "lblpackingforward";
            this.lblpackingforward.Size = new System.Drawing.Size(15, 18);
            this.lblpackingforward.TabIndex = 14;
            this.lblpackingforward.Text = "0";
            // 
            // lblgrossvalue
            // 
            this.lblgrossvalue.AutoSize = true;
            this.lblgrossvalue.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgrossvalue.Location = new System.Drawing.Point(174, 611);
            this.lblgrossvalue.Name = "lblgrossvalue";
            this.lblgrossvalue.Size = new System.Drawing.Size(15, 18);
            this.lblgrossvalue.TabIndex = 15;
            this.lblgrossvalue.Text = "0";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog1_FileOk);
            // 
            // btnUpload
            // 
            this.btnUpload.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpload.Location = new System.Drawing.Point(14, 239);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(177, 35);
            this.btnUpload.TabIndex = 16;
            this.btnUpload.Text = "Upload Document";
            this.btnUpload.UseVisualStyleBackColor = true;
            this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click);
            // 
            // DocumentScanning
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1294, 681);
            this.Controls.Add(this.lblgrossvalue);
            this.Controls.Add(this.lblpackingforward);
            this.Controls.Add(this.lblcgstamount);
            this.Controls.Add(this.lbligstamount);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lblsgstamount);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblbasicvalue);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelginnumber);
            this.Controls.Add(this.lblgintext);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "DocumentScanning";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DocumentScanning";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmScanning_FormClosing);
            this.Load += new System.EventHandler(this.DocumentScanning_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ListBox ListOfScanner;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Btnscandoc;
        private System.Windows.Forms.Label scannerlbl;
        private System.Windows.Forms.Label lblgintext;
        private System.Windows.Forms.Label labelginnumber;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblbasicvalue;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblsgstamount;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lbligstamount;
        private System.Windows.Forms.Label lblcgstamount;
        private System.Windows.Forms.Label lblpackingforward;
        private System.Windows.Forms.Label lblgrossvalue;
        private System.Windows.Forms.Button Multiplescanbtn;
        private System.Windows.Forms.TextBox txtpages;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btnUpload;
    }
}
