﻿//frmInventoryLedger

namespace Erp_Project_With_Buttons.Part_Reciept
{
    partial class frmInventoryLedger
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmInventoryLedger));
            this.lblitemdescrption = new System.Windows.Forms.Label();
            this.lblavailableqty = new System.Windows.Forms.Label();
            this.lblavaqty = new System.Windows.Forms.Label();
            this.lblrepeatCost = new System.Windows.Forms.Label();
            this.lblRepeatitemcode = new System.Windows.Forms.Label();
            this.lblUnitCost = new System.Windows.Forms.Label();
            this.lblItemcode = new System.Windows.Forms.Label();
            this.dgvmaterialLedger = new System.Windows.Forms.DataGridView();
            this.Date1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Recieved = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Issued = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Return = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StockAdjsued = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitcost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.refnumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.projectcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Customer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.User = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblNoitems = new System.Windows.Forms.Label();
            this.dtpfromdate = new System.Windows.Forms.DateTimePicker();
            this.dtptodate = new System.Windows.Forms.DateTimePicker();
            this.lblfromdate = new System.Windows.Forms.Label();
            this.lbltodate = new System.Windows.Forms.Label();
            this.btnmaterialledger = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.inventoryReceivedQty = new System.Windows.Forms.Label();
            this.Receivedlb = new System.Windows.Forms.Label();
            this.inventoryQuarantineQty = new System.Windows.Forms.Label();
            this.Quarantinelb = new System.Windows.Forms.Label();
            this.inventoryReturnQty = new System.Windows.Forms.Label();
            this.Returnlb = new System.Windows.Forms.Label();
            this.inventoryIssueQty = new System.Windows.Forms.Label();
            this.Issuelb = new System.Windows.Forms.Label();
            this.inventoryIndentQty = new System.Windows.Forms.Label();
            this.Indentlb = new System.Windows.Forms.Label();
            this.inventoryAvailableQty = new System.Windows.Forms.Label();
            this.AvailableQtylb = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblitemname = new System.Windows.Forms.Label();
            this.Project = new System.Windows.Forms.CheckBox();
            this.inventoryVendorTextBox = new System.Windows.Forms.TextBox();
            this.Vendorlb = new System.Windows.Forms.Label();
            this.Tolb = new System.Windows.Forms.Label();
            this.From = new System.Windows.Forms.Label();
            this.inventoryToDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.inventoryFromIndateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.btnAllledger = new System.Windows.Forms.Button();
            this.lblItemReturn = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblStockAdjusted = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblClosingStock = new System.Windows.Forms.Label();
            this.lblIssue = new System.Windows.Forms.Label();
            this.lblRecipt = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblOpeningBalance = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnExportExcel = new System.Windows.Forms.Button();
            this.txtItemDescription = new System.Windows.Forms.TextBox();
            this.chklbItemList = new System.Windows.Forms.CheckedListBox();
            this.lblrecievqty = new System.Windows.Forms.Label();
            this.lblissuedqty = new System.Windows.Forms.Label();
            this.lblreturnqty = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.chkItemDesc = new System.Windows.Forms.CheckBox();
            this.chkItemCode = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lblStockAdjused = new System.Windows.Forms.Label();
            this.dgvALLLedgerReport = new System.Windows.Forms.DataGridView();
            this.btnExit = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.GINReverse = new System.Windows.Forms.Button();
            this.currentStock = new System.Windows.Forms.Button();
            this.IssueLog = new System.Windows.Forms.Button();
            this.ScrapLog = new System.Windows.Forms.Button();
            this.ReturnItem = new System.Windows.Forms.Button();
            this.FIFOLog = new System.Windows.Forms.Button();
            this.IndentLog = new System.Windows.Forms.Button();
            this.GINLog = new System.Windows.Forms.Button();
            this.dataGridViewGIN = new System.Windows.Forms.DataGridView();
            this.GINNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemCodeGIN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CreateDateGIN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RefNumberGIN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectCodeGIN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.POQtYGIN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReceivedQtYGIN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RemainingQtyGIN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitCostGIN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SGSTGIN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CGSTGIN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IGSTGIN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.POAmountGIN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BatchCodeGIN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LocationGIN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IndentQtyGIN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IssuedQtyGIN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.QRPrintStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BOMProjectCodeGIN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IndentLogDataGrideViewold = new System.Windows.Forms.DataGridView();
            this.IndentNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IndentItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IndentProjectCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IndentBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IndentDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IndentQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IndentStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GINNumberIndent = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BatchCodeIndent = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LocationIndent = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PickedLocationIndent = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PickedBatchCodeIndent = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IndentFIFO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IndentLogDataGrideView = new System.Windows.Forms.DataGridView();
            this.ItemCodeFIFO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IndentNoFIFO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IndentQtyFIFO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectCodeFIFO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RemarksFIFO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GINNumberFIFO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BatchCodeFIFO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LocationFIFO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PickedBatchCodeFIFO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PickedLocationFIFO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IndentPickedByFIFO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IssuedByFIFO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CreateDateFIFO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FIFOFollowed = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReturnItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReturnIndentNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReturnProjectCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReturnQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReturnCreateDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReturnedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReturnProjectStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReturnGINNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReturnBatchCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReturnLocation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReturnVendorCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReturnType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ScrapItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ScrapIndentNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ScrapProjectCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ScrapQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ScrapCreateDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ScrapReturnedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ScrapProjectStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ScrapGINNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ScrapBatchCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ScrapLocation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ScrapReturnType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewFIFOLog = new System.Windows.Forms.DataGridView();
            this.dataGridViewReturnLog = new System.Windows.Forms.DataGridView();
            this.dataGridViewScrapLog = new System.Windows.Forms.DataGridView();
            this.dataGridViewIssueLog = new System.Windows.Forms.DataGridView();
            this.IssueLog_ItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IssueLog_IndentNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IssueLog_ProjectCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IssueLog_IndentBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IssueLog_IndentQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IssueLog_IssuedQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IssueLog_IssueType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IssueLog_Remarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IssueLog_Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IssueLog_ProjectBOMCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IssueLog_ProductNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IssueLog_GINNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IssueLog_BatchCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IssueLog_Location = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IssueLog_IssuedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IssueLog_IssuedServerDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel3 = new System.Windows.Forms.Panel();
            this.indentNotextBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.inventoryLocationtextBox = new System.Windows.Forms.TextBox();
            this.flLocation = new System.Windows.Forms.Label();
            this.btnApplyFilter = new System.Windows.Forms.Button();
            this.btnClearFilter = new System.Windows.Forms.Button();
            this.flCategory = new System.Windows.Forms.Label();
            this.inventoryCategoryTextBox = new System.Windows.Forms.TextBox();
            this.flProjectCode = new System.Windows.Forms.Label();
            this.inventoryProjectTextBox = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.currentStockApplyFilter = new System.Windows.Forms.Button();
            this.currentStockClearFilter = new System.Windows.Forms.Button();
            this.currentStockStockCostTextBox = new System.Windows.Forms.TextBox();
            this.currentStockUnitCostTextBox = new System.Windows.Forms.TextBox();
            this.currentStockLocationTextBox = new System.Windows.Forms.TextBox();
            this.currentstockItemCodeTextBox = new System.Windows.Forms.TextBox();
            this.lbStockCost = new System.Windows.Forms.Label();
            this.lbUnitCost = new System.Windows.Forms.Label();
            this.lbLocation = new System.Windows.Forms.Label();
            this.lbItemCode = new System.Windows.Forms.Label();
            this.currentStockdataGridView = new System.Windows.Forms.DataGridView();
            this.stockItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stockItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stockLocation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.currentStockUnitCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.currentStockAvailableQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.currentStockValue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.curretnStockPurchaseType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.currentStockCreatedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewGINReverse = new System.Windows.Forms.DataGridView();
            this.ItemCodeReverse = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GINNumberReverse = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReturnQTYReverse = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitPriceReverse = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.InvoiceNumberReverse = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VendorNameReverse = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VendorCodeReverse = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GINDateReverse = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.InvoiceDateReverse = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReverseGINDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dgvmaterialLedger)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvALLLedgerReport)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGIN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.IndentLogDataGrideViewold)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.IndentLogDataGrideView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFIFOLog)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewReturnLog)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewScrapLog)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewIssueLog)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.currentStockdataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGINReverse)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblitemdescrption
            // 
            this.lblitemdescrption.AutoSize = true;
            this.lblitemdescrption.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblitemdescrption.ForeColor = System.Drawing.Color.Black;
            this.lblitemdescrption.Location = new System.Drawing.Point(9, 44);
            this.lblitemdescrption.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lblitemdescrption.Name = "lblitemdescrption";
            this.lblitemdescrption.Size = new System.Drawing.Size(151, 23);
            this.lblitemdescrption.TabIndex = 19;
            this.lblitemdescrption.Text = "Item Description :";
            // 
            // lblavailableqty
            // 
            this.lblavailableqty.AutoSize = true;
            this.lblavailableqty.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblavailableqty.ForeColor = System.Drawing.Color.Black;
            this.lblavailableqty.Location = new System.Drawing.Point(163, 116);
            this.lblavailableqty.Name = "lblavailableqty";
            this.lblavailableqty.Size = new System.Drawing.Size(20, 23);
            this.lblavailableqty.TabIndex = 117;
            this.lblavailableqty.Text = "0";
            // 
            // lblavaqty
            // 
            this.lblavaqty.AutoSize = true;
            this.lblavaqty.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblavaqty.ForeColor = System.Drawing.Color.Black;
            this.lblavaqty.Location = new System.Drawing.Point(36, 116);
            this.lblavaqty.Name = "lblavaqty";
            this.lblavaqty.Size = new System.Drawing.Size(126, 23);
            this.lblavaqty.TabIndex = 116;
            this.lblavaqty.Text = "Available Qty :";
            // 
            // lblrepeatCost
            // 
            this.lblrepeatCost.AutoSize = true;
            this.lblrepeatCost.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrepeatCost.ForeColor = System.Drawing.Color.Black;
            this.lblrepeatCost.Location = new System.Drawing.Point(457, 9);
            this.lblrepeatCost.Name = "lblrepeatCost";
            this.lblrepeatCost.Size = new System.Drawing.Size(19, 23);
            this.lblrepeatCost.TabIndex = 115;
            this.lblrepeatCost.Text = "*";
            // 
            // lblRepeatitemcode
            // 
            this.lblRepeatitemcode.AutoSize = true;
            this.lblRepeatitemcode.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRepeatitemcode.ForeColor = System.Drawing.Color.Black;
            this.lblRepeatitemcode.Location = new System.Drawing.Point(161, 9);
            this.lblRepeatitemcode.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lblRepeatitemcode.Name = "lblRepeatitemcode";
            this.lblRepeatitemcode.Size = new System.Drawing.Size(19, 23);
            this.lblRepeatitemcode.TabIndex = 114;
            this.lblRepeatitemcode.Text = "*";
            // 
            // lblUnitCost
            // 
            this.lblUnitCost.AutoSize = true;
            this.lblUnitCost.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUnitCost.ForeColor = System.Drawing.Color.Black;
            this.lblUnitCost.Location = new System.Drawing.Point(370, 9);
            this.lblUnitCost.Name = "lblUnitCost";
            this.lblUnitCost.Size = new System.Drawing.Size(88, 23);
            this.lblUnitCost.TabIndex = 113;
            this.lblUnitCost.Text = "UnitCost :";
            // 
            // lblItemcode
            // 
            this.lblItemcode.AutoSize = true;
            this.lblItemcode.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemcode.ForeColor = System.Drawing.Color.Black;
            this.lblItemcode.Location = new System.Drawing.Point(61, 9);
            this.lblItemcode.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lblItemcode.Name = "lblItemcode";
            this.lblItemcode.Size = new System.Drawing.Size(100, 23);
            this.lblItemcode.TabIndex = 112;
            this.lblItemcode.Text = "Item Code :";
            // 
            // dgvmaterialLedger
            // 
            this.dgvmaterialLedger.AllowUserToAddRows = false;
            this.dgvmaterialLedger.AllowUserToDeleteRows = false;
            this.dgvmaterialLedger.AllowUserToOrderColumns = true;
            this.dgvmaterialLedger.AllowUserToResizeColumns = false;
            this.dgvmaterialLedger.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvmaterialLedger.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvmaterialLedger.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvmaterialLedger.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvmaterialLedger.ColumnHeadersHeight = 40;
            this.dgvmaterialLedger.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvmaterialLedger.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Date1,
            this.Recieved,
            this.Issued,
            this.Return,
            this.StockAdjsued,
            this.unitcost,
            this.amount,
            this.refnumber,
            this.projectcode,
            this.ProjectDesc,
            this.Customer,
            this.User});
            this.dgvmaterialLedger.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvmaterialLedger.DefaultCellStyle = dataGridViewCellStyle11;
            this.dgvmaterialLedger.EnableHeadersVisualStyles = false;
            this.dgvmaterialLedger.Location = new System.Drawing.Point(203, 17);
            this.dgvmaterialLedger.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.dgvmaterialLedger.MultiSelect = false;
            this.dgvmaterialLedger.Name = "dgvmaterialLedger";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvmaterialLedger.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dgvmaterialLedger.RowHeadersVisible = false;
            this.dgvmaterialLedger.RowHeadersWidth = 62;
            this.dgvmaterialLedger.Size = new System.Drawing.Size(1297, 412);
            this.dgvmaterialLedger.TabIndex = 118;
            this.dgvmaterialLedger.Visible = false;
            this.dgvmaterialLedger.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvmaterialLedger_CellContentClick);
            this.dgvmaterialLedger.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvmaterialLedger_CellFormatting);
            this.dgvmaterialLedger.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.dgvmaterialLedger_RowsAdded);
            // 
            // Date1
            // 
            this.Date1.DataPropertyName = "Date";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Date1.DefaultCellStyle = dataGridViewCellStyle2;
            this.Date1.HeaderText = "Date";
            this.Date1.MinimumWidth = 8;
            this.Date1.Name = "Date1";
            this.Date1.ReadOnly = true;
            this.Date1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Date1.Width = 48;
            // 
            // Recieved
            // 
            this.Recieved.DataPropertyName = "RecievedQty";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Recieved.DefaultCellStyle = dataGridViewCellStyle3;
            this.Recieved.HeaderText = "RecievedQty";
            this.Recieved.MinimumWidth = 8;
            this.Recieved.Name = "Recieved";
            this.Recieved.ReadOnly = true;
            this.Recieved.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Recieved.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Recieved.Width = 102;
            // 
            // Issued
            // 
            this.Issued.DataPropertyName = "IssuedQty";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Issued.DefaultCellStyle = dataGridViewCellStyle4;
            this.Issued.HeaderText = "Issued Qty";
            this.Issued.MinimumWidth = 8;
            this.Issued.Name = "Issued";
            this.Issued.ReadOnly = true;
            this.Issued.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Issued.Width = 89;
            // 
            // Return
            // 
            this.Return.DataPropertyName = "ReturnQty";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Return.DefaultCellStyle = dataGridViewCellStyle5;
            this.Return.HeaderText = "Return Qty";
            this.Return.MinimumWidth = 8;
            this.Return.Name = "Return";
            this.Return.ReadOnly = true;
            this.Return.Width = 111;
            // 
            // StockAdjsued
            // 
            this.StockAdjsued.DataPropertyName = "StockAdjsued";
            this.StockAdjsued.HeaderText = "Stock Adjsued";
            this.StockAdjsued.MinimumWidth = 8;
            this.StockAdjsued.Name = "StockAdjsued";
            this.StockAdjsued.ReadOnly = true;
            this.StockAdjsued.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.StockAdjsued.Width = 114;
            // 
            // unitcost
            // 
            this.unitcost.DataPropertyName = "UnitCost";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.unitcost.DefaultCellStyle = dataGridViewCellStyle6;
            this.unitcost.HeaderText = "Unit Cost";
            this.unitcost.MinimumWidth = 8;
            this.unitcost.Name = "unitcost";
            this.unitcost.ReadOnly = true;
            this.unitcost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.unitcost.Width = 81;
            // 
            // amount
            // 
            this.amount.DataPropertyName = "Amount";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.amount.DefaultCellStyle = dataGridViewCellStyle7;
            this.amount.HeaderText = "Amount";
            this.amount.MinimumWidth = 8;
            this.amount.Name = "amount";
            this.amount.ReadOnly = true;
            this.amount.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.amount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.amount.Width = 73;
            // 
            // refnumber
            // 
            this.refnumber.DataPropertyName = "RefNumber";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.refnumber.DefaultCellStyle = dataGridViewCellStyle8;
            this.refnumber.HeaderText = "Ref Number";
            this.refnumber.MinimumWidth = 8;
            this.refnumber.Name = "refnumber";
            this.refnumber.ReadOnly = true;
            this.refnumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.refnumber.Width = 99;
            // 
            // projectcode
            // 
            this.projectcode.DataPropertyName = "ProjectCode";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.projectcode.DefaultCellStyle = dataGridViewCellStyle9;
            this.projectcode.HeaderText = "Project Code";
            this.projectcode.MinimumWidth = 8;
            this.projectcode.Name = "projectcode";
            this.projectcode.ReadOnly = true;
            this.projectcode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.projectcode.Width = 104;
            // 
            // ProjectDesc
            // 
            this.ProjectDesc.DataPropertyName = "ProjectName";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ProjectDesc.DefaultCellStyle = dataGridViewCellStyle10;
            this.ProjectDesc.HeaderText = "Project Name";
            this.ProjectDesc.MinimumWidth = 8;
            this.ProjectDesc.Name = "ProjectDesc";
            this.ProjectDesc.ReadOnly = true;
            this.ProjectDesc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectDesc.Width = 110;
            // 
            // Customer
            // 
            this.Customer.DataPropertyName = "Customer";
            this.Customer.HeaderText = "Customer";
            this.Customer.MinimumWidth = 8;
            this.Customer.Name = "Customer";
            this.Customer.ReadOnly = true;
            this.Customer.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Customer.Width = 84;
            // 
            // User
            // 
            this.User.DataPropertyName = "User";
            this.User.HeaderText = "User";
            this.User.MinimumWidth = 8;
            this.User.Name = "User";
            this.User.ReadOnly = true;
            this.User.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.User.Width = 48;
            // 
            // lblNoitems
            // 
            this.lblNoitems.AutoSize = true;
            this.lblNoitems.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoitems.ForeColor = System.Drawing.Color.Red;
            this.lblNoitems.Location = new System.Drawing.Point(484, 71);
            this.lblNoitems.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lblNoitems.Name = "lblNoitems";
            this.lblNoitems.Size = new System.Drawing.Size(438, 33);
            this.lblNoitems.TabIndex = 119;
            this.lblNoitems.Text = "No Transactions For Selected Item !!!!\r\n";
            this.lblNoitems.Visible = false;
            // 
            // dtpfromdate
            // 
            this.dtpfromdate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpfromdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpfromdate.Location = new System.Drawing.Point(81, 157);
            this.dtpfromdate.Name = "dtpfromdate";
            this.dtpfromdate.Size = new System.Drawing.Size(98, 27);
            this.dtpfromdate.TabIndex = 120;
            // 
            // dtptodate
            // 
            this.dtptodate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtptodate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtptodate.Location = new System.Drawing.Point(249, 157);
            this.dtptodate.Name = "dtptodate";
            this.dtptodate.Size = new System.Drawing.Size(96, 27);
            this.dtptodate.TabIndex = 121;
            this.dtptodate.Visible = false;
            // 
            // lblfromdate
            // 
            this.lblfromdate.AutoSize = true;
            this.lblfromdate.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfromdate.ForeColor = System.Drawing.Color.Black;
            this.lblfromdate.Location = new System.Drawing.Point(18, 158);
            this.lblfromdate.Name = "lblfromdate";
            this.lblfromdate.Size = new System.Drawing.Size(60, 23);
            this.lblfromdate.TabIndex = 122;
            this.lblfromdate.Text = "From :";
            this.lblfromdate.Visible = false;
            // 
            // lbltodate
            // 
            this.lbltodate.AutoSize = true;
            this.lbltodate.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltodate.ForeColor = System.Drawing.Color.Black;
            this.lbltodate.Location = new System.Drawing.Point(207, 158);
            this.lbltodate.Name = "lbltodate";
            this.lbltodate.Size = new System.Drawing.Size(36, 23);
            this.lbltodate.TabIndex = 123;
            this.lbltodate.Text = "To :";
            this.lbltodate.Visible = false;
            // 
            // btnmaterialledger
            // 
            this.btnmaterialledger.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmaterialledger.Location = new System.Drawing.Point(359, 157);
            this.btnmaterialledger.Name = "btnmaterialledger";
            this.btnmaterialledger.Size = new System.Drawing.Size(73, 32);
            this.btnmaterialledger.TabIndex = 124;
            this.btnmaterialledger.Text = "Ledger";
            this.btnmaterialledger.UseVisualStyleBackColor = true;
            this.btnmaterialledger.Visible = false;
            this.btnmaterialledger.Click += new System.EventHandler(this.btnmaterialledger_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.inventoryReceivedQty);
            this.panel1.Controls.Add(this.Receivedlb);
            this.panel1.Controls.Add(this.inventoryQuarantineQty);
            this.panel1.Controls.Add(this.Quarantinelb);
            this.panel1.Controls.Add(this.inventoryReturnQty);
            this.panel1.Controls.Add(this.Returnlb);
            this.panel1.Controls.Add(this.inventoryIssueQty);
            this.panel1.Controls.Add(this.Issuelb);
            this.panel1.Controls.Add(this.inventoryIndentQty);
            this.panel1.Controls.Add(this.Indentlb);
            this.panel1.Controls.Add(this.inventoryAvailableQty);
            this.panel1.Controls.Add(this.AvailableQtylb);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lblitemname);
            this.panel1.Controls.Add(this.lblRepeatitemcode);
            this.panel1.Controls.Add(this.lblitemdescrption);
            this.panel1.Controls.Add(this.lblItemcode);
            this.panel1.Location = new System.Drawing.Point(506, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(792, 191);
            this.panel1.TabIndex = 125;
            // 
            // inventoryReceivedQty
            // 
            this.inventoryReceivedQty.AutoSize = true;
            this.inventoryReceivedQty.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inventoryReceivedQty.Location = new System.Drawing.Point(642, 157);
            this.inventoryReceivedQty.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.inventoryReceivedQty.Name = "inventoryReceivedQty";
            this.inventoryReceivedQty.Size = new System.Drawing.Size(17, 19);
            this.inventoryReceivedQty.TabIndex = 126;
            this.inventoryReceivedQty.Text = "0";
            // 
            // Receivedlb
            // 
            this.Receivedlb.AutoSize = true;
            this.Receivedlb.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Receivedlb.Location = new System.Drawing.Point(541, 157);
            this.Receivedlb.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.Receivedlb.Name = "Receivedlb";
            this.Receivedlb.Size = new System.Drawing.Size(95, 19);
            this.Receivedlb.TabIndex = 125;
            this.Receivedlb.Text = "ReceivedQty";
            // 
            // inventoryQuarantineQty
            // 
            this.inventoryQuarantineQty.AutoSize = true;
            this.inventoryQuarantineQty.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inventoryQuarantineQty.Location = new System.Drawing.Point(642, 135);
            this.inventoryQuarantineQty.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.inventoryQuarantineQty.Name = "inventoryQuarantineQty";
            this.inventoryQuarantineQty.Size = new System.Drawing.Size(17, 19);
            this.inventoryQuarantineQty.TabIndex = 124;
            this.inventoryQuarantineQty.Text = "0";
            // 
            // Quarantinelb
            // 
            this.Quarantinelb.AutoSize = true;
            this.Quarantinelb.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Quarantinelb.Location = new System.Drawing.Point(525, 135);
            this.Quarantinelb.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.Quarantinelb.Name = "Quarantinelb";
            this.Quarantinelb.Size = new System.Drawing.Size(111, 19);
            this.Quarantinelb.TabIndex = 123;
            this.Quarantinelb.Text = "QuarantineQty";
            // 
            // inventoryReturnQty
            // 
            this.inventoryReturnQty.AutoSize = true;
            this.inventoryReturnQty.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inventoryReturnQty.Location = new System.Drawing.Point(642, 102);
            this.inventoryReturnQty.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.inventoryReturnQty.Name = "inventoryReturnQty";
            this.inventoryReturnQty.Size = new System.Drawing.Size(17, 19);
            this.inventoryReturnQty.TabIndex = 122;
            this.inventoryReturnQty.Text = "0";
            // 
            // Returnlb
            // 
            this.Returnlb.AutoSize = true;
            this.Returnlb.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Returnlb.Location = new System.Drawing.Point(554, 102);
            this.Returnlb.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.Returnlb.Name = "Returnlb";
            this.Returnlb.Size = new System.Drawing.Size(81, 19);
            this.Returnlb.TabIndex = 121;
            this.Returnlb.Text = "ReturnQty";
            // 
            // inventoryIssueQty
            // 
            this.inventoryIssueQty.AutoSize = true;
            this.inventoryIssueQty.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inventoryIssueQty.Location = new System.Drawing.Point(642, 74);
            this.inventoryIssueQty.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.inventoryIssueQty.Name = "inventoryIssueQty";
            this.inventoryIssueQty.Size = new System.Drawing.Size(17, 19);
            this.inventoryIssueQty.TabIndex = 120;
            this.inventoryIssueQty.Text = "0";
            // 
            // Issuelb
            // 
            this.Issuelb.AutoSize = true;
            this.Issuelb.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Issuelb.Location = new System.Drawing.Point(569, 74);
            this.Issuelb.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.Issuelb.Name = "Issuelb";
            this.Issuelb.Size = new System.Drawing.Size(67, 19);
            this.Issuelb.TabIndex = 119;
            this.Issuelb.Text = "IssueQty";
            // 
            // inventoryIndentQty
            // 
            this.inventoryIndentQty.AutoSize = true;
            this.inventoryIndentQty.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inventoryIndentQty.Location = new System.Drawing.Point(642, 44);
            this.inventoryIndentQty.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.inventoryIndentQty.Name = "inventoryIndentQty";
            this.inventoryIndentQty.Size = new System.Drawing.Size(17, 19);
            this.inventoryIndentQty.TabIndex = 118;
            this.inventoryIndentQty.Text = "0";
            // 
            // Indentlb
            // 
            this.Indentlb.AutoSize = true;
            this.Indentlb.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Indentlb.Location = new System.Drawing.Point(557, 44);
            this.Indentlb.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.Indentlb.Name = "Indentlb";
            this.Indentlb.Size = new System.Drawing.Size(79, 19);
            this.Indentlb.TabIndex = 117;
            this.Indentlb.Text = "IndentQty";
            // 
            // inventoryAvailableQty
            // 
            this.inventoryAvailableQty.AutoSize = true;
            this.inventoryAvailableQty.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inventoryAvailableQty.Location = new System.Drawing.Point(642, 18);
            this.inventoryAvailableQty.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.inventoryAvailableQty.Name = "inventoryAvailableQty";
            this.inventoryAvailableQty.Size = new System.Drawing.Size(17, 19);
            this.inventoryAvailableQty.TabIndex = 116;
            this.inventoryAvailableQty.Text = "0";
            // 
            // AvailableQtylb
            // 
            this.AvailableQtylb.AutoSize = true;
            this.AvailableQtylb.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AvailableQtylb.Location = new System.Drawing.Point(541, 18);
            this.AvailableQtylb.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.AvailableQtylb.Name = "AvailableQtylb";
            this.AvailableQtylb.Size = new System.Drawing.Size(97, 19);
            this.AvailableQtylb.TabIndex = 115;
            this.AvailableQtylb.Text = "AvailableQty";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label1.Location = new System.Drawing.Point(293, 5);
            this.label1.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(206, 33);
            this.label1.TabIndex = 125;
            this.label1.Text = "Inventory Ledger";
            // 
            // lblitemname
            // 
            this.lblitemname.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblitemname.ForeColor = System.Drawing.Color.Black;
            this.lblitemname.Location = new System.Drawing.Point(161, 44);
            this.lblitemname.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lblitemname.Name = "lblitemname";
            this.lblitemname.Size = new System.Drawing.Size(389, 42);
            this.lblitemname.TabIndex = 114;
            this.lblitemname.Text = "*";
            // 
            // Project
            // 
            this.Project.AutoSize = true;
            this.Project.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Project.Location = new System.Drawing.Point(423, 172);
            this.Project.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Project.Name = "Project";
            this.Project.Size = new System.Drawing.Size(166, 33);
            this.Project.TabIndex = 133;
            this.Project.Text = "Project Code";
            this.Project.UseVisualStyleBackColor = true;
            // 
            // inventoryVendorTextBox
            // 
            this.inventoryVendorTextBox.Location = new System.Drawing.Point(73, 115);
            this.inventoryVendorTextBox.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.inventoryVendorTextBox.Name = "inventoryVendorTextBox";
            this.inventoryVendorTextBox.Size = new System.Drawing.Size(198, 20);
            this.inventoryVendorTextBox.TabIndex = 132;
            // 
            // Vendorlb
            // 
            this.Vendorlb.AutoSize = true;
            this.Vendorlb.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Vendorlb.Location = new System.Drawing.Point(1, 115);
            this.Vendorlb.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.Vendorlb.Name = "Vendorlb";
            this.Vendorlb.Size = new System.Drawing.Size(58, 19);
            this.Vendorlb.TabIndex = 131;
            this.Vendorlb.Text = "Vendor";
            // 
            // Tolb
            // 
            this.Tolb.AutoSize = true;
            this.Tolb.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tolb.Location = new System.Drawing.Point(1, 37);
            this.Tolb.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.Tolb.Name = "Tolb";
            this.Tolb.Size = new System.Drawing.Size(25, 19);
            this.Tolb.TabIndex = 130;
            this.Tolb.Text = "To";
            // 
            // From
            // 
            this.From.AutoSize = true;
            this.From.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.From.Location = new System.Drawing.Point(1, 11);
            this.From.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.From.Name = "From";
            this.From.Size = new System.Drawing.Size(44, 19);
            this.From.TabIndex = 129;
            this.From.Text = "From";
            // 
            // inventoryToDateTimePicker
            // 
            this.inventoryToDateTimePicker.Location = new System.Drawing.Point(73, 37);
            this.inventoryToDateTimePicker.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.inventoryToDateTimePicker.Name = "inventoryToDateTimePicker";
            this.inventoryToDateTimePicker.Size = new System.Drawing.Size(198, 20);
            this.inventoryToDateTimePicker.TabIndex = 128;
            // 
            // inventoryFromIndateTimePicker
            // 
            this.inventoryFromIndateTimePicker.Location = new System.Drawing.Point(73, 11);
            this.inventoryFromIndateTimePicker.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.inventoryFromIndateTimePicker.Name = "inventoryFromIndateTimePicker";
            this.inventoryFromIndateTimePicker.Size = new System.Drawing.Size(198, 20);
            this.inventoryFromIndateTimePicker.TabIndex = 127;
            this.inventoryFromIndateTimePicker.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // btnAllledger
            // 
            this.btnAllledger.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAllledger.Location = new System.Drawing.Point(359, 116);
            this.btnAllledger.Name = "btnAllledger";
            this.btnAllledger.Size = new System.Drawing.Size(145, 32);
            this.btnAllledger.TabIndex = 138;
            this.btnAllledger.Text = "All items Ledger";
            this.btnAllledger.UseVisualStyleBackColor = true;
            this.btnAllledger.Visible = false;
            this.btnAllledger.Click += new System.EventHandler(this.btnAllledger_Click);
            // 
            // lblItemReturn
            // 
            this.lblItemReturn.AutoSize = true;
            this.lblItemReturn.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemReturn.ForeColor = System.Drawing.Color.Black;
            this.lblItemReturn.Location = new System.Drawing.Point(701, 65);
            this.lblItemReturn.Name = "lblItemReturn";
            this.lblItemReturn.Size = new System.Drawing.Size(20, 23);
            this.lblItemReturn.TabIndex = 137;
            this.lblItemReturn.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(592, 65);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(115, 23);
            this.label10.TabIndex = 136;
            this.label10.Text = "Item Return :";
            // 
            // lblStockAdjusted
            // 
            this.lblStockAdjusted.AutoSize = true;
            this.lblStockAdjusted.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStockAdjusted.ForeColor = System.Drawing.Color.Black;
            this.lblStockAdjusted.Location = new System.Drawing.Point(701, 122);
            this.lblStockAdjusted.Name = "lblStockAdjusted";
            this.lblStockAdjusted.Size = new System.Drawing.Size(20, 23);
            this.lblStockAdjusted.TabIndex = 135;
            this.lblStockAdjusted.Text = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(568, 122);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(138, 23);
            this.label9.TabIndex = 134;
            this.label9.Text = "Stock Adjusted :";
            // 
            // lblClosingStock
            // 
            this.lblClosingStock.AutoSize = true;
            this.lblClosingStock.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClosingStock.ForeColor = System.Drawing.Color.Black;
            this.lblClosingStock.Location = new System.Drawing.Point(701, 151);
            this.lblClosingStock.Name = "lblClosingStock";
            this.lblClosingStock.Size = new System.Drawing.Size(20, 23);
            this.lblClosingStock.TabIndex = 133;
            this.lblClosingStock.Text = "0";
            // 
            // lblIssue
            // 
            this.lblIssue.AutoSize = true;
            this.lblIssue.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIssue.ForeColor = System.Drawing.Color.Black;
            this.lblIssue.Location = new System.Drawing.Point(701, 93);
            this.lblIssue.Name = "lblIssue";
            this.lblIssue.Size = new System.Drawing.Size(20, 23);
            this.lblIssue.TabIndex = 132;
            this.lblIssue.Text = "0";
            // 
            // lblRecipt
            // 
            this.lblRecipt.AutoSize = true;
            this.lblRecipt.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecipt.ForeColor = System.Drawing.Color.Black;
            this.lblRecipt.Location = new System.Drawing.Point(701, 35);
            this.lblRecipt.Name = "lblRecipt";
            this.lblRecipt.Size = new System.Drawing.Size(20, 23);
            this.lblRecipt.TabIndex = 131;
            this.lblRecipt.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(582, 151);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(123, 23);
            this.label7.TabIndex = 130;
            this.label7.Text = "Closing Stock :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(645, 93);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 23);
            this.label5.TabIndex = 129;
            this.label5.Text = "Issue :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(619, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 23);
            this.label2.TabIndex = 128;
            this.label2.Text = "Reciepts :";
            // 
            // lblOpeningBalance
            // 
            this.lblOpeningBalance.AutoSize = true;
            this.lblOpeningBalance.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOpeningBalance.ForeColor = System.Drawing.Color.Black;
            this.lblOpeningBalance.Location = new System.Drawing.Point(701, 6);
            this.lblOpeningBalance.Name = "lblOpeningBalance";
            this.lblOpeningBalance.Size = new System.Drawing.Size(20, 23);
            this.lblOpeningBalance.TabIndex = 127;
            this.lblOpeningBalance.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(555, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(152, 23);
            this.label3.TabIndex = 126;
            this.label3.Text = "Opening Balance :";
            // 
            // btnExportExcel
            // 
            this.btnExportExcel.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExportExcel.Location = new System.Drawing.Point(438, 156);
            this.btnExportExcel.Name = "btnExportExcel";
            this.btnExportExcel.Size = new System.Drawing.Size(132, 34);
            this.btnExportExcel.TabIndex = 125;
            this.btnExportExcel.Text = "Export to Excel";
            this.btnExportExcel.UseVisualStyleBackColor = true;
            this.btnExportExcel.Click += new System.EventHandler(this.btnExportExcel_Click);
            // 
            // txtItemDescription
            // 
            this.txtItemDescription.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemDescription.Location = new System.Drawing.Point(21, 31);
            this.txtItemDescription.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.txtItemDescription.Name = "txtItemDescription";
            this.txtItemDescription.Size = new System.Drawing.Size(465, 26);
            this.txtItemDescription.TabIndex = 106;
            this.txtItemDescription.Enter += new System.EventHandler(this.txtItemDescription_Enter);
            this.txtItemDescription.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtItemDescription_KeyPress);
            this.txtItemDescription.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemDescription_KeyUp);
            // 
            // chklbItemList
            // 
            this.chklbItemList.CheckOnClick = true;
            this.chklbItemList.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chklbItemList.FormattingEnabled = true;
            this.chklbItemList.Location = new System.Drawing.Point(2, 57);
            this.chklbItemList.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.chklbItemList.Name = "chklbItemList";
            this.chklbItemList.Size = new System.Drawing.Size(482, 67);
            this.chklbItemList.TabIndex = 107;
            this.chklbItemList.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.chklbItemList_ItemCheck);
            // 
            // lblrecievqty
            // 
            this.lblrecievqty.AutoSize = true;
            this.lblrecievqty.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrecievqty.ForeColor = System.Drawing.Color.BlueViolet;
            this.lblrecievqty.Location = new System.Drawing.Point(130, 651);
            this.lblrecievqty.Name = "lblrecievqty";
            this.lblrecievqty.Size = new System.Drawing.Size(20, 23);
            this.lblrecievqty.TabIndex = 126;
            this.lblrecievqty.Text = "0";
            // 
            // lblissuedqty
            // 
            this.lblissuedqty.AutoSize = true;
            this.lblissuedqty.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblissuedqty.ForeColor = System.Drawing.Color.Black;
            this.lblissuedqty.Location = new System.Drawing.Point(221, 654);
            this.lblissuedqty.Name = "lblissuedqty";
            this.lblissuedqty.Size = new System.Drawing.Size(20, 23);
            this.lblissuedqty.TabIndex = 126;
            this.lblissuedqty.Text = "0";
            // 
            // lblreturnqty
            // 
            this.lblreturnqty.AutoSize = true;
            this.lblreturnqty.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblreturnqty.ForeColor = System.Drawing.Color.Black;
            this.lblreturnqty.Location = new System.Drawing.Point(336, 651);
            this.lblreturnqty.Name = "lblreturnqty";
            this.lblreturnqty.Size = new System.Drawing.Size(20, 23);
            this.lblreturnqty.TabIndex = 126;
            this.lblreturnqty.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(24, 654);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 23);
            this.label6.TabIndex = 126;
            this.label6.Text = "Total :";
            // 
            // chkItemDesc
            // 
            this.chkItemDesc.AutoSize = true;
            this.chkItemDesc.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemDesc.ForeColor = System.Drawing.Color.Black;
            this.chkItemDesc.Location = new System.Drawing.Point(129, 22);
            this.chkItemDesc.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.chkItemDesc.Name = "chkItemDesc";
            this.chkItemDesc.Size = new System.Drawing.Size(98, 23);
            this.chkItemDesc.TabIndex = 214;
            this.chkItemDesc.Text = "Item Desc.";
            this.chkItemDesc.UseVisualStyleBackColor = true;
            this.chkItemDesc.CheckedChanged += new System.EventHandler(this.chkItemDesc_CheckedChanged);
            // 
            // chkItemCode
            // 
            this.chkItemCode.AutoSize = true;
            this.chkItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemCode.ForeColor = System.Drawing.Color.Black;
            this.chkItemCode.Location = new System.Drawing.Point(9, 20);
            this.chkItemCode.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.chkItemCode.Name = "chkItemCode";
            this.chkItemCode.Size = new System.Drawing.Size(97, 23);
            this.chkItemCode.TabIndex = 213;
            this.chkItemCode.Text = "Item Code";
            this.chkItemCode.UseVisualStyleBackColor = true;
            this.chkItemCode.CheckedChanged += new System.EventHandler(this.chkItemCode_CheckedChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(70, 22);
            this.label4.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 19);
            this.label4.TabIndex = 212;
            this.label4.Text = "Search by";
            // 
            // lblStockAdjused
            // 
            this.lblStockAdjused.AutoSize = true;
            this.lblStockAdjused.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStockAdjused.ForeColor = System.Drawing.Color.Black;
            this.lblStockAdjused.Location = new System.Drawing.Point(457, 654);
            this.lblStockAdjused.Name = "lblStockAdjused";
            this.lblStockAdjused.Size = new System.Drawing.Size(20, 23);
            this.lblStockAdjused.TabIndex = 215;
            this.lblStockAdjused.Text = "0";
            // 
            // dgvALLLedgerReport
            // 
            this.dgvALLLedgerReport.AllowUserToAddRows = false;
            this.dgvALLLedgerReport.AllowUserToDeleteRows = false;
            this.dgvALLLedgerReport.AllowUserToOrderColumns = true;
            this.dgvALLLedgerReport.AllowUserToResizeRows = false;
            this.dgvALLLedgerReport.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvALLLedgerReport.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dgvALLLedgerReport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvALLLedgerReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvALLLedgerReport.Location = new System.Drawing.Point(0, 0);
            this.dgvALLLedgerReport.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.dgvALLLedgerReport.Name = "dgvALLLedgerReport";
            this.dgvALLLedgerReport.ReadOnly = true;
            this.dgvALLLedgerReport.RowHeadersVisible = false;
            this.dgvALLLedgerReport.RowHeadersWidth = 62;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvALLLedgerReport.RowsDefaultCellStyle = dataGridViewCellStyle14;
            this.dgvALLLedgerReport.Size = new System.Drawing.Size(1501, 461);
            this.dgvALLLedgerReport.TabIndex = 216;
            this.dgvALLLedgerReport.Visible = false;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(1173, 648);
            this.btnExit.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(81, 31);
            this.btnExit.TabIndex = 217;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.GINReverse);
            this.panel2.Controls.Add(this.currentStock);
            this.panel2.Controls.Add(this.IssueLog);
            this.panel2.Controls.Add(this.ScrapLog);
            this.panel2.Controls.Add(this.ReturnItem);
            this.panel2.Controls.Add(this.FIFOLog);
            this.panel2.Controls.Add(this.IndentLog);
            this.panel2.Controls.Add(this.GINLog);
            this.panel2.Location = new System.Drawing.Point(2, 193);
            this.panel2.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1165, 35);
            this.panel2.TabIndex = 218;
            // 
            // GINReverse
            // 
            this.GINReverse.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GINReverse.Location = new System.Drawing.Point(780, 3);
            this.GINReverse.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.GINReverse.Name = "GINReverse";
            this.GINReverse.Size = new System.Drawing.Size(129, 29);
            this.GINReverse.TabIndex = 7;
            this.GINReverse.Text = "GIN Reverse";
            this.GINReverse.UseVisualStyleBackColor = true;
            this.GINReverse.Visible = false;
            this.GINReverse.Click += new System.EventHandler(this.test_Click);
            // 
            // currentStock
            // 
            this.currentStock.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.currentStock.Location = new System.Drawing.Point(641, 2);
            this.currentStock.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.currentStock.Name = "currentStock";
            this.currentStock.Size = new System.Drawing.Size(137, 31);
            this.currentStock.TabIndex = 6;
            this.currentStock.Text = "Current Stock";
            this.currentStock.UseVisualStyleBackColor = true;
            this.currentStock.Visible = false;
            this.currentStock.Click += new System.EventHandler(this.test_Click);
            // 
            // IssueLog
            // 
            this.IssueLog.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IssueLog.Location = new System.Drawing.Point(279, 2);
            this.IssueLog.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.IssueLog.Name = "IssueLog";
            this.IssueLog.Size = new System.Drawing.Size(89, 31);
            this.IssueLog.TabIndex = 5;
            this.IssueLog.Text = "Issue Log";
            this.IssueLog.UseVisualStyleBackColor = true;
            this.IssueLog.Click += new System.EventHandler(this.test_Click);
            // 
            // ScrapLog
            // 
            this.ScrapLog.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ScrapLog.Location = new System.Drawing.Point(494, 2);
            this.ScrapLog.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.ScrapLog.Name = "ScrapLog";
            this.ScrapLog.Size = new System.Drawing.Size(145, 31);
            this.ScrapLog.TabIndex = 4;
            this.ScrapLog.Text = "Quarantine Log";
            this.ScrapLog.UseVisualStyleBackColor = true;
            this.ScrapLog.Click += new System.EventHandler(this.test_Click);
            // 
            // ReturnItem
            // 
            this.ReturnItem.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReturnItem.Location = new System.Drawing.Point(370, 2);
            this.ReturnItem.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.ReturnItem.Name = "ReturnItem";
            this.ReturnItem.Size = new System.Drawing.Size(122, 31);
            this.ReturnItem.TabIndex = 3;
            this.ReturnItem.Text = "Return Item";
            this.ReturnItem.UseVisualStyleBackColor = true;
            this.ReturnItem.Click += new System.EventHandler(this.test_Click);
            // 
            // FIFOLog
            // 
            this.FIFOLog.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FIFOLog.Location = new System.Drawing.Point(168, 2);
            this.FIFOLog.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.FIFOLog.Name = "FIFOLog";
            this.FIFOLog.Size = new System.Drawing.Size(109, 31);
            this.FIFOLog.TabIndex = 2;
            this.FIFOLog.Text = "FIFO Log";
            this.FIFOLog.UseVisualStyleBackColor = true;
            this.FIFOLog.Click += new System.EventHandler(this.test_Click);
            // 
            // IndentLog
            // 
            this.IndentLog.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IndentLog.Location = new System.Drawing.Point(85, 2);
            this.IndentLog.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.IndentLog.Name = "IndentLog";
            this.IndentLog.Size = new System.Drawing.Size(81, 31);
            this.IndentLog.TabIndex = 1;
            this.IndentLog.Text = "Indent Log";
            this.IndentLog.UseVisualStyleBackColor = true;
            this.IndentLog.Click += new System.EventHandler(this.test_Click);
            // 
            // GINLog
            // 
            this.GINLog.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GINLog.Location = new System.Drawing.Point(2, 2);
            this.GINLog.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.GINLog.Name = "GINLog";
            this.GINLog.Size = new System.Drawing.Size(81, 31);
            this.GINLog.TabIndex = 0;
            this.GINLog.Text = "GIN Log";
            this.GINLog.UseVisualStyleBackColor = true;
            this.GINLog.Click += new System.EventHandler(this.test_Click);
            // 
            // dataGridViewGIN
            // 
            this.dataGridViewGIN.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridViewGIN.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.dataGridViewGIN.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewGIN.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewGIN.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.GINNumber,
            this.ItemCodeGIN,
            this.CreateDateGIN,
            this.RefNumberGIN,
            this.ProjectCodeGIN,
            this.POQtYGIN,
            this.ReceivedQtYGIN,
            this.RemainingQtyGIN,
            this.unitCostGIN,
            this.SGSTGIN,
            this.CGSTGIN,
            this.IGSTGIN,
            this.POAmountGIN,
            this.BatchCodeGIN,
            this.LocationGIN,
            this.IndentQtyGIN,
            this.IssuedQtyGIN,
            this.QRPrintStatus});
            this.dataGridViewGIN.DefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridViewGIN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewGIN.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridViewGIN.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewGIN.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.dataGridViewGIN.Name = "dataGridViewGIN";
            this.dataGridViewGIN.RowHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridViewGIN.RowHeadersWidth = 62;
            this.dataGridViewGIN.RowsDefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridViewGIN.Size = new System.Drawing.Size(1501, 461);
            this.dataGridViewGIN.TabIndex = 219;
            this.dataGridViewGIN.Visible = false;
            this.dataGridViewGIN.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // GINNumber
            // 
            this.GINNumber.HeaderText = "GINNumber";
            this.GINNumber.MinimumWidth = 8;
            this.GINNumber.Name = "GINNumber";
            this.GINNumber.ReadOnly = true;
            this.GINNumber.Width = 118;
            // 
            // ItemCodeGIN
            // 
            this.ItemCodeGIN.HeaderText = "ItemCode";
            this.ItemCodeGIN.MinimumWidth = 8;
            this.ItemCodeGIN.Name = "ItemCodeGIN";
            this.ItemCodeGIN.ReadOnly = true;
            this.ItemCodeGIN.Width = 102;
            // 
            // CreateDateGIN
            // 
            this.CreateDateGIN.HeaderText = "CreatedDate";
            this.CreateDateGIN.MinimumWidth = 8;
            this.CreateDateGIN.Name = "CreateDateGIN";
            this.CreateDateGIN.ReadOnly = true;
            this.CreateDateGIN.Width = 121;
            // 
            // RefNumberGIN
            // 
            this.RefNumberGIN.HeaderText = "RefNumber";
            this.RefNumberGIN.MinimumWidth = 8;
            this.RefNumberGIN.Name = "RefNumberGIN";
            this.RefNumberGIN.ReadOnly = true;
            this.RefNumberGIN.Width = 114;
            // 
            // ProjectCodeGIN
            // 
            this.ProjectCodeGIN.HeaderText = "Project Code";
            this.ProjectCodeGIN.MinimumWidth = 8;
            this.ProjectCodeGIN.Name = "ProjectCodeGIN";
            this.ProjectCodeGIN.ReadOnly = true;
            this.ProjectCodeGIN.Width = 123;
            // 
            // POQtYGIN
            // 
            this.POQtYGIN.HeaderText = "PO QtY";
            this.POQtYGIN.MinimumWidth = 8;
            this.POQtYGIN.Name = "POQtYGIN";
            this.POQtYGIN.ReadOnly = true;
            this.POQtYGIN.Width = 84;
            // 
            // ReceivedQtYGIN
            // 
            this.ReceivedQtYGIN.HeaderText = "Received QtY";
            this.ReceivedQtYGIN.MinimumWidth = 8;
            this.ReceivedQtYGIN.Name = "ReceivedQtYGIN";
            this.ReceivedQtYGIN.ReadOnly = true;
            this.ReceivedQtYGIN.Width = 125;
            // 
            // RemainingQtyGIN
            // 
            this.RemainingQtyGIN.HeaderText = "Remaining Qty";
            this.RemainingQtyGIN.MinimumWidth = 8;
            this.RemainingQtyGIN.Name = "RemainingQtyGIN";
            this.RemainingQtyGIN.ReadOnly = true;
            this.RemainingQtyGIN.Visible = false;
            this.RemainingQtyGIN.Width = 200;
            // 
            // unitCostGIN
            // 
            this.unitCostGIN.HeaderText = "unit Cost";
            this.unitCostGIN.MinimumWidth = 8;
            this.unitCostGIN.Name = "unitCostGIN";
            this.unitCostGIN.ReadOnly = true;
            this.unitCostGIN.Width = 98;
            // 
            // SGSTGIN
            // 
            this.SGSTGIN.HeaderText = "SGST";
            this.SGSTGIN.MinimumWidth = 8;
            this.SGSTGIN.Name = "SGSTGIN";
            this.SGSTGIN.ReadOnly = true;
            this.SGSTGIN.Width = 70;
            // 
            // CGSTGIN
            // 
            this.CGSTGIN.HeaderText = "CGST";
            this.CGSTGIN.MinimumWidth = 8;
            this.CGSTGIN.Name = "CGSTGIN";
            this.CGSTGIN.ReadOnly = true;
            this.CGSTGIN.Width = 71;
            // 
            // IGSTGIN
            // 
            this.IGSTGIN.HeaderText = "IGST";
            this.IGSTGIN.MinimumWidth = 8;
            this.IGSTGIN.Name = "IGSTGIN";
            this.IGSTGIN.ReadOnly = true;
            this.IGSTGIN.Width = 66;
            // 
            // POAmountGIN
            // 
            this.POAmountGIN.HeaderText = "PO Amount";
            this.POAmountGIN.MinimumWidth = 8;
            this.POAmountGIN.Name = "POAmountGIN";
            this.POAmountGIN.ReadOnly = true;
            this.POAmountGIN.Width = 116;
            // 
            // BatchCodeGIN
            // 
            this.BatchCodeGIN.HeaderText = "BatchCode";
            this.BatchCodeGIN.MinimumWidth = 8;
            this.BatchCodeGIN.Name = "BatchCodeGIN";
            this.BatchCodeGIN.ReadOnly = true;
            this.BatchCodeGIN.Width = 109;
            // 
            // LocationGIN
            // 
            this.LocationGIN.HeaderText = "Location";
            this.LocationGIN.MinimumWidth = 8;
            this.LocationGIN.Name = "LocationGIN";
            this.LocationGIN.ReadOnly = true;
            this.LocationGIN.Width = 93;
            // 
            // IndentQtyGIN
            // 
            this.IndentQtyGIN.HeaderText = "Indent Qty";
            this.IndentQtyGIN.MinimumWidth = 8;
            this.IndentQtyGIN.Name = "IndentQtyGIN";
            this.IndentQtyGIN.ReadOnly = true;
            this.IndentQtyGIN.Visible = false;
            this.IndentQtyGIN.Width = 157;
            // 
            // IssuedQtyGIN
            // 
            this.IssuedQtyGIN.HeaderText = "Issued Qty";
            this.IssuedQtyGIN.MinimumWidth = 8;
            this.IssuedQtyGIN.Name = "IssuedQtyGIN";
            this.IssuedQtyGIN.ReadOnly = true;
            this.IssuedQtyGIN.Visible = false;
            this.IssuedQtyGIN.Width = 145;
            // 
            // QRPrintStatus
            // 
            this.QRPrintStatus.HeaderText = "QRPrint Status";
            this.QRPrintStatus.MinimumWidth = 8;
            this.QRPrintStatus.Name = "QRPrintStatus";
            this.QRPrintStatus.ReadOnly = true;
            this.QRPrintStatus.Width = 137;
            // 
            // BOMProjectCodeGIN
            // 
            this.BOMProjectCodeGIN.HeaderText = "BOM ProjectCode";
            this.BOMProjectCodeGIN.MinimumWidth = 8;
            this.BOMProjectCodeGIN.Name = "BOMProjectCodeGIN";
            this.BOMProjectCodeGIN.ReadOnly = true;
            this.BOMProjectCodeGIN.Width = 211;
            // 
            // IndentLogDataGrideViewold
            // 
            this.IndentLogDataGrideViewold.ColumnHeadersHeight = 34;
            this.IndentLogDataGrideViewold.Location = new System.Drawing.Point(0, 0);
            this.IndentLogDataGrideViewold.Name = "IndentLogDataGrideViewold";
            this.IndentLogDataGrideViewold.RowHeadersWidth = 62;
            this.IndentLogDataGrideViewold.Size = new System.Drawing.Size(240, 150);
            this.IndentLogDataGrideViewold.TabIndex = 0;
            // 
            // IndentNo
            // 
            this.IndentNo.HeaderText = "IndentNo";
            this.IndentNo.MinimumWidth = 8;
            this.IndentNo.Name = "IndentNo";
            this.IndentNo.ReadOnly = true;
            // 
            // IndentItemCode
            // 
            this.IndentItemCode.HeaderText = "Item Code";
            this.IndentItemCode.MinimumWidth = 8;
            this.IndentItemCode.Name = "IndentItemCode";
            this.IndentItemCode.ReadOnly = true;
            this.IndentItemCode.Width = 97;
            // 
            // IndentProjectCode
            // 
            this.IndentProjectCode.HeaderText = "Project Code";
            this.IndentProjectCode.MinimumWidth = 8;
            this.IndentProjectCode.Name = "IndentProjectCode";
            this.IndentProjectCode.ReadOnly = true;
            this.IndentProjectCode.Width = 113;
            // 
            // IndentBy
            // 
            this.IndentBy.HeaderText = "IndentBy";
            this.IndentBy.MinimumWidth = 8;
            this.IndentBy.Name = "IndentBy";
            this.IndentBy.ReadOnly = true;
            this.IndentBy.Width = 97;
            // 
            // IndentDate
            // 
            this.IndentDate.HeaderText = "Indent Date";
            this.IndentDate.MinimumWidth = 8;
            this.IndentDate.Name = "IndentDate";
            this.IndentDate.ReadOnly = true;
            this.IndentDate.Width = 106;
            // 
            // IndentQty
            // 
            this.IndentQty.HeaderText = "Indent Qty";
            this.IndentQty.MinimumWidth = 8;
            this.IndentQty.Name = "IndentQty";
            this.IndentQty.ReadOnly = true;
            // 
            // IndentStatus
            // 
            this.IndentStatus.HeaderText = "Indent Status";
            this.IndentStatus.MinimumWidth = 8;
            this.IndentStatus.Name = "IndentStatus";
            this.IndentStatus.ReadOnly = true;
            this.IndentStatus.Width = 117;
            // 
            // GINNumberIndent
            // 
            this.GINNumberIndent.HeaderText = "GIN Number";
            this.GINNumberIndent.MinimumWidth = 8;
            this.GINNumberIndent.Name = "GINNumberIndent";
            this.GINNumberIndent.ReadOnly = true;
            this.GINNumberIndent.Width = 112;
            // 
            // BatchCodeIndent
            // 
            this.BatchCodeIndent.HeaderText = "BatchCode";
            this.BatchCodeIndent.MinimumWidth = 8;
            this.BatchCodeIndent.Name = "BatchCodeIndent";
            this.BatchCodeIndent.ReadOnly = true;
            this.BatchCodeIndent.Width = 109;
            // 
            // LocationIndent
            // 
            this.LocationIndent.HeaderText = "Location";
            this.LocationIndent.MinimumWidth = 8;
            this.LocationIndent.Name = "LocationIndent";
            this.LocationIndent.ReadOnly = true;
            this.LocationIndent.Width = 93;
            // 
            // PickedLocationIndent
            // 
            this.PickedLocationIndent.HeaderText = "Picked Location";
            this.PickedLocationIndent.MinimumWidth = 8;
            this.PickedLocationIndent.Name = "PickedLocationIndent";
            this.PickedLocationIndent.ReadOnly = true;
            this.PickedLocationIndent.Width = 129;
            // 
            // PickedBatchCodeIndent
            // 
            this.PickedBatchCodeIndent.HeaderText = "Picked BatchCode";
            this.PickedBatchCodeIndent.MinimumWidth = 8;
            this.PickedBatchCodeIndent.Name = "PickedBatchCodeIndent";
            this.PickedBatchCodeIndent.ReadOnly = true;
            this.PickedBatchCodeIndent.Width = 143;
            // 
            // IndentFIFO
            // 
            this.IndentFIFO.HeaderText = "IndentFIFO";
            this.IndentFIFO.MinimumWidth = 8;
            this.IndentFIFO.Name = "IndentFIFO";
            this.IndentFIFO.ReadOnly = true;
            this.IndentFIFO.Visible = false;
            this.IndentFIFO.Width = 123;
            // 
            // IndentLogDataGrideView
            // 
            this.IndentLogDataGrideView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.IndentLogDataGrideView.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.IndentLogDataGrideView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.IndentLogDataGrideView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.IndentLogDataGrideView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IndentNo,
            this.IndentItemCode,
            this.IndentProjectCode,
            this.IndentBy,
            this.IndentDate,
            this.IndentQty,
            this.IndentStatus,
            this.GINNumberIndent,
            this.BatchCodeIndent,
            this.LocationIndent,
            this.PickedLocationIndent,
            this.PickedBatchCodeIndent,
            this.IndentFIFO});
            this.IndentLogDataGrideView.DefaultCellStyle = dataGridViewCellStyle11;
            this.IndentLogDataGrideView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.IndentLogDataGrideView.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.IndentLogDataGrideView.Location = new System.Drawing.Point(0, 0);
            this.IndentLogDataGrideView.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.IndentLogDataGrideView.Name = "IndentLogDataGrideView";
            this.IndentLogDataGrideView.RowHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.IndentLogDataGrideView.RowHeadersWidth = 62;
            this.IndentLogDataGrideView.RowsDefaultCellStyle = dataGridViewCellStyle14;
            this.IndentLogDataGrideView.Size = new System.Drawing.Size(1501, 461);
            this.IndentLogDataGrideView.TabIndex = 220;
            this.IndentLogDataGrideView.Visible = false;
            // 
            // ItemCodeFIFO
            // 
            this.ItemCodeFIFO.HeaderText = "Item Code";
            this.ItemCodeFIFO.MinimumWidth = 8;
            this.ItemCodeFIFO.Name = "ItemCodeFIFO";
            this.ItemCodeFIFO.ReadOnly = true;
            this.ItemCodeFIFO.Width = 97;
            // 
            // IndentNoFIFO
            // 
            this.IndentNoFIFO.HeaderText = "Indent No";
            this.IndentNoFIFO.MinimumWidth = 8;
            this.IndentNoFIFO.Name = "IndentNoFIFO";
            this.IndentNoFIFO.ReadOnly = true;
            this.IndentNoFIFO.Width = 96;
            // 
            // IndentQtyFIFO
            // 
            this.IndentQtyFIFO.HeaderText = "Indent Qty";
            this.IndentQtyFIFO.MinimumWidth = 8;
            this.IndentQtyFIFO.Name = "IndentQtyFIFO";
            this.IndentQtyFIFO.ReadOnly = true;
            // 
            // ProjectCodeFIFO
            // 
            this.ProjectCodeFIFO.HeaderText = "Project Code";
            this.ProjectCodeFIFO.MinimumWidth = 8;
            this.ProjectCodeFIFO.Name = "ProjectCodeFIFO";
            this.ProjectCodeFIFO.ReadOnly = true;
            this.ProjectCodeFIFO.Width = 113;
            // 
            // RemarksFIFO
            // 
            this.RemarksFIFO.HeaderText = "Remarks";
            this.RemarksFIFO.MinimumWidth = 8;
            this.RemarksFIFO.Name = "RemarksFIFO";
            this.RemarksFIFO.ReadOnly = true;
            this.RemarksFIFO.Width = 95;
            // 
            // GINNumberFIFO
            // 
            this.GINNumberFIFO.HeaderText = "GIN Number";
            this.GINNumberFIFO.MinimumWidth = 8;
            this.GINNumberFIFO.Name = "GINNumberFIFO";
            this.GINNumberFIFO.ReadOnly = true;
            this.GINNumberFIFO.Width = 112;
            // 
            // BatchCodeFIFO
            // 
            this.BatchCodeFIFO.HeaderText = "Batch Code";
            this.BatchCodeFIFO.MinimumWidth = 8;
            this.BatchCodeFIFO.Name = "BatchCodeFIFO";
            this.BatchCodeFIFO.ReadOnly = true;
            this.BatchCodeFIFO.Width = 104;
            // 
            // LocationFIFO
            // 
            this.LocationFIFO.HeaderText = "Location";
            this.LocationFIFO.MinimumWidth = 8;
            this.LocationFIFO.Name = "LocationFIFO";
            this.LocationFIFO.ReadOnly = true;
            this.LocationFIFO.Width = 93;
            // 
            // PickedBatchCodeFIFO
            // 
            this.PickedBatchCodeFIFO.HeaderText = "Picked BatchCode";
            this.PickedBatchCodeFIFO.MinimumWidth = 8;
            this.PickedBatchCodeFIFO.Name = "PickedBatchCodeFIFO";
            this.PickedBatchCodeFIFO.ReadOnly = true;
            this.PickedBatchCodeFIFO.Width = 143;
            // 
            // PickedLocationFIFO
            // 
            this.PickedLocationFIFO.HeaderText = "Picked Location";
            this.PickedLocationFIFO.MinimumWidth = 8;
            this.PickedLocationFIFO.Name = "PickedLocationFIFO";
            this.PickedLocationFIFO.ReadOnly = true;
            this.PickedLocationFIFO.Width = 129;
            // 
            // IndentPickedByFIFO
            // 
            this.IndentPickedByFIFO.HeaderText = "Indent PickedBy";
            this.IndentPickedByFIFO.MinimumWidth = 8;
            this.IndentPickedByFIFO.Name = "IndentPickedByFIFO";
            this.IndentPickedByFIFO.ReadOnly = true;
            this.IndentPickedByFIFO.Width = 132;
            // 
            // IssuedByFIFO
            // 
            this.IssuedByFIFO.HeaderText = "IssuedBy";
            this.IssuedByFIFO.MinimumWidth = 8;
            this.IssuedByFIFO.Name = "IssuedByFIFO";
            this.IssuedByFIFO.ReadOnly = true;
            this.IssuedByFIFO.Width = 96;
            // 
            // CreateDateFIFO
            // 
            this.CreateDateFIFO.HeaderText = "Create Date";
            this.CreateDateFIFO.MinimumWidth = 8;
            this.CreateDateFIFO.Name = "CreateDateFIFO";
            this.CreateDateFIFO.ReadOnly = true;
            this.CreateDateFIFO.Width = 106;
            // 
            // FIFOFollowed
            // 
            this.FIFOFollowed.HeaderText = "FIFOFollowed";
            this.FIFOFollowed.MinimumWidth = 8;
            this.FIFOFollowed.Name = "FIFOFollowed";
            this.FIFOFollowed.ReadOnly = true;
            this.FIFOFollowed.Width = 129;
            // 
            // ReturnItemCode
            // 
            this.ReturnItemCode.HeaderText = "ItemCode";
            this.ReturnItemCode.MinimumWidth = 8;
            this.ReturnItemCode.Name = "ReturnItemCode";
            this.ReturnItemCode.ReadOnly = true;
            this.ReturnItemCode.Width = 102;
            // 
            // ReturnIndentNo
            // 
            this.ReturnIndentNo.HeaderText = "IndentNo";
            this.ReturnIndentNo.MinimumWidth = 8;
            this.ReturnIndentNo.Name = "ReturnIndentNo";
            this.ReturnIndentNo.ReadOnly = true;
            // 
            // ReturnProjectCode
            // 
            this.ReturnProjectCode.HeaderText = "Project Code";
            this.ReturnProjectCode.MinimumWidth = 8;
            this.ReturnProjectCode.Name = "ReturnProjectCode";
            this.ReturnProjectCode.ReadOnly = true;
            this.ReturnProjectCode.Width = 123;
            // 
            // ReturnQuantity
            // 
            this.ReturnQuantity.HeaderText = "Return Quantity";
            this.ReturnQuantity.MinimumWidth = 8;
            this.ReturnQuantity.Name = "ReturnQuantity";
            this.ReturnQuantity.ReadOnly = true;
            this.ReturnQuantity.Width = 146;
            // 
            // ReturnCreateDate
            // 
            this.ReturnCreateDate.HeaderText = "Create Date";
            this.ReturnCreateDate.MinimumWidth = 8;
            this.ReturnCreateDate.Name = "ReturnCreateDate";
            this.ReturnCreateDate.ReadOnly = true;
            this.ReturnCreateDate.Width = 116;
            // 
            // ReturnedBy
            // 
            this.ReturnedBy.HeaderText = "ReturnedBy";
            this.ReturnedBy.MinimumWidth = 8;
            this.ReturnedBy.Name = "ReturnedBy";
            this.ReturnedBy.ReadOnly = true;
            this.ReturnedBy.Width = 116;
            // 
            // ReturnProjectStatus
            // 
            this.ReturnProjectStatus.HeaderText = "Project Status";
            this.ReturnProjectStatus.MinimumWidth = 8;
            this.ReturnProjectStatus.Name = "ReturnProjectStatus";
            this.ReturnProjectStatus.ReadOnly = true;
            this.ReturnProjectStatus.Width = 132;
            // 
            // ReturnGINNumber
            // 
            this.ReturnGINNumber.HeaderText = "GIN Number";
            this.ReturnGINNumber.MinimumWidth = 8;
            this.ReturnGINNumber.Name = "ReturnGINNumber";
            this.ReturnGINNumber.ReadOnly = true;
            this.ReturnGINNumber.Width = 122;
            // 
            // ReturnBatchCode
            // 
            this.ReturnBatchCode.HeaderText = "Batch Code";
            this.ReturnBatchCode.MinimumWidth = 8;
            this.ReturnBatchCode.Name = "ReturnBatchCode";
            this.ReturnBatchCode.ReadOnly = true;
            this.ReturnBatchCode.Width = 113;
            // 
            // ReturnLocation
            // 
            this.ReturnLocation.HeaderText = "Location";
            this.ReturnLocation.MinimumWidth = 8;
            this.ReturnLocation.Name = "ReturnLocation";
            this.ReturnLocation.ReadOnly = true;
            this.ReturnLocation.Width = 93;
            // 
            // ReturnVendorCode
            // 
            this.ReturnVendorCode.HeaderText = "Vendor Code";
            this.ReturnVendorCode.MinimumWidth = 8;
            this.ReturnVendorCode.Name = "ReturnVendorCode";
            this.ReturnVendorCode.ReadOnly = true;
            this.ReturnVendorCode.Width = 124;
            // 
            // ReturnType
            // 
            this.ReturnType.HeaderText = "Return Type";
            this.ReturnType.MinimumWidth = 8;
            this.ReturnType.Name = "ReturnType";
            this.ReturnType.ReadOnly = true;
            this.ReturnType.Width = 118;
            // 
            // ScrapItemCode
            // 
            this.ScrapItemCode.HeaderText = "Item Code";
            this.ScrapItemCode.MinimumWidth = 8;
            this.ScrapItemCode.Name = "ScrapItemCode";
            this.ScrapItemCode.ReadOnly = true;
            this.ScrapItemCode.Width = 106;
            // 
            // ScrapIndentNo
            // 
            this.ScrapIndentNo.HeaderText = "IndentNo";
            this.ScrapIndentNo.MinimumWidth = 8;
            this.ScrapIndentNo.Name = "ScrapIndentNo";
            this.ScrapIndentNo.ReadOnly = true;
            // 
            // ScrapProjectCode
            // 
            this.ScrapProjectCode.HeaderText = "ProjectCode";
            this.ScrapProjectCode.MinimumWidth = 8;
            this.ScrapProjectCode.Name = "ScrapProjectCode";
            this.ScrapProjectCode.ReadOnly = true;
            this.ScrapProjectCode.Width = 119;
            // 
            // ScrapQuantity
            // 
            this.ScrapQuantity.HeaderText = "Quantity";
            this.ScrapQuantity.MinimumWidth = 8;
            this.ScrapQuantity.Name = "ScrapQuantity";
            this.ScrapQuantity.ReadOnly = true;
            this.ScrapQuantity.Width = 95;
            // 
            // ScrapCreateDate
            // 
            this.ScrapCreateDate.HeaderText = "CreateDate";
            this.ScrapCreateDate.MinimumWidth = 8;
            this.ScrapCreateDate.Name = "ScrapCreateDate";
            this.ScrapCreateDate.ReadOnly = true;
            this.ScrapCreateDate.Width = 112;
            // 
            // ScrapReturnedBy
            // 
            this.ScrapReturnedBy.HeaderText = "ReturnedBy";
            this.ScrapReturnedBy.MinimumWidth = 8;
            this.ScrapReturnedBy.Name = "ScrapReturnedBy";
            this.ScrapReturnedBy.ReadOnly = true;
            this.ScrapReturnedBy.Width = 116;
            // 
            // ScrapProjectStatus
            // 
            this.ScrapProjectStatus.HeaderText = "ProjectStatus";
            this.ScrapProjectStatus.MinimumWidth = 8;
            this.ScrapProjectStatus.Name = "ScrapProjectStatus";
            this.ScrapProjectStatus.ReadOnly = true;
            this.ScrapProjectStatus.Width = 128;
            // 
            // ScrapGINNumber
            // 
            this.ScrapGINNumber.HeaderText = "GINNumber";
            this.ScrapGINNumber.MinimumWidth = 8;
            this.ScrapGINNumber.Name = "ScrapGINNumber";
            this.ScrapGINNumber.ReadOnly = true;
            this.ScrapGINNumber.Width = 118;
            // 
            // ScrapBatchCode
            // 
            this.ScrapBatchCode.HeaderText = "BatchCode";
            this.ScrapBatchCode.MinimumWidth = 8;
            this.ScrapBatchCode.Name = "ScrapBatchCode";
            this.ScrapBatchCode.ReadOnly = true;
            this.ScrapBatchCode.Width = 109;
            // 
            // ScrapLocation
            // 
            this.ScrapLocation.HeaderText = "Location";
            this.ScrapLocation.MinimumWidth = 8;
            this.ScrapLocation.Name = "ScrapLocation";
            this.ScrapLocation.ReadOnly = true;
            this.ScrapLocation.Width = 93;
            // 
            // ScrapReturnType
            // 
            this.ScrapReturnType.HeaderText = "Return Type";
            this.ScrapReturnType.MinimumWidth = 8;
            this.ScrapReturnType.Name = "ScrapReturnType";
            this.ScrapReturnType.ReadOnly = true;
            this.ScrapReturnType.Width = 118;
            // 
            // dataGridViewFIFOLog
            // 
            this.dataGridViewFIFOLog.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridViewFIFOLog.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.dataGridViewFIFOLog.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewFIFOLog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewFIFOLog.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.FIFOFollowed,
            this.ItemCodeFIFO,
            this.IndentNoFIFO,
            this.IndentQtyFIFO,
            this.ProjectCodeFIFO,
            this.RemarksFIFO,
            this.GINNumberFIFO,
            this.BatchCodeFIFO,
            this.LocationFIFO,
            this.PickedBatchCodeFIFO,
            this.PickedLocationFIFO,
            this.IndentPickedByFIFO,
            this.IssuedByFIFO,
            this.CreateDateFIFO});
            this.dataGridViewFIFOLog.DefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridViewFIFOLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewFIFOLog.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridViewFIFOLog.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewFIFOLog.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.dataGridViewFIFOLog.Name = "dataGridViewFIFOLog";
            this.dataGridViewFIFOLog.RowHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridViewFIFOLog.RowHeadersWidth = 62;
            this.dataGridViewFIFOLog.RowsDefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridViewFIFOLog.Size = new System.Drawing.Size(1501, 461);
            this.dataGridViewFIFOLog.TabIndex = 220;
            this.dataGridViewFIFOLog.Visible = false;
            // 
            // dataGridViewReturnLog
            // 
            this.dataGridViewReturnLog.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridViewReturnLog.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.dataGridViewReturnLog.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewReturnLog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewReturnLog.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ReturnItemCode,
            this.ReturnIndentNo,
            this.ReturnProjectCode,
            this.ReturnQuantity,
            this.ReturnCreateDate,
            this.ReturnedBy,
            this.ReturnProjectStatus,
            this.ReturnGINNumber,
            this.ReturnBatchCode,
            this.ReturnLocation,
            this.ReturnVendorCode,
            this.ReturnType});
            this.dataGridViewReturnLog.DefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridViewReturnLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewReturnLog.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridViewReturnLog.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewReturnLog.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.dataGridViewReturnLog.Name = "dataGridViewReturnLog";
            this.dataGridViewReturnLog.RowHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridViewReturnLog.RowHeadersWidth = 62;
            this.dataGridViewReturnLog.RowsDefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridViewReturnLog.Size = new System.Drawing.Size(1501, 461);
            this.dataGridViewReturnLog.TabIndex = 220;
            this.dataGridViewReturnLog.Visible = false;
            // 
            // dataGridViewScrapLog
            // 
            this.dataGridViewScrapLog.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridViewScrapLog.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.dataGridViewScrapLog.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewScrapLog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewScrapLog.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ScrapItemCode,
            this.ScrapIndentNo,
            this.ScrapProjectCode,
            this.ScrapQuantity,
            this.ScrapCreateDate,
            this.ScrapReturnedBy,
            this.ScrapProjectStatus,
            this.ScrapGINNumber,
            this.ScrapBatchCode,
            this.ScrapLocation,
            this.ScrapReturnType});
            this.dataGridViewScrapLog.DefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridViewScrapLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewScrapLog.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridViewScrapLog.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewScrapLog.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.dataGridViewScrapLog.Name = "dataGridViewScrapLog";
            this.dataGridViewScrapLog.RowHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridViewScrapLog.RowHeadersWidth = 62;
            this.dataGridViewScrapLog.RowsDefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridViewScrapLog.Size = new System.Drawing.Size(1501, 461);
            this.dataGridViewScrapLog.TabIndex = 220;
            this.dataGridViewScrapLog.Visible = false;
            // 
            // dataGridViewIssueLog
            // 
            this.dataGridViewIssueLog.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridViewIssueLog.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.dataGridViewIssueLog.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewIssueLog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewIssueLog.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IssueLog_ItemCode,
            this.IssueLog_IndentNo,
            this.IssueLog_ProjectCode,
            this.IssueLog_IndentBy,
            this.IssueLog_IndentQty,
            this.IssueLog_IssuedQuantity,
            this.IssueLog_IssueType,
            this.IssueLog_Remarks,
            this.IssueLog_Status,
            this.IssueLog_ProjectBOMCode,
            this.IssueLog_ProductNo,
            this.IssueLog_GINNumber,
            this.IssueLog_BatchCode,
            this.IssueLog_Location,
            this.IssueLog_IssuedBy,
            this.IssueLog_IssuedServerDate});
            this.dataGridViewIssueLog.DefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridViewIssueLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewIssueLog.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridViewIssueLog.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewIssueLog.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.dataGridViewIssueLog.Name = "dataGridViewIssueLog";
            this.dataGridViewIssueLog.RowHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridViewIssueLog.RowHeadersWidth = 62;
            this.dataGridViewIssueLog.RowsDefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridViewIssueLog.Size = new System.Drawing.Size(1501, 461);
            this.dataGridViewIssueLog.TabIndex = 221;
            this.dataGridViewIssueLog.Visible = false;
            // 
            // IssueLog_ItemCode
            // 
            this.IssueLog_ItemCode.HeaderText = "Item Code";
            this.IssueLog_ItemCode.MinimumWidth = 8;
            this.IssueLog_ItemCode.Name = "IssueLog_ItemCode";
            this.IssueLog_ItemCode.ReadOnly = true;
            this.IssueLog_ItemCode.Width = 97;
            // 
            // IssueLog_IndentNo
            // 
            this.IssueLog_IndentNo.HeaderText = "Indent No";
            this.IssueLog_IndentNo.MinimumWidth = 8;
            this.IssueLog_IndentNo.Name = "IssueLog_IndentNo";
            this.IssueLog_IndentNo.ReadOnly = true;
            this.IssueLog_IndentNo.Width = 96;
            // 
            // IssueLog_ProjectCode
            // 
            this.IssueLog_ProjectCode.HeaderText = "Project Code";
            this.IssueLog_ProjectCode.MinimumWidth = 8;
            this.IssueLog_ProjectCode.Name = "IssueLog_ProjectCode";
            this.IssueLog_ProjectCode.ReadOnly = true;
            this.IssueLog_ProjectCode.Width = 113;
            // 
            // IssueLog_IndentBy
            // 
            this.IssueLog_IndentBy.HeaderText = "Indent By";
            this.IssueLog_IndentBy.MinimumWidth = 8;
            this.IssueLog_IndentBy.Name = "IssueLog_IndentBy";
            this.IssueLog_IndentBy.ReadOnly = true;
            this.IssueLog_IndentBy.Width = 93;
            // 
            // IssueLog_IndentQty
            // 
            this.IssueLog_IndentQty.HeaderText = "Indent Qty";
            this.IssueLog_IndentQty.MinimumWidth = 8;
            this.IssueLog_IndentQty.Name = "IssueLog_IndentQty";
            this.IssueLog_IndentQty.ReadOnly = true;
            // 
            // IssueLog_IssuedQuantity
            // 
            this.IssueLog_IssuedQuantity.HeaderText = "Issued Quantity";
            this.IssueLog_IssuedQuantity.MinimumWidth = 8;
            this.IssueLog_IssuedQuantity.Name = "IssueLog_IssuedQuantity";
            this.IssueLog_IssuedQuantity.ReadOnly = true;
            this.IssueLog_IssuedQuantity.Width = 131;
            // 
            // IssueLog_IssueType
            // 
            this.IssueLog_IssueType.HeaderText = "Issue Type";
            this.IssueLog_IssueType.MinimumWidth = 8;
            this.IssueLog_IssueType.Name = "IssueLog_IssueType";
            this.IssueLog_IssueType.ReadOnly = true;
            this.IssueLog_IssueType.Width = 97;
            // 
            // IssueLog_Remarks
            // 
            this.IssueLog_Remarks.HeaderText = "Remarks";
            this.IssueLog_Remarks.MinimumWidth = 8;
            this.IssueLog_Remarks.Name = "IssueLog_Remarks";
            this.IssueLog_Remarks.ReadOnly = true;
            this.IssueLog_Remarks.Width = 95;
            // 
            // IssueLog_Status
            // 
            this.IssueLog_Status.HeaderText = "Status";
            this.IssueLog_Status.MinimumWidth = 8;
            this.IssueLog_Status.Name = "IssueLog_Status";
            this.IssueLog_Status.ReadOnly = true;
            this.IssueLog_Status.Width = 79;
            // 
            // IssueLog_ProjectBOMCode
            // 
            this.IssueLog_ProjectBOMCode.HeaderText = "Project BOM Code";
            this.IssueLog_ProjectBOMCode.MinimumWidth = 8;
            this.IssueLog_ProjectBOMCode.Name = "IssueLog_ProjectBOMCode";
            this.IssueLog_ProjectBOMCode.ReadOnly = true;
            this.IssueLog_ProjectBOMCode.Visible = false;
            this.IssueLog_ProjectBOMCode.Width = 170;
            // 
            // IssueLog_ProductNo
            // 
            this.IssueLog_ProductNo.HeaderText = "Product No";
            this.IssueLog_ProductNo.MinimumWidth = 8;
            this.IssueLog_ProductNo.Name = "IssueLog_ProductNo";
            this.IssueLog_ProductNo.ReadOnly = true;
            this.IssueLog_ProductNo.Visible = false;
            this.IssueLog_ProductNo.Width = 152;
            // 
            // IssueLog_GINNumber
            // 
            this.IssueLog_GINNumber.HeaderText = "GIN Number";
            this.IssueLog_GINNumber.MinimumWidth = 8;
            this.IssueLog_GINNumber.Name = "IssueLog_GINNumber";
            this.IssueLog_GINNumber.ReadOnly = true;
            this.IssueLog_GINNumber.Width = 112;
            // 
            // IssueLog_BatchCode
            // 
            this.IssueLog_BatchCode.HeaderText = "Batch Code";
            this.IssueLog_BatchCode.MinimumWidth = 8;
            this.IssueLog_BatchCode.Name = "IssueLog_BatchCode";
            this.IssueLog_BatchCode.ReadOnly = true;
            this.IssueLog_BatchCode.Width = 104;
            // 
            // IssueLog_Location
            // 
            this.IssueLog_Location.HeaderText = "Location";
            this.IssueLog_Location.MinimumWidth = 8;
            this.IssueLog_Location.Name = "IssueLog_Location";
            this.IssueLog_Location.ReadOnly = true;
            this.IssueLog_Location.Width = 93;
            // 
            // IssueLog_IssuedBy
            // 
            this.IssueLog_IssuedBy.HeaderText = "IssuedBy";
            this.IssueLog_IssuedBy.MinimumWidth = 8;
            this.IssueLog_IssuedBy.Name = "IssueLog_IssuedBy";
            this.IssueLog_IssuedBy.ReadOnly = true;
            this.IssueLog_IssuedBy.Width = 96;
            // 
            // IssueLog_IssuedServerDate
            // 
            this.IssueLog_IssuedServerDate.HeaderText = "Issued Server Date";
            this.IssueLog_IssuedServerDate.MinimumWidth = 8;
            this.IssueLog_IssuedServerDate.Name = "IssueLog_IssuedServerDate";
            this.IssueLog_IssuedServerDate.ReadOnly = true;
            this.IssueLog_IssuedServerDate.Width = 120;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel3.Controls.Add(this.indentNotextBox);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.comboBox1);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.inventoryLocationtextBox);
            this.panel3.Controls.Add(this.flLocation);
            this.panel3.Controls.Add(this.btnApplyFilter);
            this.panel3.Controls.Add(this.btnClearFilter);
            this.panel3.Controls.Add(this.flCategory);
            this.panel3.Controls.Add(this.inventoryCategoryTextBox);
            this.panel3.Controls.Add(this.flProjectCode);
            this.panel3.Controls.Add(this.inventoryProjectTextBox);
            this.panel3.Controls.Add(this.From);
            this.panel3.Controls.Add(this.inventoryFromIndateTimePicker);
            this.panel3.Controls.Add(this.inventoryVendorTextBox);
            this.panel3.Controls.Add(this.Tolb);
            this.panel3.Controls.Add(this.Vendorlb);
            this.panel3.Controls.Add(this.inventoryToDateTimePicker);
            this.panel3.Location = new System.Drawing.Point(2, 5);
            this.panel3.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(497, 180);
            this.panel3.TabIndex = 223;
            // 
            // indentNotextBox
            // 
            this.indentNotextBox.Location = new System.Drawing.Point(365, 38);
            this.indentNotextBox.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.indentNotextBox.Name = "indentNotextBox";
            this.indentNotextBox.Size = new System.Drawing.Size(118, 20);
            this.indentNotextBox.TabIndex = 147;
            this.indentNotextBox.Visible = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label11.Location = new System.Drawing.Point(277, 40);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(74, 19);
            this.label11.TabIndex = 146;
            this.label11.Text = "IndentNo";
            this.label11.Visible = false;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Open",
            "Close"});
            this.comboBox1.Location = new System.Drawing.Point(363, 9);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(118, 21);
            this.comboBox1.TabIndex = 145;
            this.comboBox1.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(277, 11);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 19);
            this.label8.TabIndex = 144;
            this.label8.Text = "Status";
            this.label8.Visible = false;
            // 
            // inventoryLocationtextBox
            // 
            this.inventoryLocationtextBox.Location = new System.Drawing.Point(74, 139);
            this.inventoryLocationtextBox.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.inventoryLocationtextBox.Name = "inventoryLocationtextBox";
            this.inventoryLocationtextBox.Size = new System.Drawing.Size(198, 20);
            this.inventoryLocationtextBox.TabIndex = 143;
            // 
            // flLocation
            // 
            this.flLocation.AutoSize = true;
            this.flLocation.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flLocation.Location = new System.Drawing.Point(1, 137);
            this.flLocation.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.flLocation.Name = "flLocation";
            this.flLocation.Size = new System.Drawing.Size(67, 19);
            this.flLocation.TabIndex = 142;
            this.flLocation.Text = "Location";
            // 
            // btnApplyFilter
            // 
            this.btnApplyFilter.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnApplyFilter.Font = new System.Drawing.Font("Calibri", 12.25F, System.Drawing.FontStyle.Bold);
            this.btnApplyFilter.Location = new System.Drawing.Point(389, 135);
            this.btnApplyFilter.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.btnApplyFilter.Name = "btnApplyFilter";
            this.btnApplyFilter.Size = new System.Drawing.Size(101, 24);
            this.btnApplyFilter.TabIndex = 141;
            this.btnApplyFilter.Text = "Apply Filter";
            this.btnApplyFilter.UseVisualStyleBackColor = true;
            this.btnApplyFilter.Click += new System.EventHandler(this.btnApplyFilter_Click);
            // 
            // btnClearFilter
            // 
            this.btnClearFilter.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnClearFilter.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClearFilter.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnClearFilter.Font = new System.Drawing.Font("Calibri", 12.25F, System.Drawing.FontStyle.Bold);
            this.btnClearFilter.Location = new System.Drawing.Point(281, 135);
            this.btnClearFilter.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.btnClearFilter.Name = "btnClearFilter";
            this.btnClearFilter.Size = new System.Drawing.Size(101, 24);
            this.btnClearFilter.TabIndex = 140;
            this.btnClearFilter.Text = "Clear Filter";
            this.btnClearFilter.UseVisualStyleBackColor = false;
            this.btnClearFilter.Click += new System.EventHandler(this.btnClearFilter_Click);
            // 
            // flCategory
            // 
            this.flCategory.AutoSize = true;
            this.flCategory.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flCategory.Location = new System.Drawing.Point(1, 63);
            this.flCategory.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.flCategory.Name = "flCategory";
            this.flCategory.Size = new System.Drawing.Size(70, 19);
            this.flCategory.TabIndex = 137;
            this.flCategory.Text = "Category";
            // 
            // inventoryCategoryTextBox
            // 
            this.inventoryCategoryTextBox.Location = new System.Drawing.Point(74, 63);
            this.inventoryCategoryTextBox.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.inventoryCategoryTextBox.Name = "inventoryCategoryTextBox";
            this.inventoryCategoryTextBox.Size = new System.Drawing.Size(198, 20);
            this.inventoryCategoryTextBox.TabIndex = 136;
            // 
            // flProjectCode
            // 
            this.flProjectCode.AutoSize = true;
            this.flProjectCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flProjectCode.Location = new System.Drawing.Point(1, 89);
            this.flProjectCode.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.flProjectCode.Name = "flProjectCode";
            this.flProjectCode.Size = new System.Drawing.Size(58, 19);
            this.flProjectCode.TabIndex = 135;
            this.flProjectCode.Text = "Project";
            // 
            // inventoryProjectTextBox
            // 
            this.inventoryProjectTextBox.Location = new System.Drawing.Point(74, 89);
            this.inventoryProjectTextBox.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.inventoryProjectTextBox.Name = "inventoryProjectTextBox";
            this.inventoryProjectTextBox.Size = new System.Drawing.Size(198, 20);
            this.inventoryProjectTextBox.TabIndex = 134;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.currentStockApplyFilter);
            this.panel4.Controls.Add(this.currentStockClearFilter);
            this.panel4.Controls.Add(this.currentStockStockCostTextBox);
            this.panel4.Controls.Add(this.currentStockUnitCostTextBox);
            this.panel4.Controls.Add(this.currentStockLocationTextBox);
            this.panel4.Controls.Add(this.currentstockItemCodeTextBox);
            this.panel4.Controls.Add(this.lbStockCost);
            this.panel4.Controls.Add(this.lbUnitCost);
            this.panel4.Controls.Add(this.lbLocation);
            this.panel4.Controls.Add(this.lbItemCode);
            this.panel4.Location = new System.Drawing.Point(469, 9);
            this.panel4.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(289, 167);
            this.panel4.TabIndex = 225;
            this.panel4.Visible = false;
            // 
            // currentStockApplyFilter
            // 
            this.currentStockApplyFilter.Font = new System.Drawing.Font("Calibri", 12.25F, System.Drawing.FontStyle.Bold);
            this.currentStockApplyFilter.Location = new System.Drawing.Point(177, 133);
            this.currentStockApplyFilter.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.currentStockApplyFilter.Name = "currentStockApplyFilter";
            this.currentStockApplyFilter.Size = new System.Drawing.Size(97, 27);
            this.currentStockApplyFilter.TabIndex = 9;
            this.currentStockApplyFilter.Text = "Apply Filter";
            this.currentStockApplyFilter.UseVisualStyleBackColor = true;
            this.currentStockApplyFilter.Click += new System.EventHandler(this.currentStockApplyFilter_Click);
            // 
            // currentStockClearFilter
            // 
            this.currentStockClearFilter.Font = new System.Drawing.Font("Calibri", 12.25F, System.Drawing.FontStyle.Bold);
            this.currentStockClearFilter.Location = new System.Drawing.Point(17, 133);
            this.currentStockClearFilter.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.currentStockClearFilter.Name = "currentStockClearFilter";
            this.currentStockClearFilter.Size = new System.Drawing.Size(105, 27);
            this.currentStockClearFilter.TabIndex = 8;
            this.currentStockClearFilter.Text = "Clear Filter";
            this.currentStockClearFilter.UseVisualStyleBackColor = true;
            this.currentStockClearFilter.Click += new System.EventHandler(this.currentStockClearFilter_Click);
            // 
            // currentStockStockCostTextBox
            // 
            this.currentStockStockCostTextBox.Location = new System.Drawing.Point(105, 109);
            this.currentStockStockCostTextBox.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.currentStockStockCostTextBox.Name = "currentStockStockCostTextBox";
            this.currentStockStockCostTextBox.Size = new System.Drawing.Size(173, 20);
            this.currentStockStockCostTextBox.TabIndex = 7;
            // 
            // currentStockUnitCostTextBox
            // 
            this.currentStockUnitCostTextBox.Location = new System.Drawing.Point(105, 79);
            this.currentStockUnitCostTextBox.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.currentStockUnitCostTextBox.Name = "currentStockUnitCostTextBox";
            this.currentStockUnitCostTextBox.Size = new System.Drawing.Size(173, 20);
            this.currentStockUnitCostTextBox.TabIndex = 6;
            // 
            // currentStockLocationTextBox
            // 
            this.currentStockLocationTextBox.Location = new System.Drawing.Point(105, 48);
            this.currentStockLocationTextBox.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.currentStockLocationTextBox.Name = "currentStockLocationTextBox";
            this.currentStockLocationTextBox.Size = new System.Drawing.Size(173, 20);
            this.currentStockLocationTextBox.TabIndex = 5;
            // 
            // currentstockItemCodeTextBox
            // 
            this.currentstockItemCodeTextBox.Location = new System.Drawing.Point(105, 20);
            this.currentstockItemCodeTextBox.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.currentstockItemCodeTextBox.Name = "currentstockItemCodeTextBox";
            this.currentstockItemCodeTextBox.Size = new System.Drawing.Size(173, 20);
            this.currentstockItemCodeTextBox.TabIndex = 4;
            this.currentstockItemCodeTextBox.Text = "hyd";
            // 
            // lbStockCost
            // 
            this.lbStockCost.AutoSize = true;
            this.lbStockCost.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbStockCost.Location = new System.Drawing.Point(13, 107);
            this.lbStockCost.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lbStockCost.Name = "lbStockCost";
            this.lbStockCost.Size = new System.Drawing.Size(80, 19);
            this.lbStockCost.TabIndex = 3;
            this.lbStockCost.Text = "Stock Cost";
            // 
            // lbUnitCost
            // 
            this.lbUnitCost.AutoSize = true;
            this.lbUnitCost.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbUnitCost.Location = new System.Drawing.Point(13, 76);
            this.lbUnitCost.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lbUnitCost.Name = "lbUnitCost";
            this.lbUnitCost.Size = new System.Drawing.Size(71, 19);
            this.lbUnitCost.TabIndex = 2;
            this.lbUnitCost.Text = "Unit Cost";
            // 
            // lbLocation
            // 
            this.lbLocation.AutoSize = true;
            this.lbLocation.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLocation.Location = new System.Drawing.Point(13, 44);
            this.lbLocation.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lbLocation.Name = "lbLocation";
            this.lbLocation.Size = new System.Drawing.Size(67, 19);
            this.lbLocation.TabIndex = 1;
            this.lbLocation.Text = "Location";
            // 
            // lbItemCode
            // 
            this.lbItemCode.AutoSize = true;
            this.lbItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbItemCode.Location = new System.Drawing.Point(13, 18);
            this.lbItemCode.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lbItemCode.Name = "lbItemCode";
            this.lbItemCode.Size = new System.Drawing.Size(78, 19);
            this.lbItemCode.TabIndex = 0;
            this.lbItemCode.Text = "Item Code";
            // 
            // currentStockdataGridView
            // 
            this.currentStockdataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.currentStockdataGridView.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.currentStockdataGridView.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.currentStockdataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.currentStockdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.currentStockdataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.stockItemCode,
            this.stockItemDescription,
            this.stockLocation,
            this.currentStockUnitCost,
            this.currentStockAvailableQty,
            this.currentStockValue,
            this.curretnStockPurchaseType,
            this.currentStockCreatedBy});
            this.currentStockdataGridView.DefaultCellStyle = dataGridViewCellStyle13;
            this.currentStockdataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.currentStockdataGridView.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.currentStockdataGridView.Location = new System.Drawing.Point(0, 0);
            this.currentStockdataGridView.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.currentStockdataGridView.Name = "currentStockdataGridView";
            this.currentStockdataGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.currentStockdataGridView.RowHeadersWidth = 62;
            this.currentStockdataGridView.RowsDefaultCellStyle = dataGridViewCellStyle14;
            this.currentStockdataGridView.RowTemplate.Height = 28;
            this.currentStockdataGridView.Size = new System.Drawing.Size(1501, 461);
            this.currentStockdataGridView.TabIndex = 224;
            this.currentStockdataGridView.Visible = false;
            // 
            // stockItemCode
            // 
            this.stockItemCode.HeaderText = "ItemCode";
            this.stockItemCode.MinimumWidth = 8;
            this.stockItemCode.Name = "stockItemCode";
            this.stockItemCode.ReadOnly = true;
            this.stockItemCode.Width = 102;
            // 
            // stockItemDescription
            // 
            this.stockItemDescription.HeaderText = "Item Description";
            this.stockItemDescription.MinimumWidth = 8;
            this.stockItemDescription.Name = "stockItemDescription";
            this.stockItemDescription.ReadOnly = true;
            this.stockItemDescription.Width = 149;
            // 
            // stockLocation
            // 
            this.stockLocation.HeaderText = "Location";
            this.stockLocation.MinimumWidth = 8;
            this.stockLocation.Name = "stockLocation";
            this.stockLocation.ReadOnly = true;
            this.stockLocation.Width = 93;
            // 
            // currentStockUnitCost
            // 
            this.currentStockUnitCost.HeaderText = "Unit Cost";
            this.currentStockUnitCost.MinimumWidth = 8;
            this.currentStockUnitCost.Name = "currentStockUnitCost";
            this.currentStockUnitCost.ReadOnly = true;
            // 
            // currentStockAvailableQty
            // 
            this.currentStockAvailableQty.HeaderText = "Available Qty";
            this.currentStockAvailableQty.MinimumWidth = 8;
            this.currentStockAvailableQty.Name = "currentStockAvailableQty";
            this.currentStockAvailableQty.ReadOnly = true;
            this.currentStockAvailableQty.Width = 127;
            // 
            // currentStockValue
            // 
            this.currentStockValue.HeaderText = "Stock Value";
            this.currentStockValue.MinimumWidth = 8;
            this.currentStockValue.Name = "currentStockValue";
            this.currentStockValue.ReadOnly = true;
            this.currentStockValue.Width = 115;
            // 
            // curretnStockPurchaseType
            // 
            this.curretnStockPurchaseType.HeaderText = "Purchase Type";
            this.curretnStockPurchaseType.MinimumWidth = 8;
            this.curretnStockPurchaseType.Name = "curretnStockPurchaseType";
            this.curretnStockPurchaseType.ReadOnly = true;
            this.curretnStockPurchaseType.Width = 134;
            // 
            // currentStockCreatedBy
            // 
            this.currentStockCreatedBy.HeaderText = "Create BY";
            this.currentStockCreatedBy.MinimumWidth = 8;
            this.currentStockCreatedBy.Name = "currentStockCreatedBy";
            this.currentStockCreatedBy.ReadOnly = true;
            this.currentStockCreatedBy.Width = 101;
            // 
            // dataGridViewGINReverse
            // 
            this.dataGridViewGINReverse.AllowDrop = true;
            this.dataGridViewGINReverse.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridViewGINReverse.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridViewGINReverse.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.dataGridViewGINReverse.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewGINReverse.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewGINReverse.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ItemCodeReverse,
            this.GINNumberReverse,
            this.ReturnQTYReverse,
            this.UnitPriceReverse,
            this.InvoiceNumberReverse,
            this.VendorNameReverse,
            this.VendorCodeReverse,
            this.GINDateReverse,
            this.InvoiceDateReverse,
            this.ReverseGINDate});
            this.dataGridViewGINReverse.DefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridViewGINReverse.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewGINReverse.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridViewGINReverse.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewGINReverse.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.dataGridViewGINReverse.Name = "dataGridViewGINReverse";
            this.dataGridViewGINReverse.RowHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridViewGINReverse.RowHeadersWidth = 62;
            this.dataGridViewGINReverse.RowsDefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridViewGINReverse.RowTemplate.Height = 28;
            this.dataGridViewGINReverse.Size = new System.Drawing.Size(1501, 461);
            this.dataGridViewGINReverse.TabIndex = 224;
            this.dataGridViewGINReverse.Visible = false;
            // 
            // ItemCodeReverse
            // 
            this.ItemCodeReverse.HeaderText = "Item Code";
            this.ItemCodeReverse.MinimumWidth = 8;
            this.ItemCodeReverse.Name = "ItemCodeReverse";
            this.ItemCodeReverse.Width = 97;
            // 
            // GINNumberReverse
            // 
            this.GINNumberReverse.HeaderText = "GIN Number";
            this.GINNumberReverse.MinimumWidth = 8;
            this.GINNumberReverse.Name = "GINNumberReverse";
            this.GINNumberReverse.ReadOnly = true;
            this.GINNumberReverse.Width = 112;
            // 
            // ReturnQTYReverse
            // 
            this.ReturnQTYReverse.HeaderText = "Return Qty";
            this.ReturnQTYReverse.MinimumWidth = 8;
            this.ReturnQTYReverse.Name = "ReturnQTYReverse";
            this.ReturnQTYReverse.ReadOnly = true;
            this.ReturnQTYReverse.Width = 102;
            // 
            // UnitPriceReverse
            // 
            this.UnitPriceReverse.HeaderText = "Unit Price";
            this.UnitPriceReverse.MinimumWidth = 8;
            this.UnitPriceReverse.Name = "UnitPriceReverse";
            this.UnitPriceReverse.ReadOnly = true;
            this.UnitPriceReverse.Width = 95;
            // 
            // InvoiceNumberReverse
            // 
            this.InvoiceNumberReverse.HeaderText = "Invoice Number";
            this.InvoiceNumberReverse.MinimumWidth = 8;
            this.InvoiceNumberReverse.Name = "InvoiceNumberReverse";
            this.InvoiceNumberReverse.ReadOnly = true;
            this.InvoiceNumberReverse.Width = 132;
            // 
            // VendorNameReverse
            // 
            this.VendorNameReverse.HeaderText = "Vendor Name";
            this.VendorNameReverse.MinimumWidth = 8;
            this.VendorNameReverse.Name = "VendorNameReverse";
            this.VendorNameReverse.ReadOnly = true;
            this.VendorNameReverse.Width = 119;
            // 
            // VendorCodeReverse
            // 
            this.VendorCodeReverse.HeaderText = "Vendor Code";
            this.VendorCodeReverse.MinimumWidth = 8;
            this.VendorCodeReverse.Name = "VendorCodeReverse";
            this.VendorCodeReverse.ReadOnly = true;
            this.VendorCodeReverse.Width = 114;
            // 
            // GINDateReverse
            // 
            this.GINDateReverse.HeaderText = "GIN Date";
            this.GINDateReverse.MinimumWidth = 8;
            this.GINDateReverse.Name = "GINDateReverse";
            this.GINDateReverse.ReadOnly = true;
            this.GINDateReverse.Width = 89;
            // 
            // InvoiceDateReverse
            // 
            this.InvoiceDateReverse.HeaderText = "Invoice Date";
            this.InvoiceDateReverse.MinimumWidth = 8;
            this.InvoiceDateReverse.Name = "InvoiceDateReverse";
            this.InvoiceDateReverse.ReadOnly = true;
            this.InvoiceDateReverse.Width = 110;
            // 
            // ReverseGINDate
            // 
            this.ReverseGINDate.HeaderText = "GIN Reverse Date";
            this.ReverseGINDate.MinimumWidth = 8;
            this.ReverseGINDate.Name = "ReverseGINDate";
            this.ReverseGINDate.ReadOnly = true;
            this.ReverseGINDate.Width = 141;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.panel4);
            this.panel5.Location = new System.Drawing.Point(506, 0);
            this.panel5.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(770, 190);
            this.panel5.TabIndex = 225;
            // 
            // panel6
            // 
            this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel6.AutoSize = true;
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel6.Controls.Add(this.dgvALLLedgerReport);
            this.panel6.Controls.Add(this.lblNoitems);
            this.panel6.Controls.Add(this.dataGridViewGIN);
            this.panel6.Controls.Add(this.IndentLogDataGrideView);
            this.panel6.Controls.Add(this.dataGridViewFIFOLog);
            this.panel6.Controls.Add(this.dataGridViewReturnLog);
            this.panel6.Controls.Add(this.dataGridViewScrapLog);
            this.panel6.Controls.Add(this.dataGridViewIssueLog);
            this.panel6.Controls.Add(this.currentStockdataGridView);
            this.panel6.Controls.Add(this.dataGridViewGINReverse);
            this.panel6.Controls.Add(this.dgvmaterialLedger);
            this.panel6.Location = new System.Drawing.Point(2, 234);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1505, 465);
            this.panel6.TabIndex = 226;
            // 
            // frmInventoryLedger
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1512, 746);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.chkItemDesc);
            this.Controls.Add(this.chkItemCode);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtItemDescription);
            this.Controls.Add(this.chklbItemList);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(1, 3, 1, 3);
            this.Name = "frmInventoryLedger";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Inventory Ledger";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMaterialLedger_FormClosing);
            this.Load += new System.EventHandler(this.frmMaterialLedger_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvmaterialLedger)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvALLLedgerReport)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGIN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.IndentLogDataGrideViewold)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.IndentLogDataGrideView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewFIFOLog)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewReturnLog)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewScrapLog)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewIssueLog)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.currentStockdataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewGINReverse)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblitemdescrption;
        private System.Windows.Forms.Label lblavailableqty;
        private System.Windows.Forms.Label lblavaqty;
        private System.Windows.Forms.Label lblrepeatCost;
        private System.Windows.Forms.Label lblRepeatitemcode;
        private System.Windows.Forms.Label lblUnitCost;
        private System.Windows.Forms.Label lblItemcode;
        private System.Windows.Forms.DataGridView dgvmaterialLedger;
        private System.Windows.Forms.Label lblNoitems;
        private System.Windows.Forms.DateTimePicker dtpfromdate;
        private System.Windows.Forms.DateTimePicker dtptodate;
        private System.Windows.Forms.Label lblfromdate;
        private System.Windows.Forms.Label lbltodate;
        private System.Windows.Forms.Button btnmaterialledger;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtItemDescription;
        private System.Windows.Forms.CheckedListBox chklbItemList;
        private System.Windows.Forms.Label lblitemname;
        private System.Windows.Forms.Label lblrecievqty;
        private System.Windows.Forms.Label lblissuedqty;
        private System.Windows.Forms.Label lblreturnqty;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnExportExcel;
        private System.Windows.Forms.CheckBox chkItemDesc;
        private System.Windows.Forms.CheckBox chkItemCode;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblOpeningBalance;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblClosingStock;
        private System.Windows.Forms.Label lblIssue;
        private System.Windows.Forms.Label lblRecipt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Recieved;
        private System.Windows.Forms.DataGridViewTextBoxColumn Issued;
        private System.Windows.Forms.DataGridViewTextBoxColumn Return;
        private System.Windows.Forms.DataGridViewTextBoxColumn StockAdjsued;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitcost;
        private System.Windows.Forms.DataGridViewTextBoxColumn amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn refnumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn projectcode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectDesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn Customer;
        private System.Windows.Forms.DataGridViewTextBoxColumn User;
        private System.Windows.Forms.Label lblStockAdjusted;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblStockAdjused;
        private System.Windows.Forms.Label lblItemReturn;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnAllledger;
        private System.Windows.Forms.DataGridView dgvALLLedgerReport;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button ReturnItem;
        private System.Windows.Forms.Button FIFOLog;
        private System.Windows.Forms.Button IndentLog;
        private System.Windows.Forms.Button GINLog;
        // newlly added for Inventory GIN logs only
        private System.Windows.Forms.DataGridView dataGridViewGIN;
        private System.Windows.Forms.DataGridView IndentLogDataGrideViewold;//IndentLogDataGrideViewold
        private System.Windows.Forms.DataGridViewTextBoxColumn GINNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCodeGIN;
        private System.Windows.Forms.DataGridViewTextBoxColumn CreateDateGIN;
        private System.Windows.Forms.DataGridViewTextBoxColumn RefNumberGIN;
        private System.Windows.Forms.DataGridViewTextBoxColumn BOMProjectCodeGIN;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectCodeGIN;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReceivedQtYGIN;
        private System.Windows.Forms.DataGridViewTextBoxColumn POQtYGIN;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitCostGIN;
        private System.Windows.Forms.DataGridViewTextBoxColumn SGSTGIN;
        private System.Windows.Forms.DataGridViewTextBoxColumn CGSTGIN;
        private System.Windows.Forms.DataGridViewTextBoxColumn IGSTGIN;
        private System.Windows.Forms.DataGridViewTextBoxColumn POAmountGIN;
        private System.Windows.Forms.DataGridViewTextBoxColumn RemainingQtyGIN;
        private System.Windows.Forms.DataGridViewTextBoxColumn BatchCodeGIN;
        private System.Windows.Forms.DataGridViewTextBoxColumn LocationGIN;
        private System.Windows.Forms.DataGridViewTextBoxColumn IndentQtyGIN;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssuedQtyGIN;
        private System.Windows.Forms.DataGridViewTextBoxColumn QRPrintStatus;//QRPrintStatus
        private System.Windows.Forms.DataGridViewTextBoxColumn IndentNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn IndentItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn IndentProjectCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn IndentBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn IndentDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn IndentQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn IndentStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn GINNumberIndent;
        private System.Windows.Forms.DataGridViewTextBoxColumn BatchCodeIndent;
        private System.Windows.Forms.DataGridViewTextBoxColumn LocationIndent;
        private System.Windows.Forms.DataGridViewTextBoxColumn PickedLocationIndent;
        private System.Windows.Forms.DataGridViewTextBoxColumn PickedBatchCodeIndent;
        private System.Windows.Forms.DataGridViewTextBoxColumn IndentFIFO;
        private System.Windows.Forms.DataGridView IndentLogDataGrideView;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCodeFIFO;
        private System.Windows.Forms.DataGridViewTextBoxColumn IndentNoFIFO;
        private System.Windows.Forms.DataGridViewTextBoxColumn IndentQtyFIFO;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectCodeFIFO;
        private System.Windows.Forms.DataGridViewTextBoxColumn RemarksFIFO;
        private System.Windows.Forms.DataGridViewTextBoxColumn GINNumberFIFO;
        private System.Windows.Forms.DataGridViewTextBoxColumn BatchCodeFIFO;
        private System.Windows.Forms.DataGridViewTextBoxColumn LocationFIFO;
        private System.Windows.Forms.DataGridViewTextBoxColumn PickedBatchCodeFIFO;
        private System.Windows.Forms.DataGridViewTextBoxColumn PickedLocationFIFO;
        private System.Windows.Forms.DataGridViewTextBoxColumn IndentPickedByFIFO;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssuedByFIFO;
        private System.Windows.Forms.DataGridViewTextBoxColumn CreateDateFIFO;
        private System.Windows.Forms.DataGridViewTextBoxColumn FIFOFollowed;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReturnItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReturnIndentNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReturnProjectCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReturnQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReturnCreateDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReturnedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReturnProjectStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReturnGINNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReturnBatchCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReturnLocation;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReturnVendorCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReturnType;
        private System.Windows.Forms.DataGridViewTextBoxColumn ScrapItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ScrapIndentNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ScrapProjectCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ScrapQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn ScrapCreateDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ScrapReturnedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn ScrapProjectStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn ScrapGINNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn ScrapBatchCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ScrapLocation;
        private System.Windows.Forms.DataGridViewTextBoxColumn ScrapReturnType;
        //newly added for issue log
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCodeIssueLog;
        private System.Windows.Forms.DataGridViewTextBoxColumn IndentNoIssueLog;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectCodeIssueLog;
        private System.Windows.Forms.DataGridViewTextBoxColumn IndentByIssueLog;
        private System.Windows.Forms.DataGridViewTextBoxColumn IndentQtyIssueLog;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssuedQuantityIssueLog;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssueTypeIssueLog;
        private System.Windows.Forms.DataGridViewTextBoxColumn RemarksIssueLog;
        private System.Windows.Forms.DataGridViewTextBoxColumn StatusIssueLog;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectBOMCodeIssueLog;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductNoIssueLog;
        private System.Windows.Forms.DataGridViewTextBoxColumn GINNumberIssueLog;
        private System.Windows.Forms.DataGridViewTextBoxColumn BatchCodeIssueLog;
        private System.Windows.Forms.DataGridViewTextBoxColumn LocationIssueLog;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssuedServerDateIssueLog;


        private System.Windows.Forms.DataGridView dataGridViewFIFOLog;
        private System.Windows.Forms.DataGridView dataGridViewReturnLog;
        private System.Windows.Forms.Button ScrapLog;
        private System.Windows.Forms.DataGridView dataGridViewScrapLog;
        private System.Windows.Forms.Button IssueLog;
        private System.Windows.Forms.DataGridView dataGridViewIssueLog;
        private System.Windows.Forms.Label inventoryQuarantineQty;
        private System.Windows.Forms.Label Quarantinelb;
        private System.Windows.Forms.Label inventoryReturnQty;
        private System.Windows.Forms.Label Returnlb;
        private System.Windows.Forms.Label inventoryIssueQty;
        private System.Windows.Forms.Label Issuelb;
        private System.Windows.Forms.Label inventoryIndentQty;
        private System.Windows.Forms.Label Indentlb;
        private System.Windows.Forms.Label inventoryAvailableQty;
        private System.Windows.Forms.Label AvailableQtylb;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssueLog_ItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssueLog_IndentNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssueLog_ProjectCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssueLog_IndentBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssueLog_IndentQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssueLog_IssuedQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssueLog_IssueType;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssueLog_Remarks;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssueLog_Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssueLog_ProjectBOMCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssueLog_ProductNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssueLog_GINNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssueLog_BatchCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssueLog_Location;
        private System.Windows.Forms.DataGridViewTextBoxColumn IssueLog_IssuedBy;//IssueLog_IssuedBy
        private System.Windows.Forms.DataGridViewTextBoxColumn IssueLog_IssuedServerDate;
        private System.Windows.Forms.Label inventoryReceivedQty;
        private System.Windows.Forms.Label Receivedlb;
        private System.Windows.Forms.CheckBox Project;
        private System.Windows.Forms.TextBox inventoryVendorTextBox;
        private System.Windows.Forms.Label Vendorlb;
        private System.Windows.Forms.Label Tolb;
        private System.Windows.Forms.Label From;
        private System.Windows.Forms.DateTimePicker inventoryToDateTimePicker;
        private System.Windows.Forms.DateTimePicker inventoryFromIndateTimePicker;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label flProjectCode;
        private System.Windows.Forms.TextBox inventoryProjectTextBox;
        private System.Windows.Forms.Label flCategory;
        private System.Windows.Forms.TextBox inventoryCategoryTextBox;
        private System.Windows.Forms.Button btnClearFilter;
        private System.Windows.Forms.Button btnApplyFilter;
        private System.Windows.Forms.TextBox inventoryLocationtextBox;
        private System.Windows.Forms.Label flLocation;
        private System.Windows.Forms.Button currentStock;
        private System.Windows.Forms.DataGridView currentStockdataGridView;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox currentStockStockCostTextBox;
        private System.Windows.Forms.TextBox currentStockUnitCostTextBox;
        private System.Windows.Forms.TextBox currentStockLocationTextBox;
        private System.Windows.Forms.TextBox currentstockItemCodeTextBox;
        private System.Windows.Forms.Label lbStockCost;
        private System.Windows.Forms.Label lbUnitCost;
        private System.Windows.Forms.Label lbLocation;
        private System.Windows.Forms.Label lbItemCode;
        private System.Windows.Forms.Button currentStockApplyFilter;
        private System.Windows.Forms.Button currentStockClearFilter;
        private System.Windows.Forms.DataGridViewTextBoxColumn stockItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn stockItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn stockLocation;
        private System.Windows.Forms.DataGridViewTextBoxColumn currentStockUnitCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn currentStockAvailableQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn currentStockValue;
        private System.Windows.Forms.DataGridViewTextBoxColumn curretnStockPurchaseType;
        private System.Windows.Forms.DataGridViewTextBoxColumn currentStockCreatedBy;
        private System.Windows.Forms.Button GINReverse;
        private System.Windows.Forms.DataGridView dataGridViewGINReverse;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCodeReverse;
        private System.Windows.Forms.DataGridViewTextBoxColumn GINNumberReverse;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReturnQTYReverse;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitPriceReverse;
        private System.Windows.Forms.DataGridViewTextBoxColumn InvoiceNumberReverse;
        private System.Windows.Forms.DataGridViewTextBoxColumn VendorNameReverse;
        private System.Windows.Forms.DataGridViewTextBoxColumn VendorCodeReverse;
        private System.Windows.Forms.DataGridViewTextBoxColumn GINDateReverse;
        private System.Windows.Forms.DataGridViewTextBoxColumn InvoiceDateReverse;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReverseGINDate;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox indentNotextBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel6;
    }
}