﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Part_Reciept
{
    public partial class GINPOView : Form
    {
        public GINPOView()
        {
            InitializeComponent();
        }
        frmForm2 frm = new frmForm2();
        DataTable dtPolist = new DataTable();
        DataTable dtProjectList = new DataTable();
        DataAccessLayer DAL = new DataAccessLayer();
        DataView dvPOViewList = new DataView();
        BindingSource bsItemList = new BindingSource();
        DataView dvPOList = new DataView();
        Login.frmLoginForm login = new Login.frmLoginForm();
        Global Globaclass = new Global();
        DataTable ledger = new DataTable();
        double dReceipt;
        double dAvailableQty;
        string itemcreateddate;
        double dStockValue;
        private void GINPOView_Load(object sender, EventArgs e)
        {
            dtPolist = DAL.fnGINPOlistforview(0, null).Tables[0];
            if (dtPolist.Rows.Count > 0)
            {
                foreach (DataRow dr in dtPolist.Rows)
                {
                    if (!cmbGinnumber.Items.Contains(dr["GINNumber"].ToString()))
                        cmbGinnumber.Items.Add(dr["GINNumber"].ToString());
                }
            }
            ledger = DAL.fnGetLastGINnumber(1).Tables[0];
            foreach (DataRow DR in ledger.Rows)
            {
                if (!cmbLedger.Items.Contains(DR["LedgerName"].ToString()))
                    cmbLedger.Items.Add(DR["LedgerName"].ToString());
            }

            if (login.GetUserDetails[23] == "Accounts")
            {
                chkGINPO.Visible = true;
                chkGINPO.Checked = true;
                pnGINTax.Visible = true;
            }
            else
            {
                chkGINPO.Visible = false;
                pnGINTax.Visible = false;
            }
        }
        DataTable dtItemDetails = new DataTable();

        private void GINPOView_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnExit();
        }

        private void fnExit()
        {
            this.Hide();
            frm.Show();
        }


        DataTable dtGINNUmber = new DataTable();
        DataTable itemGIN = new DataTable();
        private void cmbGinnumber_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (chkGINPO.Checked)
            {
                dtGINNUmber = DAL.fnGINPOlistforview(3, cmbGinnumber.Text).Tables[0];
                if (dtGINNUmber.Rows.Count > 0)
                {
                    dgvPOItemList.AutoGenerateColumns = false;
                    dgvPOItemList.DataSource = dtGINNUmber;
                    fnTotalPOCost();
                }
            }
            else
            {
                dtGINNUmber = DAL.fnGINPOlistforview(1, cmbGinnumber.Text).Tables[0];
                if (dtGINNUmber.Rows.Count > 0)
                {
                    textBox1.Text = dtGINNUmber.Rows[0][0].ToString();
                    txtOldInvioceNumber.Text = dtGINNUmber.Rows[0][1].ToString();
                    dtpOldInvoiceDate.Text = dtGINNUmber.Rows[0][2].ToString();
                    dtpInvoiceDate.Text = dtGINNUmber.Rows[0][2].ToString();
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (cmbLedger.SelectedIndex >= 0)
            {
                Globaclass.iSuccess = DAL.fnUpdateLedger(0, cmbLedger.Text, cmbGinnumber.Text, "", "");
                textBox1.Text = cmbLedger.Text;
                cmbLedger.SelectedIndex = -1;
                MessageBox.Show("Gin number " + cmbGinnumber.Text + " ledger updated succeessfully", "Success", 0, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Please select the ledger", "Error", 0, MessageBoxIcon.Error);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            fnExit();
        }

        private void btnAddledger_Click(object sender, EventArgs e)
        {
            panelledger.Visible = true;
            pnUpdateInvoicedate.Visible = false;
        }

        private void btnledgersave_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(LedgerTextbox.Text))
            {
                Globaclass.iSuccess = DAL.fnUpdateLedger(1, LedgerTextbox.Text, login.GetUserDetails[2], "", "");
                if (Globaclass.iSuccess > 0)
                {
                    MessageBox.Show("Ledger Created succeessfully", "Success", 0, MessageBoxIcon.Information);
                    LedgerTextbox.ResetText();
                    panelledger.Visible = false;

                }
            }
            else
            {
                MessageBox.Show("Enter ledger name", "Error", 0, MessageBoxIcon.Error);
                LedgerTextbox.Focus();
            }
        }

        private void btnledgercancel_Click(object sender, EventArgs e)
        {
            panelledger.Visible = false;
            pnUpdateInvoicedate.Visible = false;
        }

        private void btnInvoiceUpdate_Click(object sender, EventArgs e)
        {
            pnUpdateInvoicedate.Visible = true;
            panelledger.Visible = false;
        }

        private void btnInvoicecancel_Click(object sender, EventArgs e)
        {
            pnUpdateInvoicedate.Visible = false;
            panelledger.Visible = false;
        }

        private void btnInvoicenodateupdate_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtinvoiceno.Text))
            {
                Globaclass.iSuccess = DAL.fnUpdateLedger(2, txtinvoiceno.Text, cmbGinnumber.Text, dtpInvoiceDate.Text, "");
                if (Globaclass.iSuccess > 0)
                {
                    MessageBox.Show("Invoice no, invoice date updated succeessfully", "Success", 0, MessageBoxIcon.Information);
                    txtinvoiceno.ResetText();
                }
            }
            else
            {
                MessageBox.Show("Enter Invoice number", "Error", 0, MessageBoxIcon.Error);
                txtinvoiceno.Focus();
            }
        }

        private void UpdateThelandingCost(string ginNumber, string itemCode)
        {
            int UpdateThelandingCost = DAL.UpdateThelandingCostStatus(0, ginNumber, itemCode);
        }

        private void dgvPOItemList_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            //MessageBox.Show("Inprogress...");

            if ((dgvPOItemList.CurrentCell.Value) != null)
            {
                //MessageBox.Show(dgvPOItemList.CurrentCell.Value.ToString());

                if (!string.IsNullOrEmpty(dgvPOItemList.CurrentCell.Value.ToString()))
                {
                    if (dgvPOItemList.CurrentCell.Value.ToString() != ".")
                    {

                        itemGIN = DAL.getDetailsFromGIN(cmbGinnumber.Text, dgvPOItemList.CurrentRow.Cells["ItemCode"].Value.ToString()).Tables[0];



                        // MessageBox.Show(itemGIN.Rows.Count.ToString());
                       // if(itemGIN.Rows[0]["LandingCostStatus"].ToString() == "")
                       // {
                        //    MessageBox.Show(itemGIN.Rows[0]["LandingCostStatus"].ToString());

                       // }
                      //  else{
                        //    MessageBox.Show("LandingCostStatus is not NULL");
                      //  }

                       // if (itemGIN.Rows.Count > 0)
                        //{
                         //   foreach (DataRow row in itemGIN.Rows)
                          //  { 
                           //     CDPercent = row["CDValue"].ToString();
                           //     CDIGSTRate = row["CDIGSTAmount"].ToString() ;
                            //    CDCessRate = row["CDCessAmount"].ToString();
                           // }
                       // }

                       

                        switch (dgvPOItemList.CurrentCell.OwningColumn.Name)
                        {
                            case "CustomsDuty":
                                
                                dgvPOItemList.CurrentRow.Cells["CustomsDutyAmt"].Value = (((Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Freight"].Value.ToString()) + Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Amount"].Value.ToString())) / 100) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["CustomsDuty"].Value.ToString())).ToString("0.00");
                                Globaclass.iSuccess = DAL.fnUpdateLedger(3, dgvPOItemList.CurrentRow.Cells["CustomsDuty"].Value.ToString(), cmbGinnumber.Text, dgvPOItemList.CurrentRow.Cells["CustomsDutyAmt"].Value.ToString(), dgvPOItemList.CurrentRow.Cells["ItemCode"].Value.ToString());
                                UpdateThelandingCost( cmbGinnumber.Text, dgvPOItemList.CurrentRow.Cells["ItemCode"].Value.ToString());
                                break;

                            case "CustomsDutyAmt":
                                Globaclass.iSuccess = DAL.fnUpdateLedger(3, dgvPOItemList.CurrentRow.Cells["CustomsDuty"].Value.ToString(), cmbGinnumber.Text, dgvPOItemList.CurrentRow.Cells["CustomsDutyAmt"].Value.ToString(), dgvPOItemList.CurrentRow.Cells["ItemCode"].Value.ToString());
                                UpdateThelandingCost( cmbGinnumber.Text, dgvPOItemList.CurrentRow.Cells["ItemCode"].Value.ToString());

                                break;

                            case "CDIGST":
                                dgvPOItemList.CurrentRow.Cells["CDIGSTAmt"].Value = ((((Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Freight"].Value.ToString()) + Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Amount"].Value.ToString())) + Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["CustomsDutyAmt"].Value.ToString()) + Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["CessAmt"].Value.ToString())) / 100) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["CDIGST"].Value.ToString())).ToString("0.00");
                                Globaclass.iSuccess = DAL.fnUpdateLedger(4, dgvPOItemList.CurrentRow.Cells["CDIGST"].Value.ToString(), cmbGinnumber.Text, dgvPOItemList.CurrentRow.Cells["CDIGSTAmt"].Value.ToString(), dgvPOItemList.CurrentRow.Cells["ItemCode"].Value.ToString());
                                UpdateThelandingCost( cmbGinnumber.Text, dgvPOItemList.CurrentRow.Cells["ItemCode"].Value.ToString());

                                break;

                            case "CDIGSTAmt":
                                Globaclass.iSuccess = DAL.fnUpdateLedger(4, dgvPOItemList.CurrentRow.Cells["CDIGST"].Value.ToString(), cmbGinnumber.Text, dgvPOItemList.CurrentRow.Cells["CDIGSTAmt"].Value.ToString(), dgvPOItemList.CurrentRow.Cells["ItemCode"].Value.ToString());
                                UpdateThelandingCost( cmbGinnumber.Text, dgvPOItemList.CurrentRow.Cells["ItemCode"].Value.ToString());

                                break;

                            case "Cess":
                                dgvPOItemList.CurrentRow.Cells["CessAmt"].Value = ((Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["CustomsDutyAmt"].Value.ToString()) / 100) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Cess"].Value.ToString())).ToString("0.00");
                                Globaclass.iSuccess = DAL.fnUpdateLedger(5, dgvPOItemList.CurrentRow.Cells["Cess"].Value.ToString(), cmbGinnumber.Text, dgvPOItemList.CurrentRow.Cells["CessAmt"].Value.ToString(), dgvPOItemList.CurrentRow.Cells["ItemCode"].Value.ToString());
                                UpdateThelandingCost( cmbGinnumber.Text, dgvPOItemList.CurrentRow.Cells["ItemCode"].Value.ToString());

                                break;

                            case "CessAmt":
                                Globaclass.iSuccess = DAL.fnUpdateLedger(5, dgvPOItemList.CurrentRow.Cells["Cess"].Value.ToString(), cmbGinnumber.Text, dgvPOItemList.CurrentRow.Cells["CessAmt"].Value.ToString(), dgvPOItemList.CurrentRow.Cells["ItemCode"].Value.ToString());
                                UpdateThelandingCost( cmbGinnumber.Text, dgvPOItemList.CurrentRow.Cells["ItemCode"].Value.ToString());
                                break;

                        }

                        fnTotalPOCost();
                     

                        DataSet ponumberset = DAL.getponumberFromGIN(cmbGinnumber.Text);
                        //MessageBox.Show(ponumberset.Tables[0].Rows[0]["RefNumber"].ToString(), "1");

                        if (ponumberset != null && ponumberset.Tables.Count > 0 && ponumberset.Tables[0].Rows.Count > 0)
                        {
                           // MessageBox.Show(ponumberset.Tables[0].Rows[0]["RefNumber"].ToString());
                            string refNumber = ponumberset.Tables[0].Rows[0]["RefNumber"].ToString();

                            // Now pass refNumber to fnGetTransactionType
                            DataSet ds = DAL.fnGetTransactionType(refNumber);
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                            {
                                //MessageBox.Show(ponumberset.Tables[0].Rows[0]["RefNumber"].ToString(), "2");
                                string transactionType = ds.Tables[0].Rows[0]["TransactionType"].ToString();

                                if (transactionType.Equals("International", StringComparison.OrdinalIgnoreCase))
                                {
                                    string itemcode = dgvPOItemList.CurrentRow.Cells["ItemCode"].Value.ToString();

                                    dtItemDetails = DAL.fnItemDetails(itemcode).Tables[0];

                                    //MessageBox.Show(dtItemDetails.Rows.Count.ToString(), "Item Count");

                            if (dtItemDetails.Rows.Count > 0)
                            {
                                if (dtItemDetails.Rows[0]["CreatedDate"].ToString() == "")
                                {
                              itemcreateddate = DateTime.Now.ToString("dd-MM-yyyy");
                                }
                                else
                                {
                                    itemcreateddate = (dtItemDetails.Rows[0]["CreatedDate"].ToString());
                                }
                                if (dtItemDetails.Rows[0]["AvailableQty"].ToString() == "")
                                {
                                    dAvailableQty = (Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["OrderedQty"].Value));
                                }
                                else
                                {
                                    dAvailableQty = Convert.ToDouble(dtItemDetails.Rows[0]["AvailableQty"].ToString()) + (Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["OrderedQty"].Value));
                                }
                                if (dtItemDetails.Rows[0]["Receipt"].ToString() == "")
                                {

                                    dReceipt = (Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["OrderedQty"].Value));
                                }
                                else
                                {
                                    dReceipt = Convert.ToDouble(dtItemDetails.Rows[0]["Receipt"].ToString()) + (Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["OrderedQty"].Value));
                                }
                                if (dtItemDetails.Rows[0]["UnitCost"].ToString() == "")
                                {
                                    dStockValue = 0;
                                }
                                else
                                {
                                    dStockValue = Convert.ToDouble(dtItemDetails.Rows[0]["UnitCost"]) * dAvailableQty;
                                }


                             
                                        //Weighted Average Rate calculation implentation.


                                        // string itemcode = dgvPOItemList.CurrentRow.Cells["ItemCode"].Value.ToString();

                                        InventoryService service = new InventoryService();
                                        DateTime fromDate = new DateTime(2025, 3, 31, 0, 0, 0);
                                        DateTime toDate = DateTime.Now; 



                                        // Step 1: Load all transactions for that item
                                        List<InventoryTransaction> transactions = service.LoadTransactions(fromDate, toDate, itemcode);

                                        // Step 2: Run WAR
                                        List<WarResult> warResults = service.CalculateWAR(transactions);

                                        // Step 3: Get latest WAR (last transaction)
                                        decimal latestWAR = 0;
                                        if (warResults.Count > 0) {
                                            latestWAR = warResults.Last().WeightedAverageRate;
                                        }
                                       // MessageBox.Show(lblGinno.Text , "logs"); 
                                        DAL.fnUpdateItemDetailswhenCDValueChanged(Global.uUPDATE, dgvPOItemList.CurrentRow.Cells["ItemCode"].Value.ToString(), (double)latestWAR);
                                       // Globaclass.iSuccess = DAL.fnAddERPLog(0, lblGinno.Text, login.GetUserDetails[2], DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), "Latest WAR Updated based on '" + lblGinno.Text + "'", "Receipt");
                                        Globaclass.iSuccess = DAL.fnAddERPLog(0, lblGinno.Text, login.GetUserDetails[2], DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), "Latest WAR Updated"+" "+latestWAR.ToString()+" "+ itemcode, "Receipt");

                                        // MessageBox.Show($@"CD : {CDPercent}-CDGIST:{CDIGSTRate}-CDCess:{CDCessRate}");
                                        // MessageBox.Show("Inprogress");
                                        DataTable getERPTransactionLog = DAL.fnGetERPTransactionLog(cmbGinnumber.Text).Tables[0];

                                        // if (CDPercent=="0" && CDIGSTRate =="0" && CDCessRate == "0")

                                        if (itemGIN.Rows[0]["LandingCostStatus"].ToString() == "")
                                        {
                                            Globaclass.iSuccess = DAL.fnUpdateItemDetailsWithouCD(Global.uUPDATE, (String.Format("{0:MM/dd/yyyy}", itemcreateddate.ToString())), dAvailableQty, dReceipt, dStockValue, dgvPOItemList.CurrentRow.Cells["ItemCode"].Value.ToString());
                                            Globaclass.iSuccess = DAL.fnAddERPLog(0, cmbGinnumber.Text , login.GetUserDetails[2], DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), "Item AvailableQty Updated", "ItemMaster");
                                            MessageBox.Show("Item Mater Updated");
                                        }
                                        else
                                        {
                                           // MessageBox.Show("Item Mater AvailableQty Already Updated");
                                        }

                                        // Globaclass.iSuccess = DAL.fnUpdateItemDetailsWithouCD(Global.uUPDATE, (String.Format("{0:MM/dd/yyyy}", itemcreateddate.ToString())), dAvailableQty, dReceipt, dStockValue, dgvPOItemList.CurrentRow.Cells["ItemCode"].Value.ToString());
                                        // Command for finding the issue - by rajkumar  


                                    }
                                }
                            }
                            else
                            {
                                //MessageBox.Show("erroe");
                                fnErrorValue();
                            }
                    }
                    else
                    {
                        fnErrorValue();
                    }
                }
                else
                {
                    fnErrorValue();
                }
            }
            else
            {
                fnErrorValue();
            }
        }
    }

        double oldvalue = 0;
        private void fnErrorValue()
        {
            MessageBox.Show("Enter a Valid Value", "Error", 0, MessageBoxIcon.Error);
            if (dgvPOItemList.CurrentCell.OwningColumn.Name == "RecieveQuantity")
            {
                dgvPOItemList.CurrentCell.Value = oldvalue;
            }
            else
            {
                dgvPOItemList.CurrentCell.Value = 0;
            }
        }

        CultureInfo india = new CultureInfo("hi-IN");
        double totalcost = 0;
        double dCustomsDutyAmt = 0;
        double dCessAmt = 0;
        double dCDIGSTAmt = 0;

        double dTotalAmount = 0;
        double dTotalDiscount = 0;
        double dTotalSgst = 0;
        double dTotalCgst = 0;
        double dTotalIgst = 0;

        private void fnTotalPOCost()
        {
            totalcost = 0;
            dTotalAmount = 0;
            dTotalDiscount = 0;
            dTotalSgst = 0;
            dTotalCgst = 0;
            dTotalIgst = 0;
            dCustomsDutyAmt = 0;
            dCessAmt = 0;
            dCDIGSTAmt = 0;
            double dFreight = 0;
            foreach (DataGridViewRow dgvr in dgvPOItemList.Rows)
            {
                // totalcost += Convert.ToDouble(dgvr.Cells["Amount"].Value) - Convert.ToDouble(dgvr.Cells["DiscAmount"].Value) + Convert.ToDouble(dgvr.Cells["IGSTAmount"].Value) + Convert.ToDouble(dgvr.Cells["SGSTAmount"].Value) + Convert.ToDouble(dgvr.Cells["CGSTAmount"].Value);
                totalcost += Convert.ToDouble(dgvr.Cells["Amount"].Value) + Convert.ToDouble(dgvr.Cells["IGSTAmount"].Value) + Convert.ToDouble(dgvr.Cells["SGSTAmount"].Value) + Convert.ToDouble(dgvr.Cells["CGSTAmount"].Value);

                dTotalAmount += Convert.ToDouble(dgvr.Cells["Amount"].Value);
                dTotalDiscount += Convert.ToDouble(dgvr.Cells["DiscAmount"].Value);
                dTotalSgst += Convert.ToDouble(dgvr.Cells["SGSTAmount"].Value);
                dTotalCgst += Convert.ToDouble(dgvr.Cells["CGSTAmount"].Value);
                dTotalIgst += Convert.ToDouble(dgvr.Cells["IGSTAmount"].Value);
                dCustomsDutyAmt += Convert.ToDouble(dgvr.Cells["CustomsDutyAmt"]?.Value);
                dCessAmt += Convert.ToDouble(dgvr.Cells["CessAmt"].Value);
                dCDIGSTAmt += Convert.ToDouble(dgvr.Cells["CDIGSTAmt"].Value);
                dFreight += Convert.ToDouble(dgvr.Cells["Freight"].Value);
            }

            //foreach (DataGridViewRow dgvr in dgPackingTaxes.Rows)
            //{
            //    totalcost += Convert.ToDouble(dgvr.Cells["taxamount"].Value) + Convert.ToDouble(dgvr.Cells["taxIGSTAmount"].Value) + Convert.ToDouble(dgvr.Cells["taxSGSTAmount"].Value) + Convert.ToDouble(dgvr.Cells["taxCGSTAmount"].Value);
            //}

            // totalcost = Math.Round(totalcost, 2);
            txtFinalNetAmount.Text = Math.Round((dCustomsDutyAmt + dFreight + dCessAmt - dCDIGSTAmt + totalcost + Convert.ToDouble(txtTCSAmount.Text)), 2).ToString();
            lblTotalAmount.Text = dTotalAmount.ToString("0.00");
            lbltotaldiscount.Text = dTotalDiscount.ToString();
            lbltotalSGST.Text = dTotalSgst.ToString();
            lbltotalCGST.Text = dTotalCgst.ToString();
            lbltotalIGST.Text = dTotalIgst.ToString();
        }

        private void chkGINPO_CheckedChanged(object sender, EventArgs e)
        {
            if (chkGINPO.Checked)
            {
                pnGINTax.Visible = true;
            }
            else
            {
                pnGINTax.Visible = false;
            }
        }

        private void btnExit1_Click(object sender, EventArgs e)
        {
            fnExit();
        }
    }
}
