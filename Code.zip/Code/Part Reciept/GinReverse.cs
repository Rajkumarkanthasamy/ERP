﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Part_Reciept
{
    public partial class GinReverse : Form
    {
        public GinReverse()
        {
            InitializeComponent();
        }

        DataAccessLayer DAL = new DataAccessLayer();
        Global GLobalClass = new Global();
        frmForm2 frm = new frmForm2();
        Login.frmLoginForm login = new Login.frmLoginForm();
        DataTable dtGINNumber = new DataTable();
        private void GinReverse_Load(object sender, EventArgs e)
        {
            dtGINNumber = DAL.fnprintReceipt(null, null).Tables[0];

           // var stringArr = dtGINNumber.AsEnumerable().Select(r => r.Field<string>("GINNumber")).ToArray();

            foreach (DataRow DR in dtGINNumber.Rows)
            {
                if (!cmbprintginnumber.Items.Contains(DR[0].ToString()))
                    cmbprintginnumber.Items.Add(DR[0].ToString());
            }


          //  cmbprintginnumber.DataSource = stringArr;
            cmbprintginnumber.SelectedIndex = -1;

        }

        private void cmbprintginnumber_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnSave.Enabled = true;
            dtGINNumber.Rows.Clear();
            dtGINNumber = DAL.fnReverseGIN(cmbprintginnumber.Text).Tables[0];

            if (dtGINNumber.Rows.Count > 0)
            {
                txtVendorcode.Text = dtGINNumber.Rows[0]["VendorCode"].ToString();
                lblVendor.Text = dtGINNumber.Rows[0]["SupplierName"].ToString();
                txtinvoiceno.Text = dtGINNumber.Rows[0]["SupplierInvoiceNumber"].ToString();
                //lblprojcode.Text = dtGINNumber.Rows[0]["ProjectCode"].ToString();
                //lblprojectdesc.Text = dtGINNumber.Rows[0]["ProjectDescription"].ToString();
                //lblpowoby.Text = dtGINNumber.Rows[0]["PreparedBy"].ToString();
                //lblcustomername.Text = dtGINNumber.Rows[0]["Customer"].ToString();
                lblGINDate.Text = dtGINNumber.Rows[0]["GINDate"].ToString();
                lblInvDate.Text = dtGINNumber.Rows[0]["InvoiceDate"].ToString();


                dgvGINReturnList.AutoGenerateColumns = false;
                dgvGINReturnList.DataSource = dtGINNumber;
                //txtprintvendorcode.Text = dtGINNumber.Rows[0]["SupplierName"].ToString();
                //txtprintprojectcode.Text = dtGINNumber.Rows[0]["ProjectCode"].ToString();
                //txtprintvendorname.Text = dtGINNumber.Rows[0]["VendorCode"].ToString();
                //txtprintprojectname.Text = dtGINNumber.Rows[0]["ProjectDescription"].ToString();
            }
        }

        double oldvalue;
        private void dgvGINReturnList_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgvGINReturnList.CurrentCell.OwningColumn.Name == "ReturnQty")
            {
                oldvalue = Convert.ToDouble(dgvGINReturnList.CurrentCell.Value);
            }
        }

        private void dgvGINReturnList_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing" + ex.Message);
            }
        }
        private void Control_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                e.Handled = true;
            }
        }

        private void dgvGINReturnList_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if ((dgvGINReturnList.CurrentCell.Value) != null)// && 
            {
                if (!string.IsNullOrEmpty(dgvGINReturnList.CurrentCell.Value.ToString()))
                {
                    if (dgvGINReturnList.CurrentCell.Value.ToString() != "." && Convert.ToDouble(dgvGINReturnList.CurrentCell.Value.ToString()) != 0.0)
                    {
                        if ((Convert.ToDouble(dgvGINReturnList.CurrentRow.Cells["RecieveQuantity"].Value) < Convert.ToDouble(dgvGINReturnList.CurrentRow.Cells["ReturnQty"].Value)) || (Convert.ToDouble(dgvGINReturnList.CurrentRow.Cells["AvailableQty"].Value) < Convert.ToDouble(dgvGINReturnList.CurrentRow.Cells["ReturnQty"].Value)))
                        {
                            if (Convert.ToDouble(dgvGINReturnList.CurrentRow.Cells["RecieveQuantity"].Value) < Convert.ToDouble(dgvGINReturnList.CurrentRow.Cells["ReturnQty"].Value))
                            {
                                MessageBox.Show("Return quanity should be lesser or equal to GIN quantity", "Error", 0, MessageBoxIcon.Error);
                            }
                            else if (Convert.ToDouble(dgvGINReturnList.CurrentRow.Cells["AvailableQty"].Value) < Convert.ToDouble(dgvGINReturnList.CurrentRow.Cells["ReturnQty"].Value))
                            {
                                MessageBox.Show("Return quanity should be lesser or equal to stock available quantity", "Error", 0, MessageBoxIcon.Error);
                            }
                            dgvGINReturnList.CurrentCell.Value = oldvalue;
                        }
                        else
                        {
                            dgvGINReturnList.CurrentRow.Cells["Amount"].Value = Convert.ToDouble(dgvGINReturnList.CurrentRow.Cells["RecieveQuantity"].Value.ToString()) * Convert.ToDouble(dgvGINReturnList.CurrentRow.Cells["UnitCost"].Value.ToString());
                            dgvGINReturnList.CurrentRow.Cells["IGSTAmount"].Value = (Convert.ToDouble(dgvGINReturnList.CurrentRow.Cells["Amount"].Value.ToString()) / 100) * Convert.ToDouble(dgvGINReturnList.CurrentRow.Cells["IGSTRate"].Value.ToString());
                            dgvGINReturnList.CurrentRow.Cells["SGSTAmount"].Value = (Convert.ToDouble(dgvGINReturnList.CurrentRow.Cells["Amount"].Value.ToString()) / 100) * Convert.ToDouble(dgvGINReturnList.CurrentRow.Cells["SGSTRate"].Value.ToString());
                            dgvGINReturnList.CurrentRow.Cells["CGSTAmount"].Value = (Convert.ToDouble(dgvGINReturnList.CurrentRow.Cells["Amount"].Value.ToString()) / 100) * Convert.ToDouble(dgvGINReturnList.CurrentRow.Cells["CGSTRate"].Value.ToString());

                        }
                    }
                    else
                    {
                        fnErrorValue();
                    }
                }
                else
                {
                    fnErrorValue();
                }
            }
            else
            {
                fnErrorValue();
            }
        }

        private void fnErrorValue()
        {
            MessageBox.Show("Enter a Valid Value", "Error", 0, MessageBoxIcon.Error);
            if (dgvGINReturnList.CurrentCell.OwningColumn.Name == "ReturnQty")
            {
                dgvGINReturnList.CurrentCell.Value = oldvalue;
            }
        }

        private void dgvGINReturnList_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (dgvGINReturnList.Rows.Count > 0)
                {
                    dgvGINReturnList.Rows.RemoveAt(dgvGINReturnList.Rows.IndexOf(dgvGINReturnList.CurrentRow));
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

        }

        private void GinReverse_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            frm.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm.Show();
        }
        bool bItemNotSelected;
        DataTable dtItemDetails = new DataTable();


        private void btnSave_Click_1(object sender, EventArgs e)
        {
            bItemNotSelected = false;
            if (dgvGINReturnList.Rows.Count > 0)
            {
                foreach (DataGridViewRow row in dgvGINReturnList.Rows)
                {
                    if (Convert.ToDouble(row.Cells["RecieveQuantity"].Value) < Convert.ToDouble(row.Cells["ReturnQty"].Value) || (Convert.ToDouble(row.Cells["AvailableQty"].Value) < (Convert.ToDouble(row.Cells["ReturnQty"].Value))))
                    {
                        bItemNotSelected = true;
                        if (Convert.ToDouble(row.Cells["RecieveQuantity"].Value) < Convert.ToDouble(row.Cells["ReturnQty"].Value))
                        {
                            MessageBox.Show("Selected item '" + row.Cells["ItemDescription"].Value + "' return quantity should be lesser or equal to GIN quantity", "Error", 0, MessageBoxIcon.Error);
                        }
                        else if (Convert.ToDouble(row.Cells["AvailableQty"].Value) < Convert.ToDouble(row.Cells["ReturnQty"].Value))
                        {
                            MessageBox.Show("Selected item '" + row.Cells["ItemDescription"].Value + "' return quantity should be lesser or equal to stock available quantity", "Error", 0, MessageBoxIcon.Error);
                        }
                        break;
                    }
                }
                if (!bItemNotSelected)
                {
                    foreach (DataGridViewRow row in dgvGINReturnList.Rows)
                    {
                        GLobalClass.iSuccess = DAL.fnAddRiverseGIN(Global.uINSERT, row.Cells["ItemCode"].Value.ToString(), cmbprintginnumber.Text, Convert.ToDouble(row.Cells["RecieveQuantity"].Value),
                            Convert.ToDouble(row.Cells["UnitCost"].Value), Convert.ToDouble(row.Cells["ReturnQty"].Value), txtinvoiceno.Text, lblVendor.Text, txtVendorcode.Text, lblGINDate.Text, lblInvDate.Text,
                            dtpRivrseGINDate.Text, Convert.ToDouble(row.Cells["IGSTRate"].Value), Convert.ToDouble(row.Cells["IGSTAmount"].Value), Convert.ToDouble(row.Cells["SGSTRate"].Value), Convert.ToDouble(row.Cells["SGSTAmount"].Value),
                              Convert.ToDouble(row.Cells["CGSTRate"].Value), Convert.ToDouble(row.Cells["CGSTAmount"].Value));

                        dtItemDetails = DAL.fnItemDetails(row.Cells["ItemCode"].Value.ToString()).Tables[0];
                        if (dtItemDetails.Rows.Count > 0)
                        {
                            double dAvailableQty = 0;
                            double dStockValue;

                            dAvailableQty = Convert.ToDouble(dtItemDetails.Rows[0]["AvailableQty"].ToString()) - (Convert.ToDouble(row.Cells["ReturnQty"].Value));

                            dStockValue = Convert.ToDouble(dtItemDetails.Rows[0]["UnitCost"]) * dAvailableQty;
                            GLobalClass.iSuccess = DAL.fnUpdateItemDetails(Global.uUPDATE, dtItemDetails.Rows[0]["CreatedDate"].ToString(), dAvailableQty, Convert.ToDouble(dtItemDetails.Rows[0]["Receipt"].ToString()), dStockValue, row.Cells["ItemCode"].Value.ToString(), Convert.ToDouble(dtItemDetails.Rows[0]["UnitCost"]));
                           
                        }
                    }
                    if (GLobalClass.iSuccess > 0)
                    {
                        GLobalClass.iSuccess = DAL.fnAddERPLog(0, cmbprintginnumber.Text, login.GetUserDetails[2], dtpRivrseGINDate.Text, "Item Reverse GIN", "Receipt");

                        MessageBox.Show("Item(s) of GIN number '" + cmbprintginnumber.Text + "' reversed successfully ", "Success", 0, MessageBoxIcon.Information);
                        btnSave.Enabled = false;
                        cmbprintginnumber.Items.Remove(cmbprintginnumber.SelectedItem);
                    }
                }
            }
        }
    }
}
