﻿namespace Erp_Project_With_Buttons.Part_Reciept
{
    partial class frmGINotheritems
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGINotheritems));
            this.pnvendor = new System.Windows.Forms.Panel();
            this.lblCountry = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPONo = new System.Windows.Forms.TextBox();
            this.chklbItemList = new System.Windows.Forms.CheckedListBox();
            this.txtItemDescription = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbLedger = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblinvoicedate = new System.Windows.Forms.Label();
            this.lblGinnumber = new System.Windows.Forms.Label();
            this.dtpInvoiceDate = new System.Windows.Forms.DateTimePicker();
            this.lblSupplierinvoicenumber = new System.Windows.Forms.Label();
            this.txtGinno = new System.Windows.Forms.TextBox();
            this.txtinvoiceno = new System.Windows.Forms.TextBox();
            this.lbldate = new System.Windows.Forms.Label();
            this.dtpGINDate = new System.Windows.Forms.DateTimePicker();
            this.txtvendorcode = new System.Windows.Forms.Label();
            this.cmbVendorName = new System.Windows.Forms.ComboBox();
            this.lblVendorName = new System.Windows.Forms.Label();
            this.btnAddTransport = new System.Windows.Forms.Button();
            this.btnPackingAmount = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbltotalIGST = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.lbltotalCGST = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.lbltotalSGST = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.lbltotaldiscount = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lblTotalAmount = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.lblFinalNetAmount = new System.Windows.Forms.Label();
            this.txtFinalNetAmount = new System.Windows.Forms.TextBox();
            this.dgPackingTaxes = new System.Windows.Forms.DataGridView();
            this.TaxDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxamount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxIGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxIGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxSGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxSGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxCGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxCGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgvPOItemList = new System.Windows.Forms.DataGridView();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.IGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiscAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiscRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HsnSacCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnvendor.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgPackingTaxes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPOItemList)).BeginInit();
            this.SuspendLayout();
            // 
            // pnvendor
            // 
            this.pnvendor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnvendor.Controls.Add(this.lblCountry);
            this.pnvendor.Controls.Add(this.label3);
            this.pnvendor.Controls.Add(this.txtPONo);
            this.pnvendor.Controls.Add(this.chklbItemList);
            this.pnvendor.Controls.Add(this.txtItemDescription);
            this.pnvendor.Controls.Add(this.label2);
            this.pnvendor.Controls.Add(this.cmbLedger);
            this.pnvendor.Controls.Add(this.label1);
            this.pnvendor.Controls.Add(this.lblinvoicedate);
            this.pnvendor.Controls.Add(this.lblGinnumber);
            this.pnvendor.Controls.Add(this.dtpInvoiceDate);
            this.pnvendor.Controls.Add(this.lblSupplierinvoicenumber);
            this.pnvendor.Controls.Add(this.txtGinno);
            this.pnvendor.Controls.Add(this.txtinvoiceno);
            this.pnvendor.Controls.Add(this.lbldate);
            this.pnvendor.Controls.Add(this.dtpGINDate);
            this.pnvendor.Controls.Add(this.txtvendorcode);
            this.pnvendor.Controls.Add(this.cmbVendorName);
            this.pnvendor.Controls.Add(this.lblVendorName);
            this.pnvendor.Location = new System.Drawing.Point(12, 12);
            this.pnvendor.Name = "pnvendor";
            this.pnvendor.Size = new System.Drawing.Size(1268, 195);
            this.pnvendor.TabIndex = 119;
            // 
            // lblCountry
            // 
            this.lblCountry.AutoSize = true;
            this.lblCountry.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCountry.ForeColor = System.Drawing.Color.Black;
            this.lblCountry.Location = new System.Drawing.Point(1058, 131);
            this.lblCountry.Name = "lblCountry";
            this.lblCountry.Size = new System.Drawing.Size(15, 18);
            this.lblCountry.TabIndex = 216;
            this.lblCountry.Text = "*";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(590, 132);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 18);
            this.label3.TabIndex = 214;
            this.label3.Text = "PO No :";
            // 
            // txtPONo
            // 
            this.txtPONo.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPONo.Location = new System.Drawing.Point(647, 131);
            this.txtPONo.Name = "txtPONo";
            this.txtPONo.Size = new System.Drawing.Size(186, 23);
            this.txtPONo.TabIndex = 215;
            // 
            // chklbItemList
            // 
            this.chklbItemList.CheckOnClick = true;
            this.chklbItemList.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chklbItemList.FormattingEnabled = true;
            this.chklbItemList.HorizontalScrollbar = true;
            this.chklbItemList.Location = new System.Drawing.Point(8, 37);
            this.chklbItemList.Name = "chklbItemList";
            this.chklbItemList.Size = new System.Drawing.Size(554, 151);
            this.chklbItemList.TabIndex = 101;
            this.chklbItemList.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.chklbItemList_ItemCheck);
            this.chklbItemList.SelectedIndexChanged += new System.EventHandler(this.chklbItemList_SelectedIndexChanged);
            // 
            // txtItemDescription
            // 
            this.txtItemDescription.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemDescription.Location = new System.Drawing.Point(111, 9);
            this.txtItemDescription.Multiline = true;
            this.txtItemDescription.Name = "txtItemDescription";
            this.txtItemDescription.Size = new System.Drawing.Size(451, 25);
            this.txtItemDescription.TabIndex = 100;
            this.txtItemDescription.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtItemDescription_KeyPress);
            this.txtItemDescription.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemDescription_KeyUp);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(7, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 19);
            this.label2.TabIndex = 105;
            this.label2.Text = "Search Item :";
            // 
            // cmbLedger
            // 
            this.cmbLedger.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbLedger.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbLedger.DropDownHeight = 120;
            this.cmbLedger.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbLedger.FormattingEnabled = true;
            this.cmbLedger.IntegralHeight = false;
            this.cmbLedger.ItemHeight = 18;
            this.cmbLedger.Location = new System.Drawing.Point(897, 40);
            this.cmbLedger.Name = "cmbLedger";
            this.cmbLedger.Size = new System.Drawing.Size(90, 26);
            this.cmbLedger.TabIndex = 213;
            this.cmbLedger.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(834, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 18);
            this.label1.TabIndex = 212;
            this.label1.Text = "Ledger :";
            this.label1.Visible = false;
            // 
            // lblinvoicedate
            // 
            this.lblinvoicedate.AutoSize = true;
            this.lblinvoicedate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinvoicedate.ForeColor = System.Drawing.Color.Black;
            this.lblinvoicedate.Location = new System.Drawing.Point(1019, 5);
            this.lblinvoicedate.Name = "lblinvoicedate";
            this.lblinvoicedate.Size = new System.Drawing.Size(99, 18);
            this.lblinvoicedate.TabIndex = 210;
            this.lblinvoicedate.Text = "Invoice Date* :";
            // 
            // lblGinnumber
            // 
            this.lblGinnumber.AutoSize = true;
            this.lblGinnumber.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGinnumber.ForeColor = System.Drawing.Color.Black;
            this.lblGinnumber.Location = new System.Drawing.Point(587, 5);
            this.lblGinnumber.Name = "lblGinnumber";
            this.lblGinnumber.Size = new System.Drawing.Size(60, 18);
            this.lblGinnumber.TabIndex = 203;
            this.lblGinnumber.Text = "GIN No :";
            // 
            // dtpInvoiceDate
            // 
            this.dtpInvoiceDate.CustomFormat = "";
            this.dtpInvoiceDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpInvoiceDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpInvoiceDate.Location = new System.Drawing.Point(1119, 2);
            this.dtpInvoiceDate.Name = "dtpInvoiceDate";
            this.dtpInvoiceDate.Size = new System.Drawing.Size(90, 26);
            this.dtpInvoiceDate.TabIndex = 208;
            this.dtpInvoiceDate.ValueChanged += new System.EventHandler(this.dtpInvoiceDate_ValueChanged);
            // 
            // lblSupplierinvoicenumber
            // 
            this.lblSupplierinvoicenumber.AutoSize = true;
            this.lblSupplierinvoicenumber.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSupplierinvoicenumber.ForeColor = System.Drawing.Color.Black;
            this.lblSupplierinvoicenumber.Location = new System.Drawing.Point(562, 42);
            this.lblSupplierinvoicenumber.Name = "lblSupplierinvoicenumber";
            this.lblSupplierinvoicenumber.Size = new System.Drawing.Size(85, 18);
            this.lblSupplierinvoicenumber.TabIndex = 205;
            this.lblSupplierinvoicenumber.Text = "InvoiceNo* :";
            // 
            // txtGinno
            // 
            this.txtGinno.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtGinno.Location = new System.Drawing.Point(647, 3);
            this.txtGinno.Name = "txtGinno";
            this.txtGinno.ReadOnly = true;
            this.txtGinno.Size = new System.Drawing.Size(165, 23);
            this.txtGinno.TabIndex = 206;
            // 
            // txtinvoiceno
            // 
            this.txtinvoiceno.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinvoiceno.Location = new System.Drawing.Point(647, 41);
            this.txtinvoiceno.Name = "txtinvoiceno";
            this.txtinvoiceno.Size = new System.Drawing.Size(165, 23);
            this.txtinvoiceno.TabIndex = 207;
            // 
            // lbldate
            // 
            this.lbldate.AutoSize = true;
            this.lbldate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldate.ForeColor = System.Drawing.Color.Black;
            this.lbldate.Location = new System.Drawing.Point(820, 4);
            this.lbldate.Name = "lbldate";
            this.lbldate.Size = new System.Drawing.Size(71, 18);
            this.lbldate.TabIndex = 204;
            this.lbldate.Text = "GIN Date :";
            // 
            // dtpGINDate
            // 
            this.dtpGINDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpGINDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpGINDate.Location = new System.Drawing.Point(897, 4);
            this.dtpGINDate.Name = "dtpGINDate";
            this.dtpGINDate.Size = new System.Drawing.Size(90, 26);
            this.dtpGINDate.TabIndex = 209;
            // 
            // txtvendorcode
            // 
            this.txtvendorcode.AutoSize = true;
            this.txtvendorcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtvendorcode.ForeColor = System.Drawing.Color.Black;
            this.txtvendorcode.Location = new System.Drawing.Point(1058, 87);
            this.txtvendorcode.Name = "txtvendorcode";
            this.txtvendorcode.Size = new System.Drawing.Size(15, 18);
            this.txtvendorcode.TabIndex = 134;
            this.txtvendorcode.Text = "*";
            // 
            // cmbVendorName
            // 
            this.cmbVendorName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbVendorName.DropDownHeight = 130;
            this.cmbVendorName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbVendorName.FormattingEnabled = true;
            this.cmbVendorName.IntegralHeight = false;
            this.cmbVendorName.Location = new System.Drawing.Point(649, 84);
            this.cmbVendorName.Name = "cmbVendorName";
            this.cmbVendorName.Size = new System.Drawing.Size(389, 26);
            this.cmbVendorName.TabIndex = 17;
            this.cmbVendorName.SelectedIndexChanged += new System.EventHandler(this.cmbVendorName_SelectedIndexChanged);
            // 
            // lblVendorName
            // 
            this.lblVendorName.AutoSize = true;
            this.lblVendorName.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVendorName.ForeColor = System.Drawing.Color.Black;
            this.lblVendorName.Location = new System.Drawing.Point(563, 87);
            this.lblVendorName.Name = "lblVendorName";
            this.lblVendorName.Size = new System.Drawing.Size(84, 15);
            this.lblVendorName.TabIndex = 16;
            this.lblVendorName.Text = "VendorName:";
            // 
            // btnAddTransport
            // 
            this.btnAddTransport.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddTransport.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold);
            this.btnAddTransport.ForeColor = System.Drawing.Color.Black;
            this.btnAddTransport.Location = new System.Drawing.Point(875, 566);
            this.btnAddTransport.Name = "btnAddTransport";
            this.btnAddTransport.Size = new System.Drawing.Size(149, 24);
            this.btnAddTransport.TabIndex = 202;
            this.btnAddTransport.Text = "Add Transportation/Freight";
            this.btnAddTransport.UseVisualStyleBackColor = false;
            this.btnAddTransport.Visible = false;
            this.btnAddTransport.Click += new System.EventHandler(this.btnAddTransport_Click);
            // 
            // btnPackingAmount
            // 
            this.btnPackingAmount.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnPackingAmount.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPackingAmount.ForeColor = System.Drawing.Color.Black;
            this.btnPackingAmount.Location = new System.Drawing.Point(875, 535);
            this.btnPackingAmount.Name = "btnPackingAmount";
            this.btnPackingAmount.Size = new System.Drawing.Size(149, 25);
            this.btnPackingAmount.TabIndex = 201;
            this.btnPackingAmount.Text = "Add Packing Forwarding";
            this.btnPackingAmount.UseVisualStyleBackColor = false;
            this.btnPackingAmount.Visible = false;
            this.btnPackingAmount.Click += new System.EventHandler(this.btnPackingAmount_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lbltotalIGST);
            this.panel1.Controls.Add(this.label25);
            this.panel1.Controls.Add(this.lbltotalCGST);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.lbltotalSGST);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.lbltotaldiscount);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.lblTotalAmount);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Location = new System.Drawing.Point(12, 464);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1268, 36);
            this.panel1.TabIndex = 200;
            // 
            // lbltotalIGST
            // 
            this.lbltotalIGST.AutoSize = true;
            this.lbltotalIGST.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotalIGST.ForeColor = System.Drawing.Color.Black;
            this.lbltotalIGST.Location = new System.Drawing.Point(1144, 2);
            this.lbltotalIGST.Name = "lbltotalIGST";
            this.lbltotalIGST.Size = new System.Drawing.Size(23, 26);
            this.lbltotalIGST.TabIndex = 128;
            this.lbltotalIGST.Text = "0";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(1059, 4);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(91, 23);
            this.label25.TabIndex = 127;
            this.label25.Text = "Total IGST:";
            // 
            // lbltotalCGST
            // 
            this.lbltotalCGST.AutoSize = true;
            this.lbltotalCGST.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotalCGST.ForeColor = System.Drawing.Color.Black;
            this.lbltotalCGST.Location = new System.Drawing.Point(907, 4);
            this.lbltotalCGST.Name = "lbltotalCGST";
            this.lbltotalCGST.Size = new System.Drawing.Size(23, 26);
            this.lbltotalCGST.TabIndex = 126;
            this.lbltotalCGST.Text = "0";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(815, 6);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(96, 23);
            this.label21.TabIndex = 125;
            this.label21.Text = "Total CGST:";
            // 
            // lbltotalSGST
            // 
            this.lbltotalSGST.AutoSize = true;
            this.lbltotalSGST.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotalSGST.ForeColor = System.Drawing.Color.Black;
            this.lbltotalSGST.Location = new System.Drawing.Point(687, 5);
            this.lbltotalSGST.Name = "lbltotalSGST";
            this.lbltotalSGST.Size = new System.Drawing.Size(23, 26);
            this.lbltotalSGST.TabIndex = 124;
            this.lbltotalSGST.Text = "0";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Black;
            this.label23.Location = new System.Drawing.Point(591, 6);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(100, 23);
            this.label23.TabIndex = 123;
            this.label23.Text = "Total SGST :";
            // 
            // lbltotaldiscount
            // 
            this.lbltotaldiscount.AutoSize = true;
            this.lbltotaldiscount.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotaldiscount.ForeColor = System.Drawing.Color.Black;
            this.lbltotaldiscount.Location = new System.Drawing.Point(416, 5);
            this.lbltotaldiscount.Name = "lbltotaldiscount";
            this.lbltotaldiscount.Size = new System.Drawing.Size(23, 26);
            this.lbltotaldiscount.TabIndex = 122;
            this.lbltotaldiscount.Text = "0";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(293, 6);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(127, 23);
            this.label18.TabIndex = 121;
            this.label18.Text = "Total Discount:";
            // 
            // lblTotalAmount
            // 
            this.lblTotalAmount.AutoSize = true;
            this.lblTotalAmount.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalAmount.ForeColor = System.Drawing.Color.Black;
            this.lblTotalAmount.Location = new System.Drawing.Point(129, 2);
            this.lblTotalAmount.Name = "lblTotalAmount";
            this.lblTotalAmount.Size = new System.Drawing.Size(23, 26);
            this.lblTotalAmount.TabIndex = 120;
            this.lblTotalAmount.Text = "0";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(9, 3);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(125, 23);
            this.label19.TabIndex = 119;
            this.label19.Text = "Total Amount :";
            // 
            // lblFinalNetAmount
            // 
            this.lblFinalNetAmount.AutoSize = true;
            this.lblFinalNetAmount.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinalNetAmount.ForeColor = System.Drawing.Color.Black;
            this.lblFinalNetAmount.Location = new System.Drawing.Point(961, 508);
            this.lblFinalNetAmount.Name = "lblFinalNetAmount";
            this.lblFinalNetAmount.Size = new System.Drawing.Size(121, 23);
            this.lblFinalNetAmount.TabIndex = 198;
            this.lblFinalNetAmount.Text = "Final Amount:";
            // 
            // txtFinalNetAmount
            // 
            this.txtFinalNetAmount.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtFinalNetAmount.Enabled = false;
            this.txtFinalNetAmount.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFinalNetAmount.Location = new System.Drawing.Point(1088, 505);
            this.txtFinalNetAmount.Name = "txtFinalNetAmount";
            this.txtFinalNetAmount.ReadOnly = true;
            this.txtFinalNetAmount.Size = new System.Drawing.Size(163, 31);
            this.txtFinalNetAmount.TabIndex = 199;
            this.txtFinalNetAmount.Text = "0.0";
            // 
            // dgPackingTaxes
            // 
            this.dgPackingTaxes.AllowUserToAddRows = false;
            this.dgPackingTaxes.AllowUserToDeleteRows = false;
            this.dgPackingTaxes.AllowUserToResizeRows = false;
            this.dgPackingTaxes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgPackingTaxes.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgPackingTaxes.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgPackingTaxes.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgPackingTaxes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgPackingTaxes.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TaxDesc,
            this.taxamount,
            this.taxIGSTRate,
            this.taxIGSTAmount,
            this.taxSGSTRate,
            this.taxSGSTAmount,
            this.taxCGSTRate,
            this.taxCGSTAmount});
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgPackingTaxes.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgPackingTaxes.EnableHeadersVisualStyles = false;
            this.dgPackingTaxes.Location = new System.Drawing.Point(10, 515);
            this.dgPackingTaxes.MultiSelect = false;
            this.dgPackingTaxes.Name = "dgPackingTaxes";
            this.dgPackingTaxes.RowHeadersVisible = false;
            this.dgPackingTaxes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgPackingTaxes.Size = new System.Drawing.Size(859, 78);
            this.dgPackingTaxes.TabIndex = 197;
            this.dgPackingTaxes.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgPackingTaxes_CellBeginEdit);
            this.dgPackingTaxes.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgPackingTaxes_CellEndEdit);
            this.dgPackingTaxes.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgPackingTaxes_EditingControlShowing);
            this.dgPackingTaxes.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgPackingTaxes_KeyUp);
            // 
            // TaxDesc
            // 
            this.TaxDesc.DataPropertyName = "TaxDescription";
            this.TaxDesc.HeaderText = "Tax Name";
            this.TaxDesc.Name = "TaxDesc";
            this.TaxDesc.ReadOnly = true;
            this.TaxDesc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxamount
            // 
            this.taxamount.DataPropertyName = "Amount";
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.LightGreen;
            this.taxamount.DefaultCellStyle = dataGridViewCellStyle2;
            this.taxamount.HeaderText = "Amount";
            this.taxamount.Name = "taxamount";
            this.taxamount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxIGSTRate
            // 
            this.taxIGSTRate.DataPropertyName = "IGSTRate";
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.LightGreen;
            this.taxIGSTRate.DefaultCellStyle = dataGridViewCellStyle3;
            this.taxIGSTRate.HeaderText = "IGST %";
            this.taxIGSTRate.Name = "taxIGSTRate";
            this.taxIGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxIGSTAmount
            // 
            this.taxIGSTAmount.DataPropertyName = "IGSTAmount";
            this.taxIGSTAmount.HeaderText = "IGST Amount";
            this.taxIGSTAmount.Name = "taxIGSTAmount";
            this.taxIGSTAmount.ReadOnly = true;
            this.taxIGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxSGSTRate
            // 
            this.taxSGSTRate.DataPropertyName = "SGSTRate";
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.LightGreen;
            this.taxSGSTRate.DefaultCellStyle = dataGridViewCellStyle4;
            this.taxSGSTRate.HeaderText = "SGST %";
            this.taxSGSTRate.Name = "taxSGSTRate";
            this.taxSGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxSGSTAmount
            // 
            this.taxSGSTAmount.DataPropertyName = "SGSTAmount";
            this.taxSGSTAmount.HeaderText = "SGST Amount";
            this.taxSGSTAmount.Name = "taxSGSTAmount";
            this.taxSGSTAmount.ReadOnly = true;
            this.taxSGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxCGSTRate
            // 
            this.taxCGSTRate.DataPropertyName = "CGSTRate";
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.LightGreen;
            this.taxCGSTRate.DefaultCellStyle = dataGridViewCellStyle5;
            this.taxCGSTRate.HeaderText = "CGST %";
            this.taxCGSTRate.Name = "taxCGSTRate";
            this.taxCGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxCGSTAmount
            // 
            this.taxCGSTAmount.DataPropertyName = "CGSTAmount";
            this.taxCGSTAmount.HeaderText = "CGST Amount";
            this.taxCGSTAmount.Name = "taxCGSTAmount";
            this.taxCGSTAmount.ReadOnly = true;
            this.taxCGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dgvPOItemList
            // 
            this.dgvPOItemList.AllowUserToAddRows = false;
            this.dgvPOItemList.AllowUserToDeleteRows = false;
            this.dgvPOItemList.AllowUserToResizeRows = false;
            this.dgvPOItemList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.Desktop;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPOItemList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgvPOItemList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPOItemList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ItemCode,
            this.ItemDescription,
            this.HsnSacCode,
            this.ProjectCode,
            this.ProductNo,
            this.Quantity,
            this.UnitPrice,
            this.DiscRate,
            this.DiscAmount,
            this.Amount,
            this.SGSTRate,
            this.SGSTAmount,
            this.CGSTRate,
            this.CGSTAmount,
            this.IGSTRate,
            this.IGSTAmount});
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle21.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle21.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPOItemList.DefaultCellStyle = dataGridViewCellStyle21;
            this.dgvPOItemList.EnableHeadersVisualStyles = false;
            this.dgvPOItemList.Location = new System.Drawing.Point(12, 213);
            this.dgvPOItemList.MultiSelect = false;
            this.dgvPOItemList.Name = "dgvPOItemList";
            this.dgvPOItemList.RowHeadersVisible = false;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvPOItemList.RowsDefaultCellStyle = dataGridViewCellStyle22;
            this.dgvPOItemList.Size = new System.Drawing.Size(1268, 244);
            this.dgvPOItemList.TabIndex = 196;
            this.dgvPOItemList.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgvPOItemList_CellBeginEdit);
            this.dgvPOItemList.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPOItemList_CellEndEdit);
            this.dgvPOItemList.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvPOItemList_EditingControlShowing);
            this.dgvPOItemList.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvPOItemList_KeyUp);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(1161, 554);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(90, 39);
            this.btnExit.TabIndex = 15;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(1042, 554);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(90, 39);
            this.btnSave.TabIndex = 14;
            this.btnSave.Text = "Recieve";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // IGSTAmount
            // 
            this.IGSTAmount.DataPropertyName = "IGSTAmount";
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle20.Format = "N2";
            dataGridViewCellStyle20.NullValue = null;
            this.IGSTAmount.DefaultCellStyle = dataGridViewCellStyle20;
            this.IGSTAmount.HeaderText = "IGST Amt";
            this.IGSTAmount.Name = "IGSTAmount";
            this.IGSTAmount.ReadOnly = true;
            this.IGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // IGSTRate
            // 
            this.IGSTRate.DataPropertyName = "IGSTRate";
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.IGSTRate.DefaultCellStyle = dataGridViewCellStyle19;
            this.IGSTRate.HeaderText = "IGST %";
            this.IGSTRate.Name = "IGSTRate";
            this.IGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // CGSTAmount
            // 
            this.CGSTAmount.DataPropertyName = "CGSTAmount";
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle18.Format = "N2";
            this.CGSTAmount.DefaultCellStyle = dataGridViewCellStyle18;
            this.CGSTAmount.HeaderText = "CGST Amt";
            this.CGSTAmount.Name = "CGSTAmount";
            this.CGSTAmount.ReadOnly = true;
            this.CGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // CGSTRate
            // 
            this.CGSTRate.DataPropertyName = "CGSTRate";
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.CGSTRate.DefaultCellStyle = dataGridViewCellStyle17;
            this.CGSTRate.HeaderText = "CGST %";
            this.CGSTRate.Name = "CGSTRate";
            this.CGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // SGSTAmount
            // 
            this.SGSTAmount.DataPropertyName = "SGSTAmount";
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle16.Format = "N2";
            this.SGSTAmount.DefaultCellStyle = dataGridViewCellStyle16;
            this.SGSTAmount.HeaderText = "SGST Amt";
            this.SGSTAmount.Name = "SGSTAmount";
            this.SGSTAmount.ReadOnly = true;
            this.SGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // SGSTRate
            // 
            this.SGSTRate.DataPropertyName = "SGSTRate";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.SGSTRate.DefaultCellStyle = dataGridViewCellStyle15;
            this.SGSTRate.HeaderText = "SGST %";
            this.SGSTRate.Name = "SGSTRate";
            this.SGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Amount
            // 
            this.Amount.DataPropertyName = "Amount";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Amount.DefaultCellStyle = dataGridViewCellStyle14;
            this.Amount.HeaderText = "Amount";
            this.Amount.Name = "Amount";
            this.Amount.ReadOnly = true;
            this.Amount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // DiscAmount
            // 
            this.DiscAmount.DataPropertyName = "DiscAmount";
            this.DiscAmount.HeaderText = "Disc Amt";
            this.DiscAmount.Name = "DiscAmount";
            this.DiscAmount.ReadOnly = true;
            this.DiscAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // DiscRate
            // 
            this.DiscRate.DataPropertyName = "DiscRate";
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.DiscRate.DefaultCellStyle = dataGridViewCellStyle13;
            this.DiscRate.HeaderText = "Disc %";
            this.DiscRate.Name = "DiscRate";
            this.DiscRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // UnitPrice
            // 
            this.UnitPrice.DataPropertyName = "UnitCost";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.UnitPrice.DefaultCellStyle = dataGridViewCellStyle12;
            this.UnitPrice.HeaderText = "Unit Cost";
            this.UnitPrice.Name = "UnitPrice";
            this.UnitPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "Quantity";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Quantity.DefaultCellStyle = dataGridViewCellStyle11;
            this.Quantity.HeaderText = "Received Qty";
            this.Quantity.Name = "Quantity";
            this.Quantity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ProductNo
            // 
            this.ProductNo.DataPropertyName = "ProductNo";
            this.ProductNo.HeaderText = "ProductNo";
            this.ProductNo.Name = "ProductNo";
            // 
            // ProjectCode
            // 
            this.ProjectCode.DataPropertyName = "BOMProjectCode";
            this.ProjectCode.HeaderText = "BOMProjectCodes";
            this.ProjectCode.Name = "ProjectCode";
            // 
            // HsnSacCode
            // 
            this.HsnSacCode.DataPropertyName = "HSNCode";
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.HsnSacCode.DefaultCellStyle = dataGridViewCellStyle10;
            this.HsnSacCode.HeaderText = "Hsn / Sac";
            this.HsnSacCode.Name = "HsnSacCode";
            this.HsnSacCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ItemDescription
            // 
            this.ItemDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ItemDescription.DataPropertyName = "ItemDescription";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.White;
            this.ItemDescription.DefaultCellStyle = dataGridViewCellStyle9;
            this.ItemDescription.HeaderText = "Item Description";
            this.ItemDescription.Name = "ItemDescription";
            this.ItemDescription.ReadOnly = true;
            this.ItemDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemDescription.Width = 132;
            // 
            // ItemCode
            // 
            this.ItemCode.DataPropertyName = "ItemCode";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.White;
            this.ItemCode.DefaultCellStyle = dataGridViewCellStyle8;
            this.ItemCode.HeaderText = "Item Code";
            this.ItemCode.Name = "ItemCode";
            this.ItemCode.ReadOnly = true;
            this.ItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // frmGINotheritems
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1282, 605);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnAddTransport);
            this.Controls.Add(this.btnPackingAmount);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblFinalNetAmount);
            this.Controls.Add(this.txtFinalNetAmount);
            this.Controls.Add(this.dgPackingTaxes);
            this.Controls.Add(this.dgvPOItemList);
            this.Controls.Add(this.pnvendor);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmGINotheritems";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SIN Receipt";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmGINotheritems_FormClosing);
            this.Load += new System.EventHandler(this.frmGINotheritems_Load);
            this.pnvendor.ResumeLayout(false);
            this.pnvendor.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgPackingTaxes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPOItemList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnvendor;
        private System.Windows.Forms.Label txtvendorcode;
        private System.Windows.Forms.ComboBox cmbVendorName;
        private System.Windows.Forms.Label lblVendorName;
        private System.Windows.Forms.Button btnAddTransport;
        private System.Windows.Forms.Button btnPackingAmount;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbltotalIGST;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label lbltotalCGST;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lbltotalSGST;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label lbltotaldiscount;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lblTotalAmount;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label lblFinalNetAmount;
        private System.Windows.Forms.TextBox txtFinalNetAmount;
        private System.Windows.Forms.DataGridView dgPackingTaxes;
        private System.Windows.Forms.DataGridViewTextBoxColumn TaxDesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxamount;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxIGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxIGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxSGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxSGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxCGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxCGSTAmount;
        private System.Windows.Forms.DataGridView dgvPOItemList;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblinvoicedate;
        private System.Windows.Forms.Label lblGinnumber;
        private System.Windows.Forms.DateTimePicker dtpInvoiceDate;
        private System.Windows.Forms.Label lblSupplierinvoicenumber;
        private System.Windows.Forms.TextBox txtGinno;
        private System.Windows.Forms.TextBox txtinvoiceno;
        private System.Windows.Forms.Label lbldate;
        private System.Windows.Forms.DateTimePicker dtpGINDate;
        private System.Windows.Forms.ComboBox cmbLedger;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckedListBox chklbItemList;
        private System.Windows.Forms.TextBox txtItemDescription;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPONo;
        private System.Windows.Forms.Label lblCountry;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn HsnSacCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiscRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiscAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn SGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn SGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn CGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn CGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn IGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn IGSTAmount;
    }
}
