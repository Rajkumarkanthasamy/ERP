﻿namespace Erp_Project_With_Buttons.Part_Reciept
{
    partial class GINPOView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GINPOView));
            this.gbSearchOptions = new System.Windows.Forms.GroupBox();
            this.chkGINPO = new System.Windows.Forms.CheckBox();
            this.cmbGinnumber = new System.Windows.Forms.ComboBox();
            this.lblGinno = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbLedger = new System.Windows.Forms.ComboBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnAddledger = new System.Windows.Forms.Button();
            this.panelledger = new System.Windows.Forms.Panel();
            this.btnledgercancel = new System.Windows.Forms.Button();
            this.LedgerTextbox = new System.Windows.Forms.TextBox();
            this.btnledgersave = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnInvoiceUpdate = new System.Windows.Forms.Button();
            this.pnUpdateInvoicedate = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.txtOldInvioceNumber = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dtpOldInvoiceDate = new System.Windows.Forms.DateTimePicker();
            this.lblSupplierinvoicenumber = new System.Windows.Forms.Label();
            this.txtinvoiceno = new System.Windows.Forms.TextBox();
            this.lblinvoicedate = new System.Windows.Forms.Label();
            this.dtpInvoiceDate = new System.Windows.Forms.DateTimePicker();
            this.btnInvoicecancel = new System.Windows.Forms.Button();
            this.btnInvoicenodateupdate = new System.Windows.Forms.Button();
            this.pnGINTax = new System.Windows.Forms.Panel();
            this.btnExit1 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.combocurrency = new System.Windows.Forms.TextBox();
            this.textBRate = new System.Windows.Forms.TextBox();
            this.dgPackingTaxes = new System.Windows.Forms.DataGridView();
            this.TaxDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxamount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxIGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxIGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxSGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxSGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxCGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxCGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label7 = new System.Windows.Forms.Label();
            this.txtTCSAmount = new System.Windows.Forms.TextBox();
            this.lblFinalNetAmount = new System.Windows.Forms.Label();
            this.txtFinalNetAmount = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lbltotalIGST = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.lbltotalCGST = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.lbltotalSGST = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.lbltotaldiscount = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lblTotalAmount = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.dgvPOItemList = new System.Windows.Forms.DataGridView();
            this.ItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OrderedQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiscRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiscAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Freight = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomsDuty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomsDutyAmt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CDIGST = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CDIGSTAmt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cess = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CessAmt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbSearchOptions.SuspendLayout();
            this.panelledger.SuspendLayout();
            this.panel1.SuspendLayout();
            this.pnUpdateInvoicedate.SuspendLayout();
            this.pnGINTax.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgPackingTaxes)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPOItemList)).BeginInit();
            this.SuspendLayout();
            // 
            // gbSearchOptions
            // 
            this.gbSearchOptions.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.gbSearchOptions.Controls.Add(this.chkGINPO);
            this.gbSearchOptions.Controls.Add(this.cmbGinnumber);
            this.gbSearchOptions.Controls.Add(this.lblGinno);
            this.gbSearchOptions.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.gbSearchOptions.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbSearchOptions.Location = new System.Drawing.Point(2, 12);
            this.gbSearchOptions.Name = "gbSearchOptions";
            this.gbSearchOptions.Size = new System.Drawing.Size(1296, 91);
            this.gbSearchOptions.TabIndex = 9;
            this.gbSearchOptions.TabStop = false;
            this.gbSearchOptions.Text = "Search Options";
            // 
            // chkGINPO
            // 
            this.chkGINPO.AutoSize = true;
            this.chkGINPO.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkGINPO.ForeColor = System.Drawing.Color.Black;
            this.chkGINPO.Location = new System.Drawing.Point(424, 33);
            this.chkGINPO.Name = "chkGINPO";
            this.chkGINPO.Size = new System.Drawing.Size(184, 23);
            this.chkGINPO.TabIndex = 185;
            this.chkGINPO.Text = "Import GIN Tax Update";
            this.chkGINPO.UseVisualStyleBackColor = true;
            this.chkGINPO.CheckedChanged += new System.EventHandler(this.chkGINPO_CheckedChanged);
            // 
            // cmbGinnumber
            // 
            this.cmbGinnumber.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbGinnumber.DropDownHeight = 130;
            this.cmbGinnumber.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbGinnumber.FormattingEnabled = true;
            this.cmbGinnumber.IntegralHeight = false;
            this.cmbGinnumber.ItemHeight = 15;
            this.cmbGinnumber.Location = new System.Drawing.Point(130, 33);
            this.cmbGinnumber.Name = "cmbGinnumber";
            this.cmbGinnumber.Size = new System.Drawing.Size(213, 23);
            this.cmbGinnumber.TabIndex = 183;
            this.cmbGinnumber.SelectedIndexChanged += new System.EventHandler(this.cmbGinnumber_SelectedIndexChanged);
            // 
            // lblGinno
            // 
            this.lblGinno.AutoSize = true;
            this.lblGinno.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGinno.ForeColor = System.Drawing.Color.Black;
            this.lblGinno.Location = new System.Drawing.Point(35, 33);
            this.lblGinno.Name = "lblGinno";
            this.lblGinno.Size = new System.Drawing.Size(86, 18);
            this.lblGinno.TabIndex = 184;
            this.lblGinno.Text = "GIN Number";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(28, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 18);
            this.label1.TabIndex = 185;
            this.label1.Text = "Old Ledger";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(123, 38);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(406, 27);
            this.textBox1.TabIndex = 186;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(28, 127);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 18);
            this.label2.TabIndex = 187;
            this.label2.Text = "New Ledger";
            // 
            // cmbLedger
            // 
            this.cmbLedger.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbLedger.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbLedger.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLedger.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbLedger.FormattingEnabled = true;
            this.cmbLedger.ItemHeight = 18;
            this.cmbLedger.Location = new System.Drawing.Point(123, 127);
            this.cmbLedger.Name = "cmbLedger";
            this.cmbLedger.Size = new System.Drawing.Size(406, 26);
            this.cmbLedger.TabIndex = 188;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(326, 174);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(90, 39);
            this.btnExit.TabIndex = 190;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnUpdate.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.Location = new System.Drawing.Point(177, 174);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(90, 39);
            this.btnUpdate.TabIndex = 189;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnAddledger
            // 
            this.btnAddledger.BackColor = System.Drawing.Color.PaleGreen;
            this.btnAddledger.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddledger.Location = new System.Drawing.Point(31, 246);
            this.btnAddledger.Name = "btnAddledger";
            this.btnAddledger.Size = new System.Drawing.Size(167, 36);
            this.btnAddledger.TabIndex = 191;
            this.btnAddledger.Text = "Add Ledger";
            this.btnAddledger.UseVisualStyleBackColor = false;
            this.btnAddledger.Click += new System.EventHandler(this.btnAddledger_Click);
            // 
            // panelledger
            // 
            this.panelledger.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelledger.Controls.Add(this.btnledgercancel);
            this.panelledger.Controls.Add(this.LedgerTextbox);
            this.panelledger.Controls.Add(this.btnledgersave);
            this.panelledger.Controls.Add(this.label3);
            this.panelledger.Location = new System.Drawing.Point(31, 22);
            this.panelledger.Name = "panelledger";
            this.panelledger.Size = new System.Drawing.Size(594, 212);
            this.panelledger.TabIndex = 192;
            this.panelledger.Visible = false;
            // 
            // btnledgercancel
            // 
            this.btnledgercancel.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnledgercancel.Location = new System.Drawing.Point(365, 120);
            this.btnledgercancel.Name = "btnledgercancel";
            this.btnledgercancel.Size = new System.Drawing.Size(99, 39);
            this.btnledgercancel.TabIndex = 3;
            this.btnledgercancel.Text = "Cancel";
            this.btnledgercancel.UseVisualStyleBackColor = true;
            this.btnledgercancel.Click += new System.EventHandler(this.btnledgercancel_Click);
            // 
            // LedgerTextbox
            // 
            this.LedgerTextbox.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LedgerTextbox.Location = new System.Drawing.Point(124, 78);
            this.LedgerTextbox.Name = "LedgerTextbox";
            this.LedgerTextbox.Size = new System.Drawing.Size(460, 26);
            this.LedgerTextbox.TabIndex = 2;
            // 
            // btnledgersave
            // 
            this.btnledgersave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnledgersave.Location = new System.Drawing.Point(238, 120);
            this.btnledgersave.Name = "btnledgersave";
            this.btnledgersave.Size = new System.Drawing.Size(98, 39);
            this.btnledgersave.TabIndex = 1;
            this.btnledgersave.Text = "Save";
            this.btnledgersave.UseVisualStyleBackColor = true;
            this.btnledgersave.Click += new System.EventHandler(this.btnledgersave_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(1, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 23);
            this.label3.TabIndex = 0;
            this.label3.Text = "Ledger Name :";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.panelledger);
            this.panel1.Controls.Add(this.btnInvoiceUpdate);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnAddledger);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.btnExit);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.btnUpdate);
            this.panel1.Controls.Add(this.cmbLedger);
            this.panel1.Location = new System.Drawing.Point(26, 122);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(650, 290);
            this.panel1.TabIndex = 193;
            // 
            // btnInvoiceUpdate
            // 
            this.btnInvoiceUpdate.BackColor = System.Drawing.Color.PaleGreen;
            this.btnInvoiceUpdate.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInvoiceUpdate.Location = new System.Drawing.Point(234, 246);
            this.btnInvoiceUpdate.Name = "btnInvoiceUpdate";
            this.btnInvoiceUpdate.Size = new System.Drawing.Size(272, 36);
            this.btnInvoiceUpdate.TabIndex = 193;
            this.btnInvoiceUpdate.Text = "Update Invoice No / Date";
            this.btnInvoiceUpdate.UseVisualStyleBackColor = false;
            this.btnInvoiceUpdate.Click += new System.EventHandler(this.btnInvoiceUpdate_Click);
            // 
            // pnUpdateInvoicedate
            // 
            this.pnUpdateInvoicedate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnUpdateInvoicedate.Controls.Add(this.label4);
            this.pnUpdateInvoicedate.Controls.Add(this.txtOldInvioceNumber);
            this.pnUpdateInvoicedate.Controls.Add(this.label5);
            this.pnUpdateInvoicedate.Controls.Add(this.dtpOldInvoiceDate);
            this.pnUpdateInvoicedate.Controls.Add(this.lblSupplierinvoicenumber);
            this.pnUpdateInvoicedate.Controls.Add(this.txtinvoiceno);
            this.pnUpdateInvoicedate.Controls.Add(this.lblinvoicedate);
            this.pnUpdateInvoicedate.Controls.Add(this.dtpInvoiceDate);
            this.pnUpdateInvoicedate.Controls.Add(this.btnInvoicecancel);
            this.pnUpdateInvoicedate.Controls.Add(this.btnInvoicenodateupdate);
            this.pnUpdateInvoicedate.Location = new System.Drawing.Point(60, 145);
            this.pnUpdateInvoicedate.Name = "pnUpdateInvoicedate";
            this.pnUpdateInvoicedate.Size = new System.Drawing.Size(594, 212);
            this.pnUpdateInvoicedate.TabIndex = 194;
            this.pnUpdateInvoicedate.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(18, 80);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 18);
            this.label4.TabIndex = 186;
            this.label4.Text = "Old InvoiceNo* :";
            // 
            // txtOldInvioceNumber
            // 
            this.txtOldInvioceNumber.Enabled = false;
            this.txtOldInvioceNumber.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOldInvioceNumber.Location = new System.Drawing.Point(130, 78);
            this.txtOldInvioceNumber.Name = "txtOldInvioceNumber";
            this.txtOldInvioceNumber.Size = new System.Drawing.Size(165, 23);
            this.txtOldInvioceNumber.TabIndex = 187;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(5, 34);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(124, 18);
            this.label5.TabIndex = 185;
            this.label5.Text = "Old Invoice Date* :";
            // 
            // dtpOldInvoiceDate
            // 
            this.dtpOldInvoiceDate.CustomFormat = "";
            this.dtpOldInvoiceDate.Enabled = false;
            this.dtpOldInvoiceDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpOldInvoiceDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpOldInvoiceDate.Location = new System.Drawing.Point(130, 31);
            this.dtpOldInvoiceDate.Name = "dtpOldInvoiceDate";
            this.dtpOldInvoiceDate.Size = new System.Drawing.Size(90, 26);
            this.dtpOldInvoiceDate.TabIndex = 184;
            // 
            // lblSupplierinvoicenumber
            // 
            this.lblSupplierinvoicenumber.AutoSize = true;
            this.lblSupplierinvoicenumber.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSupplierinvoicenumber.ForeColor = System.Drawing.Color.Black;
            this.lblSupplierinvoicenumber.Location = new System.Drawing.Point(336, 80);
            this.lblSupplierinvoicenumber.Name = "lblSupplierinvoicenumber";
            this.lblSupplierinvoicenumber.Size = new System.Drawing.Size(85, 18);
            this.lblSupplierinvoicenumber.TabIndex = 182;
            this.lblSupplierinvoicenumber.Text = "InvoiceNo* :";
            // 
            // txtinvoiceno
            // 
            this.txtinvoiceno.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinvoiceno.Location = new System.Drawing.Point(421, 79);
            this.txtinvoiceno.Name = "txtinvoiceno";
            this.txtinvoiceno.Size = new System.Drawing.Size(165, 23);
            this.txtinvoiceno.TabIndex = 183;
            // 
            // lblinvoicedate
            // 
            this.lblinvoicedate.AutoSize = true;
            this.lblinvoicedate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinvoicedate.ForeColor = System.Drawing.Color.Black;
            this.lblinvoicedate.Location = new System.Drawing.Point(323, 34);
            this.lblinvoicedate.Name = "lblinvoicedate";
            this.lblinvoicedate.Size = new System.Drawing.Size(99, 18);
            this.lblinvoicedate.TabIndex = 181;
            this.lblinvoicedate.Text = "Invoice Date* :";
            // 
            // dtpInvoiceDate
            // 
            this.dtpInvoiceDate.CustomFormat = "";
            this.dtpInvoiceDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpInvoiceDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpInvoiceDate.Location = new System.Drawing.Point(423, 31);
            this.dtpInvoiceDate.Name = "dtpInvoiceDate";
            this.dtpInvoiceDate.Size = new System.Drawing.Size(90, 26);
            this.dtpInvoiceDate.TabIndex = 180;
            // 
            // btnInvoicecancel
            // 
            this.btnInvoicecancel.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInvoicecancel.Location = new System.Drawing.Point(468, 150);
            this.btnInvoicecancel.Name = "btnInvoicecancel";
            this.btnInvoicecancel.Size = new System.Drawing.Size(99, 39);
            this.btnInvoicecancel.TabIndex = 3;
            this.btnInvoicecancel.Text = "Cancel";
            this.btnInvoicecancel.UseVisualStyleBackColor = true;
            this.btnInvoicecancel.Click += new System.EventHandler(this.btnInvoicecancel_Click);
            // 
            // btnInvoicenodateupdate
            // 
            this.btnInvoicenodateupdate.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInvoicenodateupdate.Location = new System.Drawing.Point(341, 150);
            this.btnInvoicenodateupdate.Name = "btnInvoicenodateupdate";
            this.btnInvoicenodateupdate.Size = new System.Drawing.Size(98, 39);
            this.btnInvoicenodateupdate.TabIndex = 1;
            this.btnInvoicenodateupdate.Text = "Update";
            this.btnInvoicenodateupdate.UseVisualStyleBackColor = true;
            this.btnInvoicenodateupdate.Click += new System.EventHandler(this.btnInvoicenodateupdate_Click);
            // 
            // pnGINTax
            // 
            this.pnGINTax.Controls.Add(this.btnExit1);
            this.pnGINTax.Controls.Add(this.panel2);
            this.pnGINTax.Controls.Add(this.dgPackingTaxes);
            this.pnGINTax.Controls.Add(this.label7);
            this.pnGINTax.Controls.Add(this.txtTCSAmount);
            this.pnGINTax.Controls.Add(this.lblFinalNetAmount);
            this.pnGINTax.Controls.Add(this.txtFinalNetAmount);
            this.pnGINTax.Controls.Add(this.panel3);
            this.pnGINTax.Controls.Add(this.dgvPOItemList);
            this.pnGINTax.Location = new System.Drawing.Point(9, 109);
            this.pnGINTax.Name = "pnGINTax";
            this.pnGINTax.Size = new System.Drawing.Size(1289, 561);
            this.pnGINTax.TabIndex = 195;
            // 
            // btnExit1
            // 
            this.btnExit1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit1.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit1.Location = new System.Drawing.Point(1133, 515);
            this.btnExit1.Name = "btnExit1";
            this.btnExit1.Size = new System.Drawing.Size(90, 39);
            this.btnExit1.TabIndex = 207;
            this.btnExit1.Text = "Exit";
            this.btnExit1.UseVisualStyleBackColor = false;
            this.btnExit1.Click += new System.EventHandler(this.btnExit1_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.combocurrency);
            this.panel2.Controls.Add(this.textBRate);
            this.panel2.Location = new System.Drawing.Point(50, 507);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(256, 38);
            this.panel2.TabIndex = 206;
            this.panel2.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(3, 10);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 18);
            this.label6.TabIndex = 188;
            this.label6.Text = "Currency :";
            // 
            // combocurrency
            // 
            this.combocurrency.Enabled = false;
            this.combocurrency.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combocurrency.Location = new System.Drawing.Point(79, 9);
            this.combocurrency.Name = "combocurrency";
            this.combocurrency.Size = new System.Drawing.Size(100, 23);
            this.combocurrency.TabIndex = 190;
            // 
            // textBRate
            // 
            this.textBRate.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBRate.Location = new System.Drawing.Point(188, 9);
            this.textBRate.Name = "textBRate";
            this.textBRate.Size = new System.Drawing.Size(62, 23);
            this.textBRate.TabIndex = 189;
            // 
            // dgPackingTaxes
            // 
            this.dgPackingTaxes.AllowUserToAddRows = false;
            this.dgPackingTaxes.AllowUserToDeleteRows = false;
            this.dgPackingTaxes.AllowUserToResizeRows = false;
            this.dgPackingTaxes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgPackingTaxes.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgPackingTaxes.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgPackingTaxes.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgPackingTaxes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgPackingTaxes.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TaxDesc,
            this.taxamount,
            this.taxIGSTRate,
            this.taxIGSTAmount,
            this.taxSGSTRate,
            this.taxSGSTAmount,
            this.taxCGSTRate,
            this.taxCGSTAmount});
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgPackingTaxes.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgPackingTaxes.EnableHeadersVisualStyles = false;
            this.dgPackingTaxes.Location = new System.Drawing.Point(17, 417);
            this.dgPackingTaxes.MultiSelect = false;
            this.dgPackingTaxes.Name = "dgPackingTaxes";
            this.dgPackingTaxes.RowHeadersVisible = false;
            this.dgPackingTaxes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgPackingTaxes.Size = new System.Drawing.Size(1266, 84);
            this.dgPackingTaxes.TabIndex = 205;
            this.dgPackingTaxes.Visible = false;
            // 
            // TaxDesc
            // 
            this.TaxDesc.DataPropertyName = "TaxDescription";
            this.TaxDesc.HeaderText = "Tax Name";
            this.TaxDesc.Name = "TaxDesc";
            this.TaxDesc.ReadOnly = true;
            this.TaxDesc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxamount
            // 
            this.taxamount.DataPropertyName = "Amount";
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.LightGreen;
            this.taxamount.DefaultCellStyle = dataGridViewCellStyle2;
            this.taxamount.HeaderText = "Amount";
            this.taxamount.Name = "taxamount";
            this.taxamount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxIGSTRate
            // 
            this.taxIGSTRate.DataPropertyName = "IGSTRate";
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.LightGreen;
            this.taxIGSTRate.DefaultCellStyle = dataGridViewCellStyle3;
            this.taxIGSTRate.HeaderText = "IGST %";
            this.taxIGSTRate.Name = "taxIGSTRate";
            this.taxIGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxIGSTAmount
            // 
            this.taxIGSTAmount.DataPropertyName = "IGSTAmount";
            this.taxIGSTAmount.HeaderText = "IGST Amount";
            this.taxIGSTAmount.Name = "taxIGSTAmount";
            this.taxIGSTAmount.ReadOnly = true;
            this.taxIGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxSGSTRate
            // 
            this.taxSGSTRate.DataPropertyName = "SGSTRate";
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.LightGreen;
            this.taxSGSTRate.DefaultCellStyle = dataGridViewCellStyle4;
            this.taxSGSTRate.HeaderText = "SGST %";
            this.taxSGSTRate.Name = "taxSGSTRate";
            this.taxSGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxSGSTAmount
            // 
            this.taxSGSTAmount.DataPropertyName = "SGSTAmount";
            this.taxSGSTAmount.HeaderText = "SGST Amount";
            this.taxSGSTAmount.Name = "taxSGSTAmount";
            this.taxSGSTAmount.ReadOnly = true;
            this.taxSGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxCGSTRate
            // 
            this.taxCGSTRate.DataPropertyName = "CGSTRate";
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.LightGreen;
            this.taxCGSTRate.DefaultCellStyle = dataGridViewCellStyle5;
            this.taxCGSTRate.HeaderText = "CGST %";
            this.taxCGSTRate.Name = "taxCGSTRate";
            this.taxCGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxCGSTAmount
            // 
            this.taxCGSTAmount.DataPropertyName = "CGSTAmount";
            this.taxCGSTAmount.HeaderText = "CGST Amount";
            this.taxCGSTAmount.Name = "taxCGSTAmount";
            this.taxCGSTAmount.ReadOnly = true;
            this.taxCGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(341, 515);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(115, 23);
            this.label7.TabIndex = 203;
            this.label7.Text = "TCS Amount :";
            // 
            // txtTCSAmount
            // 
            this.txtTCSAmount.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtTCSAmount.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTCSAmount.Location = new System.Drawing.Point(454, 515);
            this.txtTCSAmount.Name = "txtTCSAmount";
            this.txtTCSAmount.Size = new System.Drawing.Size(163, 27);
            this.txtTCSAmount.TabIndex = 204;
            this.txtTCSAmount.Text = "0";
            // 
            // lblFinalNetAmount
            // 
            this.lblFinalNetAmount.AutoSize = true;
            this.lblFinalNetAmount.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinalNetAmount.ForeColor = System.Drawing.Color.Black;
            this.lblFinalNetAmount.Location = new System.Drawing.Point(691, 515);
            this.lblFinalNetAmount.Name = "lblFinalNetAmount";
            this.lblFinalNetAmount.Size = new System.Drawing.Size(121, 23);
            this.lblFinalNetAmount.TabIndex = 201;
            this.lblFinalNetAmount.Text = "Final Amount:";
            // 
            // txtFinalNetAmount
            // 
            this.txtFinalNetAmount.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtFinalNetAmount.Enabled = false;
            this.txtFinalNetAmount.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFinalNetAmount.Location = new System.Drawing.Point(818, 515);
            this.txtFinalNetAmount.Name = "txtFinalNetAmount";
            this.txtFinalNetAmount.ReadOnly = true;
            this.txtFinalNetAmount.Size = new System.Drawing.Size(163, 27);
            this.txtFinalNetAmount.TabIndex = 202;
            this.txtFinalNetAmount.Text = "0.0";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.lbltotalIGST);
            this.panel3.Controls.Add(this.label25);
            this.panel3.Controls.Add(this.lbltotalCGST);
            this.panel3.Controls.Add(this.label21);
            this.panel3.Controls.Add(this.lbltotalSGST);
            this.panel3.Controls.Add(this.label23);
            this.panel3.Controls.Add(this.lbltotaldiscount);
            this.panel3.Controls.Add(this.label18);
            this.panel3.Controls.Add(this.lblTotalAmount);
            this.panel3.Controls.Add(this.label19);
            this.panel3.Location = new System.Drawing.Point(17, 375);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1266, 36);
            this.panel3.TabIndex = 186;
            // 
            // lbltotalIGST
            // 
            this.lbltotalIGST.AutoSize = true;
            this.lbltotalIGST.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotalIGST.ForeColor = System.Drawing.Color.Black;
            this.lbltotalIGST.Location = new System.Drawing.Point(1145, 1);
            this.lbltotalIGST.Name = "lbltotalIGST";
            this.lbltotalIGST.Size = new System.Drawing.Size(23, 26);
            this.lbltotalIGST.TabIndex = 128;
            this.lbltotalIGST.Text = "0";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(1059, 4);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(91, 23);
            this.label25.TabIndex = 127;
            this.label25.Text = "Total IGST:";
            // 
            // lbltotalCGST
            // 
            this.lbltotalCGST.AutoSize = true;
            this.lbltotalCGST.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotalCGST.ForeColor = System.Drawing.Color.Black;
            this.lbltotalCGST.Location = new System.Drawing.Point(907, 4);
            this.lbltotalCGST.Name = "lbltotalCGST";
            this.lbltotalCGST.Size = new System.Drawing.Size(23, 26);
            this.lbltotalCGST.TabIndex = 126;
            this.lbltotalCGST.Text = "0";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(815, 6);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(96, 23);
            this.label21.TabIndex = 125;
            this.label21.Text = "Total CGST:";
            // 
            // lbltotalSGST
            // 
            this.lbltotalSGST.AutoSize = true;
            this.lbltotalSGST.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotalSGST.ForeColor = System.Drawing.Color.Black;
            this.lbltotalSGST.Location = new System.Drawing.Point(687, 3);
            this.lbltotalSGST.Name = "lbltotalSGST";
            this.lbltotalSGST.Size = new System.Drawing.Size(23, 26);
            this.lbltotalSGST.TabIndex = 124;
            this.lbltotalSGST.Text = "0";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Black;
            this.label23.Location = new System.Drawing.Point(591, 6);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(100, 23);
            this.label23.TabIndex = 123;
            this.label23.Text = "Total SGST :";
            // 
            // lbltotaldiscount
            // 
            this.lbltotaldiscount.AutoSize = true;
            this.lbltotaldiscount.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotaldiscount.ForeColor = System.Drawing.Color.Black;
            this.lbltotaldiscount.Location = new System.Drawing.Point(416, 4);
            this.lbltotaldiscount.Name = "lbltotaldiscount";
            this.lbltotaldiscount.Size = new System.Drawing.Size(23, 26);
            this.lbltotaldiscount.TabIndex = 122;
            this.lbltotaldiscount.Text = "0";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(293, 6);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(127, 23);
            this.label18.TabIndex = 121;
            this.label18.Text = "Total Discount:";
            // 
            // lblTotalAmount
            // 
            this.lblTotalAmount.AutoSize = true;
            this.lblTotalAmount.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalAmount.ForeColor = System.Drawing.Color.Black;
            this.lblTotalAmount.Location = new System.Drawing.Point(132, 3);
            this.lblTotalAmount.Name = "lblTotalAmount";
            this.lblTotalAmount.Size = new System.Drawing.Size(23, 26);
            this.lblTotalAmount.TabIndex = 120;
            this.lblTotalAmount.Text = "0";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(9, 3);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(125, 23);
            this.label19.TabIndex = 119;
            this.label19.Text = "Total Amount :";
            // 
            // dgvPOItemList
            // 
            this.dgvPOItemList.AllowUserToAddRows = false;
            this.dgvPOItemList.AllowUserToDeleteRows = false;
            this.dgvPOItemList.AllowUserToResizeRows = false;
            this.dgvPOItemList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.Desktop;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPOItemList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgvPOItemList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPOItemList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ItemCode,
            this.ItemDescription,
            this.OrderedQty,
            this.UnitCost,
            this.DiscRate,
            this.DiscAmount,
            this.Amount,
            this.SGSTRate,
            this.SGSTAmount,
            this.CGSTRate,
            this.CGSTAmount,
            this.IGSTRate,
            this.IGSTAmount,
            this.Freight,
            this.CustomsDuty,
            this.CustomsDutyAmt,
            this.CDIGST,
            this.CDIGSTAmt,
            this.Cess,
            this.CessAmt});
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle25.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle25.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPOItemList.DefaultCellStyle = dataGridViewCellStyle25;
            this.dgvPOItemList.EnableHeadersVisualStyles = false;
            this.dgvPOItemList.Location = new System.Drawing.Point(17, 18);
            this.dgvPOItemList.MultiSelect = false;
            this.dgvPOItemList.Name = "dgvPOItemList";
            this.dgvPOItemList.RowHeadersVisible = false;
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvPOItemList.RowsDefaultCellStyle = dataGridViewCellStyle26;
            this.dgvPOItemList.Size = new System.Drawing.Size(1266, 351);
            this.dgvPOItemList.TabIndex = 185;
            this.dgvPOItemList.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPOItemList_CellEndEdit);
            // 
            // ItemCode
            // 
            this.ItemCode.DataPropertyName = "ItemCode";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ItemCode.DefaultCellStyle = dataGridViewCellStyle8;
            this.ItemCode.Frozen = true;
            this.ItemCode.HeaderText = "Item Code";
            this.ItemCode.Name = "ItemCode";
            this.ItemCode.ReadOnly = true;
            this.ItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemCode.Width = 76;
            // 
            // ItemDescription
            // 
            this.ItemDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ItemDescription.DataPropertyName = "ItemDescription";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.ItemDescription.DefaultCellStyle = dataGridViewCellStyle9;
            this.ItemDescription.Frozen = true;
            this.ItemDescription.HeaderText = "Item Description";
            this.ItemDescription.Name = "ItemDescription";
            this.ItemDescription.ReadOnly = true;
            this.ItemDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemDescription.Width = 132;
            // 
            // OrderedQty
            // 
            this.OrderedQty.DataPropertyName = "Quantity";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.OrderedQty.DefaultCellStyle = dataGridViewCellStyle10;
            this.OrderedQty.Frozen = true;
            this.OrderedQty.HeaderText = "GIN Qty";
            this.OrderedQty.Name = "OrderedQty";
            this.OrderedQty.ReadOnly = true;
            this.OrderedQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OrderedQty.Width = 40;
            // 
            // UnitCost
            // 
            this.UnitCost.DataPropertyName = "UnitCost";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.UnitCost.DefaultCellStyle = dataGridViewCellStyle11;
            this.UnitCost.Frozen = true;
            this.UnitCost.HeaderText = "Unit Cost";
            this.UnitCost.Name = "UnitCost";
            this.UnitCost.ReadOnly = true;
            this.UnitCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitCost.Width = 69;
            // 
            // DiscRate
            // 
            this.DiscRate.DataPropertyName = "DiscRate";
            this.DiscRate.Frozen = true;
            this.DiscRate.HeaderText = "Disc %";
            this.DiscRate.Name = "DiscRate";
            this.DiscRate.ReadOnly = true;
            this.DiscRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DiscRate.Width = 52;
            // 
            // DiscAmount
            // 
            this.DiscAmount.DataPropertyName = "DiscAmount";
            this.DiscAmount.Frozen = true;
            this.DiscAmount.HeaderText = "Disc Amt";
            this.DiscAmount.Name = "DiscAmount";
            this.DiscAmount.ReadOnly = true;
            this.DiscAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DiscAmount.Width = 68;
            // 
            // Amount
            // 
            this.Amount.DataPropertyName = "Amount";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Amount.DefaultCellStyle = dataGridViewCellStyle12;
            this.Amount.Frozen = true;
            this.Amount.HeaderText = "Amount";
            this.Amount.Name = "Amount";
            this.Amount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Amount.Width = 71;
            // 
            // SGSTRate
            // 
            this.SGSTRate.DataPropertyName = "SGSTRate";
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.SGSTRate.DefaultCellStyle = dataGridViewCellStyle13;
            this.SGSTRate.HeaderText = "SGST %";
            this.SGSTRate.Name = "SGSTRate";
            this.SGSTRate.ReadOnly = true;
            this.SGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SGSTRate.Width = 59;
            // 
            // SGSTAmount
            // 
            this.SGSTAmount.DataPropertyName = "SGSTAmount";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle14.Format = "N2";
            this.SGSTAmount.DefaultCellStyle = dataGridViewCellStyle14;
            this.SGSTAmount.HeaderText = "SGST Amt";
            this.SGSTAmount.Name = "SGSTAmount";
            this.SGSTAmount.ReadOnly = true;
            this.SGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SGSTAmount.Width = 74;
            // 
            // CGSTRate
            // 
            this.CGSTRate.DataPropertyName = "CGSTRate";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.CGSTRate.DefaultCellStyle = dataGridViewCellStyle15;
            this.CGSTRate.HeaderText = "CGST %";
            this.CGSTRate.Name = "CGSTRate";
            this.CGSTRate.ReadOnly = true;
            this.CGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CGSTRate.Width = 59;
            // 
            // CGSTAmount
            // 
            this.CGSTAmount.DataPropertyName = "CGSTAmount";
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle16.Format = "N2";
            this.CGSTAmount.DefaultCellStyle = dataGridViewCellStyle16;
            this.CGSTAmount.HeaderText = "CGST Amt";
            this.CGSTAmount.Name = "CGSTAmount";
            this.CGSTAmount.ReadOnly = true;
            this.CGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CGSTAmount.Width = 74;
            // 
            // IGSTRate
            // 
            this.IGSTRate.DataPropertyName = "IGSTRate";
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.IGSTRate.DefaultCellStyle = dataGridViewCellStyle17;
            this.IGSTRate.HeaderText = "IGST %";
            this.IGSTRate.Name = "IGSTRate";
            this.IGSTRate.ReadOnly = true;
            this.IGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IGSTRate.Width = 55;
            // 
            // IGSTAmount
            // 
            this.IGSTAmount.DataPropertyName = "IGSTAmount";
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle18.Format = "N2";
            dataGridViewCellStyle18.NullValue = null;
            this.IGSTAmount.DefaultCellStyle = dataGridViewCellStyle18;
            this.IGSTAmount.HeaderText = "IGST Amt";
            this.IGSTAmount.Name = "IGSTAmount";
            this.IGSTAmount.ReadOnly = true;
            this.IGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IGSTAmount.Width = 70;
            // 
            // Freight
            // 
            this.Freight.DataPropertyName = "TransportationFreight";
            this.Freight.HeaderText = "Freight";
            this.Freight.Name = "Freight";
            this.Freight.ReadOnly = true;
            this.Freight.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Freight.Width = 63;
            // 
            // CustomsDuty
            // 
            this.CustomsDuty.DataPropertyName = "CDPercent";
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.CustomsDuty.DefaultCellStyle = dataGridViewCellStyle19;
            this.CustomsDuty.HeaderText = "Customs Duty %";
            this.CustomsDuty.Name = "CustomsDuty";
            this.CustomsDuty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CustomsDuty.Width = 102;
            // 
            // CustomsDutyAmt
            // 
            this.CustomsDutyAmt.DataPropertyName = "CDValue";
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.CustomsDutyAmt.DefaultCellStyle = dataGridViewCellStyle20;
            this.CustomsDutyAmt.HeaderText = "Customs Duty Amt";
            this.CustomsDutyAmt.Name = "CustomsDutyAmt";
            this.CustomsDutyAmt.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CustomsDutyAmt.Width = 102;
            // 
            // CDIGST
            // 
            this.CDIGST.DataPropertyName = "CDIGSTRate";
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.CDIGST.DefaultCellStyle = dataGridViewCellStyle21;
            this.CDIGST.HeaderText = "CDIGST %";
            this.CDIGST.Name = "CDIGST";
            this.CDIGST.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CDIGST.Width = 71;
            // 
            // CDIGSTAmt
            // 
            this.CDIGSTAmt.DataPropertyName = "CDIGSTAmount";
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.CDIGSTAmt.DefaultCellStyle = dataGridViewCellStyle22;
            this.CDIGSTAmt.HeaderText = "CDIGST Amt";
            this.CDIGSTAmt.Name = "CDIGSTAmt";
            this.CDIGSTAmt.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CDIGSTAmt.Width = 86;
            // 
            // Cess
            // 
            this.Cess.DataPropertyName = "CDCessRate";
            dataGridViewCellStyle23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Cess.DefaultCellStyle = dataGridViewCellStyle23;
            this.Cess.HeaderText = "Cess %";
            this.Cess.Name = "Cess";
            this.Cess.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Cess.Width = 53;
            // 
            // CessAmt
            // 
            this.CessAmt.DataPropertyName = "CDCessAmount";
            dataGridViewCellStyle24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.CessAmt.DefaultCellStyle = dataGridViewCellStyle24;
            this.CessAmt.HeaderText = "Cess Amt";
            this.CessAmt.Name = "CessAmt";
            this.CessAmt.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CessAmt.Width = 68;
            // 
            // GINPOView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1304, 682);
            this.Controls.Add(this.gbSearchOptions);
            this.Controls.Add(this.pnGINTax);
            this.Controls.Add(this.pnUpdateInvoicedate);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "GINPOView";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ledger Update";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.GINPOView_FormClosing);
            this.Load += new System.EventHandler(this.GINPOView_Load);
            this.gbSearchOptions.ResumeLayout(false);
            this.gbSearchOptions.PerformLayout();
            this.panelledger.ResumeLayout(false);
            this.panelledger.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnUpdateInvoicedate.ResumeLayout(false);
            this.pnUpdateInvoicedate.PerformLayout();
            this.pnGINTax.ResumeLayout(false);
            this.pnGINTax.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgPackingTaxes)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPOItemList)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbSearchOptions;
        private System.Windows.Forms.ComboBox cmbGinnumber;
        private System.Windows.Forms.Label lblGinno;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbLedger;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnAddledger;
        private System.Windows.Forms.Panel panelledger;
        private System.Windows.Forms.Button btnledgercancel;
        private System.Windows.Forms.TextBox LedgerTextbox;
        private System.Windows.Forms.Button btnledgersave;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnInvoiceUpdate;
        private System.Windows.Forms.Panel pnUpdateInvoicedate;
        private System.Windows.Forms.Button btnInvoicecancel;
        private System.Windows.Forms.Button btnInvoicenodateupdate;
        private System.Windows.Forms.Label lblinvoicedate;
        private System.Windows.Forms.DateTimePicker dtpInvoiceDate;
        private System.Windows.Forms.Label lblSupplierinvoicenumber;
        private System.Windows.Forms.TextBox txtinvoiceno;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtOldInvioceNumber;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dtpOldInvoiceDate;
        private System.Windows.Forms.Panel pnGINTax;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lbltotalIGST;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label lbltotalCGST;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lbltotalSGST;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label lbltotaldiscount;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lblTotalAmount;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.DataGridView dgvPOItemList;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtTCSAmount;
        private System.Windows.Forms.Label lblFinalNetAmount;
        private System.Windows.Forms.TextBox txtFinalNetAmount;
        private System.Windows.Forms.DataGridView dgPackingTaxes;
        private System.Windows.Forms.DataGridViewTextBoxColumn TaxDesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxamount;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxIGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxIGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxSGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxSGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxCGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxCGSTAmount;
        private System.Windows.Forms.CheckBox chkGINPO;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox combocurrency;
        private System.Windows.Forms.TextBox textBRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn OrderedQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiscRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiscAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn SGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn SGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn CGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn CGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn IGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn IGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn Freight;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomsDuty;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomsDutyAmt;
        private System.Windows.Forms.DataGridViewTextBoxColumn CDIGST;
        private System.Windows.Forms.DataGridViewTextBoxColumn CDIGSTAmt;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cess;
        private System.Windows.Forms.DataGridViewTextBoxColumn CessAmt;
        private System.Windows.Forms.Button btnExit1;
    }
}
