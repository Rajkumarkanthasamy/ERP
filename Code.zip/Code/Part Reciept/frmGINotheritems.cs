﻿using System;
using System.Data;
using System.Globalization;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Erp_Project_With_Buttons.Part_Reciept
{
    public partial class frmGINotheritems : Form
    {
        public frmGINotheritems()
        {
            InitializeComponent();
        }

        frmForm2 frm = new frmForm2();
        DataAccessLayer DAL = new DataAccessLayer();
        Global GLobalClass = new Global();
       // frmForm2 form = new frmForm2();
        Login.frmLoginForm login = new Login.frmLoginForm();
        DataTable dtvendorList = new DataTable();
        SqlConnection SQLCon;
        DataTable ledger = new DataTable();

        Part_Reciept.DocumentScanning docscan = new Part_Reciept.DocumentScanning();
        private void frmGINotheritems_Load(object sender, EventArgs e)
        {
            dtvendorList = DAL.fnVedorList(null).Tables[0];
            foreach (DataRow dr in dtvendorList.Rows)
            {
                if (!cmbVendorName.Items.Contains(dr["VendorName"].ToString()))
                {
                    cmbVendorName.Items.Add(dr["VendorName"].ToString());
                }
            }

            dtServiceItems = DAL.fnItemMasterServiceItems(null).Tables[0];

            if (dtServiceItems.Rows.Count > 0)
            {

            }

            ledger = DAL.fnGetLastGINnumber(1).Tables[0];
            foreach (DataRow DR in ledger.Rows)
            {
                if (!cmbLedger.Items.Contains(DR["LedgerName"].ToString()))
                    cmbLedger.Items.Add(DR["LedgerName"].ToString());
            }


        }
        DataTable dtServiceItems = new DataTable();
        DataView dvItemList = new DataView();

        public DataView RowFilter1(string sRowfilter)
        {
            dvItemList = new DataView();
            if (dtServiceItems.Rows.Count > 0)
            {

                dvItemList = new DataView(dtServiceItems);
                dvItemList.RowFilter = "ItemCode like '%" + sRowfilter + "%' or ItemDescription LIKE '%" + sRowfilter + "%'";

            }

            return dvItemList;
        }
        private void fnLoadItems()
        {

        }
        private void cmbVendorName_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataView dvVendor = new DataView(dtvendorList);
            dvVendor.RowFilter = "VendorName Like'" + cmbVendorName.Text + "'";
            DataTable dtrow = dvVendor.ToTable();
            txtvendorcode.Text = dtrow.Rows[0]["VendorCode"].ToString();
            lblCountry.Text = dtrow.Rows[0]["Country"].ToString();
        }

        private void frmGINotheritems_FormClosing(object sender, FormClosingEventArgs e)
        {
           // frmReciept frm1 = new frmReciept();
            this.Hide();
            frm.Show();
        }

        DataTable dtPackingForwardingTax = new DataTable();
        private void btnPackingAmount_Click(object sender, EventArgs e)
        {
            dtPackingForwardingTax = DAL.PackingForwardingTax("PO/19100388", "Packing & Forwarding").Tables[0];

            if (dtPackingForwardingTax.Rows.Count > 0)
            {
                dtPackingForwardingTax = DAL.PackingForwardingTax("PO/19100388", null).Tables[0];
                dgPackingTaxes.AutoGenerateColumns = false;
                dgPackingTaxes.DataSource = dtPackingForwardingTax;
                dgPackingTaxes.Visible = true;
            }
            else
            {
                // GLobalClass.iSuccess = DAL.fnAddPOPackingForward(Global.uINSERT, cmbPonumber.Text, "Packing & Forwarding", 0, 0, 0, 0, 0, 0, 0);
                // dtPackingForwardingTax = DAL.PackingForwardingTax("PO/19100388", null).Tables[0];
                dtPackingForwardingTax = DAL.PackingForwardingTax("PO/19100388", null).Tables[0];
                if (dtPackingForwardingTax.Rows.Count > 0)
                {
                    dgPackingTaxes.AutoGenerateColumns = false;
                    dgPackingTaxes.DataSource = dtPackingForwardingTax;
                    dgPackingTaxes.Visible = true;
                }
            }
        }

        private void btnAddTransport_Click(object sender, EventArgs e)
        {
            dtPackingForwardingTax = DAL.PackingForwardingTax("PO/18002022", "Transportation / Freight").Tables[0];

            if (dtPackingForwardingTax.Rows.Count > 0)
            {
                dtPackingForwardingTax = DAL.PackingForwardingTax("PO/18002022", null).Tables[0];
                dgPackingTaxes.AutoGenerateColumns = false;
                dgPackingTaxes.DataSource = dtPackingForwardingTax;
                dgPackingTaxes.Visible = true;
            }
            else
            {
                //  GLobalClass.iSuccess = DAL.fnAddPOPackingForward(Global.uINSERT, "PO/19100388", "Transportation / Freight", 0, 0, 0, 0, 0, 0, 0);
                // dtPackingForwardingTax = DAL.PackingForwardingTax("PO/19100388", null).Tables[0];
                dtPackingForwardingTax = DAL.PackingForwardingTax("PO/18002022", null).Tables[0];
                if (dtPackingForwardingTax.Rows.Count > 0)
                {
                    dgPackingTaxes.AutoGenerateColumns = false;
                    dgPackingTaxes.DataSource = dtPackingForwardingTax;
                    dgPackingTaxes.Visible = true;
                }
            }
        }
        double dOldTaxRate;
        private void dgPackingTaxes_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgPackingTaxes.CurrentCell.OwningColumn.Index == 1)
            {
                dOldTaxRate = Convert.ToDouble(dgPackingTaxes.CurrentCell.Value);
            }
        }
        string sDot = ".";
        private void dgPackingTaxes_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (dgPackingTaxes.CurrentCell.Value != null)
            {
                if (!string.IsNullOrEmpty(dgPackingTaxes.CurrentCell.Value.ToString()) && (dgPackingTaxes.CurrentCell.Value.ToString() != sDot))
                {
                    switch (dgPackingTaxes.CurrentCell.OwningColumn.Index)
                    {
                        case 1:

                            dgPackingTaxes.CurrentRow.Cells[3].Value = (Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[1].Value) / 100) * Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[2].Value);
                            dgPackingTaxes.CurrentRow.Cells[5].Value = (Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[1].Value) / 100) * Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[4].Value);
                            dgPackingTaxes.CurrentRow.Cells[7].Value = (Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[1].Value) / 100) * Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[6].Value);

                            break;

                        case 2:
                            dgPackingTaxes.CurrentRow.Cells[3].Value = (Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[1].Value) / 100) * Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[2].Value);
                            break;
                        case 4:
                            dgPackingTaxes.CurrentRow.Cells[5].Value = (Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[1].Value) / 100) * Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[4].Value);
                            break;
                        case 6:
                            dgPackingTaxes.CurrentRow.Cells[7].Value = (Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[1].Value) / 100) * Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[6].Value);
                            break;

                    }
                    fnTotalPOCost();

                }
                else
                {
                    if (dgPackingTaxes.CurrentCell.OwningColumn.Index == 1)
                    {
                        dgPackingTaxes.CurrentCell.Value = dOldTaxRate;
                    }
                    else
                    {
                        dgPackingTaxes.CurrentCell.Value = 0;
                    }
                    fnTotalPOCost();
                }
            }
        }

        double dTotalAmount = 0;
        double dTotalDiscount = 0;
        double dTotalSgst = 0;
        double dTotalCgst = 0;
        double dTotalIgst = 0;
        private void fnTotalPOCost()
        {
            double totalcost = 0;
            dTotalAmount = 0;
            dTotalDiscount = 0;
            dTotalSgst = 0;
            dTotalCgst = 0;
            dTotalIgst = 0;
            foreach (DataGridViewRow dgvr in dgvPOItemList.Rows)
            {
                totalcost += Convert.ToDouble(dgvr.Cells["Amount"].Value) + Convert.ToDouble(dgvr.Cells["IGSTAmount"].Value) + Convert.ToDouble(dgvr.Cells["SGSTAmount"].Value) + Convert.ToDouble(dgvr.Cells["CGSTAmount"].Value);
                dTotalAmount += Convert.ToDouble(dgvr.Cells["Amount"].Value);
                dTotalDiscount += Convert.ToDouble(dgvr.Cells["DiscAmount"].Value);
                dTotalSgst += Convert.ToDouble(dgvr.Cells["SGSTAmount"].Value);
                dTotalCgst += Convert.ToDouble(dgvr.Cells["CGSTAmount"].Value);
                dTotalIgst += Convert.ToDouble(dgvr.Cells["IGSTAmount"].Value);
            }

            foreach (DataGridViewRow dgvr in dgPackingTaxes.Rows)
            {
                totalcost += Convert.ToDouble(dgvr.Cells["taxamount"].Value) + Convert.ToDouble(dgvr.Cells["taxIGSTAmount"].Value) + Convert.ToDouble(dgvr.Cells["taxSGSTAmount"].Value) + Convert.ToDouble(dgvr.Cells["taxCGSTAmount"].Value);
            }

            // totalcost = Math.Round(totalcost, 2);
            txtFinalNetAmount.Text = Math.Round(totalcost, 2).ToString();
            lblTotalAmount.Text = string.Format(india, "{0:c}", dTotalAmount);
            lbltotaldiscount.Text = string.Format(india, "{0:c}", dTotalDiscount);
            lbltotalSGST.Text = string.Format(india, "{0:c}", dTotalSgst);
            lbltotalCGST.Text = string.Format(india, "{0:c}", dTotalCgst);
            lbltotalIGST.Text = string.Format(india, "{0:c}", dTotalIgst);
        }
        CultureInfo india = new CultureInfo("hi-IN");
        double oldvalue;
        private void dgvPOItemList_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgvPOItemList.CurrentCell.OwningColumn.Name == "RecieveQuantity")
            {
                oldvalue = Convert.ToDouble(dgvPOItemList.CurrentCell.Value);
            }
        }

        private void dgvPOItemList_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvPOItemList.CurrentCell.OwningColumn.Name != "ItemCode" && dgvPOItemList.CurrentCell.OwningColumn.Name != "ItemDescription" && dgvPOItemList.CurrentCell.OwningColumn.Name != "HsnSacCode")
            {
                if ((dgvPOItemList.CurrentCell.Value) != null)// && 
                {
                    if (!string.IsNullOrEmpty(dgvPOItemList.CurrentCell.Value.ToString()))
                    {
                        if (dgvPOItemList.CurrentCell.Value.ToString() != "." && Convert.ToDouble(dgvPOItemList.CurrentCell.Value.ToString()) != 0.0)
                        {
                            switch (dgvPOItemList.CurrentCell.OwningColumn.Name)
                            {

                                case "Quantity":
                                case "UnitPrice":
                                case "DiscRate":
                                    dgvPOItemList.CurrentRow.Cells["Amount"].Value = Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Quantity"].Value.ToString()) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["UnitPrice"].Value.ToString());
                                    dgvPOItemList.CurrentRow.Cells["DiscAmount"].Value = (Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Amount"].Value.ToString()) / 100) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["DiscRate"].Value.ToString());
                                    dgvPOItemList.CurrentRow.Cells["Amount"].Value = (Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Amount"].Value)) - (Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["DiscAmount"].Value));
                                    dgvPOItemList.CurrentRow.Cells["IGSTAmount"].Value = (Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Amount"].Value.ToString()) / 100) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["IGSTRate"].Value.ToString());
                                    dgvPOItemList.CurrentRow.Cells["SGSTAmount"].Value = (Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Amount"].Value.ToString()) / 100) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["SGSTRate"].Value.ToString());
                                    dgvPOItemList.CurrentRow.Cells["CGSTAmount"].Value = (Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Amount"].Value.ToString()) / 100) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["CGSTRate"].Value.ToString());


                                    break;


                                case "IGSTRate":
                                    dgvPOItemList.CurrentRow.Cells["IGSTAmount"].Value = (Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Amount"].Value.ToString()) / 100) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["IGSTRate"].Value.ToString());
                                    break;

                                case "SGSTRate":
                                    dgvPOItemList.CurrentRow.Cells["SGSTAmount"].Value = (Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Amount"].Value.ToString()) / 100) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["SGSTRate"].Value.ToString());
                                    break;

                                case "CGSTRate":
                                    dgvPOItemList.CurrentRow.Cells["CGSTAmount"].Value = (Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Amount"].Value.ToString()) / 100) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["CGSTRate"].Value.ToString());
                                    break;
                            }

                        }
                        else
                        {
                            if (dgvPOItemList.CurrentCell.OwningColumn.Name == "DiscRate")
                            {
                                dgvPOItemList.CurrentRow.Cells["DiscAmount"].Value = (Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Amount"].Value.ToString()) / 100) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["DiscRate"].Value.ToString());
                                dgvPOItemList.CurrentRow.Cells["Amount"].Value = Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Quantity"].Value.ToString()) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["UnitPrice"].Value.ToString());
                                dgvPOItemList.CurrentRow.Cells["IGSTAmount"].Value = (Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Amount"].Value.ToString()) / 100) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["IGSTRate"].Value.ToString());
                                dgvPOItemList.CurrentRow.Cells["SGSTAmount"].Value = (Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Amount"].Value.ToString()) / 100) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["SGSTRate"].Value.ToString());
                                dgvPOItemList.CurrentRow.Cells["CGSTAmount"].Value = (Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Amount"].Value.ToString()) / 100) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["CGSTRate"].Value.ToString());
                            }
                            else
                            {
                                fnErrorValue();
                            }
                        }
                    }
                    else
                    {
                        fnErrorValue();
                    }
                    fnTotalPOCost();
                }
                else
                {
                    fnErrorValue();
                }
            }
        }

        private void fnErrorValue()
        {
            MessageBox.Show("Enter a Valid Value", "Error", 0, MessageBoxIcon.Error);
            if (dgvPOItemList.CurrentCell.OwningColumn.Name == "RecieveQuantity")
            {
                dgvPOItemList.CurrentCell.Value = oldvalue;
            }
            else
            {
                dgvPOItemList.CurrentCell.Value = 0;
            }
        }
        bool bItemNotSelected = false;
       string sGINID;
        int iLastGINNO;
        string sGINNO;
        DataTable Gindt = new DataTable();
        DataTable dtItemDetails = new DataTable();


        string sLedgerName = "";
        private void fnLedger(string sItemType)
        {
            sLedgerName = "";
            switch (sItemType)
            {
                case "Consumable":
                    sLedgerName = "50001 Purhcase Consumables";
                    break;
                case "Broughtout":
                    sLedgerName = "50001 Purhcase Rawmaterials";
                    break;
                case "Electronics":
                    sLedgerName = "50001 Purhcase Electronics";
                    break;
                case "Electricals":
                    sLedgerName = "50001 Purhcase Electricals";
                    break;
                case "Boughtout":
                    sLedgerName = "50001 Purhcase Rawmaterials";
                    break;
                case "Mechanical":
                    sLedgerName = "50001 Purhcase Mechanical";
                    break;
                case "Hydraulics":
                    sLedgerName = "50001 Purhcase Hydraulics";
                    break;
                case "KanBan":
                    sLedgerName = "50001 Purhcase KanBan";
                    break;
                case "Transducers":
                    sLedgerName = "50001 Purhcase Transducers";
                    break;
                case "Maintenance":
                    sLedgerName = "50001 Purhcase Maintenance";
                    break;
                case "Electronics RnD":
                    sLedgerName = "50001 Purhcase Electronics";
                    break;
                case "Service(Non-Inventory)":
                    sLedgerName = "50300 Service Charges";
                    break;
                case "Testlab":
                    sLedgerName = "50001 Purhcase RM Test Lab";
                    break;
                case "TGT":
                    sLedgerName = "50001 Purhcase TGT";
                    break;
                case "Tools":
                    sLedgerName = "50001 Purhcase Tools";
                    break;
                case "Packing Materials":
                    sLedgerName = "50001 Purhcase Packing Materials";
                    break;
                case "Fixed Asset":
                    sLedgerName = "12099 Capital Work in Progress";
                    break;
            }

            if (lblCountry.Text.ToLower() != "india")
            {
                sLedgerName = sLedgerName + "-Import";
            }


        }


        private void btnSave_Click(object sender, EventArgs e)
        {
            bItemNotSelected = false;
            if (dgvPOItemList.Rows.Count > 0)
            {
                foreach (DataGridViewRow row in dgvPOItemList.Rows)
                {
                    if (Convert.ToDouble(row.Cells["Quantity"].Value) == 0.0 || row.Cells["Quantity"].Value == null)
                    {
                        bItemNotSelected = true;
                        MessageBox.Show("Please enter the quantity of items to be recieved ", "Error", 0, MessageBoxIcon.Error);
                        break;
                    }
                    if (Convert.ToDouble(row.Cells["UnitPrice"].Value) == 0.0 || row.Cells["UnitPrice"].Value == null)
                    {
                        bItemNotSelected = true;
                        MessageBox.Show("Please enter the unit price of items to be recieved ", "Error", 0, MessageBoxIcon.Error);
                        break;
                    }
                    //if (string.IsNullOrEmpty(row.Cells["ItemCode"].Value.ToString()))
                    //{
                    //    bItemNotSelected = true;
                    //    MessageBox.Show("Please enter the item code of items to be recieved ", "Error", 0, MessageBoxIcon.Error);
                    //    break;
                    //}
                    //if (string.IsNullOrEmpty(row.Cells["ItemDescription"].Value.ToString()))
                    //{
                    //    bItemNotSelected = true;
                    //    MessageBox.Show("Please enter the item description of items to be recieved ", "Error", 0, MessageBoxIcon.Error);
                    //    break;
                    //}
                    if (row.Cells["HsnSacCode"].Value == null)
                    {
                        bItemNotSelected = true;
                        MessageBox.Show("Please enter the Hsn/Sac code of items to be recieved ", "Error", 0, MessageBoxIcon.Error);
                        break;
                    }
                    else
                    {
                        bItemNotSelected = false;
                    }
                }
            }
            if (string.IsNullOrEmpty(txtinvoiceno.Text))
            {
                MessageBox.Show("Please Enter Invoice Number! Item Not recieved!!", "Error", 0, MessageBoxIcon.Error);
                txtinvoiceno.Focus();
            }
            else if (bInvoiceDate == false)
            {
                MessageBox.Show("Please Select the Invoice Date! Item Not recieved!!", "Error", 0, MessageBoxIcon.Error);
                dtpInvoiceDate.Focus();
            }

            else if (cmbVendorName.SelectedIndex < 0)
            {
                MessageBox.Show("Please Select the Vendor Name! Item Not recieved!!", "Error", 0, MessageBoxIcon.Error);
                cmbVendorName.Focus();
            }
            else if(txtvendorcode.Text== "*")
            {
                MessageBox.Show("Please Select the Vendor Name! Item Not recieved!!", "Error", 0, MessageBoxIcon.Error);
                cmbVendorName.Focus();
            }
            //else if(cmbLedger.SelectedIndex < 0)
            //{
            //    MessageBox.Show("Please Select the Ledger! Item Not recieved!!", "Error", 0, MessageBoxIcon.Error);
            //    cmbVendorName.Focus();
            //}
            else if (bItemNotSelected == false)
            {
                //DataTable dtTestQuoteNumber = DAL.fnGINOtherItemNumber(0, null).Tables[0];
                //if (dtTestQuoteNumber.Rows.Count > 0)
                //{
                //    sGINID = dtTestQuoteNumber.Rows[0]["GINNumber"].ToString();
                //}
                //if (!string.IsNullOrEmpty(sGINID))
                //{
                //    sGINID = sGINID.Substring(10, 6);
                //    iLastGINNO = Convert.ToInt32(sGINID);
                //}
                //else
                //{
                //    iLastGINNO = 000000;
                //}

                //iLastGINNO++;
                //sGINNO = "";
                //string value = String.Format("{0:D6}", iLastGINNO);
                ////sGINNO = ("ITWSIN2022/" + value);
                //sGINNO = string.Concat("ITWSIN", DateTime.Today.ToString("yyyy"), value);
                //txtGinno.Text = sGINNO;

               
                Gindt = DAL.fnGetLastGINnumber(0).Tables[0];
                if (Gindt.Rows.Count > 0)
                {
                    int iGinNUm = Convert.ToInt32(Gindt.Rows[0][0].ToString());
                    iGinNUm++;
                    GLobalClass.iSuccess = DAL.fnAddJobMovenment(Global.uINSERT, "", txtinvoiceno.Text, (dtpGINDate.Text), 0, (dtpGINDate.Text), login.GetUserDetails[2], iGinNUm);
                    Gindt = DAL.fnGetLastGINnumber(0).Tables[0];
                    string lastginNo = Gindt.Rows[0][0].ToString();
                     //value = String.Format("{0:D6}", iLastGINNO);
                    txtGinno.Text = string.Concat("ITWSIN", lastginNo);
                    

                    foreach (DataGridViewRow row in dgvPOItemList.Rows)
                    {
                        //if (Convert.ToBoolean(row.Cells["Select"].Value) == true)
                        {
                            //GLobalClass.iSuccess = DAL.fnAddOtherGINReciept(Global.uINSERT, row.Cells["ItemCode"].Value.ToString(), row.Cells["ItemDescription"].Value.ToString(), row.Cells["HsnSacCode"].Value.ToString(),
                            //    txtGinno.Text, Convert.ToDouble(row.Cells["Quantity"].Value), Convert.ToDouble(row.Cells["UnitPrice"].Value), txtvendorcode.Text, cmbVendorName.Text,
                            //    dtpGINDate.Text, txtinvoiceno.Text, "Non-Inv GIN", dtpInvoiceDate.Text, Convert.ToDouble(row.Cells["IGSTRate"].Value),
                            //    Convert.ToDouble(row.Cells["IGSTAmount"].Value), Convert.ToDouble(row.Cells["SGSTRate"].Value), Convert.ToDouble(row.Cells["SGSTAmount"].Value),
                            //    Convert.ToDouble(row.Cells["CGSTRate"].Value), Convert.ToDouble(row.Cells["CGSTAmount"].Value), cmbLedger.Text,
                            //    Convert.ToDouble(row.Cells["DiscRate"].Value), Convert.ToDouble(row.Cells["DiscAmount"].Value));



                            dtItemDetails = DAL.fnItemDetails(row.Cells["ItemCode"].Value.ToString()).Tables[0];

                            if (dtItemDetails.Rows.Count > 0)
                            {
                                fnLedger(dtItemDetails.Rows[0]["Type"].ToString());
                            }
                            else
                            {
                                sLedgerName = "";
                            }

                            GLobalClass.iSuccess = DAL.fnAddReciept(Global.uINSERT, row.Cells["ItemCode"].Value.ToString(), row.Cells["ProjectCode"].Value != null ? row.Cells["ProjectCode"].Value.ToString() : string.Empty, row.Cells["ProductNo"].Value != null ? Convert.ToInt32(row.Cells["ProductNo"].Value) : 0, txtGinno.Text, Convert.ToDouble(row.Cells["Quantity"].Value),
                                      Convert.ToDouble(row.Cells["UnitPrice"].Value), cmbVendorName.Text, dtpGINDate.Text, txtinvoiceno.Text, "Non-Inv GIN", txtPONo.Text, dtpInvoiceDate.Text, txtvendorcode.Text
                                      , Convert.ToDouble(row.Cells["IGSTRate"].Value), Convert.ToDouble(row.Cells["IGSTAmount"].Value), Convert.ToDouble(row.Cells["SGSTRate"].Value),
                                      Convert.ToDouble(row.Cells["SGSTAmount"].Value), Convert.ToDouble(row.Cells["CGSTRate"].Value), Convert.ToDouble(row.Cells["CGSTAmount"].Value),
                                     sLedgerName, row.Cells["HsnSacCode"].Value.ToString(), Convert.ToDouble(row.Cells["DiscRate"].Value), Convert.ToDouble(row.Cells["DiscAmount"].Value), Convert.ToDouble(0),
                                      Convert.ToDouble(0), Convert.ToDouble(0), Convert.ToDouble(0),
                                      Convert.ToDouble(0), Convert.ToDouble(0), Convert.ToDouble(0), Convert.ToDouble(0), Convert.ToDouble(0), "Rupee", Convert.ToDouble(1), Convert.ToDouble((row.Cells["Amount"].Value == null) ? 0 : row.Cells["Amount"].Value));

                        }

                        //if (!string.IsNullOrEmpty(txtPONo.Text))
                        //{
                        //    GLobalClass.iSuccess = DAL.fnUpdatePODetails(Global.uUPDATE, 0, txtPONo.Text, row.Cells["ItemCode"].Value.ToString());
                        //}

                        if (!string.IsNullOrEmpty(txtPONo.Text))
                        {
                            GLobalClass.iSuccess = DAL.fnUpdatePODetails(Global.uUPDATE, txtPONo.Text);
                        }
                    }
                }
                SQLCon = new SqlConnection(DataAccessLayer.cs);
                foreach (DataGridViewRow row in dgPackingTaxes.Rows)
                {
                    if ((row.Cells[0].Value.ToString()) == "Packing & Forwarding")
                    {
                        SqlCommand cmd1 = new SqlCommand("UPDATE Receipt SET [PackingForwarding]='" + row.Cells[1].Value.ToString() + "',[PFIGSTRate]='" + row.Cells[2].Value.ToString() + "',[PFSGSTRate]='" + row.Cells[4].Value.ToString() + "',[PFCGSTRate]='" + row.Cells[6].Value.ToString() + "' where GINNumber='" + txtGinno.Text + "'", SQLCon);
                        SQLCon.Open();
                        cmd1.ExecuteNonQuery();
                        SQLCon.Close();
                    }
                    else if ((row.Cells[0].Value.ToString()) == "Transportation / Freight")
                    {
                        SqlCommand cmd2 = new SqlCommand("UPDATE Receipt SET [TransportationFreight]='" + row.Cells[1].Value.ToString() + "',[TFIGSTRate]='" + row.Cells[2].Value.ToString() + "',[TFSGSTRate]='" + row.Cells[4].Value.ToString() + "',[TFCGSTRate]='" + row.Cells[6].Value.ToString() + "' where GINNumber='" + txtGinno.Text + "'", SQLCon);
                        SQLCon.Open();
                        cmd2.ExecuteNonQuery();
                        SQLCon.Close();
                    }
                }
                if (GLobalClass.iSuccess > 0)
                {
                    GLobalClass.iSuccess = DAL.fnAddERPLog(0, txtGinno.Text, login.GetUserDetails[2], dtpGINDate.Text, "Item SIN", "Receipt");
                    DialogResult dialog = MessageBox.Show("Item(s) Received Successfully with SIN No '" + txtGinno.Text + "'", "Success", 0, MessageBoxIcon.Information);
                    if (dialog == DialogResult.OK)
                    {
                        docscan.fnGetGINnumber = txtGinno.Text;
                        Part_Reciept.DocumentScanning scannar = new Part_Reciept.DocumentScanning();
                        this.Hide();
                        pleasewaitform pleaseWait = new pleasewaitform();
                        pleaseWait.Show();
                        Application.DoEvents();
                        scannar.Show();
                        pleaseWait.Hide();
                    }
                    btnSave.Enabled = false;
                }

            }
        }
        bool bInvoiceDate = false;

        private void dtpInvoiceDate_ValueChanged(object sender, EventArgs e)
        {
            bInvoiceDate = true;
        }
        DataTable dtGINItem = new DataTable();
  


        #region PO quantity cost validating function
        private void Control_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (dgvPOItemList.CurrentCell.OwningColumn.Name == "ItemCode" || dgvPOItemList.CurrentCell.OwningColumn.Name == "ItemDescription")
            {

            }
            else if (dgvPOItemList.CurrentCell.OwningColumn.Name == "HsnSacCode")
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                {
                    e.Handled = true;
                }
            }
            else
            {
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
                {
                    e.Handled = true;
                }
                if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
                {
                    e.Handled = true;
                }
            }
        }
        #endregion

        private void dgvPOItemList_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgbomlist_EditingControlShowing   " + ex.Message);
            }
        }

        private void dgvPOItemList_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (dgvPOItemList.Rows.Count > 0)
                {
                    DialogResult DR = MessageBox.Show("Do you want to delete selected row", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (DR == DialogResult.Yes)
                    {
                        dgvPOItemList.Rows.RemoveAt(dgvPOItemList.Rows.IndexOf(dgvPOItemList.CurrentRow));
                        fnTotalPOCost();
                    }
                }
                if (dgvPOItemList.Rows.Count == 0)
                {
                    dgPackingTaxes.Rows.Clear();
                }
            }
        }

        private void dgPackingTaxes_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (dgPackingTaxes.Rows.Count > 0)
                {
                    DialogResult DR = MessageBox.Show("Do you want to delete selected row", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (DR == DialogResult.Yes)
                    {
                        dgPackingTaxes.Rows.RemoveAt(dgPackingTaxes.Rows.IndexOf(dgPackingTaxes.CurrentRow));

                    }
                }
            }
        }

        private void dgPackingTaxes_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);

            }
            catch (Exception ex)
            {
                MessageBox.Show(" dgPackingTaxes_EditingControlShowing   " + ex.Message);
            }
        }

        private void btnClearAll_Click(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //frmReciept frm1 = new frmReciept();
            this.Hide();
            frm.Show();
        }

        private void txtItemDescription_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar == '%'))
            {
                e.Handled = true;
            }
        }

        private void txtItemDescription_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
            {
                dvItemList = RowFilter1(txtItemDescription.Text);
                RowFilter2();

            }
            else
            {
                dvItemList = RowFilter1(txtItemDescription.Text);
                RowFilter2();
            }
        }

        #region Code to Filter Item Search
        private void RowFilter2()
        {
            chklbItemList.Items.Clear();
            foreach (DataRowView dv in dvItemList)
            {
                chklbItemList.Items.Add(string.Concat(dv[0].ToString(), ") ", dv[1].ToString(), ", ", dv[2].ToString()));
            }
        }
        #endregion
        string[] sItemCode;
        DataTable dtItemCheck = new DataTable();
        private void chklbItemList_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            int i = 0;
            sItemCode = chklbItemList.SelectedItem.ToString().Trim().Split(')');
            string sID = sItemCode[0];
            dtItemCheck = DAL.fnItemMasterServiceItems(sID).Tables[0];
            if (dtItemCheck.Rows.Count > 0)
            {
                foreach (DataGridViewRow DGVR in dgvPOItemList.Rows)
                {
                    if (DGVR.Cells["ItemCode"].Value.ToString().Equals(dtItemCheck.Rows[0]["ItemCode"].ToString()))
                    {
                        i = 1;
                        break;
                    }
                }
                if (i != 1)
                {
                    if (dtGINItem.Rows.Count == 0)
                    {
                        dtGINItem = DAL.AddGINOtherItems("").Tables[0];
                    }

                    dtGINItem.Rows.Add(dtItemCheck.Rows[0]["ItemCode"].ToString(), dtItemCheck.Rows[0]["ItemDescription"].ToString(), dtItemCheck.Rows[0]["HSNSACCode"].ToString(), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
                    dgvPOItemList.AutoGenerateColumns = false;
                    dgvPOItemList.DataSource = dtGINItem;
                    if (dgPackingTaxes.Rows.Count == 0)
                    {
                        dgPackingTaxes.Rows.Add("Packing & Forwarding", 0, 0, 0, 0, 0, 0, 0);
                        dgPackingTaxes.Rows.Add("Transportation / Freight", 0, 0, 0, 0, 0, 0, 0);
                    }
                }
            }

        }

        private void chklbItemList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
