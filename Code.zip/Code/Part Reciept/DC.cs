﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Part_Reciept
{
    public partial class DC : Form
    {
        public DC()
        {
            InitializeComponent();
        }

        public static string cs = @"Data Source=inbas07;Initial Catalog=BusinessManagement;User ID=sa;Password=BiSS@ERP!!";
        public SqlConnection SQLCon = new SqlConnection(cs);
        public DataSet SQLDataset = new DataSet();
        public SqlCommand SQLCmd = new SqlCommand();
        public SqlDataAdapter SQLDadpr = new SqlDataAdapter();

        DataTable DataTable = new DataTable();
        DataTable DeliveryChallanDetails = new DataTable();


        public void fnGetConnectionString()
        {
            try
            {
               
                SQLCon = new SqlConnection(cs);
                //MessageBox.Show("Connection success...!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please check the connection" + ex.Message);
            }
        }

        private void DC_Load(object sender, EventArgs e)
        {
            fnGetConnectionString();
            
            DataTable = fnGetDeliveryChallanDetails(null).Tables[0];
            if(DataTable.Rows.Count > 0)
            {
                foreach (DataRow dr in DataTable.Rows)
                {
                  if (!comboBoxDCSerialNumber.Items.Contains(dr["DCSerialNumber"].ToString()))
                        comboBoxDCSerialNumber.Items.Add(dr["DCSerialNumber"].ToString());
                }
            }
            //MessageBox.Show(DataTable.Rows.Count.ToString());
        }

        public DataSet fnGetDeliveryChallanDetails(string DCSerialNumber)
        {
            try
            {
                SQLDataset = new DataSet();
                SQLCon.Open();
                {
                    if (DCSerialNumber != null)
                        SQLCmd = new SqlCommand("Select * from DeliveryChallanDetails where DCSerialNumber='" + DCSerialNumber + "'", SQLCon);
                    else
                        SQLCmd = new SqlCommand("Select DCSerialNumber from DeliveryChallanDetails order by id desc", SQLCon);
                    SQLCmd.ExecuteNonQuery();
                    SQLDadpr = new SqlDataAdapter(SQLCmd);
                    SQLDadpr.Fill(SQLDataset);
                    SQLCon.Close();
                    return SQLDataset;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                SQLCon.Close();
                return null;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(comboBoxDCSerialNumber.Text))
            {
                DeliveryChallanDetails = fnGetDeliveryChallanDetails(comboBoxDCSerialNumber.Text).Tables[0];
                DataRow row = DeliveryChallanDetails.Rows[0];

                DCSerialNumber.Text = row["DCSerialNumber"].ToString();
                DCFor.Text = row["DCFor"].ToString();
                DCBy.Text = row["DCBy"].ToString();
                DCWorkOrder.Text = row["DCWorkOrder"].ToString();
                DCReference.Text = row["DCReference"].ToString();
                DateofChallan.Text = row["DateofChallan"].ToString();
                DispatchDate.Text = row["DispatchDate"].ToString();
                TransportMode.Text = row["TransportMode"].ToString();
                VehicleNumber.Text = row["VehicleNumber"].ToString();
                PlaceofSupply.Text = row["PlaceofSupply"].ToString();
                TransportCompany.Text = row["TransportCompany"].ToString();
                DRName.Text = row["DRName"].ToString();
                DRAddress.Text = row["DRAddress"].ToString();
                DRGSTIN.Text = row["DRGSTIN"].ToString();
                DRState.Text = row["DRState"].ToString();
                DRStateCode.Text = row["DRStateCode"].ToString();
                Remarks.Text = row["Remarks"].ToString();

            }
            else {
                MessageBox.Show("Can't able to find the DC Details...!");
            }
        }

        private void comboBoxDCcategories_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(comboBoxDCcategories.Text))
            {
                if(comboBoxDCcategories.Text == "Returnable")
                {
                    comboBoxDCType.Items.Clear();
                    comboBoxDCType.Items.AddRange(new object[] {
                    "Rework",
                    "Repair",
                    "Repair",
                    "Job Work",
                    "Calibration",
                    "Trails",
                    "Inspection",
                    "Exhibitions & Subcontract 3rd party vendors"
                    });
                    //MessageBox.Show("Returnable updated");

                    ReturnDatelabel.Visible = true;
                    dateTimePicker2.Visible = true;

                }
                else
                {
                    comboBoxDCType.Items.Clear();
                    comboBoxDCType.Items.AddRange(new object[] {
                    "Short Shipments",
                    "FOC supply",
                    "samples returned",
                    "Scrap disposal"
                   
                    });
                    ReturnDatelabel.Visible = false;
                    dateTimePicker2.Visible = false;
                    // MessageBox.Show("NON-Returnable updated");

                }
            }
        }
    }
}
