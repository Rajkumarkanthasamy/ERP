﻿using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.IO;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.Diagnostics;

namespace Erp_Project_With_Buttons.Part_Reciept
{
    public partial class frmInventoryLedger : Form
    {
        frmForm2 frm = new frmForm2();
        Login.frmLoginForm LoginForm = new Login.frmLoginForm();
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        DataTable dtRepeatedItemList = new DataTable();
        DataTable dtMaterialLedger = new DataTable();
        DataTable dtTableFilter = new DataTable();
        DataView dvItemList = new DataView();
        DataTable dtItemList = new DataTable();
        DataTable GINInventoryLogs = new DataTable();
        DataTable IndentLogs = new DataTable();
        DataTable InventorFIFO = new DataTable();
        DataTable InventoryReturnLog = new DataTable();
        DataTable GINReverseInventoryLog = new DataTable();
        DataTable ScrapLogs = new DataTable();
        DataTable currentStockLog = new DataTable();
        DataTable IssueLogs = new DataTable();
        Boolean inventoryApplyFilter = false;
        public frmInventoryLedger()
        {
            InitializeComponent();
        }

        private void frmMaterialLedger_Load(object sender, EventArgs e)
        {
            chkItemCode.Checked = true;
            dtpfromdate.Format = DateTimePickerFormat.Custom;
            dtpfromdate.CustomFormat = "dd-MM-yyyy";
            dtptodate.Format = DateTimePickerFormat.Custom;
            dtptodate.CustomFormat = "dd-MM-yyyy";
            dtItemList = DAL.fnItemList(null).Tables[0];
            dtTableFilter = dtItemList;

            if (Convert.ToBoolean(LoginForm.GetUserDetails[16]) == true || Convert.ToBoolean(LoginForm.GetUserDetails[30]) == true || Convert.ToBoolean(LoginForm.GetUserDetails[29]) == true || Convert.ToBoolean(LoginForm.GetUserDetails[31]) == true || Convert.ToBoolean(LoginForm.GetUserDetails[32]) == true || LoginForm.GetUserDetails[2].ToLower() == "lizzy")    //  lblPrepareBy.Text.ToLower() == "hebbarrk")
            {
                dgvmaterialLedger.Columns[5].Visible = true;
                dgvmaterialLedger.Columns[6].Visible = true;
                lblrepeatCost.Visible = true;
                btnExportExcel.Visible = true;
            }
            else
            {
                dgvmaterialLedger.Columns[5].Visible = false;
                dgvmaterialLedger.Columns[6].Visible = false;
                lblrepeatCost.Visible = false;
                btnExportExcel.Visible = false;
            }
        }


        private void btnmaterialledger_Click(object sender, EventArgs e)
        {
            bAllLedger = false;
            dgvALLLedgerReport.Visible = false;
            dtpfromdate.Format = DateTimePickerFormat.Custom;
            dtpfromdate.CustomFormat = "yyyy-MM-dd";
            dtptodate.Format = DateTimePickerFormat.Custom;
            dtptodate.CustomFormat = "yyyy-MM-dd";

            var yesterday1 = dtpfromdate.Value.AddDays(-1);


            dtMaterialLedger = DAL.fnMaterialLedger(lblRepeatitemcode.Text, "2001-01-01", yesterday1.ToString("yyyy-MM-dd")).Tables[0];

            if (dtMaterialLedger.Rows.Count > 0)
            {
                DataView view = dtMaterialLedger.DefaultView;
                view.Sort = "date ASC";
                DataTable sortedDate = view.ToTable();
                dgvmaterialLedger.AutoGenerateColumns = false;
                // dgvmaterialLedger.DataSource = sortedDate;

                RecievedQTY = 0;
                IssuedQTY = 0;
                ReturnQTY = 0;
                StockAdjusted = 0;
                foreach (DataRow dgvr in dtMaterialLedger.Rows)
                {
                    RecievedQTY += Convert.ToDouble(dgvr["RecievedQty"].ToString());
                    IssuedQTY += Convert.ToDouble(dgvr["IssuedQty"].ToString());
                    ReturnQTY += Convert.ToDouble(dgvr["ReturnQty"].ToString());
                    StockAdjusted += Convert.ToDouble(dgvr["StockAdjsued"].ToString());
                }

                //lblrecievqty.Text = RecievedQTY.ToString();
                //lblissuedqty.Text = IssuedQTY.ToString();
                //lblreturnqty.Text = ReturnQTY.ToString();
                //lblStockAdjusted.Text = StockAdjusted.ToString();
                //lblRecipt.Text = RecievedQTY.ToString();
                //lblIssue.Text = IssuedQTY.ToString();
                //lblItemReturn.Text = ReturnQTY.ToString();
                //lblStockAdjused.Text = StockAdjusted.ToString();
                lblOpeningBalance.Text = (Convert.ToDouble(lblOpeningBalance.Text) + RecievedQTY + ReturnQTY - IssuedQTY + StockAdjusted).ToString();

            }
            else
            {
                dtMaterialLedger = DAL.fnMaterialLedger(lblRepeatitemcode.Text, "2001-01-01", null).Tables[0];
                if (dtMaterialLedger.Rows.Count > 0)
                {
                    lblOpeningBalance.Text = dtMaterialLedger.Rows[0]["OpeningQuantity"].ToString();
                    RecievedQTY = 0;
                    IssuedQTY = 0;
                    ReturnQTY = 0;
                    StockAdjusted = 0;
                    lblClosingStock.Text = (Convert.ToDouble(lblOpeningBalance.Text) + RecievedQTY + ReturnQTY - IssuedQTY + StockAdjusted).ToString();
                }
            }

            dtMaterialLedger = DAL.fnMaterialLedger(lblRepeatitemcode.Text, dtpfromdate.Text, dtptodate.Text).Tables[0];

            if (dtMaterialLedger.Rows.Count > 0)
            {
                DataView view = dtMaterialLedger.DefaultView;
                view.Sort = "date ASC";
                DataTable sortedDate = view.ToTable();
                dgvmaterialLedger.AutoGenerateColumns = false;
                // dgvmaterialLedger.DataSource = sortedDate;

                RecievedQTY = 0;
                IssuedQTY = 0;
                ReturnQTY = 0;
                StockAdjusted = 0;
                foreach (DataRow dgvr in dtMaterialLedger.Rows)
                {
                    RecievedQTY += Convert.ToDouble(dgvr["RecievedQty"].ToString());
                    IssuedQTY += Convert.ToDouble(dgvr["IssuedQty"].ToString());
                    ReturnQTY += Convert.ToDouble(dgvr["ReturnQty"].ToString());
                    StockAdjusted += Convert.ToDouble(dgvr["StockAdjsued"].ToString());
                }

                lblrecievqty.Text = RecievedQTY.ToString();
                lblissuedqty.Text = IssuedQTY.ToString();
                lblreturnqty.Text = ReturnQTY.ToString();
                lblStockAdjusted.Text = StockAdjusted.ToString();
                lblRecipt.Text = RecievedQTY.ToString();
                lblIssue.Text = IssuedQTY.ToString();
                lblItemReturn.Text = ReturnQTY.ToString();
                lblStockAdjused.Text = StockAdjusted.ToString();
                lblClosingStock.Text = (Convert.ToDouble(lblOpeningBalance.Text) + RecievedQTY + ReturnQTY - IssuedQTY + StockAdjusted).ToString();
            }
            else
            {
                //lblNoitems.Visible = true;
                //dgvmaterialLedger.DataSource = null;
                //lblrecievqty.Text = "0";
                //lblissuedqty.Text = "0";
                //lblreturnqty.Text = "0";
                //lblStockAdjusted.Text = "0";
                //lblStockAdjused.Text = "0";

                //lblRecipt.Text = "0";
                //lblIssue.Text = "0";
                //lblStockAdjused.Text = "0";
                //lblClosingStock.Text = "0";
            }

            dtpfromdate.Format = DateTimePickerFormat.Custom;
            dtpfromdate.CustomFormat = "dd-MM-yyyy";
            dtptodate.Format = DateTimePickerFormat.Custom;
            dtptodate.CustomFormat = "dd-MM-yyyy";
        }




        private void frmMaterialLedger_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            frm.Show();
        }


        #region Rowfilter Funtion to select Item
        private void RowFilter()
        {
            chklbItemList.Items.Clear();
            foreach (DataRowView dv in dvItemList)
            {
                chklbItemList.Items.Add(string.Concat(dv[17].ToString(), ") ", dv[0].ToString(), ", ", dv[1].ToString(), ", ", dv[12].ToString()));
            }
        }
        #endregion


        private void txtItemDescription_Enter(object sender, EventArgs e)
        {
        }

        private void txtItemDescription_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar == '%'))
            {
                e.Handled = true;
            }
        }
        private void txtItemDescription_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GlobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text.Trim());

                    RowFilter();

                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GlobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text.Trim());
                    RowFilter();
                }

            }
            else
            {
                if (chkItemCode.Checked == true)
                {
                    dvItemList = GlobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text.Trim());
                    RowFilter();
                }
                else if (chkItemDesc.Checked == true)
                {
                    dvItemList = GlobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text.Trim());
                    RowFilter();
                }

            }
        }

        //#region Excel App Release Object Function
        //private void releaseObject(object obj)
        //{
        //    try
        //    {
        //        System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
        //        obj = null;
        //    }
        //    catch (Exception ex)
        //    {
        //        obj = null;
        //        MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
        //    }
        //    finally
        //    {
        //        GC.Collect();
        //    }
        //}
        //#endregion



        string[] sItemCode;
        DataTable dtItemcode = new DataTable();
        double RecievedQTY;
        double IssuedQTY;
        double ReturnQTY;
        double StockAdjusted;


        //New code added for the create table
        private void chklbItemList_ItemCheck(object sender, ItemCheckEventArgs e)
        {

            try
            {
                bAllLedger = false;
                dgvALLLedgerReport.Visible = false;

                if (!chklbItemList.CheckedItems.Contains(chklbItemList.SelectedItem))
                {
                    sItemCode = chklbItemList.SelectedItem.ToString().Trim().Split(')');
                    string sID = sItemCode[0];
                    dtItemcode = DAL.fnStandardCostItemList(sID).Tables[0];

                    if (dtItemcode.Rows.Count > 0)
                    {

                        lblRepeatitemcode.Text = dtItemcode.Rows[0]["Itemcode"].ToString();
                        lblitemname.Text = dtItemcode.Rows[0]["ItemDescription"].ToString();
                        lblrepeatCost.Text = dtItemcode.Rows[0]["UnitCost"].ToString() + " Rs";
                        lblavailableqty.Text = dtItemcode.Rows[0]["AvailableQty"].ToString(); //+ " " + dtItemcode.Rows[0]["Units"].ToString()
                        lblOpeningBalance.Text = dtItemcode.Rows[0]["OpeningQuantity"].ToString();






                        IndentLogDataGrideView.Visible = false;
                        dataGridViewFIFOLog.Visible = false;
                        dataGridViewReturnLog.Visible = false;
                        dataGridViewScrapLog.Visible = false;
                        dataGridViewIssueLog.Visible = false;
                        dataGridViewGIN.Visible = true;
                        IndentLog.BackColor = Color.White;
                        IndentLog.ForeColor = Color.Black;
                        FIFOLog.BackColor = Color.White;
                        FIFOLog.ForeColor = Color.Black;
                        ScrapLog.BackColor = Color.White;
                        ScrapLog.ForeColor = Color.Black;
                        ReturnItem.BackColor = Color.White;
                        ReturnItem.ForeColor = Color.Black;
                        IssueLog.BackColor = Color.White;
                        IssueLog.ForeColor = Color.Black;
                        GINLog.BackColor = Color.Green;
                        GINLog.ForeColor = Color.White;

                        try
                        {
                            GINInventoryLogs = DAL.getItemBatchLocation(dtItemcode.Rows[0]["Itemcode"].ToString()).Tables[0];
                            // DAL.GetERPInventoryReceivedQty(dtItemcode.Rows[0]["Itemcode"].ToString(), "ReceivedQtY");
                            //DAL.GetERPInventoryReceivedQty(dtItemcode.Rows[0]["Itemcode"].ToString(), "RemainingQty");
                            //DAL.GetERPInventoryReceivedQty(dtItemcode.Rows[0]["Itemcode"].ToString(), "IssuedQty");
                            dataGridViewGIN.AutoGenerateColumns = false;


                            // Map DataTable columns to your DataGridView columns
                            dataGridViewGIN.Columns["GINNumber"].DataPropertyName = "GINNumber";
                            dataGridViewGIN.Columns["ItemCodeGIN"].DataPropertyName = "ItemCode";
                            dataGridViewGIN.Columns["CreateDateGIN"].DataPropertyName = "CreatedDate";
                            dataGridViewGIN.Columns["RefNumberGIN"].DataPropertyName = "POWONumber";
                            // dataGridViewGIN.Columns["BOMProjectCodeGIN"].DataPropertyName = "BOMProjectCode";
                            dataGridViewGIN.Columns["ProjectCodeGIN"].DataPropertyName = "ProjectCode";
                            dataGridViewGIN.Columns["ReceivedQtYGIN"].DataPropertyName = "ReceivedQtY";
                            dataGridViewGIN.Columns["RemainingQtyGIN"].DataPropertyName = "RemainingQty";
                            dataGridViewGIN.Columns["BatchCodeGIN"].DataPropertyName = "BatchCode";
                            dataGridViewGIN.Columns["LocationGIN"].DataPropertyName = "ItemLocation";
                            dataGridViewGIN.Columns["IndentQtyGIN"].DataPropertyName = "IndentQty";
                            dataGridViewGIN.Columns["IssuedQtyGIN"].DataPropertyName = "IssuedQty";

                            // Bind the data
                            dataGridViewGIN.DataSource = GINInventoryLogs;

                            inventoryAvailableQty.Text = "0";
                            inventoryIndentQty.Text = "0";
                            inventoryIssueQty.Text = "0";
                            inventoryReturnQty.Text = "0";
                            inventoryQuarantineQty.Text = "0";


                            try
                            {
                                double totalRemainingQty = DAL.fnGetTotalRemainingQty(lblRepeatitemcode.Text, null);
                                inventoryAvailableQty.Text = totalRemainingQty.ToString();
                            }
                            catch (Exception error)
                            {
                                MessageBox.Show(error.Message, "Inventory GIN");
                            }


                            try
                            {
                                double totalIndentQty = DAL.fnGetTotalIndentQty(lblRepeatitemcode.Text, null);
                                inventoryIndentQty.Text = totalIndentQty.ToString();
                            }
                            catch (Exception error)
                            {
                                MessageBox.Show(error.Message, "Inventory Indent");
                            }


                            try
                            {
                                double totalIssuedQty = DAL.fnGetTotalIssuedQty(lblRepeatitemcode.Text, null);
                                inventoryIssueQty.Text = totalIssuedQty.ToString();

                            }
                            catch (Exception error)
                            {
                                MessageBox.Show(error.Message, "Inventory Issue");
                            }


                            try
                            {
                                double totalReturnQty = DAL.fnGetTotalReturnQty(lblRepeatitemcode.Text, null);
                                inventoryReturnQty.Text = totalReturnQty.ToString();
                            }
                            catch (Exception error)
                            {
                                MessageBox.Show(error.Message, "Inventory Return");
                            }

                            try
                            {

                                double totalQuarantineQty = DAL.fnGetTotalQuarantineQty(lblRepeatitemcode.Text, null);
                                inventoryQuarantineQty.Text = totalQuarantineQty.ToString();
                            }
                            catch (Exception error)
                            {
                                MessageBox.Show(error.Message, "Inventory Quarantain");
                            }

                            try
                            {

                                double totalReceivedQty = DAL.fnGetTotalReceivedQty(lblRepeatitemcode.Text, null);
                                inventoryReceivedQty.Text = totalReceivedQty.ToString();
                            }
                            catch (Exception error)
                            {
                                MessageBox.Show(error.Message, "Inventory Received");
                            }

                            //fnGetTotalIssuedQty
                            //MessageBox.Show(totalRemainingQty.ToString());
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("chklbItemList_ItemCheck_This error, Item Not present in the Inventory table...!" + ex.Message);
                        }




                        dtMaterialLedger = DAL.fnMaterialLedger(lblRepeatitemcode.Text, null, null).Tables[0];
                        if (dtMaterialLedger.Rows.Count > 0)
                        {
                            lblNoitems.Visible = false;


                            DataView view = dtMaterialLedger.DefaultView;
                            view.Sort = "date ASC";
                            DataTable sortedDate = view.ToTable();

                            dgvmaterialLedger.AutoGenerateColumns = false;
                            // dgvmaterialLedger.DataSource = sortedDate;

                            RecievedQTY = 0;
                            IssuedQTY = 0;
                            ReturnQTY = 0;
                            StockAdjusted = 0;
                            foreach (DataRow dgvr in dtMaterialLedger.Rows)
                            {
                                RecievedQTY += Convert.ToDouble(dgvr["RecievedQty"].ToString());
                                IssuedQTY += Convert.ToDouble(dgvr["IssuedQty"].ToString());
                                ReturnQTY += Convert.ToDouble(dgvr["ReturnQty"].ToString());
                                StockAdjusted += Convert.ToDouble(dgvr["StockAdjsued"].ToString());
                            }
                            lblrecievqty.Text = RecievedQTY.ToString();
                            lblissuedqty.Text = IssuedQTY.ToString();
                            lblreturnqty.Text = ReturnQTY.ToString();
                            lblStockAdjusted.Text = StockAdjusted.ToString();
                            lblStockAdjusted.ForeColor = Color.Red;
                            lblRecipt.Text = RecievedQTY.ToString();
                            lblIssue.Text = IssuedQTY.ToString();
                            lblItemReturn.Text = ReturnQTY.ToString();
                            lblStockAdjused.Text = StockAdjusted.ToString();
                            lblClosingStock.Text = (Convert.ToDouble(lblOpeningBalance.Text) + RecievedQTY + ReturnQTY - IssuedQTY + StockAdjusted).ToString();

                        }
                        else
                        {
                            lblNoitems.Visible = true;
                            dgvmaterialLedger.DataSource = null;
                            lblrecievqty.Text = "0";
                            lblissuedqty.Text = "0";
                            lblreturnqty.Text = "0";
                            lblStockAdjusted.Text = "0";
                            lblStockAdjused.Text = "0";

                            lblRecipt.Text = "0";
                            lblIssue.Text = "0";
                            lblStockAdjused.Text = "0";
                            lblClosingStock.Text = "0";
                            //Below lables for Inventory 
                            inventoryAvailableQty.Text = "0";
                            inventoryIndentQty.Text = "0";
                            inventoryIssueQty.Text = "0";
                            inventoryReturnQty.Text = "0";
                            inventoryQuarantineQty.Text = "0";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("chklbItemList_ItemCheck" + ex.Message);
            }
        }

        private void chklbItemList_ItemCheck_old(object sender, ItemCheckEventArgs e)
        {
            try
            {
                bAllLedger = false;
                dgvALLLedgerReport.Visible = false;
                if (!chklbItemList.CheckedItems.Contains(chklbItemList.SelectedItem))
                {
                    sItemCode = chklbItemList.SelectedItem.ToString().Trim().Split(')');
                    string sID = sItemCode[0];
                    MessageBox.Show(sID, "selected item code");
                    dtItemcode = DAL.fnStandardCostItemList(sID).Tables[0];

                    if (dtItemcode.Rows.Count > 0)
                    {
                        MessageBox.Show(dtItemcode.Rows[0]["Itemcode"].ToString(), "Complete Item Code!");

                        lblRepeatitemcode.Text = dtItemcode.Rows[0]["Itemcode"].ToString();
                        lblitemname.Text = dtItemcode.Rows[0]["ItemDescription"].ToString();
                        lblrepeatCost.Text = dtItemcode.Rows[0]["UnitCost"].ToString() + " Rs";
                        lblavailableqty.Text = dtItemcode.Rows[0]["AvailableQty"].ToString(); //+ " " + dtItemcode.Rows[0]["Units"].ToString()
                        lblOpeningBalance.Text = dtItemcode.Rows[0]["OpeningQuantity"].ToString();

                        dtMaterialLedger = DAL.fnMaterialLedger(lblRepeatitemcode.Text, null, null).Tables[0];
                        if (dtMaterialLedger.Rows.Count > 0)
                        {
                            lblNoitems.Visible = false;


                            DataView view = dtMaterialLedger.DefaultView;
                            view.Sort = "date ASC";
                            DataTable sortedDate = view.ToTable();

                            dgvmaterialLedger.AutoGenerateColumns = false;
                            // dgvmaterialLedger.DataSource = sortedDate;

                            RecievedQTY = 0;
                            IssuedQTY = 0;
                            ReturnQTY = 0;
                            StockAdjusted = 0;
                            foreach (DataRow dgvr in dtMaterialLedger.Rows)
                            {
                                RecievedQTY += Convert.ToDouble(dgvr["RecievedQty"].ToString());
                                IssuedQTY += Convert.ToDouble(dgvr["IssuedQty"].ToString());
                                ReturnQTY += Convert.ToDouble(dgvr["ReturnQty"].ToString());
                                StockAdjusted += Convert.ToDouble(dgvr["StockAdjsued"].ToString());
                            }
                            lblrecievqty.Text = RecievedQTY.ToString();
                            lblissuedqty.Text = IssuedQTY.ToString();
                            lblreturnqty.Text = ReturnQTY.ToString();
                            lblStockAdjusted.Text = StockAdjusted.ToString();
                            lblRecipt.Text = RecievedQTY.ToString();
                            lblIssue.Text = IssuedQTY.ToString();
                            lblItemReturn.Text = ReturnQTY.ToString();
                            lblStockAdjused.Text = StockAdjusted.ToString();
                            lblClosingStock.Text = (Convert.ToDouble(lblOpeningBalance.Text) + RecievedQTY + ReturnQTY - IssuedQTY + StockAdjusted).ToString();

                        }
                        else
                        {
                            lblNoitems.Visible = true;
                            dgvmaterialLedger.DataSource = null;
                            lblrecievqty.Text = "0";
                            lblissuedqty.Text = "0";
                            lblreturnqty.Text = "0";
                            lblStockAdjusted.Text = "0";
                            lblStockAdjused.Text = "0";

                            lblRecipt.Text = "0";
                            lblIssue.Text = "0";
                            lblStockAdjused.Text = "0";
                            lblClosingStock.Text = "0";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("chklbItemList_ItemCheck" + ex.Message);
            }
        }

        //this button for change the tap

        private void fnIndentLog()
        {

            Vendorlb.Visible = false;
            inventoryVendorTextBox.Visible = false;
            flLocation.Visible = false;
            inventoryLocationtextBox.Visible = false;

            dataGridViewGIN.Visible = false;
            dataGridViewFIFOLog.Visible = false;
            IndentLogDataGrideView.Visible = true;
            dataGridViewScrapLog.Visible = false;
            dataGridViewReturnLog.Visible = false;
            dataGridViewIssueLog.Visible = false;
            currentStockdataGridView.Visible = false;
            dataGridViewGINReverse.Visible = false;

            currentStock.ForeColor = Color.Black;
            currentStock.BackColor = Color.White;
            IndentLog.BackColor = Color.Green;
            IndentLog.ForeColor = Color.White;
            GINLog.BackColor = Color.White;
            GINLog.ForeColor = Color.Black;
            FIFOLog.BackColor = Color.White;
            FIFOLog.ForeColor = Color.Black;
            ScrapLog.BackColor = Color.White;
            ScrapLog.ForeColor = Color.Black;
            IssueLog.BackColor = Color.White;
            IssueLog.ForeColor = Color.Black;
            ReturnItem.BackColor = Color.White;
            ReturnItem.ForeColor = Color.Black;
            GINReverse.ForeColor = Color.Black;
            GINReverse.BackColor = Color.White;

            panel4.Visible = false;
            panel3.Visible = true;
            comboBox1.Visible = true;
            label8.Visible = true;
            label11.Visible = true;
            indentNotextBox.Visible = true;





            try
            {

                //IndentLogs = DAL.fnGetIndentERPInventorylog(lblRepeatitemcode.Text).Tables[0];

                try
                {
                    string fromDate = inventoryFromIndateTimePicker.Checked ? inventoryFromIndateTimePicker.Text : null;
                    string toDate = inventoryToDateTimePicker.Checked ? inventoryToDateTimePicker.Text : null;

                    // string vendor = string.IsNullOrWhiteSpace(inventoryVendorTextBox.Text) ? null : inventoryVendorTextBox.Text;
                    string project = string.IsNullOrWhiteSpace(inventoryProjectTextBox.Text) ? null : inventoryProjectTextBox.Text;
                    //string location = string.IsNullOrWhiteSpace(inventoryLocationtextBox.Text) ? null : inventoryLocationtextBox.Text;
                    string category = string.IsNullOrWhiteSpace(inventoryCategoryTextBox.Text) ? null : inventoryCategoryTextBox.Text;
                    string status = string.IsNullOrWhiteSpace(comboBox1.Text) ? null : comboBox1.Text;
                    string indentNumber = string.IsNullOrWhiteSpace(indentNotextBox.Text) ? null : indentNotextBox.Text;

                    // Call your DAL method

                    //MessageBox.Show(fromDate, "FROM DATE!");

                    //IndentLogs = DAL.fnGetFilteredIndentERPInventorylogtest(fromDate, toDate, project, category).Tables["FilteredData"];

                    DataSet indentDetails = DAL.fnGetFilteredIndentERPInventorylogtest(fromDate, toDate, project, category, status, indentNumber);

                    IndentLogs = indentDetails.Tables["FilteredData"];

                    string totalQty = indentDetails.Tables["TotalIndentQty"].Rows[0]["TotalIndentQty"].ToString();

                    //  MessageBox.Show("Total Indent Quantity: " + totalQty);

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message + "\n\nStack Trace:\n" + ex.StackTrace);
                }




                if (!IndentLogs.Columns.Contains("IndentFIFO"))
                    IndentLogs.Columns.Add("IndentFIFO");

                foreach (DataRow IndentLog in IndentLogs.Rows)
                {
                    IndentLog["IndentFIFO"] = "✔";

                }


                IndentLogDataGrideView.AutoGenerateColumns = false;
                IndentLogDataGrideView.Columns["IndentNo"].DataPropertyName = "IndentNo";
                IndentLogDataGrideView.Columns["IndentItemCode"].DataPropertyName = "ItemCode";
                IndentLogDataGrideView.Columns["IndentProjectCode"].DataPropertyName = "ProjectCode";
                IndentLogDataGrideView.Columns["IndentBy"].DataPropertyName = "IndentBy";
                IndentLogDataGrideView.Columns["IndentDate"].DataPropertyName = "IndentDate";
                IndentLogDataGrideView.Columns["IndentQty"].DataPropertyName = "IndentQty";
                IndentLogDataGrideView.Columns["IndentStatus"].DataPropertyName = "Status";
                IndentLogDataGrideView.Columns["GINNumberIndent"].DataPropertyName = "GINNumber";
                IndentLogDataGrideView.Columns["BatchCodeIndent"].DataPropertyName = "BatchCode";
                IndentLogDataGrideView.Columns["LocationIndent"].DataPropertyName = "Location";
                IndentLogDataGrideView.Columns["PickedLocationIndent"].DataPropertyName = "PickedLocation";
                IndentLogDataGrideView.Columns["PickedBatchCodeIndent"].DataPropertyName = "PickedBatchCode";
                IndentLogDataGrideView.Columns["IndentFIFO"].DataPropertyName = "IndentFIFO";
                IndentLogDataGrideView.DataSource = IndentLogs;

                foreach (DataGridViewRow row in IndentLogDataGrideView.Rows)
                {
                    if (row.Cells["IndentFIFO"].Value?.ToString() == "✔")
                        //row.Cells["IndentFIFO"].Style.BackColor = Color.Green;
                        row.Cells["IndentFIFO"].Style.ForeColor = Color.Green;

                    else
                        row.Cells["IndentFIFO"].Style.ForeColor = Color.Red;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("chklbItemList_ItemCheck_This error, Item Not present in the Inventory Indent table...!" + ex.Message);
            }
        }


        private void fnGINLog()
        {

            Vendorlb.Visible = true;
            inventoryVendorTextBox.Visible = true;
            flLocation.Visible = true;
            inventoryLocationtextBox.Visible = true;

            IndentLogDataGrideView.Visible = false;
            dataGridViewFIFOLog.Visible = false;
            dataGridViewReturnLog.Visible = false;
            dataGridViewScrapLog.Visible = false;
            dataGridViewGINReverse.Visible = false;

            dataGridViewIssueLog.Visible = false;
            dataGridViewGIN.Visible = true;

            currentStockdataGridView.Visible = false;
            currentStock.ForeColor = Color.Black;
            currentStock.BackColor = Color.White;

            IndentLog.BackColor = Color.White;
            IndentLog.ForeColor = Color.Black;
            FIFOLog.BackColor = Color.White;
            FIFOLog.ForeColor = Color.Black;
            ReturnItem.BackColor = Color.White;
            ReturnItem.ForeColor = Color.Black;
            ScrapLog.BackColor = Color.White;
            ScrapLog.ForeColor = Color.Black;
            IssueLog.BackColor = Color.White;
            IssueLog.ForeColor = Color.Black;
            GINLog.BackColor = Color.Green;
            GINLog.ForeColor = Color.White;
            GINReverse.ForeColor = Color.Black;
            GINReverse.BackColor = Color.White;

            panel4.Visible = false;
            panel3.Visible = true;
            comboBox1.Visible = false;
            label8.Visible = false;
            label11.Visible = false;
            indentNotextBox.Visible = false;

            try
            {
                //GINInventoryLogs = DAL.getItemBatchLocation(dtItemcode.Rows[0]["Itemcode"].ToString()).Tables[0];


                try
                {
                    string fromDate = inventoryFromIndateTimePicker.Checked ? inventoryFromIndateTimePicker.Text : null;
                    string toDate = inventoryToDateTimePicker.Checked ? inventoryToDateTimePicker.Text : null;

                    string vendor = string.IsNullOrWhiteSpace(inventoryVendorTextBox.Text) ? null : inventoryVendorTextBox.Text;
                    string project = string.IsNullOrWhiteSpace(inventoryProjectTextBox.Text) ? null : inventoryProjectTextBox.Text;
                    string location = string.IsNullOrWhiteSpace(inventoryLocationtextBox.Text) ? null : inventoryLocationtextBox.Text;
                    string category = string.IsNullOrWhiteSpace(inventoryCategoryTextBox.Text) ? null : inventoryCategoryTextBox.Text;

                    // Call your DAL method
                    GINInventoryLogs = DAL.fnGetFilteredERPInventoryLog(fromDate, toDate, vendor, project, location, category).Tables[0];
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message + "\n\nStack Trace:\n" + ex.StackTrace);
                }

                dataGridViewGIN.AutoGenerateColumns = false;


                // Map DataTable columns to your DataGridView columns
                dataGridViewGIN.Columns["GINNumber"].DataPropertyName = "GINNumber";
                dataGridViewGIN.Columns["ItemCodeGIN"].DataPropertyName = "ItemCode";
                dataGridViewGIN.Columns["CreateDateGIN"].DataPropertyName = "CreatedDate";
                dataGridViewGIN.Columns["RefNumberGIN"].DataPropertyName = "POWONumber";
                //dataGridViewGIN.Columns["BOMProjectCodeGIN"].DataPropertyName = "BOMProjectCode";
                dataGridViewGIN.Columns["ProjectCodeGIN"].DataPropertyName = "ProjectCode";
                dataGridViewGIN.Columns["POQtYGIN"].DataPropertyName = "POQty";
                dataGridViewGIN.Columns["ReceivedQtYGIN"].DataPropertyName = "ReceivedQtY";
                dataGridViewGIN.Columns["RemainingQtyGIN"].DataPropertyName = "RemainingQty";

                dataGridViewGIN.Columns["unitCostGIN"].DataPropertyName = "UnitCost";
                dataGridViewGIN.Columns["SGSTGIN"].DataPropertyName = "SGST";
                dataGridViewGIN.Columns["CGSTGIN"].DataPropertyName = "CGST";
                dataGridViewGIN.Columns["IGSTGIN"].DataPropertyName = "IGST";
                dataGridViewGIN.Columns["POAmountGIN"].DataPropertyName = "POAmount";

                dataGridViewGIN.Columns["BatchCodeGIN"].DataPropertyName = "BatchCode";
                dataGridViewGIN.Columns["LocationGIN"].DataPropertyName = "ItemLocation";
                dataGridViewGIN.Columns["IndentQtyGIN"].DataPropertyName = "IndentQty";
                dataGridViewGIN.Columns["IssuedQtyGIN"].DataPropertyName = "IssuedQty";
                dataGridViewGIN.Columns["QRPrintStatus"].DataPropertyName = "QRPrinte";


                // Bind the data
                dataGridViewGIN.DataSource = GINInventoryLogs;
            }
            catch (Exception ex)
            {
                MessageBox.Show("chklbItemList_ItemCheck_This error, Item Not present in the Inventory table...!" + ex.Message);
            }
        }


        private void fnFIFOLog()
        {
            try
            {
                Vendorlb.Visible = false;
                inventoryVendorTextBox.Visible = false;
                flLocation.Visible = false;
                inventoryLocationtextBox.Visible = false;
                dataGridViewGINReverse.Visible = false;

                dataGridViewGIN.Visible = false;
                IndentLogDataGrideView.Visible = false;
                dataGridViewReturnLog.Visible = false;
                dataGridViewScrapLog.Visible = false;
                dataGridViewIssueLog.Visible = false;
                dataGridViewFIFOLog.Visible = true;
                currentStockdataGridView.Visible = false;
                currentStock.ForeColor = Color.Black;
                currentStock.BackColor = Color.White;
                IndentLog.BackColor = Color.White;
                IndentLog.ForeColor = Color.Black;
                GINLog.BackColor = Color.White;
                GINLog.ForeColor = Color.Black;
                ReturnItem.BackColor = Color.White;
                ReturnItem.ForeColor = Color.Black;
                ScrapLog.BackColor = Color.White;
                ScrapLog.ForeColor = Color.Black;
                IssueLog.BackColor = Color.White;
                IssueLog.ForeColor = Color.Black;
                FIFOLog.BackColor = Color.Green;
                FIFOLog.ForeColor = Color.White;
                GINReverse.ForeColor = Color.Black;
                GINReverse.BackColor = Color.White;

                panel4.Visible = false;
                panel3.Visible = true;
                comboBox1.Visible = false;
                label8.Visible = false;
                label11.Visible = false;
                indentNotextBox.Visible = false;


                string fromDate = inventoryFromIndateTimePicker.Checked ? inventoryFromIndateTimePicker.Text : null;
                string toDate = inventoryToDateTimePicker.Checked ? inventoryToDateTimePicker.Text : null;
                string project = string.IsNullOrWhiteSpace(inventoryProjectTextBox.Text) ? null : inventoryProjectTextBox.Text;
                string category = string.IsNullOrWhiteSpace(inventoryCategoryTextBox.Text) ? null : inventoryCategoryTextBox.Text;



                InventorFIFO = DAL.fnGetFilteredERPInventoryFIFOLogs(fromDate, toDate, project, category).Tables[0];
                //InventorFIFO = DAL.fnGetERPInventoryFIFOLogs(lblRepeatitemcode.Text, null).Tables[0];


                foreach (DataRow row in InventorFIFO.Rows)
                {
                    //MessageBox.Show(row["ItemCode"].ToString());

                    if (row["FIFOFollowed"].ToString() == "true")
                    {
                        row["FIFOFollowed"] = "✔";
                    }
                    else
                    {
                        row["FIFOFollowed"] = "❌";
                    }

                }
                dataGridViewFIFOLog.AutoGenerateColumns = false;
                dataGridViewFIFOLog.Columns["FIFOFollowed"].DataPropertyName = "FIFOFollowed";
                dataGridViewFIFOLog.Columns["ItemCodeFIFO"].DataPropertyName = "ItemCode";
                dataGridViewFIFOLog.Columns["IndentNoFIFO"].DataPropertyName = "IndentNo";
                dataGridViewFIFOLog.Columns["IndentQtyFIFO"].DataPropertyName = "IndentQty";
                dataGridViewFIFOLog.Columns["ProjectCodeFIFO"].DataPropertyName = "ProjectCode";
                dataGridViewFIFOLog.Columns["RemarksFIFO"].DataPropertyName = "Remarks";
                dataGridViewFIFOLog.Columns["GINNumberFIFO"].DataPropertyName = "GINNumber";
                dataGridViewFIFOLog.Columns["BatchCodeFIFO"].DataPropertyName = "BatchCode";
                dataGridViewFIFOLog.Columns["LocationFIFO"].DataPropertyName = "Location";
                dataGridViewFIFOLog.Columns["PickedBatchCodeFIFO"].DataPropertyName = "PickedBatchCode";
                dataGridViewFIFOLog.Columns["PickedLocationFIFO"].DataPropertyName = "PickedLocation";
                dataGridViewFIFOLog.Columns["IssuedByFIFO"].DataPropertyName = "IssuedBy";
                dataGridViewFIFOLog.Columns["IndentPickedByFIFO"].DataPropertyName = "IndentPickedBy";
                dataGridViewFIFOLog.Columns["CreateDateFIFO"].DataPropertyName = "CreateDate";
                dataGridViewFIFOLog.DataSource = InventorFIFO;
                foreach (DataGridViewRow row in dataGridViewFIFOLog.Rows)
                {
                    if (row.Cells["FIFOFollowed"].Value?.ToString() == "✔")
                    {
                        // row.Cells["FIFOFollowed"].Style.BackColor = Color.Green;
                        row.Cells["FIFOFollowed"].Style.ForeColor = Color.Green;
                    }
                    else
                    {
                        // row.Cells["FIFOFollowed"].Style.BackColor = Color.Red;
                        row.Cells["FIFOFollowed"].Style.ForeColor = Color.Red;

                    }
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show("chklbItemList_ItemCheck_This error, Item Not present in the Inventory table...!" + ex.Message);
            }
        }

        private void fnIssueLog()
        {
            try
            {

                Vendorlb.Visible = false;
                inventoryVendorTextBox.Visible = false;
                flLocation.Visible = false;
                inventoryLocationtextBox.Visible = false;

                dataGridViewGIN.Visible = false;
                IndentLogDataGrideView.Visible = false;
                dataGridViewGINReverse.Visible = false;

                dataGridViewFIFOLog.Visible = false;
                dataGridViewReturnLog.Visible = false;
                dataGridViewScrapLog.Visible = false;
                dataGridViewIssueLog.Visible = true;
                currentStockdataGridView.Visible = false;
                currentStock.ForeColor = Color.Black;
                currentStock.BackColor = Color.White;
                IndentLog.BackColor = Color.White;
                IndentLog.ForeColor = Color.Black;
                GINLog.BackColor = Color.White;
                GINLog.ForeColor = Color.Black;
                FIFOLog.BackColor = Color.White;
                FIFOLog.ForeColor = Color.Black;
                ReturnItem.BackColor = Color.White;
                ReturnItem.ForeColor = Color.Black;
                ScrapLog.BackColor = Color.White;
                ScrapLog.ForeColor = Color.Black;
                IssueLog.BackColor = Color.Green;
                IssueLog.ForeColor = Color.White;
                GINReverse.ForeColor = Color.Black;
                GINReverse.BackColor = Color.White;

                panel4.Visible = false;
                panel3.Visible = true;
                comboBox1.Visible = false;
                label8.Visible = false;
                label11.Visible = false;
                indentNotextBox.Visible = false;



                string fromDate = inventoryFromIndateTimePicker.Checked ? inventoryFromIndateTimePicker.Text : null;
                string toDate = inventoryToDateTimePicker.Checked ? inventoryToDateTimePicker.Text : null;
                string project = string.IsNullOrWhiteSpace(inventoryProjectTextBox.Text) ? null : inventoryProjectTextBox.Text;
                string category = string.IsNullOrWhiteSpace(inventoryCategoryTextBox.Text) ? null : inventoryCategoryTextBox.Text;


                IssueLogs = DAL.fnGetFilteredERPInventoryIssueLogs(fromDate, toDate, project, category).Tables[0];

                //IssueLogs = DAL.fnGetERPInventoryIssueLogs(lblRepeatitemcode.Text, null).Tables[0];


                dataGridViewIssueLog.AutoGenerateColumns = false;



                dataGridViewIssueLog.Columns["IssueLog_ItemCode"].DataPropertyName = "ItemCode";
                dataGridViewIssueLog.Columns["IssueLog_IndentNo"].DataPropertyName = "IndentNo";
                dataGridViewIssueLog.Columns["IssueLog_ProjectCode"].DataPropertyName = "ProjectCode";
                dataGridViewIssueLog.Columns["IssueLog_IndentBy"].DataPropertyName = "IndentBy";
                dataGridViewIssueLog.Columns["IssueLog_IndentQty"].DataPropertyName = "IndentQty";
                dataGridViewIssueLog.Columns["IssueLog_IssuedQuantity"].DataPropertyName = "IssuedQuantity";
                dataGridViewIssueLog.Columns["IssueLog_IssueType"].DataPropertyName = "IssueType";
                dataGridViewIssueLog.Columns["IssueLog_Remarks"].DataPropertyName = "Remarks";
                dataGridViewIssueLog.Columns["IssueLog_Status"].DataPropertyName = "Status";
                dataGridViewIssueLog.Columns["IssueLog_ProjectBOMCode"].DataPropertyName = "ProjectBOMCode";
                dataGridViewIssueLog.Columns["IssueLog_ProductNo"].DataPropertyName = "ProductNo";
                dataGridViewIssueLog.Columns["IssueLog_GINNumber"].DataPropertyName = "GINNumber";
                dataGridViewIssueLog.Columns["IssueLog_BatchCode"].DataPropertyName = "BatchCode";
                dataGridViewIssueLog.Columns["IssueLog_Location"].DataPropertyName = "Location";
                dataGridViewIssueLog.Columns["IssueLog_IssuedServerDate"].DataPropertyName = "IssuedServerDate";
                dataGridViewIssueLog.Columns["IssueLog_IssuedBy"].DataPropertyName = "IssuedBy";//IssueLog_IssuedBy

                // Finally, bind the data
                dataGridViewIssueLog.DataSource = IssueLogs;


            }
            catch (Exception ex)
            {
                MessageBox.Show("chklbItemList_ItemCheck_This error, Return Item Log Not present in the Inventory table...!" + ex.Message);
            }
        }

        private void fnReturnItemLog()
        {
            try
            {

                Vendorlb.Visible = false;
                inventoryVendorTextBox.Visible = false;
                flLocation.Visible = false;
                inventoryLocationtextBox.Visible = false;

                dataGridViewGIN.Visible = false;
                dataGridViewGINReverse.Visible = false;

                IndentLogDataGrideView.Visible = false;
                dataGridViewFIFOLog.Visible = false;
                dataGridViewScrapLog.Visible = false;
                dataGridViewIssueLog.Visible = false;
                dataGridViewReturnLog.Visible = true;
                currentStockdataGridView.Visible = false;
                currentStock.ForeColor = Color.Black;
                currentStock.BackColor = Color.White;
                IndentLog.BackColor = Color.White;
                IndentLog.ForeColor = Color.Black;
                GINLog.BackColor = Color.White;
                GINLog.ForeColor = Color.Black;
                FIFOLog.BackColor = Color.White;
                FIFOLog.ForeColor = Color.Black;
                ScrapLog.BackColor = Color.White;
                ScrapLog.ForeColor = Color.Black;
                IssueLog.BackColor = Color.White;
                IssueLog.ForeColor = Color.Black;
                ReturnItem.BackColor = Color.Green;
                ReturnItem.ForeColor = Color.White;
                GINReverse.ForeColor = Color.Black;
                GINReverse.BackColor = Color.White;

                panel4.Visible = false;
                panel3.Visible = true;
               


                string fromDate = inventoryFromIndateTimePicker.Checked ? inventoryFromIndateTimePicker.Text : null;
                string toDate = inventoryToDateTimePicker.Checked ? inventoryToDateTimePicker.Text : null;
                string project = string.IsNullOrWhiteSpace(inventoryProjectTextBox.Text) ? null : inventoryProjectTextBox.Text;
                string category = string.IsNullOrWhiteSpace(inventoryCategoryTextBox.Text) ? null : inventoryCategoryTextBox.Text;
               


                InventoryReturnLog = DAL.fnGetFilteredERPInventoryReturnLogs(fromDate, toDate, project, category).Tables[0];
                // InventoryReturnLog = DAL.fnGetERPInventoryReturnLogs(lblRepeatitemcode.Text, null).Tables[0];

                dataGridViewReturnLog.AutoGenerateColumns = false;
                dataGridViewReturnLog.Columns["ReturnItemCode"].DataPropertyName = "ItemCode";
                dataGridViewReturnLog.Columns["ReturnIndentNo"].DataPropertyName = "IndentNo";
                dataGridViewReturnLog.Columns["ReturnProjectCode"].DataPropertyName = "ProjectCode";
                dataGridViewReturnLog.Columns["ReturnQuantity"].DataPropertyName = "Quantity";
                dataGridViewReturnLog.Columns["ReturnCreateDate"].DataPropertyName = "CreateDate";
                dataGridViewReturnLog.Columns["ReturnedBy"].DataPropertyName = "ReturnedBy";
                dataGridViewReturnLog.Columns["ReturnProjectStatus"].DataPropertyName = "ProjectStatus";
                dataGridViewReturnLog.Columns["ReturnGINNumber"].DataPropertyName = "GINNumber";
                dataGridViewReturnLog.Columns["ReturnBatchCode"].DataPropertyName = "BatchCode";
                dataGridViewReturnLog.Columns["ReturnLocation"].DataPropertyName = "Location";
                dataGridViewReturnLog.Columns["ReturnVendorCode"].DataPropertyName = "VendorCode";
                dataGridViewReturnLog.Columns["ReturnType"].DataPropertyName = "ReturnType";


                dataGridViewReturnLog.DataSource = InventoryReturnLog;


            }
            catch (Exception ex)
            {
                MessageBox.Show("chklbItemList_ItemCheck_This error, Return Item Log Not present in the Inventory table...!" + ex.Message);
            }
        }


        private void fnScrapLog()
        {

            try
            {

                Vendorlb.Visible = false;
                inventoryVendorTextBox.Visible = false;
                flLocation.Visible = false;
                inventoryLocationtextBox.Visible = false;

                panel4.Visible = false;
                panel3.Visible = true;


                dataGridViewGIN.Visible = false;
                IndentLogDataGrideView.Visible = false;
                dataGridViewFIFOLog.Visible = false;
                dataGridViewReturnLog.Visible = false;
                dataGridViewIssueLog.Visible = false;
                dataGridViewGINReverse.Visible = false;

                dataGridViewScrapLog.Visible = true;
                currentStockdataGridView.Visible = false;
                currentStock.ForeColor = Color.Black;
                currentStock.BackColor = Color.White;
                IndentLog.BackColor = Color.White;
                IndentLog.ForeColor = Color.Black;
                GINLog.BackColor = Color.White;
                GINLog.ForeColor = Color.Black;
                FIFOLog.BackColor = Color.White;
                FIFOLog.ForeColor = Color.Black;
                ReturnItem.BackColor = Color.White;
                ReturnItem.ForeColor = Color.Black;
                IssueLog.BackColor = Color.White;
                IssueLog.ForeColor = Color.Black;
                ScrapLog.BackColor = Color.Green;
                ScrapLog.ForeColor = Color.White;
                GINReverse.ForeColor = Color.Black;
                GINReverse.BackColor = Color.White;



                // ScrapLogs = DAL.fnGetERPInventoryScrapLogs(lblRepeatitemcode.Text, null).Tables[0];

                string fromDate = inventoryFromIndateTimePicker.Checked ? inventoryFromIndateTimePicker.Text : null;
                string toDate = inventoryToDateTimePicker.Checked ? inventoryToDateTimePicker.Text : null;
                string project = string.IsNullOrWhiteSpace(inventoryProjectTextBox.Text) ? null : inventoryProjectTextBox.Text;
                string category = string.IsNullOrWhiteSpace(inventoryCategoryTextBox.Text) ? null : inventoryCategoryTextBox.Text;

                ScrapLogs = DAL.fnGetFilteredERPInventoryScrapLogs(fromDate, toDate, project, category).Tables[0];





                dataGridViewScrapLog.AutoGenerateColumns = false;
                dataGridViewScrapLog.Columns["ScrapItemCode"].DataPropertyName = "ItemCode";
                dataGridViewScrapLog.Columns["ScrapIndentNo"].DataPropertyName = "IndentNo";
                dataGridViewScrapLog.Columns["ScrapProjectCode"].DataPropertyName = "ProjectCode";
                dataGridViewScrapLog.Columns["ScrapQuantity"].DataPropertyName = "Quantity";
                dataGridViewScrapLog.Columns["ScrapCreateDate"].DataPropertyName = "CreateDate";
                dataGridViewScrapLog.Columns["ScrapReturnedBy"].DataPropertyName = "ReturnedBy";
                dataGridViewScrapLog.Columns["ScrapProjectStatus"].DataPropertyName = "ProjectStatus";
                dataGridViewScrapLog.Columns["ScrapGINNumber"].DataPropertyName = "GINNumber";
                dataGridViewScrapLog.Columns["ScrapBatchCode"].DataPropertyName = "BatchCode";
                dataGridViewScrapLog.Columns["ScrapLocation"].DataPropertyName = "Location";
                dataGridViewScrapLog.Columns["ScrapReturnType"].DataPropertyName = "ReturnType";



                dataGridViewScrapLog.DataSource = ScrapLogs;



            }

            catch (Exception ex)
            {
                MessageBox.Show("chklbItemList_ItemCheck_This error, Return Item Log Not present in the Inventory table...!" + ex.Message);
            }
        }

        private void fnCurrentStock()
        {
            try
            {

                dataGridViewGIN.Visible = false;
                IndentLogDataGrideView.Visible = false;
                dataGridViewFIFOLog.Visible = false;
                dataGridViewReturnLog.Visible = false;
                dataGridViewIssueLog.Visible = false;
                dataGridViewScrapLog.Visible = false;
                dataGridViewGINReverse.Visible = false;

                currentStockdataGridView.Visible = true;
                panel4.Visible = true;





                IndentLog.BackColor = Color.White;
                IndentLog.ForeColor = Color.Black;
                GINLog.BackColor = Color.White;
                GINLog.ForeColor = Color.Black;
                FIFOLog.BackColor = Color.White;
                FIFOLog.ForeColor = Color.Black;
                ReturnItem.BackColor = Color.White;
                ReturnItem.ForeColor = Color.Black;
                IssueLog.BackColor = Color.White;
                IssueLog.ForeColor = Color.Black;
                ScrapLog.BackColor = Color.White;
                ScrapLog.ForeColor = Color.Black;
                currentStock.ForeColor = Color.White;
                currentStock.BackColor = Color.Green;
                GINReverse.ForeColor = Color.Black;
                GINReverse.BackColor = Color.White;

                //currentstockItemCodeTextBox
                //currentStockLocationTextBox
                //currentStockUnitCostTextBox
                //currentStockStockCostTextBox

                string ItemCodes = string.IsNullOrWhiteSpace(currentstockItemCodeTextBox.Text) ? null : currentstockItemCodeTextBox.Text;
                string unitCost = string.IsNullOrWhiteSpace(currentStockUnitCostTextBox.Text) ? null : currentStockUnitCostTextBox.Text;
                string StockCost = string.IsNullOrWhiteSpace(currentStockStockCostTextBox.Text) ? null : currentStockStockCostTextBox.Text;

                // MessageBox.Show(unitCost);
                DataSet currentStockData = DAL.fnGetFilteredERPInventoryCurrentStock(ItemCodes, null, unitCost, StockCost);
                //FilteredData // .Tables["TotalIndentQty"].Rows[0]["TotalIndentQty"].ToString();
                currentStockLog = currentStockData.Tables["FilteredData"];
                inventoryAvailableQty.Text = currentStockData.Tables["TotalAvailableQty"].Rows[0]["TotalAvailableQty"].ToString();
                // MessageBox.Show(currentStockData.Tables["TotalAvailableQty"].Rows[0]["TotalAvailableQty"].ToString(), "Current Stock AvailableQty!");
                //MessageBox.Show(currentStockData.Tables["TotalStockValue"].Rows[0]["TotalStockValue"].ToString(), "Current Stock TotalUnitCost!");//TotalUnitCost
                currentStockdataGridView.AutoGenerateColumns = false;


                //this.currentStockUnitCost,
                // this.currentStockFixedCost,
                //this.curretnStockPurchaseType,
                //this.currentStockCreatedB


                currentStockdataGridView.Columns["stockItemCode"].DataPropertyName = "ItemCode";
                currentStockdataGridView.Columns["stockItemDescription"].DataPropertyName = "ItemDescription";
                currentStockdataGridView.Columns["stockLocation"].DataPropertyName = "ProjectCode";
                currentStockdataGridView.Columns["currentStockUnitCost"].DataPropertyName = "UnitCost";
                currentStockdataGridView.Columns["currentStockAvailableQty"].DataPropertyName = "AvailableQty";
                currentStockdataGridView.Columns["curretnStockPurchaseType"].DataPropertyName = "PurchaseType";
                currentStockdataGridView.Columns["currentStockCreatedBy"].DataPropertyName = "CreatedBy";
                currentStockdataGridView.Columns["currentStockValue"].DataPropertyName = "StockValue";//this.currentStockValue

                currentStockdataGridView.DataSource = currentStockLog;




            }
            catch (Exception ex)
            {
                MessageBox.Show("Error, Current Stock Log Not present in the Inventory table...!" + ex.Message);
            }
        }



        private void fnGINReverse()
        {
            try
            {

                Vendorlb.Visible = false;
                inventoryVendorTextBox.Visible = false;
                flLocation.Visible = false;
                inventoryLocationtextBox.Visible = false;

                dataGridViewGIN.Visible = false;
                dataGridViewGINReverse.Visible = true;

                IndentLogDataGrideView.Visible = false;
                dataGridViewFIFOLog.Visible = false;
                dataGridViewScrapLog.Visible = false;
                dataGridViewIssueLog.Visible = false;
                dataGridViewReturnLog.Visible = false;
                currentStockdataGridView.Visible = false;
                currentStock.ForeColor = Color.Black;
                currentStock.BackColor = Color.White;
                IndentLog.BackColor = Color.White;
                IndentLog.ForeColor = Color.Black;
                GINLog.BackColor = Color.White;
                GINLog.ForeColor = Color.Black;
                FIFOLog.BackColor = Color.White;
                FIFOLog.ForeColor = Color.Black;
                ScrapLog.BackColor = Color.White;
                ScrapLog.ForeColor = Color.Black;
                IssueLog.BackColor = Color.White;
                IssueLog.ForeColor = Color.Black;
                ReturnItem.BackColor = Color.White;
                ReturnItem.ForeColor = Color.Black;
                GINReverse.ForeColor = Color.White;
                GINReverse.BackColor = Color.Green;

                panel4.Visible = false;
                panel3.Visible = true;


                string fromDate = inventoryFromIndateTimePicker.Checked ? inventoryFromIndateTimePicker.Text : null;
                string toDate = inventoryToDateTimePicker.Checked ? inventoryToDateTimePicker.Text : null;
                //  string project = string.IsNullOrWhiteSpace(inventoryProjectTextBox.Text) ? null : inventoryProjectTextBox.Text;
                string category = string.IsNullOrWhiteSpace(inventoryCategoryTextBox.Text) ? null : inventoryCategoryTextBox.Text;



                GINReverseInventoryLog = DAL.fnGetFilteredERPReverseInventoryLogs(fromDate, toDate, category).Tables[0];
                // InventoryReturnLog = DAL.fnGetERPInventoryReturnLogs(lblRepeatitemcode.Text, null).Tables[0];

                dataGridViewGINReverse.AutoGenerateColumns = false;


                //  ItemCodeReverse,
                //.GINNumberReverse,
                //this.ReturnQTYReverse,
                //this.UnitPriceReverse,
                //this.InvoiceNumberReverse,
                //this.VendorNameReverse,
                //this.VendorCodeReverse,
                //this.GINDateReverse,
                //this.InvoiceDateReverse,
                //this.ReverseGINDate


                dataGridViewGINReverse.Columns["ItemCodeReverse"].DataPropertyName = "ItemCode";
                dataGridViewGINReverse.Columns["GINNumberReverse"].DataPropertyName = "GINNumber";
                dataGridViewGINReverse.Columns["ReturnQTYReverse"].DataPropertyName = "ReturnQty";
                dataGridViewGINReverse.Columns["UnitPriceReverse"].DataPropertyName = "UnitCost";
                dataGridViewGINReverse.Columns["InvoiceNumberReverse"].DataPropertyName = "SupplierInvoiceNumber";
                dataGridViewGINReverse.Columns["VendorNameReverse"].DataPropertyName = "VendorName";
                dataGridViewGINReverse.Columns["VendorCodeReverse"].DataPropertyName = "VendorCode";
                dataGridViewGINReverse.Columns["GINDateReverse"].DataPropertyName = "GinDate";
                dataGridViewGINReverse.Columns["InvoiceDateReverse"].DataPropertyName = "InvoiceDate";
                dataGridViewGINReverse.Columns["ReverseGINDate"].DataPropertyName = "ReverseGINDate";



                dataGridViewGINReverse.DataSource = GINReverseInventoryLog;


            }
            catch (Exception ex)
            {
                MessageBox.Show("chklbItemList_ItemCheck_This error, Return Item Log Not present in the Inventory table...!" + ex.Message);
            }
        }



        string currentTableLog = "GINLog";
        private void test_Click(object sender, EventArgs e)
        {
            Button clickedButton = sender as Button; // Cast sender to Button
            if (clickedButton != null)
            {
                // MessageBox.Show("You clicked: " + clickedButton.Name);
                // Or use clickedButton.Text if you want the button label
            }
            if (clickedButton.Name == "IndentLog")
            {

                fnIndentLog();
                currentTableLog = "IndentLog";
            }


            if (clickedButton.Name == "GINLog")
            {
                fnGINLog();

                currentTableLog = "GINLog";
            }


            if (clickedButton.Name == "FIFOLog")
            {
                fnFIFOLog();
                currentTableLog = "FIFOLog";

            }

            if (clickedButton.Name == "IssueLog")
            {
                fnIssueLog();
                currentTableLog = "IssueLog";
            }


            if (clickedButton.Name == "ReturnItem")
            {
                fnReturnItemLog();
                currentTableLog = "ReturnItem";
            }

            if (clickedButton.Name == "ScrapLog")
            {
                fnScrapLog();
                currentTableLog = "ScrapLog";
            }


            if (clickedButton.Name == "currentStock")
            {
                currentTableLog = "currentStock";
                fnCurrentStock();
            }


            if (clickedButton.Name == "GINReverse")
            {
                fnGINReverse();
                currentTableLog = "GINReverse";
            }

        }





        private void dgvmaterialLedger_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            // If the column is the DATED column, check the
            // value.
            if (this.dgvmaterialLedger.Columns[e.ColumnIndex].Name == "Date1")
            {
                ShortFormDateFormat(e);
            }
        }

        private static void ShortFormDateFormat(DataGridViewCellFormattingEventArgs formatting)
        {
            if (formatting.Value != null)
            {
                try
                {
                    DateTime theDate = DateTime.Parse(formatting.Value.ToString());
                    String dateString = theDate.ToString("dd-MM-yy");
                    formatting.Value = dateString;
                    formatting.FormattingApplied = true;
                }
                catch (FormatException)
                {
                    // Set to false in case there are other handlers interested trying to
                    // format this DataGridViewCellFormattingEventArgs instance.
                    formatting.FormattingApplied = false;
                }
            }
        }

        private void dgvmaterialLedger_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {

        }

        private void btnExportExcel_Click(object sender, EventArgs e)
        {
            string ExcelFolderPath;
            string FileFullPath;

            Microsoft.Office.Interop.Excel._Application ExcelApp = null;
            Microsoft.Office.Interop.Excel._Workbook NewWorkBook = null;
            Cursor.Current = Cursors.WaitCursor;
            EXCEL.Worksheet NewWorkSheet;
            bool IsFirsttime = true;

            if (dtMaterialLedger.Rows.Count > 0)
            {
                int j = 14;
                ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\Materail Ledger\\";
                FileFullPath = ExcelFolderPath + "Material Ledger " + dtpfromdate.Text + " To " + dtptodate.Text + " " + DateTime.Now.ToString("d/M/yyyy HH/mm/ss") + " ";
                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);

                ExcelApp = new Microsoft.Office.Interop.Excel.Application();
                NewWorkBook = ExcelApp.Workbooks.Add(Type.Missing);
                Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
                worksheet = NewWorkBook.Sheets["Sheet1"];
                worksheet = NewWorkBook.ActiveSheet;
                worksheet.Name = "Material Ledger";
                object misValue = System.Reflection.Missing.Value;
                worksheet.Cells[1, 1] = Global.sCompanyName; //i++;       

                worksheet.Cells[2, 1] = "Item Code :";// i++;
                worksheet.Cells[2, 2] = lblRepeatitemcode.Text;
                //  CellMerge("Merge", NewWorkBook.ActiveSheet, 2, 2, 1, 7);
                worksheet.Cells[3, 1] = "Item Desc : ";
                worksheet.Cells[3, 2] = lblitemname.Text;
                //CellMerge("Merge", NewWorkBook.ActiveSheet, 3, 3, 1, 7);
                worksheet.Cells[4, 1] = "Dated From : ";

                worksheet.Cells[4, 2] = "" + dtpfromdate.Text + "  To : " + dtptodate.Text + "";// i++; i++;
                //CellMerge("Merge", NewWorkBook.ActiveSheet, 3, 3, 1, 3);
                worksheet.Range["A1:C1"].Cells.Font.Size = 16;
                worksheet.Range["A2:C12"].Cells.Font.Size = 12;
                // worksheet.Range["A4:C4"].Cells.Font.Size = 12;
                worksheet.Range["A1:C1"].Cells.Font.Bold = true;
                // worksheet.Range["A2:A11"].Cells.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;

                //  worksheet.Range["B2:B11"].Cells.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignLeft;
                var yesterday1 = DateTime.Today;

                worksheet.Cells[5, 1] = "Available Qunatity as on " + yesterday1.ToString("dd-MM-yyyy") + " ";



                worksheet.Cells[7, 1] = "Opening Balance :";
                worksheet.Cells[8, 1] = "Reciepts : ";
                worksheet.Cells[9, 1] = "Item Return : ";
                worksheet.Cells[10, 1] = "Issue : ";
                worksheet.Cells[11, 1] = "Stock Adjusted : ";
                worksheet.Cells[12, 1] = "Closing Stock : ";


                //worksheet.Cells[5, 1] = "Available Qunatity as on " + yesterday1.ToString("yyyy-MM-dd") + ": " + lblavailableqty.Text + "";


                worksheet.Cells[5, 2] = lblavailableqty.Text;
                worksheet.Cells[7, 2] = lblOpeningBalance.Text;
                worksheet.Cells[8, 2] = lblRecipt.Text;
                worksheet.Cells[9, 2] = lblItemReturn.Text;
                worksheet.Cells[10, 2] = lblIssue.Text;
                worksheet.Cells[11, 2] = lblStockAdjusted.Text;
                worksheet.Cells[12, 2] = lblClosingStock.Text;

                CellMerge("AlignRight", NewWorkBook.ActiveSheet, 2, 12, 1, 1);
                CellMerge("AlignLeft", NewWorkBook.ActiveSheet, 2, 12, 2, 2);

                bool bFirsttime = true;


                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Bold = true;

                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Bold = true;
                ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[j, Type.Missing]).Font.Color = Color.Blue;


                object[,] rawData = new object[dtMaterialLedger.Rows.Count + 1, dtMaterialLedger.Columns.Count];
                if (bFirsttime)
                {
                    for (int col = 0; col < dtMaterialLedger.Columns.Count; col++)
                    {
                        rawData[0, col] = dtMaterialLedger.Columns[col].ColumnName;
                    }
                    bFirsttime = false;
                }
                if (dtMaterialLedger.Rows.Count > 0)
                {
                    for (int row = 0; row < dtMaterialLedger.Rows.Count; row++)
                    {
                        for (int col = 0; col < dtMaterialLedger.Columns.Count; col++)
                        {
                            rawData[row + 1, col] = dtMaterialLedger.Rows[row].ItemArray[col];
                        }
                    }
                    string finalColLetter = string.Empty;
                    string excelRange = string.Empty;
                    if (IsFirsttime)
                    {
                        finalColLetter = string.Empty;
                        string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        int colCharsetLen = colCharset.Length;

                        if (dtMaterialLedger.Columns.Count > colCharsetLen)
                        {
                            finalColLetter = colCharset.Substring(
                                (dtMaterialLedger.Columns.Count - 1) / colCharsetLen - 1, 1);
                        }

                        finalColLetter += colCharset.Substring(
                                (dtMaterialLedger.Columns.Count - 1) % colCharsetLen, 1);
                        excelRange = string.Format("A14:{0}{1}", finalColLetter, (dtMaterialLedger.Rows.Count + 14));
                        IsFirsttime = false;
                    }
                    worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;

                }

                //worksheet.Range["A3:C5"].Cells.Font.Size = 14;
                //worksheet.Range["A3:C5"].Cells.Font.Bold = 14;
                CellMerge("Merge", NewWorkBook.ActiveSheet, 1, 1, 1, 3);
                if (!bAllLedger)
                {
                    worksheet.get_Range("C6", "C99999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    Microsoft.Office.Interop.Excel.Range Range = worksheet.get_Range("N6", "R99999");
                    Range.EntireColumn.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                    //worksheet.Rows.RowHeight = "18";
                    Microsoft.Office.Interop.Excel.Range rangea = worksheet.get_Range("K6", "K99999");
                    rangea.NumberFormat = "dd-MM-yyyy";

                    worksheet.Columns.AutoFit();
                    worksheet.Rows.AutoFit();

                    worksheet.Columns[1].ColumnWidth = 40;
                    // worksheet.Columns[1].ColumnWidth = 12;
                    // worksheet.Columns[1].WrapText = true;
                    worksheet.Columns[7].ColumnWidth = 30;
                    worksheet.Columns[7].WrapText = true;
                    worksheet.Columns[8].ColumnWidth = 50;
                    worksheet.Columns[8].WrapText = true;
                }
                else if (bAllLedger)
                {
                    worksheet.Columns.AutoFit();
                    worksheet.Rows.AutoFit();


                    worksheet.Columns[2].ColumnWidth = 40;
                    // worksheet.Columns[2].WrapText = true;
                    bAllLedger = false;
                    Microsoft.Office.Interop.Excel.Range rangea = worksheet.get_Range("J6", "J99999");
                    rangea.NumberFormat = "0.00";

                    worksheet.Cells[7, 11].Formula = "=SUM(C7,E7,-F7,-G7,H7,I7,J7)";
                    worksheet.Cells[7, 11].Calculate();

                    worksheet.Cells[7, 13].Formula = "=SUM(D7*L7)";
                    worksheet.Cells[7, 13].Calculate();
                }


                worksheet.Rows.RowHeight = "18";
                worksheet.PageSetup.PrintArea = "A1:Q" + (dtMaterialLedger.Rows.Count + 14) + "";
                worksheet.PageSetup.PrintTitleRows = "$1:$2";
                worksheet.PageSetup.PrintNotes = true;
                worksheet.PageSetup.Zoom = 75;
                worksheet.PageSetup.PrintGridlines = true;
                worksheet.PageSetup.LeftMargin = 0;
                worksheet.PageSetup.RightMargin = 0;
                worksheet.PageSetup.TopMargin = 0.75;
                worksheet.PageSetup.BottomMargin = 0.75;
                worksheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlLandscape;
                worksheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                NewWorkBook.SaveAs(FileFullPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                NewWorkBook.Save();
                NewWorkBook.Close(true, misValue, misValue);
                ExcelApp.Quit();
                releaseObject(worksheet);
                releaseObject(NewWorkBook);
                releaseObject(ExcelApp);

                if (Directory.Exists(ExcelFolderPath))
                {
                    Process.Start(ExcelFolderPath);
                }
                Cursor.Current = Cursors.Default;
            }
            else
            {
                MessageBox.Show("Select date range has no data to print.", "Error", 0, MessageBoxIcon.Error);
            }

        }

        #region CellMerge Funtion
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlMedium, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "GridLines":
                    {
                        CELLS.Borders.Color = System.Drawing.Color.Black;
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignCenter":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                        break;
                    }
                case "AlignRight":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                        break;
                    }
                case "AlignLeft":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignLeft;
                        break;
                    }
                case "Bold":
                    {
                        CELLS.Font.Bold = true;
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

        }
        #endregion

        #region Excel App Release Object Function
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
        #endregion

        private void chkItemCode_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemCode.CheckState == CheckState.Checked)
            {
                chkItemDesc.Checked = false;
            }
        }

        private void chkItemDesc_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemDesc.CheckState == CheckState.Checked)
            {
                chkItemCode.Checked = false;
            }
        }
        bool bAllLedger = false;
        private void btnAllledger_Click(object sender, EventArgs e)
        {
            bAllLedger = true;
            dtpfromdate.Format = DateTimePickerFormat.Custom;
            dtpfromdate.CustomFormat = "yyyy-MM-dd";
            dtptodate.Format = DateTimePickerFormat.Custom;
            dtptodate.CustomFormat = "yyyy-MM-dd";
            dgvALLLedgerReport.Visible = true;
            dtMaterialLedger = DAL.fnMaterialLedger(null, dtpfromdate.Text, dtptodate.Text).Tables[0];
            dtpfromdate.Format = DateTimePickerFormat.Custom;
            dtpfromdate.CustomFormat = "dd-MM-yyyy";
            dtptodate.Format = DateTimePickerFormat.Custom;
            dtptodate.CustomFormat = "dd-MM-yyyy";

            if (dtMaterialLedger.Rows.Count > 0)
            {
                fnTableMerge();
                dgvALLLedgerReport.DataSource = dtMaterialLedger;
            }
            dgvALLLedgerReport.Columns[1].Width = 40;
        }

        private void fnTableMerge()
        {
            DataTable dtMerge = new DataTable();

            dtMerge = dtMaterialLedger.Copy();



            DataTable dtRsult = dtMerge.Clone();
            var distinctRows = dtMerge.DefaultView.ToTable(true, "ItemCode").Rows.OfType<DataRow>().Select(k => k[0] + "").ToArray();
            foreach (string name in distinctRows)
            {
                var rows = dtMerge.Select("ItemCode = '" + name + "'");
                string sItemcode = "";
                string sItemdesc = "";
                double dOpenQuantity = 0;
                double dAvaQuantity = 0;
                double dRecQuantity = 0;
                double dIssuedQuantity = 0;
                double dJobIssuedQuantity = 0;
                double dIssuedItemReturnQuantity = 0;
                double dJObIssuedItemReturnQuantity = 0;
                double dStockAdjusted = 0;
                double dClsoingQuantity = 0;
                double UnitCost = 0;
                double Amount = 0;
                //  double dTotal = 0;
                //    double dGrandTotal = 0;

                if (name == "HYD-PFA-000002")
                {

                }

                foreach (DataRow row in rows)
                {
                    sItemcode = row["ItemCode"].ToString();
                    sItemdesc = row["ItemDescription"].ToString();
                    if (row["OpeningQuantity"] != DBNull.Value)
                        dOpenQuantity += Convert.ToDouble(row["OpeningQuantity"]);
                    if (row["AvailableQty"] != DBNull.Value)
                        dAvaQuantity += Convert.ToDouble(row["AvailableQty"]);
                    dRecQuantity += Convert.ToDouble(row["RecievedQty"]);
                    dIssuedQuantity += Convert.ToDouble(row["IssuedQty"]);
                    dJobIssuedQuantity += Convert.ToDouble(row["JobIssuedQty"]);
                    dIssuedItemReturnQuantity += Convert.ToDouble(row["IssueReturnQty"]);
                    dJObIssuedItemReturnQuantity += Convert.ToDouble(row["JobIssueReturnQty"]);
                    dStockAdjusted += Convert.ToDouble(row["StockAdjsued"]);
                    //  dStockAdjusted = Convert.ToDouble(row["Qty"]);
                    UnitCost = Convert.ToDouble(row["UnitCost"]);
                }
                //if (sItemcode == "ELE-P/N 3 842 992 457")
                //{
                //    int k = 99;
                //}
                // dClsoingQuantity = dOpenQuantity + dRecQuantity - dIssuedQuantity - dJobIssuedQuantity + dIssuedItemReturnQuantity + dJObIssuedItemReturnQuantity + dStockAdjusted;
                Amount = dClsoingQuantity * UnitCost;
                dtRsult.Rows.Add(sItemcode, sItemdesc, dOpenQuantity, dAvaQuantity, dRecQuantity, dIssuedQuantity, dJobIssuedQuantity, dIssuedItemReturnQuantity,
                    dJObIssuedItemReturnQuantity, dStockAdjusted, dClsoingQuantity, UnitCost, Amount);

                //lblClosingStock.Text = (Convert.ToDouble(lblOpeningBalance.Text) + RecievedQTY + ReturnQTY - IssuedQTY + StockAdjusted).ToString();

                //  value = "";
            }


            dtMaterialLedger = dtRsult.Copy();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm.Show();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void dgvmaterialLedger_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

            if (false)
            {
                panel3.Visible = true;
            }
            else
            {
                panel3.Visible = false;
                dataGridViewGIN.DataSource = null;
            }

            fnGINLog();


            if (false)
            {
                // MessageBox.Show(checkBox1.CheckState.ToString());




                try
                {
                    bAllLedger = false;
                    dgvALLLedgerReport.Visible = false;

                    //if (!chklbItemList.CheckedItems.Contains(chklbItemList.SelectedItem))
                    if (false)
                    {
                        //  MessageBox.Show("First Stage!");
                        //sItemCode = chklbItemList.SelectedItem.ToString().Trim().Split(')');
                        //string sID = sItemCode[0];
                        dtItemcode = DAL.fnStandardCostItemList(null).Tables[0];

                        //if (dtItemcode.Rows.Count > 0)
                        if (true)
                        {
                            // MessageBox.Show("second Stage!");

                            //lblRepeatitemcode.Text = dtItemcode.Rows[0]["Itemcode"].ToString();
                            //lblitemname.Text = dtItemcode.Rows[0]["ItemDescription"].ToString();
                            //lblrepeatCost.Text = dtItemcode.Rows[0]["UnitCost"].ToString() + " Rs";
                            //lblavailableqty.Text = dtItemcode.Rows[0]["AvailableQty"].ToString(); //+ " " + dtItemcode.Rows[0]["Units"].ToString()
                            //lblOpeningBalance.Text = dtItemcode.Rows[0]["OpeningQuantity"].ToString();






                            IndentLogDataGrideView.Visible = false;
                            dataGridViewFIFOLog.Visible = false;
                            dataGridViewReturnLog.Visible = false;
                            dataGridViewScrapLog.Visible = false;
                            dataGridViewIssueLog.Visible = false;
                            dataGridViewGIN.Visible = true;
                            IndentLog.BackColor = Color.White;
                            IndentLog.ForeColor = Color.Black;
                            FIFOLog.BackColor = Color.White;
                            FIFOLog.ForeColor = Color.Black;
                            ScrapLog.BackColor = Color.White;
                            ScrapLog.ForeColor = Color.Black;
                            ReturnItem.BackColor = Color.White;
                            ReturnItem.ForeColor = Color.Black;
                            IssueLog.BackColor = Color.White;
                            IssueLog.ForeColor = Color.Black;
                            GINLog.BackColor = Color.Green;
                            GINLog.ForeColor = Color.White;

                            try
                            {
                                //GINInventoryLogs = DAL.getItemBatchLocation(null).Tables[0];// This will fetch all the items In Inventory table

                                GINInventoryLogs = DAL.fnGetFilteredERPInventoryLog("08-10-2025", "15-10-2025", null, null, null, null).Tables[0];
                                // DAL.GetERPInventoryReceivedQty(dtItemcode.Rows[0]["Itemcode"].ToString(), "ReceivedQtY");
                                //DAL.GetERPInventoryReceivedQty(dtItemcode.Rows[0]["Itemcode"].ToString(), "RemainingQty");
                                //DAL.GetERPInventoryReceivedQty(dtItemcode.Rows[0]["Itemcode"].ToString(), "IssuedQty");
                                dataGridViewGIN.AutoGenerateColumns = false;


                                // Map DataTable columns to your DataGridView columns
                                dataGridViewGIN.Columns["GINNumber"].DataPropertyName = "GINNumber";
                                dataGridViewGIN.Columns["ItemCodeGIN"].DataPropertyName = "ItemCode";
                                dataGridViewGIN.Columns["CreateDateGIN"].DataPropertyName = "CreatedDate";
                                dataGridViewGIN.Columns["RefNumberGIN"].DataPropertyName = "POWONumber";
                                // dataGridViewGIN.Columns["BOMProjectCodeGIN"].DataPropertyName = "BOMProjectCode";
                                dataGridViewGIN.Columns["ProjectCodeGIN"].DataPropertyName = "ProjectCode";
                                dataGridViewGIN.Columns["ReceivedQtYGIN"].DataPropertyName = "ReceivedQtY";
                                dataGridViewGIN.Columns["RemainingQtyGIN"].DataPropertyName = "RemainingQty";
                                dataGridViewGIN.Columns["BatchCodeGIN"].DataPropertyName = "BatchCode";
                                dataGridViewGIN.Columns["LocationGIN"].DataPropertyName = "ItemLocation";
                                dataGridViewGIN.Columns["IndentQtyGIN"].DataPropertyName = "IndentQty";
                                dataGridViewGIN.Columns["IssuedQtyGIN"].DataPropertyName = "IssuedQty";

                                // Bind the data
                                dataGridViewGIN.DataSource = GINInventoryLogs;

                                inventoryAvailableQty.Text = "0";
                                inventoryIndentQty.Text = "0";
                                inventoryIssueQty.Text = "0";
                                inventoryReturnQty.Text = "0";
                                inventoryQuarantineQty.Text = "0";


                                try
                                {
                                    double totalRemainingQty = DAL.fnGetTotalRemainingQty(lblRepeatitemcode.Text, null);
                                    inventoryAvailableQty.Text = totalRemainingQty.ToString();
                                }
                                catch (Exception error)
                                {
                                    MessageBox.Show(error.Message, "Inventory GIN");
                                }


                                try
                                {
                                    double totalIndentQty = DAL.fnGetTotalIndentQty(lblRepeatitemcode.Text, null);
                                    inventoryIndentQty.Text = totalIndentQty.ToString();
                                }
                                catch (Exception error)
                                {
                                    MessageBox.Show(error.Message, "Inventory Indent");
                                }


                                try
                                {
                                    double totalIssuedQty = DAL.fnGetTotalIssuedQty(lblRepeatitemcode.Text, null);
                                    inventoryIssueQty.Text = totalIssuedQty.ToString();

                                }
                                catch (Exception error)
                                {
                                    MessageBox.Show(error.Message, "Inventory Issue");
                                }


                                try
                                {
                                    double totalReturnQty = DAL.fnGetTotalReturnQty(lblRepeatitemcode.Text, null);
                                    inventoryReturnQty.Text = totalReturnQty.ToString();
                                }
                                catch (Exception error)
                                {
                                    MessageBox.Show(error.Message, "Inventory Return");
                                }

                                try
                                {

                                    double totalQuarantineQty = DAL.fnGetTotalQuarantineQty(lblRepeatitemcode.Text, null);
                                    inventoryQuarantineQty.Text = totalQuarantineQty.ToString();
                                }
                                catch (Exception error)
                                {
                                    MessageBox.Show(error.Message, "Inventory Quarantain");
                                }

                                try
                                {

                                    double totalReceivedQty = DAL.fnGetTotalReceivedQty(lblRepeatitemcode.Text, null);
                                    inventoryReceivedQty.Text = totalReceivedQty.ToString();
                                }
                                catch (Exception error)
                                {
                                    MessageBox.Show(error.Message, "Inventory Received");
                                }

                                //fnGetTotalIssuedQty
                                //MessageBox.Show(totalRemainingQty.ToString());
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("chklbItemList_ItemCheck_This error, Item Not present in the Inventory table...!" + ex.Message);
                            }




                            dtMaterialLedger = DAL.fnMaterialLedger(lblRepeatitemcode.Text, null, null).Tables[0];
                            if (dtMaterialLedger.Rows.Count > 0)
                            {
                                lblNoitems.Visible = false;


                                DataView view = dtMaterialLedger.DefaultView;
                                view.Sort = "date ASC";
                                DataTable sortedDate = view.ToTable();

                                dgvmaterialLedger.AutoGenerateColumns = false;
                                // dgvmaterialLedger.DataSource = sortedDate;

                                RecievedQTY = 0;
                                IssuedQTY = 0;
                                ReturnQTY = 0;
                                StockAdjusted = 0;
                                foreach (DataRow dgvr in dtMaterialLedger.Rows)
                                {
                                    RecievedQTY += Convert.ToDouble(dgvr["RecievedQty"].ToString());
                                    IssuedQTY += Convert.ToDouble(dgvr["IssuedQty"].ToString());
                                    ReturnQTY += Convert.ToDouble(dgvr["ReturnQty"].ToString());
                                    StockAdjusted += Convert.ToDouble(dgvr["StockAdjsued"].ToString());
                                }
                                lblrecievqty.Text = RecievedQTY.ToString();
                                lblissuedqty.Text = IssuedQTY.ToString();
                                lblreturnqty.Text = ReturnQTY.ToString();
                                lblStockAdjusted.Text = StockAdjusted.ToString();
                                lblStockAdjusted.ForeColor = Color.Red;
                                lblRecipt.Text = RecievedQTY.ToString();
                                lblIssue.Text = IssuedQTY.ToString();
                                lblItemReturn.Text = ReturnQTY.ToString();
                                lblStockAdjused.Text = StockAdjusted.ToString();
                                lblClosingStock.Text = (Convert.ToDouble(lblOpeningBalance.Text) + RecievedQTY + ReturnQTY - IssuedQTY + StockAdjusted).ToString();

                            }
                            else
                            {
                                lblNoitems.Visible = true;
                                dgvmaterialLedger.DataSource = null;
                                lblrecievqty.Text = "0";
                                lblissuedqty.Text = "0";
                                lblreturnqty.Text = "0";
                                lblStockAdjusted.Text = "0";
                                lblStockAdjused.Text = "0";

                                lblRecipt.Text = "0";
                                lblIssue.Text = "0";
                                lblStockAdjused.Text = "0";
                                lblClosingStock.Text = "0";
                                //Below lables for Inventory 
                                inventoryAvailableQty.Text = "0";
                                inventoryIndentQty.Text = "0";
                                inventoryIssueQty.Text = "0";
                                inventoryReturnQty.Text = "0";
                                inventoryQuarantineQty.Text = "0";
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("chklbItemList_ItemCheck" + ex.Message);
                }
            }
            else
            {

            }





        }





        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void btnApplyFilter_Click(object sender, EventArgs e)
        {
            inventoryApplyFilter = true;
            // MessageBox.Show(inventoryFromIndateTimePicker.Text, "form Date");
            //MessageBox.Show(inventoryToDateTimePicker.Text, "To Date");
            // MessageBox.Show(inventoryVendorTextBox.Text, "Vendor");
            // MessageBox.Show(inventoryProjectTextBox.Text, "Project");
            // MessageBox.Show(inventoryCategoryTextBox.Text, "Country);  

            if (currentTableLog == "IndentLog")
            {
                fnIndentLog();
                // MessageBox.Show(currentTableLog, "Indent Log");
            }

            if (currentTableLog == "GINLog")
            {
                fnGINLog();
                // MessageBox.Show(currentTableLog, "GINLog");
            }

            if (currentTableLog == "FIFOLog")
            {
                fnFIFOLog();
                //MessageBox.Show(currentTableLog, "FIFOLog");
            }

            if (currentTableLog == "IssueLog")
            {
                fnIssueLog();
                //MessageBox.Show(currentTableLog, "IssueLog");
            }

            if (currentTableLog == "ReturnItem")
            {
                fnReturnItemLog();
                //MessageBox.Show(currentTableLog, "ReturnItem");
            }

            if (currentTableLog == "ScrapLog")
            {
                fnScrapLog();
                //MessageBox.Show(currentTableLog, "ScrapLog");
            }

            if (currentTableLog == "currentStock")
            {
                fnCurrentStock();
                //MessageBox.Show(currentStock, "currentStock");
            }

            if (currentTableLog == "GINReverse")
            {
                fnGINReverse();
                //MessageBox.Show(currentTableLog, "GINReverse");
            }


        }

        private void btnClearFilter_Click(object sender, EventArgs e)
        {
            inventoryApplyFilter = false;
            // inventoryToDateTimePicker.Text 
            inventoryVendorTextBox.Text = "";
            inventoryProjectTextBox.Text = "";
            inventoryCategoryTextBox.Text = "";
            comboBox1.Text = "";
            indentNotextBox.Text = "";

        }

        private void currentStockApplyFilter_Click(object sender, EventArgs e)
        {
            if (currentTableLog == "currentStock")
            {
                fnCurrentStock();
                MessageBox.Show(currentStock, "currentStock");
            }
        }

        private void currentStockClearFilter_Click(object sender, EventArgs e)
        {
            currentstockItemCodeTextBox.Text = "";
            currentStockLocationTextBox.Text = "";
            currentStockUnitCostTextBox.Text = "";
            currentStockStockCostTextBox.Text = "";
        }

        private void dataGridViewGINReverse_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

