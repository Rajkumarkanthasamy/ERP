﻿namespace Erp_Project_With_Buttons.Part_Reciept
{
    partial class DC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.Remarks = new System.Windows.Forms.Label();
            this.Remarkslabel = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.DCBy = new System.Windows.Forms.Label();
            this.DCBylabel = new System.Windows.Forms.Label();
            this.DCFor = new System.Windows.Forms.Label();
            this.DCForlabel = new System.Windows.Forms.Label();
            this.DCSerialNumber = new System.Windows.Forms.Label();
            this.DCSerialNumberlabel = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.DCReference = new System.Windows.Forms.Label();
            this.labelDCReference = new System.Windows.Forms.Label();
            this.DCWorkOrder = new System.Windows.Forms.Label();
            this.labelDCWorkOrder = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.DispatchDate = new System.Windows.Forms.Label();
            this.DateofChallan = new System.Windows.Forms.Label();
            this.DispatchDatelabel = new System.Windows.Forms.Label();
            this.labelDateofChallan = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.DRStateCode = new System.Windows.Forms.Label();
            this.DRStateCodelabel = new System.Windows.Forms.Label();
            this.DRState = new System.Windows.Forms.Label();
            this.DRStatelabel = new System.Windows.Forms.Label();
            this.DRGSTIN = new System.Windows.Forms.Label();
            this.DRGSTINlabel = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.DRAddress = new System.Windows.Forms.Label();
            this.DRAddresslabel = new System.Windows.Forms.Label();
            this.DRName = new System.Windows.Forms.Label();
            this.DRNamelabel = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.TransportCompany = new System.Windows.Forms.Label();
            this.TransportCompanylabel = new System.Windows.Forms.Label();
            this.PlaceofSupply = new System.Windows.Forms.Label();
            this.PlaceofSupplylabel = new System.Windows.Forms.Label();
            this.VehicleNumber = new System.Windows.Forms.Label();
            this.VehicleNumberlabel = new System.Windows.Forms.Label();
            this.TransportMode = new System.Windows.Forms.Label();
            this.TransportModelabel = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBoxDCSerialNumber = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.DCcategorieslabel = new System.Windows.Forms.Label();
            this.DCTypelabel = new System.Windows.Forms.Label();
            this.comboBoxDCcategories = new System.Windows.Forms.ComboBox();
            this.comboBoxDCType = new System.Windows.Forms.ComboBox();
            this.DeliveryDatelabel = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.ReturnDatelabel = new System.Windows.Forms.Label();
            this.Updatebutton = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel10.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel11.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.Updatebutton);
            this.panel1.Controls.Add(this.panel11);
            this.panel1.Controls.Add(this.panel10);
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1070, 642);
            this.panel1.TabIndex = 0;
            // 
            // panel10
            // 
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.Remarks);
            this.panel10.Controls.Add(this.Remarkslabel);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel10.Location = new System.Drawing.Point(0, 398);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(1070, 75);
            this.panel10.TabIndex = 3;
            // 
            // Remarks
            // 
            this.Remarks.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Remarks.Location = new System.Drawing.Point(68, 10);
            this.Remarks.Name = "Remarks";
            this.Remarks.Size = new System.Drawing.Size(998, 53);
            this.Remarks.TabIndex = 1;
            this.Remarks.Text = "-";
            // 
            // Remarkslabel
            // 
            this.Remarkslabel.AutoSize = true;
            this.Remarkslabel.Enabled = false;
            this.Remarkslabel.Location = new System.Drawing.Point(10, 10);
            this.Remarkslabel.Name = "Remarkslabel";
            this.Remarkslabel.Size = new System.Drawing.Size(49, 13);
            this.Remarkslabel.TabIndex = 0;
            this.Remarkslabel.Text = "Remarks:";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.4674F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.5326F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 315F));
            this.tableLayoutPanel1.Controls.Add(this.panel4, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel5, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel6, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel7, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel8, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel9, 0, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 134);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 36.36364F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 63.63636F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1070, 264);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.DCBy);
            this.panel4.Controls.Add(this.DCBylabel);
            this.panel4.Controls.Add(this.DCFor);
            this.panel4.Controls.Add(this.DCForlabel);
            this.panel4.Controls.Add(this.DCSerialNumber);
            this.panel4.Controls.Add(this.DCSerialNumberlabel);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(3, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(299, 90);
            this.panel4.TabIndex = 0;
            // 
            // DCBy
            // 
            this.DCBy.AutoSize = true;
            this.DCBy.Location = new System.Drawing.Point(67, 67);
            this.DCBy.Name = "DCBy";
            this.DCBy.Size = new System.Drawing.Size(10, 13);
            this.DCBy.TabIndex = 5;
            this.DCBy.Text = "-";
            // 
            // DCBylabel
            // 
            this.DCBylabel.AutoSize = true;
            this.DCBylabel.Enabled = false;
            this.DCBylabel.Location = new System.Drawing.Point(9, 67);
            this.DCBylabel.Name = "DCBylabel";
            this.DCBylabel.Size = new System.Drawing.Size(34, 13);
            this.DCBylabel.TabIndex = 4;
            this.DCBylabel.Text = "DCBy:";
            // 
            // DCFor
            // 
            this.DCFor.AutoSize = true;
            this.DCFor.Location = new System.Drawing.Point(67, 37);
            this.DCFor.Name = "DCFor";
            this.DCFor.Size = new System.Drawing.Size(10, 13);
            this.DCFor.TabIndex = 3;
            this.DCFor.Text = "-";
            // 
            // DCForlabel
            // 
            this.DCForlabel.AutoSize = true;
            this.DCForlabel.Enabled = false;
            this.DCForlabel.Location = new System.Drawing.Point(8, 37);
            this.DCForlabel.Name = "DCForlabel";
            this.DCForlabel.Size = new System.Drawing.Size(40, 13);
            this.DCForlabel.TabIndex = 2;
            this.DCForlabel.Text = "DC For:";
            // 
            // DCSerialNumber
            // 
            this.DCSerialNumber.AutoSize = true;
            this.DCSerialNumber.Location = new System.Drawing.Point(67, 5);
            this.DCSerialNumber.Name = "DCSerialNumber";
            this.DCSerialNumber.Size = new System.Drawing.Size(10, 13);
            this.DCSerialNumber.TabIndex = 1;
            this.DCSerialNumber.Text = "-";
            // 
            // DCSerialNumberlabel
            // 
            this.DCSerialNumberlabel.AutoSize = true;
            this.DCSerialNumberlabel.Enabled = false;
            this.DCSerialNumberlabel.Location = new System.Drawing.Point(9, 5);
            this.DCSerialNumberlabel.Name = "DCSerialNumberlabel";
            this.DCSerialNumberlabel.Size = new System.Drawing.Size(39, 13);
            this.DCSerialNumberlabel.TabIndex = 0;
            this.DCSerialNumberlabel.Text = "DC NO:";
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.DCReference);
            this.panel5.Controls.Add(this.labelDCReference);
            this.panel5.Controls.Add(this.DCWorkOrder);
            this.panel5.Controls.Add(this.labelDCWorkOrder);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(308, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(443, 90);
            this.panel5.TabIndex = 1;
            // 
            // DCReference
            // 
            this.DCReference.AutoSize = true;
            this.DCReference.Location = new System.Drawing.Point(118, 48);
            this.DCReference.Name = "DCReference";
            this.DCReference.Size = new System.Drawing.Size(10, 13);
            this.DCReference.TabIndex = 3;
            this.DCReference.Text = "-";
            // 
            // labelDCReference
            // 
            this.labelDCReference.AutoSize = true;
            this.labelDCReference.Enabled = false;
            this.labelDCReference.Location = new System.Drawing.Point(23, 48);
            this.labelDCReference.Name = "labelDCReference";
            this.labelDCReference.Size = new System.Drawing.Size(73, 13);
            this.labelDCReference.TabIndex = 2;
            this.labelDCReference.Text = "DC Reference:";
            // 
            // DCWorkOrder
            // 
            this.DCWorkOrder.AutoSize = true;
            this.DCWorkOrder.Location = new System.Drawing.Point(118, 17);
            this.DCWorkOrder.Name = "DCWorkOrder";
            this.DCWorkOrder.Size = new System.Drawing.Size(10, 13);
            this.DCWorkOrder.TabIndex = 1;
            this.DCWorkOrder.Text = "-";
            // 
            // labelDCWorkOrder
            // 
            this.labelDCWorkOrder.AutoSize = true;
            this.labelDCWorkOrder.Enabled = false;
            this.labelDCWorkOrder.Location = new System.Drawing.Point(23, 17);
            this.labelDCWorkOrder.Name = "labelDCWorkOrder";
            this.labelDCWorkOrder.Size = new System.Drawing.Size(79, 13);
            this.labelDCWorkOrder.TabIndex = 0;
            this.labelDCWorkOrder.Text = "DC Work Order:";
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.DispatchDate);
            this.panel6.Controls.Add(this.DateofChallan);
            this.panel6.Controls.Add(this.DispatchDatelabel);
            this.panel6.Controls.Add(this.labelDateofChallan);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(757, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(310, 90);
            this.panel6.TabIndex = 2;
            // 
            // DispatchDate
            // 
            this.DispatchDate.AutoSize = true;
            this.DispatchDate.Location = new System.Drawing.Point(103, 48);
            this.DispatchDate.Name = "DispatchDate";
            this.DispatchDate.Size = new System.Drawing.Size(10, 13);
            this.DispatchDate.TabIndex = 3;
            this.DispatchDate.Text = "-";
            // 
            // DateofChallan
            // 
            this.DateofChallan.AutoSize = true;
            this.DateofChallan.Location = new System.Drawing.Point(103, 17);
            this.DateofChallan.Name = "DateofChallan";
            this.DateofChallan.Size = new System.Drawing.Size(10, 13);
            this.DateofChallan.TabIndex = 2;
            this.DateofChallan.Text = "-";
            // 
            // DispatchDatelabel
            // 
            this.DispatchDatelabel.AutoSize = true;
            this.DispatchDatelabel.Enabled = false;
            this.DispatchDatelabel.Location = new System.Drawing.Point(18, 48);
            this.DispatchDatelabel.Name = "DispatchDatelabel";
            this.DispatchDatelabel.Size = new System.Drawing.Size(74, 13);
            this.DispatchDatelabel.TabIndex = 1;
            this.DispatchDatelabel.Text = "Dispatch Date:";
            // 
            // labelDateofChallan
            // 
            this.labelDateofChallan.AutoSize = true;
            this.labelDateofChallan.Enabled = false;
            this.labelDateofChallan.Location = new System.Drawing.Point(18, 17);
            this.labelDateofChallan.Name = "labelDateofChallan";
            this.labelDateofChallan.Size = new System.Drawing.Size(79, 13);
            this.labelDateofChallan.TabIndex = 0;
            this.labelDateofChallan.Text = "Date of Challan:";
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.DRStateCode);
            this.panel7.Controls.Add(this.DRStateCodelabel);
            this.panel7.Controls.Add(this.DRState);
            this.panel7.Controls.Add(this.DRStatelabel);
            this.panel7.Controls.Add(this.DRGSTIN);
            this.panel7.Controls.Add(this.DRGSTINlabel);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(757, 99);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(310, 162);
            this.panel7.TabIndex = 3;
            // 
            // DRStateCode
            // 
            this.DRStateCode.AutoSize = true;
            this.DRStateCode.Location = new System.Drawing.Point(109, 95);
            this.DRStateCode.Name = "DRStateCode";
            this.DRStateCode.Size = new System.Drawing.Size(10, 13);
            this.DRStateCode.TabIndex = 5;
            this.DRStateCode.Text = "-";
            // 
            // DRStateCodelabel
            // 
            this.DRStateCodelabel.AutoSize = true;
            this.DRStateCodelabel.Enabled = false;
            this.DRStateCodelabel.Location = new System.Drawing.Point(18, 95);
            this.DRStateCodelabel.Name = "DRStateCodelabel";
            this.DRStateCodelabel.Size = new System.Drawing.Size(73, 13);
            this.DRStateCodelabel.TabIndex = 4;
            this.DRStateCodelabel.Text = "DRState Code:";
            // 
            // DRState
            // 
            this.DRState.AutoSize = true;
            this.DRState.Location = new System.Drawing.Point(109, 57);
            this.DRState.Name = "DRState";
            this.DRState.Size = new System.Drawing.Size(10, 13);
            this.DRState.TabIndex = 3;
            this.DRState.Text = "-";
            // 
            // DRStatelabel
            // 
            this.DRStatelabel.AutoSize = true;
            this.DRStatelabel.Enabled = false;
            this.DRStatelabel.Location = new System.Drawing.Point(18, 59);
            this.DRStatelabel.Name = "DRStatelabel";
            this.DRStatelabel.Size = new System.Drawing.Size(47, 13);
            this.DRStatelabel.TabIndex = 2;
            this.DRStatelabel.Text = "DRState:";
            // 
            // DRGSTIN
            // 
            this.DRGSTIN.AutoSize = true;
            this.DRGSTIN.Location = new System.Drawing.Point(109, 20);
            this.DRGSTIN.Name = "DRGSTIN";
            this.DRGSTIN.Size = new System.Drawing.Size(10, 13);
            this.DRGSTIN.TabIndex = 1;
            this.DRGSTIN.Text = "-";
            // 
            // DRGSTINlabel
            // 
            this.DRGSTINlabel.AutoSize = true;
            this.DRGSTINlabel.Enabled = false;
            this.DRGSTINlabel.Location = new System.Drawing.Point(18, 20);
            this.DRGSTINlabel.Name = "DRGSTINlabel";
            this.DRGSTINlabel.Size = new System.Drawing.Size(50, 13);
            this.DRGSTINlabel.TabIndex = 0;
            this.DRGSTINlabel.Text = "DRGSTIN:";
            // 
            // panel8
            // 
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.DRAddress);
            this.panel8.Controls.Add(this.DRAddresslabel);
            this.panel8.Controls.Add(this.DRName);
            this.panel8.Controls.Add(this.DRNamelabel);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(308, 99);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(443, 162);
            this.panel8.TabIndex = 4;
            // 
            // DRAddress
            // 
            this.DRAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DRAddress.Location = new System.Drawing.Point(92, 95);
            this.DRAddress.Name = "DRAddress";
            this.DRAddress.Size = new System.Drawing.Size(339, 54);
            this.DRAddress.TabIndex = 3;
            this.DRAddress.Text = "-";
            // 
            // DRAddresslabel
            // 
            this.DRAddresslabel.AutoSize = true;
            this.DRAddresslabel.Enabled = false;
            this.DRAddresslabel.Location = new System.Drawing.Point(23, 95);
            this.DRAddresslabel.Name = "DRAddresslabel";
            this.DRAddresslabel.Size = new System.Drawing.Size(62, 13);
            this.DRAddresslabel.TabIndex = 2;
            this.DRAddresslabel.Text = "DR Address:";
            // 
            // DRName
            // 
            this.DRName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DRName.Location = new System.Drawing.Point(92, 20);
            this.DRName.Name = "DRName";
            this.DRName.Size = new System.Drawing.Size(339, 52);
            this.DRName.TabIndex = 1;
            this.DRName.Text = "-";
            // 
            // DRNamelabel
            // 
            this.DRNamelabel.AutoSize = true;
            this.DRNamelabel.Enabled = false;
            this.DRNamelabel.Location = new System.Drawing.Point(23, 20);
            this.DRNamelabel.Name = "DRNamelabel";
            this.DRNamelabel.Size = new System.Drawing.Size(52, 13);
            this.DRNamelabel.TabIndex = 0;
            this.DRNamelabel.Text = "DR Name:";
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.TransportCompany);
            this.panel9.Controls.Add(this.TransportCompanylabel);
            this.panel9.Controls.Add(this.PlaceofSupply);
            this.panel9.Controls.Add(this.PlaceofSupplylabel);
            this.panel9.Controls.Add(this.VehicleNumber);
            this.panel9.Controls.Add(this.VehicleNumberlabel);
            this.panel9.Controls.Add(this.TransportMode);
            this.panel9.Controls.Add(this.TransportModelabel);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(3, 99);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(299, 162);
            this.panel9.TabIndex = 5;
            // 
            // TransportCompany
            // 
            this.TransportCompany.AutoSize = true;
            this.TransportCompany.Location = new System.Drawing.Point(109, 136);
            this.TransportCompany.Name = "TransportCompany";
            this.TransportCompany.Size = new System.Drawing.Size(10, 13);
            this.TransportCompany.TabIndex = 7;
            this.TransportCompany.Text = "-";
            // 
            // TransportCompanylabel
            // 
            this.TransportCompanylabel.AutoSize = true;
            this.TransportCompanylabel.Enabled = false;
            this.TransportCompanylabel.Location = new System.Drawing.Point(9, 136);
            this.TransportCompanylabel.Name = "TransportCompanylabel";
            this.TransportCompanylabel.Size = new System.Drawing.Size(98, 13);
            this.TransportCompanylabel.TabIndex = 6;
            this.TransportCompanylabel.Text = "Transport Company:";
            // 
            // PlaceofSupply
            // 
            this.PlaceofSupply.AutoSize = true;
            this.PlaceofSupply.Location = new System.Drawing.Point(109, 95);
            this.PlaceofSupply.Name = "PlaceofSupply";
            this.PlaceofSupply.Size = new System.Drawing.Size(10, 13);
            this.PlaceofSupply.TabIndex = 5;
            this.PlaceofSupply.Text = "-";
            // 
            // PlaceofSupplylabel
            // 
            this.PlaceofSupplylabel.AutoSize = true;
            this.PlaceofSupplylabel.Enabled = false;
            this.PlaceofSupplylabel.Location = new System.Drawing.Point(8, 95);
            this.PlaceofSupplylabel.Name = "PlaceofSupplylabel";
            this.PlaceofSupplylabel.Size = new System.Drawing.Size(79, 13);
            this.PlaceofSupplylabel.TabIndex = 4;
            this.PlaceofSupplylabel.Text = "Place of Supply:";
            // 
            // VehicleNumber
            // 
            this.VehicleNumber.AutoSize = true;
            this.VehicleNumber.Location = new System.Drawing.Point(105, 57);
            this.VehicleNumber.Name = "VehicleNumber";
            this.VehicleNumber.Size = new System.Drawing.Size(10, 13);
            this.VehicleNumber.TabIndex = 3;
            this.VehicleNumber.Text = "-";
            // 
            // VehicleNumberlabel
            // 
            this.VehicleNumberlabel.AutoSize = true;
            this.VehicleNumberlabel.Enabled = false;
            this.VehicleNumberlabel.Location = new System.Drawing.Point(9, 57);
            this.VehicleNumberlabel.Name = "VehicleNumberlabel";
            this.VehicleNumberlabel.Size = new System.Drawing.Size(61, 13);
            this.VehicleNumberlabel.TabIndex = 2;
            this.VehicleNumberlabel.Text = "Vehicle NO:";
            // 
            // TransportMode
            // 
            this.TransportMode.AutoSize = true;
            this.TransportMode.Location = new System.Drawing.Point(102, 20);
            this.TransportMode.Name = "TransportMode";
            this.TransportMode.Size = new System.Drawing.Size(10, 13);
            this.TransportMode.TabIndex = 1;
            this.TransportMode.Text = "-";
            // 
            // TransportModelabel
            // 
            this.TransportModelabel.AutoSize = true;
            this.TransportModelabel.Enabled = false;
            this.TransportModelabel.Location = new System.Drawing.Point(8, 20);
            this.TransportModelabel.Name = "TransportModelabel";
            this.TransportModelabel.Size = new System.Drawing.Size(83, 13);
            this.TransportModelabel.TabIndex = 0;
            this.TransportModelabel.Text = "Transport Mode:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.comboBoxDCSerialNumber);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 68);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1070, 66);
            this.panel3.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.CornflowerBlue;
            this.button1.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(341, 34);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 22);
            this.button1.TabIndex = 4;
            this.button1.Text = "Load";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Enabled = false;
            this.label3.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 14);
            this.label3.TabIndex = 3;
            this.label3.Text = "Search by DC NO:";
            // 
            // comboBoxDCSerialNumber
            // 
            this.comboBoxDCSerialNumber.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxDCSerialNumber.FormattingEnabled = true;
            this.comboBoxDCSerialNumber.IntegralHeight = false;
            this.comboBoxDCSerialNumber.Location = new System.Drawing.Point(112, 34);
            this.comboBoxDCSerialNumber.Name = "comboBoxDCSerialNumber";
            this.comboBoxDCSerialNumber.Size = new System.Drawing.Size(207, 22);
            this.comboBoxDCSerialNumber.TabIndex = 1;
            this.comboBoxDCSerialNumber.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(12, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(220, 14);
            this.label2.TabIndex = 0;
            this.label2.Text = "Please Select The Delivery Challan Number";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1070, 68);
            this.panel2.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(471, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "Delivery Challan";
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.ReturnDatelabel);
            this.panel11.Controls.Add(this.dateTimePicker2);
            this.panel11.Controls.Add(this.dateTimePicker1);
            this.panel11.Controls.Add(this.DeliveryDatelabel);
            this.panel11.Controls.Add(this.comboBoxDCType);
            this.panel11.Controls.Add(this.comboBoxDCcategories);
            this.panel11.Controls.Add(this.DCTypelabel);
            this.panel11.Controls.Add(this.DCcategorieslabel);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel11.Location = new System.Drawing.Point(0, 473);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(1070, 100);
            this.panel11.TabIndex = 4;
            // 
            // DCcategorieslabel
            // 
            this.DCcategorieslabel.AutoSize = true;
            this.DCcategorieslabel.Enabled = false;
            this.DCcategorieslabel.Location = new System.Drawing.Point(12, 22);
            this.DCcategorieslabel.Name = "DCcategorieslabel";
            this.DCcategorieslabel.Size = new System.Drawing.Size(74, 13);
            this.DCcategorieslabel.TabIndex = 0;
            this.DCcategorieslabel.Text = "DC Categories:";
            // 
            // DCTypelabel
            // 
            this.DCTypelabel.AutoSize = true;
            this.DCTypelabel.Enabled = false;
            this.DCTypelabel.Location = new System.Drawing.Point(12, 59);
            this.DCTypelabel.Name = "DCTypelabel";
            this.DCTypelabel.Size = new System.Drawing.Size(47, 13);
            this.DCTypelabel.TabIndex = 1;
            this.DCTypelabel.Text = "DC Type:";
            // 
            // comboBoxDCcategories
            // 
            this.comboBoxDCcategories.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxDCcategories.FormattingEnabled = true;
            this.comboBoxDCcategories.Items.AddRange(new object[] {
            "Returnable",
            "Non-Returnable"});
            this.comboBoxDCcategories.Location = new System.Drawing.Point(97, 13);
            this.comboBoxDCcategories.Name = "comboBoxDCcategories";
            this.comboBoxDCcategories.Size = new System.Drawing.Size(191, 22);
            this.comboBoxDCcategories.TabIndex = 2;
            this.comboBoxDCcategories.SelectedIndexChanged += new System.EventHandler(this.comboBoxDCcategories_SelectedIndexChanged);
            // 
            // comboBoxDCType
            // 
            this.comboBoxDCType.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxDCType.FormattingEnabled = true;
            this.comboBoxDCType.Location = new System.Drawing.Point(97, 50);
            this.comboBoxDCType.Name = "comboBoxDCType";
            this.comboBoxDCType.Size = new System.Drawing.Size(191, 22);
            this.comboBoxDCType.TabIndex = 3;
            // 
            // DeliveryDatelabel
            // 
            this.DeliveryDatelabel.AutoSize = true;
            this.DeliveryDatelabel.Location = new System.Drawing.Point(332, 13);
            this.DeliveryDatelabel.Name = "DeliveryDatelabel";
            this.DeliveryDatelabel.Size = new System.Drawing.Size(73, 13);
            this.DeliveryDatelabel.TabIndex = 4;
            this.DeliveryDatelabel.Text = "Delivery Date:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(411, 11);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(173, 21);
            this.dateTimePicker1.TabIndex = 5;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(411, 51);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(173, 21);
            this.dateTimePicker2.TabIndex = 6;
            // 
            // ReturnDatelabel
            // 
            this.ReturnDatelabel.AutoSize = true;
            this.ReturnDatelabel.Location = new System.Drawing.Point(332, 54);
            this.ReturnDatelabel.Name = "ReturnDatelabel";
            this.ReturnDatelabel.Size = new System.Drawing.Size(66, 13);
            this.ReturnDatelabel.TabIndex = 7;
            this.ReturnDatelabel.Text = "Return Date:";
            // 
            // Updatebutton
            // 
            this.Updatebutton.BackColor = System.Drawing.Color.CornflowerBlue;
            this.Updatebutton.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Updatebutton.ForeColor = System.Drawing.Color.White;
            this.Updatebutton.Location = new System.Drawing.Point(976, 591);
            this.Updatebutton.Name = "Updatebutton";
            this.Updatebutton.Size = new System.Drawing.Size(82, 28);
            this.Updatebutton.TabIndex = 5;
            this.Updatebutton.Text = "Update";
            this.Updatebutton.UseVisualStyleBackColor = false;
            // 
            // DC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1070, 642);
            this.Controls.Add(this.panel1);
            this.Name = "DC";
            this.Text = "DC";
            this.Load += new System.EventHandler(this.DC_Load);
            this.panel1.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ComboBox comboBoxDCSerialNumber;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label DCFor;
        private System.Windows.Forms.Label DCForlabel;
        private System.Windows.Forms.Label DCSerialNumber;
        private System.Windows.Forms.Label DCSerialNumberlabel;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label DCReference;
        private System.Windows.Forms.Label labelDCReference;
        private System.Windows.Forms.Label DCWorkOrder;
        private System.Windows.Forms.Label labelDCWorkOrder;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label DispatchDate;
        private System.Windows.Forms.Label DateofChallan;
        private System.Windows.Forms.Label DispatchDatelabel;
        private System.Windows.Forms.Label labelDateofChallan;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label TransportCompany;
        private System.Windows.Forms.Label TransportCompanylabel;
        private System.Windows.Forms.Label PlaceofSupply;
        private System.Windows.Forms.Label PlaceofSupplylabel;
        private System.Windows.Forms.Label VehicleNumber;
        private System.Windows.Forms.Label VehicleNumberlabel;
        private System.Windows.Forms.Label TransportMode;
        private System.Windows.Forms.Label TransportModelabel;
        private System.Windows.Forms.Label DRAddress;
        private System.Windows.Forms.Label DRAddresslabel;
        private System.Windows.Forms.Label DRName;
        private System.Windows.Forms.Label DRNamelabel;
        private System.Windows.Forms.Label DCBy;
        private System.Windows.Forms.Label DCBylabel;
        private System.Windows.Forms.Label DRStateCode;
        private System.Windows.Forms.Label DRStateCodelabel;
        private System.Windows.Forms.Label DRState;
        private System.Windows.Forms.Label DRStatelabel;
        private System.Windows.Forms.Label DRGSTIN;
        private System.Windows.Forms.Label DRGSTINlabel;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label Remarks;
        private System.Windows.Forms.Label Remarkslabel;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.ComboBox comboBoxDCType;
        private System.Windows.Forms.ComboBox comboBoxDCcategories;
        private System.Windows.Forms.Label DCTypelabel;
        private System.Windows.Forms.Label DCcategorieslabel;
        private System.Windows.Forms.Button Updatebutton;
        private System.Windows.Forms.Label ReturnDatelabel;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label DeliveryDatelabel;
    }
}