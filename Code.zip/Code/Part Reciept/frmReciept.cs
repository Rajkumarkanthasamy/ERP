﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Diagnostics;
using System.Globalization;
using System.Net;
using System.Net.Mail;
using System.Collections.Generic;
using System.Reflection;
using Outlook = Microsoft.Office.Interop.Outlook;
using System.Reflection;
using System.Net;
using System.Net.Mail;
using System.Configuration;
using System.Threading;

using Zen.Barcode;
using QRCoder;
using System.Drawing.Printing;
using System.Drawing;









namespace Erp_Project_With_Buttons
{
    public partial class frmReciept : Form
    {
        frmForm2 frm = new frmForm2();
        Global GLobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        DataTable dtWOList = new DataTable();
        DataTable DTWOnumber = new DataTable();
        DataTable dtItemList = new DataTable();
        double dReceipt;
        double dAvailableQty;
        string itemcreateddate;
        double dStockValue;
        private string sJWNumber = string.Empty;
        SqlConnection SQLCon;
        double dTotalReceiptCost;
        bool bTaxStatus = false;
        TextBox txt;
        DataTable DTtaxreturn = new DataTable();
        Login.frmLoginForm login = new Login.frmLoginForm();
        Part_Reciept.DocumentScanning docscan = new Part_Reciept.DocumentScanning();
        DataTable dtlogindetails = new DataTable();
        double dTotalAmount = 0;
        double dTotalDiscount = 0;
        double dTotalSgst = 0;
        double dTotalCgst = 0;
        double dTotalIgst = 0;
        DataTable ledger = new DataTable();
        bool itemWithoutLocation = false;
        //This code added for bardcode print!
        // Generate and display barcode




        private void dgvPOItemList_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            HideReceiveQuantityColumn();
        }

        private void HideReceiveQuantityColumn()
        {
            var col = dgvPOItemList.Columns["RecieveQuantity"]; // check spelling!
            if (col != null)
            {
                col.Visible = false;
            }
        }


        public frmReciept()
        {
            InitializeComponent();
            dgvPOItemList.EditingControlShowing += dgvPOItemList_EditingControlShowing1;
        }

        private void frmReciept_Load(object sender, EventArgs e)
        {
            RecieveQuantity.Visible = false;
            chkGINPO.Checked = true;
            dgvPOItemList.Columns[0].Width = 50;
            dgvPOItemList.Columns[1].Width = 50;
            dgvPOItemList.Columns[2].Width = 150;
            dgvPOItemList.Columns[3].Width = 400;
            dtpGINDate.Format = DateTimePickerFormat.Custom;
            dtpGINDate.CustomFormat = "dd-MM-yyyy";
            //dtpGINDate.Format = DateTimePickerFormat.Custom;
            //dtpGINDate.CustomFormat = "dd-MM-yyyy HH:mm:ss";

            dtpInvoiceDate.Format = DateTimePickerFormat.Custom;
            dtpInvoiceDate.CustomFormat = "dd-MM-yyyy";

            lblUser.Text = login.GetUserDetails[2];

            if (login.GetUserDetails[2].ToLower() == "theertha rao" || login.GetUserDetails[2].ToLower() == "rashmi" || login.GetUserDetails[2].ToLower() == "sandeep s" || login.GetUserDetails[2].ToLower() == "biss" || login.GetUserDetails[2].ToLower() == "shridhar")
            {
                chkOtherItems.Visible = true;
            }
            //ledger = DAL.fnGetLastGINnumber(1).Tables[0];
            //foreach (DataRow DR in ledger.Rows)
            //{
            //    if (!cmbLedger.Items.Contains(DR["LedgerName"].ToString()))
            //        cmbLedger.Items.Add(DR["LedgerName"].ToString());
            //}

        }

        private void frmReceipt_load(object senter, EventArgs e)
        {
            loadItemLocations();
        }
        private void loadItemLocations()
        {
            var location = new List<string> { "a", "b", "c" };
            DataGridViewComboBoxColumn combocol = (DataGridViewComboBoxColumn)dgvPOItemList.Columns["itemLocation"];
            combocol.DataSource = location;
        }
        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
            frm.Show();
        }

        private void btnExit_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            frm.Show();
        }

        private void frmReciept_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            frm.Show();
        }

        // Code for Recieving the Brought out & JobWork Items
        DataTable dtItemDetails = new DataTable();
        DataTable dtGINDeliveryDays = new DataTable();
        DataTable dtInvoicenumber = new DataTable();

        //DataTable dtItemtype = new DataTable();
        string sLedgerName = "";
        private void fnLedger(string sItemType)
        {
            sLedgerName = "";
            if (chkGINPO.CheckState == CheckState.Checked)
            {
                switch (sItemType)
                {
                    case "Consumable":
                        sLedgerName = "50001 Purhcase Consumables";
                        break;
                    case "Broughtout":
                        sLedgerName = "50001 Purhcase Rawmaterials";
                        break;
                    case "Electronics":
                        sLedgerName = "50001 Purhcase Electronics";
                        break;
                    case "Electricals":
                        sLedgerName = "50001 Purhcase Electricals";
                        break;
                    case "Boughtout":
                        sLedgerName = "50001 Purhcase Rawmaterials";
                        break;
                    case "Mechanical":
                        sLedgerName = "50001 Purhcase Mechanical";
                        break;
                    case "Hydraulics":
                        sLedgerName = "50001 Purhcase Hydraulics";
                        break;
                    case "KanBan":
                        sLedgerName = "50001 Purhcase KanBan";
                        break;
                    case "Transducers":
                        sLedgerName = "50001 Purhcase Transducers";
                        break;
                    case "Maintenance":
                        sLedgerName = "50001 Purhcase Maintenance";
                        break;
                    case "Electronics RnD":
                        sLedgerName = "50001 Purhcase Electronics";
                        break;
                    case "Service(Non-Inventory)":
                        sLedgerName = "50300 Service Charges";
                        break;
                    case "Testlab":
                        sLedgerName = "50001 Purhcase RM Test Lab";
                        break;
                    case "TGT":
                        sLedgerName = "50001 Purhcase TGT";
                        break;
                    case "Tools":
                        sLedgerName = "50001 Purhcase Tools";
                        break;
                    case "Packing Materials":
                        sLedgerName = "50001 Purhcase Packing Materials";
                        break;
                    case "FixedAsset":
                        sLedgerName = "12099 Capital Work in Progress";
                        break;
                }
            }
            else if (chkGINWO.CheckState == CheckState.Checked)
            {
                switch (sItemType)
                {
                    case "Consumable":
                        sLedgerName = "50000 Job Work/Cutting Charges Consumables";
                        break;
                    case "Broughtout":
                        sLedgerName = "50000 Job Work/Cutting Charges Rawmaterials";
                        break;
                    case "Electronics":
                        sLedgerName = "50000 Job Work/Cutting Charges Electronics";
                        break;
                    case "Electricals":
                        sLedgerName = "50000 Job Work/Cutting Charges Electricals";
                        break;
                    case "Boughtout":
                        sLedgerName = "50000 Job Work/Cutting Charges Rawmaterials";
                        break;
                    case "Mechanical":
                        sLedgerName = "50000 Job Work/Cutting Charges Mechanical";
                        break;
                    case "Hydraulics":
                        sLedgerName = "50000 Job Work/Cutting Charges Hydraulics";
                        break;
                    case "KanBan":
                        sLedgerName = "50000 Job Work/Cutting Charges KanBan";
                        break;
                    case "Transducers":
                        sLedgerName = "50000 Job Work/Cutting Charges Transducers";
                        break;
                    case "Maintenance":
                        sLedgerName = "50000 Job Work/Cutting Charges Maintenance";
                        break;
                    case "Electronics RnD":
                        sLedgerName = "50000 Job Work/Cutting Charges Electronics";
                        break;
                    case "Service(Non-Inventory)":
                        sLedgerName = "50000 Job Work/Cutting Charges Service(Non-Inventory)";
                        break;
                    case "Testlab":
                        sLedgerName = "50000 Job Work/Cutting Charges Testlab";
                        break;
                    case "TGT":
                        sLedgerName = "50000 Job Work/Cutting Charges TGT";
                        break;
                    case "Tools":
                        sLedgerName = "50000 Job Work/Cutting Charges Tools";
                        break;
                    case "Packing Materials":
                        sLedgerName = "50000 Job Work/Cutting Charges Materials";
                        break;
                    case "FixedAsset":
                        sLedgerName = "50000 Job Work/Cutting Charges Fixed Asset";
                        break;
                }
            }

            if (lblCountry.Text.ToLower() != "india")
            {
                sLedgerName = sLedgerName + "-Import";
            }


        }

        //ItemCode, GINNumber, CreatedDate, PONumber,  BOMProjectCode, ProjectCode,  IndentNumbers,ReceivedQtY,PORequariedQty, RemainingQty,
        //IssuedQty, IndentDates, IssuedDates, BatchCode, ItemLocation, IssuedProjectCodes

        //private void demoFunction_old(object sender, EventArgs e)
        //{
        // string barcodeValue = "110920251655";
        //Code128BarcodeDraw barcode = BarcodeDrawFactory.Code128WithChecksum;
        //Image barcodeImage = barcode.Draw(barcodeValue, 50);
        //pictureBoxBarcode.Image = barcodeImage;
        // Print barcode
        //try { 
        //  PrintDocument printDoc = new PrintDocument();


        //printDoc.PrintPage += (s, ev) =>
        //{
        //  if (pictureBoxBarcode.Image != null)
        //{
        //  ev.Graphics.DrawImage(pictureBoxBarcode.Image, new Point(10, 10));
        //}
        //};
        //printDoc.Print();
        //MessageBox.Show("Printed Successfully!");
        //}
        //catch (Exception ex)
        //{
        //   MessageBox.Show("Error: " + ex.Message);
        //}
        //}

        private void demoFunction_(object sender, EventArgs e)
        {

            foreach (string printer in PrinterSettings.InstalledPrinters)
            {
                MessageBox.Show(printer);
            }
        }













        private void demoFunction(object sender, EventArgs e)
        {
            var labels = new List<Dictionary<string, string>>
    {
        new Dictionary<string, string>
        {
            { "QrValue", "HYD-BOS-000002110920251649" },
            { "ItemCode", "HYD-BOS-000002" },
            { "VendorCode", "TSC TTP-345" },
            { "BatchCode", "110920251649" },
            { "Count", "100" }
        },
        new Dictionary<string, string>
        {
            { "QrValue", "HYD-BOS-000003110920251650" },
            { "ItemCode", "HYD-BOS-000003" },
            { "VendorCode", "TSC TTP-345" },
            { "BatchCode", "110920251650" },
            { "Count", "200" }
        },
        new Dictionary<string, string>
        {
            { "QrValue", "HYD-BOS-000004110920251651" },
            { "ItemCode", "HYD-BOS-000004" },
            { "VendorCode", "TSC TTP-345" },
            { "BatchCode", "110920251651" },
            { "Count", "300" }
        },
        new Dictionary<string, string>
        {
            { "QrValue", "HYD-BOS-000005110920251652" },
            { "ItemCode", "HYD-BOS-000005" },
            { "VendorCode", "TSC TTP-345" },
            { "BatchCode", "110920251652" },
            { "Count", "400" }
        }
    };

            PrintDocument printDoc = new PrintDocument();
            printDoc.PrinterSettings.PrinterName = "TSC TE210";

            int labelWidth = 394;  // 10 cm approx
            int labelHeight = 197; // 2.5 cm approx
            int columns = 1;
            int rowsPerPage = 4; // Adjust based on printer page size

            PaperSize pageSize = new PaperSize("CustomPage", labelWidth * columns, labelHeight * rowsPerPage);
            printDoc.DefaultPageSettings.PaperSize = pageSize;

            int currentIndex = 0;

            printDoc.PrintPage += (s, ev) =>
            {
                using (Font font = new Font("Arial", 9, FontStyle.Regular))
                using (StringFormat centerFormat = new StringFormat()
                {
                    Alignment = StringAlignment.Center,
                    LineAlignment = StringAlignment.Near
                })
                {
                    for (int row = 0; row < rowsPerPage && currentIndex < labels.Count; row++)
                    {
                        for (int col = 0; col < columns && currentIndex < labels.Count; col++)
                        {
                            var label = labels[currentIndex];

                            // Generate QR Code
                            QRCodeGenerator qrGenerator = new QRCodeGenerator();
                            QRCodeData qrCodeData = qrGenerator.CreateQrCode(label["QrValue"], QRCodeGenerator.ECCLevel.Q);
                            QRCode qrCode = new QRCode(qrCodeData);
                            Bitmap qrCodeImage = qrCode.GetGraphic(2);

                            int xOffset = col * labelWidth;
                            int yOffset = row * labelHeight;
                            float y = yOffset + 5;

                            // Draw QR Code
                            int qrX = xOffset + (labelWidth - qrCodeImage.Width) / 6;
                            ev.Graphics.DrawImage(qrCodeImage, qrX, (int)y);

                            // Draw Item Code
                            ev.Graphics.DrawString(label["ItemCode"], font, Brushes.Black,
                                new RectangleF(xOffset, y, labelWidth, 20), centerFormat);
                            y += 20;

                            // Draw Batch Code & Count
                            string batchAndCount = $"{label["BatchCode"]}  {label["Count"]}";
                            ev.Graphics.DrawString(batchAndCount, font, Brushes.Black,
                                new RectangleF(xOffset, y, labelWidth, 20), centerFormat);
                            y += 20;

                            // Draw Vendor Code
                            ev.Graphics.DrawString(label["VendorCode"], font, Brushes.Black,
                                new RectangleF(xOffset, y, labelWidth, 20), centerFormat);

                            currentIndex++;
                        }
                    }
                }

                ev.HasMorePages = currentIndex < labels.Count;
            };

            printDoc.Print();
        }





        //this code end for printing barcode


        private void bttestSave_Click(object sender, EventArgs e)
        {
            DataTable Gindttest = new DataTable();
            Dictionary<string, string> itemBatchDict = new Dictionary<string, string>();
            Gindttest = DAL.fnGetLastGINnumber(0).Tables[0];
            String testLastGINNO = "";


            if (Gindttest.Rows.Count > 0)
            {
                int iGinNUm = Convert.ToInt32(Gindttest.Rows[0][0].ToString());
                iGinNUm++;
                Gindttest = DAL.fnGetLastGINnumber(0).Tables[0];
                string lastginNotest = Gindttest.Rows[0]["GINNo"].ToString();
                testLastGINNO = "ITWGIN" + iGinNUm.ToString();
            }

            foreach (DataGridViewRow row in dgvPOItemList.Rows)
            {
                if (row.Cells["itemLocation"].Value?.ToString() == "NOLOCATION")
                {
                    MessageBox.Show("Item Don't Have Location Can you please update Location...!");
                }
                else
                {
                    if (row.IsNewRow) continue;

                    string itemCode = row.Cells["itemCode"].Value?.ToString();
                    string selectedLocation = row.Cells["itemLocation"].Value?.ToString(); ;

                    if (row.Cells["itemLocation"].Value?.ToString() == "0" || row.Cells["itemLocation"].Value?.ToString() == null)
                    {
                        selectedLocation = "NOLOCATION";
                    }

                    string GINDATE = dtpGINDate.Text;
                    string POWONUMBER = cmbPonumber.Text;
                    string BOMPROJECTCODE = row.Cells["ProjectCode"].Value?.ToString();
                    string PROJECTCODE = lblprojcode.Text;
                    //indentnO
                    double RECEIVEDQRT = Convert.ToDouble(row.Cells["RecieveQuantity"].Value);
                    double POREQUARIEDQTY = Convert.ToDouble(row.Cells["OrderedQty"].Value);
                    string BATCHCODE = row.Cells["batchCode"].Value?.ToString();

                    string barcodeValue = row.Cells["batchCode"].Value?.ToString();

                    Code128BarcodeDraw barcode = BarcodeDrawFactory.Code128WithChecksum;
                    Image barcodeImage = barcode.Draw(barcodeValue, 50);

                    if (!itemBatchDict.ContainsKey(itemCode))
                    {
                        itemBatchDict.Add(itemCode, barcodeValue);
                    }

                    // DAL.fnAddERPInventoryLogs("NEW", itemCode, row.Cells["ItemDescription"].Value?.ToString(), testLastGINNO, GINDATE, POWONUMBER, BOMPROJECTCODE, PROJECTCODE, RECEIVEDQRT, RECEIVEDQRT, BATCHCODE, selectedLocation, barcodeImage, txtVendorcode.Text);
                    //MessageBox.Show($"itemCode:{itemCode.Length}Location:{selectedLocation.Length}GINDATE:{GINDATE.Length}PONUMBER:{PONUMBER.Length}BOMPROJECTCODE:{BOMPROJECTCODE.Length}PROJECTCODE:{PROJECTCODE.Length}RECEIVEDQRT:{RECEIVEDQRT}POREQUARIEDQTY:{POREQUARIEDQTY}BATCHCODE:{BATCHCODE.Length}");
                    //unitPrice, double sgst, double cgst, double igst, double poAmount
                }
            }

            foreach (KeyValuePair<string, string> kvp in itemBatchDict)
            {
                string itemCodeTemp = kvp.Key;
                string batchCodeTemp = kvp.Value;
                // Use itemCode and batchCode as needed
                // this code for print the bar code 
                //Code128BarcodeDraw barcode = BarcodeDrawFactory.Code128WithChecksum;
                // Image barcodeImage = barcode.Draw(batchCodeTemp, 50);
                // PrintDocument printDoc = new PrintDocument();
                //printDoc.PrinterSettings.PrinterName = "TSC TTP-345";
                //PaperSize labelSize = new PaperSize("CustomLabel", 394, 197);
                //printDoc.DefaultPageSettings.PaperSize = labelSize;
                //printDoc.PrintPage += (s, ev) =>
                // {
                //   int x = (labelSize.Width - barcodeImage.Width) / 2;
                // int y = 10;
                //ev.Graphics.DrawImage(barcodeImage, x, y);
                // using (Font font = new Font("Arial", 10))
                // {
                //    ev.Graphics.DrawString(itemCodeTemp, font, Brushes.Black, new PointF(x, y + barcodeImage.Height + 5));
                // }
                //};

                // printDoc.Print();
                //barcode print code end...
                //MessageBox.Show($"ItemCode: {itemCodeTemp}, BatchCode: {batchCodeTemp }");
            }

        }



        private void btnSave_Click(object sender, EventArgs e)
        {
            int checke = 0; ;
            DataTable Gindt = new DataTable();
            double dRemQty = 0.0;
            bool bRemainingQtyCheck = false;
            bool bItemNotSelected = true;
            SQLCon = new SqlConnection(DataAccessLayer.cs);

            //foreach(DataGridViewRow row in dgvPOItemList.Rows)
            //{
            //  if (row.IsNewRow) continue;
            // string itemCode = row.Cells["itemCode"].Value?.ToString();
            //string selectedLocation = row.Cells["itemLocation"].Value?.ToString();
            //Console.WriteLine($"{itemCode} -> Location{selectedLocation}");
            //}



            if (dgvPOItemList.Rows.Count > 0)
            {
                foreach (DataGridViewRow row in dgvPOItemList.Rows)
                {

                    if (Convert.ToBoolean(row.Cells["Select"].Value) == true && row.Cells["itemLocation"].Value?.ToString() == "NOLocation")
                    {
                        //MessageBox.Show("Item Don't Have Location Can you please update Location...!");
                        //return;
                    }


                    if (Convert.ToDouble(row.Cells["RecieveQuantity"].Value) == 0.0 || row.Cells["RecieveQuantity"].Value == null)
                    {
                        bItemNotSelected = true;
                        MessageBox.Show("Enter the quantity of item(s) to be recieved", "Error", 0, MessageBoxIcon.Error);
                        break;
                    }
                    else
                    {
                        bItemNotSelected = false;
                    }
                }
            }

            dtInvoicenumber = DAL.fnCheckInvoicenumber(0, txtVendorcode.Text, txtinvoiceno.Text).Tables[0];

            if (string.IsNullOrEmpty(txtinvoiceno.Text))
            {
                MessageBox.Show("Enter invoice number. Items not recieved", "Error", 0, MessageBoxIcon.Error);
                txtinvoiceno.Focus();
            }
            else if (dtInvoicenumber.Rows.Count > 0)
            {
                MessageBox.Show("Entered invoice number already used for the vendor. Items not recieved", "Error", 0, MessageBoxIcon.Error);
                txtinvoiceno.Focus();
            }

            //else if (cmbLedger.SelectedIndex < 0)
            //{
            //    MessageBox.Show("Please select the ledger. Items not recieved", "Error", 0, MessageBoxIcon.Error);
            //    cmbLedger.Focus();
            //}
            else if (bInvoiceDate == false)
            {
                MessageBox.Show("Please Select the invoice date. Items not recieved", "Error", 0, MessageBoxIcon.Error);
                dtpInvoiceDate.Focus();
            }
            else if (bItemNotSelected == false)
            {
                if (dgvPOItemList.Rows.Count > 0)
                {
                    dTotalReceiptCost = 0.0;
                    bItemNotSelected = true;
                    foreach (DataGridViewRow row in dgvPOItemList.Rows)
                    {
                        if (Convert.ToBoolean(row.Cells["Select"].Value) == true)
                        {
                            dTotalReceiptCost += Convert.ToDouble(row.Cells["UnitCost"].Value) * Convert.ToDouble(row.Cells["RecieveQuantity"].Value);
                        }
                    }
                    Gindt = DAL.fnGetLastGINnumber(0).Tables[0];
                    if (Gindt.Rows.Count > 0)
                    {
                        int iGinNUm = Convert.ToInt32(Gindt.Rows[0][0].ToString());
                        iGinNUm++;
                        GLobalClass.iSuccess = DAL.fnAddJobMovenment(Global.uINSERT, cmbPonumber.Text, txtinvoiceno.Text, (dtpGINDate.Text), dTotalReceiptCost, (dtpGINDate.Text), lblUser.Text, iGinNUm);
                        Gindt = DAL.fnGetLastGINnumber(0).Tables[0];
                        string lastginNo = Gindt.Rows[0]["GINNo"].ToString();
                        lblGinno.Text = lastginNo;
                        if (GLobalClass.iSuccess > 0)
                        {
                            double totalCumQty = 0;
                            double freightTotal = 0;
                            double packagingTotal = 0;

                            string poNumber = cmbPonumber.Text;

                            // Step 1: Fetch charges (freight and packaging) from dgPackingTaxes grid instead of DB


                            if (dgPackingTaxes.Rows.Count > 0)
                            {
                                foreach (DataGridViewRow row in dgPackingTaxes.Rows)
                                {
                                    if (row.Cells[0].Value == null) continue;

                                    string description = row.Cells[0].Value.ToString().Trim();

                                    if (description.Equals("Transportation / Freight", StringComparison.OrdinalIgnoreCase))
                                    {
                                        freightTotal = Convert.ToDouble(row.Cells[1].Value) / Convert.ToDouble(textBRate.Text);// Assuming amount is in cell[1]
                                    }
                                    else if (description.Equals("Packing & Forwarding", StringComparison.OrdinalIgnoreCase))
                                    {
                                        packagingTotal = Convert.ToDouble(row.Cells[1].Value) / Convert.ToDouble(textBRate.Text);//Assuming amount is in cell[1]
                                    }
                                }
                            }


                            // Step 2: Calculate total cumQty for selected items
                            foreach (DataGridViewRow row in dgvPOItemList.Rows)
                            {
                                if (Convert.ToBoolean(row.Cells["Select"].Value) == true)
                                {
                                    double qty = Convert.ToDouble(row.Cells["RecieveQuantity"].Value);
                                    double unitCost = Convert.ToDouble(row.Cells["UnitCost"].Value);
                                    totalCumQty += qty * unitCost;
                                }
                            }

                            // Step 3: Loop through selected items and distribute freight/packaging
                            foreach (DataGridViewRow row in dgvPOItemList.Rows)
                            {
                                if (Convert.ToBoolean(row.Cells["Select"].Value) == true)
                                {
                                    string itemCode = row.Cells["ItemCode"].Value.ToString();

                                    dtItemDetails = DAL.fnItemDetails(itemCode).Tables[0];

                                    if (dtItemDetails.Rows.Count > 0)
                                        fnLedger(dtItemDetails.Rows[0]["Type"].ToString());
                                    else
                                        sLedgerName = "";

                                    double qty = Convert.ToDouble(row.Cells["RecieveQuantity"].Value);
                                    double unitCost = Convert.ToDouble(row.Cells["UnitCost"].Value);
                                    double cumQty = qty * unitCost;

                                    // Share percentage
                                    double percentage = cumQty / totalCumQty;

                                    // Distribute freight and packaging
                                    double itemFreight = freightTotal * percentage;
                                    double itemPackaging = packagingTotal * percentage;

                                    //This code for update the HSN Number In ItemMaster
                                    try
                                    {
                                        DataTable itemMasterData = DAL.fnGetItemMasterHSNNumber(row.Cells["ItemCode"].Value.ToString()).Tables[0];

                                        if (itemMasterData.Rows.Count > 0)
                                        {
                                          //  MessageBox.Show("Can able to get the Item Master Data!");
                                           // MessageBox.Show(Convert.ToString(itemMasterData.Rows[0]["HSNSACCode"]));
                                            if (itemMasterData.Rows[0]["HSNSACCode"].ToString() == "" || string.IsNullOrEmpty(itemMasterData.Rows[0]["HSNSACCode"].ToString()))
                                            {
                                               // MessageBox.Show("Can able to update Item Master Data!");
                                                int fnUpdateERPItemCodeHSNNumberStatus = DAL.fnUpdateERPItemCodeHSNNumber("UPDATE", row.Cells["ItemCode"].Value.ToString(), row.Cells["HsnSacCode"].Value.ToString());
                                                //MessageBox.Show("HSNSACCode", "Updated...");
                                            }
                                        }
                                    }
                                    catch { 
                                    
                                    }

                                    

                                    GLobalClass.iSuccess = DAL.fnAddReciept(Global.uINSERT, row.Cells["ItemCode"].Value.ToString(), row.Cells["ProjectCode"].Value != null ? row.Cells["ProjectCode"].Value.ToString() : string.Empty, row.Cells["ProductNo"].Value != null ? Convert.ToInt32(row.Cells["ProductNo"].Value) : 0, lblGinno.Text, Convert.ToDouble(row.Cells["RecieveQuantity"].Value),
                                     (Convert.ToDouble(row.Cells["UnitCost"].Value) / Convert.ToDouble(textBRate.Text)), lblVendor.Text, dtpGINDate.Text, txtinvoiceno.Text, "Boughtout", cmbPonumber.Text, dtpInvoiceDate.Text, txtVendorcode.Text
                                     , Convert.ToDouble(row.Cells["IGSTRate"].Value), Convert.ToDouble(row.Cells["IGSTAmount"].Value), Convert.ToDouble(row.Cells["SGSTRate"].Value),
                                     Convert.ToDouble(row.Cells["SGSTAmount"].Value), Convert.ToDouble(row.Cells["CGSTRate"].Value), Convert.ToDouble(row.Cells["CGSTAmount"].Value),
                                     sLedgerName, row.Cells["HsnSacCode"].Value.ToString(), Convert.ToDouble(row.Cells["DiscRate"].Value), Convert.ToDouble(row.Cells["DiscAmount"].Value), Convert.ToDouble(txtTCSAmount.Text),
                                     Convert.ToDouble(row.Cells["CustomsDuty"].Value), Convert.ToDouble(row.Cells["CustomsDutyAmt"].Value), Convert.ToDouble(row.Cells["Cess"].Value),
                                     Convert.ToDouble(row.Cells["CessAmt"].Value), Convert.ToDouble(row.Cells["CDIGST"].Value), Convert.ToDouble(row.Cells["CDIGSTAmt"].Value), itemPackaging, itemFreight, combocurrency.Text, Convert.ToDouble(textBRate.Text), Convert.ToDouble((row.Cells["POAmount"].Value == null) ? 0 : row.Cells["POAmount"].Value));


                                    //New code for Batch code 

                                    if (true)
                                    {

                                        try
                                        {

                                            string itemCode_ERP = row.Cells["itemCode"].Value?.ToString();
                                            string selectedLocation = row.Cells["itemLocation"].Value?.ToString();

                                            //if (row.Cells["itemLocation"].Value?.ToString() == "0" || row.Cells["itemLocation"].Value?.ToString() == null)
                                            // {
                                            // selectedLocation = "NOLOCATION";
                                            // }

                                            string GINDATE = dtpGINDate.Text;
                                            string POWONUMBER = cmbPonumber.Text;
                                            string BOMPROJECTCODE = row.Cells["ProjectCode"].Value?.ToString();
                                            string PROJECTCODE = lblprojcode.Text;
                                            //indentnO
                                            double RECEIVEDQRT = Convert.ToDouble(row.Cells["RecieveQuantity"].Value);
                                            double POREQUARIEDQTY = Convert.ToDouble(row.Cells["OrderedQty"].Value);
                                            string BATCHCODE = row.Cells["batchCode"].Value?.ToString();

                                            string barcodeValue = row.Cells["batchCode"].Value?.ToString();

                                            Code128BarcodeDraw barcode = BarcodeDrawFactory.Code128WithChecksum;
                                            Image barcodeImage = barcode.Draw(itemCode_ERP + "" + barcodeValue, 50);

                                            // MessageBox.Show(row.Cells["ItemDescription"].Value?.ToString(), "description");

                                            



                                            DAL.fnAddERPInventoryLogs("NEW", itemCode_ERP, row.Cells["ItemDescription"].Value?.ToString(), lblGinno.Text, GINDATE, POWONUMBER, row.Cells["ProjectCode"].Value?.ToString(), RECEIVEDQRT, RECEIVEDQRT, BATCHCODE, selectedLocation, txtVendorcode.Text,
                                                Convert.ToDouble(row.Cells["UnitCost"].Value), Convert.ToDouble(row.Cells["SGSTAmount"].Value), Convert.ToDouble(row.Cells["CGSTAmount"].Value), Convert.ToDouble(row.Cells["IGSTAmount"].Value), Convert.ToDouble((row.Cells["POAmount"].Value == null) ? 0 : row.Cells["POAmount"].Value), Convert.ToDouble(row.Cells["OrderedQty"].Value));
                                            //unitPrice, double sgst, double cgst, double igst, double poAmount     

                                        }
                                        catch (Exception error)
                                        {
                                            MessageBox.Show(error.Message, "Error Message for creating EPR Inventory Logs");
                                        }
                                    }

                                    //
                                    //New code End for adding Create ERP Inventory Logs....

                                    dRemQty = Convert.ToDouble(row.Cells["RemainingQty"].Value.ToString()) - Convert.ToDouble(row.Cells["RecieveQuantity"].Value.ToString());
                                    row.Cells["RemainingQty"].Value = dRemQty.ToString();



                                    if (dtItemDetails.Rows.Count > 0)
                                    {
                                        if (dtItemDetails.Rows[0]["CreatedDate"].ToString() == "")
                                        {
                                            itemcreateddate = dtpGINDate.Text;
                                        }
                                        else
                                        {
                                            itemcreateddate = (dtItemDetails.Rows[0]["CreatedDate"].ToString());
                                        }
                                        if (dtItemDetails.Rows[0]["AvailableQty"].ToString() == "")
                                        {
                                            dAvailableQty = (Convert.ToDouble(row.Cells["RecieveQuantity"].Value));
                                        }
                                        else
                                        {
                                            dAvailableQty = Convert.ToDouble(dtItemDetails.Rows[0]["AvailableQty"].ToString()) + (Convert.ToDouble(row.Cells["RecieveQuantity"].Value));
                                        }
                                        if (dtItemDetails.Rows[0]["Receipt"].ToString() == "")
                                        {

                                            dReceipt = (Convert.ToDouble(row.Cells["RecieveQuantity"].Value));
                                        }
                                        else
                                        {
                                            dReceipt = Convert.ToDouble(dtItemDetails.Rows[0]["Receipt"].ToString()) + (Convert.ToDouble(row.Cells["RecieveQuantity"].Value));
                                        }
                                        if (dtItemDetails.Rows[0]["UnitCost"].ToString() == "")
                                        {
                                            dStockValue = 0;
                                        }
                                        else
                                        {
                                            dStockValue = Convert.ToDouble(dtItemDetails.Rows[0]["UnitCost"]) * dAvailableQty;
                                        }
                                    }

                                    DataSet ds = DAL.fnGetTransactionType(poNumber);

                                    //The Next Line For Block the war cost update..




                                    if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                                    {
                                        string transactionType = ds.Tables[0].Rows[0]["TransactionType"].ToString();

                                        if (transactionType.Equals("Domestic", StringComparison.OrdinalIgnoreCase))
                                        {

                                            //Weighted Average Rate calculation implentation.


                                            string itemcode = row.Cells["ItemCode"].Value.ToString();

                                            InventoryService service = new InventoryService();

                                            // Optional: Load full date range, or just relevant past
                                            //DateTime fromDate = DateTime.Now.AddMonths(-12); // last year
                                            //DateTime toDate = DateTime.Now;

                                            // Correctly formatted DateTime
                                            DateTime fromDate = new DateTime(2025, 3, 31, 0, 0, 0); // January 9, 2022 at 00:00:00
                                            DateTime toDate = DateTime.Now; // April 9, 2024 at 23:59:59



                                            // Step 1: Load all transactions for that item
                                            List<InventoryTransaction> transactions = service.LoadTransactions(fromDate, toDate, itemcode);

                                            // Step 2: Run WAR
                                            List<WarResult> warResults = service.CalculateWAR(transactions);

                                            // Step 3: Get latest WAR (last transaction)
                                            decimal latestWAR = 0;
                                            if (warResults.Count > 0)
                                                latestWAR = warResults.Last().WeightedAverageRate;
                                            GLobalClass.iSuccess = DAL.fnUpdateItemDetails(Global.uUPDATE, (String.Format("{0:MM/dd/yyyy}", itemcreateddate.ToString())), dAvailableQty, dReceipt, dStockValue, row.Cells["ItemCode"].Value.ToString(), (double)latestWAR);

                                            GLobalClass.iSuccess = DAL.fnAddERPLog(0, lblGinno.Text, login.GetUserDetails[2], dtpGINDate.Text, "Latest WAR Updated" + " " + latestWAR.ToString() + " " + itemcode, "Receipt");
                                        }

                                        // WAR code end....




                                        // decimal war = CalculateWAR(purchases, itemcode);
                                        // Console.WriteLine($"weighted average rate for {itemcode}:{war:F2}");




                                        //if (chkGINPO.CheckState == CheckState.Checked)
                                        //{
                                        //    GLobalClass.iSuccess = DAL.fnUpdatePODetails(Global.uUPDATE, dRemQty, cmbPonumber.Text, row.Cells["ItemCode"].Value.ToString());
                                        //}
                                    }
                                    else if (chkGINWO.CheckState == CheckState.Checked)
                                    {
                                        string itemcode = row.Cells["ItemCode"].Value.ToString();
                                        InventoryService service = new InventoryService();

                                        // Optional: Load full date range, or just relevant past
                                        //DateTime fromDate = DateTime.Now.AddMonths(-12); // last year
                                        //DateTime toDate = DateTime.Now;

                                        // Correctly formatted DateTime
                                        DateTime fromDate = new DateTime(2025, 3, 31, 0, 0, 0); // January 9, 2022 at 00:00:00
                                        DateTime toDate = DateTime.Now; // April 9, 2024 at 23:59:59



                                        // Step 1: Load all transactions for that item
                                        List<InventoryTransaction> transactions = service.LoadTransactions(fromDate, toDate, itemcode);

                                        // Step 2: Run WAR
                                        List<WarResult> warResults = service.CalculateWAR(transactions);

                                        // Step 3: Get latest WAR (last transaction)
                                        decimal latestWAR = 0;
                                        if (warResults.Count > 0)
                                            latestWAR = warResults.Last().WeightedAverageRate;
                                        GLobalClass.iSuccess = DAL.fnUpdateItemDetails(Global.uUPDATE, (String.Format("{0:MM/dd/yyyy}", itemcreateddate.ToString())), dAvailableQty, dReceipt, dStockValue, row.Cells["ItemCode"].Value.ToString(), (double)latestWAR);

                                        GLobalClass.iSuccess = DAL.fnAddERPLog(0, lblGinno.Text, login.GetUserDetails[2], dtpGINDate.Text, "Latest WAR Updated" + " " + latestWAR.ToString() + " " + itemcode, "Receipt");


                                    }

                                    //blocked the war cost if
                                    if (chkGINPO.CheckState == CheckState.Checked)
                                    {
                                        int bomStatus = DAL.GEPoBOM(cmbPonumber.Text);

                                        if (bomStatus == 0)
                                        {
                                            GLobalClass.iSuccess = DAL.fnUpdatePODetails(Global.uUPDATE, cmbPonumber.Text);
                                        }
                                        else if (bomStatus == 1)
                                        {
                                            GLobalClass.iSuccess = DAL.fnUpdatePODetailswithoutBOM(Global.uUPDATE, dRemQty, cmbPonumber.Text, row.Cells["ItemCode"].Value.ToString());

                                        }



                                    }
                                    else if (chkGINWO.CheckState == CheckState.Checked)
                                    {
                                        GLobalClass.iSuccess = DAL.fnUpdateWODetails(Global.uUPDATE, dRemQty, Convert.ToDouble(row.Cells["UnitCost"].Value.ToString()), (row.Cells["ItemCode"].Value.ToString()), cmbPonumber.Text);

                                        GLobalClass.iSuccess = DAL.fnUpdateWODetails(Global.uINSERT, 0, 0, (row.Cells["ItemCode"].Value.ToString()), cmbPonumber.Text);

                                        if ((Convert.ToDouble(row.Cells["RemainingQty"].Value) == 0))
                                        {
                                            GLobalClass.iSuccess = DAL.fnUpdateWODetails(Global.uDELETE, 0, 0, (row.Cells["ItemCode"].Value.ToString()), cmbPonumber.Text);
                                        }
                                    }
                                    if (GLobalClass.iSuccess > 0)
                                    {
                                        checke = 1;
                                    }

                                }
                                else
                                {
                                    //MessageBox.Show("Please contact the Finance Department to update customs duty. Until then, items will not be available to indent for the GIN Number: '" + lblGinno.Text + "'", "Success", 0, MessageBoxIcon.Information);

                                }
                            }
                        }
                    }
                }
                if (checke == 1)
                {
                    GLobalClass.iSuccess = DAL.fnAddERPLog(0, lblGinno.Text, login.GetUserDetails[2], dtpGINDate.Text, "Item GIN", "Receipt");

                    DialogResult dialog = MessageBox.Show("Item(s) Received Successfully with GIN No '" + lblGinno.Text + "'", "Success", 0, MessageBoxIcon.Information);
                    if (dialog == DialogResult.OK)
                    {
                        docscan.fnGetGINnumber = lblGinno.Text;
                        Part_Reciept.DocumentScanning scannar = new Part_Reciept.DocumentScanning();
                        this.Hide();
                        pleasewaitform pleaseWait = new pleasewaitform();
                        pleaseWait.Show();
                        Application.DoEvents();
                        scannar.Show();
                        pleaseWait.Hide();
                    }
                    bInvoiceDate = false;
                    btnSave.Enabled = false;
                    // txtinvoiceno.ResetText();
                    cmbLedger.SelectedIndex = -1;
                }
            }



            if (chkGINPO.CheckState == CheckState.Checked)
            {
                dtGINDeliveryDays = DAL.fnGINDeliverDateValue(cmbPonumber.Text, null).Tables[0];
            }

            else
            {
                dtGINDeliveryDays = DAL.fnGINDeliverDateValue(null, cmbPonumber.Text).Tables[0];
            }

            string sDeliveryStatus = string.Empty;
            if (dtGINDeliveryDays.Rows.Count > 0)
            {
                if (!string.IsNullOrEmpty(dtGINDeliveryDays.Rows[0]["NumberofGINDays"].ToString()))
                {
                    int noOfGINDeliverydays;
                    noOfGINDeliverydays = Convert.ToInt32(dtGINDeliveryDays.Rows[0]["NumberofGINDays"].ToString());

                    if (noOfGINDeliverydays == 0)
                    {
                        sDeliveryStatus = "Delivered On Date";
                    }
                    else if (noOfGINDeliverydays < 0)
                    {
                        int idate = noOfGINDeliverydays * -1;
                        sDeliveryStatus = "Delivered Early By " + idate + " Days ";
                    }
                    else if (noOfGINDeliverydays > 0)
                    {
                        sDeliveryStatus = "Delivered Late By " + noOfGINDeliverydays + " Days";
                    }

                    SqlCommand cmd = new SqlCommand("UPDATE Receipt SET DeliveryMonitor='" + sDeliveryStatus + "' where GINNumber='" + lblGinno.Text + "'", SQLCon);
                    SQLCon.Open();
                    cmd.ExecuteNonQuery();
                    SQLCon.Close();
                }
            }
            //--commented by bhavya
            if (dgPackingTaxes.Rows.Count > 0)
            {
                foreach (DataGridViewRow row in dgPackingTaxes.Rows)
                {
                    if ((row.Cells[0].Value.ToString()) == "Packing & Forwarding")
                    {
                        SqlCommand cmd1 = new SqlCommand("UPDATE Receipt SET [PFIGSTRate]='" + row.Cells[2].Value.ToString() + "',[PFSGSTRate]='" + row.Cells[4].Value.ToString() + "',[PFCGSTRate]='" + row.Cells[6].Value.ToString() + "' where GINNumber='" + lblGinno.Text + "'", SQLCon);
                        SQLCon.Open();
                        cmd1.ExecuteNonQuery();
                        SQLCon.Close();
                    }
                    else if ((row.Cells[0].Value.ToString()) == "Transportation / Freight")
                    {
                        SqlCommand cmd2 = new SqlCommand("UPDATE Receipt SET [TFIGSTRate]='" + row.Cells[2].Value.ToString() + "',[TFSGSTRate]='" + row.Cells[4].Value.ToString() + "',[TFCGSTRate]='" + row.Cells[6].Value.ToString() + "' where GINNumber='" + lblGinno.Text + "'", SQLCon);
                        SQLCon.Open();
                        cmd2.ExecuteNonQuery();
                        SQLCon.Close();
                    }
                }
            }
            //----------------bhavya


            DataTable dtUserGINEmail = DAL.fnGINEmail(0, lblGinno.Text).Tables[0];

            if (dtUserGINEmail.Rows.Count > 0)
            {
                dgvCopyEmail.AutoGenerateColumns = false;
                dgvCopyEmail.DataSource = dtUserGINEmail;

                try
                {
                    // DTPOItemList = DAL.purchaseOrderList(cmbPonumber.Text, null).Tables[0];
                    sRemarks = "";
                    if (chkGINPO.Checked)
                    {
                        if (DTPOItemList.Rows.Count > 0)
                        {
                            sRemarks = "<br /> <br /> User Remarks : " + DTPOItemList.Rows[0]["Remarks"].ToString() + "<br />PM/MH Remarks : " + DTPOItemList.Rows[0]["PMMHRemarks"].ToString() + "<br />PC Remarks : " + DTPOItemList.Rows[0]["PCRemarks"].ToString() + "<br /><br />";
                        }
                        else
                        {
                            sRemarks = "";
                        }
                    }
                    fnAlertMail(lblpowoby.Text, lstusers);
                    // Main function for Sending mail...!

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }

            foreach (DataGridViewRow DGVR in dgvPOItemList.Rows)
            {
                if (Convert.ToDouble(DGVR.Cells["RemainingQty"].Value) != 0)
                {
                    bRemainingQtyCheck = true;
                    break;
                }
            }
            fnGINPrint();
            txtinvoiceno.ResetText();
            if (!bRemainingQtyCheck)
            {
                cmbPonumber.Items.Remove(cmbPonumber.SelectedItem);
            }



            itemWithoutLocation = false;

        }


        public string GetTableFromDataGridWorkOrder()
        {
            StringBuilder strTable = new StringBuilder();
            try
            {
                strTable.Append("<table border='1' cellpadding='0' cellspacing='0'>");
                strTable.Append("<tr>");
                // dgvPOItemList.Columns[0].Visible = false;
                //Create Header Row for Table
                foreach (DataGridViewColumn col in dgvCopyEmail.Columns)
                {
                    strTable.AppendFormat("<th bgcolor='Gainsboro'>{0}  </th>", col.HeaderText);
                }
                strTable.Append("</tr>");
                //Create Table Rows
                for (int i = 0; i < dgvCopyEmail.Rows.Count; i++)
                {
                    strTable.Append("<tr>");
                    foreach (DataGridViewCell cell in dgvCopyEmail.Rows[i].Cells)
                    {
                        if (cell.Value != null)
                        {
                            strTable.AppendLine("<td align='center' valign='middle' bgcolor='AliceBlue'>" + cell.Value.ToString() + "</td>");
                            // strTable.AppendFormat("<td>{0}</td>", cell.Value.ToString());
                        }

                    }
                    strTable.Append("</tr>");
                }
                strTable.Append("</table>");
                //dgvPOItemList.Columns[0].Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            return strTable.ToString();
        }


        string sRemarks = "";

        #region Email Alert

        public void fnAlertMail(string sUser, ListBox sCC)
        {
            //MessageBox.Show("Alert Mail");
            try
            {
                DataTable dtlogindetails = DAL.fnloginemail(sUser).Tables[0];

                if (dtlogindetails.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
                    {
                        Outlook.Application oApp = new Outlook.Application();
                        Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                        oMsg.Subject = "Items from '" + lblVendor.Text + "' are received  at stores. PO No : " + cmbPonumber.Text + "";

                        //oMsg.IsBodyHtml = true;
                        oMsg.HTMLBody = " Dear " + lblpowoby.Text.ToUpper() + ",<br />  Received Item list as follows.  " + sRemarks + " <br /><br /> ";
                        oMsg.HTMLBody += GetTableFromDataGridWorkOrder();

                        oMsg.HTMLBody += "<br /><br /><br /><br /> <b>**** This is an auto generated E-mail. Please do not reply. ****</b>";
                        //oMsg.HTMLBody = " Dear " + sUser.ToUpper() + ", <br /><br /> Purchase Order ' " + cmbPONO.Text + " ' sent for approval.<br /> Remarks : " + sRemarks + " <br /> <br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /> ** THIS IS AN AUTO GENARATED EMAIL. PLEASE DO NOT REPLY **";
                        // Add a recipient.
                        Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                        oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                        oRecips.ResolveAll();

                        if (sCC.Items.Count > 0)
                        {
                            Outlook.Recipient oRecip;
                            List<string> sCCRecipsList = new List<string>();
                            foreach (string tempTO in sCC.Items)
                            {
                                if (tempTO != null)
                                    sCCRecipsList.Add(tempTO);
                            }
                            foreach (string t in sCCRecipsList)
                            {

                                oRecip = (Outlook.Recipient)oRecips.Add(t);
                                oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                                oRecip.Resolve();
                            }
                            oMsg.Send();
                            oRecip = null;
                        }
                        else
                        {
                            // Send.
                            oMsg.Send();
                            // Clean up.
                            oRecips = null;
                        }
                        oMsg = null;
                        oApp = null;
                        MessageBox.Show("Mail sent to the user '" + sUser + "' successfully!", "E-mail Sent", 0, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        #endregion









        DataTable dtPurchaseOrderList = new DataTable();
        DataTable dtWorkorderProjectcode = new DataTable();


        DataTable dtItemColor = new DataTable();
        private void Datagridviewcolor()
        {
            int count = 0;
            foreach (DataGridViewRow dgr in dgvPOItemList.Rows)
            {
                dtItemColor = DAL.purchaseOrderRepeatColor(dgr.Cells["ItemCode"].Value.ToString()).Tables[0];
                if (dtItemColor.Rows.Count > 0)
                {
                    dgvPOItemList.Rows[count].Cells[1].Style.BackColor = Color.Yellow;
                    dgvPOItemList.Rows[count].Cells[2].Style.BackColor = Color.Yellow;
                    dgvPOItemList.Rows[count].Cells[3].Style.BackColor = Color.Yellow;
                }
                count++;
            }
        }

        // code for Work Order number selected Item list to be loaded to the datagridview
        DataTable dtPackingForwardingTax = new DataTable();
        DataTable DTPOItemList = new DataTable();
        DataTable dtsCCUsers = new DataTable();
        DataTable itemLocations = new DataTable();
        private void cmbPonumber_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbLedger.SelectedIndex = -1;
            lstusers.Items.Clear();
            txtTCSAmount.Text = "0";
            if (chkGINPO.CheckState == CheckState.Checked)
            {
                textBRate.Enabled = true;
                sWOPO = "PO";
                lblGinno.ResetText();
                txtVendorcode.ResetText();
                lblVendor.ResetText();
                combocurrency.ResetText();
                textBRate.ResetText();
                btnSave.Enabled = true;

                dtsCCUsers = DAL.POWOCCList(1, cmbPonumber.Text).Tables[0];

                if (dtsCCUsers.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtsCCUsers.Rows[0]["emailid"].ToString()) && !lstusers.Items.Contains(dtsCCUsers.Rows[0]["emailid"].ToString()))
                    {
                        lstusers.Items.Add(dtsCCUsers.Rows[0]["emailid"].ToString());
                    }
                    if (!string.IsNullOrEmpty(dtsCCUsers.Rows[0]["emailid1"].ToString()) && !lstusers.Items.Contains(dtsCCUsers.Rows[0]["emailid1"].ToString()))
                    {
                        lstusers.Items.Add(dtsCCUsers.Rows[0]["emailid1"].ToString());
                    }

                    if (!lstusers.Items.Contains("Hemanth_Reddy@instron.com"))
                    {
                        lstusers.Items.Add("Hemanth_Reddy@instron.com");
                    }
                    //if (!lstusers.Items.Contains("Rakesh_Bharadwaj@instron.com"))
                    //{
                    //    lstusers.Items.Add("Rakesh_Bharadwaj@instron.com");
                    //}
                    if (!lstusers.Items.Contains("Santhosh_D.J@instron.com"))
                    {
                        lstusers.Items.Add("Santhosh_D.J@instron.com");
                    }
                    if (!lstusers.Items.Contains("Purushothama_H@instron.com"))
                    {
                        lstusers.Items.Add("Purushothama_H@instron.com");
                    }
                    if (!lstusers.Items.Contains("Basavanneyya_Amati@instron.com"))
                    {
                        lstusers.Items.Add("Basavanneyya_Amati@instron.com");
                    }
                    if (!lstusers.Items.Contains("Raghavendra_K@instron.com"))
                    {
                        lstusers.Items.Add("Raghavendra_K@instron.com");
                    }
                    if (!lstusers.Items.Contains("Pavana_Sm@instron.com"))
                    {
                      lstusers.Items.Add("Pavana_Sm@instron.com");
                    }
                    if (!lstusers.Items.Contains("ravindra_naiker@instron.com"))
                    {
                        lstusers.Items.Add("ravindra_naiker@instron.com");
                    }

                    //if (!lstusers.Items.Contains("Karjol_GT@instron.com"))
                    //{
                    //    lstusers.Items.Add("Karjol_GT@instron.com");
                    //}
                }

                DTPOItemList = DAL.purchaseOrderList(cmbPonumber.Text, null).Tables[0];




                if (DTPOItemList.Rows.Count > 0)
                {

                    txtVendorcode.Text = DTPOItemList.Rows[0]["VendorCode"].ToString();
                    lblVendor.Text = DTPOItemList.Rows[0]["VendorName"].ToString();
                    lblprojcode.Text = DTPOItemList.Rows[0]["ProjectCode"].ToString();
                    lblprojectdesc.Text = DTPOItemList.Rows[0]["ProjectDescription"].ToString();
                    lblpowoby.Text = DTPOItemList.Rows[0]["PreparedBy"].ToString();
                    lblcustomername.Text = DTPOItemList.Rows[0]["Customer"].ToString();
                    lblGSTCode.Text = DTPOItemList.Rows[0]["GSTCode"].ToString();
                    textBRate.Text = DTPOItemList.Rows[0]["FXRate"].ToString();
                    combocurrency.Text = DTPOItemList.Rows[0]["Currency"].ToString();
                    lblCountry.Text = DTPOItemList.Rows[0]["Country"].ToString();
                    dgvPOItemList.AutoGenerateColumns = false;



                    dgvPOItemList.DataSource = DTPOItemList;


                    foreach (DataRow DR in DTPOItemList.Rows)
                    {
                        dgvPOItemList.Rows[DTPOItemList.Rows.IndexOf(DR)].Cells["Select"].Value = true;
                    }

                    string tempItemcode = "";
                    double tempRemQty = 0;
                    double temTotalAmount = 0;
                    double temTotalpoAmount = 0;
                    double temTotalOrderedQty = 0;


                    foreach (DataGridViewRow row in dgvPOItemList.Rows)
                    {
                        // Example condition: if value in column "Status" is "Inactive"

                        if (tempItemcode != row.Cells["ItemCode"].Value?.ToString())
                        {
                            tempItemcode = row.Cells["ItemCode"].Value?.ToString();
                            tempRemQty = 0;
                            temTotalAmount = 0;
                            temTotalpoAmount = 0;
                            temTotalOrderedQty = 0;
                            foreach (DataGridViewRow subRow in dgvPOItemList.Rows)
                            {
                                if (row.Cells["ItemCode"].Value?.ToString() == subRow.Cells["ItemCode"].Value?.ToString())
                                {
                                    tempRemQty += Convert.ToDouble(subRow.Cells["RemainingQty"].Value?.ToString());
                                    temTotalAmount += Convert.ToDouble(subRow.Cells["Amount"].Value?.ToString());//Amount 
                                    temTotalpoAmount += Convert.ToDouble(subRow.Cells["POAmount"].Value?.ToString());//POAmount
                                    temTotalOrderedQty += Convert.ToDouble(subRow.Cells["OrderedQty"].Value?.ToString());//OrderedQty

                                    row.Cells["SGSTTotalAmount"].Value = Convert.ToDouble(row.Cells["SGSTAmount"].Value?.ToString());//SGSTAmount 
                                    row.Cells["CGSTTotalAmount"].Value = Convert.ToDouble(row.Cells["CGSTAmount"].Value?.ToString());//CGSTAmount 
                                    row.Cells["IGSTTotalAmount"].Value = Convert.ToDouble(row.Cells["IGSTAmount"].Value?.ToString());//IGSTAmount 

                                    row.Cells["totalRemainingQty"].Value = tempRemQty;
                                    row.Cells["TotalAmount"].Value = temTotalAmount;
                                    row.Cells["TotalPOAmount"].Value = temTotalpoAmount;
                                    row.Cells["totalOrderedQty"].Value = temTotalOrderedQty;
                                }
                            }
                            //tempRemQty = 0;
                            //tempRemQty += Convert.ToDouble(row.Cells["RemainingQty"].Value?.ToString());
                            //row.DefaultCellStyle.BackColor = Color.LightBlue;
                            row.Cells["RecieveQuantity"].Style.BackColor = Color.Yellow;
                            row.Cells["temRecieveQuantity"].Style.BackColor = Color.Yellow;//temRecieveQuantity
                            //row.Cells["Select"].Value = false;
                            // MessageBox.Show(Convert.ToBoolean(row.Cells["Select"].Value).ToString());

                        }
                        else
                        {
                            //row.DefaultCellStyle.BackColor = Color.LightGreen;
                            row.Cells["RecieveQuantity"].ReadOnly = true;
                            row.Cells["RecieveQuantity"].Style.BackColor = Color.LightGray;
                            row.Cells["totalRemainingQty"].Value = Convert.ToDouble(row.Cells["RemainingQty"].Value?.ToString());
                            row.Visible = false;
                            //tempRemQty += Convert.ToDouble(row.Cells["RemainingQty"].Value?.ToString());

                        }
                        //row.Cells["totalRemainingQty"].Value = tempRemQty;
                        //MessageBox.Show(tempRemQty.ToString());
                    }



                    if (string.IsNullOrEmpty(DTPOItemList.Rows[0]["Currency"].ToString()))
                    {
                        combocurrency.Text = "Rupee - ₹";
                        textBRate.Enabled = false;
                        textBRate.Text = "1";
                    }

                    //foreach (DataRow DR in DTPOItemList.Rows)
                    //{
                    //  dgvPOItemList.Rows[DTPOItemList.Rows.IndexOf(DR)].Cells["Select"].Value = true;
                    //}

                    int j = 1;
                    foreach (DataGridViewRow row in dgvPOItemList.Rows)
                    {
                        row.Cells["SlNo"].Value = j;
                        j++;
                    }



                    // foreach (DataRow data in DTPOItemList.Rows)
                    // {
                    // itemLocations = DAL.getItemLocation(data["ItemCode"].ToString()).Tables[0];  
                    //     foreach (DataRow locations in itemLocations.Rows)
                    // {
                    //         var location = new List<string> { locations["Location"].ToString() };
                    //         DataGridViewComboBoxColumn combocol = (DataGridViewComboBoxColumn)dgvPOItemList.Columns["itemLocation"];
                    //         combocol.DataSource = location;
                    //         combocol.AutoComplete = true;
                    //         combocol.Width = 200;
                    //         combocol.DropDownWidth = 10;
                    //     }

                    // }




                    //new code 
                    foreach (DataGridViewRow row in dgvPOItemList.Rows)
                    {

                        string itemCode = row.Cells["Itemcode"].Value?.ToString();
                        itemLocations = DAL.getItemLocation(itemCode).Tables[0];
                        // string itemLocation = itemLocations.Rows[0]["Location"];
                        List<string> locationList = new List<string>();
                        if (itemLocations.Rows.Count > 0)
                        {
                            foreach (DataRow dr in itemLocations.Rows)
                            {
                                string locs = dr["Location"].ToString();
                                row.Cells["itemLocation"].Value = locs;
                                itemLocation.ReadOnly = true;
                                //var parts = locs.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Select(i => i.Trim());
                                //locationList.AddRange(parts);
                            }
                        }
                        else
                        {
                            //itemLocation.ReadOnly = false;
                            row.Cells["itemLocation"].Value = "NOLocation";
                            itemWithoutLocation = true;
                            //itemLocation.DefaultCellStyle.BackColor = Color.Yellow;
                        }
                        //DataGridViewComboBoxCell comboCell = new DataGridViewComboBoxCell();
                        //comboCell.DataSource = locationList;
                        //if (locationList.Count > 0)
                        //  comboCell.Value = locationList[0];
                        // row.Cells["itemLocation"] = comboCell;
                    }

                    //new code end


                    foreach (DataGridViewRow row in dgvPOItemList.Rows)
                    {
                        row.Cells["batchCode"].Value = DateTime.Now.ToString("ddMMyyyy");
                    }


                    foreach (DataRow DR in DTPOItemList.Rows)
                    {
                        dgvPOItemList.Rows[DTPOItemList.Rows.IndexOf(DR)].Cells["RecieveQuantity"].Value = DTPOItemList.Rows[DTPOItemList.Rows.IndexOf(DR)]["RemainingQty"].ToString();
                        // dgvPOItemList.Rows[DTPOItemList.Rows.IndexOf(DR)].Cells["RecieveQuantity"].Value = DTPOItemList.Rows[DTPOItemList.Rows.IndexOf(DR)]["RequariedQty"].ToString();
                    }
                    Datagridviewcolor();

                    dtPackingForwardingTax = DAL.PackingForwardingTax(cmbPonumber.Text, null).Tables[0];
                    if (dtPackingForwardingTax.Rows.Count > 0)
                    {
                        dgPackingTaxes.AutoGenerateColumns = false;
                        dgPackingTaxes.DataSource = dtPackingForwardingTax;
                        dgPackingTaxes.Visible = true;
                    }
                    else
                    {
                        dgPackingTaxes.DataSource = null;
                        dgPackingTaxes.Visible = true;
                    }

                    fnTotalPOCost();
                }
                else
                {
                    txtVendorcode.ResetText();
                    lblVendor.ResetText();
                    lblprojcode.ResetText();
                    lblprojectdesc.ResetText();
                    lblpowoby.ResetText();
                    lblcustomername.ResetText();

                    dgvPOItemList.DataSource = null;
                }

            }
            else if (chkGINWO.CheckState == CheckState.Checked)
            {

                //MessageBox.Show("WO checked");
                sWOPO = "WO";
                dgPackingTaxes.Visible = false;
                btnSave.Enabled = true;
                combocurrency.Text = "Rupee - ₹";
                textBRate.Text = "1";
                DTWOnumber = DAL.WoOrderDataset(cmbPonumber.Text).Tables[0];

                dtsCCUsers = DAL.POWOCCList(2, cmbPonumber.Text).Tables[0];

                if (dtsCCUsers.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtsCCUsers.Rows[0]["emailid"].ToString()) && !lstusers.Items.Contains(dtsCCUsers.Rows[0]["emailid"].ToString()))
                    {
                        lstusers.Items.Add(dtsCCUsers.Rows[0]["emailid"].ToString());
                    }
                    if (!string.IsNullOrEmpty(dtsCCUsers.Rows[0]["emailid1"].ToString()) && !lstusers.Items.Contains(dtsCCUsers.Rows[0]["emailid1"].ToString()))
                    {
                        lstusers.Items.Add(dtsCCUsers.Rows[0]["emailid1"].ToString());
                    }

                    if (!lstusers.Items.Contains("Muthuramalingam_R@instron.com"))
                    {
                        lstusers.Items.Add("Muthuramalingam_R@instron.com");
                    }
                    //if (!lstusers.Items.Contains("Rakesh_Bharadwaj@instron.com"))
                    //{
                    //    lstusers.Items.Add("Rakesh_Bharadwaj@instron.com");
                    //}
                    if (!lstusers.Items.Contains("Santhosh_D.J@instron.com"))
                    {
                        lstusers.Items.Add("Santhosh_D.J@instron.com");
                    }
                    if (!lstusers.Items.Contains("Purushothama_H@instron.com"))
                    {
                        lstusers.Items.Add("Purushothama_H@instron.com");
                    }
                    if (!lstusers.Items.Contains("Basavanneyya_Amati@instron.com"))
                    {
                        lstusers.Items.Add("Basavanneyya_Amati@instron.com");
                    }
                    if (!lstusers.Items.Contains("Raghavendra_K@instron.com"))
                    {
                        lstusers.Items.Add("Raghavendra_K@instron.com");
                    }
                    if (!lstusers.Items.Contains("Veena_D@instron.com"))
                    {
                        lstusers.Items.Add("Veena_D@instron.com");
                    }
                    if (!lstusers.Items.Contains("ravindra_naiker@instron.com"))
                    {
                        lstusers.Items.Add("ravindra_naiker@instron.com");
                    }


                    //if (!lstusers.Items.Contains("Karjol_GT@instron.com"))
                    //{
                    //    lstusers.Items.Add("Karjol_GT@instron.com");
                    //}
                }

                if (DTWOnumber.Rows.Count > 0)
                {

                    lblprojcode.Text = DTWOnumber.Rows[0]["ProjectCode"].ToString();
                    lblprojectdesc.Text = DTWOnumber.Rows[0]["ProjectDescription"].ToString();
                    lblcustomername.Text = DTWOnumber.Rows[0]["Customer"].ToString();
                    txtVendorcode.Text = DTWOnumber.Rows[0]["VendorCode"].ToString();
                    lblVendor.Text = DTWOnumber.Rows[0]["VendorName"].ToString();
                    lblpowoby.Text = DTWOnumber.Rows[0]["PreparedBy"].ToString();
                    lblGSTCode.Text = DTWOnumber.Rows[0]["GSTCode"].ToString();
                    dgvPOItemList.AutoGenerateColumns = false;
                    dgvPOItemList.DataSource = DTWOnumber;
                    lblCountry.Text = DTWOnumber.Rows[0]["Country"].ToString();

                    foreach (DataRow DR in DTWOnumber.Rows)
                    {
                        dgvPOItemList.Rows[DTWOnumber.Rows.IndexOf(DR)].Cells["Select"].Value = true;
                    }

                    int j = 1;
                    foreach (DataGridViewRow row in dgvPOItemList.Rows)
                    {
                        row.Cells["SlNo"].Value = j;
                        j++;
                    }


                    string tempItemcode = "";
                    double tempRemQty = 0;
                    double temTotalAmount = 0;
                    double temTotalpoAmount = 0;
                    double temTotalOrderedQty = 0;


                    foreach (DataGridViewRow row in dgvPOItemList.Rows)
                    {
                        // Example condition: if value in column "Status" is "Inactive"

                        if (tempItemcode != row.Cells["ItemCode"].Value?.ToString())
                        {
                            tempItemcode = row.Cells["ItemCode"].Value?.ToString();
                            tempRemQty = 0;
                            temTotalAmount = 0;
                            temTotalpoAmount = 0;
                            temTotalOrderedQty = 0;
                            foreach (DataGridViewRow subRow in dgvPOItemList.Rows)
                            {

                                dgvPOItemList.Columns["RecieveQuantity"].Visible = false;
                                if (row.Cells["ItemCode"].Value?.ToString() == subRow.Cells["ItemCode"].Value?.ToString())
                                {
                                    tempRemQty += Convert.ToDouble(subRow.Cells["RemainingQty"].Value?.ToString());
                                    temTotalAmount += Convert.ToDouble(subRow.Cells["Amount"].Value?.ToString());//Amount 
                                    temTotalpoAmount += Convert.ToDouble(subRow.Cells["POAmount"].Value?.ToString());//POAmount
                                    temTotalOrderedQty += Convert.ToDouble(subRow.Cells["OrderedQty"].Value?.ToString());//OrderedQty

                                    row.Cells["SGSTTotalAmount"].Value = Convert.ToDouble(row.Cells["SGSTAmount"].Value?.ToString());//SGSTAmount 
                                    row.Cells["CGSTTotalAmount"].Value = Convert.ToDouble(row.Cells["CGSTAmount"].Value?.ToString());//CGSTAmount 
                                    row.Cells["IGSTTotalAmount"].Value = Convert.ToDouble(row.Cells["IGSTAmount"].Value?.ToString());//IGSTAmount 

                                    row.Cells["totalRemainingQty"].Value = tempRemQty;
                                    row.Cells["TotalAmount"].Value = temTotalAmount;
                                    row.Cells["TotalPOAmount"].Value = temTotalpoAmount;
                                    row.Cells["totalOrderedQty"].Value = temTotalOrderedQty;
                                }
                            }
                            //tempRemQty = 0;
                            //tempRemQty += Convert.ToDouble(row.Cells["RemainingQty"].Value?.ToString());
                            //row.DefaultCellStyle.BackColor = Color.LightBlue;
                            row.Cells["RecieveQuantity"].Style.BackColor = Color.Yellow;//temRecieveQuantity
                            dgvPOItemList.Columns["RecieveQuantity"].Visible = false;
                            row.Cells["temRecieveQuantity"].Style.BackColor = Color.Yellow;//temRecieveQuantity
                            //row.Cells["Select"].Value = false;
                            // MessageBox.Show(Convert.ToBoolean(row.Cells["Select"].Value).ToString());

                        }
                        else
                        {
                            //row.DefaultCellStyle.BackColor = Color.LightGreen;
                            row.Cells["RecieveQuantity"].ReadOnly = true;
                            row.Cells["RecieveQuantity"].Style.BackColor = Color.LightGray;
                            row.Cells["totalRemainingQty"].Value = Convert.ToDouble(row.Cells["RemainingQty"].Value?.ToString());
                            row.Visible = false;
                            //tempRemQty += Convert.ToDouble(row.Cells["RemainingQty"].Value?.ToString());

                        }
                        //row.Cells["totalRemainingQty"].Value = tempRemQty;
                        //MessageBox.Show(tempRemQty.ToString());
                    }






                    foreach (DataGridViewRow row in dgvPOItemList.Rows)
                    {

                        string itemCode = row.Cells["Itemcode"].Value?.ToString();
                        itemLocations = DAL.getItemLocation(itemCode).Tables[0];
                        List<string> locationList = new List<string>();
                        if (itemLocations.Rows.Count > 0)
                        {
                            foreach (DataRow dr in itemLocations.Rows)
                            {
                                string locs = dr["Location"].ToString();
                                row.Cells["itemLocation"].Value = locs;
                                //itemLocation.ReadOnly = true;
                                // var parts = locs.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Select(i => i.Trim());
                                //locationList.AddRange(parts);
                            }
                        }
                        else
                        {
                            //itemLocation.ReadOnly = false;
                            itemWithoutLocation = true;
                            row.Cells["itemLocation"].Value = "NOLocation";
                            //itemLocation.DefaultCellStyle.BackColor = Color.Yellow;
                        }
                        //DataGridViewComboBoxCell comboCell = new DataGridViewComboBoxCell();
                        //comboCell.DataSource = locationList;
                        //if (locationList.Count > 0)
                        //    comboCell.Value = locationList[0];
                        //row.Cells["itemLocation"] = comboCell;
                    }

                    //new code end


                    foreach (DataGridViewRow row in dgvPOItemList.Rows)
                    {
                        row.Cells["batchCode"].Value = DateTime.Now.ToString("ddMMyyyy");


                    }

                    foreach (DataRow DR in DTWOnumber.Rows)
                    {
                        dgvPOItemList.Rows[DTWOnumber.Rows.IndexOf(DR)].Cells["RecieveQuantity"].Value = DTWOnumber.Rows[DTWOnumber.Rows.IndexOf(DR)]["RemainingQty"].ToString();
                    }

                    dtPackingForwardingTax = DAL.PackingForwardingTax(cmbPonumber.Text, null).Tables[0];
                    if (dtPackingForwardingTax.Rows.Count > 0)
                    {
                        dgPackingTaxes.AutoGenerateColumns = false;
                        dgPackingTaxes.DataSource = dtPackingForwardingTax;
                        dgPackingTaxes.Visible = true;
                        // btnPackingAmount.Visible = true;
                        // btnAddTransport.Visible = true;
                    }
                    else
                    {
                        dgPackingTaxes.DataSource = null;
                        dgPackingTaxes.Visible = true;
                        //  btnPackingAmount.Visible = false;
                        //  btnAddTransport.Visible = false;
                    }


                    fnTotalPOCost();
                }
                else
                {
                    lblprojcode.ResetText();
                    lblprojectdesc.ResetText();
                    lblcustomername.ResetText();
                    txtVendorcode.ResetText();
                    lblVendor.ResetText();
                    lblpowoby.ResetText();
                    dgvPOItemList.DataSource = null;
                }
                //if (dgvPOItemList.Rows.Count > 0)
                //{
                //    dTotalReceiptCost = 0.0;
                //    foreach (DataGridViewRow row in dgvPOItemList.Rows)
                //    {
                //        if (Convert.ToBoolean(row.Cells["Select"].Value) == true)
                //        {
                //            dTotalReceiptCost += Convert.ToDouble(row.Cells["UnitCost"].Value) * Convert.ToDouble(row.Cells["RecieveQuantity"].Value);
                //        }
                //    }
                //    txtNetAmount.Text = dTotalReceiptCost.ToString();
                //}
            }

            if (dgvPOItemList.Rows.Count > 0)
            {
                DTtaxreturn = DAL.TaxRetturn(cmbPonumber.Text).Tables[0];
                if (DTtaxreturn.Rows.Count > 0)
                {
                    bTaxStatus = true;

                    bTaxStatus = false;
                }
            }

        }


        //search event handeler new added code...
        private void dgvPOItemList_EditingControlShowing1(Object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (dgvPOItemList.CurrentCell.OwningColumn.Name == "itemLocation" && e.Control is ComboBox combo)
            {
                combo.DropDownStyle = ComboBoxStyle.DropDown;
                combo.AutoCompleteSource = AutoCompleteSource.ListItems;
            }
        }
        //new added end...

        private void btnExit_Click_2(object sender, EventArgs e)
        {
            this.Hide();
            frm.Show();
        }

        double dnetamount;
        string sDot = ".";
        private void dgvPOItemList_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {

            //if (dgvPOItemList.CurrentCell.OwningColumn.Name == "RecieveQuantity")
            //{
            if (dgvPOItemList.CurrentCell.OwningColumn.Name != "Select")
            {
                if ((dgvPOItemList.CurrentCell.Value) != null)// && 
                {
                    if (!string.IsNullOrEmpty(dgvPOItemList.CurrentCell.Value.ToString()))
                    {
                        if (dgvPOItemList.CurrentCell.Value.ToString() != ".")//&& Convert.ToDouble(dgvPOItemList.CurrentCell.Value.ToString()) != 0.0)
                        {
                            switch (dgvPOItemList.CurrentCell.OwningColumn.Name)
                            {

                                case "temRecieveQuantity":

                                    dgvPOItemList.CurrentRow.Cells["RecieveQuantity"].Value = Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["temRecieveQuantity"].Value);
                                    double totalRequestedQty = 0;

                                    foreach (DataGridViewRow row in dgvPOItemList.Rows)
                                    {
                                        if (row.Cells["ItemCode"].Value.ToString() == dgvPOItemList.CurrentRow.Cells["ItemCode"].Value.ToString())
                                        {
                                            totalRequestedQty += Convert.ToDouble(row.Cells["RemainingQty"].Value.ToString());
                                        }
                                    }

                                    //if (Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["RemainingQty"].Value) < Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["RecieveQuantity"].Value) || Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["RecieveQuantity"].Value) == 0)
                                    if (Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["RecieveQuantity"].Value) == 0 || totalRequestedQty < Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["RecieveQuantity"].Value))
                                    {

                                        MessageBox.Show("Entered quantity is greater than remaining quantity or quantity should not be 0", "Error", 0, MessageBoxIcon.Error);
                                        (dgvPOItemList.CurrentRow.Cells["RecieveQuantity"].Value) = oldvalue;
                                        (dgvPOItemList.CurrentRow.Cells["temRecieveQuantity"].Value) = oldvalue;
                                    }
                                    else
                                    {
                                        //MessageBox.Show("else");
                                        string tempItemCode = dgvPOItemList.CurrentRow.Cells["ItemCode"].Value.ToString();
                                        double userEnteredValue = Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["RecieveQuantity"].Value);

                                        double temTotalIGSTAmount = 0;
                                        double temTotalSGSTAmount = 0;
                                        double temTotalCGSTAmount = 0;
                                        double TemTotalAmount = 0;


                                        foreach (DataGridViewRow row in dgvPOItemList.Rows)
                                        {
                                            if (row.Cells["ItemCode"].Value.ToString() == tempItemCode)
                                            {
                                                // MessageBox.Show("ItemCode is matching...!");
                                                double balanceQty = Convert.ToDouble(row.Cells["RemainingQty"].Value);
                                                if (userEnteredValue > 0)
                                                {
                                                    // MessageBox.Show(userEnteredValue.ToString(), "Balance QTY");
                                                    double qtyToAssign = Math.Min(userEnteredValue, balanceQty);
                                                    row.Cells["RecieveQuantity"].Value = qtyToAssign.ToString();
                                                    row.Cells["Select"].Value = true;
                                                    row.Cells["DiscAmount"].Value = ((Convert.ToDouble(row.Cells["RecieveQuantity"].Value.ToString()) * Convert.ToDouble(row.Cells["UnitCost"].Value.ToString()) * Convert.ToDouble(row.Cells["DiscRate"].Value.ToString())) / 100) / Convert.ToDouble(textBRate.Text);
                                                    row.Cells["Amount"].Value = ((Convert.ToDouble(qtyToAssign.ToString()) * Convert.ToDouble(row.Cells["UnitCost"].Value.ToString())) / Convert.ToDouble(textBRate.Text)) - Convert.ToDouble(row.Cells["DiscAmount"].Value.ToString());



                                                    row.Cells["IGSTAmount"].Value = (Convert.ToDouble(row.Cells["Amount"].Value.ToString()) / 100) * Convert.ToDouble(row.Cells["IGSTRate"].Value.ToString());
                                                    row.Cells["SGSTAmount"].Value = (Convert.ToDouble(row.Cells["Amount"].Value.ToString()) / 100) * Convert.ToDouble(row.Cells["SGSTRate"].Value.ToString());
                                                    row.Cells["CGSTAmount"].Value = (Convert.ToDouble(row.Cells["Amount"].Value.ToString()) / 100) * Convert.ToDouble(row.Cells["CGSTRate"].Value.ToString());




                                                    TemTotalAmount += ((Convert.ToDouble(qtyToAssign.ToString()) * Convert.ToDouble(row.Cells["UnitCost"].Value.ToString())) / Convert.ToDouble(textBRate.Text)) - Convert.ToDouble(row.Cells["DiscAmount"].Value.ToString());
                                                    temTotalIGSTAmount += (Convert.ToDouble(row.Cells["Amount"].Value.ToString()) / 100) * Convert.ToDouble(row.Cells["IGSTRate"].Value.ToString());
                                                    temTotalSGSTAmount += (Convert.ToDouble(row.Cells["Amount"].Value.ToString()) / 100) * Convert.ToDouble(row.Cells["SGSTRate"].Value.ToString());
                                                    temTotalCGSTAmount += (Convert.ToDouble(row.Cells["Amount"].Value.ToString()) / 100) * Convert.ToDouble(row.Cells["CGSTRate"].Value.ToString());

                                                    row.Cells["IGSTTotalAmount"].Value = temTotalIGSTAmount;
                                                    row.Cells["SGSTTotalAmount"].Value = temTotalSGSTAmount;
                                                    row.Cells["CGSTTotalAmount"].Value = temTotalCGSTAmount;
                                                    row.Cells["TotalAmount"].Value = TemTotalAmount;





                                                    userEnteredValue -= qtyToAssign;
                                                }
                                                else
                                                {
                                                    row.Cells["Select"].Value = false;
                                                    row.Cells["RecieveQuantity"].Value = row.Cells["RemainingQty"].Value;
                                                }
                                            }
                                        }


                                        //row.Cells["SGSTTotalAmount"].Value = Convert.ToDouble(row.Cells["SGSTAmount"].Value?.ToString());//SGSTAmount 
                                        // row.Cells["CGSTTotalAmount"].Value = Convert.ToDouble(row.Cells["CGSTAmount"].Value?.ToString());//CGSTAmount 
                                        // row.Cells["IGSTTotalAmount"].Value = Convert.ToDouble(row.Cells["IGSTAmount"].Value?.ToString());//IGSTAmount 

                                        // row.Cells["totalRemainingQty"].Value = tempRemQty;
                                        // row.Cells["TotalAmount"].Value = temTotalAmount;
                                        // row.Cells["TotalPOAmount"].Value = temTotalpoAmount;
                                        // row.Cells["totalOrderedQty"].Value = temTotalOrderedQty;


                                        //dgvPOItemList.CurrentRow.Cells["DiscAmount"].Value = ((Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["RecieveQuantity"].Value.ToString()) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["UnitCost"].Value.ToString()) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["DiscRate"].Value.ToString())) / 100) / Convert.ToDouble(textBRate.Text);
                                        //dgvPOItemList.CurrentRow.Cells["Amount"].Value = ((Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["RecieveQuantity"].Value.ToString()) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["UnitCost"].Value.ToString())) / Convert.ToDouble(textBRate.Text)) - Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["DiscAmount"].Value.ToString());
                                        //dgvPOItemList.CurrentRow.Cells["IGSTAmount"].Value = (Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Amount"].Value.ToString()) / 100) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["IGSTRate"].Value.ToString());
                                        // dgvPOItemList.CurrentRow.Cells["SGSTAmount"].Value = (Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Amount"].Value.ToString()) / 100) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["SGSTRate"].Value.ToString());
                                        // dgvPOItemList.CurrentRow.Cells["CGSTAmount"].Value = (Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Amount"].Value.ToString()) / 100) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["CGSTRate"].Value.ToString());
                                    }

                                    break;

                                case "IGSTRate":
                                    dgvPOItemList.CurrentRow.Cells["IGSTAmount"].Value = (Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Amount"].Value.ToString()) / 100) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["IGSTRate"].Value.ToString());
                                    break;

                                case "SGSTRate":
                                    dgvPOItemList.CurrentRow.Cells["SGSTAmount"].Value = (Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Amount"].Value.ToString()) / 100) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["SGSTRate"].Value.ToString());
                                    break;

                                case "CGSTRate":
                                    dgvPOItemList.CurrentRow.Cells["CGSTAmount"].Value = (Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Amount"].Value.ToString()) / 100) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["CGSTRate"].Value.ToString());
                                    break;

                                case "CustomsDuty":
                                    dgvPOItemList.CurrentRow.Cells["CustomsDutyAmt"].Value = ((Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Freight"].Value.ToString()) + Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Amount"].Value.ToString())) / 100) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["CustomsDuty"].Value.ToString());
                                    dgPackingTaxes.DataSource = null;
                                    break;

                                case "Cess":
                                    dgvPOItemList.CurrentRow.Cells["CessAmt"].Value = (Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["CustomsDutyAmt"].Value.ToString()) / 100) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Cess"].Value.ToString());
                                    dgPackingTaxes.DataSource = null;
                                    break;

                                case "CDIGST":
                                    dgvPOItemList.CurrentRow.Cells["CDIGSTAmt"].Value = (((Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Freight"].Value.ToString()) + Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["Amount"].Value.ToString())) + Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["CustomsDutyAmt"].Value.ToString()) + Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["CessAmt"].Value.ToString())) / 100) * Convert.ToDouble(dgvPOItemList.CurrentRow.Cells["CDIGST"].Value.ToString());
                                    dgPackingTaxes.DataSource = null;
                                    break;


                            }

                            fnTotalPOCost();

                        }
                        else
                        {
                            fnErrorValue();
                        }
                    }
                    else
                    {
                        fnErrorValue();
                    }
                    //     fnTotalPOCost();
                }
                else
                {
                    fnErrorValue();
                }
            }
        }



        CultureInfo india = new CultureInfo("hi-IN");
        double totalcost = 0;
        double dCustomsDutyAmt = 0;
        double dCessAmt = 0;
        double dCDIGSTAmt = 0;
        private void fnTotalPOCost()
        {
            totalcost = 0;
            dTotalAmount = 0;
            dTotalDiscount = 0;
            dTotalSgst = 0;
            dTotalCgst = 0;
            dTotalIgst = 0;
            dCustomsDutyAmt = 0;
            dCessAmt = 0;
            dCDIGSTAmt = 0;
            double dFreight = 0;
            foreach (DataGridViewRow dgvr in dgvPOItemList.Rows)
            {
                // totalcost += Convert.ToDouble(dgvr.Cells["Amount"].Value) - Convert.ToDouble(dgvr.Cells["DiscAmount"].Value) + Convert.ToDouble(dgvr.Cells["IGSTAmount"].Value) + Convert.ToDouble(dgvr.Cells["SGSTAmount"].Value) + Convert.ToDouble(dgvr.Cells["CGSTAmount"].Value);

                if (Convert.ToBoolean(dgvr.Cells["Select"].Value) == true)
                {
                    totalcost += Convert.ToDouble(dgvr.Cells["Amount"].Value) + Convert.ToDouble(dgvr.Cells["IGSTAmount"].Value) + Convert.ToDouble(dgvr.Cells["SGSTAmount"].Value) + Convert.ToDouble(dgvr.Cells["CGSTAmount"].Value);

                    dTotalAmount += Convert.ToDouble(dgvr.Cells["Amount"].Value);
                    dTotalDiscount += Convert.ToDouble(dgvr.Cells["DiscAmount"].Value);
                    dTotalSgst += Convert.ToDouble(dgvr.Cells["SGSTAmount"].Value);
                    dTotalCgst += Convert.ToDouble(dgvr.Cells["CGSTAmount"].Value);
                    dTotalIgst += Convert.ToDouble(dgvr.Cells["IGSTAmount"].Value);
                    dCustomsDutyAmt += Convert.ToDouble(dgvr.Cells["CustomsDutyAmt"].Value);
                    dCessAmt += Convert.ToDouble(dgvr.Cells["CessAmt"].Value);
                    dCDIGSTAmt += Convert.ToDouble(dgvr.Cells["CDIGSTAmt"].Value);
                    dFreight += Convert.ToDouble(dgvr.Cells["Freight"].Value);
                }
                else
                {
                    //MessageBox.Show("This row Not selected...!");
                }
            }

            foreach (DataGridViewRow dgvr in dgPackingTaxes.Rows)
            {
                totalcost += Convert.ToDouble(dgvr.Cells["taxamount"].Value) + Convert.ToDouble(dgvr.Cells["taxIGSTAmount"].Value) + Convert.ToDouble(dgvr.Cells["taxSGSTAmount"].Value) + Convert.ToDouble(dgvr.Cells["taxCGSTAmount"].Value);
            }

            // totalcost = Math.Round(totalcost, 2);
            txtFinalNetAmount.Text = Math.Round((dCustomsDutyAmt + dFreight + dCessAmt - dCDIGSTAmt + totalcost + Convert.ToDouble(txtTCSAmount.Text)), 2).ToString();
            lblTotalAmount.Text = dTotalAmount.ToString("F2");//"F2"
            lbltotaldiscount.Text = dTotalDiscount.ToString();
            lbltotalSGST.Text = dTotalSgst.ToString();
            lbltotalCGST.Text = dTotalCgst.ToString();
            lbltotalIGST.Text = dTotalIgst.ToString();
        }


        private void fnErrorValue()
        {
            MessageBox.Show("Enter a Valid Value", "Error", 0, MessageBoxIcon.Error);
            if (dgvPOItemList.CurrentCell.OwningColumn.Name == "RecieveQuantity")
            {
                dgvPOItemList.CurrentCell.Value = oldvalue;
            }
            else
            {
                dgvPOItemList.CurrentCell.Value = 0;
            }
        }

        private void dgvPOItemList_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            e.Cancel = true;
        }




        private void btnPOView_Click(object sender, EventArgs e)
        {
            this.Hide();
            pleasewaitform pleaseWait = new pleasewaitform();
            // Display form modelessly
            pleaseWait.Show();
            Application.DoEvents();
            Part_Reciept.GINPOView ginpo = new Part_Reciept.GINPOView();
            ginpo.Show();
            pleaseWait.Hide();
        }

        private void btnWOView_Click(object sender, EventArgs e)
        {
            // Part_Reciept.GINWOView woform = new Part_Reciept.GINWOView();
            //woform.Show();
        }
        #region Tax Calculation

        #endregion

        private void dgvPOItemList_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (dgvPOItemList.Rows.Count > 0)
                {
                    dgvPOItemList.Rows.RemoveAt(dgvPOItemList.Rows.IndexOf(dgvPOItemList.CurrentRow));
                    foreach (DataGridViewRow dr in dgvPOItemList.Rows)
                    {
                        dnetamount = dnetamount + Convert.ToDouble(dr.Cells["Amount"].Value.ToString());
                    }
                    //    txtNetAmount.Text = dnetamount.ToString();
                    int j = 1;
                    foreach (DataGridViewRow row in dgvPOItemList.Rows)
                    {
                        row.Cells["SlNo"].Value = j;
                        j++;
                    }



                }
            }
        }

        bool bInvoiceDate = false;
        private void dtpInvoiceDate_ValueChanged(object sender, EventArgs e)
        {
            bInvoiceDate = true;
        }
        double oldvalue;
        private void dgvPOItemList_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgvPOItemList.CurrentCell.OwningColumn.Name == "RecieveQuantity")
            {
                oldvalue = Convert.ToDouble(dgvPOItemList.CurrentCell.Value);
            }
        }

        private void dgvPOItemList_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {

        }
        private void Control_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }
            // only allow one decimal point
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                e.Handled = true;
            }
        }

        private void chkGINPO_CheckedChanged(object sender, EventArgs e)
        {
            if (chkGINPO.CheckState == CheckState.Checked)
            {
                panel2.Visible = true;
                foreach (Control lbl in this.pnPOWO.Controls)
                {
                    if (lbl.GetType() == typeof(Label) && ((lbl.Name == "lblcustomername") || (lbl.Name == "txtinvoiceno") || (lbl.Name == "lblprojcode") || (lbl.Name == "lblprojectdesc") || (lbl.Name == "txtVendorcode")
                        || (lbl.Name == "lblVendor") || (lbl.Name == "lblGinno") || (lbl.Name == "lblpowoby")))

                        lbl.ResetText();
                }
                dgvPOItemList.Columns[9].Visible = true;
                dgvPOItemList.Columns[10].Visible = true;
                lblwonum.Visible = false;
                this.chkGINWO.Checked = false;
                dgvPOItemList.DataSource = null;
                cmbPonumber.Items.Clear();
                cmbPonumber.ResetText();

                dtPurchaseOrderList = DAL.purchaseOrderList(null, "PurchaseOrder").Tables[0];
                DataView dvPO = dtPurchaseOrderList.DefaultView;
                dvPO.Sort = "DBOMNo desc";
                dtPurchaseOrderList = dvPO.ToTable();
                foreach (DataRow dr in dtPurchaseOrderList.Rows)
                {
                    if (!cmbPonumber.Items.Contains(dr["DBOMNo"].ToString()))
                        cmbPonumber.Items.Add(dr["DBOMNo"].ToString());
                }

                lblJobstatus.Visible = false;
                cmbJobstatus.Visible = false;
                bTaxStatus = true;

                bTaxStatus = false;
            }
            else
            {
                chkGINWO.Checked = true;
            }
        }

        private void chkGINWO_CheckedChanged(object sender, EventArgs e)
        {
            if (chkGINWO.CheckState == CheckState.Checked)
            {
                panel2.Visible = false;
                foreach (Control lbl in this.pnPOWO.Controls)
                {
                    if (lbl.GetType() == typeof(Label) && ((lbl.Name == "lblcustomername") || (lbl.Name == "txtinvoiceno") || (lbl.Name == "lblprojcode") || (lbl.Name == "lblprojectdesc") || (lbl.Name == "txtVendorcode")
                        || (lbl.Name == "lblVendor") || (lbl.Name == "lblGinno") || (lbl.Name == "lblpowoby")))

                        lbl.ResetText();
                }
                dgPackingTaxes.Visible = false;
                dgvPOItemList.Columns[10].Visible = true;
                dgvPOItemList.Columns[11].Visible = true;
                lblwonum.Visible = true;
                dgvPOItemList.DataSource = null;
                this.chkGINPO.Checked = false;
                dtWOList = DAL.WoOrderDataset(null).Tables[0];

                cmbPonumber.Items.Clear();
                cmbPonumber.ResetText();

                foreach (DataRow dr in dtWOList.Rows)
                {
                    if (!cmbPonumber.Items.Contains(dr["WONumber"].ToString()))
                        cmbPonumber.Items.Add(dr["WONumber"].ToString());
                }
                lblJobstatus.Visible = true;
                cmbJobstatus.Visible = true;
                bTaxStatus = true;
                bTaxStatus = false;
            }
            else
            {
                chkGINPO.Checked = true;
            }
        }

        private void btnReverseGIN_Click(object sender, EventArgs e)
        {

        }

        private void btnPackingAmount_Click(object sender, EventArgs e)
        {
            dtPackingForwardingTax = DAL.PackingForwardingTax(cmbPonumber.Text, "Packing & Forwarding").Tables[0];

            if (dtPackingForwardingTax.Rows.Count > 0)
            {
                dtPackingForwardingTax = DAL.PackingForwardingTax(cmbPonumber.Text, null).Tables[0];
                dgPackingTaxes.AutoGenerateColumns = false;
                dgPackingTaxes.DataSource = dtPackingForwardingTax;
                dgPackingTaxes.Visible = true;
            }
            else
            {
                // GLobalClass.iSuccess = DAL.fnAddPOPackingForward(Global.uINSERT, cmbPonumber.Text, "Packing & Forwarding", 0, 0, 0, 0, 0, 0, 0);
                // dtPackingForwardingTax = DAL.PackingForwardingTax("PO/19100388", null).Tables[0];
                dtPackingForwardingTax = DAL.PackingForwardingTax("PO/18002022", null).Tables[0];
                if (dtPackingForwardingTax.Rows.Count > 0)
                {
                    dgPackingTaxes.AutoGenerateColumns = false;
                    dgPackingTaxes.DataSource = dtPackingForwardingTax;
                    dgPackingTaxes.Visible = true;
                }
            }
        }

        private void btnAddTransport_Click(object sender, EventArgs e)
        {
            dtPackingForwardingTax = DAL.PackingForwardingTax(cmbPonumber.Text, "Transportation / Freight").Tables[0];

            if (dtPackingForwardingTax.Rows.Count > 0)
            {
                dtPackingForwardingTax = DAL.PackingForwardingTax(cmbPonumber.Text, null).Tables[0];
                dgPackingTaxes.AutoGenerateColumns = false;
                dgPackingTaxes.DataSource = dtPackingForwardingTax;
                dgPackingTaxes.Visible = true;
            }
            else
            {
                //  GLobalClass.iSuccess = DAL.fnAddPOPackingForward(Global.uINSERT, "PO/19100388", "Transportation / Freight", 0, 0, 0, 0, 0, 0, 0);
                // dtPackingForwardingTax = DAL.PackingForwardingTax("PO/19100388", null).Tables[0];
                dtPackingForwardingTax = DAL.PackingForwardingTax("PO/18002022", null).Tables[0];
                if (dtPackingForwardingTax.Rows.Count > 0)
                {
                    dgPackingTaxes.AutoGenerateColumns = false;
                    dgPackingTaxes.DataSource = dtPackingForwardingTax;
                    dgPackingTaxes.Visible = true;
                }
            }
        }
        double dOldTaxRate;
        private void dgPackingTaxes_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgPackingTaxes.CurrentCell.OwningColumn.Index == 1)
            {
                dOldTaxRate = Convert.ToDouble(dgPackingTaxes.CurrentCell.Value);
            }
        }

        private void dgPackingTaxes_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (dgPackingTaxes.CurrentCell.Value != null)
            {
                if (!string.IsNullOrEmpty(dgPackingTaxes.CurrentCell.Value.ToString()) && (dgPackingTaxes.CurrentCell.Value.ToString() != sDot))
                {
                    switch (dgPackingTaxes.CurrentCell.OwningColumn.Index)
                    {
                        case 1:

                            dgPackingTaxes.CurrentRow.Cells[3].Value = (Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[1].Value) / 100) * Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[2].Value);
                            dgPackingTaxes.CurrentRow.Cells[5].Value = (Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[1].Value) / 100) * Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[4].Value);
                            dgPackingTaxes.CurrentRow.Cells[7].Value = (Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[1].Value) / 100) * Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[6].Value);

                            break;

                        case 2:
                            dgPackingTaxes.CurrentRow.Cells[3].Value = (Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[1].Value) / 100) * Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[2].Value);
                            break;
                        case 4:
                            dgPackingTaxes.CurrentRow.Cells[5].Value = (Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[1].Value) / 100) * Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[4].Value);
                            break;
                        case 6:
                            dgPackingTaxes.CurrentRow.Cells[7].Value = (Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[1].Value) / 100) * Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[6].Value);
                            break;

                    }
                    fnTotalPOCost();

                }
                else
                {
                    if (dgPackingTaxes.CurrentCell.OwningColumn.Index == 1)
                    {
                        dgPackingTaxes.CurrentCell.Value = dOldTaxRate;
                    }
                    else
                    {
                        dgPackingTaxes.CurrentCell.Value = 0;
                    }
                    fnTotalPOCost();
                }
            }
        }

        private void dgPackingTaxes_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show(" dgPackingTaxes_EditingControlShowing   " + ex.Message);
            }
        }

        private void dgPackingTaxes_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                if (dgPackingTaxes.Rows.Count > 0)
                {
                    DialogResult DR = MessageBox.Show("Do you want to delete selected row", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (DR == DialogResult.Yes)
                    {
                        dgPackingTaxes.Rows.RemoveAt(dgPackingTaxes.Rows.IndexOf(dgPackingTaxes.CurrentRow));

                    }
                }
            }
        }

        private void btnGINOtherTimes_Click(object sender, EventArgs e)
        {
            //Part_Reciept.frmGINotheritems GINOtherItems = new Part_Reciept.frmGINotheritems();
            //this.Hide();
            //GINOtherItems.Show();
        }

        string sWOPO;
        private void fnGINPrint()
        {
            DataTable dtAdvancedReciept = new DataTable();
            DataTable dtPODetails = new DataTable();
            DataTable dtVendoAddress = new DataTable();
            dtAdvancedReciept = DAL.fnAdvancedReceipt(lblGinno.Text, null, sWOPO).Tables[0];
            dtPODetails = DAL.fnAdvancedReceipt(null, cmbPonumber.Text, sWOPO).Tables[0];
            dtVendoAddress = DAL.fnVedorList(txtVendorcode.Text).Tables[0];
            int iRowIndex = 1;
            int k = 1;
            string ExcelFolderPath;
            string FileFullPath;
            EXCEL.Workbook NewWorkBook;
            EXCEL.Worksheet NewWorkSheet;
            EXCEL.Application ExcelApp;
            EXCEL.Range CELLS, cell1, cell2;
            object misValue;
            Cursor.Current = Cursors.WaitCursor;
            //   if (dtGINNumber.Rows.Count > 0)
            {

                ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\Print GIN\";
                FileFullPath = ExcelFolderPath + lblGinno.Text + "-" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + "";
                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);


                ExcelApp = new EXCEL.Application();
                misValue = System.Reflection.Missing.Value;
                try
                {
                    if (ExcelApp == null)
                        MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                    NewWorkBook = ExcelApp.Workbooks.Add(misValue);

                    NewWorkBook.SaveAs(FileFullPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                    Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                    NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                    if (NewWorkSheet == null)
                        MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                    else
                        NewWorkSheet.Name = "Project GIN";
                    // Select the Excel cells, in the range c1 to c7 in the worksheet for cell access check.
                    EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                    if (RANGE == null)
                        MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                    // NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    //ExcelApp.Visible = true;
                    CELLS = NewWorkSheet.Cells;

                    string[] Text ={"",
                                Global.sCompanyName,
                                "NO.497E, 14th Cross, 4th Phase, Peenya Industrial Area,",
                                "Bangalore-560 058, Karnataka,  India. ",
                                "Phone:91(080) 28360184. FAX: (080) 28360047."};

                    foreach (string str in Text)
                    {
                        NewWorkSheet.Cells[iRowIndex, 1] = str;
                        CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);
                        iRowIndex++;
                    }

                    NewWorkSheet.Cells[iRowIndex, 1] = "GOODS INWARD NOTE REPORT";
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 15);
                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Document Number :";
                    NewWorkSheet.Cells[iRowIndex, 2] = lblGinno.Text;
                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Document Date :";
                    NewWorkSheet.Cells[iRowIndex, 2] = dtpGINDate.Text;
                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "PO Number :";
                    NewWorkSheet.Cells[iRowIndex, 2] = cmbPonumber.Text;
                    NewWorkSheet.Cells[iRowIndex, 3] = "Invoice No:";
                    NewWorkSheet.Cells[iRowIndex, 4] = txtinvoiceno.Text;
                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "PO Date :";
                    if (sWOPO == "PO")
                    {
                        NewWorkSheet.Cells[iRowIndex, 2] = DTPOItemList.Rows[0]["POGeneratedDate"].ToString();
                    }
                    else
                    {
                        NewWorkSheet.Cells[iRowIndex, 2] = DTWOnumber.Rows[0]["WOgeneratedDate"].ToString();
                    }
                    NewWorkSheet.Cells[iRowIndex, 3] = "Invoice Date :";
                    NewWorkSheet.Cells[iRowIndex, 4] = dtpInvoiceDate.Text;
                    iRowIndex++;
                    iRowIndex++;
                    if (dtPODetails.Rows.Count > 0)
                    {
                        iRowIndex--;
                        NewWorkSheet.Cells[iRowIndex, 1] = "Nature of Transaction :";
                        NewWorkSheet.Cells[iRowIndex, 2] = dtPODetails.Rows[0]["NatureofTransaction"].ToString();
                        iRowIndex++;
                    }
                    NewWorkSheet.Cells[iRowIndex, 1] = "Customer Type :";
                    NewWorkSheet.Cells[iRowIndex, 2] = "Registered";
                    iRowIndex++;
                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Received from";
                    iRowIndex++;

                    NewWorkSheet.Cells[iRowIndex, 1] = "Name :";
                    NewWorkSheet.Cells[iRowIndex, 2] = lblVendor.Text;
                    iRowIndex++;


                    NewWorkSheet.Cells[iRowIndex, 1] = "Address :";
                    NewWorkSheet.Cells[iRowIndex, 2] = dtVendoAddress.Rows[0]["Address1"].ToString();
                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 2] = dtVendoAddress.Rows[0]["Address2"].ToString();
                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 2] = dtVendoAddress.Rows[0]["Address3"].ToString();
                    iRowIndex++;
                    if (dtPODetails.Rows.Count > 0)
                    {

                        NewWorkSheet.Cells[iRowIndex, 1] = "State Code :";
                        NewWorkSheet.Cells[iRowIndex, 2] = dtPODetails.Rows[0]["ShippedStateCode"].ToString();

                        iRowIndex++;
                        NewWorkSheet.Cells[iRowIndex, 1] = "GSTIN:";
                        NewWorkSheet.Cells[iRowIndex, 2] = dtPODetails.Rows[0]["ShippedGSTIN"].ToString();
                    }
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 4, 6);
                    iRowIndex++;

                    NewWorkSheet.Range["A1:B1"].Cells.Font.Size = 16;
                    NewWorkSheet.Range["A1:B1"].Cells.Font.Bold = 16;

                    NewWorkSheet.Range["A6:B6"].Cells.Font.Size = 16;
                    NewWorkSheet.Range["A6:B6"].Cells.Font.Bold = true;
                    NewWorkSheet.Range["A6:B6"].Cells.Font.Color = Color.Red;
                    //Insert Text to the worksheet
                    //      iRowIndex++;

                    iRowIndex++;


                    string finalColLetter = string.Empty;
                    int j = 23;
                    if (dtAdvancedReciept.Rows.Count > 0)
                    {
                        object[,] rawData = new object[dtAdvancedReciept.Rows.Count + 1, dtAdvancedReciept.Columns.Count];
                        for (int col = 0; col < dtAdvancedReciept.Columns.Count; col++)
                        {
                            rawData[0, col] = dtAdvancedReciept.Columns[col].ColumnName;
                        }
                        for (int row = 0; row < dtAdvancedReciept.Rows.Count; row++)
                        {
                            for (int col = 0; col < dtAdvancedReciept.Columns.Count; col++)
                            {
                                rawData[row + 1, col] = dtAdvancedReciept.Rows[row].ItemArray[col];
                            }
                        }

                        string excelRange = string.Empty;
                        finalColLetter = string.Empty;
                        string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        int colCharsetLen = colCharset.Length;

                        if (dtAdvancedReciept.Columns.Count > colCharsetLen)
                        {
                            finalColLetter = colCharset.Substring(
                                (dtAdvancedReciept.Columns.Count - 1) / colCharsetLen - 1, 1);
                        }
                        //  j = j + 2;
                        finalColLetter += colCharset.Substring(
                                (dtAdvancedReciept.Columns.Count - 1) % colCharsetLen, 1);
                        excelRange = string.Format("A23:{0}{1}", finalColLetter, dtAdvancedReciept.Rows.Count + j);


                        NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                    }

                    if (sWOPO == "PO")
                    {
                        CellMerge("BorderAround", NewWorkSheet, 22, 22, 1, 16);
                        NewWorkSheet.Cells[22, 8] = "Discount";
                        CellMerge("Merge", NewWorkSheet, 22, 22, 8, 9);
                        CellMerge("BorderAround", NewWorkSheet, 22, 22, 8, 9);
                        NewWorkSheet.Cells[23, 8] = "%";
                        NewWorkSheet.Cells[23, 9] = "Amt";
                        NewWorkSheet.Cells[22, 11] = "CGST";
                        CellMerge("Merge", NewWorkSheet, 22, 22, 11, 12);
                        CellMerge("BorderAround", NewWorkSheet, 22, 22, 11, 12);
                        NewWorkSheet.Cells[23, 11] = "%";
                        NewWorkSheet.Cells[23, 12] = "Amt";
                        NewWorkSheet.Cells[22, 13] = "SGST";
                        CellMerge("Merge", NewWorkSheet, 22, 22, 13, 14);
                        CellMerge("BorderAround", NewWorkSheet, 22, 22, 13, 14);
                        NewWorkSheet.Cells[23, 13] = "%";
                        NewWorkSheet.Cells[23, 14] = "Amt";
                        NewWorkSheet.Cells[22, 15] = "IGST";
                        CellMerge("Merge", NewWorkSheet, 22, 22, 15, 16);
                        CellMerge("BorderAround", NewWorkSheet, 22, 22, 15, 16);
                        NewWorkSheet.Cells[23, 15] = "%";
                        NewWorkSheet.Cells[23, 16] = "Amt";
                    }

                    else
                    {

                        NewWorkSheet.Cells[22, 8] = "SGST";
                        CellMerge("Merge", NewWorkSheet, 22, 22, 8, 9);
                        CellMerge("BorderAround", NewWorkSheet, 22, 22, 8, 9);
                        NewWorkSheet.Cells[23, 8] = "%";
                        NewWorkSheet.Cells[23, 9] = "Amt";

                        NewWorkSheet.Cells[22, 10] = "CGST";
                        CellMerge("Merge", NewWorkSheet, 22, 22, 10, 11);
                        CellMerge("BorderAround", NewWorkSheet, 22, 22, 10, 11);
                        NewWorkSheet.Cells[23, 10] = "%";
                        NewWorkSheet.Cells[23, 11] = "Amt";

                        NewWorkSheet.Cells[22, 12] = "IGST";
                        CellMerge("Merge", NewWorkSheet, 22, 22, 12, 13);
                        CellMerge("BorderAround", NewWorkSheet, 22, 22, 12, 13);
                        NewWorkSheet.Cells[23, 12] = "%";
                        NewWorkSheet.Cells[23, 13] = "Amt";
                    }
                    CellMerge("GridLines", NewWorkSheet, 23, (25 + dtAdvancedReciept.Rows.Count), 1, 16);
                    CellMerge("BorderAround", NewWorkSheet, 1, 6, 1, 16);
                    CellMerge("BorderAround", NewWorkSheet, 7, 12, 1, 16);
                    CellMerge("BorderAround", NewWorkSheet, 14, 20, 1, 16);
                    CellMerge("BorderAround", NewWorkSheet, 23, 23, 1, 16);
                    NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 2] = "Packing & Forwarding";
                    DataTable dtPackingForwarding = DAL.fnPOPackingGST(lblGinno.Text, "Packing & Forwarding").Tables[0];
                    double Packing = 0;
                    double PIGST = 0;
                    double PSGST = 0;
                    double PCGST = 0;
                    if (dtPackingForwarding.Rows.Count > 0)
                    {
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 7] = dtPackingForwarding.Rows[0]["Amount"].ToString();
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 8] = 0;
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 9] = 0;
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 10] = dtPackingForwarding.Rows[0]["Amount"].ToString();
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 11] = dtPackingForwarding.Rows[0]["SGSTRate"].ToString();
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 12] = dtPackingForwarding.Rows[0]["SGSTAmount"].ToString();
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 13] = dtPackingForwarding.Rows[0]["CGSTRate"].ToString();
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 14] = dtPackingForwarding.Rows[0]["CGSTAmount"].ToString();
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 15] = dtPackingForwarding.Rows[0]["IGSTRate"].ToString();
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 16] = dtPackingForwarding.Rows[0]["IGSTAmount"].ToString();
                        Packing = Convert.ToDouble(dtPackingForwarding.Rows[0]["Amount"].ToString());
                        PIGST = Convert.ToDouble(dtPackingForwarding.Rows[0]["IGSTAmount"].ToString());
                        PSGST = Convert.ToDouble(dtPackingForwarding.Rows[0]["SGSTAmount"].ToString());
                        PCGST = Convert.ToDouble(dtPackingForwarding.Rows[0]["CGSTAmount"].ToString());
                    }
                    else
                    {
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 6] = 0;
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 7] = 0;
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 8] = 0;
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 9] = 0;
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 10] = 0;
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 11] = 0;
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 12] = 0;
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 13] = 0;
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 14] = 0;
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 15] = 0;
                        NewWorkSheet.Cells[24 + dtAdvancedReciept.Rows.Count, 16] = 0;
                    }
                    NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 2] = "Transportation / Freight";

                    dtPackingForwarding = DAL.fnPOPackingGST(lblGinno.Text, "Transportation / Freight").Tables[0];
                    double freight = 0;
                    double TIGST = 0;
                    double TSGST = 0;
                    double TCGST = 0;
                    if (dtPackingForwarding.Rows.Count > 0)
                    {
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 7] = dtPackingForwarding.Rows[0]["Amount"].ToString();
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 8] = 0;
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 9] = 0;
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 10] = dtPackingForwarding.Rows[0]["Amount"].ToString();
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 11] = dtPackingForwarding.Rows[0]["SGSTRate"].ToString();
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 12] = dtPackingForwarding.Rows[0]["SGSTAmount"].ToString();
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 13] = dtPackingForwarding.Rows[0]["CGSTRate"].ToString();
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 14] = dtPackingForwarding.Rows[0]["CGSTAmount"].ToString();
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 15] = dtPackingForwarding.Rows[0]["IGSTRate"].ToString();
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 16] = dtPackingForwarding.Rows[0]["IGSTAmount"].ToString();
                        freight = Convert.ToDouble(dtPackingForwarding.Rows[0]["Amount"].ToString());
                        TIGST = Convert.ToDouble(dtPackingForwarding.Rows[0]["IGSTAmount"].ToString());
                        TSGST = Convert.ToDouble(dtPackingForwarding.Rows[0]["SGSTAmount"].ToString());
                        TCGST = Convert.ToDouble(dtPackingForwarding.Rows[0]["CGSTAmount"].ToString());
                    }
                    else
                    {
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 7] = 0;
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 8] = 0;
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 9] = 0;
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 10] = 0;
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 11] = 0;
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 12] = 0;
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 13] = 0;
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 14] = 0;
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 15] = 0;
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count, 16] = 0;
                    }
                    string Text42;
                    if (sWOPO == "PO")
                    {
                        Text42 = "" + string.Format(india, "{0:c}", (Convert.ToDouble(dtAdvancedReciept.Compute("Sum(Amount)", "").ToString()) - Convert.ToDouble(dtAdvancedReciept.Compute("Sum(DiscAmount)", "").ToString()) + Convert.ToDouble(dtAdvancedReciept.Compute("Sum(IGSTAmount)", "").ToString()) + Convert.ToDouble(dtAdvancedReciept.Compute("Sum(SGSTAmount)", "").ToString()) + Convert.ToDouble(dtAdvancedReciept.Compute("Sum(CGSTAmount)", "").ToString()) + freight + Packing + PIGST + PSGST + PCGST + TIGST + TSGST + TCGST)) + "";
                    }
                    else
                    {
                        Text42 = "" + string.Format(india, "{0:c}", (Convert.ToDouble(dtAdvancedReciept.Compute("Sum(Amount)", "").ToString()) + Convert.ToDouble(dtAdvancedReciept.Compute("Sum(IGSTAmount)", "").ToString()) + Convert.ToDouble(dtAdvancedReciept.Compute("Sum(SGSTAmount)", "").ToString()) + Convert.ToDouble(dtAdvancedReciept.Compute("Sum(CGSTAmount)", "").ToString()) + freight + Packing + PIGST + PSGST + PCGST + TIGST + TSGST + TCGST)) + "";
                    }

                    NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count + 1, 6] = "Sub Total";
                    NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count + 1, 7] = "" + string.Format(india, "{0:c}", (Convert.ToDouble(dtAdvancedReciept.Compute("Sum(Amount)", "").ToString()) + Packing + freight)) + "";
                    if (sWOPO == "PO")
                    {
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count + 1, 9] = "" + string.Format(india, "{0:c}", (Convert.ToDouble(dtAdvancedReciept.Compute("Sum(DiscAmount)", "").ToString()))) + "";
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count + 1, 10] = "" + string.Format(india, "{0:c}", (Convert.ToDouble(dtAdvancedReciept.Compute("Sum(Amount)", "").ToString()) + Packing + freight - (Convert.ToDouble(dtAdvancedReciept.Compute("Sum(DiscAmount)", "").ToString())))) + "";
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count + 1, 12] = "" + string.Format(india, "{0:c}", (Convert.ToDouble(dtAdvancedReciept.Compute("Sum(SGSTAmount)", "").ToString()) + PSGST + TSGST)) + "";
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count + 1, 14] = "" + string.Format(india, "{0:c}", (Convert.ToDouble(dtAdvancedReciept.Compute("Sum(CGSTAmount)", "").ToString()) + PCGST + TCGST)) + "";
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count + 1, 16] = "" + string.Format(india, "{0:c}", (Convert.ToDouble(dtAdvancedReciept.Compute("Sum(IGSTAmount)", "").ToString()) + PIGST + TIGST)) + "";
                    }

                    else
                    {
                        //  NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count + 1, 8] = "" + string.Format(india, "{0:c}", (Convert.ToDouble(0))) + "";
                        //  NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count + 1, 9] = "" + string.Format(india, "{0:c}", (Convert.ToDouble(dtAdvancedReciept.Compute("Sum(Amount)", "").ToString()) + Packing + freight)) + "";
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count + 1, 10] = "" + string.Format(india, "{0:c}", (Convert.ToDouble(dtAdvancedReciept.Compute("Sum(SGSTAmount)", "").ToString()) + PSGST + TSGST)) + "";
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count + 1, 12] = "" + string.Format(india, "{0:c}", (Convert.ToDouble(dtAdvancedReciept.Compute("Sum(CGSTAmount)", "").ToString()) + PCGST + TCGST)) + "";
                        NewWorkSheet.Cells[25 + dtAdvancedReciept.Rows.Count + 1, 14] = "" + string.Format(india, "{0:c}", (Convert.ToDouble(dtAdvancedReciept.Compute("Sum(IGSTAmount)", "").ToString()) + PIGST + TIGST)) + "";
                    }

                    if (sWOPO == "PO")
                    {
                        DataTable dtCDValue = new DataTable();
                        dtCDValue = DAL.fnAdvancedCDReceipt(0, lblGinno.Text).Tables[0];
                        if (!string.IsNullOrEmpty(dtCDValue.Rows[0]["CDPercent"].ToString()))
                        {
                            NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 1, 4] = "CDPercent";
                            NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 1, 5] = dtCDValue.Rows[0]["CDPercent"].ToString();
                            NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 1, 6] = (Convert.ToDouble(dtCDValue.Compute("Sum(CDValue)", "").ToString()));
                            NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 2, 4] = "CDCessRate";
                            NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 2, 5] = dtCDValue.Rows[0]["CDCessRate"].ToString();
                            NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 2, 6] = (Convert.ToDouble(dtCDValue.Compute("Sum(CDCessAmount)", "").ToString()));
                            NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 3, 4] = "CDIGSTRate";
                            NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 3, 5] = dtCDValue.Rows[0]["CDIGSTRate"].ToString();
                            NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 3, 6] = (Convert.ToDouble(dtCDValue.Compute("Sum(CDIGSTAmount)", "").ToString()));

                            NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 4, 5] = "Grand Total";
                            NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 4, 6] = (Convert.ToDouble((Convert.ToDouble(dtAdvancedReciept.Compute("Sum(Amount)", "").ToString()) - Convert.ToDouble(dtAdvancedReciept.Compute("Sum(DiscAmount)", "").ToString()) + Convert.ToDouble(dtAdvancedReciept.Compute("Sum(IGSTAmount)", "").ToString()) + Convert.ToDouble(dtAdvancedReciept.Compute("Sum(SGSTAmount)", "").ToString()) + Convert.ToDouble(dtAdvancedReciept.Compute("Sum(CGSTAmount)", "").ToString()) + freight + Packing + PIGST + PSGST + PCGST + TIGST + TSGST + TCGST)) + Convert.ToDouble(dtCDValue.Compute("Sum(CDValue)", "").ToString()) + Convert.ToDouble(dtCDValue.Compute("Sum(CDCessAmount)", "").ToString()) + Convert.ToDouble(dtCDValue.Compute("Sum(CDIGSTAmount)", "").ToString()));
                        }

                        else
                        {
                            NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 4, 5] = "Grand Total";
                            NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 4, 6] = Text42;
                        }
                    }
                    else
                    {
                        NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 4, 5] = "Grand Total";
                        NewWorkSheet.Cells[27 + dtAdvancedReciept.Rows.Count + 4, 6] = Text42;
                    }



                    CellMerge("BorderAround", NewWorkSheet, 1, 27 + dtAdvancedReciept.Rows.Count + 4, 1, 16);


                    Microsoft.Office.Interop.Excel.Range range = NewWorkSheet.get_Range("D14", "G9999");
                    range.NumberFormat = "0.00";
                    Microsoft.Office.Interop.Excel.Range range1 = NewWorkSheet.get_Range("D10", "D11");
                    range1.NumberFormat = "dd-MM-yyyy";
                    //  Microsoft.Office.Interop.Excel.Range range11 = NewWorkSheet.get_Range("D10", "D11");
                    //range11.NumberFormat = "000";
                    NewWorkSheet.Range["A1:A1"].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    NewWorkSheet.Range["A2:A2"].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    NewWorkSheet.Range["A3:A3"].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    NewWorkSheet.Range["A4:A4"].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    NewWorkSheet.Range["A5:A5"].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                    NewWorkSheet.Range["A14:A14"].Cells.Font.Bold = true;
                    NewWorkSheet.Range["A7:A20"].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignRight;

                    NewWorkSheet.Range["B7:B20"].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;

                    ((Microsoft.Office.Interop.Excel.Range)NewWorkSheet.Rows[22, Type.Missing]).Font.Bold = true;
                    ((Microsoft.Office.Interop.Excel.Range)NewWorkSheet.Rows[22, Type.Missing]).Font.Color = Color.Blue;
                    ((Microsoft.Office.Interop.Excel.Range)NewWorkSheet.Rows[23, Type.Missing]).Font.Bold = true;
                    ((Microsoft.Office.Interop.Excel.Range)NewWorkSheet.Rows[23, Type.Missing]).Font.Color = Color.Blue;

                    NewWorkSheet.get_Range("C1", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
                    NewWorkSheet.get_Range("C1", "C9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                    NewWorkSheet.Columns.AutoFit(); //NewWorkSheet.Rows.AutoFit();
                    NewWorkSheet.Columns[1].ColumnWidth = 16;
                    NewWorkSheet.Columns[1].WrapText = true;
                    NewWorkSheet.Columns[3].ColumnWidth = 18;
                    NewWorkSheet.Columns[3].WrapText = true;
                    NewWorkSheet.Columns[2].ColumnWidth = 30;
                    NewWorkSheet.Columns[2].WrapText = true;
                    NewWorkSheet.Columns[4].ColumnWidth = 14;
                    NewWorkSheet.Columns[4].WrapText = true;
                    NewWorkSheet.Columns[5].ColumnWidth = 12;
                    NewWorkSheet.Columns[5].WrapText = true;
                    NewWorkSheet.PageSetup.Zoom = false;
                    iRowIndex = (27 + dtAdvancedReciept.Rows.Count + 4);
                    NewWorkSheet.PageSetup.PrintArea = "A1 : O" + iRowIndex + "";
                    NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                    //NewWorkSheet.Rows.RowHeight = "18";
                    NewWorkSheet.PageSetup.PrintNotes = true;
                    NewWorkSheet.PageSetup.Zoom = 60;
                    NewWorkSheet.PageSetup.FitToPagesTall = 1;
                    NewWorkSheet.PageSetup.FitToPagesWide = 1;
                    NewWorkSheet.PageSetup.LeftMargin = 0;
                    NewWorkSheet.PageSetup.RightMargin = 0;
                    NewWorkSheet.PageSetup.TopMargin = 0.75;
                    NewWorkSheet.PageSetup.BottomMargin = 0.75;
                    NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                    NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                    EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[1, 9];
                    System.Drawing.Image oImage = System.Drawing.Image.FromFile(Global.sLogo);
                    System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    NewWorkSheet.Paste(oRange, Global.sLogo);
                    NewWorkBook.Save();
                    NewWorkBook.Close(true, misValue, misValue);
                    ExcelApp.Quit();
                    releaseObject(NewWorkSheet);
                    releaseObject(NewWorkBook);
                    releaseObject(ExcelApp);

                    if (Directory.Exists(ExcelFolderPath))
                    {
                        Process.Start(ExcelFolderPath);
                    }
                    Cursor.Current = Cursors.Default;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    MessageBox.Show("Creating Excel sheet is faild...!");
                    foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                    {
                        GetProcess.Kill();
                    }
                }
            }

            //else
            //    MessageBox.Show("No indent items to save", "Error", 0, MessageBoxIcon.Question);
        }

        #region Excel App Release Object Function
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
        #endregion

        #region CellMerge Funtion
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlMedium, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "GridLines":
                    {
                        CELLS.Borders.Color = System.Drawing.Color.Black;
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignCenter":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                        break;
                    }
                case "Bold":
                    {
                        CELLS.Font.Bold = true;
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

        }
        #endregion

        private void btnPOInspection_Click(object sender, EventArgs e)
        {

        }


        private void fnEmptyTextBox(object sender, EventArgs e)
        {
            if (((TextBox)sender).Text == "")
            {
                ((TextBox)sender).Text = "0";
            }
        }

        private void fnOnlynumber(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void fnOnlynumber1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }

        }

        private void txtTCSAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber(sender, e);
        }

        private void txtTCSAmount_Leave(object sender, EventArgs e)
        {
            fnEmptyTextBox(sender, e);
        }

        private void txtTCSAmount_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtTCSAmount.Text))
            {
                txtFinalNetAmount.Text = Math.Round(dCustomsDutyAmt + dCessAmt + dCDIGSTAmt + totalcost + Convert.ToDouble(txtTCSAmount.Text), 2).ToString();
            }
        }

        private void chkOtherItems_CheckedChanged(object sender, EventArgs e)
        {
            Part_Reciept.frmGINotheritems GINOtherItems = new Part_Reciept.frmGINotheritems();
            this.Hide();
            GINOtherItems.Show();

        }

        private void btnscan_Click(object sender, EventArgs e)
        {
            Part_Reciept.DocumentScanning scannar = new Part_Reciept.DocumentScanning();
            this.Hide();
            scannar.Show();
        }

        private void textBRate_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                foreach (DataGridViewRow row in dgvPOItemList.Rows)
                {
                    row.Cells["Amount"].Value = Math.Round(Convert.ToDouble(row.Cells["RecieveQuantity"].Value) * Convert.ToDouble(row.Cells["UnitCost"].Value) / Convert.ToDouble(textBRate.Text), 3);
                }
            }
        }

        private void textBRate_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber(sender, e);
        }

        private void lblwonum_Click(object sender, EventArgs e)
        {

        }

        private void lblGinno_TextChanged(object sender, EventArgs e)
        {

        }

        private void dgvPOItemList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgPackingTaxes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvCopyEmail_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
