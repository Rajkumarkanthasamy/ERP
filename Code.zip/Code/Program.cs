﻿using Erp_Project_With_Buttons.ProjectBOM;
using System;
using System.Windows.Forms;


namespace Erp_Project_With_Buttons
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //frmValidationTimeSheet frmvalid = new frmValidationTimeSheet();
            //frmvalid.WeekelyTimeSheetReminder();
            Application.Run(new Login.frmLoginForm());
           // Application.Run(new Part_Reciept.DC());//LockBOM

        }
    }
}
