﻿namespace Erp_Project_With_Buttons.JobWork
{
    partial class ViewWorkOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ViewWorkOrder));
            this.gbSearchOptions = new System.Windows.Forms.GroupBox();
            this.btnrecentlist = new System.Windows.Forms.Button();
            this.lblFromdate = new System.Windows.Forms.Label();
            this.lblToDate = new System.Windows.Forms.Label();
            this.dtpFromDate = new System.Windows.Forms.DateTimePicker();
            this.dtpToDate = new System.Windows.Forms.DateTimePicker();
            this.chkLoad = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtIPItemCode = new System.Windows.Forms.TextBox();
            this.lblItemCode = new System.Windows.Forms.Label();
            this.dgpolist = new System.Windows.Forms.DataGridView();
            this.WONumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PreparedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WOPreparedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PMName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PMApprovedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FinalizedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FinalizedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PurchaseCommitee = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PCAuthoriseDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OMName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OMApproved = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GMName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IPItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IPOrderQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OPItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OPOrderQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VendorName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UnitCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TotalCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.JobIssueStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WOGeneratedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WOgeneratedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IPRemainingOrderQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WorkDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OPRemainingQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbSearchOptions.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgpolist)).BeginInit();
            this.SuspendLayout();
            // 
            // gbSearchOptions
            // 
            this.gbSearchOptions.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.gbSearchOptions.Controls.Add(this.btnrecentlist);
            this.gbSearchOptions.Controls.Add(this.lblFromdate);
            this.gbSearchOptions.Controls.Add(this.lblToDate);
            this.gbSearchOptions.Controls.Add(this.dtpFromDate);
            this.gbSearchOptions.Controls.Add(this.dtpToDate);
            this.gbSearchOptions.Controls.Add(this.chkLoad);
            this.gbSearchOptions.Controls.Add(this.label1);
            this.gbSearchOptions.Controls.Add(this.txtIPItemCode);
            this.gbSearchOptions.Controls.Add(this.lblItemCode);
            this.gbSearchOptions.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.gbSearchOptions.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbSearchOptions.Location = new System.Drawing.Point(3, 4);
            this.gbSearchOptions.Name = "gbSearchOptions";
            this.gbSearchOptions.Size = new System.Drawing.Size(1297, 122);
            this.gbSearchOptions.TabIndex = 11;
            this.gbSearchOptions.TabStop = false;
            this.gbSearchOptions.Text = "Search Options";
            // 
            // btnrecentlist
            // 
            this.btnrecentlist.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrecentlist.ForeColor = System.Drawing.Color.Indigo;
            this.btnrecentlist.Location = new System.Drawing.Point(993, 28);
            this.btnrecentlist.Name = "btnrecentlist";
            this.btnrecentlist.Size = new System.Drawing.Size(174, 31);
            this.btnrecentlist.TabIndex = 33;
            this.btnrecentlist.Text = "Load WO List";
            this.btnrecentlist.UseVisualStyleBackColor = true;
            this.btnrecentlist.Click += new System.EventHandler(this.btnrecentlist_Click);
            // 
            // lblFromdate
            // 
            this.lblFromdate.AutoSize = true;
            this.lblFromdate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblFromdate.Location = new System.Drawing.Point(704, 32);
            this.lblFromdate.Name = "lblFromdate";
            this.lblFromdate.Size = new System.Drawing.Size(52, 19);
            this.lblFromdate.TabIndex = 29;
            this.lblFromdate.Text = "From :";
            // 
            // lblToDate
            // 
            this.lblToDate.AutoSize = true;
            this.lblToDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblToDate.Location = new System.Drawing.Point(855, 32);
            this.lblToDate.Name = "lblToDate";
            this.lblToDate.Size = new System.Drawing.Size(33, 19);
            this.lblToDate.TabIndex = 30;
            this.lblToDate.Text = "To :";
            this.lblToDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dtpFromDate
            // 
            this.dtpFromDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.dtpFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpFromDate.Location = new System.Drawing.Point(756, 28);
            this.dtpFromDate.Name = "dtpFromDate";
            this.dtpFromDate.Size = new System.Drawing.Size(94, 27);
            this.dtpFromDate.TabIndex = 31;
            // 
            // dtpToDate
            // 
            this.dtpToDate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.dtpToDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpToDate.Location = new System.Drawing.Point(889, 28);
            this.dtpToDate.Name = "dtpToDate";
            this.dtpToDate.Size = new System.Drawing.Size(94, 27);
            this.dtpToDate.TabIndex = 32;
            // 
            // chkLoad
            // 
            this.chkLoad.AutoSize = true;
            this.chkLoad.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkLoad.ForeColor = System.Drawing.Color.MidnightBlue;
            this.chkLoad.Location = new System.Drawing.Point(1105, 81);
            this.chkLoad.Name = "chkLoad";
            this.chkLoad.Size = new System.Drawing.Size(170, 30);
            this.chkLoad.TabIndex = 15;
            this.chkLoad.Text = "Edit Work Order";
            this.chkLoad.UseVisualStyleBackColor = true;
            this.chkLoad.CheckedChanged += new System.EventHandler(this.chkLoad_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(117, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(457, 38);
            this.label1.TabIndex = 5;
            this.label1.Text = "Search Results Include : WO Number, IP Item code, OP Item Desc, \r\nVendor Code, Ve" +
    "ndor Name, Project Code or Project Name";
            // 
            // txtIPItemCode
            // 
            this.txtIPItemCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIPItemCode.Location = new System.Drawing.Point(121, 28);
            this.txtIPItemCode.Name = "txtIPItemCode";
            this.txtIPItemCode.Size = new System.Drawing.Size(539, 26);
            this.txtIPItemCode.TabIndex = 1;
            this.txtIPItemCode.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtIPItemCode_KeyUp);
            // 
            // lblItemCode
            // 
            this.lblItemCode.AutoSize = true;
            this.lblItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItemCode.Location = new System.Drawing.Point(18, 31);
            this.lblItemCode.Name = "lblItemCode";
            this.lblItemCode.Size = new System.Drawing.Size(99, 19);
            this.lblItemCode.TabIndex = 0;
            this.lblItemCode.Text = "IP Item Code:";
            // 
            // dgpolist
            // 
            this.dgpolist.AllowUserToAddRows = false;
            this.dgpolist.AllowUserToDeleteRows = false;
            this.dgpolist.AllowUserToResizeRows = false;
            this.dgpolist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgpolist.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgpolist.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgpolist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgpolist.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.WONumber,
            this.PreparedBy,
            this.WOPreparedDate,
            this.PMName,
            this.PMApprovedDate,
            this.FinalizedBy,
            this.FinalizedDate,
            this.PurchaseCommitee,
            this.PCAuthoriseDate,
            this.OMName,
            this.OMApproved,
            this.GMName,
            this.IPItemCode,
            this.IPOrderQty,
            this.OPItemCode,
            this.ItemDescription,
            this.OPOrderQty,
            this.ProjectCode,
            this.ProjectDescription,
            this.VendorName,
            this.UnitCost,
            this.TotalCost,
            this.JobIssueStatus,
            this.WOGeneratedBy,
            this.WOgeneratedDate,
            this.IPRemainingOrderQty,
            this.WorkDescription,
            this.OPRemainingQty});
            this.dgpolist.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgpolist.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgpolist.EnableHeadersVisualStyles = false;
            this.dgpolist.Location = new System.Drawing.Point(3, 132);
            this.dgpolist.MultiSelect = false;
            this.dgpolist.Name = "dgpolist";
            this.dgpolist.ReadOnly = true;
            this.dgpolist.RowHeadersVisible = false;
            this.dgpolist.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgpolist.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgpolist.Size = new System.Drawing.Size(1297, 538);
            this.dgpolist.TabIndex = 12;
            this.dgpolist.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgpolist_CellDoubleClick);
            this.dgpolist.DoubleClick += new System.EventHandler(this.dgpolist_DoubleClick);
            // 
            // WONumber
            // 
            this.WONumber.DataPropertyName = "WONumber";
            this.WONumber.Frozen = true;
            this.WONumber.HeaderText = "WO Number";
            this.WONumber.Name = "WONumber";
            this.WONumber.ReadOnly = true;
            this.WONumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.WONumber.Width = 101;
            // 
            // PreparedBy
            // 
            this.PreparedBy.DataPropertyName = "PreparedBy";
            this.PreparedBy.HeaderText = "Prepared By";
            this.PreparedBy.Name = "PreparedBy";
            this.PreparedBy.ReadOnly = true;
            this.PreparedBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PreparedBy.Width = 99;
            // 
            // WOPreparedDate
            // 
            this.WOPreparedDate.DataPropertyName = "WOPreparedDate";
            this.WOPreparedDate.HeaderText = "Date";
            this.WOPreparedDate.Name = "WOPreparedDate";
            this.WOPreparedDate.ReadOnly = true;
            this.WOPreparedDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.WOPreparedDate.Width = 47;
            // 
            // PMName
            // 
            this.PMName.DataPropertyName = "PMName";
            this.PMName.HeaderText = "Production Manager";
            this.PMName.Name = "PMName";
            this.PMName.ReadOnly = true;
            this.PMName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PMName.Width = 156;
            // 
            // PMApprovedDate
            // 
            this.PMApprovedDate.DataPropertyName = "PMApprovedDate";
            this.PMApprovedDate.HeaderText = "Date";
            this.PMApprovedDate.Name = "PMApprovedDate";
            this.PMApprovedDate.ReadOnly = true;
            this.PMApprovedDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PMApprovedDate.Width = 47;
            // 
            // FinalizedBy
            // 
            this.FinalizedBy.DataPropertyName = "FinalizedBy";
            this.FinalizedBy.HeaderText = "Finalized By";
            this.FinalizedBy.Name = "FinalizedBy";
            this.FinalizedBy.ReadOnly = true;
            this.FinalizedBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.FinalizedBy.Width = 95;
            // 
            // FinalizedDate
            // 
            this.FinalizedDate.DataPropertyName = "FinalizedDate";
            this.FinalizedDate.HeaderText = "Date";
            this.FinalizedDate.Name = "FinalizedDate";
            this.FinalizedDate.ReadOnly = true;
            this.FinalizedDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.FinalizedDate.Width = 47;
            // 
            // PurchaseCommitee
            // 
            this.PurchaseCommitee.DataPropertyName = "PurchaseCommitee";
            this.PurchaseCommitee.HeaderText = "Project Manager";
            this.PurchaseCommitee.Name = "PurchaseCommitee";
            this.PurchaseCommitee.ReadOnly = true;
            this.PurchaseCommitee.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PurchaseCommitee.Width = 129;
            // 
            // PCAuthoriseDate
            // 
            this.PCAuthoriseDate.DataPropertyName = "PCAuthoriseDate";
            this.PCAuthoriseDate.HeaderText = "Date";
            this.PCAuthoriseDate.Name = "PCAuthoriseDate";
            this.PCAuthoriseDate.ReadOnly = true;
            this.PCAuthoriseDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PCAuthoriseDate.Width = 47;
            // 
            // OMName
            // 
            this.OMName.DataPropertyName = "OperationManager";
            this.OMName.HeaderText = "OMName";
            this.OMName.Name = "OMName";
            this.OMName.ReadOnly = true;
            this.OMName.Width = 99;
            // 
            // OMApproved
            // 
            this.OMApproved.DataPropertyName = "OMApproved";
            this.OMApproved.HeaderText = "OMApproved";
            this.OMApproved.Name = "OMApproved";
            this.OMApproved.ReadOnly = true;
            this.OMApproved.Width = 127;
            // 
            // GMName
            // 
            this.GMName.DataPropertyName = "GMName";
            this.GMName.HeaderText = "GM Name";
            this.GMName.Name = "GMName";
            this.GMName.ReadOnly = true;
            this.GMName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.GMName.Width = 83;
            // 
            // IPItemCode
            // 
            this.IPItemCode.DataPropertyName = "IPItemCode";
            this.IPItemCode.HeaderText = "IP ItemCode";
            this.IPItemCode.Name = "IPItemCode";
            this.IPItemCode.ReadOnly = true;
            this.IPItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IPItemCode.Width = 97;
            // 
            // IPOrderQty
            // 
            this.IPOrderQty.DataPropertyName = "IPOrderQty";
            this.IPOrderQty.HeaderText = "IP Order Qty";
            this.IPOrderQty.Name = "IPOrderQty";
            this.IPOrderQty.ReadOnly = true;
            this.IPOrderQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IPOrderQty.Width = 101;
            // 
            // OPItemCode
            // 
            this.OPItemCode.DataPropertyName = "OPItemCode";
            this.OPItemCode.HeaderText = "OP ItemCode";
            this.OPItemCode.Name = "OPItemCode";
            this.OPItemCode.ReadOnly = true;
            this.OPItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OPItemCode.Width = 104;
            // 
            // ItemDescription
            // 
            this.ItemDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ItemDescription.DataPropertyName = "ItemDescription";
            this.ItemDescription.HeaderText = "ItemDescription";
            this.ItemDescription.Name = "ItemDescription";
            this.ItemDescription.ReadOnly = true;
            this.ItemDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ItemDescription.Width = 123;
            // 
            // OPOrderQty
            // 
            this.OPOrderQty.DataPropertyName = "OPOrderQty";
            this.OPOrderQty.HeaderText = "OP OrderQty";
            this.OPOrderQty.Name = "OPOrderQty";
            this.OPOrderQty.ReadOnly = true;
            this.OPOrderQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OPOrderQty.Width = 104;
            // 
            // ProjectCode
            // 
            this.ProjectCode.DataPropertyName = "ProjectCode";
            this.ProjectCode.HeaderText = "ProjectCode";
            this.ProjectCode.Name = "ProjectCode";
            this.ProjectCode.ReadOnly = true;
            this.ProjectCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectCode.Width = 98;
            // 
            // ProjectDescription
            // 
            this.ProjectDescription.DataPropertyName = "ProjectDescription";
            this.ProjectDescription.HeaderText = "ProjectDescription";
            this.ProjectDescription.Name = "ProjectDescription";
            this.ProjectDescription.ReadOnly = true;
            this.ProjectDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectDescription.Width = 141;
            // 
            // VendorName
            // 
            this.VendorName.DataPropertyName = "VendorName";
            this.VendorName.HeaderText = "VendorName";
            this.VendorName.Name = "VendorName";
            this.VendorName.ReadOnly = true;
            this.VendorName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.VendorName.Width = 104;
            // 
            // UnitCost
            // 
            this.UnitCost.DataPropertyName = "UnitCost";
            this.UnitCost.HeaderText = "Unit Cost";
            this.UnitCost.Name = "UnitCost";
            this.UnitCost.ReadOnly = true;
            this.UnitCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UnitCost.Width = 77;
            // 
            // TotalCost
            // 
            this.TotalCost.DataPropertyName = "TotalCost";
            this.TotalCost.HeaderText = "Total Cost";
            this.TotalCost.Name = "TotalCost";
            this.TotalCost.ReadOnly = true;
            this.TotalCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.TotalCost.Width = 82;
            // 
            // JobIssueStatus
            // 
            this.JobIssueStatus.DataPropertyName = "JobIssueStatus";
            this.JobIssueStatus.HeaderText = "Job Issue Status";
            this.JobIssueStatus.Name = "JobIssueStatus";
            this.JobIssueStatus.ReadOnly = true;
            this.JobIssueStatus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.JobIssueStatus.Width = 122;
            // 
            // WOGeneratedBy
            // 
            this.WOGeneratedBy.DataPropertyName = "WOGeneratedBy";
            this.WOGeneratedBy.HeaderText = "WO Generated By";
            this.WOGeneratedBy.Name = "WOGeneratedBy";
            this.WOGeneratedBy.ReadOnly = true;
            this.WOGeneratedBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.WOGeneratedBy.Width = 138;
            // 
            // WOgeneratedDate
            // 
            this.WOgeneratedDate.DataPropertyName = "WOgeneratedDate";
            this.WOgeneratedDate.HeaderText = "WO Generated Date";
            this.WOgeneratedDate.Name = "WOgeneratedDate";
            this.WOgeneratedDate.ReadOnly = true;
            this.WOgeneratedDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.WOgeneratedDate.Width = 153;
            // 
            // IPRemainingOrderQty
            // 
            this.IPRemainingOrderQty.DataPropertyName = "IPRemainingOrderQty";
            this.IPRemainingOrderQty.HeaderText = "IP Rem Qty";
            this.IPRemainingOrderQty.Name = "IPRemainingOrderQty";
            this.IPRemainingOrderQty.ReadOnly = true;
            this.IPRemainingOrderQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IPRemainingOrderQty.Width = 91;
            // 
            // WorkDescription
            // 
            this.WorkDescription.DataPropertyName = "WorkDescription";
            this.WorkDescription.HeaderText = "Work Description";
            this.WorkDescription.Name = "WorkDescription";
            this.WorkDescription.ReadOnly = true;
            this.WorkDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.WorkDescription.Width = 133;
            // 
            // OPRemainingQty
            // 
            this.OPRemainingQty.DataPropertyName = "OPRemainingQty";
            this.OPRemainingQty.HeaderText = "OP Rem Qty";
            this.OPRemainingQty.Name = "OPRemainingQty";
            this.OPRemainingQty.ReadOnly = true;
            this.OPRemainingQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OPRemainingQty.Width = 98;
            // 
            // ViewWorkOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1304, 682);
            this.Controls.Add(this.gbSearchOptions);
            this.Controls.Add(this.dgpolist);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "ViewWorkOrder";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "View Work Order";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ViewWorkOrder_FormClosing);
            this.Load += new System.EventHandler(this.ViewWorkOrder_Load);
            this.gbSearchOptions.ResumeLayout(false);
            this.gbSearchOptions.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgpolist)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbSearchOptions;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtIPItemCode;
        private System.Windows.Forms.Label lblItemCode;
        private System.Windows.Forms.DataGridView dgpolist;
        private System.Windows.Forms.CheckBox chkLoad;
        private System.Windows.Forms.Button btnrecentlist;
        private System.Windows.Forms.Label lblFromdate;
        private System.Windows.Forms.Label lblToDate;
        private System.Windows.Forms.DateTimePicker dtpFromDate;
        private System.Windows.Forms.DateTimePicker dtpToDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn WONumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn PreparedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn WOPreparedDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn PMName;
        private System.Windows.Forms.DataGridViewTextBoxColumn PMApprovedDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn FinalizedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn FinalizedDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn PurchaseCommitee;
        private System.Windows.Forms.DataGridViewTextBoxColumn PCAuthoriseDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn OMName;
        private System.Windows.Forms.DataGridViewTextBoxColumn OMApproved;
        private System.Windows.Forms.DataGridViewTextBoxColumn GMName;
        private System.Windows.Forms.DataGridViewTextBoxColumn IPItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn IPOrderQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn OPItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn OPOrderQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn VendorName;
        private System.Windows.Forms.DataGridViewTextBoxColumn UnitCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn TotalCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn JobIssueStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn WOGeneratedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn WOgeneratedDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn IPRemainingOrderQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn WorkDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn OPRemainingQty;
    }
}