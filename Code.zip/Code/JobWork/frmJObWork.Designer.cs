﻿namespace Erp_Project_With_Buttons.JobWork
{
    partial class frmJObWork
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmJObWork));
            this.pnItemAdd = new System.Windows.Forms.Panel();
            this.chkItemDesc = new System.Windows.Forms.CheckBox();
            this.chkItemCode = new System.Windows.Forms.CheckBox();
            this.chkopitem = new System.Windows.Forms.CheckBox();
            this.chkipitems = new System.Windows.Forms.CheckBox();
            this.lblItemDescription = new System.Windows.Forms.Label();
            this.txtItemDescription = new System.Windows.Forms.TextBox();
            this.chklbItemList = new System.Windows.Forms.CheckedListBox();
            this.btnviewpolist = new System.Windows.Forms.Button();
            this.pnProject = new System.Windows.Forms.Panel();
            this.cmbProjectCode = new System.Windows.Forms.TextBox();
            this.chkWithoutBOM = new System.Windows.Forms.CheckBox();
            this.lblVersion = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbbomname = new System.Windows.Forms.ComboBox();
            this.lblprdname = new System.Windows.Forms.Label();
            this.lblProductName = new System.Windows.Forms.Label();
            this.lblprojectbom = new System.Windows.Forms.Label();
            this.cmbEmailAlert = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.cbViewRemarks = new System.Windows.Forms.CheckBox();
            this.lblProjectStatus = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.dtpdelivery = new System.Windows.Forms.DateTimePicker();
            this.lbldeliverydate = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblProjectCode = new System.Windows.Forms.Label();
            this.dtpWODate = new System.Windows.Forms.DateTimePicker();
            this.lblVendorName = new System.Windows.Forms.Label();
            this.txtProjectName = new System.Windows.Forms.Label();
            this.lblProjectName = new System.Windows.Forms.Label();
            this.txtCost = new System.Windows.Forms.Label();
            this.lblCost = new System.Windows.Forms.Label();
            this.txtPreparedBy = new System.Windows.Forms.Label();
            this.lblPreparedBy = new System.Windows.Forms.Label();
            this.cmbVendorName = new System.Windows.Forms.ComboBox();
            this.txtAuthorisedBy = new System.Windows.Forms.Label();
            this.lblAuthorisedBy = new System.Windows.Forms.Label();
            this.txtVendorCode = new System.Windows.Forms.TextBox();
            this.chkprintwo = new System.Windows.Forms.CheckBox();
            this.txtDGReferenceno = new System.Windows.Forms.TextBox();
            this.lbldgrefno = new System.Windows.Forms.Label();
            this.lblWONo = new System.Windows.Forms.Label();
            this.cmbWONo = new System.Windows.Forms.ComboBox();
            this.lblFinalNetAmount = new System.Windows.Forms.Label();
            this.txtFinalNetAmount = new System.Windows.Forms.TextBox();
            this.dgopitemlist = new System.Windows.Forms.DataGridView();
            this.IPItem = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IPItemDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IPHsnSac = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IpUnits = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IPAvlbQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BOMQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IPReqQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OPItemCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OPItemDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HsnSacCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WorkDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OPUnits = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OPAvailableQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OPReqQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OPUnitCost = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OPAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbControlButtons = new System.Windows.Forms.GroupBox();
            this.btnRejectPO = new System.Windows.Forms.Button();
            this.btnAcceptPO = new System.Windows.Forms.Button();
            this.btnprintwo = new System.Windows.Forms.Button();
            this.btnWOGenerate = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClearAll = new System.Windows.Forms.Button();
            this.pnWoNo = new System.Windows.Forms.Panel();
            this.pnloadwolist = new System.Windows.Forms.Panel();
            this.chkWoNumber = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.lblWoby = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.cmbDeliverTerms = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.cmbPaymentTerms = new System.Windows.Forms.ComboBox();
            this.dgPackingTaxes = new System.Windows.Forms.DataGridView();
            this.TaxDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxamount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxIGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxIGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxSGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxSGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxCGSTRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxCGSTAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnViewTax = new System.Windows.Forms.Button();
            this.btnAddTransport = new System.Windows.Forms.Button();
            this.btnPackingAmount = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbltotalIGST = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.lbltotalCGST = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.lbltotalSGST = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.lblTotalAmount = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.pnRemarks = new System.Windows.Forms.Panel();
            this.llbViewRemakrs = new System.Windows.Forms.LinkLabel();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.lblRemarks = new System.Windows.Forms.Label();
            this.btnApproveWO = new System.Windows.Forms.Button();
            this.cmbWorkDescription = new System.Windows.Forms.ComboBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.btnrepeatorder = new System.Windows.Forms.Button();
            this.btnloadpolist = new System.Windows.Forms.Button();
            this.dgvRemarks = new System.Windows.Forms.DataGridView();
            this.RemarksBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RemarksDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Remarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnItemAdd.SuspendLayout();
            this.pnProject.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgopitemlist)).BeginInit();
            this.gbControlButtons.SuspendLayout();
            this.pnWoNo.SuspendLayout();
            this.pnloadwolist.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgPackingTaxes)).BeginInit();
            this.panel1.SuspendLayout();
            this.pnRemarks.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRemarks)).BeginInit();
            this.SuspendLayout();
            // 
            // pnItemAdd
            // 
            this.pnItemAdd.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnItemAdd.Controls.Add(this.chkItemDesc);
            this.pnItemAdd.Controls.Add(this.chkItemCode);
            this.pnItemAdd.Controls.Add(this.chkopitem);
            this.pnItemAdd.Controls.Add(this.chkipitems);
            this.pnItemAdd.Controls.Add(this.lblItemDescription);
            this.pnItemAdd.Controls.Add(this.txtItemDescription);
            this.pnItemAdd.Controls.Add(this.chklbItemList);
            this.pnItemAdd.Location = new System.Drawing.Point(3, 2);
            this.pnItemAdd.Name = "pnItemAdd";
            this.pnItemAdd.Size = new System.Drawing.Size(558, 287);
            this.pnItemAdd.TabIndex = 15;
            // 
            // chkItemDesc
            // 
            this.chkItemDesc.AutoSize = true;
            this.chkItemDesc.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemDesc.ForeColor = System.Drawing.Color.Black;
            this.chkItemDesc.Location = new System.Drawing.Point(265, -1);
            this.chkItemDesc.Name = "chkItemDesc";
            this.chkItemDesc.Size = new System.Drawing.Size(140, 23);
            this.chkItemDesc.TabIndex = 213;
            this.chkItemDesc.Text = "Item Description";
            this.chkItemDesc.UseVisualStyleBackColor = true;
            this.chkItemDesc.CheckedChanged += new System.EventHandler(this.chkItemDesc_CheckedChanged);
            // 
            // chkItemCode
            // 
            this.chkItemCode.AutoSize = true;
            this.chkItemCode.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkItemCode.ForeColor = System.Drawing.Color.Black;
            this.chkItemCode.Location = new System.Drawing.Point(136, 0);
            this.chkItemCode.Name = "chkItemCode";
            this.chkItemCode.Size = new System.Drawing.Size(97, 23);
            this.chkItemCode.TabIndex = 212;
            this.chkItemCode.Text = "Item Code";
            this.chkItemCode.UseVisualStyleBackColor = true;
            this.chkItemCode.CheckedChanged += new System.EventHandler(this.chkItemCode_CheckedChanged);
            // 
            // chkopitem
            // 
            this.chkopitem.AutoSize = true;
            this.chkopitem.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkopitem.ForeColor = System.Drawing.Color.Black;
            this.chkopitem.Location = new System.Drawing.Point(236, 63);
            this.chkopitem.Name = "chkopitem";
            this.chkopitem.Size = new System.Drawing.Size(161, 23);
            this.chkopitem.TabIndex = 126;
            this.chkopitem.Text = "Add Output Item(s)";
            this.chkopitem.UseVisualStyleBackColor = true;
            this.chkopitem.CheckedChanged += new System.EventHandler(this.chkopitem_CheckedChanged);
            // 
            // chkipitems
            // 
            this.chkipitems.AutoSize = true;
            this.chkipitems.Checked = true;
            this.chkipitems.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkipitems.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkipitems.ForeColor = System.Drawing.Color.Black;
            this.chkipitems.Location = new System.Drawing.Point(11, 63);
            this.chkipitems.Name = "chkipitems";
            this.chkipitems.Size = new System.Drawing.Size(148, 23);
            this.chkipitems.TabIndex = 125;
            this.chkipitems.Text = "Add Input Item(s)";
            this.chkipitems.UseVisualStyleBackColor = true;
            this.chkipitems.CheckedChanged += new System.EventHandler(this.chkipitems_CheckedChanged);
            // 
            // lblItemDescription
            // 
            this.lblItemDescription.AutoSize = true;
            this.lblItemDescription.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.lblItemDescription.ForeColor = System.Drawing.Color.Black;
            this.lblItemDescription.Location = new System.Drawing.Point(7, 1);
            this.lblItemDescription.Name = "lblItemDescription";
            this.lblItemDescription.Size = new System.Drawing.Size(90, 19);
            this.lblItemDescription.TabIndex = 122;
            this.lblItemDescription.Text = "Search Item";
            // 
            // txtItemDescription
            // 
            this.txtItemDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtItemDescription.Location = new System.Drawing.Point(4, 22);
            this.txtItemDescription.Multiline = true;
            this.txtItemDescription.Name = "txtItemDescription";
            this.txtItemDescription.Size = new System.Drawing.Size(547, 38);
            this.txtItemDescription.TabIndex = 120;
            this.txtItemDescription.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtItemDescription_MouseClick);
            this.txtItemDescription.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtItemDescription_KeyUp);
            // 
            // chklbItemList
            // 
            this.chklbItemList.CheckOnClick = true;
            this.chklbItemList.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chklbItemList.FormattingEnabled = true;
            this.chklbItemList.HorizontalScrollbar = true;
            this.chklbItemList.Location = new System.Drawing.Point(4, 87);
            this.chklbItemList.Name = "chklbItemList";
            this.chklbItemList.Size = new System.Drawing.Size(547, 193);
            this.chklbItemList.TabIndex = 118;
            this.chklbItemList.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.chklbItemList_ItemCheck);
            // 
            // btnviewpolist
            // 
            this.btnviewpolist.BackColor = System.Drawing.Color.Chocolate;
            this.btnviewpolist.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnviewpolist.Location = new System.Drawing.Point(3, 587);
            this.btnviewpolist.Name = "btnviewpolist";
            this.btnviewpolist.Size = new System.Drawing.Size(174, 37);
            this.btnviewpolist.TabIndex = 117;
            this.btnviewpolist.Text = "View Work Order";
            this.btnviewpolist.UseVisualStyleBackColor = false;
            this.btnviewpolist.Click += new System.EventHandler(this.btnviewpolist_Click);
            // 
            // pnProject
            // 
            this.pnProject.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnProject.Controls.Add(this.cmbProjectCode);
            this.pnProject.Controls.Add(this.chkWithoutBOM);
            this.pnProject.Controls.Add(this.lblVersion);
            this.pnProject.Controls.Add(this.label5);
            this.pnProject.Controls.Add(this.cmbbomname);
            this.pnProject.Controls.Add(this.lblprdname);
            this.pnProject.Controls.Add(this.lblProductName);
            this.pnProject.Controls.Add(this.lblprojectbom);
            this.pnProject.Controls.Add(this.cmbEmailAlert);
            this.pnProject.Controls.Add(this.label27);
            this.pnProject.Controls.Add(this.cbViewRemarks);
            this.pnProject.Controls.Add(this.lblProjectStatus);
            this.pnProject.Controls.Add(this.label9);
            this.pnProject.Controls.Add(this.dtpdelivery);
            this.pnProject.Controls.Add(this.lbldeliverydate);
            this.pnProject.Controls.Add(this.label6);
            this.pnProject.Controls.Add(this.lblProjectCode);
            this.pnProject.Controls.Add(this.dtpWODate);
            this.pnProject.Controls.Add(this.lblVendorName);
            this.pnProject.Controls.Add(this.txtProjectName);
            this.pnProject.Controls.Add(this.lblProjectName);
            this.pnProject.Controls.Add(this.txtCost);
            this.pnProject.Controls.Add(this.lblCost);
            this.pnProject.Controls.Add(this.txtPreparedBy);
            this.pnProject.Controls.Add(this.lblPreparedBy);
            this.pnProject.Controls.Add(this.cmbVendorName);
            this.pnProject.Controls.Add(this.txtAuthorisedBy);
            this.pnProject.Controls.Add(this.lblAuthorisedBy);
            this.pnProject.Controls.Add(this.txtVendorCode);
            this.pnProject.Location = new System.Drawing.Point(562, 42);
            this.pnProject.Name = "pnProject";
            this.pnProject.Size = new System.Drawing.Size(738, 247);
            this.pnProject.TabIndex = 121;
            // 
            // cmbProjectCode
            // 
            this.cmbProjectCode.BackColor = System.Drawing.Color.LightGreen;
            this.cmbProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.cmbProjectCode.Location = new System.Drawing.Point(102, 5);
            this.cmbProjectCode.Name = "cmbProjectCode";
            this.cmbProjectCode.ReadOnly = true;
            this.cmbProjectCode.Size = new System.Drawing.Size(286, 26);
            this.cmbProjectCode.TabIndex = 178;
            this.toolTip1.SetToolTip(this.cmbProjectCode, "Double click to view project list");
            this.cmbProjectCode.TextChanged += new System.EventHandler(this.cmbProjectCode_TextChanged);
            this.cmbProjectCode.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.cmbProjectCode_MouseDoubleClick);
            // 
            // chkWithoutBOM
            // 
            this.chkWithoutBOM.AutoSize = true;
            this.chkWithoutBOM.Enabled = false;
            this.chkWithoutBOM.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkWithoutBOM.ForeColor = System.Drawing.Color.Blue;
            this.chkWithoutBOM.Location = new System.Drawing.Point(577, 62);
            this.chkWithoutBOM.Name = "chkWithoutBOM";
            this.chkWithoutBOM.Size = new System.Drawing.Size(154, 23);
            this.chkWithoutBOM.TabIndex = 177;
            this.chkWithoutBOM.Text = "WO Without BOM";
            this.chkWithoutBOM.UseVisualStyleBackColor = true;
            this.chkWithoutBOM.CheckedChanged += new System.EventHandler(this.chkWithoutBOM_CheckedChanged);
            // 
            // lblVersion
            // 
            this.lblVersion.AutoSize = true;
            this.lblVersion.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVersion.ForeColor = System.Drawing.Color.Black;
            this.lblVersion.Location = new System.Drawing.Point(467, 80);
            this.lblVersion.MaximumSize = new System.Drawing.Size(300, 0);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(15, 18);
            this.lblVersion.TabIndex = 176;
            this.lblVersion.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(408, 80);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 18);
            this.label5.TabIndex = 175;
            this.label5.Text = "Pro No :";
            // 
            // cmbbomname
            // 
            this.cmbbomname.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbbomname.DropDownHeight = 130;
            this.cmbbomname.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbbomname.DropDownWidth = 600;
            this.cmbbomname.Enabled = false;
            this.cmbbomname.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbbomname.FormattingEnabled = true;
            this.cmbbomname.IntegralHeight = false;
            this.cmbbomname.Location = new System.Drawing.Point(102, 77);
            this.cmbbomname.Name = "cmbbomname";
            this.cmbbomname.Size = new System.Drawing.Size(286, 23);
            this.cmbbomname.TabIndex = 173;
            this.cmbbomname.SelectedIndexChanged += new System.EventHandler(this.cmbbomname_SelectedIndexChanged);
            // 
            // lblprdname
            // 
            this.lblprdname.AutoSize = true;
            this.lblprdname.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprdname.ForeColor = System.Drawing.Color.Black;
            this.lblprdname.Location = new System.Drawing.Point(4, 107);
            this.lblprdname.Name = "lblprdname";
            this.lblprdname.Size = new System.Drawing.Size(103, 18);
            this.lblprdname.TabIndex = 171;
            this.lblprdname.Text = "Product Name :";
            // 
            // lblProductName
            // 
            this.lblProductName.AutoSize = true;
            this.lblProductName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductName.ForeColor = System.Drawing.Color.Black;
            this.lblProductName.Location = new System.Drawing.Point(104, 107);
            this.lblProductName.MaximumSize = new System.Drawing.Size(300, 0);
            this.lblProductName.Name = "lblProductName";
            this.lblProductName.Size = new System.Drawing.Size(12, 18);
            this.lblProductName.TabIndex = 174;
            this.lblProductName.Text = ".";
            // 
            // lblprojectbom
            // 
            this.lblprojectbom.AutoSize = true;
            this.lblprojectbom.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.lblprojectbom.ForeColor = System.Drawing.Color.Black;
            this.lblprojectbom.Location = new System.Drawing.Point(6, 80);
            this.lblprojectbom.Name = "lblprojectbom";
            this.lblprojectbom.Size = new System.Drawing.Size(97, 18);
            this.lblprojectbom.TabIndex = 172;
            this.lblprojectbom.Text = "BOM Product :";
            // 
            // cmbEmailAlert
            // 
            this.cmbEmailAlert.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbEmailAlert.DropDownHeight = 130;
            this.cmbEmailAlert.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbEmailAlert.FormattingEnabled = true;
            this.cmbEmailAlert.IntegralHeight = false;
            this.cmbEmailAlert.Location = new System.Drawing.Point(570, 186);
            this.cmbEmailAlert.Name = "cmbEmailAlert";
            this.cmbEmailAlert.Size = new System.Drawing.Size(155, 26);
            this.cmbEmailAlert.TabIndex = 170;
            this.cmbEmailAlert.SelectedIndexChanged += new System.EventHandler(this.cmbEmailAlert_SelectedIndexChanged);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.Black;
            this.label27.Location = new System.Drawing.Point(483, 191);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(86, 15);
            this.label27.TabIndex = 169;
            this.label27.Text = "Email Alert to:";
            // 
            // cbViewRemarks
            // 
            this.cbViewRemarks.AutoSize = true;
            this.cbViewRemarks.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbViewRemarks.ForeColor = System.Drawing.Color.Blue;
            this.cbViewRemarks.Location = new System.Drawing.Point(570, 157);
            this.cbViewRemarks.Name = "cbViewRemarks";
            this.cbViewRemarks.Size = new System.Drawing.Size(87, 23);
            this.cbViewRemarks.TabIndex = 167;
            this.cbViewRemarks.Text = "View Tax";
            this.cbViewRemarks.UseVisualStyleBackColor = true;
            this.cbViewRemarks.CheckedChanged += new System.EventHandler(this.cbViewRemarks_CheckedChanged);
            // 
            // lblProjectStatus
            // 
            this.lblProjectStatus.AutoSize = true;
            this.lblProjectStatus.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectStatus.ForeColor = System.Drawing.Color.Black;
            this.lblProjectStatus.Location = new System.Drawing.Point(688, 42);
            this.lblProjectStatus.Name = "lblProjectStatus";
            this.lblProjectStatus.Size = new System.Drawing.Size(15, 18);
            this.lblProjectStatus.TabIndex = 162;
            this.lblProjectStatus.Text = "*";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(593, 41);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(97, 18);
            this.label9.TabIndex = 163;
            this.label9.Text = "Project Status:";
            // 
            // dtpdelivery
            // 
            this.dtpdelivery.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpdelivery.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpdelivery.Location = new System.Drawing.Point(646, 4);
            this.dtpdelivery.Name = "dtpdelivery";
            this.dtpdelivery.Size = new System.Drawing.Size(87, 23);
            this.dtpdelivery.TabIndex = 161;
            this.dtpdelivery.ValueChanged += new System.EventHandler(this.dtpdelivery_ValueChanged);
            // 
            // lbldeliverydate
            // 
            this.lbldeliverydate.AutoSize = true;
            this.lbldeliverydate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldeliverydate.ForeColor = System.Drawing.Color.Black;
            this.lbldeliverydate.Location = new System.Drawing.Point(567, 7);
            this.lbldeliverydate.Name = "lbldeliverydate";
            this.lbldeliverydate.Size = new System.Drawing.Size(78, 18);
            this.lbldeliverydate.TabIndex = 160;
            this.lbldeliverydate.Text = "Delivery By";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(408, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 18);
            this.label6.TabIndex = 159;
            this.label6.Text = "WO Date";
            // 
            // lblProjectCode
            // 
            this.lblProjectCode.AutoSize = true;
            this.lblProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectCode.ForeColor = System.Drawing.Color.Black;
            this.lblProjectCode.Location = new System.Drawing.Point(8, 8);
            this.lblProjectCode.Name = "lblProjectCode";
            this.lblProjectCode.Size = new System.Drawing.Size(94, 18);
            this.lblProjectCode.TabIndex = 152;
            this.lblProjectCode.Text = "Project Code :";
            // 
            // dtpWODate
            // 
            this.dtpWODate.Enabled = false;
            this.dtpWODate.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpWODate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpWODate.Location = new System.Drawing.Point(473, 5);
            this.dtpWODate.Name = "dtpWODate";
            this.dtpWODate.Size = new System.Drawing.Size(90, 23);
            this.dtpWODate.TabIndex = 130;
            // 
            // lblVendorName
            // 
            this.lblVendorName.AutoSize = true;
            this.lblVendorName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVendorName.ForeColor = System.Drawing.Color.Black;
            this.lblVendorName.Location = new System.Drawing.Point(3, 186);
            this.lblVendorName.Name = "lblVendorName";
            this.lblVendorName.Size = new System.Drawing.Size(100, 18);
            this.lblVendorName.TabIndex = 139;
            this.lblVendorName.Text = "Vendor Name :";
            // 
            // txtProjectName
            // 
            this.txtProjectName.AutoSize = true;
            this.txtProjectName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProjectName.ForeColor = System.Drawing.Color.Black;
            this.txtProjectName.Location = new System.Drawing.Point(99, 42);
            this.txtProjectName.Name = "txtProjectName";
            this.txtProjectName.Size = new System.Drawing.Size(15, 18);
            this.txtProjectName.TabIndex = 154;
            this.txtProjectName.Text = "*";
            // 
            // lblProjectName
            // 
            this.lblProjectName.AutoSize = true;
            this.lblProjectName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectName.ForeColor = System.Drawing.Color.Black;
            this.lblProjectName.Location = new System.Drawing.Point(6, 41);
            this.lblProjectName.Name = "lblProjectName";
            this.lblProjectName.Size = new System.Drawing.Size(96, 18);
            this.lblProjectName.TabIndex = 154;
            this.lblProjectName.Text = "Project Name:";
            // 
            // txtCost
            // 
            this.txtCost.AutoSize = true;
            this.txtCost.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCost.ForeColor = System.Drawing.Color.Black;
            this.txtCost.Location = new System.Drawing.Point(99, 218);
            this.txtCost.Name = "txtCost";
            this.txtCost.Size = new System.Drawing.Size(15, 18);
            this.txtCost.TabIndex = 150;
            this.txtCost.Text = "0";
            // 
            // lblCost
            // 
            this.lblCost.AutoSize = true;
            this.lblCost.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCost.ForeColor = System.Drawing.Color.Black;
            this.lblCost.Location = new System.Drawing.Point(28, 218);
            this.lblCost.Name = "lblCost";
            this.lblCost.Size = new System.Drawing.Size(72, 18);
            this.lblCost.TabIndex = 150;
            this.lblCost.Text = "Total Cost:";
            // 
            // txtPreparedBy
            // 
            this.txtPreparedBy.AutoSize = true;
            this.txtPreparedBy.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPreparedBy.ForeColor = System.Drawing.Color.Black;
            this.txtPreparedBy.Location = new System.Drawing.Point(614, 95);
            this.txtPreparedBy.Name = "txtPreparedBy";
            this.txtPreparedBy.Size = new System.Drawing.Size(15, 18);
            this.txtPreparedBy.TabIndex = 134;
            this.txtPreparedBy.Text = "*";
            // 
            // lblPreparedBy
            // 
            this.lblPreparedBy.AutoSize = true;
            this.lblPreparedBy.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreparedBy.ForeColor = System.Drawing.Color.Black;
            this.lblPreparedBy.Location = new System.Drawing.Point(530, 95);
            this.lblPreparedBy.Name = "lblPreparedBy";
            this.lblPreparedBy.Size = new System.Drawing.Size(90, 18);
            this.lblPreparedBy.TabIndex = 134;
            this.lblPreparedBy.Text = "Prepared By :";
            // 
            // cmbVendorName
            // 
            this.cmbVendorName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbVendorName.DropDownHeight = 80;
            this.cmbVendorName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbVendorName.FormattingEnabled = true;
            this.cmbVendorName.IntegralHeight = false;
            this.cmbVendorName.Location = new System.Drawing.Point(102, 185);
            this.cmbVendorName.Name = "cmbVendorName";
            this.cmbVendorName.Size = new System.Drawing.Size(334, 26);
            this.cmbVendorName.Sorted = true;
            this.cmbVendorName.TabIndex = 146;
            this.cmbVendorName.SelectedIndexChanged += new System.EventHandler(this.cmbVendorName_SelectedIndexChanged);
            // 
            // txtAuthorisedBy
            // 
            this.txtAuthorisedBy.AutoSize = true;
            this.txtAuthorisedBy.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAuthorisedBy.ForeColor = System.Drawing.Color.Black;
            this.txtAuthorisedBy.Location = new System.Drawing.Point(387, 222);
            this.txtAuthorisedBy.Name = "txtAuthorisedBy";
            this.txtAuthorisedBy.Size = new System.Drawing.Size(15, 18);
            this.txtAuthorisedBy.TabIndex = 136;
            this.txtAuthorisedBy.Text = "*";
            // 
            // lblAuthorisedBy
            // 
            this.lblAuthorisedBy.AutoSize = true;
            this.lblAuthorisedBy.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAuthorisedBy.ForeColor = System.Drawing.Color.Black;
            this.lblAuthorisedBy.Location = new System.Drawing.Point(293, 219);
            this.lblAuthorisedBy.Name = "lblAuthorisedBy";
            this.lblAuthorisedBy.Size = new System.Drawing.Size(94, 18);
            this.lblAuthorisedBy.TabIndex = 136;
            this.lblAuthorisedBy.Text = "Approved By :";
            // 
            // txtVendorCode
            // 
            this.txtVendorCode.Enabled = false;
            this.txtVendorCode.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVendorCode.Location = new System.Drawing.Point(455, 186);
            this.txtVendorCode.Multiline = true;
            this.txtVendorCode.Name = "txtVendorCode";
            this.txtVendorCode.Size = new System.Drawing.Size(27, 25);
            this.txtVendorCode.TabIndex = 138;
            this.txtVendorCode.Visible = false;
            // 
            // chkprintwo
            // 
            this.chkprintwo.AutoSize = true;
            this.chkprintwo.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkprintwo.ForeColor = System.Drawing.Color.Black;
            this.chkprintwo.Location = new System.Drawing.Point(345, 2);
            this.chkprintwo.Name = "chkprintwo";
            this.chkprintwo.Size = new System.Drawing.Size(92, 23);
            this.chkprintwo.TabIndex = 159;
            this.chkprintwo.Text = "Print WO";
            this.chkprintwo.UseVisualStyleBackColor = false;
            this.chkprintwo.CheckedChanged += new System.EventHandler(this.chkprintwo_CheckedChanged);
            // 
            // txtDGReferenceno
            // 
            this.txtDGReferenceno.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDGReferenceno.Location = new System.Drawing.Point(93, 4);
            this.txtDGReferenceno.Multiline = true;
            this.txtDGReferenceno.Name = "txtDGReferenceno";
            this.txtDGReferenceno.Size = new System.Drawing.Size(156, 22);
            this.txtDGReferenceno.TabIndex = 157;
            // 
            // lbldgrefno
            // 
            this.lbldgrefno.AutoSize = true;
            this.lbldgrefno.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldgrefno.ForeColor = System.Drawing.Color.Black;
            this.lbldgrefno.Location = new System.Drawing.Point(7, 4);
            this.lbldgrefno.Name = "lbldgrefno";
            this.lbldgrefno.Size = new System.Drawing.Size(85, 19);
            this.lbldgrefno.TabIndex = 156;
            this.lbldgrefno.Tag = "ference";
            this.lbldgrefno.Text = "DC Ref No :";
            // 
            // lblWONo
            // 
            this.lblWONo.AutoSize = true;
            this.lblWONo.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWONo.ForeColor = System.Drawing.Color.Black;
            this.lblWONo.Location = new System.Drawing.Point(5, 6);
            this.lblWONo.Name = "lblWONo";
            this.lblWONo.Size = new System.Drawing.Size(63, 19);
            this.lblWONo.TabIndex = 141;
            this.lblWONo.Text = "WO No:";
            // 
            // cmbWONo
            // 
            this.cmbWONo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbWONo.DropDownHeight = 80;
            this.cmbWONo.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbWONo.FormattingEnabled = true;
            this.cmbWONo.IntegralHeight = false;
            this.cmbWONo.Location = new System.Drawing.Point(68, 3);
            this.cmbWONo.Name = "cmbWONo";
            this.cmbWONo.Size = new System.Drawing.Size(220, 23);
            this.cmbWONo.TabIndex = 148;
            this.cmbWONo.SelectedIndexChanged += new System.EventHandler(this.cmbWONo_SelectedIndexChanged);
            // 
            // lblFinalNetAmount
            // 
            this.lblFinalNetAmount.AutoSize = true;
            this.lblFinalNetAmount.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFinalNetAmount.ForeColor = System.Drawing.Color.Black;
            this.lblFinalNetAmount.Location = new System.Drawing.Point(962, 558);
            this.lblFinalNetAmount.Name = "lblFinalNetAmount";
            this.lblFinalNetAmount.Size = new System.Drawing.Size(155, 23);
            this.lblFinalNetAmount.TabIndex = 8;
            this.lblFinalNetAmount.Text = "Final Net Amount:";
            // 
            // txtFinalNetAmount
            // 
            this.txtFinalNetAmount.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.txtFinalNetAmount.Enabled = false;
            this.txtFinalNetAmount.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFinalNetAmount.Location = new System.Drawing.Point(1119, 555);
            this.txtFinalNetAmount.Name = "txtFinalNetAmount";
            this.txtFinalNetAmount.ReadOnly = true;
            this.txtFinalNetAmount.Size = new System.Drawing.Size(178, 31);
            this.txtFinalNetAmount.TabIndex = 24;
            this.txtFinalNetAmount.Text = "0.0";
            // 
            // dgopitemlist
            // 
            this.dgopitemlist.AllowUserToAddRows = false;
            this.dgopitemlist.AllowUserToDeleteRows = false;
            this.dgopitemlist.AllowUserToResizeRows = false;
            this.dgopitemlist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgopitemlist.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgopitemlist.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgopitemlist.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgopitemlist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgopitemlist.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IPItem,
            this.IPItemDesc,
            this.IPHsnSac,
            this.IpUnits,
            this.IPAvlbQty,
            this.BOMQty,
            this.IPReqQty,
            this.OPItemCode,
            this.OPItemDesc,
            this.HsnSacCode,
            this.WorkDescription,
            this.OPUnits,
            this.OPAvailableQty,
            this.OPReqQty,
            this.OPUnitCost,
            this.OPAmount,
            this.SGSTRate,
            this.SGSTAmount,
            this.CGSTRate,
            this.CGSTAmount,
            this.IGSTRate,
            this.IGSTAmount});
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgopitemlist.DefaultCellStyle = dataGridViewCellStyle16;
            this.dgopitemlist.EnableHeadersVisualStyles = false;
            this.dgopitemlist.GridColor = System.Drawing.SystemColors.AppWorkspace;
            this.dgopitemlist.Location = new System.Drawing.Point(3, 295);
            this.dgopitemlist.MultiSelect = false;
            this.dgopitemlist.Name = "dgopitemlist";
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgopitemlist.RowHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.dgopitemlist.RowHeadersVisible = false;
            this.dgopitemlist.Size = new System.Drawing.Size(1297, 208);
            this.dgopitemlist.TabIndex = 129;
            this.dgopitemlist.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgopitemlist_CellBeginEdit);
            this.dgopitemlist.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgopitemlist_CellClick);
            this.dgopitemlist.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgopitemlist_CellEndEdit);
            this.dgopitemlist.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.dgopitemlist_CellValidating);
            this.dgopitemlist.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgopitemlist_EditingControlShowing);
            this.dgopitemlist.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.dgopitemlist_RowsRemoved);
            this.dgopitemlist.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgopitemlist_KeyUp);
            // 
            // IPItem
            // 
            this.IPItem.DataPropertyName = "IPItemCode";
            this.IPItem.HeaderText = "I/P Item";
            this.IPItem.Name = "IPItem";
            this.IPItem.ReadOnly = true;
            this.IPItem.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IPItem.Width = 70;
            // 
            // IPItemDesc
            // 
            this.IPItemDesc.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.IPItemDesc.DataPropertyName = "IPItemDesc";
            this.IPItemDesc.HeaderText = "ItemDesc.";
            this.IPItemDesc.Name = "IPItemDesc";
            this.IPItemDesc.ReadOnly = true;
            this.IPItemDesc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IPItemDesc.Width = 82;
            // 
            // IPHsnSac
            // 
            this.IPHsnSac.DataPropertyName = "IPHSNSACCode";
            this.IPHsnSac.HeaderText = "Hsn Sac";
            this.IPHsnSac.Name = "IPHsnSac";
            this.IPHsnSac.ReadOnly = true;
            this.IPHsnSac.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IPHsnSac.Width = 67;
            // 
            // IpUnits
            // 
            this.IpUnits.DataPropertyName = "IPUnit";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.IpUnits.DefaultCellStyle = dataGridViewCellStyle2;
            this.IpUnits.HeaderText = "Units";
            this.IpUnits.Name = "IpUnits";
            this.IpUnits.ReadOnly = true;
            this.IpUnits.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IpUnits.Width = 50;
            // 
            // IPAvlbQty
            // 
            this.IPAvlbQty.DataPropertyName = "IPAQty";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.IPAvlbQty.DefaultCellStyle = dataGridViewCellStyle3;
            this.IPAvlbQty.HeaderText = "Avl Qty";
            this.IPAvlbQty.Name = "IPAvlbQty";
            this.IPAvlbQty.ReadOnly = true;
            this.IPAvlbQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IPAvlbQty.Width = 66;
            // 
            // BOMQty
            // 
            this.BOMQty.DataPropertyName = "IBOMQty";
            this.BOMQty.HeaderText = "BOM Qty";
            this.BOMQty.Name = "BOMQty";
            this.BOMQty.ReadOnly = true;
            this.BOMQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.BOMQty.Width = 78;
            // 
            // IPReqQty
            // 
            this.IPReqQty.DataPropertyName = "IPOrderQty";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.IPReqQty.DefaultCellStyle = dataGridViewCellStyle4;
            this.IPReqQty.HeaderText = "Req Qty";
            this.IPReqQty.Name = "IPReqQty";
            this.IPReqQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IPReqQty.Width = 70;
            // 
            // OPItemCode
            // 
            this.OPItemCode.DataPropertyName = "OPItemCode";
            this.OPItemCode.HeaderText = "O/P Item";
            this.OPItemCode.Name = "OPItemCode";
            this.OPItemCode.ReadOnly = true;
            this.OPItemCode.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.OPItemCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OPItemCode.Width = 77;
            // 
            // OPItemDesc
            // 
            this.OPItemDesc.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.OPItemDesc.DataPropertyName = "OPItemDesc";
            this.OPItemDesc.HeaderText = "Item Desc.";
            this.OPItemDesc.Name = "OPItemDesc";
            this.OPItemDesc.ReadOnly = true;
            this.OPItemDesc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OPItemDesc.Width = 86;
            // 
            // HsnSacCode
            // 
            this.HsnSacCode.DataPropertyName = "OPHSNSACCode";
            this.HsnSacCode.HeaderText = "Hsn Sac";
            this.HsnSacCode.Name = "HsnSacCode";
            this.HsnSacCode.ReadOnly = true;
            this.HsnSacCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.HsnSacCode.Width = 67;
            // 
            // WorkDescription
            // 
            this.WorkDescription.DataPropertyName = "WorkDescription";
            this.WorkDescription.HeaderText = "Work Desc.";
            this.WorkDescription.Name = "WorkDescription";
            this.WorkDescription.ReadOnly = true;
            this.WorkDescription.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.WorkDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.WorkDescription.Width = 91;
            // 
            // OPUnits
            // 
            this.OPUnits.DataPropertyName = "OPUnit";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.OPUnits.DefaultCellStyle = dataGridViewCellStyle5;
            this.OPUnits.HeaderText = "Units";
            this.OPUnits.Name = "OPUnits";
            this.OPUnits.ReadOnly = true;
            this.OPUnits.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OPUnits.Width = 50;
            // 
            // OPAvailableQty
            // 
            this.OPAvailableQty.DataPropertyName = "OPAQTY";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.OPAvailableQty.DefaultCellStyle = dataGridViewCellStyle6;
            this.OPAvailableQty.HeaderText = "Avl Qty";
            this.OPAvailableQty.Name = "OPAvailableQty";
            this.OPAvailableQty.ReadOnly = true;
            this.OPAvailableQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OPAvailableQty.Width = 66;
            // 
            // OPReqQty
            // 
            this.OPReqQty.DataPropertyName = "OPOrderQty";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.OPReqQty.DefaultCellStyle = dataGridViewCellStyle7;
            this.OPReqQty.HeaderText = "Req Qty";
            this.OPReqQty.Name = "OPReqQty";
            this.OPReqQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OPReqQty.Width = 70;
            // 
            // OPUnitCost
            // 
            this.OPUnitCost.DataPropertyName = "UnitCost";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.OPUnitCost.DefaultCellStyle = dataGridViewCellStyle8;
            this.OPUnitCost.HeaderText = "Unit Cost";
            this.OPUnitCost.Name = "OPUnitCost";
            this.OPUnitCost.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OPUnitCost.Width = 77;
            // 
            // OPAmount
            // 
            this.OPAmount.DataPropertyName = "TotalCost";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.OPAmount.DefaultCellStyle = dataGridViewCellStyle9;
            this.OPAmount.HeaderText = "Amount";
            this.OPAmount.Name = "OPAmount";
            this.OPAmount.ReadOnly = true;
            this.OPAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OPAmount.Width = 71;
            // 
            // SGSTRate
            // 
            this.SGSTRate.DataPropertyName = "SGSTRate";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle10.NullValue = "0";
            this.SGSTRate.DefaultCellStyle = dataGridViewCellStyle10;
            this.SGSTRate.HeaderText = "SGST %";
            this.SGSTRate.Name = "SGSTRate";
            this.SGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SGSTRate.Width = 65;
            // 
            // SGSTAmount
            // 
            this.SGSTAmount.DataPropertyName = "SGSTAmount";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle11.Format = "N2";
            dataGridViewCellStyle11.NullValue = "0";
            this.SGSTAmount.DefaultCellStyle = dataGridViewCellStyle11;
            this.SGSTAmount.HeaderText = "SGST Amt ";
            this.SGSTAmount.Name = "SGSTAmount";
            this.SGSTAmount.ReadOnly = true;
            this.SGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SGSTAmount.Width = 86;
            // 
            // CGSTRate
            // 
            this.CGSTRate.DataPropertyName = "CGSTRate";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle12.NullValue = "0";
            this.CGSTRate.DefaultCellStyle = dataGridViewCellStyle12;
            this.CGSTRate.HeaderText = "CGST %";
            this.CGSTRate.Name = "CGSTRate";
            this.CGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CGSTRate.Width = 65;
            // 
            // CGSTAmount
            // 
            this.CGSTAmount.DataPropertyName = "CGSTAmount";
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle13.Format = "N2";
            dataGridViewCellStyle13.NullValue = "0";
            this.CGSTAmount.DefaultCellStyle = dataGridViewCellStyle13;
            this.CGSTAmount.HeaderText = "CGST Amt";
            this.CGSTAmount.Name = "CGSTAmount";
            this.CGSTAmount.ReadOnly = true;
            this.CGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CGSTAmount.Width = 82;
            // 
            // IGSTRate
            // 
            this.IGSTRate.DataPropertyName = "IGSTRate";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle14.NullValue = "0";
            this.IGSTRate.DefaultCellStyle = dataGridViewCellStyle14;
            this.IGSTRate.HeaderText = "IGST %";
            this.IGSTRate.Name = "IGSTRate";
            this.IGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IGSTRate.Width = 61;
            // 
            // IGSTAmount
            // 
            this.IGSTAmount.DataPropertyName = "IGSTAmount";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle15.Format = "N2";
            dataGridViewCellStyle15.NullValue = "0";
            this.IGSTAmount.DefaultCellStyle = dataGridViewCellStyle15;
            this.IGSTAmount.HeaderText = "IGST Amt";
            this.IGSTAmount.Name = "IGSTAmount";
            this.IGSTAmount.ReadOnly = true;
            this.IGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.IGSTAmount.Width = 78;
            // 
            // gbControlButtons
            // 
            this.gbControlButtons.Controls.Add(this.btnRejectPO);
            this.gbControlButtons.Controls.Add(this.btnAcceptPO);
            this.gbControlButtons.Controls.Add(this.btnprintwo);
            this.gbControlButtons.Controls.Add(this.btnWOGenerate);
            this.gbControlButtons.Controls.Add(this.btnExit);
            this.gbControlButtons.Controls.Add(this.btnSave);
            this.gbControlButtons.Controls.Add(this.btnClearAll);
            this.gbControlButtons.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.gbControlButtons.Location = new System.Drawing.Point(5, 618);
            this.gbControlButtons.Name = "gbControlButtons";
            this.gbControlButtons.Size = new System.Drawing.Size(1292, 61);
            this.gbControlButtons.TabIndex = 130;
            this.gbControlButtons.TabStop = false;
            // 
            // btnRejectPO
            // 
            this.btnRejectPO.BackColor = System.Drawing.Color.Red;
            this.btnRejectPO.Enabled = false;
            this.btnRejectPO.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRejectPO.Location = new System.Drawing.Point(161, 11);
            this.btnRejectPO.Name = "btnRejectPO";
            this.btnRejectPO.Size = new System.Drawing.Size(118, 41);
            this.btnRejectPO.TabIndex = 170;
            this.btnRejectPO.Text = "Review WO";
            this.btnRejectPO.UseVisualStyleBackColor = false;
            this.btnRejectPO.Click += new System.EventHandler(this.btnRejectPO_Click);
            // 
            // btnAcceptPO
            // 
            this.btnAcceptPO.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnAcceptPO.Enabled = false;
            this.btnAcceptPO.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnAcceptPO.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnAcceptPO.Location = new System.Drawing.Point(18, 12);
            this.btnAcceptPO.Name = "btnAcceptPO";
            this.btnAcceptPO.Size = new System.Drawing.Size(118, 41);
            this.btnAcceptPO.TabIndex = 169;
            this.btnAcceptPO.Text = "Accept WO";
            this.btnAcceptPO.UseVisualStyleBackColor = false;
            this.btnAcceptPO.Click += new System.EventHandler(this.btnAcceptPO_Click);
            // 
            // btnprintwo
            // 
            this.btnprintwo.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnprintwo.Enabled = false;
            this.btnprintwo.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnprintwo.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnprintwo.Location = new System.Drawing.Point(792, 14);
            this.btnprintwo.Name = "btnprintwo";
            this.btnprintwo.Size = new System.Drawing.Size(118, 41);
            this.btnprintwo.TabIndex = 13;
            this.btnprintwo.Text = "Print WO";
            this.btnprintwo.UseVisualStyleBackColor = false;
            this.btnprintwo.Click += new System.EventHandler(this.btnprintwo_Click);
            // 
            // btnWOGenerate
            // 
            this.btnWOGenerate.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnWOGenerate.Enabled = false;
            this.btnWOGenerate.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnWOGenerate.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnWOGenerate.Location = new System.Drawing.Point(608, 14);
            this.btnWOGenerate.Name = "btnWOGenerate";
            this.btnWOGenerate.Size = new System.Drawing.Size(118, 41);
            this.btnWOGenerate.TabIndex = 11;
            this.btnWOGenerate.Text = "WO Generate";
            this.btnWOGenerate.UseVisualStyleBackColor = false;
            this.btnWOGenerate.Click += new System.EventHandler(this.btnWOGenerate_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnExit.Location = new System.Drawing.Point(1129, 13);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(118, 41);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.Enabled = false;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnSave.Location = new System.Drawing.Point(433, 13);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(118, 41);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClearAll
            // 
            this.btnClearAll.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnClearAll.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnClearAll.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnClearAll.Location = new System.Drawing.Point(961, 13);
            this.btnClearAll.Name = "btnClearAll";
            this.btnClearAll.Size = new System.Drawing.Size(118, 41);
            this.btnClearAll.TabIndex = 7;
            this.btnClearAll.Text = "Clear All";
            this.btnClearAll.UseVisualStyleBackColor = false;
            this.btnClearAll.Click += new System.EventHandler(this.btnClearAll_Click);
            // 
            // pnWoNo
            // 
            this.pnWoNo.Controls.Add(this.cmbWONo);
            this.pnWoNo.Controls.Add(this.lblWONo);
            this.pnWoNo.Location = new System.Drawing.Point(562, 7);
            this.pnWoNo.Name = "pnWoNo";
            this.pnWoNo.Size = new System.Drawing.Size(297, 28);
            this.pnWoNo.TabIndex = 162;
            this.pnWoNo.Visible = false;
            // 
            // pnloadwolist
            // 
            this.pnloadwolist.Controls.Add(this.chkWoNumber);
            this.pnloadwolist.Controls.Add(this.chkprintwo);
            this.pnloadwolist.Controls.Add(this.lbldgrefno);
            this.pnloadwolist.Controls.Add(this.txtDGReferenceno);
            this.pnloadwolist.Location = new System.Drawing.Point(852, 173);
            this.pnloadwolist.Name = "pnloadwolist";
            this.pnloadwolist.Size = new System.Drawing.Size(440, 28);
            this.pnloadwolist.TabIndex = 163;
            this.pnloadwolist.Visible = false;
            // 
            // chkWoNumber
            // 
            this.chkWoNumber.AutoSize = true;
            this.chkWoNumber.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkWoNumber.ForeColor = System.Drawing.Color.Black;
            this.chkWoNumber.Location = new System.Drawing.Point(253, 3);
            this.chkWoNumber.Name = "chkWoNumber";
            this.chkWoNumber.Size = new System.Drawing.Size(85, 23);
            this.chkWoNumber.TabIndex = 160;
            this.chkWoNumber.Text = "Edit WO";
            this.chkWoNumber.UseVisualStyleBackColor = false;
            this.chkWoNumber.CheckedChanged += new System.EventHandler(this.chkWoNumber_CheckedChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(4, 559);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(105, 26);
            this.label8.TabIndex = 167;
            this.label8.Text = "Welcome :";
            // 
            // lblWoby
            // 
            this.lblWoby.AutoSize = true;
            this.lblWoby.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWoby.ForeColor = System.Drawing.Color.Black;
            this.lblWoby.Location = new System.Drawing.Point(109, 559);
            this.lblWoby.Name = "lblWoby";
            this.lblWoby.Size = new System.Drawing.Size(23, 26);
            this.lblWoby.TabIndex = 166;
            this.lblWoby.Text = "p";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(328, 598);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(107, 18);
            this.label15.TabIndex = 194;
            this.label15.Text = "Delivery Terms :";
            // 
            // cmbDeliverTerms
            // 
            this.cmbDeliverTerms.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbDeliverTerms.DropDownHeight = 130;
            this.cmbDeliverTerms.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDeliverTerms.FormattingEnabled = true;
            this.cmbDeliverTerms.IntegralHeight = false;
            this.cmbDeliverTerms.Location = new System.Drawing.Point(438, 595);
            this.cmbDeliverTerms.Name = "cmbDeliverTerms";
            this.cmbDeliverTerms.Size = new System.Drawing.Size(318, 26);
            this.cmbDeliverTerms.TabIndex = 195;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(324, 569);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(110, 18);
            this.label16.TabIndex = 192;
            this.label16.Text = "Payment Terms :";
            // 
            // cmbPaymentTerms
            // 
            this.cmbPaymentTerms.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbPaymentTerms.DropDownHeight = 130;
            this.cmbPaymentTerms.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPaymentTerms.FormattingEnabled = true;
            this.cmbPaymentTerms.IntegralHeight = false;
            this.cmbPaymentTerms.Location = new System.Drawing.Point(438, 566);
            this.cmbPaymentTerms.Name = "cmbPaymentTerms";
            this.cmbPaymentTerms.Size = new System.Drawing.Size(318, 26);
            this.cmbPaymentTerms.TabIndex = 193;
            // 
            // dgPackingTaxes
            // 
            this.dgPackingTaxes.AllowUserToAddRows = false;
            this.dgPackingTaxes.AllowUserToDeleteRows = false;
            this.dgPackingTaxes.AllowUserToResizeRows = false;
            this.dgPackingTaxes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgPackingTaxes.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgPackingTaxes.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgPackingTaxes.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.dgPackingTaxes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgPackingTaxes.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TaxDesc,
            this.taxamount,
            this.taxIGSTRate,
            this.taxIGSTAmount,
            this.taxSGSTRate,
            this.taxSGSTAmount,
            this.taxCGSTRate,
            this.taxCGSTAmount});
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle26.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle26.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgPackingTaxes.DefaultCellStyle = dataGridViewCellStyle26;
            this.dgPackingTaxes.EnableHeadersVisualStyles = false;
            this.dgPackingTaxes.Location = new System.Drawing.Point(178, 326);
            this.dgPackingTaxes.MultiSelect = false;
            this.dgPackingTaxes.Name = "dgPackingTaxes";
            this.dgPackingTaxes.RowHeadersVisible = false;
            this.dgPackingTaxes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgPackingTaxes.Size = new System.Drawing.Size(975, 152);
            this.dgPackingTaxes.TabIndex = 196;
            this.dgPackingTaxes.Visible = false;
            this.dgPackingTaxes.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.dgPackingTaxes_CellBeginEdit);
            this.dgPackingTaxes.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgPackingTaxes_CellEndEdit);
            this.dgPackingTaxes.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgPackingTaxes_EditingControlShowing);
            this.dgPackingTaxes.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgPackingTaxes_KeyUp);
            // 
            // TaxDesc
            // 
            this.TaxDesc.DataPropertyName = "TaxDescription";
            this.TaxDesc.HeaderText = "Tax Name";
            this.TaxDesc.Name = "TaxDesc";
            this.TaxDesc.ReadOnly = true;
            this.TaxDesc.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxamount
            // 
            this.taxamount.DataPropertyName = "Amount";
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.taxamount.DefaultCellStyle = dataGridViewCellStyle19;
            this.taxamount.HeaderText = "Amount";
            this.taxamount.Name = "taxamount";
            this.taxamount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxIGSTRate
            // 
            this.taxIGSTRate.DataPropertyName = "IGSTRate";
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.taxIGSTRate.DefaultCellStyle = dataGridViewCellStyle20;
            this.taxIGSTRate.HeaderText = "IGST Rate";
            this.taxIGSTRate.Name = "taxIGSTRate";
            this.taxIGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxIGSTAmount
            // 
            this.taxIGSTAmount.DataPropertyName = "IGSTAmount";
            dataGridViewCellStyle21.Format = "N2";
            this.taxIGSTAmount.DefaultCellStyle = dataGridViewCellStyle21;
            this.taxIGSTAmount.HeaderText = "IGST Amount";
            this.taxIGSTAmount.Name = "taxIGSTAmount";
            this.taxIGSTAmount.ReadOnly = true;
            this.taxIGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxSGSTRate
            // 
            this.taxSGSTRate.DataPropertyName = "SGSTRate";
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.taxSGSTRate.DefaultCellStyle = dataGridViewCellStyle22;
            this.taxSGSTRate.HeaderText = "SGST Rate";
            this.taxSGSTRate.Name = "taxSGSTRate";
            this.taxSGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxSGSTAmount
            // 
            this.taxSGSTAmount.DataPropertyName = "SGSTAmount";
            dataGridViewCellStyle23.Format = "N2";
            this.taxSGSTAmount.DefaultCellStyle = dataGridViewCellStyle23;
            this.taxSGSTAmount.HeaderText = "SGST Amount";
            this.taxSGSTAmount.Name = "taxSGSTAmount";
            this.taxSGSTAmount.ReadOnly = true;
            this.taxSGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxCGSTRate
            // 
            this.taxCGSTRate.DataPropertyName = "CGSTRate";
            dataGridViewCellStyle24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.taxCGSTRate.DefaultCellStyle = dataGridViewCellStyle24;
            this.taxCGSTRate.HeaderText = "CGST Rate";
            this.taxCGSTRate.Name = "taxCGSTRate";
            this.taxCGSTRate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // taxCGSTAmount
            // 
            this.taxCGSTAmount.DataPropertyName = "CGSTAmount";
            dataGridViewCellStyle25.Format = "N2";
            this.taxCGSTAmount.DefaultCellStyle = dataGridViewCellStyle25;
            this.taxCGSTAmount.HeaderText = "CGST Amount";
            this.taxCGSTAmount.Name = "taxCGSTAmount";
            this.taxCGSTAmount.ReadOnly = true;
            this.taxCGSTAmount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // btnViewTax
            // 
            this.btnViewTax.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnViewTax.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewTax.ForeColor = System.Drawing.Color.Black;
            this.btnViewTax.Location = new System.Drawing.Point(964, 594);
            this.btnViewTax.Name = "btnViewTax";
            this.btnViewTax.Size = new System.Drawing.Size(101, 24);
            this.btnViewTax.TabIndex = 199;
            this.btnViewTax.Text = "View Tax";
            this.btnViewTax.UseVisualStyleBackColor = false;
            this.btnViewTax.Click += new System.EventHandler(this.btnViewTax_Click);
            // 
            // btnAddTransport
            // 
            this.btnAddTransport.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddTransport.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddTransport.ForeColor = System.Drawing.Color.Black;
            this.btnAddTransport.Location = new System.Drawing.Point(772, 593);
            this.btnAddTransport.Name = "btnAddTransport";
            this.btnAddTransport.Size = new System.Drawing.Size(180, 24);
            this.btnAddTransport.TabIndex = 198;
            this.btnAddTransport.Text = "Add Tranportation/Freight";
            this.btnAddTransport.UseVisualStyleBackColor = false;
            this.btnAddTransport.Click += new System.EventHandler(this.btnAddTransport_Click);
            // 
            // btnPackingAmount
            // 
            this.btnPackingAmount.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnPackingAmount.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPackingAmount.ForeColor = System.Drawing.Color.Black;
            this.btnPackingAmount.Location = new System.Drawing.Point(772, 567);
            this.btnPackingAmount.Name = "btnPackingAmount";
            this.btnPackingAmount.Size = new System.Drawing.Size(180, 25);
            this.btnPackingAmount.TabIndex = 197;
            this.btnPackingAmount.Text = "Add Packing Forwarding";
            this.btnPackingAmount.UseVisualStyleBackColor = false;
            this.btnPackingAmount.Click += new System.EventHandler(this.btnPackingAmount_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lbltotalIGST);
            this.panel1.Controls.Add(this.label25);
            this.panel1.Controls.Add(this.lbltotalCGST);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.lbltotalSGST);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.lblTotalAmount);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Location = new System.Drawing.Point(4, 518);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1293, 36);
            this.panel1.TabIndex = 200;
            // 
            // lbltotalIGST
            // 
            this.lbltotalIGST.AutoSize = true;
            this.lbltotalIGST.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotalIGST.ForeColor = System.Drawing.Color.Black;
            this.lbltotalIGST.Location = new System.Drawing.Point(1145, 1);
            this.lbltotalIGST.Name = "lbltotalIGST";
            this.lbltotalIGST.Size = new System.Drawing.Size(23, 26);
            this.lbltotalIGST.TabIndex = 128;
            this.lbltotalIGST.Text = "0";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(1059, 4);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(91, 23);
            this.label25.TabIndex = 127;
            this.label25.Text = "Total IGST:";
            // 
            // lbltotalCGST
            // 
            this.lbltotalCGST.AutoSize = true;
            this.lbltotalCGST.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotalCGST.ForeColor = System.Drawing.Color.Black;
            this.lbltotalCGST.Location = new System.Drawing.Point(907, 4);
            this.lbltotalCGST.Name = "lbltotalCGST";
            this.lbltotalCGST.Size = new System.Drawing.Size(23, 26);
            this.lbltotalCGST.TabIndex = 126;
            this.lbltotalCGST.Text = "0";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(815, 6);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(96, 23);
            this.label21.TabIndex = 125;
            this.label21.Text = "Total CGST:";
            // 
            // lbltotalSGST
            // 
            this.lbltotalSGST.AutoSize = true;
            this.lbltotalSGST.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotalSGST.ForeColor = System.Drawing.Color.Black;
            this.lbltotalSGST.Location = new System.Drawing.Point(687, 3);
            this.lbltotalSGST.Name = "lbltotalSGST";
            this.lbltotalSGST.Size = new System.Drawing.Size(23, 26);
            this.lbltotalSGST.TabIndex = 124;
            this.lbltotalSGST.Text = "0";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Black;
            this.label23.Location = new System.Drawing.Point(591, 6);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(100, 23);
            this.label23.TabIndex = 123;
            this.label23.Text = "Total SGST :";
            // 
            // lblTotalAmount
            // 
            this.lblTotalAmount.AutoSize = true;
            this.lblTotalAmount.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalAmount.ForeColor = System.Drawing.Color.Black;
            this.lblTotalAmount.Location = new System.Drawing.Point(132, 3);
            this.lblTotalAmount.Name = "lblTotalAmount";
            this.lblTotalAmount.Size = new System.Drawing.Size(23, 26);
            this.lblTotalAmount.TabIndex = 120;
            this.lblTotalAmount.Text = "0";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(9, 3);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(125, 23);
            this.label19.TabIndex = 119;
            this.label19.Text = "Total Amount :";
            // 
            // pnRemarks
            // 
            this.pnRemarks.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnRemarks.Controls.Add(this.llbViewRemakrs);
            this.pnRemarks.Controls.Add(this.txtRemarks);
            this.pnRemarks.Controls.Add(this.lblRemarks);
            this.pnRemarks.Location = new System.Drawing.Point(5, 501);
            this.pnRemarks.Name = "pnRemarks";
            this.pnRemarks.Size = new System.Drawing.Size(1295, 121);
            this.pnRemarks.TabIndex = 201;
            // 
            // llbViewRemakrs
            // 
            this.llbViewRemakrs.AutoSize = true;
            this.llbViewRemakrs.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbViewRemakrs.Location = new System.Drawing.Point(261, 91);
            this.llbViewRemakrs.Name = "llbViewRemakrs";
            this.llbViewRemakrs.Size = new System.Drawing.Size(178, 19);
            this.llbViewRemakrs.TabIndex = 248;
            this.llbViewRemakrs.TabStop = true;
            this.llbViewRemakrs.Text = "View remarks of all users";
            this.llbViewRemakrs.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbViewRemakrs_LinkClicked);
            // 
            // txtRemarks
            // 
            this.txtRemarks.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRemarks.Location = new System.Drawing.Point(13, 21);
            this.txtRemarks.Multiline = true;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtRemarks.Size = new System.Drawing.Size(242, 92);
            this.txtRemarks.TabIndex = 14;
            // 
            // lblRemarks
            // 
            this.lblRemarks.AutoSize = true;
            this.lblRemarks.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRemarks.ForeColor = System.Drawing.Color.Black;
            this.lblRemarks.Location = new System.Drawing.Point(65, 0);
            this.lblRemarks.Name = "lblRemarks";
            this.lblRemarks.Size = new System.Drawing.Size(105, 19);
            this.lblRemarks.TabIndex = 13;
            this.lblRemarks.Text = "User Remarks:";
            // 
            // btnApproveWO
            // 
            this.btnApproveWO.BackColor = System.Drawing.Color.SpringGreen;
            this.btnApproveWO.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.btnApproveWO.Location = new System.Drawing.Point(874, 7);
            this.btnApproveWO.Name = "btnApproveWO";
            this.btnApproveWO.Size = new System.Drawing.Size(119, 30);
            this.btnApproveWO.TabIndex = 202;
            this.btnApproveWO.Text = "Approve WO";
            this.btnApproveWO.UseVisualStyleBackColor = false;
            this.btnApproveWO.Visible = false;
            this.btnApproveWO.Click += new System.EventHandler(this.btnApproveWO_Click);
            // 
            // cmbWorkDescription
            // 
            this.cmbWorkDescription.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbWorkDescription.DropDownHeight = 130;
            this.cmbWorkDescription.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbWorkDescription.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbWorkDescription.FormattingEnabled = true;
            this.cmbWorkDescription.IntegralHeight = false;
            this.cmbWorkDescription.Location = new System.Drawing.Point(630, 326);
            this.cmbWorkDescription.Name = "cmbWorkDescription";
            this.cmbWorkDescription.Size = new System.Drawing.Size(244, 26);
            this.cmbWorkDescription.TabIndex = 171;
            this.cmbWorkDescription.Visible = false;
            this.cmbWorkDescription.SelectedIndexChanged += new System.EventHandler(this.cmbWorkDescription_SelectedIndexChanged);
            // 
            // btnrepeatorder
            // 
            this.btnrepeatorder.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnrepeatorder.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrepeatorder.ForeColor = System.Drawing.Color.Black;
            this.btnrepeatorder.Location = new System.Drawing.Point(179, 588);
            this.btnrepeatorder.Name = "btnrepeatorder";
            this.btnrepeatorder.Size = new System.Drawing.Size(138, 34);
            this.btnrepeatorder.TabIndex = 174;
            this.btnrepeatorder.Text = "Repeat Order";
            this.btnrepeatorder.UseVisualStyleBackColor = false;
            this.btnrepeatorder.Click += new System.EventHandler(this.btnrepeatorder_Click);
            // 
            // btnloadpolist
            // 
            this.btnloadpolist.BackColor = System.Drawing.Color.SpringGreen;
            this.btnloadpolist.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnloadpolist.Location = new System.Drawing.Point(1014, 4);
            this.btnloadpolist.Name = "btnloadpolist";
            this.btnloadpolist.Size = new System.Drawing.Size(103, 29);
            this.btnloadpolist.TabIndex = 203;
            this.btnloadpolist.Text = "Load WO List";
            this.btnloadpolist.UseVisualStyleBackColor = false;
            this.btnloadpolist.Visible = false;
            this.btnloadpolist.Click += new System.EventHandler(this.btnloadpolist_Click);
            // 
            // dgvRemarks
            // 
            this.dgvRemarks.AllowUserToAddRows = false;
            this.dgvRemarks.AllowUserToOrderColumns = true;
            this.dgvRemarks.AllowUserToResizeRows = false;
            this.dgvRemarks.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvRemarks.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvRemarks.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvRemarks.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle27.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRemarks.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle27;
            this.dgvRemarks.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRemarks.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.RemarksBy,
            this.RemarksDate,
            this.Remarks});
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle28.BackColor = System.Drawing.Color.LavenderBlush;
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle28.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRemarks.DefaultCellStyle = dataGridViewCellStyle28;
            this.dgvRemarks.Location = new System.Drawing.Point(463, 246);
            this.dgvRemarks.Name = "dgvRemarks";
            this.dgvRemarks.RowHeadersVisible = false;
            this.dgvRemarks.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvRemarks.Size = new System.Drawing.Size(781, 366);
            this.dgvRemarks.TabIndex = 249;
            this.dgvRemarks.Visible = false;
            // 
            // RemarksBy
            // 
            this.RemarksBy.DataPropertyName = "Preparedby";
            this.RemarksBy.HeaderText = "Remarks By";
            this.RemarksBy.Name = "RemarksBy";
            this.RemarksBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RemarksBy.Width = 94;
            // 
            // RemarksDate
            // 
            this.RemarksDate.DataPropertyName = "WOPreparedDate";
            this.RemarksDate.HeaderText = "Date";
            this.RemarksDate.Name = "RemarksDate";
            this.RemarksDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RemarksDate.Width = 47;
            // 
            // Remarks
            // 
            this.Remarks.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Remarks.DataPropertyName = "UserRemarks";
            this.Remarks.HeaderText = "Remarks";
            this.Remarks.Name = "Remarks";
            this.Remarks.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // frmJObWork
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1304, 682);
            this.Controls.Add(this.btnloadpolist);
            this.Controls.Add(this.dgvRemarks);
            this.Controls.Add(this.pnRemarks);
            this.Controls.Add(this.btnrepeatorder);
            this.Controls.Add(this.cmbWorkDescription);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnViewTax);
            this.Controls.Add(this.btnAddTransport);
            this.Controls.Add(this.btnPackingAmount);
            this.Controls.Add(this.dgPackingTaxes);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.cmbDeliverTerms);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.cmbPaymentTerms);
            this.Controls.Add(this.pnloadwolist);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lblWoby);
            this.Controls.Add(this.pnWoNo);
            this.Controls.Add(this.gbControlButtons);
            this.Controls.Add(this.dgopitemlist);
            this.Controls.Add(this.pnProject);
            this.Controls.Add(this.btnviewpolist);
            this.Controls.Add(this.txtFinalNetAmount);
            this.Controls.Add(this.lblFinalNetAmount);
            this.Controls.Add(this.btnApproveWO);
            this.Controls.Add(this.pnItemAdd);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmJObWork";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Work Order";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmJObWork_FormClosing);
            this.Load += new System.EventHandler(this.frmJObWork_Load);
            this.pnItemAdd.ResumeLayout(false);
            this.pnItemAdd.PerformLayout();
            this.pnProject.ResumeLayout(false);
            this.pnProject.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgopitemlist)).EndInit();
            this.gbControlButtons.ResumeLayout(false);
            this.pnWoNo.ResumeLayout(false);
            this.pnWoNo.PerformLayout();
            this.pnloadwolist.ResumeLayout(false);
            this.pnloadwolist.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgPackingTaxes)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnRemarks.ResumeLayout(false);
            this.pnRemarks.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRemarks)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnItemAdd;
        private System.Windows.Forms.TextBox txtItemDescription;
        private System.Windows.Forms.CheckedListBox chklbItemList;
        private System.Windows.Forms.Button btnviewpolist;
        private System.Windows.Forms.Panel pnProject;
        private System.Windows.Forms.Label lblFinalNetAmount;
        private System.Windows.Forms.TextBox txtFinalNetAmount;
        private System.Windows.Forms.DataGridView dgopitemlist;
        private System.Windows.Forms.CheckBox chkprintwo;
        private System.Windows.Forms.Label lblProjectCode;
        private System.Windows.Forms.DateTimePicker dtpWODate;
        private System.Windows.Forms.Label lblVendorName;
        private System.Windows.Forms.Label lblProjectName;
        private System.Windows.Forms.Label lblCost;
        private System.Windows.Forms.Label lblPreparedBy;
        private System.Windows.Forms.TextBox txtDGReferenceno;
        private System.Windows.Forms.Label lbldgrefno;
        private System.Windows.Forms.ComboBox cmbVendorName;
        private System.Windows.Forms.Label lblAuthorisedBy;
        private System.Windows.Forms.TextBox txtVendorCode;
        private System.Windows.Forms.Label lblWONo;
        private System.Windows.Forms.ComboBox cmbWONo;
        private System.Windows.Forms.Label lblItemDescription;
        private System.Windows.Forms.GroupBox gbControlButtons;
        private System.Windows.Forms.Button btnprintwo;
        private System.Windows.Forms.Button btnWOGenerate;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClearAll;
        private System.Windows.Forms.CheckBox chkopitem;
        private System.Windows.Forms.CheckBox chkipitems;
        private System.Windows.Forms.Panel pnWoNo;
        private System.Windows.Forms.Panel pnloadwolist;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblWoby;
        private System.Windows.Forms.Label txtProjectName;
        private System.Windows.Forms.Label txtPreparedBy;
        private System.Windows.Forms.Label txtAuthorisedBy;
        private System.Windows.Forms.Label txtCost;
        private System.Windows.Forms.DateTimePicker dtpdelivery;
        private System.Windows.Forms.Label lbldeliverydate;
        private System.Windows.Forms.Label lblProjectStatus;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox cmbDeliverTerms;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox cmbPaymentTerms;
        private System.Windows.Forms.DataGridView dgPackingTaxes;
        private System.Windows.Forms.Button btnViewTax;
        private System.Windows.Forms.Button btnAddTransport;
        private System.Windows.Forms.Button btnPackingAmount;
        private System.Windows.Forms.CheckBox chkWoNumber;
        private System.Windows.Forms.CheckBox chkItemDesc;
        private System.Windows.Forms.CheckBox chkItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn TaxDesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxamount;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxIGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxIGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxSGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxSGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxCGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxCGSTAmount;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbltotalIGST;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label lbltotalCGST;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lbltotalSGST;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label lblTotalAmount;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel pnRemarks;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.Label lblRemarks;
        private System.Windows.Forms.Button btnApproveWO;
        private System.Windows.Forms.Button btnRejectPO;
        private System.Windows.Forms.Button btnAcceptPO;
        private System.Windows.Forms.CheckBox cbViewRemarks;
        private System.Windows.Forms.ComboBox cmbEmailAlert;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ComboBox cmbWorkDescription;
        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbbomname;
        private System.Windows.Forms.Label lblprdname;
        private System.Windows.Forms.Label lblProductName;
        private System.Windows.Forms.Label lblprojectbom;
        private System.Windows.Forms.CheckBox chkWithoutBOM;
        private System.Windows.Forms.TextBox cmbProjectCode;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button btnrepeatorder;
        private System.Windows.Forms.DataGridViewTextBoxColumn IPItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn IPItemDesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn IPHsnSac;
        private System.Windows.Forms.DataGridViewTextBoxColumn IpUnits;
        private System.Windows.Forms.DataGridViewTextBoxColumn IPAvlbQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn BOMQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn IPReqQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn OPItemCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn OPItemDesc;
        private System.Windows.Forms.DataGridViewTextBoxColumn HsnSacCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn WorkDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn OPUnits;
        private System.Windows.Forms.DataGridViewTextBoxColumn OPAvailableQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn OPReqQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn OPUnitCost;
        private System.Windows.Forms.DataGridViewTextBoxColumn OPAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn SGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn SGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn CGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn CGSTAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn IGSTRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn IGSTAmount;
        private System.Windows.Forms.Button btnloadpolist;
        private System.Windows.Forms.LinkLabel llbViewRemakrs;
        private System.Windows.Forms.DataGridView dgvRemarks;
        private System.Windows.Forms.DataGridViewTextBoxColumn RemarksBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn RemarksDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Remarks;
    }
}