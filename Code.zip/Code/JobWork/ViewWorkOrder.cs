﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.JobWork
{
    public partial class ViewWorkOrder : Form
    {
        DataTable dtWolist = new DataTable();
        DataAccessLayer DAL = new DataAccessLayer();
        DataView dvWOViewList = new DataView();
        DataTable dtProjectList = new DataTable();
        Login.frmLoginForm login = new Login.frmLoginForm();
        frmJObWork WorkOrder = new frmJObWork();

        public ViewWorkOrder()
        {
            InitializeComponent();
        }

        private void ViewWorkOrder_Load(object sender, EventArgs e)
        {
            if (Convert.ToBoolean(login.GetUserDetails[16]) == true)
            {
                chkLoad.Enabled = true;
            }
            else
            {
                chkLoad.Enabled = false;
            }

            if (Convert.ToBoolean(login.GetUserDetails[16]) == true || Convert.ToBoolean(login.GetUserDetails[30]) == true || Convert.ToBoolean(login.GetUserDetails[29]) == true || Convert.ToBoolean(login.GetUserDetails[31]) == true || Convert.ToBoolean(login.GetUserDetails[32]) == true)    //  lblPrepareBy.Text.ToLower() == "hebbarrk")
            {

                dgpolist.Columns[16].Visible = true;
                dgpolist.Columns[17].Visible = true;
            }
            else
            {
                dgpolist.Columns[16].Visible = false;
                dgpolist.Columns[17].Visible = false;
            }

            //dtWolist = DAL.fnWOlist(0,null,"","").Tables[0];
            //if (dtWolist.Rows.Count > 0)
            //{
            //    dgpolist.AutoGenerateColumns = false;
            //    dgpolist.DataSource = dtWolist;

            //    dtClone = dtWolist.Copy();
            //    bsIteSearch.DataSource = dtClone;
            //}
        }

        BindingSource bsIteSearch = new BindingSource();
        DataTable dtClone = new DataTable();

        private void fnRowFilter(uint uSearchOption, string sRowFilter)    //filter the Item list depends upon the user inpts
        {
            DataView dvWOViewList = new DataView(dtWolist);
             if (dtWolist.Rows.Count > 0)
            {
                switch (uSearchOption)
                {
                    case Global.uITEM_CODE_SEARCH:
                        {
                            bsIteSearch.Filter = string.Format("OPItemCode  LIKE '%{0}%' or IPItemCode LIKE '%{0}%' or ItemDescription  LIKE '%{0}%' or VendorName  LIKE '%{0}%' or VendorCode  LIKE '%{0}%' or WONumber  LIKE '%{0}%' or  PreparedBy  LIKE '%{0}%' or ProjectCode  LIKE '%{0}%' or ProjectDescription  LIKE '%{0}%'", sRowFilter);
                            break;
                        }
                   
                }
            }
        }

        private void ViewWorkOrder_FormClosing(object sender, FormClosingEventArgs e)
        {
           // WorkOrder.fnAdjustWorkOrder = null;
           this.Hide();
           WorkOrder.Show();
        }

      

        private void txtIPItemCode_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtIPItemCode.Text.Length > 2)
            {
                fnRowFilter(0, txtIPItemCode.Text);
                dgpolist.DataSource = bsIteSearch;
            }
            else
            {
                bsIteSearch.RemoveFilter();
            }
          
        }

        private void dgpolist_DoubleClick(object sender, EventArgs e)
        {
           
        }

    

        private void dgpolist_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (Convert.ToBoolean(login.GetUserDetails[16]) == true && (dgpolist.CurrentRow.Cells["AuthorisedBy"].Value.ToString() != string.Empty && dgpolist.CurrentRow.Cells["AuthorisedBy"].Value.ToString() != null))
            {
               
                WorkOrder.fnAdjustWorkOrder=(dgpolist.CurrentRow.Cells["WONumber"].Value.ToString());
                this.Close();
                WorkOrder.Show();
            }
        }

        private void chkLoad_CheckedChanged(object sender, EventArgs e)
        {
            if (chkLoad.CheckState == CheckState.Checked)
            {
                dtWolist = DAL.fnWOlist(1,"ItemCode","","").Tables[0];

                dgpolist.AutoGenerateColumns = false;
                dgpolist.DataSource = dtWolist;
            }
            else
            {
                dtWolist = DAL.fnWOlist(0,null,"","").Tables[0];

                dgpolist.AutoGenerateColumns = false;
                dgpolist.DataSource = dtWolist;
            }
        }

        private void btnrecentlist_Click(object sender, EventArgs e)
        {
            dtpFromDate.Format = DateTimePickerFormat.Custom;
            dtpFromDate.CustomFormat = "yyyy-MM-dd";
            dtpToDate.Format = DateTimePickerFormat.Custom;
            dtpToDate.CustomFormat = "yyyy-MM-dd";

            dtWolist = DAL.fnWOlist(2, null, dtpFromDate.Text, dtpToDate.Text).Tables[0];

            dgpolist.AutoGenerateColumns = false;
            dgpolist.DataSource = dtWolist;

            if (dtWolist.Rows.Count > 0)
            {
                dgpolist.AutoGenerateColumns = false;
                dgpolist.DataSource = dtWolist;

                dtClone = dtWolist.Copy();
                bsIteSearch.DataSource = dtClone;
            }

            dtpFromDate.Format = DateTimePickerFormat.Custom;
            dtpFromDate.CustomFormat = "dd-MM-yyyy";
            dtpToDate.Format = DateTimePickerFormat.Custom;
            dtpToDate.CustomFormat = "dd-MM-yyyy";
        }

    }
}
