﻿#region WorkOrder Form NameSpaces
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Globalization;
using Outlook = Microsoft.Office.Interop.Outlook;
#endregion
namespace Erp_Project_With_Buttons.JobWork
{
    public partial class frmJObWork : Form
    {
        #region Workorder Form Local Variables and Datatables
        frmForm2 Home = new frmForm2();
        DataAccessLayer DAL = new DataAccessLayer();
        Login.frmLoginForm login = new Login.frmLoginForm();
        Global GlobalClass = new Global();

        DataTable dtWOFilter = new DataTable();
        DataTable dtIPNewItem = new DataTable();
        DataTable dtOPNewItem = new DataTable();
        DataTable dtItemList = new DataTable();
        DataTable dtTableFilter = new DataTable();
        DataTable dtItemType = new DataTable();
        DataTable dtvendorList = new DataTable();
        DataTable dtWIPProjectlist = new DataTable();
        DataTable dtWOWorkDescription = new DataTable();
        DataTable dtPrintWorkOrder = new DataTable();
        DataTable dtVendorAddress = new DataTable();
        DataTable dtMasterList = new DataTable();
        DataTable dtTaxreturn = new DataTable();
        DataTable dtLastJobWorkNo = new DataTable();
        DataTable DTtaxreturn = new DataTable();
        DataTable dtWOrkOrderList = new DataTable();

        DataView dvItemList = new DataView();

        DataGridViewComboBoxCell DGVCBC = new DataGridViewComboBoxCell();

        private List<string> lWorkDescription = new List<string>();

        TextBox txt;
        public int sWOform = 0;
        int OutputRows = 0;
        double totalcost = 0.0;
        double oldvalue;

        private static string sProjectCode;
        private string sPercentSymbol = string.Empty;
        string sDot = ".";
        string taxname = string.Empty;
        string sLastJWNo = string.Empty;
        string sWONUmber = string.Empty;

        bool IPQty = false;
        bool bCheck = false;
        bool bDiscountduty = false;
        bool bexciseduty = false;
        bool bVATDuty = false;
        bool bTaxStatus = false;
        bool bDeliverDate = false;
        public string sWorkrder = "";

        public string fnProjectcode
        {
            get
            {
                return sProjectCode;
            }
            set
            {
                sProjectCode = value;
            }
        }

        public string fnAdjustWorkOrder
        {
            get
            {
                return sWorkrder;
            }
            set
            {
                sWorkrder = value;
            }

        }
        #endregion

        public frmJObWork()
        {
            InitializeComponent();
        }
        #region ItemCode Filter Function
        private void RowFilter()
        {
            chklbItemList.Items.Clear();
            if (chkWithoutBOM.Checked == false)
            {
                foreach (DataRowView dv in dvItemList)
                {
                    chklbItemList.Items.Add(string.Concat(dv["ID"].ToString(), ") ", dv["ItemCode"].ToString(), ", ", dv["ItemDescription"].ToString(), ", ", dv["AvailableQty"].ToString()));
                    // chklbItemList.Items.Add(string.Concat(dv[8].ToString(), ") ", dv[0].ToString(), ", ", dv[1].ToString(), ", ", dv[6].ToString()));
                }
            }
            else
            {
                foreach (DataRowView dv in dvItemList)
                {
                    chklbItemList.Items.Add(string.Concat(dv["ID"].ToString(), ") ", dv["ItemCode"].ToString(), ", ", dv["ItemDescription"].ToString(), ", ", dv["AvailableQty"].ToString()));
                }

            }

        }
        #endregion
        #region Job Work Form Load
        private void frmJObWork_Load(object sender, EventArgs e)
        {
            DataTable dtPaymentTerms = DAL.fnPaymentTermMasterList(null).Tables[0];
            chkItemCode.Checked = true;
            foreach (DataRow dr in dtPaymentTerms.Rows)
            {
                if (!cmbPaymentTerms.Items.Contains(dr["PaymentTerms"].ToString()))
                {
                    cmbPaymentTerms.Items.Add(dr["PaymentTerms"].ToString());
                }
            }

            dtItemList = DAL.fnItemList(null).Tables[0];
            DataTable dtPOApproverList = DAL.fnActiveUserList(2, login.GetUserDetails[2]).Tables[0];
            if (dtPOApproverList.Rows.Count > 0)
            {
                foreach (DataRow DR in dtPOApproverList.Rows)
                {
                    if (!cmbEmailAlert.Items.Contains(DR["POApprover"].ToString()))
                        cmbEmailAlert.Items.Add(DR["POApprover"].ToString());
                }
                cmbEmailAlert.SelectedIndex = 0;
                // cmbEmailAlert.Enabled = false;
            }
            else
            {
                DataTable dtUserName = DAL.fnActiveUserList(0, null).Tables[0];

                foreach (DataRow DR in dtUserName.Rows)
                {
                    if (!cmbEmailAlert.Items.Contains(DR["UserName"].ToString()))
                        cmbEmailAlert.Items.Add(DR["UserName"].ToString());
                }
            }
            DataTable dtDeliveryTerms = DAL.fnDeliveryTermMasterList(null).Tables[0];

            foreach (DataRow dr in dtDeliveryTerms.Rows)
            {
                if (!cmbDeliverTerms.Items.Contains(dr["DeliveryTerms"].ToString()))
                {
                    cmbDeliverTerms.Items.Add(dr["DeliveryTerms"].ToString());
                }
            }

            dtpWODate.Format = DateTimePickerFormat.Custom;
            dtpWODate.CustomFormat = "dd-MM-yyyy";
            dtpdelivery.Format = DateTimePickerFormat.Custom;
            dtpdelivery.CustomFormat = "dd-MM-yyyy";
            dgopitemlist.Columns[1].Width = 200;
            dgopitemlist.Columns[6].Width = 200;


            dtWIPProjectlist = DAL.fnWIPProjectList(null).Tables[0];

            //if (Convert.ToBoolean(login.GetUserDetails[24]) == false)
            //{

            //}
            //else
            //{
            //    dtWIPProjectlist = DAL.fnAllProjectList(null).Tables[0];
            //}
            //foreach (DataRow dr in dtWIPProjectlist.Rows)
            //{
            //    if (!cmbProjectCode.Items.Contains(dr["ProjectCode"].ToString()))
            //    {
            //        cmbProjectCode.Items.Add(dr["ProjectCode"].ToString());
            //    }
            //}

            dtvendorList = DAL.fnVedorNameList(0, null).Tables[0];
            foreach (DataRow dr in dtvendorList.Rows)
            {
                if (!cmbVendorName.Items.Contains(dr["VendorName"].ToString()))
                {
                    cmbVendorName.Items.Add(dr["VendorName"].ToString());
                }
            }
            lblWoby.Text = login.GetUserDetails[2].ToString();
            txtPreparedBy.Text = login.GetUserDetails[2].ToString();

            if (Convert.ToBoolean(login.GetUserDetails[16]) == true || Convert.ToBoolean(login.GetUserDetails[30]) == true || login.GetUserDetails[2].ToLower() == "lizzy" || login.GetUserDetails[2].ToLower() == "veena" || login.GetUserDetails[2].ToLower() == "pavana" || login.GetUserDetails[2].ToLower() == "hemanth reddy" )
            {
                if (!string.IsNullOrEmpty(sWorkrder))
                {
                    cmbWONo.Text = sWorkrder;
                    fnWorkorderNumberChanged(sWorkrder);
                }

                pnItemAdd.Enabled = false;
                pnWoNo.Visible = true;
                lbldeliverydate.Visible = true;
                dtpdelivery.Visible = true;
                cmbWONo.Enabled = true;
                // btnloadpolist.Visible = false;
                //if (Convert.ToBoolean(login.GetUserDetails[30]) == true)
                //{
                //    dtWOFilter = DAL.fnWOFilter(6, "").Tables[0];
                //    btnWOGenerate.Enabled = false;
                //    btnAcceptPO.Enabled = true;
                //    btnRejectPO.Enabled = true;
                //    pnloadwolist.Visible = false;
                //    btnloadpolist.Visible = false;
                //}
                //else

                if (Convert.ToBoolean(login.GetUserDetails[16]) == true && Convert.ToBoolean(login.GetUserDetails[30]) != true && Convert.ToBoolean(login.GetUserDetails[80]) != true || login.GetUserDetails[2].ToLower() == "lizzy" && Convert.ToBoolean(login.GetUserDetails[30]) != true && Convert.ToBoolean(login.GetUserDetails[80]) != true || login.GetUserDetails[2].ToLower() == "veena" || login.GetUserDetails[2].ToLower() == "pavana" || login.GetUserDetails[2].ToLower() == "hemanth reddy" && Convert.ToBoolean(login.GetUserDetails[30]) != true && Convert.ToBoolean(login.GetUserDetails[80]) != true)
                {
                    dtWOFilter = DAL.fnWOFilter(1, "").Tables[0];
                    btnWOGenerate.Enabled = true;
                    pnloadwolist.Visible = true;
                    btnloadpolist.Visible = true;
                }
                if (dtWOFilter.Rows.Count > 0)
                {
                    foreach (DataRow DR in dtWOFilter.Rows)
                    {
                        if (!cmbWONo.Items.Contains(DR["WONumber"].ToString()))
                            cmbWONo.Items.Add(DR["WONumber"].ToString());
                    }
                }
            }
            //else if (login.GetAuthorisedPerson.Count > 0)
            //{
            //    pnItemAdd.Enabled = true;
            //    pnWoNo.Visible = true;
            //    btnSave.Enabled = true;

            //}
            else
            {
                pnItemAdd.Enabled = true;
                btnSave.Enabled = true;
            }

            if (Convert.ToBoolean(login.GetUserDetails[30]) == true || Convert.ToBoolean(login.GetUserDetails[29]) == true || Convert.ToBoolean(login.GetUserDetails[31]) == true || Convert.ToBoolean(login.GetUserDetails[32]) == true || Convert.ToBoolean(login.GetUserDetails[80]) == true || Convert.ToBoolean(login.GetUserDetails[82]) == true || Convert.ToBoolean(login.GetUserDetails[85]) == true)    //  lblPrepareBy.Text.ToLower() == "hebbarrk")
            {
                pnWoNo.Visible = true;
                btnApproveWO.Visible = true;
            }

            if (Convert.ToBoolean(login.GetUserDetails[16]) == true || Convert.ToBoolean(login.GetUserDetails[30]) == true || Convert.ToBoolean(login.GetUserDetails[29]) == true || Convert.ToBoolean(login.GetUserDetails[31]) == true || Convert.ToBoolean(login.GetUserDetails[32]) == true || Convert.ToBoolean(login.GetUserDetails[80]) == true || login.GetUserDetails[2].ToLower() == "lizzy" || login.GetUserDetails[2].ToLower() == "veena" || login.GetUserDetails[2].ToLower() == "pavana" || login.GetUserDetails[2].ToLower() == "hemanth reddy" || Convert.ToBoolean(login.GetUserDetails[85]) == true)    //  lblPrepareBy.Text.ToLower() == "hebbarrk")
            {
                for (int i = 14; i < 22; i++)
                {
                    dgopitemlist.Columns[i].Visible = true;
                }
                btnApproveWO.Visible = true;
            }
            else
            {
                for (int i = 14; i < 22; i++)
                {
                    dgopitemlist.Columns[i].Visible = false;
                }
            }


            dtWOWorkDescription = DAL.fnWorkOrderList().Tables[0];
            if (dtWOWorkDescription.Rows.Count > 0)
            {
                foreach (DataRow DR in dtWOWorkDescription.Rows)
                {
                    if (!string.IsNullOrEmpty(DR["WorkDescription"].ToString()))
                        if (!cmbWorkDescription.Items.Contains(DR["WorkDescription"].ToString()))
                            cmbWorkDescription.Items.Add(DR["WorkDescription"].ToString());
                }
            }
        }
        #endregion

        private void BOMRowFilter()
        {
            chklbItemList.Items.Clear();
            foreach (DataRow dr in dtMachineBOMProduct.Rows)
            {
                chklbItemList.Items.Add(string.Concat(dr["ID"].ToString(), ") ", dr["ItemCode"].ToString(), ", ", dr["ItemDescription"].ToString(), ", ", dr["AvailableQty"].ToString()));
            }
        }
        #region Item Search Functions

        private void txtItemDescription_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
            {
                if (chkItemCode.Checked == true)
                {
                    if (chkWithoutBOM.Checked == false)
                    {
                        if (txtItemDescription.TextLength > 2)
                        {
                            dvItemList = GlobalClass.RowFilter(dtMachineBOMProduct, 0, txtItemDescription.Text);

                            RowFilter();
                        }
                        else
                        {
                            BOMRowFilter();
                        }
                    }
                    else
                    {
                        if (txtItemDescription.TextLength > 2)
                        {
                            dvItemList = GlobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);

                            RowFilter();
                        }
                        else
                        {
                            RowFilter();
                        }
                    }
                }
                else if (chkItemDesc.Checked == true)
                {
                    if (chkWithoutBOM.Checked == false)
                    {
                        if (txtItemDescription.TextLength > 2)
                        {
                            dvItemList = GlobalClass.RowFilter(dtMachineBOMProduct, 1, txtItemDescription.Text);
                            RowFilter();
                        }
                        else
                        {
                            BOMRowFilter();
                        }
                    }
                    else
                    {
                        if (txtItemDescription.TextLength > 2)
                        {
                            dvItemList = GlobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
                            RowFilter();
                        }
                        else
                        {
                            RowFilter();
                        }
                    }
                }

            }
            else
            {
                if (chkItemCode.Checked == true)
                {
                    if (chkWithoutBOM.Checked == false)
                    {
                        if (txtItemDescription.TextLength > 2)
                        {
                            dvItemList = GlobalClass.RowFilter(dtMachineBOMProduct, 0, txtItemDescription.Text);
                            RowFilter();
                        }
                        else
                        {
                            BOMRowFilter();
                        }
                    }
                    else
                    {
                        if (txtItemDescription.TextLength > 2)
                        {
                            dvItemList = GlobalClass.RowFilter(dtItemList, 0, txtItemDescription.Text);
                            RowFilter();
                        }
                        else
                        {
                            RowFilter();
                        }
                    }
                }
                else if (chkItemDesc.Checked == true)
                {
                    if (chkWithoutBOM.Checked == false)
                    {
                        if (txtItemDescription.TextLength > 2)
                        {
                            dvItemList = GlobalClass.RowFilter(dtMachineBOMProduct, 1, txtItemDescription.Text);
                            RowFilter();
                        }
                        else
                        {
                            BOMRowFilter();
                        }
                    }
                    else
                    {
                        if (txtItemDescription.TextLength > 2)
                        {
                            dvItemList = GlobalClass.RowFilter(dtItemList, 1, txtItemDescription.Text);
                            RowFilter();
                        }
                        else
                        {
                            RowFilter();
                        }
                    }
                }

            }
        }
        bool bItemdesc = false;

        #endregion
        #region Item Select Functions
        string[] sItemCode;
        string sID;
        string sItemcodeCheck;
        DataTable dtSelectedItem = new DataTable();
        private void chklbItemList_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            if (bCheck == false)
            {
                //if (chkWithoutBOM.Checked == true)
                //{

                //}
                //else
                //{

                //}

                sItemCode = chklbItemList.SelectedItem.ToString().Trim().Split(')');
                sID = sItemCode[0];
                try
                {

                    if (chkopitem.Checked == false)
                    {
                        int i = 0;
                        DataTable dtIPItem = new DataTable();
                        if (!chklbItemList.CheckedItems.Contains(chklbItemList.SelectedItem))
                        {
                            // dtIPItem = DAL.fnStandardCostItemList(sID).Tables[0];
                            dtIPItem = dtItemList.Select("ID ='" + sID + "'").CopyToDataTable();
                            sItemcodeCheck = dtIPItem.Rows[0][0].ToString();

                            if (Convert.ToBoolean(dtProjectBOMdetails.Rows[0]["BOMProject"].ToString()) == true)
                            {
                                dtSelectedItem = DAL.fnGetIndentMachineBOM(dtprojectBOMItems.Rows[0]["ProjectBOMCode"].ToString(), lblVersion.Text, cmbProjectCode.Text, sItemcodeCheck).Tables[0];//IndentQty
                            }
                            dtIPItem.Clear();
                            foreach (DataGridViewRow DGVR in dgopitemlist.Rows)
                            {
                                if (DGVR.Cells["IPItem"].Value.ToString() != null && DGVR.Cells["IPItem"].Value.ToString() != string.Empty)
                                {
                                    if (DGVR.Cells["IPItem"].Value.ToString().Equals(sItemcodeCheck))
                                    {
                                        i = 1;
                                        this.Focus();
                                        break;
                                    }
                                }
                            }
                            if (i != 1)
                            {
                                DataRow[] d;
                                d = (dtItemList.Select("ID ='" + sID + "'"));
                                DataRow dr = dtIPItem.NewRow();
                                if (d.Length > 0)
                                {
                                    for (int count = 0; count < d[0].ItemArray.Count(); count++)
                                    {
                                        dr[count] = d[0][count];
                                    }
                                    dtIPItem.Rows.Add(dr);
                                }
                                if (dtIPItem.Rows.Count > 0)
                                {
                                    dtIPNewItem = dtIPItem;
                                    dtIPNewItem.Rows.Clear();

                                    if (d.Length > 0)
                                    {
                                        for (int count = 0; count < d[0].ItemArray.Count(); count++)
                                        {
                                            dr[count] = d[0][count];
                                        }
                                        dtIPItem.Rows.Add(dr);
                                    }
                                }
                                dtIPNewItem.ImportRow(dtIPItem.Rows[0]);
                                dtIPNewItem.Rows.RemoveAt(0);

                                int inp = -1;
                                bool nullvalue = false;
                                if (dgopitemlist.Rows.Count == 0)
                                {
                                    dgopitemlist.Rows.Add();
                                    inp = 0;
                                    dgopitemlist.Rows[inp].Cells[0].Value = dtIPNewItem.Rows[0]["ItemCode"].ToString();
                                    dgopitemlist.Rows[inp].Cells[1].Value = dtIPNewItem.Rows[0]["ItemDescription"].ToString();
                                    dgopitemlist.Rows[inp].Cells[2].Value = dtIPNewItem.Rows[0]["HSNSACCode"].ToString();
                                    dgopitemlist.Rows[inp].Cells[3].Value = dtIPNewItem.Rows[0]["Units"].ToString();
                                    dgopitemlist.Rows[inp].Cells[4].Value = dtIPNewItem.Rows[0]["AvailableQty"].ToString();
                                    if (Convert.ToBoolean(dtProjectBOMdetails.Rows[0]["BOMProject"].ToString()) == true)
                                    {
                                        if (dtSelectedItem.Rows.Count > 0)
                                        {
                                            dgopitemlist.Rows[inp].Cells[5].Value = dtSelectedItem.Rows[0]["Quantity"].ToString();
                                            dgopitemlist.Rows[inp].Cells[6].Value = dtSelectedItem.Rows[0]["IndentQty"].ToString();
                                        }
                                        else
                                        {
                                            dgopitemlist.Rows[inp].Cells[5].Value = 0;
                                            dgopitemlist.Rows[inp].Cells[6].Value = 0;
                                        }
                                    }
                                    else
                                    {
                                        dgopitemlist.Rows[inp].Cells[5].Value = 0;
                                        dgopitemlist.Rows[inp].Cells[6].Value = 0;
                                    }

                                    dgopitemlist.Rows[inp].Cells[7].Value = "";
                                    dgopitemlist.Rows[inp].Cells[11].Value = "";
                                    dgopitemlist.Rows[inp].Cells[12].Value = "";
                                    dgopitemlist.Rows[inp].Cells[13].Value = "";
                                    dgopitemlist.Rows[inp].Cells[14].Value = "";
                                    dgopitemlist.Rows[inp].Cells[15].Value = "";
                                    dgopitemlist.Rows[inp].Cells[16].Value = 0;
                                    dgopitemlist.Rows[inp].Cells[17].Value = 0;
                                    dgopitemlist.Rows[inp].Cells[18].Value = 0;
                                    dgopitemlist.Rows[inp].Cells[19].Value = 0;
                                    dgopitemlist.Rows[inp].Cells[20].Value = 0;
                                    dgopitemlist.Rows[inp].Cells[21].Value = 0;
                                }
                                else
                                {
                                    foreach (DataGridViewRow DGVR in dgopitemlist.Rows)
                                    {
                                        inp++;
                                        if (Convert.ToString(DGVR.Cells["IPItem"].Value) == string.Empty || Convert.ToString(DGVR.Cells["IPItem"].Value) == null)
                                        {
                                            nullvalue = true;
                                            break;
                                        }
                                    }
                                    if (nullvalue == true)
                                    {
                                        dgopitemlist.Rows[inp].Cells[0].Value = dtIPNewItem.Rows[0]["ItemCode"].ToString();
                                        dgopitemlist.Rows[inp].Cells[1].Value = dtIPNewItem.Rows[0]["ItemDescription"].ToString();
                                        dgopitemlist.Rows[inp].Cells[2].Value = dtIPNewItem.Rows[0]["HSNSACCode"].ToString();
                                        dgopitemlist.Rows[inp].Cells[3].Value = dtIPNewItem.Rows[0]["Units"].ToString();
                                        dgopitemlist.Rows[inp].Cells[4].Value = dtIPNewItem.Rows[0]["AvailableQty"].ToString();
                                        // dgopitemlist.Rows[inp].Cells[5].Value = "";

                                        if (Convert.ToBoolean(dtProjectBOMdetails.Rows[0]["BOMProject"].ToString()) == true)
                                        {
                                            if (dtSelectedItem.Rows.Count > 0)
                                            {
                                                dgopitemlist.Rows[inp].Cells[5].Value = dtSelectedItem.Rows[0]["Quantity"].ToString();
                                                dgopitemlist.Rows[inp].Cells[6].Value = dtSelectedItem.Rows[0]["IndentQty"].ToString();
                                            }
                                            else
                                            {
                                                dgopitemlist.Rows[inp].Cells[5].Value = 0;
                                                dgopitemlist.Rows[inp].Cells[6].Value = 0;
                                            }
                                        }
                                        else
                                        {
                                            dgopitemlist.Rows[inp].Cells[5].Value = 0;
                                            dgopitemlist.Rows[inp].Cells[6].Value = 0;
                                        }
                                    }
                                    else
                                    {
                                        dgopitemlist.Rows.Add();
                                        inp = dgopitemlist.Rows.Count - 1;
                                        dgopitemlist.Rows[inp].Cells[0].Value = dtIPNewItem.Rows[0]["ItemCode"].ToString();
                                        dgopitemlist.Rows[inp].Cells[1].Value = dtIPNewItem.Rows[0]["ItemDescription"].ToString();
                                        dgopitemlist.Rows[inp].Cells[2].Value = dtIPNewItem.Rows[0]["HSNSACCode"].ToString();
                                        dgopitemlist.Rows[inp].Cells[3].Value = dtIPNewItem.Rows[0]["Units"].ToString();
                                        dgopitemlist.Rows[inp].Cells[4].Value = dtIPNewItem.Rows[0]["AvailableQty"].ToString();

                                        if (Convert.ToBoolean(dtProjectBOMdetails.Rows[0]["BOMProject"].ToString()) == true)
                                        {
                                            if (dtSelectedItem.Rows.Count > 0)
                                            {
                                                dgopitemlist.Rows[inp].Cells[5].Value = dtSelectedItem.Rows[0]["Quantity"].ToString();
                                                dgopitemlist.Rows[inp].Cells[6].Value = dtSelectedItem.Rows[0]["IndentQty"].ToString();
                                            }
                                            else
                                            {
                                                dgopitemlist.Rows[inp].Cells[5].Value = 0;
                                                dgopitemlist.Rows[inp].Cells[6].Value = 0;
                                            }
                                        }
                                        else
                                        {
                                            dgopitemlist.Rows[inp].Cells[5].Value = 0;
                                            dgopitemlist.Rows[inp].Cells[6].Value = 0;
                                        }
                                        //dgopitemlist.Rows[inp].Cells[5].Value = "";
                                        //dgopitemlist.Rows[inp].Cells[6].Value = "";
                                        dgopitemlist.Rows[inp].Cells[7].Value = "";
                                        dgopitemlist.Rows[inp].Cells[11].Value = "";
                                        dgopitemlist.Rows[inp].Cells[12].Value = "";
                                        dgopitemlist.Rows[inp].Cells[13].Value = "";
                                        dgopitemlist.Rows[inp].Cells[14].Value = "";
                                        dgopitemlist.Rows[inp].Cells[15].Value = "";
                                        dgopitemlist.Rows[inp].Cells[16].Value = 0;
                                        dgopitemlist.Rows[inp].Cells[17].Value = 0;
                                        dgopitemlist.Rows[inp].Cells[18].Value = 0;
                                        dgopitemlist.Rows[inp].Cells[19].Value = 0;
                                        dgopitemlist.Rows[inp].Cells[20].Value = 0;
                                        dgopitemlist.Rows[inp].Cells[21].Value = 0;
                                    }
                                }

                                foreach (DataGridViewRow dgr in dgopitemlist.Rows)
                                {
                                    if (Convert.ToDouble(dgr.Cells["IPAvlbQty"].Value) == Convert.ToDouble("0"))
                                    {
                                        dgr.DefaultCellStyle.BackColor = Color.Red;
                                    }
                                }
                            }
                            else
                            {
                                MessageBox.Show("Selected Item already present in the list", "Information", 0, MessageBoxIcon.Information);
                                int k = chklbItemList.SelectedIndex;
                                chklbItemList.SetItemCheckState(k, CheckState.Unchecked);
                            }
                        }
                        else
                        {

                        }
                    }
                    else
                    {
                        int i = 0;

                        DataTable dtOPItem = new DataTable();
                        if (!chklbItemList.CheckedItems.Contains(chklbItemList.SelectedItem))
                        {
                            sItemCode = chklbItemList.SelectedItem.ToString().Trim().Split(')');
                            sID = sItemCode[0];
                            dtOPItem = dtItemList.Select("ID ='" + sID + "'").CopyToDataTable();
                            sItemcodeCheck = dtOPItem.Rows[0][0].ToString();
                            dtOPItem.Clear();

                            if (Convert.ToBoolean(dtProjectBOMdetails.Rows[0]["BOMProject"].ToString()) == true)
                            {
                                dtSelectedItem = DAL.fnGetIndentMachineBOM(dtprojectBOMItems.Rows[0]["ProjectBOMCode"].ToString(), lblVersion.Text, cmbProjectCode.Text, sItemcodeCheck).Tables[0];//IndentQty
                            }

                            foreach (DataGridViewRow DGVR in dgopitemlist.Rows)
                            {
                                if (DGVR.Cells["OPItemCode"].Value.ToString() != null && DGVR.Cells["OPItemCode"].Value.ToString() != string.Empty)
                                {
                                    if (DGVR.Cells["OPItemCode"].Value.ToString().Equals(sItemcodeCheck))
                                    {
                                        i = 1;
                                        this.Focus();
                                        break;
                                    }
                                }
                            }
                            if (i != 1)
                            {
                                DataRow[] d;
                                d = (dtItemList.Select("ID ='" + sID + "'"));
                                DataRow dr = dtOPItem.NewRow();
                                if (d.Length > 0)
                                {
                                    for (int count = 0; count < d[0].ItemArray.Count(); count++)
                                    {
                                        dr[count] = d[0][count];
                                    }
                                    dtOPItem.Rows.Add(dr);
                                }
                                if (dtOPItem.Rows.Count > 0)
                                {
                                    dtOPNewItem = dtOPItem;
                                    dtOPNewItem.Rows.Clear();

                                    if (d.Length > 0)
                                    {
                                        for (int count = 0; count < d[0].ItemArray.Count(); count++)
                                        {
                                            dr[count] = d[0][count];
                                        }
                                        dtOPItem.Rows.Add(dr);
                                    }
                                }
                                dtOPNewItem.ImportRow(dtOPItem.Rows[0]);
                                dtOPNewItem.Rows.RemoveAt(0);
                                OutputRows = -1;
                                bool opnullvalue = false;
                                if (dgopitemlist.Rows.Count == 0)
                                {
                                    OutputRows = 0;
                                    dgopitemlist.Rows.Add();
                                    dgopitemlist.Rows[OutputRows].Cells[0].Value = "";
                                    dgopitemlist.Rows[OutputRows].Cells[1].Value = "";
                                    dgopitemlist.Rows[OutputRows].Cells[5].Value = "";
                                    dgopitemlist.Rows[OutputRows].Cells[6].Value = "";

                                    dgopitemlist.Rows[OutputRows].Cells[7].Value = dtOPNewItem.Rows[0]["ItemCode"].ToString();
                                    dgopitemlist.Rows[OutputRows].Cells[8].Value = dtOPNewItem.Rows[0]["ItemDescription"].ToString();
                                    dgopitemlist.Rows[OutputRows].Cells[9].Value = dtOPNewItem.Rows[0]["HSNSACCode"].ToString();
                                    dgopitemlist.Rows[OutputRows].Cells[11].Value = dtOPNewItem.Rows[0]["Units"].ToString();
                                    dgopitemlist.Rows[OutputRows].Cells[12].Value = dtOPNewItem.Rows[0]["AvailableQty"].ToString();

                                    if (Convert.ToBoolean(dtProjectBOMdetails.Rows[0]["BOMProject"].ToString()) == true)
                                    {

                                        if (dtSelectedItem.Rows.Count > 0)
                                        {
                                            dgopitemlist.Rows[OutputRows].Cells[13].Value = dtSelectedItem.Rows[0]["IndentQty"].ToString();
                                        }
                                        else
                                        {
                                            dgopitemlist.Rows[OutputRows].Cells[13].Value = 0;
                                        }


                                        // dgopitemlist.Rows[OutputRows].Cells[6].Value = dtSelectedItem.Rows[0]["IndentQty"].ToString();
                                    }
                                    else
                                    {
                                        dgopitemlist.Rows[OutputRows].Cells[13].Value = 0;
                                        // dgopitemlist.Rows[OutputRows].Cells[6].Value = 0;
                                    }

                                    dgopitemlist.Rows[OutputRows].Cells[14].Value = dtOPNewItem.Rows[0]["UnitCost"].ToString();
                                    dgopitemlist.Rows[OutputRows].Cells[15].Value = Convert.ToDouble(dgopitemlist.Rows[OutputRows].Cells[13].Value) * Convert.ToDouble(dtOPNewItem.Rows[0]["UnitCost"].ToString());

                                    dgopitemlist.Rows[OutputRows].Cells[16].Value = 0;
                                    dgopitemlist.Rows[OutputRows].Cells[17].Value = 0;
                                    dgopitemlist.Rows[OutputRows].Cells[18].Value = 0;
                                    dgopitemlist.Rows[OutputRows].Cells[19].Value = 0;
                                    dgopitemlist.Rows[OutputRows].Cells[20].Value = 0;
                                    dgopitemlist.Rows[OutputRows].Cells[21].Value = 0;
                                    OutputRows++;
                                }
                                else
                                {
                                    foreach (DataGridViewRow DGVR in dgopitemlist.Rows)
                                    {
                                        OutputRows++;
                                        if (Convert.ToString(DGVR.Cells["OPItemCode"].Value) == string.Empty || Convert.ToString(DGVR.Cells["OPItemCode"].Value) == null)
                                        {
                                            opnullvalue = true;
                                            break;
                                        }
                                    }
                                    if (opnullvalue == true)
                                    {
                                        dgopitemlist.Rows[OutputRows].Cells[7].Value = dtOPNewItem.Rows[0]["ItemCode"].ToString();
                                        dgopitemlist.Rows[OutputRows].Cells[8].Value = dtOPNewItem.Rows[0]["ItemDescription"].ToString();
                                        dgopitemlist.Rows[OutputRows].Cells[9].Value = dtOPNewItem.Rows[0]["HSNSACCode"].ToString();
                                        dgopitemlist.Rows[OutputRows].Cells[11].Value = dtOPNewItem.Rows[0]["Units"].ToString();
                                        dgopitemlist.Rows[OutputRows].Cells[12].Value = dtOPNewItem.Rows[0]["AvailableQty"].ToString();

                                        if (Convert.ToBoolean(dtProjectBOMdetails.Rows[0]["BOMProject"].ToString()) == true)
                                        {
                                            if (dtSelectedItem.Rows.Count > 0)
                                            {
                                                dgopitemlist.Rows[OutputRows].Cells[13].Value = dtSelectedItem.Rows[0]["IndentQty"].ToString();
                                            }
                                            else
                                            {
                                                dgopitemlist.Rows[OutputRows].Cells[13].Value = 0;
                                            }
                                            // dgopitemlist.Rows[OutputRows].Cells[6].Value = dtSelectedItem.Rows[0]["IndentQty"].ToString();
                                        }
                                        else
                                        {
                                            dgopitemlist.Rows[OutputRows].Cells[13].Value = 0;
                                            // dgopitemlist.Rows[OutputRows].Cells[6].Value = 0;
                                        }

                                        // dgopitemlist.Rows[OutputRows].Cells[14].Value = "";
                                        dgopitemlist.Rows[OutputRows].Cells[14].Value = dtOPNewItem.Rows[0]["UnitCost"].ToString();
                                        dgopitemlist.Rows[OutputRows].Cells[15].Value = Convert.ToDouble(dgopitemlist.Rows[OutputRows].Cells[13].Value) * Convert.ToDouble(dtOPNewItem.Rows[0]["UnitCost"].ToString());
                                        dgopitemlist.Rows[OutputRows].Cells[16].Value = 0;
                                        dgopitemlist.Rows[OutputRows].Cells[17].Value = 0;
                                        dgopitemlist.Rows[OutputRows].Cells[18].Value = 0;
                                        dgopitemlist.Rows[OutputRows].Cells[19].Value = 0;
                                        dgopitemlist.Rows[OutputRows].Cells[20].Value = 0;
                                        dgopitemlist.Rows[OutputRows].Cells[21].Value = 0;

                                    }
                                    else
                                    {
                                        dgopitemlist.Rows.Add();
                                        OutputRows = dgopitemlist.Rows.Count - 1;
                                        dgopitemlist.Rows[OutputRows].Cells[0].Value = "";
                                        dgopitemlist.Rows[OutputRows].Cells[1].Value = "";
                                        dgopitemlist.Rows[OutputRows].Cells[5].Value = "";
                                        dgopitemlist.Rows[OutputRows].Cells[7].Value = dtOPNewItem.Rows[0]["ItemCode"].ToString();
                                        dgopitemlist.Rows[OutputRows].Cells[8].Value = dtOPNewItem.Rows[0]["ItemDescription"].ToString();
                                        dgopitemlist.Rows[OutputRows].Cells[9].Value = dtOPNewItem.Rows[0]["HSNSACCode"].ToString();
                                        dgopitemlist.Rows[OutputRows].Cells[11].Value = dtOPNewItem.Rows[0]["Units"].ToString();
                                        dgopitemlist.Rows[OutputRows].Cells[12].Value = dtOPNewItem.Rows[0]["AvailableQty"].ToString();
                                        if (Convert.ToBoolean(dtProjectBOMdetails.Rows[0]["BOMProject"].ToString()) == true)
                                        {
                                            if (dtSelectedItem.Rows.Count > 0)
                                            {
                                                dgopitemlist.Rows[OutputRows].Cells[13].Value = dtSelectedItem.Rows[0]["IndentQty"].ToString();
                                            }
                                            else
                                            {
                                                dgopitemlist.Rows[OutputRows].Cells[13].Value = 0;
                                            }
                                            //dgopitemlist.Rows[OutputRows].Cells[13].Value = dtSelectedItem.Rows[0]["IndentQty"].ToString();
                                            // dgopitemlist.Rows[OutputRows].Cells[6].Value = dtSelectedItem.Rows[0]["IndentQty"].ToString();
                                        }
                                        else
                                        {
                                            dgopitemlist.Rows[OutputRows].Cells[13].Value = 0;
                                            // dgopitemlist.Rows[OutputRows].Cells[6].Value = 0;
                                        }
                                        //dgopitemlist.Rows[OutputRows].Cells[14].Value = "";
                                        dgopitemlist.Rows[OutputRows].Cells[14].Value = dtOPNewItem.Rows[0]["UnitCost"].ToString();
                                        dgopitemlist.Rows[OutputRows].Cells[15].Value = Convert.ToDouble(dgopitemlist.Rows[OutputRows].Cells[13].Value) * Convert.ToDouble(dtOPNewItem.Rows[0]["UnitCost"].ToString());

                                        dgopitemlist.Rows[OutputRows].Cells[16].Value = 0;
                                        dgopitemlist.Rows[OutputRows].Cells[17].Value = 0;
                                        dgopitemlist.Rows[OutputRows].Cells[18].Value = 0;
                                        dgopitemlist.Rows[OutputRows].Cells[19].Value = 0;
                                        dgopitemlist.Rows[OutputRows].Cells[20].Value = 0;
                                        dgopitemlist.Rows[OutputRows].Cells[21].Value = 0;
                                    }
                                }

                                double TotalAmount = 0.0;

                                foreach (DataGridViewRow dgvr in dgopitemlist.Rows)
                                {
                                    if (dgvr.Cells["OPAmount"].Value.ToString() != string.Empty)
                                    {
                                        TotalAmount += Convert.ToDouble(dgvr.Cells["OPAmount"].Value);
                                    }
                                }

                                txtCost.Text = TotalAmount.ToString();

                            }
                            else
                            {
                                MessageBox.Show("Selected Item already present in the list", "Information", 0, MessageBoxIcon.Information);
                                int k = chklbItemList.SelectedIndex;
                                chklbItemList.SetItemCheckState(k, CheckState.Unchecked);
                            }
                        }
                        else
                        {

                        }
                    }

                    if (dgopitemlist.Rows.Count == 1)
                    {
                        cmbbomname.Enabled = false;
                    }

                    foreach (DataGridViewRow DR in dgopitemlist.Rows)
                    {
                        //if (chkWithoutBOM.Checked == true)
                        //{
                        //    DR.Cells["IPReqQty"].ReadOnly = false;
                        //    DR.Cells["IPReqQty"].Style.BackColor = Color.LightGreen;

                        //    DR.Cells["OPReqQty"].ReadOnly = false;
                        //    DR.Cells["OPReqQty"].Style.BackColor = Color.LightGreen;
                        //}
                        //else
                        //{
                        //    DR.Cells["IPReqQty"].ReadOnly = true;
                        //    DR.Cells["IPReqQty"].Style.BackColor = Color.White;

                        //    DR.Cells["OPReqQty"].ReadOnly = true;
                        //    DR.Cells["OPReqQty"].Style.BackColor = Color.White;
                        //}
                    }
                }


                catch (Exception ex)
                {
                    MessageBox.Show("PurchaseOrder_chklbItemList_ItemCheck" + ex.Message);
                }
            }
        }
        #endregion
        #region Input Items Output Items Selection Function
        private void chkipitems_CheckedChanged(object sender, EventArgs e)
        {
            if (chkipitems.CheckState == CheckState.Checked)
            {
                bCheck = true;
                chkopitem.Checked = false;
                foreach (int i in chklbItemList.CheckedIndices)
                {
                    chklbItemList.SetItemCheckState(i, CheckState.Unchecked);
                }
                bCheck = false;
            }
            else
            {
                bCheck = true;
                chkopitem.Checked = true;
                foreach (int i in chklbItemList.CheckedIndices)
                {
                    chklbItemList.SetItemCheckState(i, CheckState.Unchecked);
                }
                bCheck = false;
            }
        }

        private void chkopitem_CheckedChanged(object sender, EventArgs e)
        {
            if (chkopitem.CheckState == CheckState.Checked)
            {
                bCheck = true;
                chkipitems.Checked = false;
                foreach (int i in chklbItemList.CheckedIndices)
                {
                    chklbItemList.SetItemCheckState(i, CheckState.Unchecked);
                }
                bCheck = false;
            }
            else
            {
                chkipitems.Checked = true;
                bCheck = true;
                foreach (int i in chklbItemList.CheckedIndices)
                {
                    chklbItemList.SetItemCheckState(i, CheckState.Unchecked);
                }
                bCheck = false;
            }
        }
        #endregion

        DataTable dtProjectBOMdetails = new DataTable();
        #region Project Select Function
        private void cmbProjectCode_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        #endregion
        #region Vendor Select Function
        private void cmbVendorName_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbVendorName.SelectedIndex == -1)
            {
                cmbVendorName.Text = string.Empty;
            }
            else
            {
                DataView dvVendor = new DataView(dtvendorList);
                dvVendor.RowFilter = "VendorName Like'" + cmbVendorName.Text + "'";
                DataTable dtrow = dvVendor.ToTable();
                txtVendorCode.Text = dtrow.Rows[0]["VendorCode"].ToString();
            }
        }
        #endregion
        #region Work Order Save Function
        private void btnSave_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow dgvr in dgopitemlist.Rows)
            {
                if (dgvr.Cells["IPItem"].Value.ToString() != string.Empty && Convert.ToDouble(dgvr.Cells["IPAvlbQty"].Value.ToString()) == 0.0)
                {
                    IPQty = true;
                    MessageBox.Show("Input Item '" + dgvr.Cells["IPItem"].Value.ToString() + "' availbale quantity is 0", "Error", 0, MessageBoxIcon.Error);
                    break;
                }

                if (dgvr.Cells["IPItem"].Value.ToString() != string.Empty && Convert.ToDouble(dgvr.Cells["IPReqQty"].Value.ToString()) == 0)
                {
                    IPQty = true;
                    MessageBox.Show("Enter required quantity for input Item '" + dgvr.Cells["IPItem"].Value.ToString() + "'", "Error", 0, MessageBoxIcon.Error);
                    break;
                }
                if (dgvr.Cells["OPItemCode"].Value.ToString() != string.Empty && Convert.ToDouble(dgvr.Cells["OPReqQty"].Value.ToString()) == 0)
                {
                    IPQty = true;
                    MessageBox.Show("Enter required quantity for output Item '" + dgvr.Cells["OPItemCode"].Value.ToString() + "'", "Error", 0, MessageBoxIcon.Error);
                    break;
                }

                if (dgvr.Cells["IPItem"].Value.ToString() != string.Empty && Convert.ToDouble(dgvr.Cells["IPReqQty"].Value.ToString()) > Convert.ToDouble(dgvr.Cells["IPAvlbQty"].Value.ToString()))
                {
                    IPQty = true;
                    MessageBox.Show("Input Item '" + dgvr.Cells["IPItem"].Value.ToString() + "' required quantity is more than the available quantity", "Error", 0, MessageBoxIcon.Error);
                    break;
                }
            }
            if (IPQty == false && dgopitemlist.RowCount > 0 && !string.IsNullOrEmpty(cmbProjectCode.Text) && !string.IsNullOrEmpty(cmbVendorName.Text) && !string.IsNullOrEmpty(txtRemarks.Text) && cmbEmailAlert.SelectedIndex >= 0)
            {
                dtLastJobWorkNo = DAL.fnGetNewJobWorkNo().Tables["JobWorkNo"]; //Get last jobwork no from the job master table which is required to insert in WorkOrder table
                if (dtLastJobWorkNo.Rows.Count > 0)
                {
                    sLastJWNo = dtLastJobWorkNo.Rows[0]["JWNumber"].ToString();
                }
                if (!string.IsNullOrEmpty(sLastJWNo))
                {
                    //   sLastJWNo = "JW300000";
                    sLastJWNo = sLastJWNo.Substring(2);
                    sLastJWNo = (Convert.ToInt64(sLastJWNo) + 1).ToString();
                    sLastJWNo = string.Concat("JW", sLastJWNo);
                    sWONUmber = string.Concat("WO/", sLastJWNo, "01");

                    //if (login.GetUserDetails[2] == login.GetUserDetails[14])
                    //{
                    foreach (DataGridViewRow DGVR in dgopitemlist.Rows)
                    {
                        if (DGVR.Cells["WorkDescription"].Value == null)
                        {
                            DGVR.Cells["WorkDescription"].Value = "";
                        }
                        if (DGVR.Cells["IPItem"].Value == null)
                        {
                            DGVR.Cells["IPItem"].Value = "";
                        }

                        if (DGVR.Cells["OPItemCode"].Value == null)
                        {
                            DGVR.Cells["OPItemCode"].Value = "";
                            DGVR.Cells["OPUnitCost"].Value = "";
                            DGVR.Cells["OPAmount"].Value = "";
                        }

                        //if (DGVR.Cells["BOMQty"].Value == "")
                        //{
                        //    DGVR.Cells["BOMQty"].Value = "0";
                        //}
                        if (DGVR.Cells["IPReqQty"].Value == null)
                        {
                            DGVR.Cells["IPReqQty"].Value = "";
                        }
                        if (DGVR.Cells["OPReqQty"].Value == null)
                        {
                            DGVR.Cells["OPReqQty"].Value = "";
                        }

                        GlobalClass.iSuccess = DAL.fnAddJOBWorkOrder(Global.uINSERT, sLastJWNo, sWONUmber, DGVR.Cells["IPItem"].Value.ToString(),
                                                              (DGVR.Cells["IPReqQty"].Value.ToString()), DGVR.Cells["OPItemCode"].Value.ToString(),
                                                              (DGVR.Cells["OPReqQty"].Value.ToString()),
                                                            txtVendorCode.Text, (DGVR.Cells["OPUnitCost"].Value.ToString()), (DGVR.Cells["OPAmount"].Value.ToString()),
                                                            "Open", login.GetUserDetails[2], login.GetUserDetails[2], "Open", DGVR.Cells["WorkDescription"].Value.ToString(),
                                                            cmbProjectCode.Text, lblProjectStatus.Text, lblVersion.Text, DGVR.Cells["BOMQty"].Value.ToString(), dtpWODate.Text, txtRemarks.Text,dtpdelivery.Text);
                    }

                    if (GlobalClass.iSuccess > 0)
                    {

                        //shreeshail is added bellow code
                        DataTable dtPMnameandHmname = DAL.fuHeadandmanager(login.GetUserDetails[2]).Tables[0];
                        if (dtPMnameandHmname.Rows[0]["Department"].ToString() != "Testlab")
                        {
                            
                            GlobalClass.iSuccess = DAL.WorkOrderApproval(7, sWONUmber, login.GetUserDetails[2], dtpWODate.Text, txtRemarks.Text);
                        }

                        
                        cmbWONo.Text = sWONUmber;
                        GlobalClass.iSuccess = DAL.fnAddERPLog(0, sWONUmber, login.GetUserDetails[2], dtpWODate.Text, "Work Order Created", "WorkOrder");
                       //---bhavya    fnAlertMail(cmbEmailAlert.Text, txtRemarks.Text);
                        MessageBox.Show("Work Order '" + sWONUmber + "' generated successfully", "Success", 0, MessageBoxIcon.Information);

                        JobWork.frmJObWork JobWork = new frmJObWork();
                        this.Hide();
                        JobWork.Show();
                    }
                    //}
                    //else
                    //{
                    //    foreach (DataGridViewRow DGVR in dgopitemlist.Rows)
                    //    {
                    //        if (DGVR.Cells["WorkDescription"].Value == null)
                    //        {
                    //            DGVR.Cells["WorkDescription"].Value = "";
                    //        }
                    //        if (DGVR.Cells["IPItem"].Value == null)
                    //        {
                    //            DGVR.Cells["IPItem"].Value = "";
                    //        }
                    //        if (DGVR.Cells["OPItemCode"].Value == null)
                    //        {
                    //            DGVR.Cells["OPItemCode"].Value = "";
                    //            DGVR.Cells["OPUnitCost"].Value = "";
                    //            DGVR.Cells["OPAmount"].Value = "";
                    //        }
                    //        if (DGVR.Cells["IPReqQty"].Value == null)
                    //        {
                    //            DGVR.Cells["IPReqQty"].Value = "";
                    //        }
                    //        if (DGVR.Cells["OPReqQty"].Value == null)
                    //        {
                    //            DGVR.Cells["OPReqQty"].Value = "";
                    //        }
                    //        //if (DGVR.Cells["BOMQty"].Value == "")
                    //        //{
                    //        //    DGVR.Cells["BOMQty"].Value = "0";
                    //        //}
                    //        GlobalClass.iSuccess = DAL.fnAddJOBWorkOrder(Global.uINSERT, sLastJWNo, sWONUmber, DGVR.Cells["IPItem"].Value.ToString(),
                    //                                              (DGVR.Cells["IPReqQty"].Value.ToString()), DGVR.Cells["OPItemCode"].Value.ToString(),
                    //                                             (DGVR.Cells["OPReqQty"].Value.ToString()),
                    //                                            txtVendorCode.Text, (DGVR.Cells["OPUnitCost"].Value.ToString()), (DGVR.Cells["OPAmount"].Value.ToString()),
                    //                                            "Open", login.GetUserDetails[2], null, "Open", DGVR.Cells["WorkDescription"].Value.ToString(),
                    //                                            cmbProjectCode.Text, lblProjectStatus.Text, lblVersion.Text, DGVR.Cells["BOMQty"].Value.ToString());
                    //    }

                    //    if (GlobalClass.iSuccess > 0)
                    //    {
                    //        GlobalClass.iSuccess = DAL.WorkOrderApproval(7, sWONUmber, login.GetUserDetails[2], dtpWODate.Text, txtRemarks.Text);
                    //        cmbWONo.Text = sWONUmber;
                    //        fnAlertMail(cmbEmailAlert.Text, txtRemarks.Text);

                    //        MessageBox.Show("Work Order '" + sWONUmber + "' generated successfully", "Success", 0, MessageBoxIcon.Information);
                    //        JobWork.frmJObWork JobWork = new frmJObWork();
                    //        this.Hide();
                    //        JobWork.Show();
                    //    }
                    //}

                }
            }
            else
            {
                if (IPQty == false)
                {
                    if (string.IsNullOrEmpty(cmbProjectCode.Text))
                    {
                        MessageBox.Show("Project code is not selected", "Error", 0, MessageBoxIcon.Error);
                        cmbProjectCode.Focus();
                    }
                    else if (string.IsNullOrEmpty(cmbVendorName.Text))
                    {
                        MessageBox.Show("Vendor name is not selected", "Error", 0, MessageBoxIcon.Error);
                        cmbVendorName.Focus();
                    }
                    else if (string.IsNullOrEmpty(txtRemarks.Text))
                    {
                        MessageBox.Show("Please write remarks. ", "Error", 0, MessageBoxIcon.Error);
                        txtRemarks.Focus();
                    }
                    else if (cmbEmailAlert.SelectedIndex < 0)
                    {
                        MessageBox.Show("Please select email alert sender name", "Error", 0, MessageBoxIcon.Error);
                        cmbEmailAlert.Focus();
                    }
                    else if (dtpdelivery.Value.Date == DateTime.Today)
                    {
                        // The selected date is today
                        
                        MessageBox.Show("The selected date is today.", "Error", 0, MessageBoxIcon.Error);
                        dtpdelivery.Focus();
                    }
                }
                //   MessageBox.Show("Please select Project or Vendor or Write Remarks to generate work order", "Error", 0, MessageBoxIcon.Error);
                IPQty = false;
            }
        }

        public void fnAlertMail(string sUser, string sRemarks)
        {
            try
            {
                bMail = false;
                DataTable dtlogindetails = DAL.fnloginemail(sUser).Tables[0]; ;
                if (dtlogindetails.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
                    {
                        Outlook.Application oApp = new Outlook.Application();
                        Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                        oMsg.Subject = "" + cmbWONo.Text + " sent for approval";
                        oMsg.HTMLBody = " Dear " + sUser.ToUpper() + ", <br /><br /> Work Order <font color='blue'>" + cmbWONo.Text + "</font> sent for approval.<br /> <br /><b> <font color='red'>" + sBOMMessage + "</font></b><br /> <br /> Remarks : " + sRemarks + " <br /> <br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";
                        // Add a recipient.
                        Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                        oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                        oRecips.ResolveAll();
                        // Send.
                        oMsg.Send();
                        bMail = true;
                        // Clean up.
                        oRecips = null;
                        oMsg = null;
                        oApp = null;
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }


        public void fnAlertMailWoGenrate(string sUser, string sRemarks)
        {
            try
            {
                bMail = false;
                DataTable dtlogindetails = DAL.fnloginemail(sUser).Tables[0]; ;
                if (dtlogindetails.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
                    {
                        Outlook.Application oApp = new Outlook.Application();
                        Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                        oMsg.Subject = "" + cmbWONo.Text + " sent for Generating Work Order";
                        oMsg.HTMLBody = " Dear " + sUser.ToUpper() + ", <br /><br /> Work Order <font color='blue'>" + cmbWONo.Text + "</font>sent for Generating the Work Order.<br /> <br /><b> <font color='red'>" + sBOMMessage + "</font></b><br /> <br /> Remarks : " + sRemarks + " <br /> <br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";
                        // Add a recipient.
                        Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                        oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                        oRecips.ResolveAll();
                        // Send.
                        oMsg.Send();
                        bMail = true;
                        // Clean up.
                        oRecips = null;
                        oMsg = null;
                        oApp = null;
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }
        #endregion

        #region Genarate Work Order Function
        private void btnWOGenerate_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(cmbWONo.Text) && !string.IsNullOrEmpty(cmbProjectCode.Text) && !string.IsNullOrEmpty(cmbVendorName.Text) && !string.IsNullOrEmpty(txtDGReferenceno.Text) && bDeliverDate == true && !string.IsNullOrEmpty(txtRemarks.Text))
            {
                foreach (DataGridViewRow DGVR in dgopitemlist.Rows)
                {
                    if (DGVR.Cells["WorkDescription"].Value == null)
                    {
                        DGVR.Cells["WorkDescription"].Value = "";
                    }
                    if (DGVR.Cells["IPItem"].Value == null)
                    {
                        DGVR.Cells["IPItem"].Value = "";
                        DGVR.Cells["IPReqQty"].Value = "";
                    }
                    if (DGVR.Cells["OPItemCode"].Value == null)
                    {
                        DGVR.Cells["OPItemCode"].Value = "";
                        DGVR.Cells["OPUnitCost"].Value = "";
                        DGVR.Cells["OPAmount"].Value = "";
                    }
                    if (string.IsNullOrEmpty(sWorkrder))
                    {
                        GlobalClass.iSuccess = DAL.fnGenarateWorkOrder(Global.uUPDATE, cmbWONo.Text, DGVR.Cells["IPItem"].Value.ToString(), DGVR.Cells["IPReqQty"].Value.ToString(),
                                                                        null, null, null, null, null, null, null, txtDGReferenceno.Text, null, null, 0, 0, 0, 0, 0, 0, 0, null, null);
                    }
                    GlobalClass.iSuccess = DAL.fnGenarateWorkOrder(Global.uINSERT, cmbWONo.Text, DGVR.Cells["OPItemCode"].Value.ToString(), DGVR.Cells["OPReqQty"].Value.ToString(), txtVendorCode.Text,
                                                                     DGVR.Cells["OPUnitCost"].Value.ToString(), DGVR.Cells["OPAmount"].Value.ToString(), login.GetUserDetails[2].ToString(), dtpWODate.Text,
                                                                     DGVR.Cells["WorkDescription"].Value.ToString(), cmbProjectCode.Text, txtDGReferenceno.Text, dtpdelivery.Text, lblProjectStatus.Text, Convert.ToDouble(DGVR.Cells["IGSTRate"].Value),
                                                                     Convert.ToDouble(DGVR.Cells["IGSTAmount"].Value), Convert.ToDouble(DGVR.Cells["SGSTRate"].Value), Convert.ToDouble(DGVR.Cells["SGSTAmount"].Value), Convert.ToDouble(DGVR.Cells["CGSTRate"].Value),
                                                                     Convert.ToDouble(DGVR.Cells["CGSTAmount"].Value), Convert.ToDouble(txtFinalNetAmount.Text), cmbPaymentTerms.Text, cmbDeliverTerms.Text);




                }
                sWorkrder = "";
                if (GlobalClass.iSuccess > 0)
                {
                    GlobalClass.iSuccess = DAL.fnGenarateWorkOrder(44, cmbWONo.Text, "", "",
                                                                       null, null, null, null, null, null, null, txtDGReferenceno.Text, null, null, 0, 0, 0, 0, 0, 0, 0, null, null);

                    dtTaxreturn = DAL.TaxRetturn(cmbWONo.Text).Tables[0];


                    if (dtTaxreturn.Rows.Count > 0)
                    {
                        //       GlobalClass.iSuccess = DAL.fnAddWOOtherCost(Global.uUPDATE, null, cmbWONo.Text, Convert.ToDouble(txtdiscountEnter.Text), Convert.ToDouble(txtExciseDutyEnter.Text), Convert.ToDouble(txtCSTEnter.Text), Convert.ToDouble(txtVatServiceTaxEnter.Text), Convert.ToDouble(txtPackingAndForwording.Text), Convert.ToDouble(txtOthersEnter.Text), txtPaymentCode.Text, txtDeliveryCode.Text, totalcost, Convert.ToDouble(txtFinalNetAmount.Text), txtDiscountFromTable.Text, txtExciseDutyTable.Text, txtCSTFromTable.Text, txtVATFromTable.Text, txtPaymentTerms.Text, txtDeliveryTerms.Text, Convert.ToDouble(txtAfterDiscount.Text));
                    }
                    else
                    {
                        //     GlobalClass.iSuccess = DAL.fnAddWOOtherCost(Global.uINSERT, null, cmbWONo.Text, Convert.ToDouble(txtdiscountEnter.Text), Convert.ToDouble(txtExciseDutyEnter.Text), Convert.ToDouble(txtCSTEnter.Text), Convert.ToDouble(txtVatServiceTaxEnter.Text), Convert.ToDouble(txtPackingAndForwording.Text), Convert.ToDouble(txtOthersEnter.Text), txtPaymentCode.Text, txtDeliveryCode.Text, totalcost, Convert.ToDouble(txtFinalNetAmount.Text), txtDiscountFromTable.Text, txtExciseDutyTable.Text, txtCSTFromTable.Text, txtVATFromTable.Text, txtPaymentTerms.Text, txtDeliveryTerms.Text, Convert.ToDouble(txtAfterDiscount.Text));
                    }
                    GlobalClass.iSuccess = DAL.WorkOrderApproval(5, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, txtRemarks.Text);
                    GlobalClass.iSuccess = DAL.fnAddERPLog(0, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, "Work Order Genarataed", "WorkOrder");
                    MessageBox.Show("Work Order '" + cmbWONo.Text + "' genarataed successfully", "Success", 0, MessageBoxIcon.Information);

                    JobWork.frmJObWork JobWork = new frmJObWork();
                    this.Hide();
                    JobWork.Show();
                }
            }
            else
            {
                if (string.IsNullOrEmpty(cmbWONo.Text))
                {
                    MessageBox.Show("Work order number is not selected please check ", "Error", 0, MessageBoxIcon.Error);
                    cmbWONo.Focus();
                }
                else if (string.IsNullOrEmpty(cmbProjectCode.Text))
                {
                    MessageBox.Show("Project code is not selected please check ", "Error", 0, MessageBoxIcon.Error);
                    cmbProjectCode.Focus();
                }
                else if (string.IsNullOrEmpty(cmbVendorName.Text))
                {
                    MessageBox.Show("Vendor name is not selected please check ", "Error", 0, MessageBoxIcon.Error);
                    cmbVendorName.Focus();
                }
                else if (string.IsNullOrEmpty(txtDGReferenceno.Text))
                {
                    MessageBox.Show("DC Ref number is not entered. ", "Error", 0, MessageBoxIcon.Error);
                    txtDGReferenceno.Focus();
                }
                else if (string.IsNullOrEmpty(txtRemarks.Text))
                {
                    MessageBox.Show("Please write remarks. ", "Error", 0, MessageBoxIcon.Error);
                    txtRemarks.Focus();
                }
                else if (bDeliverDate == false)
                {
                    MessageBox.Show("Work Order delivery date is not selected. ", "Error", 0, MessageBoxIcon.Error);
                    dtpdelivery.Focus();
                }
            }
        }
        #endregion

        #region WOrk Order Form Exit Function
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home.Show();
        }

        private void frmJObWork_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            Home.Show();
        }
        #endregion

        #region PO Item Color

        DataTable dtItemColor = new DataTable();
        private void Datagridviewcolor()
        {
            int count = 0;
            foreach (DataGridViewRow dgr in dgopitemlist.Rows)
            {
                dtItemColor = DAL.purchaseOrderRepeatColor(dgr.Cells["IPItem"].Value.ToString()).Tables[0];
                if (dtItemColor.Rows.Count > 0)
                {
                    dgopitemlist.Rows[count].Cells[0].Style.BackColor = Color.Yellow;
                    dgopitemlist.Rows[count].Cells[1].Style.BackColor = Color.Yellow;
                }

                dtItemColor = DAL.purchaseOrderRepeatColor(dgr.Cells["OPItemCode"].Value.ToString()).Tables[0];
                if (dtItemColor.Rows.Count > 0)
                {
                    dgopitemlist.Rows[count].Cells[7].Style.BackColor = Color.Yellow;
                    dgopitemlist.Rows[count].Cells[8].Style.BackColor = Color.Yellow;
                }

                //if (Convert.ToDouble(dgr.Cells[17].Value) > 0)
                //{
                //    dgopitemlist.Rows[count].Cells[2].Style.BackColor = Color.Red;
                //    dgopitemlist.Rows[count].Cells[17].Style.BackColor = Color.Red;
                //    dgopitemlist.Rows[count].Cells[18].Style.BackColor = Color.Red;
                //}
                //else if (Convert.ToDouble(dgr.Cells[17].Value) < 0)
                //{
                //    dgopitemlist.Rows[count].Cells[2].Style.BackColor = Color.LightGreen;
                //    dgopitemlist.Rows[count].Cells[17].Style.BackColor = Color.LightGreen;
                //    dgopitemlist.Rows[count].Cells[18].Style.BackColor = Color.LightGreen;
                //}

                count++;
            }
        }
        #endregion

        #region Work Order Select Function
        private void cmbWONo_SelectedIndexChanged(object sender, EventArgs e)
        {
            fnWorkorderNumberChanged(cmbWONo.Text);
        }

        bool bNewWorkOrder = false;
        private void fnWorkorderNumberChanged(string sWorkorderNo)
        {
            bNewWorkOrder = true;
            if (Convert.ToBoolean(login.GetUserDetails[16]) == true || login.GetUserDetails[2].ToLower() == "lizzy" || login.GetUserDetails[2].ToLower() == "veena" || login.GetUserDetails[2].ToLower() == "pavana" || login.GetUserDetails[2].ToLower() == "hemanth reddy")
            {
                dtWOrkOrderList = DAL.WorkOrderList(sWorkorderNo).Tables[0];
                if (dtWOrkOrderList.Rows.Count > 0)
                {
                    bDeliverDate = false;
                    dgopitemlist.AutoGenerateColumns = false;
                    dgopitemlist.DataSource = dtWOrkOrderList;

                    //txtRemarks.Text = dtWOrkOrderList.Rows[0]["UserRemarks"].ToString();
                    //txtPMMHRemarks.Text = dtWOrkOrderList.Rows[0]["PMMHRemarks"].ToString();
                    //txtPCRemarks.Text = dtWOrkOrderList.Rows[0]["PCRemarks"].ToString();
                    //txtRejectReason.Text = dtWOrkOrderList.Rows[0]["RejectReason"].ToString();
                    //txtPMRemarks.Text = dtWOrkOrderList.Rows[0]["StoresRemarks"].ToString();


                    cmbVendorName.Text = dtWOrkOrderList.Rows[0]["VendorName"].ToString();
                    txtVendorCode.Text = dtWOrkOrderList.Rows[0]["VendorCode"].ToString();
                    cmbProjectCode.Text = dtWOrkOrderList.Rows[0]["ProjectCode"].ToString();
                    txtProjectName.Text = dtWOrkOrderList.Rows[0]["ProjectDescription"].ToString();
                    txtPreparedBy.Text = dtWOrkOrderList.Rows[0]["PreparedBy"].ToString();
                    txtAuthorisedBy.Text = dtWOrkOrderList.Rows[0]["AuthorisedBy"].ToString();
                    txtDGReferenceno.Text = dtWOrkOrderList.Rows[0]["DGRefno"].ToString();
                    if (!string.IsNullOrEmpty(dtWOrkOrderList.Rows[0]["PaymentTerm"].ToString()))
                    {
                        cmbPaymentTerms.Text = dtWOrkOrderList.Rows[0]["PaymentTerm"].ToString();
                    }
                    if (!string.IsNullOrEmpty(dtWOrkOrderList.Rows[0]["DeliveryTerm"].ToString()))
                    {
                        cmbDeliverTerms.Text = dtWOrkOrderList.Rows[0]["DeliveryTerm"].ToString();
                    }
                    if (!string.IsNullOrEmpty(dtWOrkOrderList.Rows[0]["WOgeneratedDate"].ToString()))
                    {
                        dtpWODate.Value = Convert.ToDateTime(dtWOrkOrderList.Rows[0]["WOgeneratedDate"]);
                    }
                    if (!string.IsNullOrEmpty(dtWOrkOrderList.Rows[0]["WODeliveryDate"].ToString()))
                    {
                        dtpdelivery.Value = Convert.ToDateTime(dtWOrkOrderList.Rows[0]["WODeliveryDate"]);
                    }
                    if (Convert.ToBoolean(login.GetUserDetails[30]) == true)
                    { }
                    else
                    {
                        if (chkprintwo.Checked == true)
                        {
                            btnWOGenerate.Enabled = false;
                        }
                        else
                        {
                            btnWOGenerate.Enabled = true;
                        }
                    }
                    fnTotalcost();
                    //DTtaxreturn = DAL.TaxRetturn(sWorkorderNo).Tables[0];
                    //if (DTtaxreturn.Rows.Count > 0)
                    //{
                    //    bTaxStatus = true;

                    //    txtFinalNetAmount.Text = DTtaxreturn.Rows[0]["FinalNetAmount"].ToString();

                    //    bTaxStatus = false;
                    //}
                    //else
                    //{
                    //    txtFinalNetAmount.Text = totalcost.ToString();
                    //}
                }
                else
                {
                    dgopitemlist.DataSource = null;
                    cmbVendorName.ResetText();
                    txtVendorCode.ResetText();
                    cmbVendorName.SelectedText = "";
                    cmbProjectCode.SelectedText = "";
                    txtProjectName.ResetText();
                    txtCost.ResetText();
                    btnWOGenerate.Enabled = false;
                }
            }
            else
            {
                dtWOrkOrderList = DAL.WorkOrderList(sWorkorderNo).Tables[0];
                if (dtWOrkOrderList.Rows.Count > 0)
                {
                    //txtRemarks.Text = dtWOrkOrderList.Rows[0]["UserRemarks"].ToString();
                    //txtPMMHRemarks.Text = dtWOrkOrderList.Rows[0]["PMMHRemarks"].ToString();
                    //txtPCRemarks.Text = dtWOrkOrderList.Rows[0]["PCRemarks"].ToString();
                    //txtRejectReason.Text = dtWOrkOrderList.Rows[0]["RejectReason"].ToString();
                    //txtPMRemarks.Text = dtWOrkOrderList.Rows[0]["StoresRemarks"].ToString();
                    dgopitemlist.AutoGenerateColumns = false;
                    dgopitemlist.DataSource = dtWOrkOrderList;
                    Datagridviewcolor();
                    cmbVendorName.Text = dtWOrkOrderList.Rows[0]["VendorName"].ToString();
                    txtVendorCode.Text = dtWOrkOrderList.Rows[0]["VendorCode"].ToString();
                    cmbProjectCode.Text = dtWOrkOrderList.Rows[0]["ProjectCode"].ToString();
                    txtProjectName.Text = dtWOrkOrderList.Rows[0]["ProjectDescription"].ToString();
                    txtPreparedBy.Text = dtWOrkOrderList.Rows[0]["PreparedBy"].ToString();
                    txtAuthorisedBy.Text = dtWOrkOrderList.Rows[0]["AuthorisedBy"].ToString();
                    totalcost = 0.0;
                    foreach (DataGridViewRow dgvr in dgopitemlist.Rows)
                    {
                        totalcost += Convert.ToDouble(dgvr.Cells["OPAmount"].Value);
                    }
                    txtCost.Text = totalcost.ToString();
                }
                else
                {
                    dgopitemlist.DataSource = null;
                    cmbVendorName.ResetText();
                    txtVendorCode.ResetText();
                    cmbProjectCode.Text = "";
                    cmbVendorName.Text = "";
                    txtProjectName.ResetText();
                    txtCost.ResetText();
                }
            }
            bNewWorkOrder = false;
        }
        #endregion
        #region Datagridview Combobox Function
        private void dgopitemlist_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            //if (dgopitemlist.CurrentCell.ColumnIndex == dgopitemlist.Columns.IndexOf(dgopitemlist.Columns["WorkDescription"]))
            //{
            //    DGVCBC = (DataGridViewComboBoxCell)dgopitemlist.CurrentCell;
            //    if (!string.IsNullOrEmpty(e.FormattedValue.ToString()))
            //    {
            //        if (!DGVCBC.Items.Contains(e.FormattedValue))
            //        {
            //            DGVCBC.Items.Add(e.FormattedValue);
            //            lWorkDescription.Add(e.FormattedValue.ToString());
            //            DGVCBC.Value = e.FormattedValue;
            //        }
            //    }
            //}
        }
        #endregion
        #region WorkOrder Quantity, Cost, Tax Calculating Code
        private void dgopitemlist_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show("dgopitemlist_EditingControlShowing   " + ex.Message);
            }
            finally
            {
                if (dgopitemlist.CurrentCell.ColumnIndex == dgopitemlist.Columns.IndexOf(dgopitemlist.Columns["WorkDescription"]))
                {
                    ComboBox combo = e.Control as ComboBox;
                    if (combo == null)
                        // return;
                        combo.DropDownStyle = ComboBoxStyle.DropDown;
                    combo.DropDownHeight = 80;
                    combo.DropDownWidth = 25;
                }
            }
        }

        private void Control_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if (e.KeyChar == '.' && (sender as TextBox).Text.IndexOf('.') > -1)
            {
                e.Handled = true;
            }
        }

        List<string> lstBOMProjects = new List<string>();
        DataTable dtBOMProjectList = new DataTable();
        private void dgopitemlist_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            cmbWorkDescription.Visible = false;
            if (dgopitemlist.CurrentCell.ColumnIndex == 10)
            {
                if (dgopitemlist.Rows[e.RowIndex].Cells["OPItemCode"].Value != null && dgopitemlist.Rows[e.RowIndex].Cells["OPItemCode"].Value.ToString() != string.Empty)
                {
                    //cmbWorkDescription.Location = new Point(MousePosition.X, MousePosition.Y);
                    //cmbWorkDescription.DroppedDown = true;
                    //cmbWorkDescription.SelectedIndexChanged += new EventHandler(cmbWorkDescription_SelectedIndexChanged);
                    //cmbWorkDescription.Visible = true;

                    Show_Combobox(dgopitemlist.CurrentCell.RowIndex, 10);
                }
            }
            else
            {

            }
        }

        private void Show_Combobox(int iRowIndex, int iColumnIndex)
        {
            // DESCRIPTION: SHOW THE COMBO BOX IN THE SELECTED CELL OF THE GRID.
            // PARAMETERS: iRowIndex - THE ROW ID OF THE GRID.
            //             iColumnIndex - THE COLUMN ID OF THE GRID.

            int x = 0;
            int y = 0;
            int Width = 0;
            int height = 0;

            // GET THE ACTIVE CELL'S DIMENTIONS TO BIND THE COMBOBOX WITH IT.
            Rectangle rect = default(Rectangle);
            rect = dgopitemlist.GetCellDisplayRectangle(iColumnIndex, iRowIndex, false);
            x = rect.X + dgopitemlist.Left;
            y = rect.Y + dgopitemlist.Top;

            Width = rect.Width;
            height = rect.Height;

            cmbWorkDescription.SetBounds(x, y, Width, height);
            cmbWorkDescription.Visible = true;
            // cmbWorkDescription.Focus();
            cmbWorkDescription.DroppedDown = true;
        }

        public static DataTable convertStringToDataTable(string data)
        {
            DataTable dtStringtoTable = new DataTable();
            DataColumn dataColumn = new DataColumn("ProjectCode");
            DataColumn dataColumn1 = new DataColumn("ProductNo");
            DataColumn dataColumn2 = new DataColumn("ReqQty");

            dtStringtoTable.Columns.Add(dataColumn);
            dtStringtoTable.Columns.Add(dataColumn1);
            dtStringtoTable.Columns.Add(dataColumn2);
            dtStringtoTable.Columns[2].DataType = typeof(double);
            foreach (string row in data.Split(','))
            {
                DataRow dataRow = dtStringtoTable.NewRow();
                {
                    string[] keyValue = row.Split('/');
                    {
                        //   keyValue.Length
                        dataRow[0] = keyValue[0];
                        dataRow[1] = keyValue[1];
                        dataRow[2] = keyValue[2];
                    }
                }
                dtStringtoTable.Rows.Add(dataRow);
            }
            return dtStringtoTable;
        }

        private void dgopitemlist_KeyUp(object sender, KeyEventArgs e)
        {
            if (pnItemAdd.Enabled == true)
            {
                if (e.KeyCode == Keys.Delete)
                {
                    DialogResult DR = MessageBox.Show("Do you want to delete selected Item? ", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (DR == DialogResult.Yes)
                    {
                        dgopitemlist.Rows.RemoveAt(dgopitemlist.Rows.IndexOf(dgopitemlist.CurrentRow));

                        if (dgopitemlist.Rows.Count == 0)
                        {
                            cmbbomname.Enabled = true;
                        }
                    }
                }
            }
        }

        private void dgopitemlist_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (dgopitemlist.CurrentCell.OwningColumn.Name != "WorkDescription")
            {
                if ((dgopitemlist.CurrentCell.Value) != null && dgopitemlist.CurrentCell.Value.ToString() != string.Empty && dgopitemlist.CurrentCell.Value.ToString() != sDot) // != null)
                {
                    if (Convert.ToDouble(dgopitemlist.CurrentCell.Value.ToString()) != 0)
                    {
                        switch (dgopitemlist.CurrentCell.OwningColumn.Name)
                        {
                            case "IPReqQty":
                                if (Convert.ToDouble(dgopitemlist.CurrentRow.Cells["IPReqQty"].Value.ToString()) > Convert.ToDouble(dgopitemlist.CurrentRow.Cells["IPAvlbQty"].Value.ToString()))
                                {
                                    if (Convert.ToDouble(dgopitemlist.CurrentRow.Cells["IPAvlbQty"].Value) != 0)
                                    {
                                        dgopitemlist.CurrentRow.Cells["IPReqQty"].Value = dgopitemlist.CurrentRow.Cells["IPAvlbQty"].Value;
                                        MessageBox.Show("Entered quantity should be less than or equal to available quantity ", "Error", 0, MessageBoxIcon.Error);
                                    }
                                    else
                                    {
                                        dgopitemlist.CurrentRow.Cells["IPReqQty"].Value = dgopitemlist.CurrentRow.Cells["IPAvlbQty"].Value;
                                        MessageBox.Show("For Entered quantity available quantity is 0", "Error", 0, MessageBoxIcon.Error);
                                    }
                                }
                                break;

                            case "OPReqQty":
                                dgopitemlist.CurrentRow.Cells["OPAmount"].Value = Convert.ToDouble(dgopitemlist.CurrentRow.Cells["OPReqQty"].Value) * Convert.ToDouble(dgopitemlist.CurrentRow.Cells["OPUnitCost"].Value);

                                break;

                            case "OPUnitCost":
                                dgopitemlist.CurrentRow.Cells["OPAmount"].Value = Convert.ToDouble(dgopitemlist.CurrentRow.Cells["OPReqQty"].Value) * Convert.ToDouble(dgopitemlist.CurrentRow.Cells["OPUnitCost"].Value);

                                break;

                            case "SGSTRate":
                                dgopitemlist.CurrentRow.Cells["SGSTAmount"].Value = ((Convert.ToDouble(dgopitemlist.CurrentRow.Cells["OPAmount"].Value)) / 100) * Convert.ToDouble(dgopitemlist.CurrentRow.Cells["SGSTRate"].Value);
                                break;

                            case "CGSTRate":
                                dgopitemlist.CurrentRow.Cells["CGSTAmount"].Value = ((Convert.ToDouble(dgopitemlist.CurrentRow.Cells["OPAmount"].Value)) / 100) * Convert.ToDouble(dgopitemlist.CurrentRow.Cells["CGSTRate"].Value);
                                break;

                            case "IGSTRate":
                                dgopitemlist.CurrentRow.Cells["IGSTAmount"].Value = ((Convert.ToDouble(dgopitemlist.CurrentRow.Cells["OPAmount"].Value)) / 100) * Convert.ToDouble(dgopitemlist.CurrentRow.Cells["IGSTRate"].Value);
                                break;
                        }
                    }
                    else
                    {
                        if (dgopitemlist.CurrentCell.OwningColumn.Name == "IPReqQty" || dgopitemlist.CurrentCell.OwningColumn.Name == "OPReqQty" || dgopitemlist.CurrentCell.OwningColumn.Name == "OPUnitCost")
                        {
                            MessageBox.Show("The Value should be greater than 0", "Error", 0, MessageBoxIcon.Error);
                            dgopitemlist.CurrentCell.Value = oldvalue;
                        }
                        else
                        {
                            dgopitemlist.CurrentCell.Value = 0;
                        }
                    }
                }
                else
                {
                    if (dgopitemlist.CurrentCell.OwningColumn.Name == "IPReqQty" || dgopitemlist.CurrentCell.OwningColumn.Name == "OPReqQty" || dgopitemlist.CurrentCell.OwningColumn.Name == "OPUnitCost")
                    {
                        MessageBox.Show("Enter a Valid Value", "Error", 0, MessageBoxIcon.Error);
                        dgopitemlist.CurrentCell.Value = oldvalue;
                    }
                    else
                    {
                        dgopitemlist.CurrentCell.Value = 0;
                    }
                }
                fnTotalcost();
            }
        }

        double dTotalAmount = 0;
        double dTotalSgst = 0;
        double dTotalCgst = 0;
        double dTotalIgst = 0;
        #endregion
        #region TotalCost Function
        private void fnTotalcost()
        {
            //dgopitemlist.CurrentRow.Cells["SGSTAmount"].Value = ((Convert.ToDouble(dgopitemlist.CurrentRow.Cells["OPAmount"].Value)) / 100) * Convert.ToDouble(dgopitemlist.CurrentRow.Cells["SGSTRate"].Value);
            //dgopitemlist.CurrentRow.Cells["CGSTAmount"].Value = ((Convert.ToDouble(dgopitemlist.CurrentRow.Cells["OPAmount"].Value)) / 100) * Convert.ToDouble(dgopitemlist.CurrentRow.Cells["CGSTRate"].Value);
            //dgopitemlist.CurrentRow.Cells["IGSTAmount"].Value = ((Convert.ToDouble(dgopitemlist.CurrentRow.Cells["OPAmount"].Value)) / 100) * Convert.ToDouble(dgopitemlist.CurrentRow.Cells["IGSTRate"].Value);

            totalcost = 0.0;
            dTotalAmount = 0;
            dTotalSgst = 0;
            dTotalCgst = 0;
            dTotalIgst = 0;

            foreach (DataGridViewRow dgvr in dgopitemlist.Rows)
            {
                if (!string.IsNullOrEmpty(dgvr.Cells["OPAmount"].Value.ToString()))
                {
                    totalcost += Convert.ToDouble(dgvr.Cells["OPAmount"].Value) + Convert.ToDouble(dgvr.Cells["SGSTAmount"].Value) + Convert.ToDouble(dgvr.Cells["CGSTAmount"].Value) + Convert.ToDouble(dgvr.Cells["IGSTAmount"].Value);
                    dTotalAmount += Convert.ToDouble(dgvr.Cells["OPAmount"].Value);
                    dTotalSgst += Convert.ToDouble(dgvr.Cells["SGSTAmount"].Value);
                    dTotalCgst += Convert.ToDouble(dgvr.Cells["CGSTAmount"].Value);
                    dTotalIgst += Convert.ToDouble(dgvr.Cells["IGSTAmount"].Value);
                }
            }
            txtCost.Text = totalcost.ToString();
            txtFinalNetAmount.Text = totalcost.ToString();

            lblTotalAmount.Text = string.Format(india, "{0:c}", dTotalAmount);
            lbltotalSGST.Text = string.Format(india, "{0:c}", dTotalSgst);
            lbltotalCGST.Text = string.Format(india, "{0:c}", dTotalCgst);
            lbltotalIGST.Text = string.Format(india, "{0:c}", dTotalIgst);
        }
        #endregion
        #region Work Order Print Select Function
        private void chkprintwo_CheckedChanged(object sender, EventArgs e)
        {
            if (chkprintwo.Checked == true)
            {
                cmbWONo.Text = "";
                cmbWONo.Items.Clear();
                dtWOFilter = DAL.fnWOFilter(2, "").Tables[0];
                DataView dWorkOFilter = new DataView(dtWOFilter);
                dWorkOFilter.Sort = "id desc";
                dtWOFilter = dWorkOFilter.ToTable();
                if (dtWOFilter.Rows.Count > 0)
                {
                    foreach (DataRow DR in dtWOFilter.Rows)
                    {
                        if (!cmbWONo.Items.Contains(DR["WONumber"].ToString()))
                            cmbWONo.Items.Add(DR["WONumber"].ToString());
                    }
                    btnprintwo.Enabled = true;
                    btnWOGenerate.Enabled = false;
                    pnProject.Enabled = false;
                }
            }
            else
            {
                cmbWONo.Text = "";
                cmbWONo.Items.Clear();
                btnprintwo.Enabled = false;
                btnWOGenerate.Enabled = true;
                pnProject.Enabled = true;
            }
        }
        #endregion
        DataTable dtApprovedby = new DataTable();
        string sApprovedby = "";
        #region  Excel Sheet Genarating Work Order Function
        private void btnprintwo_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(cmbWONo.Text))
            {
                try
                {
                    sApprovedby = "";
                    dtApprovedby = DAL.POWOCCList(4, cmbWONo.Text).Tables[0];
                    if (dtApprovedby.Rows.Count > 0)
                    {
                        sApprovedby = "WO Approved By : " + dtApprovedby.Rows[0][0].ToString();
                    }

                    int iRowIndex = 1;
                    string ExcelFolderName;
                    string ExcelFolderPath;
                    string FileFullPath;
                    string FileFul;
                    EXCEL.Workbook NewWorkBook;
                    EXCEL.Worksheet NewWorkSheet;
                    EXCEL.Application ExcelApp;
                    EXCEL.Range CELLS, cell1, cell2;
                    object misValue;
                    dtPrintWorkOrder = DAL.PrintWorkOrderList(cmbWONo.Text, null).Tables[0];
                    dtVendorAddress = DAL.PrintWorkOrderVendorDetails(cmbWONo.Text).Tables[0];

                    ExcelFolderName = "\\WorkOrder";
                    ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + ExcelFolderName + "\\";
                    FileFullPath = ExcelFolderPath + cmbVendorName.Text + " " + (cmbWONo.Text).Replace("/", "_") + "_" + DateTime.Now.ToString("d/M/yyyy HH/mm/ss") + ".xls";
                    FileFul = ExcelFolderPath + cmbVendorName.Text + " " + (cmbWONo.Text).Replace("/", "_") + "_" + DateTime.Now.ToString("d/M/yyyy HH/mm/ss") + ".pdf";
                    string[] Text ={"","",
                                Global.sCompanyName,
                                "NO.497E, 14th Cross, 4th Phase, Peenya Industrial Area, Bangalore-560 058",
                                "Phone:91(080) 28360184. FAX: (080) 28360047.",
                                "GSTIN : 29AAACI4550Q2Z1 , CIN No: U32301HR1979PTC038643"};
                    string[] Text2 = { "WO Number : " + cmbWONo.Text + "", "WO Date : " + dtVendorAddress.Rows[0]["WOgeneratedDate"].ToString() + " ",
                                         "Project Code : " + cmbProjectCode.Text + "", "Project Name : " + txtProjectName.Text + "" ,
                                         ""};

                    CultureInfo india = new CultureInfo("hi-IN");
                    string text = string.Format(india, "{0:c}", Convert.ToDouble(txtFinalNetAmount.Text)); // ₹ 3,20,000 

                    string[] Text3 ={ "Terms and Conditions","Payment Terms : "+cmbPaymentTerms.Text+"",
                                "Delivery Schedule : "+cmbDeliverTerms.Text+"",
                                "",
                                "a) Inspection and warranty report should accompany with supply dispatch.",
                                "b) PO copy to attach along with dispatch from supplier.",
                                "c) Excess rejected materials to deliver along with supply.",
                                "d) Minimum acceptable shelf life 85% TO receive along with shelf life items supply.",
                                "e) Shelf life certificate to attach along with delivery.",
                                "f) Specificaion and drawing details should be shared by concerned department engineers.",
                                "g) L.D clause apply 5% per week in case of delayed supply.",
                                "h) Calibration report should be attached along with supply.",
                                   "",
                                "Authorised signatory                  ",
                                "",
                                "","",
                                "","","","",
                                "",
                                 "( "+login.GetUserDetails[2].ToString().ToUpper()+" )                "
                               };

                    // string[] Text4 = { "Vendor Code:", "Vendor Name:", "Contact person:", "Address:", "", "GSTIN :" };

                    string[] Text5 = { "IMPORTANT:  Please quote our WO number in all relevant documents.", "Please supply the under mentioned goods", "Subject to terms and conditions as stated below." };

                    string[] Text6 = {"" + dtVendorAddress.Rows[0]["VendorName"].ToString() + ""
                                            ,"Contact person : " + dtVendorAddress.Rows[0]["ContactPerson"].ToString() + " - " + dtVendorAddress.Rows[0]["mobileno"].ToString() +"" ,"" + dtVendorAddress.Rows[0]["Address1"].ToString() + "",
                                            "" + dtVendorAddress.Rows[0]["Address2"].ToString() + ""+"" + dtVendorAddress.Rows[0]["Address3"].ToString() + "", "Vendor Code : " + dtVendorAddress.Rows[0]["VendorCode"].ToString() + "",
                                             "GSTIN : "+ dtVendorAddress.Rows[0]["GSTCode"].ToString()+""};

                    string[] Text7 = { "Total Cost :" };
                    string[] Text8 = { "" + text + "" };
                    if (!Directory.Exists(ExcelFolderPath))
                        Directory.CreateDirectory(ExcelFolderPath);
                    ExcelApp = new EXCEL.Application();
                    misValue = System.Reflection.Missing.Value;

                    try
                    {
                        if (ExcelApp == null)
                            MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                        NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                        NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                        if (NewWorkSheet == null)
                            MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                        else
                            NewWorkSheet.Name = "WorkOrder";
                        // Select the Excel cells, in the range c1 to c7 in the worksheet for cell access check.
                        EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                        if (RANGE == null)
                            MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                        NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlWorkbookNormal, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        CELLS = NewWorkSheet.Cells;

                        NewWorkSheet.Cells[iRowIndex, 2] = "Work Order";
                        NewWorkSheet.Range["A1:B1"].Cells.Font.Size = 16;
                        NewWorkSheet.Range["A1:B1"].Cells.Font.Bold = 16;
                        NewWorkSheet.Range["A2"].Cells.Font.Size = 4;
                        NewWorkSheet.Range["A2"].Cells.Font.Bold = 4;
                        NewWorkSheet.Range["A3"].Cells.Font.Size = 14;
                        NewWorkSheet.Range["A3"].Cells.Font.Bold = 14;
                        iRowIndex++;

                        foreach (string str in Text)
                        {
                            NewWorkSheet.Cells[iRowIndex, 1] = str;
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);
                            iRowIndex++;
                        }
                        iRowIndex = 9;
                        foreach (string str in Text2)
                        {
                            NewWorkSheet.Cells[iRowIndex, 5] = str;
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 5, 9);
                            iRowIndex++;
                        }
                        iRowIndex = 8;
                        foreach (string str in Text6)
                        {
                            NewWorkSheet.Cells[iRowIndex, 1] = str;
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 4);

                            iRowIndex++;
                        }
                        // iRowIndex = 8;
                        //foreach (string str in Text4)
                        //{
                        //    NewWorkSheet.Cells[iRowIndex, 1] = str;

                        //    iRowIndex++;
                        //}
                        foreach (string str in Text5)
                        {
                            NewWorkSheet.Cells[iRowIndex, 1] = str;
                            iRowIndex++;
                        }

                        // CellMerge("AlignRight", NewWorkSheet, 8, 13, 1, 1);
                        CellMerge("BorderAround", NewWorkSheet, 1, 7, 1, 9);
                        CellMerge("BorderAround", NewWorkSheet, 8, 13, 1, 9);
                        CellMerge("BorderAround", NewWorkSheet, 14, 14, 1, 9);
                        CellMerge("Merge", NewWorkSheet, 14, 14, 1, 9);
                        CellMerge("BorderAround", NewWorkSheet, 15, 15, 1, 9);
                        CellMerge("Merge", NewWorkSheet, 15, 15, 1, 9);
                        CellMerge("BorderAround", NewWorkSheet, 16, 16, 1, 9);
                        CellMerge("Merge", NewWorkSheet, 16, 16, 1, 9);

                        //CellMerge("Merge", NewWorkSheet, 4, 4, 1, 5);
                        //CellMerge("Merge", NewWorkSheet, 5, 5, 1, 5);
                        //CellMerge("Merge", NewWorkSheet, 6, 6, 1, 5);
                        //CellMerge("Merge", NewWorkSheet, 7, 7, 1, 5);

                        bool IsFirsttime = true;
                        string finalColLetter = string.Empty;
                        int j = 18;
                        dtPrintWorkOrder.Clear();
                        dtPrintWorkOrder = DAL.PrintWorkOrderList(cmbWONo.Text, "IPItems").Tables[0];

                        for (int i = dtPrintWorkOrder.Rows.Count - 1; i >= 0; i--)
                        {
                            if (dtPrintWorkOrder.Rows[i][1] == DBNull.Value)
                                dtPrintWorkOrder.Rows[i].Delete();
                        }
                        dtPrintWorkOrder.AcceptChanges();

                        if (dtPrintWorkOrder.Rows.Count > 0)
                        {
                            object[,] rawData = new object[dtPrintWorkOrder.Rows.Count + 1, dtPrintWorkOrder.Columns.Count];
                            for (int col = 0; col < dtPrintWorkOrder.Columns.Count; col++)
                            {
                                rawData[0, col] = dtPrintWorkOrder.Columns[col].ColumnName;
                            }
                            if (dtPrintWorkOrder.Rows.Count > 0)
                            {
                                for (int row = 0; row < dtPrintWorkOrder.Rows.Count; row++)
                                {
                                    for (int col = 0; col < dtPrintWorkOrder.Columns.Count; col++)
                                    {
                                        rawData[row + 1, col] = dtPrintWorkOrder.Rows[row].ItemArray[col];
                                    }
                                }
                                string excelRange = string.Empty;
                                if (IsFirsttime)
                                {
                                    finalColLetter = string.Empty;
                                    string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                                    int colCharsetLen = colCharset.Length;

                                    if (dtPrintWorkOrder.Columns.Count > colCharsetLen)
                                    {
                                        finalColLetter = colCharset.Substring(
                                            (dtPrintWorkOrder.Columns.Count - 1) / colCharsetLen - 1, 1);
                                    }

                                    finalColLetter += colCharset.Substring(
                                            (dtPrintWorkOrder.Columns.Count - 1) % colCharsetLen, 1);
                                    excelRange = string.Format("A18:{0}{1}", finalColLetter, dtPrintWorkOrder.Rows.Count + j);
                                    IsFirsttime = false;
                                    j++;
                                }
                                else
                                {
                                    j += 1;
                                    excelRange = string.Format("A" + j + ":{0}{1}", finalColLetter, dtPrintWorkOrder.Rows.Count + j);
                                }

                                NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                            }
                        }
                        CellMerge("BorderAround", NewWorkSheet, 18, 18 + dtPrintWorkOrder.Rows.Count, 1, 3);
                        CellMerge("GridLines", NewWorkSheet, 18, 18 + dtPrintWorkOrder.Rows.Count, 1, 3);
                        NewWorkSheet.Cells[20 + dtPrintWorkOrder.Rows.Count, 7] = "SGST";


                        CellMerge("BorderAround", NewWorkSheet, 20 + dtPrintWorkOrder.Rows.Count, 20 + dtPrintWorkOrder.Rows.Count, 7, 7);


                        NewWorkSheet.Cells[20 + dtPrintWorkOrder.Rows.Count, 8] = "CGST";
                        CellMerge("BorderAround", NewWorkSheet, 20 + dtPrintWorkOrder.Rows.Count, 20 + dtPrintWorkOrder.Rows.Count, 8, 8);

                        NewWorkSheet.Cells[20 + dtPrintWorkOrder.Rows.Count, 9] = "IGST";
                        CellMerge("BorderAround", NewWorkSheet, 20 + dtPrintWorkOrder.Rows.Count, 20 + dtPrintWorkOrder.Rows.Count, 9, 9);
                        CellMerge("Bold", NewWorkSheet, 20 + dtPrintWorkOrder.Rows.Count, 20 + dtPrintWorkOrder.Rows.Count, 7, 9);
                        int krow = 21 + dtPrintWorkOrder.Rows.Count;

                        int rows = 20 + dtPrintWorkOrder.Rows.Count + 1;
                        j = rows;
                        ((Microsoft.Office.Interop.Excel.Range)NewWorkSheet.Rows[j, Type.Missing]).Font.Bold = true;
                        dtPrintWorkOrder.Clear();


                        dtPrintWorkOrder = DAL.PrintWorkOrderList(cmbWONo.Text, null).Tables[0];
                        IsFirsttime = true;
                        for (int i = dtPrintWorkOrder.Rows.Count - 1; i >= 0; i--)
                        {
                            if (dtPrintWorkOrder.Rows[i][1] == DBNull.Value)
                                dtPrintWorkOrder.Rows[i].Delete();
                        }
                        dtPrintWorkOrder.AcceptChanges();

                        if (dtPrintWorkOrder.Rows.Count > 0)
                        {
                            object[,] rawData = new object[dtPrintWorkOrder.Rows.Count + 1, dtPrintWorkOrder.Columns.Count];
                            for (int col = 0; col < dtPrintWorkOrder.Columns.Count; col++)
                            {
                                rawData[0, col] = dtPrintWorkOrder.Columns[col].ColumnName;
                            }
                            if (dtPrintWorkOrder.Rows.Count > 0)
                            {
                                for (int row = 0; row < dtPrintWorkOrder.Rows.Count; row++)
                                {
                                    for (int col = 0; col < dtPrintWorkOrder.Columns.Count; col++)
                                    {
                                        rawData[row + 1, col] = dtPrintWorkOrder.Rows[row].ItemArray[col];
                                    }
                                }
                                string excelRange = string.Empty;
                                if (IsFirsttime)
                                {
                                    finalColLetter = string.Empty;
                                    string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                                    int colCharsetLen = colCharset.Length;

                                    if (dtPrintWorkOrder.Columns.Count > colCharsetLen)
                                    {
                                        finalColLetter = colCharset.Substring(
                                            (dtPrintWorkOrder.Columns.Count - 1) / colCharsetLen - 1, 1);
                                    }

                                    finalColLetter += colCharset.Substring(
                                            (dtPrintWorkOrder.Columns.Count - 1) % colCharsetLen, 1);
                                    excelRange = string.Format("A" + rows + ":{0}{1}", finalColLetter, dtPrintWorkOrder.Rows.Count + j);
                                    IsFirsttime = false;
                                    j++;
                                }
                                else
                                {
                                    j += 1;
                                    excelRange = string.Format("A" + j + ":{0}{1}", finalColLetter, dtPrintWorkOrder.Rows.Count + j);
                                }

                                NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                            }

                            NewWorkSheet.Cells[krow, 4] = "Quantity";
                            NewWorkSheet.Cells[krow, 6] = "Amount";
                            NewWorkSheet.Cells[krow, 7] = "Amt - Rate(%)";
                            NewWorkSheet.Cells[krow, 8] = "Amt - Rate(%)";
                            NewWorkSheet.Cells[krow, 9] = "Amt - Rate(%)";


                            int iTax = rows + dtPrintWorkOrder.Rows.Count + 1;
                            foreach (string str in Text7)
                            {
                                iTax++;
                                NewWorkSheet.Cells[iTax, 6] = str;
                                CellMerge("Merge", NewWorkSheet, iTax, iTax, 6, 7);
                                CellMerge("AlignRight", NewWorkSheet, iTax, iTax, 6, 7);
                                CellMerge("Bold", NewWorkSheet, iTax, iTax, 6, 7);
                            }
                            iTax = rows + dtPrintWorkOrder.Rows.Count + 1;
                            foreach (string str in Text8)
                            {
                                iTax++;
                                NewWorkSheet.Cells[iTax, 8] = str;
                                CellMerge("Merge", NewWorkSheet, iTax, iTax, 8, 9);
                                CellMerge("AlignCenter", NewWorkSheet, iTax, iTax, 8, 9);
                                CellMerge("Bold", NewWorkSheet, iTax, iTax, 8, 9);
                            }

                            CellMerge("Bold", NewWorkSheet, rows, rows, 1, 12);
                            CellMerge("GridLines", NewWorkSheet, rows, rows + dtPrintWorkOrder.Rows.Count, 1, 9);
                            CellMerge("BorderAround", NewWorkSheet, rows + dtPrintWorkOrder.Rows.Count + 1, rows + dtPrintWorkOrder.Rows.Count + 9, 1, 9);
                            CellMerge("AlignCenter", NewWorkSheet, 1, 1, 7, 7);
                            CellMerge("AlignTop", NewWorkSheet, 8, 13, 1, 4);
                            CellMerge("AlignCenter", NewWorkSheet, 18, rows + dtPrintWorkOrder.Rows.Count, 2, 9);
                            CellMerge("AlignCenterV", NewWorkSheet, 18, rows + dtPrintWorkOrder.Rows.Count, 2, 9);

                            iRowIndex = rows + dtPrintWorkOrder.Rows.Count + 10;


                            NewWorkSheet.HPageBreaks.Add(NewWorkSheet.Range["A" + iRowIndex + ""]);

                            CellMerge("AlignCenter", NewWorkSheet, iRowIndex, iRowIndex, 1, 9);
                            CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 9);

                            int NewIrowindex = iRowIndex;
                            //  NewWorkSheet.Range["A"+ iRowIndex + ":A"+ iRowIndex + ""].Cells.Font.Size = 16;



                            int icheck = 0;
                            foreach (string str in Text3)
                            {
                                NewWorkSheet.Cells[iRowIndex, 1] = str;
                                //icheck++;
                                //if (icheck != 15)
                                //{
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 9);
                                //}
                                iRowIndex++;
                            }
                            int printrea = iRowIndex;
                            iRowIndex = rows + dtPrintWorkOrder.Rows.Count + 10;

                            //  CellMerge("BorderAround", NewWorkSheet, iRowIndex, iRowIndex + 2, 1, 9);
                            //   CellMerge("BorderAround", NewWorkSheet, iRowIndex + 4, iRowIndex + 11, 1, 9);
                            CellMerge("BorderAround", NewWorkSheet, 1, iRowIndex + 22, 1, 9);
                            CellMerge("Merge", NewWorkSheet, 1, 1, 1, 9);
                            CellMerge("AlignRight", NewWorkSheet, iRowIndex + 13, iRowIndex + 22, 1, 9);
                            //  CellMerge("Bold", NewWorkSheet, iRowIndex + 3, iRowIndex + 3, 1, 9);
                            CellMerge("Bold", NewWorkSheet, iRowIndex + 13, iRowIndex + 22, 1, 9);
                            CellMerge("Bold", NewWorkSheet, 3, 8, 1, 9);
                            CellMerge("AlignCenter", NewWorkSheet, 1, 1, 1, 9);
                          //  NewWorkSheet.Range["C9:E12"].Cells.Font.Bold = true;
                            NewWorkSheet.Range["A18:G18"].Cells.Font.Bold = true;
                            // NewWorkSheet.get_Range("B18", "L"+ iCenter + "").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;

                            // NewWorkSheet.get_Range("B18", "L30").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;

                            NewWorkSheet.Range["A3:F3"].Cells.Font.Size = 48;
                            NewWorkSheet.Range["A3:F3"].Cells.Font.Bold = true;

                            NewWorkSheet.Columns[1].ColumnWidth = 28;
                            NewWorkSheet.Columns[1].WrapText = true;
                            NewWorkSheet.Columns[2].ColumnWidth = 8;
                            NewWorkSheet.Columns[3].ColumnWidth = 18;
                            NewWorkSheet.Columns[3].WrapText = true;
                            NewWorkSheet.Columns[4].ColumnWidth = 9;
                            NewWorkSheet.Columns[5].ColumnWidth = 14;
                            NewWorkSheet.Columns[6].ColumnWidth = 14;
                            //NewWorkSheet.Columns[7].ColumnWidth = 12;
                            //NewWorkSheet.Columns[8].ColumnWidth = 12;
                            NewWorkSheet.Columns[7].ColumnWidth = 14;
                            NewWorkSheet.Columns[8].ColumnWidth = 14;
                            //NewWorkSheet.Columns[10].ColumnWidth = 12;
                            NewWorkSheet.Columns[9].ColumnWidth = 14;
                            //NewWorkSheet.Columns[12].ColumnWidth = 12;

                            //NewWorkSheet.Columns[14].ColumnWidth = 12;

                            NewWorkSheet.get_Range("A6", "A9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignGeneral;
                            NewWorkSheet.PageSetup.Zoom = false;
                            NewWorkSheet.get_Range("A4", "I9999").Cells.Font.Size = 13;
                            NewWorkSheet.get_Range("A" + NewIrowindex + "", "A" + NewIrowindex + "").Cells.Font.Size = 18;
                            Microsoft.Office.Interop.Excel.Range range1 = NewWorkSheet.get_Range("D5", "I9999");
                            range1.NumberFormat = "0.00";
                            //NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                            //NewWorkSheet.PageSetup.PrintNotes = true;
                            //NewWorkSheet.PageSetup.FitToPagesTall = 1;
                            //NewWorkSheet.PageSetup.FitToPagesWide = 1;
                            //NewWorkSheet.PageSetup.LeftMargin = 0;
                            //NewWorkSheet.PageSetup.RightMargin = 0;
                            //NewWorkSheet.PageSetup.TopMargin = 0.75;
                            //NewWorkSheet.PageSetup.BottomMargin = 0.75;

                            NewWorkSheet.PageSetup.PrintArea = "A1:I" + (printrea) + "";
                            // NewWorkSheet.PageSetup.LeftMargin = 0.1;
                            //NewWorkSheet.PageSetup.RightMargin = 0.3;
                            //NewWorkSheet.PageSetup.LeftHeader = "&\"Arial\"&10 .. " + cmbVendorName.Text + "";
                            //NewWorkSheet.PageSetup.RightHeader = "&\"Arial\"&10" + cmbWONo.Text + "";

                            NewWorkSheet.PageSetup.RightFooter = "Page &P of &N";
                            NewWorkSheet.PageSetup.PrintNotes = true;
                            NewWorkSheet.PageSetup.Zoom = 70;

                            NewWorkSheet.PageSetup.PrintTitleRows = "A1:I7";

                            NewWorkSheet.PageSetup.AlignMarginsHeaderFooter = false;
                            NewWorkSheet.PageSetup.LeftMargin = 0.3;
                            NewWorkSheet.PageSetup.RightMargin = 0.3;
                            NewWorkSheet.PageSetup.CenterHorizontally = true;

                            //NewWorkSheet.PageSetup.Zoom = false;
                            //NewWorkSheet.PageSetup.FitToPagesWide = 1;
                            //NewWorkSheet.PageSetup.FitToPagesTall = false;

                            NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                            NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                            // string _stLOGO = "C:\\Databasepath\\New_Biss_Logo.jpg";
                            EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[3, 7];

                            Image oImage = Image.FromFile(Global.sLogo);
                            System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                            NewWorkSheet.Paste(oRange, Global.sLogo);

                            EXCEL.Range oRange1 = (EXCEL.Range)NewWorkSheet.Cells[3, 1];

                            Image oImage1 = Image.FromFile(Global.sITWLogo);
                            System.Windows.Forms.Clipboard.SetDataObject(oImage1, true);
                            NewWorkSheet.Paste(oRange1, Global.sITWLogo);


                            EXCEL.Range oRange2 = (EXCEL.Range)NewWorkSheet.Cells[iTax + 1, 7];

                            Image oImage2 = Image.FromFile("C:\\Databasepath\\BissSealSign.jpg");
                            System.Windows.Forms.Clipboard.SetDataObject(oImage2, true);
                            NewWorkSheet.Paste(oRange2, "C:\\Databasepath\\BissSealSign.jpg");


                            EXCEL.Range oRange3 = (EXCEL.Range)NewWorkSheet.Cells[printrea - 9, 7];
                            Image oImage4 = Image.FromFile("C:\\Databasepath\\BissSealSign.jpg");
                            System.Windows.Forms.Clipboard.SetDataObject(oImage4, true);
                            NewWorkSheet.Paste(oRange3, "C:\\Databasepath\\BissSealSign.jpg");

                            NewWorkBook.Save();
                            ExcelApp.Visible = false;

                            NewWorkBook.ExportAsFixedFormat(EXCEL.XlFixedFormatType.xlTypePDF, FileFul);
                            System.Diagnostics.Process.Start(FileFul);

                            NewWorkBook.Close(true, misValue, misValue);
                            ExcelApp.Quit();
                            releaseObject(NewWorkSheet);
                            releaseObject(NewWorkBook);
                            releaseObject(ExcelApp);

                            if (File.Exists(FileFullPath))
                            {
                                // File.Delete(FileFullPath);
                            }

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }


        #region Excel App Release Object Function
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
        #endregion

        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "GridLines":
                    {
                        CELLS.Borders.Color = System.Drawing.Color.Black;
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlHairline, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignCenter":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                        break;
                    }

                case "AlignCenterV":
                    {
                        CELLS.VerticalAlignment = EXCEL.XlVAlign.xlVAlignCenter;
                        break;
                    }
                case "AlignRight":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                        break;
                    }
                case "AlignTop":
                    {
                        CELLS.VerticalAlignment = EXCEL.XlVAlign.xlVAlignTop;
                        break;
                    }
                case "Bold":
                    {
                        CELLS.Font.Bold = true;
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

        }
        #endregion
        #region View Work Order List

        private void btnviewpolist_Click(object sender, EventArgs e)
        {
            this.Hide();
            pleasewaitform pleaseWait = new pleasewaitform();
            pleaseWait.Show(); Application.DoEvents();
            ViewWorkOrder WOView = new ViewWorkOrder();
            WOView.Show();
            pleaseWait.Hide();
        }
        #endregion

        #region Clear All Function
        private void btnClearAll_Click(object sender, EventArgs e)
        {
            DialogResult DR = MessageBox.Show("Do you want to Clear all entered data", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (DR == DialogResult.Yes)
            {
                JobWork.frmJObWork workorder = new JobWork.frmJObWork();
                this.Hide();
                workorder.Show();
            }
        }
        #endregion
        #region Input Output Quantity Check Function
        private void dgopitemlist_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if ((dgopitemlist.CurrentCell.OwningColumn.Name == "IPReqQty") || (dgopitemlist.CurrentCell.OwningColumn.Name == "OPReqQty") || (dgopitemlist.CurrentCell.OwningColumn.Name == "OPUnitCost"))
            {
                if ((dgopitemlist.CurrentCell.Value.ToString()) != string.Empty && (dgopitemlist.CurrentCell.Value.ToString()) != sDot)
                {
                    oldvalue = Convert.ToDouble(dgopitemlist.CurrentCell.Value);
                }
            }
        }
        #endregion
        #region Total Amount Check Function
        private void dgopitemlist_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            //fnTotalcost();
        }
        #endregion
        #region Delivery Date Check Function
        private void dtpdelivery_ValueChanged(object sender, EventArgs e)
        {
            bDeliverDate = true;
            if (dtpdelivery.Value < dtpWODate.Value || dtpdelivery.Value == DateTime.Today.Date)
            {
                bDeliverDate = false;
                MessageBox.Show("Delivery date should be greater than WO date");
            }
        }
        #endregion


        CultureInfo india = new CultureInfo("hi-IN");
        DataTable dtPackingForwardingTax = new DataTable();
        private void btnPackingAmount_Click(object sender, EventArgs e)
        {
            dtPackingForwardingTax = DAL.PackingForwardingTax(cmbWONo.Text, "Packing & Forwarding").Tables[0];

            if (dtPackingForwardingTax.Rows.Count > 0)
            {
                dtPackingForwardingTax = DAL.PackingForwardingTax(cmbWONo.Text, null).Tables[0];
                dgPackingTaxes.AutoGenerateColumns = false;
                dgPackingTaxes.DataSource = dtPackingForwardingTax;
                dgPackingTaxes.Visible = true;
                btnViewTax.Text = "Close Tax";
            }
            else
            {
                GlobalClass.iSuccess = DAL.fnAddPOPackingForward(Global.uINSERT, cmbWONo.Text, "Packing & Forwarding", 0, 0, 0, 0, 0, 0, 0);
                dtPackingForwardingTax = DAL.PackingForwardingTax(cmbWONo.Text, null).Tables[0];
                if (dtPackingForwardingTax.Rows.Count > 0)
                {
                    dgPackingTaxes.AutoGenerateColumns = false;
                    dgPackingTaxes.DataSource = dtPackingForwardingTax;
                    dgPackingTaxes.Visible = true;
                    btnViewTax.Text = "Close Tax";
                }
            }
        }

        private void btnAddTransport_Click(object sender, EventArgs e)
        {
            dtPackingForwardingTax = DAL.PackingForwardingTax(cmbWONo.Text, "Transportation / Freight").Tables[0];
            if (dtPackingForwardingTax.Rows.Count > 0)
            {
                dtPackingForwardingTax = DAL.PackingForwardingTax(cmbWONo.Text, null).Tables[0];
                dgPackingTaxes.AutoGenerateColumns = false;
                dgPackingTaxes.DataSource = dtPackingForwardingTax;
                dgPackingTaxes.Visible = true;
                btnViewTax.Text = "Close Tax";
            }
            else
            {
                GlobalClass.iSuccess = DAL.fnAddPOPackingForward(Global.uINSERT, cmbWONo.Text, "Transportation / Freight", 0, 0, 0, 0, 0, 0, 0);
                dtPackingForwardingTax = DAL.PackingForwardingTax(cmbWONo.Text, null).Tables[0];
                if (dtPackingForwardingTax.Rows.Count > 0)
                {
                    dgPackingTaxes.AutoGenerateColumns = false;
                    dgPackingTaxes.DataSource = dtPackingForwardingTax;
                    dgPackingTaxes.Visible = true;
                    btnViewTax.Text = "Close Tax";
                }
            }
        }

        private void btnViewTax_Click(object sender, EventArgs e)
        {
            if (dgPackingTaxes.Visible == true)
            {
                dgPackingTaxes.Visible = false;
                btnViewTax.Text = "View Tax";
            }
            else
            {
                dgPackingTaxes.Visible = true;
                btnViewTax.Text = "Close Tax";
            }
        }

        private void dgPackingTaxes_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (dgPackingTaxes.CurrentCell.Value != null)
            {
                if (!string.IsNullOrEmpty(dgPackingTaxes.CurrentCell.Value.ToString()) && (dgPackingTaxes.CurrentCell.Value.ToString() != sDot))
                {
                    switch (dgPackingTaxes.CurrentCell.OwningColumn.Index)
                    {
                        case 1:

                            dgPackingTaxes.CurrentRow.Cells[3].Value = (Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[1].Value) / 100) * Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[2].Value);
                            dgPackingTaxes.CurrentRow.Cells[5].Value = (Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[1].Value) / 100) * Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[4].Value);
                            dgPackingTaxes.CurrentRow.Cells[7].Value = (Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[1].Value) / 100) * Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[6].Value);
                            break;
                        case 2:
                            dgPackingTaxes.CurrentRow.Cells[3].Value = (Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[1].Value) / 100) * Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[2].Value);
                            break;
                        case 4:
                            dgPackingTaxes.CurrentRow.Cells[5].Value = (Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[1].Value) / 100) * Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[4].Value);
                            break;
                        case 6:
                            dgPackingTaxes.CurrentRow.Cells[7].Value = (Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[1].Value) / 100) * Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[6].Value);
                            break;
                    }

                    GlobalClass.iSuccess = DAL.fnAddPOPackingForward(Global.uUPDATE, cmbWONo.Text, dgPackingTaxes.CurrentRow.Cells[0].Value.ToString(), Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[2].Value), Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[3].Value), Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[4].Value), Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[5].Value), Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[6].Value),
                                           Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[7].Value), Convert.ToDouble(dgPackingTaxes.CurrentRow.Cells[1].Value));
                }
                else
                {
                    if (dgPackingTaxes.CurrentCell.OwningColumn.Index == 1)
                    {
                        dgPackingTaxes.CurrentCell.Value = dOldTaxRate;
                    }
                    else
                    {
                        dgPackingTaxes.CurrentCell.Value = 0;
                    }
                }
            }
        }
        double dOldTaxRate;
        private void dgPackingTaxes_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (dgPackingTaxes.CurrentCell.OwningColumn.Index == 1)
            {
                dOldTaxRate = Convert.ToDouble(dgPackingTaxes.CurrentCell.Value);
            }
        }

        private void dgPackingTaxes_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                e.Control.KeyPress += new KeyPressEventHandler(Control_KeyPress);
            }
            catch (Exception ex)
            {
                MessageBox.Show(" dgPackingTaxes_EditingControlShowing   " + ex.Message);
            }
        }

        private void dgPackingTaxes_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)   //delete particular row by pressing Delete key
            {
                DialogResult DR = MessageBox.Show("Do you want to delete selected row", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (DR == DialogResult.Yes)
                {
                    GlobalClass.iSuccess = DAL.fnAddPOPackingForward(Global.uDELETE, cmbWONo.Text, dgPackingTaxes.CurrentRow.Cells[0].Value.ToString(), 0, 0, 0, 0, 0, 0, 0);
                    dgPackingTaxes.Rows.RemoveAt(dgPackingTaxes.Rows.IndexOf(dgPackingTaxes.CurrentRow));
                }
            }
        }

        private void chkWoNumber_CheckedChanged(object sender, EventArgs e)
        {
            if (chkWoNumber.Checked == true)
            {
                dtWOFilter = DAL.fnWOFilter(2, "").Tables[0];
                if (dtWOFilter.Rows.Count > 0)
                {
                    cmbWONo.Items.Clear();
                    foreach (DataRow DR in dtWOFilter.Rows)
                    {
                        if (!cmbWONo.Items.Contains(DR["WONumber"].ToString()))
                            cmbWONo.Items.Add(DR["WONumber"].ToString());
                    }
                    cmbWONo.Enabled = true;
                }
            }
            else
            {
                dtWOFilter = DAL.fnWOFilter(1, "").Tables[0];
                if (dtWOFilter.Rows.Count > 0)
                {
                    cmbWONo.Items.Clear();
                    foreach (DataRow DR in dtWOFilter.Rows)
                    {
                        if (!cmbWONo.Items.Contains(DR["WONumber"].ToString()))
                            cmbWONo.Items.Add(DR["WONumber"].ToString());
                    }
                    cmbWONo.Enabled = true;
                }
            }
        }

        private void chkItemCode_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemCode.CheckState == CheckState.Checked)
            {
                chkItemDesc.Checked = false;
            }
        }

        private void chkItemDesc_CheckedChanged(object sender, EventArgs e)
        {
            if (chkItemDesc.CheckState == CheckState.Checked)
            {
                chkItemCode.Checked = false;
            }
        }

        private void cbViewRemarks_CheckedChanged(object sender, EventArgs e)
        {

            if (cbViewRemarks.CheckState == CheckState.Checked)
            {
                cbViewRemarks.Text = "View Remarks";
                pnRemarks.Visible = false;
            }
            else if (cbViewRemarks.CheckState == CheckState.Unchecked)
            {
                cbViewRemarks.Text = "View Tax";
                pnRemarks.Visible = true;
            }
        }
        DataTable dtWOUserlist = new DataTable();
        private void btnApproveWO_Click(object sender, EventArgs e)
        {
            dtWOUserlist = DAL.fnPOOrderFilter(14, login.GetUserDetails[2]).Tables[0];
            btnWOGenerate.Enabled = false;
            //Rakesh
            if (Convert.ToBoolean(login.GetUserDetails[31]) == true)
            {
                btnAcceptPO.Enabled = true;
                btnRejectPO.Enabled = true;
                cmbWONo.Enabled = true;
                pnItemAdd.Enabled = false;
                cmbWONo.Text = "";
                cmbWONo.Items.Clear();
                foreach (DataRow DT in dtWOUserlist.Rows)
                {
                    dtWOFilter = DAL.fnWOFilter(31, DT["POUserName"].ToString()).Tables[0];
                    btnSave.Enabled = false;

                    if (dtWOFilter.Rows.Count > 0)
                    {
                        foreach (DataRow DR in dtWOFilter.Rows)
                        {
                            if (!cmbWONo.Items.Contains(DR["WONumber"].ToString()))
                                cmbWONo.Items.Add(DR["WONumber"].ToString());
                        }
                    }
                }
            }
            //else if (Convert.ToBoolean(login.GetUserDetails[30]) == true)
            //{

            //}
            //Ravi
            else if (Convert.ToBoolean(login.GetUserDetails[32]) == true)
            {
                btnAcceptPO.Enabled = true;
                btnRejectPO.Enabled = true;
                cmbWONo.Enabled = true;
                pnItemAdd.Enabled = false;
                cmbWONo.Text = "";
                cmbWONo.Items.Clear();
                foreach (DataRow DT in dtWOUserlist.Rows)
                {
                    dtWOFilter = DAL.fnWOFilter(32, DT["POUserName"].ToString()).Tables[0];
                    btnSave.Enabled = false;

                    if (dtWOFilter.Rows.Count > 0)
                    {
                        foreach (DataRow DR in dtWOFilter.Rows)
                        {
                            if (!cmbWONo.Items.Contains(DR["WONumber"].ToString()))
                                cmbWONo.Items.Add(DR["WONumber"].ToString());
                        }
                    }
                }
            }

            //Theertha Rao
            else if (Convert.ToBoolean(login.GetUserDetails[80]) == true)
            {
                btnAcceptPO.Enabled = true;
                btnRejectPO.Enabled = true;
                cmbWONo.Enabled = true;
                pnItemAdd.Enabled = false;
                cmbWONo.Text = "";
                cmbWONo.Items.Clear();
                dtWOFilter = DAL.fnWOFilter(80, "").Tables[0];
                btnSave.Enabled = false;

                if (dtWOFilter.Rows.Count > 0)
                {
                    foreach (DataRow DR in dtWOFilter.Rows)
                    {
                        if (!cmbWONo.Items.Contains(DR["WONumber"].ToString()))
                            cmbWONo.Items.Add(DR["WONumber"].ToString());
                    }
                }
            }

            //Test Lab
            else if (Convert.ToBoolean(login.GetUserDetails[82]) == true)
            {
                btnAcceptPO.Enabled = true;
                btnRejectPO.Enabled = true;
                cmbWONo.Enabled = true;
                pnItemAdd.Enabled = false;
                cmbWONo.Text = "";
                cmbWONo.Items.Clear();
                foreach (DataRow DT in dtWOUserlist.Rows)
                {
                    dtWOFilter = DAL.fnWOFilter(82, DT["POUserName"].ToString()).Tables[0];
                    btnSave.Enabled = false;

                    if (dtWOFilter.Rows.Count > 0)
                    {
                        foreach (DataRow DR in dtWOFilter.Rows)
                        {
                            if (!cmbWONo.Items.Contains(DR["WONumber"].ToString()))
                                cmbWONo.Items.Add(DR["WONumber"].ToString());
                        }
                    }
                }
            }


            //Ramakrishna
            else if (Convert.ToBoolean(login.GetUserDetails[30]) == true)
            {
                btnAcceptPO.Enabled = true;
                btnRejectPO.Enabled = true;
                cmbWONo.Enabled = true;
                pnItemAdd.Enabled = false;
                cmbWONo.Text = "";
                cmbWONo.Items.Clear();
                dtWOFilter = DAL.fnWOFilter(30, "").Tables[0];
                btnSave.Enabled = false;

                if (dtWOFilter.Rows.Count > 0)
                {
                    foreach (DataRow DR in dtWOFilter.Rows)
                    {
                        if (!cmbWONo.Items.Contains(DR["WONumber"].ToString()))
                            cmbWONo.Items.Add(DR["WONumber"].ToString());
                    }
                }
            }

            else if (Convert.ToBoolean(login.GetUserDetails[85]) == true)
            {
                btnAcceptPO.Enabled = true;
                btnRejectPO.Enabled = true;
                cmbWONo.Enabled = true;
                pnItemAdd.Enabled = false;
                cmbWONo.Text = "";
                cmbWONo.Items.Clear();
                dtWOFilter = DAL.fnWOFilter(3, "").Tables[0];
                btnSave.Enabled = false;

                if (dtWOFilter.Rows.Count > 0)
                {
                    foreach (DataRow DR in dtWOFilter.Rows)
                    {
                        if (!cmbWONo.Items.Contains(DR["WONumber"].ToString()))
                            cmbWONo.Items.Add(DR["WONumber"].ToString());
                    }
                }
            }

            //Vishal Thilak Kumar
            else if (Convert.ToBoolean(login.GetUserDetails[29]) == true)
            {
                btnAcceptPO.Enabled = true;
                btnRejectPO.Enabled = true;
                cmbWONo.Enabled = true;
                pnItemAdd.Enabled = false;
                cmbWONo.Text = "";
                cmbWONo.Items.Clear();
                foreach (DataRow DT in dtWOUserlist.Rows)
                {
                    dtWOFilter = DAL.fnWOFilter(29, DT["POUserName"].ToString()).Tables[0];
                    btnSave.Enabled = false;

                    if (dtWOFilter.Rows.Count > 0)
                    {
                        foreach (DataRow DR in dtWOFilter.Rows)
                        {
                            if (!cmbWONo.Items.Contains(DR["WONumber"].ToString()))
                                cmbWONo.Items.Add(DR["WONumber"].ToString());
                        }
                    }
                }
            }

            //MuthuRamalingam
            else if (Convert.ToBoolean(login.GetUserDetails[16]) == true && Convert.ToBoolean(login.GetUserDetails[30]) != true || login.GetUserDetails[2].ToLower() == "lizzy" && Convert.ToBoolean(login.GetUserDetails[30]) != true || login.GetUserDetails[2].ToLower() == "veena" || login.GetUserDetails[2].ToLower() == "pavana" || login.GetUserDetails[2].ToLower() == "hemanth reddy" && Convert.ToBoolean(login.GetUserDetails[30]) != true)
            {
                btnAcceptPO.Enabled = true;
                btnRejectPO.Enabled = true;
                cmbWONo.Enabled = true;
                pnItemAdd.Enabled = false;
                cmbWONo.Text = "";
                cmbWONo.Items.Clear();
                dtWOFilter = DAL.fnWOFilter(16, "").Tables[0];
                btnSave.Enabled = false;

                if (dtWOFilter.Rows.Count > 0)
                {
                    foreach (DataRow DR in dtWOFilter.Rows)
                    {
                        if (!cmbWONo.Items.Contains(DR["WONumber"].ToString()))
                            cmbWONo.Items.Add(DR["WONumber"].ToString());
                    }
                }
            }
        }


        private void fnPOQtyUpdate()
        {
            foreach (DataGridViewRow DGVR in dgopitemlist.Rows)
            {
                if (DGVR.Cells["WorkDescription"].Value == null)
                {
                    DGVR.Cells["WorkDescription"].Value = "";
                }
                if (DGVR.Cells["IPItem"].Value == null)
                {
                    DGVR.Cells["IPItem"].Value = "";
                    DGVR.Cells["IPReqQty"].Value = "";
                }
                if (DGVR.Cells["OPItemCode"].Value == null)
                {
                    DGVR.Cells["OPItemCode"].Value = "";
                    DGVR.Cells["OPUnitCost"].Value = "";
                    DGVR.Cells["OPAmount"].Value = "";
                }

                GlobalClass.iSuccess = DAL.fnAuthoriseWorkOrder(Global.uUPDATE, cmbWONo.Text, DGVR.Cells["IPItem"].Value.ToString(), DGVR.Cells["IPReqQty"].Value.ToString(),
                                                                  null, null, null, null, null, null);
                GlobalClass.iSuccess = DAL.fnAuthoriseWorkOrder(Global.uINSERT, cmbWONo.Text, DGVR.Cells["OPItemCode"].Value.ToString(), DGVR.Cells["OPReqQty"].Value.ToString(), txtVendorCode.Text,
                                                                   DGVR.Cells["OPUnitCost"].Value.ToString(), DGVR.Cells["OPAmount"].Value.ToString(),
                                                                   DGVR.Cells["WorkDescription"].Value.ToString(), cmbProjectCode.Text, lblProjectStatus.Text);
            }
        }

        private void btnAcceptPO_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(cmbProjectCode.Text) && !string.IsNullOrEmpty(cmbVendorName.Text) && dgopitemlist.Rows.Count > 0 && !string.IsNullOrEmpty(txtRemarks.Text) && cmbEmailAlert.SelectedIndex >= 0)
            {
                //Rakesh
                if (Convert.ToBoolean(login.GetUserDetails[31]) == true)
                {
                    fnPOQtyUpdate();
                    GlobalClass.iSuccess = DAL.WorkOrderApproval(31, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, txtRemarks.Text);
                    fnAlertMail(cmbEmailAlert.Text, txtRemarks.Text);
                    GlobalClass.iSuccess = DAL.fnAddERPLog(0, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, "Work Order approved", "WorkOrder");
                    MessageBox.Show("Work Order '" + cmbWONo.Text + "' approved successfully", "Success", 0, MessageBoxIcon.Information);
                    fnReload();
                }
                //Ravi
                else if (Convert.ToBoolean(login.GetUserDetails[32]) == true)
                {
                    fnPOQtyUpdate();
                    GlobalClass.iSuccess = DAL.WorkOrderApproval(32, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, txtRemarks.Text);
                    fnAlertMail(cmbEmailAlert.Text, txtRemarks.Text);
                    GlobalClass.iSuccess = DAL.fnAddERPLog(0, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, "Work Order approved", "WorkOrder");
                    MessageBox.Show("Work Order '" + cmbWONo.Text + "' approved successfully", "Success", 0, MessageBoxIcon.Information);
                    fnReload();
                }
                // Test Lab
                else if (Convert.ToBoolean(login.GetUserDetails[82]) == true)
                {
                    fnPOQtyUpdate();
                    GlobalClass.iSuccess = DAL.WorkOrderApproval(32, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, txtRemarks.Text);
                    GlobalClass.iSuccess = DAL.WorkOrderApproval(78, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, txtRemarks.Text);

                    GlobalClass.iSuccess = DAL.WorkOrderApproval(29, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, txtRemarks.Text);

                    if (Convert.ToDouble(txtCost.Text) >= 150000)
                    {
                        GlobalClass.iSuccess = DAL.WorkOrderApproval(4, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, "");

                        //fnAlertMail("shreeshail", txtRemarks.Text);
                        fnAlertMail("Hebbarrk", txtRemarks.Text);
                    }
                    else
                    {
                        GlobalClass.iSuccess = DAL.WorkOrderApproval(41, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, "");
                        //fnAlertMail("shreeshail", txtRemarks.Text);
                        fnAlertMailWoGenrate("Suresh Kumar", txtRemarks.Text);

                    }
                    GlobalClass.iSuccess = DAL.fnAddERPLog(0, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, "Work Order approved", "WorkOrder");
                    MessageBox.Show("Work Order '" + cmbWONo.Text + "' approved successfully", "Success", 0, MessageBoxIcon.Information);
                    fnReload();
                }

                //--VISHAL-- Thilak Kumar
                else if (Convert.ToBoolean(login.GetUserDetails[29]) == true)
                {
                    fnPOQtyUpdate();
                    GlobalClass.iSuccess = DAL.WorkOrderApproval(29, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, txtRemarks.Text);

                    if (Convert.ToDouble(txtCost.Text) <= 150000)
                    {
                        GlobalClass.iSuccess = DAL.WorkOrderApproval(8, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, "");
                        //fnAlertMail("shreeshail", txtRemarks.Text);
                        fnAlertMailWoGenrate("Suresh Kumar", txtRemarks.Text);
                    }
                    else if (Convert.ToDouble(txtCost.Text) > 150000 && Convert.ToDouble(txtCost.Text) <= 500000)
                    {
                        GlobalClass.iSuccess = DAL.WorkOrderApproval(9, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, "");
                        //fnAlertMail("shreeshail", txtRemarks.Text);
                        fnAlertMail("Vivek G", txtRemarks.Text);
                    }
                    else if (Convert.ToDouble(txtCost.Text) > 500000)
                    {
                        GlobalClass.iSuccess = DAL.WorkOrderApproval(10, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, "");
                        //fnAlertMail("shreeshail", txtRemarks.Text);
                        fnAlertMail("Vivek G", txtRemarks.Text);
                    }
                    GlobalClass.iSuccess = DAL.fnAddERPLog(0, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, "Work Order approved", "WorkOrder");
                    MessageBox.Show("Work Order '" + cmbWONo.Text + "' approved successfully", "Success", 0, MessageBoxIcon.Information);
                    fnReload();
                }



                else if (Convert.ToBoolean(login.GetUserDetails[85]) == true)
                {
                    fnPOQtyUpdate();
                    GlobalClass.iSuccess = DAL.WorkOrderApproval(11, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, txtRemarks.Text);

                    if (Convert.ToDouble(txtCost.Text) <= 150000)
                    {
                        GlobalClass.iSuccess = DAL.WorkOrderApproval(12, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, "");
                        //fnAlertMail("shreeshail", txtRemarks.Text);
                        fnAlertMailWoGenrate("Suresh Kumar", txtRemarks.Text);//Suresh Kumar
                    }
                    else if (Convert.ToDouble(txtCost.Text) > 150000 && Convert.ToDouble(txtCost.Text) <= 500000)
                    {
                        GlobalClass.iSuccess = DAL.WorkOrderApproval(13, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, "");
                        //fnAlertMail("shreeshail", txtRemarks.Text);
                        fnAlertMailWoGenrate("Suresh Kumar", txtRemarks.Text);
                    }
                    else if (Convert.ToDouble(txtCost.Text) > 500000)
                    {
                        GlobalClass.iSuccess = DAL.WorkOrderApproval(14, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, "");
                        //fnAlertMail("shreeshail", txtRemarks.Text);
                        fnAlertMail("Hebbarrk", txtRemarks.Text);
                    }
                    GlobalClass.iSuccess = DAL.fnAddERPLog(0, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, "Work Order approved", "WorkOrder");
                    MessageBox.Show("Work Order '" + cmbWONo.Text + "' approved successfully", "Success", 0, MessageBoxIcon.Information);
                    fnReload();
                }
                //Theertha Rao
                else if (Convert.ToBoolean(login.GetUserDetails[80]) == true)
                {
                    fnPOQtyUpdate();
                    GlobalClass.iSuccess = DAL.WorkOrderApproval(80, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, txtRemarks.Text);
                    fnAlertMail(cmbEmailAlert.Text, txtRemarks.Text);
                    MessageBox.Show("Work Order '" + cmbWONo.Text + "' approved successfully", "Success", 0, MessageBoxIcon.Information);
                    fnReload();
                }

                //RAMAKRISHNA
                else if (Convert.ToBoolean(login.GetUserDetails[30]) == true)
                {
                    if (!string.IsNullOrEmpty(cmbProjectCode.Text) && !string.IsNullOrEmpty(cmbVendorName.Text) && dgopitemlist.Rows.Count > 0)
                    {
                        GlobalClass.iSuccess = DAL.WorkOrderApproval(42, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, txtRemarks.Text);
                        GlobalClass.iSuccess = DAL.fnAddERPLog(0, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, "Work Order approved", "WorkOrder");
                        MessageBox.Show("Work Order '" + cmbWONo.Text + "' approved successfully", "Success", 0, MessageBoxIcon.Information);
                    }
                    fnReload();
                }
                //MuthuRamalingam
                else if (Convert.ToBoolean(login.GetUserDetails[16]) == true && Convert.ToBoolean(login.GetUserDetails[30]) != true || login.GetUserDetails[2].ToLower() == "lizzy" && Convert.ToBoolean(login.GetUserDetails[30]) != true || login.GetUserDetails[2].ToLower() == "veena" || login.GetUserDetails[2].ToLower() == "pavana" || login.GetUserDetails[2].ToLower() == "hemanth reddy" && Convert.ToBoolean(login.GetUserDetails[30]) != true)
                {
                    if (cmbDeliverTerms.SelectedIndex >= 0 && cmbPaymentTerms.SelectedIndex >= 0)
                    {
                        fnPOQtyUpdate();
                        GlobalClass.iSuccess = DAL.WorkOrderApproval(78, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, txtRemarks.Text);
                        
                        //GlobalClass.iSuccess = DAL.fnAddERPLog(0, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, "Work Order approved", "WorkOrder");
                        MessageBox.Show("Work Order '" + cmbWONo.Text + "' approved successfully", "Success", 0, MessageBoxIcon.Information);

                        DataTable dtCheckDepartment = new DataTable();
                        dtCheckDepartment = DAL.fnUserList(txtPreparedBy.Text).Tables[0];
                        GlobalClass.iSuccess = DAL.fnAddERPLog(0, cmbWONo.Text, login.GetUserDetails[2], dtpWODate.Text, "Work Order approved", "WorkOrder");
                        if (dtCheckDepartment.Rows.Count > 0)
                        {

                            if (dtCheckDepartment.Rows[0]["Department"].ToString() == "Testlab")
                            {
                                
                                fnAlertMail(cmbEmailAlert.Text, txtRemarks.Text);
                                
                                MessageBox.Show("Work Order '" + cmbWONo.Text + "' is Finalized & email alert sent to Manoj", "Success", 0, MessageBoxIcon.Information);

                            }
                            else if (dtCheckDepartment.Rows[0]["Department"].ToString() == "RnD" || dtCheckDepartment.Rows[0]["Department"].ToString() == "Electronics R&D")
                            {
                                
                                fnAlertMail(cmbEmailAlert.Text, txtRemarks.Text);
                                
                                MessageBox.Show("Work Order '" + cmbWONo.Text + "' is Finalized & email alert sent to Somayya", "Success", 0, MessageBoxIcon.Information);
                            }
                            else if (dtCheckDepartment.Rows[0]["Department"].ToString() == "Support" || dtCheckDepartment.Rows[0]["Department"].ToString() == "Design" || dtCheckDepartment.Rows[0]["Department"].ToString() == "Transducer")
                            {
                              
                                fnAlertMail(cmbEmailAlert.Text, txtRemarks.Text);
                                
                                MessageBox.Show("Work Order '" + cmbWONo.Text + "' is Finalized & email alert sent to vishal raina", "Success", 0, MessageBoxIcon.Information);
                            }
                            else if (dtCheckDepartment.Rows[0]["Department"].ToString() == "Support" || dtCheckDepartment.Rows[0]["Department"].ToString() == "Design" || dtCheckDepartment.Rows[0]["Department"].ToString() == "Production" || dtCheckDepartment.Rows[0]["Department"].ToString() == "Assembly")
                            {
                                
                                fnAlertMail(cmbEmailAlert.Text, txtRemarks.Text);
                                
                                MessageBox.Show("Work Order '" + cmbWONo.Text + "' is Finalized & email alert sent to Santhosh", "Success", 0, MessageBoxIcon.Information);
                            }
                            else if (dtCheckDepartment.Rows[0]["Department"].ToString() == "Electrical" || dtCheckDepartment.Rows[0]["Department"].ToString() == "Stores" || dtCheckDepartment.Rows[0]["Department"].ToString() == "Maintenance")
                            {
                                
                                fnAlertMail(cmbEmailAlert.Text, txtRemarks.Text);
                                
                                MessageBox.Show("Work Order '" + cmbWONo.Text + "' is Finalized & email alert sent to Ravi", "Success", 0, MessageBoxIcon.Information);
                            }
                            else if (dtCheckDepartment.Rows[0]["Department"].ToString() == "Validation")
                            {
                                
                                fnAlertMail(cmbEmailAlert.Text, txtRemarks.Text);
                                
                                MessageBox.Show("Work Order '" + cmbWONo.Text + "' is Finalized & email alert sent to Megha", "Success", 0, MessageBoxIcon.Information);
                            }
                            else if (dtCheckDepartment.Rows[0]["Department"].ToString() == "Marketing" || dtCheckDepartment.Rows[0]["Department"].ToString() == "BT" || dtCheckDepartment.Rows[0]["Department"].ToString() == "Order Processing")
                            {
                                //GLobalClass.iSuccess = DAL.purchaseOrderApproval(18, cmbPONO.Text, dtppreparedate.Text, login.GetUserDetails[2], txtRemarks.Text);
                                
                                fnAlertMail(cmbEmailAlert.Text, txtRemarks.Text);
                                
                                MessageBox.Show("Work Order '" + cmbWONo.Text + "' is Finalized & email alert sent to Vivek G", "Success", 0, MessageBoxIcon.Information);
                            }
                            else if (dtCheckDepartment.Rows[0]["Department"].ToString() == "Stores")
                            {
                                fnAlertMail(cmbEmailAlert.Text, txtRemarks.Text);
                                MessageBox.Show("Work Order '" + cmbWONo.Text + "' is Finalized & email alert sent to Muthuramalingam", "Success", 0, MessageBoxIcon.Information);
                            }
                           

                        }
                        fnReload();
                    }
                    else
                    {
                        if (cmbPaymentTerms.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the payment term", "Error", 0, MessageBoxIcon.Error);
                        }
                        else if (cmbDeliverTerms.SelectedIndex < 0)
                        {
                            MessageBox.Show("Select the delivery term", "Error", 0, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            else
            {
                if (string.IsNullOrEmpty(cmbWONo.Text))
                {
                    MessageBox.Show("Work order number is not selected please check ", "Error", 0, MessageBoxIcon.Error);
                    cmbWONo.Focus();
                }
                else if (string.IsNullOrEmpty(cmbProjectCode.Text))
                {
                    MessageBox.Show("Project code is not selected please check ", "Error", 0, MessageBoxIcon.Error);
                    cmbProjectCode.Focus();
                }
                else if (string.IsNullOrEmpty(cmbVendorName.Text))
                {
                    MessageBox.Show("Vendor name is not selected please check ", "Error", 0, MessageBoxIcon.Error);
                    cmbVendorName.Focus();
                }
                else if (string.IsNullOrEmpty(txtRemarks.Text))
                {
                    MessageBox.Show("Please write the remarks", "Error", 0, MessageBoxIcon.Error);
                    txtRemarks.Focus();
                }
                else if (cmbEmailAlert.SelectedIndex < 0)
                {
                    MessageBox.Show("Please select email alert sender name", "Error", 0, MessageBoxIcon.Error);
                    cmbEmailAlert.Focus();
                }
                

            }
        }

        private void fnReload()
        {
            JobWork.frmJObWork JobWork = new frmJObWork();
            this.Hide();
            JobWork.Show();
        }

        private void btnRejectPO_Click(object sender, EventArgs e)
        {
            dtWOFilter = DAL.fnWOFilter(7, cmbWONo.Text).Tables[0];
            if (!string.IsNullOrEmpty(cmbWONo.Text) && !string.IsNullOrEmpty(txtRemarks.Text.Trim()))
            {
                ////Rakesh
                //if (Convert.ToBoolean(login.GetUserDetails[31]) == true)
                //{
                //    string sEmialUser = dtWOFilter.Rows[0]["AuthorisedBy"].ToString();
                //    CreateEMail(sEmialUser, txtPMMHRemarks.Text);
                //    GlobalClass.iSuccess = DAL.WorkOrderApproval(131, cmbWONo.Text, txtPMMHRemarks.Text, "", "");
                //    MessageBox.Show("WO rejected & e-mail alert sent to " + sEmialUser + " ", "Information", 0, MessageBoxIcon.Information);
                //    fnReload();
                //}
                ////Ravi
                //else
                if (Convert.ToBoolean(login.GetUserDetails[32]) == true)
                {
                    string sEmialUser = dtWOFilter.Rows[0]["PMName"].ToString();
                    CreateEMail(sEmialUser, txtRemarks.Text);
                    GlobalClass.iSuccess = DAL.WorkOrderApproval(131, cmbWONo.Text, txtRemarks.Text, "", "");
                    MessageBox.Show("WO rejected & e-mail alert sent to " + sEmialUser + " ", "Information", 0, MessageBoxIcon.Information);
                    fnReload();
                }
                //Vishal Thilak Kumar
                else if (Convert.ToBoolean(login.GetUserDetails[29]) == true)
                {
                    string sEmialUser = dtWOFilter.Rows[0]["FinalizedBy"].ToString();
                    CreateEMail(sEmialUser, txtRemarks.Text);
                    GlobalClass.iSuccess = DAL.WorkOrderApproval(180, cmbWONo.Text, txtRemarks.Text, "", "");
                    MessageBox.Show("WO rejected & e-mail alert sent to " + sEmialUser + " ", "Information", 0, MessageBoxIcon.Information);
                    fnReload();
                }
                //RAMAKRISHNA
                else if (Convert.ToBoolean(login.GetUserDetails[30]) == true)
                {
                    string sEmialUser = dtWOFilter.Rows[0]["FinalizedBy"].ToString();
                    CreateEMail(sEmialUser, txtRemarks.Text);
                    GlobalClass.iSuccess = DAL.WorkOrderApproval(180, cmbWONo.Text, txtRemarks.Text, "", "");
                    MessageBox.Show("WO rejected & e-mail alert sent to " + sEmialUser + " ", "Information", 0, MessageBoxIcon.Information);
                    fnReload();
                }

                else if (Convert.ToBoolean(login.GetUserDetails[85]) == true)
                {
                    string sEmialUser = dtWOFilter.Rows[0]["FinalizedBy"].ToString();
                    CreateEMail(sEmialUser, txtRemarks.Text);
                    GlobalClass.iSuccess = DAL.WorkOrderApproval(180, cmbWONo.Text, txtRemarks.Text, "", "");
                    MessageBox.Show("WO rejected & e-mail alert sent to " + sEmialUser + " ", "Information", 0, MessageBoxIcon.Information);
                    fnReload();
                }
                //Theertha Rao
                else if (Convert.ToBoolean(login.GetUserDetails[80]) == true)
                {
                    string sEmialUser = dtWOFilter.Rows[0]["FinalizedBy"].ToString();
                    CreateEMail(sEmialUser, txtRemarks.Text);
                    GlobalClass.iSuccess = DAL.WorkOrderApproval(180, cmbWONo.Text, txtRemarks.Text, "", "");
                    MessageBox.Show("WO rejected & e-mail alert sent to " + sEmialUser + " ", "Information", 0, MessageBoxIcon.Information);
                    fnReload();
                }
                //MuthuRamalingam
                else if (Convert.ToBoolean(login.GetUserDetails[16]) == true && Convert.ToBoolean(login.GetUserDetails[30]) != true || login.GetUserDetails[2].ToLower() == "lizzy" && Convert.ToBoolean(login.GetUserDetails[30]) != true || login.GetUserDetails[2].ToLower() == "veena" || login.GetUserDetails[2].ToLower() == "pavana" || login.GetUserDetails[2].ToLower() == "hemanth reddy" && Convert.ToBoolean(login.GetUserDetails[30]) != true)
                {
                    string sEmialUser = dtWOFilter.Rows[0]["FinalizedBy"].ToString();
                    CreateEMail(sEmialUser, txtRemarks.Text);
                    GlobalClass.iSuccess = DAL.WorkOrderApproval(180, cmbWONo.Text, txtRemarks.Text, "", "");
                    MessageBox.Show("WO rejected & e-mail alert sent to " + sEmialUser + " ", "Information", 0, MessageBoxIcon.Information);
                    fnReload();
                }
            }
            else
            {
                if (cmbWONo.SelectedIndex < 0)
                {
                    MessageBox.Show("Select PO Number to reject purachase order", "Error", 0, MessageBoxIcon.Error);
                }
                else if (string.IsNullOrEmpty(txtRemarks.Text.Trim()))
                {
                    MessageBox.Show("Please write review reason to review purachase order", "Error", 0, MessageBoxIcon.Error);
                    txtRemarks.Focus();
                }
            }
        }
        bool bMail = false;

        private void CreateEMail(string sUser, string sRemarks)
        {
            try
            {
                bMail = false;
                DataTable dtlogindetails = DAL.fnloginemail(sUser).Tables[0]; ;
                if (dtlogindetails.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
                    {
                        Outlook.Application oApp = new Outlook.Application();
                        Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);


                        if (sUser != "Hebbarrk")
                        {
                            oMsg.Subject = "" + cmbWONo.Text + " sent back for review";
                            oMsg.HTMLBody = " Dear " + sUser.ToUpper() + ", <br /><br /><font color='red'> Work Order " + cmbWONo.Text + " sent back for review.<br /><br /> Review reason : " + sRemarks + "</font> <br /> <br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";
                        }
                        else
                        {
                            oMsg.Subject = "" + cmbWONo.Text + " sent for approval";
                            oMsg.HTMLBody = " Dear " + sUser.ToUpper() + ", <br /><br /> Work Order <font color='blue'>" + cmbWONo.Text + "</font> sent for approval.<br /> Purchase commitee : " + sRemarks + " <br /> <br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";
                        }
                        // Add a recipient.
                        Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                        oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                        oRecips.ResolveAll();
                        // Send.
                        oMsg.Send();
                        bMail = true;
                        // Clean up.
                        oRecips = null;
                        oMsg = null;
                        oApp = null;
                    }
                }

                //if (bMail == true)
                //{
                //    MessageBox.Show("Mail alert sent to '" + sUser + "' successfully!", "Success", 0, MessageBoxIcon.Information);
                //}
            }
            catch (Exception ex)
            {

            }
        }


        private void txtItemDescription_MouseClick(object sender, MouseEventArgs e)
        {
            if (!string.IsNullOrEmpty(cmbProjectCode.Text))
            {
                if (dtItemList.Rows.Count == 0)
                {
                    dtItemList = DAL.fnItemList(null).Tables[0];
                    RowFilter();
                }
                if (Convert.ToBoolean(dtProjectBOMdetails.Rows[0]["BOMProject"].ToString()) == true)
                {
                    if (cmbbomname.SelectedIndex < 0)
                    {
                        MessageBox.Show("Select project BOM for genarating work order ", "Error", 0, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Select project code for genarating work order ", "Error", 0, MessageBoxIcon.Error);
            }

        }

        private void cmbWorkDescription_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbWorkDescription.Visible == true)
            {
                if (dgopitemlist.CurrentCell.OwningColumn.Name == "WorkDescription")
                {
                    dgopitemlist.CurrentCell.Value = cmbWorkDescription.Text.ToString();
                    cmbWorkDescription.Visible = false;
                }
            }
        }
        string[] sProductCode;
        DataTable dtprojectBOMItems = new DataTable();
        DataTable dtMachineBOMProduct = new DataTable();
        private void cmbbomname_SelectedIndexChanged(object sender, EventArgs e)
        {
            sProductCode = cmbbomname.Text.Split('`');
            dtprojectBOMItems = DAL.fnProjectBOMProdutnamenumber(sProductCode[0], cmbProjectCode.Text, sProductCode[1], sProductCode[2]).Tables[0];
            if (dtprojectBOMItems.Rows.Count > 0)
            {
                lblProductName.Text = dtprojectBOMItems.Rows[0]["ProductName"].ToString() + " - " + dtprojectBOMItems.Rows[0]["ProductType"].ToString();
                lblVersion.Text = dtprojectBOMItems.Rows[0]["ProductNo"].ToString();

                dtMachineBOMProduct = DAL.fnGetIndentMachineBOM(dtprojectBOMItems.Rows[0]["ProjectBOMCode"].ToString(), dtprojectBOMItems.Rows[0]["ProductNo"].ToString(), cmbProjectCode.Text, null).Tables[0];

                if (dtMachineBOMProduct.Rows.Count > 0)
                {

                    chklbItemList.Items.Clear();
                    //foreach (DataRow dr in dtMachineBOMProduct.Rows)
                    //{
                    //    if (Convert.ToDouble(dr["IndentQty"].ToString()) > Convert.ToDouble(dr["AvailableQty"].ToString()))
                    //    {
                    //        dr["IndentQty"] = Convert.ToDouble(dr["AvailableQty"].ToString());
                    //    }
                    //}
                }
                //  dgBOMIndent.ReadOnly = false;

                foreach (DataRow dr in dtMachineBOMProduct.Rows)
                {
                    chklbItemList.Items.Add(string.Concat(dr["ID"].ToString(), ") ", dr["ItemCode"].ToString(), ", ", dr["ItemDescription"].ToString(), ", ", dr["AvailableQty"].ToString()));

                }
                pnItemAdd.Enabled = true;
            }
        }

        private string sBOMMessage = "";
        private void chkWithoutBOM_CheckedChanged(object sender, EventArgs e)
        {
            if (chkWithoutBOM.Checked == true)
            {
                sBOMMessage = "Please note the work order created without BOM.";
            }
            else
            {
                sBOMMessage = "";
            }
        }

        private void cmbProjectCode_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            sWOform = 1;
            Indent.frmProjectselect projectsearch = new Indent.frmProjectselect();
            projectsearch.fnWOform = sWOform.ToString();
            projectsearch.ShowDialog();
            if (fnProjectcode != null)
            {
                cmbProjectCode.Text = sProjectCode;
            }
        }

        private void cmbProjectCode_TextChanged(object sender, EventArgs e)
        {
            if (!bNewWorkOrder)
            {
                dtProjectBOMdetails = DAL.fnWIPProjectCode(cmbProjectCode.Text).Tables[0];

                if (dtProjectBOMdetails.Rows.Count > 0)
                {
                    if (dgopitemlist.Rows.Count > 0)
                    {
                        DialogResult DR = MessageBox.Show("If project changed all the selected items will be cleared. Do you want to proceed ?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        if (DR == DialogResult.Yes)
                        {

                            dgopitemlist.DataSource = null;
                            dgopitemlist.Rows.Clear();
                        }
                    }

                    txtProjectName.Text = dtProjectBOMdetails.Rows[0]["ProjectDescription"].ToString();
                    //lblcustomername.Text = dtProjectBOMdetails.Rows[0]["Customer"].ToString();
                    //pnitemlist.Enabled = true;
                    lblProjectStatus.Text = dtProjectBOMdetails.Rows[0]["Status"].ToString();
                    if (Convert.ToBoolean(dtProjectBOMdetails.Rows[0]["BOMProject"].ToString()) == true)
                    {
                        chkWithoutBOM.Checked = false;
                        // dgBOMIndent.Visible = true;
                        // dgIndentList.Visible = false;
                        DataTable dtProjectBOM = DAL.fnProjectBOMIndentList(cmbProjectCode.Text).Tables[0];
                        cmbbomname.Items.Clear();
                        cmbbomname.Enabled = true;
                        lblprojectbom.Enabled = true;
                        chklbItemList.Items.Clear();
                        // pnitemlist.Enabled = false;
                        lblprdname.Enabled = true;
                        lblProductName.ResetText();
                        lblVersion.ResetText();
                        foreach (DataRow DR in dtProjectBOM.Rows)
                        {
                            cmbbomname.Items.Add(DR["ProductCode"].ToString() + "`" + DR["ProductType"].ToString() + "`" + DR["ProductName"].ToString());
                        }
                        if (cmbbomname.Items.Count > 0)
                        {
                            cmbbomname.Enabled = true;
                        }
                        else
                        {
                            cmbbomname.Enabled = false;
                        }
                        dgopitemlist.DataSource = null;
                    }
                    else
                    {
                        chkWithoutBOM.Checked = true;
                        lblprdname.Enabled = false;
                        lblProductName.ResetText();
                        dgopitemlist.DataSource = null;
                        // pnitemlist.Enabled = true;
                        chklbItemList.Items.Clear();
                        cmbbomname.Items.Clear();
                        cmbbomname.Enabled = false;
                        lblprojectbom.Enabled = false;
                    }
                }
            }
            else
            {
                if (string.IsNullOrEmpty(cmbProjectCode.Text))
                {
                    cmbProjectCode.Text = string.Empty;
                }
                else
                {
                    DataView dvProject = new DataView(dtWIPProjectlist);
                    dvProject.RowFilter = "ProjectCode Like'" + cmbProjectCode.Text + "'";
                    DataTable dtrow = dvProject.ToTable();
                    if (dtrow.Rows.Count > 0)
                    {
                        txtProjectName.Text = dtrow.Rows[0]["ProjectDescription"].ToString();
                        lblProjectStatus.Text = dtrow.Rows[0]["Status"].ToString();
                    }
                }
            }
        }

        private void btnrepeatorder_Click(object sender, EventArgs e)
        {
            pleasewaitform pleaseWait = new pleasewaitform();
            pleaseWait.Show();
            Application.DoEvents();
            Purchase_Order.RepeatOrder repeatorder = new Purchase_Order.RepeatOrder();
            repeatorder.Show();
            pleaseWait.Hide();
        }

        private void btnloadpolist_Click(object sender, EventArgs e)
        {
            //MuthuRamalingam
            if (Convert.ToBoolean(login.GetUserDetails[16]) == true && Convert.ToBoolean(login.GetUserDetails[30]) != true || login.GetUserDetails[2].ToLower() == "lizzy" && Convert.ToBoolean(login.GetUserDetails[30]) != true || login.GetUserDetails[2].ToLower() == "veena" || login.GetUserDetails[2].ToLower() == "pavana" || login.GetUserDetails[2].ToLower() == "hemanth reddy" && Convert.ToBoolean(login.GetUserDetails[30]) != true)
            {
                btnWOGenerate.Enabled = true;
                btnAcceptPO.Enabled = true;
                btnRejectPO.Enabled = true;
                cmbWONo.Enabled = true;
                pnItemAdd.Enabled = false;
                cmbWONo.Text = "";
                cmbWONo.Items.Clear();
                dtWOFilter = DAL.fnWOFilter(161, "").Tables[0];
                btnSave.Enabled = false;

                if (dtWOFilter.Rows.Count > 0)
                {
                    foreach (DataRow DR in dtWOFilter.Rows)
                    {
                        if (!cmbWONo.Items.Contains(DR["WONumber"].ToString()))
                            cmbWONo.Items.Add(DR["WONumber"].ToString());
                    }
                }
            }
        }
        DataTable dtRemarksHistory = new DataTable();
        private void fnLoadComments()
        {

            DataTable dtCheckDepartment = new DataTable();
            dtCheckDepartment = DAL.fnUserList(txtPreparedBy.Text).Tables[0];
            if (dtCheckDepartment.Rows.Count > 0)
            {

                if (dtCheckDepartment.Rows[0]["Department"].ToString() == "Testlab")
                {
                    dtRemarksHistory = DAL.PORemarksHistory(3, cmbWONo.Text).Tables[0];
                    dgvRemarks.Visible = true;
                    if (dtRemarksHistory.Rows.Count > 0)
                    {
                        for (int i = dtRemarksHistory.Rows.Count - 1; i >= 0; i--)
                        {
                            if (dtRemarksHistory.Rows[i][0] == DBNull.Value)
                                dtRemarksHistory.Rows[i].Delete();
                        }
                        dtRemarksHistory.AcceptChanges();
                        dgvRemarks.AutoGenerateColumns = false;
                        dgvRemarks.DataSource = dtRemarksHistory;
                    }
                }
                else
                {
                    dtRemarksHistory = DAL.PORemarksHistory(7, cmbWONo.Text).Tables[0];
                    dgvRemarks.Visible = true;
                    if (dtRemarksHistory.Rows.Count > 0)
                    {
                        for (int i = dtRemarksHistory.Rows.Count - 1; i >= 0; i--)
                        {
                            if (dtRemarksHistory.Rows[i][0] == DBNull.Value)
                                dtRemarksHistory.Rows[i].Delete();
                        }
                        dtRemarksHistory.AcceptChanges();
                        dgvRemarks.AutoGenerateColumns = false;
                        dgvRemarks.DataSource = dtRemarksHistory;
                    }
                }
            }
        }
        private void llbViewRemakrs_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (llbViewRemakrs.Text == "View remarks of all users")
            {
                fnLoadComments();
                llbViewRemakrs.Text = "Hide remarks of all users";
            }
            else if (llbViewRemakrs.Text == "Hide remarks of all users")
            {
                dgvRemarks.Visible = false;
                llbViewRemakrs.Text = "View remarks of all users";
            }
        }

        private void cmbEmailAlert_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
