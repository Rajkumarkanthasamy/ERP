﻿
namespace Erp_Project_With_Buttons.Project_Master
{
    partial class frmProjectDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProjectDetails));
            this.label2 = new System.Windows.Forms.Label();
            this.lblprojname = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dtpTimeSheetDate = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbProjectcode = new System.Windows.Forms.ComboBox();
            this.btnProjectSearch = new System.Windows.Forms.Button();
            this.dgvTimeSheet = new System.Windows.Forms.DataGridView();
            this.Paymentterms = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PDIatBiSS = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LDclause = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.StandardCustom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectET = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Customization = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectFocal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SubTask = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TotalHours = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Remarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RangeCapacity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductSerialNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTimeSheet)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(91, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 19);
            this.label2.TabIndex = 192;
            this.label2.Text = "Date :";
            // 
            // lblprojname
            // 
            this.lblprojname.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprojname.ForeColor = System.Drawing.Color.Black;
            this.lblprojname.Location = new System.Drawing.Point(144, 82);
            this.lblprojname.Name = "lblprojname";
            this.lblprojname.Size = new System.Drawing.Size(407, 41);
            this.lblprojname.TabIndex = 189;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(30, 84);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 19);
            this.label6.TabIndex = 186;
            this.label6.Text = "Project Name :";
            // 
            // dtpTimeSheetDate
            // 
            this.dtpTimeSheetDate.CustomFormat = "";
            this.dtpTimeSheetDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpTimeSheetDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpTimeSheetDate.Location = new System.Drawing.Point(148, 4);
            this.dtpTimeSheetDate.Name = "dtpTimeSheetDate";
            this.dtpTimeSheetDate.Size = new System.Drawing.Size(125, 26);
            this.dtpTimeSheetDate.TabIndex = 185;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(36, 42);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(104, 19);
            this.label8.TabIndex = 182;
            this.label8.Text = "Project Code :";
            // 
            // cmbProjectcode
            // 
            this.cmbProjectcode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProjectcode.DropDownHeight = 130;
            this.cmbProjectcode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProjectcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProjectcode.FormattingEnabled = true;
            this.cmbProjectcode.IntegralHeight = false;
            this.cmbProjectcode.Location = new System.Drawing.Point(148, 40);
            this.cmbProjectcode.Name = "cmbProjectcode";
            this.cmbProjectcode.Size = new System.Drawing.Size(344, 26);
            this.cmbProjectcode.TabIndex = 183;
            // 
            // btnProjectSearch
            // 
            this.btnProjectSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnProjectSearch.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProjectSearch.Location = new System.Drawing.Point(498, 42);
            this.btnProjectSearch.Name = "btnProjectSearch";
            this.btnProjectSearch.Size = new System.Drawing.Size(24, 24);
            this.btnProjectSearch.TabIndex = 184;
            this.btnProjectSearch.Text = "....";
            this.btnProjectSearch.UseVisualStyleBackColor = false;
            // 
            // dgvTimeSheet
            // 
            this.dgvTimeSheet.AllowUserToAddRows = false;
            this.dgvTimeSheet.AllowUserToDeleteRows = false;
            this.dgvTimeSheet.AllowUserToOrderColumns = true;
            this.dgvTimeSheet.AllowUserToResizeRows = false;
            this.dgvTimeSheet.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dgvTimeSheet.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvTimeSheet.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTimeSheet.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvTimeSheet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTimeSheet.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Paymentterms,
            this.PDIatBiSS,
            this.LDclause,
            this.ProjectType,
            this.StandardCustom,
            this.ProjectET,
            this.Customization,
            this.ProjectFocal,
            this.SubTask,
            this.TotalHours,
            this.Remarks,
            this.RangeCapacity,
            this.ProductCode,
            this.ProductName,
            this.ProductSerialNumber});
            this.dgvTimeSheet.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvTimeSheet.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvTimeSheet.EnableHeadersVisualStyles = false;
            this.dgvTimeSheet.Location = new System.Drawing.Point(27, 126);
            this.dgvTimeSheet.MultiSelect = false;
            this.dgvTimeSheet.Name = "dgvTimeSheet";
            this.dgvTimeSheet.RowHeadersVisible = false;
            this.dgvTimeSheet.Size = new System.Drawing.Size(1243, 132);
            this.dgvTimeSheet.TabIndex = 193;
            // 
            // Paymentterms
            // 
            this.Paymentterms.DataPropertyName = "Payment terms";
            this.Paymentterms.Frozen = true;
            this.Paymentterms.HeaderText = "Payment Terms";
            this.Paymentterms.Name = "Paymentterms";
            this.Paymentterms.ReadOnly = true;
            this.Paymentterms.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Paymentterms.Width = 109;
            // 
            // PDIatBiSS
            // 
            this.PDIatBiSS.DataPropertyName = "PDI at BiSS";
            this.PDIatBiSS.Frozen = true;
            this.PDIatBiSS.HeaderText = "PDI at BiSS";
            this.PDIatBiSS.Name = "PDIatBiSS";
            this.PDIatBiSS.ReadOnly = true;
            this.PDIatBiSS.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PDIatBiSS.Width = 79;
            // 
            // LDclause
            // 
            this.LDclause.DataPropertyName = "LD clause";
            this.LDclause.Frozen = true;
            this.LDclause.HeaderText = "LD Clause";
            this.LDclause.Name = "LDclause";
            this.LDclause.ReadOnly = true;
            this.LDclause.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.LDclause.Width = 73;
            // 
            // ProjectType
            // 
            this.ProjectType.DataPropertyName = "ProjectType";
            this.ProjectType.Frozen = true;
            this.ProjectType.HeaderText = "Machine/Retrofit/Accessories";
            this.ProjectType.Name = "ProjectType";
            this.ProjectType.ReadOnly = true;
            this.ProjectType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectType.Width = 198;
            // 
            // StandardCustom
            // 
            this.StandardCustom.DataPropertyName = "StandardCustom";
            this.StandardCustom.Frozen = true;
            this.StandardCustom.HeaderText = "StandardCustom";
            this.StandardCustom.Name = "StandardCustom";
            this.StandardCustom.ReadOnly = true;
            this.StandardCustom.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.StandardCustom.Width = 116;
            // 
            // ProjectET
            // 
            this.ProjectET.DataPropertyName = "project8020";
            this.ProjectET.Frozen = true;
            this.ProjectET.HeaderText = "80/20";
            this.ProjectET.Name = "ProjectET";
            this.ProjectET.ReadOnly = true;
            this.ProjectET.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectET.Width = 48;
            // 
            // Customization
            // 
            this.Customization.DataPropertyName = "customizationlevel";
            this.Customization.Frozen = true;
            this.Customization.HeaderText = "Cust*";
            this.Customization.Name = "Customization";
            this.Customization.ReadOnly = true;
            this.Customization.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Customization.Width = 48;
            // 
            // ProjectFocal
            // 
            this.ProjectFocal.DataPropertyName = "Project Focal";
            this.ProjectFocal.Frozen = true;
            this.ProjectFocal.HeaderText = "ProjectFocal";
            this.ProjectFocal.Name = "ProjectFocal";
            this.ProjectFocal.ReadOnly = true;
            this.ProjectFocal.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectFocal.Width = 90;
            // 
            // SubTask
            // 
            this.SubTask.DataPropertyName = "SubTask";
            this.SubTask.Frozen = true;
            this.SubTask.HeaderText = "Sub Task";
            this.SubTask.Name = "SubTask";
            this.SubTask.ReadOnly = true;
            this.SubTask.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.SubTask.Width = 66;
            // 
            // TotalHours
            // 
            this.TotalHours.DataPropertyName = "TotalHours";
            this.TotalHours.Frozen = true;
            this.TotalHours.HeaderText = "TotalHours";
            this.TotalHours.Name = "TotalHours";
            this.TotalHours.ReadOnly = true;
            this.TotalHours.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.TotalHours.Width = 80;
            // 
            // Remarks
            // 
            this.Remarks.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Remarks.DataPropertyName = "Remarks";
            this.Remarks.Frozen = true;
            this.Remarks.HeaderText = "Remarks";
            this.Remarks.Name = "Remarks";
            this.Remarks.ReadOnly = true;
            this.Remarks.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Remarks.Width = 67;
            // 
            // RangeCapacity
            // 
            this.RangeCapacity.DataPropertyName = "RangeCapacity";
            this.RangeCapacity.Frozen = true;
            this.RangeCapacity.HeaderText = "Range/Capacity";
            this.RangeCapacity.Name = "RangeCapacity";
            this.RangeCapacity.ReadOnly = true;
            this.RangeCapacity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.RangeCapacity.Width = 110;
            // 
            // ProductCode
            // 
            this.ProductCode.DataPropertyName = "ProductCode";
            this.ProductCode.HeaderText = "ProductCode";
            this.ProductCode.Name = "ProductCode";
            this.ProductCode.ReadOnly = true;
            this.ProductCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductCode.Width = 94;
            // 
            // ProductName
            // 
            this.ProductName.DataPropertyName = "ProductName";
            this.ProductName.HeaderText = "ProductName";
            this.ProductName.Name = "ProductName";
            this.ProductName.ReadOnly = true;
            this.ProductName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductName.Width = 99;
            // 
            // ProductSerialNumber
            // 
            this.ProductSerialNumber.DataPropertyName = "ProductSerialNumber";
            this.ProductSerialNumber.HeaderText = "ProductSerialNumber";
            this.ProductSerialNumber.Name = "ProductSerialNumber";
            this.ProductSerialNumber.ReadOnly = true;
            this.ProductSerialNumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProductSerialNumber.Width = 148;
            // 
            // frmProjectDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1291, 524);
            this.Controls.Add(this.dgvTimeSheet);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblprojname);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dtpTimeSheetDate);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.cmbProjectcode);
            this.Controls.Add(this.btnProjectSearch);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmProjectDetails";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Project Details";
            this.Load += new System.EventHandler(this.frmProjectDetails_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTimeSheet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblprojname;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker dtpTimeSheetDate;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbProjectcode;
        private System.Windows.Forms.Button btnProjectSearch;
        private System.Windows.Forms.DataGridView dgvTimeSheet;
        private System.Windows.Forms.DataGridViewTextBoxColumn Paymentterms;
        private System.Windows.Forms.DataGridViewTextBoxColumn PDIatBiSS;
        private System.Windows.Forms.DataGridViewTextBoxColumn LDclause;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectType;
        private System.Windows.Forms.DataGridViewTextBoxColumn StandardCustom;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectET;
        private System.Windows.Forms.DataGridViewTextBoxColumn Customization;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectFocal;
        private System.Windows.Forms.DataGridViewTextBoxColumn SubTask;
        private System.Windows.Forms.DataGridViewTextBoxColumn TotalHours;
        private System.Windows.Forms.DataGridViewTextBoxColumn Remarks;
        private System.Windows.Forms.DataGridViewTextBoxColumn RangeCapacity;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductSerialNumber;
    }
}
