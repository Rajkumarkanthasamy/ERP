﻿namespace Erp_Project_With_Buttons.Project_Master
{
    partial class frmProjectApprove
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProjectApprove));
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtProjectDescription = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbProjectcode = new System.Windows.Forms.ComboBox();
            this.btnProjectSearch = new System.Windows.Forms.Button();
            this.lstusers = new System.Windows.Forms.ListBox();
            this.cmbDepartment = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lblsearch = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.dtpIndentDate = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Enabled = false;
            this.txtCustomerName.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtCustomerName.Location = new System.Drawing.Point(199, 166);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(408, 26);
            this.txtCustomerName.TabIndex = 205;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(83, 97);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(110, 19);
            this.label20.TabIndex = 203;
            this.label20.Text = "Project Name :";
            // 
            // txtProjectDescription
            // 
            this.txtProjectDescription.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtProjectDescription.Location = new System.Drawing.Point(199, 97);
            this.txtProjectDescription.Multiline = true;
            this.txtProjectDescription.Name = "txtProjectDescription";
            this.txtProjectDescription.ReadOnly = true;
            this.txtProjectDescription.Size = new System.Drawing.Size(408, 53);
            this.txtProjectDescription.TabIndex = 202;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(111, 168);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(82, 19);
            this.label21.TabIndex = 204;
            this.label21.Text = "Customer :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(89, 52);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(104, 19);
            this.label8.TabIndex = 199;
            this.label8.Text = "Project Code :";
            // 
            // cmbProjectcode
            // 
            this.cmbProjectcode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProjectcode.DropDownHeight = 130;
            this.cmbProjectcode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProjectcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProjectcode.FormattingEnabled = true;
            this.cmbProjectcode.IntegralHeight = false;
            this.cmbProjectcode.Location = new System.Drawing.Point(199, 52);
            this.cmbProjectcode.Name = "cmbProjectcode";
            this.cmbProjectcode.Size = new System.Drawing.Size(378, 26);
            this.cmbProjectcode.TabIndex = 200;
            this.cmbProjectcode.SelectedIndexChanged += new System.EventHandler(this.cmbProjectcode_SelectedIndexChanged);
            // 
            // btnProjectSearch
            // 
            this.btnProjectSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnProjectSearch.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProjectSearch.Location = new System.Drawing.Point(583, 54);
            this.btnProjectSearch.Name = "btnProjectSearch";
            this.btnProjectSearch.Size = new System.Drawing.Size(24, 24);
            this.btnProjectSearch.TabIndex = 201;
            this.btnProjectSearch.Text = "....";
            this.btnProjectSearch.UseVisualStyleBackColor = false;
            this.btnProjectSearch.Click += new System.EventHandler(this.btnProjectSearch_Click);
            // 
            // lstusers
            // 
            this.lstusers.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstusers.FormattingEnabled = true;
            this.lstusers.ItemHeight = 19;
            this.lstusers.Location = new System.Drawing.Point(199, 260);
            this.lstusers.Name = "lstusers";
            this.lstusers.ScrollAlwaysVisible = true;
            this.lstusers.Size = new System.Drawing.Size(332, 213);
            this.lstusers.TabIndex = 209;
            this.lstusers.KeyUp += new System.Windows.Forms.KeyEventHandler(this.lstusers_KeyUp);
            // 
            // cmbDepartment
            // 
            this.cmbDepartment.DropDownHeight = 80;
            this.cmbDepartment.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDepartment.FormattingEnabled = true;
            this.cmbDepartment.IntegralHeight = false;
            this.cmbDepartment.ItemHeight = 19;
            this.cmbDepartment.Location = new System.Drawing.Point(199, 213);
            this.cmbDepartment.MaxDropDownItems = 4;
            this.cmbDepartment.Name = "cmbDepartment";
            this.cmbDepartment.Size = new System.Drawing.Size(332, 27);
            this.cmbDepartment.TabIndex = 208;
            this.cmbDepartment.SelectedIndexChanged += new System.EventHandler(this.cmbDepartment_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(38, 260);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(155, 19);
            this.label3.TabIndex = 206;
            this.label3.Text = "Added Departments :";
            // 
            // lblsearch
            // 
            this.lblsearch.AutoSize = true;
            this.lblsearch.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsearch.ForeColor = System.Drawing.Color.Black;
            this.lblsearch.Location = new System.Drawing.Point(48, 213);
            this.lblsearch.Name = "lblsearch";
            this.lblsearch.Size = new System.Drawing.Size(145, 19);
            this.lblsearch.TabIndex = 207;
            this.lblsearch.Text = "Select Department :";
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(574, 510);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(88, 44);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(405, 510);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(88, 44);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // dtpIndentDate
            // 
            this.dtpIndentDate.Checked = false;
            this.dtpIndentDate.Enabled = false;
            this.dtpIndentDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpIndentDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpIndentDate.Location = new System.Drawing.Point(624, 94);
            this.dtpIndentDate.Name = "dtpIndentDate";
            this.dtpIndentDate.Size = new System.Drawing.Size(88, 26);
            this.dtpIndentDate.TabIndex = 210;
            // 
            // frmProjectApprove
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(724, 566);
            this.Controls.Add(this.dtpIndentDate);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.lstusers);
            this.Controls.Add(this.cmbDepartment);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblsearch);
            this.Controls.Add(this.txtCustomerName);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.txtProjectDescription);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.cmbProjectcode);
            this.Controls.Add(this.btnProjectSearch);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmProjectApprove";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Project Department Approve";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmProjectApprove_FormClosing);
            this.Load += new System.EventHandler(this.frmProjectApprove_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtProjectDescription;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbProjectcode;
        private System.Windows.Forms.Button btnProjectSearch;
        private System.Windows.Forms.ListBox lstusers;
        private System.Windows.Forms.ComboBox cmbDepartment;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblsearch;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.DateTimePicker dtpIndentDate;
    }
}