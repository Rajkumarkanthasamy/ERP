﻿using System;
using System.Data;
using System.Windows.Forms;
using Outlook = Microsoft.Office.Interop.Outlook;

namespace Erp_Project_With_Buttons.Project_Master
{
    public partial class frmPorjectMail : Form
    {
        DataTable dtUserName = new DataTable();
        DataTable dtOldUserNames = new DataTable();
        DataAccessLayer DAL = new DataAccessLayer();
        Global GLobalClass = new Global();
        Login.frmLoginForm LoginForm = new Login.frmLoginForm();
        DataTable dtProjectDetails = new DataTable();
        public frmPorjectMail()
        {
            InitializeComponent();
        }

        private void frmPorjectMail_Load(object sender, EventArgs e)
        {
            dtUserName = DAL.fnUserList(null).Tables[0];
            dtProjectDetails = DAL.fnEmailProjectDetails().Tables[0];

            foreach (DataRow DR in dtUserName.Rows)
            {
                if (!cmbusername.Items.Contains(DR["UserName"].ToString()))
                    cmbusername.Items.Add(DR["UserName"].ToString());
            }

            lstusers.Items.Clear();
        }

        private void cmbusername_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!lstusers.Items.Contains(cmbusername.Text))
            {
                lstusers.Items.Add(cmbusername.Text);
            }
        }
        DataTable dtlogindetails = new DataTable();
        bool bMail = false;
        private void btnEmail_Click(object sender, EventArgs e)
        {
            if (lstusers.Items.Count > 0)
            {
                bMail = false;
                string sCustomer = dtProjectDetails.Rows[0]["ProjectDescription"].ToString();
                sCustomer = sCustomer.Replace("\n", "");
                foreach (var listBoxItem in lstusers.Items)
                {
                    dtlogindetails = DAL.fnloginemail(listBoxItem.ToString()).Tables[0]; ;
                    if (dtlogindetails.Rows.Count > 0)
                    {
                        if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
                        {
                            try
                            {
                                Outlook.Application oApp = new Outlook.Application();
                                Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);
                                oMsg.Subject = "New Project Code For '" + sCustomer + "'";
                                oMsg.HTMLBody = " Dear " + listBoxItem.ToString().ToUpper() + ", <br /><br /> New project code  " + dtProjectDetails.Rows[0]["ProjectCode"].ToString() + " is created for project ' " + dtProjectDetails.Rows[0]["ProjectDescription"].ToString() + " ' in ERP. <br /> <br />Regards, <br /> " + dtProjectDetails.Rows[0]["CreatedBy"].ToString().ToUpper() + ".  <br /> <br /> ** THIS IS AN AUTO GENARATED EMAIL. PLEASE DO NOT REPLY **";
                                // Add a recipient.
                                Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                                oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                                oRecips.ResolveAll();
                                // Send.
                                oMsg.Send();
                                bMail = true;
                                // Clean up.
                                oRecips = null;
                                oMsg = null;
                                oApp = null;

                            }
                            catch (Exception ex)
                            {
                                bMail = false;
                                MessageBox.Show("Error: " + ex.Message);
                            }
                        }
                    }
                }
                if (bMail == true)
                {
                    MessageBox.Show("Mail sent to the selected users successfully!", "E-mail Sent", 0, MessageBoxIcon.Information);
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("Please select the user(s) to send E-mail", "Error", 0, MessageBoxIcon.Error);
            }

        }

        private void lstusers_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                lstusers.Items.Remove(lstusers.SelectedItem);
            }
        }

        private void lstusers_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
