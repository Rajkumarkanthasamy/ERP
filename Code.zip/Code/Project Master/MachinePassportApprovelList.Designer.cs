﻿
namespace Erp_Project_With_Buttons.Project_Master
{
    partial class MachinePassportApprovelList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MachinePassportApprovelList));
            this.dgApproveProjectList = new System.Windows.Forms.DataGridView();
            this.ProjectCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gbSearchOptions = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtMpApproveRemarks = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btnLoadProjects = new System.Windows.Forms.Button();
            this.dtpPMCreatedDate = new System.Windows.Forms.DateTimePicker();
            this.lblIteType = new System.Windows.Forms.Label();
            this.butAccept = new System.Windows.Forms.Button();
            this.butreject = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnExit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgApproveProjectList)).BeginInit();
            this.gbSearchOptions.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgApproveProjectList
            // 
            this.dgApproveProjectList.AllowUserToAddRows = false;
            this.dgApproveProjectList.AllowUserToDeleteRows = false;
            this.dgApproveProjectList.AllowUserToResizeRows = false;
            this.dgApproveProjectList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgApproveProjectList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgApproveProjectList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgApproveProjectList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgApproveProjectList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgApproveProjectList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProjectCode,
            this.ProjectDescription,
            this.Status});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgApproveProjectList.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgApproveProjectList.EnableHeadersVisualStyles = false;
            this.dgApproveProjectList.Location = new System.Drawing.Point(22, 86);
            this.dgApproveProjectList.Name = "dgApproveProjectList";
            this.dgApproveProjectList.RowHeadersVisible = false;
            this.dgApproveProjectList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgApproveProjectList.Size = new System.Drawing.Size(1313, 523);
            this.dgApproveProjectList.TabIndex = 10;
            this.dgApproveProjectList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgProjectList_CellContentClick);
            // 
            // ProjectCode
            // 
            this.ProjectCode.DataPropertyName = "ProjectCode";
            this.ProjectCode.Frozen = true;
            this.ProjectCode.HeaderText = "ProjectCode";
            this.ProjectCode.Name = "ProjectCode";
            this.ProjectCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectCode.Width = 102;
            // 
            // ProjectDescription
            // 
            this.ProjectDescription.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.ProjectDescription.DataPropertyName = "ProjectDescription";
            this.ProjectDescription.Frozen = true;
            this.ProjectDescription.HeaderText = "Project Name";
            this.ProjectDescription.Name = "ProjectDescription";
            this.ProjectDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectDescription.Width = 235;
            // 
            // Status
            // 
            this.Status.DataPropertyName = "Status";
            this.Status.Frozen = true;
            this.Status.HeaderText = "Status";
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            this.Status.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Status.Width = 60;
            // 
            // gbSearchOptions
            // 
            this.gbSearchOptions.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.gbSearchOptions.Controls.Add(this.label1);
            this.gbSearchOptions.Controls.Add(this.txtMpApproveRemarks);
            this.gbSearchOptions.Controls.Add(this.button1);
            this.gbSearchOptions.Controls.Add(this.btnLoadProjects);
            this.gbSearchOptions.Controls.Add(this.dtpPMCreatedDate);
            this.gbSearchOptions.Controls.Add(this.lblIteType);
            this.gbSearchOptions.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.gbSearchOptions.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbSearchOptions.Location = new System.Drawing.Point(22, 12);
            this.gbSearchOptions.Name = "gbSearchOptions";
            this.gbSearchOptions.Size = new System.Drawing.Size(1313, 68);
            this.gbSearchOptions.TabIndex = 9;
            this.gbSearchOptions.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(486, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 18);
            this.label1.TabIndex = 489;
            this.label1.Text = "Remarks:";
            // 
            // txtMpApproveRemarks
            // 
            this.txtMpApproveRemarks.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtMpApproveRemarks.Location = new System.Drawing.Point(563, 19);
            this.txtMpApproveRemarks.MaxLength = 1000;
            this.txtMpApproveRemarks.Multiline = true;
            this.txtMpApproveRemarks.Name = "txtMpApproveRemarks";
            this.txtMpApproveRemarks.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtMpApproveRemarks.Size = new System.Drawing.Size(380, 33);
            this.txtMpApproveRemarks.TabIndex = 471;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(121, 17);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(152, 33);
            this.button1.TabIndex = 488;
            this.button1.Text = "Approval";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnLoadProjects
            // 
            this.btnLoadProjects.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnLoadProjects.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnLoadProjects.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadProjects.Location = new System.Drawing.Point(298, 18);
            this.btnLoadProjects.Name = "btnLoadProjects";
            this.btnLoadProjects.Size = new System.Drawing.Size(163, 32);
            this.btnLoadProjects.TabIndex = 209;
            this.btnLoadProjects.Text = "Load All Projects";
            this.btnLoadProjects.UseVisualStyleBackColor = false;
            this.btnLoadProjects.Click += new System.EventHandler(this.btnLoadProjects_Click);
            // 
            // dtpPMCreatedDate
            // 
            this.dtpPMCreatedDate.CustomFormat = "";
            this.dtpPMCreatedDate.Enabled = false;
            this.dtpPMCreatedDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpPMCreatedDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpPMCreatedDate.Location = new System.Drawing.Point(1186, 17);
            this.dtpPMCreatedDate.Name = "dtpPMCreatedDate";
            this.dtpPMCreatedDate.Size = new System.Drawing.Size(105, 26);
            this.dtpPMCreatedDate.TabIndex = 71;
            // 
            // lblIteType
            // 
            this.lblIteType.AutoSize = true;
            this.lblIteType.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIteType.Location = new System.Drawing.Point(12, 21);
            this.lblIteType.Name = "lblIteType";
            this.lblIteType.Size = new System.Drawing.Size(92, 18);
            this.lblIteType.TabIndex = 1;
            this.lblIteType.Text = "Approval List:";
            // 
            // butAccept
            // 
            this.butAccept.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.butAccept.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.butAccept.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butAccept.Location = new System.Drawing.Point(48, 10);
            this.butAccept.Name = "butAccept";
            this.butAccept.Size = new System.Drawing.Size(100, 33);
            this.butAccept.TabIndex = 11;
            this.butAccept.Text = "Accepts";
            this.butAccept.UseVisualStyleBackColor = false;
            this.butAccept.Click += new System.EventHandler(this.butAccept_Click);
            // 
            // butreject
            // 
            this.butreject.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.butreject.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.butreject.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butreject.Location = new System.Drawing.Point(214, 10);
            this.butreject.Name = "butreject";
            this.butreject.Size = new System.Drawing.Size(100, 33);
            this.butreject.TabIndex = 12;
            this.butreject.Text = "Reject";
            this.butreject.UseVisualStyleBackColor = false;
            this.butreject.Click += new System.EventHandler(this.butreject_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.groupBox2.Controls.Add(this.butAccept);
            this.groupBox2.Controls.Add(this.butreject);
            this.groupBox2.Controls.Add(this.btnExit);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox2.Location = new System.Drawing.Point(406, 628);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(529, 46);
            this.groupBox2.TabIndex = 470;
            this.groupBox2.TabStop = false;
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnExit.Location = new System.Drawing.Point(395, 10);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(96, 33);
            this.btnExit.TabIndex = 12;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // MachinePassportApprovelList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1308, 686);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.dgApproveProjectList);
            this.Controls.Add(this.gbSearchOptions);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MachinePassportApprovelList";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MachinePassportApprovelList";
            this.Load += new System.EventHandler(this.MachinePassportApprovelList_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgApproveProjectList)).EndInit();
            this.gbSearchOptions.ResumeLayout(false);
            this.gbSearchOptions.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgApproveProjectList;
        private System.Windows.Forms.GroupBox gbSearchOptions;
        private System.Windows.Forms.Button btnLoadProjects;
        private System.Windows.Forms.DateTimePicker dtpPMCreatedDate;
        private System.Windows.Forms.Label lblIteType;
        private System.Windows.Forms.Button butAccept;
        private System.Windows.Forms.Button butreject;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox txtMpApproveRemarks;
        private System.Windows.Forms.Label label1;
    }
}