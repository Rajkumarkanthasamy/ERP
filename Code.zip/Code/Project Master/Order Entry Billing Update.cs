﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Project_Master
{
    public partial class Order_Entry_Billing_Update : Form
    {
        DataTable SelectOrderEntryNo = new DataTable();
        DataAccessLayer DAL = new DataAccessLayer();
        Global GlobalClass = new Global();
        Login.frmLoginForm login = new Login.frmLoginForm();
        frmForm2 frm = new frmForm2();
        
        public Order_Entry_Billing_Update()
        {
            InitializeComponent();
        }

        private void Order_Entry_Billing_Update_Load(object sender, EventArgs e)
        {
            SelectOrderEntryNo = DAL.OrderBillingDetails(0, null, comselectedOrderEntryNo.Text).Tables[0];

            if (SelectOrderEntryNo.Rows.Count > 0)
            {
                foreach (DataRow DR in SelectOrderEntryNo.Rows)
                {
                    if (!comselectedOrderEntryNo.Items.Contains(DR["OENo"].ToString()))
                        comselectedOrderEntryNo.Items.Add(DR["OENo"].ToString());
                }
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void comselectedOrderEntryNo_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Ensure an item is selected
            if (comselectedOrderEntryNo.SelectedItem != null)
            {
                // Get the selected order entry number
                var selectedOrderEntryNo = comselectedOrderEntryNo.SelectedItem.ToString();

                // Fetch the amount for the selected order entry number
                // Assuming that DAL.ProjectOrderBillingDetails method has a way to fetch amount based on order entry number
                var orderDetails = DAL.OrderBillingDetails(1, selectedOrderEntryNo,null);
                if (orderDetails.Tables[0].Rows.Count > 0)
                {
                    var amount = orderDetails.Tables[0].Rows[0]["Amount"].ToString();
                    txtAmount.Text = amount;
                }
                else
                {
                    txtAmount.Text = "0"; // Default value if no details found
                }
            }
        }

        private void buttprojectclosersave_Click(object sender, EventArgs e)
        {
            try
            {
                // Retrieve values from the form
                var amount = txtAmount.Text;
                var selectedOrderEntryNo = comselectedOrderEntryNo.Text;

                // Validate inputs if necessary
                if (string.IsNullOrWhiteSpace(amount) || string.IsNullOrWhiteSpace(selectedOrderEntryNo))
                {
                    MessageBox.Show("Please fill in all required fields.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Call the DAL method to save or update order billing details
                GlobalClass.iStatus = DAL.OrderBillingDetailsUpdate(0, amount,selectedOrderEntryNo);

                // Check if the operation was successful
                
                    MessageBox.Show("Order billing details saved successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
            }
            catch (Exception ex)
            {
                // Log or display the exception message
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            fnClose();
        }
        
        private void fnClose()
        {
            this.Hide();
            frm.Show();
        }
        
    }
}
