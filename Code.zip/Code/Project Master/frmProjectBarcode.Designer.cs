﻿
namespace Erp_Project_With_Buttons.Project_Master
{
    partial class frmProjectBarcode
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProjectBarcode));
            this.dgvProjHistory = new System.Windows.Forms.DataGridView();
            this.ProjectCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectQRCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectCount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.QRCodeCreatedBy = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.QRCodeCreatedDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label8 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtprojectname = new System.Windows.Forms.TextBox();
            this.chkProjectList = new System.Windows.Forms.CheckedListBox();
            this.dtpQRDate = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.txtSlNo = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCount = new System.Windows.Forms.TextBox();
            this.txtQRCode = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnDownloadQRCode = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProjHistory)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvProjHistory
            // 
            this.dgvProjHistory.AllowUserToAddRows = false;
            this.dgvProjHistory.AllowUserToDeleteRows = false;
            this.dgvProjHistory.AllowUserToResizeRows = false;
            this.dgvProjHistory.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvProjHistory.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvProjHistory.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvProjHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProjHistory.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProjectCode,
            this.ProjectQRCode,
            this.ProjectCount,
            this.QRCodeCreatedBy,
            this.QRCodeCreatedDate});
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvProjHistory.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgvProjHistory.Location = new System.Drawing.Point(136, 235);
            this.dgvProjHistory.MultiSelect = false;
            this.dgvProjHistory.Name = "dgvProjHistory";
            this.dgvProjHistory.ReadOnly = true;
            this.dgvProjHistory.RowHeadersVisible = false;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.ControlLight;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvProjHistory.RowsDefaultCellStyle = dataGridViewCellStyle7;
            this.dgvProjHistory.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvProjHistory.Size = new System.Drawing.Size(956, 111);
            this.dgvProjHistory.TabIndex = 236;
            // 
            // ProjectCode
            // 
            this.ProjectCode.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ProjectCode.DataPropertyName = "ProjectCode";
            this.ProjectCode.HeaderText = "ProjectCode";
            this.ProjectCode.Name = "ProjectCode";
            this.ProjectCode.ReadOnly = true;
            this.ProjectCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ProjectQRCode
            // 
            this.ProjectQRCode.DataPropertyName = "QRCode";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ProjectQRCode.DefaultCellStyle = dataGridViewCellStyle2;
            this.ProjectQRCode.HeaderText = "Project QR Code";
            this.ProjectQRCode.Name = "ProjectQRCode";
            this.ProjectQRCode.ReadOnly = true;
            this.ProjectQRCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectQRCode.Width = 158;
            // 
            // ProjectCount
            // 
            this.ProjectCount.DataPropertyName = "ProjectCount";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ProjectCount.DefaultCellStyle = dataGridViewCellStyle3;
            this.ProjectCount.HeaderText = "Project Count";
            this.ProjectCount.Name = "ProjectCount";
            this.ProjectCount.ReadOnly = true;
            this.ProjectCount.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectCount.Width = 159;
            // 
            // QRCodeCreatedBy
            // 
            this.QRCodeCreatedBy.DataPropertyName = "QRCodeCreatedBy";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.QRCodeCreatedBy.DefaultCellStyle = dataGridViewCellStyle4;
            this.QRCodeCreatedBy.HeaderText = "Created By";
            this.QRCodeCreatedBy.Name = "QRCodeCreatedBy";
            this.QRCodeCreatedBy.ReadOnly = true;
            this.QRCodeCreatedBy.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.QRCodeCreatedBy.Width = 159;
            // 
            // QRCodeCreatedDate
            // 
            this.QRCodeCreatedDate.DataPropertyName = "QRCodeCreatedDate";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.QRCodeCreatedDate.DefaultCellStyle = dataGridViewCellStyle5;
            this.QRCodeCreatedDate.HeaderText = "Created Date";
            this.QRCodeCreatedDate.Name = "QRCodeCreatedDate";
            this.QRCodeCreatedDate.ReadOnly = true;
            this.QRCodeCreatedDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.QRCodeCreatedDate.Width = 159;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(17, 69);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(111, 19);
            this.label8.TabIndex = 235;
            this.label8.Text = "Select Project :\t";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(12, 23);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(116, 19);
            this.label12.TabIndex = 234;
            this.label12.Text = "Search Project :\t";
            // 
            // txtprojectname
            // 
            this.txtprojectname.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtprojectname.Location = new System.Drawing.Point(136, 22);
            this.txtprojectname.Name = "txtprojectname";
            this.txtprojectname.Size = new System.Drawing.Size(693, 26);
            this.txtprojectname.TabIndex = 232;
            this.txtprojectname.TextChanged += new System.EventHandler(this.txtprojectname_TextChanged);
            this.txtprojectname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtprojectname_KeyPress);
            this.txtprojectname.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtprojectname_KeyUp);
            // 
            // chkProjectList
            // 
            this.chkProjectList.CheckOnClick = true;
            this.chkProjectList.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkProjectList.FormattingEnabled = true;
            this.chkProjectList.Location = new System.Drawing.Point(136, 69);
            this.chkProjectList.Name = "chkProjectList";
            this.chkProjectList.Size = new System.Drawing.Size(956, 151);
            this.chkProjectList.TabIndex = 233;
            this.chkProjectList.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.chkProjectList_ItemCheck);
            // 
            // dtpQRDate
            // 
            this.dtpQRDate.CustomFormat = "";
            this.dtpQRDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpQRDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpQRDate.Location = new System.Drawing.Point(387, 389);
            this.dtpQRDate.MaxDate = new System.DateTime(2040, 12, 31, 0, 0, 0, 0);
            this.dtpQRDate.MinDate = new System.DateTime(2022, 1, 1, 0, 0, 0, 0);
            this.dtpQRDate.Name = "dtpQRDate";
            this.dtpQRDate.Size = new System.Drawing.Size(119, 26);
            this.dtpQRDate.TabIndex = 237;
            this.dtpQRDate.ValueChanged += new System.EventHandler(this.dtpQRDate_ValueChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(337, 391);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 19);
            this.label11.TabIndex = 238;
            this.label11.Text = "Date :";
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(680, 542);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(113, 42);
            this.btnExit.TabIndex = 240;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(401, 542);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(170, 42);
            this.btnSave.TabIndex = 239;
            this.btnSave.Text = "Generate QR Code";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // txtSlNo
            // 
            this.txtSlNo.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSlNo.Location = new System.Drawing.Point(191, 389);
            this.txtSlNo.Name = "txtSlNo";
            this.txtSlNo.ReadOnly = true;
            this.txtSlNo.Size = new System.Drawing.Size(128, 26);
            this.txtSlNo.TabIndex = 242;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(132, 450);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(135, 19);
            this.label10.TabIndex = 241;
            this.label10.Text = "QR Code Number :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(132, 391);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 19);
            this.label1.TabIndex = 243;
            this.label1.Text = "Sl No :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(514, 394);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 19);
            this.label2.TabIndex = 244;
            this.label2.Text = "Project Count :";
            // 
            // txtCount
            // 
            this.txtCount.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCount.Location = new System.Drawing.Point(622, 391);
            this.txtCount.Name = "txtCount";
            this.txtCount.ReadOnly = true;
            this.txtCount.Size = new System.Drawing.Size(128, 26);
            this.txtCount.TabIndex = 245;
            // 
            // txtQRCode
            // 
            this.txtQRCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQRCode.Location = new System.Drawing.Point(271, 448);
            this.txtQRCode.Name = "txtQRCode";
            this.txtQRCode.ReadOnly = true;
            this.txtQRCode.Size = new System.Drawing.Size(259, 26);
            this.txtQRCode.TabIndex = 246;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(879, 370);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(213, 177);
            this.pictureBox1.TabIndex = 247;
            this.pictureBox1.TabStop = false;
            // 
            // btnDownloadQRCode
            // 
            this.btnDownloadQRCode.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDownloadQRCode.Location = new System.Drawing.Point(881, 549);
            this.btnDownloadQRCode.Name = "btnDownloadQRCode";
            this.btnDownloadQRCode.Size = new System.Drawing.Size(211, 38);
            this.btnDownloadQRCode.TabIndex = 248;
            this.btnDownloadQRCode.Text = "Download QR Code";
            this.btnDownloadQRCode.UseVisualStyleBackColor = true;
            this.btnDownloadQRCode.Visible = false;
            this.btnDownloadQRCode.Click += new System.EventHandler(this.btnDownloadQRCode_Click);
            // 
            // frmProjectBarcode
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1146, 596);
            this.Controls.Add(this.btnDownloadQRCode);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txtQRCode);
            this.Controls.Add(this.txtCount);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtSlNo);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.dtpQRDate);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.dgvProjHistory);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtprojectname);
            this.Controls.Add(this.chkProjectList);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmProjectBarcode";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Project QR Code";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmProjectBarcode_FormClosing);
            this.Load += new System.EventHandler(this.frmProjectBarcode_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvProjHistory)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvProjHistory;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtprojectname;
        private System.Windows.Forms.CheckedListBox chkProjectList;
        private System.Windows.Forms.DateTimePicker dtpQRDate;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.TextBox txtSlNo;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCount;
        private System.Windows.Forms.TextBox txtQRCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectQRCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectCount;
        private System.Windows.Forms.DataGridViewTextBoxColumn QRCodeCreatedBy;
        private System.Windows.Forms.DataGridViewTextBoxColumn QRCodeCreatedDate;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnDownloadQRCode;
    }
}