﻿
namespace Erp_Project_With_Buttons.Project_Master
{
    partial class MachinePassportStatusView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MachinePassportStatusView));
            this.dgMachineClosingList = new System.Windows.Forms.DataGridView();
            this.btnLoadProjects = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.labNoofCards = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.ProductCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductSerialNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgMachineClosingList)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgMachineClosingList
            // 
            this.dgMachineClosingList.AllowUserToAddRows = false;
            this.dgMachineClosingList.AllowUserToDeleteRows = false;
            this.dgMachineClosingList.AllowUserToResizeRows = false;
            this.dgMachineClosingList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgMachineClosingList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgMachineClosingList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgMachineClosingList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgMachineClosingList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProductCode,
            this.ProductSerialNumber,
            this.ProductName,
            this.ProductDescription,
            this.status});
            this.dgMachineClosingList.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgMachineClosingList.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgMachineClosingList.EnableHeadersVisualStyles = false;
            this.dgMachineClosingList.Location = new System.Drawing.Point(126, 108);
            this.dgMachineClosingList.MultiSelect = false;
            this.dgMachineClosingList.Name = "dgMachineClosingList";
            this.dgMachineClosingList.ReadOnly = true;
            this.dgMachineClosingList.RowHeadersVisible = false;
            this.dgMachineClosingList.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgMachineClosingList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgMachineClosingList.Size = new System.Drawing.Size(1121, 477);
            this.dgMachineClosingList.TabIndex = 10;
            this.dgMachineClosingList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgMachineClosingList_CellContentClick);
            // 
            // btnLoadProjects
            // 
            this.btnLoadProjects.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnLoadProjects.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnLoadProjects.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadProjects.Location = new System.Drawing.Point(126, 70);
            this.btnLoadProjects.Name = "btnLoadProjects";
            this.btnLoadProjects.Size = new System.Drawing.Size(163, 32);
            this.btnLoadProjects.TabIndex = 210;
            this.btnLoadProjects.Text = "Load Projects Details";
            this.btnLoadProjects.UseVisualStyleBackColor = false;
            this.btnLoadProjects.Click += new System.EventHandler(this.btnLoadProjects_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox2.Controls.Add(this.labNoofCards);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.groupBox2.Location = new System.Drawing.Point(126, 18);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1121, 46);
            this.groupBox2.TabIndex = 470;
            this.groupBox2.TabStop = false;
            // 
            // labNoofCards
            // 
            this.labNoofCards.AutoSize = true;
            this.labNoofCards.BackColor = System.Drawing.SystemColors.Control;
            this.labNoofCards.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labNoofCards.ForeColor = System.Drawing.SystemColors.WindowText;
            this.labNoofCards.Location = new System.Drawing.Point(534, 14);
            this.labNoofCards.Name = "labNoofCards";
            this.labNoofCards.Size = new System.Drawing.Size(127, 18);
            this.labNoofCards.TabIndex = 468;
            this.labNoofCards.Text = "Project status View";
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold);
            this.btnExit.Location = new System.Drawing.Point(311, 70);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(116, 33);
            this.btnExit.TabIndex = 471;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // ProductCode
            // 
            this.ProductCode.DataPropertyName = "ProductCode";
            this.ProductCode.HeaderText = "Product Code";
            this.ProductCode.Name = "ProductCode";
            this.ProductCode.ReadOnly = true;
            this.ProductCode.Width = 127;
            // 
            // ProductSerialNumber
            // 
            this.ProductSerialNumber.DataPropertyName = "ProductSerialNumber";
            this.ProductSerialNumber.HeaderText = "ProductSerial Number";
            this.ProductSerialNumber.Name = "ProductSerialNumber";
            this.ProductSerialNumber.ReadOnly = true;
            this.ProductSerialNumber.Width = 187;
            // 
            // ProductName
            // 
            this.ProductName.DataPropertyName = "ProductName";
            this.ProductName.HeaderText = "Product Name";
            this.ProductName.Name = "ProductName";
            this.ProductName.ReadOnly = true;
            this.ProductName.Width = 133;
            // 
            // ProductDescription
            // 
            this.ProductDescription.DataPropertyName = "ProductDescription";
            this.ProductDescription.HeaderText = "Product Description";
            this.ProductDescription.Name = "ProductDescription";
            this.ProductDescription.ReadOnly = true;
            this.ProductDescription.Width = 170;
            // 
            // status
            // 
            this.status.DataPropertyName = "status";
            this.status.HeaderText = "Status";
            this.status.Name = "status";
            this.status.ReadOnly = true;
            this.status.Width = 77;
            // 
            // MachinePassportStatusView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1259, 636);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnLoadProjects);
            this.Controls.Add(this.dgMachineClosingList);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MachinePassportStatusView";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MachinePassportStatusView";
            this.Load += new System.EventHandler(this.MachinePassportStatusView_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgMachineClosingList)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgMachineClosingList;
        private System.Windows.Forms.Button btnLoadProjects;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label labNoofCards;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductSerialNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn status;
    }
}