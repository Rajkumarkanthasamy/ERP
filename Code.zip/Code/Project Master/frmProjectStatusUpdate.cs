﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Project_Master
{
    public partial class frmProjectStatusUpdate : Form
    {
        public frmProjectStatusUpdate()
        {
            InitializeComponent();
        }
        Login.frmLoginForm Loginfrm = new Login.frmLoginForm();
        frmForm2 frm = new frmForm2();
        DataAccessLayer DAL = new DataAccessLayer();
        Global GlobalClass = new Global();
        private static string sProjectCode;
        public string fnProjectcode
        {
            get
            {
                return sProjectCode;
            }
            set
            {
                sProjectCode = value;
            }
        }

        public int sProjectStatusform = 0;
        DataTable dtProjctList = new DataTable();
        private void frmProjectStatusUpdate_Load(object sender, EventArgs e)
        {
            dtProjctList = DAL.fnAllProjectList(null).Tables[0];

            foreach (DataRow DR in dtProjctList.Rows)
            {
                if (!cmbProjectcode.Items.Contains(DR["ProjectCode"].ToString()))
                    cmbProjectcode.Items.Add(DR["ProjectCode"].ToString());
            }
        }

        private void fnSaveData()
        {
            GlobalClass.iStatus = DAL.fnAddProjectUpdate(5, cmbProjectcode.Text, "", cmbPMProjectStatus.Text,"");

            GlobalClass.iStatus = DAL.fnAddProjectStatusUpdate(1, cmbProjectcode.Text, cmbPMProjectStatus.Text, txtTallyVoucherNo.Text.Trim(), txtAmount.Text.Trim(),
            txtCapexCode.Text.Trim(), txtAssetSerialNo.Text.Trim(), txtRemarks.Text.Trim(), Loginfrm.GetUserDetails[2]);

            MessageBox.Show("Status Updated", "Success", 0, MessageBoxIcon.Information);
            this.Hide();
            frmProjectStatusUpdate PSU = new frmProjectStatusUpdate();
            PSU.Show();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (cmbProjectcode.SelectedIndex >= 0 && cmbPMProjectStatus.SelectedIndex >= 0 && !string.IsNullOrEmpty(txtTallyVoucherNo.Text)
                && !string.IsNullOrEmpty(txtAmount.Text) && !string.IsNullOrEmpty(txtCapexCode.Text))
            {
                if (cmbPMProjectStatus.SelectedIndex < 2 && !string.IsNullOrEmpty(txtAssetSerialNo.Text))
                {
                    fnSaveData();
                }
                else
                {
                    if (cmbPMProjectStatus.SelectedIndex == 2 && !string.IsNullOrEmpty(txtAssetSerialNo.Text))
                    {
                        fnSaveData();
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(txtAssetSerialNo.Text))
                        {
                            MessageBox.Show("Enter asset serial number", "Error", 0, MessageBoxIcon.Error);
                            txtAssetSerialNo.Focus();
                        }
                    }
                }
            }
            else
            {
                if (cmbProjectcode.SelectedIndex < 0)
                {
                    MessageBox.Show("Select project code", "Error", 0, MessageBoxIcon.Error);
                    cmbProjectcode.DroppedDown = true;
                }
                else if (cmbPMProjectStatus.SelectedIndex < 0)
                {
                    MessageBox.Show("Select project status", "Error", 0, MessageBoxIcon.Error);
                    cmbPMProjectStatus.DroppedDown = true;
                }
                else if (string.IsNullOrEmpty(txtCapexCode.Text))
                {
                    MessageBox.Show("Enter tally voucher number", "Error", 0, MessageBoxIcon.Error);
                    txtCapexCode.Focus();
                }
                else if (string.IsNullOrEmpty(txtAmount.Text))
                {
                    MessageBox.Show("Enter amount", "Error", 0, MessageBoxIcon.Error);
                    txtAmount.Focus();
                }
                else if (string.IsNullOrEmpty(txtTallyVoucherNo.Text))
                {
                    MessageBox.Show("Enter tally voucher number", "Error", 0, MessageBoxIcon.Error);
                    txtTallyVoucherNo.Focus();
                }
            }
        }

        private void btnProjectView_Click(object sender, EventArgs e)
        {
            sProjectStatusform = 1;
            Indent.frmProjectselect projectsearch = new Indent.frmProjectselect();
            projectsearch.fnProjectStatusform = sProjectStatusform.ToString();
            projectsearch.ShowDialog();
            if (fnProjectcode != null)
            {
                cmbProjectcode.Text = sProjectCode;
            }
        }

        private void frmProjectStatusUpdate_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnClose();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            fnClose();
        }

        private void fnClose()
        {
            this.Hide();
            frm.Show();
        }

        DataTable dtcapex = new DataTable();
        private void cmbProjectcode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbProjectcode.SelectedIndex >= 0)
            {
                dtcapex = DAL.fngetProjectstatusUpdate(1,cmbProjectcode.Text).Tables[0];
                DataView dvProjectBOMList = new DataView(dtProjctList);
                dvProjectBOMList.RowFilter = "ProjectCode='" + cmbProjectcode.Text + "'";
                if (dvProjectBOMList.ToTable().Rows.Count > 0)
                {
                    llbProjectName.Text = dvProjectBOMList.ToTable().Rows[0]["ProjectDescription"].ToString();
                }
                else
                {
                    llbProjectName.ResetText();
                }
                if(dtcapex.Rows.Count>0)
                {
                    cmbPMProjectStatus.Text = dtcapex.Rows[0]["ProjectStatus"].ToString();
                    txtTallyVoucherNo.Text = dtcapex.Rows[0]["TallyVoucherNo"].ToString();
                    txtAmount.Text = dtcapex.Rows[0]["Amount"].ToString();
                    txtCapexCode.Text = dtcapex.Rows[0]["CapexNo"].ToString();
                    txtAssetSerialNo.Text = dtcapex.Rows[0]["AssetSerialNo"].ToString();
                    txtRemarks.Text = dtcapex.Rows[0]["Remarks"].ToString();
                }
                else
                {
                    llbProjectName.ResetText();
                    cmbPMProjectStatus.ResetText();
                    txtTallyVoucherNo.ResetText();
                    txtAmount.ResetText();
                    txtCapexCode.ResetText();
                    txtAssetSerialNo.ResetText();
                    txtRemarks.ResetText();

                }
            }
            else
            {
                llbProjectName.ResetText();
            }
        }
    }
}
