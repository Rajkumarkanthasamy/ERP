﻿
namespace Erp_Project_With_Buttons.Project_Master
{
    partial class frmProjectTracker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProjectTracker));
            this.dgvProTracker = new System.Windows.Forms.DataGridView();
            this.cmbprocode = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btmsubmit = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.excelbtn = new System.Windows.Forms.Button();
            this.todate = new System.Windows.Forms.DateTimePicker();
            this.frmdate = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbmonth = new System.Windows.Forms.ComboBox();
            this.cmbyesno = new System.Windows.Forms.ComboBox();
            this.oDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.ProjectName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Year = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Month = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MoctDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DelivaeryDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DeliveryDatepo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PaymentTerms = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PDIbiss = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LDClause = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MachineRetrofit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MachineType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Producttype = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ComplexityLevel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProjectFocal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PlannedMonth = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ActualMonth = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OntimeDelivery = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Shipmentstatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SiteRequirement = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CriticalPath = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProposePDI = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Actualpdi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Actualshipment = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Projecctclose = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Remarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProTracker)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvProTracker
            // 
            this.dgvProTracker.AllowUserToAddRows = false;
            this.dgvProTracker.AllowUserToDeleteRows = false;
            this.dgvProTracker.AllowUserToResizeColumns = false;
            this.dgvProTracker.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvProTracker.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvProTracker.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvProTracker.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProTracker.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProjectName,
            this.ProjectCode,
            this.Year,
            this.Month,
            this.Date,
            this.MoctDate,
            this.DelivaeryDate,
            this.DeliveryDatepo,
            this.PaymentTerms,
            this.PDIbiss,
            this.LDClause,
            this.MachineRetrofit,
            this.MachineType,
            this.Producttype,
            this.ComplexityLevel,
            this.ProjectFocal,
            this.PlannedMonth,
            this.ActualMonth,
            this.OntimeDelivery,
            this.Shipmentstatus,
            this.SiteRequirement,
            this.CriticalPath,
            this.ProposePDI,
            this.Actualpdi,
            this.Actualshipment,
            this.Projecctclose,
            this.Remarks});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvProTracker.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvProTracker.EnableHeadersVisualStyles = false;
            this.dgvProTracker.Location = new System.Drawing.Point(12, 138);
            this.dgvProTracker.Name = "dgvProTracker";
            this.dgvProTracker.RowHeadersVisible = false;
            this.dgvProTracker.Size = new System.Drawing.Size(1284, 207);
            this.dgvProTracker.TabIndex = 0;
            this.dgvProTracker.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvProTracker_CellClick);
            this.dgvProTracker.Scroll += new System.Windows.Forms.ScrollEventHandler(this.dgvProTracker_Scroll);
            // 
            // cmbprocode
            // 
            this.cmbprocode.DropDownHeight = 130;
            this.cmbprocode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbprocode.FormattingEnabled = true;
            this.cmbprocode.IntegralHeight = false;
            this.cmbprocode.Location = new System.Drawing.Point(147, 68);
            this.cmbprocode.Name = "cmbprocode";
            this.cmbprocode.Size = new System.Drawing.Size(336, 26);
            this.cmbprocode.TabIndex = 1;
            this.cmbprocode.SelectedIndexChanged += new System.EventHandler(this.cmbprocode_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 23);
            this.label1.TabIndex = 2;
            this.label1.Text = "Project Code* :";
            // 
            // btmsubmit
            // 
            this.btmsubmit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btmsubmit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmsubmit.Location = new System.Drawing.Point(1060, 351);
            this.btmsubmit.Name = "btmsubmit";
            this.btmsubmit.Size = new System.Drawing.Size(129, 37);
            this.btmsubmit.TabIndex = 3;
            this.btmsubmit.TabStop = false;
            this.btmsubmit.Text = "Save";
            this.btmsubmit.UseVisualStyleBackColor = true;
            this.btmsubmit.Click += new System.EventHandler(this.btmsubmit_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.excelbtn);
            this.panel1.Controls.Add(this.todate);
            this.panel1.Controls.Add(this.cmbprocode);
            this.panel1.Controls.Add(this.frmdate);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 13);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1284, 119);
            this.panel1.TabIndex = 4;
            // 
            // excelbtn
            // 
            this.excelbtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.excelbtn.Location = new System.Drawing.Point(342, 15);
            this.excelbtn.Name = "excelbtn";
            this.excelbtn.Size = new System.Drawing.Size(141, 29);
            this.excelbtn.TabIndex = 7;
            this.excelbtn.Text = "Generate Report";
            this.excelbtn.UseVisualStyleBackColor = true;
            this.excelbtn.Click += new System.EventHandler(this.excelbtn_Click);
            // 
            // todate
            // 
            this.todate.CalendarFont = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.todate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.todate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.todate.Location = new System.Drawing.Point(217, 15);
            this.todate.Name = "todate";
            this.todate.Size = new System.Drawing.Size(108, 27);
            this.todate.TabIndex = 6;
            // 
            // frmdate
            // 
            this.frmdate.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.frmdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.frmdate.Location = new System.Drawing.Point(72, 15);
            this.frmdate.Name = "frmdate";
            this.frmdate.Size = new System.Drawing.Size(108, 27);
            this.frmdate.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(186, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(25, 19);
            this.label3.TabIndex = 4;
            this.label3.Text = "To";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(14, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 19);
            this.label2.TabIndex = 3;
            this.label2.Text = "From :";
            // 
            // cmbmonth
            // 
            this.cmbmonth.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbmonth.FormattingEnabled = true;
            this.cmbmonth.Items.AddRange(new object[] {
            "P1",
            "P2",
            "P3",
            "P4",
            "P5",
            "P6",
            "P7",
            "P8",
            "P9",
            "P10",
            "P11",
            "P12"});
            this.cmbmonth.Location = new System.Drawing.Point(66, 464);
            this.cmbmonth.Name = "cmbmonth";
            this.cmbmonth.Size = new System.Drawing.Size(39, 26);
            this.cmbmonth.TabIndex = 10;
            this.cmbmonth.Visible = false;
            this.cmbmonth.SelectedIndexChanged += new System.EventHandler(this.cmbmonth_SelectedIndexChanged);
            // 
            // cmbyesno
            // 
            this.cmbyesno.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbyesno.FormattingEnabled = true;
            this.cmbyesno.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbyesno.Location = new System.Drawing.Point(12, 464);
            this.cmbyesno.Name = "cmbyesno";
            this.cmbyesno.Size = new System.Drawing.Size(38, 26);
            this.cmbyesno.TabIndex = 9;
            this.cmbyesno.Visible = false;
            this.cmbyesno.SelectedIndexChanged += new System.EventHandler(this.cmbyesno_SelectedIndexChanged);
            // 
            // oDateTimePicker
            // 
            this.oDateTimePicker.CalendarFont = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.oDateTimePicker.Location = new System.Drawing.Point(122, 470);
            this.oDateTimePicker.Name = "oDateTimePicker";
            this.oDateTimePicker.Size = new System.Drawing.Size(31, 20);
            this.oDateTimePicker.TabIndex = 8;
            this.oDateTimePicker.Visible = false;
            this.oDateTimePicker.CloseUp += new System.EventHandler(this.oDateTimePicker_CloseUp);
            this.oDateTimePicker.TabIndexChanged += new System.EventHandler(this.oDateTimePicker_TabIndexChanged);
            // 
            // ProjectName
            // 
            this.ProjectName.DataPropertyName = "ProjectDescription";
            this.ProjectName.Frozen = true;
            this.ProjectName.HeaderText = "Project Name";
            this.ProjectName.Name = "ProjectName";
            this.ProjectName.ReadOnly = true;
            this.ProjectName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectName.Width = 108;
            // 
            // ProjectCode
            // 
            this.ProjectCode.DataPropertyName = "ProjectCode";
            this.ProjectCode.Frozen = true;
            this.ProjectCode.HeaderText = "Project Code";
            this.ProjectCode.Name = "ProjectCode";
            this.ProjectCode.ReadOnly = true;
            this.ProjectCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectCode.Width = 102;
            // 
            // Year
            // 
            this.Year.DataPropertyName = "year";
            this.Year.HeaderText = "Year";
            this.Year.Name = "Year";
            this.Year.ReadOnly = true;
            this.Year.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Year.Width = 44;
            // 
            // Month
            // 
            this.Month.DataPropertyName = "month";
            this.Month.HeaderText = "Month";
            this.Month.Name = "Month";
            this.Month.ReadOnly = true;
            this.Month.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Month.Width = 62;
            // 
            // Date
            // 
            this.Date.DataPropertyName = "DateCreated";
            this.Date.HeaderText = "Date";
            this.Date.Name = "Date";
            this.Date.ReadOnly = true;
            this.Date.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Date.Width = 47;
            // 
            // MoctDate
            // 
            this.MoctDate.DataPropertyName = "MoctDate";
            this.MoctDate.HeaderText = "MoCT Date";
            this.MoctDate.Name = "MoctDate";
            this.MoctDate.ReadOnly = true;
            this.MoctDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.MoctDate.Width = 90;
            // 
            // DelivaeryDate
            // 
            this.DelivaeryDate.DataPropertyName = "DeliveryOE";
            this.DelivaeryDate.HeaderText = "DeliveryDate As Per Order Entry";
            this.DelivaeryDate.Name = "DelivaeryDate";
            this.DelivaeryDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DelivaeryDate.Width = 139;
            // 
            // DeliveryDatepo
            // 
            this.DeliveryDatepo.DataPropertyName = "DeliveryPO";
            this.DeliveryDatepo.HeaderText = "Delivery Date As Per PO";
            this.DeliveryDatepo.Name = "DeliveryDatepo";
            this.DeliveryDatepo.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.DeliveryDatepo.Width = 118;
            // 
            // PaymentTerms
            // 
            this.PaymentTerms.DataPropertyName = "PaymentTerms";
            this.PaymentTerms.HeaderText = "Payment Terms";
            this.PaymentTerms.Name = "PaymentTerms";
            this.PaymentTerms.ReadOnly = true;
            this.PaymentTerms.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PaymentTerms.Width = 108;
            // 
            // PDIbiss
            // 
            this.PDIbiss.DataPropertyName = "PreDispatchInspection";
            this.PDIbiss.HeaderText = "PDI at BISS";
            this.PDIbiss.Name = "PDIbiss";
            this.PDIbiss.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.PDIbiss.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PDIbiss.Width = 80;
            // 
            // LDClause
            // 
            this.LDClause.DataPropertyName = "LDClause";
            this.LDClause.HeaderText = "LD Clause";
            this.LDClause.Name = "LDClause";
            this.LDClause.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.LDClause.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.LDClause.Width = 71;
            // 
            // MachineRetrofit
            // 
            this.MachineRetrofit.DataPropertyName = "MachineRetrofit";
            this.MachineRetrofit.HeaderText = "Machine/Retrofit/Accessories/OTC";
            this.MachineRetrofit.Name = "MachineRetrofit";
            this.MachineRetrofit.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.MachineRetrofit.Width = 251;
            // 
            // MachineType
            // 
            this.MachineType.DataPropertyName = "MachineType";
            this.MachineType.HeaderText = "MachineType:STD/CUS";
            this.MachineType.Name = "MachineType";
            this.MachineType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.MachineType.Width = 170;
            // 
            // Producttype
            // 
            this.Producttype.DataPropertyName = "project8020";
            this.Producttype.HeaderText = "ProductType:80/20";
            this.Producttype.Name = "Producttype";
            this.Producttype.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Producttype.Width = 146;
            // 
            // ComplexityLevel
            // 
            this.ComplexityLevel.DataPropertyName = "ComplexLevel";
            this.ComplexityLevel.HeaderText = "Complexity Level";
            this.ComplexityLevel.Name = "ComplexityLevel";
            this.ComplexityLevel.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ComplexityLevel.Width = 117;
            // 
            // ProjectFocal
            // 
            this.ProjectFocal.DataPropertyName = "ProjectFocal";
            this.ProjectFocal.HeaderText = "Project Focal";
            this.ProjectFocal.Name = "ProjectFocal";
            this.ProjectFocal.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ProjectFocal.Width = 93;
            // 
            // PlannedMonth
            // 
            this.PlannedMonth.DataPropertyName = "OriginalMonth";
            this.PlannedMonth.HeaderText = "Original Planned Month";
            this.PlannedMonth.Name = "PlannedMonth";
            this.PlannedMonth.ReadOnly = true;
            this.PlannedMonth.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.PlannedMonth.Width = 162;
            // 
            // ActualMonth
            // 
            this.ActualMonth.DataPropertyName = "ActualMonth";
            this.ActualMonth.HeaderText = "Actual Month";
            this.ActualMonth.Name = "ActualMonth";
            this.ActualMonth.ReadOnly = true;
            this.ActualMonth.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.ActualMonth.Width = 99;
            // 
            // OntimeDelivery
            // 
            this.OntimeDelivery.DataPropertyName = "Time/Planned";
            this.OntimeDelivery.HeaderText = "OnTimeDelivery vs Original Planned";
            this.OntimeDelivery.Name = "OntimeDelivery";
            this.OntimeDelivery.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.OntimeDelivery.Width = 184;
            // 
            // Shipmentstatus
            // 
            this.Shipmentstatus.DataPropertyName = "ShipStatus";
            this.Shipmentstatus.HeaderText = "Shipment Status";
            this.Shipmentstatus.Name = "Shipmentstatus";
            this.Shipmentstatus.Width = 134;
            // 
            // SiteRequirement
            // 
            this.SiteRequirement.DataPropertyName = "SiteRequireDetails";
            this.SiteRequirement.HeaderText = "Site Requirement Details";
            this.SiteRequirement.Name = "SiteRequirement";
            this.SiteRequirement.ReadOnly = true;
            this.SiteRequirement.Width = 185;
            // 
            // CriticalPath
            // 
            this.CriticalPath.DataPropertyName = "CriticalPath";
            this.CriticalPath.HeaderText = "Critical Path Status ?";
            this.CriticalPath.Name = "CriticalPath";
            this.CriticalPath.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.CriticalPath.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.CriticalPath.Width = 140;
            // 
            // ProposePDI
            // 
            this.ProposePDI.DataPropertyName = "ProposedPDI";
            this.ProposePDI.HeaderText = "ProposeD PDI/Dispatch Dates";
            this.ProposePDI.Name = "ProposePDI";
            this.ProposePDI.Width = 179;
            // 
            // Actualpdi
            // 
            this.Actualpdi.DataPropertyName = "ActualPDI";
            this.Actualpdi.HeaderText = "Actual PDI Dates";
            this.Actualpdi.Name = "Actualpdi";
            this.Actualpdi.ReadOnly = true;
            // 
            // Actualshipment
            // 
            this.Actualshipment.DataPropertyName = "ActualShipDate";
            this.Actualshipment.HeaderText = "Actual Shipment Date";
            this.Actualshipment.Name = "Actualshipment";
            this.Actualshipment.ReadOnly = true;
            this.Actualshipment.Width = 139;
            // 
            // Projecctclose
            // 
            this.Projecctclose.DataPropertyName = "ProCloseStatus";
            this.Projecctclose.HeaderText = "Projecct Closure Status";
            this.Projecctclose.Name = "Projecctclose";
            this.Projecctclose.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Projecctclose.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Projecctclose.Width = 116;
            // 
            // Remarks
            // 
            this.Remarks.DataPropertyName = "Remarks";
            this.Remarks.HeaderText = "Remarks";
            this.Remarks.Name = "Remarks";
            this.Remarks.Width = 92;
            // 
            // frmProjectTracker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1308, 629);
            this.Controls.Add(this.oDateTimePicker);
            this.Controls.Add(this.cmbmonth);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.cmbyesno);
            this.Controls.Add(this.btmsubmit);
            this.Controls.Add(this.dgvProTracker);
            this.ForeColor = System.Drawing.Color.Black;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmProjectTracker";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Project Tracker";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmProjectTracker_FormClosing);
            this.Load += new System.EventHandler(this.frmProjectTracker_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvProTracker)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.DataGridView dgvProTracker;
        private System.Windows.Forms.ComboBox cmbprocode;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btmsubmit;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button excelbtn;
        private System.Windows.Forms.DateTimePicker todate;
        private System.Windows.Forms.DateTimePicker frmdate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker oDateTimePicker;
        private System.Windows.Forms.ComboBox cmbmonth;
        private System.Windows.Forms.ComboBox cmbyesno;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn Year;
        private System.Windows.Forms.DataGridViewTextBoxColumn Month;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date;
        private System.Windows.Forms.DataGridViewTextBoxColumn MoctDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn DelivaeryDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn DeliveryDatepo;
        private System.Windows.Forms.DataGridViewTextBoxColumn PaymentTerms;
        private System.Windows.Forms.DataGridViewTextBoxColumn PDIbiss;
        private System.Windows.Forms.DataGridViewTextBoxColumn LDClause;
        private System.Windows.Forms.DataGridViewTextBoxColumn MachineRetrofit;
        private System.Windows.Forms.DataGridViewTextBoxColumn MachineType;
        private System.Windows.Forms.DataGridViewTextBoxColumn Producttype;
        private System.Windows.Forms.DataGridViewTextBoxColumn ComplexityLevel;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProjectFocal;
        private System.Windows.Forms.DataGridViewTextBoxColumn PlannedMonth;
        private System.Windows.Forms.DataGridViewTextBoxColumn ActualMonth;
        private System.Windows.Forms.DataGridViewTextBoxColumn OntimeDelivery;
        private System.Windows.Forms.DataGridViewTextBoxColumn Shipmentstatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn SiteRequirement;
        private System.Windows.Forms.DataGridViewTextBoxColumn CriticalPath;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProposePDI;
        private System.Windows.Forms.DataGridViewTextBoxColumn Actualpdi;
        private System.Windows.Forms.DataGridViewTextBoxColumn Actualshipment;
        private System.Windows.Forms.DataGridViewTextBoxColumn Projecctclose;
        private System.Windows.Forms.DataGridViewTextBoxColumn Remarks;
    }
}
