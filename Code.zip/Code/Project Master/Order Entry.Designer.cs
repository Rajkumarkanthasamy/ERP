﻿
namespace Erp_Project_With_Buttons.Project_Master
{
    partial class Order_Entry
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Order_Entry));
            this.label8 = new System.Windows.Forms.Label();
            this.cmbid = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.comBillingType = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMachineSerialNo = new System.Windows.Forms.TextBox();
            this.dtpdelivery = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.updateModelNumber = new System.Windows.Forms.Label();
            this.comselectedprojectcodeBom = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.butUpdate = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.buttprojectclosersave = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(837, 144);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 19);
            this.label8.TabIndex = 201;
            this.label8.Text = "ID :";
            // 
            // cmbid
            // 
            this.cmbid.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbid.DropDownHeight = 130;
            this.cmbid.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbid.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbid.FormattingEnabled = true;
            this.cmbid.IntegralHeight = false;
            this.cmbid.Items.AddRange(new object[] {
            "A",
            "B",
            "C",
            "D",
            "E",
            "F"});
            this.cmbid.Location = new System.Drawing.Point(874, 142);
            this.cmbid.Name = "cmbid";
            this.cmbid.Size = new System.Drawing.Size(90, 26);
            this.cmbid.TabIndex = 202;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(776, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 19);
            this.label1.TabIndex = 203;
            this.label1.Text = "Billing Type:";
            // 
            // comBillingType
            // 
            this.comBillingType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comBillingType.DropDownHeight = 130;
            this.comBillingType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comBillingType.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comBillingType.FormattingEnabled = true;
            this.comBillingType.IntegralHeight = false;
            this.comBillingType.Items.AddRange(new object[] {
            "1st Billing",
            "2nd Biling",
            "3rd Billing",
            "4rd Biling",
            "5th Billing",
            "6th Biling"});
            this.comBillingType.Location = new System.Drawing.Point(874, 91);
            this.comBillingType.Name = "comBillingType";
            this.comBillingType.Size = new System.Drawing.Size(134, 26);
            this.comBillingType.TabIndex = 204;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(189, 193);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 19);
            this.label2.TabIndex = 245;
            this.label2.Text = "Amount :";
            // 
            // txtAmount
            // 
            this.txtAmount.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtAmount.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAmount.Location = new System.Drawing.Point(268, 191);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(215, 26);
            this.txtAmount.TabIndex = 244;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(128, 149);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(134, 19);
            this.label3.TabIndex = 247;
            this.label3.Text = "MachineSerialNo :";
            // 
            // txtMachineSerialNo
            // 
            this.txtMachineSerialNo.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtMachineSerialNo.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMachineSerialNo.Location = new System.Drawing.Point(268, 147);
            this.txtMachineSerialNo.Name = "txtMachineSerialNo";
            this.txtMachineSerialNo.Size = new System.Drawing.Size(214, 26);
            this.txtMachineSerialNo.TabIndex = 246;
            // 
            // dtpdelivery
            // 
            this.dtpdelivery.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpdelivery.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpdelivery.Location = new System.Drawing.Point(874, 193);
            this.dtpdelivery.Name = "dtpdelivery";
            this.dtpdelivery.Size = new System.Drawing.Size(90, 23);
            this.dtpdelivery.TabIndex = 248;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(767, 193);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 19);
            this.label4.TabIndex = 249;
            this.label4.Text = "Current Date:";
            // 
            // updateModelNumber
            // 
            this.updateModelNumber.AutoSize = true;
            this.updateModelNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateModelNumber.Location = new System.Drawing.Point(160, 96);
            this.updateModelNumber.Name = "updateModelNumber";
            this.updateModelNumber.Size = new System.Drawing.Size(102, 16);
            this.updateModelNumber.TabIndex = 493;
            this.updateModelNumber.Text = "Project Code:";
            // 
            // comselectedprojectcodeBom
            // 
            this.comselectedprojectcodeBom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comselectedprojectcodeBom.DropDownHeight = 130;
            this.comselectedprojectcodeBom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comselectedprojectcodeBom.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comselectedprojectcodeBom.FormattingEnabled = true;
            this.comselectedprojectcodeBom.IntegralHeight = false;
            this.comselectedprojectcodeBom.Location = new System.Drawing.Point(268, 91);
            this.comselectedprojectcodeBom.Name = "comselectedprojectcodeBom";
            this.comselectedprojectcodeBom.Size = new System.Drawing.Size(214, 26);
            this.comselectedprojectcodeBom.TabIndex = 492;
            this.comselectedprojectcodeBom.SelectedIndexChanged += new System.EventHandler(this.comselectedprojectcodeBom_SelectedIndexChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.groupBox2.Controls.Add(this.butUpdate);
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.buttprojectclosersave);
            this.groupBox2.Location = new System.Drawing.Point(294, 317);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(624, 51);
            this.groupBox2.TabIndex = 503;
            this.groupBox2.TabStop = false;
            // 
            // butUpdate
            // 
            this.butUpdate.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.butUpdate.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.butUpdate.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butUpdate.Location = new System.Drawing.Point(262, 9);
            this.butUpdate.Name = "butUpdate";
            this.butUpdate.Size = new System.Drawing.Size(100, 33);
            this.butUpdate.TabIndex = 501;
            this.butUpdate.Text = "Update";
            this.butUpdate.UseVisualStyleBackColor = false;
            this.butUpdate.Click += new System.EventHandler(this.butUpdate_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(458, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 33);
            this.button1.TabIndex = 500;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // buttprojectclosersave
            // 
            this.buttprojectclosersave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.buttprojectclosersave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.buttprojectclosersave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttprojectclosersave.Location = new System.Drawing.Point(56, 12);
            this.buttprojectclosersave.Name = "buttprojectclosersave";
            this.buttprojectclosersave.Size = new System.Drawing.Size(100, 33);
            this.buttprojectclosersave.TabIndex = 498;
            this.buttprojectclosersave.Text = "Save";
            this.buttprojectclosersave.UseVisualStyleBackColor = false;
            this.buttprojectclosersave.Click += new System.EventHandler(this.buttprojectclosersave_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.groupBox1.Location = new System.Drawing.Point(59, 21);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1079, 51);
            this.groupBox1.TabIndex = 504;
            this.groupBox1.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(493, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 19);
            this.label5.TabIndex = 505;
            this.label5.Text = "ORDER ENTRY";
            // 
            // Order_Entry
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 481);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.updateModelNumber);
            this.Controls.Add(this.comselectedprojectcodeBom);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dtpdelivery);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtMachineSerialNo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtAmount);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comBillingType);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.cmbid);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Order_Entry";
            this.Text = "Order_Entry";
            this.Load += new System.EventHandler(this.Order_Entry_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbid;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comBillingType;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMachineSerialNo;
        private System.Windows.Forms.DateTimePicker dtpdelivery;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label updateModelNumber;
        private System.Windows.Forms.ComboBox comselectedprojectcodeBom;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button butUpdate;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button buttprojectclosersave;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
    }
}