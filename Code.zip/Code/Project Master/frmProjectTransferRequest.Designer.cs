﻿namespace Erp_Project_With_Buttons.Project_Master
{
    partial class frmProjectTransferRequest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProjectTransferRequest));
            this.pnProjectTransfer = new System.Windows.Forms.Panel();
            this.btnSelectProjectCode = new System.Windows.Forms.Button();
            this.lblProjectCode = new System.Windows.Forms.Label();
            this.txtProjectName = new System.Windows.Forms.Label();
            this.cmbProjectCode = new System.Windows.Forms.ComboBox();
            this.lblProjectName = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbMainProjectcode = new System.Windows.Forms.ComboBox();
            this.btnProjectView = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblMainProjectName = new System.Windows.Forms.Label();
            this.pnProjectTransfer.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnProjectTransfer
            // 
            this.pnProjectTransfer.Controls.Add(this.btnSelectProjectCode);
            this.pnProjectTransfer.Controls.Add(this.lblProjectCode);
            this.pnProjectTransfer.Controls.Add(this.txtProjectName);
            this.pnProjectTransfer.Controls.Add(this.cmbProjectCode);
            this.pnProjectTransfer.Controls.Add(this.lblProjectName);
            this.pnProjectTransfer.Location = new System.Drawing.Point(12, 187);
            this.pnProjectTransfer.Name = "pnProjectTransfer";
            this.pnProjectTransfer.Size = new System.Drawing.Size(903, 126);
            this.pnProjectTransfer.TabIndex = 127;
            // 
            // btnSelectProjectCode
            // 
            this.btnSelectProjectCode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSelectProjectCode.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectProjectCode.Location = new System.Drawing.Point(459, 3);
            this.btnSelectProjectCode.Name = "btnSelectProjectCode";
            this.btnSelectProjectCode.Size = new System.Drawing.Size(24, 24);
            this.btnSelectProjectCode.TabIndex = 143;
            this.btnSelectProjectCode.Text = "....";
            this.btnSelectProjectCode.UseVisualStyleBackColor = false;
            this.btnSelectProjectCode.Click += new System.EventHandler(this.btnSelectProjectCode_Click);
            // 
            // lblProjectCode
            // 
            this.lblProjectCode.AutoSize = true;
            this.lblProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectCode.ForeColor = System.Drawing.Color.Black;
            this.lblProjectCode.Location = new System.Drawing.Point(26, 6);
            this.lblProjectCode.Name = "lblProjectCode";
            this.lblProjectCode.Size = new System.Drawing.Size(151, 18);
            this.lblProjectCode.TabIndex = 122;
            this.lblProjectCode.Text = "Transfer Project Code*:";
            // 
            // txtProjectName
            // 
            this.txtProjectName.AutoSize = true;
            this.txtProjectName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProjectName.ForeColor = System.Drawing.Color.Black;
            this.txtProjectName.Location = new System.Drawing.Point(175, 49);
            this.txtProjectName.Name = "txtProjectName";
            this.txtProjectName.Size = new System.Drawing.Size(12, 18);
            this.txtProjectName.TabIndex = 125;
            this.txtProjectName.Text = ".";
            // 
            // cmbProjectCode
            // 
            this.cmbProjectCode.DropDownHeight = 130;
            this.cmbProjectCode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProjectCode.FormattingEnabled = true;
            this.cmbProjectCode.IntegralHeight = false;
            this.cmbProjectCode.Location = new System.Drawing.Point(178, 3);
            this.cmbProjectCode.Name = "cmbProjectCode";
            this.cmbProjectCode.Size = new System.Drawing.Size(275, 26);
            this.cmbProjectCode.TabIndex = 123;
            this.cmbProjectCode.SelectedIndexChanged += new System.EventHandler(this.cmbProjectCode_SelectedIndexChanged);
            // 
            // lblProjectName
            // 
            this.lblProjectName.AutoSize = true;
            this.lblProjectName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectName.ForeColor = System.Drawing.Color.Black;
            this.lblProjectName.Location = new System.Drawing.Point(81, 49);
            this.lblProjectName.Name = "lblProjectName";
            this.lblProjectName.Size = new System.Drawing.Size(96, 18);
            this.lblProjectName.TabIndex = 124;
            this.lblProjectName.Text = "Project Name:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(79, 77);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 19);
            this.label6.TabIndex = 143;
            this.label6.Text = "Project Name :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(85, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 19);
            this.label1.TabIndex = 140;
            this.label1.Text = "Project Code :";
            // 
            // cmbMainProjectcode
            // 
            this.cmbMainProjectcode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbMainProjectcode.DropDownHeight = 130;
            this.cmbMainProjectcode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMainProjectcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbMainProjectcode.FormattingEnabled = true;
            this.cmbMainProjectcode.IntegralHeight = false;
            this.cmbMainProjectcode.Location = new System.Drawing.Point(195, 31);
            this.cmbMainProjectcode.Name = "cmbMainProjectcode";
            this.cmbMainProjectcode.Size = new System.Drawing.Size(282, 26);
            this.cmbMainProjectcode.TabIndex = 141;
            this.cmbMainProjectcode.SelectedIndexChanged += new System.EventHandler(this.cmbMainProjectcode_SelectedIndexChanged);
            // 
            // btnProjectView
            // 
            this.btnProjectView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnProjectView.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProjectView.Location = new System.Drawing.Point(488, 33);
            this.btnProjectView.Name = "btnProjectView";
            this.btnProjectView.Size = new System.Drawing.Size(24, 24);
            this.btnProjectView.TabIndex = 142;
            this.btnProjectView.Text = "....";
            this.btnProjectView.UseVisualStyleBackColor = false;
            this.btnProjectView.Click += new System.EventHandler(this.btnProjectView_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnSave);
            this.groupBox2.Controls.Add(this.btnExit);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox2.Location = new System.Drawing.Point(123, 423);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(678, 64);
            this.groupBox2.TabIndex = 144;
            this.groupBox2.TabStop = false;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(391, 12);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(99, 46);
            this.btnSave.TabIndex = 11;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(530, 12);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(92, 46);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblMainProjectName
            // 
            this.lblMainProjectName.AutoSize = true;
            this.lblMainProjectName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMainProjectName.ForeColor = System.Drawing.Color.Black;
            this.lblMainProjectName.Location = new System.Drawing.Point(195, 77);
            this.lblMainProjectName.Name = "lblMainProjectName";
            this.lblMainProjectName.Size = new System.Drawing.Size(12, 18);
            this.lblMainProjectName.TabIndex = 145;
            this.lblMainProjectName.Text = ".";
            // 
            // frmProjectTransferRequest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(927, 489);
            this.Controls.Add(this.lblMainProjectName);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbMainProjectcode);
            this.Controls.Add(this.btnProjectView);
            this.Controls.Add(this.pnProjectTransfer);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmProjectTransferRequest";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Project Transfer Request";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmProjectTransferRequest_FormClosing);
            this.Load += new System.EventHandler(this.frmProjectTransferRequest_Load);
            this.pnProjectTransfer.ResumeLayout(false);
            this.pnProjectTransfer.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnProjectTransfer;
        private System.Windows.Forms.Label lblProjectCode;
        private System.Windows.Forms.Label txtProjectName;
        private System.Windows.Forms.ComboBox cmbProjectCode;
        private System.Windows.Forms.Label lblProjectName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbMainProjectcode;
        private System.Windows.Forms.Button btnProjectView;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSelectProjectCode;
        private System.Windows.Forms.Label lblMainProjectName;
    }
}