﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using EXCEL = Microsoft.Office.Interop.Excel;

namespace Erp_Project_With_Buttons.Project_Master
{
    public partial class frmProjectTracker : Form
    {
        Global GLobalClass = new Global();
        DataTable dtpro = new DataTable();
        DataAccessLayer DAL = new DataAccessLayer();
        DataTable dtWIPProjectlist = new DataTable();
        DataTable dtprojecttrakdetails = new DataTable();
        string ExcelFolderPath;
        string FileFullPath;
        public frmProjectTracker()
        {
            InitializeComponent();
        }

        private void frmProjectTracker_Load(object sender, EventArgs e)
        {
            dtWIPProjectlist= DAL.fnWIPProjectList(null).Tables[0];
            foreach (DataRow DR in dtWIPProjectlist.Rows)
            {
                if (!cmbprocode.Items.Contains(DR["ProjectCode"].ToString()))
                    cmbprocode.Items.Add(DR["ProjectCode"].ToString());
            }
        }

        private void cmbprocode_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable protrack = new DataTable();
            protrack = DAL.getProTracker(1, cmbprocode.Text,"").Tables[0];
            if(protrack.Rows.Count>0)
            {
                btmsubmit.Text = "Update";
                // dtpro = DAL.getProTracker(1, cmbprocode.Text).Tables[0];
                dgvProTracker.AutoGenerateColumns = false;
                dgvProTracker.DataSource = protrack;
            }
            else
            {
                btmsubmit.Text = "Save"; 
                dtpro = DAL.getProTracker(0, cmbprocode.Text,"").Tables[0];
                dgvProTracker.AutoGenerateColumns = false;
                dgvProTracker.DataSource = dtpro;
            }
           

        }

        private void btmsubmit_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow rw in this.dgvProTracker.Rows)
            {
                for (int i = 0; i < rw.Cells.Count; i++)
                {
                    if (rw.Cells[i].Value == null || rw.Cells[i].Value == DBNull.Value || String.IsNullOrWhiteSpace(rw.Cells[i].Value.ToString()))
                    {
                        rw.Cells[i].Value ="";
                    }
                }
            }

            if(btmsubmit.Text == "Save")
            {
                foreach (DataGridViewRow row in dgvProTracker.Rows)
                {
                    GLobalClass.iSuccess = DAL.insertprotracker(0, row.Cells["ProjectName"].Value.ToString(), row.Cells["ProjectCode"].Value.ToString(), row.Cells["Year"].Value.ToString(), row.Cells["Month"].Value.ToString(), row.Cells["Date"].Value.ToString(), row.Cells["MoctDate"].Value.ToString(), row.Cells["DelivaeryDate"].Value.ToString(), row.Cells["DeliveryDatepo"].Value.ToString(), row.Cells["PaymentTerms"].Value.ToString(), row.Cells["PDIbiss"].Value.ToString(), row.Cells["LDClause"].Value.ToString(), row.Cells["MachineRetrofit"].Value.ToString(), row.Cells["MachineType"].Value.ToString(), row.Cells["Producttype"].Value.ToString(), row.Cells["ComplexityLevel"].Value.ToString(), row.Cells["ProjectFocal"].Value.ToString(), row.Cells["PlannedMonth"].Value.ToString(), row.Cells["ActualMonth"].Value.ToString(), row.Cells["OntimeDelivery"].Value.ToString(), row.Cells["Shipmentstatus"].Value.ToString(), row.Cells["SiteRequirement"].Value.ToString(), row.Cells["CriticalPath"].Value.ToString(), row.Cells["ProposePDI"].Value.ToString(), row.Cells["Actualpdi"].Value.ToString(), row.Cells["Actualshipment"].Value.ToString(), row.Cells["Projecctclose"].Value.ToString(), row.Cells["Remarks"].Value.ToString());
                   
                }
                if (GLobalClass.iSuccess > 0)
                {
                    MessageBox.Show("Project Details Saved Successfully", "Success", 0, MessageBoxIcon.Information);
                    dgvProTracker.DataSource = null;
                    btmsubmit.Enabled = false;
                }
            }
            else
            {
                foreach (DataGridViewRow row in dgvProTracker.Rows)
                {
                    GLobalClass.iSuccess = DAL.insertprotracker(1, row.Cells["ProjectName"].Value.ToString(), row.Cells["ProjectCode"].Value.ToString(), row.Cells["Year"].Value.ToString(), row.Cells["Month"].Value.ToString(), row.Cells["Date"].Value.ToString(), row.Cells["MoctDate"].Value.ToString(), row.Cells["DelivaeryDate"].Value.ToString(), row.Cells["DeliveryDatepo"].Value.ToString(), row.Cells["PaymentTerms"].Value.ToString(), row.Cells["PDIbiss"].Value.ToString(), row.Cells["LDClause"].Value.ToString(), row.Cells["MachineRetrofit"].Value.ToString(), row.Cells["MachineType"].Value.ToString(), row.Cells["Producttype"].Value.ToString(), row.Cells["ComplexityLevel"].Value.ToString(), row.Cells["ProjectFocal"].Value.ToString(), row.Cells["PlannedMonth"].Value.ToString(), row.Cells["ActualMonth"].Value.ToString(), row.Cells["OntimeDelivery"].Value.ToString(), row.Cells["Shipmentstatus"].Value.ToString(), row.Cells["SiteRequirement"].Value.ToString(), row.Cells["CriticalPath"].Value.ToString(), row.Cells["ProposePDI"].Value.ToString(), row.Cells["Actualpdi"].Value.ToString(), row.Cells["Actualshipment"].Value.ToString(), row.Cells["Projecctclose"].Value.ToString(), row.Cells["Remarks"].Value.ToString());
                   
                }
                if (GLobalClass.iSuccess > 0)
                {
                    MessageBox.Show("Project Details updated Successfully", "Success", 0, MessageBoxIcon.Information);
                }
            }           
        }

        private void dgvProTracker_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 5 || e.ColumnIndex == 20 || e.ColumnIndex == 22 || e.ColumnIndex == 23 || e.ColumnIndex == 24)
            {
                cmbyesno.Visible = false;
                cmbmonth.Visible = false;
                oDateTimePicker.Visible = false;
                oDateTimePicker = new DateTimePicker();
                dgvProTracker.Controls.Add(oDateTimePicker);
                oDateTimePicker.Format = DateTimePickerFormat.Custom;
                oDateTimePicker.CustomFormat = "dd-MM-yyyy";
                Rectangle oRectangle = dgvProTracker.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, true);
                oDateTimePicker.Size = new Size(oRectangle.Width, oRectangle.Height);
                oDateTimePicker.Location = new Point(oRectangle.X, oRectangle.Y);
                oDateTimePicker.CloseUp += new EventHandler(oDateTimePicker_CloseUp);
                oDateTimePicker.TextChanged += new EventHandler(oDateTimePicker_TabIndexChanged);
                oDateTimePicker.Visible = true;
            }
            else
            {
                if (e.ColumnIndex == 16 || e.ColumnIndex == 17)
                {
                    cmbyesno.Visible = false;
                    cmbmonth.Visible = false;
                    oDateTimePicker.Visible = false;
                    int x = 0;
                    int y = 0;
                    int Width = 0;
                    int height = 0;
                    Rectangle rect = default(Rectangle);
                    rect = dgvProTracker.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, false);
                    x = rect.X + dgvProTracker.Left;
                    y = rect.Y + dgvProTracker.Top;

                    Width = rect.Width;
                    height = rect.Height;

                    cmbmonth.SetBounds(x, y, Width, height);
                    cmbmonth.Visible = true;
                    cmbmonth.DroppedDown = true;
                }
                else
                {
                    if(e.ColumnIndex == 19 || e.ColumnIndex == 21 ||e.ColumnIndex == 25)
                    {
                        cmbyesno.Visible = false;
                        cmbmonth.Visible = false;
                        oDateTimePicker.Visible = false;
                        int x = 0;
                        int y = 0;
                        int Width = 0;
                        int height = 0;
                        Rectangle rect = default(Rectangle);
                        rect = dgvProTracker.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, false);
                        x = rect.X + dgvProTracker.Left;
                        y = rect.Y + dgvProTracker.Top;

                        Width = rect.Width;
                        height = rect.Height;

                        cmbyesno.SetBounds(x, y, Width, height);
                        cmbyesno.Visible = true;
                        cmbyesno.DroppedDown = true;
                    }
                    else
                    {
                        cmbyesno.Visible = false;
                        cmbmonth.Visible = false;
                        oDateTimePicker.Visible = false;
                    }
                }
              
            }
            
        }

        private void oDateTimePicker_CloseUp(object sender, EventArgs e)
        {
            oDateTimePicker.Visible = false;
        }

        private void oDateTimePicker_TabIndexChanged(object sender, EventArgs e)
        {
            dgvProTracker.CurrentCell.Value = oDateTimePicker.Text.ToString();
        }

        private void dgvProTracker_Scroll(object sender, ScrollEventArgs e)
        {
            if(dgvProTracker.Rows.Count>0)
            {
                int x = 0;
                int y = 0;
                int Width = 0;
                int height = 0;
               
                int columnIndex = dgvProTracker.CurrentCell.ColumnIndex;
                int rowIndex = dgvProTracker.CurrentCell.RowIndex;
                Rectangle oRectangle = dgvProTracker.GetCellDisplayRectangle(columnIndex, 0, true);
                oDateTimePicker.Size = new Size(oRectangle.Width, oRectangle.Height);
                oDateTimePicker.Location = new Point(oRectangle.X, oRectangle.Y);
                x = oRectangle.X + dgvProTracker.Left;
                y = oRectangle.Y + dgvProTracker.Top;

                Width = oRectangle.Width;
                height = oRectangle.Height;
                cmbyesno.SetBounds(x, y, Width, height);
                cmbmonth.SetBounds(x, y, Width, height);
            }          
          
        }

        private void cmbmonth_SelectedIndexChanged(object sender, EventArgs e)
        {
            dgvProTracker.CurrentCell.Value = cmbmonth.Text.ToString();
            if (dgvProTracker.Rows[0].Cells[16].Value.Equals(dgvProTracker.Rows[0].Cells[17].Value))
            {
                dgvProTracker.Rows[0].Cells[18].Value = "Yes";
            }
            if (!dgvProTracker.Rows[0].Cells[16].Value.Equals(dgvProTracker.Rows[0].Cells[17].Value))
            {
                dgvProTracker.Rows[0].Cells[18].Value = "No";
            }
        }

        private void cmbyesno_SelectedIndexChanged(object sender, EventArgs e)
        {
            dgvProTracker.CurrentCell.Value = cmbyesno.Text.ToString();
                      
        }

        
        private void excelbtn_Click(object sender, EventArgs e)
        {
            string frmdte = DateTime.ParseExact(frmdate.Text, "dd/MM/yyyy", null).ToString("yyyy-MM-dd");
            string todte = DateTime.ParseExact(todate.Text, "dd/MM/yyyy", null).ToString("yyyy-MM-dd");
            dtprojecttrakdetails = DAL.getProTracker(2, frmdte, todte).Tables[0];
            if (dtprojecttrakdetails.Rows.Count > 0)
            {
                string ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\Project Tracking Report\\";
                string FileFullPath = ExcelFolderPath + "Project Tracking Report " + DateTime.Now.ToString("d/M/yyyy hh/mm/ss");
                if (!Directory.Exists(ExcelFolderPath))
                    System.IO.Directory.CreateDirectory(ExcelFolderPath);
                string finalColLetter = string.Empty;
                DataSet ds = new DataSet("ProjectTracking");
              DataTable  dtCopy = dtprojecttrakdetails.Copy();
                ds.Tables.Add(dtCopy);
               // dspro.Tables.Add(dtprojecttrakdetails);
                ExportToExcel(ds, FileFullPath, "Project Tracking");
            }
            else
            {
                MessageBox.Show("Selected date has no records to genarate report!");
            }          
           
        }
     
        public void ExportToExcel(DataSet dataSet, string outputPath, string tablename)
        {
            EXCEL.Workbook NewWorkBook;
            EXCEL.Worksheet worksheet;
            EXCEL.Application excelApp;

            excelApp = new Microsoft.Office.Interop.Excel.Application();
            NewWorkBook = excelApp.Workbooks.Add(Type.Missing);
            worksheet = NewWorkBook.Sheets["Sheet1"];
            worksheet = NewWorkBook.ActiveSheet;
            worksheet.Name = tablename;
            int StockValue;

            foreach (System.Data.DataTable dt in dataSet.Tables)
            {

                // Copy the DataTable to an object array
                object[,] rawData = new object[dt.Rows.Count + 1, dt.Columns.Count];

                // Copy the column names to the first row of the object array
                //for (int col = 0; col < dt.Columns.Count; col++)
                //{
                //    rawData[0, col] = dt.Columns[col].ColumnName;
                //}
                // Copy the values to the object array
                //for (int col = 0; col < dt.Columns.Count; col++)
                //{
                //    for (int row = 0; row < dt.Rows.Count; row++)
                //    {
                //        rawData[row + 1, col] = dt.Rows[row].ItemArray[col];
                //    }
                //}

                string finalColLetter = string.Empty;
                string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                int colCharsetLen = colCharset.Length;

                if (dt.Columns.Count > colCharsetLen)
                {
                    finalColLetter = colCharset.Substring((dt.Columns.Count - 1) / colCharsetLen - 1, 1);
                }
                finalColLetter += colCharset.Substring((dt.Columns.Count - 1) % colCharsetLen, 1);
                worksheet.Columns.AutoFit();
                worksheet.Rows.AutoFit();
                worksheet.Cells[2, 2] = Global.sCompanyName;
                worksheet.Range["A2:C2"].Cells.Font.Size = 14;
                worksheet.Range["A2:C2"].Cells.Font.Bold = 14;
                worksheet.get_Range("A2", "B2").Merge(true);
                string excelRange;
                worksheet.Rows.RowHeight = "18";
                switch (tablename)
                {
                    case "Project Tracking":
                        worksheet.Cells[4, 2] = "Project Tracking Report";
                        worksheet.Range["A4:C4"].Cells.Font.Size = 14;
                        worksheet.Range["A4:C4"].Cells.Font.Bold = 14;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[7, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[7, Type.Missing]).Font.Size = 12;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[7, Type.Missing]).Font.Color = Color.Red;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[6, Type.Missing]).Font.Bold = true;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[6, Type.Missing]).Font.Size = 14;
                        ((Microsoft.Office.Interop.Excel.Range)worksheet.Rows[6, Type.Missing]).Font.Color = Color.Red;
                        excelRange = string.Format("A7:{0}{1}", finalColLetter, dt.Rows.Count + 7);
                        //worksheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                        for (int col = 0; col < dt.Columns.Count; col++)
                        {
                            worksheet.Cells[7, col+1] = dt.Columns[col].ColumnName;
                        }
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            worksheet.Cells[i + 8, 1] = dt.Rows[i]["Project Name"].ToString();
                            worksheet.Cells[i + 8, 2] = dt.Rows[i]["Project Code"].ToString(); 
                            worksheet.Cells[i + 8, 3] = dt.Rows[i]["Year"].ToString();
                            worksheet.Cells[i + 8, 4] = dt.Rows[i]["Month"].ToString();
                            worksheet.Cells[i + 8, 5] = (!string.IsNullOrEmpty(dt.Rows[i]["Date"].ToString())) ? Convert.ToDateTime(dt.Rows[i]["Date"]).ToString("dd/MMM/yyyy") : "";
                            worksheet.Cells[i + 8, 6] = (!string.IsNullOrEmpty(dt.Rows[i]["MoCT Date"].ToString())) ? Convert.ToDateTime(dt.Rows[i]["MoCT Date"]).ToString("dd/MMM/yyyy") : "";
                            worksheet.Cells[i + 8, 7] = (!string.IsNullOrEmpty(dt.Rows[i]["Delivery Date as Per Order Entry"].ToString())) ? Convert.ToDateTime(dt.Rows[i]["Delivery Date as Per Order Entry"]).ToString("dd/MMM/yyyy") : ""; 
                            worksheet.Cells[i + 8, 8] = (!string.IsNullOrEmpty(dt.Rows[i]["Delivery Date as per PO"].ToString())) ? Convert.ToDateTime(dt.Rows[i]["Delivery Date as per PO"]).ToString("dd/MMM/yyyy") : "";
                            worksheet.Cells[i + 8, 9] = dt.Rows[i]["Payment Terms"].ToString();
                            worksheet.Cells[i + 8, 10] = dt.Rows[i]["PDI at BISS"].ToString();
                            worksheet.Cells[i + 8, 11] = dt.Rows[i]["LD Clause"].ToString();
                            worksheet.Cells[i + 8, 12] = dt.Rows[i]["Machine / Retrofit / Accessories / OTC"].ToString();
                            worksheet.Cells[i + 8, 13] = dt.Rows[i]["Machine Type: STD / CUS"].ToString();
                            worksheet.Cells[i + 8, 14] = dt.Rows[i]["Product Type 80 / 20"].ToString();
                            worksheet.Cells[i + 8, 15] = dt.Rows[i]["Complexity Level"].ToString();
                            worksheet.Cells[i + 8, 16] = dt.Rows[i]["Project Focal"].ToString();
                            worksheet.Cells[i + 8, 17] = dt.Rows[i]["Original Planned Month"].ToString();
                            worksheet.Cells[i + 8, 18] = dt.Rows[i]["Actual Month"].ToString();
                            worksheet.Cells[i + 8, 19] = dt.Rows[i]["On Time Delivery vs Original Planned"].ToString();
                            worksheet.Cells[i + 8, 20] = dt.Rows[i]["Shipment Status"].ToString();
                            worksheet.Cells[i + 8, 21] = (!string.IsNullOrEmpty(dt.Rows[i]["Site Requirement Details"].ToString())) ? Convert.ToDateTime(dt.Rows[i]["Site Requirement Details"]).ToString("dd/MMM/yyyy") : "";
                            worksheet.Cells[i + 8, 22] = dt.Rows[i]["Critical Path Status"].ToString();
                            worksheet.Cells[i + 8, 23] = (!string.IsNullOrEmpty(dt.Rows[i]["Proposed PDI / Dispatch Status"].ToString())) ? Convert.ToDateTime(dt.Rows[i]["Proposed PDI / Dispatch Status"]).ToString("dd/MMM/yyyy") : "";
                            worksheet.Cells[i + 8, 24] = (!string.IsNullOrEmpty(dt.Rows[i]["Actual PDI Dates"].ToString())) ? Convert.ToDateTime(dt.Rows[i]["Actual PDI Dates"]).ToString("dd/MMM/yyyy") : "";
                            worksheet.Cells[i + 8, 25] = (!string.IsNullOrEmpty(dt.Rows[i]["Actual Shipment Date"].ToString())) ? Convert.ToDateTime(dt.Rows[i]["Actual Shipment Date"]).ToString("dd/MMM/yyyy") : "";
                            worksheet.Cells[i + 8, 26] = dt.Rows[i]["Project Closure Status"].ToString();
                            worksheet.Cells[i + 8, 27] = dt.Rows[i]["Remarks"].ToString();
                                                  
                        }

                        worksheet.Columns.AutoFit();
                        worksheet.Columns.WrapText = true;
                        worksheet.Rows.AutoFit();
                         worksheet.get_Range("A6", "Z9999").HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;
                        //worksheet.get_Range("D6", "E9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignTop;
                        //worksheet.get_Range("A1", "A1").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignLeft;

                        worksheet.Columns[1].ColumnWidth = 35;
                        worksheet.Columns[1].WrapText = true;
                        worksheet.Columns[2].ColumnWidth = 27;
                        worksheet.Columns[2].WrapText = true;
                        worksheet.Columns[27].ColumnWidth = 30;
                        worksheet.Columns[27].WrapText = true;
                        CellMerge("Merge", worksheet, 6, 6, 3, 11);
                        CellMerge("Merge", worksheet, 6, 6, 12, 26);                       
                        CellMerge("AlignCenter", worksheet, 6, 6, 3, 11);
                        CellMerge("AlignCenter", worksheet, 6, 6, 12, 26);
                       
                        worksheet.Cells[6, 3] = "Input Details";
                        worksheet.Cells[6, 12] = "Project Execution Details";
                        worksheet.Cells[6, 27] = "Ramarks";

                        worksheet.Cells[6, 14].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightBlue);
                        worksheet.Cells[6, 21].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightGoldenrodYellow);
                        worksheet.Cells[6, 32].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Lavender);
                        worksheet.Cells[6, 43].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightCyan);
                        worksheet.Cells[6, 54].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightGreen);
                        //To add  background color to the cell
                        //for (int i = 0; i <= dt.Rows.Count; i++)
                        //{
                        //    for (int J = 14; J <= 20; J++)
                        //    {
                        //        worksheet.Cells[i + 7, J].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightBlue);
                        //    }
                        //    for (int a = 21; a <= 31; a++)
                        //    {
                        //        worksheet.Cells[i + 7, a].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightGoldenrodYellow);
                        //    }
                        //    for (int b = 32; b <= 42; b++)
                        //    {
                        //        worksheet.Cells[i + 7, b].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Lavender);
                        //    }
                        //    for (int c = 43; c <= 53; c++)
                        //    {
                        //        worksheet.Cells[i + 7, c].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightCyan);
                        //    }
                        //    for (int d = 54; d <= 57; d++)
                        //    {
                        //        worksheet.Cells[i + 7, d].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightGreen);
                        //    }
                        //}
                        //-------------Row freezing code---------------
                        //worksheet.Application.ActiveSheet.Rows[8].Select();
                        //worksheet.Application.ActiveWindow.FreezePanes = true;
                        //----------------Column freezing code--------------
                        worksheet.Activate();
                        worksheet.Application.ActiveWindow.SplitColumn = 2;
                        worksheet.Application.ActiveWindow.FreezePanes = true;
                        int L = dt.Rows.Count;
                        worksheet.get_Range("A6", "AA" + (L + 10) + "").Cells.Borders.Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin;
                        ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\Project Tracking Report\\";
                        Process.Start(ExcelFolderPath);
                        break;
                }
            }
            NewWorkBook.SaveAs(outputPath, Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook, Type.Missing,
                               Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive,
                               Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

            NewWorkBook.Save();
            NewWorkBook.Close(true, Type.Missing, Type.Missing);
            excelApp.Quit();
            releaseObject(worksheet);
            releaseObject(NewWorkBook);
            releaseObject(excelApp);
        }
        public void fnDateFormat(EXCEL.Worksheet worksheet, int column1, int column2)
        {
            Microsoft.Office.Interop.Excel.Range date = (Microsoft.Office.Interop.Excel.Range)worksheet.Cells[column1, column2];
            date.EntireColumn.NumberFormat = "DD/MM/YYYY";
        }
        public void fnDateFormatstring(EXCEL.Worksheet worksheet, string column1, string column2)
        {
            Microsoft.Office.Interop.Excel.Range date = worksheet.get_Range(column1, column2);
            date.EntireColumn.NumberFormat = "DD/MM/YYYY";
        }
        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlMedium, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignTop":
                    {
                        CELLS.VerticalAlignment = EXCEL.XlVAlign.xlVAlignTop;
                        break;
                    }
                case "ThinBorder":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        //   CELLS.Borders.Color.SetColor(Color.Red);  
                        break;
                    }

                case "GridLines":
                    {
                        CELLS.Borders.Color = System.Drawing.Color.Black;
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignCenter":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                        break;
                    }
                case "Bold":
                    {
                        CELLS.Font.Bold = true;
                        break;
                    }
                default:
                    {
                        break;
                    }
            }
        }

        private void frmProjectTracker_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.Hide();
            Project_Master.frmProjectHome Home = new Project_Master.frmProjectHome();
            Home.Show();
        }
    }
}
