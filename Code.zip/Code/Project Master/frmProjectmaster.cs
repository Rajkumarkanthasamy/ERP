﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using EXCEL = Microsoft.Office.Interop.Excel;
using Outlook = Microsoft.Office.Interop.Outlook;
using System.IO;
using System.Globalization;
using System.Text.RegularExpressions;

namespace Erp_Project_With_Buttons
{
    public partial class frmProjectmaster : Form
    {
        DataAccessLayer DAL = new DataAccessLayer();
        Global GlobalClass = new Global();

        frmForm2 Home = new frmForm2();
        Login.frmLoginForm login = new Login.frmLoginForm();
        DataTable dtProjectList = new DataTable();
        DataTable dtProjectList1 = new DataTable();
        DataTable dtrevenueqn = new DataTable();
        DataTable dtCustomerList = new DataTable();
        DataRow[] DR;
        DataTable dtProjectOrderEntry = new DataTable();
        DataTable dtProjectOrderManager = new DataTable();

        Project_Master.frmPorjectMail Mail = new Project_Master.frmPorjectMail();
        Project_Documents.frmProjectDocs ProjectDocs = new Project_Documents.frmProjectDocs();
        private string sProjectType = string.Empty;
        private string sProductType = string.Empty;
        private string sCustomerCode = string.Empty;
        private string sSerialNo = string.Empty;
        private static string sProjectCode;
        private static bool bSearch;
        private bool bDateChange = false;
        
        public string fnGetProjectCode //get selected project code from project list form
        {
            get
            {
                return sProjectCode;
            }
            set
            {
                sProjectCode = value;
            }
        }

        private void fnProjectCodeGeneration()
        {
            sProjectCode = string.Empty;
            sProjectType = string.Empty;
            sProductType = string.Empty;
            switch (cmbProjectType.Text)
            {
                case "Customer (CUS)":
                    {
                        sProjectType = "CUS";
                        break;
                    }
                case "R&D (RND)":
                    {
                        sProjectType = "RND";
                        break;
                    }
                case "TestingLab (TEL)":
                    {
                        sProjectType = "TEL";
                        break;
                    }
                case "Parts (PRT)":
                    {
                        sProjectType = "PRT";
                        break;
                    }
                case "PurchaseStock(PST)":
                    {
                        sProjectType = "PST";
                        break;
                    }
                case "Accessories (OTC)":
                    {
                        sProjectType = "OTC";
                        break;
                    }
                case "Stock (STO)":
                    {
                        sProjectType = "STO";
                        break;
                    }
                case "Fixed Asset (CIP)":
                    {
                        sProjectType = "CIP";
                        break;
                    }
                case "Testing for Sales and Marketing (SAL)":
                    {
                        sProjectType = "SAL";
                        break;
                    }
                case "Annual Maintenance Service (AMC)":
                    {
                        sProjectType = "AMC";
                        break;
                    }

                case "Expenses (EXP)":
                    {
                        sProjectType = "EXP";
                        break;
                    }
                case "Contract Testing Service (CTS)":
                    {
                        sProjectType = "CTS";
                        break;
                    }
                case "Product Service (PRS)":
                    {
                        sProjectType = "PRS";
                        break;
                    }
                case "Calibration (CAL)":
                    {
                        sProjectType = "CAL";
                        break;
                    }
                case "Repair/Breakdown (RBR)":
                    {
                        sProjectType = "RBR";
                        break;
                    }

                case "INSTRON(INS)":
                    {
                        sProjectType = "INS";
                        break;
                    }
                case "BATCH ORDER FOR PROJECTS (BOP)":
                    {
                        sProjectType = "BOP";
                        break;
                    }
                default:
                    sProjectType = cmbProjectType.Text.Substring(0, 3);
                    break;
            }
            
            switch (cmbPMProductType.Text)
            {
                case "UTM":
                    sProductType = "UTM";
                    break;
                case "STS":
                    sProductType = "STS";
                    break;
                case "DTS":
                    sProductType = "DTS";
                    break;
                case "LFS":
                    sProductType = "LFS";
                    break;
                case "TGT":
                    sProductType = "TGT";
                    break;
                case "FSW":
                    sProductType = "FSW";
                    break;
                case "ShakeTable":
                    sProductType = "SHT";
                    break;
                case "CustomRigs":
                    sProductType = "CSM";
                    break;
                case "Others":
                    sProductType = "OTS";
                    break;
                case "Inhouse":
                    sProductType = "CIN";
                    break;
                case "Capital":
                    sProductType = "CAP";
                    break;
                case "EM":
                    sProductType = "EM";
                    break;

                case "EP":
                    sProductType = "EP";
                    break;
                case "CEAST":
                    sProductType = "CEAST";
                    break;
                case "IPG":
                    sProductType = "IPG";
                    break;
                case "SH":
                    sProductType = "SH";
                    break;
                case "SMARTER":
                    sProductType = "SMARTER";
                    break;
                case "BiSS":
                    sProductType = "BiSS";
                    break;
               
                default:
                    sProductType = cmbPMProductType.Text.Substring(0, 3);
                    break;
            
            }
            
            dtProjectSlNo = DAL.fnDepartmentList(3, null, null).Tables[0];

            // DR = dtProjectList.Select("ProjectCode like '%" + DateTime.Today.ToString("yyyy-MM") + "%'");
            if (dtProjectSlNo.Rows.Count > 0)
            {
                // sSerialNo = string.Concat("0", (DR.Length + 1));

                int iSlno = Convert.ToInt32(dtProjectSlNo.Rows[0][0].ToString());
                iSlno++;
                int iSlNO1 = 100000 + iSlno;
                sSerialNo = iSlNO1.ToString();
                sProjectCode = string.Concat(sProjectType, "-", DateTime.Today.ToString("yyyy-MM"), "-", sProductType, "-", sSerialNo);
            }
        }


        public frmProjectmaster()
        {
            InitializeComponent();
            
            LoadProductTypes();
            cmbPMProductType.SelectedIndexChanged += new EventHandler(cmbPMProductType_SelectedIndexChanged);
        }
        DataTable dtProjectSlNo = new DataTable();
        DataTable dtQuotationNumber = new DataTable();
        DataTable dtApproveProject = new DataTable();
        DataTable dtDepartment = new DataTable();
        DataTable dtManufacture = new DataTable();
        DataTable dtProductType = new DataTable();
        DataTable DepartmentList = new DataTable();
        DataTable dtPegRate = new DataTable();
        DataTable subproducttype = new DataTable();
        DataTable dtRevenuRecongnition = new DataTable();
        double dPegRate;
        private void frmProjectmaster_Load(object sender, EventArgs e)
        {
            try
            {
                if (login.GetUserDetails[2].ToString() == "Vivek G")//theertha rao")
                {
                    checkBoxdept.Visible = true;  // Show the checkbox
                    checkBoxdept.Enabled = true;  // Enable the checkbox
                }
                else
                {
                    checkBoxdept.Visible = false; // Hide the checkbox
                    checkBoxdept.Enabled = false; // Disable the checkbox
                }
                dtManufacture = DAL.fnManufactureList(0).Tables[0];
                foreach (DataRow DR in dtManufacture.Rows)
                {
                    if (!comManufactureform.Items.Contains(DR[0].ToString()))
                        comManufactureform.Items.Add(DR[0].ToString());
                }

                dtDepartment = DAL.fnDepartmentList(0, null, null).Tables[0];
                foreach (DataRow DR in dtDepartment.Rows)
                {
                    if (!cmbDepartment.Items.Contains(DR[0].ToString()))
                        cmbDepartment.Items.Add(DR[0].ToString());
                }

                dtPegRate = DAL.DTPegRate("").Tables[0];
                if (dtPegRate.Rows.Count > 0)
                {
                    dPegRate = Convert.ToDouble(dtPegRate.Rows[0][1].ToString());
                }
                else
                {
                    dPegRate = 1;
                }


                dtRevenuRecongnition = DAL.fnRevenueRecognition(0, "TEL-2021-12-OTS-113001").Tables[0];
                dgvRevenueRecognition.DataSource = dtRevenuRecongnition;
                //dtrevenueqn



                if (login.GetUserDetails[2].ToLower() == "hebbarrk")
                {
                    dtApproveProject = DAL.fnGMProjectList(null).Tables[0];
                    foreach (DataRow DR in dtApproveProject.Rows)
                    {
                        if (!cmbGMApproveList.Items.Contains(DR["ProjectCode"].ToString()))
                            cmbGMApproveList.Items.Add(DR["ProjectCode"].ToString());
                    }

                    tabControl1.Enabled = false;
                    pnGMApproval.Visible = true;
                }
                else
                {
                    tabControl1.Enabled = true;
                    pnGMApproval.Visible = false;
                }

                dtpPMCreatedDate.Format = DateTimePickerFormat.Custom;
                dtpPMCreatedDate.CustomFormat = "dd-MM-yyyy";
                dtCustomerList = DAL.fnCustomerList(5, null).Tables[0];
                lblReturnedby.Text = login.GetUserDetails[2];
                cmbPMProductType.Text = null;
                cmbProjectType.Text = null;
                cmbCustomer.Text = null;
                chkBOMProject.Checked = false;
                foreach (DataRow DR in dtCustomerList.Rows)
                {
                    if (!cmbCustomer.Items.Contains(DR["CustomerName"].ToString()))
                        cmbCustomer.Items.Add(DR["CustomerName"].ToString());

                    if (!cmbEndUserCountry.Items.Contains(DR["Country"].ToString()))
                        cmbEndUserCountry.Items.Add(DR["Country"].ToString());

                }
                if (bSearch)
                {
                    fnProjectCodeLoad();
                    cmbProjectDocument.Visible = true;
                    DepartmentList = DAL.fnDepartmentList(2, sProjectCode, null).Tables[0];

                    foreach (DataRow DR in DepartmentList.Rows)
                    {
                        if (!lstusers.Items.Contains(DR[0].ToString()))
                        {
                            lstusers.Items.Add(DR[0].ToString());
                        }
                    }
                }
                dtProjectList = DAL.fnProjectList(null).Tables[0];
            }
            catch (Exception ex)
            {
                //MessageBox.Show("frmProjectmaster_frmProjectmaster_Load " + ex.Message); 
            }

            /*
            dtProductType = DAL.fnproductList(0).Tables[0];
            if (dtProductType.Rows.Count > 0)
            {
                foreach (DataRow DR in dtProductType.Rows)
                {
                    if (!cmbPMProductType.Items.Contains(DR["product_type"].ToString()))
                        cmbPMProductType.Items.Add(DR["product_type"].ToString());
                }
                cmbPMProductType.SelectedIndex = 0;
            }
            */
            /*
            var subproducttype = DAL.fnsubproducttype(productType).Tables[0];
            cmbsystemsubtype.Items.Clear(); // Clear existing items
            if (subproducttype.Rows.Count > 0)
            {
                foreach (DataRow DR in subproducttype.Rows)
                {
                    string subProductType = DR["product_subType"].ToString();
                    if (!cmbsystemsubtype.Items.Contains(subProductType))
                        cmbsystemsubtype.Items.Add(subProductType);
                }
                cmbsystemsubtype.SelectedIndex = 0; // Select the first item by default
            }
            */

        }

        string sPathLink = "";
        private void fnProjectCodeLoad()
        {
            if (fnGetProjectCode != null)
            {
                dtProjectList = DAL.fnProjectList(sProjectCode).Tables[0]; //get selected project from projectMaster database
                if (sProjectCode != null && dtProjectList.Rows.Count > 0)
                {
                    txtPMProjectCode.Text = dtProjectList.Rows[0]["ProjectCode"].ToString();

                    cmbProjectDocument.SelectedItem = dtProjectList.Rows[0]["ProjectDocument"].ToString();
                    dtProjectInfolist = DAL.fnProjectInfoList(2, txtPMProjectCode.Text, dtProjectList.Rows[0]["ProjectDocument"].ToString()).Tables[0];
                    txtPMProjectDescription.Text = dtProjectList.Rows[0]["ProjectDescription"].ToString();
                    comManufactureform.Text = dtProjectList.Rows[0]["ManufactureName"].ToString();
                    cmbProductionCompany.Text = dtProjectList.Rows[0]["ProductMaker"].ToString();
                    comboBoxProfitCentre.Text = dtProjectList.Rows[0]["ProfitCentre"].ToString();
                    //// For cmbProject8020
                    //string value8020 = dtProjectList.Rows[0]["project8020"].ToString();
                    //if (cmbProject8020.Items.Contains(value8020))
                    //    cmbProject8020.SelectedItem = value8020;

                    //// For cmbCustomizationlevel
                    //string customizationLevel = dtProjectList.Rows[0]["customizationlevel"].ToString();
                    //if (cmbCustomizationlevel.Items.Contains(customizationLevel))
                    //    cmbCustomizationlevel.SelectedItem = customizationLevel;

                    if (dtProjectInfolist.Rows.Count > 0)
                    {
                        Regex illegalInFileName = new Regex(@"[\\/:*?""<>|]");
                        string sProjName = txtPMProjectDescription.Text;
                        sProjName = illegalInFileName.Replace(sProjName, " ");

                        string newPath = @"\\inbas01\Data\ERP\Pub\ERP_Project_Document\\" + txtPMProjectCode.Text;

                        if (cmbProjectDocument.SelectedIndex >= 0)
                        {
                            sPathLink = newPath + "\\" + cmbProjectDocument.Text + "\\" + dtProjectInfolist.Rows[0]["Filename"].ToString();
                            llbProjectDocuments.Text = "Click here to open the document";
                        }
                        else
                        {
                            sPathLink = newPath;
                            llbProjectDocuments.Text = "Click here to open the document";
                        }
                        llbProjectDocuments.Visible = true;

                    }
                    else
                    {
                        llbProjectDocuments.Text = "";
                        llbProjectDocuments.Visible = false;
                    }
                    llbUploadDocs.Visible = true;


                    cmbProject8020.SelectedItem = dtProjectList.Rows[0]["project8020"].ToString();
                    cmbCustomizationlevel.SelectedItem = dtProjectList.Rows[0]["customizationlevel"].ToString();



                    if (!string.IsNullOrEmpty(dtProjectList.Rows[0]["Type"].ToString()))
                    {
                        cmbPMProductType.SelectedItem = dtProjectList.Rows[0]["Type"].ToString();
                    }
                    else
                    {
                        cmbPMProductType.Enabled = true;
                    }
                    cmbProjectType.Text = dtProjectList.Rows[0]["ProjectType"].ToString();

                    cmbWarrantyStartsFrom.Text = dtProjectList.Rows[0]["WarrantyStartsFrom"].ToString();
                    if (!string.IsNullOrEmpty(dtProjectList.Rows[0]["SystemSubType"].ToString()))
                    {
                        cmbsystemsubtype.SelectedItem = dtProjectList.Rows[0]["SystemSubType"].ToString();
                    }
                    dtpPMCreatedDate.Value = Convert.ToDateTime(dtProjectList.Rows[0]["DateCreated"]);

                    dtpPMCreatedDate.Enabled = false;

                    if (dtProjectList.Rows[0]["BOMProject"].ToString() == "True")
                    {
                        chkBOMProject.Checked = true;
                    } else
                    {
                        chkBOMProject.Checked = false;
                    }

                    if (!string.IsNullOrEmpty(dtProjectList.Rows[0]["StockProjectCode"].ToString()))
                    {
                        cmbStockProject.Items.Add(dtProjectList.Rows[0]["StockProjectCode"].ToString());
                        cmbStockProject.SelectedItem = dtProjectList.Rows[0]["StockProjectCode"].ToString();
                    }



                    btnSave.Text = Global.sBUTTON_SAVE_TEXT_ISUPDATE;

                    if (login.GetUserDetails[2].ToLower() == "hebbarrk" || login.GetUserDetails[2] == "Vivek G")
                    {
                        btnSave.Text = "Approve";
                    }

                    if (string.IsNullOrEmpty(dtProjectList.Rows[0]["Status"].ToString()))
                    {
                        btnSave.Visible = true;
                    }
                    else
                    {
                        if (login.GetUserDetails[2] == "Rashmi" || login.GetUserDetails[2].ToString() == "Vivek G" || login.GetUserDetails[23] == "Management")//|| login.GetUserDetails[2] == "theertha rao"
                        {
                            btnSave.Visible = true;
                        }
                        else
                        {
                            btnSave.Visible = false;
                        }
                    }
                    cmbProjectType.Enabled = false;
                    cmbCustomer.Enabled = false;

                    txtCapexName.Text = dtProjectList.Rows[0]["CapexName"].ToString();
                    txtCapexNumber.Text = dtProjectList.Rows[0]["CapexNumber"].ToString();
                    txtCapexRequester.Text = dtProjectList.Rows[0]["CapexRequester"].ToString();
                    txtCapexAmount.Text = dtProjectList.Rows[0]["CapexAmount"].ToString();
                    txtOverHead.Text = dtProjectList.Rows[0]["OverHeadPercentage"].ToString();

                }
                dtProjectOrderEntry = DAL.fnProjectOrderEntry(sProjectCode, 1).Tables[0];

                if (sProjectCode != null && dtProjectOrderEntry.Rows.Count > 0)
                {
                    txtPONo.Text = dtProjectOrderEntry.Rows[0]["PONo"].ToString();
                    dtpPODate.Value = Convert.ToDateTime(dtProjectOrderEntry.Rows[0]["PODate"]);
                    dtpRecievedDate.Value = Convert.ToDateTime(dtProjectOrderEntry.Rows[0]["RecievedDate"]);
                    cmbOfferNumber.Text = dtProjectOrderEntry.Rows[0]["OfferNo"].ToString();
                    cmbRevisionNumber.SelectedItem = dtProjectOrderEntry.Rows[0]["Revision"].ToString();
                    CmbStandardCustom.SelectedItem = dtProjectOrderEntry.Rows[0]["StandardCustom"].ToString();
                    cmbModelNumber.Text = dtProjectOrderEntry.Rows[0]["ModelNumber"].ToString();
                    txtWarrantyClose.Text = dtProjectOrderEntry.Rows[0]["WarrantyPeriod"].ToString();
                    cmbEndUserCountry.Text = dtProjectOrderEntry.Rows[0]["EndUserCountry"].ToString();

                    txtBilltoCustomer.Text = dtProjectOrderEntry.Rows[0]["BilltoCustomer"].ToString();
                    txtShiptoCustomer.Text = dtProjectOrderEntry.Rows[0]["ShiptoCustomer"].ToString();
                    txtProjectFocal.Text = dtProjectOrderEntry.Rows[0]["ProjectFocal"].ToString();

                    txtContactPerson.Text = dtProjectOrderEntry.Rows[0]["ContactPerson"].ToString();
                    txtDepartment.Text = dtProjectOrderEntry.Rows[0]["ContactPersonDept"].ToString();
                    txtContactAddress.Text = dtProjectOrderEntry.Rows[0]["ContactAddress"].ToString();
                    txtContactEmail.Text = dtProjectOrderEntry.Rows[0]["ContactEmail"].ToString();
                    txtOfficeNo.Text = dtProjectOrderEntry.Rows[0]["ContactOfficeNo"].ToString();
                    txtMoblieNo.Text = dtProjectOrderEntry.Rows[0]["ContactMoblieNo"].ToString();

                    cmbShippingTerms.Text = dtProjectOrderEntry.Rows[0]["ShippingTerms"].ToString();
                    cmbShippingMode.Text = dtProjectOrderEntry.Rows[0]["ShipmentMode"].ToString();
                    cmbPaymentTerms.Text = dtProjectOrderEntry.Rows[0]["PaymentTerms"].ToString();
                    cmbAgent.SelectedItem = dtProjectOrderEntry.Rows[0]["Agent"].ToString();
                    txtAgentCommission.Text = dtProjectOrderEntry.Rows[0]["AgentCommission"].ToString();
                    cmbSecurityDeposit.Text = dtProjectOrderEntry.Rows[0]["SecurityDeposit"].ToString();
                    cmbBankGuarantee.Text = dtProjectOrderEntry.Rows[0]["BankGuarantee"].ToString();
                    cmbPerformanceBankGuarantee.Text = dtProjectOrderEntry.Rows[0]["PerformanceBankGuarantee"].ToString();
                    txtDeliveryPeriod.Text = dtProjectOrderEntry.Rows[0]["DeliveryPeriod"].ToString();
                    txtStandardDeliveryPeriod.Text = dtProjectOrderEntry.Rows[0]["StandardDeliveryPeriod"].ToString();
                    if (!string.IsNullOrEmpty(dtProjectOrderEntry.Rows[0]["CustomerRequirement"].ToString()))
                    {
                        txtCustomerRequirement.Value = Convert.ToDateTime(dtProjectOrderEntry.Rows[0]["CustomerRequirement"]);
                    }
                    cmbPenaltyClause.SelectedItem = dtProjectOrderEntry.Rows[0]["PenaultyClause"].ToString();
                    cmbPreDesignPreview.Text = dtProjectOrderEntry.Rows[0]["PreDesignReview"].ToString();
                    cmbPreDispatchInspection.SelectedItem = dtProjectOrderEntry.Rows[0]["PreDispatchInspection"].ToString();
                    cmbContractualAcceptance.Text = dtProjectOrderEntry.Rows[0]["ContractualAcceptance"].ToString();
                    txtRemarks.Text = dtProjectOrderEntry.Rows[0]["Remarks"].ToString();

                    txtProjectMargin.Text = dtProjectOrderEntry.Rows[0]["ProjectMargin"].ToString();
                    txtDiscount.Text = dtProjectOrderEntry.Rows[0]["Discount"].ToString();
                    txtOrderValueinINR.Text = dtProjectOrderEntry.Rows[0]["OrderValueinINR"].ToString();
                    txtOrderValueinUSD.Text = dtProjectOrderEntry.Rows[0]["OrderValueinUSD"].ToString();
                    txtInstallationValueinINR.Text = dtProjectOrderEntry.Rows[0]["InstallationValueinINR"].ToString();
                    txtInstallationValueinUSD.Text = dtProjectOrderEntry.Rows[0]["InstallationValueinUSD"].ToString();
                    cmbLever.SelectedItem = dtProjectOrderEntry.Rows[0]["Lever"].ToString();
                    txtQuotationEffort.Text = dtProjectOrderEntry.Rows[0]["OfferEffort"].ToString();
                    txtSaleseffort.Text = dtProjectOrderEntry.Rows[0]["SalesEffort"].ToString();

                    txtTargetMaterialmargin.Text = dtProjectOrderEntry.Rows[0]["TargetMargin"].ToString();

                    chkLDClause.Checked = Convert.ToBoolean(dtProjectOrderEntry.Rows[0]["LDClause"].ToString());
                    if (!string.IsNullOrEmpty(dtProjectOrderEntry.Rows[0]["LDStartDate"].ToString()))
                    {
                        dtpLDFromDate.Value = Convert.ToDateTime(dtProjectOrderEntry.Rows[0]["LDStartDate"]);
                    }
                    if (!string.IsNullOrEmpty(dtProjectOrderEntry.Rows[0]["LDEndDate"].ToString()))
                    {
                        dtpLDToDate.Value = Convert.ToDateTime(dtProjectOrderEntry.Rows[0]["LDEndDate"]);
                    }
                    txtLDBody.Text = dtProjectOrderEntry.Rows[0]["LDBody"].ToString();

                    chkLCClause.Checked = Convert.ToBoolean(dtProjectOrderEntry.Rows[0]["LCClause"].ToString());
                    if (!string.IsNullOrEmpty(dtProjectOrderEntry.Rows[0]["LCStartDate"].ToString()))
                    {
                        dtpFromDate.Value = Convert.ToDateTime(dtProjectOrderEntry.Rows[0]["LCStartDate"]);
                    }
                    if (!string.IsNullOrEmpty(dtProjectOrderEntry.Rows[0]["LCEndDate"].ToString()))
                    {
                        dtpLCEndDate.Value = Convert.ToDateTime(dtProjectOrderEntry.Rows[0]["LCEndDate"]);
                    }
                    txtLDBody.Text = dtProjectOrderEntry.Rows[0]["LCBody"].ToString();
                    txtEstimatedDesign.Text = dtProjectOrderEntry.Rows[0]["EstimatedDesignhours"].ToString();
                    txtEstimatedManufacturing.Text = dtProjectOrderEntry.Rows[0]["EstimatedManufacturinghours"].ToString();
                    txtEstimatedInsatllation.Text = dtProjectOrderEntry.Rows[0]["EstimatedInstallationhours"].ToString();
                }
                dtRevenuRecongnition = DAL.fnRevenueRecognition(0, sProjectCode).Tables[0];
                dgvRevenueRecognition.DataSource = dtRevenuRecongnition;

                bSearch = false;
            }

            else
            {
                bSearch = false;
            }

            cmbCustomer.SelectedItem = dtProjectList.Rows[0]["Customer"].ToString();
        }


        // Method to load product types into the first dropdown
        private void LoadProductTypes()
        {
            var dtProductType = DAL.fnproductList(0).Tables[0];
            if (dtProductType.Rows.Count > 0)
            {
                foreach (DataRow DR in dtProductType.Rows)
                {
                    string productType = DR["product_type"].ToString();
                    if (!cmbPMProductType.Items.Contains(productType))
                        cmbPMProductType.Items.Add(productType);
                }
                cmbPMProductType.SelectedIndex = 0; // Select the first item by default
            }
        }

        // Method to load subproduct types based on the selected product type
        private void LoadSubProductTypes(string productType)
        {
            var subproducttype = DAL.fnsubproducttype(productType).Tables[0];
            cmbsystemsubtype.Items.Clear(); // Clear existing items
            if (subproducttype.Rows.Count > 0)
            {
                foreach (DataRow DR in subproducttype.Rows)
                {
                    string subProductType = DR["product_subType"].ToString();
                    if (!cmbsystemsubtype.Items.Contains(subProductType))
                        cmbsystemsubtype.Items.Add(subProductType);
                }
                
            }
        }



        string sYear;
        string sMonth;
        string s3DigitNumber;
        int LastQuoteNumber;
        string sFormNo;
        DataTable dtOrderFormNumber = new DataTable();
        private void btnSave_Click(object sender, EventArgs e)
        {
            
                     

            if (login.GetUserDetails[23] == "Testlab" || login.GetUserDetails[23] == "Support")
            {
                foreach (DataGridViewRow dr in dgvRevenueRecognition.Rows)
                {
                    dr.Cells[1].Value = "No";
                }
            }
            try
            {
                sFormNo = "";
                sYear = DateTime.Today.Year.ToString();
                sYear = sYear.Substring(2, 2) + "/";
                sMonth = DateTime.Today.Month.ToString() + "/";
                dtOrderFormNumber = DAL.fnOrderFormNumber().Tables[0];
                if (dtOrderFormNumber.Rows.Count > 0)
                {
                    LastQuoteNumber = Convert.ToInt32(dtOrderFormNumber.Rows[0]["Id"].ToString());
                    LastQuoteNumber++;
                    string value = String.Format("{0:D3}", LastQuoteNumber);
                    sFormNo = ("OFF/" + sYear + sMonth + value);
                }
                else
                {
                    string value = String.Format("{0:D3}", 1);
                    sFormNo = ("OFF/" + sYear + sMonth + value);
                }

                if (bBOMProject == false)
                {
                   
                    DialogResult DR = MessageBox.Show("Do you want to create/update a Project without Project BOM? ", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (DR == DialogResult.Yes)
                    {
                        ProjectStatusWarranty();
                    }
                }
                else
                {
                    ProjectStatusWarranty();
                }
                if (chkLCClause.Checked)
                {
                    AssignTaskExample("Order Entry LC Clause Reminder for " + sProjectCode + " - " + txtPMProjectDescription.Text + "", txtBody.Text, dtpFromDate.Text, dtpLCEndDate.Text);
                }

                if (chkLDClause.Checked)
                {
                    AssignTaskExample("Order Entry LD Clause Reminder for " + sProjectCode + " - " + txtPMProjectDescription.Text + "", txtLDBody.Text, dtpLDFromDate.Text, dtpLDToDate.Text);
                }
                sProjectCode = string.Empty;
            }
            catch (Exception ex)
            {
                MessageBox.Show("frmProjectmaster_btnSave_Click  " + ex.Message);
            }
        }
        bool bProjectDocument = false;
        DataTable dtProjectCapex = new DataTable();
        private void ProjectStatusWarranty()
        {
            if (cmbProjectType.Text == "Fixed Asset (CIP)")
            {
                if (btnSave.Text == Global.sBUTTON_SAVE_TEXT_ISSAVE)
                {
                    fnProjectCodeGeneration();
                    dtProjectCapex = DAL.fnProjectListWithEndDate(0, "A", txtCapexNumber.Text).Tables[0];
                    if (sProjectCode != string.Empty && dtProjectCapex.Rows.Count == 0)
                    {
                        GlobalClass.iSuccess = DAL.fnAddCapexProject(1, sProjectCode, txtPMProjectDescription.Text.Trim(), comManufactureform.Text,cmbProductionCompany.Text,(dtpPMCreatedDate.Text),
                                                                     cmbCustomer.Text, cmbPMProductType.Text, "", txtRemarks.Text, cmbProjectType.Text,
                                                                     login.GetUserDetails[2], txtcuscode.Text, bBOMProject,
                                                                     txtCapexNumber.Text, txtCapexName.Text, txtCapexRequester.Text, txtCapexAmount.Text, txtOverHead.Text, comboBoxProfitCentre.Text);
                        foreach (var listBoxItem in lstusers.Items)
                        {
                            GlobalClass.iSuccess = DAL.fnAddProjectDepartment(1, sProjectCode, listBoxItem.ToString(), login.GetUserDetails[2], dtpPMCreatedDate.Text);
                        }
                        revenuequestioninsert(0);
                        GlobalClass.iSuccess = DAL.fnAddERPLog(0, sProjectCode, login.GetUserDetails[2], dtpPMCreatedDate.Text, "Project Code Created", "ProjectMaster");
                        MessageBox.Show("New project code " + sProjectCode + " generated Successfully.");
                        btnSave.Enabled = false;
                    }
                    else
                    {
                        if (dtProjectCapex.Rows.Count > 0)
                        {
                            MessageBox.Show("Capex number already used for the other project.");
                        }
                    }

                }
                else if (login.GetUserDetails[2].ToString() == "Vivek G")//theertha rao")
                {

                    if (txtPMProjectCode.Text != string.Empty)
                    {
                        GlobalClass.iSuccess = DAL.fnAddCapexProject(2, txtPMProjectCode.Text, txtPMProjectDescription.Text.Trim(), comManufactureform.Text,cmbProductionCompany.Text, (dtpPMCreatedDate.Text),
                                                                 cmbCustomer.Text, cmbPMProductType.Text, "", txtRemarks.Text, cmbProjectType.Text, login.GetUserDetails[2], txtcuscode.Text, bBOMProject, txtCapexNumber.Text, txtCapexName.Text, txtCapexRequester.Text, txtCapexAmount.Text, txtOverHead.Text, comboBoxProfitCentre.Text);
                    }

                    foreach (var listBoxItem in lstusers.Items)
                    {
                        GlobalClass.iSuccess = DAL.fnAddProjectDepartment(2, txtPMProjectCode.Text, listBoxItem.ToString(), login.GetUserDetails[2], dtpPMCreatedDate.Text);
                        GlobalClass.iSuccess = DAL.fnAddProjectDepartment(1, txtPMProjectCode.Text, listBoxItem.ToString(), login.GetUserDetails[2], dtpPMCreatedDate.Text);
                    }
                    //  20/12/2021 commented fnCreateProjectInformation(); as cip projects are not updating 
                    // fnCreateProjectInformation();

                    GlobalClass.iSuccess = DAL.fnAddERPLog(0, txtPMProjectCode.Text, login.GetUserDetails[2], dtpPMCreatedDate.Text, "Project Code Activated", "ProjectMaster");
                    MessageBox.Show("Project code " + txtPMProjectCode.Text + " updated and activated Successfully.");
                    btnSave.Enabled = false;
                }

            }
            else
            {
                try
                {
                    //if (txtPMProjectDescription.Text != string.Empty && !string.IsNullOrEmpty(txtcuscode.Text) && !string.IsNullOrEmpty(txtWarrantyClose.Text) && !string.IsNullOrEmpty(cmbPMProductType.Text) && !string.IsNullOrEmpty(cmbProjectType.Text) && !string.IsNullOrEmpty(cmbsystemsubtype.Text) && cmbProjectType.SelectedIndex >= 0
                    //    && CmbStandardCustom.SelectedIndex >= 0 && cmbAgent.SelectedIndex >= 0 && cmbWarrantyStartsFrom.SelectedIndex >= 0)
                    //{
                    if (btnSave.Text == Global.sBUTTON_SAVE_TEXT_ISSAVE)
                    {
                        bProjectDocument = false;
                        if (cmbProjectType.Text == "Customer (CUS)")
                        {

                            if (cmbProjectDocument.SelectedIndex >= 0 && (openFileDialog1.FileName != "openFileDialog1"))
                            {
                                bProjectDocument = true;
                            }
                            else
                            {
                                bProjectDocument = false;
                            }
                            if (string.IsNullOrEmpty(txtQuotationEffort.Text) || string.IsNullOrEmpty(txtSaleseffort.Text) || string.IsNullOrEmpty(txtEstimatedDesign.Text) || string.IsNullOrEmpty(txtEstimatedManufacturing.Text) || string.IsNullOrEmpty(txtEstimatedInsatllation.Text))
                            {
                                bProjectDocument = false;
                            }
                        }
                        else
                        {
                            bProjectDocument = true;
                        }

                        if (bProjectDocument)
                        {
                            string sStockProjectCode = "";
                            if (cmbProjectType.Text == "Customer (CUS)" && cmbStockProject.SelectedIndex >= 0)
                            {
                                string str = cmbStockProject.Text;
                                str = str.Substring(3);
                                sProjectCode = "CUS" + str;
                                sStockProjectCode = cmbStockProject.Text;
                            }
                            else
                            {
                                fnProjectCodeGeneration();
                            }
                            if (sProjectCode != string.Empty)
                            {
                                GlobalClass.iSuccess = DAL.fnAddProject(Global.uINSERT, sProjectCode, txtPMProjectDescription.Text.Trim(), comManufactureform.Text,cmbProductionCompany.Text, (dtpPMCreatedDate.Text),
                                                        cmbCustomer.Text, cmbPMProductType.Text, "", "", cmbProjectType.Text, "", login.GetUserDetails[2], cmbsystemsubtype.Text,
                                                        txtcuscode.Text, bBOMProject, cmbProject8020.Text, cmbCustomizationlevel.Text, cmbWarrantyStartsFrom.Text, cmbProjectDocument.Text, sStockProjectCode, comboBoxProfitCentre.Text);
                                btnSave.Enabled = false;

                                GlobalClass.iSuccess = DAL.fnAddProjectOrderEntry(Global.uDELETE, sProjectCode, txtPONo.Text, dtpPODate.Text, dtpRecievedDate.Text, cmbOfferNumber.Text, cmbRevisionNumber.Text, CmbStandardCustom.Text, cmbModelNumber.Text, txtWarrantyClose.Text, cmbEndUserCountry.Text,
                                    txtBilltoCustomer.Text, txtShiptoCustomer.Text, txtProjectFocal.Text, txtContactPerson.Text, txtDepartment.Text, txtContactAddress.Text, txtContactEmail.Text, txtOfficeNo.Text, txtMoblieNo.Text, cmbShippingTerms.Text, cmbShippingMode.Text, cmbPaymentTerms.Text, cmbAgent.Text,
                                   txtAgentCommission.Text, cmbSecurityDeposit.Text, cmbBankGuarantee.Text, cmbPerformanceBankGuarantee.Text, txtDeliveryPeriod.Text, txtStandardDeliveryPeriod.Text, txtCustomerRequirement.Text, cmbPenaltyClause.Text, cmbPreDesignPreview.Text, cmbPreDispatchInspection.Text,
                                   cmbContractualAcceptance.Text, txtRemarks.Text, txtProjectMargin.Text, txtDiscount.Text, txtOrderValueinINR.Text, txtOrderValueinUSD.Text, txtInstallationValueinINR.Text, txtInstallationValueinUSD.Text, cmbLever.Text, txtQuotationEffort.Text, txtSaleseffort.Text,
                                    Convert.ToBoolean(chkLDClause.CheckState), dtpLDFromDate.Text, dtpLDToDate.Text, txtLDBody.Text, Convert.ToBoolean(chkLCClause.CheckState), dtpLDFromDate.Text, dtpLCEndDate.Text, txtBody.Text, txtEstimatedDesign.Text, txtEstimatedManufacturing.Text, txtEstimatedInsatllation.Text, txtTargetMaterialmargin.Text);



                                GlobalClass.iSuccess = DAL.fnAddProjectOrderEntry(Global.uINSERT, sProjectCode, txtPONo.Text, dtpPODate.Text, dtpRecievedDate.Text, cmbOfferNumber.Text, cmbRevisionNumber.Text, CmbStandardCustom.Text, cmbModelNumber.Text, txtWarrantyClose.Text, cmbEndUserCountry.Text,
                                     txtBilltoCustomer.Text, txtShiptoCustomer.Text, txtProjectFocal.Text, txtContactPerson.Text, txtDepartment.Text, txtContactAddress.Text, txtContactEmail.Text, txtOfficeNo.Text, txtMoblieNo.Text, cmbShippingTerms.Text, cmbShippingMode.Text, cmbPaymentTerms.Text, cmbAgent.Text,
                                    txtAgentCommission.Text, cmbSecurityDeposit.Text, cmbBankGuarantee.Text, cmbPerformanceBankGuarantee.Text, txtDeliveryPeriod.Text, txtStandardDeliveryPeriod.Text, txtCustomerRequirement.Text, cmbPenaltyClause.Text, cmbPreDesignPreview.Text, cmbPreDispatchInspection.Text,
                                    cmbContractualAcceptance.Text, txtRemarks.Text, txtProjectMargin.Text, txtDiscount.Text, txtOrderValueinINR.Text, txtOrderValueinUSD.Text, txtInstallationValueinINR.Text, txtInstallationValueinUSD.Text, cmbLever.Text, txtQuotationEffort.Text, txtSaleseffort.Text,
                                     Convert.ToBoolean(chkLDClause.CheckState), dtpLDFromDate.Text, dtpLDToDate.Text, txtLDBody.Text, Convert.ToBoolean(chkLCClause.CheckState), dtpLDFromDate.Text, dtpLCEndDate.Text, txtBody.Text, txtEstimatedDesign.Text, txtEstimatedManufacturing.Text, txtEstimatedInsatllation.Text, txtTargetMaterialmargin.Text);

                                //if (GlobalClass.iSuccess > 0)
                                //{
                                txtPMProjectCode.Text = sProjectCode;


                                //if (cmbProjectType.Text == "Parts (PRT)" || cmbProjectType.Text == "Accessories (OTC)")
                                //{
                                //    GlobalClass.iSuccess = DAL.fnAddProject(7, txtPMProjectCode.Text, txtPMProjectDescription.Text, dtpPMCreatedDate.Text,
                                //    cmbCustomer.Text, cmbPMProductType.Text, "WIP", "", cmbProjectType.Text, "", login.GetUserDetails[2], cmbsystemsubtype.Text, txtcuscode.Text, bBOMProject, cmbProject8020.Text, cmbCustomizationlevel.Text, cmbWarrantyStartsFrom.Text, cmbProjectDocument.Text, "");
                                //}
                                revenuequestioninsert(0);
                                GlobalClass.iSuccess = DAL.fnAddERPLog(0, sProjectCode, login.GetUserDetails[2], dtpPMCreatedDate.Text, "Project Code Created", "ProjectMaster");
                                MessageBox.Show("New project code " + sProjectCode + " generated Successfully.", "Success", 0, MessageBoxIcon.Information);

                                bRequiredDate = false;
                                if (cmbProjectType.Text == "Customer (CUS)")
                                {
                                    fnExcel();
                                    if (cmbOfferNumber.SelectedIndex >= 0 && cmbRevisionNumber.SelectedIndex >= 0)
                                    {
                                        fnScopeofSupply();
                                    }
                                }
                                else if (cmbProjectType.Text == "TestingLab (TEL)")
                                {
                                    if (cmbOfferNumber.SelectedIndex >= 0)
                                    {
                                        fnPDgeneration();
                                    }
                                }

                                cmbPMProductType.SelectedIndex = -1;
                                cmbProjectType.SelectedIndex = -1;
                                cmbCustomer.SelectedIndex = -1;
                                dtProjectList = DAL.fnProjectList(null).Tables[0];
                                bBOMProject = false;
                                Mail.ShowDialog();
                                fnCreateProjectInformation();

                            }
                        }
                        else
                        {
                            if (string.IsNullOrEmpty(txtQuotationEffort.Text))
                            {
                                txtQuotationEffort.Focus();
                                MessageBox.Show("Enter offer effort(Hrs)", "Error", 0, MessageBoxIcon.Error);
                            }
                            else if (string.IsNullOrEmpty(txtSaleseffort.Text))
                            {
                                txtSaleseffort.Focus();
                                MessageBox.Show("Enter Sales Effort(Hrs)", "Error", 0, MessageBoxIcon.Error);
                            }
                            else if (string.IsNullOrEmpty(txtEstimatedDesign.Text))
                            {
                                txtEstimatedDesign.Focus();
                                MessageBox.Show("Enter Estimated Design(Hrs)", "Error", 0, MessageBoxIcon.Error);
                            }
                            else if (string.IsNullOrEmpty(txtEstimatedManufacturing.Text))
                            {
                                txtEstimatedManufacturing.Focus();
                                MessageBox.Show("Enter Estimated Manufacturing", "Error", 0, MessageBoxIcon.Error);
                            }
                            else if (string.IsNullOrEmpty(txtEstimatedInsatllation.Text))
                            {
                                txtEstimatedInsatllation.Focus();
                                MessageBox.Show("Enter Estimated Installation", "Error", 0, MessageBoxIcon.Error);
                            }
                            else if (!bProjectDocument)
                            {
                                MessageBox.Show("Upload the customer order document", "Error", 0, MessageBoxIcon.Error);
                                cmbProjectDocument.DroppedDown = true;
                            }
                           
                        }
                    }
                    else
                    {
                        string NowDate = DateTime.Now.ToString("dd-MM-yyyy");
                        dtProjectList1 = DAL.fnProjectList(txtPMProjectCode.Text).Tables[0];

                        GlobalClass.iSuccess = DAL.fnAddProject(10, txtPMProjectCode.Text, txtPMProjectDescription.Text, comManufactureform.Text,cmbProductionCompany.Text, dtpPMCreatedDate.Text,
                              cmbCustomer.Text, cmbPMProductType.Text, "", "", cmbProjectType.Text, "", login.GetUserDetails[2], cmbsystemsubtype.Text,
                              txtcuscode.Text, bBOMProject, cmbProject8020.Text, cmbCustomizationlevel.Text, cmbWarrantyStartsFrom.Text, cmbProjectDocument.Text, "", comboBoxProfitCentre.Text);

                        if (login.GetUserDetails[2].ToLower() == "hebbarrk")
                        {
                            if (dtProjectList1.Rows.Count > 0)
                            {
                                GlobalClass.iSuccess = DAL.fnAddProject(6, txtPMProjectCode.Text, txtPMProjectDescription.Text, comManufactureform.Text,cmbProductionCompany.Text, dtpPMCreatedDate.Text,
                                                                        cmbCustomer.Text, cmbPMProductType.Text, "WIP", "", cmbProjectType.Text, "", login.GetUserDetails[2], cmbsystemsubtype.Text,
                                                                        txtcuscode.Text, bBOMProject, cmbProject8020.Text, cmbCustomizationlevel.Text, cmbWarrantyStartsFrom.Text, cmbProjectDocument.Text, "", comboBoxProfitCentre.Text);    //update the changes of the selected project                                 
                             
                                GlobalClass.iSuccess = DAL.fnAddERPLog(0, txtPMProjectCode.Text, login.GetUserDetails[2], NowDate, "Project Code Activated", "ProjectMaster");
                           
                            }

                            //shreeshail add code

                            if (cmbProjectType.Text == "BATCH ORDER FOR PROJECTS (BOP)" && dtProjectList1.Rows.Count > 0)
                            {
                                GlobalClass.iSuccess = DAL.fnAddProject(100, txtPMProjectCode.Text, txtPMProjectDescription.Text, comManufactureform.Text, cmbProductionCompany.Text, dtpPMCreatedDate.Text,
                                                                        cmbCustomer.Text, cmbPMProductType.Text, "WIP", "", cmbProjectType.Text, "", login.GetUserDetails[2], cmbsystemsubtype.Text,
                                                                        txtcuscode.Text, bBOMProject, cmbProject8020.Text, cmbCustomizationlevel.Text, cmbWarrantyStartsFrom.Text, cmbProjectDocument.Text, "", comboBoxProfitCentre.Text);    //update the changes of the selected project                                 

                                GlobalClass.iSuccess = DAL.fnAddERPLog(0, txtPMProjectCode.Text, login.GetUserDetails[2], NowDate, "Project Code Activated", "ProjectMaster");

                            }
                            if (cmbProjectType.Text == "Customer (CUS)" && cmbStockProject.SelectedIndex >= 0)
                            {
                                GlobalClass.iSuccess = DAL.fnAddProject(5, txtPMProjectCode.Text, cmbStockProject.Text,"", "","",
                                 "", "", "", "", "", "", login.GetUserDetails[2], "", "", true, "", "", "", "", "", comboBoxProfitCentre.Text);
                            }
                        }
                        else
                        {
                            /*
                            if (login.GetUserDetails[2].ToLower() == "theertha rao" || login.GetUserDetails[2].ToLower() == "rashmi") 
                            {
                                if (dtProjectList1.Rows[0]["Status"].ToString() == "")
                                {
                                    GlobalClass.iSuccess = DAL.fnAddProject(Global.uUPDATE, txtPMProjectCode.Text, txtPMProjectDescription.Text, dtpPMCreatedDate.Text,
                                    cmbCustomer.Text, cmbPMProductType.Text, "", "", cmbProjectType.Text, "", login.GetUserDetails[2], cmbsystemsubtype.Text, txtcuscode.Text, bBOMProject, cmbProject8020.Text, cmbCustomizationlevel.Text, cmbWarrantyStartsFrom.Text, cmbProjectDocument.Text, "");    //update the changes of the selected project

                                    GlobalClass.iSuccess = DAL.fnAddERPLog(0, txtPMProjectCode.Text, login.GetUserDetails[2], NowDate, "Project Deatails Approved", "ProjectMaster");

                                }
                            }
                            */
                            if (login.GetUserDetails[2].ToString() == "Vivek G")//theertha rao")
                            {
                               
                                /*
                                else if ((cmbProjectType.Text != "Customer (CUS)" && dtProjectList1.Rows[0]["Status"].ToString() == "") ||(cmbProjectType.Text != "Stock (STO)" && dtProjectList1.Rows[0]["Status"].ToString() == "") ||(cmbProjectType.Text != "Accessories (OTC)" && dtProjectList1.Rows[0]["Status"].ToString() == "" )) //&& cmbProjectType.Text != "Accessories (OTC)"
                                {
                                    GlobalClass.iSuccess = DAL.fnAddProject(7, txtPMProjectCode.Text, txtPMProjectDescription.Text, dtpPMCreatedDate.Text,
                                                                            cmbCustomer.Text, cmbPMProductType.Text, "WIP", "", cmbProjectType.Text, "", login.GetUserDetails[2], cmbsystemsubtype.Text, txtcuscode.Text, bBOMProject, cmbProject8020.Text, cmbCustomizationlevel.Text, cmbWarrantyStartsFrom.Text, cmbProjectDocument.Text, "");

                                    GlobalClass.iSuccess = DAL.fnAddERPLog(0, txtPMProjectCode.Text, login.GetUserDetails[2], NowDate, "Project Code Activated", "ProjectMaster");
                                }
                                */
                                //shreeshail 
                                if ((cmbProjectType.Text == "BATCH ORDER FOR PROJECTS (BOP)" && dtProjectList1.Rows[0]["Status"].ToString() == "" )|| (cmbProjectType.Text == "Customer (CUS)" && dtProjectList1.Rows[0]["Status"].ToString() == "")|| (cmbProjectType.Text == "Stock (STO)" && dtProjectList1.Rows[0]["Status"].ToString() == "") || (cmbProjectType.Text == "Accessories (OTC)" && dtProjectList1.Rows[0]["Status"].ToString() == "")) 
                                {
                                    GlobalClass.iSuccess = DAL.fnAddProject(11, txtPMProjectCode.Text, txtPMProjectDescription.Text, comManufactureform.Text,cmbProductionCompany.Text, dtpPMCreatedDate.Text,
                                                                            cmbCustomer.Text, cmbPMProductType.Text, "GM Approval", "", cmbProjectType.Text, "", login.GetUserDetails[2], cmbsystemsubtype.Text, txtcuscode.Text, bBOMProject, cmbProject8020.Text, cmbCustomizationlevel.Text, cmbWarrantyStartsFrom.Text, cmbProjectDocument.Text, "", comboBoxProfitCentre.Text);

                                    GlobalClass.iSuccess = DAL.fnAddERPLog(0, txtPMProjectCode.Text, login.GetUserDetails[2], NowDate, "Project Code Activated", "ProjectMaster");
                                }

                                else if (dtProjectList1.Rows[0]["Status"].ToString() == "")
                                {
                                    
                                    GlobalClass.iSuccess = DAL.fnAddProject(7, txtPMProjectCode.Text, txtPMProjectDescription.Text, comManufactureform.Text,cmbProductionCompany.Text, dtpPMCreatedDate.Text, 
                                                                            cmbCustomer.Text, cmbPMProductType.Text, "WIP", "", cmbProjectType.Text, "", login.GetUserDetails[2], cmbsystemsubtype.Text, txtcuscode.Text, bBOMProject, cmbProject8020.Text, cmbCustomizationlevel.Text, cmbWarrantyStartsFrom.Text, cmbProjectDocument.Text, "", comboBoxProfitCentre.Text);

                                    GlobalClass.iSuccess = DAL.fnAddERPLog(0, txtPMProjectCode.Text, login.GetUserDetails[2], NowDate, "Project Code Activated", "ProjectMaster");
                                    
                                    GlobalClass.iSuccess = DAL.fnAddProject(8, txtPMProjectCode.Text, txtPMProjectDescription.Text,comManufactureform.Text, cmbProductionCompany.Text, dtpPMCreatedDate.Text,
                                                                            cmbCustomer.Text, cmbPMProductType.Text, "WIP", "", cmbProjectType.Text, "", login.GetUserDetails[2], cmbsystemsubtype.Text, txtcuscode.Text, bBOMProject, cmbProject8020.Text, cmbCustomizationlevel.Text, cmbWarrantyStartsFrom.Text, cmbProjectDocument.Text, "", comboBoxProfitCentre.Text);    //update the changes of the selected project
                                   
                                    GlobalClass.iSuccess = DAL.fnAddERPLog(0, txtPMProjectCode.Text, login.GetUserDetails[2], NowDate, "Project Deatails Approved", "ProjectMaster");
                                    
                                }
                                /*
                                else
                                {
                                    if (dtProjectList1.Rows[0]["Status"].ToString() == "")
                                    {
                                        GlobalClass.iSuccess = DAL.fnAddProject(7, txtPMProjectCode.Text, txtPMProjectDescription.Text, dtpPMCreatedDate.Text,
                                                                             cmbCustomer.Text, cmbPMProductType.Text, "WIP", "", cmbProjectType.Text, "", login.GetUserDetails[2], cmbsystemsubtype.Text, txtcuscode.Text, bBOMProject, cmbProject8020.Text, cmbCustomizationlevel.Text, cmbWarrantyStartsFrom.Text, cmbProjectDocument.Text, "");

                                        GlobalClass.iSuccess = DAL.fnAddERPLog(0, txtPMProjectCode.Text, login.GetUserDetails[2], NowDate, "Project Code Activated", "ProjectMaster");
                                    }
                                }
                                */

                            }


                            GlobalClass.iSuccess = DAL.fnAddProjectOrderEntry(Global.uDELETE, txtPMProjectCode.Text, txtPONo.Text, dtpPODate.Text, dtpRecievedDate.Text, cmbOfferNumber.Text, cmbRevisionNumber.Text, CmbStandardCustom.Text, cmbModelNumber.Text, txtWarrantyClose.Text, cmbEndUserCountry.Text,
                                   txtBilltoCustomer.Text, txtShiptoCustomer.Text, txtProjectFocal.Text, txtContactPerson.Text, txtDepartment.Text, txtContactAddress.Text, txtContactEmail.Text, txtOfficeNo.Text, txtMoblieNo.Text, cmbShippingTerms.Text, cmbShippingMode.Text, cmbPaymentTerms.Text, cmbAgent.Text,
                                  txtAgentCommission.Text, cmbSecurityDeposit.Text, cmbBankGuarantee.Text, cmbPerformanceBankGuarantee.Text, txtDeliveryPeriod.Text, txtStandardDeliveryPeriod.Text, txtCustomerRequirement.Text, cmbPenaltyClause.Text, cmbPreDesignPreview.Text, cmbPreDispatchInspection.Text,
                                  cmbContractualAcceptance.Text, txtRemarks.Text, txtProjectMargin.Text, txtDiscount.Text, txtOrderValueinINR.Text, txtOrderValueinUSD.Text, txtInstallationValueinINR.Text, txtInstallationValueinUSD.Text, cmbLever.Text, txtQuotationEffort.Text, txtSaleseffort.Text,
                                   Convert.ToBoolean(chkLDClause.CheckState), dtpLDFromDate.Text, dtpLDToDate.Text, txtLDBody.Text, Convert.ToBoolean(chkLCClause.CheckState), dtpLDFromDate.Text, dtpLCEndDate.Text, txtBody.Text, txtEstimatedDesign.Text, txtEstimatedManufacturing.Text, txtEstimatedInsatllation.Text, txtTargetMaterialmargin.Text);

                            GlobalClass.iSuccess = DAL.fnAddProjectOrderEntry(Global.uINSERT, txtPMProjectCode.Text, txtPONo.Text, dtpPODate.Text, dtpRecievedDate.Text, cmbOfferNumber.Text, cmbRevisionNumber.Text, CmbStandardCustom.Text, cmbModelNumber.Text, txtWarrantyClose.Text, cmbEndUserCountry.Text,
                                   txtBilltoCustomer.Text, txtShiptoCustomer.Text, txtProjectFocal.Text, txtContactPerson.Text, txtDepartment.Text, txtContactAddress.Text, txtContactEmail.Text, txtOfficeNo.Text, txtMoblieNo.Text, cmbShippingTerms.Text, cmbShippingMode.Text, cmbPaymentTerms.Text, cmbAgent.Text,
                                  txtAgentCommission.Text, cmbSecurityDeposit.Text, cmbBankGuarantee.Text, cmbPerformanceBankGuarantee.Text, txtDeliveryPeriod.Text, txtStandardDeliveryPeriod.Text, txtCustomerRequirement.Text, cmbPenaltyClause.Text, cmbPreDesignPreview.Text, cmbPreDispatchInspection.Text,
                                  cmbContractualAcceptance.Text, txtRemarks.Text, txtProjectMargin.Text, txtDiscount.Text, txtOrderValueinINR.Text, txtOrderValueinUSD.Text, txtInstallationValueinINR.Text, txtInstallationValueinUSD.Text, cmbLever.Text, txtQuotationEffort.Text, txtSaleseffort.Text,
                                   Convert.ToBoolean(chkLDClause.CheckState), dtpLDFromDate.Text, dtpLDToDate.Text, txtLDBody.Text, Convert.ToBoolean(chkLCClause.CheckState), dtpLDFromDate.Text, dtpLCEndDate.Text, txtBody.Text, txtEstimatedDesign.Text, txtEstimatedManufacturing.Text, txtEstimatedInsatllation.Text, txtTargetMaterialmargin.Text);
                        }
                        if (GlobalClass.iSuccess > 0)
                        {
                            revenuequestioninsert(1);
                            MessageBox.Show(" Project " + txtPMProjectCode.Text + " updated successfully", "Success", 0, MessageBoxIcon.Information);
                            btnSave.Text = Global.sBUTTON_SAVE_TEXT_ISSAVE;
                            //txtPMProjectCode.ResetText();
                            if (cmbGMApproveList.Visible == true)
                            {
                                cmbGMApproveList.Items.RemoveAt(cmbGMApproveList.SelectedIndex);
                                frmProjectmaster Pm = new frmProjectmaster();
                                this.Hide();
                                Pm.Show();
                            }
                            btnSave.Enabled = false;
                            //cmbPMProductType.Text = null;
                            //cmbProjectType.Text = null;
                            //cmbCustomer.Text = null;
                            //cmbProjectType.Enabled = true;
                            //cmbPMProductType.Enabled = true;
                            //cmbCustomer.Enabled = true;
                            bBOMProject = false;
                        }
                    }
                }
                catch (Exception ex)
                { MessageBox.Show("frmProjectmaster_ProjectStatusWarrenty  " + ex.Message); }
            }
        }

        DataTable dtProjectInfolist = new DataTable();
        List<string> lFolderList = new List<string>();
        private void fnCreateProjectInformation()
        {
            dtProjectInfolist = DAL.fnProjectInfoList(1, txtPMProjectCode.Text, "").Tables[0];

            if (dtProjectInfolist.Rows.Count == 0)
            {
                lFolderList.Add("Finance Documents");
                lFolderList.Add("Project Documents");

                Regex illegalInFileName = new Regex(@"[\\/:*?""<>|]");
                string sProjName = txtPMProjectDescription.Text;
                sProjName = illegalInFileName.Replace(sProjName, " ");
                //\\inbas01\Data\ERP\Pub
                string newPath = @"\\inbas01\Data\ERP\Pub\ERP_Project_Document\\" + txtPMProjectCode.Text;
                System.IO.Directory.CreateDirectory(newPath);
                string newPath1 = newPath + "\\Finance Documents";
                System.IO.Directory.CreateDirectory(newPath1);
                newPath1 = newPath + "\\Project Documents";
                System.IO.Directory.CreateDirectory(newPath1);

                //foreach (string Foldername in lFolderList)
                //{
                //    GlobalClass.iSuccess = DAL.fnAddProjectDocuments(0, txtPMProjectCode.Text, Foldername, null, null, null, "0", "0", "");
                //}

                sProjName = sProjName + "\\";
                string sourcePath = openFileDialog1.FileName;

                string targetPath = @"\\inbas01\Data\ERP\Pub\ERP_Project_Document\" + txtPMProjectCode.Text + "\\" + cmbProjectDocument.Text + "\\";


                if (!Directory.Exists(targetPath))
                {
                    Directory.CreateDirectory(targetPath);
                }

                File.Copy(sourcePath, targetPath + Path.GetFileName(sourcePath), true);

                if (Directory.Exists(targetPath))
                {
                    GlobalClass.iSuccess = DAL.fnAddProjectDocuments(0, txtPMProjectCode.Text, cmbProjectDocument.Text, login.GetUserDetails[2],
                        login.GetUserDetails[23], dtpPMCreatedDate.Text, "1", "0", openFileDialog1.SafeFileName, cmbDocType.Text);
                }
            }
            else
            {
                Regex illegalInFileName = new Regex(@"[\\/:*?""<>|]");
                string sProjName = txtPMProjectDescription.Text;
                sProjName = illegalInFileName.Replace(sProjName, " ");
                sProjName = sProjName + "\\";
                string sourcePath = openFileDialog1.FileName;
                string targetPath = @"\\inbas01\Data\ERP\Pub\ERP_Project_Document\" + txtPMProjectCode.Text + "\\" + cmbProjectDocument.Text + "\\";


                if (!Directory.Exists(targetPath))
                {
                    Directory.CreateDirectory(targetPath);
                }

                File.Copy(sourcePath, targetPath + Path.GetFileName(sourcePath), true);

                if (Directory.Exists(targetPath))
                {
                    GlobalClass.iSuccess = DAL.fnAddProjectDocuments(1, txtPMProjectCode.Text, cmbProjectDocument.Text, login.GetUserDetails[2],
                        login.GetUserDetails[23], dtpPMCreatedDate.Text, "1", "0", openFileDialog1.SafeFileName, cmbDocType.Text);
                }
            }
        }

        ListBox Ls = new ListBox();
        public void fnAlertMail(string sUser, string sRemarks, string sDocName, ListBox sCC)
        {
            try
            {
                DataTable dtlogindetails = DAL.fnloginemail(sUser.Trim()).Tables[0]; ;
                if (dtlogindetails.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(dtlogindetails.Rows[0]["emailid"].ToString()))
                    {
                        Outlook.Application oApp = new Outlook.Application();
                        Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);

                        if (sRemarks == "New")
                        {
                            oMsg.Subject = "Project document uploaded for verify";
                            oMsg.HTMLBody = " Dear " + sUser.ToUpper() + ", <br /><br /> Project '" + txtPMProjectCode.Text + " - " + txtPMProjectDescription.Text + "' document '" + cmbProjectDocument.Text + "' is uploaded to server. Verify the document. <br /> <br />Regards, <br /> " + login.GetUserDetails[2].ToUpper() + "  <br /> <br /> <b>**** THIS IS AN AUTO GENERATED EMAIL. PLEASE DO NOT REPLY ****</b>";
                        }
                        Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                        oRecips.Add(dtlogindetails.Rows[0]["emailid"].ToString());
                        oRecips.ResolveAll();

                        if (sCC.Items.Count > 0)
                        {
                            Outlook.Recipient oRecip;
                            List<string> sCCRecipsList = new List<string>();
                            foreach (string tempTO in sCC.Items)
                            {
                                if (tempTO != null)
                                    sCCRecipsList.Add(tempTO);
                            }
                            foreach (string t in sCCRecipsList)
                            {
                                oRecip = (Outlook.Recipient)oRecips.Add(t);
                                oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                                oRecip.Resolve();
                            }
                            oMsg.Send();
                            oRecip = null;
                        }
                        else
                        {
                            // Send.
                            oMsg.Send();
                            // Clean up.
                            oRecips = null;
                        }

                        oMsg = null;
                        oApp = null;
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void AssignReminder(string Subject, string Body, DateTime FromDate, DateTime ToDate, string sEmailID)
        {
            Outlook.Application outlookApp = new Outlook.Application(); // creates new outlook app
            Outlook.AppointmentItem oAppointment = (Outlook.AppointmentItem)outlookApp.CreateItem(Outlook.OlItemType.olAppointmentItem); // creates a new appointment
            oAppointment.Subject = Subject; // set the subject
            oAppointment.Body = Body; // set the body
            oAppointment.Location = "Sales Conference"; // set the location

            oAppointment.Start = Convert.ToDateTime(FromDate);
            oAppointment.End = Convert.ToDateTime(ToDate);
            oAppointment.ReminderSet = true; // Set the reminder
            oAppointment.ReminderMinutesBeforeStart = 15; // reminder time
            oAppointment.Importance = Outlook.OlImportance.olImportanceHigh; // appointment importance
            oAppointment.BusyStatus = Outlook.OlBusyStatus.olTentative;
            oAppointment.Save();

            Outlook.MailItem mailItem = oAppointment.ForwardAsVcal();
            // email address to send to 
            mailItem.To = sEmailID;
            // send 
            mailItem.Send();
            // oAppointment.Display(true);

        }


        CultureInfo culture = new CultureInfo("en-US");
        private void AssignTaskExample(string Subject, string Body, string FromDate, string ToDate)
        {
            Outlook.Application outlookApp = new Outlook.Application(); // creates new outlook app
            Outlook.AppointmentItem oAppointment = (Outlook.AppointmentItem)outlookApp.CreateItem(Outlook.OlItemType.olAppointmentItem); // creates a new appointment
            oAppointment.Subject = Subject; // set the subject
            oAppointment.Body = Body; // set the body
            oAppointment.Location = "Sales Conference"; // set the location

            string CustomFormat = "dd/MM/yyyy hh:mm tt";
            oAppointment.Start = Convert.ToDateTime(FromDate);
            oAppointment.End = Convert.ToDateTime(ToDate);
            //  oAppointment.Start = DateTime.ParseExact(dtpFromDate.Text.ToString(), CustomFormat, culture);
            //  oAppointment.End = DateTime.ParseExact(dtpEndDate.Text.ToString(),CustomFormat, culture);
            oAppointment.ReminderSet = true; // Set the reminder
            oAppointment.ReminderMinutesBeforeStart = 15; // reminder time
            oAppointment.Importance = Outlook.OlImportance.olImportanceHigh; // appointment importance
            oAppointment.BusyStatus = Outlook.OlBusyStatus.olBusy;
            oAppointment.Save();

            Outlook.MailItem mailItem = oAppointment.ForwardAsVcal();
            // email address to send to 
            mailItem.To = "accounts@biss.in";
            // send 
            mailItem.Send();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtPMProjectDescription.Text != string.Empty || txtPMProjectCode.Text != string.Empty || cmbPMProductType.Text != Global.sCOMBOBOX_DEFAULT_TEXT || cmbCustomer.Text != string.Empty || cmbProjectType.Text != Global.sCOMBOBOX_DEFAULT_TEXT)
                {
                    if (GlobalClass.fnClearallMessage() == DialogResult.Yes)//calling the clearall message function
                    {
                        Project_Master.frmProjectSearchForm ProjectSearchForm = new Project_Master.frmProjectSearchForm();
                        bSearch = true;
                        this.Hide();
                        pleasewaitform pleaseWait = new pleasewaitform();
                        // Display form modelessly
                        pleaseWait.Show();
                        //  ALlow main UI thread to properly display please wait form.
                        Application.DoEvents();
                        pleaseWait.Hide();
                        ProjectSearchForm.ShowDialog();

                    }
                }
                else
                {
                    Project_Master.frmProjectSearchForm ProjectSearchForm = new Project_Master.frmProjectSearchForm();
                    bSearch = true;
                    this.Hide();
                    pleasewaitform pleaseWait = new pleasewaitform();
                    // Display form modelessly
                    pleaseWait.Show();
                    //  ALlow main UI thread to properly display please wait form.
                    Application.DoEvents();
                    ProjectSearchForm.ShowDialog();
                    pleaseWait.Hide();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("frmProjectmaster_btnSearch_Click" + ex.Message);
            }
        }

        private void llHome_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            //  btnHome_Click(sender, e);
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            //if (GlobalClass.fnMessageResult() == Global.sCLOSE_MESSAGE_RESULT_YES)  //calling close message function
            //    this.Close();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            fnClose();
        }

        private void fnClose()
        {
            this.Hide();
            //Project_Master.frmProjectHome Home = new Project_Master.frmProjectHome();
            Home.Show();
        }

        private void frmProjectmaster_FormClosing(object sender, FormClosingEventArgs e)
        {
            //  frmForm2 form = new frmForm2();
            fnClose();
        }



        private void cmbCustomer_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (fnGetProjectCode != null)
            {
                sCustomerCode = string.Empty;
                DR = dtCustomerList.Select("CustomerName = '" + cmbCustomer.Text + "'");
                if (DR.Length > 0)
                {
                    sCustomerCode = DR[0]["CusCode"].ToString();
                    txtcuscode.Text = DR[0]["CusCode"].ToString();
                    sCustomerCode = sCustomerCode.Substring(3);
                }
            }
            else
            {
                sCustomerCode = string.Empty;
                DR = dtCustomerList.Select("CustomerName = '" + cmbCustomer.Text + "'");
                if (DR.Length > 0)
                {
                    sCustomerCode = DR[0]["CusCode"].ToString();
                    txtcuscode.Text = DR[0]["CusCode"].ToString();
                    sCustomerCode = sCustomerCode.Substring(3);
                    txtBilltoCustomer.Text = DR[0]["Address1"].ToString() + DR[0]["Address2"].ToString() + DR[0]["Address3"].ToString();
                    txtShiptoCustomer.Text = DR[0]["Address1"].ToString() + DR[0]["Address2"].ToString() + DR[0]["Address3"].ToString();
                    cmbEndUserCountry.SelectedItem = DR[0]["Country"].ToString();

                    txtContactPerson.Text = DR[0]["ContactPerson"].ToString();
                    txtContactAddress.Text = DR[0]["Address1"].ToString() + DR[0]["Address2"].ToString() + DR[0]["Address3"].ToString();
                    txtDepartment.Text = "";
                    txtContactEmail.Text = DR[0]["EmailAddress"].ToString();
                    txtOfficeNo.Text = DR[0]["PhoneNo"].ToString();
                    txtMoblieNo.Text = DR[0]["MobileNo"].ToString();
                }
                else
                {
                    txtcuscode.Clear();
                    txtcuscode.Clear();
                    txtBilltoCustomer.Clear();
                    txtShiptoCustomer.Clear();
                    cmbEndUserCountry.SelectedIndex = -1;

                    txtContactPerson.Clear();
                    txtContactAddress.Clear();
                    txtDepartment.Clear();
                    txtContactEmail.Clear();
                    txtOfficeNo.Clear();
                    txtMoblieNo.Clear();
                }
            }
        }
        //DataTable subproducttype = new DataTable();
        private void cmbPMProductType_SelectedIndexChanged(object sender, EventArgs e)
        {

            /*
            // Call the function to get subproducttype data based on the selected item
            subproducttype = DAL.fnsubproducttype(cmbPMProductType.SelectedItem.ToString()).Tables[0];

            if (subproducttype.Rows.Count > 0)
            {
                // Set the text of cmbsystemsubtype to the value from subproducttype data
                cmbsystemsubtype.Text = subproducttype.Rows[0][2].ToString();
            }
            else
            {
                // If no data found, set cmbsystemsubtype text to empty string
                cmbsystemsubtype.Text = "";
            }

            */

            if (cmbPMProductType.SelectedItem != null)
            {
                string selectedProductType = cmbPMProductType.SelectedItem.ToString();
                LoadSubProductTypes(selectedProductType);
            }
            /*
            switch (cmbPMProductType.SelectedIndex)
              {
                  case 0:
                      cmbsystemsubtype.Text = "";
                      cmbsystemsubtype.Items.Clear();
                      cmbsystemsubtype.Items.Add("NANO");
                      cmbsystemsubtype.Items.Add("MEDIAN");
                      cmbsystemsubtype.Items.Add("MAGNUM");
                      cmbsystemsubtype.Items.Add("ELECTRA");
                      cmbsystemsubtype.Items.Add("AXIAL TORSION");
                      cmbsystemsubtype.Items.Add("ELASTOMER/HFTS");
                      break;

                  case 1:
                      cmbsystemsubtype.Text = "";
                      cmbsystemsubtype.Items.Clear();
                      cmbsystemsubtype.Items.Add("Structural Actuator");
                      cmbsystemsubtype.Items.Add("Bi-Axial");
                      break;

                  case 2:
                      cmbsystemsubtype.Text = "";
                      cmbsystemsubtype.Items.Clear();
                      cmbsystemsubtype.Items.Add("Single Station");
                      cmbsystemsubtype.Items.Add("Dual Station");
                      cmbsystemsubtype.Items.Add("Tilting");
                      cmbsystemsubtype.Items.Add("Durabality");
                      cmbsystemsubtype.Items.Add("Suspension Test Rig");
                      break;

                  case 3:
                      cmbsystemsubtype.Text = "";
                      cmbsystemsubtype.Items.Clear();
                      cmbsystemsubtype.Items.Add("Single Column");
                      cmbsystemsubtype.Items.Add("Dual Column");
                      break;

                  case 4:
                      cmbsystemsubtype.Text = "";
                      cmbsystemsubtype.Items.Clear();
                      cmbsystemsubtype.Items.Add("LigaGen");
                      cmbsystemsubtype.Items.Add("LumeGen");
                      cmbsystemsubtype.Items.Add("CartiGen");
                      cmbsystemsubtype.Items.Add("DermiGen");
                      cmbsystemsubtype.Items.Add("OsteoGen");
                      break;

                  case 5:
                      cmbsystemsubtype.Text = "";
                      cmbsystemsubtype.Items.Clear();
                      cmbsystemsubtype.Items.Add("3 Axis");
                      cmbsystemsubtype.Items.Add("5 Axis");
                      cmbsystemsubtype.Items.Add("6 Axis");
                      cmbsystemsubtype.Items.Add("Custom");
                      break;

                  case 6:
                      cmbsystemsubtype.Text = "";
                      cmbsystemsubtype.Items.Clear();
                      cmbsystemsubtype.Items.Add("Uni Axial");
                      cmbsystemsubtype.Items.Add("Bi Axial");
                      cmbsystemsubtype.Items.Add("Tri Axial");
                      break;

                  case 7:
                      cmbsystemsubtype.Text = "";
                      cmbsystemsubtype.Items.Clear();
                      cmbsystemsubtype.Items.Add("Others");
                      break;
                  case 8:
                      cmbsystemsubtype.Text = "";
                      cmbsystemsubtype.Items.Clear();
                      cmbsystemsubtype.Items.Add("Others");

                      break;

                  case 11:
                      cmbsystemsubtype.Text = "";
                      cmbsystemsubtype.Items.Clear();
                      cmbsystemsubtype.Items.Add("EM");
                      cmbsystemsubtype.Items.Add("Static Hydraulic");
                      break;
                  case 12:
                      cmbsystemsubtype.Text = "";
                      cmbsystemsubtype.Items.Clear();
                      cmbsystemsubtype.Items.Add("Drop Tower");
                      cmbsystemsubtype.Items.Add("Pendulum Impact");
                      break;
                  case 13:
                      cmbsystemsubtype.Text = "";
                      cmbsystemsubtype.Items.Clear();
                      cmbsystemsubtype.Items.Add("LFA");
                      cmbsystemsubtype.Items.Add("HFA");
                      break;

                  case 20:
                      cmbsystemsubtype.Text = "";
                      cmbsystemsubtype.Items.Clear();
                      cmbsystemsubtype.Items.Add("Grips");
                      cmbsystemsubtype.Items.Add("Jaw faces");
                      cmbsystemsubtype.Items.Add("Exensometer RT");
                      cmbsystemsubtype.Items.Add("Extensometer HT");
                      cmbsystemsubtype.Items.Add("others");
                      break;
                  case 21:
                      cmbsystemsubtype.Text = "";
                      cmbsystemsubtype.Items.Clear();
                      cmbsystemsubtype.Items.Add("Grips");
                      cmbsystemsubtype.Items.Add("Jaw faces");
                      cmbsystemsubtype.Items.Add("Extensometers");
                      cmbsystemsubtype.Items.Add("others");
                      break;

              }
            */
              
            if (cmbProjectType.SelectedIndex == 4)
            {
                if (!bSearch)
                {
                    cmbStockProject.Items.Clear();
                    cmbStockProject.SelectedIndex = -1;
                    lblProjectName.Text = "";
                    pnCustomerlinkProject.Visible = true;
                    DataTable dtStandardProject = new DataTable();
                    dtStandardProject = DAL.fnWIPStockTransferProjectList(0, "", cmbPMProductType.Text).Tables[0];
                    foreach (DataRow DR in dtStandardProject.Rows)
                    {
                        if (!cmbStockProject.Items.Contains(DR[1].ToString()))
                            cmbStockProject.Items.Add(DR[1].ToString());
                    }
                }
            }
            else 
            {
                pnCustomerlinkProject.Visible = false;
            }
            
        }

        bool bBOMProject = false;
        private void chkBOMProject_CheckedChanged(object sender, EventArgs e)
        {
            if (chkBOMProject.Checked == true)
            {
                bBOMProject = true;
            }
            else
            {
                bBOMProject = false;
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (cmbProjectType.Text == "Fixed Asset (CIP)")
            {
                if (!string.IsNullOrEmpty(txtPMProjectDescription.Text) && !string.IsNullOrEmpty(txtCapexNumber.Text) &&
                    !string.IsNullOrEmpty(txtCapexName.Text) && !string.IsNullOrEmpty(txtCapexRequester.Text) &&
                     !string.IsNullOrEmpty(txtCapexAmount.Text) && !string.IsNullOrEmpty(txtOverHead.Text) && cmbCustomer.SelectedIndex >= 0)
                {
                    tabControl1.SelectedIndex = 1;
                }
                else
                {
                    if (cmbCustomer.SelectedIndex < 0)
                    {
                        MessageBox.Show("Please select customer", "Error", 0, MessageBoxIcon.Error);
                        cmbCustomer.DroppedDown = true;
                    }
                    else if (string.IsNullOrEmpty(txtPMProjectDescription.Text))
                    {
                        MessageBox.Show("Please enter project description", "Error", 0, MessageBoxIcon.Error);
                        txtPMProjectDescription.Focus();
                    }
                    else if (string.IsNullOrEmpty(txtCapexNumber.Text))
                    {
                        MessageBox.Show("Please enter Capex Number", "Error", 0, MessageBoxIcon.Error);
                        txtCapexNumber.Focus();
                    }
                    else if (string.IsNullOrEmpty(txtCapexName.Text))
                    {
                        MessageBox.Show("Please enter Capex Name", "Error", 0, MessageBoxIcon.Error);
                        txtCapexName.Focus();
                    }
                    else if (string.IsNullOrEmpty(txtCapexRequester.Text))
                    {
                        MessageBox.Show("Please enter Capex Requester", "Error", 0, MessageBoxIcon.Error);
                        txtCapexRequester.Focus();
                    }
                    else if (string.IsNullOrEmpty(txtCapexAmount.Text))
                    {
                        MessageBox.Show("Please enter Capex Amount in INR", "Error", 0, MessageBoxIcon.Error);
                        txtCapexAmount.Focus();
                    }
                    else if (string.IsNullOrEmpty(txtOverHead.Text))
                    {
                        MessageBox.Show("Please enter Capex Amount in USD", "Error", 0, MessageBoxIcon.Error);
                        txtOverHead.Focus();
                    }
                }
            }
            else
            {
                if (txtPMProjectDescription.Text != string.Empty && cmbCustomer.SelectedIndex >= 0 && !string.IsNullOrEmpty(txtWarrantyClose.Text) && !string.IsNullOrEmpty(cmbPMProductType.Text) && !string.IsNullOrEmpty(cmbProjectType.Text) && !string.IsNullOrEmpty(cmbsystemsubtype.Text) && cmbProjectType.SelectedIndex >= 0
                        && CmbStandardCustom.SelectedIndex >= 0 && cmbWarrantyStartsFrom.Text != string.Empty && cmbProject8020.SelectedIndex >= 0 && cmbCustomizationlevel.SelectedIndex >= 0)
                {
                    tabControl1.SelectedIndex = 1;
                }
                else
                {
                    if (cmbProjectType.SelectedIndex < 0)
                    {
                        MessageBox.Show("Select Project type", "Error", 0, MessageBoxIcon.Error);
                        cmbProjectType.DroppedDown = true;
                    }
                    else if (cmbCustomer.SelectedIndex < 0)
                    {
                        MessageBox.Show("Select customer", "Error", 0, MessageBoxIcon.Error);
                        cmbCustomer.DroppedDown = true;
                    }
                    else if (CmbStandardCustom.SelectedIndex < 0)
                    {
                        MessageBox.Show("Select standard custom type", "Error", 0, MessageBoxIcon.Error);
                        CmbStandardCustom.DroppedDown = true;

                    }
                    else if (string.IsNullOrEmpty(cmbPMProductType.Text))
                    {
                        MessageBox.Show("Select Product type", "Error", 0, MessageBoxIcon.Error);
                        cmbPMProductType.DroppedDown = true;
                    }
                    else if (string.IsNullOrEmpty(cmbsystemsubtype.Text))
                    {
                        MessageBox.Show("Select system sub type", "Error", 0, MessageBoxIcon.Error);
                        cmbsystemsubtype.DroppedDown = true;
                    }

                    else if (txtPMProjectDescription.Text == string.Empty)
                    {
                        MessageBox.Show("Enter project description", "Error", 0, MessageBoxIcon.Error);
                        txtPMProjectDescription.Focus();
                    }
                    else if (string.IsNullOrEmpty(comManufactureform.Text))
                    {
                        MessageBox.Show("Select Manufacturer Name", "Error", 0, MessageBoxIcon.Error);
                        comManufactureform.DroppedDown = true;
                    }

                    else if (string.IsNullOrEmpty(cmbProductionCompany.Text))
                    {
                        MessageBox.Show("Please select the product maker BISS/Instron.", "Error", 0, MessageBoxIcon.Error);
                        cmbProductionCompany.DroppedDown = true;
                    }
                    else if (cmbWarrantyStartsFrom.Text == string.Empty)
                    {
                        MessageBox.Show("Select warrtanty starts from", "Error", 0, MessageBoxIcon.Error);
                        cmbWarrantyStartsFrom.DroppedDown = true;
                    }
                    else if (string.IsNullOrEmpty(txtWarrantyClose.Text))
                    {
                        MessageBox.Show("Enter warrtanty in months", "Error", 0, MessageBoxIcon.Error);
                        txtWarrantyClose.Focus();
                    }
                    else if (cmbProject8020.SelectedIndex < 0)
                    {
                        MessageBox.Show("Select project 80/20", "Error", 0, MessageBoxIcon.Error);
                        cmbProject8020.DroppedDown = true;
                    }
                    else if (cmbCustomizationlevel.SelectedIndex < 0)
                    {
                        MessageBox.Show("Select project customization level", "Error", 0, MessageBoxIcon.Error);
                        cmbCustomizationlevel.DroppedDown = true;
                    }
                    //code for profit centre
                    else if (string.IsNullOrEmpty(comboBoxProfitCentre.Text))
                    {
                        MessageBox.Show("Please select Profit Centre.", "Error", 0, MessageBoxIcon.Error);
                        comboBoxProfitCentre.DroppedDown = true;
                    }



                }

            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 0;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {

        }

        #region New PO
        private void fnPrintOrderEntry()
        {
            try
            {
                int iRowIndex = 1;
                string ExcelFolderName;
                string ExcelFolderPath;
                string FileFullPath;
                EXCEL.Workbook NewWorkBook;
                EXCEL.Worksheet NewWorkSheet;
                EXCEL.Application ExcelApp;
                EXCEL.Range CELLS, cell1, cell2;
                {
                    object misValue;
                    ExcelFolderName = "\\Order Entry";
                    ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + ExcelFolderName + "\\";
                    FileFullPath = ExcelFolderPath + txtPMProjectCode.Text + " Order Entry Form -" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + ".xlsx";
                    string[] Text ={"",
                                Global.sCompanyName,
                                "NO.497E,4TH PHASE PEENYA INDUSTRIAL AREA ",
                                "BANGALORE-560 058",
                                "Phone:91(080) 28360184. FAX: (080) 28360047.",
                                "Web: http://www.biss.in, Email: sales@biss.in",
                                "ORDER ENTRY FORM",
                                "Form No.: "+dtProjectOrderEntry.Rows[0]["OfferNo"].ToString()+" "};

                    string[] Text1 = {   "Remarks/Comment:",
                                         "",
                                         "",
                                         "",
                                         "",
                                         "",
                                         "" };
                    if (!Directory.Exists(ExcelFolderPath))
                        Directory.CreateDirectory(ExcelFolderPath);

                    ExcelApp = new EXCEL.Application();
                    misValue = System.Reflection.Missing.Value;
                    try
                    {
                        if (ExcelApp == null)
                            MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                        NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                        NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                        if (NewWorkSheet == null)
                            MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                        else
                            NewWorkSheet.Name = "Order Entry Form";
                        EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                        if (RANGE == null)
                            MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                        NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        CELLS = NewWorkSheet.Cells;
                        NewWorkSheet.PageSetup.PrintGridlines = false;
                        //  NewWorkSheet.Rows.AutoFit();
                        //    NewWorkSheet.Columns.AutoFit();

                        //  NewWorkSheet.Cells[iRowIndex, 2] = "Purchase Order";
                        // CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 14);
                        NewWorkSheet.Range["B1:I1"].Cells.Font.Size = 16;
                        NewWorkSheet.Range["B1:I1"].Cells.Font.Bold = 16;
                        iRowIndex++;
                        foreach (string str in Text)
                        {
                            NewWorkSheet.Cells[iRowIndex, 2] = str;
                            if (iRowIndex < 8)
                            {
                                CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 2, 9);
                            }
                            iRowIndex++;
                        }
                        CellMerge("Merge", NewWorkSheet, 8, 8, 2, 12);
                        CellMerge("Merge", NewWorkSheet, 9, 9, 2, 6);
                        var dt = Convert.ToDateTime(dtProjectList.Rows[0]["DateCreated"].ToString());
                        NewWorkSheet.Cells[9, 7] = "Date:" + dt.ToShortDateString();
                        CellMerge("Merge", NewWorkSheet, 9, 9, 7, 12);
                        CellMerge("GridLines", NewWorkSheet, 9, 9, 7, 12);

                        NewWorkSheet.Cells[10, 2] = "Customer Name:";
                        CellMerge("Merge", NewWorkSheet, 10, 10, 2, 4);
                        CellMerge("GridLines", NewWorkSheet, 10, 10, 2, 4);
                        NewWorkSheet.Cells[11, 2] = dtProjectList.Rows[0]["Customer"].ToString();
                        NewWorkSheet.Cells[11, 2].WrapText = true;
                        CellMerge("Merge", NewWorkSheet, 11, 12, 2, 4);
                        CellMerge("GridLines", NewWorkSheet, 11, 12, 2, 4);

                        NewWorkSheet.Cells[10, 5] = "PO Number and Date:";
                        CellMerge("Merge", NewWorkSheet, 10, 10, 5, 6);
                        CellMerge("GridLines", NewWorkSheet, 10, 10, 5, 6);
                        NewWorkSheet.Cells[11, 5] = dtProjectOrderEntry.Rows[0]["PONo"].ToString() + " Dated:" + dtProjectOrderEntry.Rows[0]["PODate"].ToString();
                        NewWorkSheet.Cells[11, 5].WrapText = true;
                        CellMerge("Merge", NewWorkSheet, 11, 12, 5, 6);
                        CellMerge("GridLines", NewWorkSheet, 11, 12, 5, 6);

                        NewWorkSheet.Cells[10, 7] = "Offer No and Date:";
                        CellMerge("Merge", NewWorkSheet, 10, 10, 7, 8);
                        CellMerge("GridLines", NewWorkSheet, 10, 10, 7, 8);
                        NewWorkSheet.Cells[11, 7] = dtProjectOrderEntry.Rows[0]["OfferNo"].ToString() + " Dated:" + dtProjectOrderEntry.Rows[0]["RecievedDate"].ToString();
                        NewWorkSheet.Cells[11, 7].WrapText = true;
                        CellMerge("Merge", NewWorkSheet, 11, 12, 7, 8);
                        CellMerge("GridLines", NewWorkSheet, 11, 12, 7, 8);

                        NewWorkSheet.Cells[10, 9] = "Standard/Custom:";
                        CellMerge("Merge", NewWorkSheet, 10, 10, 9, 10);
                        CellMerge("GridLines", NewWorkSheet, 10, 10, 9, 10);
                        NewWorkSheet.Cells[11, 9] = dtProjectOrderEntry.Rows[0]["StandardCustom"].ToString();
                        CellMerge("Merge", NewWorkSheet, 11, 12, 9, 10);
                        CellMerge("GridLines", NewWorkSheet, 11, 12, 9, 10);

                        NewWorkSheet.Cells[10, 11] = "Shipment Method:";
                        CellMerge("Merge", NewWorkSheet, 10, 10, 11, 12);
                        CellMerge("GridLines", NewWorkSheet, 10, 10, 11, 12);
                        NewWorkSheet.Cells[11, 11] = dtProjectOrderEntry.Rows[0]["ShipmentMode"].ToString();
                        CellMerge("Merge", NewWorkSheet, 11, 12, 11, 12);
                        CellMerge("GridLines", NewWorkSheet, 11, 12, 11, 12);

                        CellMerge("Bold", NewWorkSheet, 8, 10, 2, 12);

                        NewWorkSheet.Cells[13, 2] = "Project Code:";
                        CellMerge("Merge", NewWorkSheet, 13, 13, 2, 3);
                        CellMerge("GridLines", NewWorkSheet, 13, 13, 2, 3);
                        NewWorkSheet.Cells[14, 2] = dtProjectOrderEntry.Rows[0]["ProjectCode"].ToString();
                        CellMerge("Merge", NewWorkSheet, 14, 14, 2, 3);
                        CellMerge("GridLines", NewWorkSheet, 14, 14, 2, 3);

                        NewWorkSheet.Cells[13, 4] = "Product Code:";
                        CellMerge("Merge", NewWorkSheet, 13, 13, 4, 5);
                        CellMerge("GridLines", NewWorkSheet, 13, 13, 4, 5);
                        NewWorkSheet.Cells[14, 4] = dtProjectList.Rows[0]["Type"].ToString();
                        CellMerge("Merge", NewWorkSheet, 14, 14, 4, 5);
                        CellMerge("GridLines", NewWorkSheet, 14, 14, 4, 5);

                        NewWorkSheet.Cells[13, 6] = "Model Number:";
                        //   CellMerge("Merge", NewWorkSheet, 13, 13, 4, 5);
                        CellMerge("GridLines", NewWorkSheet, 13, 13, 6, 6);
                        NewWorkSheet.Cells[14, 6] = dtProjectOrderEntry.Rows[0]["ModelNumber"].ToString();
                        // CellMerge("Merge", NewWorkSheet, 14, 14, 4, 5);
                        CellMerge("GridLines", NewWorkSheet, 14, 14, 6, 6);

                        NewWorkSheet.Cells[13, 7] = "End User Country:";
                        CellMerge("Merge", NewWorkSheet, 13, 13, 7, 8);
                        CellMerge("GridLines", NewWorkSheet, 13, 13, 7, 8);
                        NewWorkSheet.Cells[14, 7] = dtProjectOrderEntry.Rows[0]["EndUserCountry"].ToString();
                        CellMerge("Merge", NewWorkSheet, 14, 14, 7, 8);
                        CellMerge("GridLines", NewWorkSheet, 14, 14, 7, 8);

                        NewWorkSheet.Cells[13, 9] = "Target Value:";
                        CellMerge("Merge", NewWorkSheet, 13, 13, 9, 10);
                        CellMerge("GridLines", NewWorkSheet, 13, 13, 9, 10);
                        NewWorkSheet.Cells[14, 9] = txtTargetValue.Text;
                        CellMerge("Merge", NewWorkSheet, 14, 14, 9, 10);
                        CellMerge("GridLines", NewWorkSheet, 14, 14, 9, 10);

                        NewWorkSheet.Cells[13, 11] = "Project Focal:";
                        CellMerge("Merge", NewWorkSheet, 13, 13, 11, 12);
                        CellMerge("GridLines", NewWorkSheet, 13, 13, 11, 12);
                        NewWorkSheet.Cells[14, 11] = dtProjectOrderEntry.Rows[0]["ProjectFocal"].ToString();
                        CellMerge("Merge", NewWorkSheet, 14, 14, 11, 12);
                        CellMerge("GridLines", NewWorkSheet, 14, 14, 11, 12);

                        CellMerge("Bold", NewWorkSheet, 13, 13, 2, 12);

                        NewWorkSheet.Cells[15, 2] = "Bill-to Customer Name and Address:";
                        CellMerge("Merge", NewWorkSheet, 15, 15, 2, 6);
                        CellMerge("GridLines", NewWorkSheet, 15, 15, 2, 6);
                        NewWorkSheet.Cells[16, 2] = dtProjectOrderEntry.Rows[0]["BilltoCustomer"].ToString();
                        NewWorkSheet.Cells[16, 2].WrapText = true;
                        CellMerge("Merge", NewWorkSheet, 16, 19, 2, 6);
                        CellMerge("GridLines", NewWorkSheet, 16, 19, 2, 6);

                        NewWorkSheet.Cells[15, 7] = "Ship-to Name, Address and Phone:";
                        CellMerge("Merge", NewWorkSheet, 15, 15, 7, 12);
                        CellMerge("GridLines", NewWorkSheet, 15, 15, 7, 12);
                        NewWorkSheet.Cells[16, 7] = dtProjectOrderEntry.Rows[0]["ShiptoCustomer"].ToString();
                        NewWorkSheet.Cells[16, 7].WrapText = true;
                        CellMerge("Merge", NewWorkSheet, 16, 19, 7, 12);
                        CellMerge("GridLines", NewWorkSheet, 16, 19, 7, 12);

                        CellMerge("Bold", NewWorkSheet, 15, 15, 2, 12);

                        NewWorkSheet.Cells[20, 2] = "End User Contact Details:";
                        CellMerge("Merge", NewWorkSheet, 20, 20, 2, 10);
                        CellMerge("GridLines", NewWorkSheet, 20, 20, 2, 10);

                        NewWorkSheet.Cells[20, 11] = "Shipping Terms:";
                        CellMerge("Merge", NewWorkSheet, 20, 21, 11, 12);
                        CellMerge("GridLines", NewWorkSheet, 20, 21, 11, 12);
                        NewWorkSheet.Cells[22, 11] = dtProjectOrderEntry.Rows[0]["ShippingTerms"].ToString();
                        CellMerge("Merge", NewWorkSheet, 22, 23, 11, 12);
                        CellMerge("GridLines", NewWorkSheet, 22, 23, 11, 12);


                        NewWorkSheet.Cells[21, 2] = "Name:";
                        CellMerge("Merge", NewWorkSheet, 21, 21, 2, 3);
                        CellMerge("GridLines", NewWorkSheet, 21, 21, 2, 3);
                        NewWorkSheet.Cells[22, 2] = dtProjectOrderEntry.Rows[0]["ContactPerson"].ToString();
                        CellMerge("Merge", NewWorkSheet, 22, 23, 2, 3);
                        CellMerge("GridLines", NewWorkSheet, 22, 23, 2, 3);

                        NewWorkSheet.Cells[21, 4] = "Address:";
                        CellMerge("Merge", NewWorkSheet, 21, 21, 4, 6);
                        CellMerge("GridLines", NewWorkSheet, 21, 21, 4, 6);
                        NewWorkSheet.Cells[22, 4] = dtProjectOrderEntry.Rows[0]["ContactAddress"].ToString();
                        CellMerge("Merge", NewWorkSheet, 22, 23, 4, 6);
                        CellMerge("GridLines", NewWorkSheet, 22, 23, 4, 6);

                        NewWorkSheet.Cells[21, 7] = "Phone/Mobile No.:";
                        CellMerge("Merge", NewWorkSheet, 21, 21, 7, 8);
                        CellMerge("GridLines", NewWorkSheet, 21, 21, 7, 8);
                        NewWorkSheet.Cells[22, 7] = dtProjectOrderEntry.Rows[0]["ContactOfficeNo"].ToString() + " / " + dtProjectOrderEntry.Rows[0]["ContactMoblieNo"].ToString();
                        CellMerge("Merge", NewWorkSheet, 22, 23, 7, 8);
                        CellMerge("GridLines", NewWorkSheet, 22, 23, 7, 8);

                        NewWorkSheet.Cells[21, 9] = "Email ID:";
                        CellMerge("Merge", NewWorkSheet, 21, 21, 9, 10);
                        CellMerge("GridLines", NewWorkSheet, 21, 21, 9, 10);
                        NewWorkSheet.Cells[22, 9] = dtProjectOrderEntry.Rows[0]["ContactEmail"].ToString();
                        CellMerge("Merge", NewWorkSheet, 22, 23, 9, 10);
                        CellMerge("GridLines", NewWorkSheet, 22, 23, 9, 10);

                        CellMerge("Bold", NewWorkSheet, 20, 21, 2, 12);

                        NewWorkSheet.Cells[24, 2] = "Accepted Payment Terms:";
                        CellMerge("Merge", NewWorkSheet, 24, 24, 2, 6);
                        CellMerge("GridLines", NewWorkSheet, 24, 24, 2, 6);
                        NewWorkSheet.Cells[25, 2] = dtProjectOrderEntry.Rows[0]["PaymentTerms"].ToString();
                        CellMerge("Merge", NewWorkSheet, 25, 29, 2, 6);
                        CellMerge("GridLines", NewWorkSheet, 25, 29, 2, 6);

                        NewWorkSheet.Cells[24, 7] = "Dealer/Distributor:";
                        CellMerge("Merge", NewWorkSheet, 24, 24, 7, 9);
                        CellMerge("GridLines", NewWorkSheet, 24, 24, 7, 9);
                        NewWorkSheet.Cells[25, 7] = dtProjectOrderEntry.Rows[0]["Agent"].ToString();
                        CellMerge("Merge", NewWorkSheet, 25, 25, 7, 9);
                        CellMerge("GridLines", NewWorkSheet, 25, 25, 7, 9);

                        NewWorkSheet.Cells[26, 7] = "80/20 :";
                        CellMerge("Bold", NewWorkSheet, 26, 26, 7, 8);
                        CellMerge("Merge", NewWorkSheet, 26, 26, 7, 8);
                        CellMerge("GridLines", NewWorkSheet, 26, 26, 7, 8);
                        NewWorkSheet.Cells[26, 9] = cmbProject8020.Text;

                        NewWorkSheet.Cells[26, 10] = "Customization :";
                        CellMerge("Bold", NewWorkSheet, 26, 26, 10, 11);
                        CellMerge("Merge", NewWorkSheet, 26, 26, 10, 11);
                        CellMerge("GridLines", NewWorkSheet, 26, 26, 10, 11);
                        NewWorkSheet.Cells[26, 12] = cmbCustomizationlevel.Text;
                        CellMerge("GridLines", NewWorkSheet, 26, 26, 11, 12);

                        NewWorkSheet.Cells[24, 10] = "Dealer/Distributor's Commission:";
                        CellMerge("Merge", NewWorkSheet, 24, 24, 10, 12);
                        CellMerge("GridLines", NewWorkSheet, 24, 24, 10, 12);
                        NewWorkSheet.Cells[25, 10] = dtProjectOrderEntry.Rows[0]["AgentCommission"].ToString();
                        CellMerge("Merge", NewWorkSheet, 25, 25, 10, 12);
                        CellMerge("GridLines", NewWorkSheet, 25, 25, 10, 12);

                        CellMerge("Bold", NewWorkSheet, 24, 24, 2, 12);

                        NewWorkSheet.Cells[27, 7] = "Security Deposit/Bank Guarantee/Performance Bank Guarantee:";
                        CellMerge("Bold", NewWorkSheet, 27, 27, 7, 12);
                        CellMerge("Merge", NewWorkSheet, 27, 27, 7, 12);
                        CellMerge("GridLines", NewWorkSheet, 27, 27, 7, 12);
                        NewWorkSheet.Cells[28, 7] = dtProjectOrderEntry.Rows[0]["SecurityDeposit"].ToString() + " / " + dtProjectOrderEntry.Rows[0]["BankGuarantee"].ToString() + " / " + dtProjectOrderEntry.Rows[0]["PerformanceBankGuarantee"].ToString();
                        CellMerge("Merge", NewWorkSheet, 28, 29, 7, 12);
                        CellMerge("GridLines", NewWorkSheet, 28, 29, 7, 12);


                        NewWorkSheet.Cells[30, 2] = "Standard Delivery Period:";
                        CellMerge("Merge", NewWorkSheet, 30, 30, 2, 4);
                        CellMerge("GridLines", NewWorkSheet, 30, 30, 2, 4);
                        NewWorkSheet.Cells[31, 2] = dtProjectOrderEntry.Rows[0]["StandardDeliveryPeriod"].ToString();
                        CellMerge("Merge", NewWorkSheet, 31, 31, 2, 4);
                        CellMerge("GridLines", NewWorkSheet, 31, 31, 2, 4);

                        NewWorkSheet.Cells[30, 5] = "Delivery Period as per PO:";
                        CellMerge("Merge", NewWorkSheet, 30, 30, 5, 6);
                        CellMerge("GridLines", NewWorkSheet, 30, 30, 5, 6);
                        NewWorkSheet.Cells[31, 5] = dtProjectOrderEntry.Rows[0]["DeliveryPeriod"].ToString();
                        CellMerge("Merge", NewWorkSheet, 31, 31, 5, 6);
                        CellMerge("GridLines", NewWorkSheet, 31, 31, 5, 6);


                        NewWorkSheet.Cells[30, 7] = "Customer Expectation:";
                        CellMerge("Merge", NewWorkSheet, 30, 30, 7, 9);
                        CellMerge("GridLines", NewWorkSheet, 30, 30, 7, 9);
                        NewWorkSheet.Cells[31, 7] = dtProjectOrderEntry.Rows[0]["CustomerRequirement"].ToString();
                        CellMerge("Merge", NewWorkSheet, 31, 31, 7, 9);
                        CellMerge("GridLines", NewWorkSheet, 31, 31, 7, 9);

                        NewWorkSheet.Cells[30, 10] = "Penalty Clause?";
                        CellMerge("Merge", NewWorkSheet, 30, 30, 10, 11);
                        CellMerge("GridLines", NewWorkSheet, 30, 30, 10, 11);
                        NewWorkSheet.Cells[30, 12] = dtProjectOrderEntry.Rows[0]["PenaultyClause"].ToString();
                        CellMerge("Merge", NewWorkSheet, 30, 30, 12, 12);
                        CellMerge("GridLines", NewWorkSheet, 30, 30, 12, 12);

                        CellMerge("Bold", NewWorkSheet, 30, 30, 2, 12);

                        NewWorkSheet.Cells[32, 2] = "Pre-design Review:";
                        CellMerge("Merge", NewWorkSheet, 32, 32, 2, 4);
                        CellMerge("GridLines", NewWorkSheet, 32, 32, 2, 4);
                        NewWorkSheet.Cells[33, 2] = dtProjectOrderEntry.Rows[0]["PreDesignReview"].ToString();
                        CellMerge("Merge", NewWorkSheet, 33, 34, 2, 4);
                        CellMerge("GridLines", NewWorkSheet, 33, 34, 2, 4);

                        NewWorkSheet.Cells[32, 5] = "Customer Training at BiSS:";
                        CellMerge("Merge", NewWorkSheet, 32, 32, 5, 6);
                        CellMerge("GridLines", NewWorkSheet, 32, 32, 5, 6);
                        NewWorkSheet.Cells[33, 5] = "";
                        CellMerge("Merge", NewWorkSheet, 33, 34, 5, 6);
                        CellMerge("GridLines", NewWorkSheet, 33, 34, 5, 6);

                        NewWorkSheet.Cells[32, 7] = "Pre-dispatch Inspection:";
                        CellMerge("Merge", NewWorkSheet, 32, 32, 7, 9);
                        CellMerge("GridLines", NewWorkSheet, 32, 32, 7, 9);
                        NewWorkSheet.Cells[33, 7] = dtProjectOrderEntry.Rows[0]["PreDispatchInspection"].ToString();
                        CellMerge("Merge", NewWorkSheet, 33, 34, 7, 9);
                        CellMerge("GridLines", NewWorkSheet, 33, 34, 7, 9);

                        NewWorkSheet.Cells[32, 10] = "Contractual Acceptance at Site:";
                        CellMerge("Merge", NewWorkSheet, 32, 32, 10, 12);
                        CellMerge("GridLines", NewWorkSheet, 32, 32, 10, 12);
                        NewWorkSheet.Cells[33, 10] = dtProjectOrderEntry.Rows[0]["ContractualAcceptance"].ToString();
                        CellMerge("Merge", NewWorkSheet, 33, 34, 10, 12);
                        CellMerge("GridLines", NewWorkSheet, 33, 34, 10, 12);

                        CellMerge("Bold", NewWorkSheet, 32, 32, 2, 12);

                        NewWorkSheet.Cells[35, 2] = "Project Name:";
                        CellMerge("Merge", NewWorkSheet, 35, 35, 2, 6);
                        CellMerge("GridLines", NewWorkSheet, 35, 35, 2, 6);
                        NewWorkSheet.Cells[36, 2] = dtProjectList.Rows[0]["ProjectDescription"].ToString();
                        NewWorkSheet.Cells[36, 2].WrapText = true;
                        CellMerge("Merge", NewWorkSheet, 36, 36, 2, 6);
                        CellMerge("GridLines", NewWorkSheet, 36, 36, 2, 6);

                        NewWorkSheet.Cells[35, 7] = "Warranty:";
                        CellMerge("Merge", NewWorkSheet, 35, 35, 7, 12);
                        CellMerge("GridLines", NewWorkSheet, 35, 35, 7, 12);
                        NewWorkSheet.Cells[36, 7] = dtProjectOrderEntry.Rows[0]["WarrantyPeriod"].ToString() + " Months";
                        NewWorkSheet.Cells[36, 7].WrapText = true;
                        CellMerge("Merge", NewWorkSheet, 36, 36, 7, 12);
                        CellMerge("GridLines", NewWorkSheet, 36, 36, 7, 12);

                        //NewWorkSheet.Cells[35, 7] = "ModelNumber:";
                        //CellMerge("Merge", NewWorkSheet, 35, 35, 7, 12);
                        //CellMerge("GridLines", NewWorkSheet, 35, 35, 7, 12);
                        //NewWorkSheet.Cells[36, 7] = dtProjectOrderEntry.Rows[0]["ModelNumber"].ToString();
                        //CellMerge("Merge", NewWorkSheet, 36, 36, 7, 12);
                        //CellMerge("GridLines", NewWorkSheet, 36, 36, 7, 12);

                        CellMerge("Bold", NewWorkSheet, 35, 35, 2, 12);
                        CellMerge("Bold", NewWorkSheet, 37, 37, 2, 12);

                        NewWorkSheet.Cells[37, 2] = "Sales Effort:";
                        CellMerge("Merge", NewWorkSheet, 37, 37, 2, 3);
                        CellMerge("GridLines", NewWorkSheet, 37, 37, 2, 3);
                        NewWorkSheet.Cells[38, 2] = dtProjectOrderEntry.Rows[0]["SalesEffort"].ToString();
                        CellMerge("Merge", NewWorkSheet, 38, 38, 2, 3);
                        CellMerge("GridLines", NewWorkSheet, 38, 38, 2, 3);

                        NewWorkSheet.Cells[37, 4] = "Estimated Design:";
                        CellMerge("Merge", NewWorkSheet, 37, 37, 4, 5);
                        CellMerge("GridLines", NewWorkSheet, 37, 37, 4, 5);
                        NewWorkSheet.Cells[38, 4] = dtProjectOrderEntry.Rows[0]["EstimatedDesignhours"].ToString();
                        CellMerge("Merge", NewWorkSheet, 38, 38, 4, 5);
                        CellMerge("GridLines", NewWorkSheet, 38, 38, 4, 5);

                        NewWorkSheet.Cells[37, 6] = "Estimated Manufacturing:";
                        CellMerge("Merge", NewWorkSheet, 37, 37, 6, 8);
                        CellMerge("GridLines", NewWorkSheet, 37, 37, 6, 8);
                        NewWorkSheet.Cells[38, 6] = dtProjectOrderEntry.Rows[0]["EstimatedManufacturinghours"].ToString();
                        CellMerge("Merge", NewWorkSheet, 38, 38, 6, 8);
                        CellMerge("GridLines", NewWorkSheet, 38, 38, 6, 8);

                        NewWorkSheet.Cells[37, 9] = "Estimated Installation:";
                        CellMerge("Merge", NewWorkSheet, 37, 37, 9, 12);
                        CellMerge("GridLines", NewWorkSheet, 37, 37, 9, 12);
                        NewWorkSheet.Cells[38, 9] = dtProjectOrderEntry.Rows[0]["EstimatedInstallationhours"].ToString();
                        CellMerge("Merge", NewWorkSheet, 38, 38, 9, 12);
                        CellMerge("GridLines", NewWorkSheet, 38, 38, 9, 12);

                        CellMerge("Bold", NewWorkSheet, 39, 39, 2, 12);
                        iRowIndex = 39;
                        foreach (string str in Text1)
                        {
                            NewWorkSheet.Cells[iRowIndex, 2] = str;
                            CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 2, 12);
                            iRowIndex++;
                        }

                        CellMerge("ThinBorder", NewWorkSheet, 37, 43, 2, 12);
                        CellMerge("ThinBorder", NewWorkSheet, 1, 7, 2, 12);
                        CellMerge("ThinBorder", NewWorkSheet, 8, 8, 2, 12);
                        CellMerge("AlignTop", NewWorkSheet, 11, 12, 2, 12);
                        CellMerge("AlignTop", NewWorkSheet, 16, 19, 2, 12);
                        CellMerge("AlignTop", NewWorkSheet, 22, 23, 2, 12);
                        CellMerge("AlignTop", NewWorkSheet, 25, 29, 2, 12);
                        CellMerge("AlignTop", NewWorkSheet, 33, 34, 2, 12);

                        CellMerge("AlignCenter", NewWorkSheet, 8, 8, 2, 12);
                        NewWorkSheet.Range["B2:I2"].Cells.Font.Size = 24;
                        NewWorkSheet.Range["B2:I2"].Cells.Font.Bold = true;

                        NewWorkSheet.Range["B8:L8"].Cells.Font.Size = 18;
                        NewWorkSheet.Range["B8:L8"].Cells.Font.Bold = true;

                        NewWorkSheet.Range["B16:L19"].Cells.WrapText = true;
                        NewWorkSheet.Range["B22:L23"].Cells.WrapText = true;
                        NewWorkSheet.Range["B25:F29"].Cells.WrapText = true;

                        NewWorkSheet.Range["B16:L19"].Cells.RowHeight = 45;
                        NewWorkSheet.Range["B22:L23"].Cells.RowHeight = 45;

                        CellMerge("ThinBorder", NewWorkSheet, 9, 9, 2, 6);
                        CellMerge("ThinBorder", NewWorkSheet, 31, 31, 10, 12);



                        NewWorkSheet.Columns.AutoFit();
                        NewWorkSheet.Columns[2].ColumnWidth = 13;
                        NewWorkSheet.Columns[3].ColumnWidth = 13;
                        //NewWorkSheet.Columns[4].ColumnWidth = 10;
                        NewWorkSheet.Columns[5].ColumnWidth = 16;
                        NewWorkSheet.Columns[12].ColumnWidth = 13;

                        //NewWorkSheet.get_Range("A9", "R9999").Cells.Font.Size = 13;
                        NewWorkSheet.get_Range("A1", "R9999").Cells.Font.Name = "Calibri";

                        NewWorkSheet.get_Range("A1", "R9999").Cells.RowHeight = 18;
                        NewWorkSheet.get_Range("A1", "L1").Cells.RowHeight = 4;
                        NewWorkSheet.get_Range("A2", "L2").Cells.RowHeight = 40;
                        NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                        NewWorkSheet.PageSetup.PrintNotes = true;
                        NewWorkSheet.PageSetup.Zoom = 100;
                        NewWorkSheet.PageSetup.Zoom = false;
                        NewWorkSheet.PageSetup.FitToPagesTall = 1;
                        NewWorkSheet.PageSetup.FitToPagesWide = 1;
                        NewWorkSheet.PageSetup.LeftMargin = 0;
                        NewWorkSheet.PageSetup.RightMargin = 0;
                        NewWorkSheet.PageSetup.TopMargin = 0.75;
                        NewWorkSheet.PageSetup.BottomMargin = 0.75;
                        NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                        NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;


                        // string _stLOGO = "C:\\Databasepath\\Bisslogo.jpg";--bhavya commented
                        //EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 10];

                        //Image oImage = Image.FromFile(Global.sLogo);
                        //System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                        //NewWorkSheet.Paste(oRange, Global.sLogo);
                        //------------------

                        if (cmbProductionCompany.SelectedIndex == 0)
                        {
                            if (File.Exists(Global.sLogo))
                            {
                                EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 10];
                                Image oImage = Image.FromFile(Global.sLogo);
                                System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                                NewWorkSheet.Paste(oRange, Global.sLogo);
                            }
                        }
                        else if (cmbProductionCompany.SelectedIndex == 1)
                        {
                            if (File.Exists(Global.sInsronLogo))
                            {
                                EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 10];
                                Image oImage = Image.FromFile(Global.sInsronLogo);
                                System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                                NewWorkSheet.Paste(oRange, Global.sInsronLogo);
                            }
                        }






                        EXCEL.Range oRange1 = (EXCEL.Range)NewWorkSheet.Cells[2, 2];

                        Image oImage1 = Image.FromFile(Global.sITWLogo);
                        System.Windows.Forms.Clipboard.SetDataObject(oImage1, true);
                        NewWorkSheet.Paste(oRange1, Global.sITWLogo);

                        NewWorkBook.Save();
                        ExcelApp.Visible = true;
                        System.Threading.Thread.Sleep(1000);

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                        //foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                        //{
                        //    GetProcess.Kill();
                        //}
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("PurchaseOrder_btnReport_Click  " + ex.Message);
            }
        }
        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlMedium, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignTop":
                    {
                        CELLS.VerticalAlignment = EXCEL.XlVAlign.xlVAlignTop;
                        break;
                    }
                case "ThinBorder":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        //   CELLS.Borders.Color.SetColor(Color.Red);  
                        break;
                    }

                case "GridLines":
                    {
                        CELLS.Borders.Color = System.Drawing.Color.Black;
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlThin, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignCenter":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                        break;
                    }
                case "AlignRight":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                        break;
                    }
                case "AlignLeft":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignLeft;
                        break;
                    }
                case "Bold":
                    {
                        CELLS.Font.Bold = true;
                        break;
                    }
                default:
                    {
                        break;
                    }
            }
        }

        #endregion

        private void btnExcel_Click(object sender, EventArgs e)
        {
            if (cmbProjectType.Text == "Customer (CUS)" || cmbProjectType.Text == "Stock (STO)" || cmbProjectType.Text == "Accessories (OTC)")
            {
                fnExcel();
                if (cmbOfferNumber.SelectedIndex >= 0 && cmbRevisionNumber.SelectedIndex >= 0)
                {
                    fnScopeofSupply();
                }
            }
            else if (cmbProjectType.Text == "TestingLab (TEL)")
            {
                if (cmbOfferNumber.SelectedIndex >= 0)
                {
                    fnPDgeneration();
                }
            }
        }

        private void fnPDgeneration()
        {
            DataTable dtScopeofSuplly = new DataTable();
            dtScopeofSuplly = DAL.fnDataScopeofSupply(2, cmbOfferNumber.Text, "").Tables[0];
            int iRowIndex = 1;
            string ExcelFolderPath;
            string FileFullPath;
            string FileFul;
            EXCEL.Workbook NewWorkBook;
            EXCEL.Worksheet NewWorkSheet;
            EXCEL.Application ExcelApp;
            EXCEL.Range CELLS, cell1, cell2;
            object misValue;
            if (dtScopeofSuplly.Rows.Count > 0)
            {
                ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\Project Description\\";
                FileFullPath = ExcelFolderPath + cmbModelNumber.Text + " - Project Description " + ".xls";
                FileFul = ExcelFolderPath + cmbModelNumber.Text + " - Project Description " + ".pdf";
                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);
                ExcelApp = new EXCEL.Application();
                misValue = System.Reflection.Missing.Value;
                try
                {
                    if (ExcelApp == null)
                        MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                    NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                    NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                    if (NewWorkSheet == null)
                        MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                    else
                        NewWorkSheet.Name = "ProjectDescription";
                    // Select the Excel cells, in the range c1 to c7 in the worksheet for cell access check.
                    EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                    if (RANGE == null)
                        MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                    NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlWorkbookNormal, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                    CELLS = NewWorkSheet.Cells;
                    string sCode = "";
                    if (!string.IsNullOrEmpty(cmbModelNumber.Text))
                    {
                        sCode = cmbModelNumber.Text.Substring(2, 3);
                    }
                    iRowIndex++;
                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "Customer Code : " + sCode;
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);
                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "SR Number: " + cmbModelNumber.Text + "";
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);

                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "Project Code : " + txtPMProjectCode.Text + "";
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);

                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "Test Type : " + txtPMProjectDescription.Text + "";
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);


                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "PO No & Quotation No : " + txtPONo.Text + " & " + cmbOfferNumber.Text + "";
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);

                    iRowIndex++;
                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "Test details:";
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);
                    CellMerge("GridLines", NewWorkSheet, 11, (11 + dtScopeofSuplly.Rows.Count), 1, 3);



                    if (dtScopeofSuplly.Rows.Count > 0)
                    {
                        object[,] rawData = new object[dtScopeofSuplly.Rows.Count + 1, dtScopeofSuplly.Columns.Count];
                        for (int col = 0; col < dtScopeofSuplly.Columns.Count; col++)
                        {
                            rawData[0, col] = dtScopeofSuplly.Columns[col].ColumnName;
                        }
                        for (int row = 0; row < dtScopeofSuplly.Rows.Count; row++)
                        {
                            for (int col = 0; col < dtScopeofSuplly.Columns.Count; col++)
                            {
                                rawData[row + 1, col] = dtScopeofSuplly.Rows[row].ItemArray[col];
                            }
                        }
                        string excelRange = string.Empty;
                        string finalColLetter = string.Empty;
                        string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        int colCharsetLen = colCharset.Length;

                        if (dtScopeofSuplly.Columns.Count > colCharsetLen)
                        {
                            finalColLetter = colCharset.Substring((dtScopeofSuplly.Columns.Count - 1) / colCharsetLen - 1, 1);
                        }
                        finalColLetter += colCharset.Substring((dtScopeofSuplly.Columns.Count - 1) % colCharsetLen, 1);
                        excelRange = string.Format("A11:{0}{1}", finalColLetter, (dtScopeofSuplly.Rows.Count + 11));
                        NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                    }

                    CellMerge("AlignTop", NewWorkSheet, 12, (dtScopeofSuplly.Rows.Count + 12), 1, 3);
                    CellMerge("AlignLeft", NewWorkSheet, 12, (dtScopeofSuplly.Rows.Count + 12), 2, 2);
                    CellMerge("AlignCenter", NewWorkSheet, 11, 11, 1, 3);
                    CellMerge("AlignCenter", NewWorkSheet, 12, (dtScopeofSuplly.Rows.Count + 12), 1, 1);
                    CellMerge("AlignCenter", NewWorkSheet, 12, (dtScopeofSuplly.Rows.Count + 12), 3, 3);




                    iRowIndex = dtScopeofSuplly.Rows.Count + 12;

                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "List of additional documentation provided for reference : As per SOW";
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);

                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "Broad time frame : " + txtCustomerRequirement.Text;
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);

                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "Specimen Disposal details (mandatory requirement) : Return to customer";
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);


                    iRowIndex++;
                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "Prepared By : " + login.GetUserDetails[2] + "";
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);
                    CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);
                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);

                    iRowIndex++;
                    NewWorkSheet.Cells[iRowIndex, 1] = "Date : " + dtpPMCreatedDate.Text + "";
                    CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);
                    CellMerge("AlignRight", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);
                    CellMerge("Bold", NewWorkSheet, iRowIndex, iRowIndex, 1, 3);

                    NewWorkSheet.Range["A9:C11"].Cells.Font.Bold = true;
                    NewWorkSheet.Range["A9:C11"].Cells.Font.Size = 12;
                    NewWorkSheet.Rows.AutoFit();
                    //NewWorkSheet.Columns.AutoFit();
                    NewWorkSheet.Columns[1].ColumnWidth = 6;
                    NewWorkSheet.Columns[2].ColumnWidth = 68;
                    NewWorkSheet.Columns[2].WrapText = true;
                    NewWorkSheet.Columns[3].ColumnWidth = 9;





                    NewWorkSheet.PageSetup.PrintArea = "A1:C" + (iRowIndex) + "";
                    //    NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                    NewWorkSheet.PageSetup.PrintNotes = true;
                    NewWorkSheet.PageSetup.CenterHorizontally = true;
                    NewWorkSheet.PageSetup.Zoom = 100;
                    //NewWorkSheet.PageSetup.LeftMargin = 0.3;
                    //NewWorkSheet.PageSetup.RightMargin = 0.3;
                    //NewWorkSheet.PageSetup.TopMargin = 1.8;
                    //NewWorkSheet.PageSetup.BottomMargin = 0.3;
                    NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                    NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;
                    // NewWorkSheet.PageSetup.AlignMarginsHeaderFooter = false;
                    // string filename = ("C:\\Databasepath\\Bisslogo.jpg");



                    NewWorkSheet.PageSetup.LeftHeaderPicture.Filename = "C:\\Databasepath\\BissLogoTP.jpg";
                    NewWorkSheet.PageSetup.LeftHeader = "&G";
                    NewWorkSheet.PageSetup.CenterHeader = "Project Description";
                    NewWorkSheet.PageSetup.RightHeader = "BISS/F/7.5/13";

                    NewWorkSheet.PageSetup.RightFooter = "Page &P of &N";
                    NewWorkSheet.PageSetup.LeftFooter = "Issue No: 04";
                    //string _stLOGO = ("C:\\Databasepath\\Bisslogo.jpg");
                    //EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 7];

                    //Image oImage = Image.FromFile(_stLOGO);
                    //System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    //NewWorkSheet.Paste(oRange, _stLOGO);

                    NewWorkBook.Save();
                    NewWorkBook.ExportAsFixedFormat(EXCEL.XlFixedFormatType.xlTypePDF, FileFul, EXCEL.XlFixedFormatQuality.xlQualityStandard, true);

                    VendorEMail("Manoj_H@instron.com", FileFul);
                    ExcelApp.Visible = true;
                    System.Threading.Thread.Sleep(1000);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    //foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                    //{
                    //    GetProcess.Kill();
                    //}
                }
            }
            else
            {
                MessageBox.Show("No items to save", "Error", 0, MessageBoxIcon.Question);
            }
        }


        private void VendorEMail(string sUser, string attachmentFilename)
        {
            try
            {
                //  bMail = false;
                lstusers.Items.Clear();



                Outlook.Application oApp = new Outlook.Application();
                Outlook.MailItem oMsg = (Outlook.MailItem)oApp.CreateItem(Outlook.OlItemType.olMailItem);


                oMsg.Subject = "" + cmbCustomer.Text + " - " + txtPMProjectDescription.Text + " - " + cmbModelNumber.Text + " -" + txtPMProjectCode.Text;
                oMsg.HTMLBody = "Dear Operations Manager,<br /> Greetings! <br /><br /> I have attached the project documents for " + cmbCustomer.Text + ", kindly find it., <br /><br /> ";

                oMsg.HTMLBody += ReadSignature();
                // Add a recipient.
                Outlook.Recipients oRecips = (Outlook.Recipients)oMsg.Recipients;
                oRecips.Add(sUser);
                oRecips.ResolveAll();

                if (attachmentFilename != null)
                    oMsg.Attachments.Add(attachmentFilename);


                //if (lstusers.Items.Count > 0)
                //{
                //    Outlook.Recipient oRecip;
                //    List<string> sCCRecipsList = new List<string>();
                //    foreach (string tempTO in lstusers.Items)
                //    {
                //        if (tempTO != null)
                //            sCCRecipsList.Add(tempTO);
                //    }
                //    foreach (string t in sCCRecipsList)
                //    {
                //        oRecip = (Outlook.Recipient)oRecips.Add(t);
                //        oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                //        oRecip.Resolve();
                //    }
                //}
                //    Outlook.Recipient oRecip;

                //oRecip = (Outlook.Recipient)oRecips.Add(sUser);
                //oRecip.Type = (int)Outlook.OlMailRecipientType.olCC;
                //oRecip.Resolve();


                // Send.
                oMsg.Display();

                // // var msg = Item as Outlook.MailItem;
                //   string newPath = @"\\D:\shivand RT\\";
                //// string newPath = @"\\192.168.1.81\ERP_Project_Document\Vendor Email\\" + "" + cmbPONO.Text + " to " + cmbVendorName.Text + ""; 
                // oMsg.SaveAs(newPath, Outlook.OlSaveAsType.olMSG);

                // oMsg.Send();
                //   bMail = true;
                // Clean up.
                oRecips = null;
                oMsg = null;
                oApp = null;
                //oRecip = null;
                //}
                //}

            }
            catch (Exception ex)
            {
                MessageBox.Show("Catch '" + ex + "' ", "Error", 0, MessageBoxIcon.Information);
            }
        }

        //\\192.168.1.81\ERP_Project_Document\Vendor Email
        private string ReadSignature()
        {
            string appDataDir = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\Microsoft\\Signatures";
            string signature = string.Empty;
            DirectoryInfo diInfo = new DirectoryInfo(appDataDir);

            if (diInfo.Exists)
            {
                FileInfo[] fiSignature = diInfo.GetFiles("*.htm");

                if (fiSignature.Length > 0)
                {
                    StreamReader sr = new StreamReader(fiSignature[0].FullName, Encoding.Default);
                    signature = sr.ReadToEnd();

                    if (!string.IsNullOrEmpty(signature))
                    {
                        string fileName = fiSignature[0].Name.Replace(fiSignature[0].Extension, string.Empty);
                        signature = signature.Replace(fileName + "_files/", appDataDir + "/" + fileName + "_files/");
                    }
                }
            }
            return signature;
        }


        private void fnScopeofSupply()
        {
            DataTable dtScopeofSuplly = new DataTable();
            dtScopeofSuplly = DAL.fnDataScopeofSupply(1, cmbOfferNumber.Text, cmbRevisionNumber.Text).Tables[0];
            int iRowIndex = 1;
            string ExcelFolderPath;
            string FileFullPath;
            EXCEL.Workbook NewWorkBook;
            EXCEL.Worksheet NewWorkSheet;
            EXCEL.Application ExcelApp;
            EXCEL.Range CELLS, cell1, cell2;
            object misValue;
            if (dtScopeofSuplly.Rows.Count > 0)
            {
                ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\Order Entry\\";
                FileFullPath = ExcelFolderPath + txtPMProjectCode.Text + " -Scope of Supply" + "-" + DateTime.Now.ToString("dd/MM/yyyy hh/mm/ss") + ".xls";
                if (!Directory.Exists(ExcelFolderPath))
                    Directory.CreateDirectory(ExcelFolderPath);
                ExcelApp = new EXCEL.Application();
                misValue = System.Reflection.Missing.Value;
                try
                {
                    if (ExcelApp == null)
                        MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                    NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                    NewWorkSheet = NewWorkBook.Worksheets.get_Item(1);
                    if (NewWorkSheet == null)
                        MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                    else
                        NewWorkSheet.Name = "Scope of Supply";
                    // Select the Excel cells, in the range c1 to c7 in the worksheet for cell access check.
                    EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                    if (RANGE == null)
                        MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                    NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlWorkbookNormal, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                    CELLS = NewWorkSheet.Cells;



                    if (dtScopeofSuplly.Rows.Count > 0)
                    {
                        object[,] rawData = new object[dtScopeofSuplly.Rows.Count + 1, dtScopeofSuplly.Columns.Count];
                        for (int col = 0; col < dtScopeofSuplly.Columns.Count; col++)
                        {
                            rawData[0, col] = dtScopeofSuplly.Columns[col].ColumnName;
                        }
                        for (int row = 0; row < dtScopeofSuplly.Rows.Count; row++)
                        {
                            for (int col = 0; col < dtScopeofSuplly.Columns.Count; col++)
                            {
                                rawData[row + 1, col] = dtScopeofSuplly.Rows[row].ItemArray[col];
                            }
                        }
                        string excelRange = string.Empty;
                        string finalColLetter = string.Empty;
                        string colCharset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
                        int colCharsetLen = colCharset.Length;

                        if (dtScopeofSuplly.Columns.Count > colCharsetLen)
                        {
                            finalColLetter = colCharset.Substring(
                                (dtScopeofSuplly.Columns.Count - 1) / colCharsetLen - 1, 1);
                        }

                        finalColLetter += colCharset.Substring((dtScopeofSuplly.Columns.Count - 1) % colCharsetLen, 1);
                        excelRange = string.Format("A1:{0}{1}", finalColLetter, dtScopeofSuplly.Rows.Count + 1);


                        NewWorkSheet.get_Range(excelRange, Type.Missing).Value2 = rawData;
                    }


                    NewWorkSheet.Range["A1:H1"].Cells.Font.Bold = true;
                    NewWorkSheet.Range["A1:H1"].Cells.Font.Size = 12;




                    NewWorkSheet.Rows.AutoFit();

                    NewWorkSheet.Columns.AutoFit();
                    NewWorkSheet.Columns[1].ColumnWidth = 20;
                    NewWorkSheet.Columns[3].ColumnWidth = 70;
                    // NewWorkSheet.Columns[5].ColumnWidth = 50;
                    CellMerge("AlignTop", NewWorkSheet, 1, (dtScopeofSuplly.Rows.Count + 1), 1, 7);
                    // NewWorkSheet.Rows.RowHeight = "18";


                    NewWorkSheet.PageSetup.PrintArea = "A1:H" + (dtScopeofSuplly.Rows.Count + 1) + "";
                    NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                    NewWorkSheet.PageSetup.PrintNotes = true;
                    NewWorkSheet.PageSetup.Zoom = 100;
                    NewWorkSheet.PageSetup.FitToPagesTall = 1;
                    NewWorkSheet.PageSetup.FitToPagesWide = 1;
                    NewWorkSheet.PageSetup.LeftMargin = 0;
                    NewWorkSheet.PageSetup.RightMargin = 0;
                    NewWorkSheet.PageSetup.TopMargin = 0.75;
                    NewWorkSheet.PageSetup.BottomMargin = 0.75;
                    NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                    NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                    //string _stLOGO = ("C:\\Databasepath\\Bisslogo.jpg");
                    //EXCEL.Range oRange = (EXCEL.Range)NewWorkSheet.Cells[2, 7];

                    //Image oImage = Image.FromFile(_stLOGO);
                    //System.Windows.Forms.Clipboard.SetDataObject(oImage, true);
                    //NewWorkSheet.Paste(oRange, _stLOGO);

                    NewWorkBook.Save();


                    ExcelApp.Visible = true;

                    System.Threading.Thread.Sleep(1000);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    //foreach (Process GetProcess in Process.GetProcessesByName("Excel"))
                    //{
                    //    GetProcess.Kill();
                    //}
                }
            }
            else
            {
                MessageBox.Show("No items to save", "Error", 0, MessageBoxIcon.Question);
            }
        }
        private void fnExcel()
        {
            dtProjectOrderEntry = DAL.fnProjectOrderEntry(txtPMProjectCode.Text, 1).Tables[0];
            dtProjectList = DAL.fnProjectList(txtPMProjectCode.Text).Tables[0];
            fnPrintOrderEntry();
        }

        private void btnNext1_Click(object sender, EventArgs e)
        {
            if (cmbProjectType.Text == "Fixed Asset (CIP)")
            {
                tabControl1.SelectedIndex = 2;
            }

            //shreeshail is added below code
            string inputDate = txtCustomerRequirement.Text;
            DateTime today = DateTime.Today;

            // Attempt to parse the entered date
            if ((cmbProjectType.Text == "BATCH ORDER FOR PROJECTS (BOP)") || (cmbProjectType.Text == "Customer (CUS)") || (cmbProjectType.Text == "Stock (STO)") || (cmbProjectType.Text == "Accessories (OTC)"))
            {
                if (!DateTime.TryParseExact(inputDate, "dd-MM-yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime parsedDate) || parsedDate.Date < today)
                {
                    MessageBox.Show("Please Enter Customer Requirement date or a future date.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    tabControl1.SelectedIndex = 1;
                    txtCustomerRequirement.Focus();
                }
                else if(parsedDate.Date >= today)
                {
                    tabControl1.SelectedIndex = 2;
                }
                
                
                //shreeshail is added code above code
            }



            else if (cmbProjectType.Text == "Customer (CUS)")
            {
                if (cmbAgent.SelectedIndex >= 0 && bRequiredDate && cmbSecurityDeposit.SelectedIndex >= 0 && cmbBankGuarantee.SelectedIndex >= 0
            && cmbPerformanceBankGuarantee.SelectedIndex >= 0)
                {
                    tabControl1.SelectedIndex = 2;

                    
                }

               else
                {
                   
                    if (cmbAgent.SelectedIndex < 0)
                    {
                        MessageBox.Show("Select agent type", "Error", 0, MessageBoxIcon.Error);
                        cmbAgent.DroppedDown = true;
                    }

                    else if (cmbSecurityDeposit.SelectedIndex < 0)
                    {
                        MessageBox.Show("Select security deposit", "Error", 0, MessageBoxIcon.Error);
                        cmbSecurityDeposit.DroppedDown = true;
                    }
                    else if (cmbBankGuarantee.SelectedIndex < 0)
                    {
                        MessageBox.Show("Select bank guarantee", "Error", 0, MessageBoxIcon.Error);
                        cmbBankGuarantee.DroppedDown = true;
                    }
                    else if (cmbPerformanceBankGuarantee.SelectedIndex < 0)
                    {
                        MessageBox.Show("Select performance bank guarantee", "Error", 0, MessageBoxIcon.Error);
                        cmbPerformanceBankGuarantee.DroppedDown = true;

                    }

                                     

                }
            }
            else
            {
                tabControl1.SelectedIndex = 2;
            }
        }

        private void btnBack1_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 2;
            //btnSave.Enabled = true;
        }
        DataTable dtAllRevisionNumber = new DataTable();
        private void cmbOfferNumber_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbProjectType.SelectedIndex)
            {
                case 0:
                case 4:
                case 12:
                    dtAllRevisionNumber = DAL.fnQuotationNumberLoadData(5, cmbOfferNumber.Text, "").Tables[0];
                    cmbRevisionNumber.Items.Clear();
                    cmbRevisionNumber.SelectedIndex = -1;
                    if (dtAllRevisionNumber.Rows.Count > 0)
                    {
                        foreach (DataRow DR in dtAllRevisionNumber.Rows)
                        {
                            if (!cmbRevisionNumber.Items.Contains(DR["RevisionNumber"].ToString()))
                                cmbRevisionNumber.Items.Add(DR["RevisionNumber"].ToString());
                        }
                    }
                    break;

                case 13:

                    dtQuoteEnquiryDetails = DAL.fnTestQuoteNumber(2, cmbOfferNumber.Text).Tables[0];
                    if (dtQuoteEnquiryDetails.Rows.Count > 0)
                    {
                        cmbCustomer.SelectedIndex = -1;
                        DR = dtCustomerList.Select("CustomerName = '" + dtQuoteEnquiryDetails.Rows[0]["Customer"].ToString() + "'");
                        if (DR.Length > 0)
                        {
                            cmbCustomer.SelectedItem = dtQuoteEnquiryDetails.Rows[0]["Customer"].ToString();
                        }
                        txtBilltoCustomer.Text = dtQuoteEnquiryDetails.Rows[0]["CustomerAddress"].ToString();
                        txtShiptoCustomer.Text = dtQuoteEnquiryDetails.Rows[0]["CustomerAddress"].ToString();

                        CmbStandardCustom.SelectedItem = dtQuoteEnquiryDetails.Rows[0]["StandardCustom"].ToString();
                        txtContactPerson.Text = dtQuoteEnquiryDetails.Rows[0]["ContactPerson"].ToString();
                        txtDepartment.Text = dtQuoteEnquiryDetails.Rows[0]["Department"].ToString();
                        txtContactAddress.Text = dtQuoteEnquiryDetails.Rows[0]["CustomerAddress"].ToString();
                        txtContactEmail.Text = dtQuoteEnquiryDetails.Rows[0]["EmailID"].ToString();
                        txtMoblieNo.Text = dtQuoteEnquiryDetails.Rows[0]["PhoneNumber"].ToString();
                        txtPMProjectDescription.Text = dtQuoteEnquiryDetails.Rows[0]["OfferName"].ToString();
                        if (dtQuoteEnquiryDetails.Rows[0]["Region"].ToString() == "East" || dtQuoteEnquiryDetails.Rows[0]["Region"].ToString() == "North"
                             || dtQuoteEnquiryDetails.Rows[0]["Region"].ToString() == "South" || dtQuoteEnquiryDetails.Rows[0]["Region"].ToString() == "West")
                        {
                            cmbEndUserCountry.Text = "India";
                        }
                        else
                        {
                            cmbEndUserCountry.Text = dtQuoteEnquiryDetails.Rows[0]["Region"].ToString();
                        }
                    }

                    break;
            }
        }
        DataTable dtQuoteEnquiryDetails = new DataTable();
        string[] sCustomization;
        private void cmbRevisionNumber_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtQuoteEnquiryDetails = DAL.fnQuotationNumberLoadData(1, cmbOfferNumber.Text, cmbRevisionNumber.Text).Tables[0];
            dtQuoteItems = DAL.fnQuotationNumberLoadData(2, cmbOfferNumber.Text, cmbRevisionNumber.Text).Tables[0];
            if (dtQuoteEnquiryDetails.Rows.Count > 0)
            {
                cmbCustomer.SelectedIndex = -1;
                cmbCustomer.SelectedItem = dtQuoteEnquiryDetails.Rows[0]["CustomerName"].ToString();
                txtWarrantyClose.Text = dtQuoteEnquiryDetails.Rows[0]["QuoteWarranty"].ToString();
               // cmbProject8020.SelectedItem = dtQuoteEnquiryDetails.Rows[0]["Project8020"].ToString();

                sCustomization = dtQuoteEnquiryDetails.Rows[0]["LevelofCustomization"].ToString().Split(')');
                if (!string.IsNullOrEmpty(sCustomization[0]))
                {
                    cmbCustomizationlevel.SelectedItem = sCustomization[0];
                }
                cmbModelNumber.Text = dtQuoteEnquiryDetails.Rows[0]["ModelNumber"].ToString();
                txtPMProjectDescription.Text = dtQuoteEnquiryDetails.Rows[0]["QuoteName"].ToString();
                cmbPMProductType.Text = dtQuoteEnquiryDetails.Rows[0]["QuoteFor"].ToString();
                cmbsystemsubtype.Text = dtQuoteEnquiryDetails.Rows[0]["QuoteModel"].ToString();
                txtBilltoCustomer.Text = dtQuoteEnquiryDetails.Rows[0]["Adress"].ToString();
                txtShiptoCustomer.Text = dtQuoteEnquiryDetails.Rows[0]["Adress"].ToString();
                if (dtQuoteEnquiryDetails.Rows[0]["Region"].ToString() == "East" || dtQuoteEnquiryDetails.Rows[0]["Region"].ToString() == "North"
                    || dtQuoteEnquiryDetails.Rows[0]["Region"].ToString() == "South" || dtQuoteEnquiryDetails.Rows[0]["Region"].ToString() == "West")
                {
                    cmbEndUserCountry.Text = "India";
                }
                else
                {
                    cmbEndUserCountry.Text = dtQuoteEnquiryDetails.Rows[0]["Region"].ToString();
                }
                DataTable dtStandardCustom = new DataTable();
                dtStandardCustom = DAL.fnQuotationNumberLoadData(51, dtQuoteEnquiryDetails.Rows[0]["EnquiryNumber"].ToString(), cmbRevisionNumber.Text).Tables[0];
                if (dtStandardCustom.Rows.Count > 0)
                {
                    CmbStandardCustom.SelectedItem = dtStandardCustom.Rows[0]["StandardCustom"].ToString();
                }
                txtContactPerson.Text = dtQuoteEnquiryDetails.Rows[0]["ContactPerson"].ToString();
                txtDepartment.Text = dtQuoteEnquiryDetails.Rows[0]["Department"].ToString();
                txtContactAddress.Text = dtQuoteEnquiryDetails.Rows[0]["Adress"].ToString();
                txtContactEmail.Text = dtQuoteEnquiryDetails.Rows[0]["EmailID"].ToString();
                txtMoblieNo.Text = dtQuoteEnquiryDetails.Rows[0]["ContactNumber"].ToString();


                ////shreeshail is added bellow code
                txtOrderValueinUSD.Enabled = true;
                txtInstallationValueinUSD.Enabled = true;
                txtOrderValueinINR.Enabled = true;
                txtInstallationValueinINR.Enabled = true;

                //shreeshail is added above code
                /*
                if (dtQuoteEnquiryDetails.Rows[0]["Currency"].ToString() == "USD")
                {
                    txtOrderValueinINR.Enabled = true;
                    txtInstallationValueinINR.Enabled = true;

                   
                }
                if (dtQuoteEnquiryDetails.Rows[0]["Currency"].ToString() == "INR")
                {
                    txtOrderValueinUSD.Enabled = true;
                    txtInstallationValueinUSD.Enabled = true;

                    
                }
                */
                if (dtQuoteItems.Rows.Count > 0)
                {
                    fnJackUpCalculation();
                }

            }
            else
            {
                cmbCustomer.SelectedIndex = -1;
                txtWarrantyClose.ResetText();
                cmbProject8020.SelectedIndex = -1;
                cmbCustomizationlevel.SelectedIndex = -1;
            }
        }

        private void cmbContractualAcceptance_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbContractualAcceptance.SelectedIndex == 0)
            {
                lblremarks.Visible = true;
                txtRemarks.Visible = true;
            }
            else
            {
                lblremarks.Visible = false;
                txtRemarks.Visible = false;
            }
        }

        private void chkLDClause_CheckedChanged(object sender, EventArgs e)
        {
            if (chkLDClause.Checked)
            {
                pnLDClause.Visible = true;
            }
            else
            {
                pnLDClause.Visible = false;
            }
        }

        private void chkLCClause_CheckedChanged(object sender, EventArgs e)
        {
            if (chkLCClause.Checked)
            {
                pnLCClause.Visible = true;
            }
            else
            {
                pnLCClause.Visible = false;
            }

        }
        bool bRequiredDate = false;
        private void txtCustomerRequirement_ValueChanged(object sender, EventArgs e)
        {
            bRequiredDate = true;
        }

        private void txtAgentCommission_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber(sender, e);
        }

        private void txtProjectMargin_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber1(sender, e);
        }

        private void txtDiscount_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber(sender, e);
        }

        private void txtOrderValueinINR_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber1(sender, e);
        }

        private void fnOnlynumber(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            // only allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void fnOnlynumber1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtOrderValueinUSD_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber(sender, e);
        }

        private void txtInstallationValueinINR_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber(sender, e);
        }

        private void txtInstallationValueinUSD_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber(sender, e);
        }

        private void txtWarrantyClose_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber1(sender, e);
        }

        private void Validate_Text(object sender, CancelEventArgs e)
        {
            TextBox tb = sender as TextBox;
            if (tb != null)
            {
                int i;
                if (int.TryParse(tb.Text, out i))
                {
                    if (i >= 0 && i <= 366)
                        return;
                }
            }
            MessageBox.Show("invalid input");
            e.Cancel = true;
        }

        private void txtWarrantyClose_TextChanged(object sender, EventArgs e)
        {
            var textbox = sender as TextBox;
            int value;
            if (int.TryParse(textbox.Text, out value))
            {
                if (value > 60)
                    textbox.Text = "0";
                else if (value < 0)
                    textbox.Text = "0";
            }
        }

        private void txtQuotationEffort_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber(sender, e);
        }

        private void txtSaleseffort_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber(sender, e);
        }

        private void txtEstimatedDesign_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber(sender, e);
        }

        private void txtEstimatedManufacturing_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber(sender, e);
        }

        private void txtEstimatedInsatllation_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber(sender, e);
        }

        private void cmbProjectCode_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtCapexAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber1(sender, e);
        }

        private void txtOverHead_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber1(sender, e);
        }

        private void cmbProjectType_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbOfferNumber.Text = "";
            cmbOfferNumber.Items.Clear();
            cmbOfferNumber.SelectedIndex = -1;
            panelCapex.Visible = false;
            pnCustomerlinkProject.Visible = false;
            lblWarrantyStartsfrom.Text = "Warranty Starts from *:";
            lblOrdervalidityinmonths.Text = "Warranty Period (In Months) *:";
            label15.Text = "Model Number :";
            cmbWarrantyStartsFrom.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbWarrantyStartsFrom.Text = "";
            cmbWarrantyStartsFrom.Items.Clear();
            cmbWarrantyStartsFrom.Items.Add("Starts from Invoice Date");
            cmbWarrantyStartsFrom.Items.Add("Starts from Installation Date");
            cmbWarrantyStartsFrom.Items.Add("Warranty NA");
            switch (cmbProjectType.SelectedIndex)
            {
                case 13:
                    label15.Text = "SR Number :";
                    dtQuotationNumber = DAL.fnTestQuoteNumber(1, null).Tables[0];
                    foreach (DataRow DR in dtQuotationNumber.Rows)
                    {
                        if (!cmbOfferNumber.Items.Contains(DR["QuotationNumber"].ToString()))
                            cmbOfferNumber.Items.Add(DR["QuotationNumber"].ToString());
                    }
                    cmbPMProductType.SelectedItem = "Others";
                    cmbsystemsubtype.SelectedItem = "Others";
                    lblWarrantyStartsfrom.Text = "Order valid from *:";
                    lblOrdervalidityinmonths.Text = "Order validity in months *:";
                    cmbWarrantyStartsFrom.Text = "";
                    cmbWarrantyStartsFrom.Items.Clear();

                    cmbWarrantyStartsFrom.DropDownStyle = ComboBoxStyle.DropDown;
                    break;

                case 1:
                    lblWarrantyStartsfrom.Text = "Order valid from *:";
                    lblOrdervalidityinmonths.Text = "Order validity in months *:";
                    cmbWarrantyStartsFrom.Text = "";
                    cmbWarrantyStartsFrom.Items.Clear();
                    cmbWarrantyStartsFrom.DropDownStyle = ComboBoxStyle.DropDown;
                    break;
                case 4:
                case 12:
                case 0:
                    dtQuotationNumber = DAL.fnQuotationNumberLoadData(15, "", "").Tables[0];
                    foreach (DataRow DR in dtQuotationNumber.Rows)
                    {
                        if (!cmbOfferNumber.Items.Contains(DR["QuotationNumber"].ToString()))
                            cmbOfferNumber.Items.Add(DR["QuotationNumber"].ToString());
                    }
                    pnCustomerlinkProject.Visible = true;
                    break;

                //case 0:
                //case 1:
                //case 4:
                //case 6:
                //case 7:
                //case 8:
                //case 9:
                //case 10:
                //case 11:
                //    panelCapex.Visible = false;
                //    break;

                case 6:
                    panelCapex.Visible = true;
                    break;
            }


        }

        private void cmbsystemsubtype_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbProjectDocument_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbProjectDocument.SelectedItem.ToString() == "Project Documents")
            {
                cmbDocType.Items.Clear();
                cmbDocType.Items.Add("Purchase order without price");
                cmbDocType.Items.Add("Scope of supply");
                cmbDocType.Items.Add("Technical Specifications/Compliance Statement");
                cmbDocType.Items.Add("Actuator Performance Curve");
                cmbDocType.Items.Add("MOM with customer");
                cmbDocType.Items.Add("Concept Drawing");
                cmbDocType.Items.Add("MOCT MOM");
                cmbDocType.Items.Add("Activity Chart");
                cmbDocType.Items.Add("System Layout");
                cmbDocType.Items.Add("Site requirement");
                cmbDocType.Items.Add("DAP");
                cmbDocType.Items.Add("System Manual");
                cmbDocType.Items.Add("PDI/acceptance plan ");
                cmbDocType.Items.Add("Acceptance plan at site");
                cmbDocType.Items.Add("Integration Check List");
                cmbDocType.Items.Add("Validation Report/Test Reports");
                cmbDocType.Items.Add("Machine Passport");
                cmbDocType.Items.Add("Packing list");
                cmbDocType.Items.Add("Dispatch/Delivery Proof");
                cmbDocType.Items.Add("Installation Report/certificate");
            }
            else
            {
                cmbDocType.Items.Clear();
                cmbDocType.Items.Add("Purchase order with price");
                cmbDocType.Items.Add("Bank Guarantee format");
                cmbDocType.Items.Add("Performance Bank Guarantee format");
                cmbDocType.Items.Add("Security Deposit format");
                cmbDocType.Items.Add("LC");
                cmbDocType.Items.Add("Performance Invoice");
                cmbDocType.Items.Add("Invoice");
                cmbDocType.Items.Add("Warranty Certificate");
                cmbDocType.Items.Add("Guarantee Certificate");
                cmbDocType.Items.Add("Country of origin certificate");
                cmbDocType.Items.Add("Payment Receipt");
            }
        }
        private void cmbDocType_TextChanged(object sender, EventArgs e)
        {

            //cmbProjectDocument.Visible = true;
            if (cmbProjectDocument.SelectedIndex >= 0 && !bSearch && (fnGetProjectCode == null || fnGetProjectCode == ""))
            {
                openFileDialog1.InitialDirectory = @"c:\";
                openFileDialog1.Title = "Select File";
                openFileDialog1.ShowDialog();
            }
        }
        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            if (!string.IsNullOrEmpty(txtPMProjectCode.Text))
            {
                if (cmbProjectType.Text == "Customer (CUS)")
                {
                    fnCreateProjectInformation();
                }
            }
        }

        private void llbProjectDocuments_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (!string.IsNullOrEmpty(llbProjectDocuments.Text))
            {
                System.Diagnostics.Process.Start(sPathLink);
            }
        }

        private void cmbWarrantyStartsFrom_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbWarrantyStartsFrom.SelectedIndex == 2)
            {
                txtWarrantyClose.ReadOnly = true;
                txtWarrantyClose.Text = "0";
            }
            else
            {
                txtWarrantyClose.ReadOnly = false;
            }
        }

        private void cmbDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!lstusers.Items.Contains(cmbDepartment.Text))
            {
                lstusers.Items.Add(cmbDepartment.Text);
            }
        }

        private void cmbGMApproveList_SelectedIndexChanged(object sender, EventArgs e)
        {
            sProjectCode = cmbGMApproveList.Text;
            fnProjectCodeLoad();
            tabControl1.Enabled = true;
        }

        //private void txtOrderValueinINR_TextChanged(object sender, EventArgs e)
        //{
        //    if (!string.IsNullOrEmpty(txtOrderValueinINR.Text))
        //    {
        //        txtOrderValueinUSD.Text = Math.Round(dPegRate * Convert.ToDouble(txtOrderValueinINR.Text)).ToString();
        //    }
        //}

        //private void txtInstallationValueinINR_TextChanged(object sender, EventArgs e)
        //{
        //    if (!string.IsNullOrEmpty(txtInstallationValueinINR.Text))
        //    {
        //        txtInstallationValueinUSD.Text = Math.Round(dPegRate * Convert.ToDouble(txtInstallationValueinINR.Text)).ToString();
        //    }

        //}

        private void txtTargetMaterialmargin_KeyPress(object sender, KeyPressEventArgs e)
        {
            fnOnlynumber1(sender, e);
        }

        private void txtTargetMaterialmargin_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtTargetMaterialmargin.Text))
            {
                if (login.GetUserDetails[2].ToLower() == "vivek g")
                    txtTargetValue.Text = Math.Round((1 - (Convert.ToDouble(txtTargetMaterialmargin.Text) / 100)) * Convert.ToDouble(txtOrderValueinINR.Text)).ToString();
                else
                {
                    txtTargetValue.Text = Math.Round((1 - ((Convert.ToDouble(txtTargetMaterialmargin.Text) + 5) / 100))  * Convert.ToDouble(txtOrderValueinINR.Text)).ToString();
                }
            }
            else
            {
                MessageBox.Show("Enter the target material margin", "Error", 0, MessageBoxIcon.Error);
                txtTargetMaterialmargin.Focus();
            }
        }
        DataTable dtQuoteItems = new DataTable();
        private void fnJackUpCalculation()
        {
            double dSalesMarginCost = 0;
            double sBrekTotalAmount = 0;
            foreach (DataRow dgvr in dtQuoteItems.Rows)
            {
                sBrekTotalAmount += (Convert.ToDouble(dgvr["BreakupTotal"]) * Convert.ToDouble(dgvr["Quantity"]));
                dSalesMarginCost += (Convert.ToDouble(dgvr["SalesCost"]) * Convert.ToDouble(dgvr["Quantity"]));
            }


            txtProjectMargin.Text = Math.Round((1 - (dSalesMarginCost / sBrekTotalAmount)) * 100).ToString();
          //  if (login.GetUserDetails[2].ToLower() == "vivek g" || login.GetUserDetails[2].ToLower() == "sadat" || login.GetUserDetails[2].ToLower() == "abhilash")
                if (login.GetUserDetails[2].ToLower() == "vivek g" )
            {

            }
            else
            {
                if (!string.IsNullOrEmpty(txtProjectMargin.Text))
                {
                    double kCheck = Convert.ToDouble(Math.Round((1 - (dSalesMarginCost / sBrekTotalAmount)) * 100));
                    if (kCheck > 0)
                    {
                        txtProjectMargin.Text = (Math.Round((1 - (dSalesMarginCost / sBrekTotalAmount)) * 100) - 5).ToString();
                    }
                }
            }
        }


        private void llbUploadDocs_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (!string.IsNullOrEmpty(txtPMProjectCode.Text))
            {
                ProjectDocs.fnProjectcode = txtPMProjectCode.Text;
                this.Hide();
                pleasewaitform pleaseWait = new pleasewaitform();
                pleaseWait.Show();
                Application.DoEvents();
                ProjectDocs.Show();
                pleaseWait.Hide();
            }
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void txtContactPerson_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtDepartment_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtOrderValueinINR_keydown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtOrderValueinUSD.Text = Math.Round(dPegRate * Convert.ToDouble(txtOrderValueinINR.Text)).ToString();
            }
        }

        private void txtOrderValueUSD_keydown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtOrderValueinINR.Text = Math.Round(Convert.ToDouble(txtOrderValueinUSD.Text) / dPegRate).ToString();
            }
        }

        private void txtinstallationvalueinINR_keydown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtInstallationValueinUSD.Text = Math.Round(dPegRate * Convert.ToDouble(txtInstallationValueinINR.Text)).ToString();
            }
        }

        private void txtinstallationvalueinUSD_keydown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtInstallationValueinINR.Text = Math.Round(Convert.ToDouble(txtInstallationValueinUSD.Text) / dPegRate).ToString();
            }
        }
        private void btnbackqn_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedIndex = 1;

           

        }

        private void btnnextqn_Click(object sender, EventArgs e)
        {

            tabControl1.SelectedIndex = 3;
        }
        // DataTable dtrevenue = new DataTable();
        private void revenuequestioninsert(int iCase)
        {
            switch (iCase)
            {
                case 0:
                    GlobalClass.iSuccess = DAL.fnRevenuequestioninsert(0, sProjectCode, dgvRevenueRecognition[1, 0].Value.ToString(), dgvRevenueRecognition[1, 1].Value.ToString(), dgvRevenueRecognition[1, 2].Value.ToString(), dgvRevenueRecognition[1, 3].Value.ToString(), dgvRevenueRecognition[1, 4].Value.ToString(), dgvRevenueRecognition[1, 5].Value.ToString(), dgvRevenueRecognition[1, 6].Value.ToString(), dgvRevenueRecognition[1, 7].Value.ToString(), login.GetUserDetails[2]);
                    break;

                case 1:
                    GlobalClass.iSuccess = DAL.fnRevenuequestioninsert(1, txtPMProjectCode.Text, dgvRevenueRecognition[1, 0].Value.ToString(), dgvRevenueRecognition[1, 1].Value.ToString(), dgvRevenueRecognition[1, 2].Value.ToString(), dgvRevenueRecognition[1, 3].Value.ToString(), dgvRevenueRecognition[1, 4].Value.ToString(), dgvRevenueRecognition[1, 5].Value.ToString(), dgvRevenueRecognition[1, 6].Value.ToString(), dgvRevenueRecognition[1, 7].Value.ToString(), login.GetUserDetails[2]);
                    break;
            }
        }

        private void cmbStockProject_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable dtStockProject = new DataTable();
            dtStockProject = DAL.fnProjectList(cmbStockProject.Text).Tables[0]; //get selected project from projectMaster database
            if (dtStockProject.Rows.Count > 0)
            {
                lblProjectName.Text = dtStockProject.Rows[0]["ProjectDescription"].ToString();
            }
        }

        private void dgvRevenueRecognition_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvRevenueRecognition.CurrentCell.ColumnIndex == 1)
            {
                if (dgvRevenueRecognition.CurrentCell.Value.ToString() == "No")
                {
                    dgvRevenueRecognition.CurrentCell.Value = "Yes";
                }
                else if (dgvRevenueRecognition.CurrentCell.Value.ToString() == "Yes")
                {
                    dgvRevenueRecognition.CurrentCell.Value = "No";
                }
            }
        }

        private void cmbProject8020_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbProject8020.SelectedIndex == 0)
            {
                cmbCustomizationlevel.Items.Clear();
                cmbCustomizationlevel.SelectedIndex = -1;
                cmbCustomizationlevel.Items.Add("1");
                cmbCustomizationlevel.Items.Add("2");
            }
            else if (cmbProject8020.SelectedIndex == 1)
            {
                cmbCustomizationlevel.Items.Clear();
                cmbCustomizationlevel.SelectedIndex = -1;
                cmbCustomizationlevel.Items.Add("3");
                cmbCustomizationlevel.Items.Add("4");
            }
        }

        private void checkBoxdept_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxdept.Checked)
            {
                LoadDepartments();
            }
            else
            {
                lstusers.Items.Clear();  // Clear the ListBox if unchecked
            }
        }

        private void LoadDepartments()
        {
            // Assuming DAL.fnDepartmentList(0, null, null) returns a DataSet or DataTable
            DataTable dtDepartment = DAL.fnDepartmentList(0, null, null).Tables[0];

            // Clear the existing items in the ListBox before adding new ones
            lstusers.Items.Clear();

            // Loop through the DataTable rows and add each department to the ListBox
            foreach (DataRow DR in dtDepartment.Rows)
            {
                // Check if the department is not already in the ListBox items
                if (!lstusers.Items.Contains(DR[0].ToString()))
                {
                    lstusers.Items.Add(DR[0].ToString());
                }
            }

            // Optionally, you can select the first item in the ListBox after loading
            if (lstusers.Items.Count > 0)
            {
                lstusers.SelectedIndex = 0;  // Select the first department (optional)
            }
        }
    }
}
