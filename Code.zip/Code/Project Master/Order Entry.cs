﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Project_Master
{
    public partial class Order_Entry : Form
    {
        DataTable SelectprojectCode = new DataTable();
        DataAccessLayer DAL = new DataAccessLayer();
        Global GlobalClass = new Global();
        Login.frmLoginForm login = new Login.frmLoginForm();
        public Order_Entry()
        {
            InitializeComponent();
        }

        private void Order_Entry_Load(object sender, EventArgs e)
        {
            SelectprojectCode = DAL.Project_Closer_select_project_Code(0, null).Tables[0];
            MessageBox.Show("Order Entery");
            if (SelectprojectCode.Rows.Count > 0)
            {
                foreach (DataRow DR in SelectprojectCode.Rows)
                {
                    if (!comselectedprojectcodeBom.Items.Contains(DR["ProjectCode"].ToString()))
                        comselectedprojectcodeBom.Items.Add(DR["ProjectCode"].ToString());
                }
            }
        }
        // Method to change the selected value
        public void ChangeDropdownSelection()
        {
            // Assuming you want to select the item with value "2"
            comselectedprojectcodeBom.SelectedValue = comselectedprojectcodeBom.Text;

            // Alternatively, you can select based on index
            // ddlExample.SelectedIndex = 1; // This selects the second item (index starts at 0)

            string input = comselectedprojectcodeBom.Text; // "AMC-2022-04-STS-113287-122A"

            // Split the string by '-'
            string[] parts = input.Split('-');

            if (parts.Length >= 5)
            {
                // Fetch the value after 'STS-' (i.e., the part at index 3)
                string afterSTS = parts[3];

                // Find the index of the segment just before the last segment
                int lastSegmentIndex = input.LastIndexOf('-');
                int secondLastSegmentIndex = input.LastIndexOf('-', lastSegmentIndex - 1);

                // Extract the medal value
                string medalValue = input.Substring(secondLastSegmentIndex + 1, lastSegmentIndex - secondLastSegmentIndex - 1);

                txtMachineSerialNo.Text = medalValue;
                // Display the results
                //MessageBox.Show($"Value after 'STS-': {afterSTS}\nMedal Value: {medalValue}\nLast segment: {parts[parts.Length - 1]}", "Extracted Values", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Input string does not have the expected format.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttprojectclosersave_Click(object sender, EventArgs e)
        {
            string selectedprojectcode = comselectedprojectcodeBom.Text;
            string BillingType = comBillingType.SelectedItem?.ToString();
            string pdelivery = dtpdelivery.Value.ToString("dd-MM-yyyy");
            // Extract the year (last 4 characters of the string)
            string year = pdelivery.Substring(6, 4);
            string Amount = txtAmount.Text;
            
            string id = cmbid.Text;

            // Perform validation
            if (string.IsNullOrWhiteSpace(selectedprojectcode))
            {
                MessageBox.Show("Project code is required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrEmpty(BillingType))
            {
                MessageBox.Show("Billing type must be selected.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrWhiteSpace(Amount) || !decimal.TryParse(Amount, out _))
            {
                MessageBox.Show("Please enter a valid amount.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtMachineSerialNo.Text))
            {
                MessageBox.Show("Machine serial number is required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrWhiteSpace(id))
            {
                MessageBox.Show("ID is required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Proceed with saving logic if all validations pass
            //MessageBox.Show()

            // Assuming you want to select the item with value "2"
            comselectedprojectcodeBom.SelectedValue = comselectedprojectcodeBom.Text;

            // Alternatively, you can select based on index
            // ddlExample.SelectedIndex = 1; // This selects the second item (index starts at 0)

            string input = comselectedprojectcodeBom.Text; // "AMC-2022-04-STS-113287-122A"

            // Split the string by '-'
            string[] parts = input.Split('-');
            string OENo=string.Empty;
            if (parts.Length >= 5)
            {
                // Fetch the value after 'STS-' (i.e., the part at index 3)
                string afterSTS = parts[3];

                // Find the index of the segment just before the last segment
                int lastSegmentIndex = input.LastIndexOf('-');
                int secondLastSegmentIndex = input.LastIndexOf('-', lastSegmentIndex - 1);

                // Extract the medal value
                string medalValue = input.Substring(secondLastSegmentIndex + 1, lastSegmentIndex - secondLastSegmentIndex - 1);
                 OENo = year + afterSTS + medalValue + id;
            }
            // Ensure none of the variables are null
            //string year = year ?? string.Empty;
            //string afterSTS = afterSTS ?? string.Empty;
            //string medalValue = medalValue ?? string.Empty;
            //string id = id ?? string.Empty;

            // Concatenate values into OENo
            




            // Concatenate all values into a single message
            string message = $"Project Code: {selectedprojectcode}\n" +
                             $"OENo: {OENo}\n" +
                             $"Billing Type: {BillingType}\n" +
                             $"Delivery Date: {pdelivery}\n" +
                             $"Amount: {Amount}\n" +
                             $"Machine Serial No: {txtMachineSerialNo.Text}\n" +
                             
                             $"ID: {id}";
            DateTime currentDate = DateTime.Now;
            string currentDateString = currentDate.ToString("dd-MM-yyyy HH:mm:ss");
            // Display all values in a message box
            MessageBox.Show(message);
            GlobalClass.iStatus = DAL.ProjectOrderBillingDetails(0,
                        selectedprojectcode,
                        OENo,
                        BillingType,
                        pdelivery,
                        Amount,
                        txtMachineSerialNo.Text,
                        id,
                        login.GetUserDetails[2],
                        currentDateString
                        );

        }

        private void comselectedprojectcodeBom_SelectedIndexChanged(object sender, EventArgs e)
        {
            ChangeDropdownSelection();
        }

        private void butUpdate_Click(object sender, EventArgs e)
        {
            this.Hide();
            // Create an instance of Order_Entry_Billing_Update
            Order_Entry_Billing_Update orderEntryForm = new Order_Entry_Billing_Update();

            // Show the form
            orderEntryForm.Show();

            // Define the message text
            //string messageText = "Order Entry Form has been opened.";

            // Show the message box
            //MessageBox.Show(messageText, "Popup", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

    }
}
