﻿

using System;
using System.Data;
using System.Windows.Forms;
using EXCEL = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Drawing;
using System.Linq;

namespace Erp_Project_With_Buttons.Project_Master
{
    public partial class Machine_Passport : Form
    {
        Login.frmLoginForm Loginfrm = new Login.frmLoginForm();
        frmForm2 frm = new frmForm2();
        DataAccessLayer DAL = new DataAccessLayer();
        Global GlobalClass = new Global();
        DataTable dtProductCategory = new DataTable();
        DataTable dtDGDatatable = new DataTable();
        DataTable dtPOFilter = new DataTable();
        DataTable dtPOFilter1 = new DataTable();
        DataTable dtPOFilter2 = new DataTable();
        Login.frmLoginForm login = new Login.frmLoginForm();
        frmForm2 Home = new frmForm2();


        private static string sProjectCode;
        public string fnProject_Master
        {
            get
            {
                return sProjectCode;
            }
            set
            {
                sProjectCode = value;
            }
        }

        public int sProjectStatusInstallform = 0;
        DataTable dtProjectList = new DataTable();
        BindingSource bsItemList = new BindingSource();
        //private DataGridView dataGridView;
        //private Button loadButton;
        public Machine_Passport()
        {
            InitializeComponent();
            cmbProjectcode.SelectedIndexChanged += cmbProjectcode_SelectedIndexChanged_1;
            cmbProductCategory.SelectedIndexChanged += cmbProductCategory_SelectedIndexChanged;


        }




        DataTable dtOrderentry = new DataTable();
        private void Machine_Passport_Load(object sender, EventArgs e)
        {
            dtProjectList = DAL.fnInstallProjectList(0, null).Tables[0];

            dtDGDatatable = DAL.fnDirectProjectBOMList(cmbProjectcode.Text).Tables[0];

            dtOrderentry = DAL.mpProjectOrderEntry(0, null).Tables[0];
            if (dtOrderentry.Rows.Count > 0)
            {

                foreach (DataRow DR in dtOrderentry.Rows)
                {
                    if (!cmbProjectcode.Items.Contains(DR["ProjectCode"].ToString()))
                        cmbProjectcode.Items.Add(DR["ProjectCode"].ToString());
                }

            }

            DataTable dtselcetprojectcode = new DataTable();
            dtselcetprojectcode = DAL.mpProjectOrderEntry(2, null).Tables[0];
            if (dtselcetprojectcode.Rows.Count > 0)
            {
                foreach (DataRow DR in dtselcetprojectcode.Rows)
                {

                    if (!comselectedprojectcode.Items.Contains(DR["ProjectCode"].ToString()))
                        comselectedprojectcode.Items.Add(DR["ProjectCode"].ToString());
                }

            }



            DataTable ApproveList = new DataTable();
            ApproveList = DAL.ApproveList(0, "WIP").Tables[0];
            comApproveList.Items.Clear();

            if (ApproveList.Rows.Count > 0)
            {
                foreach (DataRow DR in ApproveList.Rows)
                {
                    if (!comApproveList.Items.Contains(DR[0].ToString()))
                        comApproveList.Items.Add(DR[0].ToString());
                }
            }
        }


        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            //Project_Master.frmProjectHome Home = new Project_Master.frmProjectHome();
            Home.Show();
        }


        private void MPSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmbProjectcode.SelectedIndex >= 0 && cmbProductCategory.SelectedIndex >= 0 && AllType.SelectedIndex >= 0)
                {



                    if (textCustName.Visible && string.IsNullOrWhiteSpace(textCustName.Text))
                    {
                        MessageBox.Show("Enter  Custmar Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        textCustName.Focus();
                    }


                    else if (txtMpProjectDedscription.Visible && string.IsNullOrWhiteSpace(txtMpProjectDedscription.Text))
                    {
                        MessageBox.Show("Enter  Project Description", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtMpProjectDedscription.Focus();
                    }
                    else if (txtMpMachineModelNumber.Visible && string.IsNullOrWhiteSpace(txtMpMachineModelNumber.Text))
                    {
                        MessageBox.Show("Enter  Machine Model Number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtMpMachineModelNumber.Focus();
                    }
                    else if (textMpMachineSerialNo.Visible && string.IsNullOrWhiteSpace(textMpMachineSerialNo.Text))
                    {
                        MessageBox.Show("Enter Machine Serial No", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        textMpMachineSerialNo.Focus();
                    }
                    else if (textMaterialModelNO.Visible && string.IsNullOrWhiteSpace(textMaterialModelNO.Text))
                    {
                        MessageBox.Show("Enter Product Model No", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        textMaterialModelNO.Focus();
                    }
                    else if (cmbProjectcode.SelectedIndex < 0)
                    {
                        MessageBox.Show("Select project code", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        cmbProjectcode.Focus();
                    }
                    else if (cmbProductCategory.SelectedIndex < 0)
                    {
                        MessageBox.Show("Select Product Category", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        cmbProductCategory.Focus();
                    }

                    else if (AllType.SelectedIndex < 0 || AllType.SelectedIndex == -1)
                    {
                        MessageBox.Show("Please Select Sub Types", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        AllType.Focus();
                    }


                    string message1 = "";
                    // Declare variables to store textbox values
                    string Projectcode = cmbProjectcode.Text;
                    string ProductCategory = cmbProductCategory.Text;
                    string MachineModelNumber = txtMpMachineModelNumber.Text;
                    string MachineSerialNo = textMpMachineSerialNo.Text;
                    string PODate = textPODate.Text;
                    string ProjectDescription = txtMpProjectDedscription.Text;
                    string CustomerName = textCustName.Text;
                    string PoNo = textPoNo.Text;
                    string Type = AllType.Text;
                    string ProductModelNumber = textMaterialModelNO.Text;
                    string Specification = comspecification.Text;



                    // Proceed with data insertion for selected rows
                    foreach (DataGridViewRow row in dgItemOrProductList.Rows)
                    {
                        // Skip if the row is a new row (if applicable)
                        if (row.IsNewRow) continue;

                        // Use a helper method to safely get cell values 




                        string GetCellValue(string columnName)
                        {
                            // Check if the column exists in the DataGridView
                            if (dgItemOrProductList.Columns.Contains(columnName))
                            {
                                var cell = row.Cells[columnName];
                                return cell.Visible ? cell.Value?.ToString() : null; // Assign null if the cell is not visible
                            }
                            return null; // Return null if the column does not exist
                        }

                        // Extract cell values using the helper method
                        int SlNo = Convert.ToInt32(GetCellValue("SlNo"));
                        string productSerialNo = GetCellValue("ProductSerialNumber");
                        string Deviation = GetCellValue("Deviation");
                        string CapacityorRange = GetCellValue("CapacityOrRange");
                       // string Specification = GetCellValue("Specification");
                        string VersionNo = GetCellValue("VersionNo");
                        string ControllerSCcardType = GetCellValue("ScCardType");
                        int NoofCards = Convert.ToInt32(GetCellValue("NoOfCards"));
                        string Connectedto = GetCellValue("ConnectedTo");
                        string ApplicationDescription = GetCellValue("ApplicationDescription");
                        string Shuntvalue = GetCellValue("ShuntValue");
                        string OperatingSystem = GetCellValue("OperatingSystem");
                        string ServiceTag = GetCellValue("ServiceTag");
                        string Remarks = GetCellValue("Remarks");
                        string GripsType = GetCellValue("GripsType");
                        string TransducersType = GetCellValue("TransducersType");

                        // Set status and date
                        string status = "WIP";
                        string dateString = DateTime.Now.ToString("dd-MM-yyyy");

                        // Check if the product serial number already exists in the database
                        DataTable isDuplicateKeyTable = DAL.CheckDuplicateKey(1, productSerialNo).Tables[0];

                        // If a duplicate is found
                        if (isDuplicateKeyTable.Rows.Count > 0)
                        {
                            // Show an error message to the user


                            // Find the index of the column with the product serial number
                            int columnIndex = dgItemOrProductList.Columns["ProductSerialNumber"].Index; // Replace "ProductSerialNo" with your actual column name

                            // Find the current row index (if applicable)
                            int rowIndex = dgItemOrProductList.CurrentCell.RowIndex; // Or set to a specific row if needed

                            // Focus on the specific cell in the DataGridView
                            dgItemOrProductList.CurrentCell = dgItemOrProductList.Rows[rowIndex].Cells[columnIndex];

                            // Optionally start editing the cell to allow the user to change the serial number
                            dgItemOrProductList.BeginEdit(true);
                            MessageBox.Show("Serial No is already exist. please enter different value..", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            // Exit the method or handle further actions as needed
                            return;

                        }
                        try
                        {
                            // Call the data access method to insert the data into the database
                            GlobalClass.iStatus = DAL.MachinePassport(
                                0, // Assuming 0 is an identifier for a new entry
                                SlNo,
                                TransducersType,
                                GripsType,
                                Projectcode,
                                ProjectDescription,
                                ProductCategory,
                                MachineSerialNo,
                                MachineModelNumber,
                                CustomerName,
                                PoNo,
                                PODate,
                                productSerialNo,
                                ProductModelNumber,
                                Deviation,
                                Type,
                                CapacityorRange,
                                Specification,
                                VersionNo,
                                ControllerSCcardType,
                                NoofCards,
                                Connectedto,
                                ApplicationDescription,
                                Shuntvalue,
                                OperatingSystem,
                                ServiceTag,
                                Remarks,

                                status,
                                login.GetUserDetails[2],
                                dateString
                            );

                            // Optionally, handle the response from the database here
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Error saving data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                        }

                    }




                }




                MessageBox.Show("Machine Passport Inserted successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Hide();
                Machine_Passport Machine_Passport = new Machine_Passport();
                Machine_Passport.Show();

            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }



        private void cmbProductCategory_SelectedIndexChanged(object sender, EventArgs e)
        {

            //  LoadData();

            DataTable dtProjectBOM = DAL.fnProjectBom(cmbProjectcode.Text, 1).Tables[0];
            string QuotationNumber = dtProjectBOM.Rows[0]["QuotationNumber"].ToString();
            DataTable dataTable = DAL.fnQuoteBOMItemsselectsubproducttype(cmbProjectcode.Text, cmbProductCategory.Text, 2).Tables[0];



            // Check if the DataSet contains any tables
            if (dataTable != null && dataTable.Rows.Count > 0)
            {
                if (dataTable.Rows.Count > 0)
                {

                    AllType.Items.Clear();
                    foreach (DataRow DR in dataTable.Rows)
                    {

                        if (!AllType.Items.Contains(DR["ProductName"].ToString()))
                            AllType.Items.Add(DR["ProductName"].ToString());
                    }

                }

            }




            // Check if the selected item in cmbProductCategory is what you expect
            if (cmbProductCategory.SelectedItem != null)
            {



                AllTypes.Visible = true;
                AllType.Visible = true;



                labMaterialModelNo.Visible = true;
                textMaterialModelNO.Visible = true;
                labPODate.Visible = true;
                textPODate.Visible = true;





                if (chkUpdatePO.Checked)
                {
                    // Clear existing items in product category combo box
                    AllType.Text = "";
                    AllType.Items.Clear();

                    // Get the selected project code
                    string selectedProjectCode = cmbProjectcode.SelectedItem.ToString();
                    // Get the selected project code
                    string selectedproductcategory = cmbProductCategory.SelectedItem.ToString();

                    // Load product categories based on the selected project code
                    dtPOFilter1 = DAL.fnProjectDetailsupdate(4, selectedProjectCode, selectedproductcategory, null).Tables[0];

                    // Populate product categories
                    if (dtPOFilter1.Rows.Count > 0)
                    {
                        foreach (DataRow DR in dtPOFilter1.Rows)
                        {
                            if (!AllType.Items.Contains(DR["AllType"].ToString()))
                                AllType.Items.Add(DR["AllType"].ToString());
                        }
                        AllType.Enabled = true;
                    }

                }
                else

                    // Check if the DataSet contains any tables
                    if (dataTable != null && dataTable.Rows.Count > 0)
                {
                    if (dataTable.Rows.Count > 0)
                    {

                        AllType.Items.Clear();
                        foreach (DataRow DR in dataTable.Rows)
                        {

                            if (!AllType.Items.Contains(DR["ProductName"].ToString()))
                                AllType.Items.Add(DR["ProductName"].ToString());
                        }

                    }

                }



            }




        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void fnFormShow(Form Frm)
        {
            this.Hide();
            pleasewaitform pleaseWait = new pleasewaitform();
            pleaseWait.Show();
            Application.DoEvents();
            Frm.Show();
            pleaseWait.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (cmbProjectcode.SelectedIndex < 0)
            {
                MessageBox.Show("Select project code", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cmbProjectcode.Focus();
                return;
            }
            else if (cmbProductCategory.SelectedIndex < 0)
            {
                MessageBox.Show("Select Product Category", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cmbProductCategory.Focus();
                return;
            }
            else if (AllType.SelectedIndex < 0)
            {
                MessageBox.Show("Please Select Sub Types", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                AllType.Focus();
                return;
            }





            // Proceed with data insertion/update for selected rows
            foreach (DataGridViewRow row in dgupdate.Rows)
            {
                // Skip if the row is a new row
                if (row.IsNewRow) continue;

                // Use a helper method to safely get cell values
                string GetCellValue(string columnName)
                {
                    if (dgupdate.Columns.Contains(columnName))
                    {
                        var cell = row.Cells[columnName];
                        return cell.Visible ? cell.Value?.ToString() : null;
                    }
                    return null;
                }

                // Extract cell values
                string productSerialNo = GetCellValue("ProductSerialNumber");
                string Deviation = GetCellValue("Deviation");
                string CapacityorRange = GetCellValue("CapacityOrRange");
               // string Specification = GetCellValue("Specification");
                string VersionNo = GetCellValue("VersionNo");
                string ControllerSCcardType = GetCellValue("ScCardType");
                int NoofCards = Convert.ToInt32(GetCellValue("NoOfCards"));
                string Connectedto = GetCellValue("Connected to");
                string ApplicationDescription = GetCellValue("ApplicationDescription");
                string Shuntvalue = GetCellValue("ShuntValue");
                string OperatingSystem = GetCellValue("operatingSystem");
                string ServiceTag = GetCellValue("ServiceTag");
                string Remarks = GetCellValue("Remarks");
                string status = "WIP";

                // Update the database using a method from your DAL

                // Update the database using a method from your DAL
                int result = DAL.fnMachinePassportUpdate(
                    1,
                    cmbProjectcode.Text,
                    cmbProductCategory.Text,
                    AllType.Text,
                    productSerialNo,
                    Deviation,
                    CapacityorRange,
                   // Specification,
                    VersionNo,
                    ControllerSCcardType,
                    NoofCards,
                    Connectedto,
                    ApplicationDescription,
                    Shuntvalue,
                    OperatingSystem,
                    ServiceTag,
                    Remarks,
                    status
                );
                if (result == 0)
                {
                    MessageBox.Show($"Failed to update row with Serial No: {productSerialNo}", "Update Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
               
                   
                

            }
            MessageBox.Show("updated Successfully ", "Update Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Machine_Passport Machine_Passport = new Machine_Passport();
            Machine_Passport.Show();
        }


        private void label66_Click(object sender, EventArgs e)
        {

        }




        DataView dvProjectName = new DataView();
        private void cmbProjectcode_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            dvProjectName = new DataView(dtProjectList);
            dvProjectName.RowFilter = "ProjectCode='" + cmbProjectcode.Text + "'";

            string originalString = cmbProjectcode.Text;

            string formattedNumber = GetLastPartAfterDash(originalString);
            textMpMachineSerialNo.Text = formattedNumber;
            textMpMachineSerialNo.ReadOnly = true;
            string GetLastPartAfterDash(string input)
            {

                string[] parts = input.Split('-');
                string lastPart = parts[parts.Length - 1];

                return lastPart;
            }



            if (dvProjectName.ToTable().Rows.Count > 0)
            {
                txtMpProjectDedscription.Text = dvProjectName.ToTable().Rows[0]["ProjectDescription"].ToString();
                txtMpProjectDedscription.ReadOnly = true;
                textCustName.Text = dvProjectName.ToTable().Rows[0]["Customer"].ToString();
                textCustName.ReadOnly = true;


                DataTable dtOrderentry = DAL.fnProjectOrderEntry(cmbProjectcode.Text, 1).Tables[0];
                if (dtOrderentry.Rows.Count > 0)
                {
                    txtMpMachineModelNumber.Text = dtOrderentry.Rows[0]["ModelNumber"].ToString();
                    txtMpMachineModelNumber.ReadOnly = true;
                    textPoNo.Text = dtOrderentry.Rows[0]["PONo"].ToString();
                    textPoNo.ReadOnly = true;
                    textPODate.Text = dtOrderentry.Rows[0]["PODate"].ToString();
                    textPODate.ReadOnly = true;
                }



            }

            // Clear existing items in product category combo box
            cmbProductCategory.Text = "";
            cmbProductCategory.Items.Clear();
            if (chkUpdatePO.Checked)
            {
                // Get the selected project code
                string selectedProjectCode = cmbProjectcode.SelectedItem.ToString();

                // Load product categories based on the selected project code
                dtPOFilter1 = DAL.fnProjectDetailsupdate(3, selectedProjectCode, null, null).Tables[0];

                // Populate product categories
                if (dtPOFilter1.Rows.Count > 0)
                {
                    foreach (DataRow DR in dtPOFilter1.Rows)
                    {
                        if (!cmbProductCategory.Items.Contains(DR["ProductCategory"].ToString()))
                            cmbProductCategory.Items.Add(DR["ProductCategory"].ToString());
                    }
                    cmbProductCategory.Enabled = true;
                }
            }
            else
            {
                DataTable dtProjectBOM = DAL.fnProjectBom(cmbProjectcode.Text, 1).Tables[0];



                cmbProductCategory.Items.Clear();
                foreach (DataRow DR in dtProjectBOM.Rows)
                {

                    if (!cmbProductCategory.Items.Contains(DR["ProductGroup"].ToString()))
                        cmbProductCategory.Items.Add(DR["ProductGroup"].ToString());
                }
            }
        }


        private void ApplyGridStyle(DataGridView grid)
        {
            grid.EnableHeadersVisualStyles = false;
            grid.AllowUserToAddRows = false;
            grid.RowHeadersVisible = false;

            // Set header styles
            foreach (DataGridViewColumn column in grid.Columns)
            {
                column.HeaderCell.Style.BackColor = Color.LightSteelBlue;
                column.HeaderCell.Style.ForeColor = Color.Black;
                column.HeaderCell.Style.Font = new Font("Segoe UI", 9, FontStyle.Bold);
                column.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            }

            // Set default cell styles
            grid.DefaultCellStyle.Font = new Font("Segoe UI", 8.5f);
            grid.DefaultCellStyle.BackColor = Color.White;
            grid.DefaultCellStyle.ForeColor = Color.Black;
            grid.DefaultCellStyle.WrapMode = DataGridViewTriState.True;

            grid.RowTemplate.Height = 20;

          //  grid.AutoResizeColumns();
            grid.Refresh();
        }


        private void LoadData()
        {
            // Assuming fnCatagary is already populated from your data access layer
            DataTable fnCatagary = DAL.fnMachineproductCatagary(1, cmbProductCategory.Text).Tables[0];
            dgItemOrProductList.Visible = true;
            // Clear existing columns and rows in the DataGridView
            dgItemOrProductList.Columns.Clear();
            dgItemOrProductList.Rows.Clear();


            // Reset row count
            int rowcount = 1;
            // Check if the DataTable has rows
            if (fnCatagary.Rows.Count == 0)
            {
                dgItemOrProductList.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "SlNo",
                    HeaderText = "SlNo"
                });
                //dgItemOrProductList.Columns.Add(new DataGridViewTextBoxColumn
                //{
                //    Name = "CapacityOrRange",
                //    HeaderText = "CapacityOrRange"
                //});
                dgItemOrProductList.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "ProductSerialNumber",
                    HeaderText = "ProductSerialNumber"
                });
                dgItemOrProductList.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "Remarks",
                    HeaderText = "Remarks"
                });

                dgItemOrProductList.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Name = "Deviation",
                    HeaderText = "Deviation"
                });

                dgItemOrProductList.Refresh();


                // Insert each column name into the database with the selected category
                foreach (DataGridViewColumn column in dgItemOrProductList.Columns)
                {
                    int result = DAL.MachinePassportGridHeaders(0, column.HeaderText, cmbProductCategory.Text);

                }
                ApplyGridStyle(dgItemOrProductList);
                return;
            }
            else
            {



                // Add "Sl No" as the first column
                //dgItemOrProductList.Columns.Add(new DataGridViewTextBoxColumn
                //{
                //    Name = "SlNo",
                //    HeaderText = "SlNo"
                //});

                // Retrieve distinct "name" values from the DataTable and create columns
                // Create columns from distinct names
                var distinctNames = fnCatagary.AsEnumerable()
                                              .Select(row => row.Field<string>("name"))
                                              .Distinct();

                foreach (var name in distinctNames)
                {
                    dgItemOrProductList.Columns.Add(new DataGridViewTextBoxColumn
                    {
                        Name = name,
                        HeaderText = name
                    });
                }

                ApplyGridStyle(dgItemOrProductList);
            }


        }















        private void btnProjectSearch_Click(object sender, EventArgs e)
        {
            sProjectStatusInstallform = 1;
            Indent.frmProjectselect projectsearch = new Indent.frmProjectselect();
            projectsearch.fnProject_Master = sProjectStatusInstallform.ToString();
            projectsearch.ShowDialog();
            if (fnProject_Master != null)
            {
                cmbProjectcode.Text = sProjectCode;
            }
        }
        private void clear()
        {


            cmbProjectcode.Text = "";
            cmbProjectcode.Items.Clear();
            cmbProductCategory.Text = "";
            cmbProductCategory.Items.Clear();
            AllType.Text = "";
            AllType.Items.Clear();
            txtMpMachineModelNumber.Text = "";
            txtMpProjectDedscription.Text = "";
            textPODate.Text = "";
            textMpMachineSerialNo.Text = "";
            textMaterialModelNO.Text = "";
            textPoNo.Text = "";
            textCustName.Text = "";

        }

        private void btnprintgin_Click(object sender, EventArgs e)
        {
            MPSave.Visible = false;
            labprintprojectcode.Visible = true;
            comselectedprojectcode.Visible = true;
            if (comselectedprojectcode.SelectedIndex > -1)
            {
                int iRowIndex = 1;
                string ExcelFolderName;
                string ExcelFolderPath;
                string FileFullPath;
                //DataTable fnMachineReceipt = new DataTable();
                EXCEL.Workbook NewWorkBook;
                EXCEL.Worksheet NewWorkSheet;
                EXCEL.Application ExcelApp;
                EXCEL.Range CELLS;
                {
                    object misValue;
                    ExcelFolderName = "\\Machine Passport";
                    ExcelFolderPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + ExcelFolderName + "\\";
                    FileFullPath = ExcelFolderPath + (comselectedprojectcode.Text).Replace("/", "_") + "_" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + ".xlsx";
                    //FileFul = ExcelFolderPath + cmbVendorName.Text + " " + (cmbPONO.Text).Replace("/", "_") + "_" + DateTime.Now.ToString("d/M/yyyy hh/mm/ss") + ".pdf";
                    DataTable fnMachineReceipt0 = DAL.fnMachineReceipt(0, comselectedprojectcode.Text).Tables[0];
                    DataTable fnMachineReceipt1 = DAL.fnMachineReceipt(1, comselectedprojectcode.Text).Tables[0];

                    DataTable fnMachineproductCatagary = DAL.fnMachineproductCatagary(0, comselectedprojectcode.Text).Tables[0];


                    string[] Text ={"","",
                                Global.sCompanyName,
                                "NO.497E, 14th Cross, 4th Phase, Peenya Industrial Area,",
                                "Bangalore-560 058, Karnataka,  India. ",
                                "Phone:91(080) 28360184. FAX: (080) 28360047.",
                        ""
                               };

                    if (!Directory.Exists(ExcelFolderPath))
                        Directory.CreateDirectory(ExcelFolderPath);

                    ExcelApp = new EXCEL.Application();
                    misValue = System.Reflection.Missing.Value;
                    try
                    {
                        if (ExcelApp == null)
                            MessageBox.Show("EXCEL could not be started. Check that your office installation and project references are correct.");
                        NewWorkBook = ExcelApp.Workbooks.Add(misValue);
                        NewWorkSheet = NewWorkBook.Sheets.Add(misValue, misValue, 1, misValue);

                        if (NewWorkSheet == null)
                            MessageBox.Show("Worksheet could not be created. Check that your office installation and project references are correct.");
                        else
                        {
                            NewWorkSheet.Name = "Machine Passport";
                        }
                        EXCEL.Range RANGE = NewWorkSheet.get_Range("C1", "C7");
                        if (RANGE == null)
                            MessageBox.Show("Could not get a range. Check to be sure you have the correct versions of the office DLLs.");
                        NewWorkBook.SaveAs(FileFullPath, EXCEL.XlFileFormat.xlOpenXMLWorkbook, Type.Missing, Type.Missing, false, false, EXCEL.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                        CELLS = NewWorkSheet.Cells;
                        NewWorkSheet.PageSetup.PrintGridlines = false;

                        iRowIndex = iRowIndex + 1;
                        foreach (string str in Text)
                        {
                            NewWorkSheet.Cells[iRowIndex, 1] = str;
                            if (iRowIndex <= 8)
                                //CellMerge("Merge", NewWorkSheet, iRowIndex, iRowIndex, 1, 5);

                                iRowIndex++;
                        }

                        iRowIndex++;
                        iRowIndex++;
                        iRowIndex++;

                        //first----------------------------------------------------


                        int ifRowIndex = 9;
                        NewWorkSheet.Cells[(ifRowIndex + 1), 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                        NewWorkSheet.Cells[(ifRowIndex + 2), 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                        NewWorkSheet.Cells[(ifRowIndex + 3), 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                        NewWorkSheet.Cells[(ifRowIndex + 4), 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                        NewWorkSheet.Cells[(ifRowIndex + 5), 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                        NewWorkSheet.Cells[(ifRowIndex + 6), 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                        // NewWorkSheet.Cells[(ifRowIndex + 7), 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                        NewWorkSheet.Cells[(ifRowIndex ), 4].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                        NewWorkSheet.Cells[(ifRowIndex + 1), 4].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                        NewWorkSheet.Cells[(ifRowIndex + 2), 4].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                        NewWorkSheet.Cells[(ifRowIndex + 3), 4].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                        NewWorkSheet.Cells[(ifRowIndex + 4), 4].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                        NewWorkSheet.Cells[(ifRowIndex + 5), 4].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                        NewWorkSheet.Cells[(ifRowIndex + 6), 4].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));

                        CellMerge("GridLines", NewWorkSheet, ifRowIndex, ifRowIndex, 1, 3);
                        CellMerge("GridLines", NewWorkSheet, ifRowIndex + 1, ifRowIndex + 1, 1, 3);
                        CellMerge("GridLines", NewWorkSheet, ifRowIndex + 2, ifRowIndex + 2, 1, 3);
                        CellMerge("GridLines", NewWorkSheet, ifRowIndex + 3, ifRowIndex + 3, 1, 3);
                        CellMerge("GridLines", NewWorkSheet, ifRowIndex + 4, ifRowIndex + 4, 1, 3);
                        CellMerge("GridLines", NewWorkSheet, ifRowIndex + 5, ifRowIndex + 5, 1, 3);
                        CellMerge("GridLines", NewWorkSheet, ifRowIndex + 6, ifRowIndex + 6, 1, 3);


                        CellMerge("GridLines", NewWorkSheet, ifRowIndex, ifRowIndex, 4, 5);
                        CellMerge("GridLines", NewWorkSheet, ifRowIndex + 1, ifRowIndex + 1, 4, 5);
                        CellMerge("GridLines", NewWorkSheet, ifRowIndex + 2, ifRowIndex + 2, 4, 5);
                        CellMerge("GridLines", NewWorkSheet, ifRowIndex + 3, ifRowIndex + 3, 4, 5);
                        CellMerge("GridLines", NewWorkSheet, ifRowIndex + 4, ifRowIndex + 4, 4, 5);
                        CellMerge("GridLines", NewWorkSheet, ifRowIndex + 5, ifRowIndex + 5, 4, 5);
                        CellMerge("GridLines", NewWorkSheet, ifRowIndex + 6, ifRowIndex + 6, 4, 5);


                        CellMerge("Merge", NewWorkSheet, ifRowIndex, ifRowIndex, 1, 3);
                        CellMerge("Merge", NewWorkSheet, ifRowIndex + 1, ifRowIndex + 1, 1, 3);
                        CellMerge("Merge", NewWorkSheet, ifRowIndex + 2, ifRowIndex + 2, 1, 3);
                        CellMerge("Merge", NewWorkSheet, ifRowIndex + 3, ifRowIndex + 3, 1, 3);
                        CellMerge("Merge", NewWorkSheet, ifRowIndex + 4, ifRowIndex + 4, 1, 3);
                        CellMerge("Merge", NewWorkSheet, ifRowIndex + 5, ifRowIndex + 5, 1, 3);
                        CellMerge("Merge", NewWorkSheet, ifRowIndex + 6, ifRowIndex + 6, 1, 3);
                        CellMerge("Merge", NewWorkSheet, ifRowIndex + 7, ifRowIndex + 7, 1, 3);
                        NewWorkSheet.Cells[(ifRowIndex), 1].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));


                        CellMerge("Merge", NewWorkSheet, ifRowIndex, ifRowIndex, 4, 5);
                        CellMerge("Merge", NewWorkSheet, ifRowIndex + 1, ifRowIndex + 1, 4, 5);
                        CellMerge("Merge", NewWorkSheet, ifRowIndex + 2, ifRowIndex + 2, 4, 5);
                        CellMerge("Merge", NewWorkSheet, ifRowIndex + 3, ifRowIndex + 3, 4, 5);
                        CellMerge("Merge", NewWorkSheet, ifRowIndex + 4, ifRowIndex + 4, 4, 5);
                        CellMerge("Merge", NewWorkSheet, ifRowIndex + 5, ifRowIndex + 5, 4, 5);
                        CellMerge("Merge", NewWorkSheet, ifRowIndex + 6, ifRowIndex + 6, 4, 5);
                        CellMerge("Merge", NewWorkSheet, ifRowIndex + 7, ifRowIndex + 7, 4, 5);
                        NewWorkSheet.Cells[(ifRowIndex), 4].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));




                        NewWorkSheet.Cells[ifRowIndex, 1] = "Project Description";
                        NewWorkSheet.Cells[ifRowIndex + 1, 1] = "Customer Name";
                        NewWorkSheet.Cells[ifRowIndex + 2, 1] = "Project code";
                        NewWorkSheet.Cells[ifRowIndex + 3, 1] = "PO Number";
                        NewWorkSheet.Cells[ifRowIndex + 4, 1] = "Machine Model No";
                        NewWorkSheet.Cells[ifRowIndex + 5, 1] = "PO Date";
                        NewWorkSheet.Cells[ifRowIndex + 6, 1] = "Machine serial No";



                        NewWorkSheet.Cells[ifRowIndex, 4] = fnMachineReceipt0.Rows[0]["ProjectDescription"].ToString();
                        NewWorkSheet.Cells[ifRowIndex + 1, 4] = fnMachineReceipt0.Rows[0]["CustomerName"].ToString();
                        NewWorkSheet.Cells[ifRowIndex + 2, 4] = fnMachineReceipt0.Rows[0]["ProjectCode"].ToString();
                        NewWorkSheet.Cells[ifRowIndex + 3, 4] = fnMachineReceipt0.Rows[0]["PONumber"].ToString();
                        NewWorkSheet.Cells[ifRowIndex + 4, 4] = fnMachineReceipt0.Rows[0]["MachineModelNumber"].ToString();
                        NewWorkSheet.Cells[ifRowIndex + 5, 4] = fnMachineReceipt0.Rows[0]["PODate"].ToString();
                        NewWorkSheet.Cells[ifRowIndex + 6, 4] = fnMachineReceipt0.Rows[0]["MachineSerialNumber"].ToString();

                        CellMerge("AlignLeft", NewWorkSheet, ifRowIndex, 15, 4, 1);
                        CellMerge("VAlignCentre", NewWorkSheet, ifRowIndex, 15, 4, 1);
                        NewWorkSheet.Range["A9:A16"].Cells.Font.Size = 15;
                        NewWorkSheet.Range["A9:A16"].Cells.Font.Bold = true;



                        // Convert DataTable to a readable string format
                        var stringBuilder = new System.Text.StringBuilder();
                        ifRowIndex = 17;
                        foreach (DataRow row in fnMachineproductCatagary.Rows)
                        {
                            foreach (var item in row.ItemArray)
                            {
                               // MessageBox.Show(item.ToString());
                                //MessageBox.Show(comselectedprojectcode.Text);
                                DataTable fnProjectCategory = DAL.fnProjectCategory(1, item.ToString(), comselectedprojectcode.Text).Tables[0];



                                ifRowIndex = ifRowIndex + 1;
                                // DataTable fnProjectCategory1 = DAL.fnProjectCategory(2, item.ToString(),null).Tables[0];
                                NewWorkSheet.Cells[ifRowIndex, 4] = item.ToString();


                                CellMerge("AlignTop", NewWorkSheet, ifRowIndex, ifRowIndex, 1, 10);
                                CellMerge("Merge", NewWorkSheet, ifRowIndex, ifRowIndex, 1, 10);
                                CellMerge("VAlignCentre", NewWorkSheet, ifRowIndex, ifRowIndex, 1, 10);
                                CellMerge("AlignCenter", NewWorkSheet, ifRowIndex, ifRowIndex, 1, 10);
                                CellMerge("Bold", NewWorkSheet, ifRowIndex, ifRowIndex, 1, 10);
                                CellMerge("BorderAround", NewWorkSheet, ifRowIndex, ifRowIndex, 1, 10);
                                NewWorkSheet.Cells[ifRowIndex, 1].Font.Color = Color.FromArgb(186, 12, 47);
                                NewWorkSheet.Rows[ifRowIndex].RowHeight = 30;
                                NewWorkSheet.Range["A" + ifRowIndex + ":I" + (ifRowIndex) + ""].Cells.Font.Bold = true;
                                // Set font size for the range of cells
                                NewWorkSheet.Range[NewWorkSheet.Cells[ifRowIndex, ifRowIndex], NewWorkSheet.Cells[ifRowIndex, ifRowIndex]].Font.Size = 14;

                                // Add color to the row
                                NewWorkSheet.Rows[ifRowIndex].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                                ifRowIndex = ifRowIndex + 1;
                                // Add color to the row
                                NewWorkSheet.Rows[ifRowIndex].Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.FromArgb(220, 220, 220));
                                NewWorkSheet.Range["A" + ifRowIndex + ":I" + (ifRowIndex) + ""].Cells.Font.Bold = true;
                                NewWorkSheet.Rows[ifRowIndex].RowHeight = 20;
                                // Set font size for the range of cells
                                NewWorkSheet.Range[NewWorkSheet.Cells[ifRowIndex, ifRowIndex], NewWorkSheet.Cells[ifRowIndex, ifRowIndex]].Font.Size = 12;
                                int ifColumnIndex = 0;
                                CellMerge("GridLines", NewWorkSheet, (ifRowIndex), ((ifRowIndex)), 1, 10);
                                foreach (DataColumn col in fnProjectCategory.Columns)
                                {
                                    ifColumnIndex = ifColumnIndex + 1;
                                    // Assuming you want to merge cells in each row based on this loop
                                    NewWorkSheet.Rows[ifRowIndex].RowHeight = 20;
                                    CellMerge("GridLines", NewWorkSheet, (ifRowIndex), (ifRowIndex + ifColumnIndex), 1, 10);
                                    if (ifColumnIndex == 5)
                                    {
                                        NewWorkSheet.Cells[ifRowIndex, ifColumnIndex].Value = col.ColumnName;
                                        //NewWorkSheet.get_Range("E1", "J1").Cells.RowHeight = 65;
                                        NewWorkSheet.Columns[5].ColumnWidth = 60;
                                        NewWorkSheet.Range["A" + ifRowIndex + ":I" + ifRowIndex].Cells.WrapText = true;
                                    }

                                    NewWorkSheet.Cells[ifRowIndex, ifColumnIndex].Value = col.ColumnName;
                                    NewWorkSheet.Columns[ifColumnIndex].ColumnWidth = 60;
                                    NewWorkSheet.Range["A" + ifRowIndex + ":I" + ifRowIndex].Cells.WrapText = true;
                                    string productCategoryValue1 = col.ColumnName;

                                    NewWorkSheet.Range[NewWorkSheet.Cells[ifRowIndex, ifRowIndex], NewWorkSheet.Cells[ifRowIndex, ifRowIndex]].Font.Size = 12;
                                    //MessageBox.Show(productCategoryValue1);


                                }

                                foreach (DataRow row1 in fnProjectCategory.Rows)
                                {
                                    ifRowIndex = ifRowIndex + 1;
                                    NewWorkSheet.Range[NewWorkSheet.Cells[ifRowIndex, ifRowIndex], NewWorkSheet.Cells[ifRowIndex, ifRowIndex]].Font.Size = 12;
                                    int ifColumnIndex1 = 0;
                                    foreach (var item1 in row1.ItemArray)
                                    {
                                        ifColumnIndex1 = ifColumnIndex1 + 1;
                                        if (ifColumnIndex > 3)
                                        {
                                            NewWorkSheet.Cells[ifRowIndex, ifColumnIndex1] = item1.ToString();

                                            NewWorkSheet.Columns[5].ColumnWidth = 60;
                                            NewWorkSheet.Range["A" + ifRowIndex + ":I" + ifRowIndex].Cells.WrapText = true;

                                            // Set top-left alignment
                                            var cell = NewWorkSheet.Cells[ifRowIndex, ifColumnIndex1];
                                            cell.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignLeft;
                                            cell.VerticalAlignment = EXCEL.XlVAlign.xlVAlignTop;

                                        }

                                    }

                                }

                            }
                        }

                        // Show the data in a MessageBox
                        //MessageBox.Show(stringBuilder.ToString());

                        NewWorkSheet.Cells[1, 1].HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignCenter;
                        NewWorkSheet.get_Range("C1", "C9999").Style.VerticalAlignment = Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;


                        NewWorkSheet.Range["A1:I8"].Cells.Font.Size = 15;
                        NewWorkSheet.Range["A1:I8"].Cells.Font.Bold = true;

                        NewWorkSheet.Columns.AutoFit();
                        NewWorkSheet.get_Range("A6", "B9999").Style.HorizontalAlignment = Microsoft.Office.Interop.Excel.XlHAlign.xlHAlignGeneral;
                        NewWorkSheet.Columns[1].ColumnWidth = 25;
                        NewWorkSheet.Columns[2].ColumnWidth = 25;

                        NewWorkSheet.Columns[3].ColumnWidth = 25;
                        NewWorkSheet.Columns[4].ColumnWidth = 25;
                        NewWorkSheet.Columns[5].ColumnWidth = 40;
                        NewWorkSheet.Columns[6].ColumnWidth = 35;
                        NewWorkSheet.Columns[7].ColumnWidth = 25;
                        NewWorkSheet.Columns[8].ColumnWidth = 25;
                        NewWorkSheet.Columns[9].ColumnWidth = 25;
                        NewWorkSheet.Columns[10].ColumnWidth = 25;
                        //NewWorkSheet.Columns[1].WrapText = true;
                        //NewWorkSheet.Columns[2].WrapText = true;
                        //NewWorkSheet.Columns[3].WrapText = true;
                        //NewWorkSheet.Columns[4].WrapText = true;
                        NewWorkSheet.Columns[5].WrapText = true;
                        NewWorkSheet.Columns[6].WrapText = true;
                        NewWorkSheet.Columns[7].WrapText = true;
                        NewWorkSheet.Columns[8].WrapText = true;
                        NewWorkSheet.Columns[9].WrapText = true;
                        NewWorkSheet.Columns[10].WrapText = true;


                        NewWorkSheet.get_Range("A1", "R9999").Cells.Font.Name = "Calibri";





                        NewWorkSheet.PageSetup.PrintTitleRows = "$1:$2";
                        NewWorkSheet.PageSetup.PrintNotes = true;

                        // Fit the print area to one page wide and one page tall


                        NewWorkSheet.PageSetup.PrintArea = "A1:I" + (ifRowIndex) + "";


                        // ---------------
                        NewWorkSheet.PageSetup.RightFooter = "Page &P of &N";
                        NewWorkSheet.PageSetup.PrintNotes = true;
                       

                        NewWorkSheet.PageSetup.AlignMarginsHeaderFooter = true;
                        //NewWorkSheet.PageSetup.LeftMargin = 0.3;
                        // NewWorkSheet.PageSetup.RightMargin = 0.3;

                        NewWorkSheet.PageSetup.TopMargin = 0.1;
                        //NewWorkSheet.PageSetup.BottomMargin = 1;
                        // NewWorkSheet.PageSetup.LeftMargin = 1;
                        // NewWorkSheet.PageSetup.RightMargin = 1;
                        NewWorkSheet.PageSetup.CenterHorizontally = true;

                        // create the header range
                        //  Range headerRange = worksheet.Range["A1:J10"];

                        // set the header to repeat on each page
                        NewWorkSheet.PageSetup.PrintTitleRows = "A1:I7";

                        // -----------------





                        NewWorkSheet.PageSetup.Zoom = 100;
                        NewWorkSheet.PageSetup.Zoom = false;
                        NewWorkSheet.PageSetup.FitToPagesTall = 1;
                        NewWorkSheet.PageSetup.FitToPagesWide = 1;
                        //NewWorkSheet.PageSetup.LeftMargin = 0.25;
                        //NewWorkSheet.PageSetup.RightMargin = 0.25;
                        //NewWorkSheet.PageSetup.TopMargin = 0.75;
                        //NewWorkSheet.PageSetup.BottomMargin = 0.75;
                        NewWorkSheet.PageSetup.Orientation = Microsoft.Office.Interop.Excel.XlPageOrientation.xlPortrait;
                        NewWorkSheet.PageSetup.PaperSize = Microsoft.Office.Interop.Excel.XlPaperSize.xlPaperA4;

                        //NewWorkSheet.PrintOut(Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                        // EXCEL.Range oRange2 = (EXCEL.Range)NewWorkSheet.Cells[1, 9];
                        // Image oImage2 = Image.FromFile("C:\\Databasepath\\TQBiSSLogo.JPG");
                        // System.Windows.Forms.Clipboard.SetDataObject(oImage2, true);
                        //  NewWorkSheet.Paste(oRange2, "C:\\Databasepath\\TQBiSSLogo.JPG");

                        //  EXCEL.Range oRange1 = (EXCEL.Range)NewWorkSheet.Cells[1, 7];
                        //  Image oImage1 = Image.FromFile(Global.sITWLogo);
                        // System.Windows.Forms.Clipboard.SetDataObject(oImage1, true);
                        // NewWorkSheet.Paste(oRange1, Global.sITWLogo);


                        EXCEL.Worksheet sheet = NewWorkSheet;

                        // Logo 1
                        sheet.Shapes.AddPicture(
                            @"C:\Databasepath\TQBiSSLogo.JPG",
                            Microsoft.Office.Core.MsoTriState.msoFalse,
                            Microsoft.Office.Core.MsoTriState.msoCTrue,
                            sheet.Cells[2, 9].Left,
                            sheet.Cells[2, 9].Top,
                            -1,  // keep original width
                            -1   // keep original height
                        );

                        // Logo 2
                        sheet.Shapes.AddPicture(
                            Global.sITWLogo,
                            Microsoft.Office.Core.MsoTriState.msoFalse,
                            Microsoft.Office.Core.MsoTriState.msoCTrue,
                            sheet.Cells[2, 2].Left,
                            sheet.Cells[2, 2].Top,
                            -1,
                            -1
                        );




                        ExcelApp.Visible = false;
                        ExcelApp.Quit();
                        releaseObject(NewWorkSheet);
                        releaseObject(NewWorkBook);
                        releaseObject(ExcelApp);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }


                }
            }

            else if (comselectedprojectcode.SelectedIndex < -1)
            {
                MessageBox.Show("Select valid project code", "Error", 0, MessageBoxIcon.Error);
            }

        }




        private void CellMerge(string condition, EXCEL.Worksheet newWorkSheet, int rowIndex1, int rowIndex2, int columnIndex1, int columnIndex2)
        {
            EXCEL.Range CELLS, cell1, cell2;
            cell1 = newWorkSheet.Cells[rowIndex1, columnIndex1];
            cell2 = newWorkSheet.Cells[rowIndex2, columnIndex2];
            CELLS = (EXCEL.Range)newWorkSheet.get_Range(cell1, cell2);
            switch (condition)
            {
                case "Merge":
                    {
                        CELLS.Merge(Type.Missing);
                        break;
                    }
                case "BorderAround":
                    {
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlHairline, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }

                case "GridLines":
                    {
                        CELLS.Borders.Color = System.Drawing.Color.Black;
                        CELLS.BorderAround(EXCEL.XlLineStyle.xlContinuous, EXCEL.XlBorderWeight.xlHairline, EXCEL.XlColorIndex.xlColorIndexAutomatic, Type.Missing);
                        break;
                    }
                case "AlignCenter":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignCenter;
                        break;
                    }
                case "AlignTop":
                    {
                        CELLS.VerticalAlignment = EXCEL.XlVAlign.xlVAlignTop;
                        break;
                    }

                case "AlignRight":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignRight;
                        break;
                    }
                case "AlignLeft":
                    {
                        CELLS.HorizontalAlignment = EXCEL.XlHAlign.xlHAlignLeft;
                        break;
                    }
                case "Bold":
                    {
                        CELLS.Font.Bold = true;
                        break;
                    }
                case "AlignMiddle":

                    {

                        CELLS.VerticalAlignment = EXCEL.XlVAlign.xlVAlignCenter;

                        break;

                    }
                default:
                    {
                        break;
                    }
            }

        }



        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }





        private void comselectedprojectcode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comselectedprojectcode.SelectedIndex > -1)
            {
                string selectpcode = comselectedprojectcode.Text;
            }
        }

        private void comspecification_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comGriptype_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void ActatorType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void AllType_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Clear previous text and reset DataGridView
            textMaterialModelNO.Text = string.Empty;
            dgupdate.DataSource = null; // Clear previous data source
            dgupdate.Visible = false; // Hide DataGridView initially

            // Retrieve product description based on selected criteria
            DataTable productDescription = DAL.fnQuoteBOMItemsselectSpecification(cmbProjectcode.Text, cmbProductCategory.Text, AllType.Text, 3).Tables[0];

            // Set product code if available
            if (productDescription.Rows.Count > 0)
            {

                comspecification.Text = productDescription.Rows[0]["ProductDescription"].ToString(); // Replace "ColumnName" with the actual column name from your DataTable
                comspecification.ReadOnly = false;
                textMaterialModelNO.Text = productDescription.Rows[0]["ProductCode"].ToString();
                textMaterialModelNO.ReadOnly = true;
            }
            else
            {
                textMaterialModelNO.ReadOnly = false;
            }
            if (chkUpdatePO.Checked)
            {
                // Check if all dropdowns have selected values
                if (!string.IsNullOrEmpty(cmbProjectcode.Text) &&
                    !string.IsNullOrEmpty(AllType.Text) &&
                    !string.IsNullOrEmpty(cmbProductCategory.Text))
                {
                    var selectedProjectCode = cmbProjectcode.Text;
                    var selectedProductCategory = cmbProductCategory.Text;
                    var selectedAllType = AllType.Text;

                    // Retrieve the filtered data
                    DataTable dtPOFilter2 = DAL.fnProjectDetailsupdate(1, selectedProjectCode, selectedProductCategory, selectedAllType).Tables[0];

                    // Check if rows were retrieved
                    if (dtPOFilter2 != null && dtPOFilter2.Rows.Count > 0)
                    {
                        // Create a new DataTable to hold non-null or default values (for integers)
                        DataTable nonNullColumnsTable = new DataTable();

                        // Add only non-null or default (0 for integers) columns from the original DataTable
                        foreach (DataColumn column in dtPOFilter2.Columns)
                        {
                            bool hasNonNullOrNonZero = dtPOFilter2.AsEnumerable().Any(row =>
                            {
                                var cellValue = row[column];
                                // For integer columns, check if the value is not DBNull.Value or 0
                                if (column.DataType == typeof(int))
                                {
                                    return cellValue != DBNull.Value && (int)cellValue != 0;
                                }
                                // For non-integer columns, check if the value is not DBNull.Value
                                return cellValue != DBNull.Value;
                            });

                            if (hasNonNullOrNonZero)
                            {
                                nonNullColumnsTable.Columns.Add(column.ColumnName, column.DataType);
                            }
                        }

                        // Populate the new DataTable with rows from the original DataTable
                        foreach (DataRow row in dtPOFilter2.Rows)
                        {
                            DataRow newRow = nonNullColumnsTable.NewRow();
                            foreach (DataColumn column in nonNullColumnsTable.Columns)
                            {
                                // If it's an integer column and the value is 0, set it as DBNull.Value
                                if (dtPOFilter2.Columns[column.ColumnName].DataType == typeof(int))
                                {
                                    newRow[column.ColumnName] = row[column.ColumnName] != DBNull.Value && (int)row[column.ColumnName] != 0
                                        ? row[column.ColumnName]
                                        : DBNull.Value;
                                }
                                else
                                {
                                    newRow[column.ColumnName] = row[column.ColumnName] ?? DBNull.Value;
                                }
                            }
                            nonNullColumnsTable.Rows.Add(newRow);
                        }

                        // Ensure no extra row for input is allowed
                        dgupdate.AllowUserToAddRows = false;
                        dgItemOrProductList.Visible = false;
                        buttAdd.Visible = false;

                        // Make DataGridView visible and adjust columns
                        dgupdate.Visible = true;

                        // Set the new data source
                        dgupdate.DataSource = nonNullColumnsTable;

                        // Apply header formatting
                        dgupdate.EnableHeadersVisualStyles = false;
                        // Set row height
                        dgupdate.RowTemplate.Height = 25;

                        foreach (DataGridViewColumn column in dgupdate.Columns)
                        {
                            column.HeaderCell.Style.Font = new Font(dgupdate.Font.FontFamily, 10, FontStyle.Bold);
                            column.HeaderCell.Style.BackColor = Color.LightBlue;
                            column.HeaderCell.Style.ForeColor = Color.Black;
                        }
                        foreach (DataGridViewRow row in dgupdate.Rows)
                        {
                            foreach (DataGridViewCell cell in row.Cells)
                            {
                                // Set the font to regular (remove bold)
                                cell.Style.Font = new Font(dgupdate.Font.FontFamily, 10, FontStyle.Regular);

                                // Enable text wrapping for the cell
                                cell.Style.WrapMode = DataGridViewTriState.True;

                                // Set background and text colors
                                cell.Style.BackColor = Color.White; // Change as needed
                                cell.Style.ForeColor = Color.Black; // Change as needed
                            }
                        }

                        // Set font size for cell values
                        dgupdate.DefaultCellStyle.Font = new Font(dgupdate.Font.FontFamily, 8);

                        // Resize columns to fit content
                        dgupdate.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
                        dgupdate.DefaultCellStyle.ForeColor = Color.Black;
                        // Allow text wrapping and adjust column widths to fill the grid width
                        dgupdate.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
                        dgupdate.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                        dgupdate.DataSource = nonNullColumnsTable;
                        // Set column auto size mode to fill
                        dgupdate.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

                        // Optional: Set each column to wrap text and stretch
                        foreach (DataGridViewColumn column in dgupdate.Columns)
                        {
                            // Apply column header style
                            column.HeaderCell.Style.BackColor = Color.LightSteelBlue; // same as screenshot
                            column.HeaderCell.Style.ForeColor = Color.Black;
                            column.HeaderCell.Style.Font = new Font(dgupdate.Font.FontFamily, 9, FontStyle.Bold);

                            column.DefaultCellStyle.WrapMode = DataGridViewTriState.True;
                            column.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

                        }

                        // Optional: Set row height explicitly if needed
                        dgupdate.RowTemplate.Height = 30;
                    }





                    else
                    {
                        // Handle no data scenario
                        MessageBox.Show("No data available for the selected criteria.");
                        // Clear the DataGridView
                    }
                }
            }
            else
            {
                LoadData();
            }
        }








        private void butAccept_Click(object sender, EventArgs e)
        {
            //ApproveList.Visible = true;
            //comApproveList.Visible = true;

            try
            {
                Project_Master.MachinePassportApprovelList ProjectSearchForm = new Project_Master.MachinePassportApprovelList();
                this.Hide();
                pleasewaitform pleaseWait = new pleasewaitform();
                // Display form modelessly
                pleaseWait.Show();
                //  ALlow main UI thread to properly display please wait form.
                Application.DoEvents();
                pleaseWait.Hide();
                ProjectSearchForm.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Click On Approvel Search" + ex.Message);
            }
        }

        private void comApproveList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(cmbProjectcode.Text))
            {
                MessageBox.Show("Project code cannot be empty. Please enter a project code.");
                return;
            }

            try
            {
                pleasewaitform pleaseWait = new pleasewaitform();
                pleaseWait.Show();

                Application.DoEvents();

                // Pass the project code to the new form
                string projectCode = cmbProjectcode.Text;
                Project_Master.MachinePassportStatusView ProjectSearchForm = new Project_Master.MachinePassportStatusView(projectCode);
                this.Hide();

                pleaseWait.Hide();
                ProjectSearchForm.ShowDialog();

                this.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Click On Approval Search: " + ex.Message);
            }
        }

        private void dgItemOrProductList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        /*
            int rowcount = 0;
            private void buttAdd_Click(object sender, EventArgs e)
            {
                //Console.WriteLine("Button clicked, adding a new row.");
                dgItemOrProductList.Rows.Add(rowcount++," ");
            dgItemOrProductList.DefaultCellStyle.ForeColor = Color.Black;
            dgItemOrProductList.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
            }
        */

        private void buttAdd_Click(object sender, EventArgs e)
        {

            if (cmbProjectcode.Visible && string.IsNullOrWhiteSpace(cmbProjectcode.Text))
            {
                MessageBox.Show("Please select the project code before adding a row", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cmbProjectcode.Focus();
                return;
            }

            if (cmbProductCategory.SelectedIndex < 0)
            {
                MessageBox.Show("Please select the product category before adding a row", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cmbProductCategory.Focus();
                return;
            }


            // Determine the current row count based on existing rows
            int rowcount = dgItemOrProductList.Rows.Count + 1; // Start at 1 more than the current count

            // Add a new row
            dgItemOrProductList.Rows.Add(rowcount, " ");

            // Set default cell style color
            dgItemOrProductList.DefaultCellStyle.ForeColor = Color.Black;

            // Enable wrapping for a specific cell (e.g., the first cell in the newly added row)
            var cell = dgItemOrProductList.Rows[dgItemOrProductList.Rows.Count - 1].Cells[0] as DataGridViewTextBoxCell;
            cell.Style.WrapMode = DataGridViewTriState.True;

            // Resize columns to fit content
           // dgItemOrProductList.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);

            // Adjust the height of the row to fit the wrapped text
            dgItemOrProductList.Rows[dgItemOrProductList.Rows.Count - 1].Height = 20; // Adjust height as needed
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (cmbProjectcode.Visible && string.IsNullOrWhiteSpace(cmbProjectcode.Text))
            {
                MessageBox.Show("Please select the project code before adding a row", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cmbProjectcode.Focus();
                return;
            }

            if (cmbProductCategory.SelectedIndex < 0)
            {
                MessageBox.Show("Please select the product category before adding a row", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                cmbProductCategory.Focus();
                return;
            }



            // Add a new row
            // dgItemOrProductList.Rows.Add(rowcount++, " ");

            // Set default cell style color
            dgItemOrProductList.DefaultCellStyle.ForeColor = Color.Black;

            // Enable wrapping for a specific cell (e.g., the first cell in the newly added row)
            var cell = dgItemOrProductList.Rows[dgItemOrProductList.Rows.Count - 1].Cells[0] as DataGridViewTextBoxCell;
            cell.Style.WrapMode = DataGridViewTriState.True;

            // Resize columns to fit content
            dgItemOrProductList.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);

            // Adjust the height of the row to fit the wrapped text
            dgItemOrProductList.Rows[dgItemOrProductList.Rows.Count - 1].Height = 50; // Adjust height as needed
        }

        private void dgcommonlist_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgcommonlist_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void chkUpdatePO_CheckedChanged(object sender, EventArgs e)
        {
            {
                clear();

                dgItemOrProductList.DataSource = null;


                dtPOFilter2 = DAL.fnProjectDetailsupdate(1, cmbProjectcode.Text, cmbProductCategory.Text, AllType.Text).Tables[0];







                dtPOFilter = DAL.fnProjectDetailsupdate(2, null, null, null).Tables[0];


                DataView dvPOOrderFilter1 = new DataView(dtPOFilter);


                dvPOOrderFilter1.Sort = "ProjectCode desc";
                dtPOFilter = dvPOOrderFilter1.ToTable();

                if (dtPOFilter.Rows.Count > 0)
                {
                    foreach (DataRow DR in dtPOFilter.Rows)
                    {
                        if (!cmbProjectcode.Items.Contains(DR["ProjectCode"].ToString()))
                            cmbProjectcode.Items.Add(DR["ProjectCode"].ToString());
                    }
                    cmbProjectcode.Enabled = true;

                }



                button1.Text = "Update";
                button1.Enabled = true;
                button1.Visible = true;


            }
        }


        private void dgupdate_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textMaterialModelNO_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtMpProjectDescription_TextChanged(object sender, EventArgs e)
        {

        }

        private void textPoNo_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtMpProjectDedscription_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void fnClose()
        {
            this.Hide();
            //Project_Master.frmProjectHome Home = new Project_Master.frmProjectHome();
            Home.Show();
        }

        private void frmProjectmaster_FormClosing(object sender, FormClosingEventArgs e)
        {
            //  frmForm2 form = new frmForm2();
            fnClose();
        }
    }
}

