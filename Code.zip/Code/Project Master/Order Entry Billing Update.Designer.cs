﻿
namespace Erp_Project_With_Buttons.Project_Master
{
    partial class Order_Entry_Billing_Update
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Order_Entry_Billing_Update));
            this.label2 = new System.Windows.Forms.Label();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.buttprojectclosersave = new System.Windows.Forms.Button();
            this.updateModelNumber = new System.Windows.Forms.Label();
            this.comselectedOrderEntryNo = new System.Windows.Forms.ComboBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(401, 107);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 19);
            this.label2.TabIndex = 247;
            this.label2.Text = "Amount :";
            // 
            // txtAmount
            // 
            this.txtAmount.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtAmount.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAmount.Location = new System.Drawing.Point(489, 100);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(215, 26);
            this.txtAmount.TabIndex = 246;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(776, 55);
            this.groupBox1.TabIndex = 505;
            this.groupBox1.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(309, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 19);
            this.label5.TabIndex = 505;
            this.label5.Text = "ORDER ENTRY";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.buttprojectclosersave);
            this.groupBox2.Location = new System.Drawing.Point(102, 288);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(624, 51);
            this.groupBox2.TabIndex = 506;
            this.groupBox2.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(458, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 33);
            this.button1.TabIndex = 500;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttprojectclosersave
            // 
            this.buttprojectclosersave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.buttprojectclosersave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.buttprojectclosersave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttprojectclosersave.Location = new System.Drawing.Point(56, 12);
            this.buttprojectclosersave.Name = "buttprojectclosersave";
            this.buttprojectclosersave.Size = new System.Drawing.Size(100, 33);
            this.buttprojectclosersave.TabIndex = 498;
            this.buttprojectclosersave.Text = "Save";
            this.buttprojectclosersave.UseVisualStyleBackColor = false;
            this.buttprojectclosersave.Click += new System.EventHandler(this.buttprojectclosersave_Click);
            // 
            // updateModelNumber
            // 
            this.updateModelNumber.AutoSize = true;
            this.updateModelNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateModelNumber.Location = new System.Drawing.Point(14, 100);
            this.updateModelNumber.Name = "updateModelNumber";
            this.updateModelNumber.Size = new System.Drawing.Size(102, 16);
            this.updateModelNumber.TabIndex = 508;
            this.updateModelNumber.Text = "Project Code:";
            // 
            // comselectedOrderEntryNo
            // 
            this.comselectedOrderEntryNo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comselectedOrderEntryNo.DropDownHeight = 130;
            this.comselectedOrderEntryNo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comselectedOrderEntryNo.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comselectedOrderEntryNo.FormattingEnabled = true;
            this.comselectedOrderEntryNo.IntegralHeight = false;
            this.comselectedOrderEntryNo.Location = new System.Drawing.Point(122, 100);
            this.comselectedOrderEntryNo.Name = "comselectedOrderEntryNo";
            this.comselectedOrderEntryNo.Size = new System.Drawing.Size(197, 26);
            this.comselectedOrderEntryNo.TabIndex = 507;
            this.comselectedOrderEntryNo.SelectedIndexChanged += new System.EventHandler(this.comselectedOrderEntryNo_SelectedIndexChanged);
            // 
            // Order_Entry_Billing_Update
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.updateModelNumber);
            this.Controls.Add(this.comselectedOrderEntryNo);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtAmount);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Order_Entry_Billing_Update";
            this.Text = "Order_Entry_Billing_Update";
            this.Load += new System.EventHandler(this.Order_Entry_Billing_Update_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button buttprojectclosersave;
        private System.Windows.Forms.Label updateModelNumber;
        private System.Windows.Forms.ComboBox comselectedOrderEntryNo;
    }
}