﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Project_Master
{
    public partial class MachinePassportUpdate : Form
    {
        public MachinePassportUpdate()
        {
            InitializeComponent();
        }
        DataTable dtProductCategory = new DataTable();
        DataAccessLayer DAL = new DataAccessLayer();
        Machine_Passport frm = new Machine_Passport();
        Global GLobalClass = new Global();
        Login.frmLoginForm login = new Login.frmLoginForm();

        //Global GlobalClass = new Global();

       

        private void comselectedprojectcode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comselectedprojectcode.SelectedItem != null)
            {
                DataTable dtmachinepassportprojectcode = DAL.MachinePassportupdateselectdata(1, comselectedprojectcode.Text).Tables[0];

                if (dtmachinepassportprojectcode != null && dtmachinepassportprojectcode.Rows.Count > 0)
                {
                    if (dtmachinepassportprojectcode.Columns.Contains("ProductCodeModelNumber"))
                    {
                        string Deviation = dtmachinepassportprojectcode.Rows[0]["Deviation"]?.ToString();
                        if (string.IsNullOrEmpty(Deviation))

                        {

                            MessageBox.Show("Deviation is null or empty");

                        }

                        else

                        {

                            comDeviation.Text = Deviation;

                        }
                    }
                    else
                    {
                        MessageBox.Show("Column ProductCodeModelNumber does not exist");
                    }
                }
                else
                {
                    MessageBox.Show("No data returned from DAL.MachinePassportupdateselectdata");
                }
            }
            else
            {
                MessageBox.Show("comselectedprojectcode.SelectedItem is null");
            }
        }



        private void MachinePassportUpdate_Load_1(object sender, EventArgs e)
        {
            dtProductCategory = DAL.MachinePassportupdateselectdata(0, null).Tables[0];

            DataSet dataset = DAL.MachinePassportupdateselectdata(0, null);
            Console.WriteLine($"Rows retrieved for case 0: {dataset.Tables[0].Rows.Count}");


            if (dtProductCategory.Rows.Count > 0)
            {
                foreach (DataRow DR in dtProductCategory.Rows)
                {
                    if (!comselectedprojectcode.Items.Contains(DR["ProductCodeModelNumber"].ToString()))
                        comselectedprojectcode.Items.Add(DR["ProductCodeModelNumber"].ToString());
                }
            }
        }

        private void comDeviation_TextChanged(object sender, EventArgs e)
        {

        }

        private void butAccept_Click(object sender, EventArgs e)

        {
            if (comselectedprojectcode.SelectedIndex < 0)

            {
                MessageBox.Show("Please select an Product Code.");
                return;

            }
            else if (string.IsNullOrWhiteSpace(comDeviation.Text))

            {
                MessageBox.Show("Enter Deviation", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                comDeviation.Focus();

            }

            else

            {

                GLobalClass.iSuccess = DAL.fnMpUpdateDeviation(1, comselectedprojectcode.Text, comDeviation.Text, login.GetUserDetails[2].ToString());

                MessageBox.Show("Machine Passport update", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Hide();

                Machine_Passport machinepassport = new Machine_Passport();

                machinepassport.Show();

            }

        }
        private void fnFormShow(Form Frm)
        {
            this.Hide();
            pleasewaitform pleaseWait = new pleasewaitform();
            pleaseWait.Show();
            Application.DoEvents();
            Frm.Show();
            pleaseWait.Hide();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            frm.Show();
        }
    }
}