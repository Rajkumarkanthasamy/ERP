﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Erp_Project_With_Buttons.Project_Master
{
    public partial class frmProjectUpdate : Form
    {
        public frmProjectUpdate()
        {
            InitializeComponent();
        }
        Global GlobalClass = new Global();
        DataAccessLayer DAL = new DataAccessLayer();
        frmForm2 frm = new frmForm2();
        frmProjectmaster form = new frmProjectmaster();
        Login.frmLoginForm login = new Login.frmLoginForm();
        DataTable dtProjectList = new DataTable();
        private void frmProjectUpdate_Load(object sender, EventArgs e)
        {
            chkProjectList.Items.Clear();
            fnProjectLoad();

        }


        private void fnProjectLoad()
        {
            dtProjectList = DAL.fnProjectList(null).Tables[0];

        }
        private void btnExit_Click(object sender, EventArgs e)
        {
            fnClose();
        }

        private void fnClose()
        {
            this.Hide();
            frm.Show();
        }

        private void fnReload()
        {
            this.Hide();
            frmProjectUpdate PrjUpdate = new frmProjectUpdate();
            PrjUpdate.Show();
        }

        private void frmProjectUpdate_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnClose();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            sProjectCode = "";
            sProjectDesc = "";
            bProject = false;
            sProjectCode = txtPMProjectCode.Text;
            sProjectDesc = txtPMProjectDescription.Text;

            bool bWarrantyValid = false;
            bool bSSValid = false;

            if (chkWarranty.Checked)
            {
                if (string.IsNullOrEmpty(txtWarrantyMonths.Text))
                {
                    MessageBox.Show("Update the warranty months to create warranty code.", "Error", 0, MessageBoxIcon.Error);
                    bWarrantyValid = false;
                }

                else if (!bWarrantydate)
                {
                    MessageBox.Show("Select the warranty start date to create warranty code.", "Error", 0, MessageBoxIcon.Error);
                    bWarrantyValid = false;
                }

                else
                {
                    bWarrantyValid = true;
                }
            }
            else
            {
                bWarrantyValid = true;
            }
            if (chkShortshipment.Checked)
            {
                if (string.IsNullOrEmpty(txtShortShipdays.Text))
                {
                    MessageBox.Show("Enter the short shipment days to create short shipment code.", "Error", 0, MessageBoxIcon.Error);
                    txtShortShipdays.Focus();
                    bSSValid = false;
                }

                else if (!bShortShipdate)
                {
                    MessageBox.Show("Select the short shipment start date to create short shipment code.", "Error", 0, MessageBoxIcon.Error);
                    bSSValid = false;
                }
                else
                {
                    bSSValid = true;
                }
            }
            else
            {
                bSSValid = true;
            }



            if (bWarrantyValid && bSSValid)
            {
                if (chkWarranty.Checked)
                {
                    GlobalClass.iStatus = DAL.fnAddProject(Global.uINSERT, (sProjectCode + " -W"), (sProjectDesc + " -Warranty"),"","", dtpDate.Text,
                                                      txtCustomerName.Text, "", "WIP", "", "", "", login.GetUserDetails[2], "", txtcuscode.Text, true, "", "", "", "", "", "");
                    GlobalClass.iStatus = DAL.fnAddShortShipment(44, dtpCLosedate.Text, false, dtpStartDate.Text, (sProjectCode + " -W"));
                    MessageBox.Show("Warranty project " + (sProjectCode + " -W") + " created.");
                }

                if (chkShortshipment.Checked)
                {
                    GlobalClass.iStatus = DAL.fnAddProject(Global.uINSERT, (sProjectCode + " -SS"), (sProjectDesc + " -Short Shipment"),"","", dtpDate.Text,
                                               txtCustomerName.Text, "", "WIP", "", "", "", login.GetUserDetails[2], "", txtcuscode.Text, true, "", "", "", "", "", "");
                    GlobalClass.iStatus = DAL.fnAddShortShipment(44, dtpShortShipClose.Text, false, dtpShortShipDate.Text, (sProjectCode + " -SS"));
                    MessageBox.Show("Shortshipent project " + (sProjectCode + " -SS") + " created.");
                }
                fnProjectStatus();
                MessageBox.Show("Project " + txtPMProjectCode.Text + " updated successfully");

                fnReload();
            }
        }


        private void fnProjectStatus()
        {
            GlobalClass.iStatus = DAL.fnAddProjectUpdate(Global.uUPDATE, txtPMProjectCode.Text, txtPMProjectDescription.Text, cmbPMProjectStatus.Text, "");
            GlobalClass.iStatus = DAL.fnAddProjectStatus(0, txtPMProjectCode.Text, txtPMProjectDescription.Text, login.GetUserDetails[2], cmbPMProjectStatus.Text, dtpChangedate.Text);

            dtProjectList = DAL.fnProjectList(null).Tables[0];
            btnSave.Enabled = false;
        }

        DataTable dtProjectHistory = new DataTable();
        DataTable dtOrderentry = new DataTable();
        private void chkProjectList_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            btnSave.Enabled = true;
            txtWarrantyStartsFrom.ResetText();
            txtWarrantyMonths.ResetText();
            if (!chkProjectList.CheckedItems.Contains(chkProjectList.SelectedItem))
            {
                string[] sProjectCode = chkProjectList.SelectedItem.ToString().Trim().Split('`');
                DataView dvProjectName = new DataView(dtProjectList);
                dvProjectName.RowFilter = "ProjectCode='" + sProjectCode[0] + "'";
                if (dvProjectName.ToTable().Rows.Count > 0)
                {
                    txtPMProjectCode.Text = dvProjectName.ToTable().Rows[0]["ProjectCode"].ToString();
                    txtPMProjectDescription.Text = dvProjectName.ToTable().Rows[0]["ProjectDescription"].ToString();
                    cmbPMProjectStatus.SelectedItem = dvProjectName.ToTable().Rows[0]["Status"].ToString();
                    txtCustomerName.Text = dvProjectName.ToTable().Rows[0]["Customer"].ToString();
                    txtcuscode.Text = dvProjectName.ToTable().Rows[0]["CustomerCode"].ToString();
                    txtWarrantyStartsFrom.Text = dvProjectName.ToTable().Rows[0]["WarrantyStartsFrom"].ToString();
                    dtOrderentry = DAL.fnProjectOrderEntry(txtPMProjectCode.Text, 1).Tables[0];
                    if (dtOrderentry.Rows.Count > 0)
                    {
                        txtWarrantyMonths.Text = dtOrderentry.Rows[0]["WarrantyPeriod"].ToString();
                    }

                    var result = txtPMProjectCode.Text.Substring(txtPMProjectCode.Text.Length - 1);
                    if (result.ToString() == "S" || result.ToString() == "W")
                    {
                        result = txtPMProjectCode.Text.Remove(txtPMProjectCode.Text.Length - 3, 3);
                        dtProjectHistory = DAL.fnProjectListWithEndDate(4, result.Trim(), null).Tables[0];
                    }
                    else
                    {
                        dtProjectHistory = DAL.fnProjectListWithEndDate(4, txtPMProjectCode.Text, null).Tables[0];
                    }

                    if (dtProjectHistory.Rows.Count > 0)
                    {
                        dgvProjHistory.AutoGenerateColumns = false;
                        dgvProjHistory.DataSource = dtProjectHistory;

                        chkWarranty.Enabled = true;
                        chkShortshipment.Enabled = true;
                        pnWarranty.Enabled = false;
                        pnShortShipment.Enabled = false;

                        foreach (DataRow dr in dtProjectHistory.Rows)
                        {
                            if (dr[1].ToString() == "W")
                            {
                                chkWarranty.Checked = false;
                                chkWarranty.Enabled = false;
                                pnWarranty.Enabled = false;
                            }
                            else if (dr[1].ToString() == "S")
                            {
                                chkShortshipment.Checked = false;
                                chkShortshipment.Enabled = false;
                                pnShortShipment.Enabled = false;
                            }
                        }
                    }
                }
            }
        }

        private void txtprojectname_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
            {
                Row();
            }
            else
            {
                Row();
            }
        }
        private void Row()
        {
            dvItemList = RowFilter(dtProjectList, txtprojectname.Text);
            RowFilter();
        }

        private void RowFilter()
        {
            chkProjectList.Items.Clear();
            foreach (DataRowView dr in dvItemList)
            {
                chkProjectList.Items.Add(string.Concat(dr["ProjectCode"].ToString(), "`", dr["ProjectDescription"].ToString(), ", ", dr["Customer"].ToString(), ", ", dr["Status"].ToString()));
            }
        }
        DataView dvItemList = new DataView();
        public DataView RowFilter(DataTable dtProject, string sRowfilter)
        {
            if (sRowfilter.Length > 0)
            {
                dvItemList = new DataView(dtProject);
                dvItemList.RowFilter = "ProjectCode like '%" + sRowfilter + "%' or ProjectDescription like '%" + sRowfilter + "%' or Customer like '%" + sRowfilter + "%'";
            }

            return dvItemList;
        }

        private void txtprojectname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar == '%'))
            {
                e.Handled = true;
            }
        }


        string sProjectCode;
        string sProjectDesc;
        bool bProject = true;
       

        bool bWarrantydate = false;
        bool bShortShipdate = false;


        private void dtpStartDate_ValueChanged(object sender, EventArgs e)
        {
            bWarrantydate = false;
            if (!string.IsNullOrEmpty(txtWarrantyMonths.Text))
            {
                if (Convert.ToInt32(txtWarrantyMonths.Text) > 0)
                {
                    bWarrantydate = true;
                    dtpCLosedate.Value = dtpStartDate.Value.AddMonths(Convert.ToInt32(txtWarrantyMonths.Text));
                    dtpCLosedate.Value = dtpCLosedate.Value.AddDays(-1);
                }
            }
            else
            {
                MessageBox.Show("Update the warranty months to create warranty code.", "Error", 0, MessageBoxIcon.Error);
            }
        }

        private void dtpShortShipDate_ValueChanged(object sender, EventArgs e)
        {
            bShortShipdate = false;
            if (!string.IsNullOrEmpty(txtShortShipdays.Text))
            {
                if (Convert.ToInt32(txtShortShipdays.Text) > 0)
                {
                    bShortShipdate = true;
                    dtpShortShipClose.Value = dtpStartDate.Value.AddDays(Convert.ToInt32(txtShortShipdays.Text));
                    dtpShortShipClose.Value = dtpShortShipClose.Value.AddDays(-1);
                }
            }
            else
            {
                MessageBox.Show("Enter the short shipment days to create short shipment code.", "Error", 0, MessageBoxIcon.Error);
                txtShortShipdays.Focus();
            }
        }

        private void chkWarranty_CheckedChanged(object sender, EventArgs e)
        {
            if (chkWarranty.Checked)
            {
                pnWarranty.Enabled = true;
            }
            else
            {
                pnWarranty.Enabled = false;
            }
        }

        private void chkShortshipment_CheckedChanged(object sender, EventArgs e)
        {
            if (chkShortshipment.Checked)
            {
                pnShortShipment.Enabled = true;
            }
            else
            {
                pnShortShipment.Enabled = false;
            }
        }
    }
}
