﻿namespace Erp_Project_With_Buttons.Project_Master
{
    partial class frmProjectInstall
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProjectInstall));
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtPMProjectDescription = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtMarketingInteractions = new System.Windows.Forms.TextBox();
            this.txtWarrantyMonths = new System.Windows.Forms.TextBox();
            this.txtApplicationuserfriendly = new System.Windows.Forms.TextBox();
            this.dtpStartDate = new System.Windows.Forms.DateTimePicker();
            this.label18 = new System.Windows.Forms.Label();
            this.txtMachineUserfriendly = new System.Windows.Forms.TextBox();
            this.dtpCLosedate = new System.Windows.Forms.DateTimePicker();
            this.txtequipementpackingquality = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtqualityofinteractions = new System.Windows.Forms.TextBox();
            this.txtQualityofbissreports = new System.Windows.Forms.TextBox();
            this.txtQualityofbissproducts = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.cmbApplicationuserfriendly = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbMachineUserfriendly = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbequipementpackingquality = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbqualityofinteractions = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbQualityofbissreports = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbQualityofbissproducts = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbMarketingInteractions = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnUploadDoc = new System.Windows.Forms.Button();
            this.btnclear = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.txtRemarks = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtAssetSerialNo = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.dtpInstallationDate = new System.Windows.Forms.DateTimePicker();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtDesignationofSigned = new System.Windows.Forms.TextBox();
            this.cmbProjectcode = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnProjectSearch = new System.Windows.Forms.Button();
            this.txtPersonSigned = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.cmbProjectStatus = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtInstallationformno = new System.Windows.Forms.TextBox();
            this.panel2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txtCustomerName);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.txtPMProjectDescription);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.txtMarketingInteractions);
            this.panel2.Controls.Add(this.txtWarrantyMonths);
            this.panel2.Controls.Add(this.txtApplicationuserfriendly);
            this.panel2.Controls.Add(this.dtpStartDate);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.txtMachineUserfriendly);
            this.panel2.Controls.Add(this.dtpCLosedate);
            this.panel2.Controls.Add(this.txtequipementpackingquality);
            this.panel2.Controls.Add(this.label19);
            this.panel2.Controls.Add(this.txtqualityofinteractions);
            this.panel2.Controls.Add(this.txtQualityofbissreports);
            this.panel2.Controls.Add(this.txtQualityofbissproducts);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.cmbApplicationuserfriendly);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.cmbMachineUserfriendly);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.cmbequipementpackingquality);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.cmbqualityofinteractions);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.cmbQualityofbissreports);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.cmbQualityofbissproducts);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.cmbMarketingInteractions);
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Controls.Add(this.txtRemarks);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.txtAssetSerialNo);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.dtpInstallationDate);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.txtDesignationofSigned);
            this.panel2.Controls.Add(this.cmbProjectcode);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.btnProjectSearch);
            this.panel2.Controls.Add(this.txtPersonSigned);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.cmbProjectStatus);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.txtInstallationformno);
            this.panel2.Location = new System.Drawing.Point(12, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1231, 565);
            this.panel2.TabIndex = 138;
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Enabled = false;
            this.txtCustomerName.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtCustomerName.Location = new System.Drawing.Point(178, 118);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(280, 26);
            this.txtCustomerName.TabIndex = 198;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(59, 65);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(114, 19);
            this.label20.TabIndex = 196;
            this.label20.Text = "Project Name*:";
            // 
            // txtPMProjectDescription
            // 
            this.txtPMProjectDescription.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtPMProjectDescription.Location = new System.Drawing.Point(178, 63);
            this.txtPMProjectDescription.Multiline = true;
            this.txtPMProjectDescription.Name = "txtPMProjectDescription";
            this.txtPMProjectDescription.ReadOnly = true;
            this.txtPMProjectDescription.Size = new System.Drawing.Size(280, 53);
            this.txtPMProjectDescription.TabIndex = 195;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(85, 118);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(86, 19);
            this.label21.TabIndex = 197;
            this.label21.Text = "Customer*:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(15, 420);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(157, 19);
            this.label17.TabIndex = 169;
            this.label17.Text = "warranty Start date*:";
            // 
            // txtMarketingInteractions
            // 
            this.txtMarketingInteractions.Enabled = false;
            this.txtMarketingInteractions.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtMarketingInteractions.Location = new System.Drawing.Point(996, 37);
            this.txtMarketingInteractions.Multiline = true;
            this.txtMarketingInteractions.Name = "txtMarketingInteractions";
            this.txtMarketingInteractions.Size = new System.Drawing.Size(230, 47);
            this.txtMarketingInteractions.TabIndex = 194;
            // 
            // txtWarrantyMonths
            // 
            this.txtWarrantyMonths.Enabled = false;
            this.txtWarrantyMonths.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWarrantyMonths.Location = new System.Drawing.Point(178, 473);
            this.txtWarrantyMonths.Name = "txtWarrantyMonths";
            this.txtWarrantyMonths.ReadOnly = true;
            this.txtWarrantyMonths.Size = new System.Drawing.Size(76, 26);
            this.txtWarrantyMonths.TabIndex = 172;
            // 
            // txtApplicationuserfriendly
            // 
            this.txtApplicationuserfriendly.Enabled = false;
            this.txtApplicationuserfriendly.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtApplicationuserfriendly.Location = new System.Drawing.Point(996, 388);
            this.txtApplicationuserfriendly.Multiline = true;
            this.txtApplicationuserfriendly.Name = "txtApplicationuserfriendly";
            this.txtApplicationuserfriendly.Size = new System.Drawing.Size(230, 47);
            this.txtApplicationuserfriendly.TabIndex = 193;
            // 
            // dtpStartDate
            // 
            this.dtpStartDate.CustomFormat = "";
            this.dtpStartDate.Enabled = false;
            this.dtpStartDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpStartDate.Location = new System.Drawing.Point(178, 420);
            this.dtpStartDate.Name = "dtpStartDate";
            this.dtpStartDate.Size = new System.Drawing.Size(104, 26);
            this.dtpStartDate.TabIndex = 167;
            this.dtpStartDate.ValueChanged += new System.EventHandler(this.dtpStartDate_ValueChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(23, 461);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(148, 38);
            this.label18.TabIndex = 171;
            this.label18.Text = "Warranty in Months\r\nof Project:";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtMachineUserfriendly
            // 
            this.txtMachineUserfriendly.Enabled = false;
            this.txtMachineUserfriendly.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtMachineUserfriendly.Location = new System.Drawing.Point(996, 329);
            this.txtMachineUserfriendly.Multiline = true;
            this.txtMachineUserfriendly.Name = "txtMachineUserfriendly";
            this.txtMachineUserfriendly.Size = new System.Drawing.Size(230, 47);
            this.txtMachineUserfriendly.TabIndex = 192;
            // 
            // dtpCLosedate
            // 
            this.dtpCLosedate.CustomFormat = "";
            this.dtpCLosedate.Enabled = false;
            this.dtpCLosedate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpCLosedate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpCLosedate.Location = new System.Drawing.Point(385, 420);
            this.dtpCLosedate.Name = "dtpCLosedate";
            this.dtpCLosedate.Size = new System.Drawing.Size(104, 26);
            this.dtpCLosedate.TabIndex = 168;
            // 
            // txtequipementpackingquality
            // 
            this.txtequipementpackingquality.Enabled = false;
            this.txtequipementpackingquality.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtequipementpackingquality.Location = new System.Drawing.Point(996, 268);
            this.txtequipementpackingquality.Multiline = true;
            this.txtequipementpackingquality.Name = "txtequipementpackingquality";
            this.txtequipementpackingquality.Size = new System.Drawing.Size(230, 47);
            this.txtequipementpackingquality.TabIndex = 191;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(288, 425);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(91, 19);
            this.label19.TabIndex = 170;
            this.label19.Text = "Close date*:";
            // 
            // txtqualityofinteractions
            // 
            this.txtqualityofinteractions.Enabled = false;
            this.txtqualityofinteractions.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtqualityofinteractions.Location = new System.Drawing.Point(996, 212);
            this.txtqualityofinteractions.Multiline = true;
            this.txtqualityofinteractions.Name = "txtqualityofinteractions";
            this.txtqualityofinteractions.Size = new System.Drawing.Size(230, 47);
            this.txtqualityofinteractions.TabIndex = 190;
            // 
            // txtQualityofbissreports
            // 
            this.txtQualityofbissreports.Enabled = false;
            this.txtQualityofbissreports.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtQualityofbissreports.Location = new System.Drawing.Point(996, 151);
            this.txtQualityofbissreports.Multiline = true;
            this.txtQualityofbissreports.Name = "txtQualityofbissreports";
            this.txtQualityofbissreports.Size = new System.Drawing.Size(230, 47);
            this.txtQualityofbissreports.TabIndex = 189;
            // 
            // txtQualityofbissproducts
            // 
            this.txtQualityofbissproducts.Enabled = false;
            this.txtQualityofbissproducts.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtQualityofbissproducts.Location = new System.Drawing.Point(996, 97);
            this.txtQualityofbissproducts.Multiline = true;
            this.txtQualityofbissproducts.Name = "txtQualityofbissproducts";
            this.txtQualityofbissproducts.Size = new System.Drawing.Size(230, 47);
            this.txtQualityofbissproducts.TabIndex = 188;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(620, 388);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(156, 38);
            this.label16.TabIndex = 186;
            this.label16.Text = "User friendliness of \r\napplication software :";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cmbApplicationuserfriendly
            // 
            this.cmbApplicationuserfriendly.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbApplicationuserfriendly.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbApplicationuserfriendly.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbApplicationuserfriendly.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbApplicationuserfriendly.FormattingEnabled = true;
            this.cmbApplicationuserfriendly.Items.AddRange(new object[] {
            "Excellent",
            "Good",
            "Satisfactory",
            "UnSatisfactory"});
            this.cmbApplicationuserfriendly.Location = new System.Drawing.Point(786, 396);
            this.cmbApplicationuserfriendly.Name = "cmbApplicationuserfriendly";
            this.cmbApplicationuserfriendly.Size = new System.Drawing.Size(199, 26);
            this.cmbApplicationuserfriendly.TabIndex = 187;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(553, 340);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(223, 19);
            this.label5.TabIndex = 184;
            this.label5.Text = "Machine User Manual friendly :";
            // 
            // cmbMachineUserfriendly
            // 
            this.cmbMachineUserfriendly.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbMachineUserfriendly.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbMachineUserfriendly.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMachineUserfriendly.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbMachineUserfriendly.FormattingEnabled = true;
            this.cmbMachineUserfriendly.Items.AddRange(new object[] {
            "Excellent",
            "Good",
            "Satisfactory",
            "UnSatisfactory"});
            this.cmbMachineUserfriendly.Location = new System.Drawing.Point(786, 338);
            this.cmbMachineUserfriendly.Name = "cmbMachineUserfriendly";
            this.cmbMachineUserfriendly.Size = new System.Drawing.Size(199, 26);
            this.cmbMachineUserfriendly.TabIndex = 185;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(575, 282);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(201, 19);
            this.label7.TabIndex = 182;
            this.label7.Text = "Equipment packing quality :";
            // 
            // cmbequipementpackingquality
            // 
            this.cmbequipementpackingquality.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbequipementpackingquality.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbequipementpackingquality.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbequipementpackingquality.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbequipementpackingquality.FormattingEnabled = true;
            this.cmbequipementpackingquality.Items.AddRange(new object[] {
            "Excellent",
            "Good",
            "Satisfactory",
            "UnSatisfactory"});
            this.cmbequipementpackingquality.Location = new System.Drawing.Point(786, 280);
            this.cmbequipementpackingquality.Name = "cmbequipementpackingquality";
            this.cmbequipementpackingquality.Size = new System.Drawing.Size(199, 26);
            this.cmbequipementpackingquality.TabIndex = 183;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(544, 221);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(232, 19);
            this.label4.TabIndex = 180;
            this.label4.Text = "Interaction with BiSS Personnel :";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cmbqualityofinteractions
            // 
            this.cmbqualityofinteractions.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbqualityofinteractions.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbqualityofinteractions.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbqualityofinteractions.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbqualityofinteractions.FormattingEnabled = true;
            this.cmbqualityofinteractions.Items.AddRange(new object[] {
            "Excellent",
            "Good",
            "Satisfactory",
            "UnSatisfactory"});
            this.cmbqualityofinteractions.Location = new System.Drawing.Point(786, 219);
            this.cmbqualityofinteractions.Name = "cmbqualityofinteractions";
            this.cmbqualityofinteractions.Size = new System.Drawing.Size(199, 26);
            this.cmbqualityofinteractions.TabIndex = 181;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(601, 160);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(175, 19);
            this.label3.TabIndex = 178;
            this.label3.Text = "Quality of BiSS Reports :";
            // 
            // cmbQualityofbissreports
            // 
            this.cmbQualityofbissreports.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbQualityofbissreports.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbQualityofbissreports.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbQualityofbissreports.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbQualityofbissreports.FormattingEnabled = true;
            this.cmbQualityofbissreports.Items.AddRange(new object[] {
            "Excellent",
            "Good",
            "Satisfactory",
            "UnSatisfactory"});
            this.cmbQualityofbissreports.Location = new System.Drawing.Point(786, 158);
            this.cmbQualityofbissreports.Name = "cmbQualityofbissreports";
            this.cmbQualityofbissreports.Size = new System.Drawing.Size(199, 26);
            this.cmbQualityofbissreports.TabIndex = 179;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(593, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(183, 19);
            this.label2.TabIndex = 176;
            this.label2.Text = "Quality of BiSS Products :";
            // 
            // cmbQualityofbissproducts
            // 
            this.cmbQualityofbissproducts.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbQualityofbissproducts.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbQualityofbissproducts.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbQualityofbissproducts.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbQualityofbissproducts.FormattingEnabled = true;
            this.cmbQualityofbissproducts.Items.AddRange(new object[] {
            "Excellent",
            "Good",
            "Satisfactory",
            "UnSatisfactory"});
            this.cmbQualityofbissproducts.Location = new System.Drawing.Point(786, 101);
            this.cmbQualityofbissproducts.Name = "cmbQualityofbissproducts";
            this.cmbQualityofbissproducts.Size = new System.Drawing.Size(199, 26);
            this.cmbQualityofbissproducts.TabIndex = 177;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(604, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(172, 19);
            this.label1.TabIndex = 174;
            this.label1.Text = "Marketing Interactions :";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cmbMarketingInteractions
            // 
            this.cmbMarketingInteractions.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbMarketingInteractions.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbMarketingInteractions.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMarketingInteractions.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbMarketingInteractions.FormattingEnabled = true;
            this.cmbMarketingInteractions.Items.AddRange(new object[] {
            "Excellent",
            "Good",
            "Satisfactory",
            "UnSatisfactory"});
            this.cmbMarketingInteractions.Location = new System.Drawing.Point(786, 44);
            this.cmbMarketingInteractions.Name = "cmbMarketingInteractions";
            this.cmbMarketingInteractions.Size = new System.Drawing.Size(199, 26);
            this.cmbMarketingInteractions.TabIndex = 175;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnUploadDoc);
            this.groupBox2.Controls.Add(this.btnclear);
            this.groupBox2.Controls.Add(this.btnSave);
            this.groupBox2.Controls.Add(this.btnExit);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox2.Location = new System.Drawing.Point(557, 496);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(669, 63);
            this.groupBox2.TabIndex = 173;
            this.groupBox2.TabStop = false;
            // 
            // btnUploadDoc
            // 
            this.btnUploadDoc.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnUploadDoc.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnUploadDoc.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUploadDoc.Location = new System.Drawing.Point(88, 18);
            this.btnUploadDoc.Name = "btnUploadDoc";
            this.btnUploadDoc.Size = new System.Drawing.Size(151, 39);
            this.btnUploadDoc.TabIndex = 110;
            this.btnUploadDoc.Text = "Upload Document";
            this.btnUploadDoc.UseVisualStyleBackColor = false;
            // 
            // btnclear
            // 
            this.btnclear.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnclear.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnclear.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclear.Location = new System.Drawing.Point(413, 18);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(90, 39);
            this.btnclear.TabIndex = 109;
            this.btnclear.Text = "Clear all";
            this.btnclear.UseVisualStyleBackColor = false;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(281, 18);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(90, 39);
            this.btnSave.TabIndex = 11;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnExit.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(541, 18);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(90, 39);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // txtRemarks
            // 
            this.txtRemarks.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtRemarks.Location = new System.Drawing.Point(178, 357);
            this.txtRemarks.Multiline = true;
            this.txtRemarks.Name = "txtRemarks";
            this.txtRemarks.Size = new System.Drawing.Size(280, 47);
            this.txtRemarks.TabIndex = 172;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(96, 357);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(75, 19);
            this.label15.TabIndex = 171;
            this.label15.Text = "Remarks :";
            // 
            // txtAssetSerialNo
            // 
            this.txtAssetSerialNo.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtAssetSerialNo.Location = new System.Drawing.Point(178, 320);
            this.txtAssetSerialNo.Name = "txtAssetSerialNo";
            this.txtAssetSerialNo.Size = new System.Drawing.Size(280, 26);
            this.txtAssetSerialNo.TabIndex = 170;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(45, 322);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(127, 19);
            this.label14.TabIndex = 169;
            this.label14.Text = "Asset Serial No *:";
            // 
            // dtpInstallationDate
            // 
            this.dtpInstallationDate.CustomFormat = "";
            this.dtpInstallationDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpInstallationDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpInstallationDate.Location = new System.Drawing.Point(178, 2);
            this.dtpInstallationDate.Name = "dtpInstallationDate";
            this.dtpInstallationDate.Size = new System.Drawing.Size(125, 26);
            this.dtpInstallationDate.TabIndex = 168;
            this.dtpInstallationDate.ValueChanged += new System.EventHandler(this.dtpInstallationDate_ValueChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(1029, 7);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(136, 19);
            this.label6.TabIndex = 136;
            this.label6.Text = "Rating Comments :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(71, 37);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 19);
            this.label8.TabIndex = 20;
            this.label8.Text = "Project Code:";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // txtDesignationofSigned
            // 
            this.txtDesignationofSigned.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtDesignationofSigned.Location = new System.Drawing.Point(178, 276);
            this.txtDesignationofSigned.Name = "txtDesignationofSigned";
            this.txtDesignationofSigned.Size = new System.Drawing.Size(280, 26);
            this.txtDesignationofSigned.TabIndex = 135;
            // 
            // cmbProjectcode
            // 
            this.cmbProjectcode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProjectcode.DropDownHeight = 130;
            this.cmbProjectcode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProjectcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProjectcode.FormattingEnabled = true;
            this.cmbProjectcode.IntegralHeight = false;
            this.cmbProjectcode.Location = new System.Drawing.Point(178, 33);
            this.cmbProjectcode.Name = "cmbProjectcode";
            this.cmbProjectcode.Size = new System.Drawing.Size(280, 26);
            this.cmbProjectcode.TabIndex = 21;
            this.cmbProjectcode.SelectedIndexChanged += new System.EventHandler(this.cmbProjectcode_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(13, 268);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(159, 38);
            this.label9.TabIndex = 134;
            this.label9.Text = "Designation of signed \r\nAuthority";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnProjectSearch
            // 
            this.btnProjectSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnProjectSearch.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProjectSearch.Location = new System.Drawing.Point(464, 32);
            this.btnProjectSearch.Name = "btnProjectSearch";
            this.btnProjectSearch.Size = new System.Drawing.Size(24, 24);
            this.btnProjectSearch.TabIndex = 125;
            this.btnProjectSearch.Text = "....";
            this.btnProjectSearch.UseVisualStyleBackColor = false;
            this.btnProjectSearch.Click += new System.EventHandler(this.btnProjectSearch_Click);
            // 
            // txtPersonSigned
            // 
            this.txtPersonSigned.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtPersonSigned.Location = new System.Drawing.Point(178, 229);
            this.txtPersonSigned.Name = "txtPersonSigned";
            this.txtPersonSigned.Size = new System.Drawing.Size(280, 26);
            this.txtPersonSigned.TabIndex = 133;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(61, 151);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(110, 19);
            this.label10.TabIndex = 126;
            this.label10.Text = "Status Update:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(15, 219);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(157, 38);
            this.label11.TabIndex = 132;
            this.label11.Text = "Person Signed \r\nInstallation certificate";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cmbProjectStatus
            // 
            this.cmbProjectStatus.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbProjectStatus.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProjectStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProjectStatus.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProjectStatus.FormattingEnabled = true;
            this.cmbProjectStatus.Items.AddRange(new object[] {
            "Installation completed"});
            this.cmbProjectStatus.Location = new System.Drawing.Point(178, 149);
            this.cmbProjectStatus.Name = "cmbProjectStatus";
            this.cmbProjectStatus.Size = new System.Drawing.Size(280, 26);
            this.cmbProjectStatus.TabIndex = 127;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(11, 190);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(160, 19);
            this.label12.TabIndex = 128;
            this.label12.Text = "Installation Form No*:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(38, 5);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(133, 19);
            this.label13.TabIndex = 130;
            this.label13.Text = "Installation Date*:";
            // 
            // txtInstallationformno
            // 
            this.txtInstallationformno.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.txtInstallationformno.Location = new System.Drawing.Point(178, 186);
            this.txtInstallationformno.Name = "txtInstallationformno";
            this.txtInstallationformno.Size = new System.Drawing.Size(280, 26);
            this.txtInstallationformno.TabIndex = 129;
            // 
            // frmProjectInstall
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1255, 583);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmProjectInstall";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Project Install Status Update";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmProjectInstall_FormClosing);
            this.Load += new System.EventHandler(this.frmProjectInstall_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtRemarks;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtAssetSerialNo;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DateTimePicker dtpInstallationDate;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtDesignationofSigned;
        private System.Windows.Forms.ComboBox cmbProjectcode;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnProjectSearch;
        private System.Windows.Forms.TextBox txtPersonSigned;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cmbProjectStatus;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtInstallationformno;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnclear;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox txtMarketingInteractions;
        private System.Windows.Forms.TextBox txtApplicationuserfriendly;
        private System.Windows.Forms.TextBox txtMachineUserfriendly;
        private System.Windows.Forms.TextBox txtequipementpackingquality;
        private System.Windows.Forms.TextBox txtqualityofinteractions;
        private System.Windows.Forms.TextBox txtQualityofbissreports;
        private System.Windows.Forms.TextBox txtQualityofbissproducts;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox cmbApplicationuserfriendly;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbMachineUserfriendly;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbequipementpackingquality;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbqualityofinteractions;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbQualityofbissreports;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbQualityofbissproducts;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbMarketingInteractions;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtWarrantyMonths;
        private System.Windows.Forms.DateTimePicker dtpStartDate;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.DateTimePicker dtpCLosedate;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtPMProjectDescription;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button btnUploadDoc;
    }
}