﻿
namespace Erp_Project_With_Buttons.Project_Master
{
    partial class Project_Closer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Project_Closer));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.buttprint = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.buttprojectclosersave = new System.Windows.Forms.Button();
            this.comselectdispatch = new System.Windows.Forms.ComboBox();
            this.AllitemsasperBOMreadytodispatch = new System.Windows.Forms.Label();
            this.labelPaymentIssue = new System.Windows.Forms.Label();
            this.labelInstallationImpact = new System.Windows.Forms.Label();
            this.labelReason = new System.Windows.Forms.Label();
            this.dateTimePickerReadyDate = new System.Windows.Forms.DateTimePicker();
            this.labelReadyDate = new System.Windows.Forms.Label();
            this.labelcomboBoxOpenPoints = new System.Windows.Forms.Label();
            this.comboBoxOpenPoints = new System.Windows.Forms.ComboBox();
            this.labelAnyopenpoints = new System.Windows.Forms.Label();
            this.comboBoxOpenPoints1 = new System.Windows.Forms.ComboBox();
            this.Critical_information = new System.Windows.Forms.Label();
            this.comcreticalinformation = new System.Windows.Forms.ComboBox();
            this.labelBoxCompleteDetails = new System.Windows.Forms.Label();
            this.labelSupportingDocuments = new System.Windows.Forms.Label();
            this.labelLessonLearnt = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbProjectcode = new System.Windows.Forms.ComboBox();
            this.btnProjectSearch = new System.Windows.Forms.Button();
            this.labprojeccode1 = new System.Windows.Forms.Label();
            this.comsectinsertedProjectcode = new System.Windows.Forms.ComboBox();
            this.dgBOMprojectstatusList = new System.Windows.Forms.DataGridView();
            this.labelProjectClosure = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.textMandatetoanswerthis = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.textBoxSupportingDocuments = new System.Windows.Forms.TextBox();
            this.textBoxCompleteDetails = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.labelInstallationImpact1 = new System.Windows.Forms.Label();
            this.textBoxInstallationImpact1 = new System.Windows.Forms.TextBox();
            this.textBoxWhyNotAddressed = new System.Windows.Forms.TextBox();
            this.textBoxPaymentIssue1 = new System.Windows.Forms.TextBox();
            this.labelPaymentIssue1 = new System.Windows.Forms.Label();
            this.textWhowilladdressatsitebyservice1 = new System.Windows.Forms.TextBox();
            this.textThereasonforopenpoints1 = new System.Windows.Forms.TextBox();
            this.labelWhowilladdressatsitebyservice1 = new System.Windows.Forms.Label();
            this.labelThereasonforopenpoints1 = new System.Windows.Forms.Label();
            this.dateTimePickerReadyToFix = new System.Windows.Forms.DateTimePicker();
            this.labelWhyNotAddressed = new System.Windows.Forms.Label();
            this.labelReadyToFix = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textWhowilladdressatsitebyservice = new System.Windows.Forms.TextBox();
            this.Thereasonforopenpoints = new System.Windows.Forms.TextBox();
            this.labelWhowilladdressatsitebyservice = new System.Windows.Forms.Label();
            this.labelThereasonforopenpoints = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBoxPaymentIssue = new System.Windows.Forms.TextBox();
            this.textBoxInstallationImpact = new System.Windows.Forms.TextBox();
            this.textBoxReason = new System.Windows.Forms.TextBox();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgBOMprojectstatusList)).BeginInit();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.groupBox2.Controls.Add(this.buttprint);
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.buttprojectclosersave);
            this.groupBox2.Location = new System.Drawing.Point(540, 958);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Size = new System.Drawing.Size(936, 78);
            this.groupBox2.TabIndex = 502;
            this.groupBox2.TabStop = false;
            // 
            // buttprint
            // 
            this.buttprint.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.buttprint.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.buttprint.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttprint.Location = new System.Drawing.Point(393, 14);
            this.buttprint.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttprint.Name = "buttprint";
            this.buttprint.Size = new System.Drawing.Size(150, 51);
            this.buttprint.TabIndex = 501;
            this.buttprint.Text = "Print ";
            this.buttprint.UseVisualStyleBackColor = false;
            this.buttprint.Click += new System.EventHandler(this.buttprint_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button1.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(687, 18);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 51);
            this.button1.TabIndex = 500;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttprojectclosersave
            // 
            this.buttprojectclosersave.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.buttprojectclosersave.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.buttprojectclosersave.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttprojectclosersave.Location = new System.Drawing.Point(84, 18);
            this.buttprojectclosersave.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttprojectclosersave.Name = "buttprojectclosersave";
            this.buttprojectclosersave.Size = new System.Drawing.Size(150, 51);
            this.buttprojectclosersave.TabIndex = 498;
            this.buttprojectclosersave.Text = "Save";
            this.buttprojectclosersave.UseVisualStyleBackColor = false;
            this.buttprojectclosersave.Click += new System.EventHandler(this.buttprojectclosersave_Click);
            // 
            // comselectdispatch
            // 
            this.comselectdispatch.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comselectdispatch.DropDownHeight = 130;
            this.comselectdispatch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comselectdispatch.Enabled = false;
            this.comselectdispatch.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comselectdispatch.FormattingEnabled = true;
            this.comselectdispatch.IntegralHeight = false;
            this.comselectdispatch.Items.AddRange(new object[] {
            "YES",
            "NO"});
            this.comselectdispatch.Location = new System.Drawing.Point(306, 22);
            this.comselectdispatch.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comselectdispatch.Name = "comselectdispatch";
            this.comselectdispatch.Size = new System.Drawing.Size(235, 36);
            this.comselectdispatch.TabIndex = 503;
            this.comselectdispatch.SelectedIndexChanged += new System.EventHandler(this.comselectdispatch_SelectedIndexChanged);
            // 
            // AllitemsasperBOMreadytodispatch
            // 
            this.AllitemsasperBOMreadytodispatch.AutoSize = true;
            this.AllitemsasperBOMreadytodispatch.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AllitemsasperBOMreadytodispatch.Location = new System.Drawing.Point(82, 20);
            this.AllitemsasperBOMreadytodispatch.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.AllitemsasperBOMreadytodispatch.Name = "AllitemsasperBOMreadytodispatch";
            this.AllitemsasperBOMreadytodispatch.Size = new System.Drawing.Size(218, 56);
            this.AllitemsasperBOMreadytodispatch.TabIndex = 504;
            this.AllitemsasperBOMreadytodispatch.Text = "All items as per BOM \r\nready to dispatch :";
            this.AllitemsasperBOMreadytodispatch.Click += new System.EventHandler(this.AllitemsasperBOMreadytodispatch_Click);
            // 
            // labelPaymentIssue
            // 
            this.labelPaymentIssue.AutoSize = true;
            this.labelPaymentIssue.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPaymentIssue.Location = new System.Drawing.Point(82, 232);
            this.labelPaymentIssue.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelPaymentIssue.Name = "labelPaymentIssue";
            this.labelPaymentIssue.Size = new System.Drawing.Size(219, 56);
            this.labelPaymentIssue.TabIndex = 505;
            this.labelPaymentIssue.Text = "Any issue with \r\npayment realization?:";
            this.labelPaymentIssue.Visible = false;
            // 
            // labelInstallationImpact
            // 
            this.labelInstallationImpact.AutoSize = true;
            this.labelInstallationImpact.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelInstallationImpact.Location = new System.Drawing.Point(120, 158);
            this.labelInstallationImpact.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelInstallationImpact.Name = "labelInstallationImpact";
            this.labelInstallationImpact.Size = new System.Drawing.Size(180, 56);
            this.labelInstallationImpact.TabIndex = 507;
            this.labelInstallationImpact.Text = "How will it affect \r\nthe installation?:";
            this.labelInstallationImpact.Visible = false;
            // 
            // labelReason
            // 
            this.labelReason.AutoSize = true;
            this.labelReason.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelReason.Location = new System.Drawing.Point(82, 86);
            this.labelReason.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelReason.Name = "labelReason";
            this.labelReason.Size = new System.Drawing.Size(215, 56);
            this.labelReason.TabIndex = 511;
            this.labelReason.Text = "The reason for delay, \r\nwhy not ready?:";
            this.labelReason.Visible = false;
            // 
            // dateTimePickerReadyDate
            // 
            this.dateTimePickerReadyDate.Location = new System.Drawing.Point(742, 22);
            this.dateTimePickerReadyDate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dateTimePickerReadyDate.Name = "dateTimePickerReadyDate";
            this.dateTimePickerReadyDate.Size = new System.Drawing.Size(169, 26);
            this.dateTimePickerReadyDate.TabIndex = 513;
            this.dateTimePickerReadyDate.Visible = false;
            // 
            // labelReadyDate
            // 
            this.labelReadyDate.AutoSize = true;
            this.labelReadyDate.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelReadyDate.Location = new System.Drawing.Point(552, 20);
            this.labelReadyDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelReadyDate.Name = "labelReadyDate";
            this.labelReadyDate.Size = new System.Drawing.Size(193, 56);
            this.labelReadyDate.TabIndex = 514;
            this.labelReadyDate.Text = "When it will be \r\nready to dispatch?:";
            this.labelReadyDate.Visible = false;
            // 
            // labelcomboBoxOpenPoints
            // 
            this.labelcomboBoxOpenPoints.AutoSize = true;
            this.labelcomboBoxOpenPoints.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelcomboBoxOpenPoints.Location = new System.Drawing.Point(76, 25);
            this.labelcomboBoxOpenPoints.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelcomboBoxOpenPoints.Name = "labelcomboBoxOpenPoints";
            this.labelcomboBoxOpenPoints.Size = new System.Drawing.Size(269, 56);
            this.labelcomboBoxOpenPoints.TabIndex = 518;
            this.labelcomboBoxOpenPoints.Text = "Any open points to address\r\n at site as per internal NC?:";
            // 
            // comboBoxOpenPoints
            // 
            this.comboBoxOpenPoints.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBoxOpenPoints.DropDownHeight = 130;
            this.comboBoxOpenPoints.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxOpenPoints.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxOpenPoints.FormattingEnabled = true;
            this.comboBoxOpenPoints.IntegralHeight = false;
            this.comboBoxOpenPoints.Items.AddRange(new object[] {
            "YES",
            "NO"});
            this.comboBoxOpenPoints.Location = new System.Drawing.Point(350, 29);
            this.comboBoxOpenPoints.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBoxOpenPoints.Name = "comboBoxOpenPoints";
            this.comboBoxOpenPoints.Size = new System.Drawing.Size(226, 36);
            this.comboBoxOpenPoints.TabIndex = 517;
            this.comboBoxOpenPoints.SelectedIndexChanged += new System.EventHandler(this.comboBoxOpenPoints_SelectedIndexChanged);
            // 
            // labelAnyopenpoints
            // 
            this.labelAnyopenpoints.AutoSize = true;
            this.labelAnyopenpoints.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAnyopenpoints.Location = new System.Drawing.Point(10, 2);
            this.labelAnyopenpoints.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelAnyopenpoints.Name = "labelAnyopenpoints";
            this.labelAnyopenpoints.Size = new System.Drawing.Size(294, 56);
            this.labelAnyopenpoints.TabIndex = 522;
            this.labelAnyopenpoints.Text = "Any open points to address at\r\nsite, custfeedback during PDI:";
            // 
            // comboBoxOpenPoints1
            // 
            this.comboBoxOpenPoints1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBoxOpenPoints1.DropDownHeight = 130;
            this.comboBoxOpenPoints1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxOpenPoints1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxOpenPoints1.FormattingEnabled = true;
            this.comboBoxOpenPoints1.IntegralHeight = false;
            this.comboBoxOpenPoints1.Items.AddRange(new object[] {
            "YES",
            "NO"});
            this.comboBoxOpenPoints1.Location = new System.Drawing.Point(306, 17);
            this.comboBoxOpenPoints1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBoxOpenPoints1.Name = "comboBoxOpenPoints1";
            this.comboBoxOpenPoints1.Size = new System.Drawing.Size(214, 36);
            this.comboBoxOpenPoints1.TabIndex = 521;
            this.comboBoxOpenPoints1.SelectedIndexChanged += new System.EventHandler(this.comboBoxOpenPoints1_SelectedIndexChanged);
            // 
            // Critical_information
            // 
            this.Critical_information.AutoSize = true;
            this.Critical_information.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Critical_information.Location = new System.Drawing.Point(0, 14);
            this.Critical_information.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Critical_information.Name = "Critical_information";
            this.Critical_information.Size = new System.Drawing.Size(386, 56);
            this.Critical_information.TabIndex = 532;
            this.Critical_information.Text = "Critical information to site/\r\ninstallation engineer and/or sales focal:";
            // 
            // comcreticalinformation
            // 
            this.comcreticalinformation.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comcreticalinformation.DropDownHeight = 130;
            this.comcreticalinformation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comcreticalinformation.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comcreticalinformation.FormattingEnabled = true;
            this.comcreticalinformation.IntegralHeight = false;
            this.comcreticalinformation.Items.AddRange(new object[] {
            "YES",
            "NO"});
            this.comcreticalinformation.Location = new System.Drawing.Point(388, 29);
            this.comcreticalinformation.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comcreticalinformation.Name = "comcreticalinformation";
            this.comcreticalinformation.Size = new System.Drawing.Size(226, 36);
            this.comcreticalinformation.TabIndex = 531;
            this.comcreticalinformation.SelectedIndexChanged += new System.EventHandler(this.comcreticalinformation_SelectedIndexChanged);
            // 
            // labelBoxCompleteDetails
            // 
            this.labelBoxCompleteDetails.AutoSize = true;
            this.labelBoxCompleteDetails.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBoxCompleteDetails.Location = new System.Drawing.Point(102, 89);
            this.labelBoxCompleteDetails.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelBoxCompleteDetails.Name = "labelBoxCompleteDetails";
            this.labelBoxCompleteDetails.Size = new System.Drawing.Size(226, 56);
            this.labelBoxCompleteDetails.TabIndex = 534;
            this.labelBoxCompleteDetails.Text = "information in the tab \r\nwith complete details:";
            this.labelBoxCompleteDetails.Visible = false;
            // 
            // labelSupportingDocuments
            // 
            this.labelSupportingDocuments.AutoSize = true;
            this.labelSupportingDocuments.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSupportingDocuments.Location = new System.Drawing.Point(96, 185);
            this.labelSupportingDocuments.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelSupportingDocuments.Name = "labelSupportingDocuments";
            this.labelSupportingDocuments.Size = new System.Drawing.Size(230, 28);
            this.labelSupportingDocuments.TabIndex = 536;
            this.labelSupportingDocuments.Text = "supporting documents:";
            this.labelSupportingDocuments.Visible = false;
            // 
            // labelLessonLearnt
            // 
            this.labelLessonLearnt.AutoSize = true;
            this.labelLessonLearnt.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLessonLearnt.Location = new System.Drawing.Point(9, 43);
            this.labelLessonLearnt.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelLessonLearnt.Name = "labelLessonLearnt";
            this.labelLessonLearnt.Size = new System.Drawing.Size(148, 28);
            this.labelLessonLearnt.TabIndex = 538;
            this.labelLessonLearnt.Text = "LessonLearnt :";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.cmbProjectcode);
            this.groupBox3.Controls.Add(this.btnProjectSearch);
            this.groupBox3.Controls.Add(this.labprojeccode1);
            this.groupBox3.Controls.Add(this.comsectinsertedProjectcode);
            this.groupBox3.Controls.Add(this.dgBOMprojectstatusList);
            this.groupBox3.Controls.Add(this.labelProjectClosure);
            this.groupBox3.Controls.Add(this.groupBox7);
            this.groupBox3.Controls.Add(this.groupBox6);
            this.groupBox3.Controls.Add(this.groupBox5);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Controls.Add(this.groupBox1);
            this.groupBox3.Location = new System.Drawing.Point(18, 18);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox3.Size = new System.Drawing.Size(1935, 931);
            this.groupBox3.TabIndex = 503;
            this.groupBox3.TabStop = false;
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(16, 29);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(147, 29);
            this.label2.TabIndex = 559;
            this.label2.Text = "Project Code:";
            // 
            // cmbProjectcode
            // 
            this.cmbProjectcode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbProjectcode.DropDownHeight = 130;
            this.cmbProjectcode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbProjectcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProjectcode.FormattingEnabled = true;
            this.cmbProjectcode.IntegralHeight = false;
            this.cmbProjectcode.Location = new System.Drawing.Point(176, 26);
            this.cmbProjectcode.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cmbProjectcode.Name = "cmbProjectcode";
            this.cmbProjectcode.Size = new System.Drawing.Size(328, 36);
            this.cmbProjectcode.TabIndex = 560;
            this.cmbProjectcode.SelectedIndexChanged += new System.EventHandler(this.cmbProjectcode_SelectedIndexChanged);
            // 
            // btnProjectSearch
            // 
            this.btnProjectSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnProjectSearch.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProjectSearch.Location = new System.Drawing.Point(514, 29);
            this.btnProjectSearch.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnProjectSearch.Name = "btnProjectSearch";
            this.btnProjectSearch.Size = new System.Drawing.Size(58, 37);
            this.btnProjectSearch.TabIndex = 561;
            this.btnProjectSearch.Text = "....";
            this.btnProjectSearch.UseVisualStyleBackColor = false;
            this.btnProjectSearch.Click += new System.EventHandler(this.btnProjectSearch_Click);
            // 
            // labprojeccode1
            // 
            this.labprojeccode1.AutoSize = true;
            this.labprojeccode1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labprojeccode1.Location = new System.Drawing.Point(1434, 25);
            this.labprojeccode1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labprojeccode1.Name = "labprojeccode1";
            this.labprojeccode1.Size = new System.Drawing.Size(144, 25);
            this.labprojeccode1.TabIndex = 558;
            this.labprojeccode1.Text = "Project Code:";
            this.labprojeccode1.Visible = false;
            // 
            // comsectinsertedProjectcode
            // 
            this.comsectinsertedProjectcode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comsectinsertedProjectcode.DropDownHeight = 130;
            this.comsectinsertedProjectcode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comsectinsertedProjectcode.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comsectinsertedProjectcode.FormattingEnabled = true;
            this.comsectinsertedProjectcode.IntegralHeight = false;
            this.comsectinsertedProjectcode.Location = new System.Drawing.Point(1596, 18);
            this.comsectinsertedProjectcode.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comsectinsertedProjectcode.Name = "comsectinsertedProjectcode";
            this.comsectinsertedProjectcode.Size = new System.Drawing.Size(319, 36);
            this.comsectinsertedProjectcode.TabIndex = 557;
            this.comsectinsertedProjectcode.Visible = false;
            this.comsectinsertedProjectcode.SelectedIndexChanged += new System.EventHandler(this.comsectinsertedProjectcode_SelectedIndexChanged);
            // 
            // dgBOMprojectstatusList
            // 
            this.dgBOMprojectstatusList.AllowUserToAddRows = false;
            this.dgBOMprojectstatusList.AllowUserToDeleteRows = false;
            this.dgBOMprojectstatusList.AllowUserToResizeRows = false;
            this.dgBOMprojectstatusList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgBOMprojectstatusList.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgBOMprojectstatusList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgBOMprojectstatusList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgBOMprojectstatusList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgBOMprojectstatusList.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgBOMprojectstatusList.EnableHeadersVisualStyles = false;
            this.dgBOMprojectstatusList.Location = new System.Drawing.Point(934, 646);
            this.dgBOMprojectstatusList.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dgBOMprojectstatusList.Name = "dgBOMprojectstatusList";
            this.dgBOMprojectstatusList.RowHeadersVisible = false;
            this.dgBOMprojectstatusList.RowHeadersWidth = 62;
            this.dgBOMprojectstatusList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgBOMprojectstatusList.Size = new System.Drawing.Size(982, 275);
            this.dgBOMprojectstatusList.TabIndex = 539;
            // 
            // labelProjectClosure
            // 
            this.labelProjectClosure.AutoSize = true;
            this.labelProjectClosure.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelProjectClosure.Location = new System.Drawing.Point(915, 25);
            this.labelProjectClosure.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelProjectClosure.Name = "labelProjectClosure";
            this.labelProjectClosure.Size = new System.Drawing.Size(250, 37);
            this.labelProjectClosure.TabIndex = 556;
            this.labelProjectClosure.Text = "Project Closure";
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.groupBox7.Controls.Add(this.textMandatetoanswerthis);
            this.groupBox7.Controls.Add(this.labelLessonLearnt);
            this.groupBox7.Location = new System.Drawing.Point(3, 795);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox7.Size = new System.Drawing.Size(922, 135);
            this.groupBox7.TabIndex = 503;
            this.groupBox7.TabStop = false;
            // 
            // textMandatetoanswerthis
            // 
            this.textMandatetoanswerthis.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.textMandatetoanswerthis.Location = new System.Drawing.Point(172, 20);
            this.textMandatetoanswerthis.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textMandatetoanswerthis.MaxLength = 1000;
            this.textMandatetoanswerthis.Multiline = true;
            this.textMandatetoanswerthis.Name = "textMandatetoanswerthis";
            this.textMandatetoanswerthis.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textMandatetoanswerthis.Size = new System.Drawing.Size(739, 104);
            this.textMandatetoanswerthis.TabIndex = 557;
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.groupBox6.Controls.Add(this.textBoxSupportingDocuments);
            this.groupBox6.Controls.Add(this.textBoxCompleteDetails);
            this.groupBox6.Controls.Add(this.Critical_information);
            this.groupBox6.Controls.Add(this.comcreticalinformation);
            this.groupBox6.Controls.Add(this.labelBoxCompleteDetails);
            this.groupBox6.Controls.Add(this.labelSupportingDocuments);
            this.groupBox6.Location = new System.Drawing.Point(934, 397);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox6.Size = new System.Drawing.Size(982, 240);
            this.groupBox6.TabIndex = 503;
            this.groupBox6.TabStop = false;
            // 
            // textBoxSupportingDocuments
            // 
            this.textBoxSupportingDocuments.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.textBoxSupportingDocuments.Location = new System.Drawing.Point(339, 162);
            this.textBoxSupportingDocuments.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxSupportingDocuments.MaxLength = 1000;
            this.textBoxSupportingDocuments.Multiline = true;
            this.textBoxSupportingDocuments.Name = "textBoxSupportingDocuments";
            this.textBoxSupportingDocuments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxSupportingDocuments.Size = new System.Drawing.Size(632, 56);
            this.textBoxSupportingDocuments.TabIndex = 556;
            this.textBoxSupportingDocuments.Visible = false;
            // 
            // textBoxCompleteDetails
            // 
            this.textBoxCompleteDetails.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.textBoxCompleteDetails.Location = new System.Drawing.Point(339, 85);
            this.textBoxCompleteDetails.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxCompleteDetails.MaxLength = 1000;
            this.textBoxCompleteDetails.Multiline = true;
            this.textBoxCompleteDetails.Name = "textBoxCompleteDetails";
            this.textBoxCompleteDetails.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxCompleteDetails.Size = new System.Drawing.Size(632, 56);
            this.textBoxCompleteDetails.TabIndex = 555;
            this.textBoxCompleteDetails.Visible = false;
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.groupBox5.Controls.Add(this.labelInstallationImpact1);
            this.groupBox5.Controls.Add(this.textBoxInstallationImpact1);
            this.groupBox5.Controls.Add(this.textBoxWhyNotAddressed);
            this.groupBox5.Controls.Add(this.textBoxPaymentIssue1);
            this.groupBox5.Controls.Add(this.labelPaymentIssue1);
            this.groupBox5.Controls.Add(this.textWhowilladdressatsitebyservice1);
            this.groupBox5.Controls.Add(this.textThereasonforopenpoints1);
            this.groupBox5.Controls.Add(this.labelWhowilladdressatsitebyservice1);
            this.groupBox5.Controls.Add(this.labelThereasonforopenpoints1);
            this.groupBox5.Controls.Add(this.dateTimePickerReadyToFix);
            this.groupBox5.Controls.Add(this.labelAnyopenpoints);
            this.groupBox5.Controls.Add(this.comboBoxOpenPoints1);
            this.groupBox5.Controls.Add(this.labelWhyNotAddressed);
            this.groupBox5.Controls.Add(this.labelReadyToFix);
            this.groupBox5.Location = new System.Drawing.Point(3, 397);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox5.Size = new System.Drawing.Size(922, 389);
            this.groupBox5.TabIndex = 555;
            this.groupBox5.TabStop = false;
            // 
            // labelInstallationImpact1
            // 
            this.labelInstallationImpact1.AutoSize = true;
            this.labelInstallationImpact1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelInstallationImpact1.Location = new System.Drawing.Point(114, 323);
            this.labelInstallationImpact1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelInstallationImpact1.Name = "labelInstallationImpact1";
            this.labelInstallationImpact1.Size = new System.Drawing.Size(180, 56);
            this.labelInstallationImpact1.TabIndex = 554;
            this.labelInstallationImpact1.Text = "How will it affect \r\nthe installation?:";
            this.labelInstallationImpact1.Visible = false;
            // 
            // textBoxInstallationImpact1
            // 
            this.textBoxInstallationImpact1.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.textBoxInstallationImpact1.Location = new System.Drawing.Point(306, 323);
            this.textBoxInstallationImpact1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxInstallationImpact1.MaxLength = 1000;
            this.textBoxInstallationImpact1.Multiline = true;
            this.textBoxInstallationImpact1.Name = "textBoxInstallationImpact1";
            this.textBoxInstallationImpact1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxInstallationImpact1.Size = new System.Drawing.Size(606, 56);
            this.textBoxInstallationImpact1.TabIndex = 556;
            this.textBoxInstallationImpact1.Visible = false;
            // 
            // textBoxWhyNotAddressed
            // 
            this.textBoxWhyNotAddressed.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.textBoxWhyNotAddressed.Location = new System.Drawing.Point(306, 192);
            this.textBoxWhyNotAddressed.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxWhyNotAddressed.MaxLength = 1000;
            this.textBoxWhyNotAddressed.Multiline = true;
            this.textBoxWhyNotAddressed.Name = "textBoxWhyNotAddressed";
            this.textBoxWhyNotAddressed.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxWhyNotAddressed.Size = new System.Drawing.Size(606, 46);
            this.textBoxWhyNotAddressed.TabIndex = 555;
            this.textBoxWhyNotAddressed.Visible = false;
            // 
            // textBoxPaymentIssue1
            // 
            this.textBoxPaymentIssue1.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.textBoxPaymentIssue1.Location = new System.Drawing.Point(306, 254);
            this.textBoxPaymentIssue1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxPaymentIssue1.MaxLength = 1000;
            this.textBoxPaymentIssue1.Multiline = true;
            this.textBoxPaymentIssue1.Name = "textBoxPaymentIssue1";
            this.textBoxPaymentIssue1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxPaymentIssue1.Size = new System.Drawing.Size(606, 56);
            this.textBoxPaymentIssue1.TabIndex = 555;
            this.textBoxPaymentIssue1.Visible = false;
            // 
            // labelPaymentIssue1
            // 
            this.labelPaymentIssue1.AutoSize = true;
            this.labelPaymentIssue1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPaymentIssue1.Location = new System.Drawing.Point(72, 254);
            this.labelPaymentIssue1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelPaymentIssue1.Name = "labelPaymentIssue1";
            this.labelPaymentIssue1.Size = new System.Drawing.Size(219, 56);
            this.labelPaymentIssue1.TabIndex = 553;
            this.labelPaymentIssue1.Text = "Any issue with \r\npayment realization?:";
            this.labelPaymentIssue1.Visible = false;
            // 
            // textWhowilladdressatsitebyservice1
            // 
            this.textWhowilladdressatsitebyservice1.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.textWhowilladdressatsitebyservice1.Location = new System.Drawing.Point(306, 134);
            this.textWhowilladdressatsitebyservice1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textWhowilladdressatsitebyservice1.MaxLength = 1000;
            this.textWhowilladdressatsitebyservice1.Multiline = true;
            this.textWhowilladdressatsitebyservice1.Name = "textWhowilladdressatsitebyservice1";
            this.textWhowilladdressatsitebyservice1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textWhowilladdressatsitebyservice1.Size = new System.Drawing.Size(606, 47);
            this.textWhowilladdressatsitebyservice1.TabIndex = 554;
            this.textWhowilladdressatsitebyservice1.Visible = false;
            // 
            // textThereasonforopenpoints1
            // 
            this.textThereasonforopenpoints1.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.textThereasonforopenpoints1.Location = new System.Drawing.Point(306, 80);
            this.textThereasonforopenpoints1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textThereasonforopenpoints1.MaxLength = 1000;
            this.textThereasonforopenpoints1.Multiline = true;
            this.textThereasonforopenpoints1.Name = "textThereasonforopenpoints1";
            this.textThereasonforopenpoints1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textThereasonforopenpoints1.Size = new System.Drawing.Size(606, 42);
            this.textThereasonforopenpoints1.TabIndex = 553;
            this.textThereasonforopenpoints1.Visible = false;
            // 
            // labelWhowilladdressatsitebyservice1
            // 
            this.labelWhowilladdressatsitebyservice1.AutoSize = true;
            this.labelWhowilladdressatsitebyservice1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelWhowilladdressatsitebyservice1.Location = new System.Drawing.Point(48, 129);
            this.labelWhowilladdressatsitebyservice1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelWhowilladdressatsitebyservice1.Name = "labelWhowilladdressatsitebyservice1";
            this.labelWhowilladdressatsitebyservice1.Size = new System.Drawing.Size(244, 56);
            this.labelWhowilladdressatsitebyservice1.TabIndex = 539;
            this.labelWhowilladdressatsitebyservice1.Text = "Who will address at site \r\nby service engineer:";
            this.labelWhowilladdressatsitebyservice1.Visible = false;
            // 
            // labelThereasonforopenpoints1
            // 
            this.labelThereasonforopenpoints1.AutoSize = true;
            this.labelThereasonforopenpoints1.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelThereasonforopenpoints1.Location = new System.Drawing.Point(15, 85);
            this.labelThereasonforopenpoints1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelThereasonforopenpoints1.Name = "labelThereasonforopenpoints1";
            this.labelThereasonforopenpoints1.Size = new System.Drawing.Size(282, 28);
            this.labelThereasonforopenpoints1.TabIndex = 537;
            this.labelThereasonforopenpoints1.Text = "The reason for open points?:";
            this.labelThereasonforopenpoints1.Visible = false;
            // 
            // dateTimePickerReadyToFix
            // 
            this.dateTimePickerReadyToFix.Location = new System.Drawing.Point(734, 22);
            this.dateTimePickerReadyToFix.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dateTimePickerReadyToFix.Name = "dateTimePickerReadyToFix";
            this.dateTimePickerReadyToFix.Size = new System.Drawing.Size(178, 26);
            this.dateTimePickerReadyToFix.TabIndex = 545;
            this.dateTimePickerReadyToFix.Visible = false;
            // 
            // labelWhyNotAddressed
            // 
            this.labelWhyNotAddressed.AutoSize = true;
            this.labelWhyNotAddressed.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelWhyNotAddressed.Location = new System.Drawing.Point(90, 185);
            this.labelWhyNotAddressed.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelWhyNotAddressed.Name = "labelWhyNotAddressed";
            this.labelWhyNotAddressed.Size = new System.Drawing.Size(200, 56);
            this.labelWhyNotAddressed.TabIndex = 543;
            this.labelWhyNotAddressed.Text = "Why not addressed \r\nbefore dispatch?:";
            this.labelWhyNotAddressed.Visible = false;
            // 
            // labelReadyToFix
            // 
            this.labelReadyToFix.AutoSize = true;
            this.labelReadyToFix.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelReadyToFix.Location = new System.Drawing.Point(531, 14);
            this.labelReadyToFix.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelReadyToFix.Name = "labelReadyToFix";
            this.labelReadyToFix.Size = new System.Drawing.Size(201, 56);
            this.labelReadyToFix.TabIndex = 546;
            this.labelReadyToFix.Text = "When it will be \r\nready to fix at site?:";
            this.labelReadyToFix.Visible = false;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.groupBox4.Controls.Add(this.textWhowilladdressatsitebyservice);
            this.groupBox4.Controls.Add(this.Thereasonforopenpoints);
            this.groupBox4.Controls.Add(this.comboBoxOpenPoints);
            this.groupBox4.Controls.Add(this.labelcomboBoxOpenPoints);
            this.groupBox4.Controls.Add(this.labelWhowilladdressatsitebyservice);
            this.groupBox4.Controls.Add(this.labelThereasonforopenpoints);
            this.groupBox4.Location = new System.Drawing.Point(934, 75);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox4.Size = new System.Drawing.Size(982, 312);
            this.groupBox4.TabIndex = 503;
            this.groupBox4.TabStop = false;
            // 
            // textWhowilladdressatsitebyservice
            // 
            this.textWhowilladdressatsitebyservice.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.textWhowilladdressatsitebyservice.Location = new System.Drawing.Point(350, 165);
            this.textWhowilladdressatsitebyservice.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textWhowilladdressatsitebyservice.MaxLength = 1000;
            this.textWhowilladdressatsitebyservice.Multiline = true;
            this.textWhowilladdressatsitebyservice.Name = "textWhowilladdressatsitebyservice";
            this.textWhowilladdressatsitebyservice.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textWhowilladdressatsitebyservice.Size = new System.Drawing.Size(622, 56);
            this.textWhowilladdressatsitebyservice.TabIndex = 554;
            this.textWhowilladdressatsitebyservice.Visible = false;
            // 
            // Thereasonforopenpoints
            // 
            this.Thereasonforopenpoints.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.Thereasonforopenpoints.Location = new System.Drawing.Point(350, 82);
            this.Thereasonforopenpoints.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Thereasonforopenpoints.MaxLength = 1000;
            this.Thereasonforopenpoints.Multiline = true;
            this.Thereasonforopenpoints.Name = "Thereasonforopenpoints";
            this.Thereasonforopenpoints.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.Thereasonforopenpoints.Size = new System.Drawing.Size(622, 56);
            this.Thereasonforopenpoints.TabIndex = 553;
            this.Thereasonforopenpoints.Visible = false;
            // 
            // labelWhowilladdressatsitebyservice
            // 
            this.labelWhowilladdressatsitebyservice.AutoSize = true;
            this.labelWhowilladdressatsitebyservice.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelWhowilladdressatsitebyservice.Location = new System.Drawing.Point(102, 168);
            this.labelWhowilladdressatsitebyservice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelWhowilladdressatsitebyservice.Name = "labelWhowilladdressatsitebyservice";
            this.labelWhowilladdressatsitebyservice.Size = new System.Drawing.Size(244, 56);
            this.labelWhowilladdressatsitebyservice.TabIndex = 539;
            this.labelWhowilladdressatsitebyservice.Text = "Who will address at \r\nsite by service engineer:";
            this.labelWhowilladdressatsitebyservice.Visible = false;
            // 
            // labelThereasonforopenpoints
            // 
            this.labelThereasonforopenpoints.AutoSize = true;
            this.labelThereasonforopenpoints.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelThereasonforopenpoints.Location = new System.Drawing.Point(63, 91);
            this.labelThereasonforopenpoints.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelThereasonforopenpoints.Name = "labelThereasonforopenpoints";
            this.labelThereasonforopenpoints.Size = new System.Drawing.Size(282, 28);
            this.labelThereasonforopenpoints.TabIndex = 537;
            this.labelThereasonforopenpoints.Text = "The reason for open points?:";
            this.labelThereasonforopenpoints.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.groupBox1.Controls.Add(this.textBoxPaymentIssue);
            this.groupBox1.Controls.Add(this.textBoxInstallationImpact);
            this.groupBox1.Controls.Add(this.textBoxReason);
            this.groupBox1.Controls.Add(this.labelReason);
            this.groupBox1.Controls.Add(this.labelInstallationImpact);
            this.groupBox1.Controls.Add(this.labelPaymentIssue);
            this.groupBox1.Controls.Add(this.AllitemsasperBOMreadytodispatch);
            this.groupBox1.Controls.Add(this.comselectdispatch);
            this.groupBox1.Controls.Add(this.labelReadyDate);
            this.groupBox1.Controls.Add(this.dateTimePickerReadyDate);
            this.groupBox1.Location = new System.Drawing.Point(3, 75);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(922, 312);
            this.groupBox1.TabIndex = 549;
            this.groupBox1.TabStop = false;
            // 
            // textBoxPaymentIssue
            // 
            this.textBoxPaymentIssue.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.textBoxPaymentIssue.Location = new System.Drawing.Point(306, 232);
            this.textBoxPaymentIssue.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxPaymentIssue.MaxLength = 1000;
            this.textBoxPaymentIssue.Multiline = true;
            this.textBoxPaymentIssue.Name = "textBoxPaymentIssue";
            this.textBoxPaymentIssue.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxPaymentIssue.Size = new System.Drawing.Size(606, 56);
            this.textBoxPaymentIssue.TabIndex = 552;
            this.textBoxPaymentIssue.Visible = false;
            // 
            // textBoxInstallationImpact
            // 
            this.textBoxInstallationImpact.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.textBoxInstallationImpact.Location = new System.Drawing.Point(306, 158);
            this.textBoxInstallationImpact.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxInstallationImpact.MaxLength = 1000;
            this.textBoxInstallationImpact.Multiline = true;
            this.textBoxInstallationImpact.Name = "textBoxInstallationImpact";
            this.textBoxInstallationImpact.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxInstallationImpact.Size = new System.Drawing.Size(606, 56);
            this.textBoxInstallationImpact.TabIndex = 551;
            this.textBoxInstallationImpact.Visible = false;
            // 
            // textBoxReason
            // 
            this.textBoxReason.Font = new System.Drawing.Font("Calibri", 11.25F);
            this.textBoxReason.Location = new System.Drawing.Point(306, 86);
            this.textBoxReason.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBoxReason.MaxLength = 1000;
            this.textBoxReason.Multiline = true;
            this.textBoxReason.Name = "textBoxReason";
            this.textBoxReason.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxReason.Size = new System.Drawing.Size(606, 56);
            this.textBoxReason.TabIndex = 550;
            this.textBoxReason.Visible = false;
            // 
            // Project_Closer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1962, 1055);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Project_Closer";
            this.Text = resources.GetString("$this.Text");
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Project_Closer_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgBOMprojectstatusList)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ComboBox comselectdispatch;
        private System.Windows.Forms.Label AllitemsasperBOMreadytodispatch;
        private System.Windows.Forms.Label labelPaymentIssue;
        private System.Windows.Forms.Label labelInstallationImpact;
        private System.Windows.Forms.Label labelReason;
        private System.Windows.Forms.DateTimePicker dateTimePickerReadyDate;
        private System.Windows.Forms.Label labelReadyDate;
        private System.Windows.Forms.Label labelcomboBoxOpenPoints;
        private System.Windows.Forms.ComboBox comboBoxOpenPoints;
        private System.Windows.Forms.Label labelAnyopenpoints;
        private System.Windows.Forms.ComboBox comboBoxOpenPoints1;
        private System.Windows.Forms.Label Critical_information;
        private System.Windows.Forms.ComboBox comcreticalinformation;
        private System.Windows.Forms.Label labelBoxCompleteDetails;
        private System.Windows.Forms.Label labelSupportingDocuments;
        private System.Windows.Forms.Label labelLessonLearnt;

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button buttprojectclosersave;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label labelWhowilladdressatsitebyservice;
        private System.Windows.Forms.Label labelThereasonforopenpoints;
        private System.Windows.Forms.DateTimePicker dateTimePickerReadyToFix;
        private System.Windows.Forms.Label labelReadyToFix;
        private System.Windows.Forms.Label labelWhyNotAddressed;
        private System.Windows.Forms.DataGridView dgBOMprojectstatusList;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBoxPaymentIssue;
        private System.Windows.Forms.TextBox textBoxInstallationImpact;
        private System.Windows.Forms.TextBox textBoxReason;
        private System.Windows.Forms.TextBox textWhowilladdressatsitebyservice;
        private System.Windows.Forms.TextBox Thereasonforopenpoints;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox textBoxSupportingDocuments;
        private System.Windows.Forms.TextBox textBoxCompleteDetails;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label labelInstallationImpact1;
        private System.Windows.Forms.TextBox textBoxInstallationImpact1;
        private System.Windows.Forms.TextBox textBoxWhyNotAddressed;
        private System.Windows.Forms.TextBox textBoxPaymentIssue1;
        private System.Windows.Forms.Label labelPaymentIssue1;
        private System.Windows.Forms.TextBox textWhowilladdressatsitebyservice1;
        private System.Windows.Forms.TextBox textThereasonforopenpoints1;
        private System.Windows.Forms.Label labelWhowilladdressatsitebyservice1;
        private System.Windows.Forms.Label labelThereasonforopenpoints1;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox textMandatetoanswerthis;
        private System.Windows.Forms.Label labelProjectClosure;
        private System.Windows.Forms.Button buttprint;
        private System.Windows.Forms.Label labprojeccode1;
        private System.Windows.Forms.ComboBox comsectinsertedProjectcode;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbProjectcode;
        private System.Windows.Forms.Button btnProjectSearch;
    }
}