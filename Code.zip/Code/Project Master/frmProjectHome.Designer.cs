﻿namespace Erp_Project_With_Buttons.Project_Master
{
    partial class frmProjectHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProjectHome));
            this.llProjectInstallation = new System.Windows.Forms.LinkLabel();
            this.llProjectStatus = new System.Windows.Forms.LinkLabel();
            this.llProjectMaster = new System.Windows.Forms.LinkLabel();
            this.llbWarrantyShortShipment = new System.Windows.Forms.LinkLabel();
            this.llbProjectTransfer = new System.Windows.Forms.LinkLabel();
            this.llbProjectTransferRequest = new System.Windows.Forms.LinkLabel();
            this.llbProjectDocs = new System.Windows.Forms.LinkLabel();
            this.llbProjectStatusUpdate = new System.Windows.Forms.LinkLabel();
            this.lblName = new System.Windows.Forms.Label();
            this.lblProjectApprove = new System.Windows.Forms.LinkLabel();
            this.llbGMApprove = new System.Windows.Forms.LinkLabel();
            this.lblAssetMaster = new System.Windows.Forms.LinkLabel();
            this.btnAssetMaster = new System.Windows.Forms.Button();
            this.btnGMApprove = new System.Windows.Forms.Button();
            this.btnProjectApprove = new System.Windows.Forms.Button();
            this.btnProjectStatusupdate = new System.Windows.Forms.Button();
            this.btnProjectDocuments = new System.Windows.Forms.Button();
            this.btnProjectTransferRequest = new System.Windows.Forms.Button();
            this.btnProjectTransfer = new System.Windows.Forms.Button();
            this.btnWarrantyShortShipment = new System.Windows.Forms.Button();
            this.btnProjectInstallation = new System.Windows.Forms.Button();
            this.btnProjectStatus = new System.Windows.Forms.Button();
            this.btnProjectMaster = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.LblProjectTracker = new System.Windows.Forms.LinkLabel();
            this.llbProjectBarcode = new System.Windows.Forms.LinkLabel();
            this.btnProjectBarcode = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // llProjectInstallation
            // 
            this.llProjectInstallation.AutoSize = true;
            this.llProjectInstallation.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llProjectInstallation.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.llProjectInstallation.LinkColor = System.Drawing.Color.MediumBlue;
            this.llProjectInstallation.Location = new System.Drawing.Point(736, 190);
            this.llProjectInstallation.Name = "llProjectInstallation";
            this.llProjectInstallation.Size = new System.Drawing.Size(276, 23);
            this.llProjectInstallation.TabIndex = 13;
            this.llProjectInstallation.TabStop = true;
            this.llProjectInstallation.Text = "Project Installation Status Update";
            this.llProjectInstallation.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llProjectInstallation_LinkClicked);
            // 
            // llProjectStatus
            // 
            this.llProjectStatus.AutoSize = true;
            this.llProjectStatus.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llProjectStatus.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.llProjectStatus.LinkColor = System.Drawing.Color.MediumBlue;
            this.llProjectStatus.Location = new System.Drawing.Point(201, 276);
            this.llProjectStatus.Name = "llProjectStatus";
            this.llProjectStatus.Size = new System.Drawing.Size(183, 23);
            this.llProjectStatus.TabIndex = 11;
            this.llProjectStatus.TabStop = true;
            this.llProjectStatus.Text = "Project Status Update";
            this.llProjectStatus.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llProjectStatus_LinkClicked);
            // 
            // llProjectMaster
            // 
            this.llProjectMaster.AutoSize = true;
            this.llProjectMaster.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llProjectMaster.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.llProjectMaster.LinkColor = System.Drawing.Color.MediumBlue;
            this.llProjectMaster.Location = new System.Drawing.Point(202, 114);
            this.llProjectMaster.Name = "llProjectMaster";
            this.llProjectMaster.Size = new System.Drawing.Size(199, 23);
            this.llProjectMaster.TabIndex = 9;
            this.llProjectMaster.TabStop = true;
            this.llProjectMaster.Text = "Project Create/Approve";
            this.llProjectMaster.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llProjectMaster_LinkClicked);
            // 
            // llbWarrantyShortShipment
            // 
            this.llbWarrantyShortShipment.AutoSize = true;
            this.llbWarrantyShortShipment.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbWarrantyShortShipment.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.llbWarrantyShortShipment.LinkColor = System.Drawing.Color.MediumBlue;
            this.llbWarrantyShortShipment.Location = new System.Drawing.Point(736, 114);
            this.llbWarrantyShortShipment.Name = "llbWarrantyShortShipment";
            this.llbWarrantyShortShipment.Size = new System.Drawing.Size(288, 23);
            this.llbWarrantyShortShipment.TabIndex = 15;
            this.llbWarrantyShortShipment.TabStop = true;
            this.llbWarrantyShortShipment.Text = "Project Warranty / Short Shipment \r\n";
            this.llbWarrantyShortShipment.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbWarrantyShortShipment_LinkClicked);
            // 
            // llbProjectTransfer
            // 
            this.llbProjectTransfer.AutoSize = true;
            this.llbProjectTransfer.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbProjectTransfer.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.llbProjectTransfer.LinkColor = System.Drawing.Color.MediumBlue;
            this.llbProjectTransfer.Location = new System.Drawing.Point(736, 360);
            this.llbProjectTransfer.Name = "llbProjectTransfer";
            this.llbProjectTransfer.Size = new System.Drawing.Size(136, 23);
            this.llbProjectTransfer.TabIndex = 34;
            this.llbProjectTransfer.TabStop = true;
            this.llbProjectTransfer.Text = "Project Transfer";
            this.llbProjectTransfer.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbProjectTransfer_LinkClicked);
            // 
            // llbProjectTransferRequest
            // 
            this.llbProjectTransferRequest.AutoSize = true;
            this.llbProjectTransferRequest.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbProjectTransferRequest.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.llbProjectTransferRequest.LinkColor = System.Drawing.Color.MediumBlue;
            this.llbProjectTransferRequest.Location = new System.Drawing.Point(201, 360);
            this.llbProjectTransferRequest.Name = "llbProjectTransferRequest";
            this.llbProjectTransferRequest.Size = new System.Drawing.Size(206, 23);
            this.llbProjectTransferRequest.TabIndex = 36;
            this.llbProjectTransferRequest.TabStop = true;
            this.llbProjectTransferRequest.Text = "Project Transfer Request";
            this.llbProjectTransferRequest.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbProjectTransferRequest_LinkClicked);
            // 
            // llbProjectDocs
            // 
            this.llbProjectDocs.AutoSize = true;
            this.llbProjectDocs.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbProjectDocs.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.llbProjectDocs.LinkColor = System.Drawing.Color.MediumBlue;
            this.llbProjectDocs.Location = new System.Drawing.Point(202, 452);
            this.llbProjectDocs.Name = "llbProjectDocs";
            this.llbProjectDocs.Size = new System.Drawing.Size(221, 23);
            this.llbProjectDocs.TabIndex = 38;
            this.llbProjectDocs.TabStop = true;
            this.llbProjectDocs.Text = "Project Documents Upload";
            this.llbProjectDocs.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbProjectDocs_LinkClicked);
            // 
            // llbProjectStatusUpdate
            // 
            this.llbProjectStatusUpdate.AutoSize = true;
            this.llbProjectStatusUpdate.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbProjectStatusUpdate.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.llbProjectStatusUpdate.LinkColor = System.Drawing.Color.MediumBlue;
            this.llbProjectStatusUpdate.Location = new System.Drawing.Point(736, 278);
            this.llbProjectStatusUpdate.Name = "llbProjectStatusUpdate";
            this.llbProjectStatusUpdate.Size = new System.Drawing.Size(251, 23);
            this.llbProjectStatusUpdate.TabIndex = 40;
            this.llbProjectStatusUpdate.TabStop = true;
            this.llbProjectStatusUpdate.Text = "Project Shipment Date Update";
            this.llbProjectStatusUpdate.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbProjectStatusUpdate_LinkClicked);
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.Indigo;
            this.lblName.Location = new System.Drawing.Point(458, 9);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(294, 29);
            this.lblName.TabIndex = 42;
            this.lblName.Text = "BiSS Inventory Management";
            // 
            // lblProjectApprove
            // 
            this.lblProjectApprove.AutoSize = true;
            this.lblProjectApprove.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProjectApprove.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.lblProjectApprove.LinkColor = System.Drawing.Color.MediumBlue;
            this.lblProjectApprove.Location = new System.Drawing.Point(736, 455);
            this.lblProjectApprove.Name = "lblProjectApprove";
            this.lblProjectApprove.Size = new System.Drawing.Size(278, 23);
            this.lblProjectApprove.TabIndex = 43;
            this.lblProjectApprove.TabStop = true;
            this.lblProjectApprove.Text = "Capex Project Department Access";
            this.lblProjectApprove.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblProjectApprove_LinkClicked);
            // 
            // llbGMApprove
            // 
            this.llbGMApprove.AutoSize = true;
            this.llbGMApprove.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbGMApprove.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.llbGMApprove.LinkColor = System.Drawing.Color.MediumBlue;
            this.llbGMApprove.Location = new System.Drawing.Point(202, 189);
            this.llbGMApprove.Name = "llbGMApprove";
            this.llbGMApprove.Size = new System.Drawing.Size(184, 23);
            this.llbGMApprove.TabIndex = 45;
            this.llbGMApprove.TabStop = true;
            this.llbGMApprove.Text = "Project BOM Approve";
            this.llbGMApprove.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbGMApprove_LinkClicked);
            // 
            // lblAssetMaster
            // 
            this.lblAssetMaster.AutoSize = true;
            this.lblAssetMaster.Enabled = false;
            this.lblAssetMaster.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAssetMaster.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.lblAssetMaster.LinkColor = System.Drawing.Color.MediumBlue;
            this.lblAssetMaster.Location = new System.Drawing.Point(202, 546);
            this.lblAssetMaster.Name = "lblAssetMaster";
            this.lblAssetMaster.Size = new System.Drawing.Size(113, 23);
            this.lblAssetMaster.TabIndex = 47;
            this.lblAssetMaster.TabStop = true;
            this.lblAssetMaster.Text = "AssetMaster";
            this.lblAssetMaster.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblAssetMaster_LinkClicked);
            // 
            // btnAssetMaster
            // 
            this.btnAssetMaster.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnAssetMaster.Enabled = false;
            this.btnAssetMaster.FlatAppearance.BorderSize = 0;
            this.btnAssetMaster.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAssetMaster.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAssetMaster.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_data_recovery_48;
            this.btnAssetMaster.Location = new System.Drawing.Point(96, 519);
            this.btnAssetMaster.Name = "btnAssetMaster";
            this.btnAssetMaster.Size = new System.Drawing.Size(99, 76);
            this.btnAssetMaster.TabIndex = 48;
            this.btnAssetMaster.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAssetMaster.UseVisualStyleBackColor = true;
            this.btnAssetMaster.Click += new System.EventHandler(this.btnAssetMaster_Click);
            // 
            // btnGMApprove
            // 
            this.btnGMApprove.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnGMApprove.FlatAppearance.BorderSize = 0;
            this.btnGMApprove.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGMApprove.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGMApprove.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_todo_list_483;
            this.btnGMApprove.Location = new System.Drawing.Point(96, 163);
            this.btnGMApprove.Name = "btnGMApprove";
            this.btnGMApprove.Size = new System.Drawing.Size(99, 76);
            this.btnGMApprove.TabIndex = 46;
            this.btnGMApprove.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnGMApprove.UseVisualStyleBackColor = true;
            this.btnGMApprove.Click += new System.EventHandler(this.btnGMApprove_Click);
            // 
            // btnProjectApprove
            // 
            this.btnProjectApprove.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnProjectApprove.FlatAppearance.BorderSize = 0;
            this.btnProjectApprove.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProjectApprove.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProjectApprove.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_multichannel_481;
            this.btnProjectApprove.Location = new System.Drawing.Point(631, 424);
            this.btnProjectApprove.Name = "btnProjectApprove";
            this.btnProjectApprove.Size = new System.Drawing.Size(99, 76);
            this.btnProjectApprove.TabIndex = 44;
            this.btnProjectApprove.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnProjectApprove.UseVisualStyleBackColor = true;
            this.btnProjectApprove.Click += new System.EventHandler(this.btnProjectApprove_Click);
            // 
            // btnProjectStatusupdate
            // 
            this.btnProjectStatusupdate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnProjectStatusupdate.FlatAppearance.BorderSize = 0;
            this.btnProjectStatusupdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProjectStatusupdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProjectStatusupdate.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_timetable_48;
            this.btnProjectStatusupdate.Location = new System.Drawing.Point(631, 250);
            this.btnProjectStatusupdate.Name = "btnProjectStatusupdate";
            this.btnProjectStatusupdate.Size = new System.Drawing.Size(99, 76);
            this.btnProjectStatusupdate.TabIndex = 41;
            this.btnProjectStatusupdate.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnProjectStatusupdate.UseVisualStyleBackColor = true;
            this.btnProjectStatusupdate.Click += new System.EventHandler(this.btnProjectStatusupdate_Click);
            // 
            // btnProjectDocuments
            // 
            this.btnProjectDocuments.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnProjectDocuments.FlatAppearance.BorderSize = 0;
            this.btnProjectDocuments.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProjectDocuments.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProjectDocuments.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_upload_to_ftp_48;
            this.btnProjectDocuments.Location = new System.Drawing.Point(96, 425);
            this.btnProjectDocuments.Name = "btnProjectDocuments";
            this.btnProjectDocuments.Size = new System.Drawing.Size(99, 76);
            this.btnProjectDocuments.TabIndex = 39;
            this.btnProjectDocuments.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnProjectDocuments.UseVisualStyleBackColor = true;
            this.btnProjectDocuments.Click += new System.EventHandler(this.btnProjectDocuments_Click);
            // 
            // btnProjectTransferRequest
            // 
            this.btnProjectTransferRequest.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnProjectTransferRequest.FlatAppearance.BorderSize = 0;
            this.btnProjectTransferRequest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProjectTransferRequest.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProjectTransferRequest.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_change_48;
            this.btnProjectTransferRequest.Location = new System.Drawing.Point(96, 335);
            this.btnProjectTransferRequest.Name = "btnProjectTransferRequest";
            this.btnProjectTransferRequest.Size = new System.Drawing.Size(99, 76);
            this.btnProjectTransferRequest.TabIndex = 37;
            this.btnProjectTransferRequest.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnProjectTransferRequest.UseVisualStyleBackColor = true;
            this.btnProjectTransferRequest.Click += new System.EventHandler(this.btnProjectTransferRequest_Click);
            // 
            // btnProjectTransfer
            // 
            this.btnProjectTransfer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnProjectTransfer.FlatAppearance.BorderSize = 0;
            this.btnProjectTransfer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProjectTransfer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProjectTransfer.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_transfer_48;
            this.btnProjectTransfer.Location = new System.Drawing.Point(631, 335);
            this.btnProjectTransfer.Name = "btnProjectTransfer";
            this.btnProjectTransfer.Size = new System.Drawing.Size(99, 76);
            this.btnProjectTransfer.TabIndex = 35;
            this.btnProjectTransfer.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnProjectTransfer.UseVisualStyleBackColor = true;
            this.btnProjectTransfer.Click += new System.EventHandler(this.btnProjectTransfer_Click);
            // 
            // btnWarrantyShortShipment
            // 
            this.btnWarrantyShortShipment.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnWarrantyShortShipment.FlatAppearance.BorderSize = 0;
            this.btnWarrantyShortShipment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWarrantyShortShipment.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWarrantyShortShipment.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_hierarchy_48;
            this.btnWarrantyShortShipment.Location = new System.Drawing.Point(631, 76);
            this.btnWarrantyShortShipment.Name = "btnWarrantyShortShipment";
            this.btnWarrantyShortShipment.Size = new System.Drawing.Size(99, 76);
            this.btnWarrantyShortShipment.TabIndex = 16;
            this.btnWarrantyShortShipment.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnWarrantyShortShipment.UseVisualStyleBackColor = true;
            this.btnWarrantyShortShipment.Click += new System.EventHandler(this.btnWarrantyShortShipment_Click);
            // 
            // btnProjectInstallation
            // 
            this.btnProjectInstallation.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnProjectInstallation.FlatAppearance.BorderSize = 0;
            this.btnProjectInstallation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProjectInstallation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProjectInstallation.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_paste_48__1_1;
            this.btnProjectInstallation.Location = new System.Drawing.Point(631, 163);
            this.btnProjectInstallation.Name = "btnProjectInstallation";
            this.btnProjectInstallation.Size = new System.Drawing.Size(99, 76);
            this.btnProjectInstallation.TabIndex = 14;
            this.btnProjectInstallation.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnProjectInstallation.UseVisualStyleBackColor = true;
            this.btnProjectInstallation.Click += new System.EventHandler(this.btnProjectInstallation_Click);
            // 
            // btnProjectStatus
            // 
            this.btnProjectStatus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnProjectStatus.FlatAppearance.BorderSize = 0;
            this.btnProjectStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProjectStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProjectStatus.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_order_history_48__1_;
            this.btnProjectStatus.Location = new System.Drawing.Point(96, 249);
            this.btnProjectStatus.Name = "btnProjectStatus";
            this.btnProjectStatus.Size = new System.Drawing.Size(99, 76);
            this.btnProjectStatus.TabIndex = 12;
            this.btnProjectStatus.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnProjectStatus.UseVisualStyleBackColor = true;
            this.btnProjectStatus.Click += new System.EventHandler(this.btnProjectStatus_Click);
            // 
            // btnProjectMaster
            // 
            this.btnProjectMaster.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnProjectMaster.FlatAppearance.BorderSize = 0;
            this.btnProjectMaster.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProjectMaster.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProjectMaster.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_add_file_48__3_1;
            this.btnProjectMaster.Location = new System.Drawing.Point(96, 77);
            this.btnProjectMaster.Name = "btnProjectMaster";
            this.btnProjectMaster.Size = new System.Drawing.Size(99, 76);
            this.btnProjectMaster.TabIndex = 10;
            this.btnProjectMaster.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnProjectMaster.UseVisualStyleBackColor = true;
            this.btnProjectMaster.Click += new System.EventHandler(this.btnProjectMaster_Click);
            // 
            // button1
            // 
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button1.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_purchase_order_48__2_1;
            this.button1.Location = new System.Drawing.Point(631, 506);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(99, 78);
            this.button1.TabIndex = 49;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // LblProjectTracker
            // 
            this.LblProjectTracker.AutoSize = true;
            this.LblProjectTracker.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblProjectTracker.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.LblProjectTracker.LinkColor = System.Drawing.Color.MediumBlue;
            this.LblProjectTracker.Location = new System.Drawing.Point(736, 533);
            this.LblProjectTracker.Name = "LblProjectTracker";
            this.LblProjectTracker.Size = new System.Drawing.Size(128, 23);
            this.LblProjectTracker.TabIndex = 50;
            this.LblProjectTracker.TabStop = true;
            this.LblProjectTracker.Text = "Project Tracker";
            this.LblProjectTracker.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LblProjectTracker_LinkClicked);
            // 
            // llbProjectBarcode
            // 
            this.llbProjectBarcode.AutoSize = true;
            this.llbProjectBarcode.Enabled = false;
            this.llbProjectBarcode.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.llbProjectBarcode.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.llbProjectBarcode.LinkColor = System.Drawing.Color.MediumBlue;
            this.llbProjectBarcode.Location = new System.Drawing.Point(202, 628);
            this.llbProjectBarcode.Name = "llbProjectBarcode";
            this.llbProjectBarcode.Size = new System.Drawing.Size(139, 23);
            this.llbProjectBarcode.TabIndex = 51;
            this.llbProjectBarcode.TabStop = true;
            this.llbProjectBarcode.Text = "Project QR Code";
            this.llbProjectBarcode.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbProjectBarcode_LinkClicked);
            // 
            // btnProjectBarcode
            // 
            this.btnProjectBarcode.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnProjectBarcode.Enabled = false;
            this.btnProjectBarcode.FlatAppearance.BorderSize = 0;
            this.btnProjectBarcode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProjectBarcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProjectBarcode.Image = global::Erp_Project_With_Buttons.Properties.Resources.icons8_check_48;
            this.btnProjectBarcode.Location = new System.Drawing.Point(96, 601);
            this.btnProjectBarcode.Name = "btnProjectBarcode";
            this.btnProjectBarcode.Size = new System.Drawing.Size(99, 76);
            this.btnProjectBarcode.TabIndex = 52;
            this.btnProjectBarcode.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnProjectBarcode.UseVisualStyleBackColor = true;
            this.btnProjectBarcode.Click += new System.EventHandler(this.btnProjectBarcode_Click);
            // 
            // frmProjectHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(1212, 685);
            this.Controls.Add(this.llbProjectBarcode);
            this.Controls.Add(this.btnProjectBarcode);
            this.Controls.Add(this.LblProjectTracker);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblAssetMaster);
            this.Controls.Add(this.btnAssetMaster);
            this.Controls.Add(this.llbGMApprove);
            this.Controls.Add(this.btnGMApprove);
            this.Controls.Add(this.lblProjectApprove);
            this.Controls.Add(this.btnProjectApprove);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.llbProjectStatusUpdate);
            this.Controls.Add(this.btnProjectStatusupdate);
            this.Controls.Add(this.llbProjectDocs);
            this.Controls.Add(this.btnProjectDocuments);
            this.Controls.Add(this.llbProjectTransferRequest);
            this.Controls.Add(this.btnProjectTransferRequest);
            this.Controls.Add(this.llbProjectTransfer);
            this.Controls.Add(this.btnProjectTransfer);
            this.Controls.Add(this.llbWarrantyShortShipment);
            this.Controls.Add(this.btnWarrantyShortShipment);
            this.Controls.Add(this.llProjectInstallation);
            this.Controls.Add(this.btnProjectInstallation);
            this.Controls.Add(this.llProjectStatus);
            this.Controls.Add(this.btnProjectStatus);
            this.Controls.Add(this.llProjectMaster);
            this.Controls.Add(this.btnProjectMaster);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmProjectHome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Project Master";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmProjectHome_FormClosing);
            this.Load += new System.EventHandler(this.frmProjectHome_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.LinkLabel llProjectInstallation;
        private System.Windows.Forms.Button btnProjectInstallation;
        private System.Windows.Forms.LinkLabel llProjectStatus;
        private System.Windows.Forms.Button btnProjectStatus;
        private System.Windows.Forms.LinkLabel llProjectMaster;
        private System.Windows.Forms.Button btnProjectMaster;
        private System.Windows.Forms.LinkLabel llbWarrantyShortShipment;
        private System.Windows.Forms.Button btnWarrantyShortShipment;
        private System.Windows.Forms.LinkLabel llbProjectTransfer;
        private System.Windows.Forms.Button btnProjectTransfer;
        private System.Windows.Forms.LinkLabel llbProjectTransferRequest;
        private System.Windows.Forms.Button btnProjectTransferRequest;
        private System.Windows.Forms.LinkLabel llbProjectDocs;
        private System.Windows.Forms.Button btnProjectDocuments;
        private System.Windows.Forms.LinkLabel llbProjectStatusUpdate;
        private System.Windows.Forms.Button btnProjectStatusupdate;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.LinkLabel lblProjectApprove;
        private System.Windows.Forms.Button btnProjectApprove;
        private System.Windows.Forms.LinkLabel llbGMApprove;
        private System.Windows.Forms.Button btnGMApprove;
        private System.Windows.Forms.LinkLabel lblAssetMaster;
        private System.Windows.Forms.Button btnAssetMaster;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.LinkLabel LblProjectTracker;
        private System.Windows.Forms.LinkLabel llbProjectBarcode;
        private System.Windows.Forms.Button btnProjectBarcode;
    }
}
