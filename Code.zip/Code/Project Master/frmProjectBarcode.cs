﻿using System;
using System.Data;
using System.IO;
using System.Windows.Forms;


namespace Erp_Project_With_Buttons.Project_Master
{
    public partial class frmProjectBarcode : Form
    {
        public frmProjectBarcode()
        {
            InitializeComponent();
        }
        Global GlobalClass = new Global();
        frmForm2 frm = new frmForm2();
        DataAccessLayer DAL = new DataAccessLayer();
        frmProjectmaster form = new frmProjectmaster();
        Login.frmLoginForm login = new Login.frmLoginForm();
        DataTable dtProjectList = new DataTable();
        private void frmProjectBarcode_Load(object sender, EventArgs e)
        {
            fnProjectLoad();
        }

        private void fnProjectLoad()
        {
            dtProjectList = DAL.fnCutomerProjectList(null).Tables[0];
        }

        private void txtprojectname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar == '%'))
            {
                e.Handled = true;
            }
        }

        private void txtprojectname_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Back)
            {
                Row();
            }
            else
            {
                Row();
            }
        }

        private void Row()
        {
            dvItemList = RowFilter(dtProjectList, txtprojectname.Text);
            RowFilter();
        }

        private void RowFilter()
        {
            chkProjectList.Items.Clear();
            foreach (DataRowView dr in dvItemList)
            {
                chkProjectList.Items.Add(string.Concat(dr["ProjectCode"].ToString(), "`", dr["ProjectDescription"].ToString(), ", ", dr["Customer"].ToString(), ", ", dr["Status"].ToString()));
            }
        }
        DataView dvItemList = new DataView();
        public DataView RowFilter(DataTable dtProject, string sRowfilter)
        {
            if (sRowfilter.Length > 0)
            {
                dvItemList = new DataView(dtProject);
                dvItemList.RowFilter = "ProjectCode like '%" + sRowfilter + "%' or ProjectDescription like '%" + sRowfilter + "%' or Customer like '%" + sRowfilter + "%'";
            }

            return dvItemList;
        }

        private void frmProjectBarcode_FormClosing(object sender, FormClosingEventArgs e)
        {
            fnClose();
        }

        private void fnClose()
        {
            this.Hide();
            frm.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            fnClose();
        }

        bool bQRDate = false;
        private void dtpQRDate_ValueChanged(object sender, EventArgs e)
        {
            bQRDate = true;


            txtQRCode.Text = txtSlNo.Text + " " + dtpQRDate.Value.Year.ToString("D4").Substring(2) + dtpQRDate.Value.Month.ToString("D2") + txtCount.Text;
        }

        DataTable dtProjectQRCode = new DataTable();
        DataTable dtProjectcount = new DataTable();
        private void chkProjectList_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            bQRDate = false;
            txtQRCode.ResetText();
            txtSlNo.ResetText();
            txtCount.ResetText();
            if (!chkProjectList.CheckedItems.Contains(chkProjectList.SelectedItem))
            {
                string[] sProjectCode = chkProjectList.SelectedItem.ToString().Trim().Split('`');
                DataView dvProjectName = new DataView(dtProjectList);
                dvProjectName.RowFilter = "ProjectCode='" + sProjectCode[0] + "'";
                if (dvProjectName.ToTable().Rows.Count > 0)
                {
                    dtProjectQRCode = DAL.fnProjectQRCode(0, sProjectCode[0]).Tables[0];

                    if (dtProjectQRCode.Rows.Count > 0)
                    {
                        dgvProjHistory.AutoGenerateColumns = false;
                        dgvProjHistory.DataSource = dtProjectQRCode;
                        txtSlNo.Text = dtProjectQRCode.Rows[0]["Id"].ToString();

                        DataTable dtSLno = new DataTable();

                        dtSLno = DAL.fnProjectQRCode(0, dtProjectQRCode.Rows[0]["StockProjectCode"].ToString()).Tables[0];
                        if (dtSLno.Rows.Count > 0)
                        {
                            txtSlNo.Text = dtSLno.Rows[0]["Id"].ToString();
                        }
                    }
                    else
                    {
                        dgvProjHistory.DataSource = null;
                    }

                    dtProjectcount = DAL.fnProjectQRCode(1, sProjectCode[0]).Tables[0];
                    if (dtProjectcount.Rows.Count > 0)
                    {
                        int iProjectcount = Convert.ToInt32(dtProjectcount.Rows[0]["ProjectCount"].ToString());
                        iProjectcount++;
                        txtCount.Text = iProjectcount.ToString("D4");
                    }                   
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (dgvProjHistory.Rows.Count > 0)
            {
                bool bNullCheck = false;
                foreach (DataGridViewRow row in dgvProjHistory.Rows)
                {
                    if (row.Cells["ProjectCount"].Value == DBNull.Value)
                    {
                        bNullCheck = true;
                    }
                }

                if (bNullCheck && bQRDate)
                {

                    GlobalClass.iStatus = DAL.fnAddProjectQRCode(0, dgvProjHistory.Rows[0].Cells[0].Value.ToString(), txtCount.Text, (dtpQRDate.Value.Year.ToString("D4").Substring(2) + dtpQRDate.Value.Month.ToString("D2")).ToString(), login.GetUserDetails[2], dtpQRDate.Text,txtSlNo.Text);

                    MessageBox.Show("Selected project code QR code generated.", "Information", 0, MessageBoxIcon.Information);

                    btnDownloadQRCode_Click(sender, e);

                    this.Hide();
                    frmProjectBarcode frmProjectBarcode = new frmProjectBarcode();
                    frmProjectBarcode.Show();
                }
                else
                {
                    if (!bNullCheck)
                    {
                        MessageBox.Show("Selected project code QR code already generated.\nPlease recheck the selected project code.", "Error", 0, MessageBoxIcon.Error);
                    }
                    else if (!bQRDate)
                    {
                        MessageBox.Show("Select project ship date.", "Error", 0, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void btnDownloadQRCode_Click(object sender, EventArgs e)
        {
            Zen.Barcode.CodeQrBarcodeDraw qrcode = Zen.Barcode.BarcodeDrawFactory.CodeQr;
            pictureBox1.Image = qrcode.Draw(txtQRCode.Text, 70);
            SaveImageCapture(pictureBox1.Image);
        }

        public static void SaveImageCapture(System.Drawing.Image image)
        {
            SaveFileDialog s = new SaveFileDialog();
            s.FileName = "Image";// Default file name
            s.DefaultExt = ".Jpg";// Default file extension
            s.Filter = "Image (.jpg)|*.jpg"; // Filter files by extension

            // Show save file dialog box
            // Process save file dialog box results
            if (s.ShowDialog() == DialogResult.OK)
            {
                // Save Image
                string filename = s.FileName;
                FileStream fstream = new FileStream(filename, FileMode.Create);
                image.Save(fstream, System.Drawing.Imaging.ImageFormat.Jpeg);
                fstream.Close();

            }
        }

        private void txtprojectname_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
